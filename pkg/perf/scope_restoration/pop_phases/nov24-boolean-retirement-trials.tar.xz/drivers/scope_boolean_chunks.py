from study import *
import scope_boolean_run as sb
from types import SimpleNamespace
d=w/'scope-boolean-chunks';d.mkdir(exist_ok=True)
def edits(v):
 ed=sb.edits('run4');q=sb.q;s=ed[q];hp=sb.hp;he=ed[hp]
 if v=='audit':
  x='for len(s.coreTrail) > scope.coreTrailLimit {';s=once(s,x,'''defer func(){if len(s.scopes)==1{fmt.Fprintln(os.Stderr,"RUN-COUNT",trialRuns);trialRuns=[11]uint64{}}}()
  '''+x);s=once(s,'import (','import (\n"os"') if '"os"'not in s else s
  x='func(s *SMTInternalizerState)trialRetireBooleanRun(';s=once(s,x,'var trialRuns [11]uint64\n'+x)
  for a,b in [('if smtcoreSourceDebug','trialRuns[0]++;if smtcoreSourceDebug'),('if size<minimum{return false}','if size<minimum{trialRuns[2]++;return false};trialRuns[3]+=uint64(size)'),('if !s.basicActivity.TrialCanEraseRange(int32(low),int32(high))|| !s.delayedActivity.TrialCanEraseRange(int32(low),int32(high)){return false}','if !s.basicActivity.TrialCanEraseRange(int32(low),int32(high)){trialRuns[4]++;return false};if !s.delayedActivity.TrialCanEraseRange(int32(low),int32(high)){trialRuns[5]++;return false}'),('if n==0{return false}','if n==0{trialRuns[6]++;return false};trialRuns[7]+=uint64(n)')]:
   i=s.index('func(s *SMTInternalizerState)trialRetireBooleanRun(');s=s[:i]+once(s[i:],a,b)
  ed[q]=s;return ed
 if v=='skip':
  x='for len(s.coreTrail) > scope.coreTrailLimit {';s=once(s,x,'tryRun:=true\n'+x);s=once(s,'if len(s.coreTrail)-scope.coreTrailLimit>=4 && s.trialRetireBooleanRun(scope,4){continue}','if tryRun && len(s.coreTrail)-scope.coreTrailLimit>=4{if s.trialRetireBooleanRun(scope,4){continue};tryRun=false}');s=once(s,'switch top {','if top!=smtCoreTrailBoolVar{tryRun=true}\nswitch top {')
 elif v.startswith('chunk'):
  cap=int(v[5:]);s=once(s,'available:=min(top-scope.coreTrailLimit,len(s.booleanTrail())-scope.booleanLimit)','available:=min('+str(cap)+',top-scope.coreTrailLimit,len(s.booleanTrail())-scope.booleanLimit)')
 elif v in ('erase','erase-fast','natural'):
  # Calling each heap's existing EraseIfPresent preserves the exact order of
  # arbitrary heap permutations. Reject overflow before mutating the references.
  p1='if !s.basicActivity.TrialCanEraseRange(int32(low),int32(high))|| !s.delayedActivity.TrialCanEraseRange(int32(low),int32(high)){return false}'
  p2='s.basicActivity.TrialEraseRange(int32(low),int32(high));s.delayedActivity.TrialEraseRange(int32(low),int32(high))'
  s=once(s,p1,'if !s.basicActivity.TrialCanEraseActivity(size) || !s.delayedActivity.TrialCanEraseActivity(size){return false}')
  s=once(s,p2,'');x='s.context.exprs.retireBoolean(s.boolExpr[i],s.relevancy==nil)';s=once(s,x,'if err:=s.basicActivityDeleted(int32(i));err!=nil{panic(err)}\n'+x)
  # Only solver-created heaps, with the exact borrowed activity vector, can
  # participate. There are no user comparator callbacks in this branch.
  s=s.replace('TrialCanEraseActivity(size)','TrialCanEraseActivity(size,&s.activity)')
  he=sb.hp.read_text()+'''
func(h *Int)TrialCanEraseActivity(count int,a *[]float64)bool{return h==nil || h.self==h && !h.closed && h.activity==a && uint64(count)<=^uint64(0)-h.epoch && !diagnostic.DebugBuild}
'''
  if v=='erase-fast':
   x='if err:=s.basicActivityDeleted(int32(i));err!=nil{panic(err)}';s=once(s,x,'if s.basicActivity!=nil{s.basicActivity.EraseIfPresent(int32(i))};if s.delayedActivity!=nil{s.delayedActivity.EraseIfPresent(int32(i))}')
  if v=='natural':
   he+='''func(h *Int)TrialDropReverse(lo,hi int32){if h==nil{return};for v:=hi-1;v>=lo;v--{if e:=h.EraseIfPresent(v);e!=nil{panic(e)}}}\n'''
   x='if err:=s.basicActivityDeleted(int32(i));err!=nil{panic(err)}';s=once(s,x,'');x='for i:=high-1;i>=low;i-- {';s=once(s,x,'s.basicActivity.TrialDropReverse(int32(low),int32(high));s.delayedActivity.TrialDropReverse(int32(low),int32(high));'+x)
  ed[hp]=he
 ed[q]=s;return ed
def mk(v):
 od=d/v;o=overlay(od/'overlay',edits(v));b=od/'smt.test'
 with(w/'build.lock').open('a')as f,(od/'focused.txt').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-c','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=log,stderr=log)
  run([b,'-test.run=Pop|Restore|Retire|Backtrack|Scope','-test.count=1'],cwd=pkg/'smtcore',stdout=log,stderr=log)
  if v=='audit':
   run([b,'-test.run=^$','-test.bench','^BenchmarkSMTScopeRestorationWithQueue$/^ScopedAtoms$','-test.benchtime=2x'],cwd=pkg/'smtcore',stdout=log,stderr=log);return b,None
  gated=sb.me.build_go(od/'gated',o,'instructions:u')
 return b,gated
def main():
 vs=['audit','skip','chunk8','chunk24','erase','erase-fast','natural'];sb.d=d
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 bs.pop('audit');bs={'control':(w/'scope-boolean-run/control/smtcore.test',w/'scope-boolean-run/control/gated/bench'),'single':(w/'scope-boolean-run/single/smtcore.test',w/'scope-boolean-run/single/gated/bench')}|bs
 with ThreadPoolExecutor(2)as e:
  fs=[e.submit(sb.gates,{v:b[1]for v,b in bs.items()}|{'native':w/'scope-finalist/gated/native/bench'}),e.submit(sb.wall,{v:b[0]for v,b in bs.items()}|{'native':pkg.parent/'build/test-z3'})]
  for f in fs:f.result()
if __name__=='__main__':main()
