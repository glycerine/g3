from study import *
from types import SimpleNamespace
import importlib.util
sp=importlib.util.spec_from_file_location('smeasure',pkg/'perf/scope_restoration/pop_phases/measure.py');s=importlib.util.module_from_spec(sp);sp.loader.exec_module(s)
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
from rotating_verification import ticks,idle,thread_siblings
os.environ.update(env)
d=w/'scope-queue-final';d.mkdir(exist_ok=True)
def phases():
 a=SimpleNamespace(iterations=1508,timeout=240,thread_event='instructions:u',cpu=45)
 with(w/'build.lock').open('a')as f:
  fcntl.flock(f,fcntl.LOCK_SH);g=s.build_go(d/'gated',None,True)
 n=w/'scope-finalist/gated/native/bench'
 with(d/'phases.csv').open('w')as f:
  z=csv.writer(f);z.writerow('case phase cpu pair engine intervals instructions enabled running'.split())
  for i in range(9):
   for c in s.CASES:
    for p in (s.PHASES if c=='ScopedAtoms'else ('empty','pop')):
     for k,b in ([('g3',g),('native',n)]if i%2==0 else [('native',n),('g3',g)]):
      z.writerow([c,p,a.cpu,i+1,k,*s.measure(d/f'{i}-{c}-{p}-{k}',b,k,c,p,a)]);f.flush()
def quiet():
 b=d/'smt.test'
 with(w/'build.lock').open('a')as bl:
  fcntl.flock(bl,fcntl.LOCK_SH);run(['go','test','-c','-pgo=off','-o',b,'./smtcore'],cwd=pkg)
 cpu=15;sibs=thread_siblings(cpu);cpus=[cpu,*sibs]
 q=w/'quantifier-release/ordinary-quiet/runs.csv'
 def qual():return sum(int(x['match'])==1 and min(float(x['cpu_fraction']),float(x['sibling_idle_during']))>=.95 for x in csv.DictReader(q.open()))
 while qual()<21:time.sleep(7)
 with(d/'quiet.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine attempt cpu sibling_idle cpu_fraction scoped_ns surviving_ns'.split())
  for i in range(13):
   for k in (['g3','native']if i%2==0 else ['native','g3']):
    for att in range(100):
     before=ticks(cpus);time.sleep(1.5);start=ticks(cpus)
     if min(idle(before,start,c)for c in cpus)<.95:time.sleep(2);continue
     cmd=['taskset','-c',str(cpu)]+([b,'-test.run=^$','-test.bench=^BenchmarkSMTScopeRestorationWithQueue$','-test.benchtime=10000x','-test.cpu=1'] if k=='g3'else[pkg.parent/'build/test-z3','smt_scope_restoration','10000','Both'])
     out=d/f'quiet-{i}-{k}-{att}.txt'
     with out.open('w')as o:
      t=time.monotonic()
      with subprocess.Popen(cmd,env=dict(env,GOMAXPROCS='1'),stdout=o,stderr=subprocess.STDOUT)as proc:
       _,status,u=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
      elapsed=time.monotonic()-t
     end=ticks(cpus);occ=(u.ru_utime+u.ru_stime)/elapsed;si=min([idle(start,end,x)for x in sibs]or[1])
     assert proc.returncode==0,out
     rows={}
     for line in out.read_text().splitlines():
      m=re.search(r'BenchmarkSMTScopeRestoration(?:WithQueue)?/(ScopedAtoms|SurvivingAtoms)',line)
      if m:rows[m[1]]=float(re.search(r'([\d.]+) '+('pop-ns/op'if k=='g3'else'ns/op'),line)[1])
     assert len(rows)==2,(out,rows)
     z.writerow([i+1,k,att+1,cpu,si,occ,rows['ScopedAtoms'],rows['SurvivingAtoms']]);f.flush()
     if min(occ,si)>=.95:break
    else:raise RuntimeError((i,k))
with ThreadPoolExecutor(2)as e:
 fs=[e.submit(fn)for fn in (quiet,phases)]
 for f in fs:f.result()
