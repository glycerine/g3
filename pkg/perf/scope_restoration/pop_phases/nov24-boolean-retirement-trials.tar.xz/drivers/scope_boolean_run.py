from study import *
from types import SimpleNamespace
import importlib.util,guarded_live as gl,macro_identity as mi
sp=importlib.util.spec_from_file_location('popmeasure',pkg/'perf/scope_restoration/pop_phases/measure.py');me=importlib.util.module_from_spec(sp);sp.loader.exec_module(me)
os.environ.update(env)
d=w/'scope-boolean-run';d.mkdir(exist_ok=True)
q=pkg/'smtcore/smt_internalizer_state.go';a=pkg/'ast/ast_core_accessors.go';hp=pkg/'util/heap/heap.go'
def edits(v):
 if v=='control':return {}
 s=q.read_text();ed={}
 if v=='single':
  z=a.read_text();y='// DecRefHeldConsumed is';ed[a]=once(z,y,'''// TrialDecShared consumes a held, surviving reference.
  func(m *ASTManager)TrialDecShared(h ASTHandle)bool{if !astValidateHandles && h.slot!=0 && m.lockFree(){n:=m.nodeAt(h.slot);if n.rc>1{n.rc--;return true}};return false}
  '''+y)
  x='s.retiringBoolean, s.retiringBooleanRoot = true, expression';s=once(s,x,'''if s.manager.TrialDecShared(expression){s.coreTrail=s.coreTrail[:len(s.coreTrail)-1];s.statistics.NumDelBoolVar++;continue}
  '''+x);ed[q]=s;return ed
 minimum=int(v.removeprefix('run'));s=once(s,'top := s.coreTrail[len(s.coreTrail)-1]','''if len(s.coreTrail)-scope.coreTrailLimit>='''+str(minimum)+''' && s.trialRetireBooleanRun(scope,'''+str(minimum)+'''){continue}
 top := s.coreTrail[len(s.coreTrail)-1]''')
 s+='''
// Experimental suffix of callback-free boolean removals. All table and heap
// operations after the first decrement are infallible for the checked range.
func(s *SMTInternalizerState)trialRetireBooleanRun(scope smtInternalizerScope,minimum int)bool{
 if smtcoreSourceDebug || ast.ASTValidateHandles || s.retiringBoolean || s.theoryAwareBranching!=nil || s.relevanceActivity.delayed!=nil {return false}
 top:=len(s.coreTrail);high:=len(s.boolExpr)
 available:=min(top-scope.coreTrailLimit,len(s.booleanTrail())-scope.booleanLimit)
 cache:=(s.cachedActivity || s.caseSplitStrategy==2) && s.searching
 size:=0
 for size<available && s.coreTrail[top-1-size]==smtCoreTrailBoolVar{
  v:=high-1-size
  if v<s.equalityAtomCursor || (cache && s.activity[v]>0){break}
  size++
 }
 if size<minimum{return false}
 low:=high-size
 if !s.basicActivity.TrialCanEraseRange(int32(low),int32(high))|| !s.delayedActivity.TrialCanEraseRange(int32(low),int32(high)){return false}
 n:=s.manager.TrialReleaseRetainedApps(s.boolExpr[low:high])
 if n==0{return false}
 low=high-n
 s.basicActivity.TrialEraseRange(int32(low),int32(high));s.delayedActivity.TrialEraseRange(int32(low),int32(high))
 for i:=high-1;i>=low;i-- {
  s.context.exprs.retireBoolean(s.boolExpr[i],s.relevancy==nil)
  if page:=s.gatePage(int32(i));page!=nil{slot:=uint32(i)%smtBoolGatesPerPage;if page.compound!=nil{page.compound.gates[slot]=nil};if page.notChildren!=nil{page.notChildren[slot]=ast.ASTHandle{}}}
  s.booleanData[i].SetNullJustification();s.watches[2*i].recycle();s.watches[2*i+1].recycle()
 }
 s.boolExpr=s.boolExpr[:low];s.booleanData=s.booleanData[:low];s.activity=s.activity[:low];s.assignment=s.assignment[:2*low];s.watches=s.watches[:2*low]
 s.coreTrail=s.coreTrail[:top-n];s.statistics.NumDelBoolVar+=uint32(n)
 return true
}
'''
 ed[q]=s;ed[a]=a.read_text()+'''
func(m *ASTManager)TrialReleaseRetainedApps(hs []ASTHandle)int{
 if astValidateHandles || m==nil || !m.lockFree(){return 0}
 count:=0
 for i:=len(hs)-1;i>=0;i--{h:=hs[i];if h.slot==0 || h.origin!=m.origin || h.slot>=m.nextNode{break};n:=m.nodeAt(h.slot);if !n.live || n.generation!=h.generation || n.rc<=1 || n.kind!=ASTApp{break};n.rc--;count++}
 return count
}
'''
 ed[hp]=hp.read_text()+'''
func(h *Int)TrialCanEraseRange(lo,hi int32)bool{
 if h==nil{return true}
 if diagnostic.DebugBuild || h.self!=h || h.closed{return false}
 end:=len(h.values)-1
 for v:=min(hi,int32(len(h.indices)))-1;v>=lo;v--{
  pos:=h.indices[v];if pos==0{continue}
  if pos!=int32(end) || h.values[end]!=v{return false};end--
 }
 return uint64(len(h.values)-1-end)<=^uint64(0)-h.epoch
}
func(h *Int)TrialEraseRange(lo,hi int32){
 if h==nil{return}
 limit:=len(h.values)
 for limit>1 && h.values[limit-1]>=lo && h.values[limit-1]<hi{limit--}
 h.epoch+=uint64(len(h.values)-limit);h.values=h.values[:limit]
 if hi=min(hi,int32(len(h.indices)));hi>lo{clear(h.indices[lo:hi])}
}
'''
 return ed
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v));b=od/'smtcore.test'
 with(w/'build.lock').open('a')as f,(od/'tests.log').open('w')as out:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','3','-c','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=out,stderr=out)
  run([b,'-test.run','Scope|Pop|Retir|Restor|VarData|Activity|Interrupted|SMTRelevanc'],cwd=pkg/'smtcore',stdout=out,stderr=out)
  g=me.build_go(od/'gated',o,'instructions:u')
 return b,g,build(od/'checker',o=o)
def gates(bs):
 with(d/'phases.csv').open('w')as f:
  z=csv.writer(f);z.writerow('case phase cpu pair engine intervals instructions enabled running'.split());a=SimpleNamespace(cpu=45,iterations=1508,timeout=240,thread_event='instructions:u')
  for i in range(9):
   for c,ps in [('ScopedAtoms',['empty','undo','pop']),('SurvivingAtoms',['empty','pop'])]:
    for p in ps:
     vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
     for v in vs:
      r=me.measure(d/f'g-{i}-{c}-{p}-{v}',bs[v],v,c,p,a);z.writerow([c,p,a.cpu,i+1,v,*r]);f.flush()
def wall(bs):
 with(d/'wall.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine case iterations ns cpu'.split())
  for i in range(13):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in vs:
    cmd=['taskset','-c','15',bs[v]]
    if v=='native':cmd+=['smt_scope_restoration','10000','Both']
    else:cmd+=['-test.run=^$','-test.bench=^BenchmarkSMTScopeRestorationWithQueue$','-test.cpu=1','-test.benchtime=10000x']
    r=run(cmd,env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True);rows=[]
    for line in r.stdout.splitlines():
     m=re.search(r'BenchmarkSMTScopeRestoration(?:WithQueue)?/(ScopedAtoms|SurvivingAtoms)\s+(\d+)',line)
     if m:rows.append([i+1,v,m[1],m[2],re.search(r'([\d.]+) '+('ns/op'if v=='native'else'pop-ns/op'),line)[1],15])
    assert len(rows)==2 and all(r[3]=='10000'for r in rows),(cmd,r.stdout);z.writerows(rows);f.flush()
def main():
 vs=['control','single','run4','run12','run32']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 bb={v:b[2]for v,b in bs.items()};gl.d=d
 js=[(cpu,*j[1:5],3,j[-1])for cpu,j in zip([25,26,28,30,33,35,42,43],(j for j in mi.jobs()if j[1]not in ('ordinary','dramc_nb2')))]
 with ThreadPoolExecutor(len(js)+2)as e:
  fs=[e.submit(gates,{v:b[1]for v,b in bs.items()}|{'native':w/'scope-finalist/gated/native/bench'}),e.submit(wall,{v:b[0]for v,b in bs.items()}|{'native':pkg.parent/'build/test-z3'})]+[e.submit(gl.measure_job,j,bb)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
