from common import *
import resource
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
from rotating_verification import ticks,idle,thread_siblings
label=sys.argv[1] if len(sys.argv)>1 else 'retirement'
root=d/('quiet-scopes-'+label);root.mkdir(exist_ok=True)
items=sys.argv[2:];bs={items[i]:Path(items[i+1]).resolve(strict=True)for i in range(0,len(items),2)} if items else {'before':d/'scope-release/control/smt.test','after':d/'release-scope-ranges/smt.test','native':pkg.parent/'build/test-z3'}
assert 'native'in bs
def cpuuse():
 r=resource.getrusage(resource.RUSAGE_CHILDREN);return r.ru_utime+r.ru_stime
def measure(v,b,c,attempt):
 args=['taskset','-c',str(c),b]
 if v=='native':args+=['smt_scope_restoration','10000','Both']
 else:args+=['-test.run=^$','-test.cpu=1','-test.bench=^BenchmarkSMTScopeRestoration(WithQueue)?$','-test.benchtime=10000x','-test.count=1']
 h=thread_siblings(c);before=ticks([c,*h]);cpu=cpuuse();t=time.perf_counter()
 r=run(args,cwd=pkg/'smtcore',env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True,text=True);elapsed=time.perf_counter()-t;used=(cpuuse()-cpu)/elapsed;end=ticks([c,*h]);sg=min((idle(before,end,k)for k in h),default=1.)
 (root/f'{attempt}-{v}.bench').write_text(r.stdout+r.stderr)
 out=[]
 for row in r.stdout.splitlines():
  m=re.search(r'^BenchmarkSMTScopeRestoration(WithQueue)?/(ScopedAtoms|SurvivingAtoms)\s+(\d+)\s+',row)
  if not m:continue
  metric='pop-ns/op' if m[1] else 'ns/op';val=re.search(r'([\d.]+) '+metric,row)[1];assert m[3]=='10000';out.append((m[1]or 'make',m[2],val))
 assert len(out)==(2 if v=='native' else 4)
 return elapsed,used,sg,out
with(root/'attempts.csv').open('w')as out:
 z=csv.writer(out);z.writerow('round attempt engine cpu before sibling occupancy wall fixture case ns'.split());names=list(bs);candidates=sorted(c for c in os.sched_getaffinity(0)if c==min([c,*thread_siblings(c)]))
 i=0;attempt=0
 while i<9:
  a=ticks(list(range(48)));time.sleep(2);b=ticks(list(range(48)))
  rates={c:min(idle(a,b,k)for k in [c,*thread_siblings(c)])for c in candidates}
  available=[c for c in candidates if rates[c]>=.95]
  if not available:time.sleep(4);continue
  attempt+=1;cpu=max(available,key=lambda c:(rates[c],(c+attempt)%24));ok=True
  for v in names[i%len(names):]+names[:i%len(names)]:
   wall,occupied,sibling,rs=measure(v,bs[v],cpu,attempt)
   z.writerows([[i+1,attempt,v,cpu,rates[cpu],sibling,occupied,wall,*r]for r in rs]);out.flush()
   if min(occupied,sibling)<.95:ok=False;break
  if ok:i+=1
  print(i,attempt,cpu,ok,flush=True)
