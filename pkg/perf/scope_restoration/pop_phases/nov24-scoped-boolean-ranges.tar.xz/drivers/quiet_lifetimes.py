from common import *
import resource
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
from rotating_verification import ticks,idle,thread_siblings
out=d/'release-scope-ranges/lifetimes';out.mkdir(exist_ok=True)
bs={'before':d/'scope-periodic/control/smt.test','after':d/'release-scope-ranges/smt.test'}
n=0;attempt=0;cpus=list(range(48))
def use():
 t=resource.getrusage(resource.RUSAGE_CHILDREN);return t.ru_utime+t.ru_stime
with(out/'runs.csv').open('w')as f:
 z=csv.writer(f);z.writerow('round attempt engine cpu sibling occupancy size pattern ns bytes allocs'.split())
 while n<11:
  a=ticks(cpus);time.sleep(1);b=ticks(cpus);idlecores={c:min(idle(a,b,c),idle(a,b,c+24))for c in range(24)};ok=[c for c,v in idlecores.items()if v>=.95]
  if not ok:time.sleep(3);continue
  c=max(ok,key=lambda c:(idlecores[c],(c+attempt)%24));attempt+=1;succeeded=True
  for v in (list(bs)if n%2==0 else reversed(bs)):
   before=ticks([c,c+24]);ut=use();start=time.perf_counter()
   p=run(['taskset','-c',str(c),bs[v],'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkScopedBooleanLifetimes$','-test.benchtime=10x','-test.count=1'],cwd=pkg/'smtcore',env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
   elapsed=time.perf_counter()-start;frac=(use()-ut)/elapsed;end=ticks([c,c+24]);sibling=idle(before,end,c+24);(out/f'{attempt}-{v}.bench').write_text(p.stdout)
   rows=re.findall(r'^BenchmarkScopedBooleanLifetimes/(\d+)/(\w+)\s+10\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op',p.stdout,re.M);assert len(rows)==12
   z.writerows([[n+1,attempt,v,c,sibling,frac,*r]for r in rows]);f.flush()
   if min(frac,sibling)<.95:succeeded=False;break
  if succeeded:n+=1
  print(n,attempt,c,succeeded,flush=True)
