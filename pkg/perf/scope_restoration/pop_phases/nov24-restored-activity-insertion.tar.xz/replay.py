"""Replay activity-heap experiments in overlays on the recorded g3 module."""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--pkg", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True, help="new scratch directory")
parser.add_argument("--build", type=Path, help="in-tree C++ build directory")
parser.add_argument("--cpu", type=int, required=True)
parser.add_argument("--rounds", type=int, default=9)
parser.add_argument("--widths", type=int, nargs="+", default=[4, 32, 128, 512, 2048, 4096])
parser.add_argument("--variants", nargs="+", default=["before", "release"])
args = parser.parse_args()
pkg = args.pkg.resolve(strict=True)
out = args.output.resolve()
here = Path(__file__).resolve().parent
catalog = json.loads((here / "manifest.json").read_text())
if args.rounds < 1 or any(w < 4 or w % 2 for w in args.widths):
    parser.error("supply positive rounds and even widths of at least four")
if len(set(args.variants)) != len(args.variants) or set(args.variants) - catalog.keys():
    parser.error("supply distinct variants from " + ", ".join(catalog))
out.mkdir(parents=True)
sys.path.insert(0, str(pkg / "perf/scope_restoration/pop_phases"))
import measure
import widths

fixture = pkg / "smtcore/smt_hotpath_benchmark_test.go"
binaries = {}
for variant in args.variants:
    stage = out / variant
    stage.mkdir()
    paths = {}
    for rel in catalog[variant]:
        target = stage / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        paths[str(pkg / rel)] = str(target)
        source = subprocess.run(["git", "show", "60b797e01:pkg/" + rel],
                                cwd=pkg, capture_output=True)
        if source.returncode == 0:
            target.write_bytes(source.stdout)
    patch = here / "overlays" / (variant + ".patch")
    if patch.exists():
        subprocess.run(["patch", "--batch", "--fuzz=0", "-p1", "-i", patch], cwd=stage, check=True)
    # Compiling against the release checkout also discovers its new regression test.
    # The before and prototype heaps used a different API.
    test = "util/heap/reserved_activity_test.go"
    if variant != "release" and (pkg / test).is_file():
        stub = stage / "no_release_test.go"
        stub.write_text("package heap\n")
        paths[str(pkg / test)] = str(stub)
    plain = stage / "plain.json"
    plain.write_text(json.dumps({"Replace": paths}))
    subprocess.run(["go", "test", "-c", "-pgo=off", "-overlay=" + str(plain),
                    "-o", stage / "smt.test", "./smtcore"], cwd=pkg, check=True)
    changed = stage / fixture.name
    changed.write_text(widths.go_width_fixture(fixture))
    paths[str(fixture)] = str(changed)
    dynamic = stage / "dynamic.json"
    dynamic.write_text(json.dumps({"Replace": paths}))
    binaries[variant] = measure.build_go(stage / "gated", dynamic, "instructions:u")
build = (args.build or pkg.parent / "build").resolve(strict=True)
binaries["native"] = measure.build_native(out / "native", build, "instructions:u", widths.native_width_fixture())
names = list(binaries)
with (out / "phases.csv").open("w") as f:
    writer = csv.writer(f)
    writer.writerow("round width phase mode intervals instructions enabled running".split())
    for rr in range(args.rounds):
        offset = rr % len(args.widths)
        for width in args.widths[offset:] + args.widths[:offset]:
            os.environ["SCOPE_ATOMS"] = str(width)
            settings = SimpleNamespace(cpu=args.cpu, timeout=180, thread_event="instructions:u",
                                       iterations=measure.WARMUP + max(42, min(800, 102400 // width)))
            for phase in ("empty", "pop", "restore"):
                i = rr % len(names)
                for name in names[i:] + names[:i]:
                    folder = out / f"r{rr+1}-{width}-{phase}-{name}"
                    counts = measure.measure(folder, binaries[name], name, "ScopedAtoms", phase, settings)
                    fields = (folder / "out").read_text().split()
                    if float(fields[fields.index("atoms/op") - 1]) != width or counts[-1] != counts[-2]:
                        raise ValueError(f"wrong width or multiplexed counter in {folder}")
                    writer.writerow([rr + 1, width, phase, name, *counts])
                    f.flush()
