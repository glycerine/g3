# Memory used by saved short clauses after scope restoration

Use g3 60b797e01 as the baseline, with the benchmark in smtcore/smt_clause_atom_memory_benchmark_test.go. To build a source overlay and run both the focused tests and the worker benchmark in a fresh process:

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/atoms-roll16 --variant roll16 --cpu 31

The benchmark creates 32 independent managers and per-manager short-clause pools. Each holds 1,024 clauses of three signed literals each. It keeps one in sixteen or a single contiguous group of 64, takes a full Go collection at each boundary, then retires the remaining clauses and checks measured bytes per idle worker. The live and survivor columns are per-clause and per-worker heap growth. Measurement fixture storage is accounted for before the initial reading. The benchmark checks the retained clause's negative literal and exact source handle.

The five-rotation pool study measured the default buffers, coallocation for short buffers (short) and full 64-literal pages (short64), and 4- and 16-clause overflow pages (roll4 and roll16). The lifetime study compares replacing the final resident page on overflow with a page of 4, 8 or 16 clauses. Clauses keep their pages alive until released. The word study uses one packed 64-bit slot/generation per literal followed by sign bits. Packed, exact and pages put the header and some or all small backing arrays in the same allocation. All alternatives use the existing arena and validate source ownership, reference counts and generations.

pool/runs.csv and words/phases.csv measure the solver thread for seven rotations at widths 128, 512, 2048 and 4096. Use the width fixtures from perf/scope_restoration/pop_phases/widths.py. Both exclude eight warmup rounds and run max(42, min(800, 102400 // width)) timed iterations per process. The worker/width elapsed samples use fixed CPUs without a sibling-idle acceptance filter. Compare counts across alternatives within each matrix. The six verifier workloads per matrix use the same GoIvy 832e392ef frontend, xtrace_off, PGO disabled, GOMAXPROCS=1 and ordinary GC. Each run checks both output streams and exit status against its reference.

The census overlay counts allocations in each solver's short-clause pool and emits its histogram when the solver releases the pool. Class 0 is a resident short allocation, class 1 a short overflow allocation and class 2 a longer clause. Widths at least 128 share the final width bin. These are allocation events, not a count of simultaneous live clauses or a complete heap profile.
