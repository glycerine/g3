"""Run one saved-clause storage experiment using the local g3 checkout."""
import argparse
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--pkg", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--variant", default="before")
parser.add_argument("--cpu", type=int)
args = parser.parse_args()
pkg = args.pkg.resolve(strict=True)
out = args.output.resolve()
here = Path(__file__).resolve().parent
manifest = json.loads((here / "manifest.json").read_text())
if args.variant not in manifest:
    parser.error("choose " + ", ".join(manifest))
out.mkdir(parents=True)
paths = {}
for name in manifest[args.variant]:
    target = out / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(subprocess.check_output(["git", "show", "60b797e01:pkg/" + name], cwd=pkg))
    paths[str(pkg / name)] = str(target)
if args.variant != "before":
    patch = here / "overlays" / (args.variant + ".patch")
    subprocess.run(["patch", "-p1", "--batch", "--fuzz=0", "-i", patch], cwd=out, check=True)
overlay = out / "overlay.json"
overlay.write_text(json.dumps({"Replace": paths}))
cmd = ["go", "test", "-pgo=off", "-overlay=" + str(overlay)]
subprocess.run(cmd + ["-count=1", "-run=RetainedLiteral|ClauseAtom|ClauseStorage|ScopeRestore",
                      "./ast", "./smtcore"], cwd=pkg, check=True)
binary = out / "smt.test"
subprocess.run(cmd + ["-c", "-o", binary, "./smtcore"], cwd=pkg, check=True)
launch = ["taskset", "-c", str(args.cpu)] if args.cpu is not None else []
subprocess.run(launch + [binary, "-test.cpu=1", "-test.run=^$", "-test.benchmem",
                         "-test.bench=^BenchmarkSMTSavedClauseAtomMemory$", "-test.benchtime=1x"],
               cwd=pkg / "smtcore", check=True)
