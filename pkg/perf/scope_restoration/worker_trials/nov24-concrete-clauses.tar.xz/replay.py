"""Replay a measured concrete clause representation with its compiled Go fixture."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

def main():
    archive = Path(__file__).resolve().parent
    versions = json.loads((archive / 'versions.json').read_text())
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pkg', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--variant', choices=sorted(versions), default='release')
    p.add_argument('--cpu', type=int, required=True)
    p.add_argument('--native', action='store_true')
    a = p.parse_args()
    pkg = a.pkg.resolve(strict=True)
    out = a.output.resolve()
    out.mkdir(parents=True)
    version = versions[a.variant]
    with subprocess.Popen(['git','-C',pkg.parent,'archive',version['revision'],'pkg'],stdout=subprocess.PIPE) as git:
        with tarfile.open(fileobj=git.stdout,mode='r|') as tar:
            tar.extractall(out,filter='data')
        if git.wait():
            raise RuntimeError('git archive failed')
    tree = out / 'pkg'
    if version.get('patch'):
        subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',archive / version['patch']],cwd=tree,check=True)
    env = dict(os.environ, GOMAXPROCS='1')
    binary = out / 'smtcore.test'
    subprocess.run(['go','test','-pgo=off','-c','-o',binary,'./smtcore'],cwd=tree,env=env,check=True)
    cmd = ['taskset','-c',str(a.cpu),binary]
    subprocess.run(cmd+['-test.run=Clause|ScopeRestoration|PopResume'],cwd=tree/'smtcore',env=env,check=True)
    subprocess.run(cmd+['-test.run=^$','-test.bench=^BenchmarkSMTLiveClauseMemory$','-test.benchtime=1x','-test.cpu=1'],cwd=tree/'smtcore',env=env,check=True)
    subprocess.run(cmd+['-test.run=^$','-test.bench=^BenchmarkSMTClauseCreateClose$','-test.benchtime=4096x','-test.cpu=1'],cwd=tree/'smtcore',env=env,check=True)
    if a.native:
        sys.path.insert(0,str(pkg/'perf/ivy_apple'))
        from native_benchmark import build_native
        native = out / 'native'
        build_native(pkg.parent/'build',native,pkg.parent/'src/test/perf/clause_create_close.cpp')
        for width in (3,8,65):
            for mode in ('Bare','Learned','Saved','Proof','Handler'):
                subprocess.run(['taskset','-c',str(a.cpu),native,str(width),mode,'10000'],check=True)

if __name__=='__main__':
    main()
