# SMT expression validation and scope construction

Commit 4052fd136 validates manager identity, bounds, generation and liveness at the Internalize and NewSMTEnode entry points. The common application header and its Boolean result-sort predicate come from one slot. The release comparison starts at f830ebca3. Earlier alternatives use that same revision and supply focused regressions for Internalize.

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/g3-header --cpu 2 --variant after --native

The Go bench fixture and native enode fixture are both included in git. The public creation and revisit CSVs measure the change in process instructions between paired iteration counts. The six standalone queries preserve answer, decisions, conflicts, instantiations and resource count. The verifier rows check both streams and exit. The 228 corpus checks compare the release with saved native outcomes.

The phase study is separate, on f830ebca3. In a temporary revision export replace smtcore/smt_enode_scope_batch_benchmark_test.go and add smtcore/study_clause_thread_linux_amd64_test.go from phase-fixtures. Build the test binary. Link phase-fixtures/enode_scope_batch.cpp with the same in-tree Z3 build used by replay.py. For Go set GOMAXPROCS=1 and SCOPE_THREAD_EVENT=1. Set SCOPE_PHASE to 0, 1, 2 or 3 for the entire scope, push, internalization loop or pop. Run the named benchmark width with -test.cpu=1 and -test.benchtime=Nx. Pass the same width and N to the native binary. Set STUDY_EMPTY=1 to bracket an empty interval. Use a fresh process without STUDY_EMPTY for the full interval. The process asserts the visit count and equal enabled and running times. Subtract empty from full and divide by N times the number of fresh enodes. There are nine rotated full/empty pairs per engine and width. The reported medians for the separate intervals need not sum to the whole.

The CPU profiles repeatedly exercise widths 256 and 2048. Every run has zero throttled intervals. Leaf and inclusive counts and full folded stacks are stored by engine, width and repetition. Inclusive sample counts overlap.
