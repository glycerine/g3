// Companion to BenchmarkSMTEnodeScopeBatch in pkg/smtcore.
#include "smt/smt_context.h"
#include "ast/reg_decl_plugins.h"
#include <chrono>
#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <cstdlib>
#include <iostream>

namespace {
int counter_fd, selected = 0;
bool empty = false;
unsigned visits;
void start_counter(){
 struct perf_event_attr attr{};attr.type=PERF_TYPE_HARDWARE;attr.size=sizeof(attr);attr.config=PERF_COUNT_HW_INSTRUCTIONS;attr.disabled=1;attr.exclude_kernel=1;attr.exclude_hv=1;attr.read_format=PERF_FORMAT_TOTAL_TIME_ENABLED|PERF_FORMAT_TOTAL_TIME_RUNNING;
 counter_fd=syscall(SYS_perf_event_open,&attr,0,-1,-1,0);if(counter_fd<0){perror("perf_event_open");std::abort();}
 selected=std::atoi(std::getenv("SCOPE_PHASE"));empty=std::getenv("STUDY_EMPTY")!=nullptr;
}
void phase(unsigned id,bool begin){if(id!=unsigned(selected))return;
 if(begin){++visits;if(ioctl(counter_fd,PERF_EVENT_IOC_ENABLE,0)){std::abort();}}
 if((!begin&&!empty)||(begin&&empty))if(ioctl(counter_fd,PERF_EVENT_IOC_DISABLE,0)){std::abort();}
}
struct batch_context : smt::context {
    using smt::context::context;
    using smt::context::push_scope;
    using smt::context::pop_scope;
};

bool measure(unsigned width, unsigned rounds) {
    ast_manager m;
    reg_decl_plugins(m);
    sort_ref s(m.mk_uninterpreted_sort(symbol("U")),m);
    sort* dom[2] = {s.get(),s.get()};
    func_decl_ref f(m.mk_func_decl(symbol("f"),2,dom,s.get()),m);
    params_ref p;
    p.set_bool("auto_config", false);
    p.set_uint("relevancy", 2);
    smt_params params;
    params.updt_params(p);
    batch_context ctx(m,params,p);
    expr_ref_vector roots(m), terms(m);
    for (unsigned i = 0; i < 64; ++i) {
        roots.push_back(m.mk_const(symbol(i),s.get()));
        ctx.internalize(roots.get(i),false);
    }
    for (unsigned i = 0; i < width; ++i) {
        terms.push_back(m.mk_app(f.get(),roots.get(i%64),roots.get(i/64)));
        if (i%16 == 0) ctx.internalize(terms.get(i),false);
    }
    unsigned base = ctx.get_num_e_internalized();
    start_counter();
    auto start = std::chrono::steady_clock::now();
    for (unsigned k = 0; k < rounds; ++k) {
        phase(0,true);phase(1,true);ctx.push_scope();phase(1,false);phase(2,true);
        for (unsigned i = 0; i < width; ++i)
            if (i%16 != 0) ctx.internalize(terms.get(i),false);
        phase(2,false);if (ctx.get_num_e_internalized() != base+width-width/16) return false;
        phase(3,true);ctx.pop_scope(1);phase(3,false);phase(0,false);
        if (ctx.get_num_e_internalized() != base) return false;
    }
    uint64_t values[3];if(visits!=rounds||read(counter_fd,values,sizeof(values))!=sizeof(values))return false;close(counter_fd);
 std::cout<<"CYCLE-THREAD enode "<<rounds<<" "<<values[0]<<" "<<values[1]<<" "<<values[2]<<"\n";
 auto ns = std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-start).count();
    for (unsigned i = 0; i < width; ++i)
        if (ctx.e_internalized(terms.get(i)) != (i%16 == 0)) return false;
    std::cout << "width,iterations,ns_per_op,enodes_per_op\n" << width << ',' << rounds << ',' << ns/rounds << ',' << width-width/16 << '\n';
    return true;
}
}
int main(int argc, char** argv) {
    if (argc != 3) return 1;
    char* end;
    auto width = std::strtoul(argv[1], &end, 10);
    if (*end || (width != 32 && width != 256 && width != 2048)) return 1;
    auto iterations = std::strtoul(argv[2], &end, 10);
    if (*end || iterations == 0 || iterations > 10000000) return 1;
    memory::initialize(0);
    return measure(width, iterations) ? 0 : 1;
}
