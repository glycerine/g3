"""Build a recorded congruence table or scope-lifetime variant and run its measurements."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
here=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--pkg',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--experiment',required=True)
p.add_argument('--variant',default='control')
p.add_argument('--cpu',type=int,required=True)
p.add_argument('--count',type=int,default=1)
args=p.parse_args()
pkg=args.pkg.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
experiments=json.loads((here/'manifest.json').read_text())
if args.experiment not in experiments or args.variant not in experiments[args.experiment] or args.count<1:p.error('unknown experiment/variant or nonpositive count')
mapping={str(pkg/name):str(here/val)for name,val in experiments[args.experiment][args.variant].items()}
overlay=out/'overlay.json';overlay.write_text(json.dumps({'Replace':mapping}))
binary=out/'smt.test'
subprocess.run(['go','test','-pgo=off','-tags=xtrace_off','-overlay='+str(overlay),'-c','-o',binary,'./smtcore'],cwd=pkg,check=True)
run=['taskset','-c',str(args.cpu),binary]
env=dict(os.environ,GOMAXPROCS='1')
tests='TestSMT(Congruence|Cg|InternalizerPopResumes)|TestEqualityUndoRestores'
if args.experiment=='enodes' and args.variant!='control':tests+='|TestEqualityUndoRetiresNodesCreatedAfterMerge'
if args.experiment=='labels' and args.variant!='control':tests+='|TestSMTEnodeTrailGenerationAndLabelHash'
subprocess.run([*run,'-test.run='+tests],cwd=pkg/'smtcore',env=env,check=True)
for bench,n in ([('SMTCongruenceScopeMemory',1)]if args.experiment in ('enodes','scopes','labels')else [('SMTCongruenceTableMemory',1),('SMTCongruenceProbes',100000)]):
    subprocess.run([*run,'-test.run=^$','-test.cpu=1','-test.bench=^Benchmark'+bench+'$','-test.benchmem','-test.benchtime='+str(n)+'x','-test.count='+str(args.count)],cwd=pkg/'smtcore',env=env,check=True)
