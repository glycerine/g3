package smtcore

import "math/bits"

type smtCgSmallTable struct {
	slots   []uint32
	entries []smtCgSmallEntry
	count   int
	shift   uint8
}

type smtCgSmallEntry struct {
	k0, k1, node *SMTEnode
}

func smtCgSmallSlot(k0, k1 *SMTEnode, shift uint8) int {
	x := uint64(k0.owner.Slot()) << 32
	if k1 != nil {
		x |= uint64(k1.owner.Slot())
	}
	x ^= x >> 29
	return int((x * 0x9E3779B97F4A7C15) >> shift)
}

func (t *smtCgSmallTable) locate(k0, k1 *SMTEnode) int {
	i := smtCgSmallSlot(k0, k1, t.shift)
	mask := len(t.slots) - 1
	for {
		pos := t.slots[i]
		if pos == 0 {
			return i
		}
		e := &t.entries[pos-1]
		if e.k0 == k0 && e.k1 == k1 {
			return i
		}
		i = (i + 1) & mask
	}
}
func (t *smtCgSmallTable) get(k0, k1 *SMTEnode) *SMTEnode {
	if t.count == 0 {
		return nil
	}
	id := t.slots[t.locate(k0, k1)]
	if id == 0 {
		return nil
	}
	return t.entries[id-1].node
}
func (t *smtCgSmallTable) resize(n int) {
	slots := make([]uint32, n)
	shift := uint8(64 - bits.TrailingZeros(uint(n)))
	for j := range t.entries {
		e := &t.entries[j]
		i := smtCgSmallSlot(e.k0, e.k1, shift)
		for slots[i] != 0 {
			i = (i + 1) & (n - 1)
		}
		slots[i] = uint32(j + 1)
	}
	t.shift, t.slots = shift, slots
}
func (t *smtCgSmallTable) set(k0, k1, node *SMTEnode) {
	if 2*(t.count+1) > len(t.slots) {
		n := max(4, len(t.slots)*2)
		t.resize(n)
	}
	i := t.locate(k0, k1)
	if pos := t.slots[i]; pos != 0 {
		t.entries[pos-1].node = node
		return
	}
	t.entries = append(t.entries, smtCgSmallEntry{k0, k1, node})
	t.count++
	t.slots[i] = uint32(len(t.entries))
}
func (t *smtCgSmallTable) del(k0, k1 *SMTEnode) {
	if t.count == 0 {
		return
	}
	i := t.locate(k0, k1)
	id := t.slots[i]
	if id == 0 {
		return
	}
	pos := int(id) - 1
	last := len(t.entries) - 1
	if pos != last {
		end := t.entries[last]
		endSlot := t.locate(end.k0, end.k1)
		t.entries[pos] = end
		t.slots[endSlot] = id
	}
	t.entries[last] = smtCgSmallEntry{}
	t.entries = t.entries[:last]
	t.count--
	mask := len(t.slots) - 1
	for j := (i + 1) & mask; t.slots[j] != 0; j = (j + 1) & mask {
		e := &t.entries[t.slots[j]-1]
		home := smtCgSmallSlot(e.k0, e.k1, t.shift)
		if (j-home)&mask >= (j-i)&mask {
			t.slots[i] = t.slots[j]
			i = j
		}
	}
	t.slots[i] = 0

}
func (t *smtCgSmallTable) forEach(visit func(k0, k1, node *SMTEnode)) {
	for _, id := range t.slots {
		if id != 0 {
			e := &t.entries[id-1]
			visit(e.k0, e.k1, e.node)
		}
	}
}
