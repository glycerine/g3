"""Replay a measured node layout in a private source export."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

def main():
    here = Path(__file__).resolve().parent
    manifest = json.loads((here / "manifest.json").read_text())
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pkg", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--variant", required=True, choices=manifest["variants"])
    p.add_argument("--cpu", type=int, required=True)
    p.add_argument("--native", action="store_true")
    args = p.parse_args()
    pkg = args.pkg.resolve(strict=True)
    out = args.output.resolve()
    out.mkdir(parents=True)
    rev = manifest["release"] if args.variant == "release" else manifest["baseline"]
    with subprocess.Popen(["git", "-C", pkg.parent, "archive", rev, "pkg"], stdout=subprocess.PIPE) as git:
        with tarfile.open(fileobj=git.stdout, mode="r|") as tar:
            tar.extractall(out, filter="data")
        if git.wait():
            raise RuntimeError("git archive failed")
    tree = out / "pkg"
    if args.variant != "release":
        for f in (here / "benchmarks").glob("*.go"):
            (tree / "smtcore" / f.name).write_bytes(f.read_bytes())
        patch = here / "patches" / (args.variant + ".patch")
        if patch.is_file():
            subprocess.run(["patch", "--batch", "-p1", "-i", patch], cwd=tree, check=True)
    env = dict(os.environ, GOMAXPROCS="1")
    test = out / "smtcore.test"
    subprocess.run(["go", "test", "-pgo=off", "-c", "-o", test, "./smtcore"], cwd=tree, check=True, env=env)
    cmd = ["taskset", "-c", str(args.cpu), test]
    subprocess.run(cmd + ["-test.run=Equality|Enode|Disequal|Justification|Congruence|Conflict"], cwd=tree/"smtcore", check=True, env=env)
    subprocess.run(cmd + ["-test.run=^$", "-test.cpu=1", "-test.benchtime=1x", "-test.bench=^BenchmarkSMTEnode(FieldMemory|ParentShapes|ScopeBatch)$"], cwd=tree/"smtcore", check=True, env=env)
    if args.native:
        sys.path.insert(0, str(pkg / "perf/ivy_apple"))
        from native_benchmark import build_native
        binary = out / "native"
        build_native(pkg.parent / "build", binary, pkg.parent / "src/test/perf/enode_scope_batch.cpp")
        for width in [32, 256, 2048]:
            subprocess.run(["taskset", "-c",str(args.cpu), binary, str(width), "20"], env=env, check=True)

if __name__ == "__main__":
    main()
