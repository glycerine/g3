package smtcore

import (
	"encoding/json"
	"fmt"
	"github.com/glycerine/g3/pkg/ast"
	"os"
)

type studyCensusRow struct {
	Owner                                                                                       string
	Phase, Nodes, Decls, Edges, Theory, Disequal, Vars, WatchLists, WatchedClauses, WatchedLits int
	Parents, Children                                                                           [9]int
	Reasons                                                                                     [4]int
	Clauses, WithAtoms, WithHandler, WithProof, Reinit, Lemma                                   int
	Width                                                                                       [9]int
}

func studyCensusBin(n int) int {
	if n < 5 {
		return n
	}
	if n <= 8 {
		return 5
	}
	if n <= 16 {
		return 6
	}
	if n <= 64 {
		return 7
	}
	return 8
}
func (s *SMTInternalizerState) studyCensus(phase int) {
	if s == nil {
		return
	}
	size := len(s.enodeStack) + len(s.lemmas) + len(s.auxClauses) + len(s.boolExpr)
	if s.studyCensusCount[phase] >= 2 && size < s.studyCensusNext[phase] {
		return
	}
	s.studyCensusCount[phase]++
	s.studyCensusNext[phase] = size + size/2 + 8
	row := studyCensusRow{Owner: fmt.Sprintf("%p", s), Phase: phase, Nodes: len(s.enodeStack), Vars: len(s.boolExpr), WatchLists: len(s.watches)}
	decls := map[ast.ASTHandle]bool{}
	for _, n := range s.enodeStack {
		decls[n.Declaration()] = true
		row.Parents[studyCensusBin(int(n.NumParents()))]++
		row.Children[studyCensusBin(int(n.NumArgs()))]++
		if n.theoryVariables.variable != SMTNullTheoryVar {
			row.Theory++
		}
		if len(n.disequalityEntries()) > 0 {
			row.Disequal++
		}
		if n.trans.Target != nil {
			row.Edges++
			row.Reasons[n.trans.justification().Kind()]++
		}
	}
	row.Decls = len(decls)
	for i := range s.watches {
		w := &s.watches[i]
		if len(w.Clauses()) > 0 {
			row.WatchedClauses++
		}
		if len(w.Literals()) > 0 {
			row.WatchedLits++
		}
	}
	for _, list := range [][]SMTInternalizedClause{s.auxClauses, s.lemmas} {
		for _, r := range list {
			c := r.clause
			if c == nil || c.closed {
				continue
			}
			row.Clauses++
			row.Width[studyCensusBin(len(c.literals))]++
			if c.atoms != nil {
				row.WithAtoms++
			}
			if c.deleteHandler != nil {
				row.WithHandler++
			}
			if c.justification != nil {
				row.WithProof++
			}
			if c.InReinitStack() {
				row.Reinit++
			}
			if c.IsLemma() {
				row.Lemma++
			}
		}
	}
	b, e := json.Marshal(&row)
	if e != nil {
		panic(e)
	}
	fmt.Fprintf(os.Stderr, "RECORDCENSUS %s\n", b)
}
