#include "smt/smt_context.h"
#include "smt/smt_quantifier_stat.h"
#include "smt/fingerprints.h"
#include <cstdio>
int main() {
std::printf("%zu\n",sizeof(ast*));
std::printf("%zu\n",sizeof(smt::literal));
std::printf("%zu\n",sizeof(smt::bool_var_data));
std::printf("%zu\n",sizeof(smt::b_justification));
std::printf("%zu\n",sizeof(smt::eq_justification));
std::printf("%zu\n",sizeof(smt::enode));
std::printf("%zu\n",sizeof(smt::theory_var_list));
std::printf("%zu\n",sizeof(smt::watch_list));
std::printf("%zu\n",sizeof(smt::clause));
std::printf("%zu\n",sizeof(smt::quantifier_stat));
std::printf("%zu\n",sizeof(smt::fingerprint));
}
