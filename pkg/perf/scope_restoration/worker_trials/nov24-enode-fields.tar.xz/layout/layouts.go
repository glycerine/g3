package main
import("fmt";"unsafe";"github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/smtcore")
func main(){
fmt.Println(unsafe.Sizeof(ast.ASTHandle{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTLiteral(0)))
fmt.Println(unsafe.Sizeof(smtcore.SMTBoolVarData{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTBooleanJustification{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTEqualityJustification{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTEnode{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTTheoryVarList{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTWatchList{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTClause{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTQuantifierStat{}))
fmt.Println(unsafe.Sizeof(smtcore.SMTFingerprint{}))
}
