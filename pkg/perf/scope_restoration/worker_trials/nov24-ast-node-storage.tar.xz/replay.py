"""Rebuild and run one archived layout against a temporary export of g3."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

def main():
    here = Path(__file__).resolve().parent
    study = json.loads((here / "manifest.json").read_text())
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pkg", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--variant", choices=sorted(study["versions"]), default="after")
    parser.add_argument("--cpu", type=int, required=True)
    parser.add_argument("--iterations", type=int, default=3)
    parser.add_argument("--native", action="store_true")
    parser.add_argument("--checked", action="store_true")
    args = parser.parse_args()
    pkg = args.pkg.resolve(strict=True)
    out = args.output.resolve()
    out.mkdir(parents=True)
    src = out / "pkg"
    version = study["versions"][args.variant]
    env = dict(os.environ, GOMAXPROCS="1", GOGC="100")
    with subprocess.Popen(["git", "-C", pkg.parent, "archive", version["revision"], "pkg"], stdout=subprocess.PIPE) as git:
        with tarfile.open(fileobj=git.stdout, mode="r|") as source:
            source.extractall(out, filter="data")
        if git.wait():
            raise RuntimeError("git archive failed")
    if "patch" in version:
        subprocess.run(["patch", "--batch", "--forward", "--fuzz=0", "-p1", "-i", here/version["patch"]], check=True, cwd=src)
    for name in study.get("fixtures", []):
        target = src/name
        b = (here/"fixtures"/name).read_bytes()
        if target.exists() and target.read_bytes() != b:
            raise RuntimeError("fixture disagrees with revision: "+name)
        target.write_bytes(b)
    pin = ["taskset", "-c", str(args.cpu)]
    tags = ["-tags=g3checked,g3debug,g3trace"] if args.checked else []
    binary = out/"go.test"
    subprocess.run(["go", "test", "-pgo=off", "-p", "3", *tags, "-c", "-o", binary, "./"+study["package"]], cwd=src, env=env, check=True)
    subprocess.run(pin+[binary, "-test.run="+study["tests"]], cwd=src/study["package"], env=env, check=True)
    for bench in study["bench"]:
        subprocess.run(pin+[binary, "-test.run=^$", "-test.cpu=1", "-test.bench="+bench, "-test.benchtime="+str(args.iterations)+"x"], cwd=src/study["package"], env=env, check=True)
    if args.native:
        sys.path.insert(0, str(pkg/"perf/ivy_apple"))
        from native_benchmark import build_native
        for source, rows in study["native"].items():
            native = out/Path(source).stem
            build_native(pkg.parent/"build", native, pkg.parent/"src/test/perf"/source)
            for row in rows:
                subprocess.run(pin+[native, *map(str,row)], check=True)
if __name__ == "__main__":
    main()

