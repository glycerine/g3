# AST application and mark-owner storage

The original AST slot was 128 bytes. Commit c7fccbbac reduced each canonical entry from 16 to 12 bytes and retained the original structural hash and probe order. Commit f830ebca3 reduced the slot from 128 to 100 bytes and allocated the 64-bit mark owners on the first use of each page and plane. One mark owner is independent of the other and a false bit can still have a nonzero owner. Slots preserve the full generation and reuse clears the old owners.

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/g3-ast-before --cpu 2 --variant before
    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/g3-ast-after --cpu 2 --variant after --native

The application benchmark holds four independent managers, 2048 newly created applications each. It collects the Go heap at both ownership boundaries. The native benchmark measures requested small-object bytes and the process glibc allocation delta separately. The mark benchmark starts with 8192 live nodes. Its first-live-B metric counts the additional heap retained by the first traversal. Its ns/op measures a complete later mark and reset.

For instructions per mark and reset, subtract the retired instructions from the paired shorter process, divide by the iteration difference and the reported marks/op. The corpus rows compare both streams and expected exit status across 228 complete verifications. The six standalone solver rows retain the answer and the decision, conflict, quantifier and resource counts. The live snapshots use the same phase, enode count, concrete clauses and binary clauses for each layout.
