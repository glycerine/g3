import argparse
import json
import os
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
variants = json.loads((root / 'variants.json').read_text())
p = argparse.ArgumentParser()
p.add_argument('--pkg',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--variant',choices=variants,default='release')
p.add_argument('--cpu',type=int,required=True)
a = p.parse_args()
v = variants[a.variant]
a.output.mkdir(parents=True)
with subprocess.Popen(['git','-C',a.pkg.resolve().parent,'archive',v['base'],'pkg'],stdout=subprocess.PIPE) as git:
    with tarfile.open(fileobj=git.stdout,mode='r|') as tar:
        tar.extractall(a.output,filter='data')
    if git.wait():
        raise RuntimeError('git archive failed')
tree=a.output/'pkg'
if 'patch' in v:
    subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',root/'patches'/v['patch']],cwd=tree,check=True)
cmd=['taskset','-c',str(a.cpu),'go','test','-pgo=off','-count=1','-cpu=1','./smtcore']
if v.get('negative'):
    r=subprocess.run(cmd+['-run','^TestSMTDeclarationCandidatesSurviveMixedScopes$'],cwd=tree,capture_output=True,text=True)
    print(r.stdout+r.stderr,end='')
    if r.returncode != 1 or 'popped candidate remained' not in r.stdout:
        raise RuntimeError('expected the borrowed candidate regression')
else:
    env=dict(os.environ,GOMAXPROCS='1')
    if a.variant=='release-counters':
        env.update(SCOPE_PHASE='0',SCOPE_THREAD_EVENT='1')
    subprocess.run(cmd+['-run','Declaration|NativeRootRetirement|Borrowed','-bench','^BenchmarkSMTDeclaration(IndexAccess|Population)$','-benchtime=1x'],cwd=tree,env=env,check=True)
