# Solver declaration indexes

Build any variant in a disposable source export. Both tables are local to one checker context. The memory fixture registers 512 terms per solver under five declaration profiles. The lookup fixture measures the first read and three later scans over one, 64 or 512 declarations, including suppressed applications and interleaved creation. The control builds both indexes from the first registration.

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/decl-release --variant release --cpu 2
    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/decl-trial --variant observed --cpu 2

The release-counters variant needs perf_event_open access on Linux amd64. SCOPE_PHASE=0 and SCOPE_THREAD_EVENT=1 enable its per-thread instruction counter. STUDY_EMPTY=1 measures the same bracket without counting the benchmark operation. Each readers CSV has both readings for each of seven rotations. The reported per-term value is (full instructions minus empty instructions) / (iterations times 512). Base constants are registered outside the timer. Deferred construction may move part of their indexing cost into the first timed query.

The five early variants reproduce a failed lifetime test. The borrowed interpreter range still contained the retired enode. replay.py verifies the specific expected failure. These isolated experiments precede the mixed-registration correction and never entered the production branch.

Six complete GoIvy workloads were compared against reference stdout, stderr and exit status. The corpus records the same checks on 228 additional inputs. Standalone solver results include four exact search counters. The candidate live measurements force a collection at the same solver phase, enode count, concrete clause count and binary population. An observation is a single point in time. Pages, allocation-rate counters and templates used in earlier studies remain in the main repository.
