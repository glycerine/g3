# Compact SAT watch release and verification at the pause

The watch release is ec67023c4. The prior expression-column release is 6bf88f8c5.
The standalone CSV has three backends and five rotations across 14 SAT inputs.
Repeat with perf/ivy_raft/watch_propagation.py using --permutations 3. The old
binary names in that CSV identify those two commits and the in-tree Z3 fork.
The four quiet SAT runs preserve their exact CNF and attempt rows. GoIvy
verifier rows cover six complete runs by spec, with matched stdout, stderr and
exit status in the measurements. The compatibility rows cover 228 cases and
the heap samples cover seven matched Go solver states.

The timing directories preserve the earlier attempts as recorded. In the full
Apple run there is one completed pair and an interrupted second g3 transcript.
The short runs have their original provenance and module records. The scope
attempts table identifies accepted and rejected measurements, and the .bench
files are the original command outputs. See pkg/TODO_NEXT.md for which timing
rows qualify and the caveats about the frontend and native control.

The source benchmark for the watch population is
pkg/sat/sat_watch_population_benchmark_test.go and its native companion is
src/test/perf/sat_record_population.cpp. The source verification and reuse
fixtures are committed in the repository. The warm-empty simplifier assertion
reported in the checkptr logs also fails on the unchanged baseline.
