package smtcore

// Source: src/smt/smt_enode.cpp context-independent deletion, diagnostics,
// invariant checks, and tmp_enode implementation.

import (
	"fmt"
	"io"
	"math"

	"github.com/glycerine/g3/pkg/ast"
)

// Delete is enode::del_eh. A refused deletion leaves the node registered
// with every argument root it had on entry.
func (n *SMTEnode) Delete(updateChildrenParent bool) error {
	var local [4]smtRemovedParent
	if _, err := n.detachParentsForDeletion(updateChildrenParent, local[:0]); err != nil {
		return err
	}
	n.finishDeletion()
	return nil
}

// The source normally pops the last parent. A parent registered later may
// still be borrowed by the Go context, so an interior removal keeps its order.
type smtRemovedParent struct {
	argument int
	position int
}

func (n *SMTEnode) detachParentsForDeletion(update bool, interior []smtRemovedParent) ([]smtRemovedParent, error) {
	if err := n.valid(); err != nil {
		return nil, err
	}
	if n.classSize != 1 || n.root != n || n.next != n {
		return nil, fmt.Errorf("delete non-singleton enode (class %d root-self %t next-self %t): %w", n.classSize, n.root == n, n.next == n, ast.ErrASTDomain)
	}
	if !update {
		return nil, nil
	}
	for i, argument := range n.arguments {
		if argument == nil || argument.root == nil {
			n.restoreDeletionParents(i, interior)
			return nil, fmt.Errorf("delete enode %d: retired argument %d: %w", n.owner.Slot(), i, ast.ErrASTDomain)
		}
		root := argument.root
		parents := root.sourceParents
		last := len(parents) - 1
		if last < 0 || parents[last] != n {
			position := last - 1
			for position >= 0 && parents[position] != n {
				position--
			}
			if position < 0 {
				n.restoreDeletionParents(i, interior)
				operation, _ := n.manager.GetDeclKind(n.owner)
				family, _ := n.manager.GetFamilyID(n.owner)
				return nil, fmt.Errorf("delete enode %d family %d operation %d argument %d missing from parents (parents %d): %w", n.owner.Slot(), family, operation, i, len(parents), ast.ErrASTDomain)
			}
			interior = append(interior, smtRemovedParent{i, position})
			copy(parents[position:], parents[position+1:])
		}
		parents[last] = nil
		root.sourceParents = parents[:last]
	}
	return interior, nil
}

// Undo exactly one removal for each argument in the processed prefix.
// Shrinking the lists preserved the capacity needed to restore them.
func (n *SMTEnode) restoreDeletionParents(count int, interior []smtRemovedParent) {
	for i := count - 1; i >= 0; i-- {
		root := n.arguments[i].root
		last := len(root.sourceParents)
		parents := root.sourceParents[:last+1]
		at := last
		if k := len(interior) - 1; k >= 0 && interior[k].argument == i {
			at = interior[k].position
			copy(parents[at+1:], parents[at:last])
			interior = interior[:k]
		}
		parents[at] = n
		root.sourceParents = parents
	}
}

func (n *SMTEnode) finishDeletion() {
	n.manager = nil
	n.root, n.next, n.congruence = nil, nil, nil
	n.shortOperands = [2]*SMTEnode{}
	n.sourceParents, n.arguments = nil, nil
}

// TransReaches walks the proof tree. Brent's check catches a corrupted cycle
// without allocating, since this runs for every equality a conflict expands.
func (n *SMTEnode) TransReaches(target *SMTEnode) bool {
	checkpoint, steps, limit := n, 0, 1
	for current := n; current != nil; current = current.trans.Target {
		if current == target {
			return true
		}
		if steps == limit {
			checkpoint, steps, limit = current, 0, limit*2
		}
		steps++
		if next := current.trans.Target; next == checkpoint {
			return false
		}
	}
	return false
}

func (n *SMTEnode) ContainsParentCongruentTo(parent *SMTEnode) (bool, error) {
	if err := n.valid(); err != nil {
		return false, err
	}
	for _, candidate := range n.sourceParents {
		yes, _, err := SMTEnodesCongruent(candidate, parent)
		if err != nil {
			return false, err
		}
		if yes {
			return true, nil
		}
	}
	return false, nil
}

func (n *SMTEnode) CheckInvariant() error {
	if err := n.valid(); err != nil {
		return err
	}
	seen := make(map[*SMTEnode]struct{})
	foundRoot, hasInterpreted := false, false
	current := n
	for {
		if current == nil || current.root != n.root {
			return ast.ErrASTDomain
		}
		if _, found := seen[current]; found {
			if current != n {
				return ast.ErrASTDomain
			}
			break
		}
		seen[current] = struct{}{}
		foundRoot = foundRoot || current == n.root
		hasInterpreted = hasInterpreted || current.interpreted
		current = current.next
	}
	if !foundRoot || n == n.root && uint32(len(seen)) != n.classSize || hasInterpreted && !n.root.interpreted || !n.TransReaches(n.root) {
		return ast.ErrASTDomain
	}
	if n == n.root {
		for _, parent := range n.sourceParents {
			found := false
			for _, argument := range parent.arguments {
				if argument.root == n.root {
					found = true
					break
				}
			}
			if !found {
				return ast.ErrASTDomain
			}
		}
		for member := n.root.next; member != n.root; member = member.next {
			for _, parent := range member.sourceParents {
				if parent.IsTrueEquality() {
					continue
				}
				found, err := n.root.ContainsParentCongruentTo(parent)
				if err != nil || !found {
					if err != nil {
						return err
					}
					return ast.ErrASTDomain
				}
			}
		}
	}
	return nil
}

func (n *SMTEnode) DisplayLabels(out io.Writer) error {
	if err := n.valid(); err != nil {
		return err
	}
	if out == nil {
		return ast.ErrASTDomain
	}
	ownerID, err := n.OwnerID()
	if err != nil {
		return err
	}
	rootID, err := n.root.OwnerID()
	if err != nil {
		return err
	}
	if _, err = fmt.Fprintf(out, "#%d  ->  #%d, lbls: %s, plbls: %s, root->lbls: %s, root->plbls: %s", ownerID, rootID, n.labels.String(), n.propagatedLabels.String(), n.root.labels.String(), n.root.propagatedLabels.String()); err != nil {
		return err
	}
	if n.labelHash >= 0 {
		if _, err = fmt.Fprintf(out, ", lbl-hash: %d", n.labelHash); err != nil {
			return err
		}
	}
	_, err = io.WriteString(out, "\n")
	return err
}

type SMTTempEnode struct {
	manager *ast.ASTManager
	node    SMTEnode
}

func NewSMTTempEnode(m *ast.ASTManager) (*SMTTempEnode, error) {
	if m == nil {
		return nil, ast.ErrASTDomain
	}
	t := &SMTTempEnode{manager: m}
	t.node.manager = m
	t.node.root, t.node.next = &t.node, &t.node
	t.node.classSize = 1
	t.node.congruenceEnabled = true
	t.node.functionDeclID = math.MaxUint32
	t.node.labelHash = -1
	t.node.theoryVariables = *NewDefaultSMTTheoryVarList()
	return t, nil
}

func (t *SMTTempEnode) Set(declaration ast.ASTHandle, args []*SMTEnode) (*SMTEnode, error) {
	if t == nil || t.manager == nil {
		return nil, ast.ErrASTHandle
	}
	kind, err := t.manager.GetKind(declaration)
	if err != nil {
		return nil, err
	}
	if kind != ast.ASTFuncDecl {
		return nil, ast.ErrASTDomain
	}
	flags, err := t.manager.GetFuncDeclFlags(declaration)
	if err != nil {
		return nil, err
	}
	for _, argument := range args {
		if argument == nil || argument.root == nil {
			return nil, ast.ErrASTDomain
		}
	}
	if t.node.declaration != declaration {
		t.node.functionDeclID = math.MaxUint32
	}
	t.node.declaration = declaration
	t.node.arguments = append(t.node.arguments[:0], args...)
	t.node.commutative = len(args) == 2 && flags.Commutative
	return &t.node, nil
}

func (t *SMTTempEnode) Reset() error {
	if t == nil || t.manager == nil {
		return ast.ErrASTHandle
	}
	t.node.functionDeclID = math.MaxUint32
	return nil
}
