# Enode registration and AST layout alternatives

This archive preserves representative alternative source overlays and raw
observations from the November 24 study. None of these overlays is a retained
optimization. The driver for each family identifies the source paths,
controls, applicable revision and measurement procedure used by that family.
The registration trials read 4052fd136 as their baseline for fused
congruence probes and f830ebca3 for coallocated enode arguments. The AST
operand and application metadata trials use f830ebca3 and 4052fd136,
respectively. The flattening variants used the live rewriter source at
the measurement. The drivers originated in the local study scratch tree.
The recorded CSVs are sufficient to recover observed verifier outcomes and
instruction measurements. Use PERF_STUDY.md to interpret the paired width
slopes and distinguish those from complete-verifier measurements.
