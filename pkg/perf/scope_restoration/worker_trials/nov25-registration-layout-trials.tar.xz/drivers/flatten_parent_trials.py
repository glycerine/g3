from common import *
import holdouts as ho,split_instance_attribution as sa,candidate_operand_trials as co
a=pkg/'ast';rw=a/'rewriter';rd=d/'flatten-parent-trials';rd.mkdir(exist_ok=True);vs=['before','parent','fused','parent-fused','config','small-patterns','all']
def edits(v):
 if v=='before':return {}
 ed={};p=rw/'rewriter_engine.go';s=p.read_text()
 # Parent, result and child are held while the frame is live. Reading their
 # immutable kinds/declarations cannot invoke a user callback.
 parent=v in ('parent','parent-fused','config','all');fused=v in ('fused','parent-fused','all');config=v in ('config','all')
 i=s.index('\t\td, e := m.GetDecl(t)\n\t\tif e != nil',s.index('// The beta reducer'));end=s.index('\n\t\tsize := uint32(len(c.results))',i)
 new='''d,e:=m.GetDecl(t);if e!=nil{return e}
 '''
 if fused:
  helper=a/'ast_rewriter_access.go';ed[helper]=helper.read_text()+'''
// RewriterAppDeclaration reads the shared declaration and current reference count.
func(m *ASTManager)RewriterAppDeclaration(h ASTHandle)(ASTHandle,uint32,error){
 ref,err:=m.readKind(h,ASTApp);if err!=nil{return ASTHandle{},0,err}
 slot:=m.nodeSlotAt(ref.slot);return m.external(slot.app.decl),slot.node.rc,nil
}
'''
  new='''d,rc,e:=m.RewriterAppDeclaration(t);if e!=nil{return e}
 '''
 if parent:
  new+='''if fi>0 && c.frames[fi-1].kind==ast.ASTApp && c.frames[fi-1].state()==0{
  '''
  if config:new+='''skip:=false;if cfg,ok:=r.cfg.(*theoryRewriterConfiguration);ok{skip=!cfg.flat}
  if !skip{'''
  if not fused:new+='''rc,e:=m.GetRefCount(t);if e!=nil{return e}
  '''
  new+='''if rc<=1{pd,e:=m.GetDecl(c.frames[fi-1].curr);if e!=nil{return e};if pd==d{
   assoc,e:=m.RewriterAssociative(d);if e!=nil{return e}
   if assoc{flat,e:=r.cfg.FlatAssoc(d);if e!=nil{return e};if flat{c.frames=c.frames[:fi];return r.setNewChild(t)}}
  }}'''+('}'if config else'')+'}\n'
 elif fused:
  old=s[i:end];j=old.index('assoc := false');new+=old[j:]
 if parent or fused:ed[p]=s[:i]+new+s[end:]
 if v in ('small-patterns','all'):
  p=rw/'th_rewriter.go';s=p.read_text();i=s.index('result := make([]ast.ASTHandle',s.index('func theoryUniqueArguments('))
  s=s[:i]+'''switch arguments.Count(){case 0:return nil,nil;case 1:h,e:=arguments.At(0);if e!=nil{return nil,e};return []ast.ASTHandle{h},nil}
 if arguments.Count()<=8{
  result:=make([]ast.ASTHandle,0,arguments.Count());for i:=uint32(0);i<arguments.Count();i++{h,e:=arguments.At(i);if e!=nil{return nil,e};found:=false;for _,known:=range result{if known==h{found=true;break}};if !found{result=append(result,h)}};return result,nil
 }
 '''+s[i:];ed[p]=s
 return ed
def prep(v):
 od=rd/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v))
 with(w/'build.lock').open('a')as lk,(od/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-count=1','-overlay='+str(o),'./ast/rewriter'],cwd=pkg,stdout=f,stderr=f)
  run(['go','test','-p','3','-count=1','-tags=g3checked,g3debug,g3trace','-overlay='+str(o),'-run=RewriterEngine|Flatten|Associative|ReduceQuantifier|UniqueArguments','./ast/rewriter'],cwd=pkg,stdout=f,stderr=f)
 return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(prep,vs)))
 ho.root=co.rd=rd
 with ThreadPoolExecutor(9)as ex:
  fs=[ex.submit(ho.measure_spec,j,{v:b[0]for v,b in bb.items()},4)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  fs+=[ex.submit(co.trial,(c,n),{v:b[1]for v,b in bb.items()}|{'native':pkg.parent/'build/z3'})for c,n in zip([1,6,12,23,31,37],['miss1','miss3','miss6','core1','core3','core6'])]
  for f in fs:f.result()
 print('all passed',flush=True)

