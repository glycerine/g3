from common import *
import enode_scope_batch as eb,shared_enode_declarations as sd,shipping_term_inputs as sh,holdouts as ho,split_instance_attribution as sa,candidate_operand_trials as co
sm=pkg/'smtcore';rd=d/'coallocate-enode-arguments';rd.mkdir(exist_ok=True);vs=['before','pair','four','embedded','directory','together']
def orig(p):return subprocess.check_output(['git','show','f830ebca3:pkg/smtcore/'+p.name],cwd=pkg,text=True)
def edits(v):
 if v=='before':return {}
 ed={};directory=v in ('directory','together')
 if v!='directory':
  term=sm/'smt_internalizer.go';s=orig(term);i=s.index('func (s *SMTInternalizerState) existingTermChildren(');j=s.index('\n}',i)+2;fn=s[i:j].replace('([]*SMTEnode, bool, error)','([2]*SMTEnode, bool, error)').replace('return nil,','return [2]*SMTEnode{},').replace('return []*SMTEnode{pair[0], pair[1]}, true, nil','return pair,true,nil')
  ed[term]=s[:i]+fn+s[j:]
  k=sm/'smt_enode_core.go';s=orig(k).replace('children []*SMTEnode','children [2]*SMTEnode');i=s.index('n := &SMTEnode{');j=s.index('\n\t}',i)+3
  init='''count:=header.NumArgs;if options.SuppressArguments{count=0}
  var node *SMTEnode;var children []*SMTEnode
  '''
  if v=='embedded':
   s=once(s,'type SMTEnode struct {','type SMTEnode struct {\n shortOperands [2]*SMTEnode');i=s.index('n := &SMTEnode{');j=s.index('\n\t}',i)+3
   init+='''node=new(SMTEnode);if count>0{if count<=2{children=node.shortOperands[:count:count]}else{children=make([]*SMTEnode,count)}}'''
  else:
   arities=[2]if v=='pair'else[1,2,3,4]
   init+='switch count{'
   for n in arities:init+='case '+str(n)+':block:=new(struct{node SMTEnode;args ['+str(n)+']*SMTEnode});node=&block.node;children=block.args[:];'
   init+='default:node=new(SMTEnode);if count>0{children=make([]*SMTEnode,count)}}'
  s=s[:i]+init+'\n n:=node\n '+s[i:j].replace('n := &SMTEnode{','*n = SMTEnode{arguments:children,')+s[j:]
  s=once(s,'n.arguments = term.children','if count>0{copy(n.arguments,term.children[:])}')
  s=once(s,'n.arguments = make([]*SMTEnode, count)','')
  if v=='embedded':
   # The returned, retired node may remain borrowed. Drop GC roots in its own array.
   x=sm/'smt_enode_aux.go';ed[x]=orig(x).replace('n.sourceParents, n.arguments = nil, nil','n.shortOperands=[2]*SMTEnode{}\n n.sourceParents,n.arguments=nil,nil')
  ed[k]=s
 if directory:
  k=sm/'smt_checker.go';s=orig(k);s=once(s,'prior := c.enodes.get(node.owner)','record:=c.exprs.write(node.owner);prior:=record.enode');s=once(s,'c.enodes.set(node.owner, node)','record.enode=node;c.exprs.enodeCount++')
  s=once(s,'c.relevant.set(node.owner, relevant)','if !borrowed{relevant=record.flags&smtExprRelevant!=0};c.relevant.setRecord(record,relevant)');ed[k]=s
  k=sm/'smt_expr_table.go';s=orig(k);needle='record := r.t.write(h)\n\tmarked := record.flags&smtExprRelevant != 0'
  ed[k]=once(s,needle,'return r.setRecord(r.t.write(h),value)\n}\nfunc(r smtRelevantTable)setRecord(record *smtExprRecord,value bool)bool{\n marked:=record.flags&smtExprRelevant!=0')
  k=sm/'smt_internalizer_state.go';s=orig(k);ed[k]=s.replace('s.context.registerEnode(node, s.context.relevant.get(expression), false)','s.context.registerEnode(node,false,false)')
 return ed
def prep(v):
 od=rd/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v));b=od/'smt.test'
 with(w/'build.lock').open('a')as lk,(od/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-pgo=off','-c','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=f,stderr=f)
  run([b,'-test.run=Enode|Relevanc|Congruence|Internaliz|Declaration|MAM|ScopeRestoration|Equality|TheoryBV'],cwd=sm,stdout=f,stderr=f)
  run(['go','test','-p','3','-count=1','-tags=g3checked,g3debug,g3trace','-overlay='+str(o),'-run=Enode|ScopeRestoration|Register|Relevan|Declaration|HeldRef','./smtcore'],cwd=pkg,stdout=f,stderr=f)
 return b,build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(prep,vs)))
 eb.rd=sd.dp.rd=ho.root=co.rd=sh.rd=rd;eb.vs=vs+['native'];sd.dp.vs=sh.vs=vs
 with ThreadPoolExecutor(9)as ex:
  fs=[ex.submit(sd.dp.heap,bb),ex.submit(sh.public,bb)]+[ex.submit(eb.lane,n,{v:b[0]for v,b in bb.items()}|{'native':d/'enode-scope-batch/native/batch'})for n in (32,256,2048)]
  fs+=[ex.submit(ho.measure_spec,j,{v:b[1]for v,b in bb.items()},4)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  fs+=[ex.submit(co.trial,(c,n),{v:b[2]for v,b in bb.items()}|{'native':pkg.parent/'build/z3'})for c,n in zip([1,6,12,23,31,37],['miss1','miss3','miss6','core1','core3','core6'])]
  for f in fs:f.result()
 print('all passed',flush=True)

