from common import *
import ast_canonical_density as ca,holdouts as ho,split_instance_attribution as sa,candidate_operand_trials as co
a=pkg/'ast';rd=d/'compact-inline-operands';rd.mkdir(exist_ok=True);vs=['before','bits20','bits24','group24','wide-slot','first-two']
def orig(p):return subprocess.check_output(['git','show','f830ebca3:pkg/ast/'+p.name],cwd=pkg,text=True)
def edits(v):
 if v=='before':return {}
 ed={};storage=a/'ast_core_storage.go';s=orig(storage);pair=v=='first-two';wide=v=='wide-slot';group=v.startswith('group')or pair
 if group:s=s.replace('markOwners [2]*astMarkOwnerPage','wideOperands [astPageSize/8]*[8][astInlineArgs]astNodeRef\n markOwners [2]*astMarkOwnerPage')
 else:s=s.replace('markOwners [2]*astMarkOwnerPage','wideOperands *[astPageSize][astInlineArgs]astNodeRef\n markOwners [2]*astMarkOwnerPage')
 s=once(s,'inlineArgs [astInlineArgs]astNodeRef','inlineArgs [2]astNodeRef\n tailSlot uint32' if pair else 'inlineArgs [astInlineArgs]uint32'+('\n generations uint32'if wide else''))
 ed[storage]=s;k=a/'ast_inline_four_test.go';ed[k]=orig(k).replace('unsafe.Sizeof(astNodeSlot{}) != 100','unsafe.Sizeof(astNodeSlot{}) > 100')
 k=a/'ast_app_slice.go';s=orig(k).replace('app.inlineArgs[i] = astNodeRef{h.slot, h.generation}','m.setInlineOperand(r.slot,app,uint32(i),astNodeRef{h.slot,h.generation})')
 s=s.replace('app.inlineArgs[i] != (astNodeRef{arg.slot, arg.generation})','m.inlineOperand(app,uint32(i)) != (astNodeRef{arg.slot, arg.generation})');ed[k]=s
 k=a/'ast_core_factories.go';s=orig(k).replace('v.inlineArgs[i] = child','m.setInlineOperand(r.slot,v,i,child)').replace('v.args, e = m.newASTPayloadArguments(*args, &v.inlineArgs)','var inline [astInlineArgs]astNodeRef\n v.args,e=m.newASTPayloadArguments(*args,&inline)\n if e==nil{for i:=uint32(0);i<min(args.count,uint32(astInlineArgs));i++{m.setInlineOperand(r.slot,v,i,inline[i])}}');ed[k]=s
 k=a/'ast_core_payload.go';s=orig(k).replace('return a.inlineArgs[i], nil','return m.inlineOperand(a,i),nil').replace('return a.inlineArgs[0], a.inlineArgs[1], nil','return m.inlineOperand(a,0),m.inlineOperand(a,1),nil')
 s=once(s,'return append(dst, a.inlineArgs[:a.count]...), nil','for i:=uint32(0);i<a.count;i++{dst=append(dst,m.inlineOperand(a,i))};return dst,nil');ed[k]=s
 k=a/'ast_core_accessors.go';ed[k]=orig(k).replace('m.external(v.inlineArgs[index])','m.external(m.inlineOperand(v,index))')
 k=a/'ast_core_delete.go';ed[k]=orig(k).replace('child = inline.inlineArgs[i-1]','child=m.inlineOperand(inline,i-1)')
 k=a/'ast_table_hash.go';s=orig(k).replace('r := v.inlineArgs[i]','r := m.inlineOperand(v,i)')
 i=s.index('switch x.count {',s.index('if x.count <= astInlineArgs'));j=s.index('\n\t\t}',i)
 if pair:comp='''if x.count>0 && x.inlineArgs[0]!=y.inlineArgs[0] || x.count>1&&x.inlineArgs[1]!=y.inlineArgs[1]{return false,nil}
 for i:=uint32(2);i<x.count;i++{if m.inlineOperand(x,i)!=m.inlineOperand(y,i){return false,nil}};return true,nil'''
 else:
  # An incomplete candidate can contain bytes from a previous attempted registration.
  # Compare only the enumerated operands, including the original generation.
  fast='x.inlineArgs[0]!=0 && y.inlineArgs[0]!=0'if not wide else'x.generations!=0 && y.generations!=0'
  comp='''if x.count==0{return true,nil}
 if '''+fast+'''{'''+('if x.generations!=y.generations{return false,nil};'if wide else'')+'''switch x.count{case 1:return x.inlineArgs[0]==y.inlineArgs[0],nil;case 2:return *(*[2]uint32)(x.inlineArgs[:])==*(*[2]uint32)(y.inlineArgs[:]),nil;case 3:return *(*[3]uint32)(x.inlineArgs[:])==*(*[3]uint32)(y.inlineArgs[:]),nil;case 4:return x.inlineArgs==y.inlineArgs,nil}}
 for i:=uint32(0);i<x.count;i++{if m.inlineOperand(x,i)!=m.inlineOperand(y,i){return false,nil}};return true,nil'''
 s=s[:i]+comp+s[j:];ed[k]=s
 s='''package ast

// The slot's overflow storage stays in the owning manager. It holds the
// original references across allocation, hashing, equality and destruction.
func(m *ASTManager)wideOperandRow(slot uint32)*[astInlineArgs]astNodeRef{
 page:=m.nodes[(slot-1)/astPageSize];i:=(slot-1)%astPageSize
 '''
 if group:s+='''g:=&page.wideOperands[i/8];if *g==nil{*g=new([8][astInlineArgs]astNodeRef)};return &(*g)[i%8]
}'''
 else:s+='''if page.wideOperands==nil{page.wideOperands=new([astPageSize][astInlineArgs]astNodeRef)};return &page.wideOperands[i]
}'''
 getwide='m.nodes[(slot-1)/astPageSize].wideOperands[((slot-1)%astPageSize)/8][(slot-1)%8][i]'if group else'm.nodes[(slot-1)/astPageSize].wideOperands[(slot-1)%astPageSize][i]'
 if pair:
  s+='''
func(m *ASTManager)inlineOperand(a *astAppRecord,i uint32)astNodeRef{if i<2{return a.inlineArgs[i]};slot:=a.tailSlot;return '''+getwide+'''}
func(m *ASTManager)setInlineOperand(slot uint32,a *astAppRecord,i uint32,r astNodeRef){
 if i<2{a.inlineArgs[i]=r;return};a.tailSlot=slot;m.wideOperandRow(slot)[i]=r
}'''
 else:
  bits=20 if v=='bits20'else 24
  s+='\nconst inlineSlotBits='+str(bits)+'\n'
  packed=('a.generations!=0'if wide else'a.inlineArgs[0]!=0');null=('a.generations==0'if wide else'a.inlineArgs[0]==0');fit=('r.generation>0 && r.generation<256'if wide else 'r.slot>0 && r.slot<(1<<inlineSlotBits) && r.generation>0 && r.generation<(1<<(32-inlineSlotBits))')
  unpack='astNodeRef{a.inlineArgs[i],(a.generations>>(8*i))&255}'if wide else'astNodeRef{a.inlineArgs[i]&((1<<inlineSlotBits)-1),a.inlineArgs[i]>>inlineSlotBits}'
  pack='a.inlineArgs[i]=r.slot;shift:=8*i;a.generations=a.generations &^ (255<<shift) | r.generation<<shift'if wide else'a.inlineArgs[i]=r.slot|r.generation<<inlineSlotBits'
  s+='''
func(m *ASTManager)inlineOperand(a *astAppRecord,i uint32)astNodeRef{if '''+packed+'''{return '''+unpack+'''};slot:=a.inlineArgs[1];return '''+getwide+'''}
func(m *ASTManager)setInlineOperand(slot uint32,a *astAppRecord,i uint32,r astNodeRef){
 if '''+null+'''&&a.inlineArgs[1]!=0{m.wideOperandRow(slot)[i]=r;return}
 if '''+fit+'''{'''+pack+''';return}
 row:=m.wideOperandRow(slot)
 for j:=uint32(0);j<i;j++{row[j]=m.inlineOperand(a,j)}
 row[i]=r;a.inlineArgs=[astInlineArgs]uint32{0,slot}
 '''+('a.generations=0'if wide else'')+'''
}'''
 ed[a/'ast_inline_operands.go']=s
 return ed
def prep(v):
 od=rd/v;od.mkdir(exist_ok=True);ed=edits(v);t=a/'ast_inline_reference_range_test.go';ed[t]=(d/t.name).read_text()
 o=overlay(od/'overlay',ed);b=od/'ast.test'
 with(w/'build.lock').open('a')as lk,(od/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-pgo=off','-c','-overlay='+str(o),'-o',b,'./ast'],cwd=pkg,stdout=f,stderr=f)
  run([b,'-test.run=Inline|Application|ASTApp|Canonical|Coercion|FreeList|TraceAcquisition'],cwd=a,stdout=f,stderr=f)
  run(['go','test','-p','3','-count=1','-tags=g3checked,g3debug,g3trace','-overlay='+str(o),'-run=Inline|Application|ASTApp|Canonical|Coercion|FreeList|TraceAcquisition','./ast'],cwd=pkg,stdout=f,stderr=f)
 return b,build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(prep,vs)))
 ca.rd=ho.root=co.rd=rd;ca.vs=vs
 with ThreadPoolExecutor(9)as ex:
  fs=[ex.submit(ca.heap,bb)]
  fs+=[ex.submit(ho.measure_spec,j,{v:b[1]for v,b in bb.items()},4)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  fs+=[ex.submit(co.trial,(c,n),{v:b[2]for v,b in bb.items()}|{'native':pkg.parent/'build/z3'})for c,n in zip([1,6,12,23,31,37],['miss1','miss3','miss6','core1','core3','core6'])]
  for f in fs:f.result()
 print('all passed',flush=True)

