from common import *
import compact_inline_operands as ci,ast_canonical_density as ca,holdouts as ho,split_instance_attribution as sa,candidate_operand_trials as co
a=pkg/'ast';rd=d/'application-metadata-layout';rd.mkdir(exist_ok=True);vs=['before','identity','sort','both','boolean','operands20','compact']
def orig(p):return subprocess.check_output(['git','show','4052fd136:pkg/ast/'+p.name],cwd=pkg,text=True)
def edits(v):
 if v=='before':return {}
 ed={}
 if v in ('operands20','compact'):
  ed=ci.edits('bits20');k=a/'ast_core_accessors.go';ed[k]=orig(k).replace('m.external(v.inlineArgs[index])','m.external(m.inlineOperand(v,index))')
 if v=='operands20':return ed
 identity=v in ('identity','both','compact');sort=v in ('sort','both','compact');boolean=v=='boolean'
 files=['ast_core_storage.go','ast_core_accessors.go','ast_core_register.go','ast_app_slice.go','ast_held_constant.go','ast_inline_four_test.go'];T={nm:ed.get(a/nm)or orig(a/nm)for nm in files};s=T[files[0]]
 s=s.replace('unsafe.Offsetof(astAppRecord{}.inlineArgs)','44');T[files[-1]]=T[files[-1]].replace('unsafe.Sizeof(astNodeSlot{}) != 100','unsafe.Sizeof(astNodeSlot{}) > 100')
 if identity:
  s=once(s,'declFamily FamilyID\n\tdeclKind   int32','identity uint32')
  s+='''
func(a *astAppRecord)cacheIdentity(family FamilyID,kind int32){
 f,k:=uint32(family+1),uint32(kind+1)
 a.declCached=f<(1<<12) && k<(1<<20)
 if a.declCached{a.identity=f<<20|k}
}
func(a *astAppRecord)familyID()FamilyID{return FamilyID(a.identity>>20)-1}
func(a *astAppRecord)operation()int32{return int32(a.identity&((1<<20)-1))-1}
'''
  name='ast_app_slice.go';x=T[name];i=x.index('a.declFamily, a.declKind =');j=x.index('a.ground = true',i)
  x=x[:i]+'''family,kind:=FamilyID(NullFamilyID),int32(-1)
 if decl.identityCached{family,kind=decl.identityFamily,decl.identityKind}
 a.cacheIdentity(family,kind)
 a.labels=len(operands)>0 && family==1 && kind==0
 '''+x[j:];T[name]=x
  name='ast_core_register.go';T[name]=T[name].replace('a.declFamily, a.declKind, a.declCached = fid, k, true','a.cacheIdentity(fid,k)')
  for name in ['ast_core_accessors.go','ast_held_constant.go']:T[name]=T[name].replace('.declKind','.operation()').replace('.declFamily','.familyID()')
 if sort:
  s=once(s,'\trangeSort astNodeRef\n\t// inlineArgs','\tsortCode uint32\n\t// inlineArgs')
  s+='''
func(a *astAppRecord)cacheRange(r astNodeRef){
 if r.slot<(1<<20)&&r.generation<(1<<12){a.sortCode=r.slot|r.generation<<20}else{a.sortCode=0}
}
func(a *astAppRecord)cachedRange()astNodeRef{return astNodeRef{a.sortCode&((1<<20)-1),a.sortCode>>20}}
'''
  name='ast_app_slice.go';x=T[name].replace('m.appAt(h.slot).rangeSort','m.appAt(h.slot).cachedRange()').replace('a.rangeSort = decl.rangeSort','a.cacheRange(decl.rangeSort)');T[name]=x
  name='ast_core_register.go';T[name]=T[name].replace('a.rangeSort = m.declAt(a.decl.slot).rangeSort','a.cacheRange(m.declAt(a.decl.slot).rangeSort)')
  name='ast_core_accessors.go';x=T[name].replace('a.rangeSort.slot != 0','a.sortCode!=0').replace('return a.rangeSort, nil','return a.cachedRange(),nil').replace('.app.rangeSort.slot != 0','.app.sortCode!=0').replace('slot.app.rangeSort == m.boolSort','slot.app.cachedRange()==m.boolSort').replace('app.rangeSort.slot != 0','app.sortCode!=0').replace('app.rangeSort == m.boolSort','app.cachedRange()==m.boolSort');T[name]=x
 if boolean:
  s=once(s,'\trangeSort astNodeRef\n\t// inlineArgs','\trangeClass uint8\n\t// inlineArgs')
  s+='''
func(m *ASTManager)cacheRangeClass(a *astAppRecord,r astNodeRef){
 if r.slot==0{a.rangeClass=0}else if r==m.boolSort{a.rangeClass=1}else{a.rangeClass=2}
}
func(m *ASTManager)knownAppRange(a *astAppRecord)astNodeRef{
 if a.rangeClass==1{return m.boolSort};if a.rangeClass==2{return m.declAt(a.decl.slot).rangeSort};return astNodeRef{}
}
'''
  name='ast_app_slice.go';T[name]=T[name].replace('m.appAt(h.slot).rangeSort','m.knownAppRange(m.appAt(h.slot))').replace('a.rangeSort = decl.rangeSort','m.cacheRangeClass(a,decl.rangeSort)')
  name='ast_core_register.go';T[name]=T[name].replace('a.rangeSort = m.declAt(a.decl.slot).rangeSort','m.cacheRangeClass(a,m.declAt(a.decl.slot).rangeSort)')
  name='ast_core_accessors.go';x=T[name].replace('a.rangeSort.slot != 0','a.rangeClass==1').replace('return a.rangeSort, nil','return m.boolSort,nil').replace('.app.rangeSort.slot != 0','.app.rangeClass!=0').replace('slot.app.rangeSort == m.boolSort','slot.app.rangeClass==1').replace('app.rangeSort.slot != 0','app.rangeClass!=0').replace('app.rangeSort == m.boolSort','app.rangeClass==1');T[name]=x
 T[files[0]]=s
 for n,x in T.items():
  if x!=orig(a/n):ed[a/n]=x
 return ed
def prep(v):
 od=rd/v;od.mkdir(exist_ok=True);ed=edits(v);t=a/'ast_inline_reference_range_test.go';ed[t]=(d/t.name).read_text()
 o=overlay(od/'overlay',ed);b=od/'ast.test'
 with(w/'build.lock').open('a')as lk,(od/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-pgo=off','-c','-overlay='+str(o),'-o',b,'./ast'],cwd=pkg,stdout=f,stderr=f)
  run([b,'-test.run=Header|Identity|Inline|Application|ASTApp|Canonical|Coercion|FreeList|TraceAcquisition|Sort'],cwd=a,stdout=f,stderr=f)
  run(['go','test','-p','3','-count=1','-tags=g3checked,g3debug,g3trace','-overlay='+str(o),'-run=Header|Identity|Inline|ASTApp|Canonical|Coercion','./ast'],cwd=pkg,stdout=f,stderr=f)
 return b,build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(prep,vs)))
 ca.rd=ho.root=co.rd=rd;ca.vs=vs
 with ThreadPoolExecutor(9)as ex:
  fs=[ex.submit(ca.heap,bb)]
  fs+=[ex.submit(ho.measure_spec,j,{v:b[1]for v,b in bb.items()},4)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  fs+=[ex.submit(co.trial,(c,n),{v:b[2]for v,b in bb.items()}|{'native':pkg.parent/'build/z3'})for c,n in zip([1,6,12,23,31,37],['miss1','miss3','miss6','core1','core3','core6'])]
  for f in fs:f.result()
 print('all passed',flush=True)

