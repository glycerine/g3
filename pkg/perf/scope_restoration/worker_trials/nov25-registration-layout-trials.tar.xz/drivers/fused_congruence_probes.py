from common import *
import enode_scope_batch as eb,holdouts as ho,split_instance_attribution as sa,candidate_operand_trials as co
rd=d/'fused-congruence-probes';rd.mkdir(exist_ok=True);sm=pkg/'smtcore';vs=['before','erase-bucket','insert','erase','both','wide']
def orig(p):return subprocess.check_output(['git','show','4052fd136:pkg/smtcore/'+p.name],cwd=pkg,text=True)
def edits(v):
 if v=='before':return {}
 table=sm/'smt_cg_table.go';small=sm/'smt_cg_small_table.go';s=orig(table);q=orig(small)
 if v=='erase-bucket':
  i=s.index('candidate, _, err := t.Find(node)',s.index('func (t *SMTCongruenceTable) Erase('));j=s.index('return true, nil',i)
  return {table:s[:i]+'''if err:=t.validateNode(node);err!=nil{return false,err};bucket,err:=t.ensureTable(node);if err!=nil{return false,err}
   candidate,_,err:=bucket.find(node);if err!=nil||candidate==nil{return false,err};bucket.remove(candidate)
   '''+s[j:]}
 if v=='wide':
  i=s.index('candidate, commuted, err := bucket.find(node)',s.index('func (t *SMTCongruenceTable) Insert('))
  s=s[:i]+'''if len(node.arguments)>2{
   key:=smtCongruenceSignature(node);chain:=bucket.wide[key]
   for _,candidate:=range chain{same,swap,e:=SMTEnodesCongruent(candidate,node);if e!=nil{return SMTCongruenceInsertResult{},e};if same{return SMTCongruenceInsertResult{Node:candidate,Commuted:swap},nil}}
   bucket.wide[key]=append(chain,node);return SMTCongruenceInsertResult{Node:node},nil
  }
  '''+s[i:];return {table:s}
 q+='''
func(t *smtCgSmallTable)probe(k0,k1 *SMTEnode)(int,*SMTEnode){
 if len(t.entries)==0{return -1,nil}
 mask:=len(t.entries)-1
 for i:=smtCgSmallSlot(k0,k1,t.shift);;i=(i+1)&mask{
  e:=&t.entries[i];if e.node==nil{return i,nil};if e.k0==k0&&e.k1==k1{return i,e.node}
 }
}
'''
 if v in ('insert','both'):
  i=s.index('candidate, commuted, err := bucket.find(node)',s.index('func (t *SMTCongruenceTable) Insert('))
  s=s[:i]+'''if len(node.arguments)<=2 && (!node.commutative || bucket.flatAssociative){
  key:=smtCongruenceSmallKey(node);at,candidate:=bucket.small.probe(key[0],key[1])
  if candidate!=nil{same,swapped,e:=SMTEnodesCongruent(candidate,node);if e!=nil{return SMTCongruenceInsertResult{},e};if same{return SMTCongruenceInsertResult{Node:candidate,Commuted:swapped},nil}}
  if at<0||2*(bucket.small.count+1)>len(bucket.small.entries){bucket.small.set(key[0],key[1],node)}else if candidate==nil{bucket.small.entries[at]=smtCgSmallEntry{key[0],key[1],node};bucket.small.count++}else{bucket.small.entries[at].node=node}
  return SMTCongruenceInsertResult{Node:node},nil
 }
 '''+s[i:]
 if v in ('erase','both'):
  i=q.index('t.count--',q.index('func (t *smtCgSmallTable) del('))
  q=q[:i]+'''t.removeSlot(i)
}
func(t *smtCgSmallTable)removeSlot(i int){mask:=len(t.entries)-1
 '''+q[i:]
  i=s.index('candidate, _, err := t.Find(node)',s.index('func (t *SMTCongruenceTable) Erase('));j=s.index('return true, nil',i)
  s=s[:i]+'''if err:=t.validateNode(node);err!=nil{return false,err};bucket,e:=t.ensureTable(node);if e!=nil{return false,e}
  if len(node.arguments)<=2 && (!node.commutative || bucket.flatAssociative){
   key:=smtCongruenceSmallKey(node);at,candidate:=bucket.small.probe(key[0],key[1]);if candidate==nil{return false,nil}
   same,_,e:=SMTEnodesCongruent(candidate,node);if e!=nil||!same{return false,e}
   if smtCongruenceSmallKey(candidate)==key{bucket.small.removeSlot(at)}else{bucket.remove(candidate)}
   return true,nil
  }
  candidate,_,err:=bucket.find(node);if err!=nil||candidate==nil{return false,err}
  bucket.remove(candidate)
  '''+s[j:]
 return {table:s,small:q}
def prep(v):
 od=rd/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v));b=od/'smt.test'
 with(w/'build.lock').open('a')as lk,(od/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-pgo=off','-c','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=f,stderr=f)
  run([b,'-test.run=Cg|CG|Congruence|Equal|Enode|MAM|ScopeRestoration|Declaration'],cwd=sm,stdout=f,stderr=f)
  run(['go','test','-p','3','-count=1','-tags=g3checked,g3debug,g3trace','-overlay='+str(o),'-run=Cg|CG|Congruence|Collision|Enode|ScopeRestoration','./smtcore'],cwd=pkg,stdout=f,stderr=f)
 return b,build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(prep,vs)))
 eb.rd=ho.root=co.rd=rd;eb.vs=vs+['native']
 with ThreadPoolExecutor(9)as ex:
  fs=[ex.submit(eb.lane,n,{v:b[0]for v,b in bb.items()}|{'native':d/'enode-scope-batch/native/batch'})for n in (32,256,2048)]
  fs+=[ex.submit(ho.measure_spec,j,{v:b[1]for v,b in bb.items()},4)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  fs+=[ex.submit(co.trial,(c,n),{v:b[2]for v,b in bb.items()}|{'native':pkg.parent/'build/z3'})for c,n in zip([1,6,12,23,31,37],['miss1','miss3','miss6','core1','core3','core6'])]
  for f in fs:f.result()
 print('all passed',flush=True)

