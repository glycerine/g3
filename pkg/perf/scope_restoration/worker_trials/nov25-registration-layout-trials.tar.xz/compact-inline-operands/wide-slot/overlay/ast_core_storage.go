package ast

// Source: src/ast/ast.h; src/ast/ast.cpp:1354,2213-2238.
// Concrete pointer-free storage for src/ast/ast.h. Domain destruction is
// performed by ast_manager action translations, never by page reclamation.

import (
	"errors"
	"math"
	"reflect"
	"sync/atomic"
	"unsafe"

	"github.com/glycerine/g3/pkg/arena"

	"github.com/glycerine/g3/pkg/util/control"
	udiag "github.com/glycerine/g3/pkg/util/diagnostic"
	"github.com/glycerine/g3/pkg/util/idgen"
	unumeral "github.com/glycerine/g3/pkg/util/numeral"
	uparams "github.com/glycerine/g3/pkg/util/params"
	usymbol "github.com/glycerine/g3/pkg/util/symbol"
	utext "github.com/glycerine/g3/pkg/util/text"
)

var ErrASTHandle = errors.New("g3: invalid AST owner, kind or lifetime")
var ErrASTDomain = errors.New("g3: AST source precondition")
var ErrASTPending = errors.New("g3: AST release continuation is pending")
var astIdentity atomic.Uint64

type ASTHandle struct {
	origin           uint64
	slot, generation uint32
}

func (h ASTHandle) Origin() uint64     { return h.origin }
func (h ASTHandle) Slot() uint32       { return h.slot }
func (h ASTHandle) Generation() uint32 { return h.generation }
func (h ASTHandle) IsNull() bool       { return h == ASTHandle{} }

type astNodeRef struct{ slot, generation uint32 }
type ASTKind uint16

const (
	ASTApp ASTKind = iota
	ASTVar
	ASTQuantifier
	ASTSort
	ASTFuncDecl
)

type ASTProofMode uint8

const (
	ASTProofDisabled ASTProofMode = iota
	ASTProofEnabled
)

type ASTManagerConfig struct {
	Symbols     *usymbol.Manager
	Numerals    *unumeral.RationalService
	Budget      *arena.Budget
	ProofMode   ASTProofMode
	OutOfMemory func() bool
	TraceTags   *udiag.TraceTags
	Params      *uparams.ParamsContext
	Globals     *uparams.GlobalParamsService
}
type ASTManagerStats struct {
	LiveNodes, LiveParameters, LiveInfos, LiveReferences  uint32
	AllocatedBytes, OwnerBytes, PageBytes, DirectoryBytes uint64
}
type ASTParameter struct {
	origin           uint64
	slot, generation uint32
}
type ASTSortInfo struct {
	origin           uint64
	slot, generation uint32
}
type ASTFuncDeclInfo struct {
	origin           uint64
	slot, generation uint32
}
type ASTRef struct {
	origin           uint64
	slot, generation uint32
}
type ASTParameterKind uint32

const (
	ASTParameterInt ASTParameterKind = iota
	ASTParameterAST
	ASTParameterSymbol
	ASTParameterRational
	ASTParameterDouble
	ASTParameterExternal
)

type ASTFuncFlags struct{ LeftAssociative, RightAssociative, FlatAssociative, Commutative, Chainable, Pairwise, Injective, Idempotent, Skolem bool }
type ASTQuantifierSpec struct {
	Forall               bool
	Sorts                []ASTHandle
	Names                []usymbol.Symbol
	Body                 ASTHandle
	Weight               int32
	QID, SkolemID        usymbol.Symbol
	Patterns, NoPatterns []ASTHandle
}

type astNodeRecord struct {
	generation, id, hash, rc, kindIndex uint32
	kind                                ASTKind
	live                                bool
	flags                               astNodeFlags
}

type astNodeFlags uint8

const (
	astFirstMark astNodeFlags = 1 << iota
	astSecondMark
	astShared
	astCloseMark
	astWasSubstitutionKey
)

func (n *astNodeRecord) hasFlag(bit astNodeFlags) bool { return n.flags&bit != 0 }
func (n *astNodeRecord) setFlag(bit astNodeFlags, on bool) {
	if on {
		n.flags |= bit
	} else {
		n.flags &^= bit
	}
}

type astSortRecord struct {
	nextFree uint32
	name     usymbol.Symbol
	info     ASTSortInfo
	// identity* cache the owned info's family and kind, as for declarations.
	identityFamily FamilyID
	identityKind   int32
	identityCached bool
	// seqParam caches sequenceSortParameter's reading of the owned info
	// (seqParamState 1: no single AST parameter of the sequence family; 2:
	// seqParam is that parameter). It is reset with identityCached.
	seqParamState uint8
	seqParam      astNodeRef
}
type astFuncDeclRecord struct {
	nextFree  uint32
	name      usymbol.Symbol
	info      ASTFuncDeclInfo
	domain    arena.SmallBytesRef
	arity     uint32
	rangeSort astNodeRef
	// identityFamily and identityKind copy the family and kind of the owned
	// info registration attached (identityCached). That info lives, with
	// both fields unchanged, until this declaration is deleted.
	identityFamily FamilyID
	identityKind   int32
	identityCached bool
	// identityFlags copies that info's flags under the same condition.
	identityFlags ASTFuncFlags
	// domainRefs copies the domain payload (written once, at creation)
	// for the hot readers of normal builds; debug builds read the payload.
	domainRefs []astNodeRef
	// arithDomain caches, for arithDomainFamily, whether some domain sort
	// belongs to that family: 0 unknown, 1 no, 2 yes. Sort identities are
	// fixed while the declaration lives.
	arithDomain       uint8
	arithDomainFamily FamilyID
}
type astAppRecord struct {
	// count, the flags and the cached declaration identity come first: in
	// an astNodeSlot they share the node record's cache line.
	count                       uint32
	ground, quantifiers, labels bool
	// declCached says declFamily and declKind copy declIdentity(decl),
	// taken when the app was registered. A live app holds its declaration,
	// whose identity is unchanged until that declaration is deleted.
	declCached bool
	declFamily FamilyID
	declKind   int32
	decl       astNodeRef
	args       arena.SmallBytesRef
	depth      uint32
	// rangeSort copies the declaration's range sort, set at registration
	// (null before), and is likewise unchanged while the app is live.
	rangeSort astNodeRef
	// inlineArgs copies the first min(count, astInlineArgs) arguments of
	// the args payload, written with it; app arguments never change while
	// the app is live. appArg/appArgPair read them without the payload
	// lookup, and hashing and comparison use them when they hold all.
	inlineArgs  [astInlineArgs]uint32
	generations uint32
}

// Short applications keep up to four full generation-checked child references.
const astInlineArgs = 4

type astVarRecord struct {
	nextFree, index uint32
	sort            astNodeRef
}
type astQuantifierRecord struct {
	nextFree                                   uint32
	body                                       astNodeRef
	sorts, names, patterns, noPatterns         arena.SmallBytesRef
	count, patternCount, noPatternCount, depth uint32
	weight                                     int32
	qid, skolemID                              usymbol.Symbol
	forall, unusedVars, labels                 bool
}
type astParameterRecord struct {
	generation, nextFree uint32
	Kind                 ASTParameterKind
	Live                 bool
	integer              int32
	ast                  astNodeRef
	symbol               usymbol.Symbol
	Rational             unumeral.OwnedRational
	rationalTraceID      uint64 // allocation serial for the memory trace; 0: none
	double               float64
	external             uint32
}
type astInfoRecord struct {
	generation, nextFree            uint32
	live, isSort, private, attached bool
	lexical                         bool
	retainedByDebug                 bool
	memoryTraceAllocated            bool
	family                          FamilyID
	kind                            int32
	parameters                      []ASTParameter
	count                           uint32
	droppedParameters               uint32
	size                            SortSize
	flags                           ASTFuncFlags
}
type astRefRecord struct {
	generation, nextFree uint32
	live                 bool
	node                 astNodeRef
	owned                bool
	pending              []astNodeRef
}

const astPageSize = 64

// astNodePage holds each node slot's application record in the same page as
// its node record, indexed by slot, so app reads need neither kindIndex nor a
// second page. app[i] is meaningful only while slot i holds a live
// application; allocateNode clears it when an application takes the slot.
type astNodePage struct {
	wideOperands *[astPageSize][astInlineArgs]astNodeRef
	markOwners   [2]*astMarkOwnerPage
	slots        [astPageSize]astNodeSlot
}

// The hot node and its application operands use a single, pointer-free
// slot. While a slot is free, kindIndex holds the next free node slot.
type astNodeSlot struct {
	node astNodeRecord
	app  astAppRecord
}

// An untouched mark plane costs only the pointer in its node page.
type astMarkOwnerPage [astPageSize]uint64

// The owner budget uses the original 48-byte node record and three child
// references. Keeping the same reservation preserves allocation refusals.
const astNodeBudgetBytes = 48
const astNodePageBytes = uint64(astPageSize) * uint64(astNodeBudgetBytes+unsafe.Offsetof(astAppRecord{}.inlineArgs)+3*unsafe.Sizeof(astNodeRef{}))

type astSortPage [astPageSize]astSortRecord
type astFuncDeclPage [astPageSize]astFuncDeclRecord
type astVarPage [astPageSize]astVarRecord
type astQuantifierPage [astPageSize]astQuantifierRecord
type astParameterPage [astPageSize]astParameterRecord
type astInfoPage [astPageSize]astInfoRecord
type astRefPage [astPageSize]astRefRecord

type astPluginKind uint8

const (
	astBasicPlugin astPluginKind = iota
	astLabelPlugin
	astPatternPlugin
	astModelValuePlugin
	astUserSortPlugin
	astFormatPlugin
	astArithmeticPlugin
	astBitVectorPlugin
	astArrayPlugin
	astSequencePlugin
	astFloatingPointPlugin
	astDatatypePlugin
	astDatalogPlugin
	astPseudoBooleanPlugin
)

// The five real implementations use a cold tagged registry. No per-node
// interface or callback is stored. Plugin backing/cache ownership is explicit.
type astPluginBinding struct {
	kind    astPluginKind
	present bool
}
type astBasicPluginState struct {
	boolSort, proofSort astNodeRef
	declarations        [ASTLastBasicPR]astNodeRef
	eq, oeq, ite        []astNodeRef
	proofCaches         [ASTLastBasicPR][]astNodeRef
}
type astBuiltinPluginState struct {
	labelPos, labelNeg, labelLit usymbol.Symbol
	userNames                    []usymbol.Symbol
	userTable                    usymbol.DictionaryInt32
}

// astOwnerConfined keeps the manager's lock call sites as no-ops. An ASTManager
// is confined to one goroutine; cancellation only touches its atomic Reslimit.
type astOwnerConfined struct{}

func (astOwnerConfined) Lock()   {}
func (astOwnerConfined) Unlock() {}

type ASTManager struct {
	recursiveDefinitions    bool // see NoteRecursiveFunctionDefinitions
	declarationPluginsReady bool
	// Hot: read by lock and by every accessor. Keep these on one cache line.
	Self                                         *ASTManager
	origin                                       uint64
	nodes                                        []*astNodePage
	pendingDeletions                             []astDeletionContinuation
	nextNode                                     uint32
	traceExecuting, formatExecuting              bool
	Closed, sourceDTStarted, constructorComplete bool

	exprSubstitutions          map[arena.SmallBytesRef]*astExprSubstState
	lastExprSubstitution       *astExprSubstState
	scopedExprSubstitutions    map[arena.SmallBytesRef]*astScopedExprSubstState
	someValueProc              SomeValueProc
	ArrayCardinality           *astArrayCardinalityFrame
	arrayCardinalityInvocation uint64
	exprVisitHistory           *astExprPendingMark
	exprVisit                  astExprVisitFrame // actual charged lexical traversal storage

	traceAcquisitionHistory                                                                  *astTraceAcquisition
	traceAcquisitions, traceAcquisitionExecuting                                             *astTraceAcquisition
	traceAcquisitionSerial                                                                   uint64
	rationalTraceSerial                                                                      uint64
	mu                                                                                       astOwnerConfined
	BudgetField                                                                              *arena.Budget
	Symbols                                                                                  *usymbol.Manager
	recFun                                                                                   usymbol.Symbol
	numerals                                                                                 *unumeral.RationalService
	params                                                                                   *uparams.ParamsContext
	globals                                                                                  *uparams.GlobalParamsService
	families                                                                                 *FamilyManager
	Limit                                                                                    control.Reslimit // source inline member, charged in the ASTManager header
	allocator                                                                                *arena.SmallBytes
	Format                                                                                   *ASTManager
	proofMode                                                                                ASTProofMode
	coercions, closing                                                                       bool
	sourceDTCompleted, sourceClosing, traceEOFReached                                        bool
	sourceDTCause, errorOwnClose                                                             error
	constructorBodyCause, constructorUnwindCause, constructorOwnCause                        error
	constructorMemberStage                                                                   uint8
	constructorMembers                                                                       uint32
	constructorPendingFormat                                                                 *ASTManager
	constructorPendingFile                                                                   *astTraceFile
	TraceFile                                                                                *astTraceFile
	TraceStream                                                                              *utext.NumericTextStream
	traceTags                                                                                *udiag.TraceTags
	traceOwner                                                                               bool
	formatTraceLive                                                                          bool
	LowLevel                                                                                 astLowLevelFrame
	DebugRefCount                                                                            bool
	DebugFreeIndices                                                                         map[uint32]struct{}
	debugFreeComplete                                                                        bool
	ExprIDs, declIDs                                                                         idgen.Generator
	sorts                                                                                    []*astSortPage
	decls                                                                                    []*astFuncDeclPage
	vars                                                                                     []*astVarPage
	quantifiers                                                                              []*astQuantifierPage
	Parameters                                                                               []*astParameterPage
	infos                                                                                    []*astInfoPage
	references                                                                               []*astRefPage
	nextKind, freeKind                                                                       [5]uint32
	freeNode, nextParameter, freeParameter, nextInfo, freeInfo, nextReference, freeReference uint32
	liveNodes, liveParameters, liveInfos, liveReferences                                     uint32
	pageBytes, directoryBytes, ownerBytes                                                    uint64
	table                                                                                    astCanonicalTable
	plugins                                                                                  astPluginVector
	builtinPluginTraceLive                                                                   [5]bool
	basic                                                                                    astBasicPluginState
	builtin                                                                                  astBuiltinPluginState
	boolSort, proofSort, trueApp, falseApp, undefProof                                       astNodeRef
	deletionHead, deletionCurrent                                                            astNodeRef
	pendingDeletionHead, pendingDeletionCurrent                                              astNodeRef
	// Source fresh_id and lexical func_decl_info storage; included in owner header.
	freshID                                        uint32
	freshInfo                                      astInfoRecord
	freshInfoEpoch                                 uint32
	freshInfoActive                                bool
	floatingPointPlugin, floatingPointPluginFailed *astFloatingPointPluginOwner
	auxiliaryPlugins                               *astAuxiliaryPluginOwner
	datatypePlugin, datatypePluginFailed           *astDatatypePluginOwner
	sequencePlugin, sequencePluginFailed           *astSequencePluginOwner
	arrayPlugin                                    *astArrayPluginOwner
	arrayPluginFailed                              *astArrayPluginOwner
	bitVectorPlugin                                *astBitVectorPluginOwner
	bitVectorPluginFailed                          *astBitVectorPluginOwner
	arithmeticPlugin                               *astArithmeticPluginOwner
	arithmeticPluginFailed                         *astArithmeticPluginOwner
	formatPlugin                                   *astFormatPluginOwner
	formatPluginFailed                             *astFormatPluginOwner
	bitVectorUtilityParameters                     astBVUtilityParameters
	formatLexical                                  astFormatLexical
	appCoercion                                    astAppCoercionFrame
	formatFrames                                   *astFormatFlatFrame
	formatFrameSerial                              uint64
	// formatFlatDense is a slot-indexed flatten cache lent to one active
	// formatFlat frame at a time (formatFlatDenseOwner); entries carry the
	// owning frame's invocation, so a later frame never reads stale ones.
	formatFlatDense      []astFormatFlatDenseEntry
	formatFlatDenseOwner *astFormatFlatFrame
	// formatGroupChoice[slot] is the generation of the choice node FormatGroup
	// built (or found) at that slot: choice(flat(x), x), whose flattening is
	// its first argument. Zero (or another generation) means no such mark.
	formatGroupChoice []uint32
	ppFrames          *astFormatPPFrame
	ppFrameSerial     uint64
	// Actual dependency DAG owner is bound eagerly to this manager and allocator.
	dependencies astDependencyManager
	// smt2SortInfoTable is the command context's pp_env sort printer while
	// it formats output; nil selects the base SMT2 environment.
	smt2SortInfoTable SMT2SortInfoTable
	// seqPrepared caches a completed prepareSequencePlugin.
	seqPrepared astSequencePrepared
	// utilFamilies caches ArithmeticFamilyID and BitVectorUtilityFamilyID.
	utilFamilies astUtilityFamilies
	// traceAcquisitionFree holds retired uncaught trace acquisition frames.
	traceAcquisitionFree []*astTraceAcquisition
}

func astNextOrigin() (uint64, error) {
	for {
		old := astIdentity.Load()
		if old == math.MaxUint64 {
			return 0, arena.ErrBounds
		}
		if astIdentity.CompareAndSwap(old, old+1) {
			return old + 1, nil
		}
	}
}
func astDirectoryGrowth(old, needed uint32, width uint64) (uint32, error) {
	n := uint64(old)
	if n == 0 {
		n = 2
	}
	for n < uint64(needed) {
		n = (3*n + 1) / 2
		if n > math.MaxUint32 {
			return 0, arena.ErrBounds
		}
	}
	if n > uint64(^uint(0)>>1)/width {
		return 0, arena.ErrBounds
	}
	return uint32(n), nil
}
func (m *ASTManager) nodeSlotAt(slot uint32) *astNodeSlot {
	return &m.nodes[(slot-1)/astPageSize].slots[(slot-1)%astPageSize]
}
func (m *ASTManager) nodeAt(slot uint32) *astNodeRecord {
	return &m.nodeSlotAt(slot).node
}
func (m *ASTManager) sortAt(slot uint32) *astSortRecord {
	index := m.nodeAt(slot).kindIndex
	return &m.sorts[(index-1)/astPageSize][(index-1)%astPageSize]
}
func (m *ASTManager) declAt(slot uint32) *astFuncDeclRecord {
	index := m.nodeAt(slot).kindIndex
	return &m.decls[(index-1)/astPageSize][(index-1)%astPageSize]
}
func (m *ASTManager) appAt(slot uint32) *astAppRecord {
	return &m.nodeSlotAt(slot).app
}
func (m *ASTManager) varAt(slot uint32) *astVarRecord {
	index := m.nodeAt(slot).kindIndex
	return &m.vars[(index-1)/astPageSize][(index-1)%astPageSize]
}
func (m *ASTManager) quantifierAt(slot uint32) *astQuantifierRecord {
	index := m.nodeAt(slot).kindIndex
	return &m.quantifiers[(index-1)/astPageSize][(index-1)%astPageSize]
}
func (m *ASTManager) parameterAt(slot uint32) *astParameterRecord {
	return &m.Parameters[(slot-1)/astPageSize][(slot-1)%astPageSize]
}
func (m *ASTManager) infoAt(slot uint32) *astInfoRecord {
	return &m.infos[(slot-1)/astPageSize][(slot-1)%astPageSize]
}
func (m *ASTManager) referenceAt(slot uint32) *astRefRecord {
	return &m.references[(slot-1)/astPageSize][(slot-1)%astPageSize]
}
func (m *ASTManager) validNode(r astNodeRef) error {
	if r.slot == 0 || r.slot >= m.nextNode {
		return ErrASTHandle
	}
	n := m.nodeAt(r.slot)
	if !n.live || n.generation != r.generation {
		return ErrASTHandle
	}
	return nil
}
func (m *ASTManager) internal(h ASTHandle) (astNodeRef, error) {
	r := astNodeRef{h.slot, h.generation}
	if h.origin != m.origin {
		return astNodeRef{}, ErrASTHandle
	}
	return r, m.validNode(r)
}
func (m *ASTManager) external(r astNodeRef) ASTHandle {
	if r.slot == 0 {
		return ASTHandle{}
	}
	return ASTHandle{m.origin, r.slot, r.generation}
}
func (m *ASTManager) lock() error {
	if m == nil || m.Self != m {
		return ErrASTHandle
	}
	if m.traceExecuting || m.formatExecuting {
		return ErrASTPending
	}
	m.mu.Lock()
	if m.Closed {
		m.mu.Unlock()
		return arena.ErrClosed
	}
	if m.sourceDTStarted {
		m.mu.Unlock()
		return ErrASTPending
	}
	if !m.constructorComplete {
		m.mu.Unlock()
		return ErrASTDomain
	}
	if len(m.pendingDeletions) != 0 {
		if err := m.cleanupNodeDeletions(); err != nil {
			m.mu.Unlock()
			return err
		}
	}
	return nil
}
func (m *ASTManager) reservePage(bytes uint64) error {
	if e := m.BudgetField.Reserve(bytes); e != nil {
		return e
	}
	m.pageBytes += bytes
	return nil
}
func (m *ASTManager) prepareDirectory(old, needed int) (int, error) {
	if old >= needed {
		return old, nil
	}
	width := uint64(reflect.TypeOf((*astNodePage)(nil)).Size())
	n, e := astDirectoryGrowth(uint32(old), uint32(needed), width)
	if e != nil {
		return 0, e
	}
	if e = m.BudgetField.Reserve(uint64(n) * width); e != nil {
		return 0, e
	}
	return int(n), nil
}
func (m *ASTManager) publishDirectory(old, next int) {
	width := uint64(reflect.TypeOf((*astNodePage)(nil)).Size())
	m.BudgetField.Release(uint64(old) * width)
	m.directoryBytes += uint64(next-old) * width
}
