package ast

// Exact source AST array hash and compare_nodes/get_node_hash branches.

import (
	"bytes"
	"encoding/binary"

	"github.com/glycerine/g3/pkg/arena"
	uhash "github.com/glycerine/g3/pkg/util/hash"
)

func astHashArray(n, init uint32, hash func(uint32) uint32) uint32 {
	switch n {
	case 0:
		return init
	case 1:
		return uhash.Combine(hash(0), init)
	case 2:
		return appPairHash(init, hash(0), hash(1))
	case 3:
		return appTripleHash(init, hash(0), hash(1), hash(2))
	}
	a, b, c := uint32(0x9e3779b9), uint32(0x9e3779b9), init
	for n >= 3 {
		n--
		a += hash(n)
		n--
		b += hash(n)
		n--
		c += hash(n)
		a, b, c = uhash.MixState(a, b, c)
	}
	if n == 2 {
		b += hash(1)
	}
	if n >= 1 {
		c += hash(0)
	}
	return uhash.Mix(a, b, c)
}
func (m *ASTManager) hashPayload(p arena.SmallBytesRef, count, init uint32) (uint32, error) {
	var err error
	if data, e := m.allocator.View(p); e == nil && uint64(count)*uint64(astRefBytes) <= uint64(len(data)) {
		// One payload validation; each element is still a validated node.
		result := astHashArray(count, init, func(i uint32) uint32 {
			o := i * astRefBytes
			r := astNodeRef{binary.LittleEndian.Uint32(data[o:]), binary.LittleEndian.Uint32(data[o+4:])}
			if e := m.validNode(r); e != nil {
				if err == nil {
					err = e
				}
				return 0
			}
			return m.nodeAt(r.slot).hash
		})
		return result, err
	}
	result := astHashArray(count, init, func(i uint32) uint32 {
		r, e := m.readInternal(p, i)
		if e == nil {
			e = m.validNode(r)
		}
		if e != nil {
			if err == nil {
				err = e
			}
			return 0
		}
		return m.nodeAt(r.slot).hash
	})
	return result, err
}

// variableHash uses the hash already stored on the variable's live sort.
func (m *ASTManager) variableHash(index uint32, sort astNodeRef) uint32 {
	return uhash.Combine(index, m.nodeAt(sort.slot).hash)
}

func (m *ASTManager) nodeHash(r astNodeRef) (uint32, error) {
	if e := m.validNode(r); e != nil {
		return 0, e
	}
	switch m.nodeAt(r.slot).kind {
	case ASTSort:
		v := m.sortAt(r.slot)
		h, e := m.Symbols.Hash(v.name)
		if e != nil {
			return 0, e
		}
		if v.info == (ASTSortInfo{}) {
			return h, nil
		}
		ih, e := m.infoHash(v.info.slot, v.info.generation)
		return uhash.Combine(h, ih), e
	case ASTFuncDecl:
		v := m.declAt(r.slot)
		h, e := m.Symbols.Hash(v.name)
		if e != nil {
			return 0, e
		}
		if v.info != (ASTFuncDeclInfo{}) {
			ih, e := m.infoHash(v.info.slot, v.info.generation)
			if e != nil {
				return 0, e
			}
			h = uhash.Combine(h, ih)
		}
		return m.hashPayload(v.domain, v.arity, h)
	case ASTApp:
		v := m.appAt(r.slot)
		if e := m.validNode(v.decl); e != nil {
			return 0, e
		}
		if v.count <= astInlineArgs && !ASTSourceDebug {
			// hashPayload over the record's copy of all the arguments.
			var err error
			result := astHashArray(v.count, m.nodeAt(v.decl.slot).hash, func(i uint32) uint32 {
				r := m.inlineOperand(v, i)
				if e := m.validNode(r); e != nil {
					if err == nil {
						err = e
					}
					return 0
				}
				return m.nodeAt(r.slot).hash
			})
			return result, err
		}
		return m.hashPayload(v.args, v.count, m.nodeAt(v.decl.slot).hash)
	case ASTVar:
		v := m.varAt(r.slot)
		if e := m.validNode(v.sort); e != nil {
			return 0, e
		}
		return m.variableHash(v.index, v.sort), nil
	case ASTQuantifier:
		v := m.quantifierAt(r.slot)
		init := uint32(19)
		if v.forall {
			init = 31
		}
		a, e := m.hashPayload(v.sorts, v.count, init)
		if e != nil {
			return 0, e
		}
		if e = m.validNode(v.body); e != nil {
			return 0, e
		}
		return uhash.Mix(a, v.patternCount, m.nodeAt(v.body.slot).hash), nil
	}
	return 0, ErrASTDomain
}
func (m *ASTManager) equalPayload(a, b arena.SmallBytesRef, n uint32) (bool, error) {
	if n != 0 {
		x, ex := m.allocator.View(a)
		y, ey := m.allocator.View(b)
		if w := uint64(n) * uint64(astRefBytes); ex == nil && ey == nil && w <= uint64(len(x)) && w <= uint64(len(y)) {
			return bytes.Equal(x[:w], y[:w]), nil
		}
	}
	for i := uint32(0); i < n; i++ {
		x, e := m.readInternal(a, i)
		if e != nil {
			return false, e
		}
		y, e := m.readInternal(b, i)
		if e != nil {
			return false, e
		}
		if x != y {
			return false, nil
		}
	}
	return true, nil
}
func (m *ASTManager) compareNodes(a, b astNodeRef) (bool, error) {
	if e := m.validNode(a); e != nil {
		return false, e
	}
	if e := m.validNode(b); e != nil {
		return false, e
	}
	kind := m.nodeAt(a.slot).kind
	if kind != m.nodeAt(b.slot).kind {
		return false, nil
	}
	switch kind {
	case ASTSort:
		x, y := m.sortAt(a.slot), m.sortAt(b.slot)
		if (x.info == ASTSortInfo{}) != (y.info == ASTSortInfo{}) {
			return false, nil
		}
		if x.info != (ASTSortInfo{}) {
			eq, e := m.infoEqual(x.info.slot, x.info.generation, y.info.slot, y.info.generation)
			if e != nil || !eq {
				return eq, e
			}
		}
		return x.name == y.name, nil
	case ASTFuncDecl:
		x, y := m.declAt(a.slot), m.declAt(b.slot)
		if (x.info == ASTFuncDeclInfo{}) != (y.info == ASTFuncDeclInfo{}) {
			return false, nil
		}
		if x.info != (ASTFuncDeclInfo{}) {
			eq, e := m.infoEqual(x.info.slot, x.info.generation, y.info.slot, y.info.generation)
			if e != nil || !eq {
				return eq, e
			}
		}
		if x.name != y.name || x.arity != y.arity || x.rangeSort != y.rangeSort {
			return false, nil
		}
		return m.equalPayload(x.domain, y.domain, x.arity)
	case ASTApp:
		x, y := m.appAt(a.slot), m.appAt(b.slot)
		if x.decl != y.decl || x.count != y.count {
			return false, nil
		}
		if x.count <= astInlineArgs && !ASTSourceDebug {
			if x.count == 0 {
				return true, nil
			}
			if x.generations != 0 && y.generations != 0 {
				if x.generations != y.generations {
					return false, nil
				}
				switch x.count {
				case 1:
					return x.inlineArgs[0] == y.inlineArgs[0], nil
				case 2:
					return *(*[2]uint32)(x.inlineArgs[:]) == *(*[2]uint32)(y.inlineArgs[:]), nil
				case 3:
					return *(*[3]uint32)(x.inlineArgs[:]) == *(*[3]uint32)(y.inlineArgs[:]), nil
				case 4:
					return x.inlineArgs == y.inlineArgs, nil
				}
			}
			for i := uint32(0); i < x.count; i++ {
				if m.inlineOperand(x, i) != m.inlineOperand(y, i) {
					return false, nil
				}
			}
			return true, nil
		}
		return m.equalPayload(x.args, y.args, x.count)
	case ASTVar:
		x, y := m.varAt(a.slot), m.varAt(b.slot)
		return x.index == y.index && x.sort == y.sort, nil
	case ASTQuantifier:
		x, y := m.quantifierAt(a.slot), m.quantifierAt(b.slot)
		if x.forall != y.forall || x.count != y.count {
			return false, nil
		}
		same, e := m.equalPayload(x.sorts, y.sorts, x.count)
		if e != nil || !same {
			return same, e
		}
		for i := uint32(0); i < x.count; i++ {
			s, e := m.readSymbol(x.names, i)
			if e != nil {
				return false, e
			}
			t, e := m.readSymbol(y.names, i)
			if e != nil {
				return false, e
			}
			if s != t {
				return false, nil
			}
		}
		if x.body != y.body || x.weight != y.weight || x.patternCount != y.patternCount {
			return false, nil
		}
		same, e = m.equalPayload(x.patterns, y.patterns, x.patternCount)
		if e != nil || !same {
			return same, e
		}
		if x.noPatternCount != y.noPatternCount {
			return false, nil
		}
		return m.equalPayload(x.noPatterns, y.noPatterns, x.noPatternCount)
	}
	return false, ErrASTDomain
}
func astInlineHash(n, init uint32, v *[astInlineArgs]uint32) uint32 {
	switch n {
	case 0:
		return init
	case 1:
		return uhash.Combine(v[0], init)
	case 2:
		return appPairHash(init, v[0], v[1])
	case 3:
		return appTripleHash(init, v[0], v[1], v[2])
	default:
		return astHashArray(n, init, func(i uint32) uint32 { return v[i] })
	}
}

func appPairHash(seed, a, b uint32) uint32 { return uhash.Combine(uhash.Combine(a, b), seed) }
func appTripleHash(seed, a, b, c uint32) uint32 {
	return uhash.Combine(uhash.Combine(a, b), uhash.Combine(c, seed))
}
