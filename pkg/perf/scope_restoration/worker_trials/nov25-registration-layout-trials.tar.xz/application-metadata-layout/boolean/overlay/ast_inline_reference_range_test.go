package ast

import "testing"

// Exercise public construction, lookup and release once a live child's
// generation exceeds the eight bits used by one of the layouts.
func TestASTInlineOperandsWithReusedChild(t *testing.T) {
	m := astTestManager(t)
	sort, err := m.MkBoolSort()
	astTestMust(t, err)
	decl, err := m.MkFuncDecl(astTestSymbol(t, m, "inline-recycled-child"), []ASTHandle{sort, sort, sort, sort}, sort, ASTFuncDeclInfo{})
	astTestMust(t, err)
	astTestPin(t, m, decl)
	a, err := m.MkVar(5, sort)
	astTestMust(t, err)
	astTestPin(t, m, a)
	var b ASTHandle
	for i := 0; i < 4300; i++ {
		b, err = m.MkVar(uint32(i+18), sort)
		astTestMust(t, err)
		astTestMust(t, m.IncRef(b))
		if i < 4299 {
			astTestMust(t, m.DecRef(b))
		}
	}
	if b.Generation() <= 4095 {
		t.Fatalf("expected a frequently recycled slot, got generation %d", b.Generation())
	}
	for changed := 0; changed < 4; changed++ {
		args := []ASTHandle{a, a, a, a}
		args[changed] = b
		h, e := m.MkApp(decl, args)
		astTestMust(t, e)
		astTestMust(t, m.IncRef(h))
		again, e := m.MkApp(decl, args)
		astTestMust(t, e)
		if h != again {
			t.Fatal("canonical miss", changed)
		}
		different, e := m.MkApp(decl, []ASTHandle{a, a, a, a})
		astTestMust(t, e)
		if h == different {
			t.Fatal("canonical alias", changed)
		}
		for i, want := range args {
			got, e := m.GetArg(h, uint32(i))
			astTestMust(t, e)
			if got != want {
				t.Fatalf("operand %d got %+v want %+v", i, got, want)
			}
		}
		hash, e := m.nodeHash(astNodeRef{h.slot, h.generation})
		astTestMust(t, e)
		if hash != m.nodeAt(h.slot).hash {
			t.Fatal("hash changed", changed)
		}
		astTestMust(t, m.DecRef(h))
	}
	astTestMust(t, m.DecRef(b))
}
