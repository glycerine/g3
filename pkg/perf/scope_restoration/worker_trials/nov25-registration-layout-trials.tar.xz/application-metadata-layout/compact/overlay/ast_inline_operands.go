package ast

// The slot's overflow storage stays in the owning manager. It holds the
// original references across allocation, hashing, equality and destruction.
func (m *ASTManager) wideOperandRow(slot uint32) *[astInlineArgs]astNodeRef {
	page := m.nodes[(slot-1)/astPageSize]
	i := (slot - 1) % astPageSize
	if page.wideOperands == nil {
		page.wideOperands = new([astPageSize][astInlineArgs]astNodeRef)
	}
	return &page.wideOperands[i]
}

const inlineSlotBits = 20

func (m *ASTManager) inlineOperand(a *astAppRecord, i uint32) astNodeRef {
	if a.inlineArgs[0] != 0 {
		return astNodeRef{a.inlineArgs[i] & ((1 << inlineSlotBits) - 1), a.inlineArgs[i] >> inlineSlotBits}
	}
	slot := a.inlineArgs[1]
	return m.nodes[(slot-1)/astPageSize].wideOperands[(slot-1)%astPageSize][i]
}
func (m *ASTManager) setInlineOperand(slot uint32, a *astAppRecord, i uint32, r astNodeRef) {
	if a.inlineArgs[0] == 0 && a.inlineArgs[1] != 0 {
		m.wideOperandRow(slot)[i] = r
		return
	}
	if r.slot > 0 && r.slot < (1<<inlineSlotBits) && r.generation > 0 && r.generation < (1<<(32-inlineSlotBits)) {
		a.inlineArgs[i] = r.slot | r.generation<<inlineSlotBits
		return
	}
	row := m.wideOperandRow(slot)
	for j := uint32(0); j < i; j++ {
		row[j] = m.inlineOperand(a, j)
	}
	row[i] = r
	a.inlineArgs = [astInlineArgs]uint32{0, slot}

}
