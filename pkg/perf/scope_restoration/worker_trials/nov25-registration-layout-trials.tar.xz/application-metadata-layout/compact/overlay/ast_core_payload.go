package ast

// Source: src/ast/ast.cpp:349-355,2064-2135; src/ast/ast.h:665-683.
// Scalar payload encoding. No unsafe or borrowed slice escapes.

import (
	"encoding/binary"
	"math"

	"github.com/glycerine/g3/pkg/arena"
	usymbol "github.com/glycerine/g3/pkg/util/symbol"
)

const astRefBytes uint32 = 8
const astSymbolBytes uint32 = 24

func astPayloadOffset(index, stride uint32) (uint32, error) {
	n := uint64(index) * uint64(stride)
	if n+uint64(stride) > math.MaxUint32 || n+uint64(stride) > uint64(^uint(0)>>1) {
		return 0, arena.ErrBounds
	}
	return uint32(n), nil
}
func astPayloadBytes(count, stride uint32) (uint32, error) {
	n := uint64(count) * uint64(stride)
	if n > math.MaxUint32 || n > uint64(^uint(0)>>1) {
		return 0, arena.ErrBounds
	}
	return uint32(n), nil
}
func (m *ASTManager) writeWord(p arena.SmallBytesRef, offset, value uint32) error {
	if uint64(offset)+4 > math.MaxUint32 {
		return arena.ErrBounds
	}
	return m.allocator.WriteUint32LE(p, offset, value)
}
func (m *ASTManager) readWord(p arena.SmallBytesRef, offset uint32) (uint32, error) {
	if uint64(offset)+4 > math.MaxUint32 {
		return 0, arena.ErrBounds
	}
	return m.allocator.ReadUint32LE(p, offset)
}
func (m *ASTManager) writeInternal(p arena.SmallBytesRef, index uint32, r astNodeRef) error {
	offset, e := astPayloadOffset(index, astRefBytes)
	if e != nil {
		return e
	}
	if uint64(offset)+8 > math.MaxUint32 {
		return arena.ErrBounds
	}
	return m.allocator.WriteUint32Pair(p, offset, r.slot, r.generation)
}
func (m *ASTManager) readInternal(p arena.SmallBytesRef, index uint32) (astNodeRef, error) {
	offset, e := astPayloadOffset(index, astRefBytes)
	if e != nil {
		return astNodeRef{}, e
	}
	if uint64(offset)+8 > math.MaxUint32 {
		return astNodeRef{}, arena.ErrBounds
	}
	slot, generation, e := m.allocator.ReadUint32Pair(p, offset)
	if e != nil {
		return astNodeRef{}, e
	}
	return astNodeRef{slot, generation}, nil
}

// readInternalAll appends readInternal(p, 0..count-1) to dst with one
// payload validation. It fails as the first failing readInternal would.
func (m *ASTManager) readInternalAll(p arena.SmallBytesRef, count uint32, dst []astNodeRef) ([]astNodeRef, error) {
	if count == 0 {
		return dst, nil
	}
	data, e := m.allocator.View(p)
	if e != nil {
		return dst, e
	}
	if uint64(count)*uint64(astRefBytes) > uint64(len(data)) {
		// Report the exact error of the first failing index.
		for j := uint32(0); j < count; j++ {
			r, e := m.readInternal(p, j)
			if e != nil {
				return dst, e
			}
			dst = append(dst, r)
		}
		return dst, nil
	}
	for j := uint32(0); j < count; j++ {
		o := j * astRefBytes
		dst = append(dst, astNodeRef{binary.LittleEndian.Uint32(data[o:]), binary.LittleEndian.Uint32(data[o+4:])})
	}
	return dst, nil
}

// appArg is readInternal(a.args, i) for the record a of a live app; the
// first two arguments come from the copy kept in the record. Debug builds
// keep the checked payload read.
func (m *ASTManager) appArg(a *astAppRecord, i uint32) (astNodeRef, error) {
	if i < astInlineArgs && i < a.count && !ASTSourceDebug {
		return m.inlineOperand(a, i), nil
	}
	return m.readInternal(a.args, i)
}

// declDomain is readInternal(d.domain, i) for the record d of a live
// declaration with i < d.arity, from the record's copy in normal builds.
func (m *ASTManager) declDomain(d *astFuncDeclRecord, i uint32) (astNodeRef, error) {
	if i < uint32(len(d.domainRefs)) && !ASTSourceDebug {
		return d.domainRefs[i], nil
	}
	return m.readInternal(d.domain, i)
}

// appArgPair is readInternalPair(a.args) for the record a of a live app.
func (m *ASTManager) appArgPair(a *astAppRecord) (astNodeRef, astNodeRef, error) {
	if a.count >= 2 && !ASTSourceDebug {
		return m.inlineOperand(a, 0), m.inlineOperand(a, 1), nil
	}
	return m.readInternalPair(a.args)
}

// appArgsAll is readInternalAll(a.args, a.count, dst) for the record a of
// a live app.
func (m *ASTManager) appArgsAll(a *astAppRecord, dst []astNodeRef) ([]astNodeRef, error) {
	if a.count <= astInlineArgs && !ASTSourceDebug {
		for i := uint32(0); i < a.count; i++ {
			dst = append(dst, m.inlineOperand(a, i))
		}
		return dst, nil
	}
	return m.readInternalAll(a.args, a.count, dst)
}

// readInternalPair is readInternal at indexes 0 and 1 with one payload
// validation; p must hold at least two references.
func (m *ASTManager) readInternalPair(p arena.SmallBytesRef) (astNodeRef, astNodeRef, error) {
	s0, g0, s1, g1, e := m.allocator.ReadUint32Quad(p, 0)
	if e != nil {
		return astNodeRef{}, astNodeRef{}, e
	}
	return astNodeRef{s0, g0}, astNodeRef{s1, g1}, nil
}
func (m *ASTManager) writeSymbol(p arena.SmallBytesRef, index uint32, s usymbol.Symbol) error {
	// Symbol is local to package g3. Its scalar fields are encoded by name;
	// opaque mpnum numerals are never encoded through this representation.
	off, e := astPayloadOffset(index, astSymbolBytes)
	if e != nil {
		return e
	}
	if _, e = m.Symbols.FromToken(s.Token()); e != nil {
		return e
	}
	data, e := m.allocator.Borrow(p)
	if e != nil {
		return e
	}
	if uint64(off) > uint64(len(data)) {
		return arena.ErrBounds
	}
	data = data[off:]
	words := s.SymbolWords()
	for _, word := range [6]uint32{words[0], words[1], words[2], words[3], words[4], 0} {
		if len(data) < 4 {
			return arena.ErrBounds
		}
		binary.LittleEndian.PutUint32(data, word)
		data = data[4:]
	}
	return nil
}
func (m *ASTManager) readSymbol(p arena.SmallBytesRef, index uint32) (usymbol.Symbol, error) {
	offset, e := astPayloadOffset(index, astSymbolBytes)
	if e != nil {
		return usymbol.Symbol{}, e
	}
	var v [5]uint32
	if e := m.allocator.ReadUint32LEs(p, offset, v[:]); e != nil {
		return usymbol.Symbol{}, e
	}
	return m.Symbols.DecodeSymbolWords(v)
}
func (m *ASTManager) newASTPayload(hs []ASTHandle) (arena.SmallBytesRef, error) {
	if uint64(len(hs)) > math.MaxUint32 {
		return arena.SmallBytesRef{}, arena.ErrBounds
	}
	return m.newASTPayloadArguments(AppArguments{slice: hs, count: uint32(len(hs))}, nil)
}
func (m *ASTManager) newASTPayloadArguments(hs AppArguments, inline *[astInlineArgs]astNodeRef) (arena.SmallBytesRef, error) {
	if hs.count == 0 {
		return arena.SmallBytesRef{}, nil
	}
	if inline != nil && (hs.count <= 3 || (!astValidateHandles && hs.count == 4 && !m.BudgetField.InjectionArmed() && m.TraceStream == nil)) && !ASTSourceDebug {
		// The record's copy holds every argument: normal builds keep no
		// payload for it (appArg, hashing, comparison and the printers
		// read the copy; the null payload frees as a no-op).
		for i := uint32(0); i < hs.count; i++ {
			h, e := hs.at(i)
			var r astNodeRef
			if e == nil {
				r, e = m.internal(h)
			}
			if e != nil {
				return arena.SmallBytesRef{}, e
			}
			inline[i] = r
		}
		return arena.SmallBytesRef{}, nil
	}
	n, e := astPayloadBytes(hs.count, astRefBytes)
	if e != nil {
		return arena.SmallBytesRef{}, e
	}
	p, e := m.allocator.Allocate(n)
	if e != nil {
		return p, e
	}
	// The fresh block is n bytes; write the references in place with one
	// lookup (debug builds keep writeInternal's per-element checks).
	var data []byte
	if !ASTSourceDebug {
		if b, be := m.allocator.Borrow(p); be == nil && uint64(len(b)) == uint64(n) {
			data = b
		}
	}
	for i := uint32(0); i < hs.count; i++ {
		h, e := hs.at(i)
		var r astNodeRef
		if e == nil {
			r, e = m.internal(h)
		}
		if e == nil {
			if data != nil {
				o := i * astRefBytes
				putASTNodeRef(data[o:], r)
			} else {
				e = m.writeInternal(p, uint32(i), r)
			}
		}
		if e == nil && i < astInlineArgs && inline != nil {
			inline[i] = r
		}
		if e != nil {
			m.allocator.Deallocate(n, p)
			return arena.SmallBytesRef{}, e
		}
	}
	return p, nil
}
func (m *ASTManager) newSymbolPayload(ss []usymbol.Symbol) (arena.SmallBytesRef, error) {
	if len(ss) == 0 {
		return arena.SmallBytesRef{}, nil
	}
	if uint64(len(ss)) > math.MaxUint32 {
		return arena.SmallBytesRef{}, arena.ErrBounds
	}
	n, e := astPayloadBytes(uint32(len(ss)), astSymbolBytes)
	if e != nil {
		return arena.SmallBytesRef{}, e
	}
	p, e := m.allocator.Allocate(n)
	if e != nil {
		return p, e
	}
	for i, s := range ss {
		if _, e = m.Symbols.Hash(s); e == nil {
			e = m.writeSymbol(p, uint32(i), s)
		}
		if e != nil {
			m.allocator.Deallocate(n, p)
			return arena.SmallBytesRef{}, e
		}
	}
	return p, nil
}
func (m *ASTManager) freePayload(p arena.SmallBytesRef, n, stride uint32) error {
	if p.Slot == 0 {
		return nil
	}
	bytes, e := astPayloadBytes(n, stride)
	if e != nil {
		return e
	}
	return m.allocator.Deallocate(bytes, p)
}

func putASTNodeRef(data []byte, r astNodeRef) {
	binary.LittleEndian.PutUint32(data, r.slot)
	binary.LittleEndian.PutUint32(data[4:], r.generation)
}
