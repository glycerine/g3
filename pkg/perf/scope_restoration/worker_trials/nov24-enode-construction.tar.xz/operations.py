"""Compare the creation and deletion of one congruence node in g3 and Z3."""
import argparse
import csv
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess
import sys
import time

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pkg", type=Path, required=True)
    p.add_argument("--go", nargs=2, action="append", required=True, metavar=("LABEL","BINARY"))
    p.add_argument("--native", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--cpu", type=int, required=True)
    p.add_argument("--perf", default=shutil.which("perf"))
    p.add_argument("--rounds", type=int, default=7)
    p.add_argument("--quiet", action="store_true")
    p.add_argument("--candidate-cpu", type=int, action="append", default=[])
    p.add_argument("--arities", type=int,nargs="+",default=[0,1,2,3,4,8,16])
    p.add_argument("--max-attempts", type=int, default=40)
    opt = p.parse_args()
    opt.output = opt.output.resolve()
    sys.path.insert(0, str(opt.pkg / "perf/ivy_apple/holdouts"))
    from rotating_verification import idle, thread_siblings, ticks
    engines = {name:Path(b).resolve(strict=True) for name,b in opt.go}
    engines["native"] = opt.native.resolve(strict=True)
    cpus = [opt.cpu, *thread_siblings(opt.cpu)]
    groups = {c:[c,*thread_siblings(c)] for c in [opt.cpu,*opt.candidate_cpu]}
    observed = set().union(*groups.values())
    opt.output.mkdir(parents=True, exist_ok=False)
    def cpu_time():
        u = resource.getrusage(resource.RUSAGE_CHILDREN)
        return u.ru_utime + u.ru_stime
    def sample(name, arity, n, serial):
        args = ["taskset","-c",str(opt.cpu)]
        counter = opt.output / ("counter-" + str(serial))
        if not opt.quiet:
            args += [opt.perf,"stat","-x,", "-e","instructions:u","-o",counter,"--"]
        args += [engines[name]]
        if name == "native":
            args += [str(arity),str(n)]
        else:
            args += ["-test.run=^$","-test.cpu=1","-test.bench=^BenchmarkSMTEnodeCreation$/^"+str(arity)+"$","-test.benchtime="+str(n)+"x"]
        before = ticks(cpus)
        used = cpu_time()
        start = time.monotonic()
        r = subprocess.run(args, text=True, capture_output=True, check=True, cwd=opt.pkg/"smtcore",
                           env=dict(os.environ, GOMAXPROCS="1",GOGC="100",LC_ALL="C"))
        wall = time.monotonic()-start
        occupancy = (cpu_time()-used)/wall
        after = ticks(cpus)
        sibling = min((idle(before,after,k) for k in cpus[1:]),default=1.)
        if name == "native":
            row = next(csv.DictReader(r.stdout.splitlines()))
            assert (int(row["arity"]),int(row["iterations"])) == (arity,n),r.stdout
            ns, size, allocs = row["ns_per_op"], row["node_bytes"], ""
        else:
            match = re.search(r"^BenchmarkSMTEnodeCreation/\d+\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op",r.stdout,re.M)
            assert match and int(match[1])==n,r.stdout
            _, ns,size,allocs = match.groups()
        ir = ""
        if not opt.quiet:
            ir = next(row[0] for row in csv.reader(counter.read_text().splitlines()) if len(row)>2 and row[2]=="instructions:u")
            assert int(ir)>0
        return [n,ns,size,allocs,ir,occupancy,sibling]
    names = list(engines)
    serial = 0
    with (opt.output/"rows.csv").open("w") as f:
        z=csv.writer(f)
        z.writerow("round arity attempt engine iterations ns_per_op bytes allocs instructions cpu_fraction sibling_idle cpu".split())
        for rr in range(opt.rounds):
            arities=opt.arities
            for arity in arities[rr%len(arities):]+arities[:rr%len(arities)]:
                for attempt in range(1,opt.max_attempts+1):
                    if opt.quiet and opt.candidate_cpu:
                        before = ticks(observed)
                        time.sleep(1)
                        after = ticks(observed)
                        rates = {c:min(idle(before,after,k) for k in group) for c,group in groups.items()}
                        opt.cpu=max(rates,key=rates.get)
                        if rates[opt.cpu]<.95:continue
                        cpus=groups[opt.cpu]
                    accepted=True
                    for name in names[rr%len(names):]+names[:rr%len(names)]:
                        for n in ([1800000] if opt.quiet else [24000,300000] if (rr+arity)%2==0 else [300000,24000]):
                            serial+=1
                            row=sample(name,arity,n,serial)
                            z.writerow([rr+1,arity,attempt,name,*row,opt.cpu]);f.flush()
                            if opt.quiet and min(row[-2:])<.95:
                                accepted=False
                                break
                        if not accepted:break
                    if accepted:break
                    time.sleep(1)
                else:raise RuntimeError(("too few quiet rounds",rr+1,arity))
            print("finished round",rr+1,flush=True)
if __name__=="__main__":main()
