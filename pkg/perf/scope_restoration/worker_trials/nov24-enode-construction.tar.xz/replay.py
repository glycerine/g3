"""Build one of the node-layout experiments inside an existing g3 checkout."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pkg",required=True,type=Path)
    p.add_argument("--output",required=True,type=Path)
    p.add_argument("--variant",choices=["control","packing","header","children","packing+children","packing+header","packing+children+header","release"],default="release")
    p.add_argument("--cpu",required=True,type=int)
    p.add_argument("--native",action="store_true")
    opts=p.parse_args()
    pkg=opts.pkg.resolve(strict=True)
    directory=opts.output.resolve()
    directory.mkdir(parents=True)
    here=Path(__file__).resolve().parent
    patch_sources=directory/"tree"
    patch_sources.mkdir()
    env=dict(os.environ,GOMAXPROCS="1")
    manifest=json.loads((here/"manifest.json").read_text())
    for path in manifest["files"]:
        file=patch_sources/path
        file.parent.mkdir(parents=True,exist_ok=True)
        ref=manifest["baseline"]+":pkg/"+path
        if path in manifest["introduced"]:
            file.write_bytes((here/"creation_benchmark.go.txt").read_bytes())
        else:
            file.write_bytes(subprocess.check_output(["git","-C",pkg,"show",ref]))
    patch=here/"overlays"/(opts.variant+".patch")
    if patch.is_file():
        subprocess.run(["patch","--batch","-p1","-i",patch],cwd=patch_sources,check=True)
    dst=directory/"overlay.json"
    dst.write_text(json.dumps({"Replace":{str(pkg/k):str(patch_sources/k) for k in manifest["files"]}}))
    binary=directory/"smtcore.test"
    subprocess.run(["go","test","-pgo=off","-tags=xtrace_off","-overlay="+str(dst),"-c","-o",binary,"./smtcore"],cwd=pkg,check=True)
    command=["taskset","-c",str(opts.cpu),binary]
    subprocess.run([*command,"-test.run=Enode|Congruence|Equality|MAM|Justification|PopResumes"],cwd=pkg/"smtcore",check=True,env=env)
    subprocess.run([*command,"-test.run=^$","-test.bench=^BenchmarkSMTEnodeCreation$","-test.benchtime=10000x","-test.cpu=1"],cwd=pkg/"smtcore",check=True,env=env)
    if opts.native:
        sys.path.insert(0,str(pkg/"perf/ivy_apple"))
        from native_benchmark import build_native
        native=directory/"native"
        build_native(pkg.parent/"build",native,pkg.parent/"src/test/perf/enode_creation.cpp")
        for arity in [0,1,2,3,4,8,16]:
            subprocess.run(["taskset","-c",str(opts.cpu),native,str(arity),"10000"],check=True)
if __name__=="__main__":main()
