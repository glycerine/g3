# Solver-local expression columns

Commit 6bf88f8c5 stores the variable ID, AST generation, enode pointer and state flags in separate typed regions of a 256-slot page. Each page allocates its cache values on demand. Asserted disjunctions hold their children by slot under a live parent.

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/g3-expression-after --cpu 2 --variant after

Use a fresh output for each variant. The included ordinary and checked tests exercise full-width IDs, cached zero values, arena generation reuse and two independent solver tables. BenchmarkSMTExpressionTablePopulation puts 8192 available slots in each of eight independent solver tables. In Sparse mode it writes one slot in sixteen. Live heap is the difference after two forced collections, excluding the original ASTs. Divide the difference between the two process instruction counts by the iteration difference and reads per iteration. The 48- and 1024-solver measurements retain the full solver fixtures. See the existing BenchmarkSMTScopeRestorationPeakIdle for the corresponding tests.

The release-verifier and release-solver rows use ordinary optimized binaries. Before/after proof and search counters are checked. The 228 compatibility rows compare both streams and exit status. Archived experimental patches reproduce their original baseline. group64 uses an escape for wide variable IDs. bytes9 reads unaligned full-width values.

The matched-state observers count the table byte capacities on the same ten SMT state fields in Go and the in-tree C++ fork. The native totals cover the enode and Boolean vectors, relevance set, cached-generation map and visited set. Go totals cover allocated pages, the page directory, optional cache columns and touched-handle backing. Their allocators account for slack differently. The broader live-heap snapshot CSVs are measurements of Go process HeapAlloc after GC. Raw input files, matched state positions and separate code patches for each observer are included.

Apply the observer-native patch to the repository root of the same revision and build its shell. Apply observer-Go to the pkg directory of f830ebca3 for the baseline. Set STUDY_COLLECT_AT to the position in its CSV. The native shell prints all traversed positions. Run the listed SMT input with -st -smt2 in a fresh process.

The corrected-scope-replay directory verifies the width-2048 selector in all nine variants. The earlier logs ran the population benchmarks and missed that scope row. The corrected observations use three iterations and confirm execution. Use the paired rotation data for comparing timing.
