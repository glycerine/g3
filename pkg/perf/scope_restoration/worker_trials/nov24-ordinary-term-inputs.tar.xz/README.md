# Ordinary term internalization and enode layout trials

The retained production change is c059bebf5. The before revision is 7db84a8c8. Both use the same 208-byte enode. The public constructor and scoped internalizer benchmarks cover different operations. Divide the difference between the high and low process instruction counts by the iteration difference and the reported enodes/op for each rotation. The scope fixture retains every sixteenth node across scopes. The rows include seven rotated observations of each slope. The later public-revisit fixture retains its input between calls. Instructions for an already internalized gate measure the complete public call.

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/g3-terms --cpu 2 --variant after --native

Use a fresh output directory for each variant. The native commands link the in-tree Z3 build. The shell inputs include positive search counters and answers in each solver CSV. Six complete verifications compare exit and both output streams. The 228 compatibility checks include expected counterexamples and parse failures. The earlier refined variants include their measured clause baseline in the patch. The manager and ring variants share declaration data and were evaluated separately from the shipping change.
