"""Replay a binary-clause directory measurement in a fresh source export."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

def main():
    archive = Path(__file__).resolve().parent
    manifest = json.loads((archive / 'manifest.json').read_text())
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pkg', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--cpu', type=int, required=True)
    p.add_argument('--variant', choices=manifest['variants'], default='release')
    p.add_argument('--native', action='store_true')
    args = p.parse_args()
    pkg = args.pkg.resolve(strict=True)
    out = args.output.resolve()
    out.mkdir(parents=True)
    rev = manifest['release'] if args.variant == 'release' else manifest['baseline']
    with subprocess.Popen(['git','-C',pkg.parent,'archive',rev,'pkg'],stdout=subprocess.PIPE) as git:
        with tarfile.open(fileobj=git.stdout, mode='r|') as tar:
            tar.extractall(out, filter='data')
        if git.wait():
            raise RuntimeError('git archive failed')
    tree = out / 'pkg'
    if args.variant != 'release':
        patch = archive / 'patches' / (args.variant + '.patch')
        subprocess.run(['patch', '--batch', '-p1', '-i', patch], cwd=tree, check=True)
    env = dict(os.environ, GOMAXPROCS='1')
    test = out/'smtcore.test'
    subprocess.run(['go','test','-pgo=off','-c','-o',test,'./smtcore'],cwd=tree,env=env,check=True)
    cmd = ['taskset','-c',str(args.cpu),test]
    subprocess.run(cmd+['-test.run=Binary|Learned|Watch|ScopeRestoration|PopResume'],cwd=tree/'smtcore',env=env,check=True)
    subprocess.run(cmd+['-test.run=^$','-test.cpu=1','-test.benchtime=1x','-test.bench=^BenchmarkSMT(BinaryClauseProofMemory|ClauseDirectoryMemory)$'],cwd=tree/'smtcore',env=env,check=True)
    if args.native:
        sys.path.insert(0, str(pkg/'perf/ivy_apple'))
        from native_benchmark import build_native
        binary = out/'native'
        build_native(pkg.parent/'build',binary,pkg.parent/'src/test/perf/binary_clause_directory.cpp')
        for workers in [1,8,32]:
            subprocess.run(['taskset','-c',str(args.cpu),binary,str(workers)],env=env,check=True)

if __name__ == '__main__':
    main()
