# Watch-only binary clauses

The Go fixture preloads the same atoms before measuring each configuration. Each of eight independent internalizers installs 1,024 clauses, followed by a forced collection with all clauses live. Directory tables use 96 atoms. Proof-density tables preload 64 atoms and identical explicit proof ASTs under all densities, including Absent. They turn proof generation off before constructing the solver, and vary which previously built proof handle is published. In that table even-numbered clauses also carry the root flag.

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/binary-baseline --variant packed-control --cpu 2
    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/binary-after --variant release --native --cpu 2

Use a new output directory for each run. The native comparison uses the repository's existing release build. The benchmark verifies exactly two literal watches per installed binary and no allocation in the native small-object allocator. The watch_bytes column includes the header and full allocated data capacity of each watch list. The malloc_bytes column reports the simultaneous glibc allocator delta where supported.

directory/, proofs/, and packed/ contain controlled experiments. release/ gives the measurements on the committed implementation. Verifier rows compare complete GoIvy output and exit status with saved references. The six standalone SMT2 replays also compare search counters. Each of 228 compatibility rows checks both output streams and the expected exit, including specifications whose expected result is a failure. The deliberately failing interrupted-cleanup test is labeled prior-close-retry.log.

live/ contains whole-process Go heap samples after a forced collection at matching search and pop boundaries. Each row records the phase, counts of equality nodes, concrete and binary clauses, heap bytes, objects, allocation traffic, and GC count. The instrumentation uses STUDY_PHASE, STUDY_NODES and STUDY_CLAUSES to reproduce a row in the same verifier or direct replay. Whole-process memory includes the frontend and the rest of the solver. Allocator accounting in Go and glibc has different boundaries.
