# Scope rollback and deletion of graph nodes

The before release is 5ea5bf703. c8bdbb2f4 restores parent occurrences in original order on refusal. 1911b04a8 also handles later borrowed applications in the declaration and matching indexes. Each release has focused test outputs and a 228-case verifier compatibility table. Logs from earlier failing controls are included. Every scoped benchmark constructs distinct binary applications and checks that exactly one in sixteen nodes survives the pop. At each width the high and low iteration counts share the same setup. Divide their difference in retired process instructions by the iteration difference and the enodes/op value to reproduce the per-enode estimates.

The benchmark sources are smtcore/smt_enode_scope_batch_benchmark_test.go and ../src/test/perf/enode_scope_batch.cpp. The release regressions are smtcore/smt_enode_deletion_retry_test.go and smtcore/smt_borrowed_declaration_test.go. Experimental source variants are patches relative to 5ea5bf703. The before patch adds the regression fixture; two tests intentionally fail on this version. On a separate extracted tree the command to try a variation with the scope benchmark is:

    git -C /path/to/g3 archive 5ea5bf703 pkg | tar -x -C /tmp/empty-dir
    cd /tmp/empty-dir/pkg
    patch --batch --fuzz=0 -p1 < /path/to/extracted/patches/rollback.patch
    go test ./smtcore -run '^$' -bench '^BenchmarkSMTEnodeScopeBatch$' -benchtime=20x
