"""Replay an auxiliary/learned clause layout using a temporary source export."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

def main():
    records = Path(__file__).resolve().parent
    versions = json.loads((records / "variants.json").read_text())
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pkg",required=True,type=Path)
    p.add_argument("--output",required=True,type=Path)
    p.add_argument("--variant",default="after",choices=sorted(versions))
    p.add_argument("--cpu",required=True,type=int)
    p.add_argument("--native",action="store_true")
    p.add_argument("--state",choices=["miss1","miss3","miss6","core1","core3","core6"])
    a = p.parse_args()
    root = a.pkg.resolve(strict=True)
    out = a.output.resolve()
    out.mkdir(parents=True)
    version = versions[a.variant]
    env = dict(os.environ,GOMAXPROCS="1",GOGC="100")
    with subprocess.Popen(["git","-C",root.parent,"archive",version["revision"],"pkg"],stdout=subprocess.PIPE) as git:
        with tarfile.open(fileobj=git.stdout,mode="r|") as tar:
            tar.extractall(out,filter="data")
        if git.wait():
            raise RuntimeError("git archive failed")
    tree = out / "pkg"
    def patch(f):
        subprocess.run(["patch","--batch","--fuzz=0","-p1","-i",records/f],cwd=tree,check=True)
    if "patch" in version:
        patch(version["patch"])
    if a.variant in ("before","after"):
        patch("counter/"+a.variant+".patch")
    target = out / "smt.test"
    subprocess.run(["go","test","-pgo=off","-c","-o",target,"./smtcore"],cwd=tree,env=env,check=True)
    pin = ["taskset","-c",str(a.cpu)]
    def bench(args,**values):
        subprocess.run(pin+[target,*args],cwd=tree/"smtcore",env=dict(env,**values),check=True)
    bench(["-test.run=Clause|PopResume|ScopeRestoration"])
    bench(["-test.run=^$","-test.cpu=1","-test.bench=^BenchmarkSMTClauseDirectoryMemory$","-test.benchtime=1x"])
    if a.variant in ("before","after"):
        for empty in ("","1"):
            bench(["-test.run=^$","-test.cpu=1","-test.bench=^BenchmarkSMTConcreteClauseScope$","-test.benchtime=13x"],SCOPE_PHASE="0",SCOPE_THREAD_EVENT="1",STUDY_EMPTY=empty)
    if a.state:
        if a.variant not in ("before","after"):
            p.error("--state requires --variant before or after")
        patch("state/"+a.variant+".patch")
        cmd=out/"g3"
        subprocess.run(["go","build","-pgo=off","-o",cmd,"./cmd/g3"],cwd=tree,env=env,check=True)
        chosen=json.loads((records/"states"/a.state/"chosen.json").read_text())
        with (records/"states"/a.state/"go.csv").open() as f:
            expected=next(row for row in csv.DictReader(f) if row["engine"]==a.variant)
        pos = chosen["go"]["position"]
        run=subprocess.run(pin+[cmd,"-st","-smt2",records/"queries"/(a.state+".smt2")],env=dict(env,STUDY_COLLECT_AT=str(pos)),capture_output=True,text=True,check=True)
        stats=[run.stdout.splitlines()[0]]+[[k,int(v)]for k,v in re.findall(r":(decisions|conflicts|quant-instantiations|rlimit-count)\s+(\d+)",run.stdout)]
        assert stats==chosen["answer"],stats
        fields=(records/"state/fields.txt").read_text().split()
        state=next(dict(zip(fields,line.split()[1:]))for line in run.stderr.splitlines()if line.startswith("GOMEM "+str(pos)+" "))
        for k in chosen["keys"]+["directory_bytes"]:
            assert state[k]==expected[k],(k,state[k],expected[k])
        print(a.state,a.variant,"live clauses",state["concrete"],"directory bytes",state["directory_bytes"],"heap bytes",state["heapalloc"])
    if a.native:
        sys.path.insert(0,str(root/"perf/ivy_apple"))
        from native_benchmark import build_native
        binary=out/"native"
        build_native(root.parent/"build",binary,root.parent/"src/test/perf/binary_clause_directory.cpp")
        for name in ("Binary","Auxiliary","Learned","Justified","Mixed"):
            subprocess.run(pin+[binary,"8",name],check=True)

if __name__=="__main__":
    main()
