from common import *
import watch_lookup_trials as wt
rd=d/'sat-clause-filter';rd.mkdir(exist_ok=True);src=pkg/'sat/sat_solver_clause_core.go';test=pkg/'sat/sat_clause_filter_study_test.go'
oracle=r'''package sat
import("testing";"math/rand";"github.com/glycerine/g3/pkg/util/lbool")
func TestStudyClauseFilter(t *testing.T){s,_,_:=satSolverCheckFixture(t);for i:=0;i<68;i++{_,e:=s.MkVar(false,true);satOK(t,e)}
 rng:=rand.New(rand.NewSource(25));a:=&s.Variables
 _=a
 v:=s.Variables.clauseState();r:=satSolverClauseState{assignment:make([]int8,len(s.Variables.assignment)),levels:make([]uint32,len(s.Variables.level))}
 for j:=0;j<4000;j++{n:=rng.Intn(80);for i:=0;i<len(s.Variables.level);i++{p:=lbool.LBool(rng.Intn(3)-1);s.Variables.assignment[2*i]=p;s.Variables.assignment[2*i+1]=p.Negated();s.Variables.level[i]=uint32(rng.Intn(4));r.assignment[2*i]=int8(p);r.assignment[2*i+1]=int8(p.Negated());r.levels[i]=s.Variables.level[i]}
 l:=make([]Literal,n);for i:=range l{l[i]=Literal(rng.Intn(len(r.assignment)+3))}
 q:=append([]Literal(nil),l...);size:=uint32(n);sz:=size;scope:=uint32(j%3);x,e:=v.simplifyClause(scope,&size,l);y,ee:=r.simplifyClause(scope,&sz,q)
 // The standalone view returns ErrBounds in debug when an owner gives the source assertion. Both are rejected.
 if x!=y || (e==nil)!=(ee==nil) || size!=sz{t.Fatal(j,scope,x,e,y,ee,size,sz)};for i:=range l{if l[i]!=q[i]{t.Fatal(j,i,l,q)}}}}
'''
def make(mode):
 s=src.read_text();x='prev := DefaultLiteral()\n\tvar j uint32'
 if mode!='baseline':
  fast='''if scope==0&&span.column==nil&&span.store==nil&&*n>0&&s.variables!=nil&&uint64(span.literals[*n-1])<uint64(len(s.variables.assignment)){
   if e:=s.variables.open();e!=nil{return false,e};v:=span.literals[:*n];assignment:=s.variables.assignment;prev:=DefaultLiteral()
   BODY
  }
  '''
  if mode=='known':body='''keep:=true;for _,l:=range v{if assignment[l]!=lbool.Undef||l==prev||l==prev.Negated(){keep=false;break};prev=l};if keep{return true,nil}'''
  else:body='''var j uint32;for i,l:=range v{switch assignment[l]{case lbool.True:return false,nil;case lbool.Undef:if l==prev.Negated(){return false,nil};if l!=prev{prev=l;if j!=uint32(i){v[j]=l};j++}}};*n=j;return true,nil'''
  if mode=='scoped':
   fast=fast.replace('scope==0&&','').replace('&&s.variables!=nil','&&s.variables!=nil&&(scope==0||uint64(span.literals[*n-1].variable())<uint64(len(s.variables.level)))')
   body=body.replace('switch assignment[l]{','val:=assignment[l];if scope!=0&&s.variables.level[l.variable()]>0{val=lbool.Undef};switch val{')
  s=once(s,x,fast.replace('BODY',body)+x)
 out=rd/mode;out.mkdir(exist_ok=True);o=overlay(out/'overlay',{src:s,test:oracle})
 with(w/'build.lock').open('a')as lk,(out/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-count=1','-overlay='+str(o),'./sat'],cwd=pkg,stdout=f,stderr=f);run(['go','test','-p','3','-tags=g3checked','-count=1','-overlay='+str(o),'./sat','-run=^TestStudyClauseFilter$'],cwd=pkg,stdout=f,stderr=f)
  run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-overlay='+str(o),'-o',out/'g3','./cmd/g3'],cwd=pkg,stdout=f,stderr=f)
 return out/'g3'
def wide(c,cs,bs):
 with(rd/f'wide-{c}.csv').open('w')as f:
  run([sys.executable,pkg/'perf/ivy_raft/wide_clauses.py','--rounds','3','--perf',perf,'--cpu',str(c),*[x for k,b in bs.items()for x in ['--solver',k,b]],*[x for w,n in cs for x in ['--case',str(w),str(n)]]],stdout=f)
if __name__=='__main__':
 vs=['known','direct','scoped']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(make,vs)))
 bs={'baseline':d/'window-sort-release',**bs,'native':pkg.parent/'build/z3'};wt.rd=rd
 with ThreadPoolExecutor(6)as ex:
  fs=[ex.submit(wide,c,cs,bs)for c,cs in [(7,[(16,16384),(32,16384)]),(14,[(64,65536),(128,8192)]),(25,[(256,4096),(512,4096)])]]+[ex.submit(wt.probe,j,{k:b for k,b in bs.items()if k!='native'})for j in [(4,'pigeon8'),(12,'planted5'),(17,'propagate6')]]
  for f in fs:f.result()
