from common import *
import ground_release_controls as gc,stage_frontier as sf,holdouts as ho
rd=d/'base-clause-release';rd.mkdir(exist_ok=True)
bs={'before':d/'window-sort-release','after':d/'filter-production','native':pkg.parent/'build/z3'}
def quiet():
 with(rd/'quiet.csv').open('w')as f:run([sys.executable,pkg/'perf/ivy_raft/quiet_wide_clauses.py',*[x for k,b in bs.items()for x in ['--solver',k,b]],'--case','64','131072','--case','32','65536','--case','16','65536','--case','512','16384','--rounds','7','--max-probes','900'],stdout=f)
def wide(c,cs):
 with(rd/f'wide-{c}.csv').open('w')as f:run([sys.executable,pkg/'perf/ivy_raft/wide_clauses.py','--rounds','3','--cpu',str(c),'--perf',perf,*[x for k,b in bs.items()for x in ['--solver',k,b]],*[x for a,n in cs for x in ['--case',str(a),str(n)]]],stdout=f)
def integration():
 b=build(rd/'checker');(rd/'info.txt').write_text(linked(b));gc.d=rd;ho.root=rd;bins={'before':d/'clause-input-release/checker/goivy_check','after':b,'native':native}
 js=[(c,*j[1:])for c,j in zip([5,8,10,26],(j for j in sf.jobs()if j[1]in('tlb','hybrid','hermes_rmw_o3','ticket_protocol')))]
 with ThreadPoolExecutor(5)as ex:
  fs=[ex.submit(gc.corpus,b)]+[ex.submit(ho.measure_spec,j,bins,3)for j in js]
  for f in fs:f.result()
def hard():
 with(rd/'search.csv').open('w')as f:run([sys.executable,pkg/'perf/ivy_raft/watch_propagation.py','--rounds','3','--perf',perf,'--cpu','28',*bs.values()],stdout=f)
with ThreadPoolExecutor(7)as ex:
 fs=[ex.submit(fn)for fn in [quiet,hard,integration]]+[ex.submit(wide,c,cs)for c,cs in [(12,[(16,16384),(32,16384)]),(19,[(64,65536),(128,8192)]),(35,[(256,4096),(512,4096)])]]
 for f in fs:f.result()
