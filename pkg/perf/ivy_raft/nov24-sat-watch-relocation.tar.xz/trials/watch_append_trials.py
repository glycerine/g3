from common import *
import watch_lookup_trials as wt
rd=d/'watch-append-trials';rd.mkdir(exist_ok=True);wl=pkg/'sat/sat_solver_watch_lists.go';ws=pkg/'sat/sat_solver_watch_store.go';pr=pkg/'sat/sat_solver_propagation.go'
def edit(mode):
 data=ws.read_text();lists=wl.read_text();p=pr.read_text()
 if 'append' in mode:
  old='old := x.values()';i=data.index(old,data.index('func (x *satSolverWatchListRecord) push'));data=data[:i]+'''if b:=x.backing;b!=nil && len(b.data)<cap(b.data) && uint64(len(b.data))<uint64(^uint32(0)) {b.data=append(b.data,w);return nil};return x.growWatch(w)
}
func(x *satSolverWatchListRecord)growWatch(w satWatched)error {
 '''+data[i:]
 if 'direct' in mode:
  i=lists.index('if err := w.open()',lists.index('func (w *satSolverWatchLists) pushClause'));lists=lists[:i]+'''
  if w!=nil && w.self==w && !w.closed && uint64(i)<uint64(len(w.lists)) {
   st:=w.store;r:=w.lists[i]
   if st!=nil && st.self==st && !st.closed && r.owner==st.origin && uint64(r.slot)<uint64(len(st.records)){
    rec:=&st.records[r.slot]
    if rec.live && rec.generation==r.generation && rec.backing!=nil{
     dst:=rec.backing.data
     if len(dst)<cap(dst) && uint64(len(dst))<uint64(^uint32(0)){
      w2,er:=newSATClauseWatch(blocked,offset);if er!=nil{return er};rec.backing.data=append(dst,w2);return nil
     }
    }
   }
  }
 '''+lists[i:]
 if 'cursor'in mode:
  old='if e = v.watches.pushClause(replacement.Negated().index(), c0, off); e != nil {'
  new='''idx:=replacement.Negated().index()
  pushed:=false
  if !tracing && !satStorageSourceDebug && w.locator.slot==w.val1 {
   lists:=v.watches
   if lists!=nil && lists.self==lists && !lists.closed && uint64(idx)<uint64(len(lists.lists)){
    store:=lists.store;r:=lists.lists[idx]
    if store!=nil && store.self==store && !store.closed && r.owner==store.origin && uint64(r.slot)<uint64(len(store.records)){
     dest:=&store.records[r.slot]
     if dest.live && dest.generation==r.generation && dest.backing!=nil{
      buf:=dest.backing.data
      if len(buf)<cap(buf) && uint64(len(buf))<uint64(^uint32(0)){w.val2=2+uint32(c0)<<2;dest.backing.data=append(buf,w);pushed=true}
     }
    }
   }
  }
  if !pushed {e=v.watches.pushClause(idx,c0,off)};if e != nil {'''
  p=once(p,old,new)
 return {file:new for file,new in [(wl,lists),(ws,data),(pr,p)]if file.read_text()!=new}
def build(m):
 q=rd/m;q.mkdir(exist_ok=True);o=overlay(q/'overlay',edit(m));b=q/'g3'
 with(w/'build.lock').open('a')as lk,(q/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH)
  run(['go','test','-p','4','-count=1','-overlay='+str(o),'./sat'],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','4','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 return b
if __name__=='__main__':
 modes=['append','direct','cursor','append-cursor']
 with ThreadPoolExecutor(2)as ex:bs={'before':d/'release-arena-generation/g3',**dict(zip(modes,ex.map(build,modes)))}
 wt.rd=rd
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:wt.probe(j,bs),[(6,'pigeon7'),(17,'pigeon8'),(25,'planted5'),(32,'propagate6')]))
