from common import *
import arena_generation_release as ar
from rotating_verification import ticks,idle,thread_siblings
from watch_propagation import check_output,formulas
rd=d/'watch-release-frontier'
bs={'before':d/'release-arena-generation/g3','after':rd/'g3','native':pkg.parent/'build/z3'}
def repeat():
 for gc in ('100','off'):
  with (rd/('propagate3-gc'+gc+'.csv')).open('w')as f:
   run([sys.executable,pkg/'perf/ivy_raft/watch_propagation.py','--rounds','15','--case','propagate3','--cpu','37','--perf',perf,*bs.values()],stdout=f,env=dict(env,GOGC=gc))
def quiet():
 ar.rd=rd;names=list(bs);ids=list(range(48));sib={i:thread_siblings(i)for i in ids}
 q=next(t for t in formulas()if t[0]=='pigeon8');src=d/'release-arena-generation/quiet.cnf';accepted=0;key=None
 with (rd/'quiet.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round attempt cpu engine pre_idle sibling_idle occupancy wall user sys rss decisions conflicts'.split())
  for attempt in range(1,700):
   start=ticks(ids);time.sleep(.35);end=ticks(ids);free={i:min(idle(start,end,j)for j in [i,*sib[i]])for i in ids};c=max(free,key=free.get)
   if free[c]<.95:continue
   rot=accepted%3
   for n in names[rot:]+names[:rot]:
    txt,si,wall,u=ar.unsat_trial(bs[n],c,sib[c],src);st=check_output(txt,q[3],q[1],q[2]);k=st['decisions'],st['conflicts'];assert key is None or key==k;key=k
    oc=(u.ru_utime+u.ru_stime)/wall;z.writerow([accepted+1,attempt,c,n,free[c],si,oc,wall,u.ru_utime,u.ru_stime,u.ru_maxrss,*key]);f.flush()
    if min(oc,si)<.95:break
   else:
    accepted+=1
    if accepted==7:return
  raise RuntimeError(accepted)
if __name__=='__main__':
 with ThreadPoolExecutor(2)as e:
  fs=[e.submit(fn)for fn in (quiet,repeat)]
  for f in fs:f.result()
