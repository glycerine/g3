from common import *
import watch_inline_resolution as wi,watch_append_trials as wa
import holdouts as ho,stage_frontier as sf,ground_release_controls as gc,macro_identity as mi
rd=d/'watch-release-frontier';rd.mkdir(exist_ok=True)
def sources():
 ed=wi.edit('guarded-reslice');s=ed[wa.ws]
 start=s.index('if x.backing == nil || cap(old) != cap(next)',s.index('func(x *satSolverWatchListRecord)growWatch'));end=s.index('return nil',start)
 s=s[:start]+'''if x.backing!=nil {x.backing.alive=false;x.backing.data=nil}
 x.backing=&satWatchBacking{data:next,alive:true}
 '''+s[end:]
 s=s.replace('appendWatch(','appendWithinCapacity(').replace('growWatch(','growAndAppend(')
 i=s.index('func(x *satSolverWatchListRecord)appendWithinCapacity')
 s=s[:i]+'''// Appending within the existing backing keeps all outstanding iterators valid.
 '''+s[i:];ed[wa.ws]=s
 p=ed[wa.pr];p=once(p,'var destinations []satSolverWatchListRef','''// Assignment can call out through a trace or extension. Only borrow the
 // directory across watch moves when both are inactive.
 var destinations []satSolverWatchListRef''')
 p=once(p,'moved,_:=newSATClauseWatch(c0,off)\n         if dest.appendWatch(moved)','''nextWatch, err := newSATClauseWatch(c0,off)
         if err != nil {return false,err}
         if dest.appendWithinCapacity(nextWatch)''')
 p=p.replace('propagationDestination(','currentPropagationList(');ed[wa.pr]=p
 return ed
def make():
 o=overlay(rd/'overlay',sources());b=rd/'g3'
 with(w/'build.lock').open('a')as lock,(rd/'tests.log').open('w')as f:
  fcntl.flock(lock,fcntl.LOCK_SH)
  for tag in ('xtrace_off','g3debug','g3checked',''):
   run(['go','test','-p','3','-tags='+tag,'-overlay='+str(o),'-count=1','./sat'],cwd=pkg,stdout=f,stderr=f)
  run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=f,stderr=f)
 return b,o
def sat(name,c,b):
 with(rd/(name+'.csv')).open('w')as f:
  run([sys.executable,pkg/'perf/ivy_raft/watch_propagation.py','--case',name,'--permutations','3'if name=='pigeon8'else'1','--rounds','3','--cpu',str(c),'--perf',perf,d/'release-arena-generation/g3',b,pkg.parent/'build/z3'],stdout=f)
def integ(o):
 b=build(rd/'checker',o=o);ho.root=rd;gc.d=rd
 bs={'before':d/'release-arena-generation/checker/goivy_check','after':b,'native':native}
 js=[(c,*j[1:])for c,j in zip([4,22,38,45],(j for j in sf.jobs()if j[1]in('tlb','hybrid','hermes_rmw_o3','ticket_protocol')))]+[(13,*j[1:5],j[-1])for j in mi.jobs()if j[1]=='rfn2']
 with ThreadPoolExecutor(6)as e:
  fs=[e.submit(gc.corpus,b)]+[e.submit(ho.measure_spec,j,bs,3)for j in js]
  for f in fs:f.result()
def main():
 b,o=make()
 with ThreadPoolExecutor(4)as e:
  apps=e.submit(integ,o)
  js=list(zip(['pigeon8','propagate6','planted5','pigeon7','propagate2','planted3','propagate3','planted8'],[11,7,19,27,43,6,18,34]))
  for f in [e.submit(sat,n,c,b)for n,c in js]:f.result()
  apps.result()
if __name__=='__main__':main()
