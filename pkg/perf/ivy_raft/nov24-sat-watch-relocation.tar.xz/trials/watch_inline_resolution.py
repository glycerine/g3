from common import *
import watch_dest_cycle as wd,watch_append_trials as wa,watch_lookup_trials as wt
rd=d/'watch-inline-resolution';rd.mkdir(exist_ok=True)
def edit(mode):
 e=wd.edit('direct');p=e[wa.pr];s=e[wa.ws]
 ix=p.index('fastMoves:=');j=p.index('for pos :=',ix)
 p=p[:ix]+('''var destinations []satSolverWatchListRef
  store:=v.watches.store
  if !tracing && !satStorageSourceDebug && !s.extensionPresent {destinations=v.watches.lists}
  records:=store.records
  ''' if 'guarded'in mode else '''destinations:=v.watches.lists
  store:=v.watches.store
  records:=store.records
  fastMoves:=!tracing&&!satStorageSourceDebug&&!s.extensionPresent
  ''')+p[j:]
 ix=p.index('i:=replacement.Negated().index()');j=p.index('return false, e',ix)
 p=p[:ix]+'''i:=replacement.Negated().index()
       VAR
       if dest!=nil {
         moved,_:=newSATClauseWatch(c0,off)
         if dest.appendWatch(moved){keep=false;break}
       }
       if e=v.watches.pushClause(i,c0,off);e!=nil{
       '''+p[j:]
 if 'guarded'in mode:
  p=p.replace('VAR','dest:=propagationDestination(i,destinations,records,store.origin)')
 else:
  p=p.replace('VAR','var dest *satSolverWatchListRecord\nif fastMoves{dest=propagationDestination(i,destinations,records,store.origin)}')
 helper='''
 // The propagation loop holds this directory while extensions and trace callbacks are inactive.
 func propagationDestination(i uint32, lists []satSolverWatchListRef, records []satSolverWatchListRecord, owner uint64)*satSolverWatchListRecord{
    if uint64(i)>=uint64(len(lists)){return nil}
    ref:=lists[i];if ref.owner!=owner||uint64(ref.slot)>=uint64(len(records)){return nil}
    record:=&records[ref.slot];if !record.live||record.generation!=ref.generation{return nil}
    return record
 }'''
 if 'reslice' in mode:
  s=once(s,'b.data=append(data,w);return true','b.data=data[:n+1];b.data[n]=w;return true')
 if 'carry'in mode:
  p=once(p,'moved,_:=newSATClauseWatch(c0,off)','moved:=w;moved.SetClause(c0,off)')
 return {wa.pr:p+helper,wa.ws:s}
def main():
 wa.edit=edit;wa.rd=rd;vs=['split','guarded','guarded-reslice','guarded-reslice-carry']
 with ThreadPoolExecutor(2)as e:bs={'before':d/'release-arena-generation/g3','direct':d/'watch-destination-cycle/direct/g3',**dict(zip(vs,e.map(wa.build,vs)))}
 wt.rd=rd
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:wt.probe(j,bs),[(2,'pigeon8'),(12,'pigeon7'),(18,'planted5'),(29,'propagate6')]))
if __name__=='__main__':main()
