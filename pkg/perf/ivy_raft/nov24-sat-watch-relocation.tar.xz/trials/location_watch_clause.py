from common import *
import watch_lookup_trials as wt,watch_append_trials as wa
rd=d/'location-watch-clause';rd.mkdir(exist_ok=True)
def edit(mode):
    ab=pkg/'arena/small_bytes.go';cl=pkg/'sat/sat_clause_storage.go';lg=pkg/'sat/sat_clause_large.go';s=ab.read_text();v=cl.read_text();g=lg.read_text()
    s=once(s,'if m.nextFree != 0 {','if m.nextFree != 0 && uint32(m.nextFree)&(1<<31)==0 {')
    s+='''
    // A free-list link's low word holds at most MaxUint32 / 4 + 2.
    // An occupied block may carry its slot, generation and exact requested length.
    // The hint is optional: unusual widths, older callers and direct chunks take Borrow.
    func(a *SmallBytes)LocationHint(r SmallBytesRef)uint32{
        if a.closed||r.Slot==0||uint32(r.Slot)>=1<<31||r.Generation==0||uint32(r.Generation)>=1<<24{return 0}
        d,e:=a.descriptor(r);if e!=nil || d.page>=1<<20 || d.length>=256{return 0}
        c:=&a.chunks[d.page];if c.class==0{return 0}
        index:=d.offset/(c.class*a.config.Alignment);if index>=4095{return 0}
        c.blocks[index].nextFree=uint64(d.length)<<56|uint64(r.Generation)<<32|uint64(uint32(r.Slot)|1<<31)
        return d.page<<12|(index+1)
    }
    func(a *SmallBytes)BorrowHinted(r SmallBytesRef,hint uint32)([]byte,error){
        if hint!=0 && uint64(hint>>12)<uint64(len(a.chunks)) && uint32(r.Slot)<1<<31 && uint32(r.Generation)<1<<24{
            c:=&a.chunks[hint>>12];b:=(hint&4095)-1
            if uint64(b)<uint64(len(c.blocks)){
                k:=c.blocks[b].nextFree
                if k&0x00ffffffffffffff == uint64(r.Generation)<<32|uint64(uint32(r.Slot)|1<<31) {
                    off:=b*c.class*a.config.Alignment;end:=off+uint32(k>>56);return c.data[off:end:end],nil
                }
            }
        }
        return a.Borrow(r)
    }
    '''
    v=once(v,'slot, generation, storageKind uint32','slot, generation, storageKind, location uint32')
    v=once(v,'uint32(r.Generation), 0}, nil','uint32(r.Generation), 0, a.storage.LocationHint(r)}, nil')
    g=once(g,'entry.generation, 1}, nil','entry.generation, 1, 0}, nil')
    if mode!='place':
        v=once(v,'return a.storage.Borrow(arena.SmallBytesRef{Slot: arena.Slot(r.slot), Generation: arena.Generation(r.generation)})','return a.storage.BorrowHinted(arena.SmallBytesRef{Slot:arena.Slot(r.slot),Generation:arena.Generation(r.generation)},r.location)')
    if mode=='offset':
        # Use a byte offset and precomputed granularity, saving a multiply on each access.
        s=once(s,'return d.page<<12|(index+1)','if d.offset%4!=0||d.offset/4>=4095{return 0};return d.page<<12|(d.offset/4+1)')
        s=once(s,'b:=(hint&4095)-1','off:=((hint&4095)-1)*4;stride:=c.class*a.config.Alignment;if stride==0{return a.Borrow(r)};b:=off/stride')
        s=once(s,'off:=b*c.class*a.config.Alignment;end:=off+uint32(k>>56);return c.data[off:end:end],nil','if off==b*stride{end:=off+uint32(k>>56);return c.data[off:end:end],nil}')
    return {ab:s,cl:v,lg:g}
def make(mode):
    q=rd/mode;q.mkdir(exist_ok=True);o=overlay(q/'overlay',edit(mode));b=q/'g3'
    with(w/'build.lock').open('a')as lk,(q/'build.log').open('w')as l:
        fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-count=1','-overlay='+str(o),'./sat','./arena'],cwd=pkg,stdout=l,stderr=l)
        run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
    return b
if __name__=='__main__':
    vs=['place','block','offset']
    with ThreadPoolExecutor(2)as ex:bs={'before':d/'release-arena-generation/g3',**dict(zip(vs,ex.map(make,vs)))}
    wt.rd=rd
    with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:wt.probe(j,bs),[(10,'pigeon7'),(19,'pigeon8'),(27,'planted5'),(34,'propagate6')]))
