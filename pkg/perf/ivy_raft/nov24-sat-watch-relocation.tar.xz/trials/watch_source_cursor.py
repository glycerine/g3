from common import *
import watch_dest_cycle as wd,watch_append_trials as wa,watch_lookup_trials as wt
rd=d/'watch-source-cursor';rd.mkdir(exist_ok=True)
def edit(mode):
 ed=wd.edit('direct') if 'dest' in mode else {}
 p=wa.pr; s=ed.get(p,p.read_text());start=s.index('count, e := list.Size()');end=s.index('out := uint32(0)',start)
 s=s[:start]+'''// Get checked this literal's index and the current list owner.
    // Iter validates the child reference and captures the original end.
    iter, e := v.watches.store.Iter(v.watches.lists[list.index])
    if e != nil { return false, arena.ErrInvalidSlot }
    s.asymmCounter = int32(uint32(s.asymmCounter) - iter.end)
    s.probingCounter = int32(uint32(s.probingCounter) - iter.end)
    '''+s[end:]
 if 'end' in mode:
  start=s.index('r, e := w.ref()',s.index('func (s *satSolverPropagationState) finishPropagationList'))
  end=s.index('if x.backing != i.backing',start)
  s=s[:start]+'''if err:=w.owner.open();err!=nil{return err}
    if w.backingID!=w.owner.backingID{return ErrSATOwner}
    if uint64(w.index)>=uint64(len(w.owner.lists)){return arena.ErrBounds}
    r:=w.owner.lists[w.index]
    x,err:=w.owner.store.record(r);if err!=nil{return arena.ErrInvalidSlot}
    if i.store!=w.owner.store {x,err=i.store.record(r);if err!=nil{return err}}
    '''+s[end:]
 ed[p]=s;return ed
def main():
 wa.edit=edit;wa.rd=rd;vs=['begin','begin-end','begin-dest','begin-end-dest']
 with ThreadPoolExecutor(2)as e:bs={'before':d/'release-arena-generation/g3','dest':d/'watch-destination-cycle/direct/g3',**dict(zip(vs,e.map(wa.build,vs)))}
 wt.rd=rd
 with ThreadPoolExecutor(4)as e:list(e.map(lambda job:wt.probe(job,bs),[(9,'pigeon8'),(28,'pigeon7'),(16,'propagate6'),(37,'planted5')]))
if __name__=='__main__':main()
