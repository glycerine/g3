package arena

import (
	"strconv"
	"testing"
)

func BenchmarkSmallBytesChunkDirectory(b *testing.B) {
	for _, count := range []int{512, 4096, 16384} {
		b.Run(strconv.Itoa(count), func(b *testing.B) {
			for _, shape := range []string{"Grow", "SparseReuse", "LateHoles"} {
				b.Run(shape, func(b *testing.B) {
					store, err := NewSmallBytes(SmallBytesConfig{})
					if err != nil {
						b.Fatal(err)
					}
					defer store.Close()
					refs := make([]SmallBytesRef, count)
					fill := func() {
						for i := range refs {
							r, e := store.Allocate(256)
							if e != nil {
								b.Fatal(e)
							}
							refs[i] = r
						}
					}
					if shape != "Grow" {
						fill()
					}
					b.ReportAllocs()
					b.ResetTimer()
					for round := 0; round < b.N; round++ {
						if shape == "Grow" {
							fill()
							store.Reset()
							continue
						}
						for j := 0; j < 64; j++ {
							i := ((round*64 + j) * 2377) & (count - 1)
							if shape == "LateHoles" {
								i = count - 64 + j
							}
							if err := store.Deallocate(256, refs[i]); err != nil {
								b.Fatal(err)
							}
						}
						for j := 0; j < 64; j++ {
							i := ((round*64 + j) * 2377) & (count - 1)
							if shape == "LateHoles" {
								i = count - 64 + j
							}
							r, e := store.Allocate(256)
							if e != nil {
								b.Fatal(e)
							}
							refs[i] = r
						}
					}
					b.StopTimer()
					b.ReportMetric(float64(count), "population")
				})
			}
		})
	}
}
