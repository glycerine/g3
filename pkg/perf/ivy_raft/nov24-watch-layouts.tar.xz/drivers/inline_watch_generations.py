from common import *
import watch_origin_words as ow,watch_lookup_trials as wt
rd=d/'inline-watch-generations';rd.mkdir(exist_ok=True);st=pkg/'sat/sat_solver_watch_store.go'
def ed(v):
 if v=='base':return {}
 e=ow.ed('domain12');s=e[st];s=once(s,'type watchWord struct{val1,val2,code uint32}','type watchWord struct{val1,val2 uint32}')
 i=s.index('func(s *satSolverWatchStore) encode');j=s.index('func(s *satSolverWatchStore) rareDomain',i)
 # Single word for generations commonly seen in live learnt clauses. The scratch
 # trial enumerates every overflow use and retains the full identity in the rare table.
 bits=int(v.split('-')[1]);mask=(1<<bits)-1;upper=1<<(30-bits);enc=f'''
 func(s *satSolverWatchStore)encode(w satWatched)watchWord{{
  word:=watchWord{{val1:w.val1,val2:w.val2}}
  if !w.Clause(){{return word}}
  o,_:=w.ClauseOffset()
  if !s.commonSet{{s.common=o;s.common.slot=0;s.common.generation=0;s.commonSet=true}}
  if o.owner==s.common.owner && o.storageKind==s.common.storageKind {{
   if o.generation==1 && o.slot<1<<31{{return word}}
   if o.slot<={mask} && o.generation-2<{upper} {{word.val1=1<<31|(o.generation-2)<<{bits}|o.slot;return word}}
  }}
  word.val1=3<<30|s.rareDomain(o);return word
 }}
 func(s *satSolverWatchStore)clauseOffset(p watchWord)satClauseOffset{{
  o:=s.common;o.slot=p.val1;o.generation=1
  if p.val1>>31==0 {{return o}}
  if p.val1>>30==2 {{o.slot=p.val1&{mask};o.generation=2+((p.val1&0x3fffffff)>>{bits});return o}}
  return s.watchOffsets[p.val1&0x3fffffff]
 }}
 func(s *satSolverWatchStore)decode(p watchWord)satWatched{{w:=p.tagged();if w.Clause(){{w.locator=s.clauseOffset(p);w.val1=w.locator.slot}};return w}}
 '''
 s=s[:i]+enc+s[j:];s=once(s,'o.slot=0\n  if n,ok:=s.watchIDs[o];ok{return n}','if n,ok:=s.watchIDs[o];ok{return n}')
 e[st]=s;return e
def buildmode(n):
 sd=rd/n;sd.mkdir(exist_ok=True);o=overlay(sd/'overlay',ed(n));b=sd/'g3'
 with(w/'build.lock').open('a')as lk,(sd/'test.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for tag in ('','g3debug','g3checked'):run(['go','test','-p','2','-count=1','-overlay='+str(o),'-tags='+tag,'./sat'],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','2','-tags=xtrace_off','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
  run(['go','test','-tags=xtrace_off','-run=^$','-bench=^BenchmarkGroundInstanceWorkerMemory$','-overlay='+str(o),'-cpu=1','-benchtime=1x','-count=5','./api'],cwd=pkg,stdout=log,stderr=log)
 return b
def main():
 vs=['base','bits-16','bits-20','bits-24']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(buildmode,vs)))
 wt.rd=rd
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:wt.probe(j,bs),[(11,'pigeon8'),(17,'pigeon7'),(45,'planted5'),(41,'propagate6')]))
if __name__=='__main__':main()
