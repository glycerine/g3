from common import *
import watch_lookup_trials as wt
rd=d/'bounded-clause-views';rd.mkdir(exist_ok=True);cb=pkg/'sat/sat_clause_storage.go';tf=pkg/'sat/sat_clause_heap_trial_test.go'
bench='''package sat
import("testing";"runtime";"fmt";"errors";"github.com/glycerine/g3/pkg/arena")
func satHeapTrialBytes() int64 {runtime.GC();runtime.GC();var x runtime.MemStats;runtime.ReadMemStats(&x);return int64(x.HeapAlloc)}
func TestStudyClauseHeap(t *testing.T){
 for _,n:=range []int{64,1024,16384,65536}{
  t.Run(fmt.Sprint(n),func(t *testing.T){const workers=4
   refs:=make([]StoredClauseRef,workers*n);ss:=make([]*ClauseAllocator,workers)
   before:=satHeapTrialBytes()
   for i:=range ss{var err error;ss[i],err=NewSATClauseAllocator(satClauseAllocatorConfig{});if err!=nil{t.Fatal(err)}
    for j:=range n{r,e:=ss[i].MkClause([]Literal{Literal(2*j),Literal(2*j+2),Literal(2*j+6),Literal(2*j+10)},j%3==0);if e!=nil{t.Fatal(e)};refs[i*n+j]=r}
   }
   loaded:=satHeapTrialBytes()
   for i,s:=range ss{for j,r:=range refs[i*n:(i+1)*n]{v,e:=s.view(r);if e!=nil||v.literal(0)!=Literal(2*j){t.Fatal(j,e)}}}
   watched:=satHeapTrialBytes()
   for i,s:=range ss{for j,r:=range refs[i*n:(i+1)*n]{if j%4==0{continue};if e:=s.Delete(r);e!=nil{t.Fatal(e)};if _,e:=s.view(r);!errors.Is(e,arena.ErrInvalidSlot){t.Fatal("stale",j,e)}}}
   sparse:=satHeapTrialBytes()
   for _,s:=range ss{if e:=s.Close();e!=nil{t.Fatal(e)}}
   closed:=satHeapTrialBytes()
   t.Logf("CLAUSE-HEAP %d %d %d %d %d",n,(loaded-before)/workers,(watched-before)/workers,(sparse-before)/workers,(closed-before)/workers)
   runtime.KeepAlive(ss);runtime.KeepAlive(refs)
  })
 }
}
'''
def edits(n):
 s=cb.read_text()
 if n==0:return {tf:bench}
 s=once(s,'type ClauseAllocator struct {','type satClauseCacheEntry struct {slot,gen uint32; data []byte}\ntype ClauseAllocator struct {\n views []satClauseCacheEntry')
 s+='\nconst studyViewLimit = '+str(n)+'\n'
 # Prototype only. Use a disposable cache with no access on an invalid owner. Fixed variants have no per-live-clause requirement.
 k='return a.storage.Borrow(arena.SmallBytesRef{Slot: arena.Slot(r.slot), Generation: arena.Generation(r.generation)})'
 index='r.slot'if n<0 else 'r.slot%studyViewLimit'
 s=once(s,k,'''i:='''+index+'''
 if uint64(i)<uint64(len(a.views)){v:=&a.views[i];if v.slot==r.slot && v.gen==r.generation{return v.data,nil}}
 data,err:=a.storage.Borrow(arena.SmallBytesRef{Slot:arena.Slot(r.slot),Generation:arena.Generation(r.generation)})
 if err==nil{
 if uint64(i)>=uint64(len(a.views)){a.views=append(a.views,make([]satClauseCacheEntry,int(i)-len(a.views)+1)...)}
 a.views[i]=satClauseCacheEntry{r.slot,r.generation,data}
 }
 return data,err''')
 x='return a.storage.Deallocate(';assert s.count(x)==2;s=s.replace(x,'i:='+index+';if uint64(i)<uint64(len(a.views)) && a.views[i].slot==r.slot{a.views[i]=satClauseCacheEntry{}}\n'+x)
 s=once(s,'a.large = nil','a.views=nil\na.large=nil')
 return {cb:s,tf:bench}
def one(n):
 sd=rd/str(n);sd.mkdir(exist_ok=True);o=overlay(sd/'overlay',edits(n));b=sd/'g3'
 with(w/'build.lock').open('a')as lk,(sd/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','2','-tags=xtrace_off','-overlay='+str(o),'-c','-o',sd/'sat.test','./sat'],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','2','-pgo=off','-tags=xtrace_off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 with(sd/'heap.log').open('w')as out:run(['taskset','-c',str({0:10,256:11,1024:13,4096:15,-1:17}[n]),sd/'sat.test','-test.run=^TestStudyClauseHeap$','-test.v','-test.cpu=1','-test.count=3'],cwd=sd,stdout=out,stderr=out)
 return b
def main():
 vs=[0,256,1024,4096,-1]
 with ThreadPoolExecutor(3)as e:bs=dict(zip((str(n)for n in vs),e.map(one,vs)))
 wt.rd=rd
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:wt.probe(j,bs),[(21,'pigeon8'),(26,'pigeon7'),(33,'planted5'),(37,'propagate6')]))
if __name__=='__main__':main()
