from common import *
import move_watch_words as mw, watch_lookup_trials as wt
rd=d/'watch-origin-words';rd.mkdir(exist_ok=True)
def ed(mode):
 if mode=='base':return {}
 src=d/'move-watch-words/move8/overlay';eds={pkg/'sat'/f.name:f.read_text()for f in src.glob('*.go')}
 st=pkg/'sat/sat_solver_watch_store.go';s=eds[st]
 i=s.index('func (s *satSolverWatchStore) encode');j=s.index('type satSolverWatchListRecord',i)
 i2=s.index('func (s *satSolverWatchStore) clauseOffset');s=s[:i2]
 size={'inline24':'val1,val2,gen,kind uint32; owner uint64','domain16':'val1,val2,gen,domain uint32','domain12':'val1,val2,code uint32'}[mode]
 s=once(s,'struct{ val1, val2 uint32 }','struct{'+size+'}')
 i=s.index('func (s *satSolverWatchStore) encode');j=s.index('type satSolverWatchListRecord',i)
 encoding='''
 func(s *satSolverWatchStore) encode(w satWatched)watchWord{
  p:=watchWord{val1:w.val1,val2:w.val2}
  if w.Clause(){o,_:=w.ClauseOffset();ENC}
  return p
 }
 func(s *satSolverWatchStore)decode(p watchWord)satWatched{
  w:=p.tagged();if w.Clause(){w.locator=s.clauseOffset(p)};return w
 }
 func(s *satSolverWatchStore)clauseOffset(p watchWord)satClauseOffset{DEC}
 '''
 if mode=='inline24':
  encoding=encoding.replace('ENC','p.gen,p.kind,p.owner=o.generation,o.storageKind,o.owner').replace('DEC','return satClauseOffset{slot:p.val1,generation:p.gen,storageKind:p.kind,owner:p.owner}')
  s=s[:i]+encoding+s[j:]
  s=s.replace('watchOffsets []satClauseOffset','').replace('watchIDs     map[satClauseOffset]uint32','').replace('s.watchOffsets = nil','').replace('s.watchIDs = nil','')
 else:
  extra='''
 func(s *satSolverWatchStore) rareDomain(o satClauseOffset)uint32{
  o.slot=0
  if n,ok:=s.watchIDs[o];ok{return n}
  if s.watchIDs==nil{s.watchIDs=make(map[satClauseOffset]uint32)}
  n:=uint32(len(s.watchOffsets));s.watchOffsets=append(s.watchOffsets,o);s.watchIDs[o]=n;return n
 }
 '''
  if mode=='domain16':
   encoding=encoding.replace('ENC','''p.gen=o.generation
   if o.owner<1<<30 && o.storageKind<2 {p.domain=uint32(o.owner)<<1|o.storageKind}else{o.generation=0;p.domain=1<<31|s.rareDomain(o)}
   ''').replace('DEC','''o:=satClauseOffset{slot:p.val1,generation:p.gen,storageKind:p.domain&1,owner:uint64(p.domain>>1)}
   if p.domain>>31!=0{x:=s.watchOffsets[p.domain&0x7fffffff];o.owner,o.storageKind=x.owner,x.storageKind};return o''')
  else:
   encoding=encoding.replace('ENC','''if !s.commonSet{s.common=o;s.common.slot=0;s.common.generation=0;s.commonSet=true}
   if o.owner==s.common.owner && o.storageKind==s.common.storageKind && o.generation<1<<31{p.code=o.generation}else{p.code=1<<31|s.rareDomain(o)}''').replace('DEC','''o:=s.common;if p.code>>31!=0{o=s.watchOffsets[p.code&0x7fffffff]}else{o.generation=p.code};o.slot=p.val1;return o''')
  s=s[:i]+encoding+extra+s[j:]
  if mode=='domain12':s=once(s,'type satSolverWatchStore struct {','type satSolverWatchStore struct {\ncommonSet bool;common satClauseOffset')
 eds[st]=s
 wl=pkg/'sat/sat_solver_watch_lists.go';src=wl.read_text();a=src.index('func (w *satSolverWatchLists) pushClause(');j=src.index('\n}',a)+2
 eds[wl]+='\n'+src[a:j].replace('record.push(watch)','record.pushWord(w.store.encode(watch))')+'\n'
 return eds
def buildmode(n):
 sd=rd/n;sd.mkdir(exist_ok=True);o=overlay(sd/'overlay',ed(n));b=sd/'g3'
 with(w/'build.lock').open('a')as lk,(sd/'tests.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for tag in ('','g3debug','g3checked'):run(['go','test','-p','3','-count=1','-overlay='+str(o),'-tags='+tag,'./sat'],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
  run(['go','test','-overlay='+str(o),'-tags=xtrace_off','-run=^$','-cpu=1','-bench=^BenchmarkGroundInstanceWorkerMemory$','-count=5','-benchtime=1x','./api'],cwd=pkg,stdout=log,stderr=log)
 return b
def main():
 vs=['base','inline24','domain16','domain12']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(buildmode,vs)))
 wt.rd=rd
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:wt.probe(j,bs),[(35,'pigeon8'),(29,'pigeon7'),(5,'planted5'),(9,'propagate6')]))
if __name__=='__main__':main()
