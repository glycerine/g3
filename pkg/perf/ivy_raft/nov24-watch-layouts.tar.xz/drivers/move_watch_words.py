from common import *
import boolean_watch_cnf as bc,watch_lookup_trials as wt,packed_watch_stream as pack
rd=d/'move-watch-words';rd.mkdir(exist_ok=True)
def edits(mode):
 pu=d/'sat-watch-production/overlay';ed={pkg/'sat'/f.name:f.read_text()for f in pu.glob('*.go')}
 if mode=='base':return ed
 st=pack.storage;pr=pack.prop;ls=wt.wl;wordBase='prefix8'if 'prefix' in mode else'word8'
 packed={pkg/'sat'/f.name:f.read_text()for f in (pack.rd/wordBase/'overlay').glob('*.go')}
 s=packed[st];ed[pack.sort]=packed[pack.sort];ed[pack.sim]=packed[pack.sim]
 # Reuse the original encoded clause identity when the same watch moves to another literal in this store.
 i=s.index('old := x.values()',s.index('func (s *satSolverWatchStore) Push('));s=s[:i]+'''return x.pushWord(s.encode(w))
}
func(x *satSolverWatchListRecord)pushWord(w watchWord)error{
 '''+s[i:];s=once(s,'next := append(old, s.encode(w))','next := append(old,w)')
 add='''func(s *satSolverWatchStore) clauseOffset(p watchWord)satClauseOffset {return s.watchOffsets[p.val1-1]}''' if wordBase=='word8'else'''func(s *satSolverWatchStore) clauseOffset(p watchWord)satClauseOffset{ if p.val1>>31!=0{return s.watchOffsets[(p.val1&0x7fffffff)-1]};off:=s.common;off.slot=p.val1;return off}'''
 ed[st]=s+'\n'+add+'\n'
 s=ed[ls];i=s.index('// pushClause');j=s.index('type satSolverWatchListView struct',i)
 s=s[:i]+'''func(w *satSolverWatchLists)pushMovedWord(i uint32,blocked Literal,word watchWord)error{
 if err:=w.open();err!=nil{return err}
 if err:=satWatchLogicalBounds(i,len(w.lists));err!=nil{return err}
 word.val2=2+(uint32(blocked)<<2)
 if satStorageSourceDebug && Literal(word.val2>>2)!=blocked{return ErrSATAssertion}
 record,err:=w.store.record(w.lists[i]);if err!=nil{return arena.ErrInvalidSlot}
 return record.pushWord(word)
}
'''+s[j:];ed[ls]=s
 s=ed[pr].replace('return x.data[n], nil','return i.store.decode(x.data[n]),nil').replace('x.data[n] = w','x.data[n]=i.store.encode(w)').replace('var data []satWatched','var data []watchWord')
 s=once(s,'w := data[pos]','word:=data[pos]; w:=word.tagged()')
 s=once(s,'s.traceBlockedClause(blocked, w)','s.traceBlockedClause(blocked,iter.store.decode(word))')
 old='off, e := w.ClauseOffset()\n\t\t\t\tif e != nil {\n\t\t\t\t\treturn false, e\n\t\t\t\t}'
 s=once(s,old,'off:=iter.store.clauseOffset(word)')
 s=s.replace('data[out] = w','word.val2=w.val2;data[out]=word').replace('v.watches.pushClause(replacement.Negated().index(), c0, off)','v.watches.pushMovedWord(replacement.Negated().index(), c0, word)')
 ed[pr]=s;return ed
def buildmode(mode):
 sd=rd/mode;sd.mkdir(exist_ok=True);f=overlay(sd/'overlay',edits(mode));b=sd/'g3'
 with(w/'build.lock').open('a')as lk,(sd/'tests.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for tags in ('','g3debug'):
   run(['go','test','-p','3','-count=1','-tags='+tags,'-overlay='+str(f),'./sat'],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','4','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay='+str(f),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 return b
def main():
 vs=['base','move8','prefix8']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(buildmode,vs)))
 wt.rd=rd
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:wt.probe(j,bs),[(45,'pigeon8'),(26,'pigeon7'),(16,'planted5'),(2,'propagate6')]))
if __name__=='__main__':main()
