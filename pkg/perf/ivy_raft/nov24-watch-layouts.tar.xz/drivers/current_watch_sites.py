from common import *
import watch_instruction_sites as wi,watch_site_lines as wl,inspect
rd=d/'current-watch-sites';rd.mkdir(exist_ok=True)
def one(item):
 n,b,cpu=item;td=rd/n;td.mkdir(exist_ok=True)
 ns=wi.__dict__.copy();ns['rd']=td
 src=inspect.getsource(wi.profile).replace('cpu=17;',f'cpu={cpu};');exec(src,ns)
 for i in range(1,4):ns['profile']('g3',b,i)
 src=inspect.getsource(wl.main);i=src.index(' symbols=');j=src.index(' out=run',i)
 src=src[:i]+' symbols=[r"sat\\..*propagateCore$",r"sat\\..*pushClause$",r"sat\\..*pushMovedWord$",r"sat\\..*pushWord$",r"sat\\..*moveWatch$",r"sat\\..*\\.view$",r"arena\\..*\\.(descriptor|liveDescriptor|readLive|Borrow)$",r"sat\\..*\\.record$",r"sat\\..*watchedLiterals$"]\n'+src[j:]
 ns=wl.__dict__.copy();ns.update(rd=td,b=b);exec(src,ns);ns['main']()
def main():
 with ThreadPoolExecutor(3)as ex:list(ex.map(one,[('release',d/'sat-watch-production/g3-tree',12),('direct',d/'bounded-clause-views/-1/g3',35),('compact',d/'watch-origin-words/domain12/g3',46)]))
if __name__=='__main__':main()
