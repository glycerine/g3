from common import *
from itertools import product
import random,threading
sys.path.insert(0,str(pkg/'perf/ivy_raft'));import watch_propagation as wp
rd=d/'watch-choice-study';rd.mkdir(exist_ok=True);src=pkg/'sat/sat_clause_storage.go'
def make(v):
 f=rd/v;f.mkdir();s=src.read_text();i=s.index('func (v satClauseView) moveWatch(');j=s.index('\n}',i)+2
 if v!='original':
  same=s[i:s.index('{',i)+1]
  k=int(v[4:])if v.startswith('true')else 0
  s=s[:i]+same+'''
  n:=v.size();if n<=2{return 0,false}
  rest:=v[28:20+4*uint64(n)]
  var chosen []byte
  var lit Literal
  for len(rest)>=4{
   r:=Literal(binary.LittleEndian.Uint32(rest));a:=assignment[r.index()]
   if a!=lbool.False{
    if a==lbool.True{chosen,lit=rest,r;break}
    if chosen==nil{chosen,lit=rest,r;LIMIT}
   }
   rest=rest[4:]
  }
  if chosen==nil{return 0,false}
  v.setLiteral(1,lit);binary.LittleEndian.PutUint32(chosen,uint32(falsified));return lit,true
 }'''.replace('LIMIT','if len(rest)>4*'+str(k)+'{rest=rest[:4*'+str(k)+']}'if k else'')+s[j:]
 o=overlay(f/'overlay',{src:s})
 with(w/'build.lock').open('a')as lk,(f/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-tags=xtrace_off','-overlay='+str(o),'-pgo=off','-o',f/'g3','./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 return f/'g3'
def fixtures():
 for n,v,c,a in wp.formulas():
  yield n,v,c,a
  if n in ('pigeon7','pigeon8'):
   for seed in range(4):
    pr=random.Random(28000+seed);ls=sorted(range(1,v+1),key=lambda x:pr.random());cl=[[ls[abs(l)-1]*(1 if l>0 else -1)for l in t]for t in c]
    for t in cl:pr.shuffle(t)
    pr.shuffle(cl);yield n+'-s'+str(seed),v,cl,a
def run_case(j,bs):
 ix,(name,v,cs,expected)=j;dest=rd/name;dest.mkdir();ff=dest/'input.cnf';ff.write_text(wp.dimacs(v,cs));cpu=[6,14,19,22,25,28,36,39][ix%8]
 with(dest/'runs.csv').open('w')as out:
  z=csv.writer(out);z.writerow(['case','round','engine','cpu','answer','instructions','cycles','decisions','conflicts'])
  opts=list(bs)
  for i in range(3):
   for mode in opts[i%len(opts):]+opts[:i%len(opts)]:
    dt=dest/f'{i+1}-{mode}.stat';p=subprocess.run(['taskset','-c',str(cpu),perf,'stat','-x,','-o',dt,'-e','instructions:u,cycles:u','--',bs[mode],'-st','-dimacs',ff],env=dict(env,GOMAXPROCS='1'),cwd=dest,capture_output=True,text=True,timeout=360)
    assert p.returncode in (0,10 if expected=='sat'else 20);stat=wp.check_output(p.stdout,expected,v,cs);(dest/f'{i+1}-{mode}.stdout').write_text(p.stdout)
    hardware={x[2]:int(x[0])for x in csv.reader(dt.open())if len(x)>4 and x[2]in('cycles:u','instructions:u') and float(x[4])==100}
    z.writerow([name,i+1,mode,cpu,expected,hardware['instructions:u'],hardware['cycles:u'],stat.get('decisions',0),stat.get('conflicts',0)]);out.flush()
    if name=='pigeon8':print(name,i+1,mode,hardware['instructions:u']/1e9,flush=True)
def oracle(bs):
 sd=rd/'oracle';sd.mkdir();pr=random.Random(44068);npass=0
 with(sd/'answers.csv').open('w')as out:
  z=csv.writer(out);z.writerow(['case','variables','clauses','answer','solvers'])
  for i in range(320):
   v=pr.randint(3,10);cs=[]
   for _ in range(pr.randint(1,8*v)):
    cs.append([x*pr.choice([-1,1])for x in pr.sample(range(1,v+1),pr.randint(1 if i%3==0 else 2,min(v,7)))])
   want='sat'if any(all(any(bool(mask&(1<<(abs(l)-1)))==(l>0)for l in c)for c in cs)for mask in range(1<<v))else'unsat'
   f=sd/'input.cnf';f.write_text(wp.dimacs(v,cs));npass+=(want=='sat')
   for e,b in bs.items():
    p=subprocess.run(['taskset','-c','32',b,'-st','-dimacs',f],capture_output=True,text=True,env=dict(env,GOMAXPROCS='1'));assert p.returncode in (0,10 if want=='sat'else 20),(i,e,p.returncode);wp.check_output(p.stdout,want,v,cs)
   z.writerow([i,v,len(cs),want,len(bs)]);out.flush()
 print('finite',npass,320-npass,flush=True)
def main():
 modes=['original','true2','true4','true8','true0']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(modes,e.map(make,modes)))
 bs['native']=pkg.parent/'build/z3'
 with ThreadPoolExecutor(7)as ex:
  f=ex.submit(oracle,bs)
  for k in ex.map(lambda j:run_case(j,bs),enumerate(fixtures())):pass
  f.result()
if __name__=='__main__':main()
