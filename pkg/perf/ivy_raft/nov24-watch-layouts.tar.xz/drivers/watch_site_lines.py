from common import *
rd=d/'watch-instruction-sites';b=d/'boolean-watch-cnf/before/g3'
def main():
 symbols=['sat.\\(\\*satSolverPropagationState\\).propagateCore$','arena.\\(\\*SmallBytes\\).descriptor$','sat.\\(\\*satSolverWatchStore\\).Push$','sat.satSolverWatchListView.Push$','sat.\\(\\*ClauseAllocator\\).view$','sat.satSolverWatchListView.ref$']
 out=run(['go','tool','objdump','-s','|'.join(symbols),b],text=True,capture_output=True).stdout
 bypc={}
 for line in out.splitlines():
  fields=line.split()
  if len(fields)>=4 and fields[1].startswith('0x'):bypc[fields[1]]=(fields[0],' '.join(fields[3:]))
 for f in sorted(rd.glob('*-g3/sites.csv.gz')):
  counts=Counter();named=Counter();ops=Counter();total=0
  with gzip.open(f,'rt')as inp:
   for r in csv.DictReader(inp):
    n=int(r['samples']);total+=n
    if r['pc']in bypc:
     k,asm=bypc[r['pc']];sym=r['symbol'].split('+')[0].split('/')[-1];counts[(sym,k)]+=n;ops[(sym,k,asm,r['pc'])]+=n
     if 'propagateCore' in sym:named[k]+=n
  with(f.parent/'go-lines.csv').open('w')as dest:
   z=csv.writer(dest);z.writerow(['symbol','location','samples']);z.writerows([*k,n]for k,n in counts.most_common())
  with(f.parent/'go-asm.csv').open('w')as dest:
   z=csv.writer(dest);z.writerow(['symbol','location','instruction','pc','samples']);z.writerows([*k,n]for k,n in ops.most_common())
  if f.parent.name=='1-g3':
   print('total',total,'mapped',sum(counts.values()));print(named.most_common(20));print(*ops.most_common(10),sep='\n')
if __name__=='__main__':main()
