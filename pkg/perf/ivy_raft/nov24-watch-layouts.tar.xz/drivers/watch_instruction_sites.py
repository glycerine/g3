from common import *
rd=d/'watch-instruction-sites';rd.mkdir(exist_ok=True)
def profile(engine,b,i):
 cpu=17;sd=rd/(str(i)+'-'+engine);sd.mkdir(exist_ok=True);rec=sd/'record';period=500009
 with (sd/'stdout').open('wb')as out,(sd/'stderr').open('wb')as err:
  run(['taskset','-c',str(cpu),perf,'record','-q','--no-buildid','-e','instructions:u','-c',str(period),'-m','256','-o',rec,'--',b,'-st','-dimacs',d/'boolean-watch-cnf/inputs/pigeon8.cnf'],env=dict(env,GOMAXPROCS='1'),stdout=out,stderr=err)
 assert (sd/'stdout').read_text().startswith('unsat\n')
 freq=Counter();symbols={};total=0
 with subprocess.Popen([perf,'script','-F','ip,sym,symoff,dso,dsoff','-i',rec],stdout=subprocess.PIPE,text=True)as p:
  for line in p.stdout:
   total+=1
   m=re.match(r'^\s*([\da-f]+)\s+(.+)\s+\((.+)\+0x([\da-f]+)\)\s*$',line)
   if m and Path(m[3]).name==b.name:
    k=int(m[1]if engine=='g3'else m[4],16);freq[k]+=1;symbols[k]=m[2]
  assert p.wait()==0 and len(freq)>100
 addresses=list(freq)
 stackby={}
 if engine=='g3':
  cp=run(['addr2line','-a','-f','-i','-C','-e',b],input=''.join(hex(a)+'\n' for a in addresses),text=True,capture_output=True)
  for l in cp.stdout.splitlines():
   if l.startswith('0x'):cur=int(l,16);stackby[cur]=[]
   else:stackby[cur].append(l)
  assert len(stackby)==len(freq)
 with gzip.open(sd/'sites.csv.gz','wt')as f:
  wt=csv.writer(f);wt.writerow(['pc','symbol','samples','period','location']);wt.writerows([hex(k),symbols[k],v,period,'|'.join(stackby.get(k,[]))]for k,v in freq.most_common())
 (sd/'counts.txt').write_text(f'{total} {sum(freq.values())} {period}\n');rec.unlink();print(engine,i,total,flush=True)
def main():
 bs={'g3':d/'boolean-watch-cnf/before/g3','native':pkg.parent/'build/z3'}
 for i in range(1,4):
  for n in list(bs)[::1 if i%2 else -1]:profile(n,bs[n],i)
if __name__=='__main__':main()
