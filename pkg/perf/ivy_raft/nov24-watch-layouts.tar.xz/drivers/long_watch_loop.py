from common import *
import watch_lookup_trials as wt
rd=d/'long-watch-loop';rd.mkdir(exist_ok=True);pr=pkg/'sat/sat_solver_propagation.go';cb=pkg/'sat/sat_clause_storage.go'
def edits(mode):
 ed={}
 if 'pair' in mode:
  s=cb.read_text();i=s.index('func (v satClauseView) watchedLiterals');j=s.index('\n}',i)+2;head=s[i:s.index('{',i)+1]
  s=s[:i]+head+'''
  p:=v[20:28];word:=binary.LittleEndian.Uint64(p);first,second:=Literal(word),Literal(word>>32)
  if first==falsified {binary.LittleEndian.PutUint64(p,word>>32|word<<32);return second,first}
  return first,second
 }'''+s[j:];ed[cb]=s
 if mode in ('base','pair'):return ed
 s=pr.read_text()
 x='w := data[pos]\n\t\t\tkeep := true'
 if mode=='blocked':
  y='''if !tracing && data[pos].val2&3==2 && assignment[data[pos].val2>>2]==lbool.True{
  start:=pos
  for pos++;pos<iter.end && data[pos].val2&3==2 && assignment[data[pos].val2>>2]==lbool.True;pos++{}
  if out!=start{copy(data[out:out+pos-start],data[start:pos])};out+=pos-start;pos--;continue
 }
 '''
 else:
  y='''if !tracing && !satStorageSourceDebug && data[pos].val2&3==2{
  pos,out,e=s.propagateLongWatches(data, pos,iter.end,out,not,assignment)
  if e!=nil{return false,e};if pos==iter.end{break}
 }
 '''
  s+='''
func (s *satSolverPropagationState)propagateLongWatches(data []satWatched,pos,end,out uint32,falsified Literal,assignment []lbool.LBool)(uint32,uint32,error){
 allocator:=s.clauses;lists:=s.variables.watches
 for pos<end{
  w:=data[pos];if w.val2&3!=2{break}
  if assignment[w.val2>>2]==lbool.True{if out!=pos{data[out]=w};out++;pos++;continue}
  off:=w.locator;off.slot=w.val1
  clause,err:=allocator.view(StoredClauseRef(off));if err!=nil{return pos,out,err}
  a,b:=clause.watchedLiterals(falsified)
  if clause.flag(satClauseFlagRemoved)||b!=falsified{if out!=pos{data[out]=w};out++;pos++;continue}
  if assignment[a.index()]==lbool.True{w.SetClause(a,off);data[out]=w;out++;pos++;continue}
  repl,moved:=clause.moveWatch(falsified,assignment)
  if !moved{break}
  if err:=lists.pushClause(repl.Negated().index(),a,off);err!=nil{return pos,out,err}
  pos++
 }
 return pos,out,nil
}
'''
 s=once(s,x,y+x);ed[pr]=s;return ed
def one(mode):
 sd=rd/mode;sd.mkdir(exist_ok=True);o=overlay(sd/'overlay',edits(mode));b=sd/'g3'
 with(w/'build.lock').open('a')as lk,(sd/'tests.log').open('w')as l:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for tag in ('','xtrace_off','g3debug'):run(['go','test','-p','3','-count=1','-overlay='+str(o),'-tags='+tag,'./sat'],cwd=pkg,stdout=l,stderr=l)
  run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
 return b
def main():
 vs=['base','pair','blocked','loop','loop-pair']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(one,vs)))
 wt.rd=rd
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:wt.probe(j,bs),[(20,'pigeon8'),(16,'pigeon7'),(28,'planted5'),(10,'propagate6')]))
if __name__=='__main__':main()
