package sat

import "sort"

type satWatchSortSlice struct {
	data   []watchWord
	wide   []satClauseOffset
	binary bool
}

func (v *satWatchSortSlice) Len() int { return len(v.data) }
func (v *satWatchSortSlice) Less(i, j int) bool {
	a, b := v.data[i].tagged(), v.data[j].tagged()
	if v.binary {
		return satSimplifierBinaryLess(a, b)
	}
	return satWatchedLess(a, b)
}
func (v *satWatchSortSlice) Swap(i, j int) {
	v.data[i], v.data[j] = v.data[j], v.data[i]
	if v.wide != nil {
		v.wide[i], v.wide[j] = v.wide[j], v.wide[i]
	}
}

// watched_lt orders three source watch classes and treats entries within a
// class as equivalent. Go's stable sort keeps their original insertion order.
func (s *satSolverWatchStore) SortByKind(r satSolverWatchListRef) error {
	x, e := s.record(r)
	if e != nil {
		return e
	}
	// The store owns the interface adapter, so sorting each watch list does
	// not allocate a fresh boxed slice during the solver's outer loop.
	if x.backing == nil {
		return nil
	}
	s.sorter.data = x.values()
	s.sorter.wide = x.backing.wide
	s.sorter.binary = false
	sort.Stable(&s.sorter)
	s.sorter = satWatchSortSlice{}
	return nil
}
