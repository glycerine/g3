from common import *
import boolean_watch_cnf as bc
rd=d/'watch-lookup-trials';rd.mkdir(exist_ok=True)
cb=pkg/'sat/sat_clause_storage.go';pr=pkg/'sat/sat_solver_propagation.go';wl=pkg/'sat/sat_solver_watch_lists.go'
def edits(opts):
 c=cb.read_text();p=pr.read_text();l=wl.read_text();files={}
 if 'cache' in opts:
  c=once(c,'type ClauseAllocator struct {','type satCachedClause struct {generation uint32; data []byte}\ntype ClauseAllocator struct {\n views []satCachedClause')
  t='data, e := a.storage.Borrow(arena.SmallBytesRef{Slot: arena.Slot(r.slot), Generation: arena.Generation(r.generation)})'
  c=once(c,t,'''if int64(r.slot)<int64(len(a.views)) {entry:=&a.views[r.slot];if entry.generation==r.generation && entry.data!=nil{return satClauseView{small:entry.data},nil}}
   '''+t+'''
   if e==nil {if int64(r.slot)>=int64(len(a.views)){a.views=append(a.views,make([]satCachedClause,int(r.slot)-len(a.views)+1)...)};a.views[r.slot]=satCachedClause{r.generation,data}}''')
  # Both normal and construction-failure cleanup go through these two calls.
  for n in ['n','extent']:
   old=f'return a.storage.Deallocate(uint32({n}), arena.SmallBytesRef{{Slot: arena.Slot(r.slot), Generation: arena.Generation(r.generation)}})'
   c=once(c,old,'err := '+old[7:]+'\n if err==nil && int64(r.slot)<int64(len(a.views)){a.views[r.slot]=satCachedClause{}};return err')
  c=once(c,'a.large = nil','a.views = nil\n a.large=nil');files[cb]=c
 if 'push' in opts:
  l+='''\n// pushCurrent appends through the current outer list without constructing a retained view.
func (w *satSolverWatchLists) pushCurrent(i uint32, watch satWatched) error {
 if e:=w.open();e!=nil{return e}
 if e:=satWatchLogicalBounds(i,len(w.lists));e!=nil{return e}
 return w.store.Push(w.lists[i],watch)
}\n'''
  t='dest, e := v.watches.Get(replacement.Negated().index())\n\t\t\t\t\tif e != nil {\n\t\t\t\t\t\treturn false, e\n\t\t\t\t\t}'
  p=once(p,t,'');p=once(p,'dest.Push(nw)','v.watches.pushCurrent(replacement.Negated().index(),nw)');files[wl]=l
 if 'skip' in opts:
  p=once(p,'w.SetClause(c0, off)','w.SetClause(c0, off)\n data[out] = w; out++; keep=false')
  p=once(p,'if keep {\n\t\t\t\tdata[out] = w','if keep {\n if out!=pos || w.Kind()==3 {data[out] = w}')
  p=once(p,'// Source retains this watch BEFORE increment/mark/assignment/glue actions.\n\t\t\t\tdata[out] = w','// Source retains this watch BEFORE increment/mark/assignment/glue actions.\n if out!=pos {data[out]=w}')
 if 'read' in opts:
  old='if c0 := clause.literal(0); c0 == not {\n\t\t\t\t\tclause.setLiteral(0, clause.literal(1))\n\t\t\t\t\tclause.setLiteral(1, c0)\n\t\t\t\t}\n\t\t\t\tc1 := clause.literal(1)'
  p=once(p,old,'''c0,c1:=clause.literal(0),clause.literal(1)
  if c0==not {c0,c1=c1,c0;clause.setLiteral(0,c0);clause.setLiteral(1,c1)}''')
  p=once(p,'c0 := clause.literal(0)\n\t\t\t\tif assignment','if assignment')
 if p!=pr.read_text():files[pr]=p
 return files
def buildmode(mode):
 q=rd/mode;q.mkdir(exist_ok=True);f=overlay(q/'overlay',edits(mode.split('-')));b=q/'g3'
 with(w/'build.lock').open('a')as lock,(q/'build.log').open('w')as log:
  fcntl.flock(lock,fcntl.LOCK_SH)
  run(['go','build','-p','4','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay='+str(f),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
  run(['go','test','-count=1','-overlay='+str(f),'./sat'],cwd=pkg,stdout=log,stderr=log)
 return b
def counterstats(out):
 return {k:int(v) for k,v in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])',out) if not k.endswith('time') and 'memory' not in k}
def probe(job,bs):
 cpu,n=job;sd=rd/n;sd.mkdir(exist_ok=True);inp=bc.rd/'inputs'/(n+'.cnf');ns=list(bs);statsref=None;expected='unsat' if n.startswith('pigeon') else 'sat'
 with(sd/'runs.csv').open('w')as log:
  z=csv.writer(log);z.writerow('round engine instructions cycles seconds'.split())
  for i in range(3):
   for en in ns[i:]+ns[:i]:
    path=sd/(str(i+1)+'-'+en);st=time.monotonic()
    cp=subprocess.run(['taskset','-c',str(cpu),perf,'stat','-x,','-o',str(path)+'.stat','-e','instructions:u,cycles:u','--',bs[en],'-st','-dimacs',inp],cwd=sd,env=dict(env,GOMAXPROCS='1'),capture_output=True,timeout=150)
    out=cp.stdout.decode();assert out.splitlines()[0]==expected,(n,en,out[:200]);stats=counterstats(out);assert stats and (statsref==None or stats==statsref),(en,n,stats,statsref);statsref=stats
    (sd/(path.name+'.stdout')).write_text(out)
    measured=[int(l.split(',')[0])for l in (sd/(path.name+'.stat')).read_text().splitlines()if 'instructions:u'in l or 'cycles:u'in l]
    z.writerow([i+1,en,*measured,time.monotonic()-st]);log.flush()
    if n=='pigeon8':print(i+1,en,measured[0]/1e9,flush=True)
def main():
 vs=['push','cache','read','skip','push-cache-read','push-cache-read-skip']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(buildmode,vs)))
 bs={'before':bc.rd/'before/g3',**bs}
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:probe(j,bs),[(6,'pigeon8'),(12,'pigeon7'),(21,'planted5'),(43,'propagate6')]))
if __name__=='__main__':main()
