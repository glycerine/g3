from common import *
import watch_lookup_trials as wt,boolean_watch_cnf as bc,holdouts as ho,stage_frontier as sf
rd=d/'one-clause-view';rd.mkdir(exist_ok=True)
lg=pkg/'sat/sat_clause_large.go';testfile=pkg/'sat/sat_clause_view_test.go'
def edits(opts):
 ed=wt.edits(opts);cb=wt.cb;s=ed.get(cb,cb.read_text());pr=wt.pr;t=ed.get(pr,pr.read_text())
 s=once(s,'type satClauseView struct {\n\tsmall []byte\n\tlarge []uint32\n}','type satClauseView []byte')
 s=s.replace('satClauseView{small: data}','satClauseView(data)').replace('satClauseView{small:entry.data}','satClauseView(entry.data)').replace('satClauseView{large: a.large[r.slot].data}','satClauseView(a.large[r.slot].data)').replace('return satClauseView{}, e','return nil, e')
 k=s.index('func (v satClauseView) word(');end=s.index('func (v satClauseView) flag(',k)
 s=s[:k]+'''func (v satClauseView) word(i uint64) uint32 {return binary.LittleEndian.Uint32(v[i*4:])}
func (v satClauseView) setWord(i uint64,value uint32) {binary.LittleEndian.PutUint32(v[i*4:],value)}
func (v satClauseView) size() uint32{return v.word(1)}
func (v satClauseView) literal(i uint32) Literal{return Literal(v.word(5+uint64(i)))}
func (v satClauseView) setLiteral(i uint32,l Literal){v.setWord(5+uint64(i),uint32(l))}
'''+s[end:]
 assert s.count('i >= uint64(len(a.large[r.slot].data))')==2
 s=s.replace('i >= uint64(len(a.large[r.slot].data))','i >= uint64(len(a.large[r.slot].data))/4').replace('return a.large[r.slot].data[i], nil','return binary.LittleEndian.Uint32(a.large[r.slot].data[i*4:]),nil').replace('a.large[r.slot].data[i] = v','binary.LittleEndian.PutUint32(a.large[r.slot].data[i*4:],v)').replace('a.budget.Release(uint64(len(a.large[i].data)) * 4)','a.budget.Release(uint64(len(a.large[i].data)))')
 ed[lg]=lg.read_text().replace('[]uint32','[]byte').replace('int(bytes/4)','int(bytes)').replace('uint64(len(v.data)) * 4','uint64(len(v.data))')
 ed[testfile]=testfile.read_text().replace('word store','allocation').replace('make([]uint32, 9)','make([]byte, 9*4)').replace('view.large','view')
 if 'scan' in opts:
  key='n := clause.size()\n\t\t\t\tmoved := false\n\t\t\t\tfor j := uint32(2); j < n; j++ {\n\t\t\t\t\treplacement := clause.literal(j)\n\t\t\t\t\tif assignment[replacement.index()] == lbool.False {\n\t\t\t\t\t\tcontinue\n\t\t\t\t\t}\n\t\t\t\t\tclause.setLiteral(1, replacement)\n\t\t\t\t\tclause.setLiteral(j, not)'
  t=once(t,key,'replacement,moved:=clause.moveWatch(not,assignment);if moved{')
  key='moved = true\n\t\t\t\t\tkeep = false\n\t\t\t\t\tbreak\n\t\t\t\t}\n\t\t\t\tif moved {\n\t\t\t\t\tbreak\n\t\t\t\t}';t=once(t,key,'keep=false;break\n}')
  s+='''\nfunc (v satClauseView) moveWatch(not Literal, assignment []lbool.LBool)(Literal,bool){
 n:=v.size();if n<=2{return 0,false}
 rest:=v[28:20+4*uint64(n)]
 for len(rest)>=4 {r:=Literal(binary.LittleEndian.Uint32(rest));if assignment[r.index()]!=lbool.False{
 v.setLiteral(1,r);binary.LittleEndian.PutUint32(rest,uint32(not));return r,true
 };rest=rest[4:]}
 return 0,false
}\n'''
 if 'header' in opts:
  key='if c0 := clause.literal(0); c0 == not {\n\t\t\t\t\tclause.setLiteral(0, clause.literal(1))\n\t\t\t\t\tclause.setLiteral(1, c0)\n\t\t\t\t}\n\t\t\t\tc1 := clause.literal(1)'
  t=once(t,key,'c0,c1:=clause.watchPair(not)')
  t=once(t,'c0 := clause.literal(0)\n\t\t\t\tif assignment','if assignment')
  s+='''\nfunc(v satClauseView)watchPair(not Literal)(Literal,Literal){
 pair:=v[20:28];a:=Literal(binary.LittleEndian.Uint32(pair));b:=Literal(binary.LittleEndian.Uint32(pair[4:]));if a==not {binary.LittleEndian.PutUint32(pair,uint32(b));binary.LittleEndian.PutUint32(pair[4:],uint32(a));return b,a};return a,b
}\n'''
 ed[cb]=s
 if t!=pr.read_text():ed[pr]=t
 return ed
def main():
 old=wt.edits;oldrd=wt.rd
 # wt.buildmode resolves edits at call time; route the primitive changes to the original.
 def dispatch(opts):
  global saved
  nsed=edits
  return nsed(opts)
 vs=['unified','unified-header','unified-scan','unified-push-header-scan','unified-push-cache-header-scan']
 def buildmode(n):
  sd=rd/n;sd.mkdir(exist_ok=True);f=overlay(sd/'overlay',edits(n.split('-')));b=sd/'g3'
  with(w/'build.lock').open('a')as lk,(sd/'tests.log').open('w')as log:
   fcntl.flock(lk,fcntl.LOCK_SH)
   for tag,sel in [('', '.'),('g3debug','TestClauseView|TestSAT.*(Watch|Propagation|Clause)|TestSATStorage')]:
    cmd=['go','test','-count=1','-overlay='+str(f),'-run',sel,'./sat'];cmd=cmd[:2]+(['-tags='+tag]if tag else[])+cmd[2:];run(cmd,cwd=pkg,stdout=log,stderr=log)
   run(['go','build','-tags=xtrace_off','-p','4','-pgo=off','-buildvcs=false','-overlay='+str(f),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
  return b
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(buildmode,vs)))
 bs={'before':bc.rd/'before/g3',**bs}
 wt.rd=rd
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:wt.probe(j,bs),[(29,'pigeon8'),(1,'pigeon7'),(11,'planted5'),(35,'propagate6')]))
if __name__=='__main__':main()
