from common import *
import boolean_watch_cnf as bc,shlex
rd=d/'propagation-visit-counts';rd.mkdir(exist_ok=True)
keys='calls trail binary ternary clause external blocked looked_up swapped stale first_true scanned moved no_replacement conflict unit'.split();N=len(keys)
def cxx():
 orig=pkg.parent/'src/sat/sat_solver.cpp';s=orig.read_text()
 s=once(s,'namespace sat {', '''#include <cstdio>
namespace {
struct watch_visit_counters {
 unsigned long long counts[SIZE] = {};
 ~watch_visit_counters(){std::fprintf(stderr,"SAT-VISITS");for(auto v:counts)std::fprintf(stderr," %llu",v);std::fprintf(stderr,"\\n");}
};
thread_local watch_visit_counters visits;
}
namespace sat {'''.replace('SIZE',str(N)))
 a=s.index('bool solver::propagate_core(');e=s.index('\n    bool solver::propagate(',a);t=s[a:e]
 markers=[('calls','if (m_inconsistent)\n            return false;'),('trail','checkpoint();'),('binary','l1 = it->get_literal();'),('ternary','l1 = it->get_literal1();'),('clause','if (value(it->get_blocked_literal())'),('external','SASSERT(m_ext);'),('blocked','TRACE("propagate_clause_bug", tout << "blocked literal'),('looked_up','clause_offset cls_off = it->get_clause_offset();\n                    clause & c'),('stale','// Remark: this method'),('first_true','it2->set_clause(c[0], cls_off);'),('scanned','if (value(*l_it) != l_false)'),('moved','c[1]  = *l_it;'),('no_replacement','SASSERT(value(c[0]) == l_false ||'),('conflict','c.mark_used();\n                        CONFLICT_CLEANUP();'),('unit','m_stats.m_propagate++;')]
 for k,m in markers:t=once(t,m,f'++visits.counts[{keys.index(k)}]; '+m)
 t=once(t,'std::swap(c[0], c[1]);','{++visits.counts[8];std::swap(c[0], c[1]);}')
 source=rd/'sat_solver.cpp';source.write_text(s[:a]+t+s[e:]);builddir=pkg.parent/'build'
 ls=run(['make','-s','-n','-W','../src/sat/sat_solver.cpp','z3'],cwd=builddir,capture_output=True,text=True).stdout.splitlines()
 def cmd(expr):return shlex.split(next(l for l in ls if expr(l)))
 obj=rd/'sat_solver.o';lib=rd/'sat.a';b=rd/'z3'
 cc=cmd(lambda l:l.startswith('g++')and l.endswith(' ../src/sat/sat_solver.cpp'));cc[cc.index('-o')+1]=str(obj);cc[-1]=str(source)
 ar=cmd(lambda l:l.startswith('ar rcs sat/sat.a '));ar[2]=str(lib);ar[ar.index('sat/sat_solver.o')]=str(obj)
 ld=cmd(lambda l:l.startswith('g++') and '-o z3 'in l);ld[ld.index('-o')+1]=str(b);ld[ld.index('sat/sat.a')]=str(lib)
 with(rd/'native-build.log').open('w')as log:
  for c in(cc,ar,ld):run(c,cwd=builddir,stdout=log,stderr=log)
 return b
def gobuild():
 p=pkg/'sat/sat_solver_propagation.go';q=p.with_name('sat_solver_propagation_control.go');c=p.with_name('sat_clause_storage.go')
 s=p.read_text();a=s.index('func (s *satSolverPropagationState) propagateCore');b=s.index('\n}',a);t=s[a:b]
 markers=[('calls','if e := s.open();'),('trail','if e = s.checkpoint();'),('binary','l1 := Literal(w.val1)'),('ternary','l1, e := w.Literal1()'),('clause','blocked, e := w.BlockedLiteral()'),('external','if satStorageSourceDebug && !s.extensionPresent {'),('blocked','if tracing {\n\t\t\t\t\t\ts.traceBlockedClause'),('looked_up','off, e := w.ClauseOffset()'),('stale','if clause.flag(satClauseFlagRemoved) || c1 != not {\n'),('first_true','w.SetClause(c0, off)'),('moved','if moved {\n'),('no_replacement','value := assignment[c0.index()]'),('conflict','if value == lbool.False {\n'),('unit','s.clausePropagations++')]
 for k,m in markers:
  op=f's.studyVisits[{keys.index(k)}]++;'
  t=once(t,m,(m+op)if k in('stale','moved','conflict')else op+m)
 t=once(t,'c0, c1 := clause.watchedLiterals(not)','if clause.literal(0)==not{s.studyVisits[8]++};c0,c1:=clause.watchedLiterals(not)')
 t=once(t,'clause.moveWatch(not, assignment)','clause.moveWatch(not,assignment,&s.studyVisits[11])')
 t2=c.read_text();t2=once(t2,'moveWatch(falsified Literal, assignment []lbool.LBool)','moveWatch(falsified Literal, assignment []lbool.LBool,scanned *uint64)')
 t2=once(t2,'replacement := Literal(binary.LittleEndian.Uint32(rest))','*scanned++;replacement := Literal(binary.LittleEndian.Uint32(rest))')
 g=q.read_text();g=once(g,'import (','import ("fmt";"os";');g=once(g,'type satSolverPropagationState struct {','type satSolverPropagationState struct {\n studyVisits ['+str(N)+']uint64')
 g=once(g,'s.diffLevels.finalize()','if s.studyVisits[0]!=0{fmt.Fprint(os.Stderr,"SAT-VISITS");for _,v:=range s.studyVisits{fmt.Fprint(os.Stderr," ",v)};fmt.Fprintln(os.Stderr)};s.diffLevels.finalize()')
 o=overlay(rd/'overlay',{p:s[:a]+t+s[b:],q:g,c:t2});b=rd/'g3'
 with(w/'build.lock').open('a')as lk,(rd/'go-build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-tags=xtrace_off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 return b
def main():
 with ThreadPoolExecutor(2)as ex:
  jobs=[ex.submit(f)for f in(cxx,gobuild)];bs=dict(zip(('native','g3'),(f.result()for f in jobs)))
 with(rd/'counts.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['case','engine','result',*keys])
  for n,(p,expected)in bc.cases().items():
   for en,bin in bs.items():
    cp=run([bin,'-dimacs','-st',p],cwd=rd,env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True);assert cp.stdout.splitlines()[0]==expected;rows=[[int(x)for x in l.split()[1:]]for l in cp.stderr.splitlines()if l.startswith('SAT-VISITS')];assert rows and all(len(v)==N for v in rows),(en,n,cp.stderr);counts=list(map(sum,zip(*rows)));z.writerow([n,en,expected,*counts]);f.flush()
    if n=='pigeon8':print(en,n,counts,flush=True)
if __name__=='__main__':main()
