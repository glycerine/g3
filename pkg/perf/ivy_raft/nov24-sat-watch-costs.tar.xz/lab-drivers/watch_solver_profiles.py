from common import *
import collections
rd=d/'watch-solver-profiles';rd.mkdir(exist_ok=True)
rb=d/'boolean-watch-cnf';bs={'g3':rb/'before/g3','native':pkg.parent/'build/z3','compact24':rb/'inline24/g3','adaptive8':rb/'adaptive8/g3'}
def one(j):
 cpu,n,period=j;input=rb/'inputs'/(n+'.cnf');want='unsat'if n.startswith('pigeon')else'sat';counters={}
 for i in range(1,4):
  modes=list(bs)if n=='pigeon8'else['g3','native']
  for en in modes[(i-1)%len(modes):]+modes[:(i-1)%len(modes)]:
   b=bs[en];sd=rd/n/(str(i)+'-'+en);sd.mkdir(parents=True,exist_ok=True);rec=sd/'record'
   cmd=['taskset','-c',str(cpu),perf,'record','-q','--no-buildid','-e','instructions:u','-c',str(period),'-m','1024','--call-graph','dwarf,4096'if en=='native'else'fp','-o',rec,'--',b,'-st','-dimacs',input]
   p=subprocess.run(cmd,env=dict(env,GOMAXPROCS='1'),cwd=sd,capture_output=True)
   (sd/'stdout').write_bytes(p.stdout);(sd/'stderr').write_bytes(p.stderr);rs=p.stdout.decode().splitlines()
   assert rs and rs[0]==want,(n,en,p.returncode,rs[:3]);stats={k:int(v)for k,v in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])',p.stdout.decode())if not k.endswith('time')and 'memory'not in k}
   if n=='pigeon8':assert not counters or counters==stats,(en,counters,stats)
   counters=stats
   # PERF sample header separates stacks; frame names can contain spaces.
   hist=Counter();frames=[]
   with(sd/'decode.log').open('w')as log,subprocess.Popen([perf,'script','--no-inline','-F','comm,tid,event,ip,sym,dso','-i',rec],stdout=subprocess.PIPE,stderr=log,text=True,errors='replace')as proc:
    for line in proc.stdout:
     if not line.strip():
      if frames:hist[tuple(frames)]+=1;frames=[]
      continue
     m=re.match(r'^\s+[0-9a-f]+\s+(.+)\s+\(([^()]*)\)\s*$',line)
     if m:frames.append(re.sub(r'\+0x[\da-f]+$','',m[1]).removeprefix('github.com/glycerine/g3/pkg/'))
    if frames:hist[tuple(frames)]+=1
    assert proc.wait()==0 and hist and 'lost'not in (sd/'decode.log').read_text().lower(),(n,en)
   with gzip.open(sd/'stacks.csv.gz','wt')as f:
    w=csv.writer(f);w.writerow(['samples','period','stack']);w.writerows((v,period,'|'.join(k))for k,v in hist.items())
   rec.unlink();print(n,i,en,sum(hist.values()),flush=True)
def main():
 with ThreadPoolExecutor(3)as ex:list(ex.map(one,[(8,'pigeon8',1999993),(20,'planted5',100003),(37,'pigeon7',150011)]))
if __name__=='__main__':main()
