from common import *
import watch_solver_profiles as sp
rd=d/'remaining-watch-profiles';rd.mkdir(exist_ok=True)
sp.rd=rd;sp.bs={'g3':d/'sat-watch-production/g3-tree','native':pkg.parent/'build/z3','view-cache':d/'one-clause-view/unified-push-cache-header-scan/g3','move-word':d/'move-watch-words/move8/g3'}
with ThreadPoolExecutor(2)as ex:list(ex.map(sp.one,[(19,'pigeon8',1999993),(20,'pigeon7',250007)]))
