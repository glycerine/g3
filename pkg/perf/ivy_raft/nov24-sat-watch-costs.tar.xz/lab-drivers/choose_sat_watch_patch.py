from common import *
root=d/'one-clause-view/unified-push-header-scan/overlay';dest=d/'sat-watch-production';dest.mkdir(exist_ok=True)
def edits():
 ed={pkg/'sat'/f.name:f.read_text()for f in root.glob('*.go')}
 cb=pkg/'sat/sat_clause_storage.go';lg=cb.with_name('sat_clause_large.go');p=cb.with_name('sat_solver_propagation.go');w=cb.with_name('sat_solver_watch_lists.go');t=cb.with_name('sat_clause_view_test.go')
 # All clause headers consist of five 32-bit words in the same little-endian layout.
 s=ed[cb];ix=s.index('func (v satClauseView) moveWatch(');fn=s[ix:];s=s[:ix].rstrip()+'\n'
 ix=fn.index('func (v satClauseView) watchPair(');pair=fn[ix:];scan=fn[:ix]
 pair=pair.replace('watchPair(not Literal)','watchedLiterals(falsified Literal)').replace('a == not','a == falsified').replace('pair := v[20:28]','pair := v[satClauseLiteralsOffset : satClauseLiteralsOffset+8]')
 scan=scan.replace('moveWatch(not Literal,','moveWatch(falsified Literal,').replace('uint32(not)','uint32(falsified)').replace('rest := v[28 : 20+4*uint64(n)]','rest := v[satClauseLiteralsOffset+8 : satClauseLiteralsOffset+4*uint64(n)]').replace('r := Literal(binary.LittleEndian.Uint32(rest))','replacement := Literal(binary.LittleEndian.Uint32(rest))').replace('assignment[r.index()]','assignment[replacement.index()]').replace('v.setLiteral(1, r)','v.setLiteral(1, replacement)').replace('return r, true','return replacement, true')
 i=s.index('func (a *ClauseAllocator) allocate(n');s=s[:i]+'''// watchedLiterals places the falsified watch second, as expected by propagation.
'''+pair+'\n// moveWatch installs the first remaining literal that is true or unassigned.\n'+scan+s[i:];s=once(s,'type satClauseView []byte','const satClauseLiteralsOffset = 20\n\ntype satClauseView []byte')
 s=s.replace('return satClauseView(data), e','return data, e').replace('return satClauseView(a.large[r.slot].data), nil','return a.large[r.slot].data, nil')
 # The view comment belongs beside its type.
 s=once(s,'// satClauseView is one validated clause\'s words for the duration of one\n// propagation visit. Clause storage does not move while propagation runs.\nconst satClauseLiteralsOffset = 20\n\ntype satClauseView []byte', '''const satClauseLiteralsOffset = 5 * 4
// satClauseView borrows one clause for a propagation visit. Both allocators
// use the same little-endian header and literal words.
type satClauseView []byte''')
 ed[cb]=s
 # Preserve the original validation order: Get checks the destination before watch construction.
 s=ed[p].replace('clause.watchPair(not)','clause.watchedLiterals(not)').replace('if moved {\n\n','if moved {\n')
 s=once(s,'''nw, e := newSATClauseWatch(c0, off)
					if e != nil {
						return false, e
					}
					if e = v.watches.pushCurrent(replacement.Negated().index(), nw); e != nil {''','''if e = v.watches.pushClause(replacement.Negated().index(), c0, off); e != nil {''');ed[p]=s
 s=ed[w];i=s.index('// pushCurrent');s=s[:i].rstrip()+'\n'
 fn='''// pushClause moves an existing clause watch to the current destination list.
func (w *satSolverWatchLists) pushClause(i uint32, blocked Literal, offset satClauseOffset) error {
 if err:=w.open();err!=nil{return err}
 if err:=satWatchLogicalBounds(i,len(w.lists));err!=nil{return err}
 watch,err:=newSATClauseWatch(blocked,offset);if err!=nil{return err}
 record,err:=w.store.record(w.lists[i]);if err!=nil{return arena.ErrInvalidSlot}
 return record.push(watch)
}
'''
 i=s.index('type satSolverWatchListView struct');ed[w]=s[:i]+fn+'\n'+s[i:]
 st=cb.with_name('sat_solver_watch_store.go');s=st.read_text();i=s.index('old := x.values()',s.index('func (s *satSolverWatchStore) Push('));s=s[:i]+'''return x.push(w)
}
func (x *satSolverWatchListRecord) push(w satWatched) error {
 '''+s[i:];ed[st]=s
 s=ed[t];i=s.index('a.large = append');j=s.index('view, err := a.view(r)',i);s=s[:i]+'''r,err:=a.allocateLarge(9*4)
 if err!=nil{t.Fatal(err)}
 '''+s[j:];s=once(s,'t.Fatal("large word through checked path", got, err)\n\t}', '''t.Fatal("large word through checked path", got, err)
 }
 if err:=a.writeWord(r,7,101);err!=nil || view.literal(2)!=101{t.Fatal("checked wide write",err,view.literal(2))}
 if err:=a.releaseLarge(r);err!=nil{t.Fatal(err)}
 if _,err:=a.view(r);err==nil{t.Fatal("released wide clause accepted")}''');ed[t]=s
 return ed
def main():
 ed=edits();f=overlay(dest/'overlay',ed);b=dest/'g3'
 with(w/'build.lock').open('a')as lk,(dest/'validation.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for tag,sel,pk in [('', '.', ['sat','api']),('xtrace_off','.', ['sat','api']),('g3debug','Test(ClauseView|SAT.*(Clause|Watch|Propagation)|GroundInstance)',['sat','api']),('g3checked','Test(ClauseView|SAT.*(Clause|Watch|Propagation)|GroundInstance)',['sat','api'])]:
   run(['go','test','-p','4','-timeout=10m','-count=1','-overlay='+str(f),'-run',sel,*(['-tags='+tag]if tag else[]),*['./'+n for n in pk]],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','4','-pgo=off','-buildvcs=false','-tags=xtrace_off','-overlay='+str(f),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 print('checked normal and instrumented builds',flush=True)
if __name__=='__main__':main()
