from common import *
import random
rd=d/'boolean-watch-cnf';rd.mkdir(exist_ok=True)
def cases():
 inputs=rd/'inputs';inputs.mkdir(exist_ok=True);out={}
 def write(n,vars,cls,expected):
  p=inputs/(n+'.cnf');p.write_text(f'p cnf {vars} {len(cls)}\n'+''.join(' '.join(map(str,c))+' 0\n'for c in cls));out[n]=(p,expected)
 for width in (2,3,6):
  rng=random.Random(25519+width);N=12000;cls=[]
  for x in range(1,N):
   c=[-x,x+1]+[-z for z in rng.sample(range(1,N+1),width-2)]
   cls.append(c)
  # All-true satisfies the chain; neutral literals are only chosen from the already-forced prefix.
  cls=[[-i,i+1]+[-k for k in range(max(1,i-width+2),i)]for i in range(1,N)]
  rng.shuffle(cls);cls.append([1]);write('propagate'+str(width),N,cls,'sat')
 for width,n,m in ((3,768,2400),(5,6000,24000),(8,6000,36000)):
  rng=random.Random(920+width);cs=[]
  for _ in range(m):
   clause=[k if rng.randrange(2)else-k for k in rng.sample(range(1,n+1),width)]
   if all(x<0 for x in clause):clause[rng.randrange(width)]*=-1
   cs.append(clause)
  write('planted'+str(width),n,cs,'sat')
 for n in (7,8):
  cls=[];at=lambda i,j:1+i*n+j
  for i in range(n+1):cls.append([at(i,j)for j in range(n)])
  for j in range(n):
   for i in range(n+1):
    for k in range(i):cls.append([-at(i,j),-at(k,j)])
  write('pigeon'+str(n),n*(n+1),cls,'unsat')
 return out
def build_shell(v):
 q=rd/v;q.mkdir(exist_ok=True);b=q/'g3';cmd=['go','build','-p','5','-tags=xtrace_off','-pgo=off','-buildvcs=false','-mod=readonly'];overlayfile={'adaptive8':d/'adaptive-watch-lists/adaptive8','word8':d/'packed-watch-stream/word8','inline24':d/'compact-sat-watches/inline24'}.get(v)
 if overlayfile:cmd.append('-overlay='+str(overlayfile/'overlay/overlay.json'))
 with(w/'build.lock').open('a')as lock,(q/'build.log').open('w')as log:
  fcntl.flock(lock,fcntl.LOCK_SH);run([*cmd,'-o',b,'./cmd/g3'],env=env,cwd=pkg,stdout=log,stderr=log)
 return b
def one(j,bs):
 cpu,(n,(p,want))=j;sd=rd/n;sd.mkdir(exist_ok=True)
 with(sd/'runs.csv').open('w')as log:
  z=csv.writer(log);z.writerow('round engine cpu result instructions cycles wall'.split())
  names=list(bs)
  for i in range(5):
   for v in names[i%len(names):]+names[:i%len(names)]:
    st=time.monotonic();o=sd/(str(i+1)+'-'+v+'.stat');pr=subprocess.run(['taskset','-c',str(cpu),perf,'stat','-x,','-o',o,'-e','instructions:u,cycles:u','--',bs[v],'-dimacs',p],cwd=sd,env=dict(env,GOMAXPROCS='1'),capture_output=True,timeout=120)
    # DIMACS shells print s SATISFIABLE / UNSATISFIABLE and possibly a model.
    result=next((t.decode().strip().lower()for t in pr.stdout.splitlines() if t.startswith((b's ',b'sat',b'unsat'))),'')
    assert want in result and not (want=='sat' and 'unsat' in result),(n,v,pr.returncode,pr.stdout[:120],pr.stderr[:160])
    c=[int(x.split(',')[0])for x in o.read_text().splitlines()if 'instructions:u' in x or 'cycles:u'in x];z.writerow([i+1,v,cpu,result,*c,time.monotonic()-st]);log.flush()
  print(n,'done',flush=True)
def main():
 vs=['before','inline24','adaptive8','word8']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(build_shell,vs)))
 bs['native']=pkg.parent/'build/z3'
 job=list(zip([24,26,28,30,32,34,36,38],cases().items()))
 with ThreadPoolExecutor(3)as e:list(e.map(lambda j:one(j,bs),job))
if __name__=='__main__':main()
