from common import *
import watch_lookup_trials as wt
rd=d/'arena-inline-generation';rd.mkdir(exist_ok=True)
ab=pkg/'arena/small_bytes.go'
def edits(mode):
 x=ab.read_text()
 x=once(x,'page: page, length: size, capacity: size','page: page, length: size, capacity: uint32(g)')
 x=once(x,'offset: offset, length: size, capacity: capacity','offset: offset, length: size, capacity: uint32(g)')
 x=once(x,'class := d.capacity / a.config.Alignment\n\tc := &a.chunks[d.page]\n\tblock := d.offset / d.capacity','c := &a.chunks[d.page]\n class := c.class\n block := d.offset / (class*a.config.Alignment)')
 start=x.index('func (a *SmallBytes) Borrow');mid=x.index('{',start)+1;end=x.index('\n}',mid)
 original=x[mid:end]
 fast='''
 if !a.closed && r.Generation != 0 {
   s:=a.descriptors
   if uint32(r.Slot)-1 < s.slots {
    p,i:=s.location(r.Slot); records:=s.pages[p].records
    if i<uint32(len(records)) {
     d:=&records[i]
     if d.capacity==uint32(r.Generation) {
      end:=d.offset+d.length
      return a.chunks[d.page].data[d.offset:end:end],nil
     }
    }
   }
 }
 '''
 if mode=='cold':
  x=x[:mid]+fast+'return a.checkedBorrow(r)\n}\nfunc (a *SmallBytes) checkedBorrow(r SmallBytesRef)([]byte,error){'+original+x[end:]
 elif mode=='direct':
  x=x[:mid]+fast+'if a.closed{return nil,ErrClosed};if r==(SmallBytesRef{}){return nil,nil};return nil,ErrInvalidSlot'+x[end:]
 else:
  hoff=x.index('func (a *SmallBytes) descriptor');hm=x.index('{',hoff)+1;he=x.index('\n}',hm)
  x=x[:hm]+'''
  s:=a.descriptors
  if uint32(r.Slot)-1 < s.slots && r.Generation!=0 {
   p,i:=s.location(r.Slot);rs:=s.pages[p].records
   if i<uint32(len(rs)) && rs[i].capacity==uint32(r.Generation){return rs[i],nil}
  }
  return a.checkedDescriptor(r)
  }
  func(a *SmallBytes)checkedDescriptor(r SmallBytesRef)(vectorDescriptor,error){'''+x[hm:he]+x[he:]
 return {ab:x}
def buildmode(m):
 s=rd/m;s.mkdir(exist_ok=True);o=overlay(s/'overlay',edits(m));b=s/'g3'
 with(w/'build.lock').open('a')as lk,(s/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','4','-count=1','-overlay='+str(o),'./arena','./sat','./ast'],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','4','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 return b
if __name__=='__main__':
 modes=['cold','direct','descriptor']
 with ThreadPoolExecutor(2)as ex:bs={'before':d/'filter-production',**dict(zip(modes,ex.map(buildmode,modes)))}
 wt.rd=rd
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:wt.probe(j,bs),[(24,'pigeon8'),(18,'pigeon7'),(17,'planted5'),(47,'propagate6')]))
