from common import *
import holdouts as ho,stage_frontier as sf,macro_identity as mi,ground_release_controls as gc,production_triggers as pt,release_ground_pool as gp
import sys
sys.path.insert(0,str(pkg/'perf/ivy_raft'))
import watch_propagation as wp,quiet_wide_clauses as qw
from rotating_verification import ticks,idle,thread_siblings
rd=d/'release-arena-generation';rd.mkdir(exist_ok=True)
def buildtools():
 orig=subprocess.check_output(['git','show','2e46b8630:pkg/arena/small_bytes.go'],cwd=pkg,text=True)
 o=overlay(rd/'baseline',{pkg/'arena/small_bytes.go':orig})
 with(w/'build.lock').open('a')as lk,(rd/'build.log').open('w')as l:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for tag,ov in [('before',['-overlay='+str(o)]),('after',[])]:
   run(['go','test','-p','3','-tags=xtrace_off','-c','-o',rd/(tag+'.test'),*ov,'./arena'],cwd=pkg,stdout=l,stderr=l)
  run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-buildvcs=false','-o',rd/'g3','./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
def micro():
 with(rd/'borrow.csv').open('w')as f:
  z=csv.writer(f);z.writerow('size round engine operations ns_op instructions cycles allocs'.split())
  for size in [32,256]:
   for repeat in range(7):
    for ver in (('before','after')if repeat%2==0 else ('after','before')):
     o=rd/'micro.perf';r=run(['taskset','-c','42',perf,'stat','-x,','-e','instructions:u,cycles:u','-o',o,'--',rd/(ver+'.test'),'-test.run=^$','-test.bench=^BenchmarkSmallBytesBorrow$/^'+str(size)+'$','-test.benchtime=10000000x','-test.count=1'],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
     hit=re.search(r'BenchmarkSmallBytesBorrow/\d+\s+(\d+)\s+([\d.]+) ns/op\s+\d+ B/op\s+(\d+) allocs/op',r.stdout);assert hit,r.stdout[-500:];ct=[int(l.split(',')[0])for l in o.read_text().splitlines()if ':u'in l];z.writerow([size,repeat+1,ver,*hit.groups()[:2],*ct,hit[3]]);f.flush()
def shell():
 with(rd/'search.csv').open('w')as f:run([sys.executable,pkg/'perf/ivy_raft/watch_propagation.py','--rounds','3','--perf',perf,'--cpu','29',d/'filter-production',rd/'g3',pkg.parent/'build/z3'],stdout=f)
def unsat_trial(binary,c,siblings,src):
 before=ticks(siblings);start=time.monotonic()
 with (rd/'quiet-stdout').open('wb')as so,(rd/'quiet-stderr').open('wb')as se:
  with subprocess.Popen(['taskset','-c',str(c),binary,'-st','-dimacs',src],stdout=so,stderr=se,env=dict(env,GOMAXPROCS='1'))as proc:
   _,status,u=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
 wall=time.monotonic()-start;after=ticks(siblings);assert proc.returncode in (0,20) and not(rd/'quiet-stderr').stat().st_size
 return (rd/'quiet-stdout').read_text(),min((idle(before,after,x)for x in siblings),default=1),wall,u
def quiet():
 inp=next(t for t in wp.formulas()if t[0]=='pigeon8');src=rd/'quiet.cnf'
 with src.open('w')as f:
  print('p cnf',inp[1],len(inp[2]),file=f)
  for c in inp[2]:print(*c,0,file=f)
 ids=list(range(48));bs={'before':d/'filter-production','after':rd/'g3','native':pkg.parent/'build/z3'}
 sib={i:thread_siblings(i)for i in ids};names=list(bs);accepted=0;reference=None
 with(rd/'quiet.csv').open('w')as out:
  z=csv.writer(out);z.writerow('round attempt cpu engine idle sibling_idle occupancy wall user sys rss decisions conflicts'.split())
  for i in range(1,700):
   first=ticks(ids);time.sleep(.11);last=ticks(ids);free={cpu:idle(first,last,cpu)for cpu in ids};c=max(ids,key=lambda c:min(free[j]for j in [c,*sib[c]]))
   if min(free[j]for j in [c,*sib[c]])<.95:continue
   start=accepted%3
   for n in names[start:]+names[:start]:
    text,si,wall,u=unsat_trial(bs[n],c,sib[c],src);stats=wp.check_output(text,inp[3],inp[1],inp[2]);key=(stats['decisions'],stats['conflicts']);assert reference is None or key==reference;reference=key
    oc=(u.ru_utime+u.ru_stime)/wall;z.writerow([accepted+1,i,c,n,free[c],si,oc,wall,u.ru_utime,u.ru_stime,u.ru_maxrss,*key]);out.flush()
    if min(oc,si)<.95:break
   else:
    accepted+=1
    if accepted==7:return
 raise RuntimeError(('quiet rotations',accepted))
def integration():
 b=build(rd/'checker');(rd/'info.txt').write_text(linked(b));gc.d=rd;ho.root=rd;pt.root=rd;gp.rd=rd
 bs={'before':d/'base-clause-release/checker/goivy_check','after':b,'native':native}
 js=[(c,*j[1:])for c,j in zip([7,9,12,21],(j for j in sf.jobs()if j[1]in('tlb','hybrid','hermes_rmw_o3','ticket_protocol')))]+[(c,*j[1:5],j[-1])for c,j in zip([5,14,19,26],(j for j in mi.jobs()if j[1]in('rfn2','dramc_nb2','cf_live','raft_no_assume_test')))]+[(c,*j[1:])for c,j in zip([13,31,36],ho.jobs()[:3])]
 with ThreadPoolExecutor(13)as ex:
  fs=[ex.submit(gc.corpus,b),ex.submit(gp.memory)]+[ex.submit(ho.measure_spec,j,bs,3)for j in js]
  for f in fs:f.result()
def measurements():
 buildtools()
 with ThreadPoolExecutor(3)as ex:
  fs=[ex.submit(fn) for fn in (micro,shell,quiet)]
  for f in fs:f.result()
if __name__=='__main__':
 with ThreadPoolExecutor(2)as ex:
  fs=[ex.submit(fn)for fn in (integration,measurements)]
  for f in fs:f.result()
