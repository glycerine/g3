from common import *
import dense_sort_shapes as sh
rd=d/'dense-sort-ordered';rd.mkdir(exist_ok=True);p=sh.p
base=(d/'sat-dense-sort/noscan/overlay/sat_solver_clause_core.go').read_text()
def make(v):
 sd=rd/v;sd.mkdir(exist_ok=True);s=base;x='if len(values) >= 16 && satSortDense(values) {\n\t\treturn\n\t}'
 if v=='ordinary':s=p.read_text()
 elif v!='mask':
  body='''if len(values)>=16{
  i:=1;for i<len(values)&&values[i-1]<=values[i]{i++};if i==len(values){return}
  DESC
  MASK
  }'''
  rev='''if i==1&&values[len(values)-1]<=values[1]{for i<len(values)&&values[i-1]>=values[i]{i++};if i==len(values){for l,r:=0,len(values)-1;l<r;l,r=l+1,r-1{values[l],values[r]=values[r],values[l]};return}}'''
  s=once(s,x,body.replace('DESC',rev if v in('both','only-order')else'').replace('MASK','if satSortDense(values){return}'if v!='only-order'else''))
 if v=='quick-reject':
  x='lo, hi := uint32(63), uint32(0)';s=once(s,x,'if uint32(values[len(values)-1])-base>=4096 || uint32(values[len(values)/2])-base>=4096{return false};'+x)
 o=overlay(sd/'overlay',{p:s,sh.test:sh.bench})
 with(w/'build.lock').open('a')as lk,(sd/'go.log').open('w')as l:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-c','-overlay='+str(o),'-o',sd/'sat.test','./sat'],cwd=pkg,stdout=l,stderr=l);run([sd/'sat.test','-test.run=^TestStudySortMatchesOrdinary$'],stdout=l,stderr=l)
 return sd/'sat.test'
def main():
 names=['ordinary','mask','ascending','both','only-order','quick-reject']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(names,ex.map(make,names)))
 def lane(c,n):
  with(rd/('instr-'+str(n)+'.csv')).open('w')as f:
   wr=csv.writer(f);wr.writerow('round version words shape iterations instructions cycles ns_per_op allocs'.split())
   for i in range(3):
    for shape in sh.bench.split('var studySortShapes=[]string{')[1].split('}')[0].replace('"','').split(','):
     for v in names[i:]+names[:i]:
      reps=8000 if n>=256 else 24000;pf=rd/(str(c)+'.tmp')
      r=run(['taskset','-c',str(c),perf,'stat','-x,','-o',pf,'-e','instructions:u,cycles:u','--',bs[v],'-test.run=^$','-test.bench=^BenchmarkStudyLiteralOrder$/^'+str(n)+'$/^'+shape+'$','-test.benchtime='+str(reps)+'x','-test.cpu=1','-test.benchmem'],capture_output=True,text=True)
      a=re.search(r'^Benchmark\S+\s+\d+\s+([\d.]+) ns/op\s+\d+ B/op\s+(\d+) allocs/op',r.stdout,re.M);assert a,r.stdout;ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];wr.writerow([i+1,v,n,shape,reps,*ct,*a.groups()]);f.flush()
   print(n,'finished',flush=True)
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:lane(*j),[(3,16),(10,64),(22,256),(26,1024)]))
if __name__=='__main__':main()
