from common import *
import ground_release_controls as gc,stage_frontier as sf,holdouts as ho
rd=d/'clause-input-release';rd.mkdir(exist_ok=True)
bins={'before':d/'clause-construct-release/g3','sort':d/'dense-sort-production','both':d/'window-sort-release','native':pkg.parent/'build/z3'}
def shell(c,cs):
 with(rd/f'wide-{c}.csv').open('w')as f:
  run([sys.executable,pkg/'perf/ivy_raft/wide_clauses.py','--rounds','3','--perf',perf,'--cpu',str(c),*[x for v,b in bins.items()for x in ['--solver',v,b]],*[x for width,count in cs for x in ['--case',str(width),str(count)]]],stdout=f)
def pigeon():
 with(rd/'search.csv').open('w')as f:run([sys.executable,pkg/'perf/ivy_raft/watch_propagation.py','--cpu','9','--rounds','3','--perf',perf,bins['before'],bins['both'],bins['native']],stdout=f)
def ivy():
 b=build(rd/'checker');(rd/'info.txt').write_text(linked(b));gc.d=rd;ho.root=rd;bs={'before':d/'clause-construct-release/checker/goivy_check','both':b,'native':native}
 js=[(c,*j[1:])for c,j in zip([5,8,10,26],(j for j in sf.jobs()if j[1]in('tlb','hybrid','hermes_rmw_o3','ticket_protocol')))]
 with ThreadPoolExecutor(5)as ex:
  fs=[ex.submit(gc.corpus,b)]+[ex.submit(ho.measure_spec,j,bs,3)for j in js]
  for f in fs:f.result()
if __name__=='__main__':
 with ThreadPoolExecutor(6)as ex:
  fs=[ex.submit(pigeon),ex.submit(ivy)]+[ex.submit(shell,c,cs)for c,cs in [(3,[(256,4096),(512,4096)]),(1,[(64,65536),(128,8192)]),(22,[(16,16384),(32,16384)]),(4,[(2,8192),(3,4096)])]]
  for f in fs:f.result()
