from common import *
import resource
sys.path.insert(0,str(pkg/'perf/ivy_raft'));from wide_clauses import clauses,check_output
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));from rotating_verification import ticks,idle
rd=d/'quiet-dimacs';rd.mkdir(exist_ok=True)
bs={'before':d/'clause-construct-release/g3','after':d/'window-sort-release','native':pkg.parent/'build/z3'}
def trial(width,count):
 out=rd/f'{width}-{count}';out.mkdir(exist_ok=True);p=out/'input.cnf';ids=list(range(48))
 with p.open('w')as f:
  print('p cnf',1024,count,file=f)
  for row in clauses(1024,width,count):print(*row,0,file=f)
 models=set();reference={};tries=good=0;ns=list(bs)
 with(out/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('width count round attempt cpu engine pre_idle sibling_idle occupancy wall user sys rss decisions conflicts mk_clause'.split())
  while good<7:
   a=ticks(ids);time.sleep(.7);b=ticks(ids);free={c:min(idle(a,b,c),idle(a,b,c+24))for c in range(24)}
   c=max(free,key=free.get)
   if free[c]<.95:continue
   tries+=1;ok=True
   for v in ns[good%3:]+ns[:good%3]:
    so=out/'latest.stdout';se=out/'latest.stderr';sib=ticks([c+24]);start=time.monotonic()
    with so.open('wb')as o,se.open('wb')as e:
     sub=subprocess.Popen(['taskset','-c',str(c),bs[v],'-st','-dimacs',p],stdout=o,stderr=e,env=dict(env,GOMAXPROCS='1',GOGC='100'));_,ret,usage=os.wait4(sub.pid,0);sub.returncode=os.waitstatus_to_exitcode(ret)
    wall=time.monotonic()-start;si=idle(sib,ticks([c+24]),c+24);oc=(usage.ru_utime+usage.ru_stime)/wall;txt=so.read_text();ls=txt.splitlines();assert sub.returncode in (0,10) and ls[0]=='sat' and not se.stat().st_size
    stats=check_output(txt,'sat',1024,()if ls[1]in models else clauses(1024,width,count));models.add(ls[1]);key=(stats['decisions'],stats.get('conflicts',0),stats['mk-clause']);assert reference.setdefault('counts',key)==key and key[2]==count
    z.writerow([width,count,good+1,tries,c,v,free[c],si,oc,wall,usage.ru_utime,usage.ru_stime,usage.ru_maxrss,*key]);f.flush()
    if min(si,oc)<.95:ok=False;break
   if ok:good+=1
   if ok or tries%10==0:print(width,tries,good,flush=True)
 p.unlink()
if __name__=="__main__":
 for width,n in [(512,16384),(64,131072),(128,32768),(16,65536)]:trial(width,n)
