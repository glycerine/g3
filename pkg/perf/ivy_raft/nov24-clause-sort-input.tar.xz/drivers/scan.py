from common import *
rd=d/'dimacs-buffer-cases';rd.mkdir(exist_ok=True);p=pkg/'sat/dimacs.go';q=pkg/'sat/dimacs_parse.go';test=pkg/'sat/dimacs_buffer_trial_test.go'
testsrc=r'''package sat
import("bytes";"bufio";"strings";"io";"testing")
type dimacsTrialReader struct {data []byte; max,empty int; finish bool}
func(r *dimacsTrialReader)Read(p []byte)(int,error){if r.empty>0{r.empty--;return 0,nil};if len(r.data)==0{return 0,io.EOF};n:=copy(p,r.data[:min(len(r.data),r.max)]);r.data=r.data[n:];if len(r.data)==0&&r.finish{return n,io.ErrUnexpectedEOF};return n,nil}
func TestStudyDIMACSBufferCases(t *testing.T){
 for _,size:=range []int{1,3,7,64,4096}{for _,extra:=range []int{0,1,2,15,63,4092,4094,4095,4096}{for _,finish:=range []bool{false,true}{s:="c"+strings.Repeat("a",extra)+"\n-23 +4294967298-5 0\v62 0";v,e:=ReadDIMACSCNF(&dimacsTrialReader{[]byte(s),size,1,finish});if e!=nil||v.VariableCount!=62||len(v.Clauses)!=2||len(v.Clauses[0])!=3||v.Clauses[0][0]!= -23||v.Clauses[0][1]!=2||v.Clauses[0][2]!= -5{t.Fatal(size,extra,finish,v,e)}}}}
 s:="1-3 0\n23 xRemainder";for _,n:=range []int{4096,8192}{r:=bufio.NewReaderSize(strings.NewReader(s),n);_,e:=ReadDIMACSCNF(r);if e==nil{t.Fatal("missing error")};if e=r.UnreadByte();e!=nil{t.Fatal("consumed lookahead",e)};left,e:=io.ReadAll(r);if e!=nil||string(left)!="xRemainder"{t.Fatalf("%d unread %q %v",n,left,e)}}
}
func BenchmarkStudyDIMACSScan(b *testing.B){for _,buf:=range []bool{false,true}{n:="raw";if buf{n="buffered"};b.Run(n,func(b *testing.B){data:=bytes.Repeat([]byte("13 -75 122 +742 909-313 0\n"),1000);b.ReportAllocs();b.SetBytes(int64(len(data)));b.ResetTimer();for i:=0;i<b.N;i++{var r io.Reader=bytes.NewReader(data);if buf{r=bufio.NewReader(r)};s:=newDIMACSStreamBuffer(r);sum:=int32(0);for s.value != -1{s.skipWhitespace();if s.value== -1{break};v,e:=s.parseInt();if e!=nil{b.Fatal(e)};sum+=v};if sum==0{b.Fatal(sum)}}})}}
'''
def make(v):
 src=p.read_text();qq=q.read_text()
 if v!='old':
  src=once(src,'literals = literals[:0]\n\tfor {','literals = literals[:0]\nvar n uint32\n\tfor {')
  x='n, err := solver.sourceNumVars()\n\t\tif err != nil {\n\t\t\treturn literals, err\n\t\t}'
  src=once(src,x,'if n==0{n,err=solver.sourceNumVars();if err!=nil{return literals,err}}')
 if v=='peek':
  x="var value uint32\n\tfor b.value >= '0' && b.value <= '9' {\n\t\tvalue = value*10 + uint32(b.value-'0')\n\t\tb.advance()\n\t}"
  src=once(src,x,'''value:=uint32(b.value-'0')
   for{
    buf,_:=b.input.Peek(b.input.Buffered());i:=0
    for i<len(buf) && uint32(buf[i]-'0')<10{value=value*10+uint32(buf[i]-'0');i++}
    if i>0{_,_=b.input.Discard(i)}
    b.advance();if b.value<'0'||b.value>'9'{break};value=value*10+uint32(b.value-'0')
   }''')
 if v.startswith('window')or v=='own':
  s=(d/'wide-input-scan/digits/overlay/dimacs.go').read_text()
  x='b.advance()\n\treturn b';s=once(s,x,'if existing,ok:=input.(*bufio.Reader);ok&&existing==b.input{b.shared=true};'+x)
  s=once(s,'taken  int','taken  int\nshared bool')
  s=once(s,'_, _ = b.input.Discard(b.taken)','_,_=b.input.Discard(b.taken);b.taken=0')
  i=s.index('func (b *dimacsStreamBuffer) skipWhitespace')
  s=s[:i]+'''// Synchronize a caller-owned buffered reader before invoking a solver callback or returning.
func(b *dimacsStreamBuffer)syncInput(){
 if !b.shared||b.taken==0{return};n:=b.taken-len(b.window);b.taken=0;b.window=nil
 if n>0{_,_=b.input.Discard(n-1);_,_=b.input.ReadByte()}
}
'''+s[i:]
  s=once(s,'buffer := newDIMACSStreamBuffer(input)','buffer := newDIMACSStreamBuffer(input);defer buffer.syncInput()')
  qq=once(qq,'buffer := newDIMACSStreamBuffer(input)','buffer := newDIMACSStreamBuffer(input);defer buffer.syncInput()')
  s=once(s,'if _, err = solver.MkVar','b.syncInput();if _, err = solver.MkVar')
  s=once(s,'if err = solver.MkClause','buffer.syncInput();if err = solver.MkClause')
  if v=='own':
   x='b.taken = b.input.Buffered()';s=once(s,x,'''if !b.shared{n:=b.input.Buffered();b.window,_=b.input.Peek(n);b.taken=n;return true};'''+x)
  src=s
 sd=rd/v;sd.mkdir(exist_ok=True);o=overlay(sd/'overlay',{p:src,q:qq,test:testsrc})
 with(w/'build.lock').open('a')as lk,(sd/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-p','2','-overlay='+str(o),'-o',sd/'sat.test','./sat'],cwd=pkg,stdout=log,stderr=log);run([sd/'sat.test','-test.run=DIMACS'],stdout=log,stderr=log);run(['go','build','-p','2','-pgo=off','-tags=xtrace_off','-overlay='+str(o),'-o',sd/'g3','./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 return sd/'g3'
def main():
 vs=['old','known','peek','window'];bs={}
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(make,vs)))
 def micro():
  with(rd/'scan.csv').open('w')as f:
   z=csv.writer(f);z.writerow('round version reader ns bytes allocs'.split())
   for i in range(5):
    for v in vs[i%4:]+vs[:i%4]:
     r=run(['taskset','-c','9',rd/v/'sat.test','-test.run=^$','-test.bench=^BenchmarkStudyDIMACSScan$','-test.cpu=1','-test.benchtime=200x','-test.benchmem'],capture_output=True,text=True)
     a=re.findall(r'^BenchmarkStudyDIMACSScan/(\S+)\s+\d+\s+(\S+) ns/op\s+\S+ MB/s\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout,re.M);assert len(a)==2,r.stdout;z.writerows([i+1,v,*x]for x in a);f.flush()
 def wide(c,cs):
  with(rd/f'shell-{c}.csv').open('w')as f:run([sys.executable,pkg/'perf/ivy_raft/wide_clauses.py','--rounds','3','--perf',perf,'--cpu',str(c),*[x for k,b in {**bs,'native':pkg.parent/'build/z3'}.items()for x in['--solver',k,b]],*[x for width,n in cs for x in ['--case',str(width),str(n)]]],stdout=f)
 with ThreadPoolExecutor(3)as ex:
  fs=[ex.submit(micro),ex.submit(wide,21,[(64,65536),(256,4096)]),ex.submit(wide,1,[(16,16384),(3,4096)])]
  for f in fs:f.result()
if __name__=='__main__':main()
