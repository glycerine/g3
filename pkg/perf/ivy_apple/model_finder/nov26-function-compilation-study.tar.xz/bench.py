from pathlib import Path
import csv,re,subprocess,sys
w=Path(__file__).resolve().parent
engines=sys.argv[1:]
wr=csv.writer(sys.stdout,lineterminator='\n');wr.writerow(('round','engine','fixture','records','ns_per_op','bytes_per_op','allocs_per_op'))
for i in range(9):
 for engine in engines[i%len(engines):]+engines[:i%len(engines)]:
  bin=w/{'base':'base-bench','scan':'bench','lookup':'lookup-bench'}[engine]
  run=subprocess.run(['taskset','-c','16',bin,'-test.run','^$','-test.bench','^BenchmarkSMTModelFinder(SharedGroundArguments|AUFGraph)$','-test.cpu=1','-test.benchtime=16x'],capture_output=True,text=True,check=True)
  matches=re.findall(r'^BenchmarkSMTModelFinder(\S+)\s+16\s+(\d+) ns/op\s+([\d.]+) records/op\s+(\d+) B/op\s+(\d+) allocs/op',run.stdout,re.M)
  if len(matches)!=8:raise ValueError(run.stdout)
  for name,ns,records,b,allocs in matches:wr.writerow((i+1,engine,name,records,ns,b,allocs))
  sys.stdout.flush()
