from pathlib import Path
import json,subprocess,os
p=Path.cwd();w=p/'build/.candidate-model';old=p/'build/.boolean-enode-cost';src=p/'smtcore/smt_model_finder_auf_graph.go'
s=src.read_text().replace('flat := g.finder.flatQuantifier(quantifier)','key := smtModelFinderAUFKey{quantifier, variable}\n if node := g.uvars[key]; node != nil {return node,nil}\n flat := g.finder.flatQuantifier(quantifier)',1).replace('g.node(g.uvars, smtModelFinderAUFKey{quantifier, variable}, sort)','g.node(g.uvars, key, sort)')
i=s.index('sort, err := g.finder.manager.GetDomain');j=s.index('return g.node(g.arguments',i)
s=s[:i]+'''key := smtModelFinderAUFKey{function, position}
    if node := g.arguments[key]; node != nil { return node,nil }
    sort,err := g.finder.manager.GetDomain(function,position)
    if err!=nil {return nil,err}
    if g.argumentLayout == nil {g.argumentLayout = ast.NewObjMap(g.finder.manager)}
    h,err:=g.finder.manager.GetHash(function)
    if err!=nil{return nil,err}
    g.argumentLayout.InsertPairIfNotThere(function, uint64(position), uhash.Combine(h, position))
    '''+s[j:]
i=s.index('if node := index[key]');j=s.index('node, err := newSMT',i);s=s[:i]+s[j:]
dst=w/'lookup.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'lookup.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',old/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'lookup-goivy','./cmd/goivy_check'],cwd=old/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
