from pathlib import Path
import json,subprocess,os
p=Path.cwd(); w=p/'build/.candidate-model'; old=p/'build/.boolean-enode-cost'
graph=p/'smtcore/smt_model_finder_auf_graph.go'
node=p/'smtcore/smt_model_finder_auf_node.go'
repl={}
for f in (graph,node):
    s=f.read_text()
    if f==node:
        s=s.replace('type smtModelFinderAUFNode struct {','type smtModelFinderAUFNode struct {\n populated bool')
    else:
        i=s.index('for _, application := range context.declarationEnodes')
        s=s[:i]+'''if info.offset.IsNull() {
        if node.populated {return nil}
        node.populated=true
    }
    '''+s[i:]
    dst=w/f.name;dst.write_text(s);repl[str(f)]=str(dst)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':repl}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',old/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'trial-goivy','./cmd/goivy_check'],cwd=old/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
