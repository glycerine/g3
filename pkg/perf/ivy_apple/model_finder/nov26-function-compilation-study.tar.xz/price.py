"""Build a profiling-only split of function compilation after the local cache miss."""
import json, os, subprocess
from pathlib import Path
root=Path.cwd(); w=Path(__file__).resolve().parent; old=root/'build/.boolean-enode-cost'
core=root/'smtcore/smt_model_table.go'; checker=root/'smtcore/smt_model_checker.go'
s=core.read_text().replace('type tableModel struct {','type tableModel struct {\n priced map[ast.ASTHandle]bool')
s=s.replace('g.functionIDs[decl] = -1','''if g.priced[decl] {return g.repeatedFunction(decl,arity,depth)}
    id,err:=g.buildFunction(decl,arity,depth)
    if err==nil && !g.incomplete {g.priced[decl]=true}
    return id,err
}

//go:noinline
func (g *tableModel) repeatedFunction(decl ast.ASTHandle, arity uint32, depth int) (int,error) {
    return g.buildFunction(decl,arity,depth)
}

//go:noinline
func (g *tableModel) buildFunction(decl ast.ASTHandle, arity uint32, depth int) (int,error) {
    g.functionIDs[decl] = -1''')
t=checker.read_text().replace('tableScratch     *tableModel','priced map[ast.ASTHandle]bool\n tableScratch *tableModel')
needle='if err := model.Compress(); err != nil {'
assert t.count(needle)==1
t=t.replace(needle,'c.priced=make(map[ast.ASTHandle]bool); defer func(){ c.priced=nil; if c.tableScratch!=nil {c.tableScratch.priced=nil} }()\n '+needle)
t=t.replace('status, bindings, err := c.tableScratch.check','c.tableScratch.priced=c.priced\n status, bindings, err := c.tableScratch.check')
repl={}
for f,code in ((core,s),(checker,t)):
 dst=w/('price-'+f.name);dst.write_text(code);repl[str(f)]=str(dst)
ov=w/'price.json';ov.write_text(json.dumps({'Replace':repl}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',old/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'price-goivy','./cmd/goivy_check'],cwd=old/'frontend/goivy',check=True,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'))
