"""Instruction samples inside first and repeated function builds during hybrid model checks."""
from pathlib import Path
from collections import Counter
import csv,os,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent
gold=p/'build/.bool-scan/golden/reference/hybrid'
examples=Path('/home/jaten/ivy/ivy-lang-examples')
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(examples/'ivy/include'),XTRACE_OFF='1')
writer=csv.writer(sys.stdout,lineterminator='\n');writer.writerow(('round','first','repeated_rows','repeated_empty','outside_function','all_process'))
for i in range(1,7):
 raw=w/f'width-{i}.data'
 run=subprocess.run(['taskset','-c','16',perf,'record','-B','-N','-e','instructions:u','-c','1000003','--call-graph','fp,48','-o',raw,'--',w/'width-goivy',examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],env=env,cwd=w,capture_output=True,check=True)
 log=run.stderr.splitlines(keepends=True)
 if run.stdout!=(gold/'stdout').read_bytes() or b''.join(line for line in log if not line.startswith(b'[ perf record:'))!=(gold/'stderr').read_bytes():raise ValueError(log[-4:])
 records=subprocess.check_output([perf,'report','-D','-i',raw])
 if b'PERF_RECORD_LOST' in records or b'PERF_RECORD_THROTTLE' in records:raise ValueError(raw)
 stacks=subprocess.check_output([perf,'script','--no-inline','-i',raw],text=True)
 c=Counter()
 for sample in stacks.split('\n\n'):
  if len(sample.splitlines())<2:continue
  c['all']+=1
  if '(*SMTQuantifierManager).CheckModel' not in sample or '(*tableModel).compile' not in sample:continue
  # Frames run from leaf to root. Attribute the innermost build when fallbacks nest.
  frames=sample.splitlines()
  idx=next((j for j,f in enumerate(frames) if '(*tableModel).buildFunction+' in f),None)
  if idx is None:c['outside']+=1
  elif idx+1<len(frames) and '(*tableModel).repeatedEmpty+' in frames[idx+1]:c['empty']+=1
  elif idx+1<len(frames) and '(*tableModel).repeatedFunction+' in frames[idx+1]:c['repeat']+=1
  else:c['first']+=1
 writer.writerow((i,c['first'],c['repeat'],c['empty'],c['outside'],c['all']));sys.stdout.flush()
