# Quantifier fingerprint lifetime and table storage

Use g3 commit d5e0fc735 as the baseline. The Go benchmarks and regression tests are in smtcore. To replay a table variant, apply its patch with patch -p1 in a copy of the pkg directory and build a test binary there.

    go test -pgo=off -c -o /tmp/fingerprint.test ./smtcore
    /tmp/fingerprint.test -test.cpu=1 -test.run='^$' -test.bench='^BenchmarkSMTFingerprintTupleMemory$' -test.benchtime=1x

Each worker trial keeps 64 independent managers and 256 tuples per manager. Run the binary in a fresh process for each sample. The release comparison rotates baseline and production on CPU 28. The live and one-result columns are heap differences after a full Go collection. Ordinary cases pop the scope and retain the table for reuse. ResetWithCollisions resets the entire table while retaining the newest result, using distinct enodes with one owner for a deliberately identical bucket hash.

The final-layout record-roots trial is the layout in the release. Its retained table stores one pointer and an integer link in insertion order. Record uses the same layout and always builds its scratch tuple. Wide puts the integer link in the returned result. Side stores links in a third slice. Indexed7 uses 32-bit positions. Linear and triangular probing are open-addressed alternatives. Baseline is called before in raw files and original in workers/release.csv.

The census records each table's insertion count, highest live size, histogram at the first occurrence of that size and total histogram. The instrumentation emits FPSET events for a new table, insert, scope pop and reset. Vector lengths count bound variables. The six standalone solver files are the exact Apple enumeration captures distributed with the November 24 rewrite-resource replay. Run g3 and in-tree Z3 with -st -smt2 and GOMAXPROCS=1 for g3. The micro studies rotated CPU-pinned processes and compared the answer and every integer solver statistic except memory, allocation and timing counters. The per-run CSV retains decisions, conflicts, instantiations and resource counts along with hardware retired user instructions and cycles.

Whole-verifier comparisons use GoIvy 832e392ef with a local module replacement, -pgo=off -tags=xtrace_off and GOMAXPROCS=1 during execution. CPU and spec appear beside each row. Comparisons require the same exit and both full output streams as their reference. Nonzero exits on negative specs are expected. The matching allocations row contains total bytes allocated, number of allocations and number of collections in the process. These measurements include the frontend. The four comparisons below each include three rotations per standalone solver input and five rotations per listed complete short verifier. Long whole-verifier timings are outside these matrices.

Study matrix counts

{
  "fingerprint-arity-layout": {
    "whole": 220,
    "kernel": 90
  },
  "fingerprint-open-tables": {
    "whole": 210,
    "kernel": 144
  },
  "fingerprint-wide-index": {
    "whole": 120,
    "kernel": 90
  },
  "fingerprint-final-layout": {
    "whole": 275,
    "kernel": 108
  }
}
