; GoIvy dramc_nb2 verification condition 71. Source ord_live.ivy, Copyright 2023 Apple, Inc. See LICENSE.txt.
(declare-sort lclock 0)
(declare-datatypes ((op_type 0)) (((nop) (write) (read) (rrsp) (wr_cmp))))
(declare-sort proc 0)
(declare-sort tar_cf_clock 0)
(declare-datatypes ((mem_loc_type 0)) (((mem_loc_init) (mem_memc) (pio_memc))))
(declare-datatypes ((loc_type 0)) (((init_l) (cf_mem_l) (cf_pio_l) (cf_cmp_l) (if_l) (memc_l) (dramc_l) (arm_l))))
(declare-sort tar_clock 0)
(declare-sort index 0)
(declare-datatypes ((ph_type 0)) (((nop_ph) (wr_ph) (rd_ph) (cpl_ph))))
(declare-datatypes ((op_ack_type 0)) (((nGnRnE) (nGnRE) (nGRE) (_GRE) (normal))))
(declare-sort addr_type 0)
(declare-sort mem_type 0)
(declare-fun dramc_nb2.evma (lclock mem_type addr_type) Bool)
(declare-fun ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun ref.evs.l_req (lclock) loc_type)
(declare-fun ref.evs.req (lclock) op_type)
(declare-fun dramc_nb2.evqual_wr (lclock mem_type addr_type) Bool)
(declare-fun dramc_nb2.memc_arriving.value () lclock)
(declare-fun dramc_nb2.memc_arriving.now () Bool)
(declare-fun dramc_nb2.push_success_wr (mem_type addr_type) Bool)
(declare-fun dramc_nb2.memc_pushing.value () lclock)
(declare-fun dramc_nb2.memc_pushing.now () Bool)
(declare-fun dramc_nb2.push_trying_wr (mem_type addr_type) Bool)
(declare-fun dramc_nb2.evqual_rd (lclock mem_type addr_type) Bool)
(declare-fun dramc_nb2.push_success_rd (mem_type addr_type) Bool)
(declare-fun dramc_nb2.push_trying_rd (mem_type addr_type) Bool)
(declare-fun ref.evs.a (lclock) addr_type)
(declare-fun ref.evs.m (lclock) mem_type)
(declare-fun ref.evs.l_cmp (lclock) loc_type)
(declare-fun ref.evs.cmp (lclock) op_type)
(declare-fun rfn.evcomplete (lclock) Bool)
(declare-fun rfn.evqual (mem_type lclock) Bool)
(declare-fun cf_live.issued_memc (lclock) Bool)
(declare-fun ref.nGnR (op_ack_type) Bool)
(declare-fun ref.evs.op_ack (lclock) op_ack_type)
(declare-fun ref.nGR (op_ack_type) Bool)
(declare-fun ref.dev (lclock) Bool)
(declare-fun ref.both_nGR (lclock lclock) Bool)
(declare-fun ref.both_nGnR (lclock lclock) Bool)
(declare-fun ref.both_normal (lclock lclock) Bool)
(declare-fun ref.same_attr (lclock lclock) Bool)
(declare-fun ref.mem_memc_exception (lclock lclock) Bool)
(declare-fun ref.evs.p (lclock) proc)
(declare-fun |<:lclock:lclock| (lclock lclock) Bool)
(declare-fun ref.evs.serialized (lclock) Bool)
(declare-fun ref.prevents (lclock lclock) Bool)
(declare-fun __m_l2s_d_e (tar_cf_clock) Bool)
(declare-fun cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun l2s_d (tar_cf_clock) Bool)
(declare-fun __l2s_d_d (tar_cf_clock) Bool)
(declare-fun ref.lt_tar_cf () tar_cf_clock)
(declare-fun __m_l2s_d_d (addr_type) Bool)
(declare-fun _A () addr_type)
(declare-fun l2s_d (addr_type) Bool)
(declare-fun __m_l2s_d_c (mem_type) Bool)
(declare-fun _M () mem_type)
(declare-fun l2s_d (mem_type) Bool)
(declare-fun __m_l2s_d_b (lclock) Bool)
(declare-fun l2s_d (lclock) Bool)
(declare-fun __m_l2s_d_a (lclock) Bool)
(declare-fun __m_l2s_d (lclock) Bool)
(declare-fun cfabric.t_rd_min () lclock)
(declare-fun __l2s_d_c (lclock) Bool)
(declare-fun ref.lt () lclock)
(declare-fun |__new_loc:ordser| () Bool)
(declare-fun |__new_loc:wr| () Bool)
(declare-fun |__fml:ph| () ph_type)
(declare-fun __ts0_c () Bool)
(declare-fun |__new_loc:rd| () Bool)
(declare-fun __ts0__ts0_d_a () Bool)
(declare-fun ___old_l2s_g_2 (lclock) Bool)
(declare-fun __ts0__ts0new__old_l2s_g_2_b_a (lclock) Bool)
(declare-fun ___old_l2s_g_1 (lclock) Bool)
(declare-fun __ts0__ts0new__old_l2s_g_1_b_a (lclock) Bool)
(declare-fun |__new_loc:mem_loc| () mem_loc_type)
(declare-fun __ts0__ts0__ts0_c_a () Bool)
(declare-fun |__fml:y_a_a_a| () lclock)
(declare-fun __ts0__ts0__ts0__ts0__new_cfabric.t_rd_min_a_a_a_a () lclock)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| () lclock)
(declare-fun __ref.evs.l_req (lclock) loc_type)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_wr_c_a
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_rd_c_a
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_rfn.evqual_b_a (mem_type lclock) Bool)
(declare-fun __ts0__ts0__m_cf_live.issued_memc_a_a (lclock) Bool)
(declare-fun __ts0__ts0__m_ref.prevents_e_a (lclock lclock) Bool)
(declare-fun __ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_wr_b_a
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_rd_b_a
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_rfn.evcomplete_a (lclock) Bool)
(declare-fun __ts0__ts0__m_rfn.evqual_a_a (mem_type lclock) Bool)
(declare-fun __ts0__ts0__m_cf_live.issued_memc_b (lclock) Bool)
(declare-fun __ts0__ts0__m_ref.mem_memc_exception_b_a (lclock lclock) Bool)
(declare-fun __ref.evs.serialized (lclock) Bool)
(declare-fun __ts0__ts0__m_ref.prevents_d_a (lclock lclock) Bool)
(declare-fun __m_l2s_g_2 (lclock) Bool)
(declare-fun __ts0__ts0new__old_l2s_g_2_a_a (lclock) Bool)
(declare-fun __m_l2s_g_1 (lclock) Bool)
(declare-fun __ts0__ts0new__old_l2s_g_1_a_a (lclock) Bool)
(declare-fun __m_l2s_g_0_b (lclock) Bool)
(declare-fun __ts0__ts0new__old_l2s_g_0_b_a (lclock) Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.evma_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_wr_a_a
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_success_wr_a_a
             (mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_trying_wr_a_a
             (mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_rd_a_a
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_success_rd_a_a
             (mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_trying_rd_a_a
             (mem_type addr_type)
             Bool)
(declare-fun __ref.evs.a (lclock) addr_type)
(declare-fun __ts0__ts0__m_ref.mem_memc_exception_a_a (lclock lclock) Bool)
(declare-fun __ts0__ts0__m_ref.prevents_c_a (lclock lclock) Bool)
(declare-fun __dramc_nb2.evma (lclock mem_type addr_type) Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_wr_d
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_success_wr_b
             (mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_trying_wr_b (mem_type addr_type) Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.evqual_rd_d
             (lclock mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_success_rd_b
             (mem_type addr_type)
             Bool)
(declare-fun __ts0__ts0__m_dramc_nb2.push_trying_rd_b (mem_type addr_type) Bool)
(declare-fun __ref.evs.m (lclock) mem_type)
(declare-fun __ts0__ts0__m_rfn.evqual_c (mem_type lclock) Bool)
(declare-fun __ts0__ts0__m_ref.mem_memc_exception_c (lclock lclock) Bool)
(declare-fun __ts0__ts0__m_ref.prevents_b_a (lclock lclock) Bool)
(declare-fun __m_l2s_g_9_a () Bool)
(declare-fun __m_l2s_g_5_a () Bool)
(declare-fun __ts0__ts0__m_l2s_w_4_b () Bool)
(declare-fun __ts0__ts0__m_l2s_w_4_a_a () Bool)
(declare-fun __m_l2s_g_6_a () Bool)
(declare-fun __ts0__ts0__m_l2s_w_3_b () Bool)
(declare-fun __ts0__ts0__m_l2s_w_3_a_a () Bool)
(declare-fun __m_l2s_g_10 () Bool)
(declare-fun __ts0__ts0new__old_l2s_g_10_a_a () Bool)
(declare-fun __m_l2s_g_9 () Bool)
(declare-fun __ts0__ts0new__old_l2s_g_9_a_a () Bool)
(declare-fun __m_l2s_g_6 () Bool)
(declare-fun __ts0__ts0new__old_l2s_g_6_a_a () Bool)
(declare-fun __m_l2s_g_5 () Bool)
(declare-fun __ts0__ts0new__old_l2s_g_5_a_a () Bool)
(declare-fun __m_l2s_g_0_a (lclock) Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_0_a_a (lclock) Bool)
(declare-fun __ref.mem_memc_exception (lclock lclock) Bool)
(declare-fun __ref.evs.cmp (lclock) op_type)
(declare-fun __ts0__ts0__m_ref.prevents_a_a (lclock lclock) Bool)
(declare-fun __l2s_w_0 (lclock) Bool)
(declare-fun __ts0__ts0__m_l2s_w_0_a (lclock) Bool)
(declare-fun __l2s_g_2 (lclock) Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_2_a (lclock) Bool)
(declare-fun __l2s_g_1 (lclock) Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_1_a (lclock) Bool)
(declare-fun __m_l2s_g_0 (lclock) Bool)
(declare-fun __ts0__ts0new__old_l2s_g_0_a_a (lclock) Bool)
(declare-fun __ref.evs.req (lclock) op_type)
(declare-fun __ts0__ts0__m_ref.prevents_f (lclock lclock) Bool)
(declare-fun __l2s_w_4 () Bool)
(declare-fun __l2s_w_3 () Bool)
(declare-fun __l2s_g_10 () Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_10_a () Bool)
(declare-fun __l2s_g_9 () Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_9_a () Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_6_a () Bool)
(declare-fun __l2s_g_5 () Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_5_a () Bool)
(declare-fun __l2s_g_0 (lclock) Bool)
(declare-fun __ts0__ts0__m__old_l2s_g_0_b (lclock) Bool)
(declare-fun |__ts0__ts0__new_fml:l_a| () loc_type)
(declare-fun |__ts0__ts0__new_fml:mem_loc_a| () mem_loc_type)
(declare-fun |__fml:a| () addr_type)
(declare-fun |__ts0__ts0__new_fml:a_a_a| () addr_type)
(declare-fun |__fml:m| () mem_type)
(declare-fun |__ts0__ts0__new_fml:m_a_a| () mem_type)
(declare-fun |__new_loc:op_ack| () op_ack_type)
(declare-fun |__ts0__ts0__new_fml:op_ack_a| () op_ack_type)
(declare-fun |__ts0__ts0__new_fml:op_a| () op_type)
(declare-fun |__fml:p| () proc)
(declare-fun |__ts0__ts0__new_fml:p_a_a_a| () proc)
(declare-fun __ref.lt_tar_cf () tar_cf_clock)
(declare-fun |__ts0__ts0__ts0__new_fml:x_a| () tar_cf_clock)
(declare-fun |__ts0__ts0__new_fml:lt_a| () lclock)
(declare-fun |__ts0__ts0__new_fml:p_a_b| () proc)
(declare-fun __ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun __cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun __ts0_b_a () Bool)
(declare-fun |__fml:y_a_a| () tar_cf_clock)
(declare-fun __isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0__ts0_a_a_b () Bool)
(declare-fun __ref.evs.lt_arr (lclock) tar_clock)
(declare-fun |0:tar_clock| () tar_clock)
(declare-fun ref.evs.lt_arr (lclock) tar_clock)
(declare-fun __ts0__m_dramc_nb2.evqual_wr_c_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.evqual_rd_c_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_rfn.evqual_b_a (mem_type lclock) Bool)
(declare-fun __ts0__m_cf_live.issued_memc_a_a (lclock) Bool)
(declare-fun __ts0__m_ref.prevents_e_a (lclock lclock) Bool)
(declare-fun |__ts0__new_fml:l_a| () loc_type)
(declare-fun ___old_l2s_g_0 (lclock) Bool)
(declare-fun __m_l2s_g_0_c (lclock) Bool)
(declare-fun _old_l2s_g_0 (lclock) Bool)
(declare-fun __ts0__m_dramc_nb2.evqual_wr_b_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.evqual_rd_b_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_rfn.evcomplete_a (lclock) Bool)
(declare-fun __ts0__m_rfn.evqual_a_a (mem_type lclock) Bool)
(declare-fun __ts0__m_cf_live.issued_memc_b (lclock) Bool)
(declare-fun __ts0__m_ref.mem_memc_exception_b_a (lclock lclock) Bool)
(declare-fun __ts0__m_ref.prevents_d_a (lclock lclock) Bool)
(declare-fun l2s_g_2 (lclock) Bool)
(declare-fun __ts0__m_l2s_w_0_a (lclock) Bool)
(declare-fun l2s_w_0 (lclock) Bool)
(declare-fun |__ts0__new_fml:mem_loc_a| () mem_loc_type)
(declare-fun __ts0new__old_l2s_g_2_a_a (lclock) Bool)
(declare-fun __ts0new__old_l2s_g_1_a_a (lclock) Bool)
(declare-fun __ts0new__old_l2s_g_0_b_a (lclock) Bool)
(declare-fun __ts0__m_dramc_nb2.evma_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.evqual_wr_a_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_success_wr_a_a (mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_trying_wr_a_a (mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.evqual_rd_a_a (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_success_rd_a_a (mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_trying_rd_a_a (mem_type addr_type) Bool)
(declare-fun __ts0__m_ref.mem_memc_exception_a_a (lclock lclock) Bool)
(declare-fun __ts0__m_ref.prevents_c_a (lclock lclock) Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun __ts0__m_l2s_w_4_a_a () Bool)
(declare-fun l2s_w_4 () Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun __ts0__m_l2s_w_3_a_a () Bool)
(declare-fun l2s_w_3 () Bool)
(declare-fun |__ts0__new_fml:a_a_a| () addr_type)
(declare-fun ___old_l2s_g_10 () Bool)
(declare-fun __m_l2s_g_10_a () Bool)
(declare-fun _old_l2s_g_10 () Bool)
(declare-fun ___old_l2s_g_9 () Bool)
(declare-fun _old_l2s_g_9 () Bool)
(declare-fun ___old_l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun ___old_l2s_g_5 () Bool)
(declare-fun _old_l2s_g_5 () Bool)
(declare-fun __ts0__m_dramc_nb2.evqual_wr_d (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_success_wr_b (mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_trying_wr_b (mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.evqual_rd_d (lclock mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_success_rd_b (mem_type addr_type) Bool)
(declare-fun __ts0__m_dramc_nb2.push_trying_rd_b (mem_type addr_type) Bool)
(declare-fun __ts0__m_rfn.evqual_c (mem_type lclock) Bool)
(declare-fun __ts0__m_ref.mem_memc_exception_c (lclock lclock) Bool)
(declare-fun __ts0__m_ref.prevents_b_a (lclock lclock) Bool)
(declare-fun __ts0__m_l2s_w_4_b () Bool)
(declare-fun __ts0__m_l2s_w_3_b () Bool)
(declare-fun |__ts0__new_fml:m_a_a| () mem_type)
(declare-fun __ts0new__old_l2s_g_10_a_a () Bool)
(declare-fun __ts0new__old_l2s_g_9_a_a () Bool)
(declare-fun __ts0new__old_l2s_g_6_a_a () Bool)
(declare-fun __ts0new__old_l2s_g_5_a_a () Bool)
(declare-fun __ts0__m__old_l2s_g_0_a_a (lclock) Bool)
(declare-fun __ref.evs.op_ack (lclock) op_ack_type)
(declare-fun |__ts0__new_fml:op_ack_a| () op_ack_type)
(declare-fun __ts0__m_ref.prevents_a_a (lclock lclock) Bool)
(declare-fun __ts0__m__old_l2s_g_2_a (lclock) Bool)
(declare-fun __ts0__m__old_l2s_g_1_a (lclock) Bool)
(declare-fun __ts0new__old_l2s_g_0_a_a (lclock) Bool)
(declare-fun __ts0__m_ref.prevents_f (lclock lclock) Bool)
(declare-fun |__ts0__new_fml:op_a| () op_type)
(declare-fun __ts0__m__old_l2s_g_10_a () Bool)
(declare-fun __ts0__m__old_l2s_g_9_a () Bool)
(declare-fun __ts0__m__old_l2s_g_6_a () Bool)
(declare-fun __ts0__m__old_l2s_g_5_a () Bool)
(declare-fun __ts0__m__old_l2s_g_0_b (lclock) Bool)
(declare-fun __ref.evs.p (lclock) proc)
(declare-fun |__ts0__new_fml:p_a_a_a| () proc)
(declare-fun |__fml:y_a| () lclock)
(declare-fun __ts0__ts0__new_cfabric.t_rd_min_a_a () lclock)
(declare-fun __ref.lt () lclock)
(declare-fun |__ts0__new_fml:x_a| () lclock)
(declare-fun __cfabric.t_rd_min () lclock)
(declare-fun __isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun |__ts0__new_fml:lt_a| () lclock)
(declare-fun |__ts0__new_fml:p_a_b| () proc)
(declare-fun |__fml:y| () lclock)
(declare-fun |__ts0__new_fml:x| () lclock)
(declare-fun |__new_loc:ordser16| () Bool)
(declare-fun |__new_loc:ordser15| () Bool)
(declare-fun |__new_loc:ordser14| () Bool)
(declare-fun |__new_loc:ordser13| () Bool)
(declare-fun |__new_loc:ordser12| () Bool)
(declare-fun |__new_loc:ordser11| () Bool)
(declare-fun |__new_loc:ordser10| () Bool)
(declare-fun |__new_loc:ordser9| () Bool)
(declare-fun |__new_loc:ordser8| () Bool)
(declare-fun |__new_loc:ordser7| () Bool)
(declare-fun |__new_loc:ordser6| () Bool)
(declare-fun |__new_loc:ordser5| () Bool)
(declare-fun |__new_loc:ordser4| () Bool)
(declare-fun |__new_loc:ordser3| () Bool)
(declare-fun |__new_loc:ordser2| () Bool)
(declare-fun |__new_loc:ordser1| () Bool)
(declare-fun |__new_loc:ordser0| () Bool)
(declare-fun |__new_loc:pio_new| () Bool)
(declare-fun __ref.dev (lclock) Bool)
(declare-fun |__new_loc:dev| () Bool)
(declare-fun |__new_loc:dram_new| () Bool)
(declare-fun |__fml:mem_loc_arg| () mem_loc_type)
(declare-fun __ts0__ts0_c_a () Bool)
(declare-fun |__fml:choose_op_ack| () op_ack_type)
(declare-fun __ts0__ts0__ts0_b_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0_a_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0_a_a () Bool)
(declare-fun __ts0_e () Bool)
(declare-fun |__loc:tt| () lclock)
(declare-fun __ts0__ts0_b () Bool)
(declare-fun __ts0__ts0_a_a_a () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0__ts0_a_a () Bool)
(declare-fun |__m_loc:rd| () Bool)
(declare-fun |__m_loc:wr| () Bool)
(declare-fun __l2s_d_b (addr_type) Bool)
(declare-fun __l2s_d_a (mem_type) Bool)
(declare-fun __l2s_d (proc) Bool)
(declare-fun l2s_d (proc) Bool)
(declare-fun __dramc_nb2.evqual_wr (lclock mem_type addr_type) Bool)
(declare-fun __dramc_nb2.push_success_wr (mem_type addr_type) Bool)
(declare-fun __dramc_nb2.push_trying_wr (mem_type addr_type) Bool)
(declare-fun __dramc_nb2.evqual_rd (lclock mem_type addr_type) Bool)
(declare-fun __dramc_nb2.push_success_rd (mem_type addr_type) Bool)
(declare-fun __dramc_nb2.push_trying_rd (mem_type addr_type) Bool)
(declare-fun __rfn.evcomplete (lclock) Bool)
(declare-fun __rfn.evqual (mem_type lclock) Bool)
(declare-fun __cf_live.issued_memc (lclock) Bool)
(declare-fun __ref.both_nGR (lclock lclock) Bool)
(declare-fun __ref.both_nGnR (lclock lclock) Bool)
(declare-fun __ref.both_normal (lclock lclock) Bool)
(declare-fun __ref.prevents (lclock lclock) Bool)
(declare-fun |<:tar_cf_clock:tar_cf_clock| (tar_cf_clock tar_cf_clock) Bool)
(declare-fun |0:tar_cf_clock| () tar_cf_clock)
(declare-fun tar_cf_clock.succ (tar_cf_clock tar_cf_clock) Bool)
(declare-fun |<:tar_clock:tar_clock| (tar_clock tar_clock) Bool)
(declare-fun tar_clock.succ (tar_clock tar_clock) Bool)
(declare-fun |0:lclock| () lclock)
(declare-fun lclock.succ (lclock lclock) Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun |0:index| () index)
(declare-fun index.succ (index index) Bool)
(declare-fun dramc.wr_fair (mem_type) Bool)
(declare-fun dramc.rd_fair (mem_type) Bool)
(declare-fun rfn.abs.begun (mem_type tar_clock) Bool)
(declare-fun ref.lt_tar (mem_type) tar_clock)
(declare-fun rfn.abs.queue (mem_type tar_clock) Bool)
(declare-fun rfn.abs.done (mem_type tar_clock) Bool)
(declare-fun rfn.abs.lastq (mem_type) tar_clock)
(declare-fun rfn.abs.trying2.now (mem_type) Bool)
(declare-fun rfn.abs.trying1.now (mem_type) Bool)
(declare-fun ref.pio (lclock) Bool)
(declare-fun isd.rsp (proc mem_type addr_type lclock) Bool)
(declare-fun ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun ref.same_addr (lclock lclock) Bool)
(declare-fun ref.evs.lt_tar (lclock) tar_clock)
(declare-fun dramc.t_min (mem_type) tar_clock)
(declare-fun __cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun __ref.pio (lclock) Bool)
(declare-fun __ref.same_addr (lclock lclock) Bool)
(declare-fun __cmpl_live.arm_cpl (lclock) Bool)
(declare-fun cmpl_live.arm_cpl (lclock) Bool)
(declare-fun __cmpl_live.cf_cpl (lclock) Bool)
(declare-fun cmpl_live.cf_cpl (lclock) Bool)
(declare-fun l2s_g_1 (lclock) Bool)
(declare-fun __e2e.issued (lclock mem_type addr_type) Bool)
(declare-fun e2e.issued (lclock mem_type addr_type) Bool)
(declare-fun __cf_pio_live.issued_pio_memc (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_memc (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_if (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_if (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio (lclock) Bool)
(declare-fun cf_pio_live.issued_pio (lclock) Bool)
(declare-fun l2s_g_10 () Bool)
(declare-fun l2s_g_0 (lclock) Bool)
(declare-fun __e2e.issued_to_cf (proc lclock) Bool)
(declare-fun e2e.issued_to_cf (proc lclock) Bool)
(declare-fun __ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun __cmpl_live.retired (lclock) Bool)
(declare-fun cmpl_live.retired (lclock) Bool)
(declare-fun __ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun |__loc:tt_a| () lclock)
(declare-fun __ts0_a () Bool)
(declare-fun |__loc:aa| () addr_type)
(declare-fun |__loc:mm| () mem_type)
(declare-fun |__loc:pp| () proc)
(declare-fun __ts0_d () Bool)
(declare-fun l2s_w_2 () Bool)
(declare-fun l2s_w_1 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_init_7 () Bool)
(declare-fun l2s_init_8 () Bool)
(declare-fun l2s_init_6 () Bool)
(declare-fun l2s_init_5 () Bool)
(declare-fun l2s_init_0 (lclock) Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_init_4 () Bool)
(declare-fun l2s_init_3 () Bool)
(declare-fun l2s_init_2 () Bool)
(declare-fun l2s_s_1 () Bool)
(declare-fun l2s_s_0 (lclock) Bool)
(declare-fun l2s_init_1 (lclock) Bool)
(declare-fun l2s_a (lclock) Bool)
(assert (let ((a!1 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (__ref.evs.a |T:lclock|) _A))))
               (=> (and (not l2s_init_7) (or (not l2s_waiting) (not __l2s_w_4)))
                   (=> a!1
                       (or (= |T:lclock| __ref.lt)
                           (|<:lclock:lclock| |T:lclock| __ref.lt)))))))
      (a!2 (forall ((|T:lclock| lclock))
             (=> (or (= |T:lclock| __ref.lt)
                     (|<:lclock:lclock| |T:lclock| __ref.lt))
                 (and (__l2s_d_c |T:lclock|)))))
      (a!3 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (__ref.evs.a |T:lclock|) _A))))
               (=> (and (not l2s_init_7) (not l2s_waiting))
                   (=> (not (=> a!1 false)) (and (l2s_a |T:lclock|)))))))
      (a!4 (forall ((|T:lclock| lclock))
             (=> (and (not l2s_init_7) l2s_saved)
                 (=> (not (l2s_s_0 |T:lclock|)) (and (l2s_a |T:lclock|))))))
      (a!5 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (__ref.evs.a |T:lclock|) _A))))
               (=> (and l2s_saved (l2s_s_0 |T:lclock|)) (=> a!1 false)))))
      (a!6 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (__ref.evs.a |T:lclock|) _A))))
               (=> (and (not (l2s_s_0 |T:lclock|))
                        (not false)
                        l2s_saved
                        (not l2s_init_7)
                        (not (__l2s_w_0 |T:lclock|)))
                   (and (not (l2s_s_0 |T:lclock|)) (=> a!1 false))))))
      (a!7 (=> (and true (not l2s_waiting)) (=> (not (=> true false)) true)))
      (a!8 (or (not (forall ((|T:lclock| lclock)) (l2s_s_0 |T:lclock|)))))
      (a!9 (not (and (not l2s_init_7) (or (not l2s_waiting) (not __l2s_w_4)))))
      (a!11 (=> (and (not l2s_init_7) (or (not l2s_waiting) (not __l2s_w_4)))
                __l2s_g_5))
      (a!12 (and (=> (and l2s_init_5 l2s_init_6)
                     (forall ((|T:lclock| lclock)) (l2s_init_0 |T:lclock|)))))
      (a!14 (forall ((|T:lclock| lclock) (|Tarr:tar_cf_clock| tar_cf_clock))
              (let ((a!1 (exists ((|\|T:lclock\|!1| lclock))
                           (and (= (__ref.evs.req |\|T:lclock\|!1|) read)
                                (= (__ref.evs.l_req |\|T:lclock\|!1|) cf_mem_l)
                                (= (__ref.evs.lt_arr_cf |\|T:lclock\|!1|)
                                   __cfabric.t_rd_arr_min)))))
                (=> (and (= __cfabric.t_rd_arr_min |Tarr:tar_cf_clock|)
                         (= (__ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l))
                    a!1))))
      (a!15 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.req |T:lclock|) read)
                       (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                       (= |T:lclock| __ref.lt))
                  (= (__ref.evs.lt_arr_cf |T:lclock|) __ref.lt_tar_cf))))
      (a!16 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (not (= (__ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!17 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= (__ref.evs.lt_arr_cf |T:lclock|) __ref.lt_tar_cf)
                        (|<:tar_cf_clock:tar_cf_clock|
                          (__ref.evs.lt_arr_cf |T:lclock|)
                          __ref.lt_tar_cf))))))
      (a!18 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc))
                  (or (= (__ref.evs.lt_arr_cf |T:lclock|) __ref.lt_tar_cf)
                      (|<:tar_cf_clock:tar_cf_clock|
                        (__ref.evs.lt_arr_cf |T:lclock|)
                        __ref.lt_tar_cf)))))
      (a!19 (forall ((|T:lclock| lclock))
              (or (= (__ref.evs.lt_arr_cf |T:lclock|) __ref.lt_tar_cf)
                  (|<:tar_cf_clock:tar_cf_clock|
                    (__ref.evs.lt_arr_cf |T:lclock|)
                    __ref.lt_tar_cf))))
      (a!20 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (or (= (__ref.evs.l_req |T:lclock|) memc_l)
                                  (= (__ref.evs.l_req |T:lclock|) dramc_l)))))
              (let ((a!2 (and (or a!1 (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!2
                    (|<:tar_cf_clock:tar_cf_clock|
                      (__ref.evs.lt_arr_cf |T:lclock|)
                      __cfabric.t_rd_arr_min))))))
      (a!21 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (__ref.evs.req |T0:lclock|) read)
                       (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                       (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (__ref.evs.req |T1:lclock|) read)
                       (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)
                       (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_cf_clock:tar_cf_clock|
                    (__ref.evs.lt_arr_cf |T0:lclock|)
                    (__ref.evs.lt_arr_cf |T1:lclock|)))))
      (a!22 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (and (= (__ref.evs.req |T:lclock|) nop)
                                   (= (__ref.evs.cmp |T:lclock|) nop)))))
                (=> (and (= __ref.lt |T:lclock|)
                         (not (= |T:lclock| |0:lclock|)))
                    a!1))))
      (a!23 (forall ((|T:lclock| lclock))
              (=> (or (|<:lclock:lclock| __ref.lt |T:lclock|)
                      (= |T:lclock| |0:lclock|))
                  (and (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|)
                       (= (__ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|)))))
      (a!24 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= __cfabric.t_rd_arr_min
                           (__ref.evs.lt_arr_cf |T:lclock|))
                        (|<:tar_cf_clock:tar_cf_clock|
                          __cfabric.t_rd_arr_min
                          (__ref.evs.lt_arr_cf |T:lclock|)))))))
      (a!25 (forall ((|T:lclock| lclock))
              (not (and (= (__ref.evs.req |T:lclock|) read)
                        (= (__ref.evs.l_req |T:lclock|) cf_mem_l)))))
      (a!26 (forall ((|T:lclock| lclock))
              (and (= (__ref.evs.req |T:lclock|) nop)
                   (= (__ref.evs.cmp |T:lclock|) nop))))
      (a!27 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (not (= (__ref.evs.mem_loc |T:lclock|) mem_memc)))))
              (let ((a!2 (or (and (= (__ref.evs.req |T:lclock|) nop)
                                  (= (__ref.evs.cmp |T:lclock|) nop))
                             (= (__ref.evs.req |T:lclock|) write)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             a!1)))
                (=> a!2 (= (__ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!28 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T1:lclock|) read)
                              (not (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)))))
              (let ((a!2 (and (= (__ref.evs.req |T0:lclock|) read)
                              (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                              (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  a!1
                                  (= (__ref.evs.req |T1:lclock|) nop)))))
                (=> a!2
                    (not (= (__ref.evs.lt_arr_cf |T1:lclock|)
                            __cfabric.t_rd_arr_min)))))))
      (a!29 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1 (not (|<:lclock:lclock| |T:lclock| __cfabric.t_rd_min))))))
      (a!30 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                              (not (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
                    (a!2 (=> (and (= (__ref.evs.req |T:lclock|) read)
                                  (= (__ref.evs.mem_loc |T:lclock|) mem_memc))
                             (= (__ref.evs.l_req |T:lclock|) cf_mem_l))))
              (let ((a!3 (and (or (= (__ref.evs.cmp |T:lclock|) nop)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                                  a!1)
                              a!2)))
                (=> (|<:lclock:lclock| __cfabric.t_rd_min |T:lclock|) a!3)))))
      (a!31 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.req |T:lclock|) write)
                             (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (__ref.evs.cmp |T:lclock|) rrsp))))
                (=> a!1 (not (= __cfabric.t_rd_min |0:lclock|))))))
      (a!32 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) write)
                              (or (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                                  (= (__ref.evs.l_req |T:lclock|) cf_pio_l)))))
                (=> a!1 (not (= |T:lclock| __cfabric.t_rd_min))))))
      (a!33 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (not (and (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)))))
              (let ((a!2 (or (= (__ref.evs.req |T1:lclock|) write)
                             (and (= (__ref.evs.req |T1:lclock|) read) a!1)
                             (= (__ref.evs.req |T1:lclock|) nop))))
                (=> (and (= (__ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2)
                    (not (= |T1:lclock| __cfabric.t_rd_min)))))))
      (a!34 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.req |T:lclock|) write)
                             (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (__ref.evs.cmp |T:lclock|) rrsp))))
                (=> (and a!1 (= (__ref.evs.mem_loc |T:lclock|) pio_memc))
                    (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!35 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (__ref.evs.a |T:lclock|) |A:addr_type|)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|))))))
      (a!36 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (__ref.evs.a |T:lclock|) |A:addr_type|)
                              (not (= (__ref.evs.l_req |T:lclock|) dramc_l)))))
                (=> a!1 (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!37 (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (dramc.t_min |M:mem_type|) |0:tar_clock|))))))
      (a!38 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T0:lclock|) read))
                              (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) read))
                              (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (= (__ref.evs.a |T0:lclock|)
                                 (__ref.evs.a |T1:lclock|))))
                    (a!2 (or (|<:tar_clock:tar_clock|
                               (__ref.evs.lt_arr |T0:lclock|)
                               (dramc.t_min (__ref.evs.m |T0:lclock|)))
                             (|<:tar_clock:tar_clock|
                               (__ref.evs.lt_arr |T1:lclock|)
                               (dramc.t_min (__ref.evs.m |T0:lclock|))))))
                (=> a!1 (not a!2)))))
      (a!39 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) read)
                  (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!40 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) write)
                  (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!41 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) nop)
                  (= (__ref.evs.l_req |T:lclock|) init_l))))
      (a!42 (forall ((|T:lclock| lclock))
              (or (= (__ref.evs.req |T:lclock|) read)
                  (= (__ref.evs.req |T:lclock|) write)
                  (= (__ref.evs.req |T:lclock|) nop))))
      (a!43 (forall ((|T:lclock| lclock))
              (or (= (__ref.evs.cmp |T:lclock|) rrsp)
                  (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (__ref.evs.cmp |T:lclock|) nop))))
      (a!44 (forall ((|T:lclock| lclock))
              (=> (not (= (__ref.evs.req |T:lclock|) nop))
                  (= (__ref.evs.cmp |T:lclock|) nop))))
      (a!45 (forall ((|T:lclock| lclock))
              (=> (not (= (__ref.evs.cmp |T:lclock|) nop))
                  (= (__ref.evs.req |T:lclock|) nop))))
      (a!46 (forall ((|T:lclock| lclock))
              (let ((a!1 (forall ((|A:addr_type| addr_type)
                                  (|M:mem_type| mem_type)
                                  (|P:proc| proc))
                           (not (or (__isd.wr |P:proc|
                                              |M:mem_type|
                                              |A:addr_type|
                                              |T:lclock|)
                                    (__isd.rd |P:proc|
                                              |M:mem_type|
                                              |A:addr_type|
                                              |T:lclock|))))))
                (=> a!1
                    (and (= (__ref.evs.l_req |T:lclock|) init_l)
                         (= (ref.evs.l_cmp |T:lclock|) init_l))))))
      (a!47 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l)))
                    (a!2 (not (|<:tar_clock:tar_clock|
                                (ref.lt_tar (__ref.evs.m |T:lclock|))
                                (__ref.evs.lt_arr |T:lclock|)))))
                (=> a!1 a!2))))
      (a!48 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (|<:tar_clock:tar_clock|
                      (__ref.evs.lt_arr |T:lclock|)
                      (ref.evs.lt_tar |T:lclock|))))))
      (a!49 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))))
                    (a!3 (and (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|)))
                              (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (__ref.evs.lt_arr |T1:lclock|))))))
              (let ((a!2 (and a!1
                              (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!2 a!3)))))
      (a!50 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (__ref.evs.cmp |T0:lclock|) rrsp)))
                    (a!2 (or (and (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.l_cmp |T1:lclock|) dramc_l))
                             (and (= (__ref.evs.req |T1:lclock|) read)
                                  (= (__ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (__ref.evs.cmp |T1:lclock|) rrsp)
                                  (= (ref.evs.l_cmp |T1:lclock|) dramc_l))))
                    (a!3 (=> (or (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                                 (= (__ref.evs.cmp |T0:lclock|) rrsp))
                             (not (= (ref.evs.lt_tar |T0:lclock|)
                                     (__ref.evs.lt_arr |T1:lclock|)))))
                    (a!4 (=> (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                 (= (__ref.evs.cmp |T1:lclock|) rrsp))
                             (not (= (__ref.evs.lt_arr |T0:lclock|)
                                     (ref.evs.lt_tar |T1:lclock|))))))
              (let ((a!5 (and (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (__ref.evs.lt_arr |T1:lclock|)))
                              a!3
                              a!4)))
                (=> (and a!1
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|)))
                    a!5)))))
      (a!51 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|))))
                    (a!2 (and (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (__ref.evs.lt_arr |T1:lclock|)))
                              (not (= (ref.evs.lt_tar |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|))))))
                (=> a!1 a!2))))
      (a!52 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (not (and (= (__ref.evs.req |T0:lclock|) write)
                        (= (__ref.evs.cmp |T1:lclock|) rrsp)
                        (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                        (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                        (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (|<:tar_clock:tar_clock|
                          (__ref.evs.lt_arr |T0:lclock|)
                          (__ref.evs.lt_arr |T1:lclock|))))))
      (a!53 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (__ref.evs.req |T0:lclock|) read)
                       (= (__ref.evs.cmp |T1:lclock|) rrsp)
                       (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                       (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                       (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (__ref.evs.lt_arr |T0:lclock|)
                    (__ref.evs.lt_arr |T1:lclock|)))))
      (a!54 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.req |T1:lclock|) read))
                             (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) write)))))
                (not (and a!1
                          (= (__ref.evs.op_ack |T0:lclock|) normal)
                          (= (__ref.evs.p |T0:lclock|)
                             (__ref.evs.p |T1:lclock|))
                          (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (__ref.evs.m |T0:lclock|)
                             (__ref.evs.m |T1:lclock|))
                          (= (__ref.evs.a |T0:lclock|)
                             (__ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))))
      (a!55 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) write))
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.req |T1:lclock|) read)))))
                (=> (and a!1
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                         (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    (|<:tar_clock:tar_clock|
                      (__ref.evs.lt_arr |T0:lclock|)
                      (__ref.evs.lt_arr |T1:lclock|))))))
      (a!56 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (|<:tar_clock:tar_clock|
                                (ref.lt_tar (__ref.evs.m |T:lclock|))
                                (ref.evs.lt_tar |T:lclock|)))))
                (=> (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (__ref.evs.cmp |T:lclock|) rrsp))
                    a!1))))
      (a!57 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!1
                    (not (= (ref.evs.lt_tar |T0:lclock|)
                            (ref.evs.lt_tar |T1:lclock|)))))))
      (a!58 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                       (= (__ref.evs.cmp |T1:lclock|) rrsp)
                       (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                       (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                       (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (ref.evs.lt_tar |T0:lclock|)
                    (ref.evs.lt_tar |T1:lclock|)))))
      (a!59 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.l_req |T0:lclock|) if_l)
                              (or (= (__ref.evs.l_req |T1:lclock|) if_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
                    (a!2 (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                             (= (__ref.evs.l_req |T1:lclock|) if_l)
                             (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
              (let ((a!3 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_pio_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))
                             a!1
                             (and (= (__ref.evs.l_req |T0:lclock|) memc_l) a!2))))
                (=> (and (= (__ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.req |T1:lclock|) read)
                         (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                         (= (__ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!3)))))
      (a!60 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (__ref.evs.serialized |T:lclock|))))
                (=> a!1
                    (or (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                        (= (__ref.evs.mem_loc |T:lclock|) pio_memc))))))
      (a!61 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) write)
                  (not (__ref.evs.serialized |T:lclock|)))))
      (a!62 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) read)
                  (not (__ref.evs.serialized |T:lclock|)))))
      (a!63 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.req |T:lclock|) nop)
                       (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                  (__ref.evs.serialized |T:lclock|))))
      (a!64 (forall ((|T:lclock| lclock))
              (=> (__ref.evs.serialized |T:lclock|)
                  (or (= (__ref.evs.req |T:lclock|) nop)
                      (= (__ref.evs.cmp |T:lclock|) nop)
                      (= (__ref.evs.cmp |T:lclock|) rrsp)
                      (= (__ref.evs.cmp |T:lclock|) wr_cmp)))))
      (a!65 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                                  (not (__ref.evs.serialized |T:lclock|)))))
                    (a!2 (or (= (ref.evs.l_cmp |T:lclock|) dramc_l)
                             (= (ref.evs.l_cmp |T:lclock|) memc_l)
                             (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                             (= (ref.evs.l_cmp |T:lclock|) arm_l)))
                    (a!3 (or (= (ref.evs.l_cmp |T:lclock|) memc_l)
                             (= (ref.evs.l_cmp |T:lclock|) if_l)
                             (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                             (= (ref.evs.l_cmp |T:lclock|) arm_l)))
                    (a!5 (and (__ref.evs.serialized |T:lclock|)
                              (or (= (__ref.evs.cmp |T:lclock|) rrsp)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                              (= (ref.evs.l_cmp |T:lclock|) init_l))))
              (let ((a!4 (or (and (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                                  a!2)
                             (and (= (__ref.evs.mem_loc |T:lclock|) pio_memc)
                                  a!3))))
                (=> (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (__ref.evs.cmp |T:lclock|) rrsp))
                    (or (and a!1 a!4) a!5))))))
      (a!66 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.l_req |T:lclock|) dramc_l)
                             (= (__ref.evs.l_req |T:lclock|) memc_l)
                             (= (__ref.evs.l_req |T:lclock|) cf_mem_l)))
                    (a!2 (or (= (__ref.evs.l_req |T:lclock|) memc_l)
                             (= (__ref.evs.l_req |T:lclock|) if_l)
                             (= (__ref.evs.l_req |T:lclock|) cf_pio_l))))
              (let ((a!3 (or (and (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                                  a!1)
                             (and (= (__ref.evs.mem_loc |T:lclock|) pio_memc)
                                  a!2))))
                (=> (or (= (__ref.evs.req |T:lclock|) write)
                        (= (__ref.evs.req |T:lclock|) read))
                    a!3)))))
      (a!67 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (= (__ref.evs.cmp |T1:lclock|) rrsp))))
              (let ((a!2 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.l_cmp |T1:lclock|) init_l))
                             a!1)))
                (not (and a!2
                          (not (__ref.evs.serialized |T0:lclock|))
                          (__ref.evs.serialized |T1:lclock|)
                          (= (__ref.evs.p |T0:lclock|)
                             (__ref.evs.p |T1:lclock|))
                          (= (__ref.evs.m |T0:lclock|)
                             (__ref.evs.m |T1:lclock|))
                          (= (__ref.evs.a |T0:lclock|)
                             (__ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))))
      (a!68 (forall ((|T:lclock| lclock))
              (=> (not (__ref.evs.serialized |T:lclock|))
                  (not (= (__ref.evs.mem_loc |T:lclock|) mem_loc_init)))))
      (a!69 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.req |T:lclock|) nop)
                       (= (__ref.evs.cmp |T:lclock|) nop))
                  (= (__ref.evs.mem_loc |T:lclock|) mem_loc_init))))
      (a!70 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                             (not (= (__ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (__ref.evs.req |T1:lclock|) nop))
                             (not (= (__ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (= (__ref.evs.a |T0:lclock|)
                                 (__ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (= (__ref.evs.mem_loc |T0:lclock|)
                       (__ref.evs.mem_loc |T1:lclock|)))))))
      (a!71 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                             (not (= (__ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (__ref.evs.req |T1:lclock|) nop))
                             (not (= (__ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (= (__ref.evs.a |T0:lclock|)
                                 (__ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (or (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (__ref.evs.mem_loc |T0:lclock|) pio_memc)))))))
      (a!72 (forall ((|T:lclock| lclock) (|T0:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T:lclock|) nop))
                             (not (= (__ref.evs.cmp |T0:lclock|) nop)))))
                (=> (and a!1 (not (__ref.dev |T:lclock|)))
                    (= (__ref.evs.op_ack |T:lclock|) normal)))))
      (a!73 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T:lclock|) nop))
                             (not (= (__ref.evs.cmp |T:lclock|) nop)))))
                (=> (and a!1 (__ref.dev |T:lclock|))
                    (or (= (__ref.evs.op_ack |T:lclock|) nGnRE)
                        (= (__ref.evs.op_ack |T:lclock|) nGnRnE)
                        (= (__ref.evs.op_ack |T:lclock|) _GRE)
                        (= (__ref.evs.op_ack |T:lclock|) nGRE))))))
      (a!74 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T0:lclock|) read)
                              (or (= (__ref.evs.req |T1:lclock|) read)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (not (__ref.evs.serialized |T0:lclock|))
                              (not (__ref.evs.serialized |T1:lclock|))
                              (= (__ref.evs.p |T0:lclock|)
                                 (__ref.evs.p |T1:lclock|))
                              (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (= (__ref.evs.a |T0:lclock|)
                                 (__ref.evs.a |T1:lclock|))
                              (__ref.both_normal |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!75 (forall ((|T:lclock| lclock))
              (or (= (__ref.evs.req |T:lclock|) nop)
                  (= (__ref.evs.cmp |T:lclock|) nop)
                  (= (__ref.evs.req |T:lclock|) write)
                  (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (__ref.evs.req |T:lclock|) read)
                  (= (__ref.evs.cmp |T:lclock|) rrsp))))
      (a!76 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (__isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!77 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (__isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!78 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.mem_loc |T:lclock|) pio_memc)
                  (__ref.dev |T:lclock|))))
      (a!79 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (__isd.wr |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|)
                             (__isd.rd |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|)))
                    (a!2 (or (= (__ref.evs.op_ack |T:lclock|) nGRE)
                             (= (__ref.evs.op_ack |T:lclock|) _GRE)
                             (or (= (__ref.evs.op_ack |T:lclock|) nGnRnE)
                                 (= (__ref.evs.op_ack |T:lclock|) nGnRE)))))
                (=> (and a!1 (__ref.dev |T:lclock|)) a!2))))
      (a!80 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (__isd.wr |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|)
                             (__isd.rd |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|))))
                (=> (and a!1 (not (__ref.dev |T:lclock|)))
                    (= (__ref.evs.op_ack |T:lclock|) normal)))))
      (a!81 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (__isd.rd |P:proc|
                                  |M0:mem_type|
                                  |A0:addr_type|
                                  |T0:lclock|)
                        (ref.same_attr |T0:lclock| |T1:lclock|)
                        (= |M0:mem_type| |M1:mem_type|)
                        (= |A0:addr_type| |A1:addr_type|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!82 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M0:mem_type|
                                  |A0:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (__ref.dev |T0:lclock|)
                        (__ref.dev |T1:lclock|)
                        (__ref.both_nGnR |T0:lclock| |T1:lclock|)))))
      (a!83 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M0:mem_type|
                                  |A0:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (__ref.dev |T0:lclock|)
                        (__ref.dev |T1:lclock|)
                        (__ref.both_nGR |T0:lclock| |T1:lclock|)
                        (__ref.same_addr |T0:lclock| |T1:lclock|)))))
      (a!84 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.rd |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (__ref.dev |T0:lclock|))
                        (not (__ref.dev |T1:lclock|))))))
      (a!85 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (__ref.dev |T0:lclock|))
                        (not (__ref.dev |T1:lclock|))))))
      (a!86 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.rd |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (__ref.dev |T0:lclock|))
                        (not (__ref.dev |T1:lclock|))))))
      (a!87 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (__ref.dev |T0:lclock|))
                        (not (__ref.dev |T1:lclock|))))))
      (a!88 (forall ((|T:lclock| lclock))
              (=> (or (= |T:lclock| |0:lclock|)
                      (|<:lclock:lclock| __ref.lt |T:lclock|))
                  (and (= (__ref.evs.req |T:lclock|) nop)
                       (= (__ref.evs.cmp |T:lclock|) nop)
                       (__ref.evs.serialized |T:lclock|)))))
      (a!89 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                              (not (= (ref.evs.l_cmp |T:lclock|) init_l))
                              (__ref.evs.serialized |T:lclock|))))
              (let ((a!2 (or (and (= (__ref.evs.req |T:lclock|) write)
                                  (not (__ref.evs.serialized |T:lclock|)))
                             a!1)))
                (= (__isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (and a!2
                        (= (__ref.evs.p |T:lclock|) |P:proc|)
                        (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                        (= (__ref.evs.a |T:lclock|) |A:addr_type|)))))))
      (a!90 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (__isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (not (isd.rsp |P:proc|
                                    |M:mem_type|
                                    |A:addr_type|
                                    |T:lclock|)))
                 (and (= (__ref.evs.req |T:lclock|) read)
                      (not (__ref.evs.serialized |T:lclock|))
                      (= (__ref.evs.p |T:lclock|) |P:proc|)
                      (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (__ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!91 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (__isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (isd.rsp |P:proc| |M:mem_type| |A:addr_type| |T:lclock|))
                 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                      (not (__ref.evs.serialized |T:lclock|))
                      (= (__ref.evs.p |T:lclock|) |P:proc|)
                      (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (__ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!92 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                       (not (__ref.evs.serialized |T:lclock|)))
                  (not (= (ref.evs.l_cmp |T:lclock|) dramc_l)))))
      (a!93 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (__ref.dev |T:lclock|)))
                    (a!2 (or (= (__ref.evs.op_ack |T:lclock|) nGnRnE)
                             (= (__ref.evs.op_ack |T:lclock|) nGnRE)
                             (= (__ref.evs.op_ack |T:lclock|) nGRE)
                             (= (__ref.evs.op_ack |T:lclock|) _GRE))))
                (=> a!1 a!2))))
      (a!94 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (not (__ref.dev |T:lclock|)))))
                (=> a!1 (= (__ref.evs.op_ack |T:lclock|) normal)))))
      (a!95 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                              (__ref.dev |T:lclock|)))
                    (a!2 (or (= (__ref.evs.op_ack |T:lclock|) nGnRnE)
                             (= (__ref.evs.op_ack |T:lclock|) nGnRE)
                             (= (__ref.evs.op_ack |T:lclock|) nGRE)
                             (= (__ref.evs.op_ack |T:lclock|) _GRE))))
                (=> a!1 a!2))))
      (a!96 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                              (not (__ref.dev |T:lclock|)))))
                (=> a!1 (= (__ref.evs.op_ack |T:lclock|) normal)))))
      (a!97 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.cmp |T0:lclock|) wr_cmp))
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.cmp |T1:lclock|) wr_cmp))
                              (= (__ref.evs.p |T0:lclock|)
                                 (__ref.evs.p |T1:lclock|))
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (= (__ref.evs.a |T0:lclock|)
                                 (__ref.evs.a |T1:lclock|))
                              (ref.same_attr |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                    (a!2 (not (and (__ref.evs.serialized |T1:lclock|)
                                   (not (__ref.evs.serialized |T0:lclock|))))))
                (=> a!1 a!2))))
      (a!98 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) write))
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.req |T1:lclock|) read))))
                    (a!2 (and (= (__ref.evs.l_req |T0:lclock|) memc_l)
                              (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
                    (a!3 (or (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                             (= (__ref.evs.l_req |T1:lclock|) memc_l)
                             (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
              (let ((a!4 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))
                             a!2
                             (and (= (__ref.evs.l_req |T0:lclock|) dramc_l) a!3))))
                (=> (and a!1
                         (not (__ref.evs.serialized |T0:lclock|))
                         (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!4)))))
      (a!99 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.cmp |T1:lclock|) wr_cmp))
                              (not (__ref.evs.serialized |T0:lclock|))
                              (= (__ref.evs.p |T0:lclock|)
                                 (__ref.evs.p |T1:lclock|))
                              (= (__ref.evs.m |T0:lclock|)
                                 (__ref.evs.m |T1:lclock|))
                              (= (__ref.evs.a |T0:lclock|)
                                 (__ref.evs.a |T1:lclock|))
                              (= (__ref.evs.mem_loc |T0:lclock|) pio_memc)
                              (= (__ref.evs.mem_loc |T1:lclock|) pio_memc)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!100 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.req |T0:lclock|) write)
                               (or (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.cmp |T1:lclock|) rrsp))
                               (= (__ref.evs.p |T0:lclock|)
                                  (__ref.evs.p |T1:lclock|))
                               (= (__ref.evs.m |T0:lclock|)
                                  (__ref.evs.m |T1:lclock|))
                               (= (__ref.evs.a |T0:lclock|)
                                  (__ref.evs.a |T1:lclock|))
                               (= (__ref.evs.mem_loc |T0:lclock|) pio_memc)
                               (= (__ref.evs.mem_loc |T1:lclock|) pio_memc)
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                 (not a!1))))
      (a!101 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                   (= (__ref.evs.req |T1:lclock|) write))
                              (and (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.req |T1:lclock|) read))))
                     (a!2 (and (= (__ref.evs.l_req |T0:lclock|) if_l)
                               (or (= (__ref.evs.l_req |T1:lclock|) if_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
                     (a!3 (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                              (= (__ref.evs.l_req |T1:lclock|) if_l)
                              (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
               (let ((a!4 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_pio_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))
                              a!2
                              (and (= (__ref.evs.l_req |T0:lclock|) memc_l) a!3))))
                 (=> (and a!1
                          (= (__ref.evs.p |T0:lclock|)
                             (__ref.evs.p |T1:lclock|))
                          (= (__ref.evs.m |T0:lclock|)
                             (__ref.evs.m |T1:lclock|))
                          (= (__ref.evs.a |T0:lclock|)
                             (__ref.evs.a |T1:lclock|))
                          (= (__ref.evs.mem_loc |T0:lclock|) pio_memc)
                          (= (__ref.evs.mem_loc |T1:lclock|) pio_memc)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!4)))))
      (a!102 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (__ref.evs.req |T0:lclock|) write)
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (__ref.evs.req |T1:lclock|) write)
                        (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                        (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!103 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (__ref.evs.req |T0:lclock|) read)
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (__ref.evs.req |T1:lclock|) read)
                        (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                        (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!104 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.req |T1:lclock|) read)
                               (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)
                               (= (__ref.evs.req |T0:lclock|) read)
                               (or (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l))))
                     (a!2 (and (= (__ref.evs.req |T1:lclock|) read)
                               (= (__ref.evs.l_req |T1:lclock|) memc_l)
                               (= (__ref.evs.req |T0:lclock|) read)
                               (or (= (__ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l)))))
               (let ((a!3 (or a!1
                              a!2
                              (and (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                                   (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l)))))
                 (=> (and (= (__ref.evs.req |T0:lclock|) read)
                          (not (__ref.evs.serialized |T0:lclock|))
                          (= (__ref.evs.req |T1:lclock|) read)
                          (= (__ref.evs.p |T0:lclock|)
                             (__ref.evs.p |T1:lclock|))
                          (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (__ref.evs.m |T0:lclock|)
                             (__ref.evs.m |T1:lclock|))
                          (= (__ref.evs.a |T0:lclock|)
                             (__ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!105 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!2 (or (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (__ref.evs.l_req |T1:lclock|) memc_l)
                              (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!3 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!1
                              (and (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                                   a!2))))
                 (=> (and (= (__ref.evs.req |T0:lclock|) write)
                          (not (__ref.evs.serialized |T0:lclock|))
                          (= (__ref.evs.req |T1:lclock|) write)
                          (= (__ref.evs.p |T0:lclock|)
                             (__ref.evs.p |T1:lclock|))
                          (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (__ref.evs.m |T0:lclock|)
                             (__ref.evs.m |T1:lclock|))
                          (= (__ref.evs.a |T0:lclock|)
                             (__ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!106 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                              (= (ref.evs.l_cmp |T1:lclock|) memc_l)
                              (= (ref.evs.l_cmp |T1:lclock|) cf_mem_l)
                              (= (ref.evs.l_cmp |T1:lclock|) arm_l))))
                 (=> (and (= (__ref.evs.req |T0:lclock|) read)
                          (not (__ref.evs.serialized |T0:lclock|))
                          (= (__ref.evs.cmp |T1:lclock|) rrsp)
                          (= (__ref.evs.p |T0:lclock|)
                             (__ref.evs.p |T1:lclock|))
                          (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (__ref.evs.m |T0:lclock|)
                             (__ref.evs.m |T1:lclock|))
                          (= (__ref.evs.a |T0:lclock|)
                             (__ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     (and (= (__ref.evs.l_req |T0:lclock|) dramc_l) a!1)))))
      (a!107 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (__ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.cmp |T1:lclock|) rrsp)
                         (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!108 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (__ref.evs.req |T0:lclock|) write)
                         (= (__ref.evs.cmp |T0:lclock|) nop)
                         (= (__ref.evs.req |T1:lclock|) nop)
                         (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                         (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!109 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.cmp |T0:lclock|) rrsp))
                               (__ref.pio |T0:lclock|)
                               (or (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.cmp |T1:lclock|) rrsp))
                               (__ref.pio |T1:lclock|)
                               (= (__ref.evs.m |T0:lclock|)
                                  (__ref.evs.m |T1:lclock|))
                               (= (__ref.evs.a |T0:lclock|)
                                  (__ref.evs.a |T1:lclock|))
                               (= (__ref.evs.p |T0:lclock|)
                                  (__ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (__ref.evs.serialized |T0:lclock|))
                                    (__ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!110 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.cmp |T0:lclock|) rrsp))
                               (or (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.cmp |T1:lclock|) rrsp))
                               (= (__ref.evs.m |T0:lclock|)
                                  (__ref.evs.m |T1:lclock|))
                               (= (__ref.evs.a |T0:lclock|)
                                  (__ref.evs.a |T1:lclock|))
                               (= (__ref.evs.p |T0:lclock|)
                                  (__ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (__ref.evs.serialized |T0:lclock|))
                                    (__ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!111 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying1.now |M:mem_type|))))
      (a!112 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying2.now |M:mem_type|))))
      (a!113 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock|
                          (rfn.abs.lastq |M:mem_type|)
                          |X:tar_clock|)
                        (rfn.abs.begun |M:mem_type| |X:tar_clock|))
                   false)))
      (a!114 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (rfn.abs.begun |M:mem_type| |X:tar_clock|)
                   (rfn.abs.begun |M:mem_type| (rfn.abs.lastq |M:mem_type|)))))
      (a!115 (forall ((|M:mem_type| mem_type)
                      (|X:tar_clock| tar_clock)
                      (|Y:tar_clock| tar_clock))
               (=> (and (rfn.abs.begun |M:mem_type| |X:tar_clock|)
                        (rfn.abs.done |M:mem_type| |X:tar_clock|)
                        (|<:tar_clock:tar_clock| |Y:tar_clock| |X:tar_clock|)
                        (rfn.abs.begun |M:mem_type| |Y:tar_clock|))
                   (rfn.abs.done |M:mem_type| |Y:tar_clock|))))
      (a!116 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (rfn.abs.done |M:mem_type| |X:tar_clock|)
                   (rfn.abs.begun |M:mem_type| |X:tar_clock|))))
      (a!117 (forall ((|X:tar_clock| tar_clock))
               (not (|<:tar_clock:tar_clock| |X:tar_clock| |0:tar_clock|))))
      (a!118 (forall ((|M:mem_type| mem_type)
                      (|T:lclock| lclock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (and (rfn.abs.begun |M:mem_type| |Y:tar_clock|)
                               (=> (rfn.abs.done |M:mem_type| |Y:tar_clock|)
                                   (__rfn.evcomplete |T:lclock|))
                               (= (rfn.abs.queue |M:mem_type| |Y:tar_clock|)
                                  (= (__ref.evs.req |T:lclock|) read)))))
                 (=> (and (__rfn.evqual |M:mem_type| |T:lclock|)
                          (= |Y:tar_clock| (__ref.evs.lt_arr |T:lclock|)))
                     a!1))))
      (a!119 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (|<:tar_clock:tar_clock|
                     (ref.lt_tar |M:mem_type|)
                     |X:tar_clock|)
                   (not (rfn.abs.begun |M:mem_type| |X:tar_clock|)))))
      (a!120 (forall ((|M:mem_type| mem_type))
               (not (dramc.rd_fair |M:mem_type|))))
      (a!121 (forall ((|M:mem_type| mem_type))
               (not (dramc.wr_fair |M:mem_type|))))
      (a!122 (forall ((|V0:lclock| lclock))
               (=> (__l2s_g_0 |V0:lclock|)
                   (=> (__rfn.evqual _M |V0:lclock|)
                       (not (__l2s_g_2 |V0:lclock|))))))
      (a!123 (forall ((|V0:lclock| lclock))
               (=> (__l2s_g_1 |V0:lclock|) (not (__l2s_g_2 |V0:lclock|)))))
      (a!124 (forall ((|V0:lclock| lclock))
               (=> (__l2s_g_2 |V0:lclock|) (not (__rfn.evcomplete |V0:lclock|)))))
      (a!125 (forall ((|V0:lclock| lclock))
               (not (and (__rfn.evcomplete |V0:lclock|) (__l2s_w_0 |V0:lclock|)))))
      (a!126 (forall ((|Y:lclock| lclock))
               (or (not __ts0_c)
                   (=> (|<:lclock:lclock| |__ts0__new_fml:x| |Y:lclock|)
                       (or (= |__fml:y| |Y:lclock|)
                           (|<:lclock:lclock| |__fml:y| |Y:lclock|))))))
      (a!127 (or (not __ts0_c)
                 (or (not __ts0_a) (= (__ref.evs.req |__loc:tt_a|) read))))
      (a!128 (or (not __ts0_c)
                 (or (not __ts0_a)
                     (= (__ref.evs.mem_loc |__loc:tt_a|) mem_memc))))
      (a!129 (or (not __ts0_c)
                 (or (not __ts0_a) (= (__ref.evs.l_req |__loc:tt_a|) cf_mem_l))))
      (a!130 (forall ((|V0:lclock| lclock)
                      (|V1:proc| proc)
                      (|V2:mem_type| mem_type)
                      (|V3:addr_type| addr_type))
               (let ((a!1 (and (__isd.rd |V1:proc|
                                         |V2:mem_type|
                                         |V3:addr_type|
                                         |V0:lclock|)
                               (= (__ref.evs.req |V0:lclock|) read)
                               (= (__ref.evs.mem_loc |V0:lclock|) mem_memc)
                               (= (__ref.evs.l_req |V0:lclock|) cf_mem_l)))
                     (a!2 (and (or (= |V0:lclock| |__loc:tt_a|)
                                   (|<:lclock:lclock| |V0:lclock| |__loc:tt_a|))
                               (not (= |V0:lclock| |__loc:tt_a|)))))
                 (or (not __ts0_c) (not __ts0_a) (not (and a!1 a!2))))))
      (a!131 (forall ((|Y:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0_b_a)
                   (=> (|<:lclock:lclock| |__ts0__new_fml:x_a| |Y:lclock|)
                       (or (= |__fml:y_a| |Y:lclock|)
                           (|<:lclock:lclock| |__fml:y_a| |Y:lclock|))))))
      (a!132 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0__m__old_l2s_g_0_b |V0:lclock|)
                       (__m_l2s_g_0 |V0:lclock|)))))
      (a!133 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__m__old_l2s_g_0_b |V0:lclock|))
                               (=> (__rfn.evqual _M |V0:lclock|)
                                   (not (__l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     (not __ts0__ts0_a_a_b)
                     (=> a!1 (not (__m_l2s_g_0 |V0:lclock|)))))))
      (a!134 (=> (and (not __ts0__m__old_l2s_g_5_a)
                      (not (__dramc_nb2.push_success_rd _M _A)))
                 (not __m_l2s_g_5)))
      (a!135 (=> (and (not __ts0__m__old_l2s_g_6_a)
                      (not (__dramc_nb2.push_trying_rd _M _A)))
                 (not __m_l2s_g_6)))
      (a!136 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> (and (not __ts0__m__old_l2s_g_9_a) (not __m_l2s_g_5))
                     (not __m_l2s_g_9))))
      (a!137 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> (and (not __ts0__m__old_l2s_g_10_a) (not __m_l2s_g_6))
                     (not __m_l2s_g_10))))
      (a!138 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> __m_l2s_g_5
                     (not (__ts0__m_dramc_nb2.push_success_rd_b _M _A)))))
      (a!139 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> __m_l2s_g_6
                     (not (__ts0__m_dramc_nb2.push_trying_rd_b _M _A)))))
      (a!140 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0new__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_a |V0:lclock|)))))
      (a!141 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0new__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     (not __ts0__ts0_a_a_b)
                     (=> a!1 (not (__m_l2s_g_0_a |V0:lclock|)))))))
      (a!142 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0__m__old_l2s_g_1_a |V0:lclock|)
                       (__m_l2s_g_1 |V0:lclock|)))))
      (a!143 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0__m__old_l2s_g_2_a |V0:lclock|)
                       (__m_l2s_g_2 |V0:lclock|)))))
      (a!144 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__m_l2s_g_1 |V0:lclock|)
                       (not (__m_l2s_g_2 |V0:lclock|))))))
      (a!145 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__m_l2s_g_2 |V0:lclock|)
                       (not (__ts0__m_rfn.evcomplete_a |V0:lclock|))))))
      (a!146 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0__m__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_b |V0:lclock|)))))
      (a!147 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__m__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     (not __ts0__ts0_a_a_b)
                     (=> a!1 (not (__m_l2s_g_0_b |V0:lclock|)))))))
      (a!148 (=> (and (not __ts0new__old_l2s_g_5_a_a)
                      (not (__ts0__m_dramc_nb2.push_success_rd_b _M _A)))
                 (not __m_l2s_g_5_a)))
      (a!149 (=> (and (not __ts0new__old_l2s_g_6_a_a)
                      (not (__ts0__m_dramc_nb2.push_trying_rd_b _M _A)))
                 (not __m_l2s_g_6_a)))
      (a!150 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> (and (not __ts0new__old_l2s_g_9_a_a) (not __m_l2s_g_5_a))
                     (not __m_l2s_g_9_a))))
      (a!151 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> (and (not __ts0new__old_l2s_g_10_a_a) (not __m_l2s_g_6_a))
                     (not __m_l2s_g_10_a))))
      (a!152 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> __m_l2s_g_5_a
                     (not (__ts0__m_dramc_nb2.push_success_rd_a_a _M _A)))))
      (a!153 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> __m_l2s_g_6_a
                     (not (__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A)))))
      (a!154 (=> (and (not _old_l2s_g_5)
                      (not (__ts0__m_dramc_nb2.push_success_rd_a_a _M _A)))
                 (not l2s_g_5)))
      (a!155 (=> (and (not _old_l2s_g_6)
                      (not (__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A)))
                 (not l2s_g_6)))
      (a!156 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> (and (not _old_l2s_g_9) (not l2s_g_5)) (not l2s_g_9))))
      (a!157 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> (and (not _old_l2s_g_10) (not l2s_g_6)) (not l2s_g_10))))
      (a!158 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> l2s_g_5 (not (dramc_nb2.push_success_rd _M _A)))))
      (a!159 (or (not __ts0_c)
                 (not __ts0__ts0_a_a_b)
                 (=> l2s_g_6 (not (dramc_nb2.push_trying_rd _M _A)))))
      (a!160 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0new__old_l2s_g_0_b_a |V0:lclock|)
                       (__m_l2s_g_0_c |V0:lclock|)))))
      (a!161 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0new__old_l2s_g_0_b_a |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     (not __ts0__ts0_a_a_b)
                     (=> a!1 (not (__m_l2s_g_0_c |V0:lclock|)))))))
      (a!162 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0new__old_l2s_g_1_a_a |V0:lclock|)
                       (l2s_g_1 |V0:lclock|)))))
      (a!163 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (__ts0new__old_l2s_g_2_a_a |V0:lclock|)
                       (l2s_g_2 |V0:lclock|)))))
      (a!164 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (l2s_g_1 |V0:lclock|) (not (l2s_g_2 |V0:lclock|))))))
      (a!165 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (l2s_g_2 |V0:lclock|) (not (rfn.evcomplete |V0:lclock|))))))
      (a!166 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   (not __ts0__ts0_a_a_b)
                   (=> (_old_l2s_g_0 |V0:lclock|) (l2s_g_0 |V0:lclock|)))))
      (a!167 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (_old_l2s_g_0 |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     (not __ts0__ts0_a_a_b)
                     (=> a!1 (not (l2s_g_0 |V0:lclock|)))))))
      (a!168 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0__m__old_l2s_g_0_b |V0:lclock|)
                       (__m_l2s_g_0 |V0:lclock|)))))
      (a!169 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__m__old_l2s_g_0_b |V0:lclock|))
                               (=> (__rfn.evqual _M |V0:lclock|)
                                   (not (__l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     __ts0__ts0_a_a_b
                     (=> a!1 (not (__m_l2s_g_0 |V0:lclock|)))))))
      (a!170 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> (and (not __ts0__m__old_l2s_g_9_a) (not __m_l2s_g_5))
                     (not __m_l2s_g_9))))
      (a!171 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> (and (not __ts0__m__old_l2s_g_10_a) (not __m_l2s_g_6))
                     (not __m_l2s_g_10))))
      (a!172 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> __m_l2s_g_5
                     (not (__ts0__m_dramc_nb2.push_success_rd_b _M _A)))))
      (a!173 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> __m_l2s_g_6
                     (not (__ts0__m_dramc_nb2.push_trying_rd_b _M _A)))))
      (a!174 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0new__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_a |V0:lclock|)))))
      (a!175 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0new__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     __ts0__ts0_a_a_b
                     (=> a!1 (not (__m_l2s_g_0_a |V0:lclock|)))))))
      (a!176 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0__m__old_l2s_g_1_a |V0:lclock|)
                       (__m_l2s_g_1 |V0:lclock|)))))
      (a!177 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0__m__old_l2s_g_2_a |V0:lclock|)
                       (__m_l2s_g_2 |V0:lclock|)))))
      (a!178 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__m_l2s_g_1 |V0:lclock|)
                       (not (__m_l2s_g_2 |V0:lclock|))))))
      (a!179 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__m_l2s_g_2 |V0:lclock|)
                       (not (__ts0__m_rfn.evcomplete_a |V0:lclock|))))))
      (a!180 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0__m__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_b |V0:lclock|)))))
      (a!181 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__m__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     __ts0__ts0_a_a_b
                     (=> a!1 (not (__m_l2s_g_0_b |V0:lclock|)))))))
      (a!182 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> (and (not __ts0new__old_l2s_g_9_a_a) (not __m_l2s_g_5_a))
                     (not __m_l2s_g_9_a))))
      (a!183 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> (and (not __ts0new__old_l2s_g_10_a_a) (not __m_l2s_g_6_a))
                     (not __m_l2s_g_10_a))))
      (a!184 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> __m_l2s_g_5_a
                     (not (__ts0__m_dramc_nb2.push_success_rd_a_a _M _A)))))
      (a!185 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> __m_l2s_g_6_a
                     (not (__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A)))))
      (a!186 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> (and (not _old_l2s_g_9) (not l2s_g_5)) (not l2s_g_9))))
      (a!187 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> (and (not _old_l2s_g_10) (not l2s_g_6)) (not l2s_g_10))))
      (a!188 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> l2s_g_5 (not (dramc_nb2.push_success_rd _M _A)))))
      (a!189 (or (not __ts0_c)
                 __ts0__ts0_a_a_b
                 (=> l2s_g_6 (not (dramc_nb2.push_trying_rd _M _A)))))
      (a!190 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0new__old_l2s_g_0_b_a |V0:lclock|)
                       (__m_l2s_g_0_c |V0:lclock|)))))
      (a!191 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0new__old_l2s_g_0_b_a |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     __ts0__ts0_a_a_b
                     (=> a!1 (not (__m_l2s_g_0_c |V0:lclock|)))))))
      (a!192 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0new__old_l2s_g_1_a_a |V0:lclock|)
                       (l2s_g_1 |V0:lclock|)))))
      (a!193 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (__ts0new__old_l2s_g_2_a_a |V0:lclock|)
                       (l2s_g_2 |V0:lclock|)))))
      (a!194 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (l2s_g_1 |V0:lclock|) (not (l2s_g_2 |V0:lclock|))))))
      (a!195 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (l2s_g_2 |V0:lclock|) (not (rfn.evcomplete |V0:lclock|))))))
      (a!196 (forall ((|V0:lclock| lclock))
               (or (not __ts0_c)
                   __ts0__ts0_a_a_b
                   (=> (_old_l2s_g_0 |V0:lclock|) (l2s_g_0 |V0:lclock|)))))
      (a!197 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (_old_l2s_g_0 |V0:lclock|))
                               (=> (__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_c)
                     __ts0__ts0_a_a_b
                     (=> a!1 (not (l2s_g_0 |V0:lclock|)))))))
      (a!198 (forall ((|Y:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (=> (|<:lclock:lclock| |__ts0__new_fml:x_a| |Y:lclock|)
                       (or (= |__fml:y| |Y:lclock|)
                           (|<:lclock:lclock| |__fml:y| |Y:lclock|))))))
      (a!199 (forall ((|Y:tar_cf_clock| tar_cf_clock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (|<:tar_cf_clock:tar_cf_clock|
                         |__ts0__ts0__ts0__new_fml:x_a|
                         |Y:tar_cf_clock|)
                       (or (= |__fml:y_a_a| |Y:tar_cf_clock|)
                           (|<:tar_cf_clock:tar_cf_clock|
                             |__fml:y_a_a|
                             |Y:tar_cf_clock|))))))
      (a!200 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (or (not __ts0_a) (= (__ref.evs.req |__loc:tt_a|) read))))
      (a!201 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (or (not __ts0_a)
                     (= (__ref.evs.mem_loc |__loc:tt_a|) mem_memc))))
      (a!202 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (or (not __ts0_a) (= (__ref.evs.l_req |__loc:tt_a|) cf_mem_l))))
      (a!203 (forall ((|V0:lclock| lclock)
                      (|V1:proc| proc)
                      (|V2:mem_type| mem_type)
                      (|V3:addr_type| addr_type))
               (let ((a!1 (and (isd.rd |V1:proc|
                                       |V2:mem_type|
                                       |V3:addr_type|
                                       |V0:lclock|)
                               (= (__ref.evs.req |V0:lclock|) read)
                               (= (__ref.evs.mem_loc |V0:lclock|) mem_memc)
                               (= (__ref.evs.l_req |V0:lclock|) cf_mem_l))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     (not __ts0__ts0__ts0_c_a)
                     (or (not __ts0_b_a) (not a!1))))))
      (a!204 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0__m__old_l2s_g_0_b |V0:lclock|)
                       (__m_l2s_g_0 |V0:lclock|)))))
      (a!205 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0__m__old_l2s_g_0_b |V0:lclock|))
                               (=> (__rfn.evqual _M |V0:lclock|)
                                   (not (__l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     (not __ts0__ts0__ts0_c_a)
                     (=> a!1 (not (__m_l2s_g_0 |V0:lclock|)))))))
      (a!206 (=> (and (not __ts0__ts0__m__old_l2s_g_5_a)
                      (not (__dramc_nb2.push_success_rd _M _A)))
                 (not __m_l2s_g_5)))
      (a!207 (=> (and (not __ts0__ts0__m__old_l2s_g_6_a)
                      (not (__dramc_nb2.push_trying_rd _M _A)))
                 (not __m_l2s_g_6)))
      (a!208 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> (and (not __ts0__ts0__m__old_l2s_g_9_a) (not __m_l2s_g_5))
                     (not __m_l2s_g_9))))
      (a!209 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> (and (not __ts0__ts0__m__old_l2s_g_10_a) (not __m_l2s_g_6))
                     (not __m_l2s_g_10))))
      (a!210 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> __m_l2s_g_5
                     (not (__ts0__ts0__m_dramc_nb2.push_success_rd_b _M _A)))))
      (a!211 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> __m_l2s_g_6
                     (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_b _M _A)))))
      (a!212 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0new__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_a |V0:lclock|)))))
      (a!213 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0new__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     (not __ts0__ts0__ts0_c_a)
                     (=> a!1 (not (__m_l2s_g_0_a |V0:lclock|)))))))
      (a!214 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0__m__old_l2s_g_1_a |V0:lclock|)
                       (__m_l2s_g_1 |V0:lclock|)))))
      (a!215 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0__m__old_l2s_g_2_a |V0:lclock|)
                       (__m_l2s_g_2 |V0:lclock|)))))
      (a!216 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__m_l2s_g_1 |V0:lclock|)
                       (not (__m_l2s_g_2 |V0:lclock|))))))
      (a!217 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__m_l2s_g_2 |V0:lclock|)
                       (not (__ts0__ts0__m_rfn.evcomplete_a |V0:lclock|))))))
      (a!218 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0__m__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_b |V0:lclock|)))))
      (a!219 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0__m__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     (not __ts0__ts0__ts0_c_a)
                     (=> a!1 (not (__m_l2s_g_0_b |V0:lclock|)))))))
      (a!220 (=> (and (not __ts0__ts0new__old_l2s_g_5_a_a)
                      (not (__ts0__ts0__m_dramc_nb2.push_success_rd_b _M _A)))
                 (not __m_l2s_g_5_a)))
      (a!221 (=> (and (not __ts0__ts0new__old_l2s_g_6_a_a)
                      (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_b _M _A)))
                 (not __m_l2s_g_6_a)))
      (a!222 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> (and (not __ts0__ts0new__old_l2s_g_9_a_a)
                          (not __m_l2s_g_5_a))
                     (not __m_l2s_g_9_a))))
      (a!223 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> (and (not __ts0__ts0new__old_l2s_g_10_a_a)
                          (not __m_l2s_g_6_a))
                     (not __m_l2s_g_10_a))))
      (a!224 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> __m_l2s_g_5_a
                     (not (__ts0__ts0__m_dramc_nb2.push_success_rd_a_a _M _A)))))
      (a!225 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> __m_l2s_g_6_a
                     (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A)))))
      (a!226 (=> (and (not _old_l2s_g_5)
                      (not (__ts0__ts0__m_dramc_nb2.push_success_rd_a_a _M _A)))
                 (not l2s_g_5)))
      (a!227 (=> (and (not _old_l2s_g_6)
                      (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A)))
                 (not l2s_g_6)))
      (a!228 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> (and (not _old_l2s_g_9) (not l2s_g_5)) (not l2s_g_9))))
      (a!229 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> (and (not _old_l2s_g_10) (not l2s_g_6)) (not l2s_g_10))))
      (a!230 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> l2s_g_5 (not (dramc_nb2.push_success_rd _M _A)))))
      (a!231 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 (not __ts0__ts0__ts0_c_a)
                 (=> l2s_g_6 (not (dramc_nb2.push_trying_rd _M _A)))))
      (a!232 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0new__old_l2s_g_0_b_a |V0:lclock|)
                       (__m_l2s_g_0_c |V0:lclock|)))))
      (a!233 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0new__old_l2s_g_0_b_a |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     (not __ts0__ts0__ts0_c_a)
                     (=> a!1 (not (__m_l2s_g_0_c |V0:lclock|)))))))
      (a!234 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0new__old_l2s_g_1_a_a |V0:lclock|)
                       (l2s_g_1 |V0:lclock|)))))
      (a!235 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (__ts0__ts0new__old_l2s_g_2_a_a |V0:lclock|)
                       (l2s_g_2 |V0:lclock|)))))
      (a!236 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (l2s_g_1 |V0:lclock|) (not (l2s_g_2 |V0:lclock|))))))
      (a!237 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (l2s_g_2 |V0:lclock|) (not (rfn.evcomplete |V0:lclock|))))))
      (a!238 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   (not __ts0__ts0__ts0_c_a)
                   (=> (_old_l2s_g_0 |V0:lclock|) (l2s_g_0 |V0:lclock|)))))
      (a!239 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (_old_l2s_g_0 |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     (not __ts0__ts0__ts0_c_a)
                     (=> a!1 (not (l2s_g_0 |V0:lclock|)))))))
      (a!240 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (or (not __ts0_a) (= (__ref.evs.req |__loc:tt_a|) read))))
      (a!241 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (or (not __ts0_a)
                     (= (__ref.evs.mem_loc |__loc:tt_a|) mem_memc))))
      (a!242 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (or (not __ts0_a) (= (__ref.evs.l_req |__loc:tt_a|) cf_mem_l))))
      (a!243 (forall ((|V0:lclock| lclock)
                      (|V1:proc| proc)
                      (|V2:mem_type| mem_type)
                      (|V3:addr_type| addr_type))
               (let ((a!1 (and (isd.rd |V1:proc|
                                       |V2:mem_type|
                                       |V3:addr_type|
                                       |V0:lclock|)
                               (= (__ref.evs.req |V0:lclock|) read)
                               (= (__ref.evs.mem_loc |V0:lclock|) mem_memc)
                               (= (__ref.evs.l_req |V0:lclock|) cf_mem_l)))
                     (a!2 (and (or (= |V0:lclock| |__loc:tt_a|)
                                   (|<:lclock:lclock| |V0:lclock| |__loc:tt_a|))
                               (not (= |V0:lclock| |__loc:tt_a|)))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     __ts0__ts0__ts0_c_a
                     (not __ts0_a)
                     (not (and a!1 a!2))))))
      (a!244 (forall ((|V0:lclock| lclock)
                      (|V1:proc| proc)
                      (|V2:mem_type| mem_type)
                      (|V3:addr_type| addr_type))
               (let ((a!1 (and (isd.rd |V1:proc|
                                       |V2:mem_type|
                                       |V3:addr_type|
                                       |V0:lclock|)
                               (= (__ref.evs.req |V0:lclock|) read)
                               (= (__ref.evs.mem_loc |V0:lclock|) mem_memc)
                               (= (__ref.evs.l_req |V0:lclock|) cf_mem_l))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     __ts0__ts0__ts0_c_a
                     (or (not __ts0_b_a) (not a!1))))))
      (a!245 (forall ((|Y:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (not __ts0_b_a)
                   (=> (|<:lclock:lclock|
                         |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a|
                         |Y:lclock|)
                       (or (= |__fml:y_a_a_a| |Y:lclock|)
                           (|<:lclock:lclock| |__fml:y_a_a_a| |Y:lclock|))))))
      (a!246 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0__m__old_l2s_g_0_b |V0:lclock|)
                       (__m_l2s_g_0 |V0:lclock|)))))
      (a!247 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0__m__old_l2s_g_0_b |V0:lclock|))
                               (=> (__rfn.evqual _M |V0:lclock|)
                                   (not (__l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     __ts0__ts0__ts0_c_a
                     (=> a!1 (not (__m_l2s_g_0 |V0:lclock|)))))))
      (a!248 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> (and (not __ts0__ts0__m__old_l2s_g_9_a) (not __m_l2s_g_5))
                     (not __m_l2s_g_9))))
      (a!249 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> (and (not __ts0__ts0__m__old_l2s_g_10_a) (not __m_l2s_g_6))
                     (not __m_l2s_g_10))))
      (a!250 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> __m_l2s_g_5
                     (not (__ts0__ts0__m_dramc_nb2.push_success_rd_b _M _A)))))
      (a!251 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> __m_l2s_g_6
                     (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_b _M _A)))))
      (a!252 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0new__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_a |V0:lclock|)))))
      (a!253 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0new__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     __ts0__ts0__ts0_c_a
                     (=> a!1 (not (__m_l2s_g_0_a |V0:lclock|)))))))
      (a!254 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0__m__old_l2s_g_1_a |V0:lclock|)
                       (__m_l2s_g_1 |V0:lclock|)))))
      (a!255 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0__m__old_l2s_g_2_a |V0:lclock|)
                       (__m_l2s_g_2 |V0:lclock|)))))
      (a!256 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__m_l2s_g_1 |V0:lclock|)
                       (not (__m_l2s_g_2 |V0:lclock|))))))
      (a!257 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__m_l2s_g_2 |V0:lclock|)
                       (not (__ts0__ts0__m_rfn.evcomplete_a |V0:lclock|))))))
      (a!258 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0__m__old_l2s_g_0_a_a |V0:lclock|)
                       (__m_l2s_g_0_b |V0:lclock|)))))
      (a!259 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0__m__old_l2s_g_0_a_a |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                                   (not (__m_l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     __ts0__ts0__ts0_c_a
                     (=> a!1 (not (__m_l2s_g_0_b |V0:lclock|)))))))
      (a!260 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> (and (not __ts0__ts0new__old_l2s_g_9_a_a)
                          (not __m_l2s_g_5_a))
                     (not __m_l2s_g_9_a))))
      (a!261 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> (and (not __ts0__ts0new__old_l2s_g_10_a_a)
                          (not __m_l2s_g_6_a))
                     (not __m_l2s_g_10_a))))
      (a!262 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> __m_l2s_g_5_a
                     (not (__ts0__ts0__m_dramc_nb2.push_success_rd_a_a _M _A)))))
      (a!263 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> __m_l2s_g_6_a
                     (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A)))))
      (a!264 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> (and (not _old_l2s_g_9) (not l2s_g_5)) (not l2s_g_9))))
      (a!265 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> (and (not _old_l2s_g_10) (not l2s_g_6)) (not l2s_g_10))))
      (a!266 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> l2s_g_5 (not (dramc_nb2.push_success_rd _M _A)))))
      (a!267 (or __ts0_c
                 (not __ts0__ts0_d_a)
                 __ts0__ts0__ts0_c_a
                 (=> l2s_g_6 (not (dramc_nb2.push_trying_rd _M _A)))))
      (a!268 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0new__old_l2s_g_0_b_a |V0:lclock|)
                       (__m_l2s_g_0_c |V0:lclock|)))))
      (a!269 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (__ts0__ts0new__old_l2s_g_0_b_a |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     __ts0__ts0__ts0_c_a
                     (=> a!1 (not (__m_l2s_g_0_c |V0:lclock|)))))))
      (a!270 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0new__old_l2s_g_1_a_a |V0:lclock|)
                       (l2s_g_1 |V0:lclock|)))))
      (a!271 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (__ts0__ts0new__old_l2s_g_2_a_a |V0:lclock|)
                       (l2s_g_2 |V0:lclock|)))))
      (a!272 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (l2s_g_1 |V0:lclock|) (not (l2s_g_2 |V0:lclock|))))))
      (a!273 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (l2s_g_2 |V0:lclock|) (not (rfn.evcomplete |V0:lclock|))))))
      (a!274 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   (not __ts0__ts0_d_a)
                   __ts0__ts0__ts0_c_a
                   (=> (_old_l2s_g_0 |V0:lclock|) (l2s_g_0 |V0:lclock|)))))
      (a!275 (forall ((|V0:lclock| lclock))
               (let ((a!1 (and (not (_old_l2s_g_0 |V0:lclock|))
                               (=> (__ts0__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                                   (not (l2s_g_2 |V0:lclock|))))))
                 (or __ts0_c
                     (not __ts0__ts0_d_a)
                     __ts0__ts0__ts0_c_a
                     (=> a!1 (not (l2s_g_0 |V0:lclock|)))))))
      (a!276 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (ref.pnd_or_ser_rd
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)
                      (__ref.pnd_or_ser_rd
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)))))
      (a!277 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cmpl_live.retired |V0:lclock|)
                      (__cmpl_live.retired |V0:lclock|)))))
      (a!278 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (ref.pnd_or_ser_wr
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)
                      (__ref.pnd_or_ser_wr
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)))))
      (a!279 (forall ((|V0:proc| proc) (|V1:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (e2e.issued_to_cf |V0:proc| |V1:lclock|)
                      (__e2e.issued_to_cf |V0:proc| |V1:lclock|)))))
      (a!280 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (l2s_g_0 |V0:lclock|) (__l2s_g_0 |V0:lclock|)))))
      (a!281 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cf_pio_live.issued_pio |V0:lclock|)
                      (__cf_pio_live.issued_pio |V0:lclock|)))))
      (a!282 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cf_pio_live.issued_pio_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_if |V0:lclock|)))))
      (a!283 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cf_pio_live.issued_pio_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_memc |V0:lclock|)))))
      (a!284 (forall ((|V0:lclock| lclock)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (e2e.issued |V0:lclock| |V1:mem_type| |V2:addr_type|)
                      (__e2e.issued |V0:lclock| |V1:mem_type| |V2:addr_type|)))))
      (a!285 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (l2s_g_1 |V0:lclock|) (__l2s_g_1 |V0:lclock|)))))
      (a!286 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (l2s_g_2 |V0:lclock|) (__l2s_g_2 |V0:lclock|)))))
      (a!287 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cmpl_live.cf_cpl |V0:lclock|)
                      (__cmpl_live.cf_cpl |V0:lclock|)))))
      (a!288 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cmpl_live.arm_cpl |V0:lclock|)
                      (__cmpl_live.arm_cpl |V0:lclock|)))))
      (a!289 (forall ((|V0:lclock| lclock) (|V1:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (ref.same_addr |V0:lclock| |V1:lclock|)
                      (__ref.same_addr |V0:lclock| |V1:lclock|)))))
      (a!290 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (ref.pio |V0:lclock|) (__ref.pio |V0:lclock|)))))
      (a!291 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))))
      (a!292 (forall ((|V0:lclock| lclock))
               (or __ts0_c
                   __ts0__ts0_d_a
                   (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))))
      (a!293 (forall ((|T:lclock| lclock) (|Tarr:tar_cf_clock| tar_cf_clock))
               (let ((a!1 (exists ((|\|T:lclock\|!1| lclock))
                            (and (= (ref.evs.req |\|T:lclock\|!1|) read)
                                 (= (ref.evs.l_req |\|T:lclock\|!1|) cf_mem_l)
                                 (= (ref.evs.lt_arr_cf |\|T:lclock\|!1|)
                                    cfabric.t_rd_arr_min)))))
                 (=> (and (= cfabric.t_rd_arr_min |Tarr:tar_cf_clock|)
                          (= (ref.evs.req |T:lclock|) read)
                          (= (ref.evs.l_req |T:lclock|) cf_mem_l))
                     a!1))))
      (a!294 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.req |T:lclock|) read)
                        (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                        (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                        (= |T:lclock| ref.lt))
                   (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf))))
      (a!295 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1
                     (not (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!296 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1
                     (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                         (|<:tar_cf_clock:tar_cf_clock|
                           (ref.evs.lt_arr_cf |T:lclock|)
                           ref.lt_tar_cf))))))
      (a!297 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                        (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                   (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                       (|<:tar_cf_clock:tar_cf_clock|
                         (ref.evs.lt_arr_cf |T:lclock|)
                         ref.lt_tar_cf)))))
      (a!298 (forall ((|T:lclock| lclock))
               (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                   (|<:tar_cf_clock:tar_cf_clock|
                     (ref.evs.lt_arr_cf |T:lclock|)
                     ref.lt_tar_cf))))
      (a!299 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (or (= (ref.evs.l_req |T:lclock|) memc_l)
                                   (= (ref.evs.l_req |T:lclock|) dramc_l)))))
               (let ((a!2 (and (or a!1 (= (ref.evs.cmp |T:lclock|) rrsp))
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!2
                     (|<:tar_cf_clock:tar_cf_clock|
                       (ref.evs.lt_arr_cf |T:lclock|)
                       cfabric.t_rd_arr_min))))))
      (a!300 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) read)
                        (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                        (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.req |T1:lclock|) read)
                        (= (ref.evs.l_req |T1:lclock|) cf_mem_l)
                        (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                   (|<:tar_cf_clock:tar_cf_clock|
                     (ref.evs.lt_arr_cf |T0:lclock|)
                     (ref.evs.lt_arr_cf |T1:lclock|)))))
      (a!301 (forall ((|T:lclock| lclock))
               (let ((a!1 (not (and (= (ref.evs.req |T:lclock|) nop)
                                    (= (ref.evs.cmp |T:lclock|) nop)))))
                 (=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|)))
                     a!1))))
      (a!302 (forall ((|T:lclock| lclock))
               (=> (or (|<:lclock:lclock| ref.lt |T:lclock|)
                       (= |T:lclock| |0:lclock|))
                   (and (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)
                        (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|)))))
      (a!303 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1
                     (or (= cfabric.t_rd_arr_min (ref.evs.lt_arr_cf |T:lclock|))
                         (|<:tar_cf_clock:tar_cf_clock|
                           cfabric.t_rd_arr_min
                           (ref.evs.lt_arr_cf |T:lclock|)))))))
      (a!304 (forall ((|T:lclock| lclock))
               (not (and (= (ref.evs.req |T:lclock|) read)
                         (= (ref.evs.l_req |T:lclock|) cf_mem_l)))))
      (a!305 (forall ((|T:lclock| lclock))
               (and (= (ref.evs.req |T:lclock|) nop)
                    (= (ref.evs.cmp |T:lclock|) nop))))
      (a!306 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                   (= (ref.evs.cmp |T:lclock|) rrsp))
                               (not (= (ref.evs.mem_loc |T:lclock|) mem_memc)))))
               (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) nop)
                                   (= (ref.evs.cmp |T:lclock|) nop))
                              (= (ref.evs.req |T:lclock|) write)
                              (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              a!1)))
                 (=> a!2 (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!307 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T1:lclock|) read)
                               (not (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
               (let ((a!2 (and (= (ref.evs.req |T0:lclock|) read)
                               (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                               (or (= (ref.evs.req |T1:lclock|) write)
                                   a!1
                                   (= (ref.evs.req |T1:lclock|) nop)))))
                 (=> a!2
                     (not (= (ref.evs.lt_arr_cf |T1:lclock|)
                             cfabric.t_rd_arr_min)))))))
      (a!308 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1 (not (|<:lclock:lclock| |T:lclock| cfabric.t_rd_min))))))
      (a!309 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.req |T:lclock|) write)
                              (= (ref.evs.req |T:lclock|) read)
                              (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (= (ref.evs.cmp |T:lclock|) rrsp))))
                 (=> a!1 (not (= cfabric.t_rd_min |0:lclock|))))))
      (a!310 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                               (or (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T:lclock|) cf_pio_l)))))
                 (=> a!1 (not (= |T:lclock| cfabric.t_rd_min))))))
      (a!311 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (not (and (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                                    (= (ref.evs.l_req |T1:lclock|) cf_mem_l)))))
               (let ((a!2 (or (= (ref.evs.req |T1:lclock|) write)
                              (and (= (ref.evs.req |T1:lclock|) read) a!1)
                              (= (ref.evs.req |T1:lclock|) nop))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          a!2)
                     (not (= |T1:lclock| cfabric.t_rd_min)))))))
      (a!312 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.req |T:lclock|) write)
                              (= (ref.evs.req |T:lclock|) read)
                              (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (= (ref.evs.cmp |T:lclock|) rrsp))))
                 (=> (and a!1 (= (ref.evs.mem_loc |T:lclock|) pio_memc))
                     (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!313 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.req |T:lclock|) read))
                               (= (ref.evs.m |T:lclock|) |M:mem_type|)
                               (= (ref.evs.a |T:lclock|) |A:addr_type|)
                               (= (ref.evs.l_req |T:lclock|) dramc_l))))
                 (=> a!1 (not (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|))))))
      (a!314 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.req |T:lclock|) read))
                               (= (ref.evs.m |T:lclock|) |M:mem_type|)
                               (= (ref.evs.a |T:lclock|) |A:addr_type|)
                               (not (= (ref.evs.l_req |T:lclock|) dramc_l)))))
                 (=> a!1 (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!315 (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.req |T:lclock|) read))
                               (= (ref.evs.m |T:lclock|) |M:mem_type|)
                               (= (ref.evs.l_req |T:lclock|) dramc_l))))
                 (=> a!1 (not (= (dramc.t_min |M:mem_type|) |0:tar_clock|))))))
      (a!316 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) read)
                   (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!317 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) write)
                   (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!318 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) nop)
                   (= (ref.evs.l_req |T:lclock|) init_l))))
      (a!319 (forall ((|T:lclock| lclock))
               (or (= (ref.evs.req |T:lclock|) read)
                   (= (ref.evs.req |T:lclock|) write)
                   (= (ref.evs.req |T:lclock|) nop))))
      (a!320 (forall ((|T:lclock| lclock))
               (or (= (ref.evs.cmp |T:lclock|) rrsp)
                   (= (ref.evs.cmp |T:lclock|) wr_cmp)
                   (= (ref.evs.cmp |T:lclock|) nop))))
      (a!321 (forall ((|T:lclock| lclock))
               (=> (not (= (ref.evs.req |T:lclock|) nop))
                   (= (ref.evs.cmp |T:lclock|) nop))))
      (a!322 (forall ((|T:lclock| lclock))
               (=> (not (= (ref.evs.cmp |T:lclock|) nop))
                   (= (ref.evs.req |T:lclock|) nop))))
      (a!323 (forall ((|T:lclock| lclock))
               (let ((a!1 (forall ((|A:addr_type| addr_type)
                                   (|M:mem_type| mem_type)
                                   (|P:proc| proc))
                            (not (or (isd.wr |P:proc|
                                             |M:mem_type|
                                             |A:addr_type|
                                             |T:lclock|)
                                     (isd.rd |P:proc|
                                             |M:mem_type|
                                             |A:addr_type|
                                             |T:lclock|))))))
                 (=> a!1
                     (and (= (ref.evs.l_req |T:lclock|) init_l)
                          (= (ref.evs.l_cmp |T:lclock|) init_l))))))
      (a!324 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                   (= (ref.evs.cmp |T:lclock|) rrsp))
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1
                     (|<:tar_clock:tar_clock|
                       (ref.evs.lt_arr |T:lclock|)
                       (ref.evs.lt_tar |T:lclock|))))))
      (a!325 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))
                              (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))
                              (= (ref.evs.cmp |T0:lclock|) rrsp)))
                     (a!2 (or (and (= (ref.evs.req |T1:lclock|) write)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l))
                              (and (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                   (= (ref.evs.l_cmp |T1:lclock|) dramc_l))
                              (and (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l))
                              (and (= (ref.evs.cmp |T1:lclock|) rrsp)
                                   (= (ref.evs.l_cmp |T1:lclock|) dramc_l))))
                     (a!3 (=> (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (not (= (ref.evs.lt_tar |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|)))))
                     (a!4 (=> (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|))))))
               (let ((a!5 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                       (ref.evs.lt_arr |T1:lclock|)))
                               a!3
                               a!4)))
                 (=> (and a!1
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          a!2
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (not (= |T0:lclock| |T1:lclock|)))
                     a!5)))))
      (a!326 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) write)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.l_req |T0:lclock|) dramc_l)
                         (|<:tar_clock:tar_clock|
                           (ref.evs.lt_arr |T0:lclock|)
                           (ref.evs.lt_arr |T1:lclock|))))))
      (a!327 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) read)
                        (= (ref.evs.cmp |T1:lclock|) rrsp)
                        (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                        (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                        (ref.same_attr |T0:lclock| |T1:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                   (|<:tar_clock:tar_clock|
                     (ref.evs.lt_arr |T0:lclock|)
                     (ref.evs.lt_arr |T1:lclock|)))))
      (a!328 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read))
                              (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write)))))
                 (not (and a!1
                           (= (ref.evs.op_ack |T0:lclock|) normal)
                           (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                           (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                           (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                           (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                           (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                           (ref.same_attr |T0:lclock| |T1:lclock|)
                           (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))))
      (a!329 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write))
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read)))))
                 (=> (and a!1
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (= (ref.evs.l_req |T0:lclock|) dramc_l)
                          (= (ref.evs.l_req |T1:lclock|) dramc_l)
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     (|<:tar_clock:tar_clock|
                       (ref.evs.lt_arr |T0:lclock|)
                       (ref.evs.lt_arr |T1:lclock|))))))
      (a!330 (forall ((|T:lclock| lclock))
               (let ((a!1 (not (|<:tar_clock:tar_clock|
                                 (ref.lt_tar (ref.evs.m |T:lclock|))
                                 (ref.evs.lt_tar |T:lclock|)))))
                 (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                         (= (ref.evs.cmp |T:lclock|) rrsp))
                     a!1))))
      (a!331 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                   (= (ref.evs.cmp |T1:lclock|) rrsp))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (not (= |T0:lclock| |T1:lclock|)))))
                 (=> a!1
                     (not (= (ref.evs.lt_tar |T0:lclock|)
                             (ref.evs.lt_tar |T1:lclock|)))))))
      (a!332 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                        (= (ref.evs.cmp |T1:lclock|) rrsp)
                        (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                        (ref.same_attr |T0:lclock| |T1:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                   (|<:tar_clock:tar_clock|
                     (ref.evs.lt_tar |T0:lclock|)
                     (ref.evs.lt_tar |T1:lclock|)))))
      (a!333 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.l_req |T0:lclock|) if_l)
                               (or (= (ref.evs.l_req |T1:lclock|) if_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
                     (a!2 (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                              (= (ref.evs.l_req |T1:lclock|) if_l)
                              (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
               (let ((a!3 (or (and (= (ref.evs.l_req |T0:lclock|) cf_pio_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_pio_l))
                              a!1
                              (and (= (ref.evs.l_req |T0:lclock|) memc_l) a!2))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (= (ref.evs.req |T1:lclock|) read)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!334 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                   (= (ref.evs.cmp |T:lclock|) rrsp))
                               (ref.evs.serialized |T:lclock|))))
                 (=> a!1
                     (or (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T:lclock|) pio_memc))))))
      (a!335 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) write)
                   (not (ref.evs.serialized |T:lclock|)))))
      (a!336 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) read)
                   (not (ref.evs.serialized |T:lclock|)))))
      (a!337 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.req |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) wr_cmp))
                   (ref.evs.serialized |T:lclock|))))
      (a!338 (forall ((|T:lclock| lclock))
               (=> (ref.evs.serialized |T:lclock|)
                   (or (= (ref.evs.req |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) rrsp)
                       (= (ref.evs.cmp |T:lclock|) wr_cmp)))))
      (a!339 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (and (= (ref.evs.cmp |T:lclock|) rrsp)
                                   (not (ref.evs.serialized |T:lclock|)))))
                     (a!2 (or (= (ref.evs.l_cmp |T:lclock|) dramc_l)
                              (= (ref.evs.l_cmp |T:lclock|) memc_l)
                              (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                              (= (ref.evs.l_cmp |T:lclock|) arm_l)))
                     (a!3 (or (= (ref.evs.l_cmp |T:lclock|) memc_l)
                              (= (ref.evs.l_cmp |T:lclock|) if_l)
                              (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                              (= (ref.evs.l_cmp |T:lclock|) arm_l)))
                     (a!5 (and (ref.evs.serialized |T:lclock|)
                               (or (= (ref.evs.cmp |T:lclock|) rrsp)
                                   (= (ref.evs.cmp |T:lclock|) wr_cmp))
                               (= (ref.evs.l_cmp |T:lclock|) init_l))))
               (let ((a!4 (or (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                                   a!2)
                              (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                                   a!3))))
                 (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                         (= (ref.evs.cmp |T:lclock|) rrsp))
                     (or (and a!1 a!4) a!5))))))
      (a!340 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.l_req |T:lclock|) dramc_l)
                              (= (ref.evs.l_req |T:lclock|) memc_l)
                              (= (ref.evs.l_req |T:lclock|) cf_mem_l)))
                     (a!2 (or (= (ref.evs.l_req |T:lclock|) memc_l)
                              (= (ref.evs.l_req |T:lclock|) if_l)
                              (= (ref.evs.l_req |T:lclock|) cf_pio_l))))
               (let ((a!3 (or (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                                   a!1)
                              (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                                   a!2))))
                 (=> (or (= (ref.evs.req |T:lclock|) write)
                         (= (ref.evs.req |T:lclock|) read))
                     a!3)))))
      (a!341 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (= (ref.evs.cmp |T1:lclock|) rrsp))))
               (let ((a!2 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                   (= (ref.evs.l_cmp |T1:lclock|) init_l))
                              a!1)))
                 (not (and a!2
                           (not (ref.evs.serialized |T0:lclock|))
                           (ref.evs.serialized |T1:lclock|)
                           (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                           (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                           (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                           (ref.same_attr |T0:lclock| |T1:lclock|)
                           (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))))
      (a!342 (forall ((|T:lclock| lclock))
               (=> (not (ref.evs.serialized |T:lclock|))
                   (not (= (ref.evs.mem_loc |T:lclock|) mem_loc_init)))))
      (a!343 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.req |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) nop))
                   (= (ref.evs.mem_loc |T:lclock|) mem_loc_init))))
      (a!344 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                              (not (= (ref.evs.cmp |T0:lclock|) nop))))
                     (a!2 (or (not (= (ref.evs.req |T1:lclock|) nop))
                              (not (= (ref.evs.cmp |T1:lclock|) nop)))))
               (let ((a!3 (and a!1
                               a!2
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|)))))
                 (=> a!3
                     (= (ref.evs.mem_loc |T0:lclock|)
                        (ref.evs.mem_loc |T1:lclock|)))))))
      (a!345 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                              (not (= (ref.evs.cmp |T0:lclock|) nop))))
                     (a!2 (or (not (= (ref.evs.req |T1:lclock|) nop))
                              (not (= (ref.evs.cmp |T1:lclock|) nop)))))
               (let ((a!3 (and a!1
                               a!2
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|)))))
                 (=> a!3
                     (or (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)))))))
      (a!346 (forall ((|T:lclock| lclock) (|T0:lclock| lclock))
               (let ((a!1 (or (not (= (ref.evs.req |T:lclock|) nop))
                              (not (= (ref.evs.cmp |T0:lclock|) nop)))))
                 (=> (and a!1 (not (ref.dev |T:lclock|)))
                     (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!347 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (not (= (ref.evs.req |T:lclock|) nop))
                              (not (= (ref.evs.cmp |T:lclock|) nop)))))
                 (=> (and a!1 (ref.dev |T:lclock|))
                     (or (= (ref.evs.op_ack |T:lclock|) nGnRE)
                         (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                         (= (ref.evs.op_ack |T:lclock|) _GRE)
                         (= (ref.evs.op_ack |T:lclock|) nGRE))))))
      (a!348 (forall ((|T:lclock| lclock))
               (or (= (ref.evs.req |T:lclock|) nop)
                   (= (ref.evs.cmp |T:lclock|) nop)
                   (= (ref.evs.req |T:lclock|) write)
                   (= (ref.evs.cmp |T:lclock|) wr_cmp)
                   (= (ref.evs.req |T:lclock|) read)
                   (= (ref.evs.cmp |T:lclock|) rrsp))))
      (a!349 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (=> (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (not (= |T:lclock| |0:lclock|)))))
      (a!350 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (=> (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (not (= |T:lclock| |0:lclock|)))))
      (a!351 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                   (ref.dev |T:lclock|))))
      (a!352 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (let ((a!1 (or (isd.wr |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|)
                              (isd.rd |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|)))
                     (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGRE)
                              (= (ref.evs.op_ack |T:lclock|) _GRE)
                              (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                                  (= (ref.evs.op_ack |T:lclock|) nGnRE)))))
                 (=> (and a!1 (ref.dev |T:lclock|)) a!2))))
      (a!353 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (let ((a!1 (or (isd.wr |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|)
                              (isd.rd |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|))))
                 (=> (and a!1 (not (ref.dev |T:lclock|)))
                     (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!354 (forall ((|A0:addr_type| addr_type)
                      (|A1:addr_type| addr_type)
                      (|M0:mem_type| mem_type)
                      (|M1:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_wr
                           |P:proc|
                           |M1:mem_type|
                           |A1:addr_type|
                           |T1:lclock|)
                         (isd.rd |P:proc|
                                 |M0:mem_type|
                                 |A0:addr_type|
                                 |T0:lclock|)
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= |M0:mem_type| |M1:mem_type|)
                         (= |A0:addr_type| |A1:addr_type|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!355 (forall ((|A0:addr_type| addr_type)
                      (|A1:addr_type| addr_type)
                      (|M0:mem_type| mem_type)
                      (|M1:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M1:mem_type|
                           |A1:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M0:mem_type|
                                 |A0:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (ref.dev |T0:lclock|)
                         (ref.dev |T1:lclock|)
                         (ref.both_nGnR |T0:lclock| |T1:lclock|)))))
      (a!356 (forall ((|A0:addr_type| addr_type)
                      (|A1:addr_type| addr_type)
                      (|M0:mem_type| mem_type)
                      (|M1:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M1:mem_type|
                           |A1:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M0:mem_type|
                                 |A0:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (ref.dev |T0:lclock|)
                         (ref.dev |T1:lclock|)
                         (ref.both_nGR |T0:lclock| |T1:lclock|)
                         (ref.same_addr |T0:lclock| |T1:lclock|)))))
      (a!357 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.rd |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!358 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!359 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_wr
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.rd |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!360 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_wr
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!361 (forall ((|T:lclock| lclock))
               (=> (or (= |T:lclock| |0:lclock|)
                       (|<:lclock:lclock| ref.lt |T:lclock|))
                   (and (= (ref.evs.req |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) nop)
                        (ref.evs.serialized |T:lclock|)))))
      (a!362 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l))
                               (ref.evs.serialized |T:lclock|))))
               (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) write)
                                   (not (ref.evs.serialized |T:lclock|)))
                              a!1)))
                 (= (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                    (and a!2
                         (= (ref.evs.p |T:lclock|) |P:proc|)
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (ref.evs.a |T:lclock|) |A:addr_type|)))))))
      (a!363 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                       (not (isd.rsp |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)))
                  (and (= (ref.evs.req |T:lclock|) read)
                       (not (ref.evs.serialized |T:lclock|))
                       (= (ref.evs.p |T:lclock|) |P:proc|)
                       (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!364 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                       (isd.rsp |P:proc| |M:mem_type| |A:addr_type| |T:lclock|))
                  (and (= (ref.evs.cmp |T:lclock|) rrsp)
                       (not (ref.evs.serialized |T:lclock|))
                       (= (ref.evs.p |T:lclock|) |P:proc|)
                       (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!365 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                        (not (ref.evs.serialized |T:lclock|)))
                   (not (= (ref.evs.l_cmp |T:lclock|) dramc_l)))))
      (a!366 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                   (= (ref.evs.cmp |T:lclock|) rrsp))
                               (not (ref.dev |T:lclock|)))))
                 (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!367 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.cmp |T:lclock|) wr_cmp))
                               (not (ref.dev |T:lclock|)))))
                 (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!368 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write))
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read))))
                     (a!2 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!3 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (ref.evs.l_req |T1:lclock|) memc_l)
                              (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!4 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!2
                              (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!3))))
                 (=> (and a!1
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!4)))))
      (a!369 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write))
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read))))
                     (a!2 (and (= (ref.evs.l_req |T0:lclock|) if_l)
                               (or (= (ref.evs.l_req |T1:lclock|) if_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
                     (a!3 (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                              (= (ref.evs.l_req |T1:lclock|) if_l)
                              (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
               (let ((a!4 (or (and (= (ref.evs.l_req |T0:lclock|) cf_pio_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_pio_l))
                              a!2
                              (and (= (ref.evs.l_req |T0:lclock|) memc_l) a!3))))
                 (=> (and a!1
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!4)))))
      (a!370 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) write)
                        (= (ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (ref.evs.req |T1:lclock|) write)
                        (= (ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!371 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) read)
                        (= (ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (ref.evs.req |T1:lclock|) read)
                        (= (ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!372 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T1:lclock|) read)
                               (= (ref.evs.l_req |T1:lclock|) cf_mem_l)
                               (= (ref.evs.req |T0:lclock|) read)
                               (or (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))))
                     (a!2 (and (= (ref.evs.req |T1:lclock|) read)
                               (= (ref.evs.l_req |T1:lclock|) memc_l)
                               (= (ref.evs.req |T0:lclock|) read)
                               (or (= (ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
               (let ((a!3 (or a!1
                              a!2
                              (and (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l)
                                   (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.req |T1:lclock|) read)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!373 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!2 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (ref.evs.l_req |T1:lclock|) memc_l)
                              (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!3 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!1
                              (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!2))))
                 (=> (and (= (ref.evs.req |T0:lclock|) write)
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.req |T1:lclock|) write)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!374 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                              (= (ref.evs.l_cmp |T1:lclock|) memc_l)
                              (= (ref.evs.l_cmp |T1:lclock|) cf_mem_l)
                              (= (ref.evs.l_cmp |T1:lclock|) arm_l))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.cmp |T1:lclock|) rrsp)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!1)))))
      (a!375 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) read)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!376 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) write)
                         (= (ref.evs.cmp |T0:lclock|) nop)
                         (= (ref.evs.req |T1:lclock|) nop)
                         (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!377 (forall ((|M:mem_type| mem_type)
                      (|T:lclock| lclock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (and (rfn.abs.begun |M:mem_type| |Y:tar_clock|)
                               (=> (rfn.abs.done |M:mem_type| |Y:tar_clock|)
                                   (rfn.evcomplete |T:lclock|))
                               (= (rfn.abs.queue |M:mem_type| |Y:tar_clock|)
                                  (= (ref.evs.req |T:lclock|) read)))))
                 (=> (and (rfn.evqual |M:mem_type| |T:lclock|)
                          (= |Y:tar_clock| (ref.evs.lt_arr |T:lclock|)))
                     a!1))))
      (a!378 (forall ((|T:index| index) (|U:index| index) (|V:index| index))
               (=> (and (|<:index:index| |T:index| |U:index|)
                        (|<:index:index| |U:index| |V:index|))
                   (|<:index:index| |T:index| |V:index|))))
      (a!379 (forall ((|T:index| index) (|U:index| index))
               (not (and (|<:index:index| |T:index| |U:index|)
                         (|<:index:index| |U:index| |T:index|)))))
      (a!380 (forall ((|T:lclock| lclock)
                      (|U:lclock| lclock)
                      (|V:lclock| lclock))
               (=> (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                        (|<:lclock:lclock| |U:lclock| |V:lclock|))
                   (|<:lclock:lclock| |T:lclock| |V:lclock|))))
      (a!381 (forall ((|T:lclock| lclock) (|U:lclock| lclock))
               (not (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                         (|<:lclock:lclock| |U:lclock| |T:lclock|)))))
      (a!382 (forall ((|T:tar_clock| tar_clock)
                      (|U:tar_clock| tar_clock)
                      (|V:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                        (|<:tar_clock:tar_clock| |U:tar_clock| |V:tar_clock|))
                   (|<:tar_clock:tar_clock| |T:tar_clock| |V:tar_clock|))))
      (a!383 (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
               (not (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                         (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))))
      (a!384 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock)
                      (|V:tar_cf_clock| tar_cf_clock))
               (=> (and (|<:tar_cf_clock:tar_cf_clock|
                          |T:tar_cf_clock|
                          |U:tar_cf_clock|)
                        (|<:tar_cf_clock:tar_cf_clock|
                          |U:tar_cf_clock|
                          |V:tar_cf_clock|))
                   (|<:tar_cf_clock:tar_cf_clock|
                     |T:tar_cf_clock|
                     |V:tar_cf_clock|))))
      (a!385 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock))
               (not (and (|<:tar_cf_clock:tar_cf_clock|
                           |T:tar_cf_clock|
                           |U:tar_cf_clock|)
                         (|<:tar_cf_clock:tar_cf_clock|
                           |U:tar_cf_clock|
                           |T:tar_cf_clock|)))))
      (a!386 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)
                  (and (= (__ref.evs.cmp |T0:lclock|) rrsp)
                       (= (__ref.evs.cmp |T1:lclock|) rrsp)
                       (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                       (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (__ref.evs.mem_loc |T1:lclock|) mem_memc)))))
      (a!387 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.same_attr |T0:lclock| |T1:lclock|)
                  (or (__ref.both_nGnR |T0:lclock| |T1:lclock|)
                      (__ref.both_nGR |T0:lclock| |T1:lclock|)
                      (__ref.both_normal |T0:lclock| |T1:lclock|)))))
      (a!388 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (__ref.both_normal |T0:lclock| |T1:lclock|)
                  (and (= (__ref.evs.op_ack |T0:lclock|) normal)
                       (= (__ref.evs.op_ack |T1:lclock|) normal)))))
      (a!389 (forall ((|T:lclock| lclock))
               (= (__ref.dev |T:lclock|)
                  (or (ref.nGR (__ref.evs.op_ack |T:lclock|))
                      (ref.nGnR (__ref.evs.op_ack |T:lclock|))))))
      (a!390 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (__ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!391 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_trying_rd |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (__dramc_nb2.evma dramc_nb2.memc_pushing.value
                                         |M:mem_type|
                                         |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_pushing.value) read)))))
      (a!392 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_success_rd |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (__dramc_nb2.evma dramc_nb2.memc_arriving.value
                                         |M:mem_type|
                                         |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_arriving.value) read)))))
      (a!393 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__dramc_nb2.evqual_rd |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (__ref.evs.req |T:lclock|) read)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                       (__dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)))))
      (a!394 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_trying_wr |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (__dramc_nb2.evma dramc_nb2.memc_pushing.value
                                         |M:mem_type|
                                         |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_pushing.value) write)))))
      (a!395 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_success_wr |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (__dramc_nb2.evma dramc_nb2.memc_arriving.value
                                         |M:mem_type|
                                         |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_arriving.value) write)))))
      (a!396 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__dramc_nb2.evqual_wr |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (__ref.evs.req |T:lclock|) write)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                       (__dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)))))
      (a!397 (forall ((|V0:proc| proc))
               (= (l2s_d |V0:proc|)
                  (ite (and (= |V0:proc| |__fml:p|)) true (__l2s_d |V0:proc|)))))
      (a!398 (forall ((|V0:mem_type| mem_type))
               (= (__m_l2s_d_c |V0:mem_type|)
                  (ite (and (= |V0:mem_type| |__fml:m|))
                       true
                       (__l2s_d_a |V0:mem_type|)))))
      (a!399 (forall ((|V0:addr_type| addr_type))
               (= (__m_l2s_d_d |V0:addr_type|)
                  (ite (and (= |V0:addr_type| |__fml:a|))
                       true
                       (__l2s_d_b |V0:addr_type|)))))
      (a!400 (ite __ts0_e
                  (ite __ts0__ts0_c_a
                       (ite __ts0__ts0__ts0_a_a |__fml:choose_op_ack| nGnRnE)
                       (ite __ts0__ts0__ts0_b_a_a
                            nGRE
                            (ite __ts0__ts0__ts0__ts0_a_a_a_a _GRE normal)))
                  (ite __ts0__ts0_b
                       (ite __ts0__ts0_a_a_a |__fml:choose_op_ack| normal)
                       (ite __ts0__ts0_a_a_a |__fml:choose_op_ack| nGnRnE))))
      (a!401 (ite __ts0__ts0_b
                  (not (or (= |__fml:choose_op_ack| nGnRnE)
                           (= |__fml:choose_op_ack| nGnRE)))
                  (not (= |__fml:choose_op_ack| normal))))
      (a!402 (= |__new_loc:pio_new|
                (ite __ts0_e
                     (and __ts0__ts0_c_a (= |__fml:mem_loc_arg| pio_memc))
                     (and (__ref.dev |__loc:tt|)
                          (= |__new_loc:mem_loc| pio_memc)))))
      (a!403 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.wr |__fml:p| |M:mem_type| |A:addr_type| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) write) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGnR (__ref.evs.op_ack |T:lclock|))
                      |__new_loc:pio_new|
                      (not (and (= |M:mem_type| |__fml:m|)
                                (= |A:addr_type| |__fml:a|)))))))
      (a!404 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.rd |__fml:p| |M:mem_type| |A:addr_type| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) read) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGnR (__ref.evs.op_ack |T:lclock|))))))
      (a!405 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.rd |__fml:p| |M:mem_type| |A:addr_type| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) read) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGR (__ref.evs.op_ack |T:lclock|))))))
      (a!406 (exists ((|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.wr |__fml:p| |__fml:m| |__fml:a| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) write) a!1)
                      (not (__ref.dev |T:lclock|))
                      |__new_loc:dram_new|))))
      (a!407 (exists ((|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.wr |__fml:p| |__fml:m| |__fml:a| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) write) a!1)
                      (not (__ref.dev |T:lclock|))
                      |__new_loc:pio_new|))))
      (a!408 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.rd |__fml:p| |M:mem_type| |A:addr_type| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) read) a!1)
                      (not (__ref.dev |T:lclock|))))))
      (a!409 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.wr |__fml:p| |M:mem_type| |A:addr_type| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) write) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGnR (__ref.evs.op_ack |T:lclock|))
                      |__new_loc:dram_new|))))
      (a!410 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.wr |__fml:p| |M:mem_type| |A:addr_type| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) write) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGnR (__ref.evs.op_ack |T:lclock|))
                      |__new_loc:pio_new|))))
      (a!411 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.rd |__fml:p| |M:mem_type| |A:addr_type| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) read) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGnR (__ref.evs.op_ack |T:lclock|))
                      |__new_loc:pio_new|
                      (not (and (= |M:mem_type| |__fml:m|)
                                (= |A:addr_type| |__fml:a|)))))))
      (a!412 (exists ((|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.wr |__fml:p| |__fml:m| |__fml:a| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) write) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGR (__ref.evs.op_ack |T:lclock|))
                      |__new_loc:dram_new|))))
      (a!413 (exists ((|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.wr |__fml:p| |__fml:m| |__fml:a| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) write) a!1)
                      (__ref.dev |T:lclock|)
                      (ref.nGR (__ref.evs.op_ack |T:lclock|))
                      |__new_loc:pio_new|))))
      (a!414 (exists ((|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.rd |__fml:p| |__fml:m| |__fml:a| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) read) a!1)
                      (not (__ref.dev |T:lclock|))
                      |__new_loc:dram_new|))))
      (a!415 (exists ((|T:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l)))))
                 (and (__isd.rd |__fml:p| |__fml:m| |__fml:a| |T:lclock|)
                      (or (= (__ref.evs.req |T:lclock|) read) a!1)
                      (not (__ref.dev |T:lclock|))
                      |__new_loc:pio_new|))))
      (a!416 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (let ((a!1 (and (= |V0:proc| |__fml:p|)
                               (= |V1:mem_type| |__fml:m|)
                               (= |V2:addr_type| |__fml:a|)
                               (= |V3:lclock| ref.lt))))
                 (= (isd.wr |V0:proc| |V1:mem_type| |V2:addr_type| |V3:lclock|)
                    (ite __ts0_c
                         (ite a!1
                              true
                              (__isd.wr |V0:proc|
                                        |V1:mem_type|
                                        |V2:addr_type|
                                        |V3:lclock|))
                         (__isd.wr |V0:proc|
                                   |V1:mem_type|
                                   |V2:addr_type|
                                   |V3:lclock|))))))
      (a!417 (ite __ts0_c
                  (ite __ts0_b_a
                       __ts0__ts0__new_cfabric.t_rd_min_a_a
                       __cfabric.t_rd_min)
                  (ite __ts0__ts0_d_a
                       (ite __ts0__ts0__ts0_c_a
                            (ite __ts0_b_a ref.lt __cfabric.t_rd_min)
                            (ite __ts0_b_a
                                 __ts0__ts0__ts0__ts0__new_cfabric.t_rd_min_a_a_a_a
                                 __cfabric.t_rd_min))
                       __cfabric.t_rd_min)))
      (a!418 (= __ts0__m_l2s_w_3_b
                (and __l2s_w_3
                     (not (__ts0__m_dramc_nb2.push_trying_rd_b _M _A))
                     (not __m_l2s_g_6))))
      (a!419 (forall ((|V0:lclock| lclock))
               (= (__ts0__m_l2s_w_0_a |V0:lclock|)
                  (and (__l2s_w_0 |V0:lclock|)
                       (not (__ts0__m_rfn.evcomplete_a |V0:lclock|))
                       (not (__m_l2s_g_2 |V0:lclock|))))))
      (a!420 (= __ts0__m_l2s_w_3_a_a
                (and __ts0__m_l2s_w_3_b
                     (not (__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A))
                     (not __m_l2s_g_6_a))))
      (a!421 (ite __ts0__ts0_d_a
                  (and __ts0__ts0__m_l2s_w_3_a_a
                       (not (dramc_nb2.push_trying_rd _M _A))
                       (not l2s_g_6))
                  __l2s_w_3))
      (a!423 (ite __ts0_c
                  (and __ts0__m_l2s_w_4_a_a (not l2s_g_5) (not l2s_g_9))
                  (ite __ts0__ts0_d_a
                       (and __ts0__ts0__m_l2s_w_4_a_a
                            (not l2s_g_5)
                            (not l2s_g_9))
                       __l2s_w_4)))
      (a!424 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__ts0__m_dramc_nb2.evma_a
                    |T:lclock|
                    |M:mem_type|
                    |A:addr_type|)
                  (and (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (__ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!425 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__m_dramc_nb2.push_trying_rd_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_pushing.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) read)))))
      (a!426 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__m_dramc_nb2.push_success_rd_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_arriving.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) read)))))
      (a!427 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__ts0__m_dramc_nb2.evqual_rd_a_a
                    |T:lclock|
                    |M:mem_type|
                    |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) read)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                       (__ts0__m_dramc_nb2.evma_a
                         |T:lclock|
                         |M:mem_type|
                         |A:addr_type|)))))
      (a!428 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__m_dramc_nb2.push_trying_wr_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_pushing.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) write)))))
      (a!429 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__m_dramc_nb2.push_success_wr_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_arriving.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) write)))))
      (a!430 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__ts0__m_dramc_nb2.evqual_wr_a_a
                    |T:lclock|
                    |M:mem_type|
                    |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) write)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                       (__ts0__m_dramc_nb2.evma_a
                         |T:lclock|
                         |M:mem_type|
                         |A:addr_type|)))))
      (a!431 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                              (not (= (ref.evs.cmp |T0:lclock|) nop))))
                     (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                               (= (ref.evs.l_cmp |T1:lclock|) init_l)))
                     (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                               (__ref.evs.serialized |T0:lclock|)
                               (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
                     (a!5 (and (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|))))
               (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                                   (__ref.evs.serialized |T1:lclock|))
                              a!2)))
               (let ((a!6 (and a!1
                               (or (and a!3
                                        (|<:lclock:lclock|
                                          |T0:lclock|
                                          |T1:lclock|))
                                   a!4)
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               a!5
                               (not (ref.mem_memc_exception
                                      |T0:lclock|
                                      |T1:lclock|))))
                     (a!7 (and a!1
                               (or (and a!3
                                        (|<:lclock:lclock|
                                          |T0:lclock|
                                          |T1:lclock|))
                                   a!4)
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               a!5
                               (not (__ts0__m_ref.mem_memc_exception_b_a
                                      |T0:lclock|
                                      |T1:lclock|)))))
                 (= (__ts0__m_ref.prevents_d_a |T0:lclock| |T1:lclock|)
                    (ite __ts0__ts0_a_a_b (ite __ts0__ts0_a_a_b a!6 a!7) a!6)))))))
      (a!432 (forall ((|V0:lclock| lclock))
               (= (_old_l2s_g_0 |V0:lclock|)
                  (ite __ts0_c
                       (__m_l2s_g_0_c |V0:lclock|)
                       (ite __ts0__ts0_d_a
                            (__m_l2s_g_0_c |V0:lclock|)
                            (___old_l2s_g_0 |V0:lclock|))))))
      (a!433 (= ref.lt_tar_cf
                (ite __ts0_c
                     __ref.lt_tar_cf
                     (ite __ts0__ts0_d_a
                          (ite __ts0__ts0__ts0_c_a
                               |__fml:y_a_a|
                               __ref.lt_tar_cf)
                          __ref.lt_tar_cf))))
      (a!434 (ite __ts0_c
                  __cfabric.t_rd_arr_min
                  (ite __ts0__ts0_d_a
                       (ite __ts0__ts0__ts0_c_a
                            (ite __ts0_b_a ref.lt_tar_cf __cfabric.t_rd_arr_min)
                            __cfabric.t_rd_arr_min)
                       __cfabric.t_rd_arr_min)))
      (a!435 (forall ((|V0:lclock| lclock))
               (let ((a!1 (ite __ts0__ts0__ts0_c_a
                               (ite (and (= |V0:lclock| ref.lt))
                                    ref.lt_tar_cf
                                    (__ref.evs.lt_arr_cf |V0:lclock|))
                               (__ref.evs.lt_arr_cf |V0:lclock|))))
                 (= (ref.evs.lt_arr_cf |V0:lclock|)
                    (ite __ts0_c
                         (__ref.evs.lt_arr_cf |V0:lclock|)
                         (ite __ts0__ts0_d_a
                              a!1
                              (__ref.evs.lt_arr_cf |V0:lclock|)))))))
      (a!436 (= __ts0__ts0__m_l2s_w_3_b
                (and __l2s_w_3
                     (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_b _M _A))
                     (not __m_l2s_g_6))))
      (a!437 (forall ((|V0:lclock| lclock))
               (= (__ts0__ts0__m_l2s_w_0_a |V0:lclock|)
                  (and (__l2s_w_0 |V0:lclock|)
                       (not (__ts0__ts0__m_rfn.evcomplete_a |V0:lclock|))
                       (not (__m_l2s_g_2 |V0:lclock|))))))
      (a!438 (= __ts0__ts0__m_l2s_w_3_a_a
                (and __ts0__ts0__m_l2s_w_3_b
                     (not (__ts0__ts0__m_dramc_nb2.push_trying_rd_a_a _M _A))
                     (not __m_l2s_g_6_a))))
      (a!439 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__ts0__ts0__m_dramc_nb2.evma_a
                    |T:lclock|
                    |M:mem_type|
                    |A:addr_type|)
                  (and (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (__ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!440 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__ts0__m_dramc_nb2.push_trying_rd_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (__ts0__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_pushing.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) read)))))
      (a!441 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__ts0__m_dramc_nb2.push_success_rd_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (__ts0__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_arriving.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) read)))))
      (a!442 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__ts0__ts0__m_dramc_nb2.evqual_rd_a_a
                    |T:lclock|
                    |M:mem_type|
                    |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) read)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                       (__ts0__ts0__m_dramc_nb2.evma_a
                         |T:lclock|
                         |M:mem_type|
                         |A:addr_type|)))))
      (a!443 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__ts0__m_dramc_nb2.push_trying_wr_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (__ts0__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_pushing.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) write)))))
      (a!444 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__ts0__ts0__m_dramc_nb2.push_success_wr_a_a
                    |M:mem_type|
                    |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (__ts0__ts0__m_dramc_nb2.evma_a
                         dramc_nb2.memc_arriving.value
                         |M:mem_type|
                         |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) write)))))
      (a!445 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__ts0__ts0__m_dramc_nb2.evqual_wr_a_a
                    |T:lclock|
                    |M:mem_type|
                    |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) write)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                       (__ts0__ts0__m_dramc_nb2.evma_a
                         |T:lclock|
                         |M:mem_type|
                         |A:addr_type|)))))
      (a!446 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                              (not (= (ref.evs.cmp |T0:lclock|) nop))))
                     (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                               (= (ref.evs.l_cmp |T1:lclock|) init_l)))
                     (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                               (__ref.evs.serialized |T0:lclock|)
                               (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
                     (a!5 (and (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|))))
               (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                                   (__ref.evs.serialized |T1:lclock|))
                              a!2)))
               (let ((a!6 (and a!1
                               (or (and a!3
                                        (|<:lclock:lclock|
                                          |T0:lclock|
                                          |T1:lclock|))
                                   a!4)
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               a!5
                               (not (ref.mem_memc_exception
                                      |T0:lclock|
                                      |T1:lclock|))))
                     (a!7 (and a!1
                               (or (and a!3
                                        (|<:lclock:lclock|
                                          |T0:lclock|
                                          |T1:lclock|))
                                   a!4)
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               a!5
                               (not (__ts0__ts0__m_ref.mem_memc_exception_b_a
                                      |T0:lclock|
                                      |T1:lclock|)))))
                 (= (__ts0__ts0__m_ref.prevents_d_a |T0:lclock| |T1:lclock|)
                    (ite __ts0__ts0__ts0_c_a
                         (ite __ts0__ts0__ts0_c_a a!6 a!7)
                         a!6)))))))
      (a!447 (forall ((|V0:lclock| lclock))
               (= (__m_l2s_d |V0:lclock|)
                  (ite (and (= |V0:lclock| ref.lt))
                       true
                       (__l2s_d_c |V0:lclock|)))))
      (a!448 (forall ((|V0:lclock| lclock))
               (= (__m_l2s_d_a |V0:lclock|)
                  (ite (and (= |V0:lclock| cfabric.t_rd_min))
                       true
                       (__m_l2s_d |V0:lclock|)))))
      (a!449 (forall ((|V0:lclock| lclock))
               (= (__m_l2s_d_b |V0:lclock|)
                  (ite (and (= |V0:lclock| dramc_nb2.memc_pushing.value))
                       true
                       (__m_l2s_d_a |V0:lclock|)))))
      (a!450 (forall ((|V0:lclock| lclock))
               (= (l2s_d |V0:lclock|)
                  (ite (and (= |V0:lclock| dramc_nb2.memc_arriving.value))
                       true
                       (__m_l2s_d_b |V0:lclock|)))))
      (a!451 (forall ((|V0:mem_type| mem_type))
               (= (l2s_d |V0:mem_type|)
                  (ite (and (= |V0:mem_type| _M))
                       true
                       (__m_l2s_d_c |V0:mem_type|)))))
      (a!452 (forall ((|V0:addr_type| addr_type))
               (= (l2s_d |V0:addr_type|)
                  (ite (and (= |V0:addr_type| _A))
                       true
                       (__m_l2s_d_d |V0:addr_type|)))))
      (a!453 (forall ((|V0:tar_cf_clock| tar_cf_clock))
               (= (__m_l2s_d_e |V0:tar_cf_clock|)
                  (ite (and (= |V0:tar_cf_clock| ref.lt_tar_cf))
                       true
                       (__l2s_d_d |V0:tar_cf_clock|)))))
      (a!454 (forall ((|V0:tar_cf_clock| tar_cf_clock))
               (= (l2s_d |V0:tar_cf_clock|)
                  (ite (and (= |V0:tar_cf_clock| cfabric.t_rd_arr_min))
                       true
                       (__m_l2s_d_e |V0:tar_cf_clock|)))))
      (a!455 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.mem_memc_exception |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
      (a!456 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.same_attr |T0:lclock| |T1:lclock|)
                  (or (ref.both_nGnR |T0:lclock| |T1:lclock|)
                      (ref.both_nGR |T0:lclock| |T1:lclock|)
                      (ref.both_normal |T0:lclock| |T1:lclock|)))))
      (a!457 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.both_normal |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.op_ack |T0:lclock|) normal)
                       (= (ref.evs.op_ack |T1:lclock|) normal)))))
      (a!458 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGRE)
                      (= |OP_ACK:op_ack_type| _GRE)))))
      (a!459 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGnR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGnRE)
                      (= |OP_ACK:op_ack_type| nGnRnE)))))
      (a!460 (forall ((|T:lclock| lclock))
               (= (ref.dev |T:lclock|)
                  (or (ref.nGR (ref.evs.op_ack |T:lclock|))
                      (ref.nGnR (ref.evs.op_ack |T:lclock|))))))
      (a!461 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!462 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_trying_rd |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) read)))))
      (a!463 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_success_rd |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (dramc_nb2.evma dramc_nb2.memc_arriving.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) read)))))
      (a!464 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (dramc_nb2.evqual_rd |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) read)
                       (= (ref.evs.l_req |T:lclock|) memc_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)))))
      (a!465 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_trying_wr |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) write)))))
      (a!466 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_success_wr |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (dramc_nb2.evma dramc_nb2.memc_arriving.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) write)))))
      (a!467 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (dramc_nb2.evqual_wr |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) write)
                       (= (ref.evs.l_req |T:lclock|) memc_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))))
(let ((a!10 (or a!9
                (not (forall ((|T:lclock| lclock))
                       (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                                       (__rfn.evqual _M |T:lclock|)
                                       (= (__ref.evs.a |T:lclock|) _A))))
                         (=> a!1 false))))
                (not true)
                (not (=> true false))))
      (a!13 (=> a!12
                (=> (and (and l2s_init_5 l2s_init_6) l2s_init_8) l2s_init_7)))
      (a!422 (ite __ts0_c
                  (and __ts0__m_l2s_w_3_a_a
                       (not (dramc_nb2.push_trying_rd _M _A))
                       (not l2s_g_6))
                  a!421)))
  (and a!1
       a!2
       a!3
       a!4
       a!1
       a!5
       a!6
       (forall ((|T:lclock| lclock))
         (=> (l2s_init_1 |T:lclock|) (__l2s_g_1 |T:lclock|)))
       (=> true (=> true true))
       (=> true true)
       a!7
       (=> (and true l2s_saved) (=> (not l2s_s_1) true))
       (=> true (=> true true))
       (=> (and l2s_saved l2s_s_1) (=> true false))
       (=> (and (not l2s_s_1) (not a!8) l2s_saved true (not __l2s_w_3))
           (and (not l2s_s_1) (=> true false)))
       (=> l2s_init_8 __l2s_g_10)
       a!10
       l2s_g_7
       (=> l2s_g_3 (or (not l2s_waiting) (not l2s_w_1)))
       (not l2s_init_2)
       l2s_g_8
       (=> l2s_g_4 (or (not l2s_waiting) (not l2s_w_2)))
       (not l2s_init_3)
       __l2s_g_10
       (=> __l2s_g_6 (or (not l2s_waiting) (not __l2s_w_3)))
       (not l2s_init_4)
       (=> __l2s_g_9 (or (not l2s_waiting) (not __l2s_w_4)))
       (=> (or (not l2s_waiting) (not __l2s_w_4)) __l2s_g_5)
       (not l2s_init_7)
       (or (not l2s_init_7) __l2s_g_9)
       (=> (and (not l2s_init_7) __l2s_g_9)
           (or (not l2s_waiting) (not __l2s_w_4)))
       a!11
       (or l2s_waiting l2s_frozen l2s_saved)
       (or (not l2s_waiting) (not l2s_frozen))
       (or (not l2s_waiting) (not l2s_saved))
       (or (not l2s_frozen) (not l2s_saved))
       (__l2s_d_c __ref.lt)
       (__l2s_d_c __cfabric.t_rd_min)
       (__l2s_d_c dramc_nb2.memc_pushing.value)
       (__l2s_d_c dramc_nb2.memc_arriving.value)
       (__l2s_d_a _M)
       (__l2s_d_b _A)
       (__l2s_d_d __ref.lt_tar_cf)
       (__l2s_d_d __cfabric.t_rd_arr_min)
       (forall ((|T:lclock| lclock))
         (=> (l2s_init_0 |T:lclock|) (__l2s_g_0 |T:lclock|)))
       (not a!13)
       a!14
       a!15
       a!16
       a!17
       a!18
       a!19
       a!20
       a!21
       a!22
       a!23
       (=> (= __ref.lt |0:lclock|) (= __ref.lt_tar_cf |0:tar_cf_clock|))
       a!24
       (=> a!25
           (or (|<:tar_cf_clock:tar_cf_clock|
                 __ref.lt_tar_cf
                 __cfabric.t_rd_arr_min)
               (= __cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!26 (= __cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!27
       a!28
       a!29
       a!30
       (=> a!25
           (or (|<:lclock:lclock| __ref.lt __cfabric.t_rd_min)
               (= __cfabric.t_rd_min |0:lclock|)))
       (=> a!26 (= __cfabric.t_rd_min |0:lclock|))
       a!31
       a!32
       a!33
       (= (__ref.evs.req |0:lclock|) nop)
       (= (__ref.evs.l_req |0:lclock|) init_l)
       (= (__ref.evs.cmp |0:lclock|) nop)
       (= (ref.evs.l_cmp |0:lclock|) init_l)
       (= (__ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (__ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!34
       a!35
       a!36
       a!37
       a!38
       a!39
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!62
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       a!116
       a!117
       a!118
       a!119
       a!120
       a!121
       (not dramc_nb2.memc_pushing.now)
       (not dramc_nb2.memc_arriving.now)
       a!122
       a!123
       a!124
       (=> l2s_g_3 (not (dramc.rd_fair _M)))
       (=> l2s_g_4 (not (dramc.wr_fair _M)))
       (=> __l2s_g_5 (not (__dramc_nb2.push_success_rd _M _A)))
       (=> __l2s_g_6 (not (__dramc_nb2.push_trying_rd _M _A)))
       (=> l2s_g_7 (not l2s_g_3))
       (=> l2s_g_8 (not l2s_g_4))
       (=> __l2s_g_9 (not __l2s_g_5))
       (=> __l2s_g_10 (not __l2s_g_6))
       (not (and __l2s_g_5 __l2s_w_4))
       a!125
       (not (and (__dramc_nb2.push_trying_rd _M _A) __l2s_w_3))
       (not (and (dramc.rd_fair _M) l2s_w_1))
       (not (and (dramc.wr_fair _M) l2s_w_2))
       a!14
       a!15
       a!16
       a!17
       a!18
       a!19
       a!20
       a!21
       a!22
       a!23
       (=> (= __ref.lt |0:lclock|) (= __ref.lt_tar_cf |0:tar_cf_clock|))
       a!24
       (=> a!25
           (or (|<:tar_cf_clock:tar_cf_clock|
                 __ref.lt_tar_cf
                 __cfabric.t_rd_arr_min)
               (= __cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!26 (= __cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!27
       a!28
       a!29
       a!30
       (=> a!25
           (or (|<:lclock:lclock| __ref.lt __cfabric.t_rd_min)
               (= __cfabric.t_rd_min |0:lclock|)))
       (=> a!26 (= __cfabric.t_rd_min |0:lclock|))
       a!31
       a!32
       a!33
       (= (__ref.evs.req |0:lclock|) nop)
       (= (__ref.evs.l_req |0:lclock|) init_l)
       (= (__ref.evs.cmp |0:lclock|) nop)
       (= (ref.evs.l_cmp |0:lclock|) init_l)
       (= (__ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (__ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!34
       a!35
       a!36
       a!37
       a!38
       a!39
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!62
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       a!116
       a!117
       a!118
       a!119
       a!120
       a!121
       (or __ts0_d __ts0_e)
       (or (not __ts0_d)
           (= (__ref.evs.req |__loc:tt|) read)
           (= (__ref.evs.req |__loc:tt|) write)
           (= (__ref.evs.cmp |__loc:tt|) rrsp)
           (= (__ref.evs.cmp |__loc:tt|) wr_cmp))
       (or (not __ts0_d) (= (__ref.evs.m |__loc:tt|) |__fml:m|))
       (or (not __ts0_d) (= (__ref.evs.a |__loc:tt|) |__fml:a|))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (and (or (= (__ref.evs.req |V0:lclock|) read)
                             (= (__ref.evs.req |V0:lclock|) write)
                             (= (__ref.evs.cmp |V0:lclock|) rrsp)
                             (= (__ref.evs.cmp |V0:lclock|) wr_cmp))
                         (= (__ref.evs.m |V0:lclock|) |__fml:m|)
                         (= (__ref.evs.a |V0:lclock|) |__fml:a|))))
           (or (not __ts0_e) (not a!1))))
       (or (not __ts0_c) (|<:lclock:lclock| |__ts0__new_fml:x| |__fml:y|))
       a!126
       (or (not __ts0_c) (lclock.succ |__ts0__new_fml:x| |__fml:y|))
       (or (not __ts0_c) (or __ts0_a __ts0_b_a))
       (or (not __ts0_c)
           (not __ts0_a)
           (__isd.rd |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt_a|))
       a!127
       a!128
       a!129
       a!130
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (__isd.rd |V1:proc|
                                   |V2:mem_type|
                                   |V3:addr_type|
                                   |V0:lclock|)
                         (= (__ref.evs.req |V0:lclock|) read)
                         (= (__ref.evs.mem_loc |V0:lclock|) mem_memc)
                         (= (__ref.evs.l_req |V0:lclock|) cf_mem_l))))
           (or (not __ts0_c) (not __ts0_b_a) (not a!1))))
       (or (not __ts0_c)
           (not __ts0_b_a)
           (|<:lclock:lclock| |__ts0__new_fml:x_a| |__fml:y_a|))
       a!131
       (or (not __ts0_c)
           (not __ts0_b_a)
           (lclock.succ |__ts0__new_fml:x_a| |__fml:y_a|))
       a!132
       a!133
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0__m__old_l2s_g_5_a __m_l2s_g_5))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!134)
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0__m__old_l2s_g_6_a __m_l2s_g_6))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!135)
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0__m__old_l2s_g_9_a __m_l2s_g_9))
       a!136
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0__m__old_l2s_g_10_a __m_l2s_g_10))
       a!137
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0 |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       a!138
       a!139
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __m_l2s_g_9 (not __m_l2s_g_5)))
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __m_l2s_g_10 (not __m_l2s_g_6)))
       a!140
       a!141
       a!142
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__m__old_l2s_g_1_a |V0:lclock|))
                             (not (__m_l2s_g_2 |V0:lclock|)))
                        (not (__m_l2s_g_1 |V0:lclock|)))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       a!143
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__m__old_l2s_g_2_a |V0:lclock|))
                             (not (__rfn.evcomplete |V0:lclock|)))
                        (not (__m_l2s_g_2 |V0:lclock|)))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_a |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       a!144
       a!145
       a!146
       a!147
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0new__old_l2s_g_5_a_a __m_l2s_g_5_a))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!148)
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0new__old_l2s_g_6_a_a __m_l2s_g_6_a))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!149)
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0new__old_l2s_g_9_a_a __m_l2s_g_9_a))
       a!150
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __ts0new__old_l2s_g_10_a_a __m_l2s_g_10_a))
       a!151
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_b |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       a!152
       a!153
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __m_l2s_g_9_a (not __m_l2s_g_5_a)))
       (or (not __ts0_c)
           (not __ts0__ts0_a_a_b)
           (=> __m_l2s_g_10_a (not __m_l2s_g_6_a)))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) (=> _old_l2s_g_5 l2s_g_5))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!154)
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) (=> _old_l2s_g_6 l2s_g_6))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!155)
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) (=> _old_l2s_g_9 l2s_g_9))
       a!156
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) (=> _old_l2s_g_10 l2s_g_10))
       a!157
       a!158
       a!159
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) (=> l2s_g_9 (not l2s_g_5)))
       (or (not __ts0_c) (not __ts0__ts0_a_a_b) (=> l2s_g_10 (not l2s_g_6)))
       a!160
       a!161
       a!162
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0new__old_l2s_g_1_a_a |V0:lclock|))
                             (not (l2s_g_2 |V0:lclock|)))
                        (not (l2s_g_1 |V0:lclock|)))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       a!163
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0new__old_l2s_g_2_a_a |V0:lclock|))
                             (not (__ts0__m_rfn.evcomplete_a |V0:lclock|)))
                        (not (l2s_g_2 |V0:lclock|)))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_c |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       a!164
       a!165
       a!166
       a!167
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (l2s_g_0 |V0:lclock|)
                        (=> (rfn.evqual _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) (not __ts0__ts0_a_a_b) a!1)))
       a!168
       a!169
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0__m__old_l2s_g_5_a __m_l2s_g_5))
       (or (not __ts0_c) __ts0__ts0_a_a_b a!134)
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0__m__old_l2s_g_6_a __m_l2s_g_6))
       (or (not __ts0_c) __ts0__ts0_a_a_b a!135)
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0__m__old_l2s_g_9_a __m_l2s_g_9))
       a!170
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0__m__old_l2s_g_10_a __m_l2s_g_10))
       a!171
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0 |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       a!172
       a!173
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> __m_l2s_g_9 (not __m_l2s_g_5)))
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> __m_l2s_g_10 (not __m_l2s_g_6)))
       a!174
       a!175
       a!176
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__m__old_l2s_g_1_a |V0:lclock|))
                             (not (__m_l2s_g_2 |V0:lclock|)))
                        (not (__m_l2s_g_1 |V0:lclock|)))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       a!177
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__m__old_l2s_g_2_a |V0:lclock|))
                             (not (__rfn.evcomplete |V0:lclock|)))
                        (not (__m_l2s_g_2 |V0:lclock|)))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_a |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       a!178
       a!179
       a!180
       a!181
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0new__old_l2s_g_5_a_a __m_l2s_g_5_a))
       (or (not __ts0_c) __ts0__ts0_a_a_b a!148)
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0new__old_l2s_g_6_a_a __m_l2s_g_6_a))
       (or (not __ts0_c) __ts0__ts0_a_a_b a!149)
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0new__old_l2s_g_9_a_a __m_l2s_g_9_a))
       a!182
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __ts0new__old_l2s_g_10_a_a __m_l2s_g_10_a))
       a!183
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_b |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       a!184
       a!185
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __m_l2s_g_9_a (not __m_l2s_g_5_a)))
       (or (not __ts0_c)
           __ts0__ts0_a_a_b
           (=> __m_l2s_g_10_a (not __m_l2s_g_6_a)))
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> _old_l2s_g_5 l2s_g_5))
       (or (not __ts0_c) __ts0__ts0_a_a_b a!154)
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> _old_l2s_g_6 l2s_g_6))
       (or (not __ts0_c) __ts0__ts0_a_a_b a!155)
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> _old_l2s_g_9 l2s_g_9))
       a!186
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> _old_l2s_g_10 l2s_g_10))
       a!187
       a!188
       a!189
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> l2s_g_9 (not l2s_g_5)))
       (or (not __ts0_c) __ts0__ts0_a_a_b (=> l2s_g_10 (not l2s_g_6)))
       a!190
       a!191
       a!192
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0new__old_l2s_g_1_a_a |V0:lclock|))
                             (not (l2s_g_2 |V0:lclock|)))
                        (not (l2s_g_1 |V0:lclock|)))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       a!193
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0new__old_l2s_g_2_a_a |V0:lclock|))
                             (not (__ts0__m_rfn.evcomplete_a |V0:lclock|)))
                        (not (l2s_g_2 |V0:lclock|)))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_c |V0:lclock|)
                        (=> (__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       a!194
       a!195
       a!196
       a!197
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (l2s_g_0 |V0:lclock|)
                        (=> (rfn.evqual _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or (not __ts0_c) __ts0__ts0_a_a_b a!1)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (|<:lclock:lclock| |__ts0__new_fml:x_a| |__fml:y|))
       a!198
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (lclock.succ |__ts0__new_fml:x_a| |__fml:y|))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (|<:tar_cf_clock:tar_cf_clock|
             |__ts0__ts0__ts0__new_fml:x_a|
             |__fml:y_a_a|))
       a!199
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (tar_cf_clock.succ |__ts0__ts0__ts0__new_fml:x_a| |__fml:y_a_a|))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (or __ts0_a __ts0_b_a))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (or (not __ts0_a)
               (isd.rd |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt_a|)))
       a!200
       a!201
       a!202
       a!203
       a!204
       a!205
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0__m__old_l2s_g_5_a __m_l2s_g_5))
       (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!206)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0__m__old_l2s_g_6_a __m_l2s_g_6))
       (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!207)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0__m__old_l2s_g_9_a __m_l2s_g_9))
       a!208
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0__m__old_l2s_g_10_a __m_l2s_g_10))
       a!209
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0 |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       a!210
       a!211
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __m_l2s_g_9 (not __m_l2s_g_5)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __m_l2s_g_10 (not __m_l2s_g_6)))
       a!212
       a!213
       a!214
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0__m__old_l2s_g_1_a |V0:lclock|))
                             (not (__m_l2s_g_2 |V0:lclock|)))
                        (not (__m_l2s_g_1 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       a!215
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0__m__old_l2s_g_2_a |V0:lclock|))
                             (not (__rfn.evcomplete |V0:lclock|)))
                        (not (__m_l2s_g_2 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_a |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       a!216
       a!217
       a!218
       a!219
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0new__old_l2s_g_5_a_a __m_l2s_g_5_a))
       (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!220)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0new__old_l2s_g_6_a_a __m_l2s_g_6_a))
       (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!221)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0new__old_l2s_g_9_a_a __m_l2s_g_9_a))
       a!222
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __ts0__ts0new__old_l2s_g_10_a_a __m_l2s_g_10_a))
       a!223
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_b |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       a!224
       a!225
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __m_l2s_g_9_a (not __m_l2s_g_5_a)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> __m_l2s_g_10_a (not __m_l2s_g_6_a)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> _old_l2s_g_5 l2s_g_5))
       (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!226)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> _old_l2s_g_6 l2s_g_6))
       (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!227)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> _old_l2s_g_9 l2s_g_9))
       a!228
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> _old_l2s_g_10 l2s_g_10))
       a!229
       a!230
       a!231
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> l2s_g_9 (not l2s_g_5)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (=> l2s_g_10 (not l2s_g_6)))
       a!232
       a!233
       a!234
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0new__old_l2s_g_1_a_a |V0:lclock|))
                             (not (l2s_g_2 |V0:lclock|)))
                        (not (l2s_g_1 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       a!235
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0new__old_l2s_g_2_a_a |V0:lclock|))
                             (not (__ts0__ts0__m_rfn.evcomplete_a |V0:lclock|)))
                        (not (l2s_g_2 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_c |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       a!236
       a!237
       a!238
       a!239
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (l2s_g_0 |V0:lclock|)
                        (=> (rfn.evqual _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) (not __ts0__ts0__ts0_c_a) a!1)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (or __ts0_a __ts0_b_a))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (or (not __ts0_a)
               (isd.rd |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt_a|)))
       a!240
       a!241
       a!242
       a!243
       a!244
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (not __ts0_b_a)
           (|<:lclock:lclock|
             |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a|
             |__fml:y_a_a_a|))
       a!245
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (not __ts0_b_a)
           (lclock.succ |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| |__fml:y_a_a_a|))
       a!246
       a!247
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0__m__old_l2s_g_5_a __m_l2s_g_5))
       (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!206)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0__m__old_l2s_g_6_a __m_l2s_g_6))
       (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!207)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0__m__old_l2s_g_9_a __m_l2s_g_9))
       a!248
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0__m__old_l2s_g_10_a __m_l2s_g_10))
       a!249
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0 |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       a!250
       a!251
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __m_l2s_g_9 (not __m_l2s_g_5)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __m_l2s_g_10 (not __m_l2s_g_6)))
       a!252
       a!253
       a!254
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0__m__old_l2s_g_1_a |V0:lclock|))
                             (not (__m_l2s_g_2 |V0:lclock|)))
                        (not (__m_l2s_g_1 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       a!255
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0__m__old_l2s_g_2_a |V0:lclock|))
                             (not (__rfn.evcomplete |V0:lclock|)))
                        (not (__m_l2s_g_2 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_a |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_c _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       a!256
       a!257
       a!258
       a!259
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0new__old_l2s_g_5_a_a __m_l2s_g_5_a))
       (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!220)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0new__old_l2s_g_6_a_a __m_l2s_g_6_a))
       (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!221)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0new__old_l2s_g_9_a_a __m_l2s_g_9_a))
       a!260
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __ts0__ts0new__old_l2s_g_10_a_a __m_l2s_g_10_a))
       a!261
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_b |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_a_a _M |V0:lclock|)
                            (not (__m_l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       a!262
       a!263
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __m_l2s_g_9_a (not __m_l2s_g_5_a)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> __m_l2s_g_10_a (not __m_l2s_g_6_a)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> _old_l2s_g_5 l2s_g_5))
       (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!226)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> _old_l2s_g_6 l2s_g_6))
       (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!227)
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> _old_l2s_g_9 l2s_g_9))
       a!264
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> _old_l2s_g_10 l2s_g_10))
       a!265
       a!266
       a!267
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> l2s_g_9 (not l2s_g_5)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           __ts0__ts0__ts0_c_a
           (=> l2s_g_10 (not l2s_g_6)))
       a!268
       a!269
       a!270
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0new__old_l2s_g_1_a_a |V0:lclock|))
                             (not (l2s_g_2 |V0:lclock|)))
                        (not (l2s_g_1 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       a!271
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (and (not (__ts0__ts0new__old_l2s_g_2_a_a |V0:lclock|))
                             (not (__ts0__ts0__m_rfn.evcomplete_a |V0:lclock|)))
                        (not (l2s_g_2 |V0:lclock|)))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (__m_l2s_g_0_c |V0:lclock|)
                        (=> (__ts0__ts0__m_rfn.evqual_b_a _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       a!272
       a!273
       a!274
       a!275
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (=> (l2s_g_0 |V0:lclock|)
                        (=> (rfn.evqual _M |V0:lclock|)
                            (not (l2s_g_2 |V0:lclock|))))))
           (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a a!1)))
       a!276
       a!277
       a!278
       a!279
       a!280
       (or __ts0_c __ts0__ts0_d_a (= l2s_g_5 __l2s_g_5))
       (or __ts0_c __ts0__ts0_d_a (= l2s_g_6 __l2s_g_6))
       (or __ts0_c __ts0__ts0_d_a (= l2s_g_9 __l2s_g_9))
       (or __ts0_c __ts0__ts0_d_a (= l2s_g_10 __l2s_g_10))
       a!281
       a!282
       a!283
       a!284
       a!285
       a!286
       a!287
       a!288
       a!289
       a!290
       a!291
       a!292
       a!293
       a!294
       a!295
       a!296
       a!297
       a!298
       a!299
       a!300
       a!301
       a!302
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!303
       (=> a!304
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 cfabric.t_rd_arr_min)
               (= cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!305 (= cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!306
       a!307
       a!308
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) rrsp)
                         (not (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
               (a!2 (=> (and (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                        (= (ref.evs.l_req |T:lclock|) cf_mem_l))))
         (let ((a!3 (and (or (= (ref.evs.cmp |T:lclock|) nop)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             a!1)
                         a!2)))
           (=> (|<:lclock:lclock| cfabric.t_rd_min |T:lclock|) a!3))))
       (=> a!304
           (or (|<:lclock:lclock| ref.lt cfabric.t_rd_min)
               (= cfabric.t_rd_min |0:lclock|)))
       (=> a!305 (= cfabric.t_rd_min |0:lclock|))
       a!309
       a!310
       a!311
       (= (ref.evs.req |0:lclock|) nop)
       (= (ref.evs.l_req |0:lclock|) init_l)
       (= (ref.evs.cmp |0:lclock|) nop)
       (= (ref.evs.l_cmp |0:lclock|) init_l)
       (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!312
       a!313
       a!314
       a!315
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.req |T0:lclock|) read))
                         (= (ref.evs.l_req |T0:lclock|) dramc_l)
                         (or (= (ref.evs.req |T1:lclock|) write)
                             (= (ref.evs.req |T1:lclock|) read))
                         (= (ref.evs.l_req |T1:lclock|) dramc_l)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))))
               (a!2 (or (|<:tar_clock:tar_clock|
                          (ref.evs.lt_arr |T0:lclock|)
                          (dramc.t_min (ref.evs.m |T0:lclock|)))
                        (|<:tar_clock:tar_clock|
                          (ref.evs.lt_arr |T1:lclock|)
                          (dramc.t_min (ref.evs.m |T0:lclock|))))))
           (=> a!1 (not a!2))))
       a!316
       a!317
       a!318
       a!319
       a!320
       a!321
       a!322
       a!323
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.req |T:lclock|) read))
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (= (ref.evs.l_req |T:lclock|) dramc_l)))
               (a!2 (not (|<:tar_clock:tar_clock|
                           (ref.lt_tar (ref.evs.m |T:lclock|))
                           (ref.evs.lt_arr |T:lclock|)))))
           (=> a!1 a!2)))
       a!324
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l))
                        (and (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l))))
               (a!3 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                 (ref.evs.lt_tar |T1:lclock|)))
                         (not (= (ref.evs.lt_arr |T0:lclock|)
                                 (ref.evs.lt_arr |T1:lclock|))))))
         (let ((a!2 (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|)))))
           (=> a!2 a!3))))
       a!325
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T0:lclock|) rrsp))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|))))
               (a!2 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                 (ref.evs.lt_arr |T1:lclock|)))
                         (not (= (ref.evs.lt_tar |T0:lclock|)
                                 (ref.evs.lt_tar |T1:lclock|))))))
           (=> a!1 a!2)))
       a!326
       a!327
       a!328
       a!329
       a!330
       a!331
       a!332
       a!333
       a!334
       a!335
       a!336
       a!337
       a!338
       a!339
       a!340
       a!341
       a!342
       a!343
       a!344
       a!345
       a!346
       a!347
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                         (or (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (not (ref.evs.serialized |T0:lclock|))
                         (not (ref.evs.serialized |T1:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.both_normal |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
           (not a!1)))
       a!348
       a!349
       a!350
       a!351
       a!352
       a!353
       a!354
       a!355
       a!356
       a!357
       a!358
       a!359
       a!360
       a!361
       a!362
       a!363
       a!364
       a!336
       a!365
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.cmp |T:lclock|) rrsp))
                         (ref.dev |T:lclock|)))
               (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                        (= (ref.evs.op_ack |T:lclock|) nGnRE)
                        (= (ref.evs.op_ack |T:lclock|) nGRE)
                        (= (ref.evs.op_ack |T:lclock|) _GRE))))
           (=> a!1 a!2)))
       a!366
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (ref.dev |T:lclock|)))
               (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                        (= (ref.evs.op_ack |T:lclock|) nGnRE)
                        (= (ref.evs.op_ack |T:lclock|) nGRE)
                        (= (ref.evs.op_ack |T:lclock|) _GRE))))
           (=> a!1 a!2)))
       a!367
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.cmp |T0:lclock|) wr_cmp))
                         (or (= (ref.evs.req |T1:lclock|) write)
                             (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (not (and (ref.evs.serialized |T1:lclock|)
                              (not (ref.evs.serialized |T0:lclock|))))))
           (=> a!1 a!2)))
       a!368
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.cmp |T0:lclock|) rrsp))
                         (or (= (ref.evs.req |T1:lclock|) write)
                             (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                         (not (ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
           (not a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T0:lclock|) write)
                         (or (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
           (not a!1)))
       a!369
       a!370
       a!371
       a!372
       a!373
       a!374
       a!375
       a!376
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.cmp |T0:lclock|) rrsp))
                         (ref.pio |T0:lclock|)
                         (or (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (ref.pio |T1:lclock|)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (not (and (not (ref.evs.serialized |T0:lclock|))
                              (ref.evs.serialized |T1:lclock|)))))
           (=> a!1 a!2)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.cmp |T0:lclock|) rrsp))
                         (or (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (not (and (not (ref.evs.serialized |T0:lclock|))
                              (ref.evs.serialized |T1:lclock|)))))
           (=> a!1 a!2)))
       a!111
       a!112
       a!113
       a!114
       a!115
       a!116
       a!117
       a!377
       a!119
       a!120
       a!121
       (forall ((|X:index| index) (|Y:index| index) (|Z:index| index))
         (let ((a!1 (and (|<:index:index| |X:index| |Z:index|)
                         (not (and (|<:index:index| |X:index| |Y:index|)
                                   (|<:index:index| |Y:index| |Z:index|))))))
           (=> (index.succ |X:index| |Z:index|) a!1)))
       a!378
       a!379
       (forall ((|T:index| index) (|U:index| index))
         (or (|<:index:index| |T:index| |U:index|)
             (= |T:index| |U:index|)
             (|<:index:index| |U:index| |T:index|)))
       (forall ((|X:index| index))
         (or (= |0:index| |X:index|) (|<:index:index| |0:index| |X:index|)))
       (forall ((|X:lclock| lclock) (|Y:lclock| lclock) (|Z:lclock| lclock))
         (let ((a!1 (and (|<:lclock:lclock| |X:lclock| |Z:lclock|)
                         (not (and (|<:lclock:lclock| |X:lclock| |Y:lclock|)
                                   (|<:lclock:lclock| |Y:lclock| |Z:lclock|))))))
           (=> (lclock.succ |X:lclock| |Z:lclock|) a!1)))
       a!380
       a!381
       (forall ((|T:lclock| lclock) (|U:lclock| lclock))
         (or (|<:lclock:lclock| |T:lclock| |U:lclock|)
             (= |T:lclock| |U:lclock|)
             (|<:lclock:lclock| |U:lclock| |T:lclock|)))
       (forall ((|X:lclock| lclock))
         (or (= |0:lclock| |X:lclock|)
             (|<:lclock:lclock| |0:lclock| |X:lclock|)))
       (forall ((|X:tar_clock| tar_clock)
                (|Y:tar_clock| tar_clock)
                (|Z:tar_clock| tar_clock))
         (let ((a!1 (and (|<:tar_clock:tar_clock| |X:tar_clock| |Z:tar_clock|)
                         (not (and (|<:tar_clock:tar_clock|
                                     |X:tar_clock|
                                     |Y:tar_clock|)
                                   (|<:tar_clock:tar_clock|
                                     |Y:tar_clock|
                                     |Z:tar_clock|))))))
           (=> (tar_clock.succ |X:tar_clock| |Z:tar_clock|) a!1)))
       a!382
       a!383
       (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
         (or (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
             (= |T:tar_clock| |U:tar_clock|)
             (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))
       (forall ((|X:tar_clock| tar_clock))
         (or (= |0:tar_clock| |X:tar_clock|)
             (|<:tar_clock:tar_clock| |0:tar_clock| |X:tar_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock)
                (|Y:tar_cf_clock| tar_cf_clock)
                (|Z:tar_cf_clock| tar_cf_clock))
         (let ((a!1 (and (|<:tar_cf_clock:tar_cf_clock|
                           |X:tar_cf_clock|
                           |Z:tar_cf_clock|)
                         (not (and (|<:tar_cf_clock:tar_cf_clock|
                                     |X:tar_cf_clock|
                                     |Y:tar_cf_clock|)
                                   (|<:tar_cf_clock:tar_cf_clock|
                                     |Y:tar_cf_clock|
                                     |Z:tar_cf_clock|))))))
           (=> (tar_cf_clock.succ |X:tar_cf_clock| |Z:tar_cf_clock|) a!1)))
       a!384
       a!385
       (forall ((|T:tar_cf_clock| tar_cf_clock) (|U:tar_cf_clock| tar_cf_clock))
         (or (|<:tar_cf_clock:tar_cf_clock| |T:tar_cf_clock| |U:tar_cf_clock|)
             (= |T:tar_cf_clock| |U:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |U:tar_cf_clock| |T:tar_cf_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock))
         (or (= |0:tar_cf_clock| |X:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |0:tar_cf_clock| |X:tar_cf_clock|)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                        (not (= (__ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (__ref.evs.p |T0:lclock|) (__ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       a!386
       a!387
       a!388
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (__ref.evs.op_ack |T0:lclock|) nGnRnE)
                             (= (__ref.evs.op_ack |T0:lclock|) nGnRE))
                         (or (= (__ref.evs.op_ack |T1:lclock|) nGnRnE)
                             (= (__ref.evs.op_ack |T1:lclock|) nGnRE)))))
           (= (__ref.both_nGnR |T0:lclock| |T1:lclock|) a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (__ref.evs.op_ack |T0:lclock|) nGRE)
                             (= (__ref.evs.op_ack |T0:lclock|) _GRE))
                         (or (= (__ref.evs.op_ack |T1:lclock|) nGRE)
                             (= (__ref.evs.op_ack |T1:lclock|) _GRE)))))
           (= (__ref.both_nGR |T0:lclock| |T1:lclock|) a!1)))
       a!389
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__cf_live.issued_memc |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__rfn.evqual |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (__ref.evs.cmp |T:lclock|) rrsp)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (__rfn.evcomplete |T:lclock|) a!1)))
       a!390
       a!391
       a!392
       a!393
       a!394
       a!395
       a!396
       a!397
       a!398
       a!399
       (not |__m_loc:wr|)
       (not |__m_loc:rd|)
       (= |__new_loc:wr| (or __ts0_b |__m_loc:wr|))
       (= |__new_loc:rd|
          (ite __ts0_b |__m_loc:rd| (or __ts0__ts0_a_a |__m_loc:rd|)))
       (= __ts0__ts0_a_a (= |__fml:ph| rd_ph))
       (= __ts0_b (= |__fml:ph| wr_ph))
       (= |__new_loc:mem_loc|
          (ite __ts0_e
               (ite __ts0__ts0_c_a |__fml:mem_loc_arg| mem_memc)
               (__ref.evs.mem_loc |__loc:tt|)))
       (= |__new_loc:op_ack| a!400)
       (= __ts0__ts0_a_a_a a!401)
       (= __ts0__ts0_b (= |__new_loc:mem_loc| mem_memc))
       a!402
       (= |__new_loc:dram_new|
          (ite __ts0_e (not __ts0__ts0_c_a) (= |__new_loc:mem_loc| mem_memc)))
       (= __ts0__ts0__ts0_a_a (not (= |__fml:choose_op_ack| normal)))
       (= __ts0__ts0__ts0__ts0_a_a_a_a (= |__fml:choose_op_ack| _GRE))
       (= __ts0__ts0__ts0_b_a_a (= |__fml:choose_op_ack| nGRE))
       (= __ts0__ts0_c_a (= |__fml:mem_loc_arg| pio_memc))
       (= |__new_loc:dev| (not (= |__new_loc:op_ack| normal)))
       (= |__new_loc:ordser0|
          (and |__new_loc:wr|
               |__new_loc:dev|
               (ref.nGnR |__new_loc:op_ack|)
               a!403))
       (= |__new_loc:ordser1|
          (and |__new_loc:wr|
               |__new_loc:dev|
               (ref.nGnR |__new_loc:op_ack|)
               a!404))
       (= |__new_loc:ordser2|
          (and |__new_loc:wr|
               |__new_loc:dev|
               (ref.nGnR |__new_loc:op_ack|)
               a!405))
       (= |__new_loc:ordser3|
          (and |__new_loc:wr|
               |__new_loc:dev|
               (ref.nGR |__new_loc:op_ack|)
               a!404))
       (= |__new_loc:ordser4|
          (and |__new_loc:wr|
               |__new_loc:dev|
               (ref.nGR |__new_loc:op_ack|)
               a!405))
       (= |__new_loc:ordser5| (and |__new_loc:wr| (not |__new_loc:dev|) a!406))
       (= |__new_loc:ordser6| (and |__new_loc:wr| (not |__new_loc:dev|) a!407))
       (= |__new_loc:ordser7| (and |__new_loc:wr| (not |__new_loc:dev|) a!408))
       (= |__new_loc:ordser8|
          (and |__new_loc:rd|
               |__new_loc:dev|
               (ref.nGnR |__new_loc:op_ack|)
               a!409))
       (= |__new_loc:ordser9|
          (and |__new_loc:rd|
               |__new_loc:dev|
               (ref.nGnR |__new_loc:op_ack|)
               a!410))
       (= |__new_loc:ordser10|
          (and |__new_loc:rd|
               |__new_loc:dev|
               (ref.nGnR |__new_loc:op_ack|)
               a!411))
       (= |__new_loc:ordser11|
          (and |__new_loc:rd|
               |__new_loc:dev|
               (ref.nGR |__new_loc:op_ack|)
               a!412))
       (= |__new_loc:ordser12|
          (and |__new_loc:rd|
               |__new_loc:dev|
               (ref.nGR |__new_loc:op_ack|)
               a!413))
       (= |__new_loc:ordser13| (and |__new_loc:rd| (not |__new_loc:dev|) a!406))
       (= |__new_loc:ordser14| (and |__new_loc:rd| (not |__new_loc:dev|) a!407))
       (= |__new_loc:ordser15| (and |__new_loc:rd| (not |__new_loc:dev|) a!414))
       (= |__new_loc:ordser16| (and |__new_loc:rd| (not |__new_loc:dev|) a!415))
       (= |__new_loc:ordser|
          (or |__new_loc:ordser0|
              |__new_loc:ordser1|
              |__new_loc:ordser2|
              |__new_loc:ordser3|
              |__new_loc:ordser4|
              |__new_loc:ordser5|
              |__new_loc:ordser6|
              |__new_loc:ordser7|
              |__new_loc:ordser8|
              |__new_loc:ordser9|
              |__new_loc:ordser10|
              |__new_loc:ordser11|
              |__new_loc:ordser12|
              |__new_loc:ordser13|
              |__new_loc:ordser14|
              |__new_loc:ordser15|
              |__new_loc:ordser16|))
       (= |__ts0__new_fml:x| __ref.lt)
       (= ref.lt
          (ite __ts0_c |__fml:y| (ite __ts0__ts0_d_a |__fml:y| __ref.lt)))
       (= |__ts0__new_fml:p_a_b| |__fml:p|)
       (= |__ts0__new_fml:lt_a| ref.lt)
       a!416
       (= cfabric.t_rd_min a!417)
       (= |__ts0__new_fml:x_a| (ite __ts0_c ref.lt __ref.lt))
       (= __ts0__ts0__new_cfabric.t_rd_min_a_a |__fml:y_a|)
       (= |__ts0__new_fml:p_a_a_a| |__fml:p|)
       (= |__ts0__new_fml:op_a| write)
       (= |__ts0__new_fml:op_ack_a| |__new_loc:op_ack|)
       (= |__ts0__new_fml:m_a_a| |__fml:m|)
       (= |__ts0__new_fml:a_a_a| |__fml:a|)
       (= |__ts0__new_fml:mem_loc_a| |__new_loc:mem_loc|)
       (= |__ts0__new_fml:l_a| (ite __ts0__ts0_a_a_b cf_mem_l cf_pio_l))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__ts0__new_fml:p_a_a_a|
                              (__ref.evs.p |V0:lclock|))
                         (__ref.evs.p |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__new_fml:p_a_a_a|
                              (__ref.evs.p |V0:lclock|))
                         a!1)))
           (= (ref.evs.p |V0:lclock|) a!2))))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__m__old_l2s_g_0_b |V0:lclock|) (__l2s_g_0 |V0:lclock|)))
       (= __ts0__m__old_l2s_g_5_a __l2s_g_5)
       (= __ts0__m__old_l2s_g_6_a __l2s_g_6)
       (= __ts0__m__old_l2s_g_9_a __l2s_g_9)
       (= __ts0__m__old_l2s_g_10_a __l2s_g_10)
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__ts0__new_fml:op_a|
                              (__ref.evs.req |V0:lclock|))
                         (__ref.evs.req |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__new_fml:op_a|
                              (__ref.evs.req |V0:lclock|))
                         a!1)))
           (= (ref.evs.req |V0:lclock|) a!2))))
       a!418
       (= __ts0__m_l2s_w_4_b
          (and __l2s_w_4 (not __m_l2s_g_5) (not __m_l2s_g_9)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                        (not (= (__ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__m_ref.prevents_f |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|V0:lclock| lclock))
         (= (__ts0new__old_l2s_g_0_a_a |V0:lclock|) (__m_l2s_g_0 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__m__old_l2s_g_1_a |V0:lclock|) (__l2s_g_1 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__m__old_l2s_g_2_a |V0:lclock|) (__l2s_g_2 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              nop
                              (__ref.evs.cmp |V0:lclock|))
                         (__ref.evs.cmp |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              nop
                              (__ref.evs.cmp |V0:lclock|))
                         a!1)))
           (= (ref.evs.cmp |V0:lclock|) a!2))))
       a!419
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (__ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__m_ref.prevents_a_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__ts0__new_fml:op_ack_a|
                              (__ref.evs.op_ack |V0:lclock|))
                         (__ref.evs.op_ack |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__new_fml:op_ack_a|
                              (__ref.evs.op_ack |V0:lclock|))
                         a!1)))
           (= (ref.evs.op_ack |V0:lclock|) a!2))))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__m__old_l2s_g_0_a_a |V0:lclock|) (__m_l2s_g_0_a |V0:lclock|)))
       (= __ts0new__old_l2s_g_5_a_a __m_l2s_g_5)
       (= __ts0new__old_l2s_g_6_a_a __m_l2s_g_6)
       (= __ts0new__old_l2s_g_9_a_a __m_l2s_g_9)
       (= __ts0new__old_l2s_g_10_a_a __m_l2s_g_10)
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__ts0__new_fml:m_a_a|
                              (__ref.evs.m |V0:lclock|))
                         (__ref.evs.m |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__new_fml:m_a_a|
                              (__ref.evs.m |V0:lclock|))
                         a!1)))
           (= (ref.evs.m |V0:lclock|) a!2))))
       a!420
       (= __ts0__m_l2s_w_4_a_a
          (and __ts0__m_l2s_w_4_b (not __m_l2s_g_5_a) (not __m_l2s_g_9_a)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ts0__m_ref.mem_memc_exception_c
                                |T0:lclock|
                                |T1:lclock|)))))
           (= (__ts0__m_ref.prevents_b_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc))))
           (= (__ts0__m_ref.mem_memc_exception_c |T0:lclock| |T1:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__m_rfn.evqual_c |M:mem_type| |T:lclock|) a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_pushing.now
                         (__dramc_nb2.evma dramc_nb2.memc_pushing.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_pushing.value) read))))
           (= (__ts0__m_dramc_nb2.push_trying_rd_b |M:mem_type| |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_arriving.now
                         (__dramc_nb2.evma dramc_nb2.memc_arriving.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_arriving.value) read))))
           (= (__ts0__m_dramc_nb2.push_success_rd_b |M:mem_type| |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (__dramc_nb2.evma |T:lclock|
                                           |M:mem_type|
                                           |A:addr_type|))))
           (= (__ts0__m_dramc_nb2.evqual_rd_d
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_pushing.now
                         (__dramc_nb2.evma dramc_nb2.memc_pushing.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_pushing.value) write))))
           (= (__ts0__m_dramc_nb2.push_trying_wr_b |M:mem_type| |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_arriving.now
                         (__dramc_nb2.evma dramc_nb2.memc_arriving.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_arriving.value) write))))
           (= (__ts0__m_dramc_nb2.push_success_wr_b |M:mem_type| |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (__dramc_nb2.evma |T:lclock|
                                           |M:mem_type|
                                           |A:addr_type|))))
           (= (__ts0__m_dramc_nb2.evqual_wr_d
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (= _old_l2s_g_5
          (ite __ts0_c
               __m_l2s_g_5_a
               (ite __ts0__ts0_d_a __m_l2s_g_5_a ___old_l2s_g_5)))
       (= _old_l2s_g_6
          (ite __ts0_c
               __m_l2s_g_6_a
               (ite __ts0__ts0_d_a __m_l2s_g_6_a ___old_l2s_g_6)))
       (= _old_l2s_g_9
          (ite __ts0_c
               __m_l2s_g_9_a
               (ite __ts0__ts0_d_a __m_l2s_g_9_a ___old_l2s_g_9)))
       (= _old_l2s_g_10
          (ite __ts0_c
               __m_l2s_g_10_a
               (ite __ts0__ts0_d_a __m_l2s_g_10_a ___old_l2s_g_10)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__ts0__new_fml:a_a_a|
                              (__ref.evs.a |V0:lclock|))
                         (__ref.evs.a |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__new_fml:a_a_a|
                              (__ref.evs.a |V0:lclock|))
                         a!1)))
           (= (ref.evs.a |V0:lclock|) a!2))))
       (= l2s_w_3 a!422)
       (= l2s_w_4 a!423)
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ts0__m_ref.mem_memc_exception_a_a
                                |T0:lclock|
                                |T1:lclock|)))))
           (= (__ts0__m_ref.prevents_c_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc))))
           (= (__ts0__m_ref.mem_memc_exception_a_a |T0:lclock| |T1:lclock|) a!1)))
       a!424
       a!425
       a!426
       a!427
       a!428
       a!429
       a!430
       (forall ((|V0:lclock| lclock))
         (= (__ts0new__old_l2s_g_0_b_a |V0:lclock|) (__m_l2s_g_0_b |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0new__old_l2s_g_1_a_a |V0:lclock|) (__m_l2s_g_1 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0new__old_l2s_g_2_a_a |V0:lclock|) (__m_l2s_g_2 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__ts0__new_fml:mem_loc_a|
                              (__ref.evs.mem_loc |V0:lclock|))
                         (__ref.evs.mem_loc |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__new_fml:mem_loc_a|
                              (__ref.evs.mem_loc |V0:lclock|))
                         a!1)))
           (= (ref.evs.mem_loc |V0:lclock|) a!2))))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (and (__ts0__ts0__m_l2s_w_0_a |V0:lclock|)
                              (not (rfn.evcomplete |V0:lclock|))
                              (not (l2s_g_2 |V0:lclock|)))
                         (__l2s_w_0 |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (and (__ts0__m_l2s_w_0_a |V0:lclock|)
                              (not (rfn.evcomplete |V0:lclock|))
                              (not (l2s_g_2 |V0:lclock|)))
                         a!1)))
           (= (l2s_w_0 |V0:lclock|) a!2))))
       a!431
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc))))
           (= (__ts0__m_ref.mem_memc_exception_b_a |T0:lclock| |T1:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__m_cf_live.issued_memc_b |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__m_rfn.evqual_a_a |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (__ts0__m_rfn.evcomplete_a |T:lclock|) a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__m_dramc_nb2.evqual_rd_b_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__m_dramc_nb2.evqual_wr_b_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              false
                              (__ref.evs.serialized |V0:lclock|))
                         (__ref.evs.serialized |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              false
                              (__ref.evs.serialized |V0:lclock|))
                         a!1)))
           (= (ref.evs.serialized |V0:lclock|) a!2))))
       a!432
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__ts0__new_fml:l_a|
                              (__ref.evs.l_req |V0:lclock|))
                         (__ref.evs.l_req |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |__ts0__new_fml:l_a|
                              (__ref.evs.l_req |V0:lclock|))
                         a!1)))
           (= (ref.evs.l_req |V0:lclock|) a!2))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__m_ref.prevents_e_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__m_cf_live.issued_memc_a_a |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__m_rfn.evqual_b_a |M:mem_type| |T:lclock|) a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__m_dramc_nb2.evqual_rd_c_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__m_dramc_nb2.evqual_wr_c_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0_d_a
                         (ite (and (= |V0:lclock| ref.lt))
                              |0:tar_clock|
                              (__ref.evs.lt_arr |V0:lclock|))
                         (__ref.evs.lt_arr |V0:lclock|))))
         (let ((a!2 (ite __ts0_c
                         (ite (and (= |V0:lclock| ref.lt))
                              |0:tar_clock|
                              (__ref.evs.lt_arr |V0:lclock|))
                         a!1)))
           (= (ref.evs.lt_arr |V0:lclock|) a!2))))
       (= __ts0__ts0_a_a_b (= |__new_loc:mem_loc| mem_memc))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (and (= |V0:proc| |__fml:p|)
                         (= |V1:mem_type| |__fml:m|)
                         (= |V2:addr_type| |__fml:a|)
                         (= |V3:lclock| ref.lt))))
         (let ((a!2 (ite __ts0_c
                         (__isd.rd |V0:proc|
                                   |V1:mem_type|
                                   |V2:addr_type|
                                   |V3:lclock|)
                         (ite __ts0__ts0_d_a
                              (ite a!1
                                   true
                                   (__isd.rd |V0:proc|
                                             |V1:mem_type|
                                             |V2:addr_type|
                                             |V3:lclock|))
                              (__isd.rd |V0:proc|
                                        |V1:mem_type|
                                        |V2:addr_type|
                                        |V3:lclock|)))))
           (= (isd.rd |V0:proc| |V1:mem_type| |V2:addr_type| |V3:lclock|) a!2))))
       a!433
       (= cfabric.t_rd_arr_min a!434)
       a!435
       (= |__ts0__ts0__new_fml:p_a_b| |__fml:p|)
       (= |__ts0__ts0__new_fml:lt_a| ref.lt)
       (= |__ts0__ts0__ts0__new_fml:x_a| __ref.lt_tar_cf)
       (= |__ts0__ts0__new_fml:p_a_a_a| |__fml:p|)
       (= |__ts0__ts0__new_fml:op_a| read)
       (= |__ts0__ts0__new_fml:op_ack_a| |__new_loc:op_ack|)
       (= |__ts0__ts0__new_fml:m_a_a| |__fml:m|)
       (= |__ts0__ts0__new_fml:a_a_a| |__fml:a|)
       (= |__ts0__ts0__new_fml:mem_loc_a| |__new_loc:mem_loc|)
       (= |__ts0__ts0__new_fml:l_a| (ite __ts0__ts0__ts0_c_a cf_mem_l cf_pio_l))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0__m__old_l2s_g_0_b |V0:lclock|) (__l2s_g_0 |V0:lclock|)))
       (= __ts0__ts0__m__old_l2s_g_5_a __l2s_g_5)
       (= __ts0__ts0__m__old_l2s_g_6_a __l2s_g_6)
       (= __ts0__ts0__m__old_l2s_g_9_a __l2s_g_9)
       (= __ts0__ts0__m__old_l2s_g_10_a __l2s_g_10)
       a!436
       (= __ts0__ts0__m_l2s_w_4_b
          (and __l2s_w_4 (not __m_l2s_g_5) (not __m_l2s_g_9)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                        (not (= (__ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__ts0__m_ref.prevents_f |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0new__old_l2s_g_0_a_a |V0:lclock|)
            (__m_l2s_g_0 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0__m__old_l2s_g_1_a |V0:lclock|) (__l2s_g_1 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0__m__old_l2s_g_2_a |V0:lclock|) (__l2s_g_2 |V0:lclock|)))
       a!437
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (__ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__ts0__m_ref.prevents_a_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0__m__old_l2s_g_0_a_a |V0:lclock|)
            (__m_l2s_g_0_a |V0:lclock|)))
       (= __ts0__ts0new__old_l2s_g_5_a_a __m_l2s_g_5)
       (= __ts0__ts0new__old_l2s_g_6_a_a __m_l2s_g_6)
       (= __ts0__ts0new__old_l2s_g_9_a_a __m_l2s_g_9)
       (= __ts0__ts0new__old_l2s_g_10_a_a __m_l2s_g_10)
       a!438
       (= __ts0__ts0__m_l2s_w_4_a_a
          (and __ts0__ts0__m_l2s_w_4_b (not __m_l2s_g_5_a) (not __m_l2s_g_9_a)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ts0__ts0__m_ref.mem_memc_exception_c
                                |T0:lclock|
                                |T1:lclock|)))))
           (= (__ts0__ts0__m_ref.prevents_b_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (__ref.evs.m |T0:lclock|) (__ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc))))
           (= (__ts0__ts0__m_ref.mem_memc_exception_c |T0:lclock| |T1:lclock|)
              a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__ts0__m_rfn.evqual_c |M:mem_type| |T:lclock|) a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_pushing.now
                         (__dramc_nb2.evma dramc_nb2.memc_pushing.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_pushing.value) read))))
           (= (__ts0__ts0__m_dramc_nb2.push_trying_rd_b
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_arriving.now
                         (__dramc_nb2.evma dramc_nb2.memc_arriving.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_arriving.value) read))))
           (= (__ts0__ts0__m_dramc_nb2.push_success_rd_b
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (__dramc_nb2.evma |T:lclock|
                                           |M:mem_type|
                                           |A:addr_type|))))
           (= (__ts0__ts0__m_dramc_nb2.evqual_rd_d
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_pushing.now
                         (__dramc_nb2.evma dramc_nb2.memc_pushing.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_pushing.value) write))))
           (= (__ts0__ts0__m_dramc_nb2.push_trying_wr_b
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
         (let ((a!1 (and dramc_nb2.memc_arriving.now
                         (__dramc_nb2.evma dramc_nb2.memc_arriving.value
                                           |M:mem_type|
                                           |A:addr_type|)
                         (= (ref.evs.req dramc_nb2.memc_arriving.value) write))))
           (= (__ts0__ts0__m_dramc_nb2.push_success_wr_b
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (__dramc_nb2.evma |T:lclock|
                                           |M:mem_type|
                                           |A:addr_type|))))
           (= (__ts0__ts0__m_dramc_nb2.evqual_wr_d
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ts0__ts0__m_ref.mem_memc_exception_a_a
                                |T0:lclock|
                                |T1:lclock|)))))
           (= (__ts0__ts0__m_ref.prevents_c_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (__ref.evs.a |T0:lclock|) (__ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc))))
           (= (__ts0__ts0__m_ref.mem_memc_exception_a_a |T0:lclock| |T1:lclock|)
              a!1)))
       a!439
       a!440
       a!441
       a!442
       a!443
       a!444
       a!445
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0new__old_l2s_g_0_b_a |V0:lclock|)
            (__m_l2s_g_0_b |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0new__old_l2s_g_1_a_a |V0:lclock|)
            (__m_l2s_g_1 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0new__old_l2s_g_2_a_a |V0:lclock|)
            (__m_l2s_g_2 |V0:lclock|)))
       a!446
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= (__ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (__ref.evs.mem_loc |T1:lclock|) mem_memc))))
           (= (__ts0__ts0__m_ref.mem_memc_exception_b_a |T0:lclock| |T1:lclock|)
              a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__ts0__m_cf_live.issued_memc_b |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__ts0__m_rfn.evqual_a_a |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (__ts0__ts0__m_rfn.evcomplete_a |T:lclock|) a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__ts0__m_dramc_nb2.evqual_rd_b_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (__ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__ts0__m_dramc_nb2.evqual_wr_b_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__ts0__m_ref.prevents_e_a |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__ts0__m_cf_live.issued_memc_a_a |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__ts0__ts0__m_rfn.evqual_b_a |M:mem_type| |T:lclock|) a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__ts0__m_dramc_nb2.evqual_rd_c_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (forall ((|A:addr_type| addr_type)
                (|M:mem_type| mem_type)
                (|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                         (= (__ref.evs.l_req |T:lclock|) memc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))
           (= (__ts0__ts0__m_dramc_nb2.evqual_wr_c_a
                |T:lclock|
                |M:mem_type|
                |A:addr_type|)
              a!1)))
       (= |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| ref.lt)
       (= __ts0__ts0__ts0__ts0__new_cfabric.t_rd_min_a_a_a_a |__fml:y_a_a_a|)
       (= __ts0__ts0__ts0_c_a (= |__new_loc:mem_loc| mem_memc))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0new__old_l2s_g_1_b_a |V0:lclock|)
            (___old_l2s_g_1 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (__ts0__ts0new__old_l2s_g_2_b_a |V0:lclock|)
            (___old_l2s_g_2 |V0:lclock|)))
       (= __ts0__ts0_d_a
          (and (= |__fml:ph| rd_ph) |__new_loc:rd| (not |__new_loc:ordser|)))
       (= __ts0_c
          (and (= |__fml:ph| wr_ph) |__new_loc:wr| (not |__new_loc:ordser|)))
       a!447
       a!448
       a!449
       a!450
       a!451
       a!452
       a!453
       a!454
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       a!455
       a!456
       a!457
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T0:lclock|) nGnRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T1:lclock|) nGnRE)))))
           (= (ref.both_nGnR |T0:lclock| |T1:lclock|) a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGRE)
                             (= (ref.evs.op_ack |T0:lclock|) _GRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGRE)
                             (= (ref.evs.op_ack |T1:lclock|) _GRE)))))
           (= (ref.both_nGR |T0:lclock| |T1:lclock|) a!1)))
       a!458
       a!459
       a!460
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (cf_live.issued_memc |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (rfn.evqual |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (rfn.evcomplete |T:lclock|) a!1)))
       a!461
       a!462
       a!463
       a!464
       a!465
       a!466
       a!467))))
(assert (let ((a!1 (or (not (forall ((|T:lclock| lclock)) (l2s_s_0 |T:lclock|))))))
(let ((a!2 (not (=> (and (not l2s_s_1) (not a!1) l2s_saved true (not l2s_w_3))
                    (and (not l2s_s_1) (=> true false))))))
  (and a!2))))
(check-sat)
(get-info :all-statistics)
