; GoIvy dramc_nb2 verification condition 369. Source ord_live.ivy, Copyright 2023 Apple, Inc. See LICENSE.txt.
(declare-sort lclock 0)
(declare-datatypes ((op_type 0)) (((nop) (write) (read) (rrsp) (wr_cmp))))
(declare-sort proc 0)
(declare-sort tar_cf_clock 0)
(declare-datatypes ((mem_loc_type 0)) (((mem_loc_init) (mem_memc) (pio_memc))))
(declare-datatypes ((loc_type 0)) (((init_l) (cf_mem_l) (cf_pio_l) (cf_cmp_l) (if_l) (memc_l) (dramc_l) (arm_l))))
(declare-sort tar_clock 0)
(declare-sort index 0)
(declare-datatypes ((ph_type 0)) (((nop_ph) (wr_ph) (rd_ph) (cpl_ph))))
(declare-datatypes ((op_ack_type 0)) (((nGnRnE) (nGnRE) (nGRE) (_GRE) (normal))))
(declare-sort addr_type 0)
(declare-sort mem_type 0)
(declare-fun dramc_nb2.evma (lclock mem_type addr_type) Bool)
(declare-fun ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun ref.evs.l_req (lclock) loc_type)
(declare-fun ref.evs.req (lclock) op_type)
(declare-fun dramc_nb2.evqual_wr (lclock mem_type addr_type) Bool)
(declare-fun dramc_nb2.memc_arriving.value () lclock)
(declare-fun dramc_nb2.memc_arriving.now () Bool)
(declare-fun dramc_nb2.push_success_wr (mem_type addr_type) Bool)
(declare-fun dramc_nb2.memc_pushing.value () lclock)
(declare-fun dramc_nb2.memc_pushing.now () Bool)
(declare-fun dramc_nb2.push_trying_wr (mem_type addr_type) Bool)
(declare-fun dramc_nb2.evqual_rd (lclock mem_type addr_type) Bool)
(declare-fun dramc_nb2.push_success_rd (mem_type addr_type) Bool)
(declare-fun dramc_nb2.push_trying_rd (mem_type addr_type) Bool)
(declare-fun ref.evs.a (lclock) addr_type)
(declare-fun ref.evs.m (lclock) mem_type)
(declare-fun ref.evs.l_cmp (lclock) loc_type)
(declare-fun ref.evs.cmp (lclock) op_type)
(declare-fun rfn.evcomplete (lclock) Bool)
(declare-fun rfn.evqual (mem_type lclock) Bool)
(declare-fun cf_live.issued_memc (lclock) Bool)
(declare-fun ref.nGnR (op_ack_type) Bool)
(declare-fun ref.evs.op_ack (lclock) op_ack_type)
(declare-fun ref.nGR (op_ack_type) Bool)
(declare-fun ref.dev (lclock) Bool)
(declare-fun ref.both_nGR (lclock lclock) Bool)
(declare-fun ref.both_nGnR (lclock lclock) Bool)
(declare-fun ref.both_normal (lclock lclock) Bool)
(declare-fun ref.same_attr (lclock lclock) Bool)
(declare-fun ref.mem_memc_exception (lclock lclock) Bool)
(declare-fun ref.evs.p (lclock) proc)
(declare-fun |<:lclock:lclock| (lclock lclock) Bool)
(declare-fun ref.evs.serialized (lclock) Bool)
(declare-fun ref.prevents (lclock lclock) Bool)
(declare-fun __l2s_d_d (tar_cf_clock) Bool)
(declare-fun l2s_d (tar_cf_clock) Bool)
(declare-fun |__fml:ph| () ph_type)
(declare-fun __ts0_e () Bool)
(declare-fun __ts0__ts0_d_a () Bool)
(declare-fun |__new_loc:tt| () lclock)
(declare-fun |0:lclock| () lclock)
(declare-fun |__new_loc:ordpip| () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ref.evs.serialized (lclock) Bool)
(declare-fun __ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun __ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun __ref.evs.cmp (lclock) op_type)
(declare-fun __ref.evs.req (lclock) op_type)
(declare-fun __l2s_w_0 (lclock) Bool)
(declare-fun l2s_w_0 (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun __cmpl_live.arm_cpl (lclock) Bool)
(declare-fun cmpl_live.arm_cpl (lclock) Bool)
(declare-fun __cmpl_live.cf_cpl (lclock) Bool)
(declare-fun cmpl_live.cf_cpl (lclock) Bool)
(declare-fun __ref.evs.l_cmp (lclock) loc_type)
(declare-fun __l2s_g_2 (lclock) Bool)
(declare-fun l2s_g_2 (lclock) Bool)
(declare-fun ___old_l2s_g_2 (lclock) Bool)
(declare-fun _old_l2s_g_2 (lclock) Bool)
(declare-fun __l2s_g_1 (lclock) Bool)
(declare-fun l2s_g_1 (lclock) Bool)
(declare-fun ___old_l2s_g_1 (lclock) Bool)
(declare-fun _old_l2s_g_1 (lclock) Bool)
(declare-fun __ref.evs.l_req (lclock) loc_type)
(declare-fun |__fml:a| () addr_type)
(declare-fun |__fml:m| () mem_type)
(declare-fun __ts0_b_a () Bool)
(declare-fun __dramc_nb2.memc_arriving.now () Bool)
(declare-fun __l2s_w_4 () Bool)
(declare-fun l2s_w_4 () Bool)
(declare-fun __dramc_nb2.memc_arriving.value () lclock)
(declare-fun __l2s_g_9 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun ___old_l2s_g_9 () Bool)
(declare-fun _old_l2s_g_9 () Bool)
(declare-fun __l2s_g_5 () Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun ___old_l2s_g_5 () Bool)
(declare-fun _old_l2s_g_5 () Bool)
(declare-fun |__new_fml:lt_b| () lclock)
(declare-fun |__new_loc:m| () mem_type)
(declare-fun __ts0_a_a () Bool)
(declare-fun __rfn.abs.begun (mem_type tar_clock) Bool)
(declare-fun rfn.abs.begun (mem_type tar_clock) Bool)
(declare-fun __rfn.abs.queue (mem_type tar_clock) Bool)
(declare-fun rfn.abs.queue (mem_type tar_clock) Bool)
(declare-fun |__new_fml:kind| () Bool)
(declare-fun ref.evs.lt_arr (lclock) tar_clock)
(declare-fun |__new_fml:lt_a| () tar_clock)
(declare-fun |__new_prm:M| () mem_type)
(declare-fun __l2s_g_0 (lclock) Bool)
(declare-fun _old_l2s_g_0 (lclock) Bool)
(declare-fun __ref.evs.lt_arr (lclock) tar_clock)
(declare-fun ref.lt_tar (mem_type) tar_clock)
(declare-fun __ref.lt_tar (mem_type) tar_clock)
(declare-fun |__fml:y| () tar_clock)
(declare-fun |__new_fml:x| () tar_clock)
(declare-fun __m_dramc_nb2.memc_pushing.now () Bool)
(declare-fun __m_dramc_nb2.push_trying_wr_a (mem_type addr_type) Bool)
(declare-fun __m_dramc_nb2.push_trying_rd_a (mem_type addr_type) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _A () addr_type)
(declare-fun _M () mem_type)
(declare-fun __m_l2s_w_3_a () Bool)
(declare-fun l2s_w_3 () Bool)
(declare-fun __m_l2s_g_10_a () Bool)
(declare-fun _old_l2s_g_10 () Bool)
(declare-fun __m_l2s_g_6_a () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun __dramc_nb2.memc_pushing.now () Bool)
(declare-fun __m_dramc_nb2.push_trying_wr (mem_type addr_type) Bool)
(declare-fun __m_dramc_nb2.push_trying_rd (mem_type addr_type) Bool)
(declare-fun __m_l2s_w_3 () Bool)
(declare-fun __m_l2s_g_10 () Bool)
(declare-fun new__old_l2s_g_10_a () Bool)
(declare-fun __m_l2s_g_6 () Bool)
(declare-fun new__old_l2s_g_6_a () Bool)
(declare-fun __l2s_w_3 () Bool)
(declare-fun |__new_fml:val| () lclock)
(declare-fun __l2s_g_10 () Bool)
(declare-fun __m__old_l2s_g_10 () Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun __m__old_l2s_g_6 () Bool)
(declare-fun |__new_fml:lt| () lclock)
(declare-fun |__m_loc:ordpip| () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun |__loc:t| () lclock)
(declare-fun |__m_loc:tt| () lclock)
(declare-fun __m_memc.cpl_fair (proc mem_type addr_type lclock) Bool)
(declare-fun |__fml:lt| () lclock)
(declare-fun |__fml:p| () proc)
(declare-fun memc.cpl_fair (proc mem_type addr_type lclock) Bool)
(declare-fun __memc.cpl_fair (proc mem_type addr_type lclock) Bool)
(declare-fun memc.wr_fair (mem_type addr_type) Bool)
(declare-fun __memc.wr_fair (mem_type addr_type) Bool)
(declare-fun __m_memc.wr_fair (mem_type addr_type) Bool)
(declare-fun memc.rd_fair (mem_type addr_type) Bool)
(declare-fun __memc.rd_fair (mem_type addr_type) Bool)
(declare-fun __m_memc.rd_fair (mem_type addr_type) Bool)
(declare-fun __l2s_d_c (lclock) Bool)
(declare-fun l2s_d (lclock) Bool)
(declare-fun __l2s_d_b (addr_type) Bool)
(declare-fun l2s_d (addr_type) Bool)
(declare-fun __l2s_d_a (mem_type) Bool)
(declare-fun l2s_d (mem_type) Bool)
(declare-fun __l2s_d (proc) Bool)
(declare-fun l2s_d (proc) Bool)
(declare-fun __dramc_nb2.evqual_wr (lclock mem_type addr_type) Bool)
(declare-fun __dramc_nb2.push_success_wr (mem_type addr_type) Bool)
(declare-fun __dramc_nb2.memc_pushing.value () lclock)
(declare-fun __dramc_nb2.push_trying_wr (mem_type addr_type) Bool)
(declare-fun __dramc_nb2.evqual_rd (lclock mem_type addr_type) Bool)
(declare-fun __dramc_nb2.push_success_rd (mem_type addr_type) Bool)
(declare-fun __dramc_nb2.push_trying_rd (mem_type addr_type) Bool)
(declare-fun __rfn.evcomplete (lclock) Bool)
(declare-fun __rfn.evqual (mem_type lclock) Bool)
(declare-fun __cf_live.issued_memc (lclock) Bool)
(declare-fun __ref.mem_memc_exception (lclock lclock) Bool)
(declare-fun __ref.prevents (lclock lclock) Bool)
(declare-fun |<:tar_cf_clock:tar_cf_clock| (tar_cf_clock tar_cf_clock) Bool)
(declare-fun |0:tar_cf_clock| () tar_cf_clock)
(declare-fun tar_cf_clock.succ (tar_cf_clock tar_cf_clock) Bool)
(declare-fun |<:tar_clock:tar_clock| (tar_clock tar_clock) Bool)
(declare-fun |0:tar_clock| () tar_clock)
(declare-fun tar_clock.succ (tar_clock tar_clock) Bool)
(declare-fun lclock.succ (lclock lclock) Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun |0:index| () index)
(declare-fun index.succ (index index) Bool)
(declare-fun __X () tar_clock)
(declare-fun l2s_g_0 (lclock) Bool)
(declare-fun rfn.abs.done (mem_type tar_clock) Bool)
(declare-fun rfn.abs.lastq (mem_type) tar_clock)
(declare-fun rfn.abs.trying2.now (mem_type) Bool)
(declare-fun rfn.abs.trying1.now (mem_type) Bool)
(declare-fun l2s_g_10 () Bool)
(declare-fun isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun |__loc:pp| () proc)
(declare-fun isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun dramc.wr_fair (mem_type) Bool)
(declare-fun dramc.rd_fair (mem_type) Bool)
(declare-fun ref.pio (lclock) Bool)
(declare-fun isd.rsp (proc mem_type addr_type lclock) Bool)
(declare-fun ref.lt () lclock)
(declare-fun ref.same_addr (lclock lclock) Bool)
(declare-fun ref.evs.lt_tar (lclock) tar_clock)
(declare-fun dramc.t_min (mem_type) tar_clock)
(declare-fun ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun cfabric.t_rd_min () lclock)
(declare-fun cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun ref.lt_tar_cf () tar_cf_clock)
(declare-fun l2s_w_2 () Bool)
(declare-fun l2s_w_1 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_init_7 () Bool)
(declare-fun l2s_init_8 () Bool)
(declare-fun l2s_init_6 () Bool)
(declare-fun l2s_init_5 () Bool)
(declare-fun l2s_init_0 (lclock) Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_init_4 () Bool)
(declare-fun l2s_init_3 () Bool)
(declare-fun l2s_init_2 () Bool)
(declare-fun l2s_s_1 () Bool)
(declare-fun l2s_s_0 (lclock) Bool)
(declare-fun l2s_init_1 (lclock) Bool)
(declare-fun l2s_a (lclock) Bool)
(assert (let ((a!1 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (ref.evs.a |T:lclock|) _A))))
               (=> (and (not l2s_init_7) (or (not l2s_waiting) (not __l2s_w_4)))
                   (=> a!1
                       (or (= |T:lclock| ref.lt)
                           (|<:lclock:lclock| |T:lclock| ref.lt)))))))
      (a!2 (forall ((|T:lclock| lclock))
             (=> (or (= |T:lclock| ref.lt)
                     (|<:lclock:lclock| |T:lclock| ref.lt))
                 (and (__l2s_d_c |T:lclock|)))))
      (a!3 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (ref.evs.a |T:lclock|) _A))))
               (=> (and (not l2s_init_7) (not l2s_waiting))
                   (=> (not (=> a!1 false)) (and (l2s_a |T:lclock|)))))))
      (a!4 (forall ((|T:lclock| lclock))
             (=> (and (not l2s_init_7) l2s_saved)
                 (=> (not (l2s_s_0 |T:lclock|)) (and (l2s_a |T:lclock|))))))
      (a!5 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (ref.evs.a |T:lclock|) _A))))
               (=> (and l2s_saved (l2s_s_0 |T:lclock|)) (=> a!1 false)))))
      (a!6 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                             (__rfn.evqual _M |T:lclock|)
                             (= (ref.evs.a |T:lclock|) _A))))
               (=> (and (not (l2s_s_0 |T:lclock|))
                        (not false)
                        l2s_saved
                        (not l2s_init_7)
                        (not (__l2s_w_0 |T:lclock|)))
                   (and (not (l2s_s_0 |T:lclock|)) (=> a!1 false))))))
      (a!7 (=> (and true (not l2s_waiting)) (=> (not (=> true false)) true)))
      (a!8 (or (not (forall ((|T:lclock| lclock)) (l2s_s_0 |T:lclock|)))))
      (a!9 (not (and (not l2s_init_7) (or (not l2s_waiting) (not __l2s_w_4)))))
      (a!11 (=> (and (not l2s_init_7) (or (not l2s_waiting) (not __l2s_w_4)))
                __l2s_g_5))
      (a!12 (and (=> (and l2s_init_5 l2s_init_6)
                     (forall ((|T:lclock| lclock)) (l2s_init_0 |T:lclock|)))))
      (a!14 (forall ((|T:lclock| lclock) (|Tarr:tar_cf_clock| tar_cf_clock))
              (let ((a!1 (exists ((|\|T:lclock\|!1| lclock))
                           (and (= (__ref.evs.req |\|T:lclock\|!1|) read)
                                (= (__ref.evs.l_req |\|T:lclock\|!1|) cf_mem_l)
                                (= (ref.evs.lt_arr_cf |\|T:lclock\|!1|)
                                   cfabric.t_rd_arr_min)))))
                (=> (and (= cfabric.t_rd_arr_min |Tarr:tar_cf_clock|)
                         (= (__ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l))
                    a!1))))
      (a!15 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.req |T:lclock|) read)
                       (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (= |T:lclock| ref.lt))
                  (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf))))
      (a!16 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (not (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!17 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                        (|<:tar_cf_clock:tar_cf_clock|
                          (ref.evs.lt_arr_cf |T:lclock|)
                          ref.lt_tar_cf))))))
      (a!18 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                  (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                      (|<:tar_cf_clock:tar_cf_clock|
                        (ref.evs.lt_arr_cf |T:lclock|)
                        ref.lt_tar_cf)))))
      (a!19 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                  (|<:tar_cf_clock:tar_cf_clock|
                    (ref.evs.lt_arr_cf |T:lclock|)
                    ref.lt_tar_cf))))
      (a!20 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (or (= (__ref.evs.l_req |T:lclock|) memc_l)
                                  (= (__ref.evs.l_req |T:lclock|) dramc_l)))))
              (let ((a!2 (and (or a!1 (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!2
                    (|<:tar_cf_clock:tar_cf_clock|
                      (ref.evs.lt_arr_cf |T:lclock|)
                      cfabric.t_rd_arr_min))))))
      (a!21 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (__ref.evs.req |T0:lclock|) read)
                       (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (__ref.evs.req |T1:lclock|) read)
                       (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_cf_clock:tar_cf_clock|
                    (ref.evs.lt_arr_cf |T0:lclock|)
                    (ref.evs.lt_arr_cf |T1:lclock|)))))
      (a!22 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (and (= (__ref.evs.req |T:lclock|) nop)
                                   (= (__ref.evs.cmp |T:lclock|) nop)))))
                (=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|)))
                    a!1))))
      (a!23 (forall ((|T:lclock| lclock))
              (=> (or (|<:lclock:lclock| ref.lt |T:lclock|)
                      (= |T:lclock| |0:lclock|))
                  (and (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|)
                       (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|)))))
      (a!24 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= cfabric.t_rd_arr_min (ref.evs.lt_arr_cf |T:lclock|))
                        (|<:tar_cf_clock:tar_cf_clock|
                          cfabric.t_rd_arr_min
                          (ref.evs.lt_arr_cf |T:lclock|)))))))
      (a!25 (forall ((|T:lclock| lclock))
              (not (and (= (__ref.evs.req |T:lclock|) read)
                        (= (__ref.evs.l_req |T:lclock|) cf_mem_l)))))
      (a!26 (forall ((|T:lclock| lclock))
              (and (= (__ref.evs.req |T:lclock|) nop)
                   (= (__ref.evs.cmp |T:lclock|) nop))))
      (a!27 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (not (= (ref.evs.mem_loc |T:lclock|) mem_memc)))))
              (let ((a!2 (or (and (= (__ref.evs.req |T:lclock|) nop)
                                  (= (__ref.evs.cmp |T:lclock|) nop))
                             (= (__ref.evs.req |T:lclock|) write)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             a!1)))
                (=> a!2 (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!28 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T1:lclock|) read)
                              (not (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
              (let ((a!2 (and (= (__ref.evs.req |T0:lclock|) read)
                              (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  a!1
                                  (= (__ref.evs.req |T1:lclock|) nop)))))
                (=> a!2
                    (not (= (ref.evs.lt_arr_cf |T1:lclock|)
                            cfabric.t_rd_arr_min)))))))
      (a!29 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1 (not (|<:lclock:lclock| |T:lclock| cfabric.t_rd_min))))))
      (a!30 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                              (not (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                    (a!2 (=> (and (= (__ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                             (= (__ref.evs.l_req |T:lclock|) cf_mem_l))))
              (let ((a!3 (and (or (= (__ref.evs.cmp |T:lclock|) nop)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                                  a!1)
                              a!2)))
                (=> (|<:lclock:lclock| cfabric.t_rd_min |T:lclock|) a!3)))))
      (a!31 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.req |T:lclock|) write)
                             (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (__ref.evs.cmp |T:lclock|) rrsp))))
                (=> a!1 (not (= cfabric.t_rd_min |0:lclock|))))))
      (a!32 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T:lclock|) write)
                              (or (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                                  (= (__ref.evs.l_req |T:lclock|) cf_pio_l)))))
                (=> a!1 (not (= |T:lclock| cfabric.t_rd_min))))))
      (a!33 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (not (and (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)))))
              (let ((a!2 (or (= (__ref.evs.req |T1:lclock|) write)
                             (and (= (__ref.evs.req |T1:lclock|) read) a!1)
                             (= (__ref.evs.req |T1:lclock|) nop))))
                (=> (and (= (__ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2)
                    (not (= |T1:lclock| cfabric.t_rd_min)))))))
      (a!34 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.req |T:lclock|) write)
                             (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (__ref.evs.cmp |T:lclock|) rrsp))))
                (=> (and a!1 (= (ref.evs.mem_loc |T:lclock|) pio_memc))
                    (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!35 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (ref.evs.a |T:lclock|) |A:addr_type|)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|))))))
      (a!36 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (ref.evs.a |T:lclock|) |A:addr_type|)
                              (not (= (__ref.evs.l_req |T:lclock|) dramc_l)))))
                (=> a!1 (= (__ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!37 (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (dramc.t_min |M:mem_type|) |0:tar_clock|))))))
      (a!38 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T0:lclock|) read))
                              (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) read))
                              (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))))
                    (a!2 (or (|<:tar_clock:tar_clock|
                               (__ref.evs.lt_arr |T0:lclock|)
                               (dramc.t_min (ref.evs.m |T0:lclock|)))
                             (|<:tar_clock:tar_clock|
                               (__ref.evs.lt_arr |T1:lclock|)
                               (dramc.t_min (ref.evs.m |T0:lclock|))))))
                (=> a!1 (not a!2)))))
      (a!39 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) read)
                  (= (__ref.evs.l_cmp |T:lclock|) init_l))))
      (a!40 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) write)
                  (= (__ref.evs.l_cmp |T:lclock|) init_l))))
      (a!41 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) nop)
                  (= (__ref.evs.l_req |T:lclock|) init_l))))
      (a!42 (forall ((|T:lclock| lclock))
              (or (= (__ref.evs.req |T:lclock|) read)
                  (= (__ref.evs.req |T:lclock|) write)
                  (= (__ref.evs.req |T:lclock|) nop))))
      (a!43 (forall ((|T:lclock| lclock))
              (or (= (__ref.evs.cmp |T:lclock|) rrsp)
                  (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (__ref.evs.cmp |T:lclock|) nop))))
      (a!44 (forall ((|T:lclock| lclock))
              (=> (not (= (__ref.evs.req |T:lclock|) nop))
                  (= (__ref.evs.cmp |T:lclock|) nop))))
      (a!45 (forall ((|T:lclock| lclock))
              (=> (not (= (__ref.evs.cmp |T:lclock|) nop))
                  (= (__ref.evs.req |T:lclock|) nop))))
      (a!46 (forall ((|T:lclock| lclock))
              (let ((a!1 (forall ((|A:addr_type| addr_type)
                                  (|M:mem_type| mem_type)
                                  (|P:proc| proc))
                           (not (or (isd.wr |P:proc|
                                            |M:mem_type|
                                            |A:addr_type|
                                            |T:lclock|)
                                    (isd.rd |P:proc|
                                            |M:mem_type|
                                            |A:addr_type|
                                            |T:lclock|))))))
                (=> a!1
                    (and (= (__ref.evs.l_req |T:lclock|) init_l)
                         (= (__ref.evs.l_cmp |T:lclock|) init_l))))))
      (a!47 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.req |T:lclock|) read))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l)))
                    (a!2 (not (|<:tar_clock:tar_clock|
                                (__ref.lt_tar (ref.evs.m |T:lclock|))
                                (__ref.evs.lt_arr |T:lclock|)))))
                (=> a!1 a!2))))
      (a!48 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (|<:tar_clock:tar_clock|
                      (__ref.evs.lt_arr |T:lclock|)
                      (ref.evs.lt_tar |T:lclock|))))))
      (a!49 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))))
                    (a!3 (and (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|)))
                              (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (__ref.evs.lt_arr |T1:lclock|))))))
              (let ((a!2 (and a!1
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (__ref.evs.l_cmp |T1:lclock|) dramc_l)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!2 a!3)))))
      (a!50 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (__ref.evs.cmp |T0:lclock|) rrsp)))
                    (a!2 (or (and (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) dramc_l))
                             (and (= (__ref.evs.req |T1:lclock|) read)
                                  (= (__ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (__ref.evs.cmp |T1:lclock|) rrsp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) dramc_l))))
                    (a!3 (=> (or (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                                 (= (__ref.evs.cmp |T0:lclock|) rrsp))
                             (not (= (ref.evs.lt_tar |T0:lclock|)
                                     (__ref.evs.lt_arr |T1:lclock|)))))
                    (a!4 (=> (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                 (= (__ref.evs.cmp |T1:lclock|) rrsp))
                             (not (= (__ref.evs.lt_arr |T0:lclock|)
                                     (ref.evs.lt_tar |T1:lclock|))))))
              (let ((a!5 (and (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (__ref.evs.lt_arr |T1:lclock|)))
                              a!3
                              a!4)))
                (=> (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|)))
                    a!5)))))
      (a!51 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|))))
                    (a!2 (and (not (= (__ref.evs.lt_arr |T0:lclock|)
                                      (__ref.evs.lt_arr |T1:lclock|)))
                              (not (= (ref.evs.lt_tar |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|))))))
                (=> a!1 a!2))))
      (a!52 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (not (and (= (__ref.evs.req |T0:lclock|) write)
                        (= (__ref.evs.cmp |T1:lclock|) rrsp)
                        (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (|<:tar_clock:tar_clock|
                          (__ref.evs.lt_arr |T0:lclock|)
                          (__ref.evs.lt_arr |T1:lclock|))))))
      (a!53 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (__ref.evs.req |T0:lclock|) read)
                       (= (__ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (__ref.evs.lt_arr |T0:lclock|)
                    (__ref.evs.lt_arr |T1:lclock|)))))
      (a!54 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.req |T1:lclock|) read))
                             (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) write)))))
                (not (and a!1
                          (= (ref.evs.op_ack |T0:lclock|) normal)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))))
      (a!55 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) write))
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.req |T1:lclock|) read)))))
                (=> (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                         (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    (|<:tar_clock:tar_clock|
                      (__ref.evs.lt_arr |T0:lclock|)
                      (__ref.evs.lt_arr |T1:lclock|))))))
      (a!56 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (|<:tar_clock:tar_clock|
                                (__ref.lt_tar (ref.evs.m |T:lclock|))
                                (ref.evs.lt_tar |T:lclock|)))))
                (=> (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (__ref.evs.cmp |T:lclock|) rrsp))
                    a!1))))
      (a!57 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (or (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!1
                    (not (= (ref.evs.lt_tar |T0:lclock|)
                            (ref.evs.lt_tar |T1:lclock|)))))))
      (a!58 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (__ref.evs.cmp |T0:lclock|) wr_cmp)
                       (= (__ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (ref.evs.lt_tar |T0:lclock|)
                    (ref.evs.lt_tar |T1:lclock|)))))
      (a!59 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.l_req |T0:lclock|) if_l)
                              (or (= (__ref.evs.l_req |T1:lclock|) if_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
                    (a!2 (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                             (= (__ref.evs.l_req |T1:lclock|) if_l)
                             (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
              (let ((a!3 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_pio_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))
                             a!1
                             (and (= (__ref.evs.l_req |T0:lclock|) memc_l) a!2))))
                (=> (and (= (__ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.req |T1:lclock|) read)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!3)))))
      (a!60 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (__ref.evs.serialized |T:lclock|))))
                (=> a!1
                    (or (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T:lclock|) pio_memc))))))
      (a!61 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) write)
                  (not (__ref.evs.serialized |T:lclock|)))))
      (a!62 (forall ((|T:lclock| lclock))
              (=> (= (__ref.evs.req |T:lclock|) read)
                  (not (__ref.evs.serialized |T:lclock|)))))
      (a!63 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.req |T:lclock|) nop)
                       (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                  (__ref.evs.serialized |T:lclock|))))
      (a!64 (forall ((|T:lclock| lclock))
              (=> (__ref.evs.serialized |T:lclock|)
                  (or (= (__ref.evs.req |T:lclock|) nop)
                      (= (__ref.evs.cmp |T:lclock|) nop)
                      (= (__ref.evs.cmp |T:lclock|) rrsp)
                      (= (__ref.evs.cmp |T:lclock|) wr_cmp)))))
      (a!65 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                             (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                                  (not (__ref.evs.serialized |T:lclock|)))))
                    (a!2 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                              (or (= (__ref.evs.l_cmp |T:lclock|) dramc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) memc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) arm_l))))
                    (a!3 (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                              (or (= (__ref.evs.l_cmp |T:lclock|) memc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) if_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) arm_l))))
                    (a!4 (and (__ref.evs.serialized |T:lclock|)
                              (or (= (__ref.evs.cmp |T:lclock|) rrsp)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                              (= (__ref.evs.l_cmp |T:lclock|) init_l))))
                (=> (or (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (__ref.evs.cmp |T:lclock|) rrsp))
                    (or (and a!1 (or a!2 a!3)) a!4)))))
      (a!66 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.l_req |T:lclock|) dramc_l)
                             (= (__ref.evs.l_req |T:lclock|) memc_l)
                             (= (__ref.evs.l_req |T:lclock|) cf_mem_l)))
                    (a!2 (or (= (__ref.evs.l_req |T:lclock|) memc_l)
                             (= (__ref.evs.l_req |T:lclock|) if_l)
                             (= (__ref.evs.l_req |T:lclock|) cf_pio_l))))
              (let ((a!3 (or (and (= (ref.evs.mem_loc |T:lclock|) mem_memc) a!1)
                             (and (= (ref.evs.mem_loc |T:lclock|) pio_memc) a!2))))
                (=> (or (= (__ref.evs.req |T:lclock|) write)
                        (= (__ref.evs.req |T:lclock|) read))
                    a!3)))))
      (a!67 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (= (__ref.evs.cmp |T1:lclock|) rrsp))))
              (let ((a!2 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) init_l))
                             a!1)))
                (not (and a!2
                          (not (__ref.evs.serialized |T0:lclock|))
                          (__ref.evs.serialized |T1:lclock|)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))))
      (a!68 (forall ((|T:lclock| lclock))
              (=> (not (__ref.evs.serialized |T:lclock|))
                  (not (= (ref.evs.mem_loc |T:lclock|) mem_loc_init)))))
      (a!69 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.req |T:lclock|) nop)
                       (= (__ref.evs.cmp |T:lclock|) nop))
                  (= (ref.evs.mem_loc |T:lclock|) mem_loc_init))))
      (a!70 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                             (not (= (__ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (__ref.evs.req |T1:lclock|) nop))
                             (not (= (__ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (= (ref.evs.mem_loc |T0:lclock|)
                       (ref.evs.mem_loc |T1:lclock|)))))))
      (a!71 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                             (not (= (__ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (__ref.evs.req |T1:lclock|) nop))
                             (not (= (__ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (or (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T0:lclock|) pio_memc)))))))
      (a!72 (forall ((|T:lclock| lclock) (|T0:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T:lclock|) nop))
                             (not (= (__ref.evs.cmp |T0:lclock|) nop)))))
                (=> (and a!1 (not (ref.dev |T:lclock|)))
                    (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!73 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (not (= (__ref.evs.req |T:lclock|) nop))
                             (not (= (__ref.evs.cmp |T:lclock|) nop)))))
                (=> (and a!1 (ref.dev |T:lclock|))
                    (or (= (ref.evs.op_ack |T:lclock|) nGnRE)
                        (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                        (= (ref.evs.op_ack |T:lclock|) _GRE)
                        (= (ref.evs.op_ack |T:lclock|) nGRE))))))
      (a!74 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.req |T0:lclock|) read)
                              (or (= (__ref.evs.req |T1:lclock|) read)
                                  (= (__ref.evs.cmp |T1:lclock|) rrsp))
                              (not (__ref.evs.serialized |T0:lclock|))
                              (not (__ref.evs.serialized |T1:lclock|))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (ref.both_normal |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!75 (forall ((|T:lclock| lclock))
              (or (= (__ref.evs.req |T:lclock|) nop)
                  (= (__ref.evs.cmp |T:lclock|) nop)
                  (= (__ref.evs.req |T:lclock|) write)
                  (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (__ref.evs.req |T:lclock|) read)
                  (= (__ref.evs.cmp |T:lclock|) rrsp))))
      (a!76 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!77 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!78 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                  (ref.dev |T:lclock|))))
      (a!79 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (isd.wr |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)
                             (isd.rd |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE)
                             (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                                 (= (ref.evs.op_ack |T:lclock|) nGnRE)))))
                (=> (and a!1 (ref.dev |T:lclock|)) a!2))))
      (a!80 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (isd.wr |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)
                             (isd.rd |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|))))
                (=> (and a!1 (not (ref.dev |T:lclock|)))
                    (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!81 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (isd.rd |P:proc|
                                |M0:mem_type|
                                |A0:addr_type|
                                |T0:lclock|)
                        (ref.same_attr |T0:lclock| |T1:lclock|)
                        (= |M0:mem_type| |M1:mem_type|)
                        (= |A0:addr_type| |A1:addr_type|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!82 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc|
                                |M0:mem_type|
                                |A0:addr_type|
                                |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (ref.dev |T0:lclock|)
                        (ref.dev |T1:lclock|)
                        (ref.both_nGnR |T0:lclock| |T1:lclock|)))))
      (a!83 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc|
                                |M0:mem_type|
                                |A0:addr_type|
                                |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (ref.dev |T0:lclock|)
                        (ref.dev |T1:lclock|)
                        (ref.both_nGR |T0:lclock| |T1:lclock|)
                        (ref.same_addr |T0:lclock| |T1:lclock|)))))
      (a!84 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!85 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!86 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!87 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!88 (forall ((|T:lclock| lclock))
              (=> (or (= |T:lclock| |0:lclock|)
                      (|<:lclock:lclock| ref.lt |T:lclock|))
                  (and (= (__ref.evs.req |T:lclock|) nop)
                       (= (__ref.evs.cmp |T:lclock|) nop)
                       (__ref.evs.serialized |T:lclock|)))))
      (a!89 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (and (= (__ref.evs.cmp |T:lclock|) wr_cmp)
                              (not (= (__ref.evs.l_cmp |T:lclock|) init_l))
                              (__ref.evs.serialized |T:lclock|))))
              (let ((a!2 (or (and (= (__ref.evs.req |T:lclock|) write)
                                  (not (__ref.evs.serialized |T:lclock|)))
                             a!1)))
                (= (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (and a!2
                        (= (ref.evs.p |T:lclock|) |P:proc|)
                        (= (ref.evs.m |T:lclock|) |M:mem_type|)
                        (= (ref.evs.a |T:lclock|) |A:addr_type|)))))))
      (a!90 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (not (isd.rsp |P:proc|
                                    |M:mem_type|
                                    |A:addr_type|
                                    |T:lclock|)))
                 (and (= (__ref.evs.req |T:lclock|) read)
                      (not (__ref.evs.serialized |T:lclock|))
                      (= (ref.evs.p |T:lclock|) |P:proc|)
                      (= (ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!91 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (isd.rsp |P:proc| |M:mem_type| |A:addr_type| |T:lclock|))
                 (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                      (not (__ref.evs.serialized |T:lclock|))
                      (= (ref.evs.p |T:lclock|) |P:proc|)
                      (= (ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!92 (forall ((|T:lclock| lclock))
              (=> (and (= (__ref.evs.cmp |T:lclock|) rrsp)
                       (not (__ref.evs.serialized |T:lclock|)))
                  (not (= (__ref.evs.l_cmp |T:lclock|) dramc_l)))))
      (a!93 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (ref.dev |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T:lclock|) nGnRE)
                             (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE))))
                (=> a!1 a!2))))
      (a!94 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                                  (= (__ref.evs.cmp |T:lclock|) rrsp))
                              (not (ref.dev |T:lclock|)))))
                (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!95 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                              (ref.dev |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T:lclock|) nGnRE)
                             (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE))))
                (=> a!1 a!2))))
      (a!96 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) write)
                                  (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                              (not (ref.dev |T:lclock|)))))
                (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!97 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.cmp |T0:lclock|) wr_cmp))
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.cmp |T1:lclock|) wr_cmp))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (ref.same_attr |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                    (a!2 (not (and (__ref.evs.serialized |T1:lclock|)
                                   (not (__ref.evs.serialized |T0:lclock|))))))
                (=> a!1 a!2))))
      (a!98 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.req |T1:lclock|) write))
                             (and (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.req |T1:lclock|) read))))
                    (a!2 (and (= (__ref.evs.l_req |T0:lclock|) memc_l)
                              (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
                    (a!3 (or (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                             (= (__ref.evs.l_req |T1:lclock|) memc_l)
                             (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
              (let ((a!4 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))
                             a!2
                             (and (= (__ref.evs.l_req |T0:lclock|) dramc_l) a!3))))
                (=> (and a!1
                         (not (__ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!4)))))
      (a!99 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.cmp |T0:lclock|) rrsp))
                              (or (= (__ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.cmp |T1:lclock|) wr_cmp))
                              (not (__ref.evs.serialized |T0:lclock|))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                              (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!100 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.req |T0:lclock|) write)
                               (or (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.cmp |T1:lclock|) rrsp))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                 (not a!1))))
      (a!101 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (__ref.evs.req |T0:lclock|) write)
                                   (= (__ref.evs.req |T1:lclock|) write))
                              (and (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.req |T1:lclock|) read))))
                     (a!2 (and (= (__ref.evs.l_req |T0:lclock|) if_l)
                               (or (= (__ref.evs.l_req |T1:lclock|) if_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
                     (a!3 (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                              (= (__ref.evs.l_req |T1:lclock|) if_l)
                              (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
               (let ((a!4 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_pio_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))
                              a!2
                              (and (= (__ref.evs.l_req |T0:lclock|) memc_l) a!3))))
                 (=> (and a!1
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!4)))))
      (a!102 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (__ref.evs.req |T0:lclock|) write)
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (__ref.evs.req |T1:lclock|) write)
                        (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!103 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (__ref.evs.req |T0:lclock|) read)
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (__ref.evs.req |T1:lclock|) read)
                        (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!104 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.req |T1:lclock|) read)
                               (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)
                               (= (__ref.evs.req |T0:lclock|) read)
                               (or (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l))))
                     (a!2 (and (= (__ref.evs.req |T1:lclock|) read)
                               (= (__ref.evs.l_req |T1:lclock|) memc_l)
                               (= (__ref.evs.req |T0:lclock|) read)
                               (or (= (__ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l)))))
               (let ((a!3 (or a!1
                              a!2
                              (and (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                                   (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l)))))
                 (=> (and (= (__ref.evs.req |T0:lclock|) read)
                          (not (__ref.evs.serialized |T0:lclock|))
                          (= (__ref.evs.req |T1:lclock|) read)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!105 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!2 (or (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (__ref.evs.l_req |T1:lclock|) memc_l)
                              (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!3 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!1
                              (and (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                                   a!2))))
                 (=> (and (= (__ref.evs.req |T0:lclock|) write)
                          (not (__ref.evs.serialized |T0:lclock|))
                          (= (__ref.evs.req |T1:lclock|) write)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!106 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                               (or (= (__ref.evs.l_cmp |T1:lclock|) dramc_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) memc_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) arm_l)))))
                 (=> (and (= (__ref.evs.req |T0:lclock|) read)
                          (not (__ref.evs.serialized |T0:lclock|))
                          (= (__ref.evs.cmp |T1:lclock|) rrsp)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!1))))
      (a!107 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (__ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!108 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (__ref.evs.req |T0:lclock|) write)
                         (= (__ref.evs.cmp |T0:lclock|) nop)
                         (= (__ref.evs.req |T1:lclock|) nop)
                         (= (__ref.evs.cmp |T1:lclock|) wr_cmp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!109 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.cmp |T0:lclock|) rrsp))
                               (ref.pio |T0:lclock|)
                               (or (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.cmp |T1:lclock|) rrsp))
                               (ref.pio |T1:lclock|)
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (__ref.evs.serialized |T0:lclock|))
                                    (__ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!110 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (__ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.cmp |T0:lclock|) rrsp))
                               (or (= (__ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.cmp |T1:lclock|) rrsp))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (__ref.evs.serialized |T0:lclock|))
                                    (__ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!111 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying1.now |M:mem_type|))))
      (a!112 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying2.now |M:mem_type|))))
      (a!113 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock|
                          (rfn.abs.lastq |M:mem_type|)
                          |X:tar_clock|)
                        (__rfn.abs.begun |M:mem_type| |X:tar_clock|))
                   false)))
      (a!114 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (__rfn.abs.begun |M:mem_type| |X:tar_clock|)
                   (__rfn.abs.begun |M:mem_type| (rfn.abs.lastq |M:mem_type|)))))
      (a!115 (forall ((|M:mem_type| mem_type)
                      (|X:tar_clock| tar_clock)
                      (|Y:tar_clock| tar_clock))
               (=> (and (__rfn.abs.begun |M:mem_type| |X:tar_clock|)
                        (rfn.abs.done |M:mem_type| |X:tar_clock|)
                        (|<:tar_clock:tar_clock| |Y:tar_clock| |X:tar_clock|)
                        (__rfn.abs.begun |M:mem_type| |Y:tar_clock|))
                   (rfn.abs.done |M:mem_type| |Y:tar_clock|))))
      (a!116 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (rfn.abs.done |M:mem_type| |X:tar_clock|)
                   (__rfn.abs.begun |M:mem_type| |X:tar_clock|))))
      (a!117 (forall ((|X:tar_clock| tar_clock))
               (not (|<:tar_clock:tar_clock| |X:tar_clock| |0:tar_clock|))))
      (a!118 (forall ((|M:mem_type| mem_type)
                      (|T:lclock| lclock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (and (__rfn.abs.begun |M:mem_type| |Y:tar_clock|)
                               (=> (rfn.abs.done |M:mem_type| |Y:tar_clock|)
                                   (__rfn.evcomplete |T:lclock|))
                               (= (__rfn.abs.queue |M:mem_type| |Y:tar_clock|)
                                  (= (__ref.evs.req |T:lclock|) read)))))
                 (=> (and (__rfn.evqual |M:mem_type| |T:lclock|)
                          (= |Y:tar_clock| (__ref.evs.lt_arr |T:lclock|)))
                     a!1))))
      (a!119 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (|<:tar_clock:tar_clock|
                     (__ref.lt_tar |M:mem_type|)
                     |X:tar_clock|)
                   (not (__rfn.abs.begun |M:mem_type| |X:tar_clock|)))))
      (a!120 (forall ((|M:mem_type| mem_type))
               (not (dramc.rd_fair |M:mem_type|))))
      (a!121 (forall ((|M:mem_type| mem_type))
               (not (dramc.wr_fair |M:mem_type|))))
      (a!122 (forall ((|V0:lclock| lclock))
               (=> (__l2s_g_0 |V0:lclock|)
                   (=> (__rfn.evqual _M |V0:lclock|)
                       (not (__l2s_g_2 |V0:lclock|))))))
      (a!123 (forall ((|V0:lclock| lclock))
               (=> (__l2s_g_1 |V0:lclock|) (not (__l2s_g_2 |V0:lclock|)))))
      (a!124 (forall ((|V0:lclock| lclock))
               (=> (__l2s_g_2 |V0:lclock|) (not (__rfn.evcomplete |V0:lclock|)))))
      (a!125 (forall ((|V0:lclock| lclock))
               (not (and (__rfn.evcomplete |V0:lclock|) (__l2s_w_0 |V0:lclock|)))))
      (a!126 (or (not __ts0_e)
                 (or (not __ts0_a) (= (__ref.evs.l_req |__loc:t|) memc_l))))
      (a!127 (forall ((|V0:lclock| lclock) (|V1:proc| proc))
               (let ((a!1 (and (isd.rd |V1:proc|
                                       |__fml:m|
                                       |__fml:a|
                                       |V0:lclock|)
                               (= (__ref.evs.req |V0:lclock|) read)
                               (= (__ref.evs.l_req |V0:lclock|) memc_l)))
                     (a!2 (and (or (= |V0:lclock| |__loc:t|)
                                   (|<:lclock:lclock| |V0:lclock| |__loc:t|))
                               (not (= |V0:lclock| |__loc:t|)))))
                 (or (not __ts0_e) (not __ts0_a) (not (and a!1 a!2))))))
      (a!128 (=> (and (not __m__old_l2s_g_6)
                      (not (__dramc_nb2.push_trying_rd _M _A)))
                 (not __m_l2s_g_6)))
      (a!129 (or (not __ts0_c)
                 (=> (and (not __m__old_l2s_g_10) (not __m_l2s_g_6))
                     (not __m_l2s_g_10))))
      (a!130 (or (not __ts0_c)
                 (=> __m_l2s_g_6 (not (__m_dramc_nb2.push_trying_rd _M _A)))))
      (a!131 (or (not __ts0_e)
                 (or (not __ts0_c) (=> __m_l2s_g_10 (not __m_l2s_g_6)))))
      (a!132 (=> (and (not new__old_l2s_g_6_a)
                      (not (__m_dramc_nb2.push_trying_rd _M _A)))
                 (not __m_l2s_g_6_a)))
      (a!133 (or (not __ts0_c)
                 (=> (and (not new__old_l2s_g_10_a) (not __m_l2s_g_6_a))
                     (not __m_l2s_g_10_a))))
      (a!134 (or (not __ts0_c)
                 (=> __m_l2s_g_6_a (not (__m_dramc_nb2.push_trying_rd_a _M _A)))))
      (a!135 (or (not __ts0_e)
                 (or (not __ts0_c) (=> __m_l2s_g_10_a (not __m_l2s_g_6_a)))))
      (a!136 (=> (and (not _old_l2s_g_6)
                      (not (__m_dramc_nb2.push_trying_rd_a _M _A)))
                 (not l2s_g_6)))
      (a!137 (or (not __ts0_c)
                 (=> (and (not _old_l2s_g_10) (not l2s_g_6)) (not l2s_g_10))))
      (a!138 (or (not __ts0_c)
                 (=> l2s_g_6 (not (dramc_nb2.push_trying_rd _M _A)))))
      (a!139 (or (not __ts0_e) (or (not __ts0_c) (=> l2s_g_10 (not l2s_g_6)))))
      (a!140 (forall ((|M:mem_type| mem_type))
               (or (not __ts0_e)
                   (or (not __ts0_c)
                       (not __ts0_b_a)
                       (not (rfn.abs.trying1.now |M:mem_type|))))))
      (a!141 (forall ((|M:mem_type| mem_type))
               (or (not __ts0_e)
                   (or (not __ts0_c)
                       (not __ts0_b_a)
                       (not (rfn.abs.trying2.now |M:mem_type|))))))
      (a!142 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (let ((a!1 (=> (and (|<:tar_clock:tar_clock|
                                     (rfn.abs.lastq |M:mem_type|)
                                     |X:tar_clock|)
                                   (__rfn.abs.begun |M:mem_type| |X:tar_clock|))
                              false)))
                 (or (not __ts0_e) (or (not __ts0_c) (not __ts0_b_a) a!1)))))
      (a!143 (forall ((|M:mem_type| mem_type)
                      (|X:tar_clock| tar_clock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (=> (and (__rfn.abs.begun |M:mem_type| |X:tar_clock|)
                                   (rfn.abs.done |M:mem_type| |X:tar_clock|)
                                   (|<:tar_clock:tar_clock|
                                     |Y:tar_clock|
                                     |X:tar_clock|)
                                   (__rfn.abs.begun |M:mem_type| |Y:tar_clock|))
                              (rfn.abs.done |M:mem_type| |Y:tar_clock|))))
                 (or (not __ts0_e) (or (not __ts0_c) (not __ts0_b_a) a!1)))))
      (a!144 (forall ((|X:tar_clock| tar_clock))
               (or (not __ts0_e)
                   (or (not __ts0_c)
                       (not __ts0_b_a)
                       (not (|<:tar_clock:tar_clock|
                              |X:tar_clock|
                              |0:tar_clock|))))))
      (a!145 (forall ((|V0:lclock| lclock))
               (let ((a!1 (=> (l2s_g_0 |V0:lclock|)
                              (=> (rfn.evqual _M |V0:lclock|)
                                  (not (__l2s_g_2 |V0:lclock|))))))
                 (or (not __ts0_e) (or (not __ts0_c) (not __ts0_b_a) a!1)))))
      (a!146 (or (not __ts0_c)
                 (not __ts0_b_a)
                 (not __ts0_a_a)
                 (not (=> (__rfn.abs.begun |__new_prm:M| __X)
                          (|<:tar_clock:tar_clock| __X |__new_fml:lt_a|)))))
      (a!147 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 (or (not __ts0_a) (= (__ref.evs.l_req |__loc:t|) memc_l))))
      (a!148 (forall ((|V0:lclock| lclock) (|V1:proc| proc))
               (let ((a!1 (and (isd.wr |V1:proc|
                                       |__fml:m|
                                       |__fml:a|
                                       |V0:lclock|)
                               (= (__ref.evs.req |V0:lclock|) write)
                               (= (__ref.evs.l_req |V0:lclock|) memc_l)))
                     (a!2 (and (or (= |V0:lclock| |__loc:t|)
                                   (|<:lclock:lclock| |V0:lclock| |__loc:t|))
                               (not (= |V0:lclock| |__loc:t|)))))
                 (or __ts0_e
                     (not __ts0__ts0_d_a)
                     (not __ts0_a)
                     (not (and a!1 a!2))))))
      (a!149 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 (or (not __ts0_c) (=> __m_l2s_g_10 (not __m_l2s_g_6)))))
      (a!150 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 (or (not __ts0_c) (=> __m_l2s_g_10_a (not __m_l2s_g_6_a)))))
      (a!151 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 (or (not __ts0_c) (=> l2s_g_10 (not l2s_g_6)))))
      (a!152 (forall ((|M:mem_type| mem_type))
               (or __ts0_e
                   (not __ts0__ts0_d_a)
                   (or (not __ts0_c)
                       (not __ts0_b_a)
                       (not (rfn.abs.trying1.now |M:mem_type|))))))
      (a!153 (forall ((|M:mem_type| mem_type))
               (or __ts0_e
                   (not __ts0__ts0_d_a)
                   (or (not __ts0_c)
                       (not __ts0_b_a)
                       (not (rfn.abs.trying2.now |M:mem_type|))))))
      (a!154 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (let ((a!1 (=> (and (|<:tar_clock:tar_clock|
                                     (rfn.abs.lastq |M:mem_type|)
                                     |X:tar_clock|)
                                   (__rfn.abs.begun |M:mem_type| |X:tar_clock|))
                              false)))
                 (or __ts0_e
                     (not __ts0__ts0_d_a)
                     (or (not __ts0_c) (not __ts0_b_a) a!1)))))
      (a!155 (forall ((|M:mem_type| mem_type)
                      (|X:tar_clock| tar_clock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (=> (and (__rfn.abs.begun |M:mem_type| |X:tar_clock|)
                                   (rfn.abs.done |M:mem_type| |X:tar_clock|)
                                   (|<:tar_clock:tar_clock|
                                     |Y:tar_clock|
                                     |X:tar_clock|)
                                   (__rfn.abs.begun |M:mem_type| |Y:tar_clock|))
                              (rfn.abs.done |M:mem_type| |Y:tar_clock|))))
                 (or __ts0_e
                     (not __ts0__ts0_d_a)
                     (or (not __ts0_c) (not __ts0_b_a) a!1)))))
      (a!156 (forall ((|X:tar_clock| tar_clock))
               (or __ts0_e
                   (not __ts0__ts0_d_a)
                   (or (not __ts0_c)
                       (not __ts0_b_a)
                       (not (|<:tar_clock:tar_clock|
                              |X:tar_clock|
                              |0:tar_clock|))))))
      (a!157 (forall ((|V0:lclock| lclock))
               (let ((a!1 (=> (l2s_g_0 |V0:lclock|)
                              (=> (rfn.evqual _M |V0:lclock|)
                                  (not (__l2s_g_2 |V0:lclock|))))))
                 (or __ts0_e
                     (not __ts0__ts0_d_a)
                     (or (not __ts0_c) (not __ts0_b_a) a!1)))))
      (a!158 (forall ((|T:index| index) (|U:index| index) (|V:index| index))
               (=> (and (|<:index:index| |T:index| |U:index|)
                        (|<:index:index| |U:index| |V:index|))
                   (|<:index:index| |T:index| |V:index|))))
      (a!159 (forall ((|T:index| index) (|U:index| index))
               (not (and (|<:index:index| |T:index| |U:index|)
                         (|<:index:index| |U:index| |T:index|)))))
      (a!160 (forall ((|T:lclock| lclock)
                      (|U:lclock| lclock)
                      (|V:lclock| lclock))
               (=> (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                        (|<:lclock:lclock| |U:lclock| |V:lclock|))
                   (|<:lclock:lclock| |T:lclock| |V:lclock|))))
      (a!161 (forall ((|T:lclock| lclock) (|U:lclock| lclock))
               (not (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                         (|<:lclock:lclock| |U:lclock| |T:lclock|)))))
      (a!162 (forall ((|T:tar_clock| tar_clock)
                      (|U:tar_clock| tar_clock)
                      (|V:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                        (|<:tar_clock:tar_clock| |U:tar_clock| |V:tar_clock|))
                   (|<:tar_clock:tar_clock| |T:tar_clock| |V:tar_clock|))))
      (a!163 (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
               (not (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                         (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))))
      (a!164 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock)
                      (|V:tar_cf_clock| tar_cf_clock))
               (=> (and (|<:tar_cf_clock:tar_cf_clock|
                          |T:tar_cf_clock|
                          |U:tar_cf_clock|)
                        (|<:tar_cf_clock:tar_cf_clock|
                          |U:tar_cf_clock|
                          |V:tar_cf_clock|))
                   (|<:tar_cf_clock:tar_cf_clock|
                     |T:tar_cf_clock|
                     |V:tar_cf_clock|))))
      (a!165 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock))
               (not (and (|<:tar_cf_clock:tar_cf_clock|
                           |T:tar_cf_clock|
                           |U:tar_cf_clock|)
                         (|<:tar_cf_clock:tar_cf_clock|
                           |U:tar_cf_clock|
                           |T:tar_cf_clock|)))))
      (a!166 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)
                  (and (= (__ref.evs.cmp |T0:lclock|) rrsp)
                       (= (__ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
      (a!167 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_trying_rd |M:mem_type| |A:addr_type|)
                  (and __dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma __dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req __dramc_nb2.memc_pushing.value) read)))))
      (a!168 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_success_rd |M:mem_type| |A:addr_type|)
                  (and __dramc_nb2.memc_arriving.now
                       (dramc_nb2.evma __dramc_nb2.memc_arriving.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req __dramc_nb2.memc_arriving.value) read)))))
      (a!169 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__dramc_nb2.evqual_rd |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (__ref.evs.req |T:lclock|) read)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)))))
      (a!170 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_trying_wr |M:mem_type| |A:addr_type|)
                  (and __dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma __dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req __dramc_nb2.memc_pushing.value) write)))))
      (a!171 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__dramc_nb2.push_success_wr |M:mem_type| |A:addr_type|)
                  (and __dramc_nb2.memc_arriving.now
                       (dramc_nb2.evma __dramc_nb2.memc_arriving.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req __dramc_nb2.memc_arriving.value) write)))))
      (a!172 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (__dramc_nb2.evqual_wr |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (__ref.evs.req |T:lclock|) write)
                       (= (__ref.evs.l_req |T:lclock|) memc_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)))))
      (a!173 (forall ((|V0:proc| proc))
               (= (l2s_d |V0:proc|)
                  (ite (and (= |V0:proc| |__fml:p|)) true (__l2s_d |V0:proc|)))))
      (a!174 (forall ((|V0:mem_type| mem_type))
               (= (l2s_d |V0:mem_type|)
                  (ite (and (= |V0:mem_type| |__fml:m|))
                       true
                       (__l2s_d_a |V0:mem_type|)))))
      (a!175 (forall ((|V0:addr_type| addr_type))
               (= (l2s_d |V0:addr_type|)
                  (ite (and (= |V0:addr_type| |__fml:a|))
                       true
                       (__l2s_d_b |V0:addr_type|)))))
      (a!176 (forall ((|V0:lclock| lclock))
               (= (l2s_d |V0:lclock|)
                  (ite (and (= |V0:lclock| |__fml:lt|))
                       true
                       (__l2s_d_c |V0:lclock|)))))
      (a!177 (forall ((|V0:mem_type| mem_type) (|V1:addr_type| addr_type))
               (= (__m_memc.rd_fair |V0:mem_type| |V1:addr_type|)
                  (ite (and (= |V0:mem_type| |__fml:m|)
                            (= |V1:addr_type| |__fml:a|))
                       (= |__fml:ph| rd_ph)
                       (__memc.rd_fair |V0:mem_type| |V1:addr_type|)))))
      (a!178 (forall ((|V0:mem_type| mem_type) (|V1:addr_type| addr_type))
               (= (__m_memc.wr_fair |V0:mem_type| |V1:addr_type|)
                  (ite (and (= |V0:mem_type| |__fml:m|)
                            (= |V1:addr_type| |__fml:a|))
                       (= |__fml:ph| wr_ph)
                       (__memc.wr_fair |V0:mem_type| |V1:addr_type|)))))
      (a!179 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (let ((a!1 (and (= |V0:proc| |__fml:p|)
                               (= |V1:mem_type| |__fml:m|)
                               (= |V2:addr_type| |__fml:a|)
                               (= |V3:lclock| |__fml:lt|))))
                 (= (__m_memc.cpl_fair
                      |V0:proc|
                      |V1:mem_type|
                      |V2:addr_type|
                      |V3:lclock|)
                    (ite a!1
                         (= |__fml:ph| cpl_ph)
                         (__memc.cpl_fair |V0:proc|
                                          |V1:mem_type|
                                          |V2:addr_type|
                                          |V3:lclock|))))))
      (a!180 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (let ((a!1 (and (= |V0:proc| |__fml:p|)
                               (= |V1:mem_type| |__fml:m|)
                               (= |V2:addr_type| |__fml:a|)
                               (= |V3:lclock| |__fml:lt|))))
                 (= (memc.cpl_fair |V0:proc|
                                   |V1:mem_type|
                                   |V2:addr_type|
                                   |V3:lclock|)
                    (ite a!1
                         false
                         (__m_memc.cpl_fair
                           |V0:proc|
                           |V1:mem_type|
                           |V2:addr_type|
                           |V3:lclock|))))))
      (a!181 (= __m_l2s_w_3
                (and __l2s_w_3
                     (not (__m_dramc_nb2.push_trying_rd _M _A))
                     (not __m_l2s_g_6))))
      (a!182 (= __m_l2s_w_3_a
                (and __m_l2s_w_3
                     (not (__m_dramc_nb2.push_trying_rd_a _M _A))
                     (not __m_l2s_g_6_a))))
      (a!183 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__m_dramc_nb2.push_trying_rd |M:mem_type| |A:addr_type|)
                  (and __dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_pushing.value) read)))))
      (a!184 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__m_dramc_nb2.push_trying_wr |M:mem_type| |A:addr_type|)
                  (and __dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_pushing.value) write)))))
      (a!185 (= l2s_w_3
                (and __m_l2s_w_3_a
                     (not (dramc_nb2.push_trying_rd _M _A))
                     (not l2s_g_6))))
      (a!186 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__m_dramc_nb2.push_trying_rd_a |M:mem_type| |A:addr_type|)
                  (and __m_dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_pushing.value) read)))))
      (a!187 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (__m_dramc_nb2.push_trying_wr_a |M:mem_type| |A:addr_type|)
                  (and __m_dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (__ref.evs.req dramc_nb2.memc_pushing.value) write)))))
      (a!188 (forall ((|V0:lclock| lclock))
               (= (ref.evs.lt_arr |V0:lclock|)
                  (ite (and (= |V0:lclock| |__new_loc:tt|))
                       (ref.lt_tar (ref.evs.m |__new_loc:tt|))
                       (__ref.evs.lt_arr |V0:lclock|)))))
      (a!189 (forall ((|V0:lclock| lclock))
               (= (ref.evs.l_req |V0:lclock|)
                  (ite (and (= |V0:lclock| |__new_loc:tt|))
                       dramc_l
                       (__ref.evs.l_req |V0:lclock|)))))
      (a!190 (exists ((|T:lclock| lclock))
               (and (= (__ref.evs.req |T:lclock|) read)
                    (= (ref.evs.m |T:lclock|) |__fml:m|)
                    (= (ref.evs.a |T:lclock|) |__fml:a|)
                    (= (__ref.evs.l_req |T:lclock|) dramc_l))))
      (a!191 (exists ((|T:lclock| lclock))
               (and (= (__ref.evs.req |T:lclock|) write)
                    (= (ref.evs.m |T:lclock|) |__fml:m|)
                    (= (ref.evs.a |T:lclock|) |__fml:a|)
                    (= (__ref.evs.l_req |T:lclock|) dramc_l))))
      (a!192 (= __ts0_c
                (and (not |__new_loc:ordpip|)
                     (not (= |__new_loc:tt| |0:lclock|))
                     (= (ref.evs.mem_loc |__new_loc:tt|) mem_memc))))
      (a!193 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.mem_memc_exception |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
      (a!194 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.same_attr |T0:lclock| |T1:lclock|)
                  (or (ref.both_nGnR |T0:lclock| |T1:lclock|)
                      (ref.both_nGR |T0:lclock| |T1:lclock|)
                      (ref.both_normal |T0:lclock| |T1:lclock|)))))
      (a!195 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.both_normal |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.op_ack |T0:lclock|) normal)
                       (= (ref.evs.op_ack |T1:lclock|) normal)))))
      (a!196 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGRE)
                      (= |OP_ACK:op_ack_type| _GRE)))))
      (a!197 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGnR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGnRE)
                      (= |OP_ACK:op_ack_type| nGnRnE)))))
      (a!198 (forall ((|T:lclock| lclock))
               (= (ref.dev |T:lclock|)
                  (or (ref.nGR (ref.evs.op_ack |T:lclock|))
                      (ref.nGnR (ref.evs.op_ack |T:lclock|))))))
      (a!199 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!200 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_trying_rd |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) read)))))
      (a!201 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_success_rd |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (dramc_nb2.evma dramc_nb2.memc_arriving.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) read)))))
      (a!202 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (dramc_nb2.evqual_rd |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) read)
                       (= (ref.evs.l_req |T:lclock|) memc_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|)))))
      (a!203 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_trying_wr |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_pushing.now
                       (dramc_nb2.evma dramc_nb2.memc_pushing.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_pushing.value) write)))))
      (a!204 (forall ((|A:addr_type| addr_type) (|M:mem_type| mem_type))
               (= (dramc_nb2.push_success_wr |M:mem_type| |A:addr_type|)
                  (and dramc_nb2.memc_arriving.now
                       (dramc_nb2.evma dramc_nb2.memc_arriving.value
                                       |M:mem_type|
                                       |A:addr_type|)
                       (= (ref.evs.req dramc_nb2.memc_arriving.value) write)))))
      (a!205 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (= (dramc_nb2.evqual_wr |T:lclock| |M:mem_type| |A:addr_type|)
                  (and (= (ref.evs.req |T:lclock|) write)
                       (= (ref.evs.l_req |T:lclock|) memc_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (dramc_nb2.evma |T:lclock| |M:mem_type| |A:addr_type|))))))
(let ((a!10 (or a!9
                (not (forall ((|T:lclock| lclock))
                       (let ((a!1 (and (= (__ref.evs.req |T:lclock|) read)
                                       (__rfn.evqual _M |T:lclock|)
                                       (= (ref.evs.a |T:lclock|) _A))))
                         (=> a!1 false))))
                (not true)
                (not (=> true false))))
      (a!13 (=> a!12
                (=> (and (and l2s_init_5 l2s_init_6) l2s_init_8) l2s_init_7))))
  (and a!1
       a!2
       a!3
       a!4
       a!1
       a!5
       a!6
       (forall ((|T:lclock| lclock))
         (=> (l2s_init_1 |T:lclock|) (__l2s_g_1 |T:lclock|)))
       (=> true (=> true true))
       (=> true true)
       a!7
       (=> (and true l2s_saved) (=> (not l2s_s_1) true))
       (=> true (=> true true))
       (=> (and l2s_saved l2s_s_1) (=> true false))
       (=> (and (not l2s_s_1) (not a!8) l2s_saved true (not __l2s_w_3))
           (and (not l2s_s_1) (=> true false)))
       (=> l2s_init_8 __l2s_g_10)
       a!10
       l2s_g_7
       (=> l2s_g_3 (or (not l2s_waiting) (not l2s_w_1)))
       (not l2s_init_2)
       l2s_g_8
       (=> l2s_g_4 (or (not l2s_waiting) (not l2s_w_2)))
       (not l2s_init_3)
       __l2s_g_10
       (=> __l2s_g_6 (or (not l2s_waiting) (not __l2s_w_3)))
       (not l2s_init_4)
       (=> __l2s_g_9 (or (not l2s_waiting) (not __l2s_w_4)))
       (=> (or (not l2s_waiting) (not __l2s_w_4)) __l2s_g_5)
       (not l2s_init_7)
       (or (not l2s_init_7) __l2s_g_9)
       (=> (and (not l2s_init_7) __l2s_g_9)
           (or (not l2s_waiting) (not __l2s_w_4)))
       a!11
       (or l2s_waiting l2s_frozen l2s_saved)
       (or (not l2s_waiting) (not l2s_frozen))
       (or (not l2s_waiting) (not l2s_saved))
       (or (not l2s_frozen) (not l2s_saved))
       (__l2s_d_c ref.lt)
       (__l2s_d_c cfabric.t_rd_min)
       (__l2s_d_c __dramc_nb2.memc_pushing.value)
       (__l2s_d_c __dramc_nb2.memc_arriving.value)
       (__l2s_d_a _M)
       (__l2s_d_b _A)
       (__l2s_d_d ref.lt_tar_cf)
       (__l2s_d_d cfabric.t_rd_arr_min)
       (forall ((|T:lclock| lclock))
         (=> (l2s_init_0 |T:lclock|) (__l2s_g_0 |T:lclock|)))
       (not a!13)
       a!14
       a!15
       a!16
       a!17
       a!18
       a!19
       a!20
       a!21
       a!22
       a!23
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!24
       (=> a!25
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 cfabric.t_rd_arr_min)
               (= cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!26 (= cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!27
       a!28
       a!29
       a!30
       (=> a!25
           (or (|<:lclock:lclock| ref.lt cfabric.t_rd_min)
               (= cfabric.t_rd_min |0:lclock|)))
       (=> a!26 (= cfabric.t_rd_min |0:lclock|))
       a!31
       a!32
       a!33
       (= (__ref.evs.req |0:lclock|) nop)
       (= (__ref.evs.l_req |0:lclock|) init_l)
       (= (__ref.evs.cmp |0:lclock|) nop)
       (= (__ref.evs.l_cmp |0:lclock|) init_l)
       (= (__ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!34
       a!35
       a!36
       a!37
       a!38
       a!39
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!62
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       a!116
       a!117
       a!118
       a!119
       a!120
       a!121
       (not __dramc_nb2.memc_pushing.now)
       (not __dramc_nb2.memc_arriving.now)
       a!122
       a!123
       a!124
       (=> l2s_g_3 (not (dramc.rd_fair _M)))
       (=> l2s_g_4 (not (dramc.wr_fair _M)))
       (=> __l2s_g_5 (not (__dramc_nb2.push_success_rd _M _A)))
       (=> __l2s_g_6 (not (__dramc_nb2.push_trying_rd _M _A)))
       (=> l2s_g_7 (not l2s_g_3))
       (=> l2s_g_8 (not l2s_g_4))
       (=> __l2s_g_9 (not __l2s_g_5))
       (=> __l2s_g_10 (not __l2s_g_6))
       (not (and __l2s_g_5 __l2s_w_4))
       a!125
       (not (and (__dramc_nb2.push_trying_rd _M _A) __l2s_w_3))
       (not (and (dramc.rd_fair _M) l2s_w_1))
       (not (and (dramc.wr_fair _M) l2s_w_2))
       a!14
       a!15
       a!16
       a!17
       a!18
       a!19
       a!20
       a!21
       a!22
       a!23
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!24
       (=> a!25
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 cfabric.t_rd_arr_min)
               (= cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!26 (= cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!27
       a!28
       a!29
       a!30
       (=> a!25
           (or (|<:lclock:lclock| ref.lt cfabric.t_rd_min)
               (= cfabric.t_rd_min |0:lclock|)))
       (=> a!26 (= cfabric.t_rd_min |0:lclock|))
       a!31
       a!32
       a!33
       (= (__ref.evs.req |0:lclock|) nop)
       (= (__ref.evs.l_req |0:lclock|) init_l)
       (= (__ref.evs.cmp |0:lclock|) nop)
       (= (__ref.evs.l_cmp |0:lclock|) init_l)
       (= (__ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!34
       a!35
       a!36
       a!37
       a!38
       a!39
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!62
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       a!116
       a!117
       a!118
       a!119
       a!120
       a!121
       (or (not __ts0_e) (or __ts0_a __ts0_b))
       (or (not __ts0_e)
           (not __ts0_a)
           (isd.rd |__loc:pp| |__fml:m| |__fml:a| |__loc:t|))
       (or (not __ts0_e) (not __ts0_a) (= (__ref.evs.req |__loc:t|) read))
       a!126
       a!127
       (forall ((|V0:lclock| lclock) (|V1:proc| proc))
         (let ((a!1 (and (isd.rd |V1:proc| |__fml:m| |__fml:a| |V0:lclock|)
                         (= (__ref.evs.req |V0:lclock|) read)
                         (= (__ref.evs.l_req |V0:lclock|) memc_l))))
           (or (not __ts0_e) (not __ts0_b) (not a!1))))
       (or (not __ts0_e) (or (not __ts0_c) (=> __m__old_l2s_g_6 __m_l2s_g_6)))
       (or (not __ts0_e) (or (not __ts0_c) a!128))
       (or (not __ts0_e) (or (not __ts0_c) (=> __m__old_l2s_g_10 __m_l2s_g_10)))
       (or (not __ts0_e) a!129)
       (or (not __ts0_e) a!130)
       a!131
       (or (not __ts0_e)
           (or (not __ts0_c) (=> new__old_l2s_g_6_a __m_l2s_g_6_a)))
       (or (not __ts0_e) (or (not __ts0_c) a!132))
       (or (not __ts0_e)
           (or (not __ts0_c) (=> new__old_l2s_g_10_a __m_l2s_g_10_a)))
       (or (not __ts0_e) a!133)
       (or (not __ts0_e) a!134)
       a!135
       (or (not __ts0_e) (or (not __ts0_c) (=> _old_l2s_g_6 l2s_g_6)))
       (or (not __ts0_e) (or (not __ts0_c) a!136))
       (or (not __ts0_e) (or (not __ts0_c) (=> _old_l2s_g_10 l2s_g_10)))
       (or (not __ts0_e) a!137)
       (or (not __ts0_e) a!138)
       a!139
       (or (not __ts0_e)
           (or (not __ts0_c)
               (not __ts0_b_a)
               (|<:tar_clock:tar_clock| |__new_fml:x| |__fml:y|)))
       (forall ((|Y:tar_clock| tar_clock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (|<:tar_clock:tar_clock|
                              |__new_fml:x|
                              |Y:tar_clock|)
                            (or (= |__fml:y| |Y:tar_clock|)
                                (|<:tar_clock:tar_clock|
                                  |__fml:y|
                                  |Y:tar_clock|))))))
           (or (not __ts0_e) a!1)))
       (or (not __ts0_e)
           (or (not __ts0_c)
               (not __ts0_b_a)
               (tar_clock.succ |__new_fml:x| |__fml:y|)))
       a!140
       a!141
       a!142
       (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (__rfn.abs.begun |M:mem_type| |X:tar_clock|)
                            (__rfn.abs.begun |M:mem_type|
                                             (rfn.abs.lastq |M:mem_type|))))))
           (or (not __ts0_e) a!1)))
       a!143
       (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (rfn.abs.done |M:mem_type| |X:tar_clock|)
                            (__rfn.abs.begun |M:mem_type| |X:tar_clock|)))))
           (or (not __ts0_e) a!1)))
       a!144
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (_old_l2s_g_0 |V0:lclock|) (l2s_g_0 |V0:lclock|)))))
           (or (not __ts0_e) a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (and (not (_old_l2s_g_0 |V0:lclock|))
                         (=> (__rfn.evqual _M |V0:lclock|)
                             (not (__l2s_g_2 |V0:lclock|))))))
         (let ((a!2 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> a!1 (not (l2s_g_0 |V0:lclock|))))))
           (or (not __ts0_e) a!2))))
       a!145
       (or (not __ts0_e) a!146)
       (or (not __ts0_e) (or (not __ts0_c) (not __ts0_b_a) __ts0_a_a false))
       (or (not __ts0_e) (or (not __ts0_c) __ts0_b_a false))
       (or (not __ts0_e) (or __ts0_c false))
       (or __ts0_e (not __ts0__ts0_d_a) (or __ts0_a __ts0_b))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (not __ts0_a)
           (isd.wr |__loc:pp| |__fml:m| |__fml:a| |__loc:t|))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (not __ts0_a)
           (= (__ref.evs.req |__loc:t|) write))
       a!147
       a!148
       (forall ((|V0:lclock| lclock) (|V1:proc| proc))
         (let ((a!1 (and (isd.wr |V1:proc| |__fml:m| |__fml:a| |V0:lclock|)
                         (= (__ref.evs.req |V0:lclock|) write)
                         (= (__ref.evs.l_req |V0:lclock|) memc_l))))
           (or __ts0_e (not __ts0__ts0_d_a) (not __ts0_b) (not a!1))))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c) (=> __m__old_l2s_g_6 __m_l2s_g_6)))
       (or __ts0_e (not __ts0__ts0_d_a) (or (not __ts0_c) a!128))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c) (=> __m__old_l2s_g_10 __m_l2s_g_10)))
       (or __ts0_e (not __ts0__ts0_d_a) a!129)
       (or __ts0_e (not __ts0__ts0_d_a) a!130)
       a!149
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c) (=> new__old_l2s_g_6_a __m_l2s_g_6_a)))
       (or __ts0_e (not __ts0__ts0_d_a) (or (not __ts0_c) a!132))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c) (=> new__old_l2s_g_10_a __m_l2s_g_10_a)))
       (or __ts0_e (not __ts0__ts0_d_a) a!133)
       (or __ts0_e (not __ts0__ts0_d_a) a!134)
       a!150
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c) (=> _old_l2s_g_6 l2s_g_6)))
       (or __ts0_e (not __ts0__ts0_d_a) (or (not __ts0_c) a!136))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c) (=> _old_l2s_g_10 l2s_g_10)))
       (or __ts0_e (not __ts0__ts0_d_a) a!137)
       (or __ts0_e (not __ts0__ts0_d_a) a!138)
       a!151
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c)
               (not __ts0_b_a)
               (|<:tar_clock:tar_clock| |__new_fml:x| |__fml:y|)))
       (forall ((|Y:tar_clock| tar_clock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (|<:tar_clock:tar_clock|
                              |__new_fml:x|
                              |Y:tar_clock|)
                            (or (= |__fml:y| |Y:tar_clock|)
                                (|<:tar_clock:tar_clock|
                                  |__fml:y|
                                  |Y:tar_clock|))))))
           (or __ts0_e (not __ts0__ts0_d_a) a!1)))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c)
               (not __ts0_b_a)
               (tar_clock.succ |__new_fml:x| |__fml:y|)))
       a!152
       a!153
       a!154
       (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (__rfn.abs.begun |M:mem_type| |X:tar_clock|)
                            (__rfn.abs.begun |M:mem_type|
                                             (rfn.abs.lastq |M:mem_type|))))))
           (or __ts0_e (not __ts0__ts0_d_a) a!1)))
       a!155
       (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (rfn.abs.done |M:mem_type| |X:tar_clock|)
                            (__rfn.abs.begun |M:mem_type| |X:tar_clock|)))))
           (or __ts0_e (not __ts0__ts0_d_a) a!1)))
       a!156
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> (_old_l2s_g_0 |V0:lclock|) (l2s_g_0 |V0:lclock|)))))
           (or __ts0_e (not __ts0__ts0_d_a) a!1)))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (and (not (_old_l2s_g_0 |V0:lclock|))
                         (=> (__rfn.evqual _M |V0:lclock|)
                             (not (__l2s_g_2 |V0:lclock|))))))
         (let ((a!2 (or (not __ts0_c)
                        (not __ts0_b_a)
                        (=> a!1 (not (l2s_g_0 |V0:lclock|))))))
           (or __ts0_e (not __ts0__ts0_d_a) a!2))))
       a!157
       (or __ts0_e (not __ts0__ts0_d_a) a!146)
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (or (not __ts0_c) (not __ts0_b_a) __ts0_a_a false))
       (or __ts0_e (not __ts0__ts0_d_a) (or (not __ts0_c) __ts0_b_a false))
       (or __ts0_e (not __ts0__ts0_d_a) (or __ts0_c false))
       (or __ts0_e __ts0__ts0_d_a false)
       (forall ((|X:index| index) (|Y:index| index) (|Z:index| index))
         (let ((a!1 (and (|<:index:index| |X:index| |Z:index|)
                         (not (and (|<:index:index| |X:index| |Y:index|)
                                   (|<:index:index| |Y:index| |Z:index|))))))
           (=> (index.succ |X:index| |Z:index|) a!1)))
       a!158
       a!159
       (forall ((|T:index| index) (|U:index| index))
         (or (|<:index:index| |T:index| |U:index|)
             (= |T:index| |U:index|)
             (|<:index:index| |U:index| |T:index|)))
       (forall ((|X:index| index))
         (or (= |0:index| |X:index|) (|<:index:index| |0:index| |X:index|)))
       (forall ((|X:lclock| lclock) (|Y:lclock| lclock) (|Z:lclock| lclock))
         (let ((a!1 (and (|<:lclock:lclock| |X:lclock| |Z:lclock|)
                         (not (and (|<:lclock:lclock| |X:lclock| |Y:lclock|)
                                   (|<:lclock:lclock| |Y:lclock| |Z:lclock|))))))
           (=> (lclock.succ |X:lclock| |Z:lclock|) a!1)))
       a!160
       a!161
       (forall ((|T:lclock| lclock) (|U:lclock| lclock))
         (or (|<:lclock:lclock| |T:lclock| |U:lclock|)
             (= |T:lclock| |U:lclock|)
             (|<:lclock:lclock| |U:lclock| |T:lclock|)))
       (forall ((|X:lclock| lclock))
         (or (= |0:lclock| |X:lclock|)
             (|<:lclock:lclock| |0:lclock| |X:lclock|)))
       (forall ((|X:tar_clock| tar_clock)
                (|Y:tar_clock| tar_clock)
                (|Z:tar_clock| tar_clock))
         (let ((a!1 (and (|<:tar_clock:tar_clock| |X:tar_clock| |Z:tar_clock|)
                         (not (and (|<:tar_clock:tar_clock|
                                     |X:tar_clock|
                                     |Y:tar_clock|)
                                   (|<:tar_clock:tar_clock|
                                     |Y:tar_clock|
                                     |Z:tar_clock|))))))
           (=> (tar_clock.succ |X:tar_clock| |Z:tar_clock|) a!1)))
       a!162
       a!163
       (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
         (or (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
             (= |T:tar_clock| |U:tar_clock|)
             (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))
       (forall ((|X:tar_clock| tar_clock))
         (or (= |0:tar_clock| |X:tar_clock|)
             (|<:tar_clock:tar_clock| |0:tar_clock| |X:tar_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock)
                (|Y:tar_cf_clock| tar_cf_clock)
                (|Z:tar_cf_clock| tar_cf_clock))
         (let ((a!1 (and (|<:tar_cf_clock:tar_cf_clock|
                           |X:tar_cf_clock|
                           |Z:tar_cf_clock|)
                         (not (and (|<:tar_cf_clock:tar_cf_clock|
                                     |X:tar_cf_clock|
                                     |Y:tar_cf_clock|)
                                   (|<:tar_cf_clock:tar_cf_clock|
                                     |Y:tar_cf_clock|
                                     |Z:tar_cf_clock|))))))
           (=> (tar_cf_clock.succ |X:tar_cf_clock| |Z:tar_cf_clock|) a!1)))
       a!164
       a!165
       (forall ((|T:tar_cf_clock| tar_cf_clock) (|U:tar_cf_clock| tar_cf_clock))
         (or (|<:tar_cf_clock:tar_cf_clock| |T:tar_cf_clock| |U:tar_cf_clock|)
             (= |T:tar_cf_clock| |U:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |U:tar_cf_clock| |T:tar_cf_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock))
         (or (= |0:tar_cf_clock| |X:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |0:tar_cf_clock| |X:tar_cf_clock|)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (__ref.evs.req |T0:lclock|) nop))
                        (not (= (__ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (__ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (__ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (__ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       a!166
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__cf_live.issued_memc |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (__ref.evs.req |T:lclock|) read)
                             (= (__ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__rfn.evqual |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (__ref.evs.cmp |T:lclock|) rrsp)
                             (= (__ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (__ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (__rfn.evcomplete |T:lclock|) a!1)))
       a!167
       a!168
       a!169
       a!170
       a!171
       a!172
       a!173
       a!174
       a!175
       a!176
       a!177
       (forall ((|V0:mem_type| mem_type) (|V1:addr_type| addr_type))
         (not (memc.rd_fair |V0:mem_type| |V1:addr_type|)))
       a!178
       (forall ((|V0:mem_type| mem_type) (|V1:addr_type| addr_type))
         (not (memc.wr_fair |V0:mem_type| |V1:addr_type|)))
       a!179
       a!180
       |__m_loc:ordpip|
       (= |__m_loc:tt| |0:lclock|)
       (= |__new_loc:tt| (ite __ts0_b |__m_loc:tt| |__loc:t|))
       (= |__new_loc:ordpip| (ite __ts0_b |__m_loc:ordpip| false))
       (= |__new_fml:lt| |__new_loc:tt|)
       (= |__new_fml:val| |__new_fml:lt|)
       (= __m__old_l2s_g_6 __l2s_g_6)
       (= __m__old_l2s_g_10 __l2s_g_10)
       (= dramc_nb2.memc_pushing.value |__new_fml:val|)
       a!181
       (= new__old_l2s_g_6_a __m_l2s_g_6)
       (= new__old_l2s_g_10_a __m_l2s_g_10)
       __m_dramc_nb2.memc_pushing.now
       a!182
       a!183
       a!184
       (= _old_l2s_g_6 __m_l2s_g_6_a)
       (= _old_l2s_g_10 __m_l2s_g_10_a)
       (not dramc_nb2.memc_pushing.now)
       a!185
       a!186
       a!187
       (= |__new_fml:x| (__ref.lt_tar (ref.evs.m |__new_loc:tt|)))
       (forall ((|V0:mem_type| mem_type))
         (let ((a!1 (ite (and (= |V0:mem_type| (ref.evs.m |__new_loc:tt|)))
                         |__fml:y|
                         (__ref.lt_tar |V0:mem_type|))))
           (= (ref.lt_tar |V0:mem_type|) a!1)))
       a!188
       (forall ((|V0:lclock| lclock))
         (= (_old_l2s_g_0 |V0:lclock|) (__l2s_g_0 |V0:lclock|)))
       a!189
       (= |__new_fml:lt_b| |__new_loc:tt|)
       (= |__new_loc:m| (ref.evs.m |__new_fml:lt_b|))
       (= |__new_prm:M| |__new_loc:m|)
       (= |__new_fml:lt_a| (ref.evs.lt_arr |__new_fml:lt_b|))
       (= |__new_fml:kind| (= (__ref.evs.req |__new_fml:lt_b|) read))
       (forall ((|V0:mem_type| mem_type) (|V1:tar_clock| tar_clock))
         (= (rfn.abs.queue |V0:mem_type| |V1:tar_clock|)
            (__rfn.abs.queue |V0:mem_type| |V1:tar_clock|)))
       (forall ((|V0:mem_type| mem_type) (|V1:tar_clock| tar_clock))
         (= (rfn.abs.begun |V0:mem_type| |V1:tar_clock|)
            (__rfn.abs.begun |V0:mem_type| |V1:tar_clock|)))
       (= __ts0_a_a (rfn.evqual |__new_loc:m| |__new_fml:lt_b|))
       (= _old_l2s_g_5 ___old_l2s_g_5)
       (= l2s_g_5 __l2s_g_5)
       (= _old_l2s_g_9 ___old_l2s_g_9)
       (= l2s_g_9 __l2s_g_9)
       (= dramc_nb2.memc_arriving.value __dramc_nb2.memc_arriving.value)
       (= l2s_w_4 __l2s_w_4)
       (= dramc_nb2.memc_arriving.now __dramc_nb2.memc_arriving.now)
       (= __ts0_b_a (ite __ts0_e (not a!190) (not a!191)))
       (forall ((|V0:lclock| lclock))
         (= (_old_l2s_g_1 |V0:lclock|) (___old_l2s_g_1 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (l2s_g_1 |V0:lclock|) (__l2s_g_1 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (_old_l2s_g_2 |V0:lclock|) (___old_l2s_g_2 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (l2s_g_2 |V0:lclock|) (__l2s_g_2 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (ref.evs.l_cmp |V0:lclock|) (__ref.evs.l_cmp |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (cmpl_live.cf_cpl |V0:lclock|) (__cmpl_live.cf_cpl |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (cmpl_live.arm_cpl |V0:lclock|) (__cmpl_live.arm_cpl |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
            (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
            (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (l2s_w_0 |V0:lclock|) (__l2s_w_0 |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (ref.evs.req |V0:lclock|) (__ref.evs.req |V0:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (ref.evs.cmp |V0:lclock|) (__ref.evs.cmp |V0:lclock|)))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (= (ref.pnd_or_ser_wr
              |V0:proc|
              |V1:mem_type|
              |V2:addr_type|
              |V3:lclock|)
            (__ref.pnd_or_ser_wr
              |V0:proc|
              |V1:mem_type|
              |V2:addr_type|
              |V3:lclock|)))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (= (ref.pnd_or_ser_rd
              |V0:proc|
              |V1:mem_type|
              |V2:addr_type|
              |V3:lclock|)
            (__ref.pnd_or_ser_rd
              |V0:proc|
              |V1:mem_type|
              |V2:addr_type|
              |V3:lclock|)))
       (forall ((|V0:lclock| lclock))
         (= (ref.evs.serialized |V0:lclock|) (__ref.evs.serialized |V0:lclock|)))
       a!192
       (= __ts0__ts0_d_a (= |__fml:ph| wr_ph))
       (= __ts0_e (= |__fml:ph| rd_ph))
       (forall ((|V0:tar_cf_clock| tar_cf_clock))
         (= (l2s_d |V0:tar_cf_clock|) (__l2s_d_d |V0:tar_cf_clock|)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       a!193
       a!194
       a!195
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T0:lclock|) nGnRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T1:lclock|) nGnRE)))))
           (= (ref.both_nGnR |T0:lclock| |T1:lclock|) a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGRE)
                             (= (ref.evs.op_ack |T0:lclock|) _GRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGRE)
                             (= (ref.evs.op_ack |T1:lclock|) _GRE)))))
           (= (ref.both_nGR |T0:lclock| |T1:lclock|) a!1)))
       a!196
       a!197
       a!198
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (cf_live.issued_memc |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (rfn.evqual |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (rfn.evcomplete |T:lclock|) a!1)))
       a!199
       a!200
       a!201
       a!202
       a!203
       a!204
       a!205))))
(assert (and (not false)))
(check-sat)
(get-info :all-statistics)
