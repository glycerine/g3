(declare-sort lclock)
(declare-datatypes ((op_type 0)) ((op_type (nop) (write) (read) (rrsp) (wr_cmp))))
(declare-sort proc)
(declare-sort tar_cf_clock)
(declare-datatypes ((loc_type 0)) ((loc_type (init_l) (cf_mem_l) (cf_pio_l) (cf_cmp_l) (if_l) (memc_l) (dramc_l) (arm_l))))
(declare-datatypes ((mem_loc_type 0)) ((mem_loc_type (mem_loc_init) (mem_memc) (pio_memc))))
(declare-sort tar_clock)
(declare-sort index)
(declare-datatypes ((ph_type 0)) ((ph_type (nop_ph) (wr_ph) (rd_ph) (cpl_ph))))
(declare-datatypes ((op_ack_type 0)) ((op_ack_type (nGnRnE) (nGnRE) (nGRE) (_GRE) (normal))))
(declare-sort addr_type)
(declare-sort mem_type)
(declare-fun ref.evs.l_cmp (lclock) loc_type)
(declare-fun ref.evs.cmp (lclock) op_type)
(declare-fun ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun rfn.evcomplete (lclock) Bool)
(declare-fun ref.evs.l_req (lclock) loc_type)
(declare-fun ref.evs.m (lclock) mem_type)
(declare-fun ref.evs.req (lclock) op_type)
(declare-fun rfn.evqual (mem_type lclock) Bool)
(declare-fun cf_live.issued_memc (lclock) Bool)
(declare-fun ref.nGnR (op_ack_type) Bool)
(declare-fun ref.evs.op_ack (lclock) op_ack_type)
(declare-fun ref.nGR (op_ack_type) Bool)
(declare-fun ref.dev (lclock) Bool)
(declare-fun ref.both_nGR (lclock lclock) Bool)
(declare-fun ref.both_nGnR (lclock lclock) Bool)
(declare-fun ref.both_normal (lclock lclock) Bool)
(declare-fun ref.same_attr (lclock lclock) Bool)
(declare-fun ref.evs.a (lclock) addr_type)
(declare-fun ref.mem_memc_exception (lclock lclock) Bool)
(declare-fun ref.evs.p (lclock) proc)
(declare-fun |<:lclock:lclock| (lclock lclock) Bool)
(declare-fun ref.evs.serialized (lclock) Bool)
(declare-fun ref.prevents (lclock lclock) Bool)
(declare-fun |__fml:ph| () ph_type)
(declare-fun __ts0_a () Bool)
(declare-fun __ref.evs.l_cmp (lclock) loc_type)
(declare-fun |__loc:tt| () lclock)
(declare-fun __ts0__ts0__ts0_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0_c () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0_b_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a (lclock lclock) Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a| () lclock)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0_a_a () Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_loc:a_a| () addr_type)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_loc:m_a| () mem_type)
(declare-fun |__fml:p| () proc)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a| () proc)
(declare-fun __isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun |__new_fml:a| () addr_type)
(declare-fun |__new_fml:m| () mem_type)
(declare-fun __ts0_c_a () Bool)
(declare-fun isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun __isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.prevents_a_a (lclock lclock) Bool)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:lt_a_a| () lclock)
(declare-fun __ts0__ts0__ts0__ts0__ts0_a_a_a () Bool)
(declare-fun __ref.evs.serialized (lclock) Bool)
(declare-fun |__ts0__ts0__ts0__ts0__new_loc:a_a_a| () addr_type)
(declare-fun |__ts0__ts0__ts0__ts0__new_loc:m_a_a| () mem_type)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:p_a_a_a| () proc)
(declare-fun |__loc:ordrob| () Bool)
(declare-fun |__new_loc:ordrob| () Bool)
(declare-fun |__loc:ordrob1| () Bool)
(declare-fun |__new_loc:ordrob1| () Bool)
(declare-fun |__loc:ordrob0| () Bool)
(declare-fun |__new_loc:ordrob0| () Bool)
(declare-fun |__fml:a| () addr_type)
(declare-fun |__fml:m| () mem_type)
(declare-fun rfn2.abs.completed (proc lclock) Bool)
(declare-fun |__loc:x| () lclock)
(declare-fun |__ts0__new_prm:P| () proc)
(declare-fun __ts0__ts0__ts0_a () Bool)
(declare-fun __rfn2.abs.done (proc lclock) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun rfn2.abs.done (proc lclock) Bool)
(declare-fun __rfn2.abs.trying.now (proc) Bool)
(declare-fun __ts0__m_rfn2.abs.trying.now (proc) Bool)
(declare-fun |__ts0__new_prm:P_a| () proc)
(declare-fun rfn2.abs.trying.now (proc) Bool)
(declare-fun |__ts0__new_fml:p_a| () proc)
(declare-fun |__fml:t| () lclock)
(declare-fun |__ts0__new_fml:lt| () lclock)
(declare-fun __m_arm.cpl_fair (proc) Bool)
(declare-fun arm.cpl_fair (proc) Bool)
(declare-fun __arm.cpl_fair (proc) Bool)
(declare-fun __rfn.evcomplete (lclock) Bool)
(declare-fun __ref.prevents (lclock lclock) Bool)
(declare-fun |<:tar_cf_clock:tar_cf_clock| (tar_cf_clock tar_cf_clock) Bool)
(declare-fun |0:tar_cf_clock| () tar_cf_clock)
(declare-fun tar_cf_clock.succ (tar_cf_clock tar_cf_clock) Bool)
(declare-fun |<:tar_clock:tar_clock| (tar_clock tar_clock) Bool)
(declare-fun |0:tar_clock| () tar_clock)
(declare-fun tar_clock.succ (tar_clock tar_clock) Bool)
(declare-fun |0:lclock| () lclock)
(declare-fun lclock.succ (lclock lclock) Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun |0:index| () index)
(declare-fun index.succ (index index) Bool)
(declare-fun dramc.wr_fair (mem_type) Bool)
(declare-fun dramc.rd_fair (mem_type) Bool)
(declare-fun rfn.abs.begun (mem_type tar_clock) Bool)
(declare-fun ref.lt_tar (mem_type) tar_clock)
(declare-fun rfn.abs.queue (mem_type tar_clock) Bool)
(declare-fun rfn.abs.done (mem_type tar_clock) Bool)
(declare-fun ref.evs.lt_arr (lclock) tar_clock)
(declare-fun rfn.abs.lastq (mem_type) tar_clock)
(declare-fun rfn.abs.trying2.now (mem_type) Bool)
(declare-fun rfn.abs.trying1.now (mem_type) Bool)
(declare-fun ref.pio (lclock) Bool)
(declare-fun isd.rsp (proc mem_type addr_type lclock) Bool)
(declare-fun ref.lt () lclock)
(declare-fun ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun ref.same_addr (lclock lclock) Bool)
(declare-fun ref.evs.lt_tar (lclock) tar_clock)
(declare-fun dramc.t_min (mem_type) tar_clock)
(declare-fun ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun cfabric.t_rd_min () lclock)
(declare-fun cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun ref.lt_tar_cf () tar_cf_clock)
(declare-fun rfn2.abs.begun (proc lclock) Bool)
(declare-fun __cmpl_live.retired (lclock) Bool)
(declare-fun cmpl_live.retired (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun __cmpl_live.arm_cpl (lclock) Bool)
(declare-fun cmpl_live.arm_cpl (lclock) Bool)
(declare-fun __cmpl_live.cf_cpl (lclock) Bool)
(declare-fun cmpl_live.cf_cpl (lclock) Bool)
(declare-fun __ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun __ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0_b_a () Bool)
(declare-fun __m_ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun __m_ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0_b () Bool)
(declare-fun @T () lclock)
(declare-fun @P () proc)
(declare-fun @A () addr_type)
(declare-fun @M () mem_type)
(assert (let ((a!1 (forall ((|A:addr_type| addr_type)
                    (|M:mem_type| mem_type)
                    (|P:proc| proc)
                    (|T:lclock| lclock))
             (let ((a!1 (and (rfn2.abs.begun |P:proc| |T:lclock|)
                             (not (__rfn2.abs.done |P:proc| |T:lclock|))
                             (=> (rfn2.abs.completed |P:proc| |T:lclock|)
                                 (= (__ref.evs.l_cmp |T:lclock|) arm_l)))))
               (=> (or (__isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                       (__isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|))
                   a!1))))
      (a!2 (forall ((|P:proc| proc) (|X:lclock| lclock))
             (=> (|<:lclock:lclock| ref.lt |X:lclock|)
                 (not (rfn2.abs.begun |P:proc| |X:lclock|)))))
      (a!3 (forall ((|P:proc| proc)) (not (__rfn2.abs.trying.now |P:proc|))))
      (a!4 (forall ((|P:proc| proc) (|X:lclock| lclock) (|Y:lclock| lclock))
             (=> (and (rfn2.abs.begun |P:proc| |X:lclock|)
                      (__rfn2.abs.done |P:proc| |X:lclock|)
                      (|<:lclock:lclock| |Y:lclock| |X:lclock|)
                      (rfn2.abs.begun |P:proc| |Y:lclock|))
                 (__rfn2.abs.done |P:proc| |Y:lclock|))))
      (a!5 (forall ((|P:proc| proc) (|X:lclock| lclock))
             (=> (rfn2.abs.completed |P:proc| |X:lclock|)
                 (rfn2.abs.begun |P:proc| |X:lclock|))))
      (a!6 (forall ((|P:proc| proc) (|X:lclock| lclock))
             (=> (__rfn2.abs.done |P:proc| |X:lclock|)
                 (and (rfn2.abs.begun |P:proc| |X:lclock|)
                      (rfn2.abs.completed |P:proc| |X:lclock|)))))
      (a!7 (forall ((|X:lclock| lclock))
             (not (|<:lclock:lclock| |X:lclock| |0:lclock|))))
      (a!8 (forall ((|T:lclock| lclock) (|Tarr:tar_cf_clock| tar_cf_clock))
             (let ((a!1 (exists ((|\|T:lclock\|!1| lclock))
                          (and (= (ref.evs.req |\|T:lclock\|!1|) read)
                               (= (ref.evs.l_req |\|T:lclock\|!1|) cf_mem_l)
                               (= (ref.evs.lt_arr_cf |\|T:lclock\|!1|)
                                  cfabric.t_rd_arr_min)))))
               (=> (and (= cfabric.t_rd_arr_min |Tarr:tar_cf_clock|)
                        (= (ref.evs.req |T:lclock|) read)
                        (= (ref.evs.l_req |T:lclock|) cf_mem_l))
                   a!1))))
      (a!9 (forall ((|T:lclock| lclock))
             (=> (and (= (ref.evs.req |T:lclock|) read)
                      (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                      (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                      (= |T:lclock| ref.lt))
                 (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf))))
      (a!10 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (not (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!11 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                        (|<:tar_cf_clock:tar_cf_clock|
                          (ref.evs.lt_arr_cf |T:lclock|)
                          ref.lt_tar_cf))))))
      (a!12 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                  (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                      (|<:tar_cf_clock:tar_cf_clock|
                        (ref.evs.lt_arr_cf |T:lclock|)
                        ref.lt_tar_cf)))))
      (a!13 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                  (|<:tar_cf_clock:tar_cf_clock|
                    (ref.evs.lt_arr_cf |T:lclock|)
                    ref.lt_tar_cf))))
      (a!14 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (or (= (ref.evs.l_req |T:lclock|) memc_l)
                                  (= (ref.evs.l_req |T:lclock|) dramc_l)))))
              (let ((a!2 (and (or a!1 (= (ref.evs.cmp |T:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!2
                    (|<:tar_cf_clock:tar_cf_clock|
                      (ref.evs.lt_arr_cf |T:lclock|)
                      cfabric.t_rd_arr_min))))))
      (a!15 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.req |T0:lclock|) read)
                       (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.req |T1:lclock|) read)
                       (= (ref.evs.l_req |T1:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_cf_clock:tar_cf_clock|
                    (ref.evs.lt_arr_cf |T0:lclock|)
                    (ref.evs.lt_arr_cf |T1:lclock|)))))
      (a!16 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (and (= (ref.evs.req |T:lclock|) nop)
                                   (= (ref.evs.cmp |T:lclock|) nop)))))
                (=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|)))
                    a!1))))
      (a!17 (forall ((|T:lclock| lclock))
              (=> (or (|<:lclock:lclock| ref.lt |T:lclock|)
                      (= |T:lclock| |0:lclock|))
                  (and (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)
                       (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|)))))
      (a!18 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= cfabric.t_rd_arr_min (ref.evs.lt_arr_cf |T:lclock|))
                        (|<:tar_cf_clock:tar_cf_clock|
                          cfabric.t_rd_arr_min
                          (ref.evs.lt_arr_cf |T:lclock|)))))))
      (a!19 (forall ((|T:lclock| lclock))
              (not (and (= (ref.evs.req |T:lclock|) read)
                        (= (ref.evs.l_req |T:lclock|) cf_mem_l)))))
      (a!20 (forall ((|T:lclock| lclock))
              (and (= (ref.evs.req |T:lclock|) nop)
                   (= (ref.evs.cmp |T:lclock|) nop))))
      (a!21 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (not (= (ref.evs.mem_loc |T:lclock|) mem_memc)))))
              (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) nop)
                                  (= (ref.evs.cmp |T:lclock|) nop))
                             (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             a!1)))
                (=> a!2 (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!22 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T1:lclock|) read)
                              (not (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
              (let ((a!2 (and (= (ref.evs.req |T0:lclock|) read)
                              (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (ref.evs.req |T1:lclock|) write)
                                  a!1
                                  (= (ref.evs.req |T1:lclock|) nop)))))
                (=> a!2
                    (not (= (ref.evs.lt_arr_cf |T1:lclock|)
                            cfabric.t_rd_arr_min)))))))
      (a!23 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1 (not (|<:lclock:lclock| |T:lclock| cfabric.t_rd_min))))))
      (a!24 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) rrsp)
                              (not (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                    (a!2 (=> (and (= (ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                             (= (ref.evs.l_req |T:lclock|) cf_mem_l))))
              (let ((a!3 (and (or (= (ref.evs.cmp |T:lclock|) nop)
                                  (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                  a!1)
                              a!2)))
                (=> (|<:lclock:lclock| cfabric.t_rd_min |T:lclock|) a!3)))))
      (a!25 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T:lclock|) rrsp))))
                (=> a!1 (not (= cfabric.t_rd_min |0:lclock|))))))
      (a!26 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                              (or (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                                  (= (ref.evs.l_req |T:lclock|) cf_pio_l)))))
                (=> a!1 (not (= |T:lclock| cfabric.t_rd_min))))))
      (a!27 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (not (and (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l)))))
              (let ((a!2 (or (= (ref.evs.req |T1:lclock|) write)
                             (and (= (ref.evs.req |T1:lclock|) read) a!1)
                             (= (ref.evs.req |T1:lclock|) nop))))
                (=> (and (= (ref.evs.req |T0:lclock|) read)
                         (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2)
                    (not (= |T1:lclock| cfabric.t_rd_min)))))))
      (a!28 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T:lclock|) rrsp))))
                (=> (and a!1 (= (ref.evs.mem_loc |T:lclock|) pio_memc))
                    (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!29 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (ref.evs.a |T:lclock|) |A:addr_type|)
                              (= (ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|))))))
      (a!30 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (ref.evs.a |T:lclock|) |A:addr_type|)
                              (not (= (ref.evs.l_req |T:lclock|) dramc_l)))))
                (=> a!1 (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!31 (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (dramc.t_min |M:mem_type|) |0:tar_clock|))))))
      (a!32 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T0:lclock|) read))
                              (= (ref.evs.l_req |T0:lclock|) dramc_l)
                              (or (= (ref.evs.req |T1:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) read))
                              (= (ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))))
                    (a!2 (or (|<:tar_clock:tar_clock|
                               (ref.evs.lt_arr |T0:lclock|)
                               (dramc.t_min (ref.evs.m |T0:lclock|)))
                             (|<:tar_clock:tar_clock|
                               (ref.evs.lt_arr |T1:lclock|)
                               (dramc.t_min (ref.evs.m |T0:lclock|))))))
                (=> a!1 (not a!2)))))
      (a!33 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) read)
                  (= (__ref.evs.l_cmp |T:lclock|) init_l))))
      (a!34 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) write)
                  (= (__ref.evs.l_cmp |T:lclock|) init_l))))
      (a!35 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) nop)
                  (= (ref.evs.l_req |T:lclock|) init_l))))
      (a!36 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.req |T:lclock|) read)
                  (= (ref.evs.req |T:lclock|) write)
                  (= (ref.evs.req |T:lclock|) nop))))
      (a!37 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.cmp |T:lclock|) rrsp)
                  (= (ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (ref.evs.cmp |T:lclock|) nop))))
      (a!38 (forall ((|T:lclock| lclock))
              (=> (not (= (ref.evs.req |T:lclock|) nop))
                  (= (ref.evs.cmp |T:lclock|) nop))))
      (a!39 (forall ((|T:lclock| lclock))
              (=> (not (= (ref.evs.cmp |T:lclock|) nop))
                  (= (ref.evs.req |T:lclock|) nop))))
      (a!40 (forall ((|T:lclock| lclock))
              (let ((a!1 (forall ((|A:addr_type| addr_type)
                                  (|M:mem_type| mem_type)
                                  (|P:proc| proc))
                           (not (or (__isd.wr |P:proc|
                                              |M:mem_type|
                                              |A:addr_type|
                                              |T:lclock|)
                                    (__isd.rd |P:proc|
                                              |M:mem_type|
                                              |A:addr_type|
                                              |T:lclock|))))))
                (=> a!1
                    (and (= (ref.evs.l_req |T:lclock|) init_l)
                         (= (__ref.evs.l_cmp |T:lclock|) init_l))))))
      (a!41 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                              (= (ref.evs.l_req |T:lclock|) dramc_l)))
                    (a!2 (not (|<:tar_clock:tar_clock|
                                (ref.lt_tar (ref.evs.m |T:lclock|))
                                (ref.evs.lt_arr |T:lclock|)))))
                (=> a!1 a!2))))
      (a!42 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (|<:tar_clock:tar_clock|
                      (ref.evs.lt_arr |T:lclock|)
                      (ref.evs.lt_tar |T:lclock|))))))
      (a!43 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.l_req |T0:lclock|) dramc_l))
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.l_req |T0:lclock|) dramc_l))))
                    (a!3 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|)))
                              (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|))))))
              (let ((a!2 (and a!1
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (__ref.evs.l_cmp |T1:lclock|) dramc_l)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!2 a!3)))))
      (a!44 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (ref.evs.cmp |T0:lclock|) rrsp)))
                    (a!2 (or (and (= (ref.evs.req |T1:lclock|) write)
                                  (= (ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) dramc_l))
                             (and (= (ref.evs.req |T1:lclock|) read)
                                  (= (ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (ref.evs.cmp |T1:lclock|) rrsp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) dramc_l))))
                    (a!3 (=> (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                 (= (ref.evs.cmp |T0:lclock|) rrsp))
                             (not (= (ref.evs.lt_tar |T0:lclock|)
                                     (ref.evs.lt_arr |T1:lclock|)))))
                    (a!4 (=> (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                 (= (ref.evs.cmp |T1:lclock|) rrsp))
                             (not (= (ref.evs.lt_arr |T0:lclock|)
                                     (ref.evs.lt_tar |T1:lclock|))))))
              (let ((a!5 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|)))
                              a!3
                              a!4)))
                (=> (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|)))
                    a!5)))))
      (a!45 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|))))
                    (a!2 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|)))
                              (not (= (ref.evs.lt_tar |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|))))))
                (=> a!1 a!2))))
      (a!46 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (not (and (= (ref.evs.req |T0:lclock|) write)
                        (= (ref.evs.cmp |T1:lclock|) rrsp)
                        (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                        (= (ref.evs.l_req |T0:lclock|) dramc_l)
                        (|<:tar_clock:tar_clock|
                          (ref.evs.lt_arr |T0:lclock|)
                          (ref.evs.lt_arr |T1:lclock|))))))
      (a!47 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.req |T0:lclock|) read)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (ref.evs.lt_arr |T0:lclock|)
                    (ref.evs.lt_arr |T1:lclock|)))))
      (a!48 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.req |T1:lclock|) read))
                             (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) write)))))
                (not (and a!1
                          (= (ref.evs.op_ack |T0:lclock|) normal)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))))
      (a!49 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) write))
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.req |T1:lclock|) read)))))
                (=> (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.l_req |T0:lclock|) dramc_l)
                         (= (ref.evs.l_req |T1:lclock|) dramc_l)
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    (|<:tar_clock:tar_clock|
                      (ref.evs.lt_arr |T0:lclock|)
                      (ref.evs.lt_arr |T1:lclock|))))))
      (a!50 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (|<:tar_clock:tar_clock|
                                (ref.lt_tar (ref.evs.m |T:lclock|))
                                (ref.evs.lt_tar |T:lclock|)))))
                (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (ref.evs.cmp |T:lclock|) rrsp))
                    a!1))))
      (a!51 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!1
                    (not (= (ref.evs.lt_tar |T0:lclock|)
                            (ref.evs.lt_tar |T1:lclock|)))))))
      (a!52 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (ref.evs.lt_tar |T0:lclock|)
                    (ref.evs.lt_tar |T1:lclock|)))))
      (a!53 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.l_req |T0:lclock|) if_l)
                              (or (= (ref.evs.l_req |T1:lclock|) if_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
                    (a!2 (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                             (= (ref.evs.l_req |T1:lclock|) if_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
              (let ((a!3 (or (and (= (ref.evs.l_req |T0:lclock|) cf_pio_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_pio_l))
                             a!1
                             (and (= (ref.evs.l_req |T0:lclock|) memc_l) a!2))))
                (=> (and (= (ref.evs.req |T0:lclock|) read)
                         (= (ref.evs.req |T1:lclock|) read)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!3)))))
      (a!54 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (__ref.evs.serialized |T:lclock|))))
                (=> a!1
                    (or (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T:lclock|) pio_memc))))))
      (a!55 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) write)
                  (not (__ref.evs.serialized |T:lclock|)))))
      (a!56 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) read)
                  (not (__ref.evs.serialized |T:lclock|)))))
      (a!57 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.req |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) wr_cmp))
                  (__ref.evs.serialized |T:lclock|))))
      (a!58 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.req |T:lclock|) nop)
                             (= (ref.evs.cmp |T:lclock|) nop)
                             (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))))
                (=> (__ref.evs.serialized |T:lclock|) a!1))))
      (a!59 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             (and (= (ref.evs.cmp |T:lclock|) rrsp)
                                  (not (__ref.evs.serialized |T:lclock|)))))
                    (a!2 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                              (or (= (__ref.evs.l_cmp |T:lclock|) dramc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) memc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) arm_l))))
                    (a!3 (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                              (or (= (__ref.evs.l_cmp |T:lclock|) memc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) if_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) arm_l))))
                    (a!4 (and (__ref.evs.serialized |T:lclock|)
                              (or (= (ref.evs.cmp |T:lclock|) rrsp)
                                  (= (ref.evs.cmp |T:lclock|) wr_cmp))
                              (= (__ref.evs.l_cmp |T:lclock|) init_l))))
                (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (ref.evs.cmp |T:lclock|) rrsp))
                    (or (and a!1 (or a!2 a!3)) a!4)))))
      (a!60 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.l_req |T:lclock|) dramc_l)
                             (= (ref.evs.l_req |T:lclock|) memc_l)
                             (= (ref.evs.l_req |T:lclock|) cf_mem_l)))
                    (a!2 (or (= (ref.evs.l_req |T:lclock|) memc_l)
                             (= (ref.evs.l_req |T:lclock|) if_l)
                             (= (ref.evs.l_req |T:lclock|) cf_pio_l))))
              (let ((a!3 (or (and (= (ref.evs.mem_loc |T:lclock|) mem_memc) a!1)
                             (and (= (ref.evs.mem_loc |T:lclock|) pio_memc) a!2))))
                (=> (or (= (ref.evs.req |T:lclock|) write)
                        (= (ref.evs.req |T:lclock|) read))
                    a!3)))))
      (a!61 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (= (ref.evs.cmp |T1:lclock|) rrsp))))
              (let ((a!2 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) init_l))
                             a!1)))
                (not (and a!2
                          (not (__ref.evs.serialized |T0:lclock|))
                          (__ref.evs.serialized |T1:lclock|)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))))
      (a!62 (forall ((|T:lclock| lclock))
              (=> (not (__ref.evs.serialized |T:lclock|))
                  (not (= (ref.evs.mem_loc |T:lclock|) mem_loc_init)))))
      (a!63 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.req |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) nop))
                  (= (ref.evs.mem_loc |T:lclock|) mem_loc_init))))
      (a!64 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                             (not (= (ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (ref.evs.req |T1:lclock|) nop))
                             (not (= (ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (= (ref.evs.mem_loc |T0:lclock|)
                       (ref.evs.mem_loc |T1:lclock|)))))))
      (a!65 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                             (not (= (ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (ref.evs.req |T1:lclock|) nop))
                             (not (= (ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (or (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T0:lclock|) pio_memc)))))))
      (a!66 (forall ((|T:lclock| lclock) (|T0:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T:lclock|) nop))
                             (not (= (ref.evs.cmp |T0:lclock|) nop)))))
                (=> (and a!1 (not (ref.dev |T:lclock|)))
                    (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!67 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T:lclock|) nop))
                             (not (= (ref.evs.cmp |T:lclock|) nop)))))
                (=> (and a!1 (ref.dev |T:lclock|))
                    (or (= (ref.evs.op_ack |T:lclock|) nGnRE)
                        (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                        (= (ref.evs.op_ack |T:lclock|) _GRE)
                        (= (ref.evs.op_ack |T:lclock|) nGRE))))))
      (a!68 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                              (or (= (ref.evs.req |T1:lclock|) read)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (not (__ref.evs.serialized |T0:lclock|))
                              (not (__ref.evs.serialized |T1:lclock|))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (ref.both_normal |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!69 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.req |T:lclock|) nop)
                  (= (ref.evs.cmp |T:lclock|) nop)
                  (= (ref.evs.req |T:lclock|) write)
                  (= (ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (ref.evs.req |T:lclock|) read)
                  (= (ref.evs.cmp |T:lclock|) rrsp))))
      (a!70 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (__isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!71 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (__isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!72 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                  (ref.dev |T:lclock|))))
      (a!73 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (__isd.wr |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|)
                             (__isd.rd |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE)
                             (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                                 (= (ref.evs.op_ack |T:lclock|) nGnRE)))))
                (=> (and a!1 (ref.dev |T:lclock|)) a!2))))
      (a!74 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (__isd.wr |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|)
                             (__isd.rd |P:proc|
                                       |M:mem_type|
                                       |A:addr_type|
                                       |T:lclock|))))
                (=> (and a!1 (not (ref.dev |T:lclock|)))
                    (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!75 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (__isd.rd |P:proc|
                                  |M0:mem_type|
                                  |A0:addr_type|
                                  |T0:lclock|)
                        (ref.same_attr |T0:lclock| |T1:lclock|)
                        (= |M0:mem_type| |M1:mem_type|)
                        (= |A0:addr_type| |A1:addr_type|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!76 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M0:mem_type|
                                  |A0:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (ref.dev |T0:lclock|)
                        (ref.dev |T1:lclock|)
                        (ref.both_nGnR |T0:lclock| |T1:lclock|)))))
      (a!77 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M0:mem_type|
                                  |A0:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (ref.dev |T0:lclock|)
                        (ref.dev |T1:lclock|)
                        (ref.both_nGR |T0:lclock| |T1:lclock|)
                        (ref.same_addr |T0:lclock| |T1:lclock|)))))
      (a!78 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.rd |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!79 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!80 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.rd |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!81 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (__ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (__isd.wr |P:proc|
                                  |M:mem_type|
                                  |A:addr_type|
                                  |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!82 (forall ((|T:lclock| lclock))
              (=> (or (= |T:lclock| |0:lclock|)
                      (|<:lclock:lclock| ref.lt |T:lclock|))
                  (and (= (ref.evs.req |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) nop)
                       (__ref.evs.serialized |T:lclock|)))))
      (a!83 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (not (= (__ref.evs.l_cmp |T:lclock|) init_l))
                              (__ref.evs.serialized |T:lclock|))))
              (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) write)
                                  (not (__ref.evs.serialized |T:lclock|)))
                             a!1)))
                (= (__isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (and a!2
                        (= (ref.evs.p |T:lclock|) |P:proc|)
                        (= (ref.evs.m |T:lclock|) |M:mem_type|)
                        (= (ref.evs.a |T:lclock|) |A:addr_type|)))))))
      (a!84 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (__isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (not (isd.rsp |P:proc|
                                    |M:mem_type|
                                    |A:addr_type|
                                    |T:lclock|)))
                 (and (= (ref.evs.req |T:lclock|) read)
                      (not (__ref.evs.serialized |T:lclock|))
                      (= (ref.evs.p |T:lclock|) |P:proc|)
                      (= (ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!85 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (__isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (isd.rsp |P:proc| |M:mem_type| |A:addr_type| |T:lclock|))
                 (and (= (ref.evs.cmp |T:lclock|) rrsp)
                      (not (__ref.evs.serialized |T:lclock|))
                      (= (ref.evs.p |T:lclock|) |P:proc|)
                      (= (ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!86 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                       (not (__ref.evs.serialized |T:lclock|)))
                  (not (= (__ref.evs.l_cmp |T:lclock|) dramc_l)))))
      (a!87 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (ref.dev |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T:lclock|) nGnRE)
                             (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE))))
                (=> a!1 a!2))))
      (a!88 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (not (ref.dev |T:lclock|)))))
                (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!89 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.cmp |T:lclock|) wr_cmp))
                              (ref.dev |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T:lclock|) nGnRE)
                             (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE))))
                (=> a!1 a!2))))
      (a!90 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.cmp |T:lclock|) wr_cmp))
                              (not (ref.dev |T:lclock|)))))
                (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!91 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.cmp |T0:lclock|) wr_cmp))
                              (or (= (ref.evs.req |T1:lclock|) write)
                                  (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (ref.same_attr |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                    (a!2 (not (and (__ref.evs.serialized |T1:lclock|)
                                   (not (__ref.evs.serialized |T0:lclock|))))))
                (=> a!1 a!2))))
      (a!92 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) write))
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.req |T1:lclock|) read))))
                    (a!2 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                              (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
                    (a!3 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                             (= (ref.evs.l_req |T1:lclock|) memc_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
              (let ((a!4 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                             a!2
                             (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!3))))
                (=> (and a!1
                         (not (__ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!4)))))
      (a!93 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (or (= (ref.evs.req |T1:lclock|) write)
                                  (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                              (not (__ref.evs.serialized |T0:lclock|))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                              (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!94 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T0:lclock|) write)
                              (or (= (ref.evs.req |T1:lclock|) read)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                              (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                              (ref.same_attr |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!95 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) write))
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.req |T1:lclock|) read))))
                    (a!2 (and (= (ref.evs.l_req |T0:lclock|) if_l)
                              (or (= (ref.evs.l_req |T1:lclock|) if_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
                    (a!3 (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                             (= (ref.evs.l_req |T1:lclock|) if_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
              (let ((a!4 (or (and (= (ref.evs.l_req |T0:lclock|) cf_pio_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_pio_l))
                             a!2
                             (and (= (ref.evs.l_req |T0:lclock|) memc_l) a!3))))
                (=> (and a!1
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!4)))))
      (a!96 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.req |T0:lclock|) write)
                       (= (ref.evs.l_req |T0:lclock|) dramc_l)
                       (= (ref.evs.req |T1:lclock|) write)
                       (= (ref.evs.l_req |T1:lclock|) dramc_l)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                  (= |T0:lclock| |T1:lclock|))))
      (a!97 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.req |T0:lclock|) read)
                       (= (ref.evs.l_req |T0:lclock|) dramc_l)
                       (= (ref.evs.req |T1:lclock|) read)
                       (= (ref.evs.l_req |T1:lclock|) dramc_l)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                  (= |T0:lclock| |T1:lclock|))))
      (a!98 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T1:lclock|) read)
                              (= (ref.evs.l_req |T1:lclock|) cf_mem_l)
                              (= (ref.evs.req |T0:lclock|) read)
                              (or (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                  (= (ref.evs.l_req |T0:lclock|) memc_l)
                                  (= (ref.evs.l_req |T0:lclock|) dramc_l))))
                    (a!2 (and (= (ref.evs.req |T1:lclock|) read)
                              (= (ref.evs.l_req |T1:lclock|) memc_l)
                              (= (ref.evs.req |T0:lclock|) read)
                              (or (= (ref.evs.l_req |T0:lclock|) memc_l)
                                  (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
              (let ((a!3 (or a!1
                             a!2
                             (and (= (ref.evs.req |T1:lclock|) read)
                                  (= (ref.evs.l_req |T1:lclock|) dramc_l)
                                  (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
                (=> (and (= (ref.evs.req |T0:lclock|) read)
                         (not (__ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.req |T1:lclock|) read)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!3)))))
      (a!99 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                              (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
                    (a!2 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                             (= (ref.evs.l_req |T1:lclock|) memc_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
              (let ((a!3 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                  (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                             a!1
                             (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!2))))
                (=> (and (= (ref.evs.req |T0:lclock|) write)
                         (not (__ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.req |T1:lclock|) write)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    a!3)))))
      (a!100 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.l_req |T0:lclock|) dramc_l)
                               (or (= (__ref.evs.l_cmp |T1:lclock|) dramc_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) memc_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) arm_l)))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (not (__ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.cmp |T1:lclock|) rrsp)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!1))))
      (a!101 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) read)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!102 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) write)
                         (= (ref.evs.cmp |T0:lclock|) nop)
                         (= (ref.evs.req |T1:lclock|) nop)
                         (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!103 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (ref.pio |T0:lclock|)
                               (or (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.cmp |T1:lclock|) rrsp))
                               (ref.pio |T1:lclock|)
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (__ref.evs.serialized |T0:lclock|))
                                    (__ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!104 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (or (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.cmp |T1:lclock|) rrsp))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (__ref.evs.serialized |T0:lclock|))
                                    (__ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!105 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying1.now |M:mem_type|))))
      (a!106 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying2.now |M:mem_type|))))
      (a!107 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock|
                          (rfn.abs.lastq |M:mem_type|)
                          |X:tar_clock|)
                        (rfn.abs.begun |M:mem_type| |X:tar_clock|))
                   false)))
      (a!108 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (rfn.abs.begun |M:mem_type| |X:tar_clock|)
                   (rfn.abs.begun |M:mem_type| (rfn.abs.lastq |M:mem_type|)))))
      (a!109 (forall ((|M:mem_type| mem_type)
                      (|X:tar_clock| tar_clock)
                      (|Y:tar_clock| tar_clock))
               (=> (and (rfn.abs.begun |M:mem_type| |X:tar_clock|)
                        (rfn.abs.done |M:mem_type| |X:tar_clock|)
                        (|<:tar_clock:tar_clock| |Y:tar_clock| |X:tar_clock|)
                        (rfn.abs.begun |M:mem_type| |Y:tar_clock|))
                   (rfn.abs.done |M:mem_type| |Y:tar_clock|))))
      (a!110 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (rfn.abs.done |M:mem_type| |X:tar_clock|)
                   (rfn.abs.begun |M:mem_type| |X:tar_clock|))))
      (a!111 (forall ((|X:tar_clock| tar_clock))
               (not (|<:tar_clock:tar_clock| |X:tar_clock| |0:tar_clock|))))
      (a!112 (forall ((|M:mem_type| mem_type)
                      (|T:lclock| lclock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (and (rfn.abs.begun |M:mem_type| |Y:tar_clock|)
                               (=> (rfn.abs.done |M:mem_type| |Y:tar_clock|)
                                   (__rfn.evcomplete |T:lclock|))
                               (= (rfn.abs.queue |M:mem_type| |Y:tar_clock|)
                                  (= (ref.evs.req |T:lclock|) read)))))
                 (=> (and (rfn.evqual |M:mem_type| |T:lclock|)
                          (= |Y:tar_clock| (ref.evs.lt_arr |T:lclock|)))
                     a!1))))
      (a!113 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (|<:tar_clock:tar_clock|
                     (ref.lt_tar |M:mem_type|)
                     |X:tar_clock|)
                   (not (rfn.abs.begun |M:mem_type| |X:tar_clock|)))))
      (a!114 (forall ((|M:mem_type| mem_type))
               (not (dramc.rd_fair |M:mem_type|))))
      (a!115 (forall ((|M:mem_type| mem_type))
               (not (dramc.wr_fair |M:mem_type|))))
      (a!116 (forall ((|P:proc| proc))
               (or (not __ts0_a) (not (rfn2.abs.trying.now |P:proc|)))))
      (a!117 (forall ((|P:proc| proc) (|X:lclock| lclock))
               (or (not __ts0_a)
                   (=> (rfn2.abs.completed |P:proc| |X:lclock|)
                       (rfn2.abs.begun |P:proc| |X:lclock|)))))
      (a!118 (forall ((|X:lclock| lclock))
               (or (not __ts0_a)
                   (not (|<:lclock:lclock| |X:lclock| |0:lclock|)))))
      (a!119 (or (not __ts0_a)
                 (not __ts0_b_a)
                 (not (= (__ref.evs.l_cmp |__loc:tt|) init_l))))
      (a!120 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   (not __ts0__ts0__ts0__ts0_c)
                   __ts0__ts0__ts0__ts0__ts0_a_a_a
                   (= (__m_ref.pnd_or_ser_rd
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)
                      (__ref.pnd_or_ser_rd
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)))))
      (a!121 (forall ((|T:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   (not __ts0__ts0__ts0__ts0_c)
                   (not (ref.prevents |T:lclock| |__loc:tt|)))))
      (a!122 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   __ts0__ts0__ts0__ts0_c
                   (not __ts0__ts0__ts0__ts0__ts0_b_a)
                   __ts0__ts0__ts0__ts0__ts0__ts0_a_a
                   (= (__m_ref.pnd_or_ser_wr
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)
                      (__ref.pnd_or_ser_wr
                        |V0:proc|
                        |V1:mem_type|
                        |V2:addr_type|
                        |V3:lclock|)))))
      (a!123 (forall ((|T:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   __ts0__ts0__ts0__ts0_c
                   (not __ts0__ts0__ts0__ts0__ts0_b_a)
                   (not (ref.prevents |T:lclock| |__loc:tt|)))))
      (a!124 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   __ts0__ts0__ts0__ts0_c
                   __ts0__ts0__ts0__ts0__ts0_b_a
                   (= (cmpl_live.cf_cpl |V0:lclock|)
                      (__cmpl_live.cf_cpl |V0:lclock|)))))
      (a!125 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   __ts0__ts0__ts0__ts0_c
                   __ts0__ts0__ts0__ts0__ts0_b_a
                   (= (cmpl_live.arm_cpl |V0:lclock|)
                      (__cmpl_live.arm_cpl |V0:lclock|)))))
      (a!126 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   __ts0__ts0__ts0__ts0_c
                   __ts0__ts0__ts0__ts0__ts0_b_a
                   (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))))
      (a!127 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   __ts0__ts0__ts0__ts0_c
                   __ts0__ts0__ts0__ts0__ts0_b_a
                   (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))))
      (a!128 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   (not __ts0__ts0__ts0_a_a)
                   __ts0__ts0__ts0__ts0_c
                   __ts0__ts0__ts0__ts0__ts0_b_a
                   (= (cmpl_live.retired |V0:lclock|)
                      (__cmpl_live.retired |V0:lclock|)))))
      (a!129 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   __ts0__ts0__ts0_a_a
                   (= (cmpl_live.cf_cpl |V0:lclock|)
                      (__cmpl_live.cf_cpl |V0:lclock|)))))
      (a!130 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   __ts0__ts0__ts0_a_a
                   (= (cmpl_live.arm_cpl |V0:lclock|)
                      (__cmpl_live.arm_cpl |V0:lclock|)))))
      (a!131 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   __ts0__ts0__ts0_a_a
                   (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))))
      (a!132 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   __ts0__ts0__ts0_a_a
                   (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))))
      (a!133 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_b_a)
                   __ts0__ts0__ts0_a_a
                   (= (cmpl_live.retired |V0:lclock|)
                      (__cmpl_live.retired |V0:lclock|)))))
      (a!134 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_c_a)
                   (= (cmpl_live.cf_cpl |V0:lclock|)
                      (__cmpl_live.cf_cpl |V0:lclock|)))))
      (a!135 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_c_a)
                   (= (cmpl_live.arm_cpl |V0:lclock|)
                      (__cmpl_live.arm_cpl |V0:lclock|)))))
      (a!136 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_c_a)
                   (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))))
      (a!137 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_c_a)
                   (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))))
      (a!138 (forall ((|V0:lclock| lclock))
               (or (not __ts0_a)
                   (not __ts0_c_a)
                   (= (cmpl_live.retired |V0:lclock|)
                      (__cmpl_live.retired |V0:lclock|)))))
      (a!139 (forall ((|V0:lclock| lclock))
               (or __ts0_a
                   (= (cmpl_live.cf_cpl |V0:lclock|)
                      (__cmpl_live.cf_cpl |V0:lclock|)))))
      (a!140 (forall ((|V0:lclock| lclock))
               (or __ts0_a
                   (= (cmpl_live.arm_cpl |V0:lclock|)
                      (__cmpl_live.arm_cpl |V0:lclock|)))))
      (a!141 (forall ((|V0:lclock| lclock))
               (or __ts0_a
                   (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))))
      (a!142 (forall ((|V0:lclock| lclock))
               (or __ts0_a
                   (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))))
      (a!143 (forall ((|V0:lclock| lclock))
               (or __ts0_a
                   (= (cmpl_live.retired |V0:lclock|)
                      (__cmpl_live.retired |V0:lclock|)))))
      (a!144 (forall ((|P:proc| proc) (|X:lclock| lclock) (|Y:lclock| lclock))
               (=> (and (rfn2.abs.begun |P:proc| |X:lclock|)
                        (rfn2.abs.done |P:proc| |X:lclock|)
                        (|<:lclock:lclock| |Y:lclock| |X:lclock|)
                        (rfn2.abs.begun |P:proc| |Y:lclock|))
                   (rfn2.abs.done |P:proc| |Y:lclock|))))
      (a!145 (forall ((|P:proc| proc) (|X:lclock| lclock))
               (=> (rfn2.abs.done |P:proc| |X:lclock|)
                   (and (rfn2.abs.begun |P:proc| |X:lclock|)
                        (rfn2.abs.completed |P:proc| |X:lclock|)))))
      (a!146 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) read)
                   (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!147 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) write)
                   (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!148 (forall ((|T:lclock| lclock))
               (let ((a!1 (forall ((|A:addr_type| addr_type)
                                   (|M:mem_type| mem_type)
                                   (|P:proc| proc))
                            (not (or (isd.wr |P:proc|
                                             |M:mem_type|
                                             |A:addr_type|
                                             |T:lclock|)
                                     (isd.rd |P:proc|
                                             |M:mem_type|
                                             |A:addr_type|
                                             |T:lclock|))))))
                 (=> a!1
                     (and (= (ref.evs.l_req |T:lclock|) init_l)
                          (= (ref.evs.l_cmp |T:lclock|) init_l))))))
      (a!149 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))
                              (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))
                              (= (ref.evs.cmp |T0:lclock|) rrsp)))
                     (a!2 (or (and (= (ref.evs.req |T1:lclock|) write)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l))
                              (and (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                   (= (ref.evs.l_cmp |T1:lclock|) dramc_l))
                              (and (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l))
                              (and (= (ref.evs.cmp |T1:lclock|) rrsp)
                                   (= (ref.evs.l_cmp |T1:lclock|) dramc_l))))
                     (a!3 (=> (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (not (= (ref.evs.lt_tar |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|)))))
                     (a!4 (=> (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|))))))
               (let ((a!5 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                       (ref.evs.lt_arr |T1:lclock|)))
                               a!3
                               a!4)))
                 (=> (and a!1
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          a!2
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (not (= |T0:lclock| |T1:lclock|)))
                     a!5)))))
      (a!150 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                   (= (ref.evs.cmp |T:lclock|) rrsp))
                               (ref.evs.serialized |T:lclock|))))
                 (=> a!1
                     (or (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T:lclock|) pio_memc))))))
      (a!151 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) write)
                   (not (ref.evs.serialized |T:lclock|)))))
      (a!152 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) read)
                   (not (ref.evs.serialized |T:lclock|)))))
      (a!153 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.req |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) wr_cmp))
                   (ref.evs.serialized |T:lclock|))))
      (a!154 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (and (= (ref.evs.cmp |T:lclock|) rrsp)
                                   (not (ref.evs.serialized |T:lclock|)))))
                     (a!2 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                               (or (= (ref.evs.l_cmp |T:lclock|) dramc_l)
                                   (= (ref.evs.l_cmp |T:lclock|) memc_l)
                                   (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                   (= (ref.evs.l_cmp |T:lclock|) arm_l))))
                     (a!3 (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                               (or (= (ref.evs.l_cmp |T:lclock|) memc_l)
                                   (= (ref.evs.l_cmp |T:lclock|) if_l)
                                   (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                   (= (ref.evs.l_cmp |T:lclock|) arm_l))))
                     (a!4 (and (ref.evs.serialized |T:lclock|)
                               (or (= (ref.evs.cmp |T:lclock|) rrsp)
                                   (= (ref.evs.cmp |T:lclock|) wr_cmp))
                               (= (ref.evs.l_cmp |T:lclock|) init_l))))
                 (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                         (= (ref.evs.cmp |T:lclock|) rrsp))
                     (or (and a!1 (or a!2 a!3)) a!4)))))
      (a!155 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (= (ref.evs.cmp |T1:lclock|) rrsp))))
               (let ((a!2 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                   (= (ref.evs.l_cmp |T1:lclock|) init_l))
                              a!1)))
                 (not (and a!2
                           (not (ref.evs.serialized |T0:lclock|))
                           (ref.evs.serialized |T1:lclock|)
                           (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                           (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                           (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                           (ref.same_attr |T0:lclock| |T1:lclock|)
                           (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))))
      (a!156 (forall ((|T:lclock| lclock))
               (=> (not (ref.evs.serialized |T:lclock|))
                   (not (= (ref.evs.mem_loc |T:lclock|) mem_loc_init)))))
      (a!157 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (=> (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (not (= |T:lclock| |0:lclock|)))))
      (a!158 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (=> (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (not (= |T:lclock| |0:lclock|)))))
      (a!159 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (let ((a!1 (or (isd.wr |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|)
                              (isd.rd |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|)))
                     (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGRE)
                              (= (ref.evs.op_ack |T:lclock|) _GRE)
                              (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                                  (= (ref.evs.op_ack |T:lclock|) nGnRE)))))
                 (=> (and a!1 (ref.dev |T:lclock|)) a!2))))
      (a!160 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (let ((a!1 (or (isd.wr |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|)
                              (isd.rd |P:proc|
                                      |M:mem_type|
                                      |A:addr_type|
                                      |T:lclock|))))
                 (=> (and a!1 (not (ref.dev |T:lclock|)))
                     (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!161 (forall ((|A0:addr_type| addr_type)
                      (|A1:addr_type| addr_type)
                      (|M0:mem_type| mem_type)
                      (|M1:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_wr
                           |P:proc|
                           |M1:mem_type|
                           |A1:addr_type|
                           |T1:lclock|)
                         (isd.rd |P:proc|
                                 |M0:mem_type|
                                 |A0:addr_type|
                                 |T0:lclock|)
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (= |M0:mem_type| |M1:mem_type|)
                         (= |A0:addr_type| |A1:addr_type|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!162 (forall ((|A0:addr_type| addr_type)
                      (|A1:addr_type| addr_type)
                      (|M0:mem_type| mem_type)
                      (|M1:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M1:mem_type|
                           |A1:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M0:mem_type|
                                 |A0:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (ref.dev |T0:lclock|)
                         (ref.dev |T1:lclock|)
                         (ref.both_nGnR |T0:lclock| |T1:lclock|)))))
      (a!163 (forall ((|A0:addr_type| addr_type)
                      (|A1:addr_type| addr_type)
                      (|M0:mem_type| mem_type)
                      (|M1:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M1:mem_type|
                           |A1:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M0:mem_type|
                                 |A0:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (ref.dev |T0:lclock|)
                         (ref.dev |T1:lclock|)
                         (ref.both_nGR |T0:lclock| |T1:lclock|)
                         (ref.same_addr |T0:lclock| |T1:lclock|)))))
      (a!164 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.rd |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!165 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_rd
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!166 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_wr
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.rd |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!167 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T0:lclock| lclock)
                      (|T1:lclock| lclock))
               (not (and (ref.pnd_or_ser_wr
                           |P:proc|
                           |M:mem_type|
                           |A:addr_type|
                           |T1:lclock|)
                         (isd.wr |P:proc|
                                 |M:mem_type|
                                 |A:addr_type|
                                 |T0:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                         (not (ref.dev |T0:lclock|))
                         (not (ref.dev |T1:lclock|))))))
      (a!168 (forall ((|T:lclock| lclock))
               (=> (or (= |T:lclock| |0:lclock|)
                       (|<:lclock:lclock| ref.lt |T:lclock|))
                   (and (= (ref.evs.req |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) nop)
                        (ref.evs.serialized |T:lclock|)))))
      (a!169 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l))
                               (ref.evs.serialized |T:lclock|))))
               (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) write)
                                   (not (ref.evs.serialized |T:lclock|)))
                              a!1)))
                 (= (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                    (and a!2
                         (= (ref.evs.p |T:lclock|) |P:proc|)
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (ref.evs.a |T:lclock|) |A:addr_type|)))))))
      (a!170 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                       (not (isd.rsp |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)))
                  (and (= (ref.evs.req |T:lclock|) read)
                       (not (ref.evs.serialized |T:lclock|))
                       (= (ref.evs.p |T:lclock|) |P:proc|)
                       (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!171 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                       (isd.rsp |P:proc| |M:mem_type| |A:addr_type| |T:lclock|))
                  (and (= (ref.evs.cmp |T:lclock|) rrsp)
                       (not (ref.evs.serialized |T:lclock|))
                       (= (ref.evs.p |T:lclock|) |P:proc|)
                       (= (ref.evs.m |T:lclock|) |M:mem_type|)
                       (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!172 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                        (not (ref.evs.serialized |T:lclock|)))
                   (not (= (ref.evs.l_cmp |T:lclock|) dramc_l)))))
      (a!173 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write))
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read))))
                     (a!2 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!3 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (ref.evs.l_req |T1:lclock|) memc_l)
                              (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!4 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!2
                              (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!3))))
                 (=> (and a!1
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!4)))))
      (a!174 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T1:lclock|) read)
                               (= (ref.evs.l_req |T1:lclock|) cf_mem_l)
                               (= (ref.evs.req |T0:lclock|) read)
                               (or (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))))
                     (a!2 (and (= (ref.evs.req |T1:lclock|) read)
                               (= (ref.evs.l_req |T1:lclock|) memc_l)
                               (= (ref.evs.req |T0:lclock|) read)
                               (or (= (ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
               (let ((a!3 (or a!1
                              a!2
                              (and (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l)
                                   (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.req |T1:lclock|) read)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!175 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!2 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (ref.evs.l_req |T1:lclock|) memc_l)
                              (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!3 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!1
                              (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!2))))
                 (=> (and (= (ref.evs.req |T0:lclock|) write)
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.req |T1:lclock|) write)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!3)))))
      (a!176 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.l_req |T0:lclock|) dramc_l)
                               (or (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                                   (= (ref.evs.l_cmp |T1:lclock|) memc_l)
                                   (= (ref.evs.l_cmp |T1:lclock|) cf_mem_l)
                                   (= (ref.evs.l_cmp |T1:lclock|) arm_l)))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (not (ref.evs.serialized |T0:lclock|))
                          (= (ref.evs.cmp |T1:lclock|) rrsp)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     a!1))))
      (a!177 (forall ((|M:mem_type| mem_type)
                      (|T:lclock| lclock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (and (rfn.abs.begun |M:mem_type| |Y:tar_clock|)
                               (=> (rfn.abs.done |M:mem_type| |Y:tar_clock|)
                                   (rfn.evcomplete |T:lclock|))
                               (= (rfn.abs.queue |M:mem_type| |Y:tar_clock|)
                                  (= (ref.evs.req |T:lclock|) read)))))
                 (=> (and (rfn.evqual |M:mem_type| |T:lclock|)
                          (= |Y:tar_clock| (ref.evs.lt_arr |T:lclock|)))
                     a!1))))
      (a!178 (forall ((|T:index| index) (|U:index| index) (|V:index| index))
               (=> (and (|<:index:index| |T:index| |U:index|)
                        (|<:index:index| |U:index| |V:index|))
                   (|<:index:index| |T:index| |V:index|))))
      (a!179 (forall ((|T:index| index) (|U:index| index))
               (not (and (|<:index:index| |T:index| |U:index|)
                         (|<:index:index| |U:index| |T:index|)))))
      (a!180 (forall ((|T:lclock| lclock)
                      (|U:lclock| lclock)
                      (|V:lclock| lclock))
               (=> (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                        (|<:lclock:lclock| |U:lclock| |V:lclock|))
                   (|<:lclock:lclock| |T:lclock| |V:lclock|))))
      (a!181 (forall ((|T:lclock| lclock) (|U:lclock| lclock))
               (not (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                         (|<:lclock:lclock| |U:lclock| |T:lclock|)))))
      (a!182 (forall ((|T:tar_clock| tar_clock)
                      (|U:tar_clock| tar_clock)
                      (|V:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                        (|<:tar_clock:tar_clock| |U:tar_clock| |V:tar_clock|))
                   (|<:tar_clock:tar_clock| |T:tar_clock| |V:tar_clock|))))
      (a!183 (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
               (not (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                         (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))))
      (a!184 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock)
                      (|V:tar_cf_clock| tar_cf_clock))
               (=> (and (|<:tar_cf_clock:tar_cf_clock|
                          |T:tar_cf_clock|
                          |U:tar_cf_clock|)
                        (|<:tar_cf_clock:tar_cf_clock|
                          |U:tar_cf_clock|
                          |V:tar_cf_clock|))
                   (|<:tar_cf_clock:tar_cf_clock|
                     |T:tar_cf_clock|
                     |V:tar_cf_clock|))))
      (a!185 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock))
               (not (and (|<:tar_cf_clock:tar_cf_clock|
                           |T:tar_cf_clock|
                           |U:tar_cf_clock|)
                         (|<:tar_cf_clock:tar_cf_clock|
                           |U:tar_cf_clock|
                           |T:tar_cf_clock|)))))
      (a!186 (forall ((|V0:proc| proc))
               (= (__m_arm.cpl_fair |V0:proc|)
                  (ite (and (= |V0:proc| |__fml:p|))
                       (= |__fml:ph| cpl_ph)
                       (__arm.cpl_fair |V0:proc|)))))
      (a!187 (forall ((|V0:proc| proc))
               (= (arm.cpl_fair |V0:proc|)
                  (ite (and (= |V0:proc| |__fml:p|))
                       false
                       (__m_arm.cpl_fair |V0:proc|)))))
      (a!188 (forall ((|V0:proc| proc))
               (= (__ts0__m_rfn2.abs.trying.now |V0:proc|)
                  (ite (and (= |V0:proc| |__ts0__new_prm:P_a|))
                       true
                       (__rfn2.abs.trying.now |V0:proc|)))))
      (a!189 (forall ((|V0:proc| proc) (|V1:lclock| lclock))
               (let ((a!1 (ite __ts0__ts0__ts0_a
                               (ite (and (= |V0:proc| |__ts0__new_prm:P|)
                                         (= |V1:lclock| |__loc:x|))
                                    true
                                    (__rfn2.abs.done |V0:proc| |V1:lclock|))
                               (__rfn2.abs.done |V0:proc| |V1:lclock|))))
                 (= (rfn2.abs.done |V0:proc| |V1:lclock|)
                    (ite __ts0_a
                         (ite __ts0_c
                              (__rfn2.abs.done |V0:proc| |V1:lclock|)
                              a!1)
                         (__rfn2.abs.done |V0:proc| |V1:lclock|))))))
      (a!190 (= |__new_fml:m|
                (ite __ts0_a
                     (ite __ts0_c_a |__fml:m| (ref.evs.m |__loc:tt|))
                     |__fml:m|)))
      (a!191 (= |__new_fml:a|
                (ite __ts0_a
                     (ite __ts0_c_a |__fml:a| (ref.evs.a |__loc:tt|))
                     |__fml:a|)))
      (a!192 (exists ((|T:lclock| lclock))
               (and (= (ref.evs.cmp |T:lclock|) rrsp)
                    (not (= (__ref.evs.l_cmp |T:lclock|) init_l))
                    (= (ref.evs.p |T:lclock|) |__fml:p|)
                    (|<:lclock:lclock| |T:lclock| |__loc:tt|))))
      (a!194 (exists ((|T:lclock| lclock))
               (and (= (ref.evs.cmp |T:lclock|) wr_cmp)
                    (not (= (__ref.evs.l_cmp |T:lclock|) init_l))
                    (= (ref.evs.p |T:lclock|) |__fml:p|)
                    (|<:lclock:lclock| |T:lclock| |__loc:tt|))))
      (a!196 (ite __ts0_a
                  (ite __ts0_c_a
                       |__loc:ordrob|
                       (and (not __ts0__ts0__ts0_a_a) |__loc:ordrob|))
                  |__loc:ordrob|))
      (a!197 (forall ((|V0:lclock| lclock))
               (let ((a!1 (ite __ts0__ts0__ts0__ts0__ts0_a_a_a
                               (ite (and (= |V0:lclock|
                                            |__ts0__ts0__ts0__ts0__new_fml:lt_a_a|))
                                    true
                                    (__ref.evs.serialized |V0:lclock|))
                               (__ref.evs.serialized |V0:lclock|)))
                     (a!2 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_a
                               (ite (and (= |V0:lclock|
                                            |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a|))
                                    true
                                    (__ref.evs.serialized |V0:lclock|))
                               (__ref.evs.serialized |V0:lclock|))))
               (let ((a!3 (ite __ts0__ts0__ts0_a_a
                               (ite __ts0__ts0__ts0__ts0_c
                                    a!1
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_a
                                         a!2
                                         (__ref.evs.serialized |V0:lclock|)))
                               (__ref.evs.serialized |V0:lclock|))))
                 (= (ref.evs.serialized |V0:lclock|)
                    (ite __ts0_a
                         (ite __ts0_c_a (__ref.evs.serialized |V0:lclock|) a!3)
                         (__ref.evs.serialized |V0:lclock|)))))))
      (a!198 (forall ((|V0:proc| proc)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type)
                      (|V3:lclock| lclock))
               (let ((a!1 (and (= |V0:proc| |__fml:p|)
                               (= |V1:mem_type| |__new_fml:m|)
                               (= |V2:addr_type| |__new_fml:a|)
                               (= |V3:lclock| |__loc:tt|))))
               (let ((a!2 (ite __ts0__ts0__ts0_a_a
                               (ite __ts0__ts0__ts0__ts0_c
                                    (ite a!1
                                         false
                                         (__isd.rd |V0:proc|
                                                   |V1:mem_type|
                                                   |V2:addr_type|
                                                   |V3:lclock|))
                                    (__isd.rd |V0:proc|
                                              |V1:mem_type|
                                              |V2:addr_type|
                                              |V3:lclock|))
                               (__isd.rd |V0:proc|
                                         |V1:mem_type|
                                         |V2:addr_type|
                                         |V3:lclock|))))
                 (= (isd.rd |V0:proc| |V1:mem_type| |V2:addr_type| |V3:lclock|)
                    (ite __ts0_a
                         (ite __ts0_c_a
                              (__isd.rd |V0:proc|
                                        |V1:mem_type|
                                        |V2:addr_type|
                                        |V3:lclock|)
                              a!2)
                         (__isd.rd |V0:proc|
                                   |V1:mem_type|
                                   |V2:addr_type|
                                   |V3:lclock|)))))))
      (a!199 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.mem_memc_exception |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
      (a!200 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.same_attr |T0:lclock| |T1:lclock|)
                  (or (ref.both_nGnR |T0:lclock| |T1:lclock|)
                      (ref.both_nGR |T0:lclock| |T1:lclock|)
                      (ref.both_normal |T0:lclock| |T1:lclock|)))))
      (a!201 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.both_normal |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.op_ack |T0:lclock|) normal)
                       (= (ref.evs.op_ack |T1:lclock|) normal)))))
      (a!202 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGRE)
                      (= |OP_ACK:op_ack_type| _GRE)))))
      (a!203 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGnR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGnRE)
                      (= |OP_ACK:op_ack_type| nGnRnE)))))
      (a!204 (forall ((|T:lclock| lclock))
               (= (ref.dev |T:lclock|)
                  (or (ref.nGR (ref.evs.op_ack |T:lclock|))
                      (ref.nGnR (ref.evs.op_ack |T:lclock|)))))))
(let ((a!193 (= |__new_loc:ordrob0|
                (ite __ts0_a
                     (ite __ts0_c_a
                          |__loc:ordrob0|
                          (ite __ts0__ts0__ts0_a_a a!192 |__loc:ordrob0|))
                     |__loc:ordrob0|)))
      (a!195 (= |__new_loc:ordrob1|
                (ite __ts0_a
                     (ite __ts0_c_a
                          |__loc:ordrob1|
                          (ite __ts0__ts0__ts0_a_a a!194 |__loc:ordrob1|))
                     |__loc:ordrob1|))))
  (and a!1
       a!2
       (forall ((|P:proc| proc)) (not (__arm.cpl_fair |P:proc|)))
       a!3
       a!4
       a!5
       a!6
       a!7
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       a!14
       a!15
       a!16
       a!17
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!18
       (=> a!19
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 cfabric.t_rd_arr_min)
               (= cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!20 (= cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!21
       a!22
       a!23
       a!24
       (=> a!19
           (or (|<:lclock:lclock| ref.lt cfabric.t_rd_min)
               (= cfabric.t_rd_min |0:lclock|)))
       (=> a!20 (= cfabric.t_rd_min |0:lclock|))
       a!25
       a!26
       a!27
       (= (ref.evs.req |0:lclock|) nop)
       (= (ref.evs.l_req |0:lclock|) init_l)
       (= (ref.evs.cmp |0:lclock|) nop)
       (= (__ref.evs.l_cmp |0:lclock|) init_l)
       (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!28
       a!29
       a!30
       a!31
       a!32
       a!33
       a!34
       a!35
       a!36
       a!37
       a!38
       a!39
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!56
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       a!3
       a!4
       a!5
       a!6
       a!7
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       a!14
       a!15
       a!16
       a!17
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!18
       (=> a!19
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 cfabric.t_rd_arr_min)
               (= cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!20 (= cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!21
       a!22
       a!23
       a!24
       (=> a!19
           (or (|<:lclock:lclock| ref.lt cfabric.t_rd_min)
               (= cfabric.t_rd_min |0:lclock|)))
       (=> a!20 (= cfabric.t_rd_min |0:lclock|))
       a!25
       a!26
       a!27
       (= (ref.evs.req |0:lclock|) nop)
       (= (ref.evs.l_req |0:lclock|) init_l)
       (= (ref.evs.cmp |0:lclock|) nop)
       (= (__ref.evs.l_cmp |0:lclock|) init_l)
       (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!28
       a!29
       a!30
       a!31
       a!32
       a!33
       a!34
       a!35
       a!36
       a!37
       a!38
       a!39
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!56
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       (or (not __ts0_a) __ts0_b __ts0_c)
       (or (not __ts0_a)
           (not __ts0_b)
           (not (__rfn2.abs.done |__ts0__new_prm:P| |__loc:x|)))
       (or (not __ts0_a)
           (not __ts0_b)
           (rfn2.abs.begun |__ts0__new_prm:P| |__loc:x|))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (and (and (not (__rfn2.abs.done |__ts0__new_prm:P|
                                                    |V0:lclock|))
                              (rfn2.abs.begun |__ts0__new_prm:P| |V0:lclock|))
                         (or (= |V0:lclock| |__loc:x|)
                             (|<:lclock:lclock| |V0:lclock| |__loc:x|))
                         (not (= |V0:lclock| |__loc:x|)))))
           (or (not __ts0_a) (not __ts0_b) (not a!1))))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (not (and (not (__rfn2.abs.done |__ts0__new_prm:P|
                                                    |V0:lclock|))
                              (rfn2.abs.begun |__ts0__new_prm:P| |V0:lclock|)))))
           (or (not __ts0_a) (not __ts0_c) a!1)))
       a!116
       (forall ((|P:proc| proc) (|X:lclock| lclock) (|Y:lclock| lclock))
         (let ((a!1 (=> (and (rfn2.abs.begun |P:proc| |X:lclock|)
                             (rfn2.abs.done |P:proc| |X:lclock|)
                             (|<:lclock:lclock| |Y:lclock| |X:lclock|)
                             (rfn2.abs.begun |P:proc| |Y:lclock|))
                        (rfn2.abs.done |P:proc| |Y:lclock|))))
           (or (not __ts0_a) a!1)))
       a!117
       (forall ((|P:proc| proc) (|X:lclock| lclock))
         (let ((a!1 (=> (rfn2.abs.done |P:proc| |X:lclock|)
                        (and (rfn2.abs.begun |P:proc| |X:lclock|)
                             (rfn2.abs.completed |P:proc| |X:lclock|)))))
           (or (not __ts0_a) a!1)))
       a!118
       (or (not __ts0_a) __ts0_b_a __ts0_c_a)
       (or (not __ts0_a) (not __ts0_b_a) (= (ref.evs.p |__loc:tt|) |__fml:p|))
       (or (not __ts0_a)
           (not __ts0_b_a)
           (= (ref.evs.cmp |__loc:tt|) rrsp)
           (= (ref.evs.cmp |__loc:tt|) wr_cmp))
       a!119
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.p |V0:lclock|) |__fml:p|)
                         (or (= (ref.evs.cmp |V0:lclock|) rrsp)
                             (= (ref.evs.cmp |V0:lclock|) wr_cmp))
                         (not (= (__ref.evs.l_cmp |V0:lclock|) init_l)))))
         (let ((a!2 (not (and a!1
                              (or (= |V0:lclock| |__loc:tt|)
                                  (|<:lclock:lclock| |V0:lclock| |__loc:tt|))
                              (not (= |V0:lclock| |__loc:tt|))))))
           (or (not __ts0_a) (not __ts0_b_a) a!2))))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a)
               (not __ts0_b_a)
               (not __ts0__ts0__ts0_a_a)
               (not __ts0__ts0__ts0__ts0_c)
               __ts0__ts0__ts0__ts0__ts0_a_a_a
               a!1)))
       a!120
       a!121
       a!122
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a)
               (not __ts0_b_a)
               (not __ts0__ts0__ts0_a_a)
               __ts0__ts0__ts0__ts0_c
               (not __ts0__ts0__ts0__ts0__ts0_b_a)
               __ts0__ts0__ts0__ts0__ts0__ts0_a_a
               a!1)))
       a!123
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a)
               (not __ts0_b_a)
               (not __ts0__ts0__ts0_a_a)
               __ts0__ts0__ts0__ts0_c
               __ts0__ts0__ts0__ts0__ts0_b_a
               a!1)))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a)
               (not __ts0_b_a)
               (not __ts0__ts0__ts0_a_a)
               __ts0__ts0__ts0__ts0_c
               __ts0__ts0__ts0__ts0__ts0_b_a
               a!1)))
       a!124
       a!125
       a!126
       a!127
       a!128
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a) (not __ts0_b_a) __ts0__ts0__ts0_a_a a!1)))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a) (not __ts0_b_a) __ts0__ts0__ts0_a_a a!1)))
       a!129
       a!130
       a!131
       a!132
       a!133
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.p |V0:lclock|) |__fml:p|)
                         (or (= (ref.evs.cmp |V0:lclock|) rrsp)
                             (= (ref.evs.cmp |V0:lclock|) wr_cmp))
                         (not (= (__ref.evs.l_cmp |V0:lclock|) init_l)))))
           (or (not __ts0_a) (not __ts0_c_a) (not a!1))))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a) (not __ts0_c_a) a!1)))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or (not __ts0_a) (not __ts0_c_a) a!1)))
       a!134
       a!135
       a!136
       a!137
       a!138
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_wr
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or __ts0_a a!1)))
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (= (ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|)
                       (__ref.pnd_or_ser_rd
                         |V0:proc|
                         |V1:mem_type|
                         |V2:addr_type|
                         |V3:lclock|))))
           (or __ts0_a a!1)))
       a!139
       a!140
       a!141
       a!142
       a!143
       (forall ((|P:proc| proc)) (not (rfn2.abs.trying.now |P:proc|)))
       a!144
       a!5
       a!145
       a!7
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       a!14
       a!15
       a!16
       a!17
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!18
       (=> a!19
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 cfabric.t_rd_arr_min)
               (= cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!20 (= cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!21
       a!22
       a!23
       a!24
       (=> a!19
           (or (|<:lclock:lclock| ref.lt cfabric.t_rd_min)
               (= cfabric.t_rd_min |0:lclock|)))
       (=> a!20 (= cfabric.t_rd_min |0:lclock|))
       a!25
       a!26
       a!27
       (= (ref.evs.req |0:lclock|) nop)
       (= (ref.evs.l_req |0:lclock|) init_l)
       (= (ref.evs.cmp |0:lclock|) nop)
       (= (ref.evs.l_cmp |0:lclock|) init_l)
       (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!28
       a!29
       a!30
       a!31
       a!32
       a!146
       a!147
       a!35
       a!36
       a!37
       a!38
       a!39
       a!148
       a!41
       a!42
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l))
                        (and (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l))))
               (a!3 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                 (ref.evs.lt_tar |T1:lclock|)))
                         (not (= (ref.evs.lt_arr |T0:lclock|)
                                 (ref.evs.lt_arr |T1:lclock|))))))
         (let ((a!2 (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|)))))
           (=> a!2 a!3))))
       a!149
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!150
       a!151
       a!152
       a!153
       (forall ((|T:lclock| lclock))
         (let ((a!1 (or (= (ref.evs.req |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) rrsp)
                        (= (ref.evs.cmp |T:lclock|) wr_cmp))))
           (=> (ref.evs.serialized |T:lclock|) a!1)))
       a!154
       a!60
       a!155
       a!156
       a!63
       a!64
       a!65
       a!66
       a!67
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                         (or (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (not (ref.evs.serialized |T0:lclock|))
                         (not (ref.evs.serialized |T1:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.both_normal |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
           (not a!1)))
       a!69
       a!157
       a!158
       a!72
       a!159
       a!160
       a!161
       a!162
       a!163
       a!164
       a!165
       a!166
       a!167
       a!168
       a!169
       a!170
       a!171
       a!152
       a!172
       a!87
       a!88
       a!89
       a!90
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.cmp |T0:lclock|) wr_cmp))
                         (or (= (ref.evs.req |T1:lclock|) write)
                             (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (not (and (ref.evs.serialized |T1:lclock|)
                              (not (ref.evs.serialized |T0:lclock|))))))
           (=> a!1 a!2)))
       a!173
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.cmp |T0:lclock|) rrsp))
                         (or (= (ref.evs.req |T1:lclock|) write)
                             (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                         (not (ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
           (not a!1)))
       a!94
       a!95
       a!96
       a!97
       a!174
       a!175
       a!176
       a!101
       a!102
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.cmp |T0:lclock|) rrsp))
                         (ref.pio |T0:lclock|)
                         (or (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (ref.pio |T1:lclock|)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (not (and (not (ref.evs.serialized |T0:lclock|))
                              (ref.evs.serialized |T1:lclock|)))))
           (=> a!1 a!2)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.cmp |T0:lclock|) rrsp))
                         (or (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (not (and (not (ref.evs.serialized |T0:lclock|))
                              (ref.evs.serialized |T1:lclock|)))))
           (=> a!1 a!2)))
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!177
       a!113
       a!114
       a!115
       (forall ((|X:index| index) (|Y:index| index) (|Z:index| index))
         (let ((a!1 (and (|<:index:index| |X:index| |Z:index|)
                         (not (and (|<:index:index| |X:index| |Y:index|)
                                   (|<:index:index| |Y:index| |Z:index|))))))
           (=> (index.succ |X:index| |Z:index|) a!1)))
       a!178
       a!179
       (forall ((|T:index| index) (|U:index| index))
         (or (|<:index:index| |T:index| |U:index|)
             (= |T:index| |U:index|)
             (|<:index:index| |U:index| |T:index|)))
       (forall ((|X:index| index))
         (or (= |0:index| |X:index|) (|<:index:index| |0:index| |X:index|)))
       (forall ((|X:lclock| lclock) (|Y:lclock| lclock) (|Z:lclock| lclock))
         (let ((a!1 (and (|<:lclock:lclock| |X:lclock| |Z:lclock|)
                         (not (and (|<:lclock:lclock| |X:lclock| |Y:lclock|)
                                   (|<:lclock:lclock| |Y:lclock| |Z:lclock|))))))
           (=> (lclock.succ |X:lclock| |Z:lclock|) a!1)))
       a!180
       a!181
       (forall ((|T:lclock| lclock) (|U:lclock| lclock))
         (or (|<:lclock:lclock| |T:lclock| |U:lclock|)
             (= |T:lclock| |U:lclock|)
             (|<:lclock:lclock| |U:lclock| |T:lclock|)))
       (forall ((|X:lclock| lclock))
         (or (= |0:lclock| |X:lclock|)
             (|<:lclock:lclock| |0:lclock| |X:lclock|)))
       (forall ((|X:tar_clock| tar_clock)
                (|Y:tar_clock| tar_clock)
                (|Z:tar_clock| tar_clock))
         (let ((a!1 (and (|<:tar_clock:tar_clock| |X:tar_clock| |Z:tar_clock|)
                         (not (and (|<:tar_clock:tar_clock|
                                     |X:tar_clock|
                                     |Y:tar_clock|)
                                   (|<:tar_clock:tar_clock|
                                     |Y:tar_clock|
                                     |Z:tar_clock|))))))
           (=> (tar_clock.succ |X:tar_clock| |Z:tar_clock|) a!1)))
       a!182
       a!183
       (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
         (or (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
             (= |T:tar_clock| |U:tar_clock|)
             (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))
       (forall ((|X:tar_clock| tar_clock))
         (or (= |0:tar_clock| |X:tar_clock|)
             (|<:tar_clock:tar_clock| |0:tar_clock| |X:tar_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock)
                (|Y:tar_cf_clock| tar_cf_clock)
                (|Z:tar_cf_clock| tar_cf_clock))
         (let ((a!1 (and (|<:tar_cf_clock:tar_cf_clock|
                           |X:tar_cf_clock|
                           |Z:tar_cf_clock|)
                         (not (and (|<:tar_cf_clock:tar_cf_clock|
                                     |X:tar_cf_clock|
                                     |Y:tar_cf_clock|)
                                   (|<:tar_cf_clock:tar_cf_clock|
                                     |Y:tar_cf_clock|
                                     |Z:tar_cf_clock|))))))
           (=> (tar_cf_clock.succ |X:tar_cf_clock| |Z:tar_cf_clock|) a!1)))
       a!184
       a!185
       (forall ((|T:tar_cf_clock| tar_cf_clock) (|U:tar_cf_clock| tar_cf_clock))
         (or (|<:tar_cf_clock:tar_cf_clock| |T:tar_cf_clock| |U:tar_cf_clock|)
             (= |T:tar_cf_clock| |U:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |U:tar_cf_clock| |T:tar_cf_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock))
         (or (= |0:tar_cf_clock| |X:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |0:tar_cf_clock| |X:tar_cf_clock|)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (__ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (__ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (ref.evs.l_req |T1:lclock|) init_l))
                         (__ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (__ref.evs.serialized |T0:lclock|))
                             (__ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (__ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (__rfn.evcomplete |T:lclock|) a!1)))
       a!186
       a!187
       (= |__ts0__new_fml:p_a| |__fml:p|)
       (= |__ts0__new_fml:lt| |__fml:t|)
       (= |__ts0__new_prm:P| |__ts0__new_fml:p_a|)
       (= |__ts0__new_prm:P_a| |__ts0__new_prm:P|)
       a!188
       (forall ((|V0:proc| proc))
         (let ((a!1 (ite __ts0_a
                         (ite (and (= |V0:proc| |__ts0__new_prm:P_a|))
                              false
                              (__ts0__m_rfn2.abs.trying.now |V0:proc|))
                         (__rfn2.abs.trying.now |V0:proc|))))
           (= (rfn2.abs.trying.now |V0:proc|) a!1)))
       a!189
       (= __ts0__ts0__ts0_a (rfn2.abs.completed |__ts0__new_prm:P| |__loc:x|))
       a!190
       a!191
       a!193
       a!195
       (= |__new_loc:ordrob| a!196)
       (= |__ts0__ts0__ts0__ts0__new_fml:p_a_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__new_fml:lt_a_a| |__loc:tt|)
       (= |__ts0__ts0__ts0__ts0__new_loc:m_a_a|
          (ref.evs.m |__ts0__ts0__ts0__ts0__new_fml:lt_a_a|))
       (= |__ts0__ts0__ts0__ts0__new_loc:a_a_a|
          (ref.evs.a |__ts0__ts0__ts0__ts0__new_fml:lt_a_a|))
       a!197
       (= __ts0__ts0__ts0__ts0__ts0_a_a_a
          (= (ref.evs.cmp |__ts0__ts0__ts0__ts0__new_fml:lt_a_a|) rrsp))
       (forall ((|V0:lclock| lclock))
         (let ((a!1 (ite __ts0__ts0__ts0__ts0__ts0_b_a
                         (ite (and (= |V0:lclock|
                                      |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a|))
                              init_l
                              (__ref.evs.l_cmp |V0:lclock|))
                         (__ref.evs.l_cmp |V0:lclock|))))
         (let ((a!2 (ite __ts0__ts0__ts0__ts0_c
                         (ite (and (= |V0:lclock|
                                      |__ts0__ts0__ts0__ts0__new_fml:lt_a_a|))
                              init_l
                              (__ref.evs.l_cmp |V0:lclock|))
                         a!1)))
         (let ((a!3 (ite __ts0_a
                         (ite __ts0_c_a
                              (__ref.evs.l_cmp |V0:lclock|)
                              (ite __ts0__ts0__ts0_a_a
                                   a!2
                                   (__ref.evs.l_cmp |V0:lclock|)))
                         (__ref.evs.l_cmp |V0:lclock|))))
           (= (ref.evs.l_cmp |V0:lclock|) a!3)))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (__ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (__ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__ts0__ts0__ts0__m_ref.prevents_a_a |T0:lclock| |T1:lclock|)
              a!6)))))
       a!198
       (forall ((|V0:proc| proc)
                (|V1:mem_type| mem_type)
                (|V2:addr_type| addr_type)
                (|V3:lclock| lclock))
         (let ((a!1 (and (= |V0:proc| |__fml:p|)
                         (= |V1:mem_type| |__new_fml:m|)
                         (= |V2:addr_type| |__new_fml:a|)
                         (= |V3:lclock| |__loc:tt|))))
         (let ((a!2 (ite __ts0__ts0__ts0__ts0_c
                         (__isd.wr |V0:proc|
                                   |V1:mem_type|
                                   |V2:addr_type|
                                   |V3:lclock|)
                         (ite __ts0__ts0__ts0__ts0__ts0_b_a
                              (ite a!1
                                   false
                                   (__isd.wr |V0:proc|
                                             |V1:mem_type|
                                             |V2:addr_type|
                                             |V3:lclock|))
                              (__isd.wr |V0:proc|
                                        |V1:mem_type|
                                        |V2:addr_type|
                                        |V3:lclock|)))))
         (let ((a!3 (ite __ts0_a
                         (ite __ts0_c_a
                              (__isd.wr |V0:proc|
                                        |V1:mem_type|
                                        |V2:addr_type|
                                        |V3:lclock|)
                              (ite __ts0__ts0__ts0_a_a
                                   a!2
                                   (__isd.wr |V0:proc|
                                             |V1:mem_type|
                                             |V2:addr_type|
                                             |V3:lclock|)))
                         (__isd.wr |V0:proc|
                                   |V1:mem_type|
                                   |V2:addr_type|
                                   |V3:lclock|))))
           (= (isd.wr |V0:proc| |V1:mem_type| |V2:addr_type| |V3:lclock|) a!3)))))
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a| |__loc:tt|)
       (= |__ts0__ts0__ts0__ts0__ts0__new_loc:m_a|
          (ref.evs.m |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a|))
       (= |__ts0__ts0__ts0__ts0__ts0__new_loc:a_a|
          (ref.evs.a |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a|))
       (= __ts0__ts0__ts0__ts0__ts0__ts0_a_a
          (= (ref.evs.cmp |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a|) rrsp))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (__ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (__ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a
                |T0:lclock|
                |T1:lclock|)
              a!6)))))
       (= __ts0__ts0__ts0__ts0__ts0_b_a (= (ref.evs.cmp |__loc:tt|) wr_cmp))
       (= __ts0__ts0__ts0__ts0_c (= (ref.evs.cmp |__loc:tt|) rrsp))
       (= __ts0__ts0__ts0_a_a (= (__ref.evs.l_cmp |__loc:tt|) arm_l))
       (= __ts0_a (= |__fml:ph| cpl_ph))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       a!199
       a!200
       a!201
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T0:lclock|) nGnRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T1:lclock|) nGnRE)))))
           (= (ref.both_nGnR |T0:lclock| |T1:lclock|) a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGRE)
                             (= (ref.evs.op_ack |T0:lclock|) _GRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGRE)
                             (= (ref.evs.op_ack |T1:lclock|) _GRE)))))
           (= (ref.both_nGR |T0:lclock| |T1:lclock|) a!1)))
       a!202
       a!203
       a!204
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (cf_live.issued_memc |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (rfn.evqual |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (rfn.evcomplete |T:lclock|) a!1)))))))
(assert (let ((a!1 (and (rfn2.abs.begun @P @T)
                (not (rfn2.abs.done @P @T))
                (=> (rfn2.abs.completed @P @T) (= (ref.evs.l_cmp @T) arm_l)))))
(let ((a!2 (not (=> (or (isd.rd @P @M @A @T) (isd.wr @P @M @A @T)) a!1))))
  (and a!2))))

(check-sat)
