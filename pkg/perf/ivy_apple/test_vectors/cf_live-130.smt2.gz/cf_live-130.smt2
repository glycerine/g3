; GoIvy cf_live verification condition 130. Source ord_live.ivy, Copyright 2023 Apple, Inc. See LICENSE.txt.
(declare-sort lclock 0)
(declare-datatypes ((op_type 0)) (((nop) (write) (read) (rrsp) (wr_cmp))))
(declare-sort proc 0)
(declare-sort tar_cf_clock 0)
(declare-datatypes ((loc_type 0)) (((init_l) (cf_mem_l) (cf_pio_l) (cf_cmp_l) (if_l) (memc_l) (dramc_l) (arm_l))))
(declare-datatypes ((mem_loc_type 0)) (((mem_loc_init) (mem_memc) (pio_memc))))
(declare-sort tar_clock 0)
(declare-sort index 0)
(declare-datatypes ((ph_type 0)) (((nop_ph) (wr_ph) (rd_ph) (cpl_ph))))
(declare-datatypes ((op_ack_type 0)) (((nGnRnE) (nGnRE) (nGRE) (_GRE) (normal))))
(declare-sort addr_type 0)
(declare-sort mem_type 0)
(declare-fun ref.evs.l_cmp (lclock) loc_type)
(declare-fun ref.evs.cmp (lclock) op_type)
(declare-fun ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun rfn.evcomplete (lclock) Bool)
(declare-fun ref.evs.l_req (lclock) loc_type)
(declare-fun ref.evs.m (lclock) mem_type)
(declare-fun ref.evs.req (lclock) op_type)
(declare-fun rfn.evqual (mem_type lclock) Bool)
(declare-fun cf_live.issued_memc (lclock) Bool)
(declare-fun ref.nGnR (op_ack_type) Bool)
(declare-fun ref.evs.op_ack (lclock) op_ack_type)
(declare-fun ref.nGR (op_ack_type) Bool)
(declare-fun ref.dev (lclock) Bool)
(declare-fun ref.both_nGR (lclock lclock) Bool)
(declare-fun ref.both_nGnR (lclock lclock) Bool)
(declare-fun ref.both_normal (lclock lclock) Bool)
(declare-fun ref.same_attr (lclock lclock) Bool)
(declare-fun ref.evs.a (lclock) addr_type)
(declare-fun ref.mem_memc_exception (lclock lclock) Bool)
(declare-fun ref.evs.p (lclock) proc)
(declare-fun |<:lclock:lclock| (lclock lclock) Bool)
(declare-fun ref.evs.serialized (lclock) Bool)
(declare-fun ref.prevents (lclock lclock) Bool)
(declare-fun __m_l2s_d_b (tar_cf_clock) Bool)
(declare-fun cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun l2s_d (tar_cf_clock) Bool)
(declare-fun __l2s_d_a (tar_cf_clock) Bool)
(declare-fun ref.lt_tar_cf () tar_cf_clock)
(declare-fun __m_l2s_d_a (lclock) Bool)
(declare-fun _T () lclock)
(declare-fun l2s_d (lclock) Bool)
(declare-fun __m_l2s_d (lclock) Bool)
(declare-fun cfabric.t_rd_min () lclock)
(declare-fun __l2s_d (lclock) Bool)
(declare-fun ref.lt () lclock)
(declare-fun |__new_loc:rd| () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun |__fml:sel_memc| () Bool)
(declare-fun |__fml:ph| () ph_type)
(declare-fun __ts0__ts0_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0_a_a () Bool)
(declare-fun |__fml:y_a| () tar_cf_clock)
(declare-fun __ts0__ts0__ts0__ts0__new_cfabric.t_rd_arr_min_a_a () tar_cf_clock)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:x_a| () tar_cf_clock)
(declare-fun __cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun |__loc:tt_a_a| () lclock)
(declare-fun __ts0_c_a_a () Bool)
(declare-fun __ts0__ts0__ts0_a_a_a () Bool)
(declare-fun |__fml:y| () lclock)
(declare-fun __ts0__ts0__ts0__new_cfabric.t_rd_min_a_a () lclock)
(declare-fun |__ts0__ts0__ts0__new_fml:x_a_a| () lclock)
(declare-fun __cfabric.t_rd_min () lclock)
(declare-fun |__loc:tt_a| () lclock)
(declare-fun __ts0_c_a () Bool)
(declare-fun |__new_loc:ordpip| () Bool)
(declare-fun |__new_loc:wr| () Bool)
(declare-fun __ts0_b_a () Bool)
(declare-fun |__new_loc:t| () lclock)
(declare-fun |__ts0__ts0__new_fml:lt_a| () lclock)
(declare-fun __ref.evs.l_cmp (lclock) loc_type)
(declare-fun __ts0_a_a () Bool)
(declare-fun |__new_loc:cmp| () Bool)
(declare-fun __l2s_w_0 () Bool)
(declare-fun l2s_g_0 () Bool)
(declare-fun l2s_g_1 () Bool)
(declare-fun l2s_w_0 () Bool)
(declare-fun __ref.evs.l_req (lclock) loc_type)
(declare-fun ___old_l2s_g_1 () Bool)
(declare-fun __l2s_g_1 () Bool)
(declare-fun _old_l2s_g_1 () Bool)
(declare-fun ___old_l2s_g_0 () Bool)
(declare-fun __l2s_g_0 () Bool)
(declare-fun _old_l2s_g_0 () Bool)
(declare-fun |__new_loc:ordpip3| () Bool)
(declare-fun |__new_loc:ordpip2| () Bool)
(declare-fun |__new_loc:ordpip1| () Bool)
(declare-fun |__new_loc:ordpip0| () Bool)
(declare-fun isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun |__new_loc:p| () proc)
(declare-fun isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun |<:tar_cf_clock:tar_cf_clock| (tar_cf_clock tar_cf_clock) Bool)
(declare-fun __ts0_e () Bool)
(declare-fun __ts0__ts0_d_a () Bool)
(declare-fun |__m_loc:cmp| () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun |__m_loc:wr| () Bool)
(declare-fun |__m_loc:rd| () Bool)
(declare-fun |__loc:a| () addr_type)
(declare-fun |__loc:aa| () addr_type)
(declare-fun |__new_loc:a| () addr_type)
(declare-fun |__loc:m| () mem_type)
(declare-fun |__loc:mm| () mem_type)
(declare-fun |__new_loc:m| () mem_type)
(declare-fun |__loc:p| () proc)
(declare-fun |__loc:pp| () proc)
(declare-fun |__loc:t| () lclock)
(declare-fun |__loc:tt| () lclock)
(declare-fun cfabric.cpl_fair () Bool)
(declare-fun __m_cfabric.cpl_fair () Bool)
(declare-fun cfabric.wr_pio_fair () Bool)
(declare-fun __m_cfabric.wr_pio_fair () Bool)
(declare-fun cfabric.rd_pio_fair () Bool)
(declare-fun __m_cfabric.rd_pio_fair () Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun cfabric.wr_fair () Bool)
(declare-fun __m_l2s_w_2 () Bool)
(declare-fun l2s_w_2 () Bool)
(declare-fun __m_l2s_g_5 () Bool)
(declare-fun new__old_l2s_g_5_a () Bool)
(declare-fun __m_l2s_g_3 () Bool)
(declare-fun new__old_l2s_g_3_a () Bool)
(declare-fun __m_cfabric.wr_fair () Bool)
(declare-fun __l2s_w_2 () Bool)
(declare-fun __l2s_g_5 () Bool)
(declare-fun __m__old_l2s_g_5 () Bool)
(declare-fun __l2s_g_3 () Bool)
(declare-fun __m__old_l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun cfabric.rd_fair () Bool)
(declare-fun __m_l2s_w_1 () Bool)
(declare-fun l2s_w_1 () Bool)
(declare-fun __m_l2s_g_4 () Bool)
(declare-fun new__old_l2s_g_4_a () Bool)
(declare-fun __m_l2s_g_2 () Bool)
(declare-fun new__old_l2s_g_2_a () Bool)
(declare-fun __m_cfabric.rd_fair () Bool)
(declare-fun __l2s_w_1 () Bool)
(declare-fun __l2s_g_4 () Bool)
(declare-fun __m__old_l2s_g_4 () Bool)
(declare-fun __l2s_g_2 () Bool)
(declare-fun __m__old_l2s_g_2 () Bool)
(declare-fun __rfn.evcomplete (lclock) Bool)
(declare-fun __rfn.evqual (mem_type lclock) Bool)
(declare-fun __cf_live.issued_memc (lclock) Bool)
(declare-fun __ref.prevents (lclock lclock) Bool)
(declare-fun |0:tar_cf_clock| () tar_cf_clock)
(declare-fun tar_cf_clock.succ (tar_cf_clock tar_cf_clock) Bool)
(declare-fun |<:tar_clock:tar_clock| (tar_clock tar_clock) Bool)
(declare-fun |0:tar_clock| () tar_clock)
(declare-fun tar_clock.succ (tar_clock tar_clock) Bool)
(declare-fun |0:lclock| () lclock)
(declare-fun lclock.succ (lclock lclock) Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun |0:index| () index)
(declare-fun index.succ (index index) Bool)
(declare-fun dramc.wr_fair (mem_type) Bool)
(declare-fun dramc.rd_fair (mem_type) Bool)
(declare-fun rfn.abs.begun (mem_type tar_clock) Bool)
(declare-fun ref.lt_tar (mem_type) tar_clock)
(declare-fun rfn.abs.queue (mem_type tar_clock) Bool)
(declare-fun rfn.abs.done (mem_type tar_clock) Bool)
(declare-fun ref.evs.lt_arr (lclock) tar_clock)
(declare-fun rfn.abs.lastq (mem_type) tar_clock)
(declare-fun rfn.abs.trying2.now (mem_type) Bool)
(declare-fun rfn.abs.trying1.now (mem_type) Bool)
(declare-fun ref.pio (lclock) Bool)
(declare-fun isd.rsp (proc mem_type addr_type lclock) Bool)
(declare-fun ref.pnd_or_ser_wr (proc mem_type addr_type lclock) Bool)
(declare-fun ref.pnd_or_ser_rd (proc mem_type addr_type lclock) Bool)
(declare-fun ref.same_addr (lclock lclock) Bool)
(declare-fun ref.evs.lt_tar (lclock) tar_clock)
(declare-fun dramc.t_min (mem_type) tar_clock)
(declare-fun __ts0_b_a_a () Bool)
(declare-fun |__loc:aa_a_a| () addr_type)
(declare-fun |__loc:mm_a_a| () mem_type)
(declare-fun |__loc:pp_a_a| () proc)
(declare-fun __ts0_b_b () Bool)
(declare-fun |__loc:aa_a| () addr_type)
(declare-fun |__loc:mm_a| () mem_type)
(declare-fun |__loc:pp_a| () proc)
(declare-fun __e2e.issued_to_cf (proc lclock) Bool)
(declare-fun e2e.issued_to_cf (proc lclock) Bool)
(declare-fun __e2e.issued (lclock mem_type addr_type) Bool)
(declare-fun e2e.issued (lclock mem_type addr_type) Bool)
(declare-fun __cf_pio_live.issued_pio_memc (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_memc (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_if (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_if (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio (lclock) Bool)
(declare-fun cf_pio_live.issued_pio (lclock) Bool)
(declare-fun __dramc_nb2.evqual_wr (lclock mem_type addr_type) Bool)
(declare-fun dramc_nb2.evqual_wr (lclock mem_type addr_type) Bool)
(declare-fun __dramc_nb2.evqual_rd (lclock mem_type addr_type) Bool)
(declare-fun dramc_nb2.evqual_rd (lclock mem_type addr_type) Bool)
(declare-fun __cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_if (lclock) Bool)
(declare-fun __cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun cf_pio_live.issued_pio_cpl_memc (lclock) Bool)
(declare-fun __cmpl_live.arm_cpl (lclock) Bool)
(declare-fun cmpl_live.arm_cpl (lclock) Bool)
(declare-fun __cmpl_live.cf_cpl (lclock) Bool)
(declare-fun cmpl_live.cf_cpl (lclock) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun __cfabric.wr_fair () Bool)
(declare-fun l2s_g_2 () Bool)
(declare-fun __cfabric.rd_fair () Bool)
(declare-fun l2s_init_0 () Bool)
(declare-fun l2s_init_2 () Bool)
(declare-fun l2s_init_1 () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_init_4 () Bool)
(declare-fun l2s_init_3 () Bool)
(declare-fun l2s_s_1 (lclock) Bool)
(declare-fun l2s_s_0 (lclock) Bool)
(declare-fun l2s_a (lclock) Bool)
(assert (let ((a!1 (forall ((|T1:lclock| lclock) (|T2:lclock| lclock))
             (=> (and (__cf_live.issued_memc |T1:lclock|)
                      (= (ref.evs.req |T1:lclock|) read)
                      (__cf_live.issued_memc |T2:lclock|)
                      (= (ref.evs.req |T2:lclock|) read)
                      (|<:lclock:lclock| |T1:lclock| |T2:lclock|))
                 (|<:tar_cf_clock:tar_cf_clock|
                   (ref.evs.lt_arr_cf |T1:lclock|)
                   (ref.evs.lt_arr_cf |T2:lclock|)))))
      (a!2 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (or (= |T:lclock| _T)
                                 (|<:lclock:lclock| |T:lclock| _T))
                             (= (ref.evs.req _T) read))))
               (=> (and (not l2s_init_0) (or (not l2s_waiting) (not __l2s_w_0)))
                   (=> a!1
                       (or (= |T:lclock| ref.lt)
                           (|<:lclock:lclock| |T:lclock| ref.lt)))))))
      (a!3 (forall ((|T:lclock| lclock))
             (=> (or (= |T:lclock| ref.lt)
                     (|<:lclock:lclock| |T:lclock| ref.lt))
                 (and (__l2s_d |T:lclock|)))))
      (a!4 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (or (= |T:lclock| _T)
                                 (|<:lclock:lclock| |T:lclock| _T))
                             (= (ref.evs.req _T) read))))
               (=> (and (not l2s_init_0) (not l2s_waiting))
                   (=> a!1 (and (l2s_a |T:lclock|)))))))
      (a!5 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (not (__cf_live.issued_memc |T:lclock|))
                             (or (= |T:lclock| _T)
                                 (|<:lclock:lclock| |T:lclock| _T))
                             (or (= |T:lclock| ref.lt)
                                 (|<:lclock:lclock| |T:lclock| ref.lt)))))
               (=> (and a!1 (= (ref.evs.req _T) read))
                   (or (= |T:lclock| ref.lt)
                       (|<:lclock:lclock| |T:lclock| ref.lt))))))
      (a!6 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (not (__cf_live.issued_memc |T:lclock|))
                             (or (= |T:lclock| _T)
                                 (|<:lclock:lclock| |T:lclock| _T))
                             (or (= |T:lclock| ref.lt)
                                 (|<:lclock:lclock| |T:lclock| ref.lt)))))
               (=> (and l2s_saved (l2s_s_0 |T:lclock|))
                   (and a!1 (= (ref.evs.req _T) read))))))
      (a!7 (not (forall ((|T:lclock| lclock))
                  (let ((a!1 (and (or (= |T:lclock| _T)
                                      (|<:lclock:lclock| |T:lclock| _T))
                                  (= (ref.evs.req _T) read))))
                    (=> a!1 (l2s_s_0 |T:lclock|))))))
      (a!8 (exists ((|T:lclock| lclock))
             (let ((a!1 (and (not (__cf_live.issued_memc |T:lclock|))
                             (or (= |T:lclock| _T)
                                 (|<:lclock:lclock| |T:lclock| _T))
                             (or (= |T:lclock| ref.lt)
                                 (|<:lclock:lclock| |T:lclock| ref.lt)))))
               (and (not (l2s_s_0 |T:lclock|))
                    (and a!1 (= (ref.evs.req _T) read))))))
      (a!9 (forall ((|T:lclock| lclock))
             (let ((a!1 (and (or (= |T:lclock| _T)
                                 (|<:lclock:lclock| |T:lclock| _T))
                             (= (ref.evs.req _T) write))))
               (=> true
                   (=> a!1
                       (or (= |T:lclock| ref.lt)
                           (|<:lclock:lclock| |T:lclock| ref.lt)))))))
      (a!10 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (= (ref.evs.req _T) write))))
                (=> (and true (not l2s_waiting))
                    (=> a!1 (and (l2s_a |T:lclock|)))))))
      (a!11 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (not (__cf_live.issued_memc |T:lclock|))
                              (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (or (= |T:lclock| ref.lt)
                                  (|<:lclock:lclock| |T:lclock| ref.lt)))))
                (=> (and a!1 (= (ref.evs.req _T) write))
                    (or (= |T:lclock| ref.lt)
                        (|<:lclock:lclock| |T:lclock| ref.lt))))))
      (a!12 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (not (__cf_live.issued_memc |T:lclock|))
                              (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (or (= |T:lclock| ref.lt)
                                  (|<:lclock:lclock| |T:lclock| ref.lt)))))
                (=> (and l2s_saved (l2s_s_1 |T:lclock|))
                    (and a!1 (= (ref.evs.req _T) write))))))
      (a!13 (not (forall ((|T:lclock| lclock))
                   (let ((a!1 (and (or (= |T:lclock| _T)
                                       (|<:lclock:lclock| |T:lclock| _T))
                                   (= (ref.evs.req _T) write))))
                     (=> a!1 (l2s_s_1 |T:lclock|))))))
      (a!14 (exists ((|T:lclock| lclock))
              (let ((a!1 (and (not (__cf_live.issued_memc |T:lclock|))
                              (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (or (= |T:lclock| ref.lt)
                                  (|<:lclock:lclock| |T:lclock| ref.lt)))))
                (and (not (l2s_s_1 |T:lclock|))
                     (and a!1 (= (ref.evs.req _T) write))))))
      (a!16 (not (and (not l2s_init_0) (or (not l2s_waiting) (not __l2s_w_0)))))
      (a!17 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (= (ref.evs.req _T) read)))
                    (a!2 (and (not (__cf_live.issued_memc |T:lclock|))
                              (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (or (= |T:lclock| ref.lt)
                                  (|<:lclock:lclock| |T:lclock| ref.lt)))))
              (let ((a!3 (=> a!1 (and a!2 (= (ref.evs.req _T) read)))))
                (=> (and (and (= |T:lclock| _T) (__cf_live.issued_memc _T))
                         (= (ref.evs.req _T) read))
                    a!3)))))
      (a!18 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (= (ref.evs.req _T) write)))
                    (a!2 (and (not (__cf_live.issued_memc |T:lclock|))
                              (or (= |T:lclock| _T)
                                  (|<:lclock:lclock| |T:lclock| _T))
                              (or (= |T:lclock| ref.lt)
                                  (|<:lclock:lclock| |T:lclock| ref.lt)))))
              (let ((a!3 (=> a!1 (and a!2 (= (ref.evs.req _T) write)))))
                (=> (and (and (= |T:lclock| _T) (__cf_live.issued_memc _T))
                         (= (ref.evs.req _T) write))
                    a!3)))))
      (a!19 (=> (and (not l2s_init_0) (or (not l2s_waiting) (not __l2s_w_0)))
                __l2s_g_1))
      (a!20 (forall ((|T:lclock| lclock) (|Tarr:tar_cf_clock| tar_cf_clock))
              (let ((a!1 (exists ((|\|T:lclock\|!1| lclock))
                           (and (= (ref.evs.req |\|T:lclock\|!1|) read)
                                (= (__ref.evs.l_req |\|T:lclock\|!1|) cf_mem_l)
                                (= (ref.evs.lt_arr_cf |\|T:lclock\|!1|)
                                   __cfabric.t_rd_arr_min)))))
                (=> (and (= __cfabric.t_rd_arr_min |Tarr:tar_cf_clock|)
                         (= (ref.evs.req |T:lclock|) read)
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l))
                    a!1))))
      (a!21 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.req |T:lclock|) read)
                       (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                       (= |T:lclock| ref.lt))
                  (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf))))
      (a!22 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (not (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!23 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                        (|<:tar_cf_clock:tar_cf_clock|
                          (ref.evs.lt_arr_cf |T:lclock|)
                          ref.lt_tar_cf))))))
      (a!24 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                       (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                  (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                      (|<:tar_cf_clock:tar_cf_clock|
                        (ref.evs.lt_arr_cf |T:lclock|)
                        ref.lt_tar_cf)))))
      (a!25 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                  (|<:tar_cf_clock:tar_cf_clock|
                    (ref.evs.lt_arr_cf |T:lclock|)
                    ref.lt_tar_cf))))
      (a!26 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (or (= (__ref.evs.l_req |T:lclock|) memc_l)
                                  (= (__ref.evs.l_req |T:lclock|) dramc_l)))))
              (let ((a!2 (and (or a!1 (= (ref.evs.cmp |T:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!2
                    (|<:tar_cf_clock:tar_cf_clock|
                      (ref.evs.lt_arr_cf |T:lclock|)
                      __cfabric.t_rd_arr_min))))))
      (a!27 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.req |T0:lclock|) read)
                       (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.req |T1:lclock|) read)
                       (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_cf_clock:tar_cf_clock|
                    (ref.evs.lt_arr_cf |T0:lclock|)
                    (ref.evs.lt_arr_cf |T1:lclock|)))))
      (a!28 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (and (= (ref.evs.req |T:lclock|) nop)
                                   (= (ref.evs.cmp |T:lclock|) nop)))))
                (=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|)))
                    a!1))))
      (a!29 (forall ((|T:lclock| lclock))
              (=> (or (|<:lclock:lclock| ref.lt |T:lclock|)
                      (= |T:lclock| |0:lclock|))
                  (and (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)
                       (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|)))))
      (a!30 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (or (= __cfabric.t_rd_arr_min
                           (ref.evs.lt_arr_cf |T:lclock|))
                        (|<:tar_cf_clock:tar_cf_clock|
                          __cfabric.t_rd_arr_min
                          (ref.evs.lt_arr_cf |T:lclock|)))))))
      (a!31 (forall ((|T:lclock| lclock))
              (not (and (= (ref.evs.req |T:lclock|) read)
                        (= (__ref.evs.l_req |T:lclock|) cf_mem_l)))))
      (a!32 (forall ((|T:lclock| lclock))
              (and (= (ref.evs.req |T:lclock|) nop)
                   (= (ref.evs.cmp |T:lclock|) nop))))
      (a!33 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (not (= (ref.evs.mem_loc |T:lclock|) mem_memc)))))
              (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) nop)
                                  (= (ref.evs.cmp |T:lclock|) nop))
                             (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             a!1)))
                (=> a!2 (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!34 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T1:lclock|) read)
                              (not (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
              (let ((a!2 (or (= (ref.evs.req |T1:lclock|) write)
                             a!1
                             (= (ref.evs.req |T1:lclock|) nop))))
                (=> (and (= (ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2)
                    (not (= (ref.evs.lt_arr_cf |T1:lclock|)
                            __cfabric.t_rd_arr_min)))))))
      (a!35 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                              (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1 (not (|<:lclock:lclock| |T:lclock| __cfabric.t_rd_min))))))
      (a!36 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) rrsp)
                              (not (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                    (a!3 (=> (and (= (ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                             (= (__ref.evs.l_req |T:lclock|) cf_mem_l))))
              (let ((a!2 (or (= (ref.evs.cmp |T:lclock|) nop)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             a!1)))
                (=> (|<:lclock:lclock| __cfabric.t_rd_min |T:lclock|)
                    (and a!2 a!3))))))
      (a!37 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T:lclock|) rrsp))))
                (=> a!1 (not (= __cfabric.t_rd_min |0:lclock|))))))
      (a!38 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                              (or (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                                  (= (__ref.evs.l_req |T:lclock|) cf_pio_l)))))
                (=> a!1 (not (= |T:lclock| __cfabric.t_rd_min))))))
      (a!39 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (not (and (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)))))
              (let ((a!2 (or (= (ref.evs.req |T1:lclock|) write)
                             (and (= (ref.evs.req |T1:lclock|) read) a!1)
                             (= (ref.evs.req |T1:lclock|) nop))))
                (=> (and (= (ref.evs.req |T0:lclock|) read)
                         (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2)
                    (not (= |T1:lclock| __cfabric.t_rd_min)))))))
      (a!40 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T:lclock|) rrsp))))
                (=> (and a!1 (= (ref.evs.mem_loc |T:lclock|) pio_memc))
                    (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!41 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (ref.evs.a |T:lclock|) |A:addr_type|)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|))))))
      (a!42 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (ref.evs.a |T:lclock|) |A:addr_type|)
                              (not (= (__ref.evs.l_req |T:lclock|) dramc_l)))))
                (=> a!1 (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!43 (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.m |T:lclock|) |M:mem_type|)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l))))
                (=> a!1 (not (= (dramc.t_min |M:mem_type|) |0:tar_clock|))))))
      (a!44 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T0:lclock|) read))
                              (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                              (or (= (ref.evs.req |T1:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) read))
                              (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))))
                    (a!2 (or (|<:tar_clock:tar_clock|
                               (ref.evs.lt_arr |T0:lclock|)
                               (dramc.t_min (ref.evs.m |T0:lclock|)))
                             (|<:tar_clock:tar_clock|
                               (ref.evs.lt_arr |T1:lclock|)
                               (dramc.t_min (ref.evs.m |T0:lclock|))))))
                (=> a!1 (not a!2)))))
      (a!45 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) read)
                  (= (__ref.evs.l_cmp |T:lclock|) init_l))))
      (a!46 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) write)
                  (= (__ref.evs.l_cmp |T:lclock|) init_l))))
      (a!47 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) nop)
                  (= (__ref.evs.l_req |T:lclock|) init_l))))
      (a!48 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.req |T:lclock|) read)
                  (= (ref.evs.req |T:lclock|) write)
                  (= (ref.evs.req |T:lclock|) nop))))
      (a!49 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.cmp |T:lclock|) rrsp)
                  (= (ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (ref.evs.cmp |T:lclock|) nop))))
      (a!50 (forall ((|T:lclock| lclock))
              (=> (not (= (ref.evs.req |T:lclock|) nop))
                  (= (ref.evs.cmp |T:lclock|) nop))))
      (a!51 (forall ((|T:lclock| lclock))
              (=> (not (= (ref.evs.cmp |T:lclock|) nop))
                  (= (ref.evs.req |T:lclock|) nop))))
      (a!52 (forall ((|T:lclock| lclock))
              (let ((a!1 (forall ((|A:addr_type| addr_type)
                                  (|M:mem_type| mem_type)
                                  (|P:proc| proc))
                           (not (or (isd.wr |P:proc|
                                            |M:mem_type|
                                            |A:addr_type|
                                            |T:lclock|)
                                    (isd.rd |P:proc|
                                            |M:mem_type|
                                            |A:addr_type|
                                            |T:lclock|))))))
                (=> a!1
                    (and (= (__ref.evs.l_req |T:lclock|) init_l)
                         (= (__ref.evs.l_cmp |T:lclock|) init_l))))))
      (a!53 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                  (= (ref.evs.req |T:lclock|) read))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                              (= (__ref.evs.l_req |T:lclock|) dramc_l)))
                    (a!2 (not (|<:tar_clock:tar_clock|
                                (ref.lt_tar (ref.evs.m |T:lclock|))
                                (ref.evs.lt_arr |T:lclock|)))))
                (=> a!1 a!2))))
      (a!54 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                (=> a!1
                    (|<:tar_clock:tar_clock|
                      (ref.evs.lt_arr |T:lclock|)
                      (ref.evs.lt_tar |T:lclock|))))))
      (a!55 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))))
                    (a!3 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|)))
                              (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|))))))
              (let ((a!2 (and a!1
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (__ref.evs.l_cmp |T1:lclock|) dramc_l)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!2 a!3)))))
      (a!56 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (__ref.evs.l_req |T0:lclock|) dramc_l))
                             (= (ref.evs.cmp |T0:lclock|) rrsp)))
                    (a!2 (or (and (= (ref.evs.req |T1:lclock|) write)
                                  (= (__ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) dramc_l))
                             (and (= (ref.evs.req |T1:lclock|) read)
                                  (= (__ref.evs.l_req |T1:lclock|) dramc_l))
                             (and (= (ref.evs.cmp |T1:lclock|) rrsp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) dramc_l))))
                    (a!3 (=> (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                 (= (ref.evs.cmp |T0:lclock|) rrsp))
                             (not (= (ref.evs.lt_tar |T0:lclock|)
                                     (ref.evs.lt_arr |T1:lclock|)))))
                    (a!4 (=> (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                 (= (ref.evs.cmp |T1:lclock|) rrsp))
                             (not (= (ref.evs.lt_arr |T0:lclock|)
                                     (ref.evs.lt_tar |T1:lclock|))))))
              (let ((a!5 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|)))
                              a!3
                              a!4)))
                (=> (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         a!2
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|)))
                    a!5)))))
      (a!57 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|))))
                    (a!2 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|)))
                              (not (= (ref.evs.lt_tar |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|))))))
                (=> a!1 a!2))))
      (a!58 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (not (and (= (ref.evs.req |T0:lclock|) write)
                        (= (ref.evs.cmp |T1:lclock|) rrsp)
                        (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (|<:tar_clock:tar_clock|
                          (ref.evs.lt_arr |T0:lclock|)
                          (ref.evs.lt_arr |T1:lclock|))))))
      (a!59 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.req |T0:lclock|) read)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (ref.evs.lt_arr |T0:lclock|)
                    (ref.evs.lt_arr |T1:lclock|)))))
      (a!60 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.req |T1:lclock|) read))
                             (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) write)))))
                (not (and a!1
                          (= (ref.evs.op_ack |T0:lclock|) normal)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))))
      (a!61 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.req |T1:lclock|) write))
                             (and (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.req |T1:lclock|) read)))))
                (=> (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                         (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                    (|<:tar_clock:tar_clock|
                      (ref.evs.lt_arr |T0:lclock|)
                      (ref.evs.lt_arr |T1:lclock|))))))
      (a!62 (forall ((|T:lclock| lclock))
              (let ((a!1 (not (|<:tar_clock:tar_clock|
                                (ref.lt_tar (ref.evs.m |T:lclock|))
                                (ref.evs.lt_tar |T:lclock|)))))
                (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (ref.evs.cmp |T:lclock|) rrsp))
                    a!1))))
      (a!63 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (not (= |T0:lclock| |T1:lclock|)))))
                (=> a!1
                    (not (= (ref.evs.lt_tar |T0:lclock|)
                            (ref.evs.lt_tar |T1:lclock|)))))))
      (a!64 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (=> (and (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                  (|<:tar_clock:tar_clock|
                    (ref.evs.lt_tar |T0:lclock|)
                    (ref.evs.lt_tar |T1:lclock|)))))
      (a!65 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                              (= (ref.evs.req |T1:lclock|) read)
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                              (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (ref.same_attr |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                    (a!2 (and (= (__ref.evs.l_req |T0:lclock|) if_l)
                              (or (= (__ref.evs.l_req |T1:lclock|) if_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
                    (a!3 (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                             (= (__ref.evs.l_req |T1:lclock|) if_l)
                             (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
              (let ((a!4 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_pio_l)
                                  (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))
                             a!2
                             (and (= (__ref.evs.l_req |T0:lclock|) memc_l) a!3))))
                (=> a!1 a!4)))))
      (a!66 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (ref.evs.serialized |T:lclock|))))
                (=> a!1
                    (or (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T:lclock|) pio_memc))))))
      (a!67 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) write)
                  (not (ref.evs.serialized |T:lclock|)))))
      (a!68 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.req |T:lclock|) read)
                  (not (ref.evs.serialized |T:lclock|)))))
      (a!69 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.req |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) wr_cmp))
                  (ref.evs.serialized |T:lclock|))))
      (a!70 (forall ((|T:lclock| lclock))
              (=> (ref.evs.serialized |T:lclock|)
                  (or (= (ref.evs.req |T:lclock|) nop)
                      (= (ref.evs.cmp |T:lclock|) nop)
                      (= (ref.evs.cmp |T:lclock|) rrsp)
                      (= (ref.evs.cmp |T:lclock|) wr_cmp)))))
      (a!71 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                             (and (= (ref.evs.cmp |T:lclock|) rrsp)
                                  (not (ref.evs.serialized |T:lclock|)))))
                    (a!2 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                              (or (= (__ref.evs.l_cmp |T:lclock|) dramc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) memc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) arm_l))))
                    (a!3 (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                              (or (= (__ref.evs.l_cmp |T:lclock|) memc_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) if_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                  (= (__ref.evs.l_cmp |T:lclock|) arm_l))))
                    (a!4 (and (ref.evs.serialized |T:lclock|)
                              (or (= (ref.evs.cmp |T:lclock|) rrsp)
                                  (= (ref.evs.cmp |T:lclock|) wr_cmp))
                              (= (__ref.evs.l_cmp |T:lclock|) init_l))))
                (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                        (= (ref.evs.cmp |T:lclock|) rrsp))
                    (or (and a!1 (or a!2 a!3)) a!4)))))
      (a!72 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (= (__ref.evs.l_req |T:lclock|) dramc_l)
                             (= (__ref.evs.l_req |T:lclock|) memc_l)
                             (= (__ref.evs.l_req |T:lclock|) cf_mem_l)))
                    (a!2 (or (= (__ref.evs.l_req |T:lclock|) memc_l)
                             (= (__ref.evs.l_req |T:lclock|) if_l)
                             (= (__ref.evs.l_req |T:lclock|) cf_pio_l))))
              (let ((a!3 (or (and (= (ref.evs.mem_loc |T:lclock|) mem_memc) a!1)
                             (and (= (ref.evs.mem_loc |T:lclock|) pio_memc) a!2))))
                (=> (or (= (ref.evs.req |T:lclock|) write)
                        (= (ref.evs.req |T:lclock|) read))
                    a!3)))))
      (a!73 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (= (ref.evs.cmp |T1:lclock|) rrsp))))
              (let ((a!2 (or (and (= (ref.evs.req |T0:lclock|) write)
                                  (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (__ref.evs.l_cmp |T1:lclock|) init_l))
                             a!1)))
                (not (and a!2
                          (not (ref.evs.serialized |T0:lclock|))
                          (ref.evs.serialized |T1:lclock|)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))))
      (a!74 (forall ((|T:lclock| lclock))
              (=> (not (ref.evs.serialized |T:lclock|))
                  (not (= (ref.evs.mem_loc |T:lclock|) mem_loc_init)))))
      (a!75 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.req |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) nop))
                  (= (ref.evs.mem_loc |T:lclock|) mem_loc_init))))
      (a!76 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                             (not (= (ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (ref.evs.req |T1:lclock|) nop))
                             (not (= (ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (= (ref.evs.mem_loc |T0:lclock|)
                       (ref.evs.mem_loc |T1:lclock|)))))))
      (a!77 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                             (not (= (ref.evs.cmp |T0:lclock|) nop))))
                    (a!2 (or (not (= (ref.evs.req |T1:lclock|) nop))
                             (not (= (ref.evs.cmp |T1:lclock|) nop)))))
              (let ((a!3 (and a!1
                              a!2
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|)))))
                (=> a!3
                    (or (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.mem_loc |T0:lclock|) pio_memc)))))))
      (a!78 (forall ((|T:lclock| lclock) (|T0:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T:lclock|) nop))
                             (not (= (ref.evs.cmp |T0:lclock|) nop)))))
                (=> (and a!1 (not (ref.dev |T:lclock|)))
                    (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!79 (forall ((|T:lclock| lclock))
              (let ((a!1 (or (not (= (ref.evs.req |T:lclock|) nop))
                             (not (= (ref.evs.cmp |T:lclock|) nop)))))
                (=> (and a!1 (ref.dev |T:lclock|))
                    (or (= (ref.evs.op_ack |T:lclock|) nGnRE)
                        (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                        (= (ref.evs.op_ack |T:lclock|) _GRE)
                        (= (ref.evs.op_ack |T:lclock|) nGRE))))))
      (a!80 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                              (or (= (ref.evs.req |T1:lclock|) read)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (not (ref.evs.serialized |T0:lclock|))
                              (not (ref.evs.serialized |T1:lclock|))
                              (= (ref.evs.p |T0:lclock|)
                                 (ref.evs.p |T1:lclock|))
                              (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                              (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                              (= (ref.evs.m |T0:lclock|)
                                 (ref.evs.m |T1:lclock|))
                              (= (ref.evs.a |T0:lclock|)
                                 (ref.evs.a |T1:lclock|))
                              (ref.both_normal |T0:lclock| |T1:lclock|)
                              (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                (not a!1))))
      (a!81 (forall ((|T:lclock| lclock))
              (or (= (ref.evs.req |T:lclock|) nop)
                  (= (ref.evs.cmp |T:lclock|) nop)
                  (= (ref.evs.req |T:lclock|) write)
                  (= (ref.evs.cmp |T:lclock|) wr_cmp)
                  (= (ref.evs.req |T:lclock|) read)
                  (= (ref.evs.cmp |T:lclock|) rrsp))))
      (a!82 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!83 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (=> (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                  (not (= |T:lclock| |0:lclock|)))))
      (a!84 (forall ((|T:lclock| lclock))
              (=> (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                  (ref.dev |T:lclock|))))
      (a!85 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (isd.wr |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)
                             (isd.rd |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE)
                             (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                                 (= (ref.evs.op_ack |T:lclock|) nGnRE)))))
                (=> (and a!1 (ref.dev |T:lclock|)) a!2))))
      (a!86 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (or (isd.wr |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|)
                             (isd.rd |P:proc|
                                     |M:mem_type|
                                     |A:addr_type|
                                     |T:lclock|))))
                (=> (and a!1 (not (ref.dev |T:lclock|)))
                    (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!87 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (ref.pnd_or_ser_wr
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (isd.rd |P:proc|
                                |M0:mem_type|
                                |A0:addr_type|
                                |T0:lclock|)
                        (ref.same_attr |T0:lclock| |T1:lclock|)
                        (= |M0:mem_type| |M1:mem_type|)
                        (= |A0:addr_type| |A1:addr_type|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!88 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc|
                                |M0:mem_type|
                                |A0:addr_type|
                                |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (ref.dev |T0:lclock|)
                        (ref.dev |T1:lclock|)
                        (ref.both_nGnR |T0:lclock| |T1:lclock|)))))
      (a!89 (forall ((|A0:addr_type| addr_type)
                     (|A1:addr_type| addr_type)
                     (|M0:mem_type| mem_type)
                     (|M1:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (ref.pnd_or_ser_rd
                          |P:proc|
                          |M1:mem_type|
                          |A1:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc|
                                |M0:mem_type|
                                |A0:addr_type|
                                |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (ref.dev |T0:lclock|)
                        (ref.dev |T1:lclock|)
                        (ref.both_nGR |T0:lclock| |T1:lclock|)
                        (ref.same_addr |T0:lclock| |T1:lclock|)))))
      (a!90 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!91 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (ref.pnd_or_ser_rd
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!92 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!93 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T0:lclock| lclock)
                     (|T1:lclock| lclock))
              (not (and (ref.pnd_or_ser_wr
                          |P:proc|
                          |M:mem_type|
                          |A:addr_type|
                          |T1:lclock|)
                        (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T0:lclock|)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|)
                        (not (ref.dev |T0:lclock|))
                        (not (ref.dev |T1:lclock|))))))
      (a!94 (forall ((|T:lclock| lclock))
              (=> (or (= |T:lclock| |0:lclock|)
                      (|<:lclock:lclock| ref.lt |T:lclock|))
                  (and (= (ref.evs.req |T:lclock|) nop)
                       (= (ref.evs.cmp |T:lclock|) nop)
                       (ref.evs.serialized |T:lclock|)))))
      (a!95 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (not (= (__ref.evs.l_cmp |T:lclock|) init_l))
                              (ref.evs.serialized |T:lclock|))))
              (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) write)
                                  (not (ref.evs.serialized |T:lclock|)))
                             a!1)))
                (= (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                   (and a!2
                        (= (ref.evs.p |T:lclock|) |P:proc|)
                        (= (ref.evs.m |T:lclock|) |M:mem_type|)
                        (= (ref.evs.a |T:lclock|) |A:addr_type|)))))))
      (a!96 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (not (isd.rsp |P:proc|
                                    |M:mem_type|
                                    |A:addr_type|
                                    |T:lclock|)))
                 (and (= (ref.evs.req |T:lclock|) read)
                      (not (ref.evs.serialized |T:lclock|))
                      (= (ref.evs.p |T:lclock|) |P:proc|)
                      (= (ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!97 (forall ((|A:addr_type| addr_type)
                     (|M:mem_type| mem_type)
                     (|P:proc| proc)
                     (|T:lclock| lclock))
              (= (and (isd.rd |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                      (isd.rsp |P:proc| |M:mem_type| |A:addr_type| |T:lclock|))
                 (and (= (ref.evs.cmp |T:lclock|) rrsp)
                      (not (ref.evs.serialized |T:lclock|))
                      (= (ref.evs.p |T:lclock|) |P:proc|)
                      (= (ref.evs.m |T:lclock|) |M:mem_type|)
                      (= (ref.evs.a |T:lclock|) |A:addr_type|)))))
      (a!98 (forall ((|T:lclock| lclock))
              (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                       (not (ref.evs.serialized |T:lclock|)))
                  (not (= (__ref.evs.l_cmp |T:lclock|) dramc_l)))))
      (a!99 (forall ((|T:lclock| lclock))
              (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                  (= (ref.evs.cmp |T:lclock|) rrsp))
                              (ref.dev |T:lclock|)))
                    (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T:lclock|) nGnRE)
                             (= (ref.evs.op_ack |T:lclock|) nGRE)
                             (= (ref.evs.op_ack |T:lclock|) _GRE))))
                (=> a!1 a!2))))
      (a!100 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                                   (= (ref.evs.cmp |T:lclock|) rrsp))
                               (not (ref.dev |T:lclock|)))))
                 (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!101 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.cmp |T:lclock|) wr_cmp))
                               (ref.dev |T:lclock|)))
                     (a!2 (or (= (ref.evs.op_ack |T:lclock|) nGnRnE)
                              (= (ref.evs.op_ack |T:lclock|) nGnRE)
                              (= (ref.evs.op_ack |T:lclock|) nGRE)
                              (= (ref.evs.op_ack |T:lclock|) _GRE))))
                 (=> a!1 a!2))))
      (a!102 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.cmp |T:lclock|) wr_cmp))
                               (not (ref.dev |T:lclock|)))))
                 (=> a!1 (= (ref.evs.op_ack |T:lclock|) normal)))))
      (a!103 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.cmp |T0:lclock|) wr_cmp))
                               (or (= (ref.evs.req |T1:lclock|) write)
                                   (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (ref.evs.serialized |T1:lclock|)
                                    (not (ref.evs.serialized |T0:lclock|))))))
                 (=> a!1 a!2))))
      (a!104 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write))
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read))))
                     (a!3 (and (= (__ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!4 (or (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (__ref.evs.l_req |T1:lclock|) memc_l)
                              (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!2 (and a!1
                               (not (ref.evs.serialized |T0:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!5 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!3
                              (and (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                                   a!4))))
                 (=> a!2 a!5)))))
      (a!105 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (or (= (ref.evs.req |T1:lclock|) write)
                                   (= (ref.evs.cmp |T1:lclock|) wr_cmp))
                               (not (ref.evs.serialized |T0:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                 (not a!1))))
      (a!106 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T0:lclock|) write)
                               (or (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.cmp |T1:lclock|) rrsp))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|))))
                 (not a!1))))
      (a!107 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write))
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read))))
                     (a!3 (and (= (__ref.evs.l_req |T0:lclock|) if_l)
                               (or (= (__ref.evs.l_req |T1:lclock|) if_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
                     (a!4 (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                              (= (__ref.evs.l_req |T1:lclock|) if_l)
                              (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))))
               (let ((a!2 (and a!1
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!5 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_pio_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_pio_l))
                              a!3
                              (and (= (__ref.evs.l_req |T0:lclock|) memc_l) a!4))))
                 (=> a!2 a!5)))))
      (a!108 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) write)
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (ref.evs.req |T1:lclock|) write)
                        (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!109 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) read)
                        (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (ref.evs.req |T1:lclock|) read)
                        (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!110 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                               (not (ref.evs.serialized |T0:lclock|))
                               (= (ref.evs.req |T1:lclock|) read)
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (and (= (ref.evs.req |T1:lclock|) read)
                               (= (__ref.evs.l_req |T1:lclock|) cf_mem_l)
                               (= (ref.evs.req |T0:lclock|) read)
                               (or (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l))))
                     (a!3 (and (= (ref.evs.req |T1:lclock|) read)
                               (= (__ref.evs.l_req |T1:lclock|) memc_l)
                               (= (ref.evs.req |T0:lclock|) read)
                               (or (= (__ref.evs.l_req |T0:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l)))))
               (let ((a!4 (or a!2
                              a!3
                              (and (= (ref.evs.req |T1:lclock|) read)
                                   (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                                   (= (ref.evs.req |T0:lclock|) read)
                                   (= (__ref.evs.l_req |T0:lclock|) dramc_l)))))
                 (=> a!1 a!4)))))
      (a!111 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T0:lclock|) write)
                               (not (ref.evs.serialized |T0:lclock|))
                               (= (ref.evs.req |T1:lclock|) write)
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (and (= (__ref.evs.l_req |T0:lclock|) memc_l)
                               (or (= (__ref.evs.l_req |T1:lclock|) memc_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
                     (a!3 (or (= (__ref.evs.l_req |T1:lclock|) dramc_l)
                              (= (__ref.evs.l_req |T1:lclock|) memc_l)
                              (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (let ((a!4 (or (and (= (__ref.evs.l_req |T0:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_req |T1:lclock|) cf_mem_l))
                              a!2
                              (and (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                                   a!3))))
                 (=> a!1 a!4)))))
      (a!112 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                               (not (ref.evs.serialized |T0:lclock|))
                               (= (ref.evs.cmp |T1:lclock|) rrsp)
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                               (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (and (= (__ref.evs.l_req |T0:lclock|) dramc_l)
                               (or (= (__ref.evs.l_cmp |T1:lclock|) dramc_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) memc_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) cf_mem_l)
                                   (= (__ref.evs.l_cmp |T1:lclock|) arm_l)))))
                 (=> a!1 a!2))))
      (a!113 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) read)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!114 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) write)
                         (= (ref.evs.cmp |T0:lclock|) nop)
                         (= (ref.evs.req |T1:lclock|) nop)
                         (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))
      (a!115 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (ref.pio |T0:lclock|)
                               (or (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.cmp |T1:lclock|) rrsp))
                               (ref.pio |T1:lclock|)
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (ref.evs.serialized |T0:lclock|))
                                    (ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!116 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (or (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.cmp |T1:lclock|) rrsp))
                               (= (ref.evs.m |T0:lclock|)
                                  (ref.evs.m |T1:lclock|))
                               (= (ref.evs.a |T0:lclock|)
                                  (ref.evs.a |T1:lclock|))
                               (= (ref.evs.p |T0:lclock|)
                                  (ref.evs.p |T1:lclock|))
                               (ref.same_attr |T0:lclock| |T1:lclock|)
                               (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
                     (a!2 (not (and (not (ref.evs.serialized |T0:lclock|))
                                    (ref.evs.serialized |T1:lclock|)))))
                 (=> a!1 a!2))))
      (a!117 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying1.now |M:mem_type|))))
      (a!118 (forall ((|M:mem_type| mem_type))
               (not (rfn.abs.trying2.now |M:mem_type|))))
      (a!119 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock|
                          (rfn.abs.lastq |M:mem_type|)
                          |X:tar_clock|)
                        (rfn.abs.begun |M:mem_type| |X:tar_clock|))
                   false)))
      (a!120 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (rfn.abs.begun |M:mem_type| |X:tar_clock|)
                   (rfn.abs.begun |M:mem_type| (rfn.abs.lastq |M:mem_type|)))))
      (a!121 (forall ((|M:mem_type| mem_type)
                      (|X:tar_clock| tar_clock)
                      (|Y:tar_clock| tar_clock))
               (=> (and (rfn.abs.begun |M:mem_type| |X:tar_clock|)
                        (rfn.abs.done |M:mem_type| |X:tar_clock|)
                        (|<:tar_clock:tar_clock| |Y:tar_clock| |X:tar_clock|)
                        (rfn.abs.begun |M:mem_type| |Y:tar_clock|))
                   (rfn.abs.done |M:mem_type| |Y:tar_clock|))))
      (a!122 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (rfn.abs.done |M:mem_type| |X:tar_clock|)
                   (rfn.abs.begun |M:mem_type| |X:tar_clock|))))
      (a!123 (forall ((|X:tar_clock| tar_clock))
               (not (|<:tar_clock:tar_clock| |X:tar_clock| |0:tar_clock|))))
      (a!124 (forall ((|M:mem_type| mem_type)
                      (|T:lclock| lclock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (and (rfn.abs.begun |M:mem_type| |Y:tar_clock|)
                               (=> (rfn.abs.done |M:mem_type| |Y:tar_clock|)
                                   (__rfn.evcomplete |T:lclock|))
                               (= (rfn.abs.queue |M:mem_type| |Y:tar_clock|)
                                  (= (ref.evs.req |T:lclock|) read)))))
                 (=> (and (__rfn.evqual |M:mem_type| |T:lclock|)
                          (= |Y:tar_clock| (ref.evs.lt_arr |T:lclock|)))
                     a!1))))
      (a!125 (forall ((|M:mem_type| mem_type) (|X:tar_clock| tar_clock))
               (=> (|<:tar_clock:tar_clock|
                     (ref.lt_tar |M:mem_type|)
                     |X:tar_clock|)
                   (not (rfn.abs.begun |M:mem_type| |X:tar_clock|)))))
      (a!126 (forall ((|M:mem_type| mem_type))
               (not (dramc.rd_fair |M:mem_type|))))
      (a!127 (forall ((|M:mem_type| mem_type))
               (not (dramc.wr_fair |M:mem_type|))))
      (a!128 (=> __l2s_g_0 (not (and (__cf_live.issued_memc _T) __l2s_g_1))))
      (a!129 (=> __l2s_g_1 (not (= (__ref.evs.l_req _T) memc_l))))
      (a!130 (not (and (and (__cf_live.issued_memc _T) __l2s_g_1) __l2s_w_0)))
      (a!131 (or (not __ts0_e)
                 (not __ts0_c)
                 (or (not __ts0_a) (= (ref.evs.req |__loc:tt|) read))))
      (a!132 (or (not __ts0_e)
                 (or (not __ts0_c)
                     (not __ts0_a)
                     (= (__ref.evs.l_req |__loc:tt|) cf_mem_l))))
      (a!133 (or (not __ts0_e)
                 __ts0_c
                 (or (not __ts0_a) (= (ref.evs.req |__loc:tt|) read))))
      (a!134 (or (not __ts0_e)
                 __ts0_c
                 (not __ts0_a)
                 (not (= (ref.evs.mem_loc |__loc:tt|) mem_memc))))
      (a!135 (or (not __ts0_e)
                 (or __ts0_c
                     (not __ts0_a)
                     (= (__ref.evs.l_req |__loc:tt|) cf_pio_l))))
      (a!136 (forall ((|V0:lclock| lclock)
                      (|V1:proc| proc)
                      (|V2:mem_type| mem_type)
                      (|V3:addr_type| addr_type))
               (let ((a!1 (and (isd.rd |V1:proc|
                                       |V2:mem_type|
                                       |V3:addr_type|
                                       |V0:lclock|)
                               (= (ref.evs.req |V0:lclock|) read)
                               (not (= (ref.evs.mem_loc |V0:lclock|) mem_memc))
                               (= (__ref.evs.l_req |V0:lclock|) cf_pio_l)))
                     (a!2 (and (or (= |V0:lclock| |__loc:tt|)
                                   (|<:lclock:lclock| |V0:lclock| |__loc:tt|))
                               (not (= |V0:lclock| |__loc:tt|)))))
                 (or (not __ts0_e) __ts0_c (not __ts0_a) (not (and a!1 a!2))))))
      (a!137 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 (not __ts0_c)
                 (or (not __ts0_a) (= (ref.evs.req |__loc:tt|) write))))
      (a!138 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 (or (not __ts0_c)
                     (not __ts0_a)
                     (= (__ref.evs.l_req |__loc:tt|) cf_mem_l))))
      (a!139 (forall ((|V0:lclock| lclock)
                      (|V1:proc| proc)
                      (|V2:mem_type| mem_type)
                      (|V3:addr_type| addr_type))
               (let ((a!1 (and (isd.wr |V1:proc|
                                       |V2:mem_type|
                                       |V3:addr_type|
                                       |V0:lclock|)
                               (= (ref.evs.req |V0:lclock|) write)
                               (= (__ref.evs.l_req |V0:lclock|) cf_mem_l)))
                     (a!2 (and (or (= |V0:lclock| |__loc:tt|)
                                   (|<:lclock:lclock| |V0:lclock| |__loc:tt|))
                               (not (= |V0:lclock| |__loc:tt|)))))
                 (or __ts0_e
                     (not __ts0__ts0_d_a)
                     (not __ts0_c)
                     (not __ts0_a)
                     (not (and a!1 a!2))))))
      (a!140 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 __ts0_c
                 (or (not __ts0_a) (= (ref.evs.req |__loc:tt|) write))))
      (a!141 (or __ts0_e
                 (not __ts0__ts0_d_a)
                 (or __ts0_c
                     (not __ts0_a)
                     (= (__ref.evs.l_req |__loc:tt|) cf_pio_l))))
      (a!142 (forall ((|V0:lclock| lclock)
                      (|V1:proc| proc)
                      (|V2:mem_type| mem_type)
                      (|V3:addr_type| addr_type))
               (let ((a!1 (and (isd.wr |V1:proc|
                                       |V2:mem_type|
                                       |V3:addr_type|
                                       |V0:lclock|)
                               (= (ref.evs.req |V0:lclock|) write)
                               (= (__ref.evs.l_req |V0:lclock|) cf_pio_l)))
                     (a!2 (and (or (= |V0:lclock| |__loc:tt|)
                                   (|<:lclock:lclock| |V0:lclock| |__loc:tt|))
                               (not (= |V0:lclock| |__loc:tt|)))))
                 (or __ts0_e
                     (not __ts0__ts0_d_a)
                     __ts0_c
                     (not __ts0_a)
                     (not (and a!1 a!2))))))
      (a!143 (or __ts0_e
                 __ts0__ts0_d_a
                 (not __ts0_c)
                 (not __ts0_a)
                 (and (isd.rd |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt|)
                      (= (ref.evs.cmp |__loc:tt|) rrsp))
                 (and (isd.wr |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt|)
                      (= (ref.evs.cmp |__loc:tt|) wr_cmp))))
      (a!144 (and (not _old_l2s_g_0)
                  (not (and (__cf_live.issued_memc _T) l2s_g_1))))
      (a!145 (and (not _old_l2s_g_1) (not (= (__ref.evs.l_req _T) memc_l))))
      (a!146 (=> l2s_g_0 (not (and (cf_live.issued_memc _T) l2s_g_1))))
      (a!147 (=> l2s_g_1 (not (= (ref.evs.l_req _T) memc_l))))
      (a!148 (forall ((|V0:lclock| lclock))
               (or (not __ts0_b_a)
                   (= (cmpl_live.cf_cpl |V0:lclock|)
                      (__cmpl_live.cf_cpl |V0:lclock|)))))
      (a!149 (forall ((|V0:lclock| lclock))
               (or (not __ts0_b_a)
                   (= (cmpl_live.arm_cpl |V0:lclock|)
                      (__cmpl_live.arm_cpl |V0:lclock|)))))
      (a!150 (forall ((|V0:lclock| lclock))
               (or (not __ts0_b_a)
                   (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))))
      (a!151 (forall ((|V0:lclock| lclock))
               (or (not __ts0_b_a)
                   (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))))
      (a!152 (forall ((|V0:lclock| lclock))
               (or __ts0_b_a
                   __ts0_a_a
                   (= (cmpl_live.cf_cpl |V0:lclock|)
                      (__cmpl_live.cf_cpl |V0:lclock|)))))
      (a!153 (forall ((|V0:lclock| lclock))
               (or __ts0_b_a
                   __ts0_a_a
                   (= (cmpl_live.arm_cpl |V0:lclock|)
                      (__cmpl_live.arm_cpl |V0:lclock|)))))
      (a!154 (forall ((|V0:lclock| lclock))
               (or __ts0_b_a
                   __ts0_a_a
                   (= (cf_pio_live.issued_pio_cpl_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_memc |V0:lclock|)))))
      (a!155 (forall ((|V0:lclock| lclock))
               (or __ts0_b_a
                   __ts0_a_a
                   (= (cf_pio_live.issued_pio_cpl_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_cpl_if |V0:lclock|)))))
      (a!156 (forall ((|V0:lclock| lclock)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type))
               (or __ts0_b_a
                   (= (dramc_nb2.evqual_rd
                        |V0:lclock|
                        |V1:mem_type|
                        |V2:addr_type|)
                      (__dramc_nb2.evqual_rd
                        |V0:lclock|
                        |V1:mem_type|
                        |V2:addr_type|)))))
      (a!157 (forall ((|V0:lclock| lclock)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type))
               (or __ts0_b_a
                   (= (dramc_nb2.evqual_wr
                        |V0:lclock|
                        |V1:mem_type|
                        |V2:addr_type|)
                      (__dramc_nb2.evqual_wr
                        |V0:lclock|
                        |V1:mem_type|
                        |V2:addr_type|)))))
      (a!158 (forall ((|V0:lclock| lclock))
               (or __ts0_b_a
                   (= (cf_pio_live.issued_pio |V0:lclock|)
                      (__cf_pio_live.issued_pio |V0:lclock|)))))
      (a!159 (forall ((|V0:lclock| lclock))
               (or __ts0_b_a
                   (= (cf_pio_live.issued_pio_if |V0:lclock|)
                      (__cf_pio_live.issued_pio_if |V0:lclock|)))))
      (a!160 (forall ((|V0:lclock| lclock))
               (or __ts0_b_a
                   (= (cf_pio_live.issued_pio_memc |V0:lclock|)
                      (__cf_pio_live.issued_pio_memc |V0:lclock|)))))
      (a!161 (forall ((|V0:lclock| lclock)
                      (|V1:mem_type| mem_type)
                      (|V2:addr_type| addr_type))
               (or __ts0_b_a
                   (= (e2e.issued |V0:lclock| |V1:mem_type| |V2:addr_type|)
                      (__e2e.issued |V0:lclock| |V1:mem_type| |V2:addr_type|)))))
      (a!162 (forall ((|V0:proc| proc) (|V1:lclock| lclock))
               (or __ts0_b_a
                   (= (e2e.issued_to_cf |V0:proc| |V1:lclock|)
                      (__e2e.issued_to_cf |V0:proc| |V1:lclock|)))))
      (a!163 (forall ((|Y:lclock| lclock))
               (or (not __ts0_d)
                   (not __ts0_c_a)
                   (not __ts0__ts0__ts0_a_a_a)
                   (=> (|<:lclock:lclock|
                         |__ts0__ts0__ts0__new_fml:x_a_a|
                         |Y:lclock|)
                       (or (= |__fml:y| |Y:lclock|)
                           (|<:lclock:lclock| |__fml:y| |Y:lclock|))))))
      (a!164 (forall ((|Y:tar_cf_clock| tar_cf_clock))
               (or (not __ts0_d)
                   (not __ts0__ts0_a)
                   (not __ts0_c_a_a)
                   (not __ts0__ts0__ts0__ts0_a_a)
                   (=> (|<:tar_cf_clock:tar_cf_clock|
                         |__ts0__ts0__ts0__ts0__new_fml:x_a|
                         |Y:tar_cf_clock|)
                       (or (= |__fml:y_a| |Y:tar_cf_clock|)
                           (|<:tar_cf_clock:tar_cf_clock|
                             |__fml:y_a|
                             |Y:tar_cf_clock|))))))
      (a!165 (forall ((|T:lclock| lclock) (|Tarr:tar_cf_clock| tar_cf_clock))
               (let ((a!1 (exists ((|\|T:lclock\|!1| lclock))
                            (and (= (ref.evs.req |\|T:lclock\|!1|) read)
                                 (= (ref.evs.l_req |\|T:lclock\|!1|) cf_mem_l)
                                 (= (ref.evs.lt_arr_cf |\|T:lclock\|!1|)
                                    cfabric.t_rd_arr_min)))))
                 (=> (and (= cfabric.t_rd_arr_min |Tarr:tar_cf_clock|)
                          (= (ref.evs.req |T:lclock|) read)
                          (= (ref.evs.l_req |T:lclock|) cf_mem_l))
                     a!1))))
      (a!166 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.req |T:lclock|) read)
                        (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                        (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                        (= |T:lclock| ref.lt))
                   (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf))))
      (a!167 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1
                     (not (= (ref.evs.lt_arr_cf |T:lclock|) |0:tar_cf_clock|))))))
      (a!168 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1
                     (or (= (ref.evs.lt_arr_cf |T:lclock|) ref.lt_tar_cf)
                         (|<:tar_cf_clock:tar_cf_clock|
                           (ref.evs.lt_arr_cf |T:lclock|)
                           ref.lt_tar_cf))))))
      (a!169 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (or (= (ref.evs.l_req |T:lclock|) memc_l)
                                   (= (ref.evs.l_req |T:lclock|) dramc_l)))))
               (let ((a!2 (and (or a!1 (= (ref.evs.cmp |T:lclock|) rrsp))
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!2
                     (|<:tar_cf_clock:tar_cf_clock|
                       (ref.evs.lt_arr_cf |T:lclock|)
                       cfabric.t_rd_arr_min))))))
      (a!170 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) read)
                        (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                        (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                        (= (ref.evs.req |T1:lclock|) read)
                        (= (ref.evs.l_req |T1:lclock|) cf_mem_l)
                        (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                        (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                   (|<:tar_cf_clock:tar_cf_clock|
                     (ref.evs.lt_arr_cf |T0:lclock|)
                     (ref.evs.lt_arr_cf |T1:lclock|)))))
      (a!171 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1
                     (or (= cfabric.t_rd_arr_min (ref.evs.lt_arr_cf |T:lclock|))
                         (|<:tar_cf_clock:tar_cf_clock|
                           cfabric.t_rd_arr_min
                           (ref.evs.lt_arr_cf |T:lclock|)))))))
      (a!172 (forall ((|T:lclock| lclock))
               (not (and (= (ref.evs.req |T:lclock|) read)
                         (= (ref.evs.l_req |T:lclock|) cf_mem_l)))))
      (a!173 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T1:lclock|) read)
                               (not (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
               (let ((a!2 (or (= (ref.evs.req |T1:lclock|) write)
                              a!1
                              (= (ref.evs.req |T1:lclock|) nop))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          a!2)
                     (not (= (ref.evs.lt_arr_cf |T1:lclock|)
                             cfabric.t_rd_arr_min)))))))
      (a!174 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) read)
                               (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                               (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
                 (=> a!1 (not (|<:lclock:lclock| |T:lclock| cfabric.t_rd_min))))))
      (a!175 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.req |T:lclock|) write)
                              (= (ref.evs.req |T:lclock|) read)
                              (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (= (ref.evs.cmp |T:lclock|) rrsp))))
                 (=> a!1 (not (= cfabric.t_rd_min |0:lclock|))))))
      (a!176 (forall ((|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.req |T:lclock|) write)
                               (or (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                                   (= (ref.evs.l_req |T:lclock|) cf_pio_l)))))
                 (=> a!1 (not (= |T:lclock| cfabric.t_rd_min))))))
      (a!177 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (not (and (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                                    (= (ref.evs.l_req |T1:lclock|) cf_mem_l)))))
               (let ((a!2 (or (= (ref.evs.req |T1:lclock|) write)
                              (and (= (ref.evs.req |T1:lclock|) read) a!1)
                              (= (ref.evs.req |T1:lclock|) nop))))
                 (=> (and (= (ref.evs.req |T0:lclock|) read)
                          (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          a!2)
                     (not (= |T1:lclock| cfabric.t_rd_min)))))))
      (a!178 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.req |T:lclock|) read))
                               (= (ref.evs.m |T:lclock|) |M:mem_type|)
                               (= (ref.evs.a |T:lclock|) |A:addr_type|)
                               (= (ref.evs.l_req |T:lclock|) dramc_l))))
                 (=> a!1 (not (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|))))))
      (a!179 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.req |T:lclock|) read))
                               (= (ref.evs.m |T:lclock|) |M:mem_type|)
                               (= (ref.evs.a |T:lclock|) |A:addr_type|)
                               (not (= (ref.evs.l_req |T:lclock|) dramc_l)))))
                 (=> a!1 (= (ref.evs.lt_arr |T:lclock|) |0:tar_clock|)))))
      (a!180 (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                                   (= (ref.evs.req |T:lclock|) read))
                               (= (ref.evs.m |T:lclock|) |M:mem_type|)
                               (= (ref.evs.l_req |T:lclock|) dramc_l))))
                 (=> a!1 (not (= (dramc.t_min |M:mem_type|) |0:tar_clock|))))))
      (a!181 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) read)
                   (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!182 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) write)
                   (= (ref.evs.l_cmp |T:lclock|) init_l))))
      (a!183 (forall ((|T:lclock| lclock))
               (=> (= (ref.evs.req |T:lclock|) nop)
                   (= (ref.evs.l_req |T:lclock|) init_l))))
      (a!184 (forall ((|T:lclock| lclock))
               (let ((a!1 (forall ((|A:addr_type| addr_type)
                                   (|M:mem_type| mem_type)
                                   (|P:proc| proc))
                            (not (or (isd.wr |P:proc|
                                             |M:mem_type|
                                             |A:addr_type|
                                             |T:lclock|)
                                     (isd.rd |P:proc|
                                             |M:mem_type|
                                             |A:addr_type|
                                             |T:lclock|))))))
                 (=> a!1
                     (and (= (ref.evs.l_req |T:lclock|) init_l)
                          (= (ref.evs.l_cmp |T:lclock|) init_l))))))
      (a!185 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))
                              (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.l_req |T0:lclock|) dramc_l))
                              (= (ref.evs.cmp |T0:lclock|) rrsp)))
                     (a!2 (or (and (= (ref.evs.req |T1:lclock|) write)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l))
                              (and (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                   (= (ref.evs.l_cmp |T1:lclock|) dramc_l))
                              (and (= (ref.evs.req |T1:lclock|) read)
                                   (= (ref.evs.l_req |T1:lclock|) dramc_l))
                              (and (= (ref.evs.cmp |T1:lclock|) rrsp)
                                   (= (ref.evs.l_cmp |T1:lclock|) dramc_l))))
                     (a!3 (=> (or (= (ref.evs.cmp |T0:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T0:lclock|) rrsp))
                              (not (= (ref.evs.lt_tar |T0:lclock|)
                                      (ref.evs.lt_arr |T1:lclock|)))))
                     (a!4 (=> (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                  (= (ref.evs.cmp |T1:lclock|) rrsp))
                              (not (= (ref.evs.lt_arr |T0:lclock|)
                                      (ref.evs.lt_tar |T1:lclock|))))))
               (let ((a!5 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                       (ref.evs.lt_arr |T1:lclock|)))
                               a!3
                               a!4)))
                 (=> (and a!1
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          a!2
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (not (= |T0:lclock| |T1:lclock|)))
                     a!5)))))
      (a!186 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (not (and (= (ref.evs.req |T0:lclock|) write)
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.l_req |T0:lclock|) dramc_l)
                         (|<:tar_clock:tar_clock|
                           (ref.evs.lt_arr |T0:lclock|)
                           (ref.evs.lt_arr |T1:lclock|))))))
      (a!187 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.req |T1:lclock|) write))
                              (and (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.req |T1:lclock|) read)))))
                 (=> (and a!1
                          (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                          (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                          (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                          (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                          (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                          (= (ref.evs.l_req |T0:lclock|) dramc_l)
                          (= (ref.evs.l_req |T1:lclock|) dramc_l)
                          (ref.same_attr |T0:lclock| |T1:lclock|)
                          (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                     (|<:tar_clock:tar_clock|
                       (ref.evs.lt_arr |T0:lclock|)
                       (ref.evs.lt_arr |T1:lclock|))))))
      (a!188 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                              (and (= (ref.evs.cmp |T:lclock|) rrsp)
                                   (not (ref.evs.serialized |T:lclock|)))))
                     (a!2 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                               (or (= (ref.evs.l_cmp |T:lclock|) dramc_l)
                                   (= (ref.evs.l_cmp |T:lclock|) memc_l)
                                   (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                   (= (ref.evs.l_cmp |T:lclock|) arm_l))))
                     (a!3 (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                               (or (= (ref.evs.l_cmp |T:lclock|) memc_l)
                                   (= (ref.evs.l_cmp |T:lclock|) if_l)
                                   (= (ref.evs.l_cmp |T:lclock|) cf_cmp_l)
                                   (= (ref.evs.l_cmp |T:lclock|) arm_l))))
                     (a!4 (and (ref.evs.serialized |T:lclock|)
                               (or (= (ref.evs.cmp |T:lclock|) rrsp)
                                   (= (ref.evs.cmp |T:lclock|) wr_cmp))
                               (= (ref.evs.l_cmp |T:lclock|) init_l))))
                 (=> (or (= (ref.evs.cmp |T:lclock|) wr_cmp)
                         (= (ref.evs.cmp |T:lclock|) rrsp))
                     (or (and a!1 (or a!2 a!3)) a!4)))))
      (a!189 (forall ((|T:lclock| lclock))
               (let ((a!1 (or (= (ref.evs.l_req |T:lclock|) dramc_l)
                              (= (ref.evs.l_req |T:lclock|) memc_l)
                              (= (ref.evs.l_req |T:lclock|) cf_mem_l)))
                     (a!2 (or (= (ref.evs.l_req |T:lclock|) memc_l)
                              (= (ref.evs.l_req |T:lclock|) if_l)
                              (= (ref.evs.l_req |T:lclock|) cf_pio_l))))
               (let ((a!3 (or (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                                   a!1)
                              (and (= (ref.evs.mem_loc |T:lclock|) pio_memc)
                                   a!2))))
                 (=> (or (= (ref.evs.req |T:lclock|) write)
                         (= (ref.evs.req |T:lclock|) read))
                     a!3)))))
      (a!190 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) read)
                                   (= (ref.evs.cmp |T0:lclock|) rrsp))
                               (= (ref.evs.cmp |T1:lclock|) rrsp))))
               (let ((a!2 (or (and (= (ref.evs.req |T0:lclock|) write)
                                   (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                                   (= (ref.evs.l_cmp |T1:lclock|) init_l))
                              a!1)))
                 (not (and a!2
                           (not (ref.evs.serialized |T0:lclock|))
                           (ref.evs.serialized |T1:lclock|)
                           (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                           (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                           (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                           (ref.same_attr |T0:lclock| |T1:lclock|)
                           (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))))))
      (a!191 (forall ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|P:proc| proc)
                      (|T:lclock| lclock))
               (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) wr_cmp)
                               (not (= (ref.evs.l_cmp |T:lclock|) init_l))
                               (ref.evs.serialized |T:lclock|))))
               (let ((a!2 (or (and (= (ref.evs.req |T:lclock|) write)
                                   (not (ref.evs.serialized |T:lclock|)))
                              a!1)))
                 (= (isd.wr |P:proc| |M:mem_type| |A:addr_type| |T:lclock|)
                    (and a!2
                         (= (ref.evs.p |T:lclock|) |P:proc|)
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (ref.evs.a |T:lclock|) |A:addr_type|)))))))
      (a!192 (forall ((|T:lclock| lclock))
               (=> (and (= (ref.evs.cmp |T:lclock|) rrsp)
                        (not (ref.evs.serialized |T:lclock|)))
                   (not (= (ref.evs.l_cmp |T:lclock|) dramc_l)))))
      (a!193 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) write)
                        (= (ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (ref.evs.req |T1:lclock|) write)
                        (= (ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!194 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (=> (and (= (ref.evs.req |T0:lclock|) read)
                        (= (ref.evs.l_req |T0:lclock|) dramc_l)
                        (= (ref.evs.req |T1:lclock|) read)
                        (= (ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                        (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|)))
                   (= |T0:lclock| |T1:lclock|))))
      (a!195 (forall ((|M:mem_type| mem_type)
                      (|T:lclock| lclock)
                      (|Y:tar_clock| tar_clock))
               (let ((a!1 (and (rfn.abs.begun |M:mem_type| |Y:tar_clock|)
                               (=> (rfn.abs.done |M:mem_type| |Y:tar_clock|)
                                   (rfn.evcomplete |T:lclock|))
                               (= (rfn.abs.queue |M:mem_type| |Y:tar_clock|)
                                  (= (ref.evs.req |T:lclock|) read)))))
                 (=> (and (rfn.evqual |M:mem_type| |T:lclock|)
                          (= |Y:tar_clock| (ref.evs.lt_arr |T:lclock|)))
                     a!1))))
      (a!196 (forall ((|T:index| index) (|U:index| index) (|V:index| index))
               (=> (and (|<:index:index| |T:index| |U:index|)
                        (|<:index:index| |U:index| |V:index|))
                   (|<:index:index| |T:index| |V:index|))))
      (a!197 (forall ((|T:index| index) (|U:index| index))
               (not (and (|<:index:index| |T:index| |U:index|)
                         (|<:index:index| |U:index| |T:index|)))))
      (a!198 (forall ((|T:lclock| lclock)
                      (|U:lclock| lclock)
                      (|V:lclock| lclock))
               (=> (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                        (|<:lclock:lclock| |U:lclock| |V:lclock|))
                   (|<:lclock:lclock| |T:lclock| |V:lclock|))))
      (a!199 (forall ((|T:lclock| lclock) (|U:lclock| lclock))
               (not (and (|<:lclock:lclock| |T:lclock| |U:lclock|)
                         (|<:lclock:lclock| |U:lclock| |T:lclock|)))))
      (a!200 (forall ((|T:tar_clock| tar_clock)
                      (|U:tar_clock| tar_clock)
                      (|V:tar_clock| tar_clock))
               (=> (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                        (|<:tar_clock:tar_clock| |U:tar_clock| |V:tar_clock|))
                   (|<:tar_clock:tar_clock| |T:tar_clock| |V:tar_clock|))))
      (a!201 (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
               (not (and (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
                         (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))))
      (a!202 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock)
                      (|V:tar_cf_clock| tar_cf_clock))
               (=> (and (|<:tar_cf_clock:tar_cf_clock|
                          |T:tar_cf_clock|
                          |U:tar_cf_clock|)
                        (|<:tar_cf_clock:tar_cf_clock|
                          |U:tar_cf_clock|
                          |V:tar_cf_clock|))
                   (|<:tar_cf_clock:tar_cf_clock|
                     |T:tar_cf_clock|
                     |V:tar_cf_clock|))))
      (a!203 (forall ((|T:tar_cf_clock| tar_cf_clock)
                      (|U:tar_cf_clock| tar_cf_clock))
               (not (and (|<:tar_cf_clock:tar_cf_clock|
                           |T:tar_cf_clock|
                           |U:tar_cf_clock|)
                         (|<:tar_cf_clock:tar_cf_clock|
                           |U:tar_cf_clock|
                           |T:tar_cf_clock|)))))
      (a!204 (ite __ts0_e
                  (ite __ts0_b |__loc:t| |__loc:tt|)
                  (ite __ts0__ts0_d_a
                       (ite __ts0_b |__loc:t| |__loc:tt|)
                       (ite __ts0_c
                            (ite __ts0_b |__loc:t| |__loc:tt|)
                            |__loc:t|))))
      (a!205 (ite __ts0_e
                  (ite __ts0_b |__loc:p| |__loc:pp|)
                  (ite __ts0__ts0_d_a
                       (ite __ts0_b |__loc:p| |__loc:pp|)
                       (ite __ts0_c
                            (ite __ts0_b |__loc:p| |__loc:pp|)
                            |__loc:p|))))
      (a!206 (ite __ts0_e
                  (ite __ts0_b |__loc:m| |__loc:mm|)
                  (ite __ts0__ts0_d_a
                       (ite __ts0_b |__loc:m| |__loc:mm|)
                       (ite __ts0_c
                            (ite __ts0_b |__loc:m| |__loc:mm|)
                            |__loc:m|))))
      (a!207 (ite __ts0_e
                  (ite __ts0_b |__loc:a| |__loc:aa|)
                  (ite __ts0__ts0_d_a
                       (ite __ts0_b |__loc:a| |__loc:aa|)
                       (ite __ts0_c
                            (ite __ts0_b |__loc:a| |__loc:aa|)
                            |__loc:a|))))
      (a!208 (= __ts0_c
                (ite __ts0_e
                     |__fml:sel_memc|
                     (ite __ts0__ts0_d_a |__fml:sel_memc| (= |__fml:ph| cpl_ph)))))
      (a!209 (= |__new_loc:wr|
                (ite __ts0_e
                     |__m_loc:wr|
                     (ite __ts0__ts0_d_a
                          (ite __ts0_b |__m_loc:wr| true)
                          |__m_loc:wr|))))
      (a!210 (ite __ts0_e
                  |__m_loc:cmp|
                  (ite __ts0__ts0_d_a
                       |__m_loc:cmp|
                       (ite __ts0_c
                            (ite __ts0_b |__m_loc:cmp| true)
                            |__m_loc:cmp|))))
      (a!211 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (and (isd.rd |__new_loc:p| |M:mem_type| |A:addr_type| |T:lclock|)
                    (= (ref.evs.req |T:lclock|) read)
                    (or (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                        (= (__ref.evs.l_req |T:lclock|) cf_pio_l))
                    (= (ref.evs.mem_loc |__new_loc:t|)
                       (ref.evs.mem_loc |T:lclock|))
                    (= (ref.evs.mem_loc |__new_loc:t|) mem_memc)
                    (|<:tar_cf_clock:tar_cf_clock|
                      (ref.evs.lt_arr_cf |T:lclock|)
                      (ref.evs.lt_arr_cf |__new_loc:t|)))))
      (a!212 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (and (isd.wr |__new_loc:p| |M:mem_type| |A:addr_type| |T:lclock|)
                    (= (ref.evs.req |T:lclock|) write)
                    (or (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                        (= (__ref.evs.l_req |T:lclock|) cf_pio_l))
                    (= (ref.evs.mem_loc |__new_loc:t|)
                       (ref.evs.mem_loc |T:lclock|))
                    (= (ref.evs.mem_loc |__new_loc:t|) mem_memc)
                    (|<:lclock:lclock| |T:lclock| |__new_loc:t|))))
      (a!213 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (and (isd.rd |__new_loc:p| |M:mem_type| |A:addr_type| |T:lclock|)
                    (= (ref.evs.req |T:lclock|) read)
                    (or (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                        (= (__ref.evs.l_req |T:lclock|) cf_pio_l))
                    (= (ref.evs.mem_loc |__new_loc:t|)
                       (ref.evs.mem_loc |T:lclock|))
                    (= (ref.evs.mem_loc |__new_loc:t|) pio_memc)
                    (|<:lclock:lclock| |T:lclock| |__new_loc:t|))))
      (a!214 (exists ((|A:addr_type| addr_type)
                      (|M:mem_type| mem_type)
                      (|T:lclock| lclock))
               (and (isd.wr |__new_loc:p| |M:mem_type| |A:addr_type| |T:lclock|)
                    (= (ref.evs.req |T:lclock|) write)
                    (or (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                        (= (__ref.evs.l_req |T:lclock|) cf_pio_l))
                    (= (ref.evs.mem_loc |__new_loc:t|)
                       (ref.evs.mem_loc |T:lclock|))
                    (= (ref.evs.mem_loc |__new_loc:t|) pio_memc)
                    (|<:lclock:lclock| |T:lclock| |__new_loc:t|))))
      (a!215 (forall ((|V0:lclock| lclock))
               (let ((a!1 (ite __ts0_a_a
                               (ite (and (= |V0:lclock| |__new_loc:t|))
                                    memc_l
                                    (__ref.evs.l_req |V0:lclock|))
                               (ite (and (= |V0:lclock| |__new_loc:t|))
                                    if_l
                                    (__ref.evs.l_req |V0:lclock|)))))
                 (= (ref.evs.l_req |V0:lclock|)
                    (ite __ts0_b_a a!1 (__ref.evs.l_req |V0:lclock|))))))
      (a!216 (and __l2s_w_0
                  (not (and (cf_live.issued_memc _T) l2s_g_1))
                  (not l2s_g_0)))
      (a!217 (= __ts0_a_a
                (ite __ts0_b_a
                     (= (ref.evs.mem_loc |__new_loc:t|) mem_memc)
                     |__new_loc:cmp|)))
      (a!218 (forall ((|V0:lclock| lclock))
               (let ((a!1 (ite __ts0_a_a
                               (ite (and (= |V0:lclock| |__new_loc:t|))
                                    arm_l
                                    (__ref.evs.l_cmp |V0:lclock|))
                               (__ref.evs.l_cmp |V0:lclock|))))
                 (= (ref.evs.l_cmp |V0:lclock|)
                    (ite __ts0_b_a (__ref.evs.l_cmp |V0:lclock|) a!1)))))
      (a!219 (= cfabric.t_rd_min
                (ite __ts0_d
                     (ite __ts0_c_a
                          (ite __ts0__ts0__ts0_a_a_a
                               __ts0__ts0__ts0__new_cfabric.t_rd_min_a_a
                               __cfabric.t_rd_min)
                          |__loc:tt_a|)
                     __cfabric.t_rd_min)))
      (a!220 (ite __ts0_d
                  (ite __ts0__ts0_a
                       (ite __ts0_c_a_a
                            (ite __ts0__ts0__ts0__ts0_a_a
                                 __ts0__ts0__ts0__ts0__new_cfabric.t_rd_arr_min_a_a
                                 __cfabric.t_rd_arr_min)
                            (ref.evs.lt_arr_cf |__loc:tt_a_a|))
                       __cfabric.t_rd_arr_min)
                  __cfabric.t_rd_arr_min))
      (a!221 (forall ((|V0:lclock| lclock))
               (= (__m_l2s_d |V0:lclock|)
                  (ite (and (= |V0:lclock| ref.lt)) true (__l2s_d |V0:lclock|)))))
      (a!222 (forall ((|V0:lclock| lclock))
               (= (__m_l2s_d_a |V0:lclock|)
                  (ite (and (= |V0:lclock| cfabric.t_rd_min))
                       true
                       (__m_l2s_d |V0:lclock|)))))
      (a!223 (forall ((|V0:lclock| lclock))
               (= (l2s_d |V0:lclock|)
                  (ite (and (= |V0:lclock| _T)) true (__m_l2s_d_a |V0:lclock|)))))
      (a!224 (forall ((|V0:tar_cf_clock| tar_cf_clock))
               (= (__m_l2s_d_b |V0:tar_cf_clock|)
                  (ite (and (= |V0:tar_cf_clock| ref.lt_tar_cf))
                       true
                       (__l2s_d_a |V0:tar_cf_clock|)))))
      (a!225 (forall ((|V0:tar_cf_clock| tar_cf_clock))
               (= (l2s_d |V0:tar_cf_clock|)
                  (ite (and (= |V0:tar_cf_clock| cfabric.t_rd_arr_min))
                       true
                       (__m_l2s_d_b |V0:tar_cf_clock|)))))
      (a!226 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.mem_memc_exception |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.cmp |T0:lclock|) rrsp)
                       (= (ref.evs.cmp |T1:lclock|) rrsp)
                       (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                       (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                       (ref.same_attr |T0:lclock| |T1:lclock|)
                       (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                       (= (ref.evs.mem_loc |T1:lclock|) mem_memc)))))
      (a!227 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.same_attr |T0:lclock| |T1:lclock|)
                  (or (ref.both_nGnR |T0:lclock| |T1:lclock|)
                      (ref.both_nGR |T0:lclock| |T1:lclock|)
                      (ref.both_normal |T0:lclock| |T1:lclock|)))))
      (a!228 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
               (= (ref.both_normal |T0:lclock| |T1:lclock|)
                  (and (= (ref.evs.op_ack |T0:lclock|) normal)
                       (= (ref.evs.op_ack |T1:lclock|) normal)))))
      (a!229 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGRE)
                      (= |OP_ACK:op_ack_type| _GRE)))))
      (a!230 (forall ((|OP_ACK:op_ack_type| op_ack_type))
               (= (ref.nGnR |OP_ACK:op_ack_type|)
                  (or (= |OP_ACK:op_ack_type| nGnRE)
                      (= |OP_ACK:op_ack_type| nGnRnE)))))
      (a!231 (forall ((|T:lclock| lclock))
               (= (ref.dev |T:lclock|)
                  (or (ref.nGR (ref.evs.op_ack |T:lclock|))
                      (ref.nGnR (ref.evs.op_ack |T:lclock|)))))))
(let ((a!15 (=> (and a!13 (not (or a!7)) l2s_saved true (not __l2s_w_2)) a!14)))
  (and (not __cfabric.rd_fair)
       (not __cfabric.wr_fair)
       a!1
       a!2
       a!3
       a!4
       a!5
       a!2
       a!6
       (=> (and a!7 (not false) l2s_saved (not l2s_init_0) (not __l2s_w_1)) a!8)
       (=> l2s_init_1 __l2s_g_2)
       a!9
       a!3
       a!10
       a!11
       a!9
       a!12
       a!15
       (=> l2s_init_2 __l2s_g_3)
       (or a!16 (not a!17) (not true) (not a!18))
       __l2s_g_2
       (=> __l2s_g_4 (or (not l2s_waiting) (not __l2s_w_1)))
       (not l2s_init_3)
       __l2s_g_3
       (=> __l2s_g_5 (or (not l2s_waiting) (not __l2s_w_2)))
       (not l2s_init_4)
       (=> __l2s_g_0 (or (not l2s_waiting) (not __l2s_w_0)))
       (not l2s_init_0)
       (or (not l2s_init_0) __l2s_g_0)
       (=> (and (not l2s_init_0) __l2s_g_0)
           (or (not l2s_waiting) (not __l2s_w_0)))
       a!19
       (or l2s_waiting l2s_frozen l2s_saved)
       (or (not l2s_waiting) (not l2s_frozen))
       (or (not l2s_waiting) (not l2s_saved))
       (or (not l2s_frozen) (not l2s_saved))
       (__l2s_d ref.lt)
       (__l2s_d __cfabric.t_rd_min)
       (__l2s_d _T)
       (__l2s_d_a ref.lt_tar_cf)
       (__l2s_d_a __cfabric.t_rd_arr_min)
       (not (=> (and l2s_init_1 l2s_init_2) l2s_init_0))
       a!20
       a!21
       a!22
       a!23
       a!24
       a!25
       a!26
       a!27
       a!28
       a!29
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!30
       (=> a!31
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 __cfabric.t_rd_arr_min)
               (= __cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!32 (= __cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!33
       a!34
       a!35
       a!36
       (=> a!31
           (or (|<:lclock:lclock| ref.lt __cfabric.t_rd_min)
               (= __cfabric.t_rd_min |0:lclock|)))
       (=> a!32 (= __cfabric.t_rd_min |0:lclock|))
       a!37
       a!38
       a!39
       (= (ref.evs.req |0:lclock|) nop)
       (= (__ref.evs.l_req |0:lclock|) init_l)
       (= (ref.evs.cmp |0:lclock|) nop)
       (= (__ref.evs.l_cmp |0:lclock|) init_l)
       (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!68
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       a!116
       a!117
       a!118
       a!119
       a!120
       a!121
       a!122
       a!123
       a!124
       a!125
       a!126
       a!127
       a!128
       a!129
       (=> __l2s_g_2 (not __l2s_g_4))
       (=> __l2s_g_3 (not __l2s_g_5))
       (=> __l2s_g_4 (not __cfabric.rd_fair))
       (=> __l2s_g_5 (not __cfabric.wr_fair))
       a!130
       (not (and __cfabric.rd_fair __l2s_w_1))
       (not (and __cfabric.wr_fair __l2s_w_2))
       a!20
       a!21
       a!22
       a!23
       a!24
       a!25
       a!26
       a!27
       a!28
       a!29
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!30
       (=> a!31
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 __cfabric.t_rd_arr_min)
               (= __cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!32 (= __cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!33
       a!34
       a!35
       a!36
       (=> a!31
           (or (|<:lclock:lclock| ref.lt __cfabric.t_rd_min)
               (= __cfabric.t_rd_min |0:lclock|)))
       (=> a!32 (= __cfabric.t_rd_min |0:lclock|))
       a!37
       a!38
       a!39
       (= (ref.evs.req |0:lclock|) nop)
       (= (__ref.evs.l_req |0:lclock|) init_l)
       (= (ref.evs.cmp |0:lclock|) nop)
       (= (__ref.evs.l_cmp |0:lclock|) init_l)
       (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       a!70
       a!71
       a!72
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!92
       a!93
       a!94
       a!95
       a!96
       a!97
       a!68
       a!98
       a!99
       a!100
       a!101
       a!102
       a!103
       a!104
       a!105
       a!106
       a!107
       a!108
       a!109
       a!110
       a!111
       a!112
       a!113
       a!114
       a!115
       a!116
       a!117
       a!118
       a!119
       a!120
       a!121
       a!122
       a!123
       a!124
       a!125
       a!126
       a!127
       (=> __m__old_l2s_g_2 __m_l2s_g_2)
       (=> (and (not __m__old_l2s_g_2) (not __m_l2s_g_4)) (not __m_l2s_g_2))
       (=> __m__old_l2s_g_4 __m_l2s_g_4)
       (=> (and (not __m__old_l2s_g_4) (not __cfabric.rd_fair))
           (not __m_l2s_g_4))
       (=> __m_l2s_g_2 (not __m_l2s_g_4))
       (=> __m_l2s_g_4 (not __m_cfabric.rd_fair))
       (=> new__old_l2s_g_2_a l2s_g_2)
       (=> (and (not new__old_l2s_g_2_a) (not l2s_g_4)) (not l2s_g_2))
       (=> new__old_l2s_g_4_a l2s_g_4)
       (=> (and (not new__old_l2s_g_4_a) (not __m_cfabric.rd_fair))
           (not l2s_g_4))
       (=> l2s_g_2 (not l2s_g_4))
       (=> l2s_g_4 (not cfabric.rd_fair))
       (=> __m__old_l2s_g_3 __m_l2s_g_3)
       (=> (and (not __m__old_l2s_g_3) (not __m_l2s_g_5)) (not __m_l2s_g_3))
       (=> __m__old_l2s_g_5 __m_l2s_g_5)
       (=> (and (not __m__old_l2s_g_5) (not __cfabric.wr_fair))
           (not __m_l2s_g_5))
       (=> __m_l2s_g_3 (not __m_l2s_g_5))
       (=> __m_l2s_g_5 (not __m_cfabric.wr_fair))
       (=> new__old_l2s_g_3_a l2s_g_3)
       (=> (and (not new__old_l2s_g_3_a) (not l2s_g_5)) (not l2s_g_3))
       (=> new__old_l2s_g_5_a l2s_g_5)
       (=> (and (not new__old_l2s_g_5_a) (not __m_cfabric.wr_fair))
           (not l2s_g_5))
       (=> l2s_g_3 (not l2s_g_5))
       (=> l2s_g_5 (not cfabric.wr_fair))
       (or (not __ts0_e) (or (not __ts0_c) (or __ts0_a __ts0_b)))
       (or (not __ts0_e)
           (not __ts0_c)
           (or (not __ts0_a)
               (isd.rd |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt|)))
       a!131
       (or (not __ts0_e)
           (not __ts0_c)
           (not __ts0_a)
           (= (ref.evs.mem_loc |__loc:tt|) mem_memc))
       a!132
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.rd |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) read)
                         (= (ref.evs.mem_loc |V0:lclock|) mem_memc)
                         (= (__ref.evs.l_req |V0:lclock|) cf_mem_l))))
         (let ((a!2 (=> a!1
                        (not (|<:tar_cf_clock:tar_cf_clock|
                               (ref.evs.lt_arr_cf |V0:lclock|)
                               (ref.evs.lt_arr_cf |__loc:tt|))))))
           (or (not __ts0_e) (not __ts0_c) (not __ts0_a) a!2))))
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.rd |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) read)
                         (= (ref.evs.mem_loc |V0:lclock|) mem_memc)
                         (= (__ref.evs.l_req |V0:lclock|) cf_mem_l))))
           (or (not __ts0_e) (not __ts0_c) (not __ts0_b) (not a!1))))
       (or (not __ts0_e) (or __ts0_c (or __ts0_a __ts0_b)))
       (or (not __ts0_e)
           __ts0_c
           (or (not __ts0_a)
               (isd.rd |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt|)))
       a!133
       a!134
       a!135
       a!136
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.rd |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) read)
                         (not (= (ref.evs.mem_loc |V0:lclock|) mem_memc))
                         (= (__ref.evs.l_req |V0:lclock|) cf_pio_l))))
           (or (not __ts0_e) __ts0_c (not __ts0_b) (not a!1))))
       (or __ts0_e (not __ts0__ts0_d_a) (or (not __ts0_c) (or __ts0_a __ts0_b)))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           (not __ts0_c)
           (or (not __ts0_a)
               (isd.wr |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt|)))
       a!137
       a!138
       a!139
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.wr |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) write)
                         (= (__ref.evs.l_req |V0:lclock|) cf_mem_l))))
           (or __ts0_e
               (not __ts0__ts0_d_a)
               (not __ts0_c)
               (not __ts0_b)
               (not a!1))))
       (or __ts0_e (not __ts0__ts0_d_a) (or __ts0_c (or __ts0_a __ts0_b)))
       (or __ts0_e
           (not __ts0__ts0_d_a)
           __ts0_c
           (or (not __ts0_a)
               (isd.wr |__loc:pp| |__loc:mm| |__loc:aa| |__loc:tt|)))
       a!140
       a!141
       a!142
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.wr |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) write)
                         (= (__ref.evs.l_req |V0:lclock|) cf_pio_l))))
           (or __ts0_e (not __ts0__ts0_d_a) __ts0_c (not __ts0_b) (not a!1))))
       (or __ts0_e __ts0__ts0_d_a (or (not __ts0_c) (or __ts0_a __ts0_b)))
       a!143
       (or __ts0_e
           __ts0__ts0_d_a
           (not __ts0_c)
           (not __ts0_a)
           (= (__ref.evs.l_cmp |__loc:tt|) cf_cmp_l))
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (or (and (isd.rd |V1:proc|
                                     |V2:mem_type|
                                     |V3:addr_type|
                                     |V0:lclock|)
                             (= (ref.evs.cmp |V0:lclock|) rrsp))
                        (and (isd.wr |V1:proc|
                                     |V2:mem_type|
                                     |V3:addr_type|
                                     |V0:lclock|)
                             (= (ref.evs.cmp |V0:lclock|) wr_cmp))))
               (a!2 (and (or (= |V0:lclock| |__loc:tt|)
                             (|<:lclock:lclock| |V0:lclock| |__loc:tt|))
                         (not (= |V0:lclock| |__loc:tt|)))))
         (let ((a!3 (and (and a!1 (= (__ref.evs.l_cmp |V0:lclock|) cf_cmp_l))
                         a!2)))
           (or __ts0_e __ts0__ts0_d_a (not __ts0_c) (not __ts0_a) (not a!3)))))
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (or (and (isd.rd |V1:proc|
                                     |V2:mem_type|
                                     |V3:addr_type|
                                     |V0:lclock|)
                             (= (ref.evs.cmp |V0:lclock|) rrsp))
                        (and (isd.wr |V1:proc|
                                     |V2:mem_type|
                                     |V3:addr_type|
                                     |V0:lclock|)
                             (= (ref.evs.cmp |V0:lclock|) wr_cmp)))))
         (let ((a!2 (not (and a!1 (= (__ref.evs.l_cmp |V0:lclock|) cf_cmp_l)))))
           (or __ts0_e __ts0__ts0_d_a (not __ts0_c) (not __ts0_b) a!2))))
       (or (not __ts0_b_a) (not __ts0_a_a) (=> _old_l2s_g_0 l2s_g_0))
       (or (not __ts0_b_a) (not __ts0_a_a) (=> a!144 (not l2s_g_0)))
       (or (not __ts0_b_a) (not __ts0_a_a) (=> _old_l2s_g_1 l2s_g_1))
       (or (not __ts0_b_a) (not __ts0_a_a) (=> a!145 (not l2s_g_1)))
       (or (not __ts0_b_a) (not __ts0_a_a) a!146)
       (or (not __ts0_b_a) (not __ts0_a_a) a!147)
       (or (not __ts0_b_a) __ts0_a_a (=> _old_l2s_g_0 l2s_g_0))
       (or (not __ts0_b_a) __ts0_a_a (=> a!144 (not l2s_g_0)))
       (or (not __ts0_b_a) __ts0_a_a (=> _old_l2s_g_1 l2s_g_1))
       (or (not __ts0_b_a) __ts0_a_a (=> a!145 (not l2s_g_1)))
       (or (not __ts0_b_a) __ts0_a_a a!146)
       (or (not __ts0_b_a) __ts0_a_a a!147)
       (or (not __ts0_b_a)
           __ts0_a_a
           (= (ref.evs.mem_loc |__new_loc:t|) pio_memc))
       a!148
       a!149
       a!150
       a!151
       a!152
       a!153
       a!154
       a!155
       (or __ts0_b_a (= l2s_g_0 __l2s_g_0))
       (or __ts0_b_a (= l2s_g_1 __l2s_g_1))
       a!156
       a!157
       a!158
       a!159
       a!160
       a!161
       a!162
       (or (not __ts0_d) __ts0_b_b __ts0_c_a)
       (or (not __ts0_d)
           (not __ts0_b_b)
           (isd.rd |__loc:pp_a| |__loc:mm_a| |__loc:aa_a| |__loc:tt_a|))
       (or (not __ts0_d) (not __ts0_b_b) (= (ref.evs.req |__loc:tt_a|) read))
       (or (not __ts0_d)
           (not __ts0_b_b)
           (= (ref.evs.mem_loc |__loc:tt_a|) mem_memc))
       (or (not __ts0_d)
           (not __ts0_b_b)
           (= (ref.evs.l_req |__loc:tt_a|) cf_mem_l))
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.rd |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) read)
                         (= (ref.evs.mem_loc |V0:lclock|) mem_memc)
                         (= (ref.evs.l_req |V0:lclock|) cf_mem_l))))
         (let ((a!2 (not (and a!1
                              (or (= |V0:lclock| |__loc:tt_a|)
                                  (|<:lclock:lclock| |V0:lclock| |__loc:tt_a|))
                              (not (= |V0:lclock| |__loc:tt_a|))))))
           (or (not __ts0_d) (not __ts0_b_b) a!2))))
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.rd |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) read)
                         (= (ref.evs.mem_loc |V0:lclock|) mem_memc)
                         (= (ref.evs.l_req |V0:lclock|) cf_mem_l))))
           (or (not __ts0_d) (not __ts0_c_a) (not a!1))))
       (or (not __ts0_d)
           (not __ts0_c_a)
           (not __ts0__ts0__ts0_a_a_a)
           (|<:lclock:lclock| |__ts0__ts0__ts0__new_fml:x_a_a| |__fml:y|))
       a!163
       (or (not __ts0_d)
           (not __ts0_c_a)
           (not __ts0__ts0__ts0_a_a_a)
           (lclock.succ |__ts0__ts0__ts0__new_fml:x_a_a| |__fml:y|))
       (or (not __ts0_d) (not __ts0__ts0_a) __ts0_b_a_a __ts0_c_a_a)
       (or (not __ts0_d)
           (not __ts0__ts0_a)
           (not __ts0_b_a_a)
           (isd.rd |__loc:pp_a_a| |__loc:mm_a_a| |__loc:aa_a_a| |__loc:tt_a_a|))
       (or (not __ts0_d)
           (not __ts0__ts0_a)
           (not __ts0_b_a_a)
           (= (ref.evs.req |__loc:tt_a_a|) read))
       (or (not __ts0_d)
           (not __ts0__ts0_a)
           (not __ts0_b_a_a)
           (= (ref.evs.mem_loc |__loc:tt_a_a|) mem_memc))
       (or (not __ts0_d)
           (not __ts0__ts0_a)
           (not __ts0_b_a_a)
           (= (ref.evs.l_req |__loc:tt_a_a|) cf_mem_l))
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.rd |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) read)
                         (= (ref.evs.mem_loc |V0:lclock|) mem_memc)
                         (= (ref.evs.l_req |V0:lclock|) cf_mem_l))))
         (let ((a!2 (=> a!1
                        (not (|<:tar_cf_clock:tar_cf_clock|
                               (ref.evs.lt_arr_cf |V0:lclock|)
                               (ref.evs.lt_arr_cf |__loc:tt_a_a|))))))
           (or (not __ts0_d) (not __ts0__ts0_a) (not __ts0_b_a_a) a!2))))
       (forall ((|V0:lclock| lclock)
                (|V1:proc| proc)
                (|V2:mem_type| mem_type)
                (|V3:addr_type| addr_type))
         (let ((a!1 (and (isd.rd |V1:proc|
                                 |V2:mem_type|
                                 |V3:addr_type|
                                 |V0:lclock|)
                         (= (ref.evs.req |V0:lclock|) read)
                         (= (ref.evs.mem_loc |V0:lclock|) mem_memc)
                         (= (ref.evs.l_req |V0:lclock|) cf_mem_l))))
           (or (not __ts0_d) (not __ts0__ts0_a) (not __ts0_c_a_a) (not a!1))))
       (or (not __ts0_d)
           (not __ts0__ts0_a)
           (not __ts0_c_a_a)
           (not __ts0__ts0__ts0__ts0_a_a)
           (|<:tar_cf_clock:tar_cf_clock|
             |__ts0__ts0__ts0__ts0__new_fml:x_a|
             |__fml:y_a|))
       a!164
       (or (not __ts0_d)
           (not __ts0__ts0_a)
           (not __ts0_c_a_a)
           (not __ts0__ts0__ts0__ts0_a_a)
           (tar_cf_clock.succ |__ts0__ts0__ts0__ts0__new_fml:x_a| |__fml:y_a|))
       a!165
       a!166
       a!167
       a!168
       a!24
       a!25
       a!169
       a!170
       a!28
       a!29
       (=> (= ref.lt |0:lclock|) (= ref.lt_tar_cf |0:tar_cf_clock|))
       a!171
       (=> a!172
           (or (|<:tar_cf_clock:tar_cf_clock|
                 ref.lt_tar_cf
                 cfabric.t_rd_arr_min)
               (= cfabric.t_rd_arr_min |0:tar_cf_clock|)))
       (=> a!32 (= cfabric.t_rd_arr_min |0:tar_cf_clock|))
       a!33
       a!173
       a!174
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.cmp |T:lclock|) rrsp)
                         (not (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
               (a!3 (=> (and (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.mem_loc |T:lclock|) mem_memc))
                        (= (ref.evs.l_req |T:lclock|) cf_mem_l))))
         (let ((a!2 (or (= (ref.evs.cmp |T:lclock|) nop)
                        (= (ref.evs.cmp |T:lclock|) wr_cmp)
                        a!1)))
           (=> (|<:lclock:lclock| cfabric.t_rd_min |T:lclock|) (and a!2 a!3)))))
       (=> a!172
           (or (|<:lclock:lclock| ref.lt cfabric.t_rd_min)
               (= cfabric.t_rd_min |0:lclock|)))
       (=> a!32 (= cfabric.t_rd_min |0:lclock|))
       a!175
       a!176
       a!177
       (= (ref.evs.req |0:lclock|) nop)
       (= (ref.evs.l_req |0:lclock|) init_l)
       (= (ref.evs.cmp |0:lclock|) nop)
       (= (ref.evs.l_cmp |0:lclock|) init_l)
       (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|)
       (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|)
       a!40
       a!178
       a!179
       a!180
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.req |T0:lclock|) read))
                         (= (ref.evs.l_req |T0:lclock|) dramc_l)
                         (or (= (ref.evs.req |T1:lclock|) write)
                             (= (ref.evs.req |T1:lclock|) read))
                         (= (ref.evs.l_req |T1:lclock|) dramc_l)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))))
               (a!2 (or (|<:tar_clock:tar_clock|
                          (ref.evs.lt_arr |T0:lclock|)
                          (dramc.t_min (ref.evs.m |T0:lclock|)))
                        (|<:tar_clock:tar_clock|
                          (ref.evs.lt_arr |T1:lclock|)
                          (dramc.t_min (ref.evs.m |T0:lclock|))))))
           (=> a!1 (not a!2))))
       a!181
       a!182
       a!183
       a!48
       a!49
       a!50
       a!51
       a!184
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) write)
                             (= (ref.evs.req |T:lclock|) read))
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (= (ref.evs.l_req |T:lclock|) dramc_l)))
               (a!2 (not (|<:tar_clock:tar_clock|
                           (ref.lt_tar (ref.evs.m |T:lclock|))
                           (ref.evs.lt_arr |T:lclock|)))))
           (=> a!1 a!2)))
       a!54
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l))
                        (and (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l))))
               (a!3 (and (not (= (ref.evs.lt_arr |T0:lclock|)
                                 (ref.evs.lt_tar |T1:lclock|)))
                         (not (= (ref.evs.lt_arr |T0:lclock|)
                                 (ref.evs.lt_arr |T1:lclock|))))))
         (let ((a!2 (and a!1
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T1:lclock|) wr_cmp)
                             (= (ref.evs.cmp |T1:lclock|) rrsp))
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (not (= |T0:lclock| |T1:lclock|)))))
           (=> a!2 a!3))))
       a!185
       a!57
       a!186
       a!59
       a!60
       a!187
       a!62
       a!63
       a!64
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                         (= (ref.evs.req |T1:lclock|) read)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (and (= (ref.evs.l_req |T0:lclock|) if_l)
                         (or (= (ref.evs.l_req |T1:lclock|) if_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
               (a!3 (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                        (= (ref.evs.l_req |T1:lclock|) if_l)
                        (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
         (let ((a!4 (or (and (= (ref.evs.l_req |T0:lclock|) cf_pio_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_pio_l))
                        a!2
                        (and (= (ref.evs.l_req |T0:lclock|) memc_l) a!3))))
           (=> a!1 a!4))))
       a!66
       a!67
       a!68
       a!69
       a!70
       a!188
       a!189
       a!190
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       a!80
       a!81
       a!82
       a!83
       a!84
       a!85
       a!86
       a!87
       a!88
       a!89
       a!90
       a!91
       a!92
       a!93
       a!94
       a!191
       a!96
       a!97
       a!68
       a!192
       a!99
       a!100
       a!101
       a!102
       a!103
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.req |T1:lclock|) write))
                        (and (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.req |T1:lclock|) read))))
               (a!3 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                         (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (a!4 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.l_req |T1:lclock|) memc_l)
                        (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
         (let ((a!2 (and a!1
                         (not (ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!5 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                        a!3
                        (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!4))))
           (=> a!2 a!5))))
       a!105
       a!106
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (and (= (ref.evs.req |T0:lclock|) write)
                             (= (ref.evs.req |T1:lclock|) write))
                        (and (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.req |T1:lclock|) read))))
               (a!3 (and (= (ref.evs.l_req |T0:lclock|) if_l)
                         (or (= (ref.evs.l_req |T1:lclock|) if_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
               (a!4 (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                        (= (ref.evs.l_req |T1:lclock|) if_l)
                        (= (ref.evs.l_req |T1:lclock|) cf_pio_l))))
         (let ((a!2 (and a!1
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) pio_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) pio_memc)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!5 (or (and (= (ref.evs.l_req |T0:lclock|) cf_pio_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_pio_l))
                        a!3
                        (and (= (ref.evs.l_req |T0:lclock|) memc_l) a!4))))
           (=> a!2 a!5))))
       a!193
       a!194
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                         (not (ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.req |T1:lclock|) read)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (and (= (ref.evs.req |T1:lclock|) read)
                         (= (ref.evs.l_req |T1:lclock|) cf_mem_l)
                         (= (ref.evs.req |T0:lclock|) read)
                         (or (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                             (= (ref.evs.l_req |T0:lclock|) memc_l)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l))))
               (a!3 (and (= (ref.evs.req |T1:lclock|) read)
                         (= (ref.evs.l_req |T1:lclock|) memc_l)
                         (= (ref.evs.req |T0:lclock|) read)
                         (or (= (ref.evs.l_req |T0:lclock|) memc_l)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
         (let ((a!4 (or a!2
                        a!3
                        (and (= (ref.evs.req |T1:lclock|) read)
                             (= (ref.evs.l_req |T1:lclock|) dramc_l)
                             (= (ref.evs.req |T0:lclock|) read)
                             (= (ref.evs.l_req |T0:lclock|) dramc_l)))))
           (=> a!1 a!4))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T0:lclock|) write)
                         (not (ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.req |T1:lclock|) write)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (and (= (ref.evs.l_req |T0:lclock|) memc_l)
                         (or (= (ref.evs.l_req |T1:lclock|) memc_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
               (a!3 (or (= (ref.evs.l_req |T1:lclock|) dramc_l)
                        (= (ref.evs.l_req |T1:lclock|) memc_l)
                        (= (ref.evs.l_req |T1:lclock|) cf_mem_l))))
         (let ((a!4 (or (and (= (ref.evs.l_req |T0:lclock|) cf_mem_l)
                             (= (ref.evs.l_req |T1:lclock|) cf_mem_l))
                        a!2
                        (and (= (ref.evs.l_req |T0:lclock|) dramc_l) a!3))))
           (=> a!1 a!4))))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.req |T0:lclock|) read)
                         (not (ref.evs.serialized |T0:lclock|))
                         (= (ref.evs.cmp |T1:lclock|) rrsp)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         (= (ref.evs.mem_loc |T0:lclock|) mem_memc)
                         (= (ref.evs.mem_loc |T1:lclock|) mem_memc)
                         (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|)
                         (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
               (a!2 (and (= (ref.evs.l_req |T0:lclock|) dramc_l)
                         (or (= (ref.evs.l_cmp |T1:lclock|) dramc_l)
                             (= (ref.evs.l_cmp |T1:lclock|) memc_l)
                             (= (ref.evs.l_cmp |T1:lclock|) cf_mem_l)
                             (= (ref.evs.l_cmp |T1:lclock|) arm_l)))))
           (=> a!1 a!2)))
       a!113
       a!114
       a!115
       a!116
       a!117
       a!118
       a!119
       a!120
       a!121
       a!122
       a!123
       a!195
       a!125
       a!126
       a!127
       (forall ((|X:index| index) (|Y:index| index) (|Z:index| index))
         (let ((a!1 (and (|<:index:index| |X:index| |Z:index|)
                         (not (and (|<:index:index| |X:index| |Y:index|)
                                   (|<:index:index| |Y:index| |Z:index|))))))
           (=> (index.succ |X:index| |Z:index|) a!1)))
       a!196
       a!197
       (forall ((|T:index| index) (|U:index| index))
         (or (|<:index:index| |T:index| |U:index|)
             (= |T:index| |U:index|)
             (|<:index:index| |U:index| |T:index|)))
       (forall ((|X:index| index))
         (or (= |0:index| |X:index|) (|<:index:index| |0:index| |X:index|)))
       (forall ((|X:lclock| lclock) (|Y:lclock| lclock) (|Z:lclock| lclock))
         (let ((a!1 (and (|<:lclock:lclock| |X:lclock| |Z:lclock|)
                         (not (and (|<:lclock:lclock| |X:lclock| |Y:lclock|)
                                   (|<:lclock:lclock| |Y:lclock| |Z:lclock|))))))
           (=> (lclock.succ |X:lclock| |Z:lclock|) a!1)))
       a!198
       a!199
       (forall ((|T:lclock| lclock) (|U:lclock| lclock))
         (or (|<:lclock:lclock| |T:lclock| |U:lclock|)
             (= |T:lclock| |U:lclock|)
             (|<:lclock:lclock| |U:lclock| |T:lclock|)))
       (forall ((|X:lclock| lclock))
         (or (= |0:lclock| |X:lclock|)
             (|<:lclock:lclock| |0:lclock| |X:lclock|)))
       (forall ((|X:tar_clock| tar_clock)
                (|Y:tar_clock| tar_clock)
                (|Z:tar_clock| tar_clock))
         (let ((a!1 (and (|<:tar_clock:tar_clock| |X:tar_clock| |Z:tar_clock|)
                         (not (and (|<:tar_clock:tar_clock|
                                     |X:tar_clock|
                                     |Y:tar_clock|)
                                   (|<:tar_clock:tar_clock|
                                     |Y:tar_clock|
                                     |Z:tar_clock|))))))
           (=> (tar_clock.succ |X:tar_clock| |Z:tar_clock|) a!1)))
       a!200
       a!201
       (forall ((|T:tar_clock| tar_clock) (|U:tar_clock| tar_clock))
         (or (|<:tar_clock:tar_clock| |T:tar_clock| |U:tar_clock|)
             (= |T:tar_clock| |U:tar_clock|)
             (|<:tar_clock:tar_clock| |U:tar_clock| |T:tar_clock|)))
       (forall ((|X:tar_clock| tar_clock))
         (or (= |0:tar_clock| |X:tar_clock|)
             (|<:tar_clock:tar_clock| |0:tar_clock| |X:tar_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock)
                (|Y:tar_cf_clock| tar_cf_clock)
                (|Z:tar_cf_clock| tar_cf_clock))
         (let ((a!1 (and (|<:tar_cf_clock:tar_cf_clock|
                           |X:tar_cf_clock|
                           |Z:tar_cf_clock|)
                         (not (and (|<:tar_cf_clock:tar_cf_clock|
                                     |X:tar_cf_clock|
                                     |Y:tar_cf_clock|)
                                   (|<:tar_cf_clock:tar_cf_clock|
                                     |Y:tar_cf_clock|
                                     |Z:tar_cf_clock|))))))
           (=> (tar_cf_clock.succ |X:tar_cf_clock| |Z:tar_cf_clock|) a!1)))
       a!202
       a!203
       (forall ((|T:tar_cf_clock| tar_cf_clock) (|U:tar_cf_clock| tar_cf_clock))
         (or (|<:tar_cf_clock:tar_cf_clock| |T:tar_cf_clock| |U:tar_cf_clock|)
             (= |T:tar_cf_clock| |U:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |U:tar_cf_clock| |T:tar_cf_clock|)))
       (forall ((|X:tar_cf_clock| tar_cf_clock))
         (or (= |0:tar_cf_clock| |X:tar_cf_clock|)
             (|<:tar_cf_clock:tar_cf_clock| |0:tar_cf_clock| |X:tar_cf_clock|)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (__ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (__ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (__ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (__ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (__ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__cf_live.issued_memc |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (__ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (__rfn.evqual |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (__ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (__rfn.evcomplete |T:lclock|) a!1)))
       (not |__m_loc:wr|)
       (not |__m_loc:rd|)
       (not |__m_loc:cmp|)
       (= __m__old_l2s_g_2 __l2s_g_2)
       (= __m__old_l2s_g_4 __l2s_g_4)
       (= __m_cfabric.rd_fair (and (= |__fml:ph| rd_ph) |__fml:sel_memc|))
       (= __m_l2s_w_1
          (and __l2s_w_1 (not __m_cfabric.rd_fair) (not __m_l2s_g_4)))
       (= new__old_l2s_g_2_a __m_l2s_g_2)
       (= new__old_l2s_g_4_a __m_l2s_g_4)
       (not cfabric.rd_fair)
       (= l2s_w_1 (and __m_l2s_w_1 (not cfabric.rd_fair) (not l2s_g_4)))
       (= __m__old_l2s_g_3 __l2s_g_3)
       (= __m__old_l2s_g_5 __l2s_g_5)
       (= __m_cfabric.wr_fair (and (= |__fml:ph| wr_ph) |__fml:sel_memc|))
       (= __m_l2s_w_2
          (and __l2s_w_2 (not __m_cfabric.wr_fair) (not __m_l2s_g_5)))
       (= new__old_l2s_g_3_a __m_l2s_g_3)
       (= new__old_l2s_g_5_a __m_l2s_g_5)
       (not cfabric.wr_fair)
       (= l2s_w_2 (and __m_l2s_w_2 (not cfabric.wr_fair) (not l2s_g_5)))
       (= __m_cfabric.rd_pio_fair
          (and (= |__fml:ph| rd_ph) (not |__fml:sel_memc|)))
       (not cfabric.rd_pio_fair)
       (= __m_cfabric.wr_pio_fair
          (and (= |__fml:ph| wr_ph) (not |__fml:sel_memc|)))
       (not cfabric.wr_pio_fair)
       (= __m_cfabric.cpl_fair (= |__fml:ph| cpl_ph))
       (not cfabric.cpl_fair)
       (= |__new_loc:t| a!204)
       (= |__new_loc:p| a!205)
       (= |__new_loc:m| a!206)
       (= |__new_loc:a| a!207)
       (= |__new_loc:rd|
          (ite __ts0_e (ite __ts0_b |__m_loc:rd| true) |__m_loc:rd|))
       a!208
       a!209
       (= |__new_loc:cmp| a!210)
       (= __ts0__ts0_d_a (= |__fml:ph| wr_ph))
       (= __ts0_e (= |__fml:ph| rd_ph))
       (= |__new_loc:ordpip0| (and |__new_loc:rd| a!211))
       (= |__new_loc:ordpip1| (and |__new_loc:wr| a!212))
       (= |__new_loc:ordpip2| (and |__new_loc:rd| a!213))
       (= |__new_loc:ordpip3| (and |__new_loc:wr| a!214))
       (= |__new_loc:ordpip|
          (or |__new_loc:ordpip0|
              |__new_loc:ordpip1|
              |__new_loc:ordpip2|
              |__new_loc:ordpip3|))
       (= _old_l2s_g_0 (ite __ts0_b_a __l2s_g_0 ___old_l2s_g_0))
       (= _old_l2s_g_1 (ite __ts0_b_a __l2s_g_1 ___old_l2s_g_1))
       a!215
       (= l2s_w_0 (ite __ts0_b_a a!216 __l2s_w_0))
       a!217
       a!218
       (= |__ts0__ts0__new_fml:lt_a| |__new_loc:t|)
       (= __ts0_b_a
          (and (or |__new_loc:rd| |__new_loc:wr|) (not |__new_loc:ordpip|)))
       a!219
       (= |__ts0__ts0__ts0__new_fml:x_a_a| ref.lt)
       (= __ts0__ts0__ts0__new_cfabric.t_rd_min_a_a |__fml:y|)
       (= __ts0__ts0__ts0_a_a_a |__new_loc:rd|)
       (= cfabric.t_rd_arr_min a!220)
       (= |__ts0__ts0__ts0__ts0__new_fml:x_a| ref.lt_tar_cf)
       (= __ts0__ts0__ts0__ts0__new_cfabric.t_rd_arr_min_a_a |__fml:y_a|)
       (= __ts0__ts0__ts0__ts0_a_a |__new_loc:rd|)
       (= __ts0__ts0_a (and (= |__fml:ph| rd_ph) |__fml:sel_memc|))
       (= __ts0_d |__new_loc:rd|)
       a!221
       a!222
       a!223
       a!224
       a!225
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (or (not (= (ref.evs.req |T0:lclock|) nop))
                        (not (= (ref.evs.cmp |T0:lclock|) nop))))
               (a!2 (and (not (= (ref.evs.l_cmp |T0:lclock|) init_l))
                         (= (ref.evs.l_cmp |T1:lclock|) init_l)))
               (a!4 (and (not (= (ref.evs.l_req |T1:lclock|) init_l))
                         (ref.evs.serialized |T0:lclock|)
                         (|<:lclock:lclock| |T1:lclock| |T0:lclock|)))
               (a!5 (and (= (ref.evs.m |T0:lclock|) (ref.evs.m |T1:lclock|))
                         (= (ref.evs.a |T0:lclock|) (ref.evs.a |T1:lclock|))
                         (ref.same_attr |T0:lclock| |T1:lclock|))))
         (let ((a!3 (or (and (not (ref.evs.serialized |T0:lclock|))
                             (ref.evs.serialized |T1:lclock|))
                        a!2)))
         (let ((a!6 (and a!1
                         (or (and a!3
                                  (|<:lclock:lclock| |T0:lclock| |T1:lclock|))
                             a!4)
                         (= (ref.evs.p |T0:lclock|) (ref.evs.p |T1:lclock|))
                         a!5
                         (not (ref.mem_memc_exception |T0:lclock| |T1:lclock|)))))
           (= (ref.prevents |T0:lclock| |T1:lclock|) a!6)))))
       a!226
       a!227
       a!228
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T0:lclock|) nGnRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGnRnE)
                             (= (ref.evs.op_ack |T1:lclock|) nGnRE)))))
           (= (ref.both_nGnR |T0:lclock| |T1:lclock|) a!1)))
       (forall ((|T0:lclock| lclock) (|T1:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.op_ack |T0:lclock|) nGRE)
                             (= (ref.evs.op_ack |T0:lclock|) _GRE))
                         (or (= (ref.evs.op_ack |T1:lclock|) nGRE)
                             (= (ref.evs.op_ack |T1:lclock|) _GRE)))))
           (= (ref.both_nGR |T0:lclock| |T1:lclock|) a!1)))
       a!229
       a!230
       a!231
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.l_req |T:lclock|) cf_mem_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (cf_live.issued_memc |T:lclock|) a!1)))
       (forall ((|M:mem_type| mem_type) (|T:lclock| lclock))
         (let ((a!1 (and (or (= (ref.evs.req |T:lclock|) read)
                             (= (ref.evs.req |T:lclock|) write))
                         (= (ref.evs.m |T:lclock|) |M:mem_type|)
                         (= (ref.evs.l_req |T:lclock|) dramc_l)
                         (= (ref.evs.mem_loc |T:lclock|) mem_memc))))
           (= (rfn.evqual |M:mem_type| |T:lclock|) a!1)))
       (forall ((|T:lclock| lclock))
         (let ((a!1 (and (= (ref.evs.mem_loc |T:lclock|) mem_memc)
                         (or (= (ref.evs.cmp |T:lclock|) rrsp)
                             (= (ref.evs.cmp |T:lclock|) wr_cmp))
                         (= (ref.evs.l_cmp |T:lclock|) memc_l))))
           (= (rfn.evcomplete |T:lclock|) a!1)))))))
(assert (let ((a!1 (forall ((|T:lclock| lclock))
             (=> (and (or (= |T:lclock| _T) (|<:lclock:lclock| |T:lclock| _T))
                      (= (ref.evs.req _T) write))
                 (l2s_s_1 |T:lclock|))))
      (a!2 (forall ((|T:lclock| lclock))
             (=> (and (or (= |T:lclock| _T) (|<:lclock:lclock| |T:lclock| _T))
                      (= (ref.evs.req _T) read))
                 (l2s_s_0 |T:lclock|))))
      (a!4 (exists ((|T:lclock| lclock))
             (and (not (l2s_s_1 |T:lclock|))
                  (not (cf_live.issued_memc |T:lclock|))
                  (or (= |T:lclock| _T) (|<:lclock:lclock| |T:lclock| _T))
                  (or (= |T:lclock| ref.lt)
                      (|<:lclock:lclock| |T:lclock| ref.lt))
                  (= (ref.evs.req _T) write)))))
(let ((a!3 (and (not a!1) (not (or (not a!2))) l2s_saved true (not l2s_w_2))))
  (and (not (=> a!3 a!4))))))
(check-sat)
(get-info :all-statistics)
