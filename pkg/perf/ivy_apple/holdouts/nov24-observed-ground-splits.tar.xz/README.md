# Bounded case splits on observed ground instances

g3 commit 619a2b3f3 contains the released implementation, Go benchmark, and two of the real DIMACS captures. The baseline is 1d0da278d. Both binaries used the GoIvy frontend at 832e392ef, GOMAXPROCS=1, xtrace_off and local modules. The measurements used a Threadripper 3960X. The previous release checker was built at dc8fe811f, which has identical Go sources to the baseline.

Run the following commands from g3/pkg to repeat the focused measurements.

    go test ./api/internal/order -run '^TestGroundSplit' -count=1
    go test ./api/internal/order -run '^$' -bench '^BenchmarkGroundInstanceObservedSplit$' -cpu=1 -count=5

Extract the archive and run python3 replay_witnesses.py /path/to/g3 or python3 replay_witnesses.py /path/to/the/in-tree/build/z3. Each capture has a DIMACS comment holding the signed goal. Each table reports the base, the base under the goal, and the base under its opposite. The verifier runs in cases.tsv use the indicated file relative to ivy-lang-examples, preceded by isolate=NAME when populated. To repeat the quiet measurements use perf/ivy_apple/holdouts/rotating_verification.py with the current and previous GoIvy checkers, the same frontend linked to the in-tree native Z3, a pinned CPU, and five rounds. The results preserve every attempt and the CPU/sibling occupancy observations.

The capped-split-release tables are the shipped algorithm. observed-split-release is the earlier cap that counted only clause visits. probe-residual-units varies search depth, split-instance-attribution varies where splits run, split-after-warmup varies the number of early calls left to the solver, and split-goal-schedule changes the relative timing of fast proofs and general solver calls. The ARM subset labels give exactly the batch/goal pairs permitted to split. Each phase table records instructions on the calling OS thread with results, batch and goal. The 228 corpus rows preserve output and exit comparisons including expected verification failures.
