"""Independently verify the two signs of every captured Boolean goal."""
import csv
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for table in sorted((root / "witnesses").glob("*/native.csv")):
    for row in csv.DictReader(table.open()):
        source = (table.parent / row["file"]).read_text().splitlines()
        goal = int(source[0].split()[-1])
        _, _, variables, count = source[1].split()
        for column, unit in (("plain", 0), ("positive", goal), ("negative", -goal)):
            clauses = source[2:] + ([f"{unit} 0"] if unit else [])
            assert len(clauses) == int(count) + bool(unit)
            text = f"p cnf {variables} {len(clauses)}\n" + "\n".join(clauses) + "\n"
            result = subprocess.run([sys.argv[1], "-dimacs", "-in"], input=text,
                                    capture_output=True, text=True, timeout=60)
            answers = [x for x in result.stdout.upper().splitlines()
                       if x in ("S SATISFIABLE", "S UNSATISFIABLE", "SAT", "UNSAT")]
            assert len(answers) == 1 and result.returncode in (0, 10, 20), result
            actual = "unsat" if "UNSAT" in answers[0] else "sat"
            assert actual == row[column], (table, row, column, actual)
    print(table.parent.name, "verified")
