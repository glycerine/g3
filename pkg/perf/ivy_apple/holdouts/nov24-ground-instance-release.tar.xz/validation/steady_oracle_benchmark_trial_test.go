package api

import (
	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/solver"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

func TestSteadyProjectionOracle(t *testing.T) {
	cases, e := os.ReadDir(os.Getenv("G3_STEADY_CASES"))
	if e != nil {
		t.Fatal(e)
	}
	var total, proved, satisfiable, unknown int
	for _, c := range cases {
		if !c.IsDir() {
			continue
		}
		t.Run(c.Name(), func(t *testing.T) {
			dir := filepath.Join(os.Getenv("G3_STEADY_CASES"), c.Name())
			read := func(n string) string {
				b, e := os.ReadFile(filepath.Join(dir, n))
				if e != nil {
					t.Fatal(e)
				}
				return string(b)
			}
			ctx, s := orderSolver(t, read("input.smt2"))
			m, e := ctx.Manager()
			astTestMust(t, e)
			roots, e := solver.Assertions(s.solver)
			astTestMust(t, e)
			n, e := strconv.Atoi(read("nbase"))
			astTestMust(t, e)
			want := strings.Fields(read("expected"))
			if len(want) != 3*(len(roots)-n) {
				t.Fatal("case width", len(want), len(roots), n)
			}
			idx := 0
			var db groundInstanceSolver
			defer func() { astTestMust(t, db.close()) }()
			for _, end := range []int{n, n / 2, n} {
				xs := make([]ast.ASTHandle, end+1)
				copy(xs, roots[:end])
				for _, q := range roots[n:] {
					xs[end] = q
					got, e := db.prove(s, m, xs, 2_000_000, 1)
					astTestMust(t, e)
					if got && want[idx] != "unsat" {
						t.Fatalf("base %d goal %d proved %s", end, idx, want[idx])
					}
					if want[idx] == "sat" {
						satisfiable++
					}
					if want[idx] == "unknown" {
						unknown++
					}
					if got {
						proved++
					}
					total++
					idx++
				}
			}
		})
	}
	t.Log("checked", total, "proved", proved, "concrete SAT", satisfiable, "native unknown", unknown)
	if total < 6000 || proved < 500 || satisfiable < 800 {
		t.Fatal("insufficient discrimination")
	}
}
