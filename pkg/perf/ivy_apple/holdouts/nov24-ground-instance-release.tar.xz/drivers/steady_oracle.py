from common import *
import random,itertools,re
from concurrent.futures import ProcessPoolExecutor,as_completed
rd=d/'steady-oracle';rd.mkdir(exist_ok=True)
def fixture(seed):
 rng=random.Random(67319+seed);h=rd/'cases'/str(seed);h.mkdir(parents=True,exist_ok=True)
 names={'U':['a','b','c'],'V':['d','e']};dom={'U':range(3),'V':range(2),'Bool':[False,True]};types={'f':(('U',),'U'),'g':(('U',),'U'),'v':(('U',),'V'),'h':(('V','U'),'U'),'p':(('U',),'Bool'),'q':(('U',),'Bool'),'s':(('V',),'Bool'),'r':(('U','V'),'Bool')}
 for sort,ns in names.items():
  for nm in ns:types[nm]=((),sort)
 model={s:{t:rng.choice(dom[res])for t in itertools.product(*(dom[a]for a in args))}for s,(args,res)in types.items()}
 for st,ns in names.items():
  for i,n in enumerate(ns):model[n][()]=i
 def ev(h,eta):
  if isinstance(h,str):
   if h in eta:return eta[h]
   if h in ('true','false'):return h=='true'
   return model[h][()]
  op,*es=h;v=[ev(e,eta)for e in es]
  if op=='=':return v[0]==v[1]
  if op=='not':return not v[0]
  if op=='or':return any(v)
  if op=='and':return all(v)
  if op=='xor':return v[0]!=v[1]
  if op=='=>':return not v[0]or v[1]
  if op=='ite':return v[1]if v[0]else v[2]
  return model[op][tuple(v)]
 def term(st,depth,vs):
  if depth==0 or rng.random()<.35:
   ls=names.get(st,['true','false'])+[n for n,s in vs if s==st]
   if st=='Bool' and rng.random()<.8:return ('p',rng.choice(names['U']))
   return rng.choice(ls)
  choices=[f for f,(ss,ty)in types.items()if ss and ty==st]
  if st=='Bool':choices+=['=','and','or','not','=>','xor']*2
  if rng.random()<.14:choices+=['ite']*3
  f=rng.choice(choices)
  if f=='=':st=rng.choice(['U','V','Bool']);args=(st,st)
  elif f in ('and','or','=>','xor'):args=('Bool','Bool')
  elif f=='not':args=('Bool',)
  elif f=='ite':args=('Bool',st,st)
  else:args=types[f][0]
  return (f,*(term(s,depth-1,vs)for s in args))
 def smt(x):return x if isinstance(x,str)else '('+' '.join(smt(a)for a in x)+')'
 def sub(h,eta):return eta.get(h,h)if isinstance(h,str)else(h[0],*(sub(a,eta)for a in h[1:]))
 decl=['(declare-sort U 0)','(declare-sort V 0)']+['(declare-fun '+s+' ('+' '.join(args)+') '+v+')'for s,(args,v)in types.items()]
 base=[];rules=[]
 for st,ns in names.items():base.append('(forall ((x '+st+')) (or '+' '.join('(= x '+v+')'for v in ns)+'))')
 for i in range(15):
  vs=list(zip(['x','y','z'],[rng.choice(['U','V'])for _ in range(rng.randrange(1,4))]));body=term('Bool',3,vs)
  holds=[ev(body,dict(zip((s for s,_ in vs),vals)))for vals in itertools.product(*(dom[ty]for _,ty in vs))]
  if not any(holds):body=('not',body)
  elif not all(holds):
   # Keep a nontrivial logical consequence valid in the generated model.
   nm,ty=vs[0];t=rng.choice(names[ty]);br=('=',nm,t);keep=[ev(body,dict(zip((s for s,_ in vs),vals)))for vals in itertools.product(*(dom[ty]for _,ty in vs))if vals[0]==model[t][()]]
   body=('=>',br,body)if all(keep)else('or',body,('not',body))
  assert all(ev(body,dict(zip((s for s,_ in vs),vals)))for vals in itertools.product(*(dom[ty]for _,ty in vs)))
  base.append('(forall ('+' '.join('('+n+' '+ty+')'for n,ty in vs)+') '+smt(body)+')');rules.append((vs,body))
 for f,(args,st)in types.items():
  if args and rng.random()<.8:
   for tup in itertools.product(*(names[a]for a in args)):
    if rng.random()<.4:continue
    val=ev((f,*tup),{});res=('true'if val else'false')if st=='Bool'else names[st][val];base.append(smt(('=',(f,*tup),res)))
 goals=[]
 for i in range(90):
  if i%3==0:
   vs,body=rng.choice(rules);b=sub(body,{nm:rng.choice(names[st])for nm,st in vs});q=('not',b)
  else:q=term('Bool',rng.randrange(2,5),[])
  # Keep an observed constant in every generated goal; this tautology imposes no model constraint.
  t=rng.choice(names['U']);q=('and',('=',t,t),q);goals.append(smt(q))
 # Check the same sequence under two exact premise lists, including a shrink and restoration.
 ci=['(assert '+b+')'for b in base];gg=['(assert '+g+')'for g in goals]
 (h/'input.smt2').write_text('\n'.join(decl+ci+gg));(h/'nbase').write_text(str(len(base)));rows=[]
 for sz in [len(base),len(base)//2,len(base)]:
  script='(set-option :timeout 1800)\n'+'\n'.join(decl+ci[:sz]+['(push 1)\n'+g+'\n(check-sat)\n(pop 1)'for g in gg])+'\n'
  p=subprocess.run([pkg.parent/'build/z3','-in','-smt2'],input=script,text=True,capture_output=True,timeout=210)
  assert p.returncode==0 and not p.stderr and len(p.stdout.splitlines())==len(goals),(seed,p.stdout[-300:],p.stderr)
  rows.extend(p.stdout.splitlines())
 (h/'expected').write_text('\n'.join(rows)+'\n');return seed,Counter(rows)
code='''package api
import("os";"strconv";"strings";"path/filepath";"testing";"github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/solver")
func TestSteadyProjectionOracle(t *testing.T){
 cases,e:=os.ReadDir(os.Getenv("G3_STEADY_CASES"));if e!=nil{t.Fatal(e)};var total,proved,satisfiable,unknown int
 for _,c:=range cases{if !c.IsDir(){continue};t.Run(c.Name(),func(t *testing.T){
  dir:=filepath.Join(os.Getenv("G3_STEADY_CASES"),c.Name());read:=func(n string)string{b,e:=os.ReadFile(filepath.Join(dir,n));if e!=nil{t.Fatal(e)};return string(b)}
  ctx,s:=orderSolver(t,read("input.smt2"));m,e:=ctx.Manager();astTestMust(t,e);roots,e:=solver.Assertions(s.solver);astTestMust(t,e);n,e:=strconv.Atoi(read("nbase"));astTestMust(t,e);want:=strings.Fields(read("expected"));if len(want)!=3*(len(roots)-n){t.Fatal("case width",len(want),len(roots),n)};idx:=0;var db studySteadySearch;defer func(){astTestMust(t,db.close())}()
  for _,end:=range []int{n,n/2,n}{xs:=make([]ast.ASTHandle,end+1);copy(xs,roots[:end]);for _,q:=range roots[n:]{xs[end]=q;got,e:=db.prove(s,m,xs);astTestMust(t,e);if got&&want[idx]!="unsat"{t.Fatalf("base %d goal %d proved %s",end,idx,want[idx])};if want[idx]=="sat"{satisfiable++};if want[idx]=="unknown"{unknown++};if got{proved++};total++;idx++}}
 })}
 t.Log("checked",total,"proved",proved,"concrete SAT",satisfiable,"native unknown",unknown);if total<6000||proved<500||satisfiable<800{t.Fatal("insufficient discrimination")}
}
'''
def main():
 with ProcessPoolExecutor(6)as ex,(rd/'native.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['seed','sat','unsat','unknown'])
  for seed,ct in ex.map(fixture,range(32)):z.writerow([seed,ct['sat'],ct['unsat'],ct['unknown']]);f.flush()
 p=pkg/'api/steady_oracle_benchmark_trial_test.go';od=d/'steady-ground-search/overlay'
 ed={p:code}
 for f in od.glob('*.go'):
  path=(pkg/'api/internal/order'if f.name.startswith('steady_ground')else pkg/'api')/f.name;ed[path]=f.read_text()
 o=overlay(rd/'overlay',ed)
 for backend in ['sat','units','both']:
  with(w/'build.lock').open('a')as lk,(rd/(backend+'.log')).open('w')as f:
   fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-count=1','-p','3','-tags=xtrace_off','-overlay='+str(o),'./api','-run','^TestSteadyProjectionOracle$','-v'],cwd=pkg,env=dict(env,G3_STEADY_ENGINE=backend,G3_STEADY_REPEAT='1',G3_STEADY_MIN='1',G3_STEADY_CONGRUENCE='32',G3_STEADY_DECISIONS='12',G3_STEADY_CASES=str(rd/'cases')),stdout=f,stderr=f)
  print(backend,flush=True)
if __name__=='__main__':main()
