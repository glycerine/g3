from common import *
import corpus_phases as cp,verification_frontier as vf,holdouts as ho,private_cost as pc,live_checks as lc
root=d/'stage-frontier';root.mkdir(exist_ok=True)
q=ivy.resolve()/'z3bridge_solver_model.go'
def jobs():
 src=ho.jobs()[3:]
 for n,spec in [('tlb','examples/liveness/tlb.ivy'),('hybrid','examples/liveness/hybrid_reliable_broadcast_cisa.ivy'),('cubicle','test/flash_cubicle.ivy'),('flash_example','examples/ivy/flash2.ivy')]:
  inds=w/'predicate-verification/corpus';rc=next(int(r['exit']) for f in inds.glob('cpu-*.csv')for r in readcsv(f)if r['spec']==spec)
  src.append((2,n,spec,'',rc,vf.reference(spec)))
 return [(c,*j[1:])for c,j in zip([1,5,7,11,12,13,17,19,21,23,25,27,29],src)]
def phase():
 cp.root=root/'outer';cp.root.mkdir(exist_ok=True)
 b=build(cp.root/'checker',o=cp.instrumentation());(cp.root/'build-info.txt').write_text(linked(b))
 bs={'g3':b,'native':w/'conditional-cost/native/checker/goivy_check'}
 with ThreadPoolExecutor(8)as ex:list(ex.map(cp.lane,[(c,[(n,sp,iso,rf,rc)],bs)for c,n,sp,iso,rc,rf in jobs()]))
def priv():
 od=root/'private';od.mkdir(exist_ok=True)
 edits={}
 import inspect
 f=inspect.getsource(pc.make)
 f=once(f,"return build(root/'g3',o=overlay(root/'overlay',edits))","return edits")
 f=f.replace("'func ProjectQuantifiedGoal('","'func ProjectQuantifiedGoal('")
 local=pc.__dict__.copy();exec(f,local);ed=local['make']()
 def instrument(path,start,slot):
  file=pkg/path;s=ed.get(file,file.read_text())
  if 'github.com/glycerine/g3/pkg/api/internal/proofmeter' not in s:
   if 'import (' in s:s=once(s,'import (','import (\n"github.com/glycerine/g3/pkg/api/internal/proofmeter"')
   else:s=once(s,'import ','import "github.com/glycerine/g3/pkg/api/internal/proofmeter"\nimport ')
  i=s.index('{',s.index(start))+1
  ed[file]=s[:i]+'\n defer proofmeter.Leave('+str(slot)+',proofmeter.Enter())\n'+s[i:]
 instrument('api/internal/order/quantified_goal.go','func (p *QuantifiedPremises) Project(',13)
 instrument('api/api_enumeration_refutation.go','func (p *enumerationRefutation) check(',14)
 t=q.read_text();lo=t.index('func (s *Solver) GetSmallModelWithCond(');hi=t.index('\n}',lo);sub=t[lo:hi];sub=once(sub,'z3solver := s.newZ3Solver()','trialBatch++; batch:=trialBatch;z3solver := s.newZ3Solver()');sub=once(sub,'for _, fc := range finalCond {','for j, fc := range finalCond {')
 for name,x in [('early','if proveGoal(zCond) {'),('check','res, err := s.decideZ3With(z3solver, finalCheck)')]:
  sub=once(sub,x,'fmt.Fprintln(os.Stderr,"QUERY",batch,j+1,"'+name+'");'+x)
 t=t[:lo]+sub+t[hi:]+'\nvar trialBatch int\n'
 if '"os"' not in t:t=once(t,'import (','import ("os";')
 ed[q]=t;b=build(od/'checker',o=overlay(od/'overlay',ed));(od/'build-info.txt').write_text(linked(b))
 def lane(j):
  c,n,sp,iso,rc,rf=j;td=od/n;td.mkdir(exist_ok=True)
  for i in range(3):
   td2=td/str(1+i);td2.mkdir();p=subprocess.run(['taskset','-c',str(c),b,examples/sp],cwd=td2,env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True)
   extra=bytearray();goal=(0,0,'none')
   with gzip.open(td2/'private.csv.gz','wt')as f:
    z=csv.writer(f);z.writerow(['batch','goal','stage','ordinal','early','total','transition','quantwrapper','groundproj','ground','universal','short','plan','goalinstances','bool','relevant','recent','assertions','quantparse','enumeration','unused'])
    for line in p.stderr.splitlines(keepends=True):
     if line.startswith(b'QUERY '):_,batch,g,kind=line.decode().split();goal=(int(batch),int(g),kind)
     elif line.startswith(b'PRIVATE-COST '):
      vals=line.decode().split();z.writerow([*goal,int(vals[1]),vals[2],*[int(v.strip('[]'))for v in vals[3:]]])
     else:extra.extend(line)
   assert(p.returncode,p.stdout,extra)==(rc,(rf/'stdout').read_bytes(),(rf/'stderr').read_bytes()),(n,p.returncode,extra[-400:])
   (td2/'validated').write_text('matched\n')
  print('private',n,flush=True)
 with ThreadPoolExecutor(8)as ex:list(ex.map(lane,jobs()))
def inner():
 lc.root=root/'inner';lc.root.mkdir(exist_ok=True)
 bs={'g3':lc.make('control',False),'g3-stats':lc.make('control',True),'native-stats':d/'live-checks/native-stats/goivy_check'}
 with ThreadPoolExecutor(8)as ex:list(ex.map(lambda j:lc.lane((*j[:5],None,j[-1]),bs,2),jobs()))
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:
  fs={f:ex.submit(f)for f in (phase,priv,inner)}
  for f,x in fs.items():
   try:x.result()
   except Exception:
    import traceback;traceback.print_exc()
