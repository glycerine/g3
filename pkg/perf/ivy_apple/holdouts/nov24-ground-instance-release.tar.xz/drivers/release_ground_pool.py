from common import *
import production_triggers as pt, ground_release_controls as gc, stage_frontier as sf,macro_identity as mi, holdouts as ho, timed_policy as tp, steady_oracle as so, fcntl
rd=d/'release-ground-pool';rd.mkdir(exist_ok=True)
def test(t):
 a=['go','test','-p','4','-count=1','-timeout=10m']
 if t:a.append('-tags='+t)
 a+=['./api','./api/internal/order']
 if t in ('g3debug','g3checked'):a+=['-run','Test(GroundInstance|OrderProof|OrderAbstraction|Witness|Verification|ProofPlan)']
 with(w/'build.lock').open('a')as lk,(rd/('test-'+(t or 'normal')+'.log')).open('w')as out:
  fcntl.flock(lk,fcntl.LOCK_SH);run(a,cwd=pkg,env=env,stdout=out,stderr=out)
 print('tests',t,flush=True)
def finite():
 p=pkg/'api/steady_oracle_benchmark_trial_test.go';s=so.code.replace('var db studySteadySearch','var db groundInstanceSolver').replace('db.prove(s,m,xs)','db.prove(s,m,xs,2_000_000,1)');o=overlay(rd/'oracle-overlay',{p:s})
 with(w/'build.lock').open('a')as lk,(rd/'oracle.log').open('w')as l:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-overlay='+str(o),'-tags=xtrace_off','-run','^TestSteadyProjectionOracle$','-count=1','-v','./api'],cwd=pkg,env=dict(env,G3_STEADY_CASES=str(so.rd/'cases')),stdout=l,stderr=l)
 print('oracle',flush=True)
def memory():
 with(w/'build.lock').open('a')as lk,(rd/'memory.log').open('w')as l:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-tags=xtrace_off','-run','^$','-bench','^Benchmark(GroundInstanceWorkerMemory|VerificationGroundInstanceSiblings)$','-cpu=1','-count=7','-benchtime=1x','./api'],cwd=pkg,env=env,stdout=l,stderr=l)
 print('memory',flush=True)
def main():
 pt.root=rd;gc.d=rd;ho.root=rd
 with ThreadPoolExecutor(18)as ex:
  bb=ex.submit(build,rd/'checker');fs=[ex.submit(test,t)for t in ('','xtrace_off','g3debug','g3checked')]+[ex.submit(pt.source_trace),ex.submit(finite),ex.submit(memory)]
  b=bb.result();(rd/'build-info.txt').write_text(linked(b));fs.append(ex.submit(gc.corpus,b))
  tp.root=rd/'timed';tp.root.mkdir();bs={'before':d/'release-repeat-plans/checker/goivy_check','release':b,'native':native};tp.bins=bs
  js=[j for j in sf.jobs()if j[1]in ('tlb','hermes_rmw_o3','arm_rules3','flash2','ticket_protocol','alternating_bit_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([3,5,9,11,12,15],(j for j in mi.jobs()if j[1]in('rfn2','cf_live','dramc_nb2','raft_no_assume_test','raftok','toy-consensus')))]+ho.jobs()[:3]
  for j in js:
   fs.append(ex.submit(ho.measure_spec,j,bs,5 if j[1]in('tlb','cf_live','rfn2')else 3))
   if j[1]=='tlb':fs.append(ex.submit(tp.lane,j[1:]))
  for f in fs:f.result()
if __name__=='__main__':main()
