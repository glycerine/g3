from common import *
from types import SimpleNamespace
import stage_frontier as sf,macro_identity as mi
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import rotating_verification as rv
root=d/'private-plan-wall';root.mkdir(exist_ok=True)
bins={'previous':d/'production-connected/checker/goivy_check','current':d/'production-plans/checker/goivy_check','native':native}
def lane(j):
 n,sp,iso,rc,ref=j;td=root/n;td.mkdir();ids=list(range(48));success=0;tries=0
 with(td/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round attempt engine cpu before sibling occupancy match wall user sys rss'.split())
  while success<7:
   plist=range(1 if n=='ticket_protocol'else 2,24,2);a=rv.ticks(ids);time.sleep(3);b=rv.ticks(ids);idle={c:min(rv.idle(a,b,c),rv.idle(a,b,c+24))for c in plist};cpu=max(idle,key=idle.get)
   if idle[cpu]<.95:continue
   tries+=1;es=list(bins);ok=True
   for v in es[success%3:]+es[:success%3]:
    path=td/f'{success+1}-{tries}-{v}';s=rv.ticks([cpu+24]);r,t,_=rv.measure_time(bins[v],SimpleNamespace(cpu=cpu,isolate=iso,spec=examples/sp),path);e=rv.ticks([cpu+24]);sib=rv.idle(s,e,cpu+24);occ=(t[1]+t[2])/t[0];matched=r==rc and all((path/k).read_bytes()==(ref/k).read_bytes()for k in ['stdout','stderr']);assert matched
    z.writerow([success+1,tries,v,cpu,idle[cpu],sib,occ,int(matched),*t]);f.flush()
    if min(sib,occ)<.95:ok=False;break
   if ok:success+=1
   print(n,tries,success,flush=True)
if __name__=='__main__':
 js=[j[1:]for j in sf.jobs()if j[1]=='ticket_protocol']+[(*j[1:5],j[-1])for j in mi.jobs()if j[1]=='cf_live']
 with ThreadPoolExecutor(2)as ex:list(ex.map(lane,js))
