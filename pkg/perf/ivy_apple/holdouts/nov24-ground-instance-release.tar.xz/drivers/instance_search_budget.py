from common import *
import holdouts as ho,stage_frontier as sf,shlex
rd=d/'instance-search-budget';rd.mkdir(exist_ok=True)
p=pkg/'api/api_ground_instances.go';entry='result, err := s.sat.solver.Check(assumptions)'
def make():
 s=once(p.read_text(),'import (','import (\n"os"\n"strconv"\n"fmt"\n"time"')
 s+='\nvar studyLimit=func()uint32{x,_:=strconv.Atoi(os.Getenv("G3_INSTANCE_SEARCH_STEPS"));return uint32(x)}()\nvar studyAudit=os.Getenv("G3_INSTANCE_SEARCH_AUDIT")!=""\n'
 s=once(s,entry,'''var tick time.Time;var count uint64
 if studyAudit {tick=time.Now();count=s.sat.limit.Count()}
 if studyLimit!=0{if e:=s.sat.limit.Push(studyLimit);e!=nil{return false,e}}
 '''+entry+'''
 if studyAudit{nv,_:=s.sat.solver.SourceNumVars();fmt.Fprintln(os.Stderr,"INST-SAT",q.Variables,nv,len(q.Clauses),len(q.PermanentUnits()),int(result),s.sat.limit.Count()-count,time.Since(tick).Nanoseconds())}
 if studyLimit!=0{exhausted:=!s.sat.limit.IncOffset(0);s.sat.limit.Pop()
  if exhausted && (err==nil || errors.Is(err,sat.ErrSATSolverCanceled)){return false,nil}
 }''')
 return build(rd/'checker',o=overlay(rd/'overlay',{p:s}))
def audit(j,b):
 cpu,n,sp,iso,rc,rf=j;od=rd/('audit-'+n);od.mkdir(exist_ok=True)
 with (od/'stdout').open('wb')as out,(od/'stderr').open('wb')as err,gzip.open(od/'queries.csv.gz','wt')as f:
  z=csv.writer(f);z.writerow('variables mapped clauses units result steps wall_ns'.split());p=subprocess.Popen(['taskset','-c',str(cpu),b,*(['isolate='+iso]if iso else[]),examples/sp],env=dict(env,GOMAXPROCS='1',GOGC='100',G3_INSTANCE_SEARCH_AUDIT='1'),cwd=od,stdout=out,stderr=subprocess.PIPE)
  for l in p.stderr:
   if l.startswith(b'INST-SAT '):z.writerow(list(map(int,l.split()[1:])))
   else:err.write(l)
  ret=p.wait()
 assert ret==rc and all((rf/k).read_bytes()==(od/k).read_bytes()for k in ('stdout','stderr')),n
 print('audit',n,flush=True)
def main():
 b=make();bs={}
 for v in (64,256,1024,4096,16384):
  n=f'steps{v}';u=rd/(n+'.sh');u.write_text('#!/bin/sh\nG3_INSTANCE_SEARCH_STEPS='+str(v)+' exec '+shlex.quote(str(b))+' "$@"\n');u.chmod(0o700);bs[n]=u
 bs['release']=d/'release-ground-pool/checker/goivy_check';bs['before']=d/'release-repeat-plans/checker/goivy_check';ho.root=rd
 js=[(34,*j[1:])for j in sf.jobs()if j[1]=='tlb']+[(cpu,*j[1:])for cpu,j in zip([3,12,21],ho.jobs()[:3])]
 with ThreadPoolExecutor(6)as e:
  fs=[e.submit(audit,(cpu,*j[1:]),b)for cpu,j in zip([44,31,36,40],js)]+[e.submit(ho.measure_spec,j,bs,3 if j[1]=='tlb'else 1)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
