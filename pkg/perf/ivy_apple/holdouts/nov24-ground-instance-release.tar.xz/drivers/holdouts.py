from common import *
from types import SimpleNamespace
from panel import measure,EVENTS
import verification_frontier as vf
root=d/'holdouts';root.mkdir(exist_ok=True)
def measure_spec(j,bins,rep):
 cpu,n,sp,iso,rc,rf=j;od=root/n;od.mkdir(exist_ok=True)
 with(od/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['spec','round','engine','cpu','exit','match','wall','user','sys','rss',*EVENTS]);vs=list(bins)
  for i in range(rep):
   for v in vs[i%len(vs):]+vs[:i%len(vs)]:
    sd=od/f'{i+1}-{v}';cfg=SimpleNamespace(cpu=cpu,perf=perf,spec=examples/sp,isolate=iso)
    ret,t,cts=measure(bins[v],cfg,sd,rc,100);matches=ret==rc and all((sd/k).read_bytes()==(rf/k).read_bytes()for k in ['stdout','stderr']);z.writerow([n,i+1,v,cpu,ret,int(matches),*t,*cts]);f.flush();assert matches,(n,v,ret);print(n,i+1,v,int(cts[0])/1e9,flush=True)
def jobs():
 ls=[(14,'apple2','doc/examples/apple/ord_live2.ivy','',0,w/'extended-phases/long/2/1/native'),(16,'apple','doc/examples/apple/ord_live.ivy','',0,w/'apple-original-pairs/14-native'),(18,'testing','jea/hermes_rmw_o3_testing.ivy','',0,w/'extended-phases/long/1/1/native')]
 for j,r in enumerate(readcsv(w/'extended-phases/cases.csv')):
  n=r['spec'];ls.append((20+j,Path(n).stem,n,'',int(r['exit']),vf.reference(n)))
 return ls
if __name__=='__main__':
 bins={'g3':base,'native':native,'data256':w/'conditional-datatypes/data256/checker/goivy_check'}
 for v,b in bins.items():
  info=linked(b)if v!='native'else subprocess.check_output(['go','version','-m',b],text=True);(root/(v+'-info.txt')).write_text(info)
 with ThreadPoolExecutor(12)as ex:list(ex.map(lambda j:measure_spec(j,bins,3),jobs()))
