from common import *
from types import SimpleNamespace
from panel import measure,EVENTS
import holdouts as ho
rd=d/'apple2-ground-release-pairing';rd.mkdir(exist_ok=True)
def lane(j):
 i,cpu=j;_,n,sp,iso,rc,rf=ho.jobs()[0];bs={'before':d/'release-repeat-plans/checker/goivy_check','release':d/'release-ground-pool/checker/goivy_check','native':native};order=list(bs);cfg=SimpleNamespace(cpu=cpu,perf=perf,spec=examples/sp,isolate=iso)
 with (rd/f'rotation-{i+1}.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['spec','round','engine','cpu','exit','match','wall','user','sys','rss',*EVENTS])
  for v in order[i:]+order[:i]:
   sd=rd/f'{i+1}-{v}';ret,t,cts=measure(bs[v],cfg,sd,rc,100);matches=ret==rc and all((sd/k).read_bytes()==(rf/k).read_bytes()for k in('stdout','stderr'));z.writerow([n,i+1,v,cpu,ret,int(matches),*t,*cts]);f.flush();assert matches;print(i+1,v,int(cts[0])/1e9,flush=True)
def main():
 with ThreadPoolExecutor(3)as ex:list(ex.map(lane,enumerate([12,17,0])))
 rows=[r for f in sorted(rd.glob('rotation-*.csv'))for r in readcsv(f)];assert len(rows)==9 and all(int(r['match'])for r in rows)
 with(rd/'runs.csv').open('w')as f:z=csv.DictWriter(f,fieldnames=list(rows[0]));z.writeheader();z.writerows(rows)
if __name__=='__main__':main()
