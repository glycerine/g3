from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from statistics import median
import csv,fcntl,gzip,json,os,re,subprocess,sys,time
w=Path('/tmp/g3-nov23-day')
prior=Path('/tmp/g3-nov22b')
pkg=Path('/home/jaten/g3/pkg').resolve()
ivy=Path('/home/jaten/ivy/goivy')
examples=Path('/home/jaten/ivy/ivy-lang-examples')
perf=Path('/usr/lib/linux-tools/6.17.0-35-generic/perf')
env=dict(os.environ,GOCACHE=str(w/'cache'),GOMAXPROCS='4',PYTHONDONTWRITEBYTECODE='1',XTRACE_OFF='1')
def run(a,**kw):
 return subprocess.run(a,check=True,env=kw.pop('env',env),**kw)
def build(d,en='g3',o=None,shell=False):
 d.mkdir(parents=True,exist_ok=True)
 b=d/('g3'if shell else'goivy_check')
 c=['go','build','-p','6','-pgo=off','-buildvcs=false','-mod=readonly']
 if not shell:c+=['-modfile='+str(w/'local-checkout.mod')]
 if o:c+=['-overlay='+str(o)]
 if not shell:c+=['-tags=xtrace_off'+(',classic_z3' if en=='native' else '')]
 c+=['-o',str(b),'./cmd/g3' if shell else './cmd/goivy_check']
 with(w/'build.lock').open('a') as lock,(d/'build.log').open('w') as log:
  fcntl.flock(lock,fcntl.LOCK_SH)
  run(c,cwd=pkg if shell else ivy,stdout=log,stderr=log)
 if not shell and not(d/'abc').exists():(d/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
 return b
def overlay(d,edits):
 d.mkdir(parents=True,exist_ok=True);replace={}
 for path,s in edits.items():
  f=d/path.name;f.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
  replace[str(path)]=str(f)
  if path.is_relative_to(pkg):replace[str(Path('/home/jaten/g3/pkg')/path.relative_to(pkg))]=str(f)
  if path.is_relative_to(ivy.resolve()):replace[str(ivy/path.relative_to(ivy.resolve()))]=str(f)
 o=d/'overlay.json';o.write_text(json.dumps({'Replace':replace}));return o
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b)
def baseline():
 target=w/'baseline'
 with ThreadPoolExecutor(3)as ex:
  jobs=[ex.submit(build,target/e,e) for e in ('g3','native')]
  jobs.append(ex.submit(build,target/'shell',shell=True))
  for j in jobs:print(j.result(),flush=True)
if __name__=='__main__':baseline()
