from pathlib import Path
import sys
prior_day=Path('/tmp/g3-nov23-day')
sys.path.insert(0,str(prior_day))
from study import *
from collections import defaultdict,Counter
from statistics import median
d=Path('/tmp/g3-nov24-day')
base=w/'rows-final/checker/goivy_check'
native=w/'frontend-owned-production/after-native/goivy_check'
def linked(binary):
 info=subprocess.check_output(['go','version','-m',binary],text=True)
 assert '=>\t/home/jaten/g3/pkg\t(devel)' in info, binary
 return info
def readcsv(path):
 with path.open()as f:return list(csv.DictReader(f))
