from common import *
rd=d/'instance-worker-heap';rd.mkdir(exist_ok=True)
p=pkg/'api/api_ground_instances_test.go'
s=once(p.read_text(),'import (','import ("os";"runtime/pprof";')
s=once(s,'base := raftLiveHeap()','base := raftLiveHeap(); studyHeap(b,"base")')
s=once(s,'active += raftLiveHeap() - base','active += raftLiveHeap() - base;studyHeap(b,"active")')
s=once(s,'idle += raftLiveHeap() - base','idle += raftLiveHeap() - base;studyHeap(b,"closed")')
s+='\nfunc studyHeap(b *testing.B,which string){f,err:=os.Create(os.Getenv("G3_HEAP_DIR")+"/"+which+".pb");if err!=nil{b.Fatal(err)};err=pprof.WriteHeapProfile(f);if err!=nil{b.Fatal(err)};if err=f.Close();err!=nil{b.Fatal(err)}}\n'
def main():
 o=overlay(rd/'overlay',{p:s});b=rd/'heap.test'
 with(w/'build.lock').open('a')as lock,(rd/'build.log').open('w')as f:
  fcntl.flock(lock,fcntl.LOCK_SH);run(['go','test','-tags=xtrace_off','-overlay='+str(o),'-c','-o',b,'./api'],cwd=pkg,env=env,stdout=f,stderr=f)
 sd=rd/'eight';sd.mkdir(exist_ok=True)
 with(sd/'bench.log').open('w')as l:run(['taskset','-c','28',b,'-test.run=^$','-test.bench=^BenchmarkGroundInstanceWorkerMemory$','-test.cpu=1','-test.benchtime=1x','-test.memprofilerate=256'],env=dict(env,G3_HEAP_DIR=str(sd)),cwd=pkg/'api',stdout=l,stderr=l)
 for stat in ('inuse_space','alloc_space','inuse_objects','alloc_objects'):
  for stage in ('active','closed'):
   with(sd/f'{stage}-{stat}.txt').open('w')as l:run(['go','tool','pprof','-top','-nodecount=80','-sample_index='+stat,'-diff_base',sd/'base.pb',b,sd/(stage+'.pb')],env=env,stdout=l,stderr=l)
 print('all profiles',flush=True)
if __name__=='__main__':main()
