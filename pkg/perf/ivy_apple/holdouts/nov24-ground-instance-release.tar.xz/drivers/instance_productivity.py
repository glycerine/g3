from common import *
import stage_frontier as sf,macro_identity as mi,holdouts as ho
rd=d/'instance-productivity';rd.mkdir(exist_ok=True)
def main():
 p=pkg/'api/api_ground_instances.go';s=p.read_text()
 s=once(s,'import (','import (\n"os"\n"fmt"\n"time"')
 s=once(s,'pool             *order.GroundInstancePool','calls,wins,projected,unitsOnly,searchCalls int\n totalNS,projectNS,reduceNS,searchNS int64\n pool             *order.GroundInstancePool')
 s=once(s,'if err := s.sat.close(); err != nil {','if s.pool!=nil && s.calls>0{fmt.Fprintln(os.Stderr,"INST-POOL",s.calls,s.wins,s.projected,s.unitsOnly,s.searchCalls,s.totalNS,s.projectNS,s.reduceNS,s.searchNS)}\n if err := s.sat.close(); err != nil {')
 s=once(s,'if s.pool.Disabled() {\n\t\treturn false, nil','t0:=time.Now();defer func(){s.totalNS+=time.Since(t0).Nanoseconds();s.calls++;if proved{s.wins++}}()\n if s.pool.Disabled() {\n\t\treturn false, nil')
 x='q, err := s.pool.Project(goal, steps, minRules, limit)';s=once(s,x,'t:=time.Now();'+x+'\ns.projectNS+=time.Since(t).Nanoseconds();if q!=nil{s.projected++}')
 x='conflict, complete := q.Reduce(limit)';s=once(s,x,'t=time.Now();'+x+'\ns.reduceNS+=time.Since(t).Nanoseconds()')
 s=once(s,'if conflict {\n\t\treturn true, nil','if conflict {s.unitsOnly++;\n\t\treturn true, nil')
 s=once(s,'return s.search(src, m, q)','s.searchCalls++;t=time.Now();defer func(){s.searchNS+=time.Since(t).Nanoseconds()}();return s.search(src,m,q)')
 b=build(rd/'checker',o=overlay(rd/'overlay',{p:s}));(rd/'build-info.txt').write_text(linked(b))
 js=[j for j in sf.jobs()if j[1]in('hybrid','tlb','hermes_rmw_o3','ticket_protocol')]+ho.jobs()[:3]+[(c,*j[1:5],j[-1])for c,j in zip([2,5,10],(j for j in mi.jobs()if j[1]in('dramc_nb2','cf_live','rfn2')))]
 def one(j):
  cpu,n,sp,iso,rc,rf=j;sd=rd/n;sd.mkdir(exist_ok=True);args=['taskset','-c',str(cpu),b,*(['isolate='+iso]if iso else[]),examples/sp]
  with (sd/'pool.csv').open('w') as f:
   z=csv.writer(f);z.writerow('calls wins projected units_only searches wall_ns project_ns reduce_ns search_ns'.split())
   with (sd/'stdout').open('wb')as out,(sd/'stderr').open('wb')as err:
    proc=subprocess.Popen(args,cwd=sd,env=dict(env,GOMAXPROCS='1',GOGC='100'),stdout=out,stderr=subprocess.PIPE)
    for l in proc.stderr:
     if l.startswith(b'INST-POOL '):z.writerow(list(map(int,l.split()[1:])));f.flush()
     else:err.write(l)
    ret=proc.wait()
  assert ret==rc and all((rf/p).read_bytes()==(sd/p).read_bytes()for p in('stdout','stderr')),n
  rows=readcsv(sd/'pool.csv');print(n,len(rows),{k:sum(int(r[k])for r in rows)for k in('calls','wins','searches','wall_ns')},flush=True)
 with ThreadPoolExecutor(7)as e:list(e.map(one,js))
if __name__=='__main__':main()
