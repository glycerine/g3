from study import *
from panel import measure,EVENTS,CASES
from types import SimpleNamespace
import verification_frontier as vf,filecmp
d=w/'ground-release-controls';d.mkdir(exist_ok=True);paired=w/'frontend-controls/paired-build'
def corpus(b):
 import spec_survey
 old=w/'relation-selection-release/corpus';cases=(old/'specs.txt').read_text().splitlines()
 expected={int(row['index']):int(row['exit'])for p in old.glob('cpu-*.csv')for row in csv.DictReader(p.open())}
 cs=[1,7,10,17];rd=d/'corpus';rd.mkdir();cfg=SimpleNamespace(perf=perf,seconds=360,gogc=100)
 def lane(j):
  c,rs=j
  with(rd/f'{c}.csv').open('w')as f:
   wr=csv.writer(f);wr.writerow('index case exit timeout wall user sys rss instructions pass fail ok stdout stderr'.split())
   for i,sp in rs:
    p=rd/str(i);v=spec_survey.measure(cfg,examples/sp,b,p,c);matches=[int(filecmp.cmp(p/s,old/str(i)/'g3'/s,shallow=False))for s in ('stdout','stderr')]
    wr.writerow([i,sp,*v,*matches]);f.flush();assert v[0]==expected[i]and v[1]==0 and matches==[1,1],(sp,v,matches)
 with ThreadPoolExecutor(4)as ex:list(ex.map(lane,[(c,list(enumerate(cases))[i::4])for i,c in enumerate(cs)]))
 print('corpus',len(cases),flush=True)
def panel(x):
 c,n,sp,iso,ref,ex,b=x;p=d/n;p.mkdir();cfg=SimpleNamespace(cpu=c,perf=perf,spec=examples/sp,isolate=iso)
 with(p/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('round engine match exit wall user sys rss'.split()+list(EVENTS))
  bs={'current':b,'previous':paired/'g3/goivy_check','native':paired/'native/goivy_check'}
  for i in range(3):
   ks=list(bs);ks=ks[i:]+ks[:i]
   for k in ks:
    sd=p/f'{i+1}-{k}';rc,t,cs=measure(bs[k],cfg,sd,ex,100);ok=rc==ex and all((sd/z).read_bytes()==(ref/z).read_bytes()for z in ('stdout','stderr'));wr.writerow([i+1,k,int(ok),rc,*t,*cs]);f.flush();assert ok,(sd,rc)
 print(n,flush=True)
def main():
 b=build(d/'checker');js=[]
 for c,n in [(1,'rfn2'),(3,'cf_live'),(6,'dramc_nb2'),(12,'raft_no_assume_test')]:
  sp,iso,*_=CASES[n];js.append((c,n,sp,iso,next((prior/'end-panel-final').glob('*/'+n+'/1/g3')),0,b))
 for c,i in [(8,0),(9,1),(13,2),(18,3)]:
  sp=vf.cases[i];ref=vf.reference(sp);js.append((c,Path(sp).stem,sp,'',ref,int(b'FAIL'in(ref/'stdout').read_bytes()),b))
 def whole():
  run([sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',b,'--previous',paired/'g3/goivy_check','--native',paired/'native/goivy_check','--cpu','20','--rounds','3','--max-attempts','12','--spec',examples/'jea/hermes_rmw_o3_testing.ivy','--reference',w/'extended-phases/long/1/1/native','--perf',perf,'--output',d/'whole'],stdout=subprocess.DEVNULL)
  print('whole',flush=True)
 with ThreadPoolExecutor(10)as e:
  fs=[e.submit(whole),e.submit(corpus,b)]+[e.submit(panel,j)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
