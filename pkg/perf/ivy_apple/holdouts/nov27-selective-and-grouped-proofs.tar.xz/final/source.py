from pathlib import Path
import json,subprocess
p=Path.cwd()
w=Path(__file__).resolve().parent
src=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
key=src/'z3bridge_solver_model.go'
s=key.read_text()
o='\t\tfor _, fc := range finalCond {'
assert s.count(o)==1
s=s.replace(o,'''\t\t// Only the g3 batch supplies a pre-push proof operation. Once it needs
        // concrete search, sibling equalities can share one refutation.
        groupEqualities := proveGoal != nil && !s.showVCsEnabled()
        nextGroup, provenThrough := 0, 0
        for index, fc := range finalCond {''')
o='\t\t\t\tzCond, err := s.ClausesToZ3(cond)\n'
pos=s.index(o,s.index('s.showVCsFinalCond("assert", cond)'))
s=s[:pos]+'''                if index < provenThrough {
                    overallResult = smt.Unsat
                    fc.Unsat()
                    continue
                }
'''+s[pos:]
o='\t\t\t\tif s.opts.Incremental {\n\t\t\t\t\tz3solver.Push()'
assert s.count(o)==1
s=s.replace(o,'''                if groupEqualities && index >= nextGroup && len(finalCond)-index >= 3 {
                    count := guardedEqualityCount(finalCond[index:])
                    nextGroup = index + count
                    if count >= 3 && s.proveGuardedEqualities(z3solver, zCond, finalCond[index+1:nextGroup]) {
                        provenThrough = nextGroup
                        overallResult = smt.Unsat
                        fc.Unsat()
                        continue
                    }
                }
'''+o)
v=w/key.name;v.write_text(s)
helper=src/'z3bridge_guarded_equalities.go'
(w/helper.name).write_text('''package goivy

import "github.com/glycerine/ivy/goivy/smt"

// guardedEqualityCount finds consecutive, static counterexample conditions of
// the form !(guard => equality) with a shared conjunctive guard. Leave other
// checkers in their original callback and assertion order.
func guardedEqualityCount(conditions []FinalCond) int {
    var first Expr
    for i, condition := range conditions {
        if i == 16 {
            return i
        }
        checker, ok := condition.(*ConjChecker)
        if !ok || checker.FC == nil || len(checker.FC.Defs) != 0 || len(checker.FC.Fmlas) != 1 {
            return i
        }
        neg, ok := checker.FC.Fmlas[0].(*LogicNot)
        if !ok { return i }
        implication, ok := neg.Body.(*LogicImplies)
        if !ok { return i }
        guard, ok := implication.T1.(*LogicAnd)
        if !ok || len(guard.Terms) < 2 { return i }
        switch implication.T2.(type) {
        case *Eq, *LogicIff:
        default:
            return i
        }
        if i == 0 { first = guard } else if !first.Equal(guard) { return i }
    }
    return len(conditions)
}

// An unsatisfiable disjunction refutes every original counterexample condition.
// Keep each condition intact, including constraints introduced during translation.
// An inconclusive group or a satisfiable group goes back to the individual
// checks so the first failing obligation can return its own model.
func (s *Solver) proveGuardedEqualities(zs *smt.Z3Solver, first smt.Z3Expr, rest []FinalCond) bool {
    goals := make([]smt.Z3Expr, 1, 1+len(rest))
    goals[0] = first
    for _, condition := range rest {
        goal, err := s.ClausesToZ3(condition.(*ConjChecker).FC)
        if err != nil { return false }
        goals = append(goals, zs.SimplifyVerificationCondition(goal))
    }
    zs.Push()
    defer zs.Pop()
    zs.Assert(s.tr.Ctx.Or(goals...))
    return zs.Check() == smt.Unsat
}
''')
subprocess.run(['gofmt','-w',v,w/helper.name],check=True)
j=w/'overlay.json';j.write_text(json.dumps({'Replace':{str(key):str(v),str(helper):str(w/helper.name)}}))
fl=['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve())]
for mode,extra in [('base',[]),('release',['-overlay',j])]:
 subprocess.run([*fl,*extra,'-o',w/mode,'./cmd/goivy_check'],cwd=src,check=True)
