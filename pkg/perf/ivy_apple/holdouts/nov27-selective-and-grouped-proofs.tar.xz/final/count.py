from pathlib import Path
import os,json,subprocess,csv,concurrent.futures
p=Path.cwd();w=Path(__file__).resolve().parent
o=json.loads((w/'overlay.json').read_text());helper=next(k for k in o['Replace'] if 'equalities.go' in k)
src=Path(o['Replace'][helper]).read_text().replace('return zs.Check() == smt.Unsat','answer:=zs.Check();println("GROUP-COUNT", len(goals),int(answer));return answer == smt.Unsat')
f=w/'counter.go.txt';f.write_text(src);o['Replace'][helper]=str(f);j=w/'counter.json';j.write_text(json.dumps(o))
front=Path(helper).parent
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'counts','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');names=(rank/'compat.txt').read_text().splitlines()
codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
ex=Path('/home/jaten/ivy/ivy-lang-examples')
def run(task):
 i,name=task;ref=rank/'compat'/str(i+1)/'1/native'
 r=subprocess.run([w/'counts',ex/name],cwd='/tmp/g3-frame-child',capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
 keep=[];out=[]
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'GROUP-COUNT '):
   _,size,ans=line.split();out.append((name,int(size),int(ans)))
  else:keep.append(line)
 assert (r.returncode,r.stdout,b''.join(keep))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),name
 return out or [(name,0,'')]
with (w/'counts.csv').open('w') as f,concurrent.futures.ThreadPoolExecutor(6) as pool:
 out=csv.writer(f);out.writerow(['case','group_size','result'])
 for rows in pool.map(run,enumerate(names)):out.writerows(rows);f.flush()
