from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
front=Path('/home/jaten/ivy/goivy').resolve()
f=w/'z3bridge_guarded_equalities_test.go';subprocess.run(['gofmt','-w',f],check=True)
o=json.loads((w/'overlay.json').read_text());o['Replace']={str(front/Path(k).name):v for k,v in o['Replace'].items()};o['Replace'][str(front/f.name)]=str(f);j=w/'tests.json';j.write_text(json.dumps(o))
for tags in ['xtrace_off','xtrace_off,classic_z3']:
 subprocess.run(['go','test','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags',tags,'-overlay',j,'.','-run','Test(GuardedEqualityBatch|GetSmallModelFinalCondAssumeOrderMatchesPython|Z3Bridge.*(Scope|Model|FinalCond))','-count=1','-timeout=4m'],cwd=front,check=True)
