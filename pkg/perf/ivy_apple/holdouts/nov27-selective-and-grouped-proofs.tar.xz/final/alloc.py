from pathlib import Path
import csv,json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
main=front/'cmd/goivy_check/main.go';src=main.read_text()
src=src.replace('import (','import ("runtime/pprof";"runtime";',1) if '"runtime"' not in src else src.replace('import (','import ("runtime/pprof";',1)
src=src.replace('os.Exit(goivy.MainWithConfig(args, cfg))','''var before, after runtime.MemStats
    runtime.ReadMemStats(&before)
    n:=goivy.MainWithConfig(args,cfg)
    runtime.ReadMemStats(&after)
    println("HEAP-STUDY",after.TotalAlloc-before.TotalAlloc,after.Mallocs-before.Mallocs,after.NumGC-before.NumGC,after.HeapAlloc)
    if name:=os.Getenv("HYBRID_PROFILE");name!=""{
        runtime.GC();runtime.GC()
        f,e:=os.Create(name);if e!=nil{panic(e)}
        if e=pprof.Lookup("allocs").WriteTo(f,0);e!=nil{panic(e)};if e=f.Close();e!=nil{panic(e)}
    }
    os.Exit(n)''');assert 'HEAP-STUDY' in src
v=w/'heap-main.go.txt';v.write_text(src)
o=json.loads((w/'overlay.json').read_text());o['Replace'][str(main)]=str(v)
j=w/'alloc.json';j.write_text(json.dumps(o));ex=Path('/home/jaten/ivy/ivy-lang-examples')
ref=Path('/tmp/g3-reduction-rows/compat/2/1/native')
with (w/'alloc.csv').open('w') as f:
 out=csv.writer(f);out.writerow('engine round bytes objects collections heap_end'.split())
 for e,tags in [('g3','xtrace_off'),('native','xtrace_off,classic_z3')]:
    exe=w/('alloc-'+e)
    subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags',tags,'-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
    for i in range(3):
        prof=w/('hybrid-'+e+'.pb')
        r=subprocess.run(['taskset','-c','18',exe,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd='/tmp/g3-frame-child',capture_output=True,timeout=60,check=True,env=dict(os.environ,GOGC='100',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),HYBRID_PROFILE=str(prof) if i==2 else ''))
        lines=r.stderr.splitlines(keepends=True);assert r.stdout==(ref/'stdout').read_bytes() and b''.join(l for l in lines if not l.startswith(b'HEAP-STUDY '))==(ref/'stderr').read_bytes()
        row,=[l.decode().split()[1:] for l in lines if l.startswith(b'HEAP-STUDY ')];out.writerow([e,i,*row]);f.flush()
    for typ in ['alloc_space','alloc_objects']:
        with (w/(e+'-'+typ+'.txt')).open('w') as dest: subprocess.run(['go','tool','pprof','-top','-nodecount=30','-'+typ,exe,prof],stdout=dest,check=True)
