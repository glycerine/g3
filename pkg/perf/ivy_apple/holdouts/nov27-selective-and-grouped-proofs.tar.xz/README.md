# Ticket proof learning and grouped sibling obligations

The work that shipped is GoIvy 4b548dc4b on top of 792f425e9, measured with
g3 e977d5f08. final/release.patch contains the exact frontend change and
its regression. Run the portable regression from the GoIvy module with
`go test . -run '^TestGuardedEqualityBatch$' -count=1`. To time a complete
verification independently, build cmd/goivy_check and run it with
GOIVY_INCLUDE pointing at ivy/include in ivy-lang-examples and the full
POPL18 ticket_protocol.ivy path from final/complete.csv. Build the linked
control with tags xtrace_off,classic_z3. The measured g3 binaries used
xtrace_off and the repository's nov27-raft-tlb-sat-smt.pprof PGO profile.

For selective learning and grouped CLI replay, extract the immediately
preceding nov27-ticket-matched-siblings.tar.xz into a scratch directory.
Its reuse/ directory contains the 994 original SMT snapshots, term parser
and check weights. Build the g3 CLI using go build -o /tmp/g3-cli ./cmd/g3.
From this archive run:

    python3 selective.py /path/to/previous/archive /tmp/g3-cli --cpu 2 --perf /path/to/perf
    python3 group.py /path/to/previous/archive /tmp/g3-cli --cases 3 --cpu 2 --perf /path/to/perf

popl.csv contains selective training costs. group3.csv contains grouped CLI
replay. whole.csv and holdouts.csv measure unrestricted groups. adaptive.csv
uses the preceding individual check time. screen.csv tries the private proof
before joint search. compound.csv compares no grouping (1), a shared guard
(16), a shared compound guard (116) and the lookahead-only control (216).
equalities.csv uses the static GoIvy prefilter and disjoins complete conditions.
native.csv applies the same candidate to native Z3. Each counted outcome in
final/counts.csv is negative one for UNSAT. A zero size marks an input on which
the fast path never ran.

The GoIvy overlay and replay builders record the study machine's original CPU
numbers and filesystem paths. The prerelease frontends, Ivy examples, PGO
profile, external ABC helper and the 228 native golden transcripts are required
to run the complete verification panel. Adapt paths in the drivers on a different
host. deps/ retains the shared benchmark drivers, reference inventory and original
instrumentation from prior work. The earlier ceiling study documents the frontend
snapshot layout. The preliminary guard.py backend-kind probe is superseded by
compound.py, which reads the backend's actual implication declaration kind.
checked-panel*.csv and eq-panel*.csv are the corrected experimental panels.

final/complete.csv and final/panel*.csv are the production-candidate timings and
transcript comparisons. final/recheck.csv and final/otherhits.csv repeat selected
inputs. final/{raft_no_assume,rfn2,dramc_nb2}/long.csv check the longer holdouts.
hybrid-ranking.csv ranks ordinary check windows and hybrid-stage-summary.csv
also measures the other phases. All commit/build data here are local snapshots;
no generated Go overlay is needed to run the shipped code.
