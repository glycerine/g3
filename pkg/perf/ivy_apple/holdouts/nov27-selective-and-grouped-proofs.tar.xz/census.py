from pathlib import Path
import os,csv,subprocess
w=Path(__file__).resolve().parent
s=(w/'frontend.py').read_text()
code='''
s=s.replace('s.showVCsBase(clauses)','s.showVCsBase(clauses); batch:=newStageBatch()')
s=s.replace('ans:=z3solver.Check()', 'finish:=startStage(batch,ordinal+1);ans:=z3solver.Check();finish(fmt.Sprintf("group-%d-%v",len(goals),ans))')
s=s.replace('res, err := s.decideZ3With(z3solver, finalCheck)','finish:=startStage(batch,ordinal+1);res, err := s.decideZ3With(z3solver, finalCheck);finish("single")')
'''
s=s.replace("overlay=w/'group.go.txt';",code+"overlay=w/'census.go.txt';").replace("'overlay.json'","'census.json'").replace("str(f):str(overlay)","str(f):str(overlay),str(f.parent/'window_study.go'):str(w/'window.go.txt')").replace("w/'group',","w/'census',")
(w/'window.go.txt').write_text(Path('/tmp/g3-ticket-focus/reuse/weight-window.go').read_text())
exec(s)
names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'census.csv').open('w') as f:
    out=csv.writer(f)
    out.writerow('case width batch ordinal phase instructions ns'.split())
    for nr in [3,2,5,11,6,8,12]:
        for width in [1,16]:
            r=subprocess.run(['taskset','-c','18',w/'census',ex/names[nr-1]],cwd='/tmp/g3-frame-child',env=dict(os.environ,GROUP_WIDTH=str(width),GOMAXPROCS='1',GOGC='off',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=False,timeout=30)
            ref=Path('/tmp/g3-reduction-rows/compat')/str(nr)/'1/native'
            assert r.returncode==next(int(z["exit"]) for z in csv.DictReader(open("/tmp/g3-reduction-rows/ranking.csv")) if z["case"]==names[nr-1]),r.stderr[-400:]
            keep=[]
            for line in r.stderr.splitlines(keepends=True):
                if line.startswith(b'STAGE-COUNT '):
                    _,b,g,phase,count,empty,en,run,ns=line.decode().split()
                    assert en==run
                    out.writerow([nr,width,b,g,phase,count,ns])
                else:keep.append(line)
            assert (r.stdout,b''.join(keep))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
            f.flush()
