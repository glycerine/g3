"""Compare ordinary batch replay with selectively tracked goals using an independent solver."""
import argparse
import collections
import csv
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("archive", type=Path, help="extracted Ticket archive with reuse/ snapshots")
parser.add_argument("cli", type=Path)
parser.add_argument("--case", type=int, default=3)
parser.add_argument("--cpu", default="20")
parser.add_argument("--perf", default="perf")
parser.add_argument("--rounds", type=int, default=3)
args = parser.parse_args()
sys.path.insert(0, str(args.archive / "reuse"))
from analyze import compatible, data

terms, history, declarations, _ = data(args.case)
batches = collections.defaultdict(list)
for i, (batch, goal, base, query) in enumerate(history):
    batches[batch].append(i)
samples = collections.defaultdict(list)
for r in csv.DictReader((args.archive / "reuse/weights.csv").open()):
    if int(r["case"]) == args.case and r["engine"] == "g3":
        samples[int(r["batch"]), int(r["goal"])].append(int(r["instructions"]))

def weight(i):
    return statistics.median(samples.get(history[i][:2], [0]))

def run(ids, tracked):
    if not ids:
        return 0, {}
    order = sorted(history[ids[0]][2])
    signature = {}
    for i in ids:
        assert history[i][2] == set(order)
        for k, v in declarations[i].items():
            assert signature.setdefault(k, v) == v
    lines = ["(set-option :produce-unsat-cores true)"] if tracked else []
    lines.extend(terms.render(v) for vs in signature.values() for v in sorted(vs))
    labels = ["focus-selector-%d" % j for j in range(len(order))]
    assert not set(labels).intersection(signature)
    for label, term in zip(labels, order):
        expr = terms.render(term)
        if tracked:
            lines.append(f"(declare-const {label} Bool)")
            expr = f"(=> {label} {expr})"
        lines.append(f"(assert {expr})")
    for i in ids:
        expr = " ".join(terms.render(v) for v in sorted(history[i][3]))
        lines.extend(["(push 1)", f"(assert (and {expr}))"])
        if tracked:
            lines.extend(["(check-sat-assuming (" + " ".join(labels) + "))", "(get-unsat-core)"])
        else:
            lines.append("(check-sat)")
        lines.extend(["(pop 1)", '(echo "END")'])
    with tempfile.NamedTemporaryFile() as counts:
        cmd = ["taskset", "-c", args.cpu, args.perf, "stat", "-x,", "-o", counts.name,
               "-e", "instructions:u", "--", args.cli, "smt.macro_finder=true", "-in"]
        result = subprocess.run(cmd, input="\n".join(lines)+"\n", capture_output=True, text=True,
                                check=True, timeout=90, env=dict(os.environ, GOMAXPROCS="1", GOGC="100"))
        count, = [int(r[0]) for r in csv.reader(Path(counts.name).read_text().splitlines())
                  if len(r)>4 and r[2]=="instructions:u" and float(r[4])==100]
    parts = result.stdout.replace('"END"', 'END').split('END')
    assert len(parts)==len(ids)+1 and not parts[-1].strip(), result.stdout[-200:]
    cores = {}
    for i, part in zip(ids, parts):
        lines = part.strip().splitlines()
        assert lines[0] == 'unsat', (i, part)
        if tracked:
            core = " ".join(lines[1:])
            assert re.fullmatch(r'\((?:\s*focus-selector-\d+)*\s*\)', core), core
            cores[i] = frozenset(order[int(j)] for j in re.findall(r'focus-selector-(\d+)', core))
        else:
            assert len(lines)==1
    return count, cores

def replay(rotation, threshold):
    cache = collections.defaultdict(list)
    prior = collections.defaultdict(list)
    for batch, ids in batches.items():
        ordinary, training, hits = [], [], []
        for i in ids:
            _, _, base, query = history[i]
            j = next((old for old, core in cache[query]
                      if core<=base and compatible(declarations[i], declarations[old])), None)
            if j is not None:
                hits.append((i,j))
            elif threshold >= 0 and any(weight(old)>=threshold and compatible(declarations[old],declarations[i])
                                        for old in prior[query]):
                training.append(i)
            else:
                ordinary.append(i)
        plain_cost, _ = run(ordinary, False)
        train_cost, cores = run(training, True)
        for i, core in cores.items():
            cache[history[i][3]].append((i, core))
        for i in ordinary+training:
            prior[history[i][3]].append(i)
        # Payload excludes indexes, term storage, declarations, and allocator overhead.
        payload = sum(4*len(core) for entries in cache.values() for _,core in entries)
        writer.writerow([rotation,threshold,batch,len(ids),len(ordinary),len(training),len(hits),
                         sum(weight(i) for i,j in hits),plain_cost,train_cost,payload])
        sys.stdout.flush()
        if rotation==0:
            for i,j in hits:
                core = cores.get(j)
                if core is None:
                    core = next(c for old,c in cache[history[i][3]] if old==j)
                source = [terms.render(v) for vs in declarations[i].values() for v in sorted(vs)]
                source.extend("(assert "+terms.render(v)+")" for v in sorted(core|history[i][3]))
                result = subprocess.run([args.cli,"smt.macro_finder=true","-in"],
                    input="\n".join(source+["(check-sat)"])+"\n",capture_output=True,text=True,check=True,timeout=30)
                assert result.stdout.strip()=="unsat", (i,j,result.stdout)

writer = csv.writer(sys.stdout)
writer.writerow("round threshold batch checks plain trained hits hit_weight plain_ins train_ins core_id_bytes".split())
modes = [-1, 0, 1000000, 5000000, 20000000]
for r in range(args.rounds):
    for threshold in modes[r:]+modes[:r]:
        replay(r, threshold)
