from pathlib import Path
s=(Path(__file__).resolve().parent/'whole.py').read_text().replace("w/'group'","w/'adaptive'").replace('GROUP_WIDTH=m','GROUP_WIDTH=("1" if m=="off" else "16"),GROUP_MIN_US=m')
exec(s)
