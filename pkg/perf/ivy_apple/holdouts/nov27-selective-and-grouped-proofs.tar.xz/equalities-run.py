from pathlib import Path
s=(Path(__file__).resolve().parent/'whole.py').read_text().replace("w/'group'","w/'equalities'").replace("timeout=12'","timeout=60'")
exec(s)
