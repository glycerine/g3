from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'frontend.py').read_text()
extra="""
s=s.replace('provenThrough, triedThrough:=0,0','''provenThrough, triedThrough:=0,0
        surfaceGuard:=func(fc FinalCond)Expr{
            c,ok:=fc.(*ConjChecker);if !ok || c.FC==nil || len(c.FC.Fmlas)!=1 || len(c.FC.Defs)!=0{return nil}
            n,ok:=c.FC.Fmlas[0].(*LogicNot);if !ok{return nil}
            imp,ok:=n.Body.(*LogicImplies);if !ok{return nil}
            g,ok:=imp.T1.(*LogicAnd);if !ok || len(g.Terms)<2{return nil}
            switch imp.T2.(type){case *Eq,*LogicIff:return g}
            return nil
        }''')
s=s.replace('if _,ok:=fc.(*ConjChecker);ok {','''if guard:=surfaceGuard(fc);guard!=nil && ordinal+2<len(finalCond) {
                        end:=ordinal+1
                        for end<len(finalCond) && end-ordinal<width {g:=surfaceGuard(finalCond[end]);if g==nil||!guard.Equal(g){break};end++}
                        triedThrough=end
                        if end-ordinal>=3 {''')
s=s.replace('j<len(finalCond)&&len(goals)<width','j<end')
s=s.replace('triedThrough=ordinal+len(goals)','end=ordinal+len(goals)')
s=s.replace('provenThrough=triedThrough','provenThrough=end')
s=s.replace('                    }\\n                }\\n                if s.opts.Incremental {','                    }}\\n                }\\n                if s.opts.Incremental {')
"""
s=s.replace("overlay=w/'group.go.txt';",extra+"overlay=w/'equalities.go.txt';").replace("'overlay.json'","'equalities.json'").replace("w/'group',","w/'equalities',")
exec(s)
