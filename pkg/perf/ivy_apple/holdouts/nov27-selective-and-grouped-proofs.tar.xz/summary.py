from pathlib import Path
import statistics as st,csv,collections
w=Path(__file__).resolve().parent
summ=[]
def whole(filename,base,comp):
 z=collections.defaultdict(lambda:collections.defaultdict(dict))
 for r in csv.DictReader((w/(filename+'.csv')).open()):
    assert r['status']=='match',r
    z[r['case']][int(r['round'])][r['mode']]=int(r['instructions']),float(r['ms'])
 for c,rs in z.items():
    for k in comp:
        v=[(r[base],r[k]) for r in rs.values() if k in r and base in r]
        if not v:continue
        v0,v1=zip(*v)
        med=lambda v,i:st.median(x[i] for x in v)
        delta=lambda i:st.median(100*(b[i]/a[i]-1) for a,b in v)
        summ.append([filename,c,base,k,len(v),round(med(v0,0)),round(med(v1,0)),round(delta(0),2),round(med(v0,1),2),round(med(v1,1),2),round(delta(1),2)])
for f,base,modes in [('whole','1',['8','16']),('holdouts','1',['16']),('adaptive','off',['300','1000']),('screen','1',['16']),('compound','1',['16','116','216']),('equalities','1',['16']),('native','1',['16']),('final/complete','base',['release','native']),('final/recheck','base',['release']),('final/otherhits','base',['release'])]:
 whole(f,base,modes)
for n in ['rfn2','dramc_nb2','raft_no_assume']:
 whole('final/'+n+'/long','base',['release'])
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('experiment case baseline mode pairs baseline_ins result_ins paired_ins_pct baseline_ms result_ms paired_ms_pct'.split());out.writerows(summ)
a=collections.defaultdict(list)
for r in csv.DictReader((w/'popl.csv').open()):a[int(r['threshold']),int(r['round'])].append(r)
with (w/'training-summary.csv').open('w') as f:
 o=csv.writer(f);o.writerow('threshold ordinary trained hits saved_window_M solver_M core_id_bytes'.split())
 for q in [-1,0,1000000,5000000,20000000]:
    rs=[v for (t,_),v in a.items() if t==q]
    totals=lambda k:st.median(sum(float(r[k]) for r in v) for v in rs)
    ins=st.median(sum(int(r['plain_ins'])+int(r['train_ins']) for r in v) for v in rs)
    o.writerow([q,int(totals('plain')),int(totals('trained')),int(totals('hits')),round(totals('hit_weight')/1e6,2),round(ins/1e6,2),rs[0][-1]['core_id_bytes']])
