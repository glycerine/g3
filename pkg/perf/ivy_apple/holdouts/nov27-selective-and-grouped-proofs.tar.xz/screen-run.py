from pathlib import Path
s=(Path(__file__).resolve().parent/'whole.py').read_text().replace("w/'group'","w/'screen'")
exec(s)
