"""Experimental GoIvy overlay. Only known static ConjChecker conditions can be grouped."""
from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent
p=Path.cwd()
f=(p/'build/.boolean-enode-cost/frontend/goivy/z3bridge_solver_model.go').resolve()
s=f.read_text().replace('"sort"','"sort"\n"strconv"',1)
old='for _, fc := range finalCond {'
assert s.count(old)==1
s=s.replace(old,'''width,_:=strconv.Atoi(os.Getenv("GROUP_WIDTH"))
        provenThrough, triedThrough:=0,0
        for ordinal, fc := range finalCond {''')
k='finalCheck := check'
assert s.count(k)==1
s=s.replace(k,'''if ordinal<provenThrough {overallResult=smt.Unsat;fc.Unsat();continue}
                '''+k)
k='if s.opts.Incremental {\n\t\t\t\t\tz3solver.Push()'
assert s.count(k)==1
s=s.replace(k,'''if width>1 && ordinal>=triedThrough && s.opts.Incremental && (!xtracer.Enabled || xtracer.Suppressed) {
                    if _,ok:=fc.(*ConjChecker);ok {
                        goals:=[]smt.Z3Expr{zCond}
                        for j:=ordinal+1;j<len(finalCond)&&len(goals)<width;j++{
                            c,ok:=finalCond[j].(*ConjChecker);if !ok || c.FC==nil {break}
                            v,e:=s.ClausesToZ3(c.FC);if e!=nil {break}
                            goals=append(goals,z3solver.SimplifyVerificationCondition(v))
                        }
                        triedThrough=ordinal+len(goals)
                        if len(goals)>1 {
                            z3solver.Push()
                            z3solver.Assert(s.tr.Ctx.Or(goals...))
                            ans:=z3solver.Check()
                            z3solver.Pop()
                            if ans==smt.Unsat {provenThrough=triedThrough;overallResult=smt.Unsat;fc.Unsat();continue}
                        }
                    }
                }
                '''+k)
overlay=w/'group.go.txt'; overlay.write_text(s)
o=w/'overlay.json';o.write_text(json.dumps({'Replace':{str(f):str(overlay)}}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'group','./cmd/goivy_check'],cwd=f.parent,check=True)
