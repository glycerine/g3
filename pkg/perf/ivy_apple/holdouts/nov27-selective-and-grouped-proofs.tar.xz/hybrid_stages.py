from pathlib import Path
import os,csv,json,collections,statistics,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
original=Path('/tmp/g3-ticket-stages/bridge.go.txt')
s=original.read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');prefix,s=s[:i],s[i:]
s=s.replace('end("new")','end("new");end=startStage(batch,0)',1)
s=s.replace('z3solver.Assert(zc)','z3solver.Assert(zc);end("base-translate-assert")',1)
s=s.replace('s.showVCsFinalCond("assert", cond)','s.showVCsFinalCond("assert", cond);translation:=startStage(batch,ordinal+1)',1)
s=s.replace('zCond, err := s.ClausesToZ3(cond)\n\t\t\t\tif err != nil {\n\t\t\t\t\tcontinue\n\t\t\t\t}\n\t\t\t\tfinalCheck','zCond, err := s.ClausesToZ3(cond);translation("goal-translate")\n\t\t\t\tif err != nil {\n\t\t\t\t\tcontinue\n\t\t\t\t}\n\t\t\t\tfinalCheck',1)
assert 'translation("goal-translate")' in s
s=s.replace('z3solver.Reset()\n\t\treturn nil, nil','end=startStage(batch,0);z3solver.Reset();end("reset")\n\t\treturn nil, nil',1)
f=w/'hybrid-stages.go.txt';f.write_text(prefix+s)
j=w/'hybrid-stages.json';j.write_text(json.dumps({'Replace':{str(front/'z3bridge_solver_model.go'):str(f),str(front/'stage_study.go'):str(w/'window.go.txt')}}))
for e,tags in [('g3','xtrace_off'),('z3','xtrace_off,classic_z3')]:
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags',tags,'-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/('stages-'+e),'./cmd/goivy_check'],cwd=front,check=True)
s=(w/'hybrid.py').read_text()
s=s[:s.index('groups=collections.')].replace("d/('all-window-'+engine)","w/('stages-'+engine)").replace("'hybrid.csv'","'hybrid-stages.csv'").replace("goal instructions","goal stage instructions").replace("and phase=='check'","").replace("i,b,g,n]","i,b,g,phase,n]")
exec(s)
a=collections.Counter()
for r in csv.DictReader((w/'hybrid-stages.csv').open()):a[r['engine'],int(r['round']),r['stage']]+=int(r['instructions'])
with (w/'hybrid-stage-summary.csv').open('w') as f:
 o=csv.writer(f);o.writerow('stage g3 z3 difference'.split())
 for stage in sorted(set(k[2] for k in a)):
  g,z=[int(statistics.median(a[e,i,stage] for i in range(5))) for e in ['g3','z3']];o.writerow([stage,g,z,g-z])
