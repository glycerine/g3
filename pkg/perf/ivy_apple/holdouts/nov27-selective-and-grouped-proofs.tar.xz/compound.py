from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'guard.py').read_text()
new="""
k=f.parent/'smt/g3_inspect.go'
inspect=w/'compound-inspect.go.txt'
inspect.write_text(k.read_text()+'\\nconst StudyImplies DeclKind = DeclKind(api.APIDeclarationImplies)\\n')
s=s[:s.index('var impliesKind smt.DeclKind')]+s[s.index('guardParts:=func'):]
s=s.replace('inner.IsAppOf(impliesKind)','inner.IsAppOf(smt.StudyImplies)')
s=s.replace('return inner.Arg(0),s.tr.Ctx.Not(inner.Arg(1)),true','''a:=inner.Arg(0)
                    if width<100 || (a.IsAppOf(smt.DeclAnd) && a.NumArgs()>=2) {
                        return a,s.tr.Ctx.Not(inner.Arg(1)),true
                    }''')
s=s.replace('len(goals)<width','len(goals)<width%100')
s=s.replace('if len(goals)>1 {','if len(goals)>1 && width<200 {')
"""
anchor="exec(s)"
s=s[:s.rindex(anchor)]+'''s=s.replace("overlay=w/'guard.go.txt';",new+"overlay=w/'compound.go.txt';").replace("str(f):str(overlay)","str(f):str(overlay),str(k):str(inspect)").replace("'guard.json'","'compound.json'").replace("w/'guard',","w/'compound',")
exec(s)
'''
exec(s)
