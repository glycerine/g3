from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'frontend.py').read_text()
key="overlay=w/'group.go.txt';"
code='''
s=s.replace('"strconv"', '"strconv";"time"')
s=s.replace('provenThrough, triedThrough:=0,0','minUsec,_:=strconv.Atoi(os.Getenv("GROUP_MIN_US"));lastUsec:=int64(0);provenThrough, triedThrough:=0,0')
s=s.replace('ordinal>=triedThrough &&','ordinal>=triedThrough && lastUsec>=int64(minUsec) &&')
s=s.replace('ans:=z3solver.Check()','ans:=z3solver.Check();lastUsec=0')
s=s.replace('res, err := s.decideZ3With(z3solver, finalCheck)','sampleStart:=time.Now();res, err := s.decideZ3With(z3solver, finalCheck);lastUsec=time.Since(sampleStart).Microseconds()')
'''
s=s.replace(key,code+key).replace("'group.go.txt'","'adaptive.go.txt'").replace("'overlay.json'","'adaptive.json'").replace("w/'group',","w/'adaptive',")
exec(s)
