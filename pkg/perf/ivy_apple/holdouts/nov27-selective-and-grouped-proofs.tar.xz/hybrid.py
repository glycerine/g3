"""Rank complete Hybrid broadcast check windows on the pair used for the Ticket core study."""
from pathlib import Path
import os,csv,statistics,subprocess,collections
w=Path(__file__).resolve().parent;d=Path('/wd_black1tb/home/jaten/tmp/g3-ticket-focus');ex=Path('/home/jaten/ivy/ivy-lang-examples')
name='examples/liveness/hybrid_reliable_broadcast_cisa.ivy'
ref=Path('/tmp/g3-reduction-rows/compat/2/1/native')
with (w/'hybrid.csv').open('w') as f:
 out=csv.writer(f);out.writerow('engine round batch goal instructions'.split())
 for i in range(5):
  for engine in ['g3','z3'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','18',d/('all-window-'+engine),ex/name],cwd='/tmp/g3-frame-child',capture_output=True,timeout=60,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
   keep=[]
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'STAGE-COUNT '):
     _,b,g,phase,n,empty,en,run,ns=line.decode().split();assert en==run and phase=='check';out.writerow([engine,i,b,g,n])
    else:keep.append(line)
   assert (r.returncode,r.stdout,b''.join(keep))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
   f.flush()
groups=collections.defaultdict(list)
for r in csv.DictReader((w/'hybrid.csv').open()):groups[r['engine'],int(r['batch']),int(r['goal'])].append(int(r['instructions']))
assert all(len(v)==5 for v in groups.values())
rows=[]
for b,g in set((b,g) for engine,b,g in groups):
 vals=[int(statistics.median(groups.get((e,b,g),[0]))) for e in ['g3','z3']]
 rows.append([b,g,*vals,vals[0]-vals[1]])
with (w/'hybrid-ranking.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal g3 z3 difference'.split());out.writerows(sorted(rows,key=lambda r:-r[-1]))
