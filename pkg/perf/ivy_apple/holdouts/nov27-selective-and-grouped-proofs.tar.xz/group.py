"""Time incremental sibling checks with a shared premise assertion and optional disjunction."""
import argparse
import collections
import csv
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

p = argparse.ArgumentParser()
p.add_argument("archive", type=Path)
p.add_argument("cli", type=Path)
p.add_argument("--perf", default="perf")
p.add_argument("--cpu", default="20")
p.add_argument("--rounds", type=int, default=3)
p.add_argument("--widths", type=int, nargs="+", default=[1,2,4,8,16,64])
p.add_argument("--cases", type=int, nargs="+", default=[3,6,8])
a = p.parse_args()
sys.path.insert(0, str(a.archive / "reuse"))
from analyze import data, compatible

out = csv.writer(sys.stdout)
out.writerow("case round batch segment width checks calls fallback result instructions ms".split())
for nr in a.cases:
    terms,h,ds,_=data(nr)
    groups=[]
    for i,(b,g,base,goal) in enumerate(h):
        if not groups or groups[-1][0]!=b or groups[-1][1]!=base or not compatible(ds[i],groups[-1][2]):
            groups.append((b,base,{},[]))
        groups[-1][2].update(ds[i])
        groups[-1][3].append(i)
    for rot in range(a.rounds):
        for width in a.widths[rot:]+a.widths[:rot]:
            for seg,(b,base,sig,ids) in enumerate(groups):
                start=time.monotonic()
                decl=[terms.render(v) for vs in sig.values() for v in sorted(vs)]
                # Match the original single, conjunctive base assertion in each arm.
                decl+=["(assert (and "+" ".join(terms.render(v) for v in sorted(base))+"))"]
                queries=["(and "+" ".join(terms.render(v) for v in sorted(h[i][3]))+")" for i in ids]
                chunks=[queries[i:i+width] for i in range(0,len(ids),width)]
                calls=0
                total=0
                def run(chunks):
                    global calls,total
                    lines=list(decl)
                    for chunk in chunks:
                        q=chunk[0] if len(chunk)==1 else "(or "+" ".join(chunk)+")"
                        lines+=["(push 1)","(assert "+q+")","(check-sat)","(pop 1)"]
                    with tempfile.NamedTemporaryFile() as tmp:
                        cmd=["taskset","-c",a.cpu,a.perf,"stat","-x,","-o",tmp.name,"-e","instructions:u","--",a.cli,"smt.macro_finder=true","-in"]
                        r=subprocess.run(cmd,input="\n".join(lines)+"\n",text=True,capture_output=True,timeout=60,check=True,env=dict(os.environ,GOMAXPROCS="1",GOGC="100"))
                        count,=[int(row[0]) for row in csv.reader(Path(tmp.name).read_text().splitlines()) if len(row)>4 and row[2]=="instructions:u" and float(row[4])==100]
                    ans=r.stdout.strip().splitlines()
                    assert len(ans)==len(chunks) and all(v in ('unsat','sat','unknown') for v in ans),ans
                    total+=count
                    calls+=len(chunks)
                    return ans
                try:
                    ans=run(chunks)
                    retry=[[q] for c,v in zip(chunks,ans) if v!='unsat' for q in c]
                    if retry:
                        assert run(retry)==['unsat']*len(retry)
                    ok='unsat'
                except subprocess.TimeoutExpired:
                    ok='timeout'
                    retry=[]
                out.writerow([nr,rot,b,seg,width,len(ids),calls,len(retry),ok,total,round((time.monotonic()-start)*1000,2)])
                sys.stdout.flush()
