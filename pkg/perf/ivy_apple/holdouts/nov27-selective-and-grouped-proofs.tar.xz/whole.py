from pathlib import Path
import os
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-plan-replay/final/outliers.py').read_text()
s=s[:s.index('modes=')]+'''modes={k:w/'group' for k in os.environ['WIDTHS'].split()}
'''+s[s.index('def run'):s.rindex('run(12,')]
s=s.replace('dict(os.environ,GOMAXPROCS','dict(os.environ,GROUP_WIDTH=m,GOMAXPROCS').replace('timeout=120','timeout=12').replace('120000','12000')
exec(s)
run(int(os.getenv('CPU','12')),os.environ['STEM'],[cases[int(n)-1] for n in os.environ['CASES'].split()],int(os.environ['ROUNDS']),list(modes))
