from pathlib import Path
import os
w=Path(__file__).resolve().parent;binary=w/'compound'
s=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0]
s=s[:s.index('subprocess.run([*flags')]+s[s.index('def run'):]
s=s.replace('dict(os.environ,GOMAXPROCS','dict(os.environ,GROUP_WIDTH=m,GOMAXPROCS')
modes={k:binary for k in ['1','16','116']}
exec(s)
with concurrent.futures.ThreadPoolExecutor(6) as pool:
 jobs=[pool.submit(run,1+2*i,'checked-panel'+str(i),cases[i::6],1,['1','16','116']) for i in range(6)]
 for job in jobs:job.result()
