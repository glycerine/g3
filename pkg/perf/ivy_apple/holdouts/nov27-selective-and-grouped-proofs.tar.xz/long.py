from pathlib import Path
import json,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd()
front=p/'build/.boolean-enode-cost/apple-source/goivy'
base=front/'z3bridge_solver_model.go'
src=(w/'equalities.go.txt').read_text()
assert 'if shrink && !s.opts.DisableModelShrinking {' in src and 'if shrink && !s.opts.DisableModelShrinking {' not in base.read_text()
a=w/'apple.go.txt';a.write_text(src.replace('if shrink && !s.opts.DisableModelShrinking {','if shrink {'))
j=w/'apple.json';j.write_text(json.dumps({'Replace':{str(base.resolve()):str(a)}}))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-overlay',j,'-o',w/'apple','./cmd/goivy_check'],cwd=front,check=True)
s=Path('/tmp/g3-plan-budget/long.py').read_text();s=s[:s.index('bin=Path')]+s[s.index("ex=Path"):]
s=s.replace("modes=['base','256','512']","modes=['1','16']").replace('range(3):','range(2):').replace("exe=bin/m if apple else (Path('/tmp/g3-live-frame-cost/recheck/baseline') if m=='base' else w/m/'release')","exe=w/('apple' if apple else 'equalities')").replace('dict(os.environ,GOMAXPROCS','dict(os.environ,GROUP_WIDTH=m,GOMAXPROCS')
exec(s)
