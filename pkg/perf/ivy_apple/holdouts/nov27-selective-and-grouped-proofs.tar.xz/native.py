from pathlib import Path
import subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd()
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off,classic_z3','-overlay',w/'equalities.json','-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'native','./cmd/goivy_check'],cwd=front,check=True)
exec((w/'whole.py').read_text().replace("w/'group'","w/'native'"))
