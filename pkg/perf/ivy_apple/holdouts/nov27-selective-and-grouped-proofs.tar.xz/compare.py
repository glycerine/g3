from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'census.csv').open()))
direct={(r['case'],r['batch'],int(r['ordinal'])):int(r['instructions']) for r in rows if r['width']=='1'}
with (w/'spans.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case batch first count answer group_ins individual_ins'.split())
 for r in rows:
  if not r['phase'].startswith('group-'):continue
  _,length,answer=r['phase'].split('-');size=int(length);i=int(r['ordinal']);nr=r['case'];b=r['batch']
  normals=sum(direct.get((nr,b,j),0) for j in range(i,i+size))
  out.writerow([nr,b,i,size,answer,r['instructions'],normals])
sums=collections.defaultdict(list)
for r in csv.DictReader((w/'spans.csv').open()):
 sums[int(r['case']),int(r['count'])].append((int(r['group_ins'])-int(r['individual_ins']))/1e6)
for k,v in sorted(sums.items()):print(k,len(v),round(sum(v)))
