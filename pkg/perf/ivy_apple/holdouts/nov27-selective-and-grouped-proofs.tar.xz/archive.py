from pathlib import Path
import tarfile,csv,io
w=Path(__file__).resolve().parent
dst=Path.cwd()/'perf/ivy_apple/holdouts/nov27-selective-and-grouped-proofs.tar.xz'
with tarfile.open(dst,'w:xz',preset=5) as a:
 for p in sorted(w.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(w)
  if rel.name.startswith('panel') and len(rel.parts)==1:continue
  if p.suffix in ('.py','.go','.txt','.csv','.pb','.md','.patch') or rel.as_posix() in ['final/test.log','final/live.log','final/live-local.log']:
   a.add(p,arcname=str(rel))
 for n in ['g3-or-install/final/release.py','g3-plan-replay/final/outliers.py','g3-plan-budget/long.py','g3-reduction-rows/compat.txt','g3-reduction-rows/ranking.csv','g3-ticket-stages/bridge.go.txt','g3-ticket-focus/reuse/weight-window.go','g3-ticket-focus/reuse/weights.py','g3-ticket-focus/reuse/analyze.py']:
  a.add(Path('/tmp')/n,arcname='deps/'+n)
with tarfile.open(dst) as a:
 names=a.getnames()
 def rows(n):return list(csv.DictReader(io.TextIOWrapper(a.extractfile(n))))
 panel=[r for n in names if n.startswith('final/panel') and n.endswith('.csv') for r in rows(n)]
 assert len(panel)==len(set(x['case'] for x in panel))==228 and all(x['status']=='match' for x in panel)
 assert len(rows('final/complete.csv'))==7*3*8
 assert len(rows('final/alloc.csv'))==6
 assert len(rows('hybrid-ranking.csv'))==839
 assert all(len(rows('final/'+n+'/long.csv'))==6 for n in ['rfn2','dramc_nb2','raft_no_assume'])
 assert sum(int(r['group_size']) for r in rows('final/counts.csv'))==131
 assert len({r['case'] for r in rows('final/counts.csv')})==228
 print(len(names),'archived files;',dst.stat().st_size,'bytes')
