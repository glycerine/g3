from pathlib import Path
import subprocess,json,os,csv
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);p=Path.cwd();front=p/'build/.boolean-enode-cost/frontend/goivy';files=json.loads((w.parent/'direct/overlay.json').read_text())['Replace'];key=next(k for k in files if k.endswith('/focus_trial.go'));src=Path(files[key]).read_text().replace('if (batch!=4 && batch!=5) || (goal!=55 && goal!=56) {return func(string){}}; ','');f=w/'weight-window.go';f.write_text(src);files[key]=str(f);o=w/'weight.json';o.write_text(json.dumps({'Replace':files}));ex=Path('/home/jaten/ivy/ivy-lang-examples');names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
for e in ['g3','z3']:
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-overlay',o,'-o',d/('all-window-'+e),'./cmd/goivy_check'],cwd=front,check=True)
with (w/'weights.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case engine round batch goal instructions'.split())
 for i in range(5):
  for e in ['g3','z3'][::1 if i%2==0 else -1]:
   for nr in [3,6,8]:
    ref=Path('/tmp/g3-reduction-rows/compat')/str(nr)/'1/native'
    r=subprocess.run(['taskset','-c','18',d/('all-window-'+e),ex/names[nr-1]],cwd=d,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
    keep=[];rows=[]
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'STAGE-COUNT '):
      _,b,g,s,n,empty,en,run,ns=l.split();assert en==run and s==b'check';rows.append([nr,e,i,int(b),int(g),int(n)])
     else:keep.append(l)
    assert (r.returncode,r.stdout,b''.join(keep))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());out.writerows(rows);f.flush()
