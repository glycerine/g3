from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'census.py').read_text()
p=s.index("s=(w/'frontend.py')")
q=s.index("exec(s)",p)+len("exec(s)")
# Reuse the generated compound overlay after its build, adding only diagnostics.
s=s[:p]+'''import json
p=Path.cwd();o=json.loads((w/'compound.json').read_text());target=next(k for k in o['Replace'] if k.endswith('/z3bridge_solver_model.go'));f=Path(target)
src=Path(o['Replace'][target]).read_text().replace('s.showVCsBase(clauses)','s.showVCsBase(clauses);batch:=newStageBatch()')
src=src.replace('ans:=z3solver.Check()','finish:=startStage(batch,ordinal+1);ans:=z3solver.Check();finish(fmt.Sprintf("group-%d-%v",len(goals),ans))')
src=src.replace('res, err := s.decideZ3With(z3solver, finalCheck)','finish:=startStage(batch,ordinal+1);res, err := s.decideZ3With(z3solver, finalCheck);finish("single")')
overlay=w/'guard-census.go.txt';overlay.write_text(src);o['Replace'][target]=str(overlay);o['Replace'][str(f.parent/'window_study.go')]=str(w/'window.go.txt')
j=w/'guard-census.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'guard-census','./cmd/goivy_check'],cwd=f.parent,check=True)
'''+s[q:]
s=s.replace("'census.csv'","'guard-census.csv'").replace("w/'census',","w/'guard-census',").replace('in [1,16]','in [1,16,116]').replace('[3,2,5,11,6,8,12]','[3,4,11,1]').replace('timeout=30','timeout=150')
exec(s)
