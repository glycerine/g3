from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'frontend.py').read_text()
extra="""
s=s.replace('for ordinal, fc := range finalCond {','''var screen func(smt.Z3Expr) bool
        seen:=make(map[int]bool)
        if width>1 && len(finalCond)>1 && s.opts.Incremental {
            var closeScreen func()
            screen,closeScreen=z3solver.StudyScreen(len(finalCond))
            defer closeScreen()
        }
        for ordinal, fc := range finalCond {''')
s=s.replace('if ordinal<provenThrough {','if ordinal<provenThrough || seen[ordinal] {')
s=s.replace('goals:=[]smt.Z3Expr{zCond}', 'goals:=[]smt.Z3Expr{zCond}; through:=ordinal+1')
s=s.replace('len(goals)<width','j-ordinal<width')
s=s.replace('goals=append(goals,z3solver.SimplifyVerificationCondition(v))','v=z3solver.SimplifyVerificationCondition(v); through=j+1; if screen(v){seen[j]=true} else {goals=append(goals,v)}')
s=s.replace('triedThrough=ordinal+len(goals)','triedThrough=through')
bridge=f.parent/'smt/g3_solver.go'
m=bridge.read_text()+'''\nfunc (s *Z3Solver) StudyScreen(count int)(func(Z3Expr) bool,func()) {
    b:=s.c.BeginOrderProofBatchForGoals(count)
    return func(goal Z3Expr)bool{
        s.Push(); s.Assert(goal)
        var yes bool
        s.ctx.do(func(){var err error;yes,err=b.Prove();if err!=nil {yes=false}})
        s.Pop()
        return yes
    },func(){fail(b.Close())}
}
'''
br=w/'screen-bridge.go.txt';br.write_text(m)
"""
s=s.replace("overlay=w/'group.go.txt';",extra+"overlay=w/'screen.go.txt';").replace("'overlay.json'","'screen.json'").replace("str(f):str(overlay)","str(f):str(overlay),str(bridge):str(br)").replace("w/'group',","w/'screen',")
exec(s)
