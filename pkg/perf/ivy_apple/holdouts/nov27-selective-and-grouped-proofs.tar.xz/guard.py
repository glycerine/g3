from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'frontend.py').read_text()
extra="""
s=s.replace('provenThrough, triedThrough:=0,0', '''provenThrough, triedThrough:=0,0
        var impliesKind smt.DeclKind
        if width>1 && len(finalCond)>1 {
            ctx:=s.tr.Ctx
            impliesKind=ctx.Implies(ctx.BoolVal(true),ctx.BoolVal(false)).Decl().Kind()
        }
        guardParts:=func(v smt.Z3Expr)(smt.Z3Expr,smt.Z3Expr,bool) {
            for v.IsAppOf(smt.DeclAnd) && v.NumArgs()==1 {v=v.Arg(0)}
            if v.IsAppOf(smt.DeclNot) {
                inner:=v.Arg(0)
                if inner.IsAppOf(impliesKind) && inner.NumArgs()==2 {
                    return inner.Arg(0),s.tr.Ctx.Not(inner.Arg(1)),true
                }
            }
            return smt.Z3Expr{},smt.Z3Expr{},false
        }''')
s=s.replace('if _,ok:=fc.(*ConjChecker);ok {','if guard,first,ok:=guardParts(zCond);ok {\n                        if _,static:=fc.(*ConjChecker);!static{goto singleGoal}')
s=s.replace('goals:=[]smt.Z3Expr{zCond}','goals:=[]smt.Z3Expr{first}')
s=s.replace('goals=append(goals,z3solver.SimplifyVerificationCondition(v))','g,tail,ok:=guardParts(z3solver.SimplifyVerificationCondition(v)); if !ok || !guard.Equal(g){break}; goals=append(goals,tail)')
s=s.replace('Assert(s.tr.Ctx.Or(goals...))','Assert(s.tr.Ctx.And(guard,s.tr.Ctx.Or(goals...)))')
s=s.replace('                if s.opts.Incremental {\n\t\t\t\t\tz3solver.Push()', '                singleGoal: if s.opts.Incremental {\n\t\t\t\t\tz3solver.Push()')
"""
# Escape embedded newlines in Python string literals inside the generated build driver.
extra=extra.replace('ok {\n                        if _,static','ok {\\n                        if _,static').replace('Incremental {\n\t\t\t\t\tz3solver.Push()',r'Incremental {\n\t\t\t\t\tz3solver.Push()')
s=s.replace("overlay=w/'group.go.txt';",extra+"overlay=w/'guard.go.txt';").replace("'overlay.json'","'guard.json'").replace("w/'group',","w/'guard',")
exec(s)
