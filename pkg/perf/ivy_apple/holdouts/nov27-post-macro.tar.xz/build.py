from pathlib import Path
import sys, subprocess, json,shlex,re,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();engine=sys.argv[1];front,mod=map(lambda x:Path(x).resolve(),sys.argv[2:4])
def rep(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(n,s):
    path=w/n;path.write_text(s);return str(path)
files={}
stage=(w/'phase.go.txt').read_text()
files[str(front/'phase_observer_trial.go')]=save(engine+'-stage.go',stage.replace('start := time.Now()', 'os.Setenv("PASS_FD",fmt.Sprint(fd));start := time.Now()').replace('elapsed := time.Since(start)','os.Unsetenv("PASS_FD");elapsed := time.Since(start)'))
files[str(front/'z3bridge_solver_model.go')]=str(w/(engine+'-bridge.go.txt'))
if engine=='ordinary':
 k=p/'smtcore/smt_asserted_macros.go';s=rep(k.read_text(),'"fmt"','"fmt"\n "os"\n "strconv"\n "syscall"\n "unsafe"')
 s+='''
func passFD() int {v,e:=strconv.Atoi(os.Getenv("PASS_FD"));if e!=nil{return -1};return v}
func passRead(fd int) int64 {if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if n!=24||e!=0||c[1]!=c[2]{panic("counter")};return int64(c[0])}
func passLog(fd int,args ...any){if fd>=0{fmt.Fprint(os.Stderr,"PASS ");fmt.Fprintln(os.Stderr,args...)}}
'''
 s+="\nvar postFD = -1\nvar postSum [4]int64\nvar postCount [4]int\n"
 s=s.replace('return k.replacePendingMacroBatch(batch)',"""postFD=passFD();postSum=[4]int64{};postCount=[4]int{}
 a,b:=passRead(postFD),passRead(postFD);err=k.replacePendingMacroBatch(batch);total:=passRead(postFD)-2*b+a
 for i,key:=range []string{"swap","flush","same","changed"} {passLog(postFD,key,0,0,0,0,0,postCount[i],postSum[i])}
 passLog(postFD,"total",0,0,0,0,0,1,total);postFD=-1;return err""",1)
 a=s.index('func (k *SMTKernel) replacePendingMacroBatch');x=s.index('return k.reduceAndSolveAssertions()',a)
 s=s[:x]+'postSum[0]+=passRead(postFD)-2*b+a;postCount[0]++;'+s[x:]
 x=s.index('if err := k.swapPendingFormulaBatch',a);s=s[:x]+'a,b:=passRead(postFD),passRead(postFD);'+s[x:]
 files[str(k)]=save(k.name,s)
 k=p/'smtcore/smt_asserted_reduce.go';s=k.read_text();i=s.index('if err := k.flushAssertedCache()',s.index('func (k *SMTKernel) reduceAndSolveAssertions'));s=s[:i]+s[i:].replace('if err := k.flushAssertedCache(); err != nil {','a,b:=passRead(postFD),passRead(postFD);err:=k.flushAssertedCache();postSum[1]+=passRead(postFD)-2*b+a;postCount[1]++;if err!=nil {',1);files[str(k)]=save(k.name,s)
 k=p/'smtcore/smt_asserted_formulas.go';s=rep(k.read_text(),'err = k.preprocessor.Rewrite(formula, resultRef)','if postFD>=0{a,b:=passRead(postFD),passRead(postFD);err=k.preprocessor.Rewrite(formula,resultRef);n:=passRead(postFD)-2*b+a;out,_:=k.manager.RefGet(resultRef);i:=2;if out!=formula{i=3};postSum[i]+=n;postCount[i]++} else {err=k.preprocessor.Rewrite(formula,resultRef)}');files[str(k)]=save(k.name,s)
else:
 k=p.parent/'src/smt/asserted_formulas.cpp'
 s='''#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include <cstdint>
static int passfd(){auto v=std::getenv("PASS_FD");return v?std::atoi(v):-1;}
static int64_t rd(int f){if(f<0)return 0;uint64_t c[3];if(read(f,c,24)!=24||c[1]!=c[2])std::abort();return c[0];}
'''+k.read_text()
 s="static thread_local int postfd=-1;static thread_local long long sums[4]={},counts[4]={};\n"+s
 a=s.index('void asserted_formulas::find_macros_core()');b=s.index('void asserted_formulas::expand_macros()',a);part=s[a:b]
 part=rep(part,'swap_asserted_formulas(new_fmls);', 'postfd=passfd();for(int i=0;i<4;i++){sums[i]=0;counts[i]=0;}auto a=rd(postfd),b=rd(postfd);swap_asserted_formulas(new_fmls);sums[0]+=rd(postfd)-2*b+a;counts[0]++;')
 part=rep(part,'reduce_and_solve();','reduce_and_solve();auto total=rd(postfd)-2*b+a;if(postfd>=0){char const* names[]={"swap","flush","same","changed"};for(int i=0;i<4;i++)std::fprintf(stderr,"PASS %s 0 0 0 0 0 %lld %lld\\n",names[i],counts[i],sums[i]);std::fprintf(stderr,"PASS total 0 0 0 0 0 1 %lld\\n",(long long)total);}postfd=-1;')
 s=s[:a]+part+s[b:]
 s=rep(s,'flush_cache(); // collect garbage','auto a=rd(postfd),b=rd(postfd);flush_cache();sums[1]+=rd(postfd)-2*b+a;counts[1]++;')
 s=rep(s,'simplify(j, result, result_pr);','if(postfd>=0){auto a=rd(postfd),b=rd(postfd);simplify(j,result,result_pr);auto cost=rd(postfd)-2*b+a;int i=j.get_fml()==result?2:3;sums[i]+=cost;counts[i]++;}else{simplify(j,result,result_pr);}')
 build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 obj=w/'asserted_formulas.o';subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,save(k.name,s)],cwd=build,check=True)
 lib=w/'libpass.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
 k=front/'smt/quantifier.go';files[str(k)]=save('quantifier.go',rep(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=save(engine+'.json',json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if engine=='native' else ''),'-overlay',ov,'-o',w/engine,'./cmd/goivy_check'],cwd=front,check=True)
