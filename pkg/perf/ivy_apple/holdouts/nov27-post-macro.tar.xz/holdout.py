"""Price pass operations across every physical stage of additional verifier controls."""
from pathlib import Path
import os,csv,json,sys,subprocess,collections
w=Path(__file__).resolve().parent;gold,ex=map(Path,sys.argv[1:3]);eng=sys.argv[3];cases=json.loads((gold/'cases.json').read_text())
with (w/('holdout-'+eng+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round stage operation calls first second'.split())
 for case in ('ticket_protocol','hybrid','arm_rules3','fba'):
    spec,iso,code=cases[case];ref=gold/'reference'/case
    for n in range(3):
        r=subprocess.run(['taskset','-c',sys.argv[4],w/eng]+(['isolate='+iso] if iso else [])+[ex/spec],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=180)
        pending=[];clean=bytearray();counts=collections.defaultdict(lambda:[0,0,0])
        for line in r.stderr.splitlines(keepends=True):
            if line.startswith(b'PASS '):pending.append(line.decode().split()[1:])
            elif line.startswith(b'STAGE-COUNT '):
                stage=line.decode().split()[3]
                for v in pending:
                    c=counts[stage,v[0]];c[0]+=1;c[1]+=int(v[-2]);c[2]+=int(v[-1])
                pending.clear()
            else:clean.extend(line)
        assert not pending and (r.returncode,r.stdout,clean)==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
        for k,vals in sorted(counts.items()):out.writerow([case,n,*k,*vals])
        f.flush()
