"""Test the ordinary theory application's empty proof register."""
import argparse
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--goivy',action='store_true')
args=parser.parse_args()
pkg=Path.cwd()
ivy=Path.home()/'ivy/goivy'
root=Path(__file__).resolve().parent
out=root/'empty-proof'
out.mkdir(exist_ok=True)
sources={}

def edit(path, old, new):
    src=pkg/path
    dst=out/src.name
    text=sources.get(src,src).read_text()
    assert text.count(old)==1, (path,old)
    dst.write_bytes(subprocess.check_output(['gofmt'],input=text.replace(old,new).encode()))
    sources[src]=dst

edit('ast/rewriter/rewriter_engine.go',
     'st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)',
     '''var st RewriteStatus
     if cfg, ok := r.cfg.(*theoryRewriterConfiguration); ok && !ast.ASTValidateHandles && !ast.ASTSourceDebug {
        st,e=cfg.reduceApplication(d,args,r.r)
     } else {
        st,e=r.cfg.ReduceApp(d,args,r.r,r.pr2)
     }''')
edit('ast/rewriter/th_rewriter.go',
     'status, err := c.reduceAppCore(decl, args, out)\n\tif err != nil || status != RewriteDone',
     '''return c.reduceApplication(decl,args,out)
}
func (c *theoryRewriterConfiguration) reduceApplication(decl ast.ASTHandle, args ast.AppArguments, out ast.ASTRef) (RewriteStatus,error) {
    status,err:=c.reduceAppCore(decl,args,out)
    if err!=nil || status!=RewriteDone''')
if args.goivy:
    for src,dst in list(sources.items()):
        sources[Path.home()/'g3/pkg'/src.relative_to(pkg)]=dst
name='goivy_check' if args.goivy else 'g3'
target=['-tags=xtrace_off','./cmd/goivy_check'] if args.goivy else ['./cmd/g3']
overlay=out/(name+'.json')
overlay.write_text(json.dumps({'Replace': {str(k):str(v) for k,v in sources.items()}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/name,*target],
               cwd=ivy if args.goivy else pkg,check=True)
