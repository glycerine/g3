"""Run the untimed GoIvy observer and check both streams against references."""
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
reference = Path(sys.argv[1])
examples = Path.home() / 'ivy/ivy-lang-examples'
cases = json.loads((reference/'cases.json').read_text())
for case in ('ticket_protocol','hybrid','arm_rules3'):
    spec, isolate, code = cases[case]
    args = ['isolate='+isolate] if isolate else []
    work = out/'complete-census'
    work.mkdir(exist_ok=True)
    run = subprocess.run(['taskset','-c','11',str(out/'observer/goivy_check'),*args,str(examples/spec)],
                         cwd=work, capture_output=True, env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),timeout=120)
    (work/(case+'.stdout')).write_bytes(run.stdout)
    (work/(case+'.stderr')).write_bytes(run.stderr)
    diagnostics = run.stderr.splitlines(keepends=True)
    observed = [line[len(b'INSTANCE-STEPS '):] for line in diagnostics if line.startswith(b'INSTANCE-STEPS ')]
    assert len(observed)==1 and run.returncode==code, (case,run.returncode)
    normal = b''.join(line for line in diagnostics if not line.startswith(b'INSTANCE-STEPS '))
    assert run.stdout==(reference/'reference'/case/'stdout').read_bytes(), case
    assert normal==(reference/'reference'/case/'stderr').read_bytes(), case
    (work/(case+'.json')).write_bytes(observed[0])
