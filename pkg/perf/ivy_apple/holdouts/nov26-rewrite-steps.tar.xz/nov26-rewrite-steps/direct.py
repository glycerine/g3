"""Try concrete dispatch for the standard theory configuration."""
import argparse
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--goivy', action='store_true')
args = parser.parse_args()
pkg = Path.cwd()
path = Path('ast/rewriter/rewriter_engine.go')
source = (pkg / path).read_text()
out = Path(__file__).resolve().parent / 'direct'
out.mkdir(exist_ok=True)
dst = out / path.name

def replace(before, after, expected=1):
    global source
    if source.count(before) != expected:
        raise ValueError((before,source.count(before)))
    source = source.replace(before, after, 1)

replace('cfg                      Configuration', 'cfg                      Configuration\n theory *theoryRewriterConfiguration')
replace('r.cfg = cfg', 'r.cfg = cfg\n r.theory, _ = cfg.(*theoryRewriterConfiguration)')
replace('sub, subProof, found, e := r.cfg.GetSubst(t)', '''var sub, subProof ast.ASTHandle
    var found bool
    var e error
    if r.theory != nil {
        if r.theory.hasSubstitution {sub, subProof, found,e=r.theory.GetSubst(t)}
    } else {
        sub, subProof, found,e=r.cfg.GetSubst(t)
    }''')
replace('allowed, e := r.cfg.PreVisit(t)\n\tif e != nil {\n\t\treturn false, e\n\t}', '''allowed:=true
    if r.theory==nil {
        allowed,e=r.cfg.PreVisit(t)
        if e!=nil {return false,e}
    }''')
replace('func (r *rewriterEngine) mustCacheShape(t ast.ASTHandle, kind ast.ASTKind, rc, n uint32) (bool, error) {', '''func (r *rewriterEngine) mustCacheShape(t ast.ASTHandle, kind ast.ASTKind, rc, n uint32) (bool, error) {
    if r.theory!=nil {
        return t != r.core.root && (r.theory.cacheAll || rc>1) && (kind==ast.ASTQuantifier || kind==ast.ASTApp && n>0),nil
    }''')
replace('st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)', '''var st RewriteStatus
    if r.theory!=nil {
        st,e=r.theory.ReduceApp(d,args,r.r,r.pr2)
    } else {
        st,e=r.cfg.ReduceApp(d,args,r.r,r.pr2)
    }''')
replace('def, _, _, macro, e := r.cfg.GetMacro(d)', '''var def ast.ASTHandle
    var macro bool
    if r.theory==nil {def,_,_,macro,e=r.cfg.GetMacro(d)}''')
replace('exceeded, err := r.cfg.MaxStepsExceeded(r.numSteps)', '''var exceeded bool
    var err error
    if r.theory!=nil {
        exceeded,err=r.theory.MaxStepsExceeded(r.numSteps)
    } else {
        exceeded,err=r.cfg.MaxStepsExceeded(r.numSteps)
    }''')
dst.write_bytes(subprocess.check_output(['gofmt'], input=source.encode()))
name = 'goivy_check' if args.goivy else 'g3'
targets = ['-tags=xtrace_off','./cmd/goivy_check'] if args.goivy else ['./cmd/g3']
cwd = Path.home()/'ivy/goivy' if args.goivy else pkg
overlay = out / (name+'.json')
paths = {str(pkg/path): str(dst)}
if args.goivy:
    paths[str(Path.home()/'g3/pkg'/path)] = str(dst)
overlay.write_text(json.dumps({'Replace': paths}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/name,*targets],cwd=cwd,check=True)
