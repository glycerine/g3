package rewriter

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/glycerine/g3/pkg/ast"
)

type rewriteObservation struct {
	Visits, CacheEligible, VisitHits, CacheMisses uint64
	FrameProbes, FrameHits, AppSteps, QuantSteps  uint64
	Reducers, ReducerMisses, UnchangedApps        uint64
	Steps, Charge                                 uint64
	FramesByOperation                             map[string]uint64
}

type rewriteObservationTotals struct {
	Roots, Identity, Repeated, RepeatedIdentity, DifferentCharge, DifferentSteps uint64
	All, Repeat, RepeatIdentity                                                  rewriteObservation
	CommonRoot                                                                   ASTRewriteExample
}
type ASTRewriteExample struct {
	Origin           uint64
	Slot, Generation uint32
	Repeats          uint64
	First, Last      rewriteObservation
}
type rewriteObservationSeen struct {
	value   ast.ASTHandle
	first   rewriteObservation
	repeats uint64
}

var rewriteTotals rewriteObservationTotals
var rewriteActive *rewriteObservation

func (a *rewriteObservation) add(b rewriteObservation) {
	a.Visits += b.Visits
	a.CacheEligible += b.CacheEligible
	a.VisitHits += b.VisitHits
	a.CacheMisses += b.CacheMisses
	a.FrameProbes += b.FrameProbes
	a.FrameHits += b.FrameHits
	a.AppSteps += b.AppSteps
	a.QuantSteps += b.QuantSteps
	a.Reducers += b.Reducers
	a.ReducerMisses += b.ReducerMisses
	a.UnchangedApps += b.UnchangedApps
	a.Steps += b.Steps
	a.Charge += b.Charge
	if a.FramesByOperation == nil {
		a.FramesByOperation = make(map[string]uint64)
	}
	for k, v := range b.FramesByOperation {
		a.FramesByOperation[k] += v
	}
}

func (r *TheoryRewriter) ObserveInstanceRewrite(raw ast.ASTHandle, out ast.ASTRef) error {
	var obs rewriteObservation
	obs.FramesByOperation = make(map[string]uint64)
	previous := rewriteActive
	rewriteActive = &obs
	defer func() { rewriteActive = previous }()
	limit := r.manager.ResourceLimit()
	steps := limit.Steps
	if err := r.Rewrite(raw, out); err != nil {
		return err
	}
	obs.Charge = limit.Steps - steps
	obs.Steps = uint64(r.traversal.engine.numSteps)
	value, err := r.manager.RefGet(out)
	if err != nil {
		return err
	}
	totals := &rewriteTotals
	totals.Roots++
	totals.All.add(obs)
	if value == raw {
		totals.Identity++
	}
	if r.rewriteObservations == nil {
		r.rewriteObservations = make(map[ast.ASTHandle]rewriteObservationSeen)
	}
	seen, known := r.rewriteObservations[raw]
	if known {
		totals.Repeated++
		totals.Repeat.add(obs)
		if seen.first.Charge != obs.Charge {
			totals.DifferentCharge++
		}
		if seen.first.Steps != obs.Steps {
			totals.DifferentSteps++
		}
		if value == raw && seen.value == raw {
			totals.RepeatedIdentity++
			totals.RepeatIdentity.add(obs)
		}
		seen.repeats++
		if seen.repeats > totals.CommonRoot.Repeats {
			totals.CommonRoot = ASTRewriteExample{raw.Origin(), raw.Slot(), uint32(raw.Generation()), seen.repeats, seen.first, obs}
		}
	} else {
		seen = rewriteObservationSeen{value: value, first: obs}
	}
	r.rewriteObservations[raw] = seen
	return nil
}

func PrintRewriteObservation() {
	out, err := json.Marshal(rewriteTotals)
	if err != nil {
		panic(err)
	}
	fmt.Fprintf(os.Stderr, "INSTANCE-STEPS %s\n", out)
}
