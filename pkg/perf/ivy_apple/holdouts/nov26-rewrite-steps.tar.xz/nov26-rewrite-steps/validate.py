"""Validate and summarize the matched rewriter observations."""
import csv
import collections
import json
from pathlib import Path
import re
import statistics
import sys

root = Path(__file__).resolve().parent
names = ('ticket-127', 'ticket-290', 'toy-consensus-18')
stats = ('decisions', 'conflicts', 'quant-instantiations', 'rlimit-count')
expected = {}
for path in sorted(root.glob('standalone*.csv')):
    rows = collections.defaultdict(list)
    for row in csv.DictReader(path.open()):
        key = row['query']
        values = tuple(row[k] for k in stats)
        if key in expected:
            assert expected[key] == values, (path.name,key,values,expected[key])
        else:
            expected[key] = values
        rows[key, row['engine']].append(row)
    assert {len(values) for values in rows.values()} == {11}, path.name
    print(path.name)
    for (case, label), values in rows.items():
        print(' ',case,label,*[round(statistics.median(float(v[k]) for v in values),3)
                               for k in ('instructions','cycles','milliseconds')])
for name in names:
    text = (root/(name+'.stdout')).read_text()
    assert text.startswith('unsat\n') and '(error' not in text
    numbers=dict(re.findall(r':([\w-]+)\s+(\d+)\b',text))
    assert tuple(numbers.get(key,'-') for key in stats)==expected[name]
    census=(root/(name+'.census')).read_text().splitlines()
    assert len(census)==1 and census[0].startswith('INSTANCE-STEPS ')
    observed=json.loads(census[0].split(' ',1)[1])
    assert observed['All']['FrameHits']==0
    assert observed['All']['FrameProbes']==observed['All']['CacheMisses']
for path in sorted((root/'complete-census').glob('*.json')):
    census=json.loads(path.read_text()); all=census['All']
    assert all['FrameHits']==0 and all['FrameProbes']==all['CacheMisses']
    print(path.stem,census['Roots'],census['Repeated'],census['DifferentCharge'],all['VisitHits'],all['FrameProbes'])
