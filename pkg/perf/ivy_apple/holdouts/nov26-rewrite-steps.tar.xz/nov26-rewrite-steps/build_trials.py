"""Build independent rewriter trials or an untimed per-instance observer."""
import argparse
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('variants', nargs='+')
parser.add_argument('--goivy', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
pkg = Path.cwd()
ivy = Path.home() / 'ivy/goivy'
engine = 'ast/rewriter/rewriter_engine.go'

for variant in args.variants:
    paths = {}
    out = root / variant
    out.mkdir(exist_ok=True)

    def replace(name, old, new, goivy_file=False, expected=1):
        src = (ivy if goivy_file else pkg) / name
        text = paths.get(src, src).read_text()
        if text.count(old) != expected:
            raise ValueError((name, old, text.count(old)))
        dst = out / (('ivy-' if goivy_file else '')+src.name)
        dst.write_bytes(subprocess.check_output(['gofmt'], input=text.replace(old,new,1).encode()))
        paths[src] = dst
        if goivy_file:
            paths[src.resolve()] = dst

    if variant == 'observer':
        src = pkg / 'ast/rewriter/instance_rewrite_observer.go'
        paths[src] = root / 'rewrite_observer.go'
        replace('ast/rewriter/th_rewriter.go', 'type TheoryRewriter struct {',
                'type TheoryRewriter struct {\nrewriteObservations map[ast.ASTHandle]rewriteObservationSeen')
        replace('smtcore/smt_qi_instance.go', 'if err = rw.Rewrite(instance, simplified); err != nil {',
                'if err = rw.ObserveInstanceRewrite(instance, simplified); err != nil {')
        replace(engine, 'func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32) (bool, error) {',
                'func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32) (bool, error) {\nif a:=rewriteActive;a!=nil {a.Visits++}')
        replace(engine, 'if cache {\n\t\th, e := c.getCached(t)',
                'if cache {\nif a:=rewriteActive;a!=nil {a.CacheEligible++}\n h, e := c.getCached(t)')
        replace(engine, 'if !h.IsNull() {\n\t\t\tif e = r.sameSort(t, h);',
                'if !h.IsNull() {\nif a:=rewriteActive;a!=nil {a.VisitHits++}\n if e = r.sameSort(t, h);', expected=2)
        replace(engine, 'allowed, e := r.cfg.PreVisit(t)\n\tif e != nil {',
                'if cache && rewriteActive!=nil {rewriteActive.CacheMisses++}\n allowed, e := r.cfg.PreVisit(t)\n\tif e != nil {')
        replace(engine, 'if !r.substituteVariables && fr.state() == 0 && fr.index() == 0 && fr.cacheResult() {\n\t\t\th, e := c.getCached(t)',
                'if !r.substituteVariables && fr.state() == 0 && fr.index() == 0 && fr.cacheResult() {\nif rewriteActive!=nil {rewriteActive.FrameProbes++}\n h,e:=c.getCached(t)')
        replace(engine, 'if !h.IsNull() {\n\t\t\t\tif e = appendRewriterRoot(m, &c.results, h);',
                'if !h.IsNull() {\nif rewriteActive!=nil {rewriteActive.FrameHits++}\n if e=appendRewriterRoot(m,&c.results,h);')
        replace(engine, 'kind := fr.kind\n\t\tif ast.ASTValidateHandles',
                '''kind := fr.kind
        if a:=rewriteActive;a!=nil {
            switch kind {
            case ast.ASTApp:
                a.AppSteps++
                _, family, op, err := m.AppIdentity(t)
                if err == nil {
                    name := "theory"
                    switch family {
                    case ast.NullFamilyID: name="uninterpreted"
                    case m.BasicFamilyID():
                        switch op {
                        case ast.ASTOpNot: name="not"
                        case ast.ASTOpAnd: name="and"
                        case ast.ASTOpOr: name="or"
                        case ast.ASTOpIte: name="ite"
                        case ast.ASTOpEq, ast.ASTOpIff: name="eq"
                        default: name="other-Boolean"
                        }
                    }
                    a.FramesByOperation[name]++
                }
            case ast.ASTQuantifier: a.QuantSteps++
            }
        }
        if ast.ASTValidateHandles''')
        replace(engine, 'st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)',
                '''st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)
        if a:=rewriteActive;a!=nil {
            a.Reducers++
            if st==brFailed { a.ReducerMisses++; if !fr.newChild() {a.UnchangedApps++} }
        }''')
        main = 'cmd/goivy_check/main.go' if args.goivy else 'cmd/g3/main.go'
        replace(main, 'package main', 'package main\nimport "github.com/glycerine/g3/pkg/ast/rewriter"', args.goivy)
        if args.goivy:
            replace(main, 'os.Exit(goivy.MainWithConfig(args, cfg))',
                    'code := goivy.MainWithConfig(args, cfg)\n rewriter.PrintRewriteObservation()\n os.Exit(code)', True)
        else:
            replace(main, 'func main() {', 'func main() {\n defer rewriter.PrintRewriteObservation()')
    else:
        parts = variant.split('+') if variant != 'base' else []
        if set(parts) - {'probe','identity','head'}:
            parser.error('unknown variant ' + variant)
        if 'probe' in parts:
            replace(engine,'modelBooleanShortCircuit bool','modelBooleanShortCircuit bool\nlastProbeIsFinal bool')
            replace(engine,'r.cfg = cfg','''r.cfg = cfg
    _, theory := cfg.(*theoryRewriterConfiguration)
    r.lastProbeIsFinal = theory && !proofGen && !ast.ASTValidateHandles && !ast.ASTSourceDebug''')
            replace(engine,'if !r.substituteVariables && fr.state() == 0 && fr.index() == 0 && fr.cacheResult() {',
                    'if !r.substituteVariables && !r.lastProbeIsFinal && fr.state() == 0 && fr.index() == 0 && fr.cacheResult() {')
        if 'identity' in parts:
            replace(engine,'else {\n\t\t\th := t\n\t\t\tif fr.newChild() {\n\t\t\t\th, e = m.RewriterMakeApp',
                    '''else {
            if !fr.newChild() && r.canFinishIdentity() {
                previous, e := m.RefGetHeld(r.r)
                if e != nil {return e}
                if previous.IsNull() { return r.finishIdentity(fr) }
            }
            h := t
            if fr.newChild() {
                h, e = m.RewriterMakeApp''')
            replace(engine,'func (r *rewriterEngine) rewritten(fr rewriterFrame, clear bool) error {','''func (r *rewriterEngine) canFinishIdentity() bool {
    if ast.ASTValidateHandles || ast.ASTSourceDebug || diagnostic.TraceCompiled() {
        return false
    }
    _, theory := r.cfg.(*theoryRewriterConfiguration)
    m := r.core.manager
    return theory && m.TraceStream == nil && !m.Budget().InjectionArmed()
}

func (r *rewriterEngine) finishIdentity(fr rewriterFrame) error {
    c := &r.core
    if e := shrinkRewriterRoots(c.manager, &c.results, fr.spos); e != nil {return e}
    if e := appendRewriterRoot(c.manager, &c.results, fr.curr); e != nil {return e}
    if e := r.cache(fr, fr.curr); e != nil {return e}
    c.frames = c.frames[:len(c.frames)-1]
    return nil
}

func (r *rewriterEngine) rewritten(fr rewriterFrame, clear bool) error {''')
            replace(engine,'"github.com/glycerine/g3/pkg/ast"', '"github.com/glycerine/g3/pkg/ast"\n"github.com/glycerine/g3/pkg/util/diagnostic"')
        if 'head' in parts:
            replace('ast/ast_core_query.go','func (m *ASTManager) GetArity(h ASTHandle) (uint32, error) {','''func (m *ASTManager) AppDeclRefCount(h ASTHandle) (ASTHandle, uint32, error) {
    if !m.fastHandle(h) {
        r, err := m.readKind(h, ASTApp)
        if err != nil { return ASTHandle{}, 0, err }
        h.slot = r.slot
    }
    slot := m.nodeSlotAt(h.slot)
    if slot.node.kind != ASTApp {return ASTHandle{}, 0, ErrASTDomain}
    return m.external(slot.app.decl), slot.node.rc, nil
}

func (m *ASTManager) GetArity(h ASTHandle) (uint32, error) {''')
            start='''d, e := m.GetDecl(t)
		if e != nil {
			return e
		}
		// f->is_associative() && t->get_ref_count() <= 1 &&
		// frame_stack().size() > 1: pure reads, the declaration's flags
		// read only when the cheaper tests pass.
		rc, e := m.GetRefCount(t)'''
            replace(engine,start,'d, rc, e := m.AppDeclRefCount(t)')
    cwd = ivy if args.goivy else pkg
    name_out = 'goivy_check' if args.goivy else 'g3'
    target = ('-tags=xtrace_off','./cmd/goivy_check') if args.goivy else ('./cmd/g3',)
    if args.goivy:
        for src, dst in list(paths.items()):
            if src.is_relative_to(pkg):
                paths[Path.home()/'g3/pkg'/src.relative_to(pkg)] = dst
    overlay = out / (name_out + '.json')
    overlay.write_text(json.dumps({'Replace': {str(src):str(dst) for src,dst in paths.items()}}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,
                    '-o',out/name_out,*target],cwd=cwd,check=True)
