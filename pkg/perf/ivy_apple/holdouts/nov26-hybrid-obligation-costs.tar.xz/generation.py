from pathlib import Path
import subprocess,json,os,sys
w=Path(__file__).resolve().parent;base=w.parent/'.boolean-enode-cost';p=Path.cwd()
src=p/'smtcore/smt_model_checker.go';code=src.read_text()
needle='if status == lbool.True && !auxiliary.config.CertifyBoundedModelTables {'
mark='_, err = c.enqueueCounterexample(quantifier, bindings, true, maxGeneration)'
for choice in sys.argv[1:]:
 # This mark is scoped to a table-derived witness. The finite-domain fallback has other callers.
 s=code.replace('tableScratch     *tableModel','tableWitnessTrial bool\n tableScratch *tableModel')
 start=s.index(needle);i=s.index('added, err := c.addFiniteCounterexample(quantifier, bindings)',start)
 last=i+len('added, err := c.addFiniteCounterexample(quantifier, bindings)')
 s=s[:i]+'c.tableWitnessTrial=true\n'+s[i:last]+'\n c.tableWitnessTrial=false'+s[last:]
 if choice=='seen':
  s=s.replace(mark,'if c.tableWitnessTrial {println("MBEVENT generation",maxGeneration)}\n'+mark)
 else:
  s=s.replace(mark,'if c.tableWitnessTrial && maxGeneration > '+str(int(choice))+' {return false,nil}\n'+mark)
 dst=w/('generation-'+choice+'.go');dst.write_text(s)
 ov=w/('generation-'+choice+'.json');files=json.loads((w/'observer.json').read_text())['Replace'] if choice=='seen' else {}
 files[str(src)]=str(dst);ov.write_text(json.dumps({'Replace':files}))
 exe=w/('count-generation' if choice=='seen' else 'gen'+choice)
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=base/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
