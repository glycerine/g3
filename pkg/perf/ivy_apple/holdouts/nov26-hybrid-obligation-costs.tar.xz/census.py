"""Build separate count observers. The original stage end markers attribute events."""
from pathlib import Path
import sys,os,subprocess,json,shlex,re,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();root=p.parent;build=root/'build'
base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
def once(s,needle,suffix):
 assert s.count(needle)==1,needle
 return s.replace(needle,needle+suffix)
def add(s,needle,tag):
 return once(s,needle,'\n println("MBEVENT '+tag+'")\n')
paths=json.loads((w/'observer.json').read_text())['Replace']
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
engine=sys.argv[1]
if engine=='z3':
 flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row);mk=(build/'Makefile').read_text()
 includes=shlex.split(re.search(r'^includes_39 = (.*)$',mk,re.M)[1])
 lib=w/'libobserver.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
 for filename in ('smt_model_generator','smt_model_checker'):
  f=root/('src/smt/'+filename+'.cpp');s=f.read_text()
  if filename=='smt_model_generator':
   s=once(s,'proto_model * model_generator::mk_model() {','\nstd::fputs("MBEVENT build\\n",stderr);')
  else:
   s=once(s,'bool model_checker::check(quantifier * q) {','\nstd::fputs("MBEVENT quantifier\\n",stderr);')
   s=once(s,'bool model_checker::check(proto_model * md, obj_map<enode, app *> const & root2value) {','\nstd::fputs("MBEVENT candidate\\n",stderr);')
   line='lbool r = m_aux_context->check();'
   assert s.count(line)==2
   s=s.replace(line,line+'\nstd::fputs("MBEVENT complete\\n",stderr);',1)
   last=s.rindex(line)+len(line);s=s[:last]+'\nstd::fputs("MBEVENT restricted\\n",stderr);'+s[last:]
  dest=w/f.name;dest.write_text('#include <cstdio>\n'+s);obj=w/(filename+'.o')
  subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-o',obj,dest],cwd=build,check=True)
  subprocess.run(['ar','r',lib,obj],check=True)
 q=front/'smt/quantifier.go';n=w/'quantifier.go';n.write_text(q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));paths[str(q)]=str(n)
else:
 for filename in ('smt_kernel.go','smt_model_checker.go'):
  f=p/'smtcore'/filename;s=f.read_text()
  if filename=='smt_kernel.go':s=add(s,'func (k *SMTKernel) buildCandidateModelGenerator() (*SMTModelGenerator, error) {','build')
  else:
   s=add(s,'func (c *SMTModelChecker) Check(model *protomodel.ProtoModel, quantifiers []ast.ASTHandle) (bool, error) {','candidate')
   s=add(s,'func (c *SMTModelChecker) auxiliaryCounterexamples(model *protomodel.ProtoModel, quantifier ast.ASTHandle, remaining *uint32) (found bool, result error) {','quantifier')
   for needle,tag in [('status, err := auxiliary.CheckSat(nil)','complete'),('status, err = auxiliary.CheckSat(nil)','restricted')]:s=add(s,needle,tag)
   s=once(s,'status, bindings, err := c.tableScratch.check(c.manager, model, flat, body, count)','\n println("MBEVENT table",int(status))')
  dest=w/f.name;dest.write_text(s);paths[str(f)]=str(dest)
ov=w/('count-'+engine+'.json');ov.write_text(json.dumps({'Replace':paths}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','xtrace_off,classic_z3' if engine=='z3' else 'xtrace_off','-overlay',ov,'-o',w/('count-'+engine),'./cmd/goivy_check'],cwd=front,env=env,check=True)
