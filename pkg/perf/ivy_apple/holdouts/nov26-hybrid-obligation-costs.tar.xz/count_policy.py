from pathlib import Path
import subprocess,json,os
w=Path(__file__).resolve().parent
base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
files=json.loads((w/'count-g3.json').read_text())['Replace'];k=next(k for k in files if k.endswith('smt_model_checker.go'));s=Path(files[k]).read_text()
needle='if status == lbool.True && !auxiliary.config.CertifyBoundedModelTables {'
assert s.count(needle)==1
dest=w/'count-certify.go';dest.write_text(s.replace(needle,'if false && '+needle[3:]));files[k]=str(dest)
ov=w/'count-certify.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'count-certify','./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
