"""Compare the two complete hybrid verifiers on independently numbered batch/goal pairs."""
from pathlib import Path
import subprocess,sys,os,csv
w=Path(__file__).resolve().parent
gold=w.parent/'.bool-scan/golden/reference/hybrid'
examples=Path('/home/jaten/ivy/ivy-lang-examples'); spec=examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'
wr=csv.writer(sys.stdout,lineterminator='\n');wr.writerow(('round','engine','batch','goal','phase','instructions','empty','enabled_ns','running_ns','wall_ns'))
for i in range(3):
 for e in (('ordinary','g3') if i%2==0 else ('g3','ordinary')):
  r=subprocess.run(['taskset','-c','12',w/e,spec],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
  keep=[];seen=set()
  for line in r.stderr.splitlines(keepends=True):
   if not line.startswith(b'STAGE-COUNT '):keep.append(line);continue
   _,b,g,phase,ins,empty,en,run,wall=line.decode().split()
   if int(ins)<=0 or int(run)!=int(en) or int(run)<=0 or (b,g,phase) in seen:raise ValueError(line)
   seen.add((b,g,phase));wr.writerow([i+1,e,b,g,phase,ins,empty,en,run,wall])
  if r.stdout!=(gold/'stdout').read_bytes() or b''.join(keep)!=(gold/'stderr').read_bytes() or not seen:raise ValueError((e,keep))
  sys.stdout.flush()
