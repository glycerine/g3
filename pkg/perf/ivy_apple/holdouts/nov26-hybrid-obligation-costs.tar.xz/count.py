from pathlib import Path
from collections import Counter
import subprocess,csv,sys,os
w=Path(__file__).resolve().parent
gold=w.parent/'.bool-scan/golden/reference/hybrid'
examples=Path('/home/jaten/ivy/ivy-lang-examples')
out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('engine','batch','goal','phase','event','calls'))
for eng in sys.argv[1:]:
 r=subprocess.run(['taskset','-c','12',w/('count-'+eng),examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
 c=Counter();keep=[]
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'MBEVENT '):c[line.decode().strip()[8:]]+=1
  elif line.startswith(b'STAGE-COUNT '):
   _,b,g,phase,*_=line.decode().split()
   for key,v in sorted(c.items()):out.writerow((eng,b,g,phase,key,v))
   c.clear()
  else:keep.append(line)
 if c or r.stdout!=(gold/'stdout').read_bytes() or b''.join(keep)!=(gold/'stderr').read_bytes():raise ValueError((eng,c,keep[:3]))
 sys.stdout.flush()
