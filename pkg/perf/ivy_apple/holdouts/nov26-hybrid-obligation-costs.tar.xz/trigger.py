from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost'
src=p/'tactic/portfolio/strategic_solver_factory.go';dest=w/'trigger.go';needle='config.PreferConnectedMultiPatterns = true';s=src.read_text();assert s.count(needle)==1
dest.write_text(s.replace(needle,'config.PreferConnectedMultiPatterns = false'))
for tag,files in [('ordinary',json.loads((w/'observer.json').read_text())['Replace']),('ordinary-release',{})]:
 files[str(src)]=str(dest);ov=w/(tag+'.json');ov.write_text(json.dumps({'Replace':files}))
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/tag,'./cmd/goivy_check'],cwd=base/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
