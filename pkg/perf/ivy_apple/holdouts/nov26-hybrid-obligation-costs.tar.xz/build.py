from pathlib import Path
import json,sys,subprocess,os
w=Path(__file__).resolve().parent
base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
files={'z3bridge_solver_model.go':w/'z3bridge_solver_model.go','phase_observer_trial.go':w/'phase-counters/phase_observer_trial.go'}
ov=w/'observer.json';ov.write_text(json.dumps({'Replace':{str(front/k):str(v) for k,v in files.items()}}))
for eng in sys.argv[1:]:
 subprocess.run(['go','build','-buildvcs=false','-pgo=off','-modfile',base/'heap/study.mod','-mod=readonly','-overlay',ov,'-tags','classic_z3,xtrace_off' if eng=='z3' else 'xtrace_off','-o',w/eng,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
