from pathlib import Path
import json,os,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;base=w.parent/'.boolean-enode-cost';src=p/'smtcore/smt_internalizer.go'
for variant in sys.argv[1:]:
 s=subprocess.check_output(['git','show','6e13043d9:pkg/smtcore/smt_internalizer.go'],text=True);lo=s.index('// A proof or assignment callback');hi=s.index('// mk_clause: j =',lo)
 if variant!='base':
  restore=s[lo:hi];s=s[:lo]+s[hi:];target='for _, literal := range literals {';i=s.index(target,s.index('removedFalse := s.clauseRemovedScratch[:0]'));s=s[:i]+restore+s[i:]
 if variant=='checked':
  t=s.index('kept := s.clauseKeptScratch');i=s.index('// mk_clause: j =',t)
  body=s[t:i].replace('for _, literal := range literals {','stateErr := s.open()\n for _, literal := range literals {').replace('value, err := s.Assignment(literal)','if stateErr!=nil {return stateErr}\n value, err := s.literalAssignment(literal)')
  s=s[:t]+body+s[i:]
 dst=w/(variant+'-clause.go');dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
 ov=w/(variant+'-clause.json');ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
 env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
 subprocess.run(['go','test','-c','-pgo=off','-overlay',ov,'-o',w/(variant+'-bench'),'./smtcore'],env=env,check=True)
 if variant!='base':
  subprocess.run(['go','build','-pgo=off','-modfile',base/'heap/study.mod','-buildvcs=false','-mod=readonly','-overlay',ov,'-tags=xtrace_off','-o',w/('clause-'+variant),'./cmd/goivy_check'],cwd=base/'frontend/goivy',env=env,check=True)
