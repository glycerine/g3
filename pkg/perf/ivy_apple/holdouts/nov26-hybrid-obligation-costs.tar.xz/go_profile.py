from pathlib import Path
import subprocess,json,os,sys,csv,re
from collections import Counter
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
sys.path.insert(0,str(p/'perf/ivy_apple'))
from phase_counters import OBSERVER
observer=OBSERVER.split('var phaseCommand')[1].split('func beginMeasuredCheck')[0]
stage=(w/'phase-counters/phase_observer_trial.go').read_text().replace('"fmt"','"fmt"\n"io"')+'\nvar phaseCommand'+observer
patch=(w/'z3bridge_solver_model.go').read_text()
needle='res, err := s.decideZ3With(z3solver, finalCheck)'
assert patch.count(needle)==1
patch=patch.replace(needle,'''selected:=batch==35 && ordinal+1==1
                if selected {phaseSignal("enable")}
                '''+needle+'''
                if selected {phaseSignal("disable")}''')
files={}
for f,code in [('z3bridge_solver_model.go',patch),('phase_observer_trial.go',stage)]:
 dest=w/('window-'+f);dest.write_text(code);files[str(front/f)]=str(dest)
ov=w/'window.json';ov.write_text(json.dumps({'Replace':files}))
examples=Path('/home/jaten/ivy/ivy-lang-examples');gold=w.parent/'.bool-scan/golden/reference/hybrid'
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('engine','round','phase','leaf','samples'))
for eng in ('g3',):
 bin=w/('window-'+eng)
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','xtrace_off,classic_z3' if eng=='z3' else 'xtrace_off','-overlay',ov,'-o',bin,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
 accepted=0
 for i in range(15):
  if accepted==4:break
  d=w/f'go-window-{eng}-{i}';d.mkdir();ctl=d/'ctl';ack=d/'ack';os.mkfifo(ctl);os.mkfifo(ack);raw=d/'perf.data'
  r=subprocess.run(['taskset','-c','15',perf,'record','-m','1024','-B','-N','-D','-1','-e','instructions:u','-c','1000003','--control',f'fifo:{ctl},{ack}','--call-graph','fp,48' if eng=='g3' else 'dwarf,8192','-o',raw,'--',bin,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=d,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include'),IVY_PERF_CONTROL=str(ctl),IVY_PERF_ACK=str(ack)),capture_output=True,timeout=90,check=True)
  lines=r.stderr.splitlines(keepends=True);other=[l for l in lines if not l.startswith((b'STAGE-COUNT ',b'[ perf record:',b'Events enabled',b'Events disabled'))]
  if b''.join(other)!=(gold/'stderr').read_bytes() or r.stdout!=(gold/'stdout').read_bytes():raise ValueError(other[:10])
  records=subprocess.check_output([perf,'report','-D','-i',raw])
  if b'PERF_RECORD_LOST' in records or b'PERF_RECORD_THROTTLE' in records:continue
  counts=Counter()
  for b in subprocess.check_output([perf,'script','--no-inline','-i',raw],text=True).split('\n\n'):
   frames=re.findall(r'^\s+[\da-fA-F]+ (.*?)\+0x',b,re.M)
   if not frames:continue
   phase=next((key for key,anchors in [
    ('candidate build',('buildCandidateModelGenerator','smt::model_generator::mk_model(','smt::context::mk_proto_model(')),
    ('model check',('(*SMTModelChecker).','smt::model_checker::check(')),
    ('instance queue',('(*SMTQuantifierManager).instantiate','smt::qi_queue::instantiate(')),
    ('matching',('(*smtMAM','smt::mam::','smt::mam_impl::')),
    ('rewrite',('(*TheoryRewriter).Rewrite','th_rewriter::operator()')),
   ] if any(a in b for a in anchors)),'other')
   counts[phase,frames[0].split('/pkg/')[-1]]+=1
  accepted+=1
  for (ph,leaf),n in counts.items():out.writerow((eng,accepted,ph,leaf,n))
  sys.stdout.flush()

 assert accepted==4
