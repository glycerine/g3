from collections import Counter,defaultdict
import csv,statistics,sys
rows=list(csv.DictReader(open(sys.argv[1])))
engines=sorted({r['engine'] for r in rows})
print(engines)
by=defaultdict(Counter); phases=defaultdict(list)
for r in rows:
 run,e,b,g=int(r['round']),r['engine'],int(r['batch']),int(r['goal'])
 ph=r['phase'];n=int(r['instructions']);by[e,b,g][run]+=n
 phases[e,b,g,ph].append(n)
med={key:statistics.median(v.values()) for key,v in by.items()}
s=sorted([(sum((1 if e=='g3' else -1)*med.get((e,b,g),0) for e in engines),b,g) for b,g in {(b,g) for e,b,g in med}],reverse=True)
print(len(s),'net',sum(i for i,b,g in s),'top10',sum(i for i,b,g in s[:10]))
for n,b,g in s[:15]:
 print(b,g,round(n/1e6,2),[(e,{ph:round(statistics.median(v)/1e6,2) for (e2,b2,g2,ph),v in phases.items() if (e2,b2,g2)==(e,b,g)}) for e in engines])
