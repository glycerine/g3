"""Rotate the auxiliary clause simplification benchmark across private builds."""
import csv,re,sys,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent;out=csv.writer(sys.stdout,lineterminator='\n')
out.writerow(('round','engine','width','kind','ns_per_op','bytes_per_op','allocs_per_op'))
engines=sys.argv[1:]
for i in range(9):
 for eng in engines[i%len(engines):]+engines[:i%len(engines)]:
  txt=subprocess.check_output(['taskset','-c','16',w/(eng+'-bench'),'-test.run','^$','-test.bench','^BenchmarkSMTAuxiliaryClauseSimplification$','-test.cpu=1','-test.benchtime=20000x'],text=True)
  rows=re.findall(r'^BenchmarkSMTAuxiliaryClauseSimplification/Width(\d+)/Kind(\d+)\s+20000\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',txt,re.M)
  assert len(rows)==10
  for row in rows:out.writerow((i+1,eng,*row))
  sys.stdout.flush()
