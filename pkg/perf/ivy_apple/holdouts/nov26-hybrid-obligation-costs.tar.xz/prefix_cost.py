"""Read the active check counter when model checking starts on the selected obligation."""
from pathlib import Path
import subprocess,sys,os,json,shutil,re,shlex,csv
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy';root=p.parent
src=(w/'phase-counters/phase_observer_trial.go').read_text().replace('"fmt"','"fmt"\n"strconv"')
src=src.replace('start := time.Now()','if batch==35 && goal==1 {os.Setenv("G3_TRIAL_STAGE_FD",strconv.Itoa(int(fd)))}\n start:=time.Now()')
src=src.replace('total := ivyThreadRead(fd)','if batch==35 && goal==1 {os.Unsetenv("G3_TRIAL_STAGE_FD")}\n total:=ivyThreadRead(fd)')
fo=w/'prefix-frontend.go';fo.write_text(src)
examples=Path('/home/jaten/ivy/ivy-lang-examples');ref=w.parent/'.bool-scan/golden/reference/hybrid'
out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('engine','round','candidate_ordinal','adjusted_instructions_since_check_entry','adjusted_full_check'))
for eng in sys.argv[1:]:
 files=json.loads((w/'observer.json').read_text())['Replace'];files[str(front/'phase_observer_trial.go')]=str(fo)
 if eng=='z3':
  build=root/'build';mk=(build/'Makefile').read_text();flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
  f=root/'src/smt/smt_model_checker.cpp';s=f.read_text();needle='bool model_checker::check(proto_model * md, obj_map<enode, app *> const & root2value) {'
  assert s.count(needle)==1
  s=s.replace(needle,needle+'''
       if(auto str=std::getenv("G3_TRIAL_STAGE_FD")) {
           uint64_t counts[3]; if(read(std::atoi(str), counts, sizeof(counts))!=sizeof(counts) || counts[1]!=counts[2]) std::abort();
           fprintf(stderr,"PREFIX %llu\\n",(unsigned long long)counts[0]);
       }''')
  dest=w/'prefix-smt_model_checker.cpp';dest.write_text('#include <cstdio>\n#include <cstdlib>\n#include <unistd.h>\n'+s)
  # The archive member name must match the original object.
  od=w/'prefix-obj';od.mkdir(exist_ok=True);obj=od/'smt_model_checker.o'
  subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',obj,dest],cwd=build,check=True)
  lib=w/'libprefix.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
  q=front/'smt/quantifier.go';dest=w/'prefix-quantifier.go';dest.write_text(q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));files[str(q)]=str(dest)
 else:
  f=p/'smtcore/smt_model_checker.go';s=f.read_text()
  for pkg in ('syscall','strconv','os','unsafe'):
   if '"'+pkg+'"' not in s:s=s.replace('import (','import (\n"'+pkg+'"',1)
  needle='func (c *SMTModelChecker) Check(model *protomodel.ProtoModel, quantifiers []ast.ASTHandle) (bool, error) {'
  assert s.count(needle)==1
  s=s.replace(needle,needle+'''\n if v:=os.Getenv("G3_TRIAL_STAGE_FD"); v!="" {
      fd,e:=strconv.Atoi(v);if e!=nil {panic(e)}
      var counts [3]uint64; n,_,errno:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&counts[0])),24)
      if errno!=0 || n!=24 || counts[1]!=counts[2] {panic("invalid prefix counter")}
      println("PREFIX",counts[0])
  }''')
  dest=w/'prefix-checker.go';dest.write_text(s);files[str(f)]=str(dest)
 ov=w/('prefix-'+eng+'.json');ov.write_text(json.dumps({'Replace':files}));exe=w/('prefix-'+eng)
 subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if eng=='z3' else 'xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
 for i in range(5):
  r=subprocess.run(['taskset','-c','14',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
  keep=[];values=[];found=False
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'PREFIX '):values.append(int(line.split()[1]))
   elif line.startswith(b'STAGE-COUNT '):
    _,b,g,ph,ins,empty,en,run,wall=line.decode().split()
    if (b,g,ph)==('35','1','check'):
     if found or not values or en!=run:raise ValueError((b,g,ph))
     for j,n in enumerate(values):out.writerow((eng,i+1,j+1,n-int(empty),ins))
     found=True
    elif values:raise ValueError((b,g,ph))
    values.clear()
   else:keep.append(line)
  if r.stdout!=(ref/'stdout').read_bytes() or b''.join(keep)!=(ref/'stderr').read_bytes() or not found:raise ValueError(eng)
  sys.stdout.flush()
