from pathlib import Path
import subprocess,os,json,sys
w=Path(__file__).resolve().parent;base=w.parent/'.boolean-enode-cost';p=Path.cwd()
src=p/'smtcore/smt_model_table_check.go'
for engine in sys.argv[1:]:
 s=src.read_text()
 if engine=='outer':
  needle='for i := len(positions) - 1; i >= 0; i-- {'
  repl='for k := 0; k < len(positions); k++ {\n i:=len(positions)-1-k; if !bounded {i=k}'
 elif engine=='reverse':
  needle='bySort[sort] = domain';repl='if !bounded {for i,j:=0,len(domain)-1; i<j; i,j=i+1,j-1 {domain[i],domain[j]=domain[j],domain[i]}}\n'+needle
 assert s.count(needle)==1
 dst=w/(engine+'.go');dst.write_text(s.replace(needle,repl));ov=w/(engine+'.json');ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/(engine+'-release'),'./cmd/goivy_check'],cwd=base/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
