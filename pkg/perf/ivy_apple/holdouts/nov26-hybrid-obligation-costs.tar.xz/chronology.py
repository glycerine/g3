from pathlib import Path
import csv,subprocess,json,os,sys,shutil
from collections import Counter
w=Path(__file__).resolve().parent;base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
examples=Path('/home/jaten/ivy/ivy-lang-examples');ref=w.parent/'.bool-scan/golden/reference/hybrid'
out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('engine','batch','goal','phase','candidate_checks_started','event','count'))
for eng in sys.argv[1:]:
 if eng=='z3':
  files=json.loads((w/'count-z3.json').read_text())['Replace']
  lib=w/'libcombined.a';shutil.copyfile(w/'libobserver.a',lib);subprocess.run(['ar','r',lib,w/'qi_queue.o'],check=True)
  q=front/'smt/quantifier.go';dest=w/'combined-quantifier.go';dest.write_text(q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));files[str(q)]=str(dest)
 else:
  files=json.loads((w/('count-'+eng+'.json')).read_text())['Replace']
  for k,v in json.loads((w/'qi-g3.json').read_text())['Replace'].items():files[k]=v
 ov=w/('timeline-'+eng+'.json');ov.write_text(json.dumps({'Replace':files}));exe=w/('timeline-'+eng)
 subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if eng=='z3' else 'xtrace_off','-mod=readonly','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
 r=subprocess.run(['taskset','-c','16',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,capture_output=True,check=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
 c=Counter();n=0;keep=[]
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'MBEVENT '):
   event=line.decode().strip()[8:]
   if event=='candidate':n+=1
   c[n,event]+=1
  elif line.startswith(b'STAGE-COUNT '):
   _,b,g,phase,*_=line.decode().split()
   for (num,event),value in sorted(c.items()):out.writerow((eng,b,g,phase,num,event,value))
   c.clear();n=0
  else:keep.append(line)
 if c or r.stdout!=(ref/'stdout').read_bytes() or b''.join(keep)!=(ref/'stderr').read_bytes():raise ValueError(eng)
 sys.stdout.flush()
