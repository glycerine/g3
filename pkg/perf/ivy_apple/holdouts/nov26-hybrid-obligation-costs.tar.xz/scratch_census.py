from pathlib import Path
import json,subprocess,csv,os,sys
w=Path(__file__).resolve().parent;base=w.parent/'.boolean-enode-cost';p=Path.cwd();src=p/'smtcore/smt_internalizer.go'
s=subprocess.check_output(['git','show','6e13043d9:pkg/smtcore/smt_internalizer.go'],text=True)
a=s.index('removedFalse := s.clauseRemovedScratch[:0]');b=s.index('// A proof or assignment callback',a)
body=s[a:b].replace('return nil','if cap(kept)>cap(s.clauseKeptScratch) || cap(removedFalse)>cap(s.clauseRemovedScratch) { println("SCRATCH", cap(kept),cap(removedFalse)) };return nil')
dest=w/'scratch-census.go';dest.write_text(s[:a]+body+s[b:]);ov=w/'scratch-census.json';ov.write_text(json.dumps({'Replace':{str(src):str(dest)}}));exe=w/'scratch-audit'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),cwd=base/'frontend/goivy',check=True)
examples=Path('/home/jaten/ivy/ivy-lang-examples');gold=w.parent/'.bool-scan/golden'
out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('case','early_returns_with_growth','retained_prefix_max_capacity','removed_max_capacity'))
for name,(path,iso,rc) in json.loads((gold/'cases.json').read_text()).items():
 r=subprocess.run(['taskset','-c','16',exe,examples/path],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(examples/'ivy/include'),XTRACE_OFF='1'),capture_output=True)
 keep=[];sizes=[]
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'SCRATCH '):sizes.append(list(map(int,line.split()[1:])))
  else:keep.append(line)
 ref=gold/'reference'/name
 if (r.returncode,r.stdout,b''.join(keep))!=(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()):raise ValueError(name)
 out.writerow((name,len(sizes),*(max((z[j] for z in sizes),default=0) for j in (0,1))))
