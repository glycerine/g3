from pathlib import Path
import csv,subprocess,re,sys
from collections import Counter
w=Path(__file__).resolve().parent
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
writer=csv.writer(sys.stdout,lineterminator='\n');writer.writerow(['engine','round','period','phase','samples'])
for e,dirname,period in [('g3','go-window-g3',1000003),('z3','confirmed-z3',500009)]:
 count=0
 for d in sorted(w.glob(dirname+'-*')):
  raw=d/'perf.data'
  records=subprocess.check_output([perf,'report','-D','-i',raw])
  if b'PERF_RECORD_LOST' in records or b'PERF_RECORD_THROTTLE' in records:continue
  c=Counter()
  for b in subprocess.check_output([perf,'script','--no-inline','-i',raw],text=True).split('\n\n'):
   if '(*SMTQuantifierManager).instantiate' not in b and 'smt::qi_queue::instantiate(' not in b:continue
   # Prefer a concrete assertion when it calls the rewriter or the checker.
   key=next((k for k,anchors in [('assertion',('(*SMTInternalizerState).assertExpression','smt::context::internalize_assertion(')),('rewrite',('(*TheoryRewriter).Rewrite','th_rewriter::operator()','rewriter_tpl<th_rewriter_cfg>')),('checker',('(*SMTChecker).','smt::checker::')),('substitution',('(*SMTCachedVarSubstitution).','cached_var_subst::operator()')),('lemma construction',('(*SMTQIInstanceBuilder).finish','ast_manager::mk_app('))] if any(a in b for a in anchors)),'other queue')
   c[key]+=1
  count+=1
  for k,n in c.items():writer.writerow([e,count,period,k,n])
  sys.stdout.flush()
 assert count==4
