from pathlib import Path
import subprocess,sys,os,json
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
for variant in sys.argv[1:]:
 src=p/'smtcore/smt_model_checker.go';s=src.read_text()
 if variant=='certify':needle='if status == lbool.True && !auxiliary.config.CertifyBoundedModelTables {';repl='if false && '+needle[3:]
 elif variant=='off':needle='if (auxiliary.config.CheckUninterpretedModelTables';repl='if false && (auxiliary.config.CheckUninterpretedModelTables'
 assert s.count(needle)==1
 dst=w/(variant+'.go');dst.write_text(s.replace(needle,repl))
 for staged in (True,False):
  files=json.loads((w/'observer.json').read_text())['Replace'] if staged else {}
  files[str(src)]=str(dst);ov=w/(variant+str(staged)+'.json');ov.write_text(json.dumps({'Replace':files}))
  subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/(variant+('' if staged else '-release')),'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
