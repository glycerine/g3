from pathlib import Path
import subprocess,sys,os,json,re,shlex,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();root=p.parent;base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy';build=root/'build'
def subst(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
mode=sys.argv[1]
files=json.loads((w/'observer.json').read_text())['Replace']
if mode=='z3':
 flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row);mk=(build/'Makefile').read_text()
 inc=shlex.split(re.search(r'^includes_39 = (.*)$',mk,re.M)[1]);src=root/'src/smt/qi_queue.cpp';s=src.read_text()
 for a,event in [('void qi_queue::instantiate(entry & ent) {','queued'),('m_context.get_rewriter()(instance, s_instance, pr);','rewritten'),('stat->inc_num_instances();','lemma')]:
  s=subst(s,a,a+'\nstd::fputs("MBEVENT '+event+'\\n",stderr);')
 dest=w/src.name;dest.write_text('#include <cstdio>\n'+s);obj=w/'qi_queue.o'
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dest],cwd=build,check=True)
 lib=w/'libqueue.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
 q=front/'smt/quantifier.go';dest=w/'queue-quantifier.go';dest.write_text(q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));files[str(q)]=str(dest)
else:
 src=p/'smtcore/smt_quantifier_manager.go';s=src.read_text()
 for a,event in [('var prepared SMTQIPreparedInstance','queued'),('if !instance.ReducedTrue() {','lemma')]:
  s=subst(s,a,a+'\nprintln("MBEVENT '+event+'")')
 s=subst(s,'if !instance.ReducedTrue() {','println("MBEVENT rewritten")\nif !instance.ReducedTrue() {')
 dest=w/'queue-manager.go';dest.write_text(s);files[str(src)]=str(dest)
 if mode=='certify':files[str(p/'smtcore/smt_model_checker.go')]=str(w/'certify.go')
ov=w/('qi-'+mode+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','xtrace_off,classic_z3' if mode=='z3' else 'xtrace_off','-overlay',ov,'-o',w/('count-qi-'+mode),'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
