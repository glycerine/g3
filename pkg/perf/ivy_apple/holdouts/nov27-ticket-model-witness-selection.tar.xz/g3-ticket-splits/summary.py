from pathlib import Path
import csv,statistics as st,collections as c
w=Path(__file__).resolve().parent;names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
for stem in ['policy','paired','diagonal','confirmation']:
 f=w/(stem+'.csv')
 if not f.exists():continue
 d=c.defaultdict(lambda:c.defaultdict(list))
 for r in csv.DictReader(f.open()):d[r['case']][r['policy']].append(int(r['instructions']))
 for k,v in d.items():
  if 'off' in v:print(stem,k,[(m,len(x),round(100*(st.median(x)/st.median(v['off'])-1),2)) for m,x in v.items() if m!='off'])
d=c.defaultdict(dict)
for f in w.glob('screen-*.csv'):
 for r in csv.DictReader(f.open()):
  if r['status']=='match':d[int(r['case'])][r['policy']]=int(r['instructions'])
pairs=[((v['prefix']/v['off']-1)*100,(v['prefix']-v['off'])/1e6,i) for i,v in d.items() if len(v)==2]
print('screen pairs',len(pairs))
for pct,delta,i in sorted(pairs,key=lambda x:-abs(x[1]))[:12]:print(i,round(pct,2),round(delta,2),names[i-1])
