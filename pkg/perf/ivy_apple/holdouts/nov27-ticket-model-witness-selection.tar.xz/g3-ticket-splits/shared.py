from pathlib import Path
import os,csv,json,subprocess as sp,itertools
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-arm-pass/release.json').read_text());a=p/'smtcore/smt_model_checker.go';s=a.read_text().replace('import (','import ("os";',1)
s=s.replace('added, err := c.addFiniteCounterexample(quantifier, bindings)','added, err := c.tableCounterexample(quantifier, bindings, c.manager.ResourceLimit().Limit==0 && chooser!=nil)',1)
k='count, err := c.manager.GetNumDeclarations(quantifier)';i=s.index(k,s.index('func (c *SMTModelChecker) addFiniteCounterexample'));s=s[:i]+'''return c.tableCounterexample(quantifier,values,false)
}
var shareMode=os.Getenv("SHARED_BIND")
func(c *SMTModelChecker)tableCounterexample(quantifier ast.ASTHandle,values []ast.ASTHandle,consider bool)(bool,error){
 '''+s[i:]
k='_, err = c.enqueueCounterexample(quantifier, bindings, true, maxGeneration)'
s=s.replace(k,'''if consider && shareMode!="" && len(bindings)==2 && len(c.newInstances)>0 {
 prev:=c.newInstances[len(c.newInstances)-1]
 if len(prev.bindings)==2 && prev.quantifier!=quantifier {
 a,b:=prev.bindings[0]==bindings[0],prev.bindings[1]==bindings[1]
 if (shareMode=="prefix" && a && !b) || (shareMode=="either" && a!=b) || (shareMode=="initial" && a && !b && c.iteration==1) {return false,nil}
 }
 }
 '''+k,1)
b=w/'shared.go';b.write_text(s);ov['Replace'][str(a)]=str(b);j=w/'shared.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'shared','./cmd/goivy_check'],cwd=front,check=True)
