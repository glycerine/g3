from pathlib import Path
import json,subprocess as sp,os,csv
p=Path.cwd();w=Path(__file__).resolve().parent;ov=json.loads((w/'trial.json').read_text())
a=p/'smtcore/smt_model_checker.go';s=Path(ov['Replace'][str(a)]).read_text().replace('if trialMode=="all"','''if trialMode=="describe" && trialCandidate==1 {println("DATA witness",trialWitness,count,witnessTree(c.manager,body));for i,v:=range bindings{term,gen,ok,e:=c.modelFinder.Inverse(quantifier,uint32(i),v);if e!=nil{panic(e)};println("DATA bind",trialWitness,i,gen,ok,witnessTree(c.manager,term))}}
 if (trialCandidate==1 && trialMask & (1<<(trialWitness-1)) != 0) || trialMode=="all"''')
s=s.replace('import ("os";','import ("os";"strings";"strconv";');src=(w/'smt_qi_queue_schedule.go.txt').read_text();s+='\n'+src[src.index('func trialTree('):]+'\nvar trialMask,_=strconv.Atoi(os.Getenv("MASK"))\n'
b=w/'mask.go';b.write_text(s);ov['Replace'][str(a)]=str(b);j=w/'mask.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'mask','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
ref=Path('/tmp/g3-reduction-rows/compat/6/1/native');ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'masks.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round mask instructions calls'.split())
 for i in range(3):
  for mask in [(j+i*11)%32 for j in range(32)]:
   r=sp.run(['taskset','-c','12',w/'mask',ex/'examples/liveness/ticket_nested.ivy'],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',BATCH='16',GOAL='1',MASK=str(mask),EXPERIMENT='describe' if i==0 and mask==0 else '',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,check=True)
   rest=[];calls=0;vals=[];desc=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'TRIAL delegate '):calls+=1
    elif l.startswith(b'DATA '):desc.append(l)
    elif l.startswith(b'STAGE-COUNT '):a=l.split();assert a[6]==a[7];vals.append(int(a[4]))
    else:rest.append(l)
   if desc:(w/'witnesses.txt').write_bytes(b''.join(desc))
   assert len(vals)==1 and calls==mask.bit_count() and (r.stdout,b''.join(rest))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(mask,calls,rest[-2:])
   out.writerow([i,mask,vals[0],calls]);f.flush()
