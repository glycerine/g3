from pathlib import Path
import os,sys,csv,subprocess as sp,json
p=Path.cwd();w=Path(__file__).resolve().parent;prev=Path('/tmp/g3-ticket-first');front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();base=Path('/tmp/g3-arm-pass/release.json')
s=(prev/'build.py').read_text().replace('/tmp/g3-selective/final/overlay.json',str(base)).replace('batch==4 && index==54','batch==trialTarget && index+1==trialGoal').replace("+'\\nvar trialBatch int\\n'", "+'\\nvar trialBatch int\\nvar trialTarget,_=strconv.Atoi(os.Getenv(\"BATCH\"))\\nvar trialGoal,_=strconv.Atoi(os.Getenv(\"GOAL\"))\\n'")
exec(s.replace('import ("github.com/glycerine','import ("strconv";"github.com/glycerine'))
ov=json.loads(base.read_text());a=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(a)]).read_text();k='func (s *Solver) GetSmallModelWithCond(';i=s.index(k);j=s.index('s.showVCsBase(clauses)',i)
s=s[:j]+'trialBatch++;batch:=trialBatch\n '+s[j:];k='res, err := s.decideZ3With(z3solver, finalCheck)';s=s.replace(k,'''target:=batch==trialTarget && index+1==trialGoal
 if target{os.Setenv("G3_WITNESS_STAGE","yes");os.Setenv("G3_WITNESS_INDEX","0")}
 '''+k+'''
 if target{os.Unsetenv("G3_WITNESS_STAGE")}''')
b=w/'native-bridge.go.txt';b.write_text(s.replace('import (','import ("strconv";',1)+'\nvar trialBatch int\nvar trialTarget,_=strconv.Atoi(os.Getenv("BATCH"))\nvar trialGoal,_=strconv.Atoi(os.Getenv("GOAL"))\n');ov['Replace'][str(a)]=str(b);ov['Replace'][str(front/'smt/quantifier.go')]='/tmp/g3-queue-arrivals/z3-all-quantifier.go'
j=w/'native.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off,classic_z3','-pgo=off','-overlay',j,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'native','./cmd/goivy_check'],cwd=front,check=True)
