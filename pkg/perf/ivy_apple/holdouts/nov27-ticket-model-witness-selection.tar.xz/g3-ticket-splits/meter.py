from pathlib import Path
import json,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'overlay.json').read_text());a=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(a)]).read_text()
k='if batch==trialTarget && index+1==trialGoal{smtcore.TrialActive=true;println("TRACE start")}'
assert k in s;s=s.replace(k,'var end func(string);if batch==trialTarget && index+1==trialGoal {smtcore.TrialActive=true;end=startStage(batch,index+1)}').replace('if batch==trialTarget && index+1==trialGoal{smtcore.TrialActive=false;println("TRACE stop")}','if end!=nil{smtcore.TrialActive=false;end("check")}')
b=w/'meter-bridge.go.txt';b.write_text(s);ov['Replace'][str(a)]=str(b);ov['Replace'][str(front/'phase_observer_trial.go')]='/tmp/g3-live-numeral/ticket/phase_observer_trial.go.txt'
for n in ['smt_search.go','smt_quantifier_manager.go','smt_qi_queue_schedule.go']:del ov['Replace'][str(p/'smtcore'/n)]
a=p/'smtcore/smt_activity_heap_queue.go';s=Path(ov['Replace'][str(a)]).read_text().replace('println("TRACE force",trialPop,v,witnessTree(q.state.manager,q.state.boolExpr[v]));','println("TRIAL used",trialPop,v);');b=w/'meter-queue.go';b.write_text(s+'\nvar TrialActive bool\n');ov['Replace'][str(a)]=str(b)
j=w/'meter.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'meter','./cmd/goivy_check'],cwd=front,check=True)
