from pathlib import Path
import os,json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads((w/'mask.json').read_text());a=p/'smtcore/smt_model_checker.go';s=Path(ov['Replace'][str(a)]).read_text()
k='inserted, err := c.enqueueCounterexample(quantifier, bindings, useInverse, generation)'
s=s.replace(k,'''if TrialActive && c==trialOwner && trialCandidate==1 {println("DATA recovered",trialWitness,*remaining);for i,v:=range bindings{println("DATA recovered-bind",i,witnessTree(c.manager,v),witnessTree(c.manager,raw[i]))}}
 '''+k)
# The nested ABI uses decl-order tuples. Compare every concrete binary trial with the scalar model.
b=w/'bindings-checker.go';b.write_text(s);ov['Replace'][str(a)]=str(b)
a=p/'smtcore/smt_model_table_check.go';s=a.read_text();k='if witness := g.witness(bindings); witness != nil {'
s=s.replace(k,k+'''
 if TrialActive && trialCandidate==1 && trialWitness==2 && count==2 && checker!=nil {
 work,incomplete:=g.work,g.incomplete
 for _,left:=range domains[0]{for _,right:=range domains[1]{tuple:=[]int{right,left};g.work=100000;g.incomplete=false
 if g.evaluate(root,tuple,0)!=tableFalse || g.incomplete {continue};vals:=g.witness(tuple);if vals==nil{continue}
 t,_,ok,_:=checker.modelFinder.Inverse(flat,0,vals[0]);u,_,ok2,_:=checker.modelFinder.Inverse(flat,1,vals[1]);if ok && ok2{println("DATA feasible",left,right,witnessTree(g.manager,t),witnessTree(g.manager,u))}
 }};g.work,g.incomplete=work,incomplete
 }
''',1)
b=w/'bindings-table.go';b.write_text(s);ov['Replace'][str(a)]=str(b)
j=w/'bindings.json';j.write_text(json.dumps(ov));sp.run(['go','build','-buildvcs=false','-mod=readonly','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'bindings','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows/compat/6/1/native')
r=sp.run([w/'bindings',ex/'examples/liveness/ticket_nested.ivy'],env=dict(os.environ,GOGC='off',GOMAXPROCS='1',BATCH='16',GOAL='1',MASK='4',EXPERIMENT='describe',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,check=True);ls=r.stderr.splitlines(keepends=True)
assert (r.stdout,b''.join(l for l in ls if not l.startswith((b'DATA ',b'TRIAL ',b'STAGE-COUNT '))))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
(w/'selected.txt').write_bytes(b''.join(l for l in ls if l.startswith(b'DATA ')))
