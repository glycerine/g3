from pathlib import Path
import os,json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'smtcore/smt_model_table_check.go'
s=a.read_text().replace('import (','import ("os";',1)+'\nvar diagonalPolicy=os.Getenv("SHARED_BIND")\n'
k='if witness := g.witness(bindings); witness != nil {'
s=s.replace(k,k+'''
 if !bounded && checker!=nil && count==2 && sorts[0]==sorts[1] && bindings[0]!=bindings[1] && diagonalPolicy!="" {
 eligible:=diagonalPolicy=="any"; if !eligible && len(checker.newInstances)>0 {
 prev:=checker.newInstances[len(checker.newInstances)-1]
 if len(prev.bindings)==2 && prev.quantifier!=flat {
  left,_,ok,e:=checker.modelFinder.Inverse(flat,0,witness[0]); if e!=nil{return lbool.Undef,nil,e}
  if ok && left==prev.bindings[0] {
  right,_,ok,e:=checker.modelFinder.Inverse(flat,1,witness[1]);if e!=nil{return lbool.Undef,nil,e};eligible=ok && right!=prev.bindings[1]
  }
 }
 }
 if eligible {
 same:=[2]int{bindings[0],bindings[0]}
 if g.evaluate(root,same[:],0)==tableFalse && !g.incomplete && g.work>0 {
  _,_,ok,e:=checker.modelFinder.Inverse(flat,0,witness[1]);if e!=nil{return lbool.Undef,nil,e}
  if ok {witness[0]=witness[1];return lbool.True,witness,nil}
 }
 if diagonalPolicy=="fallback"{return lbool.Undef,nil,nil}
 }
 }
''',1)
b=w/'diagonal.go';b.write_text(s);ov=json.loads(Path('/tmp/g3-arm-pass/release.json').read_text());ov['Replace'][str(a)]=str(b);j=w/'diagonal.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'diagonal','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
