from pathlib import Path
import os,subprocess as sp,csv,sys,collections as c
w=Path(__file__).resolve().parent;rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
for nr,b,g in [(6,16,1),(3,2,55)]:
 case=(rank/'compat.txt').read_text().splitlines()[nr-1];ref=rank/'compat'/str(nr)/'1/native'
 for en in ('observe','native'):
  env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),BATCH=str(b),GOAL=str(g),G3_WITNESS_TRACE='1')
  r=sp.run(['taskset','-c','14',w/en,ex/case],cwd=w,env=env,capture_output=True,check=True)
  rest=[];prefix=b'TRACE ' if en=='observe' else b'WT '
  with (w/f'{nr}-{en}.csv').open('w') as f:
   o=csv.writer(f);o.writerow(['event','value'])
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(prefix):
     k,_,v=l[len(prefix):].rstrip().decode().partition(' ')
     if k in ('split','offer','formula'):o.writerow([k,v])
    else:rest.append(l)
  assert (r.stdout,b''.join(rest))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),rest[-2:]
