from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'trial.py').read_text();s=s[:s.index('ov=json.loads')] + s[s.index('ex=Path'):]
s=s.replace("w/'trials.csv'","w/'splits.csv'").replace("[(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]","[(3,2,55,['default','4','5','6','both'])]").replace("w/'trial'","p/'build/nov27-pass-tmp/ticket-observers/trial'").replace("EXPERIMENT=mode","EXPERIMENT='order' if mode=='both' else '',FORCE_POP='6' if mode=='both' else mode,FORCE_VAR='0' if mode=='default' else '130'");exec(s)
