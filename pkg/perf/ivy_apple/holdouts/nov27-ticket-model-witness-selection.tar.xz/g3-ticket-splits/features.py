from pathlib import Path
import csv,json,subprocess as sp,os
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads((w/'shared.json').read_text());a=p/'smtcore/smt_model_checker.go';s=Path(ov['Replace'][str(a)]).read_text()
k='&& c.iteration==1) {return false,nil}'
assert k in s;s=s.replace(k,'''&& c.iteration==1) {s0,e:=c.manager.GetSort(bindings[0]);if e!=nil{return false,e};s1,e:=c.manager.GetSort(bindings[1]);if e!=nil{return false,e}; println("FEATURE",len(c.state.boolExpr),c.registry.NumQuantifiers(),len(c.newInstances),c.iteration,prev.generation,maxGeneration,s0==s1,c.state.statistics.NumDecisions,c.state.statistics.NumConflicts);return false,nil}'''.replace('c.registry.NumQuantifiers()','c.maxCexs'))
b=w/'features.go';b.write_text(s);ov['Replace'][str(a)]=str(b);j=w/'features.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'features','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');names=(rank/'compat.txt').read_text().splitlines()
with (w/'features.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case variables maxcexs pending iteration previous_generation generation same_sort decisions conflicts'.split())
 for nr in (6,227,225,11,196,201,2,4,3,5,12,8):
  name=names[nr-1];d=rank/'compat'/str(nr)/'1/native'
  r=sp.run(['taskset','-c','24',w/'features',ex/name],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),SHARED_BIND='prefix'),cwd=w,capture_output=True);rest=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'FEATURE '):o.writerow([nr,*l.decode().split()[1:]])
   else:rest.append(l)
  assert (r.stdout,b''.join(rest))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes());f.flush()
