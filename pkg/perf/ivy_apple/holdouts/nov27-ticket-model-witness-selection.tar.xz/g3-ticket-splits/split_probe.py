from pathlib import Path
import os,subprocess as sp,csv
w=Path(__file__).resolve().parent;p=Path.cwd();binary=p/'build/nov27-pass-tmp/ticket-observers/observe';ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');name=(rank/'compat.txt').read_text().splitlines()[2];ref=rank/'compat/3/1/native'
with (w/'eligibility.csv').open('w') as f:
 out=csv.writer(f);out.writerow('pop split status selected'.split())
 for pop in [4,5,6]:
  r=sp.run([binary,ex/name],env=dict(os.environ,GOGC='off',GOMAXPROCS='1',BATCH='2',GOAL='55',FORCE_VAR='130',FORCE_POP=str(pop),XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True)
  rest=[];n=0;chosen='';pos=0
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'TRACE split '):n+=1
   elif l.startswith(b'TRACE force '):chosen=l.decode().strip();pos=n+1
   elif not l.startswith(b'TRACE '):rest.append(l)
  status='match' if (r.returncode,r.stdout,b''.join(rest))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()) else 'ineligible' if b'panic: ineligible trial' in r.stderr else 'different'
  out.writerow([pop,pos,status,chosen]);f.flush()
