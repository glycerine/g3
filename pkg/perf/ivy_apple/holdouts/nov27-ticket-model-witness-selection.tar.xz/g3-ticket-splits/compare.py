import sys,csv,collections as c
from pathlib import Path
w=Path(__file__).resolve().parent
sys.path.insert(0,'/tmp/g3-ticket-first');from analyze import norm
for nr in (6,3):
 histories=[]
 for en in ('observe','native'):
  names=c.defaultdict(dict);history=[]
  for r in csv.DictReader((w/f'{nr}-{en}.csv').open()):
   k,v=r['event'],r['value'];value=v.split(' ',1)[1] if k=='split' else v
   history.append((k,norm(value,names[k]),v))
  histories.append(history)
 for ev in ('all','split','offer','formula'):
  a,b=([v for v in h if ev=='all' or v[0]==ev] for h in histories)
  n=next((i for i,(x,y) in enumerate(zip(a,b)) if x[:2]!=y[:2]),min(len(a),len(b)))
  print(nr,ev,'common',n,'counts',len(a),len(b))
  if n<min(len(a),len(b)):
   print('preceded',c.Counter(x[0] for x in a[:n]));print(a[n][0],a[n][2][:240]);print(b[n][0],b[n][2][:240])
