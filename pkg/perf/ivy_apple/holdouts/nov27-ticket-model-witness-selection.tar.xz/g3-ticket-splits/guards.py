from pathlib import Path
import json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads((w/'shared.json').read_text());a=p/'smtcore/smt_model_checker.go';s=Path(ov['Replace'][str(a)]).read_text()
i=s.index('if (shareMode=="prefix"');j=s.index(' {return false,nil}',i)
s=s[:i]+'''if a&&!b {
 same:=false
 if shareMode=="sort" {u,_:=c.manager.GetSort(bindings[0]);v,_:=c.manager.GetSort(bindings[1]);same=u==v}
 if shareMode=="prefix" || shareMode=="sort" && same || shareMode=="conflict" && c.state.statistics.NumConflicts>c.state.searchConflictBase || shareMode=="ground" && prev.generation==0 && maxGeneration==0 || shareMode=="pending" && len(c.newInstances)>1'''+s[j:];s=s.replace(' {return false,nil}', ' {return false,nil}}',1)
b=w/'guards.go';b.write_text(s);ov['Replace'][str(a)]=str(b);j=w/'guards.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'guards','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
