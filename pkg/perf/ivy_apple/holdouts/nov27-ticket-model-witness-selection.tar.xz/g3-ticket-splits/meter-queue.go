package smtcore

// Source: src/smt/smt_case_split_queue.cpp:64-148 act_case_split_queue.

import ("os";"strconv";
	"fmt"
	"io"

	"github.com/glycerine/g3/pkg/ast"
	uheap "github.com/glycerine/g3/pkg/util/heap"
	"github.com/glycerine/g3/pkg/util/lbool"
)

func (s *SMTInternalizerState) ensureBasicActivityQueue() error {
	if err := s.open(); err != nil {
		return err
	}
	if s.basicActivity != nil {
		return nil
	}
	h, err := uheap.New(1024, uheap.Config{Budget: s.manager.Budget(), Activity: &s.activity})
	if err != nil {
		return err
	}
	// Source creates the reserved true variable before ordinary variables.
	// Standalone Go selectors can be configured after internalization; seed
	// the existing variables in their original creation order exactly once.
	for v := int32(0); int(v) < len(s.boolExpr); v++ {
		if err = h.Reserve(v + 1); err == nil {
			err = h.Insert(v)
		}
		if err != nil {
			_ = h.Close()
			return err
		}
	}
	s.basicActivity = h
	return nil
}

func (s *SMTInternalizerState) basicActivityCreated(v int32) error {
	if s.basicActivity == nil {
		return nil
	}
	if !smtcoreSourceDebug {
		target, other := s.basicActivity, s.delayedActivity
		if other != nil && s.searching {
			target, other = other, target
		}
		if (other == nil || v < other.Bounds()) && target.TryInsertReservedActivity(v) {
			return nil
		}
	}
	if smtcoreSourceDebug || v >= s.basicActivity.Bounds() {
		if err := s.basicActivity.Reserve(v + 1); err != nil {
			return err
		}
	}
	if s.delayedActivity != nil {
		if smtcoreSourceDebug || v >= s.delayedActivity.Bounds() {
			if err := s.delayedActivity.Reserve(v + 1); err != nil {
				return err
			}
		}

		if err := smtCaseSplitAssert(173, "!m_delayed_queue.contains(v)", func() bool { return !s.delayedActivity.Contains(v) }); err != nil {
			return err
		}
		if err := smtCaseSplitAssert(174, "!m_queue.contains(v)", func() bool { return !s.basicActivity.Contains(v) }); err != nil {
			return err
		}
		if s.searching {
			return s.delayedActivity.Insert(v)
		}
	} else if err := smtCaseSplitAssert(85, "!m_queue.contains(v)", func() bool { return !s.basicActivity.Contains(v) }); err != nil {
		return err
	}
	return s.basicActivity.Insert(v)
}

func (s *SMTInternalizerState) basicActivityUnassigned(v int32) error {
	if s.basicActivity != nil && !s.basicActivity.Contains(v) {
		return s.basicActivity.Insert(v)
	}
	return nil
}

func (s *SMTInternalizerState) basicActivityDeleted(v int32) error {
	if err := s.basicActivity.EraseIfPresent(v); err != nil {
		return err
	}
	return s.delayedActivity.EraseIfPresent(v)
}

func (q *SMTActivityCaseSplitQueue) nextBasicActivity() (int32, lbool.LBool, error) {
	h := q.state.basicActivity
	if h == nil {
		if err := q.state.ensureBasicActivityQueue(); err != nil {
			return SMTNullBoolVar, lbool.Undef, err
		}
		h = q.state.basicActivity
	}
	if v, err := q.randomVariable(q.randomVariableFrequency); err != nil || v != SMTNullBoolVar {
		return v, lbool.Undef, err
	}
	if TrialActive {trialPop++; if trialPop==forcePop && forceVar>0{v:=int32(forceVar);value,e:=q.state.Assignment(NewSMTLiteral(v,false));if e!=nil || value!=lbool.Undef || !h.Contains(v){panic("ineligible trial")};println("TRIAL used",trialPop,v);return v,lbool.Undef,h.Erase(v)} }
 return q.state.popBasicActivityHeap()
}

func (s *SMTInternalizerState) popBasicActivityHeap() (int32, lbool.LBool, error) {
	h := s.basicActivity
	for !h.Empty() {
		v, err := h.EraseMin()
		if err != nil {
			return SMTNullBoolVar, lbool.Undef, err
		}
		value, err := s.Assignment(NewSMTLiteral(v, false))
		if err != nil {
			return SMTNullBoolVar, lbool.Undef, err
		}
		if value == lbool.Undef {
			return v, lbool.Undef, nil
		}
	}
	return SMTNullBoolVar, lbool.Undef, nil
}

func (s *SMTInternalizerState) DisplayBasicActivityQueue(out io.Writer) error {
	if err := s.open(); err != nil {
		return err
	}
	if out == nil {
		return ast.ErrASTHandle
	}
	if s.basicActivity == nil {
		return nil
	}
	values, err := s.basicActivity.AppendValues(nil)
	if err != nil {
		return err
	}
	first := true
	for _, v := range values {
		value, err := s.Assignment(NewSMTLiteral(v, false))
		if err != nil {
			return err
		}
		if value != lbool.Undef {
			continue
		}
		if first {
			if err = smtWriteTheoryText(out, "remaining case-splits:\n"); err != nil {
				return err
			}
			first = false
		}
		id, err := s.manager.GetASTID(s.boolExpr[v])
		if err != nil {
			return err
		}
		if err = smtWriteTheoryText(out, fmt.Sprintf("#%d ", id)); err != nil {
			return err
		}
	}
	if !first {
		return smtWriteTheoryText(out, "\n")
	}
	return nil
}

// Source cact_case_split_queue inherits the ordinary consuming heap.
func (s *SMTInternalizerState) ensureCachedActivityQueue() error {
	if err := s.ensureBasicActivityQueue(); err != nil {
		return err
	}
	s.cachedActivity = true
	return nil
}

var trialPop int
var forceVar,_=strconv.Atoi(os.Getenv("FORCE_VAR"))
var forcePop,_=strconv.Atoi(os.Getenv("FORCE_POP"))

var TrialActive bool
