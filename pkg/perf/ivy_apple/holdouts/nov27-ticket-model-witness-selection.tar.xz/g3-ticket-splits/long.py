from pathlib import Path
import json,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/apple-source/goivy').resolve()
ov=json.loads(Path('/tmp/g3-selective/final/apple.json').read_text());ov['Replace'][str(p/'smtcore/smt_model_checker.go')]=str(w/'guards.go');j=w/'apple.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-o',w/'apple','./cmd/goivy_check'],cwd=front,check=True)
s=Path('/tmp/g3-plan-budget/long.py').read_text();s=s[:s.index('bin=Path')]+s[s.index('ex=Path'):];s=s.replace("modes=['base','256','512']","modes=['off','pending']").replace('for m in modes[i:]+modes[:i]:','for m in modes[i%2:]+modes[:i%2]:').replace("exe=bin/m if apple else (Path('/tmp/g3-live-frame-cost/recheck/baseline') if m=='base' else w/m/'release')","exe=w/('apple' if apple else 'guards')").replace("XTRACE_OFF='1'","XTRACE_OFF='1',SHARED_BIND='' if m=='off' else m");exec(s)
