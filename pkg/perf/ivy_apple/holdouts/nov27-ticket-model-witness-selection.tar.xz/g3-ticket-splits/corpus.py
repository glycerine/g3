from pathlib import Path
import csv,concurrent.futures,os
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-or-install/final/release.py').read_text();s=s[:s.index('subprocess.run([*flags')]+s[s.index('def run'):s.index('run(12,')]
exec(s);policy=os.environ.get('SHARED_BIND','prefix');os.environ['SHARED_BIND']=policy;modes={policy:w/os.getenv('EXE','shared')}
with concurrent.futures.ThreadPoolExecutor(6) as pool:
 jobs=[pool.submit(run,1+i*2,policy+'-panel'+str(i),cases[i::6],1,[policy]) for i in range(6)]
 for job in jobs:job.result()
