from pathlib import Path
from trial import panel
import guards
c={}
src=Path(__file__).with_name('shapes.py').read_text()
exec(src[:src.rindex("panel(['probe'],patch,run)")],c)
def patch(pkg,name):
    for p,s in guards.patch(pkg,'all'):
        if p.name.endswith('stat.go'):
            yield p,s
            continue
        s=p.read_text()
        a='return q.instantiate([]SMTQIQueueEntry{entry})\n\t}, q.state.resourceLimitsExceeded)'
        yield p,s.replace(a,'''if StudyGoal {
          quant:=entry.Fingerprint.data;guard:=q.registry.statistics[quant].studyGuard
          if !guard.IsNull(){println("ROWBEGIN",quant.Slot(),quant.Generation(),int(q.state.context.getAssignment(guard)),entry.Cost<=q.registry.schedule.lazyThreshold)}
        }
        '''+a)+'\nvar StudyGoal bool\n'
panel(['probe'],patch,c['run'])
