from pathlib import Path
import csv,statistics as st
for folder in ('bindings','guards','findapp'):
 for f in sorted((Path(__file__).resolve().parent/folder).glob('time*')):
    rows=list(csv.DictReader(f.open()))
    med={}
    for row in rows:
        med.setdefault(row['engine'],[]).append(int(row['instructions']))
    if 'base' in med:
        print(folder,f.stem,len(rows),{k:round(100*(st.median(v)/st.median(med['base'])-1),2) for k,v in med.items() if k!='base'})
