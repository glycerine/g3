from trial import panel
from adaptive import run

def patch(pkg,name):
    if name == 'base':
        return
    p = pkg/'smtcore/smt_quantifier_stat.go'
    s = p.read_text().replace('candidateChecks ', 'studyGuard ast.ASTHandle\n candidateChecks ', 1)
    marker = 'result.caseSplitFactor = caseSplit.Value()'
    assert marker in s
    yield p, s.replace(marker,'result.studyGuard = studyUnaryGuard(g.manager,quantifier,body)\n '+marker) + """
func studyUnaryGuard(m *ast.ASTManager, q, body ast.ASTHandle) ast.ASTHandle {
    var absent ast.ASTHandle
    n,e := m.GetNumDeclarations(q)
    if e!=nil || n!=1 { return absent }
    patterns,e := m.GetNumPatterns(q)
    if e!=nil || patterns<2 {return absent}
    h,e:=m.NodeHeader(body)
    if e!=nil || h.Kind!=ast.ASTApp || h.Family!=m.BasicFamilyID() || h.DeclKind!=ast.ASTOpOr || h.NumArgs<3 {return absent}
    for i:=uint32(0);i<h.NumArgs;i++ {
        lit,e:=m.GetArg(body,i)
        if e!=nil{return absent}
        neg,child,e:=m.IsNot(lit)
        if e!=nil{return absent}
        atom:=lit
        if neg{atom=child}
        h,e:=m.NodeHeader(atom)
        if e==nil && h.Kind==ast.ASTApp && h.NumArgs==0 && h.Family==ast.NullFamilyID{return lit}
    }
    return absent
}
"""
    p=pkg/'smtcore/smt_quantifier_manager.go'
    a='return q.instantiate([]SMTQIQueueEntry{entry})\n\t}, q.state.resourceLimitsExceeded)'
    s=p.read_text()
    assert s.count(a)==1
    extra={'all':'','undef':' && q.state.context.getAssignment(guard)==lbool.Undef','false':' && q.state.context.getAssignment(guard)==lbool.False'}[name]
    yield p,s.replace(a,'''guard:=q.registry.statistics[entry.Fingerprint.data].studyGuard
    if !guard.IsNull() && entry.Cost<=q.registry.schedule.lazyThreshold'''+extra+'''{
        promote,e:=q.promoteUnsatEntry(entry);if e!=nil{return e}
        if !promote{entry.Instantiated=false;q.registry.schedule.delayedEntries=append(q.registry.schedule.delayedEntries,entry);return nil}
    }
    '''+a)

if __name__=='__main__':panel(['base','all','undef','false'],patch,run)
