from trial import panel
from bindings import run

def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_cg_table.go'
    s=p.read_text()
    at=s.index('func (t *SMTCongruenceTable) FindApp')
    a='found, _, err := bucket.find(&tmp)'
    assert a in s[at:]
    extra='''
    if len(args)<=2 {
        a:=args[0].root
        var b *SMTEnode
        if len(args)==2 {b=args[1].root}
        hit:=bucket.small.get(a,b)
        if hit!=nil && len(hit.arguments)==len(args) && hit.arguments[0].root==a && (len(args)==1 || hit.arguments[1].root==b) {
            return hit,nil
        }
        if hit==nil && !(commutative && len(args)==2 && a!=b && !bucket.flatAssociative){return nil,nil}
    }
    '''
    yield p,s[:at]+s[at:].replace(a,extra+a)
if __name__=='__main__':panel(['base','trial'],patch,run)
