import bindings,findapp,tempfile,os,json,subprocess
from pathlib import Path
pkg=Path.cwd()
out=Path(os.environ['RESULTS'])
out.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as temp:
    d=Path(temp)
    for name,module in [('base',None),('bindings',bindings),('findapp',findapp)]:
        mapping={}
        if module:
            for p,s in module.patch(pkg,'trial'):
                dest=d/(name+p.name)
                dest.write_text(s)
                mapping[str(p)]=str(dest)
        j=d/'overlay.json'
        j.write_text(json.dumps({'Replace':mapping}))
        subprocess.run(['go','test','-overlay',j,'-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-c','-o',d/name,'./smtcore'],check=True)
    cases=['base','bindings','findapp']
    for i in range(5):
        for name in cases[i%3:]+cases[:i%3]:
            with (out/(name+'.txt')).open('a') as f:
                subprocess.run(['taskset','-c',os.environ['PROBE_CPU'],d/name,'-test.run','^$','-test.bench','BenchmarkSMTQuantifierCandidate$/Width4/First/RegisteredChecker|BenchmarkSMTCongruenceProbes$/(Ordered|Miss|Commuted|PositionalMiss)$','-test.benchtime','250000x','-test.cpu','1'],stdout=f,check=True)
