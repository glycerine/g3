"""Extend the verified full-proof observer with insertion, batch and dispatch events."""
from pathlib import Path
import csv,json,os,re,shlex,shutil,subprocess,sys
w=Path(__file__).resolve().parent;old=w.parent/'g3-clause-confirmation';p=Path.cwd()
b=(p/'build/.boolean-enode-cost').resolve();f=b/'frontend/goivy';n=(p/'build/.witness-origin/search-native').resolve()
e=sys.argv[1];files=json.loads((old/('search-'+e+'.json')).read_text())['Replace']
def sub(s,a,z):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
def save(k,s):
 dst=w/(e+'-'+k.name);dst.write_text(s);files[str(k)]=files[str(k.resolve())]=str(dst)
if e=='g3':
 k=p/'smtcore/smt_qi_queue_schedule.go';s=k.read_text();s=sub(s,'import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast"; )\nimport (\n"fmt"\n"strings" )')
 s+='''
func queueEvent(m *ast.ASTManager, phase string, f *SMTFingerprint,c float32,g uint32){
 if !witnessTrace(){return}
 var b strings.Builder
 fmt.Fprintf(&b,"%g %d %s",c,g,witnessTree(m,f.data))
 for _,v:=range f.args {b.WriteString(" | ");b.WriteString(witnessTree(m,v.Owner()))}
 println("WT "+phase,b.String())
}
'''
 a='q.newEntries = append(q.newEntries,';s=sub(s,a,'queueEvent(q.manager,"offer",fingerprint,cost,generation)\n'+a)
 a='sinceLastCheck := 0';s=sub(s,a,'if witnessTrace() && len(q.newEntries)>0 {println("WT batch",len(q.newEntries))}\n'+a);save(k,s)
 k=p/'smtcore/smt_quantifier_manager.go';s=Path(files[str(k)]).read_text()
 a='var prepared SMTQIPreparedInstance';s=sub(s,a,'queueEvent(q.state.manager,"pick",entry.Fingerprint,entry.Cost,entry.Generation)\n'+a);save(k,s)
else:
 build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 s=(n/'qi_queue.cpp').read_text();a='namespace smt {';s=sub(s,a,a+'''
static void ev(const char* phase,fingerprint*f,float cost,unsigned gen) {
 if(!active())return;
 std::ostringstream out;shape(out,static_cast<quantifier*>(f->get_data()));
 for(unsigned i=0;i<f->get_num_args();++i){out<<" | ";shape(out,f->get_arg(i)->get_owner());}
 fprintf(stderr,"WT %s %g %u %s\\n",phase,cost,gen,out.str().c_str());
}
''')
 a='m_new_entries.push_back(entry(f, cost, generation));';s=sub(s,a,'ev("offer",f,cost,generation);'+a)
 a='for (entry & curr : m_new_entries) {';s=sub(s,a,'if(active()&&!m_new_entries.empty())fprintf(stderr,"WT batch %u\\n",m_new_entries.size());\n'+a)
 a='ent.m_instantiated = true;';s=sub(s,a,'ev("pick",f,ent.m_cost,generation);'+a)
 dst=w/'qi_queue.cpp';dst.write_text(s);obj=w/'qi_queue.o';lib=w/'libevents.a';shutil.copyfile(n/'lib.a',lib)
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dst],cwd=build,check=True);subprocess.run(['ar','r',lib,obj],check=True)
 k=f/'smt/quantifier.go';s=Path(files[str(k)]).read_text();s=re.sub(r'(?<=#cgo LDFLAGS: )[^\n]+/lib.a',str(lib),s);save(k,s)
ov=w/(e+'.json');ov.write_text(json.dumps({'Replace':files}));binary=w/e
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',ov,'-o',binary,'./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=p/'build/.bool-scan/golden/reference/hybrid'
r=subprocess.run(['taskset','-c','14',binary,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',G3_WITNESS_TRACE='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=True)
keep=[];pending=[];cand=0;found=set()
with (w/(e+'.csv')).open('w') as file:
 wr=csv.writer(file);wr.writerow(['batch','goal','candidate','event','value'])
 for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'WT '):
        parts=line.rstrip().decode().split(' ',2);cand+=parts[1]=='candidate'
        pending.append((cand,parts[1],parts[2] if len(parts)>2 else ''))
    elif line.startswith(b'STAGE-COUNT '):
        _,bt,g,ph,*_=line.decode().split()
        if (bt,g) in [('31','34'),('11','5')] and ph=='check':
            found.add((bt,g));assert pending
            for row in pending:wr.writerow((bt,g,*row))
        pending=[];cand=0
    else:keep.append(line)
assert len(found)==2 and r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
