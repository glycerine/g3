import csv,collections,re
from pathlib import Path
w=Path(__file__).resolve().parent
def norm(s):
    ids={}
    return re.sub(r'([^\s()!]+)!\d+(?=[()\s]|$)',lambda m:m[1]+'!@'+str(ids.setdefault(m[0],len(ids))),s)
for b,limit in [('31',24),('11',16)]:
    histories=[]
    for e in ['g3','z3']:
        rows=list(csv.DictReader((w/('all-'+e+'.csv')).open()))
        plain=list(csv.DictReader((w/(e+'.csv')).open()))
        assert [r for r in rows if r['event']!='split']==plain
        rows=[r for r in rows if r['batch']==b and r['candidate']=='0']
        history=[];offers=0;emits=0
        for r in rows:
            ev=r['event']
            if ev=='offer':
                offers+=1
                if offers==limit+1:print(b,e,'first divergent offer after',len(history),'decisions and',emits,'lemmas; last split',history[-1] if history else None)
            if ev=='formula':emits+=1
            if ev=='split':
                var,sign,node=r['value'].split(' ',2)
                history.append((var,sign,norm(node),offers,emits))
        histories.append(history)
    a,z=histories
    n=next((i for i,(x,y) in enumerate(zip(a,z)) if x[1:3]!=y[1:3]),min(len(a),len(z)))
    print('signed shape prefix',b,n,'of',len(a),len(z))
    if n<min(len(a),len(z)):print('first different split',b,'g3',a[n], 'z3',z[n])
