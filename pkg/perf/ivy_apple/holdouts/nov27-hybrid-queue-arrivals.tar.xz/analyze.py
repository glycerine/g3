"""Compare scoped event sequences and the selected fingerprint at the divergence."""
from pathlib import Path
import collections,csv,re
w=Path(__file__).resolve().parent
def normalized(s):
    seen={}
    def rename(m):
        return m[1]+'!@'+str(seen.setdefault(m[0],len(seen)))
    return re.sub(r'([^\s()!]+)!\d+(?=[()\s]|$)',rename,s)
def get(e,bt):
    rows=list(csv.DictReader((w/(e+'.csv')).open()))
    old=list(csv.DictReader((w.parent/'g3-clause-confirmation'/('events-'+e+'.csv')).open()))
    keep=[r for r in rows if r['event'] not in ('offer','pick','batch')]
    assert old==keep
    return [r for r in rows if r['batch']==bt and r['candidate']=='0']
def parse(rows):
    offers=[];picks=[];formulas=[];batches=[]
    for pos,r in enumerate(rows):
        kind=r['event'];v=r['value']
        if kind=='batch':
            batches.append(int(v))
        if kind in ('offer','pick'):
            cost,gen,raw=v.split(' ',2)
            t={'cost':float(cost),'gen':int(gen),'raw':raw,'shape':normalized(raw),'pos':pos,'batch':len(batches),'emitted':len(formulas)}
            (offers if kind=='offer' else picks).append(t)
        if kind=='formula':
            assert picks
            formulas.append((picks[-1],len(offers),len(picks),pos))
    return offers,picks,formulas,batches
for bt,miss in [('31',13),('11',7)]:
    tables={e:parse(get(e,bt)) for e in ['g3','z3']}
    for i in [0,1]:
        a,b=([r['shape'] for r in t[i]] for t in tables.values())
        n=next((idx for idx,(x,y) in enumerate(zip(a,b)) if x!=y),min(len(a),len(b)))
        print(bt,['offers','picks'][i],'prefix',n,'of',len(a),len(b))
    for e,other in [('g3','z3'),('z3','g3')]:
        offers,picks,formulas,batches=tables[e]
        selected,count,ip,pos=formulas[miss-1]
        their=tables[other][2][miss-1][0]['shape']
        print(bt,e,'batches',batches,'costs',collections.Counter(o['cost'] for o in offers))
        print('lemma',miss, 'offers so far',count,'selection',ip,'batch',selected['batch'],'cost',selected['cost'],'gen',selected['gen'])
        for label,lookup in [('local',selected['shape']),('other',their)]:
            print(label,'offered',[(i+1,v['emitted'],v['cost'],v['gen']) for i,v in enumerate(offers) if v['shape']==lookup][:8], 'selected',[(i+1,v['emitted']) for i,v in enumerate(picks) if v['shape']==lookup][:8])
        print('offers dispatched in input order', [o['raw'] for o in offers]==[o['raw'] for o in picks])
