
(declare-fun f (Int) Int)(assert (forall ((x Int)) (>= (f x) 2)))(assert (< (f 1) 2))
(check-sat)(get-info :all-statistics)
