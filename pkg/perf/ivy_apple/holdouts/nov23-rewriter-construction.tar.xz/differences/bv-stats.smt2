
(declare-const x (_ BitVec 4))(assert (= (bvadd x #x1) #x3))
(check-sat)(get-info :all-statistics)
