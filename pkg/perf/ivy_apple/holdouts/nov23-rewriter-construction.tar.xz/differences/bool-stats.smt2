
(declare-const x Bool)(assert (or x (not x)))
(check-sat)(get-info :all-statistics)
