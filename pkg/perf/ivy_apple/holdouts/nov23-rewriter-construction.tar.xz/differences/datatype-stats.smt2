
(declare-datatype T ((one)(two)))(declare-const x T)(assert (distinct x one))
(check-sat)(get-info :all-statistics)
