
(declare-const x (Array Int Int))(assert (= (select (store x 1 2) 1) 2))
(check-sat)(get-info :all-statistics)
