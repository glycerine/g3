
(declare-const x Float32)(assert (fp.isZero x))
(check-sat)(get-info :all-statistics)
