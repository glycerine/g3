
(declare-fun f (Real) Real)(assert (forall ((x Real)) (>= (f x) (* x x))))(assert (< (f 2.0) 3.0))
(check-sat)(get-info :all-statistics)
