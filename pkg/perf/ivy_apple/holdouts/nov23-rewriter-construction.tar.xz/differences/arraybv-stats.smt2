
(declare-const x (Array (_ BitVec 4) (_ BitVec 4)))(assert (= (select x #x3) #x7))
(check-sat)(get-info :all-statistics)
