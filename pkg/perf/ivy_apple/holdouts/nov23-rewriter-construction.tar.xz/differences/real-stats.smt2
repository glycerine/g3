
(declare-const x Real)(assert (= (* x x) 2))
(check-sat)(get-info :all-statistics)
