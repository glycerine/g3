
(declare-sort A 0)(declare-const x A)(declare-fun f (A) A)(assert (= (f x) x))
(check-sat)(get-info :all-statistics)
