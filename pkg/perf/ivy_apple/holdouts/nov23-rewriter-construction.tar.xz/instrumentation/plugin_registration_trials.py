from study import *
from collections import Counter
import simplifier_rebuild as shell,guarded_live as gl
from panel import CASES
d=w/'plugin-registration-trials';d.mkdir(exist_ok=True)
a=pkg/'ast/ast_core_storage.go';q=pkg/'ast/ast_reg_decl_plugins.go';r=pkg/'ast/ast_auxiliary_plugins.go'
def edits(v):
 if v=='control':return {}
 ed={}
 if 'register'in v:
  ed[a]=once(a.read_text(),'recursiveDefinitions bool // see NoteRecursiveFunctionDefinitions','recursiveDefinitions bool // see NoteRecursiveFunctionDefinitions\ndeclarationPluginsReady bool')
  s=q.read_text();s=once(s,'func (m *ASTManager) RegisterDeclarationPlugins() error {','''func (m *ASTManager) RegisterDeclarationPlugins() error {
   if e:=m.lock();e!=nil{return e}
   ready:=m.declarationPluginsReady && m.Symbols==m.families.symbols
   m.mu.Unlock()
   if ready{return m.Symbols.CheckOpen()}''')
  s=once(s,'\n\treturn nil\n}', '''\n if e:=m.lock();e!=nil{return e};m.declarationPluginsReady=true;m.mu.Unlock();return nil
}''')
  ed[q]=s
 if 'aux'in v:
  s=r.read_text();s=once(s,'family := "pb"','''if existing:=m.auxiliaryPlugin(k);existing!=nil && m.Symbols==m.families.symbols {if e:=m.Symbols.CheckOpen();e!=nil{return NullFamilyID,e};return existing.family,nil};family := "pb"''');ed[r]=s
 return ed
def make(v):
 o=d/v;ov=overlay(o/'overlay',edits(v));b=build(o/'checker',o=ov);s=build(o/'shell',o=ov,shell=True)
 return b,s
if __name__=='__main__':
 vs=['control','register','aux','register-aux']
 with ThreadPoolExecutor(2)as e:paths=dict(zip(vs,e.map(make,vs)))
 sh={n:bs[1]for n,bs in paths.items()};sh['native']=pkg.parent/'build/z3'
 bs={n:v[0]for n,v in paths.items()}
 ls=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));cs=[0,3,6,8,9,12]
 shell.d=d/'phases';shell.d.mkdir();gl.d=d;ref=w/'guarded-live/ordinary-11/1-native'
 jobs=[(4,'ordinary','jea/hermes_rmw_o3.ivy','',0,3,ref),(22,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native')]
 for cpu,n in zip([1,2,7,10,13,14,16,18],['tlb','hybrid_reliable_broadcast_cisa','flash2','toy-consensus','rfn2','dramc_nb2','raftok','raft_no_assume_test']):
  sp,iso,_,f,u=CASES[n];rf=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'));jobs.append((cpu,n,sp,iso,int(bool(f or u)),3,rf))
 with ThreadPoolExecutor(len(cs)+len(jobs))as e:
  fs=[e.submit(shell.lane,(c,ls[i::len(cs)],sh))for i,c in enumerate(cs)]+[e.submit(gl.measure_job,j,bs)for j in jobs]
  [f.result()for f in fs]
