from study import *
from collections import Counter
data=w/'simplifier-rebuild';d=w/'rebuild-attribution';d.mkdir(exist_ok=True)
target=pkg/'ast/rewriter/th_rewriter.go'
def prepare():
 q=target;s=q.read_text();observer=(w/'plan-cost/overlay/plan_cost_observer.go').read_text().replace('package api','package rewriter')
 k=observer.index('func finishPlanCost');observer=observer[:k]+'''func reportNewRewriter(t uint64, samples *[12]uint64) {total:=readCounter()-t;syscall.Close(int(fd));runtime.UnlockOSThread();fmt.Fprintln(os.Stderr,"REWRITER-COST",total,*samples,empty)}
func rewriterCostDelta(k int,s *[12]uint64,t *uint64){n:=readCounter();s[k]=n-*t;*t=n}
'''
 sig='if err := m.RegisterDeclarationPlugins()';s=once(s,sig,'start:=beginPlanCost();cur:=start;var meter [12]uint64;defer reportNewRewriter(start,&meter)\n '+sig)
 s=once(s,'n := uint64(reflect.TypeOf(TheoryRewriter{}).Size())','rewriterCostDelta(0,&meter,&cur)\n n := uint64(reflect.TypeOf(TheoryRewriter{}).Size())')
 s=s.replace('if err := r.constructConfiguration(); err != nil {','rewriterCostDelta(1,&meter,&cur)\n if err := r.constructMeasured(&meter,&cur); err != nil {',1)
 i=s.index('func (r *TheoryRewriter) constructConfiguration()');j=s.index('\n}',i)+2
 sub=s[i:j].replace('constructConfiguration()', 'constructMeasured(meter *[12]uint64,cur *uint64)')
 for idx,name in enumerate(['arithmetic','bitVector','array','datatype','floating','datalog','pseudoBoolean','sequence']):
  a=sub.index('if c.'+name+',');sub=sub[:a]+f'rewriterCostDelta({idx+2},meter,cur)\n '+sub[a:]
 sub=once(sub,'return r.readLocalParams()','rewriterCostDelta(10,meter,cur);err=r.readLocalParams();rewriterCostDelta(11,meter,cur);return err')
 s=s[:j]+'\n'+sub+'\n'+s[j:]
 o=overlay(d/'overlay',{q:s,q.with_name('construction_experiment.go'):observer});return build(d/'shell',o=o,shell=True)
def one(task):
 cpu,ls,b=task
 with(d/(str(cpu)+'.csv')).open('w')as f:
  z=csv.writer(f);z.writerow('file ordinal total registration ownership bool arith bv array datatype fp datalog pb sequence params empty'.split())
  for file in ls:
   p=subprocess.run(['taskset','-c',str(cpu),b,'-in','-smt2'],input=file.read_bytes(),capture_output=True,env=dict(env,GOMAXPROCS='1'),timeout=90);assert p.returncode==0 and p.stdout.strip()in(b'sat',b'unsat',b'unknown'),(file,p.stderr[-180:]);other=[]
   for j,line in enumerate(p.stderr.splitlines()):
    m=re.fullmatch(rb'REWRITER-COST (\d+) \[([\d ]+)\] (\d+)',line)
    if not m:other.append(line);continue
    vs=list(map(int,m[2].split()));assert len(vs)==12;z.writerow([file.name,j,int(m[1]),*vs,int(m[3])])
   assert not other,(file,other[:1]);f.flush()
 print('attribution',cpu,flush=True)
if __name__=='__main__':
 b=prepare();cs=[0,3,6,8];ls=sorted((data/'inputs').glob('*.smt2'))
 with ThreadPoolExecutor(len(cs))as e:list(e.map(one,[(c,ls[j::len(cs)],b)for j,c in enumerate(cs)]))
