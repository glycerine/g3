from study import *
d=w/'plugin-release-micro';d.mkdir(exist_ok=True)
qs=[pkg/'ast/ast_core_storage.go',pkg/'ast/ast_reg_decl_plugins.go']
ed={q:run(['git','show','b870bf6a7:pkg/'+str(q.relative_to(pkg))],cwd=pkg,capture_output=True,text=True).stdout for q in qs}
def one(v):
 o=overlay(d/v/'overlay',ed if v=='previous'else{})
 b=d/v/'ast.test';run(['go','test','-p=3','-overlay='+str(o),'-c','-o',b,'./ast'],cwd=pkg)
 return b
if __name__=='__main__':
 vs=['previous','current']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(one,vs)))
 with(d/'bench.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round version ns bytes allocs'.split())
  for i in range(9):
   for v in vs[::1 if i%2==0 else -1]:
    r=run(['taskset','-c','19',bs[v],'-test.run=^(TestASTRegisterDeclarationPlugins|TestRepeatedDeclarationRegistrationChecksOwners)','-test.bench=^BenchmarkRepeatedDeclarationRegistration$','-test.cpu=1','-test.benchtime=200000x','-test.benchmem'],capture_output=True,text=True)
    a=next(l.split()for l in r.stdout.splitlines()if l.startswith('Benchmark'));z.writerow([i+1,v,a[2],a[4],a[6]]);f.flush()
