from study import *
from collections import Counter
import select
d=w/'branch-profiles';d.mkdir(exist_ok=True)
def main():
 ls=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'))
 def one(j):
  cpu,fs=j;dd=d/str(cpu);dd.mkdir();ctl,ack=dd/'control',dd/'ack';os.mkfifo(ctl);os.mkfifo(ack);cf=os.open(ctl,os.O_RDWR);af=os.open(ack,os.O_RDWR)
  def sig(t):os.write(cf,t.encode()+b'\n');assert select.select([af],[],[],20)[0]and os.read(af,64).startswith(b'ack')
  try:
   with(dd/'tree.csv').open('w')as f:
    z=csv.writer(f);z.writerow(['file','mode','answer','kind','symbol','samples'])
    for src in fs:
     for v in ('control','seed','native'):
      b=pkg.parent/'build/z3'if v=='native'else w/'strategic-branch-trials'/v/'shell/g3';data=dd/'counts.data'
      cmd=['taskset','-c',str(cpu),perf,'record','-q','-m','1024','--no-buildid','-e','instructions:u','-c','160001','--call-graph','dwarf,8192'if v=='native'else'fp','--control',f'fifo:{ctl},{ack}','-D','-1','-o',data,'--',b,'-in','-smt2']
      with subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(env,GOMAXPROCS='1',GOGC='100'))as p:
       p.stdin.write(src.read_bytes().rstrip().removesuffix(b'(check-sat)')+b'\n(echo "loaded")\n');p.stdin.flush();assert p.stdout.readline().strip()==b'loaded';sig('enable');p.stdin.write(b'(check-sat)\n');p.stdin.flush();ans=p.stdout.readline().strip().decode();assert ans in ('sat','unsat','unknown'),ans;sig('disable');o,e=p.communicate(b'(exit)\n',timeout=20);assert p.returncode==0 and not o and b'lost'not in e.lower()
      pp=run([perf,'script','--no-inline','-F','event,ip,sym,dso','-i',data],capture_output=True,text=True);assert 'lost'not in pp.stderr.lower();data.unlink();ct=Counter()
      for rec in pp.stdout.split('\n\n'):
       stack=[]
       for ln in rec.splitlines()[1:]:
        mat=re.match(r'^\s*[0-9a-fA-F]+\s+(.+?)\s+\([^)]*\)\s*$',ln)
        if mat:stack.append(re.sub(r'\+0x[0-9a-fA-F]+$','',mat[1]).removeprefix('github.com/glycerine/g3/pkg/'))
       if stack:
        ct['leaf',stack[0]]+=1
        for x in set(stack):ct['inclusive',x]+=1
      assert ct
      for(k,x),c in ct.items():z.writerow([src.name,v,ans,k,x,c])
      f.flush()
  finally:os.close(cf);os.close(af);ctl.unlink();ack.unlink()
 cs=[0,3,6,8,12,16]
 with ThreadPoolExecutor(len(cs)) as e:list(e.map(one,[(c,ls[i::len(cs)])for i,c in enumerate(cs)]))
if __name__=='__main__':main()
