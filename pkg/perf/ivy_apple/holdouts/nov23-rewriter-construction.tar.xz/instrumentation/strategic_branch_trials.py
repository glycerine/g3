from study import *
import simplifier_rebuild as shell
d=w/'strategic-branch-trials';d.mkdir(exist_ok=True)
def edits(v):
 if v=='control':return {}
 q=pkg/'tactic/portfolio/smt_strategic_solver.go';s=q.read_text();a=s.index('func newDefaultStrategicTactic(');n=s.index('qfFPLRA, err :=',a);b=s.index('fragment :=',n);part=s[n:b]
 pattern=r'(\w+), err := smtlogics\.(New\w+Tactic)\(m, p, config\)'
 def sub(mat):return 'var '+mat[1]+' tactic.Tactic; '+mat[1]+', err = tactic.NewLazyTactic(m,config.Params,p,func(m *ast.ASTManager,p *uparams.ParamsRef)(tactic.Tactic,error){return smtlogics.'+mat[2]+'(m,p,config)})'
 part,count=re.subn(pattern,sub,part);assert count==11
 s=s[:n]+part+s[b:]
 if v=='seed':
  s=once(s,'strategy, err := newDefaultStrategicTactic(m, p, config)','''anchors,e:=newDeferredDefaultTactic(m,p,config);if e!=nil{return nil,e};defer func(){if err!=nil{err=errors.Join(err,anchors.Close())}}()
  strategy, err := newDefaultStrategicTactic(m, p, config)''')
  s=once(s,'return newStrategicSolver(m, strategy, logic, p, proofs, models, cores, config)\n}\n\nfunc newDefaultStrategicTactic','''v,e:=newStrategicSolver(m,strategy,logic,p,proofs,models,cores,config);if e!=nil{return nil,e};return &experimentalBranchSolver{Solver:v,anchors:anchors},nil\n}\n\nfunc newDefaultStrategicTactic''')
  s+='''\ntype experimentalBranchSolver struct{solver.Solver;anchors *deferredDefaultTactic}
func (s *experimentalBranchSolver)Close()error{return errors.Join(s.Solver.Close(),s.anchors.Close())}\n'''
 return {q:s}
def main():
 vs=['control','lazy','seed']
 def mk(v):return build(d/v/'shell',o=overlay(d/v/'overlay',edits(v)),shell=True)
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 bs['native']=pkg.parent/'build/z3';ls=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));cs=[0,3,6,8,12,18]
 shell.d=d/'phases';shell.d.mkdir()
 with ThreadPoolExecutor(len(cs))as e:list(e.map(shell.lane,[(c,ls[j::len(cs)],bs)for j,c in enumerate(cs)]))
if __name__=='__main__':main()
