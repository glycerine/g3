from study import *
from collections import Counter
d=w/'portfolio-census';d.mkdir(exist_ok=True)
def main():
 q=pkg/'ast/rewriter/th_rewriter.go';s=q.read_text();n=s.index('func NewTheoryRewriter(');i=s.index('{',n);s=s[:i+1]+'\n reportCreationExperiment()\n'+s[i+1:]
 u=q.with_name('creation_census_experiment.go');h='''package rewriter
import ("runtime";"fmt";"os";"strings")
func reportCreationExperiment(){var a [100]uintptr;n:=runtime.Callers(3,a[:]);fs:=runtime.CallersFrames(a[:n]);var out []string;for{f,more:=fs.Next();out=append(out,strings.TrimPrefix(f.Function,"github.com/glycerine/g3/pkg/"));if !more{break}};fmt.Fprintln(os.Stderr,"CREATE",strings.Join(out,"|"))}'''
 b=build(d/'shell',o=overlay(d/'overlay',{q:s,u:h}),shell=True)
 for pre in ('ground','quantified'):
  file=next(iter(sorted((w/'simplifier-rebuild/inputs').glob(pre+'-*.smt2'))));query=file.read_bytes().replace(b'(check-sat)',b'(echo "PHASE-CHECK")\n(check-sat)\n(echo "PHASE-FINAL")')
  r=run([b,'-in','-smt2'],input=query,stderr=subprocess.STDOUT,stdout=subprocess.PIPE);(d/(pre+'.txt')).write_bytes(r.stdout)
  cur='before';c=Counter()
  for line in r.stdout.decode().splitlines():
   if 'PHASE-CHECK' in line:cur='checking'
   elif 'PHASE-FINAL' in line:cur='closing'
   elif line.startswith('CREATE '):
    stack=line[7:].split('|');en=next((v for v in stack if v.startswith('tactic/portfolio.')),'other');ta=next((v for v in stack if 'smtlogics.New' in v),'other')
    c[cur,stack[0],en,ta]+=1
  with(d/(pre+'.csv')).open('w')as f:
   z=csv.writer(f);z.writerow(['phase','immediate','portfolio','tactic','calls']);z.writerows([*k,v]for k,v in c.most_common())
  print(pre,c.most_common(5),flush=True)
if __name__=='__main__':main()
