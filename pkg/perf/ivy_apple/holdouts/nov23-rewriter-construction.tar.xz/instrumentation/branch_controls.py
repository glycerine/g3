from study import *
from collections import Counter
import itertools
d=w/'branch-controls';d.mkdir(exist_ok=True);ds=d/'inputs';ds.mkdir(exist_ok=True)
def inputs():
 for f in sorted((pkg/'cmd/g3/test_vectors').glob('*.smt2')):
  yield 'repo-'+f.name,f.read_bytes()
 samples={'int':'(declare-const x Int)(assert (= x 3))','real':'(declare-const x Real)(assert (= (* x x) 2))','qint':'(declare-fun f (Int) Int)(assert (forall ((x Int)) (>= (f x) 2)))(assert (< (f 1) 2))','qreal':'(declare-fun f (Real) Real)(assert (forall ((x Real)) (>= (f x) (* x x))))(assert (< (f 2.0) 3.0))','array':'(declare-const x (Array Int Int))(assert (= (select (store x 1 2) 1) 2))','bv':'(declare-const x (_ BitVec 4))(assert (= (bvadd x #x1) #x3))','arraybv':'(declare-const x (Array (_ BitVec 4) (_ BitVec 4)))(assert (= (select x #x3) #x7))','bool':'(declare-const x Bool)(assert (or x (not x)))','uf':'(declare-sort A 0)(declare-const x A)(declare-fun f (A) A)(assert (= (f x) x))','FP':'(declare-const x Float32)(assert (fp.isZero x))','datatype':'(declare-datatype T ((one)(two)))(declare-const x T)(assert (distinct x one))'}
 actions={'once':'(check-sat)','twice':'(check-sat)(check-sat)','stack':'(check-sat)(push)(assert false)(check-sat)(pop)(check-sat)','model':'(check-sat)(get-model)','stats':'(check-sat)(get-info :all-statistics)','rlimit':'(set-option :rlimit 10)(check-sat)','steps':'(set-option :rewriter.max_steps 1)(check-sat)','proof':'(check-sat)(push)(assert false)(check-sat)(get-proof)(pop)','core':'(assert (! false :named contrad))(check-sat)(get-unsat-core)'}
 for (n,q),(k,s)in itertools.product(samples.items(),actions.items()):
  opts={'core':'(set-option :produce-unsat-cores true)','proof':'(set-option :produce-proofs true)','model':'(set-option :produce-models true)'}.get(k,'')
  yield n+'-'+k+'.smt2',(opts+'\n'+q+'\n'+s+'\n').encode()
def main():
 cases=[]
 for n,q in inputs():f=ds/n;f.write_bytes(q);cases.append(f)
 bins={v:w/'strategic-branch-trials'/v/'shell/g3'for v in ['control','lazy','seed']};bins['native']=pkg.parent/'build/z3'
 def one(cs):
  cpu,fs=cs;dd=d/str(cpu);dd.mkdir()
  with(dd/'results.csv').open('w')as fo:
   z=csv.writer(fo);z.writerow('source mode exit matches_g3 bytes'.split())
   for f in fs:
    ref=None
    for v,b in bins.items():
     try:r=subprocess.run(['taskset','-c',str(cpu),b,'-in','-smt2'],input=f.read_bytes(),capture_output=True,timeout=12,env=dict(env,GOGC='100',GOMAXPROCS='1'));out=r.stdout;err=r.stderr;rc=r.returncode
     except subprocess.TimeoutExpired as ex:out=ex.stdout or b'';err=ex.stderr or b'';rc=124
     if v=='control':ref=(rc,out,err)
     same=(rc,out,err)==ref;z.writerow([f.name,v,rc,int(same),len(out)]);fo.flush();od=dd/f.stem;od.mkdir(exist_ok=True);(od/(v+'.out')).write_bytes(out);(od/(v+'.err')).write_bytes(err)
  print(cpu,len(fs),flush=True)
 cs=[0,3,8,13,16,18,22,24]
 with ThreadPoolExecutor(8)as ex:list(ex.map(one,[(c,cases[i::8])for i,c in enumerate(cs)]))
if __name__=='__main__':main()
