from study import *
import tarfile
from types import SimpleNamespace
from collections import Counter
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
from shell_check_phases import measure
q=pkg/'tactic/core/simplify_tactic.go';d=w/'simplifier-rebuild';d.mkdir(exist_ok=True)
def variant(v):
 if v=='control':return{}
 s=q.read_text()
 s=once(s,'paramsReady bool','paramsReady bool\n deferred bool')
 if 'first'in v:
  s=once(s,'t.rewriter, err = rewriter.NewTheoryRewriter(m, context, globals, &t.params)','t.deferred=true')
 if 'after'in v:
  s=once(s,'var err error\n\tt.rewriter, err = rewriter.NewTheoryRewriter(t.manager, t.context, t.globals, &t.params)\n\tt.steps = 0\n\treturn err','t.deferred=true;t.steps=0;return nil')
 s=once(s,'!t.paramsReady || t.rewriter == nil','!t.paramsReady || (t.rewriter == nil && !t.deferred)')
 offs=s.index('func (t *SimplifyTactic) UpdateParams(')
 s=s[:offs]+'''func(t *SimplifyTactic)ensureExperiment()error{if !t.deferred{return nil};var e error;t.rewriter,e=rewriter.NewTheoryRewriter(t.manager,t.context,t.globals,&t.params);t.deferred=false;return e}
'''+s[offs:]
 s=once(s,'return t.rewriter.UpdateParams(params)','if t.deferred {return nil};return t.rewriter.UpdateParams(params)')
 s=once(s,'return t.rewriteGoal(goal)','if err:=t.ensureExperiment();err!=nil{return err};return t.rewriteGoal(goal)')
 return{q:s}
def cases():
 dest=d/'inputs';dest.mkdir(exist_ok=True)
 with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov23-hermes-ground-search.tar.gz')as ar:
  for member in ar:
   if member.name.startswith(('phases/inputs/','ground-check-inputs/')):
    fn=('quantified-'if member.name.startswith('phases/')else'ground-')+Path(member.name).name
    (dest/fn).write_bytes(ar.extractfile(member).read())
 return sorted(dest.iterdir())
def lane(job):
 cpu,paths,bs=job;p=d/str(cpu);p.mkdir()
 with(p/'runs.csv').open('w')as out:
  wr=csv.writer(out);wr.writerow('file round mode stage answer instructions'.split())
  for j,f in enumerate(paths):
   query=f.read_bytes().rstrip().removesuffix(b'(check-sat)');truth=None
   for rnd in range(2):
    modes=list(bs);offset=(j+rnd)%len(bs);modes=modes[offset:]+modes[:offset]
    for v in modes:
     for phase in ('load','check'):
      result,ins=measure(bs[v],query,cpu,str(perf),phase);assert result==truth or truth is None,(f,rnd,v,phase,result,truth);truth=result
      wr.writerow([f.name,rnd+1,v,phase,result,ins]);out.flush()
  print('done',cpu,len(paths),flush=True)
def main():
 paths=cases();vs=['control','first','after','first-after']
 def buildone(v):
  od=d/v;b=build(od/'shell',o=overlay(od/'overlay',variant(v)),shell=True);return b
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(buildone,vs)))
 bs['native']=pkg.parent/'build/z3'
 cs=[0,1,3,6,8,9,12,18]
 with ThreadPoolExecutor(len(cs))as e:list(e.map(lane,[(c,paths[j::len(cs)],bs)for j,c in enumerate(cs)]))
if __name__=='__main__':main()
