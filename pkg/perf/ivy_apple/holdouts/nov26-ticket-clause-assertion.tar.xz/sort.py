"""Test sorting only disordered short auxiliary clauses and reusing known-open assignment reads."""
from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent
src=Path.cwd()/'smtcore/smt_internalizer.go'
s=src.read_text()
mode=sys.argv[1]
p=s.index('if ordered {',s.index('func (s *SMTInternalizerState) addClauseKindWithJustificationAndDeleteHandler'))
q=s.index('\n\t// Adjacent indices',p)
if mode=='sort':
 s=s[:p]+'''if ordered {
        switch len(literals) {
        case 0,1:
        case 2:
            if literals[0]>literals[1] {literals=[]SMTLiteral{literals[1],literals[0]}}
        case 3:
            a,b,c:=literals[0],literals[1],literals[2]
            if a>b {a,b=b,a}
            if b>c {b,c=c,b}
            if a>b {a,b=b,a}
            literals=[]SMTLiteral{a,b,c}
        default:
            s.clauseSortScratch=append(s.clauseSortScratch[:0],literals...)
            literals=s.clauseSortScratch
            slices.Sort(literals)
        }
    }'''+s[q:]
elif mode=='assign':
 p=s.index('for _, literal := range literals {',q);q=s.index('// A proof or assignment callback',p)
 seg=s[p:q]
 k='value, err := s.Assignment(literal)'
 assert seg.count(k)==2
 seg=seg.replace(k,'''if !checkedOpen {
                if err:=s.open();err!=nil{return err}
                checkedOpen=true
            }
            value, err := s.literalAssignment(literal)''')
 s=s[:p]+'checkedOpen:=false\n\t'+seg+s[q:]
else: raise ValueError(mode)
dst=w/(mode+'.go');dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/(mode+'.json');overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-mod=readonly','-pgo=off','-buildvcs=false','-overlay',overlay,'-o',w/mode,'./cmd/g3'],check=True)
