"""Compare scope benchmarks with the old and released internalizer."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
src=Path.cwd()/'smtcore/smt_internalizer.go'
old=w/'baseline_internalizer.go'
old.write_bytes(subprocess.check_output(['git','show','05092af7a:pkg/smtcore/smt_internalizer.go']))
overlay=w/'baseline.json';overlay.write_text(json.dumps({'Replace':{str(src):str(old)}}))
for name,opts in [('base',['-overlay',overlay]),('release',[])]:
 subprocess.run(['go','test','-pgo=off','-mod=readonly','-c','-o',w/(name+'-bench'),*opts,'./smtcore'],check=True)
for i in range(7):
 for name in (('base','release') if i%2==0 else ('release','base')):
    rows=subprocess.check_output(['taskset','-c','12',w/(name+'-bench'),'-test.run=^$','-test.bench=^BenchmarkSMTBooleanEnodeFlagTrail$','-test.benchtime=100x'],text=True)
    for row in rows.splitlines():
        if row.startswith('Benchmark'):print(name,i+1,row,flush=True)
