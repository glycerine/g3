"""Count full benchmark process instructions, cycles and verify the retained capacities."""
from pathlib import Path
import csv,subprocess,sys
w=Path(__file__).resolve().parent
out=csv.writer(sys.stdout)
out.writerow(('surviving','round','engine','instructions','cycles','capacity_bytes','trail_entries'))
for n in (0,256):
 for i in range(7):
    for name in (('base','release') if i%2==0 else ('release','base')):
        counters=w/'bench.stat'
        r=subprocess.check_output(['taskset','-c','11',sys.argv[1],'stat','-x,','-e','instructions:u,cycles:u','-o',counters,'--',w/(name+'-bench'),'-test.run=^$','-test.bench=^BenchmarkSMTBooleanEnodeFlagTrail$/^'+str(n)+'Surviving$','-test.benchtime=1000x'],text=True)
        line=next(line.split() for line in r.splitlines() if line.startswith('Benchmark'))
        cap,entries=float(line[line.index('flag-capacity-B')-1]),float(line[line.index('flag-entries/op')-1])
        assert (cap,entries)==((2048,512) if name=='base' else (4*n,n))
        hw={x[2]:int(x[0]) for x in csv.reader(counters.read_text().splitlines()) if len(x)>4 and x[2].endswith(':u') and float(x[4])==100}
        out.writerow((n,i+1,name,hw['instructions:u'],hw['cycles:u'],int(cap),int(entries)));sys.stdout.flush()
