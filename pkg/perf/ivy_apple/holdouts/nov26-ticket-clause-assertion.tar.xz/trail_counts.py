import subprocess,csv,re,sys
from pathlib import Path
w=Path(__file__).resolve().parent
out=csv.writer(sys.stdout)
out.writerow(('query','build','assertion','same_scope','outer_scope','peak_capacity'))
for q,expected in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
 r=subprocess.run([w/'trail','-in','-smt2'],input=(Path(sys.argv[1])/(q+'.smt2')).read_bytes(),capture_output=True,check=True)
 stats=dict(re.findall(rb':([\w-]+)\s+(\d+)\b',r.stdout))
 assert r.stdout.startswith(b'unsat\n') and tuple(int(stats[k]) for k in [b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count'])==expected
 for i,line in enumerate(r.stderr.decode().splitlines(),1):
    label,*v=line.split()
    assert label=='TRAIL' and len(v)==3
    out.writerow((q,sys.argv[2],i,*v))
