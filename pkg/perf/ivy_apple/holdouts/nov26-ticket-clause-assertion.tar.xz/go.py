"""Instrument the same quantifier assertion boundary in the Go CLI."""
import json,subprocess
from pathlib import Path
pkg=Path.cwd()
out=Path(__file__).resolve().parent
mapping={}
def save(name,s):
    src=pkg/'smtcore'/name
    dst=out/name
    dst.write_text(s)
    mapping[str(src)]=str(dst)
def once(s,k,v):
    assert s.count(k)==1,k
    return s.replace(k,v)
name='smt_qi_instance.go'
s=(pkg/'smtcore'/name).read_text()
k='if err = internalizer.internalizeInstance(result, locals.arguments); err != nil {'
s=once(s,k,'''qaCounting = true
    qaCalls++
    err = internalizer.internalizeInstance(result, locals.arguments)
    qaCounting = false
    println("QA",qaCalls,qaOrs,qaArgs,qaBound,qaNeg,qaBoundNeg,qaEntries,qaNodes,qaVars,qaRoots,qaWatches,qaTermLook,qaTermHit,qaIgnored,qaImmediate,qaInstalled)
    if err != nil {''')
s+='\nvar qaOrDepth int\nvar qaCounting bool\nvar qaCalls,qaOrs,qaArgs,qaBound,qaNeg,qaBoundNeg,qaEntries,qaNodes,qaVars,qaRoots,qaWatches,qaTermLook,qaTermHit,qaIgnored,qaImmediate,qaInstalled int\n'
save(name,s)
name='smt_internalizer.go'
s=(pkg/'smtcore'/name).read_text()
k='for index, argument := range arguments {\n\t\t\t\tif instanceArguments != nil'
s=once(s,k,'''for index, argument := range arguments {
                if qaCounting {
                    if index==0 {qaOrs++}
                    qaArgs++
                    sign,child,e:=s.manager.IsNot(argument)
                    if e!=nil {panic(e)}
                    atom:=argument
                    if sign {atom=child;qaNeg++}
                    nested,_,e:=s.manager.IsNot(atom)
                    if e!=nil {panic(e)}
                    if _,ok:=s.boolVar.lookup(atom); !nested && ok {
                        qaBound++
                        if sign {qaBoundNeg++}
                    }
                }
                if instanceArguments != nil''')
k='func (s *SMTInternalizerState) Internalize(expression ast.ASTHandle, gateContext bool) error {'
s=once(s,k,k+'\n if qaCounting {qaEntries++}')
k='func (s *SMTInternalizerState) addRootClause(literals []SMTLiteral, assertionProof ast.ASTHandle) error {'
s=once(s,k,k+'\n if qaCounting {qaRoots++}')
k='func (s *SMTInternalizerState) internalizeTerm(expression ast.ASTHandle, header *ast.ASTNodeHeader) error {'
s=once(s,k,k+'\n if qaCounting {qaTermLook++; if s.context.enodes.get(expression)!=nil {qaTermHit++}}')
save(name,s)
for name,markers in [('smt_internalizer_state.go',[('s.statistics.NumMkBoolVar++','qaVars'),('s.statistics.NumMkEnode++','qaNodes')]),('smt_relevancy_asserted_or.go',[('if !p.enabled || len(args) == 0 {','qaWatches')])]:
    s=(pkg/'smtcore'/name).read_text()
    for k,counter in markers:
        s=once(s,k,'if qaCounting {'+counter+'++}\n '+k)
    if name=='smt_relevancy_asserted_or.go':
        s=once(s,'if qaCounting {qaWatches++}', 'if qaCounting {qaWatches++;qaOrDepth++;defer func(){qaOrDepth--}()}')
    save(name,s)
name='smt_relevancy.go'
s=(pkg/'smtcore'/name).read_text()
k='return p.addOrWatches(parent, smtRelevancyOr)'
s=once(s,k,'if qaCounting {qaWatches++;qaOrDepth++;defer func(){qaOrDepth--}()}\n'+k)
i=s.index('func (p *SMTRelevancyPropagator) addWatch(')
j=s.index('func (p *SMTRelevancyPropagator) AddWatchTarget',i)
part=s[i:j]
for val,cnt in [('False','qaIgnored'),('True','qaImmediate'),('Undef','qaInstalled')]:
    k='case lbool.'+val+':'
    part=once(part,k,k+' if qaCounting && qaOrDepth>0 {'+cnt+'++}')
save(name,s[:i]+part+s[j:])
overlay=out/'go.json'
overlay.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
