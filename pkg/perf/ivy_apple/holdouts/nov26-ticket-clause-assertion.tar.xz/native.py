"""Count queue assertion roots and their OR operands in this fork's C++ CLI."""
from pathlib import Path
import re,shlex,subprocess
pkg=Path.cwd()
root=pkg.parent
build=root/'build'
out=Path(__file__).resolve().parent
flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
make=(build/'Makefile').read_text()
includes=shlex.split(re.search(r'^includes_39 = (.*)$',make,re.M)[1])
header=out/'observer.hpp'
header.write_text("""#pragma once
#include <cstdio>
extern bool counting;
extern int or_depth;
struct qa_watch_scope { qa_watch_scope(){++or_depth;} ~qa_watch_scope(){--or_depth;} };
extern unsigned long long calls,ors,args,bound,neg,boundneg,entries,nodes,vars,roots,watches,termlook,termhit,ignored,immediate,installed;
""")
def once(code,old,new):
    assert code.count(old)==1,(old,code.count(old))
    return code.replace(old,new)
objs=[]
for filename in ['qi_queue','smt_relevancy','smt_internalizer']:
    src=root/('src/smt/'+filename+'.cpp')
    s=src.read_text()
    if filename=='qi_queue':
        s+='\nbool counting; int or_depth; unsigned long long calls,ors,args,bound,neg,boundneg,entries,nodes,vars,roots,watches,termlook,termhit,ignored,immediate,installed;\n'
        k='m_context.internalize_instance(lemma, pr1, gen);'
        s=once(s,k,'counting=true; calls++; '+k+' counting=false; std::fprintf(stderr,"QA %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu\\n",calls,ors,args,bound,neg,boundneg,entries,nodes,vars,roots,watches,termlook,termhit,ignored,immediate,installed);')
    elif filename=='smt_relevancy':
        i=s.index('void add_watch(expr * n, bool val, relevancy_eh * eh) override')
        j=s.index('void add_watch(expr * n, bool val, expr * target)',i)
        part=s[i:j]
        for val,cnt in [('l_false','ignored'),('l_undef','installed'),('l_true','immediate')]:
            k='case '+val+':'
            part=once(part,k,k+' if (::counting && ::or_depth) ++::'+cnt+';')
        s=s[:i]+part+s[j:]
    else:
        k='expr * arg = to_app(n)->get_arg(i); \n                    internalize(arg, true);'
        s=once(s,k,'''expr * arg = to_app(n)->get_arg(i);
                    if (::counting) {
                        if (!i) ++::ors;
                        ++::args;
                        bool sign = m_manager.is_not(arg);
                        expr *atom = sign ? to_app(arg)->get_arg(0) : arg;
                        bool ready = !m_manager.is_not(atom) && b_internalized(atom);
                        ::neg += sign; ::bound += ready; ::boundneg += ready && sign;
                    }
                    internalize(arg, true);''')
        k='void context::internalize(expr * n, bool gate_ctx) {'
        s=once(s,k,k+' if (::counting) ++::entries;')
        for sig,cnt in [('enode * context::mk_enode(app * n, bool suppress_args, bool merge_tf, bool cgc_enabled) {','nodes'),('bool_var context::mk_bool_var(expr * n) {','vars'),('void context::mk_root_clause(unsigned num_lits, literal * lits, proof * pr) {','roots'),('void context::add_or_rel_watches(app * n) {','watches')]:
            s=once(s,sig,sig+' if (::counting) ++::'+cnt+';')
        sig='void context::internalize_term(app * n) {'
        s=once(s,sig,sig+' if (::counting) { ++::termlook; ::termhit += e_internalized(n); }')
        sig='void context::add_or_rel_watches(app * n) {'
        s=once(s,sig,sig+' qa_watch_scope local_scope;')
    dst=out/src.name
    dst.write_text(s)
    obj=out/(filename+'.o')
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-include',header,'-o',obj,dst],cwd=build,check=True)
    objs.append(obj)
link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',make,re.M)[1]
libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
subprocess.run([flags['LINK'],'-o',out/'z3',*objs,*libs,*shlex.split(flags['LINK_EXTRA_FLAGS'])],cwd=build,check=True)
