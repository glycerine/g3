"""Test stripping one negation via the Boolean accessor instead of a full AST header."""
import json,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
src=Path.cwd()/'smtcore/smt_internalizer_state.go'
s=src.read_text()
i=s.index('header, err := s.manager.NodeHeader(expression)',s.index('func (s *SMTInternalizerState) Literal('))
j=s.index('// Reserved truth',i)
s=s[:i]+'''negated, child, err := s.manager.IsNot(expression)
    if err!=nil {return SMTNullLiteral,err}
    if negated {
        '''+s[j:]
dst=w/'literal_state.go';dst.write_text(s)
overlay=w/'literal.json';overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',w/'literal','./cmd/g3'],check=True)
