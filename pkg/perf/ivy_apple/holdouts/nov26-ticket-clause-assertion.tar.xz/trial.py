"""Build small independent changes to queue assertion and enode creation."""
import json,subprocess,sys
from pathlib import Path
pkg=Path.cwd(); w=Path(__file__).resolve().parent; mode=sys.argv[1]
def replace(s,k,v):
    assert s.count(k)==1,(k,s.count(k))
    return s.replace(k,v)
name='smtcore/smt_internalizer.go'
if mode in ('flags','short'):name='smtcore/smt_enode_core.go'
src=pkg/name; s=src.read_text()
if mode=='flags':
    k='flags, err := m.GetFuncDeclFlags(header.Decl)\n\tif err != nil {\n\t\treturn nil, err\n\t}'
    s=replace(s,k,'''var flags ast.ASTFuncFlags
    if !options.SuppressArguments && header.NumArgs==2 {
        var err error
        flags,err=m.GetFuncDeclFlags(header.Decl)
        if err!=nil {return nil,err}
    }''')
elif mode=='short':
    s=replace(s,'n := &SMTEnode{','''var n *SMTEnode
    var small []*SMTEnode
    if term==nil && !options.SuppressArguments && header.NumArgs>0 && header.NumArgs<=2 {
        storage:=new(struct{node SMTEnode; children [2]*SMTEnode})
        n=&storage.node
        small=storage.children[:header.NumArgs]
    } else {n=new(SMTEnode)}
    *n = SMTEnode{''')
    s=replace(s,'n.arguments = make([]*SMTEnode, count)','if small!=nil {n.arguments=small} else {n.arguments = make([]*SMTEnode, count)}')
elif mode=='existing':
    k='// Validate the incoming expression before reading its arena slot.'
    s=replace(s,k,'''if !gateContext && !ast.ASTValidateHandles && !ast.ASTSourceDebug {
        if n:=s.context.enodes.get(expression); n!=nil && n.root!=nil && !n.boolean && s.theories[n.family]==nil {
            return s.manager.ValidateHandle(expression)
        }
    }
    '''+k)
elif mode=='literals':
    k='literals := make([]SMTLiteral, len(arguments))'
    s=replace(s,k,'''var short [8]SMTLiteral
    var literals []SMTLiteral
    if len(arguments)<=len(short) {literals=short[:len(arguments)]} else {literals=make([]SMTLiteral,len(arguments))}''')
else:raise ValueError(mode)
dst=w/(mode+'.go')
dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/(mode+'.json')
overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',w/mode,'./cmd/g3'],check=True)
