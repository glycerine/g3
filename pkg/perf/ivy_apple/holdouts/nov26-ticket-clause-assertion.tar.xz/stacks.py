"""Attribute each sample inside a queue assertion to its self symbol and direct child of assertion."""
from collections import Counter
import csv,re,subprocess,sys
from pathlib import Path
out=csv.writer(sys.stdout);out.writerow(('query','engine','round','child','self','samples'))
for f in sorted(Path(sys.argv[1]).glob('ticket-*.data')):
    q,i,e=f.stem.rsplit('-',2)
    a,queue=('(*SMTInternalizerState).assertExpression','(*SMTQuantifierManager).instantiate') if e=='g3' else ('smt::context::internalize_assertion(','smt::qi_queue::instantiate(smt::qi_queue::entry&)')
    counts=Counter()
    for sample in subprocess.check_output([sys.argv[2],'script','-i',f],text=True).split('\n\n'):
        if a not in sample or queue not in sample:continue
        frames=re.findall(r'^\s+[\da-fA-F]+ (.*?)\+0x',sample,re.M)
        j=next((j for j,x in enumerate(frames) if a in x),None)
        if j is None:continue
        counts[frames[j-1].split('/pkg/')[-1] if j else '(self or inlined)',frames[0].split('/pkg/')[-1]]+=1
    for k,n in counts.items():out.writerow((q,e,i,*k,n))
