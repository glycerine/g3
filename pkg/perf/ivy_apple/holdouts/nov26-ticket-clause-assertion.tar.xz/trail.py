"""Count trail records by the lifetime of the variable the record restores."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
pkg=Path.cwd()
src=pkg/'smtcore/smt_internalizer.go'
s=src.read_text()
k='s.enodeFlagTrail = append(s.enodeFlagTrail, variable)'
assert s.count(k) in (1,2)
s=s.replace(k,k+'''
        if s.booleanData[variable].InternalLevel() == s.scopeLevel {qaSame++} else {qaOuter++}
        if n:=cap(s.enodeFlagTrail);n>qaPeak {qaPeak=n}''')
s+='\nvar qaSame,qaOuter,qaPeak int\n'
dst=w/'trail_observer.go';dst.write_text(s)
src2=pkg/'smtcore/smt_qi_instance.go';s=src2.read_text()
k='traceStreamWriter(out)("[end-of-instance]\\n")\n\t}\n\treturn result, nil'
assert s.count(k)==1
s=s.replace(k,'traceStreamWriter(out)("[end-of-instance]\\n")\n\t}\n println("TRAIL",qaSame,qaOuter,qaPeak)\n return result,nil')
dst2=w/'trail_qi.go';dst2.write_text(s)
overlay=w/'trail.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(dst),str(src2):str(dst2)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',w/'trail','./cmd/g3'],check=True)
