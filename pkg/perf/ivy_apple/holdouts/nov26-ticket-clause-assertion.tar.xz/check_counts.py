"""Check both engines at every assertion, including the final expected count."""
import csv
from pathlib import Path

with Path(__file__).with_name('complete.csv').open() as source:
    rows = list(csv.DictReader(source))
for query, expected in [('ticket-127', 1389), ('ticket-290', 1241)]:
    def history(engine):
        return [row for row in rows if row['query'] == query and row['engine'] == engine]
    go, native = history('g3'), history('z3')
    assert len(go) == len(native) == expected
    for i, (g, z) in enumerate(zip(go, native), 1):
        assert int(g['calls']) == i
        for key in g.keys() - {'engine', 'entries'}:
            assert g[key] == z[key], (query, i, key, g[key], z[key])
    print(query, expected, 'matched assertions')
