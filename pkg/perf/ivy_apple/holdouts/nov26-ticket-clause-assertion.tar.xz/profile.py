"""Profile current ordinary rewriters by immediate operation and self symbol."""
import argparse
from collections import Counter
import csv
import os
import re
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('fixtures',type=Path)
p.add_argument('g3')
p.add_argument('z3')
p.add_argument('--perf',default='perf')
p.add_argument('--cpu',default='10')
p.add_argument('--rounds',type=int,default=16)
a = p.parse_args()
work = Path(__file__).resolve().parent
fields = ('decisions','conflicts','quant-instantiations','rlimit-count')
with (work/'profile.csv').open('w') as output:
    writer = csv.writer(output)
    writer.writerow(('query','round','engine','component','child','self','samples'))
    for query,expected in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
        for i in range(a.rounds):
            for engine in (('g3','z3') if i%2 == 0 else ('z3','g3')):
                go = engine == 'g3'
                data = work/'sample.data'
                cmd = ['taskset','-c',a.cpu,a.perf,'record','-B','-N','-e','instructions:u','-c','1000003','--call-graph','fp,64' if go else 'dwarf,8192','-o',data,'--',getattr(a,engine),'-in','-smt2']
                r = subprocess.run(cmd,input=(a.fixtures/(query+'.smt2')).read_bytes(),capture_output=True,timeout=60,env=dict(os.environ,GOMAXPROCS='1',GOGC='400'),check=True)
                stats = dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()))
                assert r.stdout.startswith(b'unsat\n') and tuple(int(stats[k]) for k in fields)==expected
                dump = subprocess.check_output([a.perf,'report','-D','-i',data],text=True)
                assert not any(k in dump for k in ('PERF_RECORD_LOST','PERF_RECORD_THROTTLE'))
                samples = subprocess.check_output([a.perf,'script','-i',data],text=True).split('\n\n')
                counts = Counter()
                for sample in samples:
                    anchor = '(*SMTInternalizerState).assertExpression' if go else 'smt::context::internalize_assertion('
                    inst = '(*SMTQuantifierManager).instantiate' if go else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)'
                    if anchor not in sample or inst not in sample:
                        continue
                    frames=re.findall(r'^\s+[a-fA-F0-9]+ (.*?)\+0x',sample,re.M)
                    index=next((j for j,fr in enumerate(frames) if anchor in fr),None)
                    if index is None:continue
                    child=frames[index-1] if index else '(self or inlined)'
                    cuts=[('create enode', '.mkEnode' if go else '::mk_enode('),
                          ('create variable','.publishBoolVar' if go else '::mk_bool_var('),
                          ('register OR watches','.addAssertedOrWatches' if go else '::add_or_rel_watches('),
                          ('make clause','.addClauseKindWithJustificationAndDeleteHandler' if go else '::mk_clause(')]
                    stage=next((label for label,needle in cuts if any(needle in f for f in frames[:index])),'other')
                    counts[stage,child.split('/pkg/')[-1],frames[0].split('/pkg/')[-1]]+=1
                for k,v in sorted(counts.items()):
                    writer.writerow((query,i+1,engine,*k,v))
                output.flush()
