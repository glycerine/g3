"""Validate each instrumented process and compare cumulative counters per assertion."""
from pathlib import Path
import csv,re,subprocess,sys
w=Path(__file__).resolve().parent
writer=csv.writer(sys.stdout)
writer.writerow(['query','engine','calls','ors','args','bound','neg','boundneg','entries','enodes','variables','root_clauses','or_watch_calls','term_lookups','term_hits','ignored','immediate','installed'])
for q,expected in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
    for engine in ['g3','z3']:
        r=subprocess.run([w/engine,'-in','-smt2'],input=(Path(sys.argv[1])/(q+'.smt2')).read_bytes(),capture_output=True,timeout=60,check=True)
        stats=dict(re.findall(rb':([\w-]+)\s+(\d+)\b',r.stdout))
        assert r.stdout.startswith(b'unsat\n') and tuple(int(stats[k]) for k in [b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count'])==expected
        for i,row in enumerate(r.stderr.decode().splitlines(),1):
            label,*counts=row.split()
            assert label=='QA' and len(counts)==16 and int(counts[0])==i
            writer.writerow([q,engine,*counts])
