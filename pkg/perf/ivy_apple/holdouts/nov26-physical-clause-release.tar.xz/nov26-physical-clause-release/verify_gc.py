"""Compare complete verifier runs with automatic GC disabled."""

import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--examples", required=True, type=Path)
    parser.add_argument("--cpu", required=True, type=int)
    parser.add_argument("--perf", default="perf")
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--case", action="append", required=True)
    parser.add_argument("engines", nargs="+", help="label=executable")
    args = parser.parse_args()
    cases = json.loads((args.reference / "cases.json").read_text())
    engines = [entry.split("=", 1) for entry in args.engines]
    env = dict(os.environ, GOMAXPROCS="1", GOGC="off", XTRACE_OFF="1")
    out = Path(__file__).resolve().parent
    writer = csv.writer(sys.stdout)
    writer.writerow(("case", "round", "engine", "instructions", "cycles", "milliseconds"))
    for name in args.case:
        path, isolate, exit_code = cases[name]
        reference = args.reference / "reference" / name
        expected = ((reference / "stdout").read_bytes(), (reference / "stderr").read_bytes())
        for turn in range(args.rounds):
            offset = turn % len(engines)
            for label, binary in engines[offset:] + engines[:offset]:
                directory = out / ("gc-off-" + label)
                directory.mkdir(exist_ok=True)
                counters = directory / "perf.csv"
                command = ["taskset", "-c", str(args.cpu), args.perf, "stat", "-x,", "-o", counters,
                           "-e", "instructions:u,cycles:u", "--", str(Path(binary).resolve())]
                if isolate:
                    command.append("isolate=" + isolate)
                command.append(str(args.examples / path))
                start = time.monotonic()
                run = subprocess.run(command, cwd=directory, capture_output=True, env=env, timeout=120)
                elapsed = (time.monotonic() - start) * 1e3
                if run.returncode != exit_code or expected != (run.stdout, run.stderr):
                    (directory / "failure.stdout").write_bytes(run.stdout)
                    (directory / "failure.stderr").write_bytes(run.stderr)
                    raise ValueError((name, label, run.returncode))
                hw = {row[2]: int(row[0]) for row in csv.reader(counters.read_text().splitlines())
                      if len(row) > 4 and row[2].endswith(":u") and float(row[4]) == 100.0}
                writer.writerow((name, turn + 1, label, hw["instructions:u"], hw["cycles:u"], f"{elapsed:.3f}"))
                sys.stdout.flush()


if __name__ == "__main__":
    main()
