# Physical SAT clause pages in the release build

The SAT baseline is `ef703a38b`. The included evidence uses the corresponding ordinary Go backend, the released implementation, and the native executable from this fork. The GoIvy baseline and release were built from the same frontend revision, with the same local module replacement and with `-pgo=off -tags=xtrace_off`. The build records identify the previous linked native executable. All verifier runs had the same ABC executable in `PATH`.

The DIMACS fixtures are in `nov26-physical-clause-arena.tar.xz`. With both g3 executables built from `pkg/` using `go build -pgo=off -buildvcs=false -o /path/to/g3 ./cmd/g3`, rerun the seven ordinary rotations as follows.

```sh
out=/path/to/unpacked/nov26-physical-clause-release
fixtures=/path/to/unpacked/nov26-physical-clause-arena/fixtures
python3 "$out/measure.py" --cpu 11 --rounds 7 \
    --case "unsat:$fixtures/random-208-3.cnf" --case "sat:$fixtures/random-208-4.cnf" \
    --case "sat:$fixtures/planted3.cnf:stdin" --case "sat:$fixtures/planted8.cnf:stdin" \
    "baseline=/path/to/baseline/g3" "physical=/path/to/release/g3" "z3=../build/z3"
```

The baseline build overlaid the version of `sat/sat_clause_storage.go` from `ef703a38b` and hid the new `arena/clause_pages.go`. Add `--solver-arg=-v:2` for pigeon8 to run ordinary CDCL, and set `--perf` if perf is installed under a version-specific path. The driver checks hardware counter coverage, conflict, decision and propagation counts, and evaluates satisfying assignments against every clause. The profiles record one sample per 2,000,003 retired user instructions, with frame-pointer stacks. Both `throttle` files count zero lost or throttled samples.

The SAT fixture is `BenchmarkSATClauseMixedChurn` with `-benchtime=3x -benchmem`. The fixture allocates and retires 2,048 clauses per iteration in each of 24 independent stores. The peak and warm live heap values are forced-GC deltas beyond a base of 32 retained ternaries per worker. `BenchmarkSATClauseBorrowPopulation` uses `-benchtime=700x -benchmem`. Each round ran on CPU 9 with one Go processor, alternating binary order.

The default-GC verifier runs came from `perf/ivy_apple/holdouts/rotating_verification.py` with `--rounds 3 --min-idle 0.85`, `--previous`, `--g3`, `--native`, and hardware counters enabled. The accepted rows have at least 0.85 for sibling idleness and process CPU fraction. `verifier-hybrid` was stopped by the driver's idle guard before the first run. `verifier-hybrid-retry` has the accepted rotations. `verify_gc.py --reference "$out" --examples ~/ivy/ivy-lang-examples --cpu 9 --case ticket_protocol --case arm_rules3 --case hybrid baseline=/path/to/base/goivy_check physical=/path/to/release/goivy_check` reproduces the GC-off series. Both drivers check both output streams and the exit code against the archived reference.
