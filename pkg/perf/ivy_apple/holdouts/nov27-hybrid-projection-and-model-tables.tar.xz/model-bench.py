from pathlib import Path
import csv,os,subprocess
w=Path(__file__).resolve().parent;env=dict(os.environ,GOMAXPROCS='1')
with (w/'model-bench.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round mode benchmark metrics'.split())
 for r in range(9):
  modes=['base','views','packed']
  for mode in modes[r%3:]+modes[:r%3]:
   for pattern,time in [('ModelTableGroundEnumeration/Tables','5000x'),('ModelTableWorkerScratch','1x'),('ModelTableFunctionLookup/Arity2/(Last|First)','200000x')]:
    cmd=['taskset','-c','14',w/(mode+'-model.test'),'-test.run','^TestModelTable','-test.bench','^Benchmark'+pattern+'$','-test.benchtime='+time]
    p=subprocess.run(cmd,cwd=Path.cwd()/'smtcore',capture_output=True,text=True,env=env)
    assert p.returncode==0,p.stdout[-1500:]+p.stderr
    for line in p.stdout.splitlines():
     if line.startswith('Benchmark'):
      name,metrics=line.split(None,1);out.writerow([r,mode,name,metrics.strip()]);f.flush()
