from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent
o=json.loads((w/'views-model.json').read_text())['Replace']
folder=p/'smtcore'
for nm in ['smt_model_table.go','smt_model_table_check.go','smt_model_table_diagram.go']:
 k=folder/nm;s=Path(o.get(str(k),k)).read_text()
 if nm=='smt_model_table.go':
  s=s.replace('index int\n','index uint32\n',1).replace('tableVariable, int(index)','tableVariable, index').replace('tableConstant, id','tableConstant, uint32(id)').replace('n.index, err = g.function','index, err := g.function').replace('n.op = tableApplication','n.op, n.index = tableApplication, uint32(index)').replace('tableArithmetic, int(header.DeclKind)','tableArithmetic, uint32(header.DeclKind)')
 else:s=s.replace('term.index >= len(bindings)','uint64(term.index) >= uint64(len(bindings))').replace('return term.index','return int(term.index)').replace('result = -term.index','result = -int(term.index)')
 f=w/('small-'+nm);f.write_text(s);o[str(k)]=str(f)
j=w/'small-model.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','test','-c','-overlay',j,'-o',w/'small-model.test','./smtcore'],check=True)
o.update(json.loads((w/'base.json').read_text())['Replace']);j=w/'small.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'small','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
s=(w/'model-bench.py').read_text().replace("'views','packed'","'views','small'").replace("'model-bench.csv'","'small-bench.csv'").replace("'14'","'22'");exec(s)
