from pathlib import Path
import os,subprocess,csv,statistics,collections
w=Path(__file__).resolve().parent
rank=Path('/tmp/g3-reduction-rows')
ex=Path('/home/jaten/ivy/ivy-lang-examples')
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
def perf(cmd):
 stat=w/'prefix.stat'
 r=subprocess.run(['taskset','-c','18','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-e','instructions:u','-o',stat,'--',*cmd],capture_output=True,env=env,timeout=90)
 v,=[int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100]
 return r,v
with (w/'prefix-bench.csv').open('w') as f:
 o=csv.writer(f);o.writerow('round mode kind ns bytes objects'.split())
 for i in range(7):
  for mode in ['base','prefix'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','18',w/(mode+'.test'),'-test.run','^TestQuantifiedPremisesAcrossSiblingGoals$','-test.bench','^BenchmarkAppleQuantifiedPremises$','-test.benchtime=100x'],cwd=Path.cwd()/'api',env=env,check=True,capture_output=True)
   for line in r.stdout.decode().splitlines():
    if line.startswith('Benchmark'):
     name,count,ns,_,size,_,objs,_=line.split();o.writerow([i,mode,name,ns,size,objs]);f.flush()
names=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
with (w/'prefix-whole.csv').open('w') as f,(w/'prefix-census.csv').open('w') as cf:
 o=csv.writer(f);o.writerow('case round mode instructions'.split());c=csv.writer(cf);c.writerow('case seed hit nodes children base_nodes base_symbols terms arguments'.split())
 for nr in [2,3,4,12]:
  name=names[nr-1];ref=rank/'compat'/str(nr)/'1/native'
  for mode,i in [('census',0)]+[(m,i) for i in range(7) for m in ['base','prefix'][::1 if i%2==0 else -1]]:
   r,v=perf([w/mode,ex/name]);normal=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'PROJ '):c.writerow([name,*l.decode().split()[1:]])
    else:normal.append(l)
   assert (r.returncode,r.stdout,b''.join(normal))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,r.stderr[-300:])
   if mode!='census':o.writerow([name,i,mode,v]);f.flush()
   cf.flush()
