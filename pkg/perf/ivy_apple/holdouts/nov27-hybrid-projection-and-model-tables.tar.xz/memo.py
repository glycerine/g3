from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;folder=p/'smtcore'
o={}
for name in ['smt_model_table.go','smt_model_table_check.go']:
 f=folder/name;s=f.read_text()
 if name=='smt_model_table.go':
  s=s.replace('type tableModel struct {','type modelSavedValue struct { dep,key,value,depth,spent int }\ntype tableModel struct {\n memo []modelSavedValue')
  s=s.replace('g.manager = nil','g.memo=nil\n    g.manager = nil')
 else:
  s=s.replace('g.work = 100000','if tuples>=16 && count>=2 {g.prepareSavedValues()}\n    g.work = 100000',1)
  k='term := &g.terms[id]\n\teval := func'
  s=s.replace(k,'''term := &g.terms[id]
    if g.memo!=nil && term.op!=tableVariable && term.op!=tableConstant {
        e:=&g.memo[id]
        if e.dep>=-1 && e.dep<len(bindings) {
            key:=0;if e.dep>=0 {key=bindings[e.dep]}
            if e.value!=0 && e.key==key && e.depth==depth && g.work>e.spent {g.work-=e.spent;return e.value}
            start:=g.work;v:=g.evaluateTerm(term,bindings,depth)
            if !g.incomplete && v!=0 && g.work>0 {e.key,e.value,e.depth,e.spent=key,v,depth,start-g.work}
            return v
        }
    }
    return g.evaluateTerm(term,bindings,depth)
}
func(g *tableModel) prepareSavedValues(){
    g.memo=make([]modelSavedValue,len(g.terms))
    for i:=1;i<len(g.terms);i++{
        t:=&g.terms[i];dep:=-1
        if t.op==tableVariable {dep=t.index} else {
            for _,id:=range t.args{
                other:=g.memo[id].dep
                if other == -2 || (other>=0 && dep>=0 && other!=dep){dep=-2;break}
                if other>=0 {dep=other}
            }
        }
        g.memo[i].dep=dep
    }
}
func(g *tableModel)evaluateTerm(term *tableTerm,bindings []int,depth int)int{
    eval := func''')
 dest=w/('memo-'+name);dest.write_text(s);o[str(f)]=str(dest)
j=w/'memo-model.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','test','-overlay',j,'./smtcore','-run','TestModel(Table|Checker)','-count=1'],check=True)
o.update(json.loads((w/'base.json').read_text())['Replace']);j=w/'memo.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'memo','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
