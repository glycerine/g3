from pathlib import Path
import json,subprocess,re
p=Path.cwd();w=Path(__file__).resolve().parent;folder=p/'smtcore'
for mode in ['base','views','packed']:
 files={}
 def setsrc(name,text):
  ref=folder/name;dst=w/(mode+'-'+name);dst.write_text(text);files[str(ref)]=str(dst)
 if mode!='base':
  name='smt_model_table.go';s=(folder/name).read_text().replace('terms       []tableTerm','arguments   []int\n\tterms       []tableTerm')
  s=s.replace('n.args = make([]int, header.NumArgs)\n\t\tfor i := range n.args {','start:=len(g.arguments)\n        g.arguments=append(g.arguments, make([]int,header.NumArgs)...)\n        for i:=0; i<int(header.NumArgs);i++ {').replace('n.args[i], err = g.compile(arg, depth+1)','child,err:=g.compile(arg, depth+1)').replace('\t\t\tif err != nil || g.incomplete {\n\t\t\t\treturn 0, err\n\t\t\t}\n\t\t}\n\tdefault:', '\t\t\tif err != nil || g.incomplete {\n\t\t\t\treturn 0, err\n\t\t\t}\n            g.arguments[start+i]=child\n\t\t}\n        n.args=g.arguments[start:start+int(header.NumArgs)]\n\tdefault:')
  assert 'g.arguments[start+i]=child' in s
  s=s.replace('g.manager = nil','if cap(g.arguments)>512 { g.arguments=nil } else {g.arguments=g.arguments[:0]}\n    g.manager = nil')
  if mode=='packed':
   s=s.replace('args  []int','first,last uint32').replace('n.args=g.arguments[start:start+int(header.NumArgs)]','n.first,n.last=uint32(start),uint32(start)+header.NumArgs').replace('\tclear(g.terms)\n','')
   for name2,anchor,owner in [('smt_model_table_check.go','term := &g.terms[id]','g'),('smt_model_table_diagram.go','term := &d.model.terms[id]','d.model'),('smt_model_table_integer.go','func (g *tableModel) evaluateInteger(term *tableTerm, bindings []int, depth int) int {','g')]:
    t=(folder/name2).read_text().replace('term.args','children').replace(anchor,anchor+'\n    children:='+owner+'.arguments[term.first:term.last]');setsrc(name2,t)
   nm='smt_model_table_lookup_benchmark_test.go';t=(folder/nm).read_text().replace('g.terms = append(g.terms, tableTerm{op: tableApplication, args: args})','g.arguments=args\n        g.terms = append(g.terms, tableTerm{op: tableApplication, last: uint32(arity)})');setsrc(nm,t)
   nm='smt_model_table_diagram_test.go';t=(folder/nm).read_text()
   for key in ['func BenchmarkModelTableCongruence','func TestModelTableLookupSharedPrefix']:
    k=t.index(key);start=t.index('terms: []tableTerm{',k);end=t.index('\n\t\t},',start)
    args=[]
    def sub(m):
     i=len(args);args.extend(m[1].split(', '));return 'first: %d,last: %d'%(i,len(args))
    nodes=re.sub(r'args: \[\]int\{([^}]+)\}',sub,t[start:end]);t=t[:start]+'arguments: []int{'+', '.join(args)+'},\n        '+nodes+t[end:]
   setsrc(nm,t)
  setsrc(name,s)
 j=w/(mode+'-model.json');j.write_text(json.dumps({'Replace':files}))
 subprocess.run(['go','test','-c','-overlay',j,'-o',w/(mode+'-model.test'),'./smtcore'],check=True)
 files.update(json.loads((w/'base.json').read_text())['Replace']);j=w/(mode+'-verify.json');j.write_text(json.dumps({'Replace':files}))
 if mode!='base':
  subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/mode,'./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
