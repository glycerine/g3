from pathlib import Path
import csv,subprocess,json,sys,concurrent.futures
p=Path.cwd();w=Path(__file__).resolve().parent;old=Path('/tmp/g3-ticket-focus/prices')
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();mod=(p/'build/.boolean-enode-cost/heap/study.mod').resolve()
def job(e,cpu):
 ov=json.loads((old/('detail-'+e+'.json')).read_text())
 k=str(front/'focus_trial.go');source=Path(ov['Replace'][k]).read_text()
 filt='(batch!=4 && batch!=5) || (goal!=55 && goal!=56)';assert source.count(filt)==1
 f=w/(e+'-focus.go.txt');f.write_text(source.replace(filt,'(batch!=31 && batch!=33 && batch!=34) || (goal!=33 && goal!=34)'));ov['Replace'][k]=str(f)
 if e=='g3':
  for f in (p/'smtcore').glob('smt_*.go'):
   if str(f) in ov['Replace']:
    # Confirm the existing observer overlays contain the current production algorithm.
    baseline=subprocess.check_output(['git','show','e977d5f08:pkg/smtcore/'+f.name],text=True)
    assert baseline==f.read_text(),f
 j=w/(e+'.json');j.write_text(json.dumps(ov))
 subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',j,'-o',w/('detail-'+e),'./cmd/goivy_check'],cwd=front,check=True)
 s=(old/'run.py').read_text().replace("[(3,'4/55'),(3,'4/56'),(3,'5/55'),(3,'5/56')]","[(2,str(b)+'/'+str(g)) for b in [31,33,34] for g in [33,34]]").replace('range(5)','range(3)').replace("eng=sys.argv[1]","eng="+repr(e)).replace('sys.argv[2]',repr(cpu))
 exec(s,{'__file__':__file__})
with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(job,['g3','z3'],['8','14']))
exec((old/'summary.py').read_text())
