from pathlib import Path
import subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;fg=p/'api/internal/order/quantified_goal.go';fp=fg.with_name('quantified_premises.go')
g=fg.read_text();q=fp.read_text().replace('\t"maps"\n','')
g=g.replace('sharedPremises     bool','goalSymbols []ast.ASTHandle\n    sharedPremises     bool').replace('g.symbols[symbol] = n.symbol','g.symbols[symbol] = n.symbol\n                if g.goalSymbols!=nil {g.goalSymbols=append(g.goalSymbols,symbol)}')
g=g.replace('if err := g.readInputs(assertions[baseLen:], inputs[baseLen:]); err != nil {','if err := premises.readGoal(g, assertions[baseLen:], inputs[baseLen:]); err != nil {')
q=q[:q.index('\t// The goal appends nodes')]+'''    g.sourceIDs, g.symbols = p.sourceIDs, p.symbols
    return nil
}

func(p *QuantifiedPremises) readGoal(g *groundProjection, assertions []ast.ASTHandle, inputs []uint32) error {
    if p.manager==nil {return g.readInputs(assertions,inputs)}
    start:=len(g.input)
    g.goalSymbols=[]ast.ASTHandle{}
    err:=g.readInputs(assertions,inputs)
    for _,n:=range g.input[start:] {delete(g.sourceIDs,n.expr)}
    for _,decl:=range g.goalSymbols {delete(g.symbols,decl)}
    return err
}
'''
o={}
for f,s in [(fg,g),(fp,q)]:
 dest=w/('rollback-'+f.name);dest.write_text(s);o[str(f)]=str(dest)
j=w/'rollback-test.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','test','-c','-overlay',j,'-o',w/'rollback.test','./api'],check=True)
o.update(json.loads((w/'base.json').read_text())['Replace']);j=w/'rollback.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'rollback','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
s=(w/'run-prefix.py').read_text().replace('prefix','rollback').replace("'18'","'14'");exec(s)
