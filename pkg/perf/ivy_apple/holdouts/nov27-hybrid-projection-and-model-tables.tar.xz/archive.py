from pathlib import Path
import tarfile,csv
w=Path(__file__).resolve().parent
dest=Path('perf/ivy_apple/holdouts/nov27-hybrid-projection-and-model-tables.tar.xz')
with tarfile.open(dest,'w:xz') as t:
 for f in sorted(w.rglob('*')):
  if f.is_symlink() or not f.is_file() or f.suffix not in ('.go','.txt','.csv','.py','.md','.json','.log'):continue
  if f.name in ('phase-samples.csv','report.py'):continue
  t.add(f,str(f.relative_to(w)))
 for d,names in [('/tmp/g3-ticket-focus',['build.py','sample.py','prices/run.py','prices/summary.py','prices/build.py','prices/qi_queue.cpp','prices/smt_internalizer.cpp','prices/detail-g3-smt_internalizer.go','prices/detail-g3-smt_internalizer_state.go','prices/detail-g3-smt_cg_table.go','direct/bridge.go.txt']),('/tmp/g3-selective/final',['z3bridge_guarded_equalities.go','z3bridge_solver_model.go','overlay.json','apple.json','apple.go.txt','heap-main.go.txt']),('/tmp/g3-or-install/final',['release.py']),('/tmp/g3-plan-budget',['long.py'])]:
  for name in names:t.add(Path(d)/name,'dependencies/'+Path(d).parent.name+'-'+Path(d).name+'/'+name)
with tarfile.open(dest) as t:
 for n,count in [('release-whole.csv',168),('confirm.csv',42),('release-alloc.csv',12),('prices/summary.csv',None)]:
  import io
  rows=list(csv.DictReader(io.TextIOWrapper(t.extractfile(n))))
  assert rows and (count is None or len(rows)==count),(n,len(rows))
