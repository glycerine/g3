from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;fg=p/'api/internal/order/quantified_goal.go';fp=fg.with_name('quantified_premises.go')
q=(w/fp.name).read_text().replace('work, nextPoll     int','prepared *groundedPrefix\n    work, nextPoll int')
g=(w/fg.name).read_text().replace('import "github','import "maps"\nimport "github',1)
i=g.index('n := min(len(g.input)');j=g.index('\n\tfor _, id := range g.quantifiers',i)
g=g[:i]+'''g.global = make([]uint32, len(g.input))
    g.local = make([]uint32, len(g.input))
    g.version = make([]uint32, len(g.input))
    if p:=g.parsedPremises; p!=nil && p.prepared!=nil {
        prefix:=p.prepared
        if err:=g.compiler.charge(prefix.work);err!=nil{return nil,err}
        copy(g.global,prefix.global)
        g.terms,g.arguments=prefix.terms,prefix.arguments
        g.quantifiers,g.roots=prefix.quantifiers,prefix.roots
        g.applications=maps.Clone(prefix.applications)
        inputs=inputs[len(p.roots):]
    } else {
        n:=min(len(g.input),g.compiler.ceiling-g.compiler.work+1,2048)
        if !seedGoal && n>=16 {
            g.terms=make([]groundApplication,1,n)
            g.applications=make(map[uint64]uint32,n)
            g.arguments=make([]uint32,0,min(len(g.children),2*n))
        }
    }
    initialWork:=g.compiler.work
    for i,id:=range inputs {
        term,err:=g.ground(id,0);if err!=nil{return nil,err}
        g.roots=append(g.roots,term)
        if p:=g.parsedPremises; p!=nil && p.prepared==nil && i+1==len(p.roots) {
            p.prepared=&groundedPrefix{
                work:g.compiler.work-initialWork, global:append([]uint32(nil),g.global[:len(p.input)]...),
                terms:g.terms, arguments:g.arguments, quantifiers:g.quantifiers,roots:g.roots,
                applications:maps.Clone(g.applications),
            }
        }
    }'''+g[j:]
q+='''
type groundedPrefix struct {
 work int
 global,arguments,quantifiers,roots []uint32
 terms []groundApplication
 applications map[uint64]uint32
}
'''
o={}
for f,s in [(fg,g),(fp,q)]:
 dst=w/('prefix-'+f.name);dst.write_text(s);o[str(f)]=str(dst)
j=w/'prefix-test.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','test','-c','-overlay',j,'-o',w/'prefix.test','./api'],check=True)
o.update(json.loads((w/'base.json').read_text())['Replace']);j=w/'prefix.json';j.write_text(json.dumps({'Replace':o}))
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'prefix','./cmd/goivy_check'],cwd=front,check=True)
