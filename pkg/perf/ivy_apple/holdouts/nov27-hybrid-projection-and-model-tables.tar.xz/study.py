from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
fg=p/'api/internal/order/quantified_goal.go';fp=fg.with_name('quantified_premises.go')
g=fg.read_text();q=fp.read_text().replace('\t"maps"\n','')
g=g.replace('sharedPremises     bool','parsedPremises *QuantifiedPremises\n\tsharedPremises     bool')
g=g.replace('if id := g.sourceIDs[h]; id != 0 {','if g.parsedPremises != nil { if id:=g.parsedPremises.sourceIDs[h]; id!=0{return id,nil} }; if id := g.sourceIDs[h]; id != 0 {')
g=g.replace('n.symbol = g.symbols[symbol]','''if g.parsedPremises!=nil {n.symbol=g.parsedPremises.symbols[symbol]}
        if n.symbol==0 {n.symbol = g.symbols[symbol]}''').replace('n.symbol = uint32(len(g.symbols) + 1)','n.symbol = uint32(len(g.symbols) + 1); if g.parsedPremises!=nil{n.symbol+=uint32(len(g.parsedPremises.symbols))}')
q=q.replace('p.sourceIDs, p.symbols = g.sourceIDs, g.symbols','p.sourceIDs, p.symbols = g.sourceIDs, g.symbols\n        g.sourceIDs, g.symbols = make(map[ast.ASTHandle]uint32),make(map[ast.ASTHandle]uint32)')
q=q.replace('g.sourceIDs, g.symbols = maps.Clone(p.sourceIDs), maps.Clone(p.symbols)','g.parsedPremises = p')
for f,s in [(fg,g),(fp,q)]: (w/f.name).write_text(s)
o={str(f):str(w/f.name) for f in [fg,fp]}
j=w/'trial.json';j.write_text(json.dumps({'Replace':o}))
for mode in ['base','delta','census']:
 files={} if mode!='delta' else o.copy()
 if mode=='census':
  counts=fg.read_text().replace('g.sharedPremises = seedGoal','''baseHit:=premises!=nil && premises.manager==g.manager && slices.Equal(premises.base,assertions[:len(assertions)-1])
    defer func(){pn,ps:=0,0;if premises!=nil{pn=len(premises.sourceIDs);ps=len(premises.symbols)};println("PROJ",seedGoal,baseHit,len(g.input),len(g.children),pn,ps,len(g.terms),len(g.arguments))}()
    g.sharedPremises = seedGoal''').replace('import "github','import "slices"\nimport "github')
  f=w/'count.go.txt';f.write_text(counts);files[str(fg)]=str(f)
 files.update(json.loads(Path('/tmp/g3-selective/final/overlay.json').read_text())['Replace'])
 j=w/(mode+'.json');j.write_text(json.dumps({'Replace':files}))
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
 if mode!='census':
  opts=['-overlay',w/'trial.json'] if mode=='delta' else []
  subprocess.run(['go','test','-c',*opts,'-o',w/(mode+'.test'),'./api'],check=True)
