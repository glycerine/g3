from pathlib import Path
import csv,statistics,collections
w=Path(__file__).resolve().parent
for stem in ['bench','prefix-bench','rollback-bench','whole','prefix-whole','memo-whole','release-alloc','alloc','release-whole','workers']:
 rows=collections.defaultdict(list)
 for r in csv.DictReader((w/(stem+'.csv')).open()):
  rows[r.get('case',r.get('kind','')).split('/')[-1],r['mode']].append([float(r[k]) for k in ['instructions','ms','objects','total_bytes','ns','bytes','retained'] if k in r])
 print(stem)
 for (c,m),v in rows.items():
  if stem=='alloc' and m not in ('base','views'):continue
  print(c,m,len(v),[round(statistics.median(x),2) for x in zip(*v)])
