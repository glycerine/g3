from pathlib import Path
import os
w=Path(__file__).resolve().parent;os.environ['FOCUS_BIN']=str(w)
s=Path('/tmp/g3-ticket-focus/build.py').read_text().replace('(batch!=4 && batch!=5) || (goal!=55 && goal!=56)','(batch!=31 && batch!=33 && batch!=34) || (goal!=33 && goal!=34)')
exec(s)
s=Path('/tmp/g3-ticket-focus/sample.py').read_text().replace("'popl18' in n and n.endswith('/ticket_protocol.ivy')","n.endswith('/hybrid_reliable_broadcast_cisa.ivy')").replace('len(windows)==4','len(windows)==6').replace('range(11)','range(7)').replace("'-c','12'","'-c','12'")
exec(s)
