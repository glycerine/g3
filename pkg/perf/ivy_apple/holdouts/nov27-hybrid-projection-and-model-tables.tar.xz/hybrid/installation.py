"""Count nearest sampled callee of each engine's instance-installation entry."""
import csv,collections
from pathlib import Path
w=Path(__file__).resolve().parent
keys={'g3':'github.com/glycerine/g3/pkg/smtcore.(*SMTQIInstanceBuilder).MaterializeAndInternalize','z3':'smt::qi_queue::instantiate(smt::qi_queue::entry&)'}
counts=collections.Counter(); rounds=collections.defaultdict(set)
for row in csv.DictReader((w/'samples.csv').open()):
 e=row['engine'];frames=row['stack'].splitlines()
 rounds[e].add(row['round'])
 if keys[e] not in frames:continue
 pos=frames.index(keys[e]);child=frames[pos-1] if pos else '(self)'
 counts[e,child]+=int(row['period'])*int(row['count'])
with (w/'installation.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['engine','nearest_sampled_callee','mean_sampled_instructions'])
 for (e,child),count in counts.most_common():o.writerow([e,child,round(count/len(rounds[e]))])
