from pathlib import Path
import csv,os,re,sys,subprocess,collections
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);ex=Path('/home/jaten/ivy/ivy-lang-examples');names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
name=next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy'));gold=Path('/tmp/g3-reduction-rows/compat')/str(names.index(name)+1)/'1/native'
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),DEBUGINFOD_URLS='',GOGC='100')
def stamp(n):return '%d.%09d'%divmod(n,10**9)
with (w/'samples.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round engine batch goal period count stack'.split())
 for i in range(11):
  for mode in ['g3','z3'][::1 if i%2==0 else -1]:
   data=d/('run-%s.data'%mode);period=1500007+i*2029
   r=subprocess.run(['taskset','-c','12',perf,'record','--clockid','mono','-m','1024','-B','-N','-q','-e','instructions:u','-c',str(period),'--call-graph','fp,56' if mode=='g3' else 'dwarf,8192','-o',data,d/mode,ex/name],cwd=d,capture_output=True,env=env)
   lines=r.stderr.splitlines(keepends=True);windows=[[int(v) for v in line.split()[1:]] for line in lines if line.startswith(b'WINDOW ')]
   assert (r.returncode,r.stdout,b''.join(x for x in lines if not x.startswith(b'WINDOW ')))==(0,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(mode,r.stderr[-500:])
   assert len(windows)==4,(mode,windows)
   stats=subprocess.check_output([perf,'report','--stdio','--stats','-i',data],text=True)
   assert not re.search(r'(LOST|THROTTLE) events:',stats)
   for b,g,tid,l,h in windows:
    text=subprocess.check_output([perf,'script','--no-inline','--ns','--tid',str(tid),'--time',stamp(l)+','+stamp(h),'-F','tid,time,event,ip,sym','-i',data],text=True,env=env)
    tally=collections.Counter()
    for row in text.strip().split('\n\n'):
     lines=row.splitlines()
     if len(lines)>1:tally['\n'.join(re.sub(r'^\s*[0-9a-f]+\s+','',x).strip() for x in lines[1:])]+=1
    assert tally,(mode,b,g)
    for stack,c in tally.items():out.writerow([i,mode,b,g,period,c,stack])
   f.flush();data.unlink()
