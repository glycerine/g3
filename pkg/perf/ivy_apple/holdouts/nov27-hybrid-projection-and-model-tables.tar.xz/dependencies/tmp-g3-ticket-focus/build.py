from pathlib import Path
import subprocess,json,os
p=Path.cwd();w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);d.mkdir(exist_ok=True)
front=p/'build/.boolean-enode-cost/frontend/goivy'; f=front/'z3bridge_solver_model.go'
s=f.read_text().replace('s.showVCsBase(clauses)','s.showVCsBase(clauses)\n batch:=newStageBatch()',1)
key='for _, fc := range finalCond {'; assert s.count(key)==1
s=s.replace(key,'for ordinal, fc := range finalCond {')
key='res, err := s.decideZ3With(z3solver, finalCheck)';assert s.count(key)==1
s=s.replace(key,'end := startStage(batch,ordinal+1)\n'+key+'\nend("check")');(w/'bridge.go.txt').write_text(s)
src=(Path('/tmp/g3-ticket-all-checks/windows.go.txt').read_text().replace('if goal==0','if (batch!=4 && batch!=5) || (goal!=55 && goal!=56)'));(w/'window.go.txt').write_text(src)
o=w/'overlay.json';o.write_text(json.dumps({'Replace':{str(f.resolve()):str(w/'bridge.go.txt'),str((front/'focus_trial.go').resolve()):str(w/'window.go.txt')}}))
for name,tags in [('g3','xtrace_off'),('z3','xtrace_off,classic_z3')]:
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags',tags,'-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/name,'./cmd/goivy_check'],cwd=front,check=True)
