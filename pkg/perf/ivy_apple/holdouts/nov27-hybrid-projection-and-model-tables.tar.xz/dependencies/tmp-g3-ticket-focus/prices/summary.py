from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('engine case operation rounds calls instructions per_call'.split())
 for e in ['g3','z3']:
  d=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0]))
  for r in csv.DictReader((w/(e+'.csv')).open()):
   k=int(r['slot']);name={6:'or-operands',7:'root-clauses',14:'asserted-instances'}.get(k) or ['variable','enode','gate','gate-clause','congruence','term'][k%8]
   vals=d[r['target'],name][int(r['round'])];vals[0]+=int(r['calls']);vals[1]+=int(r['instructions'])
  for (c,n),vs in sorted(d.items()):
   calls={v[0] for v in vs.values()};assert len(calls)==1;count=calls.pop();ins=int(statistics.median(v[1] for v in vs.values()))
   out.writerow([e,c,n,len(vs),count,ins,round(ins/count,2)])
