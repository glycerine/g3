from pathlib import Path
import subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;o=json.loads((w/'packed-model.json').read_text())['Replace']
k=p/'smtcore/smt_model_table_check.go';s=Path(o[str(k)]).read_text();left=s.index('children:=');right=s.index('switch term.op',left);definition=s[left:right];start=s.index('case ast.ASTOpNot:',right)
s=s[:left]+s[right:start]+'}\n    '+definition+'switch term.op {\n    '+s[start:];f=w/'leaves.go.txt';f.write_text(s);o[str(k)]=str(f);j=w/'leaves-model.json';j.write_text(json.dumps({'Replace':o}))
subprocess.run(['go','test','-c','-overlay',j,'-o',w/'leaves-model.test','./smtcore'],check=True)
o.update(json.loads((w/'base.json').read_text())['Replace']);j=w/'leaves-verify.json';j.write_text(json.dumps({'Replace':o}));front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/'leaves','./cmd/goivy_check'],cwd=front,check=True)
