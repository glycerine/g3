from pathlib import Path
import subprocess,json,os,csv
w=Path(__file__).resolve().parent;p=Path.cwd()
for mode in ['base','delta','prefix']:
 j=w/('workers-'+mode+'.json')
 o={'Replace':{}} if mode=='base' else json.loads((w/('trial.json' if mode=='delta' else 'prefix-test.json')).read_text())
 o['Replace'][str(p/'api/api_projection_workers_benchmark_test.go')]=str(w/'live_test.go.txt')
 j.write_text(json.dumps(o))
 subprocess.run(['go','test','-c','-overlay',j,'-o',w/('workers-'+mode+'.test'),'./api'],check=True)
with (w/'workers.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round mode kind retained'.split())
 for i in range(3):
  modes=['base','delta','prefix']
  for m in modes[i:]+modes[:i]:
   r=subprocess.run(['taskset','-c','16',w/('workers-'+m+'.test'),'-test.run','^$','-test.bench','^BenchmarkQuantifiedPremiseWorkers$','-test.benchtime=2x'],env=dict(os.environ,GOMAXPROCS='1'),cwd=p/'api',capture_output=True,check=True,timeout=180)
   for line in r.stdout.decode().splitlines():
    if line.startswith('Benchmark'):v=line.split();out.writerow([i,m,v[0],v[-2]]);f.flush()
