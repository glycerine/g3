"""Isolate PGO recursive inlining of Internalize with the production profile."""
from pathlib import Path
import subprocess as sp
d=Path(__file__).resolve().parent
s=(d/'notify-trials.py').read_text()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+'''    modes=['base','boundary']
    for mode in modes:
        for filename in ['smt_internalizer.go','smt_mam_code.go']:
            p=pkg/'smtcore'/filename
            source=sp.check_output(['git','show','b79866e51:pkg/smtcore/'+filename]).decode()
            if mode=='boundary' and filename=='smt_internalizer.go':
                anchor='func (s *SMTInternalizerState) Internalize('
                assert source.count(anchor)==1
                source=source.replace(anchor,'//go:noinline\\n'+anchor)
            put(p,source)
'''+s[b:]
s=s.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("'notification.csv'","'header.csv'")
exec(compile(s,'header','exec'))
