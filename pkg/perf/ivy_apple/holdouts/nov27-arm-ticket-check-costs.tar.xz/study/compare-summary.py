"""Report medians of round totals, and paired changes on complete verifiers."""
import csv,collections,statistics as st
from pathlib import Path
d=Path(__file__).resolve().parent
for name in ['header','compact','layout-heap','header-heap','header-value']:
    p=d/(name+'.csv')
    if not p.exists():continue
    rows=list(csv.DictReader(p.open()))
    for col in ['instructions','allocated_bytes','mallocs']:
        groups=collections.defaultdict(collections.Counter)
        for r in rows:
            if col in r:groups[r['case'],r['mode']][r['round']]+=int(r[col])
        for key,totals in sorted(groups.items()):
            print(name,col,*key,len(totals),st.median(totals.values()))
for p in sorted(d.glob('*/time-*.csv')):
    rounds=collections.defaultdict(dict)
    for r in csv.DictReader(p.open()):rounds[r['round']][r['engine']]=r
    for k in ['instructions','cycles','wall_ms']:
        paired=[100*(float(v['trial'][k])/float(v['base'][k])-1) for v in rounds.values() if len(v)==2]
        if paired:print(p.parent.name,p.stem,k,len(paired),round(st.median(paired),2))
