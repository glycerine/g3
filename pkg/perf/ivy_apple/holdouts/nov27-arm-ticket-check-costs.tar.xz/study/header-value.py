from pathlib import Path
import runpy
here=Path(__file__).resolve().parent
v=runpy.run_path(str(here/'header-variants.py'))
source_variant=v['source_variant']
s=(here/'notify-trials.py').read_text()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+v['build_part']()+s[b:]
s=s.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'notification.csv'","'header-value.csv'")
exec(compile(s,'header-value','exec'))
