"""Record allocator-attributed call stacks in the live incremental history of each check."""
from pathlib import Path
import csv,json,os,subprocess as sp,tarfile,tempfile
d=Path(__file__).resolve().parent
body=(d/'stacks.py').read_text()
i=body.index(" for eng in ('g3','z3'):")
j=body.index(" ctl=d/'ctl';",i)
body=body[:j].replace("for eng in ('g3','z3'):","for eng in ('g3',):").replace("'profile.go.txt'","'alloc.go.txt'")
body+=""" with (out/'alloc.csv').open('w') as f:
    w=csv.writer(f);w.writerow('case batch goal objects bytes stack'.split())
    for case,b,g in [(4,6,4),(4,6,5),(4,6,6),(8,12,8),(8,16,1),(8,14,8),(8,13,8)]:
        spec=(ref/'compat.txt').read_text().splitlines()[case-1]
        code=next(int(x['exit']) for x in csv.DictReader((ref/'ranking.csv').open()) if x['case']==spec)
        env=dict(os.environ,GODEBUG='memprofilerate=1',GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TARGET_GOAL=f'{b}/{g}')
        r=sp.run(['taskset','-c',os.environ['CPU'],d/'g3',ex/spec],cwd=d,capture_output=True,env=env,timeout=240)
        ordinary=[];sites=0
        for line in r.stderr.splitlines(keepends=True):
            if line.startswith(b'SITE\\t'):
                _,objects,size,stack=line.rstrip().split(b'\\t',3)
                w.writerow([case,b,g,int(objects),int(size),stack.decode()]);sites+=1
            else:ordinary.append(line)
        gold=ref/'compat'/str(case)/'1/native'
        assert sites>0 and (r.returncode,r.stdout,b''.join(ordinary))==(code,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(r.returncode,r.stderr[-900:])
        f.flush()
"""
exec(compile(body,'allocation','exec'))
