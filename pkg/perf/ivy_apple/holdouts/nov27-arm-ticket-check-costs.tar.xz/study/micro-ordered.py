"""Count instructions for exact, commuted and absent erasures in alternating runs."""
import csv,os,json,subprocess as sp,tempfile
from pathlib import Path
here=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp);p=Path('smtcore/smt_cg_table.go').resolve()
    mappings={}
    for name in ('smt_cg_table.go','smt_cg_small_table.go'):
        p=Path('smtcore',name).resolve();src=d/p.name
        src.write_bytes(sp.check_output(['git','show','b79866e51:pkg/smtcore/'+name]))
        mappings[str(p)]=str(src)
    ov=d/'orig.json';ov.write_text(json.dumps({'Replace':mappings}))
    for mode in ('base','ordered'):
        sp.run(['go','test','-c','-o',d/mode,*(['-overlay',ov] if mode=='base' else []),'./smtcore'],check=True)
    with (here/'micro-ordered.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['round','mode','probe','instructions','ns_op'])
        for i in range(5):
            for mode in (('ordered','base') if i%2 else ('base','ordered')):
                for name in ('EraseInsert','EraseCommuted','EraseMiss'):
                    path=d/'stat';r=sp.run(['taskset','-c',os.environ['CPU'],os.environ['PERF'],'stat','-x,','-e','instructions:u','-o',path,'--',d/mode,'-test.run=^$','-test.cpu=1','-test.benchtime=1000000x','-test.bench=^BenchmarkSMTCongruenceProbes$/^'+name+'$'],check=True,capture_output=True,text=True)
                    v=next(r for r in csv.reader(path.open()) if len(r)>4 and r[2]=='instructions:u')
                    assert float(v[4])==100
                    row=next(x.split() for x in r.stdout.splitlines() if x.startswith('BenchmarkSMTCongruenceProbes'))
                    w.writerow([i,mode,name,int(v[0]),float(row[2])]);f.flush()
