"""Separate Go GC pacing from mutator work on the seven checks, with allocation counters outside the timed interval."""
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'notify-trials.py').read_text()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+'''    observer=Path(mp[str(front/'phase_observer_trial.go')])
    src=observer.read_text().replace('start := time.Now()', 'var before,after runtime.MemStats; if track {runtime.ReadMemStats(&before)};start := time.Now()').replace('runtime.LockOSThread()','track:=os.Getenv("TRACK_HEAP")=="1";runtime.LockOSThread()').replace('runtime.UnlockOSThread()', 'if track {runtime.ReadMemStats(&after);fmt.Fprintln(os.Stderr,"HEAP",batch,goal,after.TotalAlloc-before.TotalAlloc,after.Mallocs-before.Mallocs,after.NumGC-before.NumGC)};runtime.UnlockOSThread()')
    observer.write_text(src)
    for mode in ['release']:
'''+s[b:]
s=s.replace("'notification.csv'","'gc.csv'").replace("w.writerow('round case mode batch goal instructions'.split())","w.writerow('round case gc track batch goal instructions allocated_bytes mallocs collections'.split())")
s=s.replace('for i in range(4):','modes=[("100","0"),("off","1"),("off","0"),("100","1")]\n        for i in range(4):').replace('for mode in modes[i:]+modes[:i]:','for gc,track in modes[i:]+modes[:i]:').replace('d/mode,ex/spec',"d/'release',ex/spec").replace("GOGC='off',GOMAXPROCS","GOGC=gc,TRACK_HEAP=track,GOMAXPROCS")
s=s.replace('clean=[];cost={}','clean=[];cost={};heap={}').replace("if l.startswith(b'OPEN '):continue","if l.startswith(b'HEAP '):\n                            heap[tuple(map(int,a[1:3]))]=list(map(int,a[3:]));continue\n                        if l.startswith(b'OPEN '):continue").replace('for k,v in cost.items():w.writerow([i,case,mode,*k,v])','for k,v in cost.items():w.writerow([i,case,gc,track,*k,v,*(heap[k] if track=="1" else ["","",""])])')
exec(compile(s,'gc','exec'))
