from pathlib import Path
import importlib.util
p=Path(__file__).resolve().parent
def source_variant(s, mode):
    if mode=='base':return s
    if mode=='boundary':return s.replace('func (s *SMTInternalizerState) Internalize(', '//go:noinline\nfunc (s *SMTInternalizerState) Internalize(')
    a=s.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp');b=s.index('func (s *SMTInternalizerState) argumentLiterals',a)
    part=s[a:b].replace('header *ast.ASTNodeHeader','header ast.ASTNodeHeader').replace('s.smtHeaderBasicOperation(header)','s.smtHeaderBasicOperation(&header)').replace('s.mkBoolVar(expression, header','s.mkBoolVar(expression, &header')
    return (s[:a]+part+s[b:]).replace('internalizeFormulaCoreOp(expression, gateContext, header, true)','internalizeFormulaCoreOp(expression, gateContext, *header, true)').replace('internalizeFormulaCoreOp(expression, gateContext, &header, false)','internalizeFormulaCoreOp(expression, gateContext, header, false)')
def build_part():
    return """    modes=['base','boundary','value']
    for mode in modes:
        for name in ('smt_internalizer.go','smt_mam_code.go'):
            source=sp.check_output(['git','show','b79866e51:pkg/smtcore/'+name]).decode()
            put(pkg/'smtcore'/name,source_variant(source,mode) if name=='smt_internalizer.go' else source)
"""
if __name__=='__main__':
    s=(p/'layout-heap.py').read_text()
    start=s.index('s=s[:a]+"""');end=s.index('+s[b:]',start)
    s=s[:start]+'s=s[:a]+build_part()'+s[end:]
    exec(compile(s.replace('layout-heap.csv','header-heap.csv'),'header-heap','exec'))
