"""Generate matcher layouts with common instructions and coallocated opcode-specific operands."""
from pathlib import Path
import re,subprocess as sp
def base_source():
    return sp.check_output(['git','show','b79866e51:pkg/smtcore/smt_mam_code.go']).decode()
def layout(mode):
    s=base_source()
    if mode=='base':return s
    start=s.index('// smtMAMInstr is');end=s.index('func (i *smtMAMInstr) isInit()',start)
    s=s[:start]+'''// Common interpreter operands. Instructions that need AST handles or
// variable-length operands allocate those alongside this record.
type smtMAMInstr struct {
	next *smtMAMInstr
	alt *smtMAMInstr
	enode *SMTEnode
	*smtMAMAppOperands
	*smtMAMYieldOperands
	lblSet approx.UintSet
	numArgs uint32
	reg1, reg2 uint32
	reg uint32
	oreg, ireg uint32
	op smtMAMOpcode
}

type smtMAMAppOperands struct {
	label ast.ASTHandle
	joints []smtMAMJoint
	iregs []uint32
}

type smtMAMYieldOperands struct {
	qa, pat ast.ASTHandle
	binding []uint32
}

func newSMTMAMAppInstr(label ast.ASTHandle) *smtMAMInstr {
	block := new(struct {
		instr smtMAMInstr
		operands smtMAMAppOperands
	})
	block.operands.label = label
	block.instr.smtMAMAppOperands = &block.operands
	return &block.instr
}

'''+s[end:]
    a=s.index('return &smtMAMInstr{op: mamCountedOp(mamBIND1')
    b=s.index('\n}',a)
    s=s[:a]+'''r := newSMTMAMAppInstr(lbl)
	r.op, r.numArgs = mamCountedOp(mamBIND1, mamBINDN, numArgs), numArgs
	r.ireg, r.oreg = ireg, oreg
	return r'''+s[b:]
    s=re.sub(r'r := &smtMAMInstr\{op: mamCountedOp\(mamGETCGR1,.*?\n', '''r := newSMTMAMAppInstr(lbl)
	r.numArgs, r.oreg = uint32(len(iregs)), oreg
	r.op = mamCountedOp(mamGETCGR1, mamGETCGRN, r.numArgs)
	r.iregs = append([]uint32(nil), iregs...)
''',s)
    s=re.sub(r'return &smtMAMInstr\{op: mamISCGR,.*?\n','''r := newSMTMAMAppInstr(lbl)
	r.op, r.numArgs, r.ireg = mamISCGR, uint32(len(iregs)), ireg
	r.iregs = append([]uint32(nil), iregs...)
	return r
''',s)
    s=re.sub(r'return &smtMAMInstr\{op: mamCountedOp\(mamYIELD1,.*?\n','''block := new(struct {
		instr smtMAMInstr
		yield smtMAMYieldOperands
	})
	block.instr.smtMAMYieldOperands = &block.yield
	block.instr.op = mamCountedOp(mamYIELD1, mamYIELDN, uint32(len(bindings)))
	block.yield.qa, block.yield.pat = qa, pat
	block.yield.binding = append([]uint32(nil), bindings...)
	return &block.instr
''',s)
    s=re.sub(r'return &smtMAMInstr\{op: mamCONTINUE,.*?\n','''r := newSMTMAMAppInstr(lbl)
	r.op, r.numArgs, r.oreg, r.lblSet = mamCONTINUE, numArgs, oreg, s
	r.joints = append([]smtMAMJoint(nil), joints...)
	return r
''',s)
    if mode=='inline':
        s=s.replace('yield smtMAMYieldOperands\n\t})','yield smtMAMYieldOperands\n\t\tshort [3]uint32\n\t})')
        s=s.replace('block.yield.binding = append([]uint32(nil), bindings...)','''if len(bindings) <= len(block.short) {
		block.yield.binding = block.short[:len(bindings):len(bindings)]
		copy(block.yield.binding, bindings)
	} else {
		block.yield.binding = append([]uint32(nil), bindings...)
	}''')
    return s
if __name__=='__main__':
    d=Path(__file__).resolve().parent
    s=(d/'notify-trials.py').read_text();a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
    s=s[:a]+"""    modes=['base','compact','inline']
    for mode in modes:
        put(pkg/'smtcore/smt_mam_code.go',layout(mode))
        for name in ('smt_cg_table.go','smt_cg_small_table.go'):
            put(pkg/'smtcore'/name,sp.check_output(['git','show','b79866e51:pkg/smtcore/'+name]).decode())
"""+s[b:]
    s=s.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'notification.csv'","'compact.csv'")
    exec(compile(s,'compact','exec'))
