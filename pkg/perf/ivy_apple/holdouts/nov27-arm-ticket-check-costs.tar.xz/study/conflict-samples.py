"""Partition resolver samples by its immediate callee, once per sampled stack."""
import csv,collections
from pathlib import Path
d=Path(__file__).resolve().parent
bins=collections.Counter()
for r in csv.DictReader((d/'stacks.csv').open()):
    frames=r['stack'].splitlines()
    needle='SMTKernel).resolveSearchConflict' if r['engine']=='g3' else 'smt::context::resolve_conflict()'
    ix=next((i for i in reversed(range(len(frames))) if needle in frames[i]),None)
    if ix is None:continue
    callee=frames[ix-1] if ix else '<self>'
    bins[r['case'],r['engine'],callee]+=int(r['samples'])*int(r['period'])
with (d/'conflict-samples.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['case','engine','child_frame','mean_sampled_M'])
    for (case,engine,callee),total in sorted(bins.items(), key=lambda kv:-kv[1]):
        w.writerow([case,engine,callee,round(total/3e6,2)])
