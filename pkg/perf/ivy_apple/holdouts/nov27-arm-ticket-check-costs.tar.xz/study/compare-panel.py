"""Compare complete verifiers with selected baseline sources from git."""
from pathlib import Path
import os,tarfile,subprocess as sp
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
 s=t.extractfile('study/panel.py').read().decode()
a=s.index("    if name=='trial':");b=s.index("    j=d/",a)
s=s[:a]+"""    if name=='base':
        for fname in os.environ['BASE_FILES'].split(','):
            path=d/fname;path.write_bytes(sp.check_output(['git','show',os.environ['BASE_REV']+':pkg/smtcore/'+fname]))
            mp[str(pkg/'smtcore'/fname)]=str(path)
"""+s[b:]
exec(compile(s,'panel','exec'))
