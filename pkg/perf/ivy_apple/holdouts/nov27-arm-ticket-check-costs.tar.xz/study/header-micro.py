import json,os,tempfile,subprocess as sp
from pathlib import Path
src=Path('smtcore/smt_internalizer.go').resolve()
here=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    old=tmp/'old.go'
    old.write_bytes(sp.check_output(['git','show','4fac8a1a2:pkg/smtcore/smt_internalizer.go']))
    overlay=tmp/'overlay.json'
    overlay.write_text(json.dumps({'Replace':{str(src):str(old)}}))
    for mode in ['base','value']:
        sp.run(['go','test','-c','-o',tmp/mode,'-pgo='+str(Path('perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),*(['-overlay',overlay] if mode=='base' else []),'./smtcore'],check=True)
    with (here/'header.bench').open('w') as f:
        for i in range(6):
            for mode in (['base','value'] if i%2==0 else ['value','base']):
                print('variant:',mode,file=f,flush=True)
                sp.run(['taskset','-c',os.environ['CPU'],tmp/mode,'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTInternalizeFormulaChildren$','-test.benchtime=10000x'],stdout=f,check=True)
