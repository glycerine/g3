"""Measure seven checks in their original solver histories, with paired uninstrumented controls."""
from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-tlb-model-bindings.tar.xz') as t:
    s=t.extractfile('study/phases.py').read().decode()
s=s.replace("('base','release','native')","('release','native')")
s=s.replace("b'capturePush=batch==60 && index==0;'","b'capturePush=(batch==6 && index>=3 && index<=5)||(batch==12 && index==7)||(batch==16 && index==0)||((batch==13||batch==14)&&index==7);'")
s=s.replace('        put(front/fn,data)',"""        if fn.startswith('phase_'):
            data=data.replace(b'if capturePush { os.Setenv',b'if capturePush { if os.Getenv("OBSERVE_QI")=="1"{os.Setenv').replace(b'fmt.Sprint(fd));fmt.Fprintln',b'fmt.Sprint(fd))};fmt.Fprintln')
        put(front/fn,data)""")
s=s[:s.index(" with (out/'phases.csv')")]+""" with (out/'phases.csv').open('w') as f:
    w=csv.writer(f);w.writerow('round case engine observed batch goal phase flag calls instructions'.split())
    specs=(ref/'compat.txt').read_text().splitlines()
    exits={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
    for i in range(3):
      for case,targets in [(4,{(6,4),(6,5),(6,6)}),(8,{(12,8),(16,1),(14,8),(13,8)})]:
        spec=specs[case-1]
        modes=[('release',0),('native',1),('release',1),('native',0)]
        for eng,observe in modes[i:]+modes[:i]:
            r=sp.run(['taskset','-c',os.environ['CPU'],d/eng,ex/spec],cwd=d,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',OBSERVE_QI=str(observe),XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),timeout=180)
            clean=[];active=None;done=set();cost=Counter();count=Counter()
            for line in r.stderr.splitlines(keepends=True):
                a=line.split()
                if line.startswith(b'OPEN '):
                    assert active is None
                    active=tuple(map(int,a[1:]))
                elif line.startswith(b'STAGE-COUNT '):
                    if active:
                        assert active==tuple(map(int,a[1:3])) and a[3]==b'check' and a[6]==a[7]
                        if active in targets:
                            assert active not in done
                            done.add(active)
                            w.writerow([i,case,eng,observe,*active,'whole',0,1,int(a[4])])
                            for k in sorted(count):w.writerow([i,case,eng,observe,*active,*k,count[k],cost[k]])
                        active=None;cost.clear();count.clear()
                elif active and a and a[0] in (b'C',b'S',b'R',b'A'):
                    assert observe
                    k=(a[0].decode(),int(a[1]));count[k]+=1;cost[k]+=int(a[2])
                else:clean.append(line)
            gold=ref/'compat'/str(case)/'1/native'
            assert (r.returncode,r.stdout,b''.join(clean))==(exits[spec],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(eng,r.stderr[-1000:])
            assert done==targets,(eng,done,targets)
            f.flush()
"""
exec(compile(s,'seven-checks','exec'))
