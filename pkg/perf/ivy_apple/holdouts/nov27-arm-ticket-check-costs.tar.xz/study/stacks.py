"""Sample the live Satisfiability Modulo Theories check with perf disabled outside it."""
import csv,json,os,re,subprocess as sp,tarfile,tempfile
from collections import Counter
from pathlib import Path
here=Path(__file__).resolve().parent;pkg=Path.cwd();out=Path(os.environ['RESULTS']);out.mkdir(parents=True,exist_ok=True)
front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']);spec=(ref/'compat.txt').read_text().splitlines()[0]
def src(archive,name):
    with tarfile.open(pkg/'perf/ivy_apple/holdouts'/archive) as t:return t.extractfile('study/'+name).read()
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp)
 for eng in ('g3','z3'):
    native=eng=='z3'
    bridge=src('nov27-unary-demand-and-fresh-symbols.tar.xz','sources/native-z3bridge_solver_model.go.txt') if native else src('nov27-terminal-conflict-replay.tar.xz','stage-bridge.go.txt')
    guard=src('nov27-unary-demand-and-fresh-symbols.tar.xz','sources/native-z3bridge_guarded_equalities.go.txt') if native else src('nov27-terminal-conflict-replay.tar.xz','guards.go.txt')
    mp={};needle=b'stopCheck:=startStage(';assert bridge.count(needle)==1
    for name,code in [('z3bridge_solver_model.go',bridge.replace(needle,b'stopCheck:=startMappedCheck(')),('z3bridge_guarded_equalities.go',guard),('phase_observer_trial.go',(here/'profile.go.txt').read_bytes())]:
        tmp=d/(eng+name);tmp.write_bytes(code);mp[str(front/name)]=str(tmp)
    j=d/'ov.json';j.write_text(json.dumps({'Replace':mp}))
    sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','classic_z3,xtrace_off' if native else 'xtrace_off','-pgo='+('off' if native else str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-overlay',j,'-o',d/eng,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=os.environ.get('TRIAL_CACHE',str(d/'cache'))),check=True)
 ctl=d/'ctl';ack=d/'ack';os.mkfifo(ctl);os.mkfifo(ack)
 perf=os.environ.get('PERF','perf')
 with (out/'stacks.csv').open('w') as f:
    wr=csv.writer(f);wr.writerow(['case','batch','goal','engine','round','period','samples','stack'])
    for i in range(3):
        for eng in (['g3','z3'] if i%2==0 else ['z3','g3']):
          for case,batch,goal in [(4,6,4),(4,6,5),(4,6,6),(8,12,8),(8,16,1),(8,14,8),(8,13,8)]:
            spec=(ref/'compat.txt').read_text().splitlines()[case-1]
            code=next(int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open()) if r['case']==spec)
            period=1500007+i*200;data=d/'record'
            env=dict(os.environ,TARGET_GOAL=f'{batch}/{goal}',DEBUGINFOD_URLS='',GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),PROFILE_CTL=str(ctl),PROFILE_ACK=str(ack))
            cmd=['taskset','-c',os.environ['CPU'],perf,'record','-q','-D','-1','--control',f'fifo:{ctl},{ack}','-e','instructions:u','-c',str(period),'--call-graph','fp,64' if eng=='g3' else 'dwarf,8192','-o',data,'--',d/eng,ex/spec]
            r=sp.run(cmd,cwd=d,env=env,capture_output=True,timeout=120)
            ordinary=[];tids=[]
            for l in r.stderr.splitlines(keepends=True):
                if l.startswith(b'PROFILE_TID '):tids.append(l.split()[1])
                elif l.strip() not in (b'Events enabled',b'Events disabled'):ordinary.append(l)
            gold=ref/'compat'/str(case)/'1/native'
            if (r.returncode,r.stdout,b''.join(ordinary))!=(code,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()):(out/'failed.log').write_bytes(r.stderr);raise ValueError((r.returncode,r.stderr[:1200]))
            assert len(tids)==1
            stats=sp.check_output([perf,'report','--stdio','--stats','-i',data],env=env,text=True)
            assert not re.search(r'(LOST|THROTTLE) events:',stats),stats[-1800:]
            output=sp.check_output([perf,'script','--ns','-F','tid,time,event,ip,sym','-i',data],env=env,text=True)
            measured=Counter()
            for sample in output.strip().split('\n\n'):
                lines=sample.splitlines()
                if lines and lines[0].strip().split()[0]==tids[0].decode():
                    syms=tuple(re.sub(r'^\s*[0-9a-f]+\s+','',l).strip() for l in lines[1:] if l.strip());measured[syms]+=1
            assert sum(measured.values())>12,(eng,len(measured),output[:200])
            for stack,n in measured.items():wr.writerow([case,batch,goal,eng,i,period,n,'\n'.join(stack)])
            f.flush();data.unlink()
