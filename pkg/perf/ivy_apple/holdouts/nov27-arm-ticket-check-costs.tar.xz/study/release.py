"""Validate the optimized verifier and measure ordinary-GC complete workloads."""
import os, tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-matched-watch-installation.tar.xz') as t:
    name=os.environ['STUDY']
    s=t.extractfile('g3-matched-install/'+('apple.py' if name=='apple' else 'final.py')).read().decode()
    if name=='apple':
        s=s.replace("('smt_relevancy.go','smt_relevancy_asserted_or.go')","('smt_mam_impl.go','smt_relevance_case_split_queue.go','smt_theory_propagation.go')")
    else:
        s=s.replace('"\'smt_relevancy.go\',\'smt_relevancy_asserted_or.go\'"','"\'smt_mam_impl.go\',\'smt_relevance_case_split_queue.go\',\'smt_theory_propagation.go\'"')
    s=s.replace('dc5d2d13e:pkg','3157f735a:pkg')
exec(compile(s,'release','exec'))
