"""Compare home-bucket and probed-slot erasure, preserving rotated-key semantics."""
from pathlib import Path
import subprocess as sp
d=Path(__file__).resolve().parent
s=(d/'table-trials.py').read_text()
lo=s.index('def variant(');hi=s.index('with tempfile.TemporaryDirectory() as tmp:',lo)
s=s[:lo]+'''def variant(name):
    path=pkg/'smtcore/smt_cg_small_table.go'
    tab=pkg/'smtcore/smt_cg_table.go'
    a,b=[sp.check_output(['git','show','3157f735a:pkg/smtcore/'+p.name]).decode() for p in (path,tab)]
    if name=='home':
        anchor='erased, err := bucket.small.eraseCongruent(key, node)'
        before="""if bucket.small.count != 0 && (!node.commutative || len(node.arguments)==2) {
            home:=smtCgSmallSlot(key[0],key[1],bucket.small.shift)
            entry:=&bucket.small.entries[home]
            if entry.node==node && entry.k0==key[0] && entry.k1==key[1] {
                bucket.small.deleteSlot(home)
                return true,nil
            }
        }
        """
        b=b.replace(anchor,before+anchor)
    if name=='ordered':
        a=a.replace('query *SMTEnode) (bool, error)', 'query *SMTEnode, ordered bool) (bool, error)')
        anchor='if node != query || (node.commutative && len(node.arguments) != 2) {'
        a=a.replace(anchor,"""if ordered && node==query && (!node.commutative || len(node.arguments)==2) {
            t.deleteSlot(i)
            return true,nil
        }
        """+anchor)
        b=b.replace('small.eraseCongruent(key, node)','small.eraseCongruent(key, node, true)').replace('small.eraseCongruent([2]*SMTEnode{key[1], key[0]}, node)','small.eraseCongruent([2]*SMTEnode{key[1], key[0]}, node, false)')
    return [(path,a),(tab,b)]
'''+s[hi:]
s=s.replace("['base','slot','mix','cached']","['base','home','ordered']").replace('p,s=variant(mode);put(p,s)','for p,src in variant(mode):put(p,src)').replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'tables.csv'","'erase.csv'")
exec(compile(s,'erase','exec'))
