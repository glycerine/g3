from pathlib import Path
s=Path(__file__).with_name('release.py').read_text()
s=s.replace("'smt_mam_impl.go','smt_relevance_case_split_queue.go','smt_theory_propagation.go'","'smt_cg_table.go',").replace("\\'smt_mam_impl.go\\',\\'smt_relevance_case_split_queue.go\\',\\'smt_theory_propagation.go\\'","\\'smt_cg_table.go\\',").replace('3157f735a:pkg','b79866e51:pkg')
exec(compile(s,'panel','exec'))
