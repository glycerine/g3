import csv,statistics as st,collections
from pathlib import Path
d=Path(__file__).resolve().parent
for name in ['tables','notification','erase','admission']:
    p=d/(name+'.csv')
    if not p.exists():continue
    c=collections.Counter()
    for x in csv.DictReader(p.open()):c[x['case'],x['mode'],x['round']]+=int(x['instructions'])
    for case,mode in sorted({(k,m) for k,m,i in c}):
        vals=[v/1e6 for (k,m,i),v in c.items() if (k,m)==(case,mode)]
        print(name,case,mode,len(vals),round(st.median(vals),2))
for p in sorted(d.glob('*/time-*.csv')):
    a=collections.defaultdict(dict)
    for r in csv.DictReader(p.open()):a[r['round']][r['engine']]=r
    vals=[100*(int(v['trial']['instructions'])/int(v['base']['instructions'])-1) for v in a.values() if len(v)==2]
    if vals:print(p.stem,len(vals),round(st.median(vals),2))
