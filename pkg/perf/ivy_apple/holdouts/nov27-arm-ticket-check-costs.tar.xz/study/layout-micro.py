import os,json,subprocess as sp,tempfile
from compact import layout
from pathlib import Path
d=Path(__file__).resolve().parent;pkg=Path.cwd()
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    for mode in ('base','compact','inline'):
        src=tmp/(mode+'.go');src.write_text(layout(mode))
        ov=tmp/'overlay.json'
        ov.write_text(json.dumps({'Replace':{str(pkg/'smtcore/smt_mam_code.go'):str(src),str(pkg/'smtcore/smt_mam_instruction_benchmark_test.go'):str(d/'instructions_test.go.txt')}}))
        sp.run(['go','test','-c','-overlay',ov,'-o',tmp/mode,'./smtcore'],check=True)
    with (d/'layout.bench').open('w') as f:
        modes=['base','compact','inline']
        for i in range(6):
            for mode in modes[i%3:]+modes[:i%3]:
                print('layout:',mode,file=f,flush=True)
                sp.run(['taskset','-c',os.environ['CPU'],tmp/mode,'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTMAMInstructionStorage$','-test.benchtime=100000x'],check=True,stdout=f)
