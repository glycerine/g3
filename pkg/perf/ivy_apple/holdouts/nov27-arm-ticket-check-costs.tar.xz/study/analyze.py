"""Aggregate disjoint phases within runs before taking medians in millions."""
from pathlib import Path
from collections import defaultdict
import csv,statistics as st
d=Path(__file__).resolve().parent
r=list(csv.DictReader((d/'phases.csv').open()))
with (d/'summary.csv').open('w') as f:
    w=csv.writer(f);w.writerow('case batch goal engine whole_M check_M subst_M rewrite_M install_M other_M candidates installs'.split())
    for case,batch,goal in sorted({tuple(map(int,(x['case'],x['batch'],x['goal']))) for x in r}):
        for eng in ['release','native']:
            vals=[]
            for i in range(3):
                ops=defaultdict(int);calls=defaultdict(int)
                for x in r:
                    if (x['case'],x['batch'],x['goal'],x['round'],x['engine'])!=tuple(map(str,[case,batch,goal,i,eng])):continue
                    op=x['phase']
                    if int(x['observed']) != int(op!='whole'):continue
                    ops[op]+=int(x['instructions']);calls[op]+=int(x['calls'])
                if not calls['whole']:continue
                vals.append([ops[o]/1e6 for o in ('whole','C','S','R','A')]+[(ops['whole']-sum(ops[o] for o in ('C','S','R','A')))/1e6,calls['C'],calls['A']])
            if vals:w.writerow([case,batch,goal,eng,*[round(st.median(col),2) for col in zip(*vals)]])
