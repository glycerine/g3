"""Inclusive samples, so nested rows must be read independently."""
from pathlib import Path
import csv,collections,statistics as st
d=Path(__file__).resolve().parent
rows=list(csv.DictReader((d/'stacks.csv').open()))
cats={
'Equality merge':('SMTInternalizerState).addEquality','smt::context::add_eq('),
'Congruence erasure':('SMTCongruenceTable).Erase','smt::cg_table::erase('),
'Congruence insertion':('SMTCongruenceTable).Insert','smt::cg_table::insert('),
'Relevance notification':('SMTInternalizerState).notifyRelevant','smt::context::relevant_eh('),
'Watch relevance propagation':('SMTRelevancyPropagator).propagateWithOr','smt::relevancy_propagator_imp::propagate()'),
'Matcher interpreter':('smtMAMInterpreter).execute','smt::interpreter::execute_core'),
'Backjump resolution':('SMTKernel).resolveSearchConflict','smt::context::resolve_conflict()'),
'All samples':('','')}
with (d/'sample-summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow('case category g3_M z3_M'.split())
 for case in ['4','8']:
    for op,patterns in cats.items():
        v=[]
        for eng,pattern in zip(('g3','z3'),patterns):
            runs=[sum(int(r['period'])*int(r['samples']) for r in rows if r['case']==case and r['round']==str(i) and r['engine']==eng and pattern in r['stack']) for i in range(3)]
            v.append(round(st.mean(runs)/1e6,1))
        w.writerow([case,op,*v])
