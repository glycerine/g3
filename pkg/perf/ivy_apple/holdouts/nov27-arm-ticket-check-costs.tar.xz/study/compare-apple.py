from pathlib import Path
src=Path(__file__).with_name('compare-panel.py').read_text()
src=src[:src.index("exec(compile")]
exec(compile(src,'compare-panel-source','exec'))
s=s.replace("apple=name=='apple'","apple=True").replace("apple=mode=='apple'","apple=True")
s=s.replace("((1,3),(4,8),(6,227))","(('rfn2',),('dramc_nb2',))").replace('range(5)','range(3)')
if os.environ.get('ONLY_RFN2'):
    s=s.replace("(('rfn2',),('dramc_nb2',))","(('rfn2',),)").replace('for i in range(3):','for i in range(9):')
exec(compile(s,'compare-apple','exec'))
