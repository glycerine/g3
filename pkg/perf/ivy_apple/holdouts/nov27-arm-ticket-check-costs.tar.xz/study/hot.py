from pathlib import Path
import csv,collections,sys
d=Path(__file__).resolve().parent
s=collections.defaultdict(collections.Counter);rounds=collections.defaultdict(set)
for r in csv.DictReader((d/'stacks.csv').open()):
    k=r['case'],r['engine'];op=r['stack'].splitlines()
    if not op:continue
    rounds[k].add(r['round'])
    weight=int(r['samples'])*int(r['period'])
    # Bucket by immediate callee of the selected parent in the captured stack.
    by=sys.argv[1] if len(sys.argv)>1 else 'bounded'
    i=next((i for i,f in enumerate(op) if by.lower() in f.lower()),None)
    if i is None:continue
    s[k][op[max(0,i-1)]]+=weight
for k,v in sorted(s.items()):
    print(k,[(n.split('/pkg/')[-1][:105],round(i/len(rounds[k])/1e6,1)) for n,i in v.most_common(12)])
