from pathlib import Path
from compact import layout
p=Path(__file__).resolve().parent/'gc.py'
s=p.read_text()
s=s[:s.rindex("exec(compile(s,")]
exec(compile(s,'build-gc-driver','exec'))
a=s.index("    for mode in ['release']:");b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['base','compact','inline']
    for mode in modes:
        put(pkg/'smtcore/smt_mam_code.go',layout(mode))
        for name in ('smt_cg_table.go','smt_cg_small_table.go'):
            put(pkg/'smtcore'/name,sp.check_output(['git','show','b79866e51:pkg/smtcore/'+name]).decode())
"""+s[b:]
s=s.replace("modes=[(\"100\",\"0\"),(\"off\",\"1\"),(\"off\",\"0\"),(\"100\",\"1\")]","gc,track='100','1'").replace('range(4)','range(6)').replace('for gc,track in modes[i:]+modes[:i]:','for mode in modes[i%3:]+modes[:i%3]:').replace("d/'release',ex/spec","d/mode,ex/spec").replace('case gc track batch','case mode track batch').replace('i,case,gc,track','i,case,mode,track').replace("'gc.csv'","'layout-heap.csv'")
exec(compile(s,'layout-heap','exec'))
