from pathlib import Path
import csv,collections
d=Path(__file__).resolve().parent
data=collections.defaultdict(lambda:collections.Counter())
for r in csv.DictReader((d/'alloc.csv').open()):
    loc=next((f for f in r['stack'].split('|') if '/pkg/' in f),r['stack'].split('|')[0])
    loc=loc.split('/pkg/')[-1]
    for g in [loc,'ALL']:
        c=data[r['case'],g];c['bytes']+=int(r['bytes']);c['objects']+=int(r['objects'])
with (d/'alloc-summary.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['case','site','bytes','objects'])
    for (k,g),v in sorted(data.items(),key=lambda t:-t[1]['bytes']):
        w.writerow([k,g,v['bytes'],v['objects']])
for case in ('4','8'):
    print(case,sorted([(v['bytes'],v['objects'],g) for (k,g),v in data.items() if k==case],reverse=True)[:12])
