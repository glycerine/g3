"""Compare small-arity congruence-table representations in the seven complete-verifier checks."""
from pathlib import Path
import csv,json,os,subprocess as sp,tarfile,tempfile
pkg=Path.cwd();here=Path(__file__).resolve().parent
front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']);names=(ref/'compat.txt').read_text().splitlines()
codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
def member(archive,name):
    with tarfile.open(pkg/'perf/ivy_apple/holdouts'/archive) as t:return t.extractfile(name).read().decode()
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp);mp={}
    def put(p,s):
        f=d/p.name;f.write_text(s);mp[str(p)]=str(f)
    bridge=member('nov27-terminal-conflict-replay.tar.xz','study/stage-bridge.go.txt').replace('stopCheck:=startStage(batch,index+1);','capturePush=(batch==6 && index>=3 && index<=5)||(batch==12 && index==7)||(batch==16 && index==0)||((batch==13||batch==14)&&index==7);stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");capturePush=false')
    put(front/'z3bridge_solver_model.go',bridge)
    put(front/'z3bridge_guarded_equalities.go',member('nov27-terminal-conflict-replay.tar.xz','study/guards.go.txt'))
    put(front/'phase_observer_trial.go',member('nov27-first-push-queue-comparison.tar.xz','check-g3-phase_observer_trial.go').replace('runtime.LockOSThread()','if !capturePush{return func(string){}};runtime.LockOSThread()'))
    modes=['base','mam','header','both']
    for mode in modes:
        for name in ('smt_mam_impl.go','smt_relevance_case_split_queue.go','smt_theory_propagation.go'):
            p=pkg/'smtcore'/name
            include=mode=='both' or (mode=='mam' and name=='smt_mam_impl.go') or (mode=='header' and name!='smt_mam_impl.go')
            put(p,p.read_text() if include else sp.check_output(['git','show','3157f735a:pkg/smtcore/'+name]).decode())
        j=d/'overlay.json';j.write_text(json.dumps({'Replace':mp}))
        sp.run(['go','build','-tags','xtrace_off','-buildvcs=false','-mod=readonly','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',d/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=os.environ['TRIAL_CACHE']),check=True)
    with (here/'notification.csv').open('w') as f:
        w=csv.writer(f);w.writerow('round case mode batch goal instructions'.split())
        for i in range(4):
            for mode in modes[i:]+modes[:i]:
                for case,targets in [(4,{(6,4),(6,5),(6,6)}),(8,{(12,8),(16,1),(14,8),(13,8)})]:
                    spec=names[case-1];gold=ref/'compat'/str(case)/'1/native'
                    r=sp.run(['taskset','-c',os.environ['CPU'],d/mode,ex/spec],cwd=d,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),timeout=180)
                    clean=[];cost={}
                    for l in r.stderr.splitlines(keepends=True):
                        a=l.split()
                        if l.startswith(b'OPEN '):continue
                        if l.startswith(b'STAGE-COUNT '):
                            k=tuple(map(int,a[1:3]))
                            if k in targets:
                                assert a[6]==a[7] and a[3]==b'check' and k not in cost
                                cost[k]=int(a[4])
                        else:clean.append(l)
                    assert set(cost)==targets and (r.returncode,r.stdout,b''.join(clean))==(codes[spec],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes())
                    for k,v in cost.items():w.writerow([i,case,mode,*k,v])
                    f.flush()
