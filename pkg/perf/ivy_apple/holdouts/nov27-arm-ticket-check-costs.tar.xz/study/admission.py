"""Price the maximum benefit of omitting case-split admission on a fixed non-relevance strategy."""
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'notify-trials.py').read_text().replace("modes=['base','mam','header','both']","modes=['base','skip']").replace("include=mode=='both' or (mode=='mam' and name=='smt_mam_impl.go') or (mode=='header' and name!='smt_mam_impl.go')","""include=True""").replace("put(p,p.read_text() if include else sp.check_output(['git','show','3157f735a:pkg/smtcore/'+name]).decode())","""src=p.read_text()
            if mode=='skip' and name=='smt_theory_propagation.go':
                anchor='if boolean {\\n\\t\\tif err := s.admitRelevanceCaseSplit'
                assert src.count(anchor)==1
                src=src.replace(anchor, 'if boolean && s.caseSplitStrategy >= 3 && s.caseSplitStrategy <= 5 {\\n\\t\\tif err := s.admitRelevanceCaseSplit')
            put(p,src)""").replace('modes[i:]+modes[:i]','modes[::1 if i%2==0 else -1]').replace("'notification.csv'","'admission.csv'")
exec(compile(s,'admission','exec'))
