from pathlib import Path
import csv,statistics
from collections import defaultdict,Counter
w=Path(__file__).resolve().parent
def key(r):return (int(r['batch']),int(r['goal']),r['phase'])
tables={}
for m in ['g3','native']:
 rows=list(csv.DictReader((w/(m+'.csv')).open()));fields=list(rows[0])[4:]
 # Within each phase aggregate repeated sequential intervals. Record all phases.
 d=defaultdict(Counter)
 for r in rows:
  if r['round']=='0':d[key(r)].update({k:int(r[k]) for k in fields})
 tables[m]=d
cost=defaultdict(Counter)
for r in csv.DictReader((w/'prices.csv').open()):cost[r['engine'],key(r)][r['round']]+=int(r['instructions'])
groups=defaultdict(lambda:[0,0,0]);out=[]
for k in sorted(tables['g3'].keys()|tables['native'].keys()):
 if k[-1]!='check':continue
 x,y=[tables[m].get(k) for m in ['g3','native']]
 category='native-only' if x is None else 'g3-only' if y is None else 'different' if x!=y else 'matched' if any(x.values()) else 'zero'
 vals=[statistics.median(cost[m,k].values()) if cost[m,k] else 0 for m in ['g3','native']]
 out.append([*k,category,*vals,vals[0]-vals[1],*[t[f] if t else 0 for t in (x,y) for f in fields]])
 g=groups[category];g[0]+=1;g[1]+=vals[0];g[2]+=vals[1]
with (w/'checks.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['batch','goal','phase','category','g3','native','gap',*['%s_%s'%(m,f) for m in tables for f in fields]]);o.writerows(sorted(out,key=lambda row:-row[6]))
print(groups)
for row in sorted(out,key=lambda row:-row[6])[:10]:print(row[:7])
