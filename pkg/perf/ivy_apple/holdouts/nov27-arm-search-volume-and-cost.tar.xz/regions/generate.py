from pathlib import Path
import sys
w=Path(__file__).resolve().parent;s=(w.parent/'events.py').read_text()
s=s[:s.index("names=[")]+"names=['detach','reinsert','undo','empty','detach_calls','reinsert_calls','undo_calls','empty_calls','unused']\n"+s[s.index('def overlay'):]
a=s.index(' src={');b=s.index('\nelse:',a)
s=s[:a]+''' f=p/'smtcore/smt_equality_propagation.go';t=f.read_text()
 for i,method in enumerate(['detachCongruenceParents','reinsertCongruenceParents','undoEquality']):
  a=t.index('func (s *SMTInternalizerState) '+method+'(');b=t.index('{',a)+1;t=t[:b]+'studyEnd(3, freshRead());defer studyEnd('+str(i)+',freshRead());'+t[b:]
 overlay(f,t)
 helper=(w/'read.go.txt').read_text()
 overlay(p/'smtcore/study_event_counts.go',helper)
'''+s[b:]
a=s.index(' for i,k in enumerate');b=s.index(" q=w/'smt_context.cpp'",a)
s=s[:a]+''' helper+=(w/'read.cpp.txt').read_text()
 for i,method in enumerate(['remove_parents_from_cg_table','reinsert_parents_into_cg_table','undo_add_eq']):
  a=s.index('void context::'+method+'(');b=s.index('{',a)+1;s=s[:b]+'endStudy(3,freshRead());studyMeter meter('+str(i)+');'+s[b:]
'''+s[b:]
s=s.replace("assert rows and (previous==None or previous==rows);previous=rows","assert rows and (previous==None or [r[:3]+r[7:] for r in previous]==[r[:3]+r[7:] for r in rows]);previous=rows")
h=Path('/tmp/g3-or-install/fresh.go.txt').read_text();h='package smtcore\nimport("syscall";"unsafe";"runtime")\nvar freshFD uintptr\nvar StudyEventCounts [9]uint64\n'+h[h.index('func freshRead'):h.index('func freshAdd')]+'func studyEnd(i int,t uint64){t1:=freshRead();StudyEventCounts[i]+=t1-t;StudyEventCounts[i+4]++}\n'
(w/'read.go.txt').write_text(h)
h=Path('/tmp/g3-arm-history/native.py').read_text();h=h[h.index('#include <linux/perf_event.h>'):h.index('static void freshAdd')]+'''static void endStudy(int i,unsigned long long t){auto t1=freshRead();auto p=studyBuffer();p[i]+=t1-t;p[i+4]++;}
struct studyMeter{unsigned i;unsigned long long t;studyMeter(unsigned i):i(i),t(freshRead()){}~studyMeter(){endStudy(i,t);}};\n'''
(w/'read.cpp.txt').write_text(h);(w/'run.py').write_text(s)
