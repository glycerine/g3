from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_cg_small_table.go';s=f.read_text().replace('shift   uint8','deleted uint32\n shift   uint8').replace('type smtCgSmallEntry struct','var deletedCgEntry SMTEnode\n\ntype smtCgSmallEntry struct')
a=s.index('// set is');b=s.index('// slot finds',a);t=s[a:b].replace('mask :=','if int(t.deleted)+t.count+1 >= len(t.entries){t.rebuild(len(t.entries))}\n hole:=-1\n mask :=')
t=t.replace('*e = smtCgSmallEntry{k0, k1, node}','if hole>=0{e=&t.entries[hole];t.deleted--};*e = smtCgSmallEntry{k0, k1, node}').replace('if e.k0 == k0', 'if e.node==&deletedCgEntry && hole<0{hole=i};if e.k0 == k0')
s=s[:a]+t+s[b:];a=s.index('mask :=',s.index('func (t *smtCgSmallTable) deleteSlot'));b=s.index('\n}',a);s=s[:a]+'''t.count--
 if t.entries[(i+1)&(len(t.entries)-1)].node==nil{
   t.entries[i]=smtCgSmallEntry{}
 }else{
   t.entries[i]=smtCgSmallEntry{node:&deletedCgEntry}
   t.deleted++
 }'''+s[b:]
s=s.replace('old := t.entries\n\tsize := 8','size := 8').replace('len(old)','len(t.entries)').replace('shift := uint8(64)','t.rebuild(size)\n}\nfunc (t *smtCgSmallTable) rebuild(size int){\n old:=t.entries;t.deleted=0\n shift := uint8(64)').replace('e.node != nil {','e.node != nil && e.node!=&deletedCgEntry {')
dst=w/'table.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().replace("Path('/tmp/g3-card-install/volume-release')","Path('/tmp/g3-or-install/final/release')").replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("],7,['base','release']", "],11,['base','release']").replace("run(12","run(8")
exec(compile(script,__file__,'exec'))
