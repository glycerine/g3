from pathlib import Path
w=Path(__file__).resolve().parent;base=w.parent/'regions'
s=(base/'run.py').read_text()
a=s.index(" f=p/'smtcore/smt_equality_propagation.go'");b=s.index(' helper=',a)
s=s[:a]+''' for file,methods in [('smt_search.go',[(0,'boundedSearch'),(2,'resolveSearchConflict')]),('smt_theory_propagation.go',[(1,'PropagateCore')])]:
  f=p/'smtcore'/file;t=f.read_text()
  for i,method in methods:
   a=t.index(') '+method+'(');b=t.index('{',a)+1;t=t[:b]+'studyEnd(3, freshRead());defer studyEnd('+str(i)+',freshRead());'+t[b:]
  overlay(f,t)
'''+s[b:]
s=s.replace("['remove_parents_from_cg_table','reinsert_parents_into_cg_table','undo_add_eq']","['bounded_search','propagate','resolve_conflict']").replace("'void context::'+method+'('","' context::'+method+'('")
s=s.replace("'detach'","'bounded'").replace("'reinsert'","'propagate'").replace("'undo'","'resolve'").replace('detach_calls','bounded_calls').replace('reinsert_calls','propagate_calls').replace('undo_calls','resolve_calls')
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt']:(w/n).write_text((base/n).read_text())
s=(base/'compare.py').read_text().replace("'detach','reinsert','undo'","'bounded','propagate','resolve'")
(w/'compare.py').write_text(s)
