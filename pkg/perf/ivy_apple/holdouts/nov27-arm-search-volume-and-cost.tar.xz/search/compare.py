from pathlib import Path
from collections import Counter
import csv,statistics
w=Path(__file__).resolve().parent
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','scope','region','calls','empty_per_call','net_M','net_per_call'])
 for m in ['g3','native']:
  data=list(csv.DictReader((w/(m+'.csv')).open()))
  for label,b,g in [('all',0,0),('6/5',6,5),('6/6',6,6)]:
   for field in ['bounded','propagate','resolve']:
    vals=[]
    for i in range(3):
     rows=[r for r in data if r['round']==str(i) and (not b or (r['batch']==str(b) and r['goal']==str(g) and r['phase']=='check'))]
     def total(key):return sum(int(r[key]) for r in rows)
     e=total('empty')/total('empty_calls');n=total(field+'_calls');net=total(field)-e*n
     vals.append([n,e,net/1e6,net/n])
    assert vals[0][0]==vals[-1][0];out.writerow([m,label,field,*[round(statistics.median(col),2) for col in zip(*vals)]])
