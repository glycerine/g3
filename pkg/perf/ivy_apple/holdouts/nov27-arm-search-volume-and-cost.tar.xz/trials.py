from pathlib import Path
import csv,statistics as S
w=Path(__file__).resolve().parent
for f in [w/'micro.csv',*w.glob('*/whole.csv')]:
 d={}
 for r in csv.DictReader(f.open()):
  assert r.get('status','match')=='match'
  d.setdefault(r.get('benchmark',r.get('case')),{}).setdefault(r['round'],{})[r['mode']]=int(r['instructions'])
 for name,vs in d.items():
  for m in sorted({m for r in vs.values() for m in r}-{'base'}):
   ratios=[100*(r[m]/r['base']-1) for r in vs.values() if 'base' in r and m in r]
   if ratios:print(f.parent.name,name,m,len(ratios),round(S.median(ratios),2))
