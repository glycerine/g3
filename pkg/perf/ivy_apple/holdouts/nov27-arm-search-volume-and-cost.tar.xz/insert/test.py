from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();rep={}
def save(f,s):
 dst=w/(f.name+'.txt');dst.write_text(s);rep[str(f)]=str(dst)
f=p/'smtcore/smt_cg_small_table.go';s=f.read_text()+'''
// insertPositional returns the existing representative or stores node at the
// first empty slot. Table growth invalidates the slot and requires a new probe.
func (t *smtCgSmallTable) insertPositional(node *SMTEnode) (SMTCongruenceInsertResult,error) {
 key:=smtCongruenceSmallKey(node)
 if len(t.entries)>0 {
 mask:=len(t.entries)-1
 for i:=smtCgSmallSlot(key[0],key[1],t.shift); ; i=(i+1)&mask {
  e:=&t.entries[i]
  if e.node==nil {
   if 2*(t.count+1)>len(t.entries){break}
   *e=smtCgSmallEntry{key[0],key[1],node};t.count++
   return SMTCongruenceInsertResult{Node:node},nil
  }
  if e.k0==key[0] && e.k1==key[1] {
   ok,comm,err:=SMTEnodesCongruent(e.node,node)
   if err!=nil{return SMTCongruenceInsertResult{},err}
   if ok{return SMTCongruenceInsertResult{Node:e.node,Commuted:comm},nil}
   e.node=node;return SMTCongruenceInsertResult{Node:node},nil
  }
 }
 }
 t.set(key[0],key[1],node)
 return SMTCongruenceInsertResult{Node:node},nil
}
''';save(f,s)
f=p/'smtcore/smt_cg_table.go';s=f.read_text();k='candidate, commuted, err := bucket.find(node)';assert s.count(k)==1;save(f,s.replace(k,'if !node.commutative && len(node.arguments)<=2{return bucket.small.insertPositional(node)};'+k))
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':rep}))
script=Path('/tmp/g3-arm-events/trial/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('run(12', 'run(18'))
