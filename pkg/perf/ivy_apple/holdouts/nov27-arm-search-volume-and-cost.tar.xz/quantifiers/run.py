"""Generate observational overlays for both engines. Run from pkg."""
from pathlib import Path
import csv,json,os,subprocess,sys,re,shlex,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();mode=sys.argv[1]
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(); prior=Path('/tmp/g3-ticket-stages')
ov=json.loads((prior/'translated.json').read_text())['Replace']
names=['match','notify','queue','empty','match_calls','notify_calls','queue_calls','empty_calls','unused']
def overlay(f,s):
 dst=w/(mode+'-'+f.name+('' if f.name=='quantifier.go' else '.txt'));dst.write_text(s);ov[str(f)]=str(dst)
def sub(s,k,z):
 assert s.count(k)==1,(k,s.count(k));return s.replace(k,z)
st=(prior/'stage.go.txt').read_text()
if mode=='g3':
 st=st.replace('import (','import (\n"github.com/glycerine/g3/pkg/smtcore"')
 expr='smtcore.StudyEventCounts'
 f=p/'smtcore/smt_quantifier_manager.go';t=f.read_text()
 a=t.index('func (q *SMTQuantifierManager) Propagate()');b=t.index('func (q *SMTQuantifierManager) active',a);r=t[a:b];r=r.replace('if err := q.mam.Match(); err != nil {','studyEnd(3,freshRead());start:=freshRead();err:=q.mam.Match();studyEnd(0,start);if err!=nil{').replace('q.notifyNewEnodes()','start=freshRead();q.notifyNewEnodes();studyEnd(1,start)').replace('return q.registry.schedule.instantiateNew','defer studyEnd(2,freshRead());return q.registry.schedule.instantiateNew');overlay(f,t[:a]+r+t[b:]);overlay(p/'smtcore/smt_cg_small_table.go',subprocess.check_output(['git','show','4808f7da6:pkg/smtcore/smt_cg_small_table.go'],text=True))
 helper=(w/'read.go.txt').read_text()
 overlay(p/'smtcore/study_event_counts.go',helper)

else:
 expr='studyRead()'
 st+='''
func studyRead() (v [9]uint64) {
 b,e:=os.ReadFile(os.Getenv("ARM_EVENT_FILE"));if e!=nil{panic(e)}
 for i:=range v {v[i]=binary.LittleEndian.Uint64(b[8*i:])};return
}
'''
 st=st.replace('import (','import (\n"encoding/binary"')
 b=p.parent/'build';src=p.parent/'src/smt';s=(src/'smt_quantifier.cpp').read_text()
 helper='''
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdlib>
static unsigned long long* studyBuffer(){
 static auto p=[](){int fd=open(getenv("ARM_EVENT_FILE"),O_RDWR);if(fd<0)abort();
 void* ptr=mmap(nullptr,4096,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);if(ptr==MAP_FAILED)abort();close(fd);
 return static_cast<unsigned long long*>(ptr);}();return p;
}
'''
 helper+=(w/'read.cpp.txt').read_text()
 k='m_plugin->propagate();\n            m_qi_queue.instantiate();';s=sub(s,k,'m_plugin->propagate();{studyMeter meter(2);m_qi_queue.instantiate();}')
 k='void propagate() override {\n            m_mam->match();';s=sub(s,k,k.split('m_mam->match();')[0]+'endStudy(3,freshRead());{studyMeter meter(0);m_mam->match();}studyMeter meter(1);')
 b=p.parent/'build';q=w/'smt_quantifier.cpp';q.write_text(helper+s);mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l)
 subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),'-I'+str(src),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',w/'smt_quantifier.o',q],cwd=b,check=True)
 lib=w/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,w/'smt_quantifier.o'],check=True)
 f=front/'smt/quantifier.go';overlay(f,sub(f.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
st=sub(st,'runtime.LockOSThread()','before:='+expr+';runtime.LockOSThread()')
st=sub(st,'runtime.UnlockOSThread()','runtime.UnlockOSThread();after:='+expr+';fmt.Fprintf(os.Stderr,"EVENT %d %d %s",batch,goal,phase);for i:=range after{fmt.Fprintf(os.Stderr," %d",after[i]-before[i])};fmt.Fprintln(os.Stderr)')
overlay(front/'phase_observer_trial.go',st)
ovpath=w/(mode+'.json');ovpath.write_text(json.dumps({'Replace':ov}));exe=w/mode
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off'+(',classic_z3' if mode=='native' else ''),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',ovpath,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');case='test/arm_rules3.ivy';ref=rank/'compat'/str((rank/'compat.txt').read_text().splitlines().index(case)+1)/'1/native'
with (w/(mode+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow(['round','batch','goal','phase',*names]);previous=None
 for i in range(3):
  mem=w/(mode+'.map');mem.write_bytes(bytes(4096))
  r=subprocess.run(['taskset','-c','14' if mode=='native' else '12',exe,ex/case],cwd=w,env=dict(os.environ,ARM_EVENT_FILE=str(mem),GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
  raw=[];rows=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'EVENT '):rows.append(l.decode().split()[1:])
   elif not l.startswith(b'STAGE-COUNT '):raw.append(l)
  assert (r.returncode,r.stdout,b''.join(raw))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(r.returncode,r.stderr[-1200:])
  assert rows and (previous==None or [r[:3]+r[7:] for r in previous]==[r[:3]+r[7:] for r in rows]);previous=rows
  out.writerows([[i,*row] for row in rows]);f.flush()
