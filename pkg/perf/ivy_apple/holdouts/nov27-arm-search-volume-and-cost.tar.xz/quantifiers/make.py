from pathlib import Path
w=Path(__file__).resolve().parent;base=w.parent/'regions';s=(base/'run.py').read_text();a=s.index(" f=p/'smtcore/smt_equality_propagation.go'");b=s.index(' helper=',a)
s=s[:a]+''' f=p/'smtcore/smt_quantifier_manager.go';t=f.read_text()
 a=t.index('func (q *SMTQuantifierManager) Propagate()');b=t.index('func (q *SMTQuantifierManager) active',a);r=t[a:b];r=r.replace('if err := q.mam.Match(); err != nil {','studyEnd(3,freshRead());start:=freshRead();err:=q.mam.Match();studyEnd(0,start);if err!=nil{').replace('q.notifyNewEnodes()','start=freshRead();q.notifyNewEnodes();studyEnd(1,start)').replace('return q.registry.schedule.instantiateNew','defer studyEnd(2,freshRead());return q.registry.schedule.instantiateNew');overlay(f,t[:a]+r+t[b:]);overlay(p/'smtcore/smt_cg_small_table.go',subprocess.check_output(['git','show','4808f7da6:pkg/smtcore/smt_cg_small_table.go'],text=True))
'''+s[b:]
s=s.replace('smt_context.cpp','smt_quantifier.cpp').replace('smt_context.o','smt_quantifier.o')
a=s.index(' for i,method in enumerate(');b=s.index(" b=p.parent/'build';q=",a)
s=s[:a]+''' k='m_plugin->propagate();\\n            m_qi_queue.instantiate();';s=sub(s,k,'m_plugin->propagate();{studyMeter meter(2);m_qi_queue.instantiate();}')
 k='void propagate() override {\\n            m_mam->match();';s=sub(s,k,k.split('m_mam->match();')[0]+'endStudy(3,freshRead());{studyMeter meter(0);m_mam->match();}studyMeter meter(1);')
'''+s[b:]
a=s.index('names=[');b=s.index('\ndef overlay',a);s=s[:a]+s[a:b].replace('detach','match').replace('reinsert','notify').replace('undo','queue')+s[b:]
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt']:(w/n).write_text((base/n).read_text())
(w/'compare.py').write_text((base/'compare.py').read_text().replace("'detach','reinsert','undo'","'match','notify','queue'"))
