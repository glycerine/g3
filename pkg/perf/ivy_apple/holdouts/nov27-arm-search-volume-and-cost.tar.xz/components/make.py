from pathlib import Path
w=Path(__file__).resolve().parent;base=w.parent/'search';s=(base/'run.py').read_text().replace("[('smt_search.go',[(0,'boundedSearch'),(2,'resolveSearchConflict')]),('smt_theory_propagation.go',[(1,'PropagateCore')])]","[('smt_boolean_propagation.go',[(0,'Propagate')]),('smt_theory_propagation.go',[(1,'PropagateTheoryAssignments')]),('smt_quantifier_manager.go',[(2,'Propagate')])]")
a=s.index(' for i,method in enumerate(');b=s.index(" b=p.parent/'build';q=",a)
s=s[:a]+''' a=s.index('bool context::propagate()');b=s.index('void context::set_conflict',a);seg=s[a:b]
 for i,(start,end) in enumerate([('if (!bcp())','if (!propagate_th_case_split'),('if (!propagate_atoms())','propagate_th_eqs();'),('m_qmanager->propagate();','if (inconsistent())')]):
  pos=seg.index(start);e=seg.index(end,pos);seg=seg[:pos]+'{endStudy(3,freshRead());studyMeter meter('+str(i)+');'+seg[pos:e]+'}'+seg[e:]
 s=s[:a]+seg+s[b:]
'''+s[b:]
for old,new in [('bounded','bcp'),('propagate','atoms_eq'),('resolve','quantifiers')]:
 a=s.index('names=[');b=s.index('\ndef overlay',a);s=s[:a]+s[a:b].replace(old,new)+s[b:]
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt']:(w/n).write_text((base/n).read_text())
s=(base/'compare.py').read_text().replace("'bounded','propagate','resolve'","'bcp','atoms_eq','quantifiers'")
(w/'compare.py').write_text(s)
