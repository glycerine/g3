from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'smtcore/smt_cg_small_table.go';s=f.read_text()
k='node := t.entries[i].node\n\tequal, _, err'
assert s.count(k)==1
s=s.replace(k,'''node := t.entries[i].node
	if node == query && (!query.commutative || len(query.arguments)==2) && (len(query.arguments)!=2 || key[0]==query.arguments[0].root) {
		t.deleteSlot(i)
		return true,nil
	}
	equal, _, err''')
dst=w/'table.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().replace("Path('/tmp/g3-card-install/volume-release')","Path('/tmp/g3-or-install/final/release')").replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("],7,['base','release']", "],11,['base','release']")
exec(compile(script,__file__,'exec'))
