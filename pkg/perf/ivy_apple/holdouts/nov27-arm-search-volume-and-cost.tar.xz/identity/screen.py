from pathlib import Path
import concurrent.futures
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0]
s=s[:s.index('subprocess.run([*flags')]+s[s.index('modes={'):]
exec(s)
abc=w/'abc'
if not abc.exists():abc.symlink_to('/tmp/g3-frame-child/abc')
cpus=[0,2,4,6,8,10,12,14]
with concurrent.futures.ThreadPoolExecutor(len(cpus)) as pool:
 jobs=[pool.submit(run,cpu,'survey'+str(i),cases[i::len(cpus)],1,['release']) for i,cpu in enumerate(cpus)]
 for job in jobs:job.result()
