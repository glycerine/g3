from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_cg_small_table.go';s=f.read_text();a=s.index('equal, _, err := SMTEnodesCongruent(node, query)');b=s.index('// A merge',a)
s=s[:a]+'''// A representative is congruent to itself in either probe order.
	// Malformed commutative applications still go through the arity check.
	if node != query || (node.commutative && len(node.arguments) != 2) {
		equal, _, err := SMTEnodesCongruent(node, query)
		if err != nil || !equal {
			return false, err
		}
	}
	'''+s[b:]
dst=w/'table.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().replace("Path('/tmp/g3-card-install/volume-release')","Path('/tmp/g3-or-install/final/release')").replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("],7,['base','release']", "],13,['base','release']").replace("run(12","run(16")
exec(compile(script,__file__,'exec'))
