from pathlib import Path
import csv,os,statistics,subprocess
w=Path(__file__).resolve().parent;prior=Path('/tmp/g3-ticket-stages');p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ex=Path('/home/jaten/ivy/ivy-lang-examples');case='test/arm_rules3.ivy';rank=Path('/tmp/g3-reduction-rows');ref=rank/'compat'/str((rank/'compat.txt').read_text().splitlines().index(case)+1)/'1/native'
with (w/'prices.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','engine','batch','goal','phase','instructions'])
 for m in ['g3','native']:
  subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off'+(',classic_z3' if m=='native' else ''),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',prior/'translated.json','-o',w/('price-'+m),'./cmd/goivy_check'],cwd=front,check=True)
 for i in range(5):
  for m in ['native','g3'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','16',w/('price-'+m),ex/case],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=120)
   raw=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'STAGE-COUNT '):
     _,b,g,ph,n,empty,en,active,ns=l.decode().split();assert en==active and int(en)>0
     out.writerow([i,m,b,g,ph,n])
    else:raw.append(l)
   assert (r.returncode,r.stdout,b''.join(raw))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
