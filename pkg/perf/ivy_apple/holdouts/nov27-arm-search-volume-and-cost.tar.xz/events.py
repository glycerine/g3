"""Generate observational overlays for both engines. Run from pkg."""
from pathlib import Path
import csv,json,os,subprocess,sys,re,shlex,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();mode=sys.argv[1]
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(); prior=Path('/tmp/g3-ticket-stages')
ov=json.loads((prior/'translated.json').read_text())['Replace']
names=['atoms','pending_eq','add_eq','merges','parents','conflicts','undone_literals','undo_merge','cg_erase']
def overlay(f,s):
 dst=w/(mode+'-'+f.name+('' if f.name=='quantifier.go' else '.txt'));dst.write_text(s);ov[str(f)]=str(dst)
def sub(s,k,z):
 assert s.count(k)==1,(k,s.count(k));return s.replace(k,z)
st=(prior/'stage.go.txt').read_text()
if mode=='g3':
 st=st.replace('import (','import (\n"github.com/glycerine/g3/pkg/smtcore"')
 expr='smtcore.StudyEventCounts'
 src={
 'smt_theory_propagation.go':[('if err := s.propagateAssignedAtom(s.atomQueue[i]);',0)],
 'smt_equality_propagation.go':[('entry := s.pending[s.pendingHead]',1),('s.statistics.NumAddEq++',2),('if err := s.detachCongruenceParents(r1);',3),('if !parent.sourceParentMark && parent.congruence == parent && !parent.IsTrueEquality()',4),('if _, err := s.congruence.Erase(parent);',8)],
 'smt_search.go':[('func (k *SMTKernel) resolveSearchConflict(session *smtSearchSession) (bool, error) {',5)],
 'smt_internalizer_state.go':[('s.assignedLiterals = s.assignedLiterals[:scope.assignedLimit]',6)]}
 for file,edits in src.items():
  f=p/'smtcore'/file;s=f.read_text()
  for k,i in edits:
   if i==8:k='s.traceAddEqParents("remove_parents_from_cg_table"'+s.split('s.traceAddEqParents("remove_parents_from_cg_table"',1)[1].split('if _, err := s.congruence.Erase(parent);',1)[0]+k
   if i==8:s=sub(s,k,k.replace('if _, err','StudyEventCounts[8]++;if _, err'));continue
   z='StudyEventCounts[%d]++;'%i
   if i==6:z='StudyEventCounts[6]+=uint64(len(s.assignedLiterals)-scope.assignedLimit);'
   s=sub(s,k,k+z if i==5 else z+k)
  if file=='smt_equality_propagation.go':
   k='func (s *SMTInternalizerState) undoEquality(entry *smtEqualityUndo) error {';s=sub(s,k,k+'StudyEventCounts[7]++;')
  overlay(f,s)
 overlay(p/'smtcore/study_event_counts.go','package smtcore\nvar StudyEventCounts [9]uint64\n')
else:
 expr='studyRead()'
 st+='''
func studyRead() (v [9]uint64) {
 b,e:=os.ReadFile(os.Getenv("ARM_EVENT_FILE"));if e!=nil{panic(e)}
 for i:=range v {v[i]=binary.LittleEndian.Uint64(b[8*i:])};return
}
'''
 st=st.replace('import (','import (\n"encoding/binary"')
 b=p.parent/'build';src=p.parent/'src/smt';s=(src/'smt_context.cpp').read_text()
 helper='''
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdlib>
static unsigned long long* studyBuffer(){
 static auto p=[](){int fd=open(getenv("ARM_EVENT_FILE"),O_RDWR);if(fd<0)abort();
 void* ptr=mmap(nullptr,4096,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);if(ptr==MAP_FAILED)abort();close(fd);
 return static_cast<unsigned long long*>(ptr);}();return p;
}
'''
 for i,k in enumerate(['literal  l = m_atom_propagation_queue[i];','new_eq & entry = m_eq_propagation_queue[i];','m_stats.m_num_add_eq++;','remove_parents_from_cg_table(r1);','// Remove parents from the congruence table','bool context::resolve_conflict() {','m_assigned_literals.shrink(old_lim);','void context::undo_add_eq(','TRACE("add_eq_parents", tout << "add_eq removing:']):
  z='studyBuffer()['+str(i)+']++;'
  if i==4:z='studyBuffer()[4]+=r1->get_num_parents();'
  if i==6:z='studyBuffer()[6]+=m_assigned_literals.size()-old_lim;'
  if i==7:k=s[s.index(k):s.index('{',s.index(k))+1]
  if i==8:
   a=s.index(k);j=s.index('m_cg_table.erase(parent);',a);s=s[:j]+'{'+z+'m_cg_table.erase(parent);}'+s[j+len('m_cg_table.erase(parent);'):];continue
  s=sub(s,k,k+z if i in [5,7] else z+k)
 q=w/'smt_context.cpp';q.write_text(helper+s);mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l)
 subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),'-I'+str(src),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',w/'smt_context.o',q],cwd=b,check=True)
 lib=w/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,w/'smt_context.o'],check=True)
 f=front/'smt/quantifier.go';overlay(f,sub(f.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
st=sub(st,'runtime.LockOSThread()','before:='+expr+';runtime.LockOSThread()')
st=sub(st,'runtime.UnlockOSThread()','runtime.UnlockOSThread();after:='+expr+';fmt.Fprintf(os.Stderr,"EVENT %d %d %s",batch,goal,phase);for i:=range after{fmt.Fprintf(os.Stderr," %d",after[i]-before[i])};fmt.Fprintln(os.Stderr)')
overlay(front/'phase_observer_trial.go',st)
ovpath=w/(mode+'.json');ovpath.write_text(json.dumps({'Replace':ov}));exe=w/mode
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off'+(',classic_z3' if mode=='native' else ''),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',ovpath,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');case='test/arm_rules3.ivy';ref=rank/'compat'/str((rank/'compat.txt').read_text().splitlines().index(case)+1)/'1/native'
with (w/(mode+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow(['round','batch','goal','phase',*names]);previous=None
 for i in range(3):
  mem=w/(mode+'.map');mem.write_bytes(bytes(4096))
  r=subprocess.run(['taskset','-c','14' if mode=='native' else '12',exe,ex/case],cwd=w,env=dict(os.environ,ARM_EVENT_FILE=str(mem),GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
  raw=[];rows=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'EVENT '):rows.append(l.decode().split()[1:])
   elif not l.startswith(b'STAGE-COUNT '):raw.append(l)
  assert (r.returncode,r.stdout,b''.join(raw))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(r.returncode,r.stderr[-1200:])
  assert rows and (previous==None or previous==rows);previous=rows
  out.writerows([[i,*row] for row in rows]);f.flush()
