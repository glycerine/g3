from pathlib import Path
import csv,os,subprocess
w=Path(__file__).resolve().parent
modes=['base','trial','insert','self']
for m in modes:
 subprocess.run(['go','test','-c',*(['-overlay',w/m/'trial.json'] if m!='base' else []),'-o',w/(m+'.test'),'./smtcore'],check=True)
 subprocess.run([w/(m+'.test'),'-test.run','Congruence|MergeAndUndo'],check=True)
with (w/'micro.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['round','mode','benchmark','instructions'])
 for i in range(7):
  for m in modes[i%4:]+modes[:i%4]:
   for case,it in [('BenchmarkSMTMergeAndUndo','20000x'),('BenchmarkSMTCongruenceProbes$/^EraseInsert','200000x'),('BenchmarkSMTCongruenceProbes$/^EraseCommuted','200000x')]:
    st=w/'micro.stat'
    r=subprocess.run(['taskset','-c','18','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',st,'-e','instructions:u','--',w/(m+'.test'),'-test.run','^$','-test.bench','^'+case+'$','-test.benchtime',it,'-test.cpu','1'],capture_output=True,check=True)
    assert b'ns/op' in r.stdout
    n=next(x[0] for x in csv.reader(st.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    o.writerow([i,m,case,n]);f.flush()
