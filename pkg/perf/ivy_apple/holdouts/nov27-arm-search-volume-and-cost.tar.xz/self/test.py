from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_enode_core.go';s=f.read_text();a=s.index('func SMTEnodesCongruent(');k='if left.declaration != right.declaration';j=s.index(k,a)
s=s[:j]+'''if left == right {
		if left.commutative && len(left.arguments) != 2 {
			return false, false, ast.ErrASTDomain
		}
		return true, false, nil
	}
	'''+s[j:]
dst=w/'enode.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().replace("Path('/tmp/g3-card-install/volume-release')","Path('/tmp/g3-or-install/final/release')").replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("],7,['base','release']", "],11,['base','release']").replace("run(12","run(10")
exec(compile(script,__file__,'exec'))
