from pathlib import Path
w=Path(__file__).resolve().parent;base=w.parent/'quantifiers';s=(base/'run.py').read_text();a=s.index(" f=p/'smtcore/smt_quantifier_manager.go'");b=s.index(' helper=',a)
s=s[:a]+''' f=p/'smtcore/smt_qi_instance.go';t=f.read_text()
 for i,(k,call) in enumerate([('if _, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance); err != nil {','_, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance)'),('if err = rw.Rewrite(instance, simplified); err != nil {','err = rw.Rewrite(instance,simplified)'),('if err = internalizer.internalizeInstance(result, locals.arguments); err != nil {','err = internalizer.internalizeInstance(result,locals.arguments)')]):
  t=sub(t,k,'studyEnd(3,freshRead());tick:=freshRead();'+call+';studyEnd('+str(i)+',tick);if err!=nil{')
 overlay(f,t);overlay(p/'smtcore/smt_cg_small_table.go',subprocess.check_output(['git','show','4808f7da6:pkg/smtcore/smt_cg_small_table.go'],text=True))
'''+s[b:];s=s.replace('smt_quantifier.cpp','qi_queue.cpp').replace('smt_quantifier.o','qi_queue.o')
a=s.index(" k='m_plugin->propagate();");b=s.index(" b=p.parent/'build';q=",a);s=s[:a]+''' for i,k in enumerate(['m_subst(q, num_bindings, bindings, instance);','m_context.get_rewriter()(instance, s_instance, pr);','m_context.internalize_instance(lemma, pr1, gen);']):
  s=sub(s,k,'{endStudy(3,freshRead());studyMeter meter('+str(i)+');'+k+'}')
'''+s[b:];a=s.index('names=[');b=s.index('\ndef overlay',a);s=s[:a]+s[a:b].replace('match','substitution').replace('notify','rewrite').replace('queue','assertion')+s[b:]
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt']:(w/n).write_text((base/n).read_text())
(w/'compare.py').write_text((base/'compare.py').read_text().replace("'match','notify','queue'","'substitution','rewrite','assertion'"))
