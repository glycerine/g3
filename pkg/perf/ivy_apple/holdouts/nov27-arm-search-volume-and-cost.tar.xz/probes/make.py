from pathlib import Path
w=Path(__file__).resolve().parent;s=(w.parent/'events.py').read_text()
a=s.index(' src={');b=s.index(" overlay(p/'smtcore/study_event_counts.go'",a)
s=s[:a]+''' f=p/'smtcore/smt_cg_small_table.go';t=f.read_text()
 for j,fn in enumerate(['get','set','slot']):
  a=t.index('func (t *smtCgSmallTable) '+fn+'(');b=t.index('{',a)+1;t=t[:b]+'StudyEventCounts['+str(j*2)+']++;'+t[b:];k=t.index('e := &t.entries[i]',b);t=t[:k]+'StudyEventCounts['+str(j*2+1)+']++;'+t[k:]
 a=t.index('func (t *smtCgSmallTable) deleteSlot(');b=t.index('{',a)+1;t=t[:b]+'StudyEventCounts[6]++;'+t[b:]
 t=sub(t,'home := smtCgSmallSlot(e.k0','StudyEventCounts[7]++;home := smtCgSmallSlot(e.k0');t=sub(t,'t.entries[i] = *e','StudyEventCounts[8]++;t.entries[i] = *e');overlay(f,t)
'''+s[b:]
a=s.index('names=[');b=s.index('\ndef overlay',a);s=s[:a]+"names=['get','get_slots','set','set_slots','slot','slot_slots','deleted','tail_visited','relocated']"+s[b:]
(w/'run.py').write_text(s)
