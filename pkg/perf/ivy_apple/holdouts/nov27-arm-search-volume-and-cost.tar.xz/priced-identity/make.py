from pathlib import Path
w=Path(__file__).resolve().parent;base=w.parent/'regions'
s=(base/'run.py').read_text().replace("ovpath=w/(mode+'.json')","ov.update(json.loads((w.parent/'identity/trial.json').read_text())['Replace']);ovpath=w/(mode+'.json')")
(w/'run.py').write_text(s)
(w/'read.go.txt').write_text((base/'read.go.txt').read_text())
