"""Compare bounded local search policies on three-literal formulas."""
import json
import os
from pathlib import Path
import subprocess

pkg=Path.cwd().resolve()
out=Path(__file__).resolve().parent
path=pkg/'sat/sat_dimacs_repair.go'
source=path.read_text()
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')

def sub(code, old, new):
    assert code.count(old)==1,old
    return code.replace(old,new)

def expand(code):
    old='\tbestRemaining, lastImprovement := len(r.unsatisfied), 0'
    return sub(code,old,'''    n, clauses := int(cnf.variables),len(cnf.ends)
    dense := n >= 128 && n <= 4096 && 2*clauses >= 7*n && 2*clauses <= 9*n && len(cnf.literals) == 3*clauses
    if dense {
        for i,end := range cnf.ends {
            if end != 3*uint32(i+1) {
                dense=false
                break
            }
        }
    }
    if dense {
        maxFlips = min(170*len(r.value),120_000)
        work = min(500*len(cnf.literals), 2_000_000)
        patience = min(10000,35*len(r.value))
    }
'''+old)

def weighted(code, cubic):
    code=sub(code,'\t\tbest, score := uint32(0), int(^uint(0)>>1)', '''        best, score := uint32(0), int(^uint(0)>>1)
        var weights [3]int
        total := 0''')
    code=sub(code,'\t\tfor _, lit := range row {','\t\tfor i, lit := range row {')
    denom='breaks*breaks*breaks+1' if cubic else 'breaks*breaks+1'
    code=sub(code,'\t\t\tif breaks < score {',f'''            if dense {{
                weight := 4096/({denom})+1
                weights[i]=weight
                total += weight
            }}
            if breaks < score {{''')
    code=sub(code,'if breaks == 0 {','if breaks == 0 && !dense {')
    return sub(code,'\t\tif score > 0 && r.random(3) == 0 {', '''        if dense {
            choice := r.random(total)
            for i, weight := range weights {
                if choice < weight {
                    best = r.value[row[i]>>1]
                    break
                }
                choice-=weight
            }
        } else if score > 0 && r.random(3) == 0 {''')

def tabu(code):
    code=sub(code,'\tbestRemaining, lastImprovement := len(r.unsatisfied), 0','''    var last []int
    if dense {last=make([]int,len(r.value))}
    bestRemaining, lastImprovement := len(r.unsatisfied), 0''')
    code=sub(code,'\t\t\tif breaks < score {','''            if dense && breaks > 0 && flips+8-last[lit>>1] < 12 {
                breaks += 3
            }
            if breaks < score || dense && breaks==score && last[live>>1] < last[best>>1] {''')
    code=sub(code,'\t\tr.value[best>>1] ^= 1','''        if dense { last[best>>1] = flips+8 }
        r.value[best>>1] ^= 1''')
    return code

wide=expand(source)
for name,code in {'baseline':source,'long-walk':wide,'weighted':weighted(wide,False),
                  'weighted-cubic':weighted(wide,True),'tabu':tabu(wide)}.items():
    target=out/(name+'.go')
    target.write_bytes(subprocess.check_output(['gofmt'],input=code.encode()))
    over=out/(name+'.json')
    over.write_text(json.dumps({'Replace':{str(path):str(target)}}))
    subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-overlay='+str(over),
                    '-o',out/name,'./cmd/g3'],cwd=pkg,env=env,check=True)
    print(name,'built',flush=True)
