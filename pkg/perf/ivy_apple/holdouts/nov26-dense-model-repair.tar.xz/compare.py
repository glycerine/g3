"""Rotate local search policies over dense SAT and hidden/ordinary UNSAT."""
from collections import defaultdict
import argparse
import csv
import io
import os
from pathlib import Path
import random
from statistics import median
import subprocess
import sys
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('variants', nargs='+')
p.add_argument('--rounds', type=int, default=3)
p.add_argument('--label', default='runs')
p.add_argument('--cpu', default='8')
p.add_argument('--case', action='append')
p.add_argument('--independent', action='store_true')
args=p.parse_args()
pkg=Path.cwd().resolve()
out=Path(__file__).resolve().parent
data=out/'fixtures'
data.mkdir(exist_ok=True)
sys.path.insert(0,str(pkg/'perf/ivy_raft'))
from watch_propagation import check_output, dimacs, formulas

native=pkg.parent/'build/z3'
env=dict(os.environ,GOMAXPROCS='1')
def independently_classify(path):
    r=subprocess.run([native,'-dimacs',path],capture_output=True,text=True,timeout=30,check=True)
    verdict=r.stdout.splitlines()[0]
    assert verdict in ('sat','unsat'), (path,verdict)
    return verdict

inputs={}
for file in sorted((pkg/'build/.nov26-planted-search/repair-adaptive/unseen').glob('w3-n330-*.cnf')):
    inputs[file]='sat'

for n,m in ((144,590),(208,874),(256,1100)):
    for offset in range(5):
        rng=random.Random(13231+13*n+offset)
        planted=offset<3
        signs=[rng.choice((True,False)) for _ in range(n)]
        cs=[]
        for i in range(m):
            row=rng.sample(range(1,n+1),3)
            signs3=rng.randrange(1 if planted else 0,8)
            cs.append([(v if bool(signs3&(1<<j)) == signs[v-1] else -v)
                       for j,v in enumerate(row)])
        path=data/f'{"planted" if planted else "random"}-{n}-{offset}.cnf'
        path.write_text(dimacs(n,cs))
        inputs[path]='sat' if planted else independently_classify(path)
        if offset==2:
            a,b,c=n+1,n+2,n+3
            for state in range(8):
                cs.append([v if state&(1<<i) else -v for i,v in enumerate((a,b,c))])
            path=data/f'hidden-{n}.cnf'
            path.write_text(dimacs(n+3,cs))
            inputs[path]='unsat'
for case,n,cs,answer in formulas(1,mixed_polarity=True):
    if case.startswith('planted') or case in ('pigeon7','pigeon8-s0'):
        path=data/(case+'.cnf')
        path.write_text('c '+(' '*4096)+'\n'+dimacs(n,cs))
        inputs[path]=answer

if args.independent:
    inputs.clear()
    for n,m in ((160,568),(192,781),(240,1075)):
        for offset in range(5):
            rng=random.Random(392699+59*n+offset)
            signs=[rng.choice((1,-1)) for _ in range(n)]
            clauses=[]
            for i in range(m):
                row=rng.sample(range(1,n+1),3)
                mask=rng.randrange(1,8)
                clauses.append([v*signs[v-1]*(1 if mask&(1<<j) else -1) for j,v in enumerate(row)])
            path=data/f'independent-{n}-{offset}.cnf'
            path.write_text(dimacs(n,clauses))
            inputs[path]='sat'

engines={'baseline':out/'baseline','z3':native}
engines.update((label,out/label) for label in args.variants)
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (out/(args.label+'.csv')).open('w') as stream:
    w=csv.writer(stream)
    w.writerow(('case','engine','round','answer','variables_created','instructions','milliseconds'))
    for file,answer in inputs.items():
        if args.case and file.stem not in args.case:
            continue
        cs=[]
        for line in file.read_text().splitlines():
            if line.startswith('p '):
                n=int(line.split()[2])
            elif line and not line.startswith('c'):
                cs.append([int(s) for s in line.split()[:-1]])
        order=list(engines)
        for turn in range(args.rounds):
            offset=turn%len(order)
            for label in order[offset:]+order[:offset]:
                cmd=['taskset','-c',args.cpu,perf,'stat','-x,','-e','instructions:u','--',
                     engines[label],'-st','-dimacs',file]
                start=time.monotonic()
                result=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=60,check=True)
                ms=(time.monotonic()-start)*1e3
                check_output(result.stdout,answer,n,cs)
                inst,=[int(r[0]) for r in csv.reader(io.StringIO(result.stderr)) if len(r)>4 and r[2]=='instructions:u' and float(r[4])==100]
                w.writerow((file.stem,label,turn+1,answer,int(':mk-bool-var' in result.stdout),inst,f'{ms:.3f}'))
        print(file.name,answer,flush=True)
        stream.flush()
