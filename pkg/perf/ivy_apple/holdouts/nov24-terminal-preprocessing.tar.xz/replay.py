"""Replay a complete formula, its named core or its ground goal in a fresh solver."""
import argparse
import csv
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LIMIT_ERROR = '(error "tactic failed: max. resource limit exceeded")'


def replay(binary, case, tactic, sample, show_count):
    folder = ROOT / 'cases' / case
    with (folder / 'runs.csv').open() as stream:
        recorded = list(csv.DictReader(stream))
    expected = next(r['expected'] for r in recorded if r['input'] == ('original' if sample == 'core' else sample))
    if sample == 'core':
        if expected != 'unsat':
            raise ValueError(f'{case} was satisfiable and has no core')
        formula = (folder / 'core.smt2').read_text()
    elif sample == 'weak':
        goal = json.loads((folder / 'rows.json').read_text())[-1]
        formula = (folder / 'header.smt2').read_text() + '(assert ' + goal + ')\n'
    else:
        formula = (folder / 'input.smt2').read_text()
    tactics = json.loads((ROOT / 'tactics.json').read_text())
    before = '(set-option :rlimit 4000000)\n'
    cmd = [str(binary.resolve()), '-in', '-smt2']
    if show_count:
        cmd = ['perf', 'stat', '-e', 'instructions:u,cycles:u', '--', *cmd]
    p = subprocess.run(cmd, input=before + formula + tactics[tactic] + '\n',
                       text=True, stdout=subprocess.PIPE, timeout=120)
    out = p.stdout.strip()
    if out == LIMIT_ERROR and sample == 'original' and expected == 'sat' and tactic == 'ctx' and case.startswith('test_liveness2-sat-'):
        print(case, tactic, sample, 'resource exhausted')
        return
    if p.returncode != 0 or out != expected:
        raise RuntimeError(f'{case} {tactic} {sample}: expected {expected}, got {out!r}, exit {p.returncode}')
    print(case, tactic, sample, out)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('solver', type=Path)
    parser.add_argument('case')
    parser.add_argument('--tactic', default='smt')
    parser.add_argument('--input', choices=('original', 'core', 'weak'), default='original')
    parser.add_argument('--perf', action='store_true')
    args = parser.parse_args()
    replay(args.solver, args.case, args.tactic, args.input, args.perf)
