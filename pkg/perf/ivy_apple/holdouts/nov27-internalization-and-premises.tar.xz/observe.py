"""Build a per-instance Boolean/term call census in the two matching frontends."""
from pathlib import Path
import json,subprocess,sys,re,shlex,shutil
p=Path.cwd();w=Path(__file__).resolve().parent
e=sys.argv[1];front,mod,stage=map(lambda x:Path(x).resolve(),sys.argv[2:])
files=json.loads(stage.read_text())['Replace']
def change(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
def write(k,s):
 d=w/(e+'-'+k.name);d.write_text(s);files[str(k)]=str(d)
if e=='g3':
 k=p/'smtcore/smt_internalizer.go';s=k.read_text()
 a='return s.assertExpression(lemma, proof, instance.Generation(), arguments)';s=change(s,a,'println("QI-BEGIN");defer println("QI-END");'+a)
 a='if s.manager.IsTrue(expression) || s.manager.IsFalse(expression) {';i=s.index(a,s.index('func (s *SMTInternalizerState) internalizeFormula('))
 s=s[:i]+'''_,present:=s.boolVar.lookup(expression)
    op1,basic1:=s.smtHeaderBasicOperation(header)
    typ:="predicate"
    switch {case s.manager.IsTrue(expression)||s.manager.IsFalse(expression):typ="constant"
    case header.Kind==ast.ASTQuantifier:typ="quantifier"
    case basic1&&op1==ast.ASTOpNot:typ="not"
    case basic1&&op1==ast.ASTOpEq:typ="eq"
    case basic1:typ="basic"}
    println("IC-F",typ,gateContext,present)
    '''+s[i:]
 a='func (s *SMTInternalizerState) internalizeTerm(expression ast.ASTHandle, header *ast.ASTNodeHeader) error {'
 s=change(s,a,a+'\nprintln("IC-T",s.context.enodes.get(expression)!=nil)')
 write(k,s)
else:
 build=p.parent/'build';src=p.parent/'src/smt'
 flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 lib=w/'lib-census.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
 for name in ['qi_queue','smt_internalizer']:
  k=src/(name+'.cpp');s=k.read_text()
  if name=='qi_queue':
   a='m_context.internalize_instance(lemma, pr1, gen);';s=change(s,a,'fprintf(stderr,"QI-BEGIN\\n");'+a+'fprintf(stderr,"QI-END\\n");')
  else:
   a='void context::internalize_formula(expr * n, bool gate_ctx) {'
   s=change(s,a,a+'''\nconst char* typ=m_manager.is_true(n)||m_manager.is_false(n)?"constant":is_quantifier(n)?"quantifier":m_manager.is_not(n)?"not":m_manager.is_eq(n)?"eq":to_app(n)->get_family_id()==m_manager.get_basic_family_id()?"basic":"predicate";
    fprintf(stderr,"IC-F %s %s %s\\n",typ,gate_ctx?"true":"false",b_internalized(n)?"true":"false");''')
   a='void context::internalize_term(app * n) {';s=change(s,a,a+'\nfprintf(stderr,"IC-T %s\\n",e_internalized(n)?"true":"false");')
  d=w/k.name;d.write_text(s);obj=w/(name+'.o')
  subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,d],cwd=build,check=True)
  subprocess.run(['ar','r',lib,obj],check=True)
 k=front/'smt/quantifier.go';write(k,change(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=w/(e+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',ov,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
