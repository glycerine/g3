"""Measure independent refutations after selecting top-level conjuncts of the original premise."""
from pathlib import Path
import re,subprocess,sys,collections,csv,json
w=Path(__file__).resolve().parent
fixtures,native,go=map(lambda x:Path(x).resolve(),sys.argv[1:])
def parse(s):
 stack=[[]]
 for m in re.finditer(r'\s+|;[^\n]*|\(|\)|\|[^|]*\||"(?:""|[^"])*"|[^\s();"|]+',s):
  t=m[0]
  if t.isspace() or t.startswith(';'):continue
  if t=='(': stack.append([])
  elif t==')':stack[-2].append(stack.pop())
  else:stack[-1].append(t)
 assert len(stack)==1
 return stack[0]
def fmt(x):return x if isinstance(x,str) else '('+' '.join(map(fmt,x))+')'
def split(x):
 if isinstance(x,list) and x[0]=='and':
  return [v for a in x[1:] for v in split(a)]
 if isinstance(x,list) and x[0]=='let':
  out=[]
  for v in split(x[2]):
   names=set(re.findall(r'[^\s()]+',fmt(v)))
   binds=[b for b in x[1] if b[0] in names]
   out.append(['let',binds,v] if binds else v)
  return out
 return [x]
def query(forms,base,items,names=False):
 s=['(set-option :produce-unsat-cores true)'] if names else []
 for z in forms:
  if z is base:
   if names:s.extend('(assert (! '+fmt(t)+' :named p'+str(i)+'))' for i,t in items)
   elif items:s.append(fmt(['assert',['and',*[t for _,t in items]]]))
  else:s.append(fmt(z))
  if z[0]=='check-sat' and names:s.append('(get-unsat-core)')
 return ('\n'.join(s)+'\n').encode()
def run(binary,s):
 r=subprocess.run([binary,'-in','-smt2'],input=s,capture_output=True,timeout=40)
 assert r.returncode==0 and not r.stderr and r.stdout.startswith(b'unsat\n') and b'(error' not in r.stdout,(binary,r.stdout[:500],r.stderr[:200])
 return r.stdout
if __name__=='__main__':
 for source in sorted(fixtures.glob('*.smt2')):
  forms=parse(source.read_text());assert [x[0] for x in forms if x[0] in ('assert','push','check-sat')]==['assert','push','assert','check-sat']
  base=next(x for x in forms if x[0]=='assert');items=list(enumerate(split(base[1])))
  sel=query(forms,base,items,True)
  reply=run(native,sel).splitlines()[1];assert re.fullmatch(rb'\((?:p\d+(?: p\d+)*)?\)',reply),reply
  indices={int(x) for x in re.findall(rb'p(\d+)',reply)}
  (w/(source.stem+'.indices.json')).write_text(json.dumps(sorted(indices)))
  subsets={'core':[it for it in items if it[0] in indices], 'all':items}
  for key,subset in subsets.items():
   s=query(forms,base,subset);run(native,s);run(go,s);(w/(source.stem+'-'+key+'.smt2')).write_bytes(s)
  print(source.stem,len(items),len(indices),flush=True)
