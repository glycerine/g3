from pathlib import Path
import os,csv,subprocess,re,sys
w=Path(__file__).resolve().parent;perf=sys.argv[1];wr=csv.writer(sys.stdout);wr.writerow(('round','engine','arity','width','instructions','ns_per_op','bytes','allocs'))
for i in range(7):
 for arity,stem in [(1,'Unary'),(2,'')]:
  for width,n in [(32,1000),(2048,50)]:
   for e in ('basereg','reg')[::1 if i%2==0 else -1]:
    f=w/'reg.perf'
    r=subprocess.run(['taskset','-c','16',perf,'stat','-x,','-o',f,'-e','instructions:u','--',w/(e+'.test'),'-test.run=^$','-test.cpu=1',f'-test.bench=^BenchmarkSMT{stem}EnodeScopeBatch$/^{width}$',f'-test.benchtime={n}x'],env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,check=True)
    v=re.search(rb'\s+(\d+)\s+([\d.]+) ns/op\s+[\d.]+ enodes/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert v and int(v[1])==n,r.stdout[:500]
    hw=next(v[0] for v in csv.reader(f.read_text().splitlines()) if len(v)>4 and v[2]=='instructions:u' and float(v[4])==100)
    wr.writerow((i,e,arity,width,hw,*[v[j].decode() for j in (2,3,4)]));sys.stdout.flush()
