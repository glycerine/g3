"""Select premises without a proof using symbols that are rare within the premise set."""
from premises import *
from collections import Counter
import os
def symbols(x,ds):
 if isinstance(x,str): return {x} & ds
 return set().union(*(symbols(c,ds) for c in x))
wr=csv.writer(sys.stdout);wr.writerow(['query','tolerance','depth','premises','limit','status','instructions','instances'])
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
for source in sorted(fixtures.glob('*.smt2')):
 forms=parse(source.read_text());base,goal=[x for x in forms if x[0]=='assert']
 items=list(enumerate(split(base[1])));ds={x[1] for x in forms if x[0]=='declare-fun'}
 syms=[symbols(t,ds) for _,t in items];f=Counter(s for ss in syms for s in ss);seen={}
 for tol in (1,2,4):
  sig=symbols(goal[1],ds);take=set()
  for depth in range(1,5):
   new={i for i,ss in enumerate(syms) if not ss or any(f[s]<=tol*min(f[x] for x in ss) for s in ss & sig)}
   sig.update(*(syms[i] for i in new));take|=new
   key=tuple(sorted(take))
   if key not in seen:
    # A deterministic solver resource cap bounds unsuccessful attempts.
    q=b'(set-option :rlimit 150000)\n'+query(forms,base,[items[i] for i in key]);ps=w/'rarity.perf'
    r=subprocess.run(['taskset','-c','16',perf,'stat','-x,','-o',ps,'-e','instructions:u','--',go,'-in','-smt2'],input=q,capture_output=True,timeout=20,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
    assert not r.returncode and not r.stderr and b'(error' not in r.stdout,(r.stdout[:300],r.stderr)
    status=r.stdout.splitlines()[0].decode();assert status in ('sat','unsat','unknown')
    hw=next(v for v in csv.reader(ps.read_text().splitlines()) if len(v)>4 and v[2]=='instructions:u' and float(v[4])==100)
    stats=dict(re.findall(rb':([\w-]+)\s+(\d+)',r.stdout));seen[key]=(status,int(hw[0]),int(stats.get(b'quant-instantiations',b'0')))
   wr.writerow((source.stem,tol,depth,len(key),150000,*seen[key]));sys.stdout.flush()
