"""Extend resolved non-Boolean term inputs to fresh binary and unary predicates."""
from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent
mode=sys.argv[1];files={}
def save(k,s):
 d=w/(mode+'-'+k.name+'.txt');d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));files[str(k)]=str(d)
k=p/'smtcore/smt_internalizer.go';s=k.read_text()
i=s.index('for index := uint32(0)',s.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp'))
j=s.index('variable, isNew',i)
s=s[:i]+'''var inputs *smtTermInputs
 if knownBoolean && !isGate && count>0 && count<=2 && !ast.ASTValidateHandles && !smtcoreSourceDebug && !ast.ASTSourceDebug && s.manager.TraceStream==nil && !s.manager.Budget().InjectionArmed() {
    children, ok, err := s.existingTermChildren(expression,count)
    if err!=nil{return err}
    if ok { inputs=&smtTermInputs{header:*header, children:children,boolean:true} }
 }
 if inputs==nil {
 '''+s[i:j]+'}\n'+s[j:]
a='if _, err = s.attachBooleanEnode(expression, variable, isGate, !gateContext, true); err != nil {'
assert s.count(a)==1
if mode=='inputs':
 s=s.replace(a,'''if inputs!=nil {
    if _,err=s.mkEnode(expression,false,!gateContext,true,inputs);err!=nil{return err}
    data,err:=s.BooleanData(variable);if err!=nil{return err};s.setEnodeFlag(variable,data.InternalLevel()==s.scopeLevel)
 } else '''+a)
save(k,s)
k=p/'smtcore/smt_enode_core.go';s=k.read_text().replace('type smtTermInputs struct {','type smtTermInputs struct {\nboolean bool').replace('header = term.header','header = term.header;boolean=term.boolean');save(k,s)
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',ov,'-o',w/mode,'./cmd/g3'],check=True)
