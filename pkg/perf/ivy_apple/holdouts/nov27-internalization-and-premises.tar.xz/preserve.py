"""Keep the original let nesting and surviving conjunct order when projecting a proof core."""
from premises import *
for source in sorted(fixtures.glob('*.smt2')):
 forms=parse(source.read_text());base=next(x for x in forms if x[0]=='assert')
 indices=set(json.loads((w/(source.stem+'.indices.json')).read_text()))
 seq=iter(range(len(split(base[1]))))
 def project(x):
  if isinstance(x,list) and x[0]=='and':
   children=[v for c in x[1:] if (v:=project(c)) is not None]
   return ['and',*children] if len(children)>1 else children[0] if children else None
  if isinstance(x,list) and x[0]=='let':
   body=project(x[2]);return ['let',x[1],body] if body is not None else None
  return x if next(seq) in indices else None
 subset=project(base[1]);assert subset and next(seq,None) is None
 s=('\n'.join(fmt(['assert',subset] if z is base else z) for z in forms)+'\n').encode()
 run(native,s);run(go,s);(w/(source.stem+'-nested.smt2')).write_bytes(s)
