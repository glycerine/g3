"""Resolve the owned enode's expression page once for registration and relevance."""
from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;out={}
def save(k,s):
 d=w/('register-'+k.name);d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));out[str(k)]=str(d)
k=p/'smtcore/smt_checker.go';s=k.read_text().replace('prior := c.enodes.get(node.owner)','''page := c.exprs.writePage(node.owner)
 offset := node.owner.Slot()%smtExprPageSize
 prior := page.enodes[offset]''').replace('c.enodes.set(node.owner, node)','page.enodes[offset]=node; c.exprs.enodeCount++').replace('c.relevant.set(node.owner, relevant)','''record:=&page.records[offset]
 if borrowed {
    c.relevant.setRecord(record,relevant)
 } else {
    c.relevant.setRecord(record,record.flags&smtExprRelevant!=0)
 }''');save(k,s)
k=p/'smtcore/smt_expr_table.go';s=k.read_text().replace('record := r.t.write(h)\n\tmarked', '''return r.setRecord(r.t.write(h), value)
}

func (r smtRelevantTable) setRecord(record *smtExprRecord, value bool) bool {
 marked''');save(k,s)
k=p/'smtcore/smt_internalizer_state.go';s=k.read_text().replace('registerEnode(node, s.context.relevant.get(expression), false)','registerEnode(node, false, false)');save(k,s)
ov=w/'register.json';ov.write_text(json.dumps({'Replace':out}))
