"""Train a premise subset on goal 55 and attempt goal 56 in each identical Ticket base."""
from premises import *
import os
perf=sys.argv[-1] if len(sys.argv)>4 else '/usr/lib/linux-tools/6.17.0-35-generic/perf'
def expand(x,env):
 if isinstance(x,str):return env.get(x,x)
 if x[0]=='let':return expand(x[2],env|{n:expand(t,env) for n,t in x[1]})
 if x[0] in ('forall','exists'):
  return [x[0],x[1],expand(x[2],{k:v for k,v in env.items() if k not in {n for n,_ in x[1]}})]
 return [expand(c,env) for c in x]
def measure(engine,q):
 f=w/'neighbors.perf'
 r=subprocess.run(['taskset','-c','16',perf,'stat','-x,','-e','instructions:u','-o',f,'--',engine,'-in','-smt2'],input=q,capture_output=True,timeout=30,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
 assert not r.returncode and not r.stderr and b'(error' not in r.stdout,(r.returncode,r.stdout[:300],r.stderr[:200])
 hw=next(v for v in csv.reader(f.read_text().splitlines()) if len(v)>4 and v[2]=='instructions:u' and float(v[4])==100)
 return r.stdout,int(hw[0])
if __name__=='__main__':
 wr=csv.writer(sys.stdout);wr.writerow(('batch','goal','trial','round','engine','premises','status','instructions'))
 prefix=b'(set-option :smt.macro_finder true)\n(set-option :rlimit 300000)\n'
 for b in range(1,10):
  q=prefix+(w/f'snap-{b}-0-base.smt2').read_bytes()
  for e,exe in [('g3',go),('z3',native)]:
   res,n=measure(exe,q);wr.writerow((b,0,'base',0,e,'',res.splitlines()[0].decode(),n))
 for b in range(2,6):
  paired={}
  for g in (55,56):
   forms=parse((w/f'snap-{b}-{g}-goal.smt2').read_text())
   base,goal=[x for x in forms if x[0]=='assert']
   items=list(enumerate(split(expand(base[1],{}))))
   paired[g]=(forms,base,items)
  assert [fmt(t) for _,t in paired[55][2]]==[fmt(t) for _,t in paired[56][2]]
  forms,base,items=paired[55];sel=prefix+query(forms,base,items,True)
  res,n=measure(native,sel);assert res.startswith(b'unsat\n');indices={int(x) for x in re.findall(rb'p(\d+)',res.splitlines()[1])};assert indices
  wr.writerow((b,55,'learn-core',0,'z3',len(indices),'unsat',n))
  for g in (55,56):
   forms,base,items=paired[g]
   inputs={'original':(len(items),prefix+(w/f'snap-{b}-{g}-goal.smt2').read_bytes()),'all':(len(items),prefix+query(forms,base,items)),'selected':(len(indices),prefix+query(forms,base,[it for it in items if it[0] in indices]))}
   for i in range(5):
    combos=[(e,exe,k) for e,exe in [('g3',go),('z3',native)] for k in inputs]
    for e,exe,k in combos[i:]+combos[:i]:
     size,q=inputs[k];res,n=measure(exe,q);status=res.splitlines()[0].decode()
     assert status in ('sat','unsat','unknown') and (k=='selected' and g==56 or status=='unsat')
     wr.writerow((b,g,k,i,e,size,status,n));sys.stdout.flush()
