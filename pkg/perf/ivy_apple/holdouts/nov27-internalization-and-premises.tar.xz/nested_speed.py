from pathlib import Path
import re,sys,subprocess,os,csv
w=Path(__file__).resolve().parent;fixtures,native,go,perf=map(lambda s:Path(s).resolve(),sys.argv[1:])
wr=csv.writer(sys.stdout);wr.writerow(('query','round','engine','input','instructions','cycles','decisions','conflicts','instances'))
for q in sorted(fixtures.glob('*.smt2')):
 paths={'original':q,**{k:w/(q.stem+'-'+k+'.smt2') for k in ['all','core','nested']}}
 for i in range(8):
  pairs=[(e,k) for e in ('g3','z3') for k in paths]
  for e,k in pairs[i%len(pairs):]+pairs[:i%len(pairs)]:
   ps=w/'last.perf'
   r=subprocess.run(['taskset','-c','16',perf,'stat','-x,','-o',ps,'-e','instructions:u,cycles:u','--',go if e=='g3' else native,'-in','-smt2'],input=paths[k].read_bytes(),capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'),timeout=40)
   assert r.returncode==0 and not r.stderr and r.stdout.startswith(b'unsat\n') and b'(error' not in r.stdout
   stats=dict(re.findall(rb':([\w-]+)\s+(\d+)',r.stdout));hw={v[2]:int(v[0]) for v in csv.reader(ps.read_text().splitlines()) if len(v)>4 and v[2].endswith(':u') and float(v[4])==100}
   wr.writerow([q.stem,i,e,k,hw['instructions:u'],hw['cycles:u'],*[int(stats.get(key,b'0')) for key in (b'decisions',b'conflicts',b'quant-instantiations')]]);sys.stdout.flush()
