from collections import Counter
from pathlib import Path
import csv,json,os,subprocess,sys
w=Path(__file__).resolve().parent
gold,examples=map(Path,sys.argv[1:])
gold=gold.resolve();ref=gold/'reference/ticket_protocol'
rel,_,rc=json.loads((gold/'cases.json').read_text())['ticket_protocol']
wr=csv.writer(sys.stdout);wr.writerow(('engine','batch','goal','calls','count'))
for e in ('g3','z3'):
 r=subprocess.run(['taskset','-c','16',w/e,examples/rel],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
 keep=[];active=False;counts=Counter();total=0
 for line in r.stderr.splitlines(keepends=True):
  if line==b'QI-BEGIN\n':
   assert not active
   active=True;counts['instances']+=1
  elif line==b'QI-END\n':
   assert active
   active=False
  elif line.startswith((b'IC-F ',b'IC-T ')):
   if active:counts[line.decode().strip()]+=1
  elif line.startswith(b'STAGE-COUNT '):
   assert not active
   _,b,g,phase,*_=line.split()
   if phase==b'check' and int(b) in (2,3,4,5) and int(g) in (55,56):
    for k,v in sorted(counts.items()):wr.writerow((e,int(b),int(g),k,v))
    total+=counts['instances']
   counts.clear()
  else:keep.append(line)
 assert total==3700 and (r.returncode,r.stdout,b''.join(keep))==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(total,r.returncode,keep[-3:])
