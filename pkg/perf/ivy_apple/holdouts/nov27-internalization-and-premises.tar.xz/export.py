"""Export base, assumed-base and eight goal snapshots from the pinned native Ticket verifier."""
from pathlib import Path
import json,sys,subprocess,os
w=Path(__file__).resolve().parent;front,mod,stage,gold,examples=map(lambda s:Path(s).resolve(),sys.argv[1:]);examples=Path(sys.argv[-1])
files=json.loads(stage.read_text())['Replace'];k=front/'z3bridge_solver_model.go';s=Path(files[str(k)]).read_text()
a='z3solver.Assert(zc)\n\n\t// Process final conditions'
b='''z3solver.Assert(zc)
 writeSnapshot:=func(kind string,ord int){if err:=os.WriteFile(fmt.Sprintf("snap-%d-%d-%s.smt2",batch,ord,kind),[]byte(z3solver.ToSMT2()),0600);err!=nil{panic(err)}}
 writeSnapshot("base",0)

 // Process final conditions'''
assert s.count(a)==1;s=s.replace(a,b)
a='z3solver.Assert(zCond)\n\t\t\t\tassumes';assert s.count(a)==1;s=s.replace(a,'z3solver.Assert(zCond)\n writeSnapshot("assume",ordinal+1)\n assumes')
a='z3solver.Assert(zCond)\n\t\t\t\tend("assert")';assert s.count(a)==1;s=s.replace(a,'z3solver.Assert(zCond)\n if batch>=2 && batch<=5 && (ordinal==54||ordinal==55){writeSnapshot("goal",ordinal+1)}\n end("assert")')
d=w/'export.go.txt';d.write_text(s);files[str(k)]=str(d);o=w/'export.json';o.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off,classic_z3','-overlay',o,'-o',w/'export','./cmd/goivy_check'],cwd=front,check=True)
rel,_,rc=json.loads((gold/'cases.json').read_text())['ticket_protocol'];ref=gold/'reference/ticket_protocol'
r=subprocess.run([w/'export',examples/rel],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True)
(w/'export.stdout').write_bytes(r.stdout);(w/'export.stderr').write_bytes(r.stderr)
assert (r.returncode,r.stdout,b''.join(v for v in r.stderr.splitlines(keepends=True) if not v.startswith(b'STAGE-COUNT ')))==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
