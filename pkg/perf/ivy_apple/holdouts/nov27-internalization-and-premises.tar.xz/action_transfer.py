"""Transfer same-goal cores forward in action order, retaining every unseen premise."""
from neighbors import *
wr=csv.writer(sys.stdout);wr.writerow(('batch','goal','trial','round','engine','premises','status','instructions'))
prefix=b'(set-option :smt.macro_finder true)\n(set-option :rlimit 300000)\n'
for g in (55,56):
 prev=None
 for b in range(2,6):
  forms=parse((w/f'snap-{b}-{g}-goal.smt2').read_text());base,goal=[x for x in forms if x[0]=='assert']
  items=list(enumerate(split(expand(base[1],{}))));keys=[fmt(t) for _,t in items]
  if prev:
   seen,essential=prev
   select=[it for it,key in zip(items,keys) if key not in seen or key in essential]
   q=prefix+query(forms,base,select)
   for i in range(5):
    for e,exe in [('g3',go),('z3',native)][::1 if i%2==0 else -1]:
     res,n=measure(exe,q);status=res.splitlines()[0].decode();assert status in ('sat','unsat','unknown')
     wr.writerow((b,g,'novel-plus-core',i,e,len(select),status,n));sys.stdout.flush()
  res,n=measure(native,prefix+query(forms,base,items,True));assert res.startswith(b'unsat\n');indices={int(x) for x in re.findall(rb'p(\d+)',res.splitlines()[1])};assert indices
  prev=(set(keys),{keys[i] for i in indices})
  wr.writerow((b,g,'learn-core',0,'z3',len(indices),'unsat',n))
