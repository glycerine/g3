"""Read archived measurements without rebuilding a solver."""
from collections import defaultdict,Counter
from pathlib import Path
from statistics import median
import csv
w=Path(__file__).resolve().parent
def rows(file):return list(csv.DictReader((w/(file+'.csv')).open()))
def groups(file,keys,field):
 d=defaultdict(list)
 for r in rows(file):d[tuple(r[k] for k in keys.split())].append(int(r[field]))
 return {k:median(v) for k,v in d.items()}
for file,keys in [('nested','query engine input'),('neighbors','batch goal engine trial status'),('action','batch goal engine trial status')]:
 for k,n in groups(file,keys,'instructions').items():print(file,*k,round(n/1e6,3))
for field in ['calls','instructions']:
 out=Counter()
 for r in rows('price'):out[r['engine'],r['kind'],r['round']]+=int(r[field])
 for e,k in sorted({(e,k) for e,k,i in out}):
  print('price',field,e,k,median(out[e,k,str(i)] for i in range(5)))
