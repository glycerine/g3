from pathlib import Path
import collections,csv,sys
rows=list(csv.DictReader(Path(sys.argv[1]).open()))
for e,core,ass,entry in [('g3','internalizeFormulaCoreOp','assertExpression','(*SMTQuantifierManager).instantiate'),('z3','internalize_formula_core','internalize_assertion','smt::qi_queue::instantiate(smt::qi_queue::entry&)')]:
 rounds={r['round'] for r in rows if r['engine']==e}
 child=collections.Counter()
 for r in rows:
  s=r['stack'].splitlines()
  if r['engine']!=e or not all(any(k in v for v in s) for k in (entry,ass,core)):continue
  i=max(i for i,v in enumerate(s) if core in v)
  child[s[i-1] if i else '(self)']+=int(r['period'])*int(r['samples'])
 print(e,'M instructions per eight checks')
 for k,v in child.most_common():print(round(v/len(rounds)/1e6,3),k)
