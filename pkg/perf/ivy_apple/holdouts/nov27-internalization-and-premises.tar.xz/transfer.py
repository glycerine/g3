"""Apply a prior proof's original conjuncts to a different query, with a full-query fallback."""
from pathlib import Path
import sys,subprocess
from premises import parse,split,fmt,query,fixtures,w,native,go
import json
queries={}
for source in sorted(fixtures.glob('ticket*.smt2')):
 forms=parse(source.read_text());base=next(x for x in forms if x[0]=='assert')
 items=list(enumerate(split(base[1])));idx=json.loads((w/(source.stem+'.indices.json')).read_text())
 queries[source.stem]=(forms,base,items,{fmt(items[i][1]) for i in idx})
for dest,(forms,base,items,_) in queries.items():
 for src,(_,_,_,core) in queries.items():
  if src==dest:continue
  known=[it for it in items if fmt(it[1]) in core]
  s=query(forms,base,known)
  (w/(dest+'-transfer.smt2')).write_bytes(s)
  for engine in [native,go]:
   try:r=subprocess.run([engine,'-T:5','-in','-smt2'],input=s,capture_output=True,timeout=7)
   except subprocess.TimeoutExpired:print('transfer',src,dest,len(known),engine.name,'time limit');continue
   print('transfer',src,dest,len(known),engine.name,r.returncode,r.stdout[:50],r.stderr[:80],flush=True)
