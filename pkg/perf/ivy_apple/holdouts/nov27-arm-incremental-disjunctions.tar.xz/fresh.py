from pathlib import Path
import json,subprocess,os,csv,re
w=Path(__file__).resolve().parent;p=Path.cwd();replacement={}
def edit(rel,fn):
 f=p/rel;dst=w/(f.name+'.txt');dst.write_text(fn(f.read_text()));replacement[str(f)]=str(dst)
def insert(s,k,addition):
 assert s.count(k)==1,k
 return s.replace(k,addition+k)
edit('smtcore/smt_qi_instance.go',lambda s:insert(s,'if err = internalizer.internalizeInstance(result, locals.arguments);','freshInstance=true;defer func(){freshInstance=false}();'))
def instrument(s):
 k='if err = s.Internalize(argument, isGate); err != nil {'
 s=insert(s,k,'''track:=false;var tick uint64
 if freshInstance && freshTarget.IsNull() && basic && op==ast.ASTOpEq && s.context.enodes.get(argument)==nil {
 _,bound:=s.boolVar.lookup(argument);boolean,e:=s.manager.HasBoolSort(argument);if e!=nil{panic(e)}
 if boolean && !bound {track=true;freshTarget=argument;tick=freshRead()}
 }
 ''')
 k='return fmt.Errorf("internalize formula child %d: %w", index, err)\n\t\t}'
 assert s.count(k)==1;s=s.replace(k,k+'\n if track {freshAdd(0,tick);freshTarget=ast.ASTHandle{};freshPrint()}')
 k='isGate := basic && (smtInternalizerGateOperation(op) || op == ast.ASTOpNot)'
 assert s.count(k)==1;s=s.replace(k,k+'\n direct:=freshTarget==expression;var childTick uint64;if direct{childTick=freshRead()}')
 s=insert(s,'variable, isNew := s.boolVar.lookup(expression)','if direct{freshAdd(1,childTick)};')
 return wrap(wrap(s,'attachBooleanEnode',3),'addGateConstraints',4)
def wrap(s,name,cat):
 key='func (s *SMTInternalizerState) '+name+'(';a=s.index(key);b=s.index('{',a)+1
 return s[:b]+'\n if expression==freshTarget {defer freshAdd('+str(cat)+',freshRead())}'+s[b:]
edit('smtcore/smt_internalizer.go',instrument)
edit('smtcore/smt_internalizer_state.go',lambda s:wrap(s,'mkBoolVar',2))
helper=w/'fresh.go.txt'
helper.write_text('''package smtcore
import("syscall";"unsafe";"runtime";"github.com/glycerine/g3/pkg/ast")
var freshInstance bool
var freshTarget ast.ASTHandle
var freshFD uintptr
var freshCosts,freshCounts [6]uint64
func freshRead()uint64{
 if freshFD==0{runtime.LockOSThread();var attr struct{Type,Size uint32;Config,Period,Sample,Format,Flags uint64;Tail [16]byte};attr.Size=uint32(unsafe.Sizeof(attr));attr.Config=1;attr.Format=3;attr.Flags=1<<5|1<<6;var e syscall.Errno;freshFD,_,e=syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN,uintptr(unsafe.Pointer(&attr)),0,^uintptr(0),^uintptr(0),0,0);if e!=0{panic(e)}}
 var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,freshFD,uintptr(unsafe.Pointer(&v)),24);if e!=0||n!=24||v[1]!=v[2]||v[1]==0{panic("bad counter")};return v[0]}
func freshAdd(i int,t uint64){freshCosts[i]+=freshRead()-t;freshCounts[i]++}
func freshPrint(){freshAdd(5,freshRead());print("FRESH");for i:=range freshCosts {print(" ",freshCounts[i]," ",freshCosts[i]);freshCounts[i]=0;freshCosts[i]=0};println()}
''')
replacement[str(p/'smtcore/zz_fresh_study.go')]=str(helper)
ov=w/'fresh.json';ov.write_text(json.dumps({'Replace':replacement}))
exe=w/'fresh';subprocess.run(['go','build','-buildvcs=false','-pgo=off','-overlay',ov,'-o',exe,'./cmd/g3'],check=True)
h=Path('/tmp/g3-frame-child');gold={r['fixture']:r for r in csv.DictReader((h/'held-replay.csv').open()) if r['engine']=='z3'}
with (w/'fresh-cost.csv').open('w') as fo:
 out=csv.writer(fo);out.writerow(['fixture','round','operation','calls','instructions'])
 for i in range(3):
  for name in ['arm_rules3-6-5','arm_rules3-6-6']:
   r=subprocess.run(['taskset','-c','12',exe,'-in','-smt2'],input=(h/'held-fixtures'/(name+'.smt2')).read_bytes(),capture_output=True,check=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
   vals=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));assert r.stdout.startswith(b'unsat\n') and all(vals[k]==gold[name][k] for k in ['decisions','conflicts','quant-instantiations','rlimit-count'])
   totals=[0]*12
   for l in r.stderr.decode().splitlines():
    k,*vs=l.split();assert k=='FRESH' and len(vs)==12
    totals=[v+int(n) for v,n in zip(totals,vs)]
   for j,k in enumerate(['total','recursive-children','variable','enode','gate','empty']):out.writerow([name,i,k,*totals[j*2:j*2+2]])
   fo.flush()
