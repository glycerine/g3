from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
s=(w.parent/'fresh.py').read_text()
s=s.replace('freshTarget.IsNull() && basic','freshParent.IsNull() && basic')
s=s.replace('if boolean && !bound {track=true;freshTarget=argument;tick=freshRead()}','if boolean && !bound {freshParent=argument;parent=true}')
s=s.replace('track:=false;var tick uint64','parent:=false;track:=false;var tick uint64')
s=s.replace(" ''')\n k='return fmt.Errorf",''' if expression==freshParent && freshTarget.IsNull() {h,b,e:=s.manager.ExpressionHeader(argument);if e!=nil{panic(e)};_,bound:=s.boolVar.lookup(argument);if b && h.NumArgs==5 && h.Family==s.manager.BasicFamilyID() && !bound && s.context.enodes.get(argument)==nil {freshTarget=argument;track=true;println("ARITY5",h.DeclKind);tick=freshRead()}}
 \x27\x27\x27)
 k='return fmt.Errorf''')
s=s.replace('if track {freshAdd(0,tick);','if parent{freshParent=ast.ASTHandle{}}; if track {freshAdd(0,tick);')
s=s.replace('var freshTarget ast.ASTHandle','var freshParent,freshTarget ast.ASTHandle')
s=s.replace('totals=[0]*12','totals=[0]*12;ops={}').replace("k,*vs=l.split();assert","k,*vs=l.split()\n    if k=='ARITY5':ops[vs[0]]=ops.get(vs[0],0)+1;continue\n    assert").replace("for j,k in enumerate(['total'","for k,c in ops.items():out.writerow([name,i,'opcode-'+k,c,0])\n   for j,k in enumerate(['total'")
(w/'fresh.py').write_text(s)
subprocess.run([sys.executable,w/'fresh.py'],check=True)
