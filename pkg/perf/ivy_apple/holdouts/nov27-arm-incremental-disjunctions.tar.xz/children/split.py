from pathlib import Path
import sys,subprocess
w=Path(__file__).resolve().parent
s=(w.parent/'fresh.py').read_text()
k="return wrap(wrap(s,'attachBooleanEnode',3),'addGateConstraints',4)"
s=s.replace(k,'''k='if err = s.Internalize(argument, isGate); err != nil {'
 s=insert(s,k,"var costTick uint64;var bo,present,bound bool;var fam int32;var arity uint32;if direct {ah,b,e:=s.manager.ExpressionHeader(argument);if e!=nil{panic(e)};bo=b;fam=int32(ah.Family);arity=ah.NumArgs;present=s.context.enodes.get(argument)!=nil;_,bound=s.boolVar.lookup(argument);costTick=freshRead()};")
 s=insert(s,'if track {freshAdd(0,tick);', 'if direct {val:=freshRead()-costTick;println("CHILD",bo,fam,arity,present,bound,val)};')
 '''+k)
s=s.replace('totals=[0]*12','totals=[0]*12;cats={}').replace("k,*vs=l.split();assert",'''k,*vs=l.split()
    if k=='CHILD':
     key=tuple(vs[:-1]);c=cats.setdefault(key,[0,0]);c[0]+=1;c[1]+=int(vs[-1]);continue
    assert''').replace("for j,k in enumerate(['total'", "for key,c in cats.items():out.writerow([name,i,'/'.join(key),*c])\n   for j,k in enumerate(['total'")
(w/'fresh.py').write_text(s)
s=(w.parent/'native.py').read_text()
k="sub('bool is_new_var = false;'"
i=s.index(k)
s=s[:i]+'''k='internalize(arg, _is_gate);'
sub(k,\'''bool bo=false,present=false,bound=false;int family=0;unsigned arity=0;unsigned long long ct=0;if(direct){bo=m_manager.is_bool(arg);present=e_internalized(arg);bound=bo&&b_internalized(arg);family=is_app(arg)?(int)to_app(arg)->get_family_id():-1;arity=is_app(arg)?to_app(arg)->get_num_args():0;ct=freshRead();}\'''+k+\'''if(direct){auto value=freshRead()-ct;fprintf(stderr,"CHILD %s %d %u %s %s %llu\\\\n",bo?"true":"false",family,arity,present?"true":"false",bound?"true":"false",value);}\''')
'''+s[i:]
(w/'native.py').write_text(s)
subprocess.run([sys.executable,w/(sys.argv[1]+'.py')],check=True)
