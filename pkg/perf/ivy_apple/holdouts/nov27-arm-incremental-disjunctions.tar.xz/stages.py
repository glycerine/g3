from pathlib import Path
import csv,json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ex=Path('/home/jaten/ivy/ivy-lang-examples')
name='test/arm_rules3.ivy';src=Path('/tmp/g3-reduction-rows')
ref=src/'compat'/str((src/'compat.txt').read_text().splitlines().index(name)+1)/'1/native'
code=next(int(r['exit']) for r in csv.DictReader((src/'ranking.csv').open()) if r['case']==name)
for mode in ['base','iff']:
 ov=json.loads(Path('/tmp/g3-ticket-stages/translated.json').read_text())
 if mode=='iff':ov['Replace'].update(json.loads(Path('/tmp/g3-arm-equality/iff/rewrite.json').read_text())['Replace'])
 f=w/(mode+'.json');f.write_text(json.dumps(ov))
 subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',f,'-o',w/mode,'./cmd/goivy_check'],cwd=frontend,check=True)
with (w/'rows.csv').open('w') as fo:
 out=csv.writer(fo);out.writerow(['round','mode','batch','goal','stage','instructions'])
 expected={}
 for i in range(7):
  for mode in ['base','iff'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','14',w/mode,ex/name],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
   rows=[];raw=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'STAGE-COUNT '):
     _,b,g,s,n,empty,en,active,ns=l.decode().split();assert int(en)>0 and en==active;rows.append([b,g,s,int(n)])
    else:raw.append(l)
   assert (r.returncode,r.stdout,b''.join(raw))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
   keys=[r[:3] for r in rows];assert keys and expected.setdefault(mode,keys)==keys
   out.writerows([i,mode,*r] for r in rows);fo.flush()
