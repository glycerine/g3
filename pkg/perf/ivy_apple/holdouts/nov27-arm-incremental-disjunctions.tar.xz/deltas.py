"""Difference successive cumulative search counters within each incremental solver batch."""
from pathlib import Path
from collections import defaultdict
import csv
w=Path(__file__).resolve().parent
counts=defaultdict(dict)
for r in csv.DictReader((w/'counters.csv').open()):
 counts[r['mode'],int(r['batch']),int(r['goal'])][r['key']]=int(r['cumulative'])
prior={}
with (w/'search-deltas.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['mode','batch','goal','key','delta'])
 for (m,b,g),curr in sorted(counts.items()):
  last=prior.get((m,b),{})
  for k,n in curr.items():
   delta=n-last.get(k,0)
   out.writerow([m,b,g,k,delta])
  prior[m,b]=curr
