from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'smtcore/smt_internalizer.go';s=f.read_text();k='return s.relevancy.AddOrWatches(expression)';assert s.count(k)==1
s=s.replace(k,'''for _, arg := range arguments {
 if arg.Var() < SMTFirstBoolVar {return s.relevancy.AddOrWatches(expression)}
 }
 handler:=smtRelevancyHandler{kind:smtRelevancyOr,target:expression}
 for _,arg:=range arguments {if err:=s.relevancy.addWatch(s.boolExpr[arg.Var()],!arg.Sign(),&handler);err!=nil{return err}}
 return nil''')
dst=w/'watches.go.txt';dst.write_text(s);ov=w/'watch.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','release'])
