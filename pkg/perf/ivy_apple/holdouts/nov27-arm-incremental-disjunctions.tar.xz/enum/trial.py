from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'ast/rewriter/rewriter_configuration.go';s=f.read_text();k='case ast.ASTOpOr:\n\t\tif rw.flat';assert s.count(k)==1
s=s.replace(k,'case ast.ASTOpOr:\n if args.Count()>=3 && args.Count()<64 {status,err:=rw.enumComplement(args,out);if err!=nil || status!=brFailed{return status,err}}\n if rw.flat')+'\n'+(w/'enum.go.txt').read_text()
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'enum.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','release'])
