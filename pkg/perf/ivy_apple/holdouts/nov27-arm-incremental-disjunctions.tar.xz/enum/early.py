"""Rewrite membership in the declared op_type enum in the two recorded input files."""
from pathlib import Path
from dataclasses import dataclass
import re,sys,csv
w=Path(__file__).resolve().parent
src=Path('/tmp/g3-arm-equality/fixtures');out=w/'early';out.mkdir(exist_ok=True)
@dataclass
class Node:
 lo:int
 hi:int
 terms:tuple
 def key(self):return tuple(t.key() if isinstance(t,Node) else t for t in self.terms)
def key(x):return x.key() if isinstance(x,Node) else x
for file in sorted(src.glob('*.smt2')):
 s=file.read_text();stack=[];roots=[];edits=[]
 for m in re.finditer(r';[^\n]*|\|[^|]*\||"(?:[^"]|"")*"|\(|\)|[^\s();]+',s):
  t=m[0]
  if t.startswith(';'):continue
  if t=='(':stack.append((m.start(),[]))
  elif t==')':
   lo,ts=stack.pop();n=Node(lo,m.end(),tuple(ts));(stack[-1][1] if stack else roots).append(n)
  else:stack[-1][1].append(t)
 assert not stack
 assert roots[0].key()==('declare-datatypes',(('op_type','0'),),(('op_type',('nop',),('ld',),('st',),('lda',),('stl',)),))
 enum={'nop','ld','st','lda','stl'}
 def visit(n):
  if not isinstance(n,Node):return
  k=n.key()
  if k and k[0] in ('let','forall','exists'):
   assert all(v[0] not in enum for v in k[1])
  if len(k)==5 and k[0]=='or':
   members=set();terms=[]
   for v in n.terms[1:]:
    if not isinstance(v,Node) or len(v.terms)!=3 or v.terms[0]!='=':break
    a,b=v.terms[1:];a,b=(b,a) if isinstance(a,str) and a in enum else (a,b)
    if not isinstance(b,str) or b not in enum:break
    members.add(b);terms.append(a)
   if len(members)==4 and all(key(x)==key(terms[0]) for x in terms):
    a=terms[0];t=s[a.lo:a.hi] if isinstance(a,Node) else a;edits.append((n.lo,n.hi,'(not (= '+t+' '+(enum-members).pop()+'))'));return
  for x in n.terms:visit(x)
 for n in roots:visit(n)
 assert edits
 for lo,hi,v in reversed(edits):s=s[:lo]+v+s[hi:]
 (out/file.name).write_text(s);print(file.name,len(edits))
