from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'smtcore/smt_case_split_queue.go';s=f.read_text()
k='phase := false\n\tswitch q.phaseSelection';assert s.count(k)==1
s=s.replace(k,'''if data.IsEquality() && !data.PhaseAvailable() && q.phaseSelection != 1 && q.phaseSelection != 5 {
 return next,lbool.True,nil
 }
 '''+k)
dst=w/'phase.go.txt';dst.write_text(s);ov=w/'phase.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'polarity',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],7,['base','release'])
