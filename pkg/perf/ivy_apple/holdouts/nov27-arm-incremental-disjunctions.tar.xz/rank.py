"""Pair identical stage boundaries before aggregating the measured instruction differences."""
from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
rows=collections.defaultdict(lambda:collections.defaultdict(lambda:collections.Counter()))
for r in csv.DictReader((w/'rows.csv').open()):
 rows[int(r['round'])][r['mode']][int(r['batch']),int(r['goal']),r['stage']]+=int(r['instructions'])
assert len(rows)==7
for which,select in [('stage',lambda k:k),('goal',lambda k:k[:2]),('phase',lambda k:k[2:]),('total',lambda k:('all',))]:
 grouped=collections.defaultdict(list)
 for modes in rows.values():
  a=modes['base'];b=modes['iff'];assert a and b
  groups=collections.defaultdict(lambda:[0,0])
  for k in a.keys() | b.keys():
   v=groups[select(k)];v[0]+=a[k];v[1]+=b[k]
  for k,(x,y) in groups.items():grouped[k].append((x,y,y-x))
 with (w/(which+'.csv')).open('w') as f:
  out=csv.writer(f);out.writerow([*{'stage':['batch','goal','stage'],'goal':['batch','goal'],'phase':['phase'],'total':['scope']}[which],'base','iff','paired_difference'])
  for k,vs in sorted(grouped.items(),key=lambda t:-statistics.median(v[2] for v in t[1])):
   out.writerow([*k,*[statistics.median(v[i] for v in vs) for i in range(3)]])
