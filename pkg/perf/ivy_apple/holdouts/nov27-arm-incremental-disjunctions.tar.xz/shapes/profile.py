from pathlib import Path
import json,os,subprocess,csv,collections,re
w=Path(__file__).resolve().parent;p=Path.cwd();source=w.parent/'five';o=json.loads((source/'fresh.json').read_text())
f=p/'smtcore/smt_internalizer.go';s=Path(o['Replace'][str(f)]).read_text().replace('"slices"','"slices"\n"strings"');k='println("ARITY5",h.DeclKind)';assert s.count(k)==1
s=s.replace(k,'var builder strings.Builder; s.studyShape(argument,&builder,3);println("SHAPE",builder.String())')
s+='''
func (s *SMTInternalizerState) studyShape(h ast.ASTHandle,w *strings.Builder,depth int){
 a,e:=s.manager.NodeHeader(h);if e!=nil{panic(e)}
 if a.Family==ast.NullFamilyID && a.NumArgs==0 {w.WriteByte('_');return}
 if e=s.manager.DisplayDeclarationHead(w,a.Decl);e!=nil{panic(e)}
 if depth==0||a.NumArgs==0{return};w.WriteByte('(')
 for i:=uint32(0);i<a.NumArgs;i++{if i>0{w.WriteByte(',')};c,e:=s.manager.GetArg(h,i);if e!=nil{panic(e)};s.studyShape(c,w,depth-1)};w.WriteByte(')')
}
'''
dst=w/'shape.go.txt';dst.write_text(s);o['Replace'][str(f)]=str(dst);f=w/'shape.json';f.write_text(json.dumps(o))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',f,'-o',w/'cli','./cmd/g3'],check=True)
h=Path('/tmp/g3-frame-child');gold={r['fixture']:r for r in csv.DictReader((h/'held-replay.csv').open()) if r['engine']=='z3'}
with (w/'shapes.csv').open('w') as fo:
 out=csv.writer(fo);out.writerow(['goal','shape','calls'])
 for name in ['arm_rules3-6-5','arm_rules3-6-6']:
  r=subprocess.run(['taskset','-c','12',w/'cli','-in','-smt2'],input=(h/'held-fixtures'/(name+'.smt2')).read_bytes(),capture_output=True,check=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
  vals=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));assert r.stdout.startswith(b'unsat\n') and all(vals[k]==gold[name][k] for k in ['decisions','conflicts','quant-instantiations','rlimit-count'])
  counts=collections.Counter(l[6:] for l in r.stderr.decode().splitlines() if l.startswith('SHAPE '))
  assert sum(counts.values())=={'arm_rules3-6-5':2272,'arm_rules3-6-6':1856}[name]
  for k,n in counts.most_common():out.writerow([name,k,n])
