from pathlib import Path
import csv,json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ex=Path('/home/jaten/ivy/ivy-lang-examples');name='test/arm_rules3.ivy';src=Path('/tmp/g3-reduction-rows')
ref=src/'compat'/str((src/'compat.txt').read_text().splitlines().index(name)+1)/'1/native'
code=next(int(r['exit']) for r in csv.DictReader((src/'ranking.csv').open()) if r['case']==name)
h=Path('/tmp/g3-ticket-stages')
dst=w/'bridge.go.txt';s=(h/'translated.go.txt').read_text();k='end("check")';assert s.count(k)==1;dst.write_text(s.replace(k,k+'\n z3solver.StudyCounters(batch,ordinal+1)'))
method=w/'solver.go.txt';srcgo=frontend/'smt/g3_solver.go';method.write_text(srcgo.read_text()+'''
func (s *Z3Solver) StudyCounters(batch,goal int) {
 s.ctx.do(func(){
 st,e:=s.c.Statistics();fail(e);defer st.Close()
 size,e:=st.Size();fail(e)
 for i:=uint32(0);i<size;i++ {
 k,e:=st.Key(i);fail(e)
 switch k {case "decisions","conflicts","quant instantiations","rlimit count","propagations","mk bool var","mk clause":
 v,e:=st.UintValue(i);fail(e);println("SEARCH",batch,goal,k,"=",v)}
 }
 })
}
''')
with (w/'counters.csv').open('w') as fo:
 out=csv.writer(fo);out.writerow(['mode','batch','goal','key','cumulative'])
 for mode in ['base','iff']:
  ov=json.loads((h/'translated.json').read_text());ov['Replace'][str(frontend/'z3bridge_solver_model.go')]=str(dst);ov['Replace'][str(srcgo)]=str(method)
  if mode=='iff':ov['Replace'].update(json.loads(Path('/tmp/g3-arm-equality/iff/rewrite.json').read_text())['Replace'])
  f=w/(mode+'-search.json');f.write_text(json.dumps(ov));exe=w/(mode+'-search')
  subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',f,'-o',exe,'./cmd/goivy_check'],cwd=frontend,check=True)
  r=subprocess.run(['taskset','-c','12',exe,ex/name],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
  raw=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'SEARCH '):
    _,batch,g,rest=l.decode().strip().split(' ',3);key,value=rest.split(' = ');out.writerow([mode,batch,g,key,value])
   elif not l.startswith(b'STAGE-COUNT '):raw.append(l)
  assert (r.returncode,r.stdout,b''.join(raw))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),raw[:4];fo.flush()
