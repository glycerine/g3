from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
a=p/'ast/rewriter/th_rewriter.go';k=p/'ast/macros/macro_expander.go';s=a.read_text()
key='func NewTheoryRewriter(m *ast.ASTManager, context *uparams.ParamsContext, globals *uparams.GlobalParamsService, local *uparams.ParamsRef) (*TheoryRewriter, error) {'
s=s.replace(key,key+'''
 return trialNewRewriter(m,context,globals,local,false)
}
func TrialMacroRewriter(m *ast.ASTManager,context *uparams.ParamsContext,globals *uparams.GlobalParamsService,local *uparams.ParamsRef)(*TheoryRewriter,error){
 return trialNewRewriter(m,context,globals,local,true)
}
func trialNewRewriter(m *ast.ASTManager,context *uparams.ParamsContext,globals *uparams.GlobalParamsService,local *uparams.ParamsRef,lazy bool)(*TheoryRewriter,error){
''')
s=s.replace('bitVector            *BVRewriter','bitVector            *BVRewriter\n trialFamily ast.FamilyID\n trialLazy bool').replace('r.configuration.owner = r','r.configuration.trialLazy=lazy\n r.configuration.owner = r',1)
key='if c.bitVector, err = NewBVRewriter(r.manager, r.context, legacy, r.local); err != nil {\n\t\treturn err\n\t}'
assert s.count(key)==1
s=s.replace('c.bitVector.bvFamily','c.trialFamily').replace(key,'''if c.trialLazy {
    if c.trialFamily,err=r.manager.BitVectorUtilityFamilyID();err!=nil{return err}
 } else {
    if c.bitVector,err=NewBVRewriter(r.manager,r.context,legacy,r.local);err!=nil{return err}
    c.trialFamily=c.bitVector.bvFamily
 }''')
s+='''
func (c *theoryRewriterConfiguration) trialEnsureBV()error {
 if c.bitVector!=nil{return nil};r:=c.owner
 legacy,err:=r.globals.Manager();if err!=nil{return err}
 c.bitVector,err=NewBVRewriter(r.manager,r.context,legacy,r.local);return err
}
'''
for a1 in ['status, err = c.bitVector.RewriteEquality(', 'if status, err := c.bitVector.RewriteIte(', 'return c.bitVector.RewriteApp(']:
 s=s.replace(a1,'if err:=c.trialEnsureBV();err!=nil{return RewriteFailed,err};'+a1)
s=s.replace('if err := r.configuration.bitVector.polynomial.config.UpdateBitVector','if err:=r.configuration.trialEnsureBV();err!=nil{return err};if err := r.configuration.bitVector.polynomial.config.UpdateBitVector')
files={}
for src,txt in [(a,s),(k,k.read_text().replace('rewriter.NewTheoryRewriter(', 'rewriter.TrialMacroRewriter('))]:
 dst=w/src.name;dst.write_text(txt);files[str(src)]=str(dst)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
