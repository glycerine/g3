from pathlib import Path
import sys, subprocess, json,shlex,re,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();engine=sys.argv[1];front,mod=map(lambda x:Path(x).resolve(),sys.argv[2:4])
def rep(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(n,s):
    path=w/n;path.write_text(s);return str(path)
files={}
stage=(w/'phase.go.txt').read_text()
files[str(front/'phase_observer_trial.go')]=save(engine+'-stage.go',stage.replace('start := time.Now()', 'os.Setenv("PASS_FD",fmt.Sprint(fd));start := time.Now()').replace('elapsed := time.Since(start)','os.Unsetenv("PASS_FD");elapsed := time.Since(start)'))
files[str(front/'z3bridge_solver_model.go')]=str(w/(engine+'-bridge.go.txt'))
if engine=='ordinary':
 k=p/'smtcore/smt_asserted_macros.go';s=rep(k.read_text(),'"fmt"','"fmt"\n "os"\n "strconv"\n "syscall"\n "unsafe"')
 s+='''
func passFD() int {v,e:=strconv.Atoi(os.Getenv("PASS_FD"));if e!=nil{return -1};return v}
func passRead(fd int) int64 {if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if n!=24||e!=0||c[1]!=c[2]{panic("counter")};return int64(c[0])}
func passLog(fd int,args ...any){if fd>=0{fmt.Fprint(os.Stderr,"PASS ");fmt.Fprintln(os.Stderr,args...)}}
'''
 s=rep(s,'inputs := make([]macros.Formula','fd:=passFD();before:=k.assertedMacros.NumMacros();a,b:=passRead(fd),passRead(fd);inputs := make([]macros.Formula')
 s=s.replace('return k.replacePendingMacroBatch(batch)','''first:=passRead(fd)-2*b+a;eq:=0
 for i,row:=range inputs {if i<batch.Len()&&batch.MatchesJustification(i,row.Expression,row.Proof){eq++}}
 a,b=passRead(fd),passRead(fd);err=k.replacePendingMacroBatch(batch);second:=passRead(fd)-2*b+a
 passLog(fd,"macro",len(inputs),batch.Len(),eq,before,k.assertedMacros.NumMacros(),first,second)
 return err''',1)
 files[str(k)]=save(k.name,s)
 k=p/'smtcore/smt_asserted_propagate.go';s=rep(k.read_text(),'one, result = k.rewritePendingAssertion(i)','fd:=passFD();a,b:=passRead(fd),passRead(fd);one, result = k.rewritePendingAssertion(i);first:=passRead(fd)-2*b+a')
 s=rep(s,'result = k.addAssertionSubstitution(k.assertions[i], depth)','a,b=passRead(fd),passRead(fd);result = k.addAssertionSubstitution(k.assertions[i], depth);second:=passRead(fd)-2*b+a;did:=0;if one {did=1};passLog(fd,"value",i-k.assertedHead,len(k.assertions)-k.assertedHead,did,0,0,first,second)')
 files[str(k)]=save(k.name,s)
else:
 k=p.parent/'src/smt/asserted_formulas.cpp'
 s='''#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include <cstdint>
static int passfd(){auto v=std::getenv("PASS_FD");return v?std::atoi(v):-1;}
static int64_t rd(int f){if(f<0)return 0;uint64_t c[3];if(read(f,c,24)!=24||c[1]!=c[2])std::abort();return c[0];}
'''+k.read_text()
 a=s.index('void asserted_formulas::find_macros_core()');b=s.index('void asserted_formulas::expand_macros()',a);part=s[a:b]
 part=rep(part,'vector<justified_expr> new_fmls;', 'int fd=passfd(); unsigned before=m_macro_manager.get_num_macros();auto a=rd(fd),b=rd(fd);vector<justified_expr> new_fmls;')
 part=rep(part,'swap_asserted_formulas(new_fmls);','''auto first=rd(fd)-2*b+a; unsigned cnt=sz-m_qhead, eq=0,n=new_fmls.size();
 for(unsigned i=0;i<cnt&&i<n;++i) if(new_fmls[i].get_fml()==m_formulas[m_qhead+i].get_fml()&&new_fmls[i].get_proof()==m_formulas[m_qhead+i].get_proof()) ++eq;
 a=rd(fd);b=rd(fd);swap_asserted_formulas(new_fmls);''')
 part=rep(part,'reduce_and_solve();','reduce_and_solve(); auto second=rd(fd)-2*b+a;if(fd>=0)std::fprintf(stderr,"PASS macro %u %u %u %u %u %lld %lld\\n",cnt,n,eq,before,m_macro_manager.get_num_macros(),(long long)first,(long long)second);')
 s=s[:a]+part+s[b:]
 s=rep(s,'unsigned asserted_formulas::propagate_values(unsigned i) {','unsigned asserted_formulas::propagate_values(unsigned i) { int fd=passfd();auto a=rd(fd),b=rd(fd);')
 s=rep(s,'update_substitution(new_n, new_pr);','auto first=rd(fd)-2*b+a;a=rd(fd);b=rd(fd);update_substitution(new_n, new_pr);auto second=rd(fd)-2*b+a;if(fd>=0)std::fprintf(stderr,"PASS value %u %u %u 0 0 %lld %lld\\n",i-m_qhead,m_formulas.size()-m_qhead,(unsigned)(n!=new_n),(long long)first,(long long)second);')
 build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 obj=w/'asserted_formulas.o';subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,save(k.name,s)],cwd=build,check=True)
 lib=w/'libpass.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
 k=front/'smt/quantifier.go';files[str(k)]=save('quantifier.go',rep(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=save(engine+'.json',json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if engine=='native' else ''),'-overlay',ov,'-o',w/engine,'./cmd/goivy_check'],cwd=front,check=True)
