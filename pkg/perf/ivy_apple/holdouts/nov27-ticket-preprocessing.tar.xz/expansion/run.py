from pathlib import Path
import csv,sys,os,json,subprocess
w=Path(__file__).resolve().parent
gold,ex=map(Path,sys.argv[1:3]);eng=sys.argv[3]
spec=ex/json.loads((gold/'cases.json').read_text())['ticket_protocol'][0];ref=gold/'reference/ticket_protocol'
env=dict(os.environ,GOMAXPROCS='1',GOGC='off',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1')
with (w/(eng+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('round batch goal stage operation index_or_input size_or_output changed_or_same before after first second'.split())
 for n in range(5):
    r=subprocess.run(['taskset','-c',sys.argv[4],w/eng,spec],cwd=w,env=env,capture_output=True,check=True,timeout=120)
    pending=[];clean=bytearray();checks=0
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'PASS '):pending.append(line.decode().split()[1:])
        elif line.startswith(b'STAGE-COUNT '):
            _,b,g,stage,*_=line.decode().split()
            checks+=stage=='check'
            out.writerows([[n,b,g,stage,*v] for v in pending]);pending.clear()
        else:clean.extend(line)
    assert not pending and checks==284 and r.stdout==(ref/'stdout').read_bytes() and clean==(ref/'stderr').read_bytes(),(pending[:1],checks,clean[:300])
