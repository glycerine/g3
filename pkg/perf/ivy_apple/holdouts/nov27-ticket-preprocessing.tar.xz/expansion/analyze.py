from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
counts=collections.defaultdict(collections.Counter);keys=collections.defaultdict(list)
for eng in ('ordinary','native'):
 for r in csv.DictReader((w/(eng+'.csv')).open()):
    n,b,g=map(int,(r['round'],r['batch'],r['goal']))
    if r['stage']!='check' or (2<=b<=5 and g in (55,56)) or (6<=b<=8 and g==1):continue
    rounds,defs,changed,_,_,first,second=map(int,list(r.values())[5:])
    keys[eng,n,b,g].append((defs,changed))
    c=counts[eng,changed,n];c['calls']+=1;c['passes']+=rounds;c['expand']+=first;c['norm']+=second;c['normalized']+=second!=0
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','changed','calls','passes','expand','norm','normalized'])
 for eng in ('ordinary','native'):
    for changed in (0,1):
        v=[int(statistics.median(counts[eng,changed,r][s] for r in range(5))) for s in ('calls','passes','expand','norm','normalized')]
        out.writerow([eng,changed,*v]);print(eng,changed,v)
pair={(b,g) for e,n,b,g in keys}
print('mismatched definition count/change sequence',[k for k in sorted(pair) if keys[('ordinary',0)+k]!=keys[('native',0)+k]])
