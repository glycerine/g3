from pathlib import Path
import sys, subprocess, json,shlex,re,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();engine=sys.argv[1];front,mod=map(lambda x:Path(x).resolve(),sys.argv[2:4])
def rep(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(n,s):
    path=w/n;path.write_text(s);return str(path)
files={}
stage=(w.parent/'phase.go.txt').read_text()
files[str(front/'phase_observer_trial.go')]=save(engine+'-stage.go',stage.replace('start := time.Now()', 'os.Setenv("PASS_FD",fmt.Sprint(fd));start := time.Now()').replace('elapsed := time.Since(start)','os.Unsetenv("PASS_FD");elapsed := time.Since(start)'))
files[str(front/'z3bridge_solver_model.go')]=str(w.parent/(engine+'-bridge.go.txt'))
if engine=='ordinary':
 k=p/'ast/macros/macro_expander.go';s=rep(k.read_text(),'"errors"','"errors"\n "os"\n "fmt"\n "syscall"\n "strconv"\n "unsafe"')
 s+='''
func passFD() int {v,e:=strconv.Atoi(os.Getenv("PASS_FD"));if e!=nil{return -1};return v}
func passRead(fd int) int64 {if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if n!=24||e!=0||c[1]!=c[2]{panic("counter")};return int64(c[0])}
func passLog(fd int,args ...any){if fd>=0{fmt.Fprint(os.Stderr,"PASS ");fmt.Fprintln(os.Stderr,args...)}}
'''

 key='if err := m.manager.SetRef(out, term); err != nil {'
 idx=s.index(key,s.index('func (m *Manager) ExpandMacros('))
 s=s[:idx]+"""fd:=passFD();a,b:=passRead(fd),passRead(fd);var cutoff int64;rounds:=0
 defer func(){
    end:=passRead(fd)-2*b+a;var norm int64;if cutoff!=0{norm=end-cutoff}else{cutoff=end}
    got,err:=m.manager.RefGet(out);if err!=nil{panic(err)};did:=0;if got!=term{did=1}
    passLog(fd,"expand",rounds,m.NumMacros(),did,0,0,cutoff,norm)
 }()
 """+s[idx:]
 s=rep(s,'cfg := &macroExpanderConfig{owner: m}','rounds++;cfg := &macroExpanderConfig{owner: m}')
 s=rep(s,'normalizer, err := newMacroTheoryNormalizer','cutoff=passRead(fd)-2*b+a;normalizer, err := newMacroTheoryNormalizer')
 files[str(k)]=save(k.name,s)
else:
 k=p.parent/'src/ast/macros/macro_manager.cpp'
 s='''#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include <cstdint>
static int passfd(){auto v=std::getenv("PASS_FD");return v?std::atoi(v):-1;}
static int64_t rd(int f){if(f<0)return 0;uint64_t c[3];if(read(f,c,24)!=24||c[1]!=c[2])std::abort();return c[0];}
'''+k.read_text()

 k1='void macro_manager::expand_macros('
 idx=s.index('{',s.index(k1))+1
 s=s[:idx]+'''int fd=passfd();auto a=rd(fd),b=rd(fd);int64_t cutoff=0;unsigned rounds=0;
 '''+s[idx:]
 s=rep(s,'macro_expander_rw proc(m, *this);','++rounds;macro_expander_rw proc(m, *this);')
 s=rep(s,'th_rewriter rw(m);','cutoff=rd(fd)-2*b+a;th_rewriter rw(m);')
 idx=s.rindex('}',s.index(k1))
 s=s[:idx]+'''auto end=rd(fd)-2*b+a;auto norm=cutoff?end-cutoff:0;
 if(fd>=0)std::fprintf(stderr,"PASS expand %u %u %u 0 0 %lld %lld\\n",rounds,get_num_macros(),(unsigned)(r.get()!=n),(long long)(cutoff?cutoff:end),(long long)norm);
 '''+s[idx:]
 build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_13 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 obj=w/'macro_manager.o';subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,save(k.name,s)],cwd=build,check=True)
 lib=w/'libpass.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
 k=front/'smt/quantifier.go';files[str(k)]=save('quantifier.go',rep(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=save(engine+'.json',json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if engine=='native' else ''),'-overlay',ov,'-o',w/engine,'./cmd/goivy_check'],cwd=front,check=True)
