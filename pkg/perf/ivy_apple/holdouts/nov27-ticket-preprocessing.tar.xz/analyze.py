"""Disjoint finder and value-row intervals; compare order and outcome in all five rounds."""
import csv,collections,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
sums=collections.defaultdict(collections.Counter);seen=collections.defaultdict(list)
for eng in ['ordinary','native']:
 for r in csv.DictReader((w/(eng+'.csv')).open()):
    rnd,b,g=map(int,(r['round'],r['batch'],r['goal']))
    if r['stage']!='check' or (2<=b<=5 and g in [55,56]) or (b in [6,7,8] and g==1):continue
    op=r['operation'];i,size,d,before,after,a,z=map(int,list(r.values())[5:])
    seen[eng,rnd,b,g,op].append((i,size,d,before,after))
    typ=('same' if i==size==d else 'changed') if op=='macro' else ('changed' if d else 'same')
    for label in [typ,'all']:
        c=sums[eng,rnd,op,label];c['calls']+=1;c['first']+=a;c['second']+=z
stats={}
for eng in ['ordinary','native']:
 for op in ['macro','value']:
    for typ in ['same','changed','all']:
        rows=[sums[eng,r,op,typ] for r in range(5)]
        stats[eng,op,typ]=[int(statistics.median(c[k] for c in rows)) for k in ['calls','first','second']]
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('operation change engine calls first second'.split())
 for (eng,op,typ),row in stats.items():out.writerow([op,typ,eng,*row])
for op in ['macro','value']:
 keys=sorted({(b,g) for eng,n,b,g,k in seen if k==op})
 mismatch=[]
 for b,g in keys:
    for eng in ['ordinary','native']:
        assert all(seen[eng,r,b,g,op]==seen[eng,0,b,g,op] for r in range(5))
    if seen['ordinary',0,b,g,op]!=seen['native',0,b,g,op]:mismatch.append((b,g))
 print(op,len(keys),'participating checks, mismatches',mismatch)
for eng in ['ordinary','native']:
 r=[v for (e,n,b,g,o),xs in seen.items() if e==eng and n==0 and o=='macro' for v in xs]
 print(eng,'macro input rows',sum(x[0] for x in r),'output rows',sum(x[1] for x in r),'same positions',sum(x[2] for x in r),'definition changes',sum(x[3]!=x[4] for x in r))
