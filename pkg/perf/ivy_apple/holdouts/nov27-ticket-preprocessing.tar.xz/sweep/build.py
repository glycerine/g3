from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
src=p/'smtcore/smt_asserted_propagate.go';s=src.read_text()
k='if result == nil {\n\t\t\t\t\tresult = k.addAssertionSubstitution'
assert s.count(k)==1;s=s.replace(k,'if result == nil && step+1 < len(k.assertions)-k.assertedHead {\n\t\t\t\t\tresult = k.addAssertionSubstitution')
dst=w/src.name;dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags','xtrace_off','-overlay',ov,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
