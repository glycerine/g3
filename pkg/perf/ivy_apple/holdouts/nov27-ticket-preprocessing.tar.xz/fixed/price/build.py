from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;root=w.parent.parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
files=json.loads((root/'expansion/ordinary.json').read_text())['Replace'];s=(root/'expansion/macro_expander.go').read_text();trial=(w.parent/'macro_expander.go').read_text()
a=trial.index('\t\t// oldTerm and out both hold');b=trial.index('\n\t}\n\tif !changed',a)
key='\t\tchanged = true\n\t}\n\tif !changed'
assert s.count(key)==1
s=s.replace(key,'\t\tchanged = true\n'+trial[a:b]+'\n\t}\n\tif !changed')
dst=w/'macro_expander.go';dst.write_text(s);files[str(p/'ast/macros/macro_expander.go')]=str(dst)
ov=w/'overlay.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'ordinary','./cmd/goivy_check'],cwd=front,check=True)
