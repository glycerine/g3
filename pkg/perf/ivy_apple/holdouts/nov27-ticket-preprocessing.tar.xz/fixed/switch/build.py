from pathlib import Path
import subprocess,sys,json
w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3]);src=Path.cwd()/'ast/macros/macro_expander.go'
s=(w.parent/src.name).read_text().replace('"errors"','"errors"\n "os"')
s=s.replace('if m.chargeUnchangedExpansion(next) {','if trialFinalProbe && m.chargeUnchangedExpansion(next) {')
s+='\nvar trialFinalProbe=os.Getenv("MACRO_FINAL_PROBE")=="on"\n'
# Keep the additional reference read in the trial arm, just as in the two release binaries.
s=s.replace('next, err := m.manager.RefGet(oldTerm)','if trialFinalProbe {next, err := m.manager.RefGet(oldTerm)').replace('if trialFinalProbe && m.chargeUnchangedExpansion(next) {\n\t\t\tbreak\n\t\t}', 'if m.chargeUnchangedExpansion(next) {break}}')
dst=w/src.name;dst.write_text(s);ov=w/'switch.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'both','./cmd/goivy_check'],cwd=front,check=True)
