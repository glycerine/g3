from pathlib import Path
import subprocess,sys,os
w=Path(__file__).resolve().parent;exe,ex,out=map(Path,sys.argv[1:])
r=subprocess.run(['taskset','-c','19',exe,ex/'examples/liveness/tlb.ivy'],env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),cwd=w,capture_output=True,timeout=180)
assert r.returncode==1 and r.stderr==b'error: failed checks: 2\n',(r.returncode,r.stderr[:300])
(out/'stdout').write_bytes(r.stdout);(out/'stderr').write_bytes(r.stderr);print(len(r.stdout))
