from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
src=p/'ast/macros/macro_expander.go';s=src.read_text();needle='\t\tchanged = true\n\t}\n\tif !changed {'
assert s.count(needle)==1
s=s.replace(needle,'''		changed = true
		// oldTerm and out both hold the expanded expression. A macro-free
		// fixed point can charge the final traversal before normalization.
		next, err := m.manager.RefGet(oldTerm)
		if err != nil {
			return resultDependency, err
		}
		if m.chargeUnchangedExpansion(next) {
			break
		}
	}
	if !changed {''')
dst=w/src.name;dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
