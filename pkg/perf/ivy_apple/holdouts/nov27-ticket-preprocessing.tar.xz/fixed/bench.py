from pathlib import Path
import csv,subprocess,re,os
w=Path(__file__).resolve().parent
with (w/'bench.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','build','case','ns','bytes','allocs'])
 for n in range(9):
    for eng in ['base','trial'][::1 if n%2==0 else -1]:
        r=subprocess.check_output(['taskset','-c','17',w/(eng+'.test'),'-test.run=^$','-test.bench=^BenchmarkMacroExpansion$','-test.benchtime=3000x','-test.benchmem'],text=True,env=dict(os.environ,GOMAXPROCS='1'))
        matches=re.findall(r'BenchmarkMacroExpansion/(\w+)(?:-\d+)?\s+3000\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r)
        assert len(matches)==5,r
        for m in matches:out.writerow([n,eng,*m])
