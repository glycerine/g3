from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
k=p/'smtcore/smt_asserted_macros.go';a=p/'ast/macros/macro_finder.go'
s=a.read_text()+'''
// Trial first pass over rows kept alive by the solver's assertion vector.
func (f *Finder) TrialBorrowed(input []Formula) (*FormulaBatch,error) {
    current,found,err:=f.pass(&FormulaBatch{rows:input})
    if err!=nil{return nil,err}
    for found {
        next,again,e:=f.pass(current)
        if e!=nil{return nil,errors.Join(e,current.Close())}
        if e=current.Close();e!=nil{return nil,errors.Join(e,next.Close())}
        current,found=next,again
    }
    return current,nil
}
'''
files={}
for src,txt in [(a,s),(k,k.read_text().replace('finder.Apply(inputs)','finder.TrialBorrowed(inputs)'))]:
 dst=w/src.name;dst.write_text(txt);files[str(src)]=str(dst)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
