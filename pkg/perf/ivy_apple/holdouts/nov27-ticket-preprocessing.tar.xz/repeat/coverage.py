import csv,subprocess,os,sys,json,collections
from pathlib import Path
w=Path(__file__).resolve().parent;gold,ex=map(Path,sys.argv[1:3]);cases=json.loads((gold/'cases.json').read_text())
with (w/'coverage.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','rows','calls'])
 for c in ('ticket_protocol','hybrid','arm_rules3','fba'):
    spec,iso,code=cases[c];ref=gold/'reference'/c
    r=subprocess.run(['taskset','-c','17',w/'observe']+(['isolate='+iso] if iso else [])+[ex/spec],cwd=w,env=dict(os.environ,GOGC='off',GOIVY_INCLUDE=str(ex/'ivy/include'),GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True,timeout=180)
    counts=collections.Counter();clean=bytearray()
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'SAME-MACRO '):counts[int(line.split()[1])]+=1
        else:clean.extend(line)
    assert (r.returncode,r.stdout,clean)==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    for size,count in sorted(counts.items()):out.writerow([c,size,count])
    print(c,sum(counts.values()))
