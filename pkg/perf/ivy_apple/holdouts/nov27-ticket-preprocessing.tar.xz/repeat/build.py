from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3]);mode=sys.argv[3]
files={}
def store(name,mut):
 src=p/'smtcore'/name;s=src.read_text();t=mut(s);assert t!=s
 dst=w/(mode+'-'+name);dst.write_text(t);files[str(src)]=str(dst)
# Snapshot kept on the stack for a single reduce call; the kernel only borrows it until that call returns.
store('smt_kernel.go',lambda s:s.replace('skipRepeatedPreprocessing bool','passTrial *macroTrial\n skipRepeatedPreprocessing bool'))
store('smt_asserted_driver.go',lambda s:s.replace('if k.assertedMacros.HasMacros() {','''var memo macroTrial;old:=k.passTrial;k.passTrial=&memo;defer func(){k.passTrial=old}()
 if k.assertedMacros.HasMacros() {''',1))
def macros(s):
 s=s.replace('func (k *SMTKernel) findPendingMacros()', '''type macroTrial struct{n,defs int; rows [16]SMTKernelAssertion}
func (t *macroTrial) same(rows []SMTKernelAssertion,defs int)bool{
 if t==nil || len(rows)==0 || len(rows)!=t.n || defs!=t.defs{return false}
 return slices.Equal(t.rows[:t.n],rows)
}
func (k *SMTKernel) findPendingMacros()''')
 s=s.replace('inputs := make([]macros.Formula','''incoming:=k.assertions[k.assertedHead:];t:=k.passTrial;defs:=k.assertedMacros.NumMacros()
 if t.same(incoming,defs){'''+('''fmt.Fprintln(os.Stderr,"SAME-MACRO",len(incoming))''' if mode=='observe' else '''return k.reduceAndSolveAssertions()''')+'''}
 if t!=nil {t.n=0}
 inputs := make([]macros.Formula''',1)
 needle='return k.replacePendingMacroBatch(batch)'
 s=s.replace(needle,'''if t!=nil && len(incoming)<=len(t.rows) && len(incoming)==batch.Len() && defs==k.assertedMacros.NumMacros(){
    same:=true;for i,old:=range incoming {if !batch.MatchesJustification(i,old.Formula,old.Proof){same=false;break}}
    if same{t.n=copy(t.rows[:],incoming);t.defs=defs}
 }
 '''+needle,1)
 return s.replace('"fmt"','"fmt"\n "os"') if mode=='observe' else s
store('smt_asserted_macros.go',macros)
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags','xtrace_off','-overlay',ov,'-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
