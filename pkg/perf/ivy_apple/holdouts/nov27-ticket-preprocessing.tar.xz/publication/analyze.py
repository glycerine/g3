from pathlib import Path
import collections,csv,statistics
w=Path(__file__).resolve().parent
summary=collections.defaultdict(lambda:[0,0,0]);series=collections.defaultdict(list)
for e in ['ordinary','native']:
 for r in csv.DictReader((w/(e+'.csv')).open()):
    n,b,g=map(int,(r['round'],r['batch'],r['goal']))
    if r['operation']!='publish' or r['stage']!='check' or 2<=b<=5 and g in (55,56) or 6<=b<=8 and g==1:continue
    found,published,same,priorSame,priorCount,a,z=map(int,list(r.values())[5:])
    series[e,n,b,g].append((found,published,same,priorSame,priorCount))
    d=summary[e,n,priorCount==found==priorSame,found==published==same];d[0]+=1;d[1]+=a;d[2]+=z
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('engine finder_unchanged reduction_unchanged calls discovery publication'.split())
 for k in sorted({(e,p,q) for e,n,p,q in summary}):
    e,p,q=k;rr=[summary[e,n,p,q] for n in range(5)]
    row=[*k,*[int(statistics.median(x[i] for x in rr)) for i in range(3)]]
    out.writerow(row);print(row)
keys={(b,g) for e,n,b,g in series}
print('ordered outcome mismatches',[(b,g) for b,g in sorted(keys) if series['ordinary',0,b,g]!=series['native',0,b,g]])
