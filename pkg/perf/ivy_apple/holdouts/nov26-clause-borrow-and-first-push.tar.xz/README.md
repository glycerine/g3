# Clause borrowing trials and first-push rewrite census

All patches apply to the pkg directory at 47792d65b and are independent
experiments. Production at this revision borrows references during a local
scan and stores all clause bytes in the arena. The three alternatives add
a lookup directory to that allocator. borrow caches []byte plus generation
for views. scalar uses that representation for scalar word reads too.
borrow16 also serves scalar reads and stores pointer, length and generation
in 16 bytes. Release and construction-failure cleanup clear directory
entries when the arena consumes the block. These prototypes are unshipped.

Use pkg/perf/ivy_raft/watch_propagation.py with --case pigeon8 --permutations 3
--rounds 3 to reproduce. The raw rows preserve solver paths, CPU-independent
instruction measurements, cycles, elapsed time, decisions and conflicts.
For layout memory use BenchmarkSATClauseBorrowPopulation with GOMAXPROCS=1.
Each reported observation includes live arena and directory bytes across 24
workers at 2,048 clauses per worker and excludes the original reference slice.
The sampled profiles used the committed g3 on CPU 14 and a user-mode period
of 1,999,993 instructions. Neither profile had throttle or loss records.

The observer patch counts work on the outer internalizePushBase path when
the kernel is at depth zero. A key includes exact formula and proof handles,
substitution revision, transformation mode and the AND-elimination setting.
It counts successful repeated roots with matching results and the resource
steps used by those calls. It records an ordinal for every observed call,
including private solvers whose first push performed no assertion rewrites.
The 9 nonempty Ticket and 34 nonempty hybrid rows match the number of
physical first pushes in the independent frontend phase counters. The
observer leaves the ordinary operations in place. Both transcripts matched.

The quiet timing rows use the paired GoIvy build recorded in pair/build.json
and its local source replacement. Each spec made three qualifying rotations.
The complete Apple ord_live2 rotation was still running when this archive
was made. The full-suite log covers 114 tracked Go package directories at the
subsumption release. Ignored experiment source overlays live under build.
