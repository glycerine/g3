from pathlib import Path
import subprocess,json,os,csv,collections
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();src=p/'smtcore/smt_cg_table.go'
s=src.read_text().replace('b.wide = make(map[uint64][]*SMTEnode)','println("CG-WIDE")\n b.wide = make(map[uint64][]*SMTEnode)').replace('bucket := &smtCongruenceBucket{','println("CG-REGISTER")\n bucket := &smtCongruenceBucket{')
dst=w/'maps.go.txt';dst.write_text(s);ov=w/'maps.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}));exe=w/'maps'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');gold=Path('/tmp/g3-reduction-rows');names=(gold/'compat.txt').read_text().splitlines()
with (w/'maps.csv').open('w') as dest:
 out=csv.writer(dest);out.writerow('input registered used_wide unused_wide'.split())
 for nr in [2,3,6,8,12]:
  ref=gold/'compat'/str(nr)/'1/native'
  r=subprocess.run([exe,ex/names[nr-1]],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True)
  n=collections.Counter();err=bytearray()
  for line in r.stderr.splitlines(keepends=True):
   if line in [b'CG-REGISTER\n',b'CG-WIDE\n']:n[line.strip()]+=1
   else:err.extend(line)
  assert (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
  out.writerow((nr,n[b'CG-REGISTER'],n[b'CG-WIDE'],n[b'CG-REGISTER']-n[b'CG-WIDE']));dest.flush()
