from pathlib import Path
import subprocess,csv,collections,os
w=Path(__file__).resolve().parent;ex=Path('/home/jaten/ivy/ivy-lang-examples');gold=Path('/tmp/g3-reduction-rows');ns=(gold/'compat.txt').read_text().splitlines()
with (w/'sites.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case target sibling site draws round instances operands'.split())
 for nr,target,tag,advance in [(3,'4/55','4/4',6),(3,'4/55','4/17',1),(6,'14/44','14/31',8),(6,'14/44','14/43',130),(8,'12/8','12/6',16)]:
  ref=gold/'compat'/str(nr)/'1/native'
  for site in ["neither","initial","decision","all"]:
   v=advance
   for i in range(2):
    r=subprocess.run(['taskset','-c','10',w/'sites',ex/ns[nr-1]],cwd=w,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1',DRAW_GOAL=tag,ACTION_SCOPE='draw'+str(v),TICKET_TARGET=target,RNG_SITE=site))
    err=bytearray();n=collections.Counter();events=[];hit=None
    for line in r.stderr.splitlines(keepends=True):
     if line.startswith(b'IC-PRICE '):
      _,k,c,_=line.split();n[int(k)]+=int(c)
     elif line.startswith(b'STUDY-DRAW '):events.append(int(line.split()[1]))
     elif line.startswith(b'STAGE-COUNT '):
      _,b,g,stage,num,empty,en,active,ns_=line.decode().split();assert en==active
      if b+'/'+g==target and stage=='check':hit=n.copy()
      n.clear()
     else:err.extend(line)
    assert events==[v] and hit and (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(nr,events,err[:300])
    out.writerow((nr,target,tag,site,v,i,hit[14],hit[6]));f.flush()
