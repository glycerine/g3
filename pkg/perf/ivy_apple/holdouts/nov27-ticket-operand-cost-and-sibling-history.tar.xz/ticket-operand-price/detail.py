"""Build a per-instance Boolean/term call census in the two matching frontends."""
from pathlib import Path
import json,subprocess,sys,re,shlex,shutil
p=Path.cwd();w=Path(__file__).resolve().parent
e=sys.argv[1];front,mod,stage=map(lambda x:Path(x).resolve(),sys.argv[2:])
files=json.loads(stage.read_text())['Replace']
def change(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
def write(k,s):
 d=w/('detail-'+e+'-'+k.name);d.write_text(s);files[str(k)]=str(d)

k=front/'phase_observer_trial.go';s=Path(files[str(k)]).read_text()
a='start := time.Now()';s=change(s,a,'target:=fmt.Sprint(batch,"/",goal)==os.Getenv("TICKET_TARGET");if target {os.Setenv("G3_FORMULA_FD",fmt.Sprint(fd))};'+a)
a='elapsed := time.Since(start)';s=change(s,a,'if target {os.Unsetenv("G3_FORMULA_FD")};'+a);write(k,s)
if e=='g3':
 k=p/'smtcore/smt_internalizer.go';s=k.read_text().replace('"errors"','"errors"\n"os"\n"strconv"\n"syscall"\n"unsafe"')
 a='return s.assertExpression(lemma, proof, instance.Generation(), arguments)'
 s=change(s,a,'''if val:=os.Getenv("G3_FORMULA_FD"); val!="" {
 fd,e:=strconv.Atoi(val);if e!=nil {panic(e)};priceFD=fd;priceN[14]++
 defer func(){priceFD=-1;for i,n:=range priceN {if n>0 {println("IC-PRICE",i,n,priceI[i])}};clear(priceN[:]);clear(priceI[:])}()
 };'''+a)
 a='func (s *SMTInternalizerState) internalizeFormula(expression ast.ASTHandle, gateContext bool, header *ast.ASTNodeHeader) error {'
 s=change(s,a,a+'''if fd:=priceFD;fd>=0 {
  k:=0
  if op,b:=s.smtHeaderBasicOperation(header); b && op==ast.ASTOpNot && gateContext{k=2;child,e:=s.manager.GetArg(expression,0);if e!=nil {panic(e)};if _,ok:=s.boolVar.lookup(child);ok{k=3}
  } else if _,ok:=s.boolVar.lookup(expression);ok{k=1}
  priceFD=-1
  activeFD=fd;group=k;defer func(){activeFD=-1; priceFD=fd}()
 }''')
 s+='''
var priceFD = -1
 var activeFD = -1
 var group int
 func detail(i int) func() {fd:=activeFD; k:=group*8+i; a:=priceRead(fd);b:=priceRead(fd);return func(){c:=priceRead(fd);priceN[k]++;priceI[k]+=int64(c-b)-int64(b-a)}}
 var priceN [32]int
 var priceI [32]int64
 func priceRead(fd int) uint64 {var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if e!=0 || n!=24{panic("counter read")};return c[0]}
 '''

 def hooks(s,h):
  for name,i in h:
   pat=r'(^func (?:\([^\n]+?\) )?'+name+r'\([^\n]+? \{)$'
   s,n=re.subn(pat,lambda m:m[0]+'\n if activeFD>=0 {defer detail('+str(i)+')()}\n',s,flags=re.M);assert n==1,name
  return s
 s=hooks(s,[('addGateConstraints',2),('addGateClause',3),('internalizeTerm',5)])
 a='case ast.ASTOpOr:\n\t\t\tliterals := make([]SMTLiteral, len(arguments))'
 s=change(s,a,a+'; if priceFD>=0 {priceN[6]+=len(arguments)}')
 a='func (s *SMTInternalizerState) addRootClause(literals []SMTLiteral, assertionProof ast.ASTHandle) error {'
 s=change(s,a,a+'if priceFD>=0 {priceN[7]++};')
 write(k,s)
 for path,h in [('smt_internalizer_state.go',[('mkBoolVar',0),('mkEnode',1)]),('smt_cg_table.go',[('Insert',4)])]:
  k=p/'smtcore'/path;write(k,hooks(k.read_text(),h))
else:
 build=p.parent/'build';src=p.parent/'src/smt'
 flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 lib=w/'lib-detail.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
 for name in ['qi_queue','smt_internalizer']:
  k=src/(name+'.cpp');s=k.read_text()

  if name=='qi_queue':
   s='#include <cstdlib>\nextern int g3price_fd;extern long long g3price_cost[32];extern int g3price_n[32];\n'+s
   a='m_context.internalize_instance(lemma, pr1, gen);';s=change(s,a,'''const char* fd=getenv("G3_FORMULA_FD");
    if(fd){g3price_fd=atoi(fd);g3price_n[14]++;}
    '''+a+'''
    if(fd){g3price_fd=-1;for(int i=0;i<32;i++){if(g3price_n[i])fprintf(stderr,"IC-PRICE %d %d %lld\\n",i,g3price_n[i],g3price_cost[i]);g3price_n[i]=0;g3price_cost[i]=0;}}''')
  else:
   s='''#include <unistd.h>
#include <cstdint>
#include <cstdlib>
int g3price_fd=-1,g3price_n[32]={};long long g3price_cost[32]={};
static uint64_t g3rd(int fd){uint64_t c[3];if(read(fd,c,24)!=24)abort();return c[0];}
static int active_fd=-1,group=-1;
struct TrialPrice {int fd;TrialPrice(int key):fd(g3price_fd){if(fd>=0){g3price_fd=-1;active_fd=fd;group=key;}}
 ~TrialPrice(){if(fd>=0){active_fd=-1;g3price_fd=fd;}}};
struct Detail {int fd,k;uint64_t a,b;Detail(int sub):fd(active_fd),k(group*8+sub){if(fd>=0){a=g3rd(fd);b=g3rd(fd);}}
 ~Detail(){if(fd>=0){auto c=g3rd(fd);g3price_n[k]++;g3price_cost[k]+=(long long)(c-b)-(long long)(b-a);}}};
'''+s
   a='void context::internalize_formula(expr * n, bool gate_ctx) {'
   s=change(s,a,a+'TrialPrice guard(g3price_fd<0?0:m_manager.is_not(n)&&gate_ctx?(b_internalized(to_app(n)->get_arg(0))?3:2):b_internalized(n)?1:0);')

   for fn,sub in [('mk_bool_var',0),('mk_enode',1),('mk_gate_clause',3),('internalize_term',5)]:
    if fn=='mk_gate_clause':sig='void context::mk_gate_clause(unsigned num_lits, literal * lits) {';s=change(s,sig,sig+'Detail sub('+str(sub)+');')
    else:
     s,n=re.subn(r'(context::'+fn+r'\([^\n]+? \{)',lambda m:m[0]+'Detail sub('+str(sub)+');',s);assert n==1,fn
   a=s.index('if (is_new_var && n->get_family_id()');b=s.index('case OP_TRUE:',a)
   part,n=re.subn(r'(case OP_(?:AND|OR|ITE|NOT|IFF):)(.*?break;)',r'\1 {Detail sub(2);\2}',s[a:b],flags=re.S);assert n==5
   s=s[:a]+part+s[b:]
   sig='enode_bool_pair pair = m_cg_table.insert(e);';s=change(s,sig,'enode_bool_pair pair;{Detail sub(4);pair=m_cg_table.insert(e);}')
   a=s.index('void context::internalize_assertion(');b=s.index('void context::assert_default(',a)
   part=s[a:b].replace('unsigned num = to_app(n)->get_num_args();','unsigned num = to_app(n)->get_num_args(); if(g3price_fd>=0)g3price_n[6]+=num;').replace('mk_root_clause(', 'if(g3price_fd>=0)g3price_n[7]++;mk_root_clause(')
   s=s[:a]+part+s[b:]
  d=w/k.name;d.write_text(s);obj=w/(name+'.o')
  subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,d],cwd=build,check=True)
  subprocess.run(['ar','r',lib,obj],check=True)
 k=front/'smt/quantifier.go';write(k,change(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=w/('detail-'+e+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',ov,'-o',w/('detail-'+e),'./cmd/goivy_check'],cwd=front,check=True)
