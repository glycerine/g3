from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
src=p/'smtcore/smt_cg_table.go';s=src.read_text().replace('import (','import (\n "os"').replace('type smtCongruenceBucket struct {','var trialLazy = os.Getenv("ACTION_SCOPE")=="lazy"\n\ntype smtCongruenceBucket struct {')
s=s.replace('t.buckets = append(t.buckets, bucket)','if !trialLazy { bucket.wide = make(map[uint64][]*SMTEnode) }\n t.buckets = append(t.buckets, bucket)')
dst=w/'switch.go.txt';dst.write_text(s);o=w/'switch.json';o.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',o,'-o',w/'switch','./cmd/goivy_check'],cwd=f,check=True)
s=(w/'compare.py').read_text().replace("Path('/tmp/g3-reduction-rows/release') if m=='base' else w/m","w/'switch'")
assert "exe=w/'switch'" in s
(w/'toggle.py').write_text(s)
