from pathlib import Path
import json,subprocess,os,csv,collections
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'sibling.json').read_text())['Replace'];src=f/'z3bridge_solver_model.go';s=Path(ov[str(src)]).read_text()
a='if tag==os.Getenv("FORCE_ORDINARY"){finalCheck=z3solver.Check}';assert s.count(a)==1
s=s.replace(a,'forced:=tag==os.Getenv("FORCE_ORDINARY");if forced{finalCheck=z3solver.Check;os.Setenv("HEURISTIC_BEGIN","1")}').replace('end("check")','if forced{os.Unsetenv("HEURISTIC_BEGIN")};end("check")')
dst=w/'heuristics-bridge.go.txt';dst.write_text(s);ov[str(src)]=str(dst)
src=p/'smtcore/smt_assumptions.go';s=src.read_text().replace('"fmt"','"fmt"\n"os"')
a='func (k *SMTKernel) CheckAssumptions(assumptions []ast.ASTHandle) (result lbool.LBool, resultErr error) {'
s=s.replace(a,a+'''
 if os.Getenv("HEURISTIC_BEGIN")=="1" {
  // Only the outer call belonging to the selected concrete goal.
  os.Setenv("HEURISTIC_BEGIN","inner")
  state:=k.internalizer
  rng:=state.random
  data:=append([]SMTBoolVarData(nil),state.booleanData...)
  owners:=append([]ast.ASTHandle(nil),state.boolExpr...)
  mode:=os.Getenv("HEURISTIC_MODE")
  defer func(){
    draws:=0; probe:=rng
    for probe!=state.random && draws<1000000 {probe.Next();draws++}
    diff:=0
    for i:=0;i<min(len(data),len(state.booleanData));i++{
      if owners[i]!=state.boolExpr[i]{continue}
      before,after:=&data[i],&state.booleanData[i]
      if before.Phase()!=after.Phase() || before.PhaseAvailable()!=after.PhaseAvailable(){diff++}
      if mode=="phase"||mode=="both"{after.SetPhase(before.Phase());after.SetPhaseAvailable(before.PhaseAvailable())}
    }
    if mode=="rng"||mode=="both"{state.random=rng}
    println("HEURISTICS",draws,diff)
  }()
 }''')
dst=w/'heuristics-check.go.txt';dst.write_text(s);ov[str(src)]=str(dst);o=w/'heuristics.json';o.write_text(json.dumps({'Replace':ov}))
exe=w/'heuristics';subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');gold=Path('/tmp/g3-reduction-rows');ns=(gold/'compat.txt').read_text().splitlines()
with (w/'heuristics.csv').open('w') as dest:
 out=csv.writer(dest);out.writerow('case target forced mode round draws phase_changes instances operands'.split())
 for nr,target,force in [(3,'4/55','4/4'),(3,'4/55','4/17'),(6,'14/44','14/31'),(6,'14/44','14/43'),(8,'12/8','12/6')]:
  ref=gold/'compat'/str(nr)/'1/native'
  for mode in ['keep','rng','phase','both']:
   for i in range(2):
    r=subprocess.run(['taskset','-c','10',exe,ex/ns[nr-1]],env=dict(os.environ,XTRACE_OFF='1',GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),FORCE_ORDINARY=force,TICKET_TARGET=target,HEURISTIC_MODE=mode),capture_output=True,cwd=w,timeout=90)
    n=collections.Counter();outcome=None;state=None;err=bytearray()
    for line in r.stderr.splitlines(keepends=True):
     if line.startswith(b'HEURISTICS '):assert state is None;state=line.decode().split()[1:]
     elif line.startswith(b'PRIVATE '):pass
     elif line.startswith(b'IC-PRICE '):
      _,k,c,_=line.split();n[int(k)]+=int(c)
     elif line.startswith(b'STAGE-COUNT '):
      _,b,h,stage,num,empty,en,active,ns_=line.decode().split();assert en==active
      if b+'/'+h==target and stage=='check':outcome=n.copy()
      n.clear()
     else:err.extend(line)
    assert state and outcome and (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(state,nr,err[:200])
    out.writerow([nr,target,force,mode,i,*state,outcome[14],outcome[6]]);dest.flush()
