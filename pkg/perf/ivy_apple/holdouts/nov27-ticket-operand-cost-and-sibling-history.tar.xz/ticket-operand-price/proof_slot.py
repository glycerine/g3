"""Test omitting the empty proof output slot when proof generation and combination are off."""
from pathlib import Path
import json,subprocess,csv,sys
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
k=p/'smtcore/smt_asserted_formulas.go';s=k.read_text();a=s.index('func (k *SMTKernel) preprocessAssertionMode(');q=s.index('proofRef, err :=',a)
s=s[:q]+'''if !k.preprocessor.ProofGen() && proofSlotTrial {
  proofs,e:=k.manager.ProofsEnabled(); if e!=nil{return ast.ASTHandle{},ast.ASTHandle{},e}
  if !proofs {return k.preprocessAssertionWithMode(formula,proof,resultRef,ast.ASTRef{},mode)}
 }
 '''+s[q:]
s=s.replace('import (','import (\n"os"',1) if '"os"' not in s else s
s+='\nvar proofSlotTrial = os.Getenv("ACTION_SCOPE")=="slot"\n'
d=w/'proof-slot.go.txt';d.write_text(s)
ov=json.loads((w/'original.json').read_text());ov['Replace'][str(k)]=str(d)
o=w/'proof-slot.json';o.write_text(json.dumps(ov));exe=w/'proof-slot'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
driver=w/'proof_slot_compare.py';driver.write_text((w/'compare.py').read_text().replace("Path('/tmp/g3-reduction-rows/release') if m=='base' else w/m","w/'proof-slot'"))
names=list(dict.fromkeys(r['case'] for r in csv.DictReader((w/'seed0_base_draw1.csv').open())))
subprocess.run([sys.executable,driver,'proofslot_base_slot','14','5',*names],check=True)
