from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'draw-meter.json').read_text())['Replace']
def emit(src,s):
 d=w/('sites-'+src.name+'.txt');d.write_text(s);ov[str(src)]=str(d)
root=p/'smtcore'
for src in root.glob('*.go'):
 if src.name.endswith('_test.go'):continue
 s=Path(ov.get(str(src),src)).read_text();old=s
 if src.name=='smt_internalizer_state.go':
  s=s.replace('random                     z3rand.Generator','random                     z3rand.Generator\n studyShift z3rand.Generator\n studyPart string')
  s=s.replace('s.random.Next()%1000','s.studyNext("initial")%1000')
  s+='\nfunc (s *SMTInternalizerState) studyNext(part string) uint32 {v:=s.random.Next(); if s.studyPart!="" {shift:=s.studyShift.Next();if s.studyPart=="all" || s.studyPart==part{return shift}};return v}\n'
 if src.name=='smt_kernel.go':
  s=s.replace('for j:=0;j<n;j++{k.internalizer.random.Next()}','k.internalizer.studyPart=os.Getenv("RNG_SITE");k.internalizer.studyShift=k.internalizer.random;for j:=0;j<n;j++{k.internalizer.studyShift.Next()}')
 for a in ['q.state','t.state']:
  s=s.replace(a+'.random.Next()',a+'.studyNext("decision")')
 if s!=old:emit(src,s)
o=w/'sites.json';o.write_text(json.dumps({'Replace':ov}));exe=w/'sites'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
s=(w/'draw_counts.py').read_text().replace("w/'meter'","w/'sites'").replace("w/'draw-counts.csv'","w/'sites.csv'").replace('sibling draws round','sibling site draws round').replace('for v in [0,advance]:','for site in ["neither","initial","decision","all"]:\n   v=advance').replace('TICKET_TARGET=target','TICKET_TARGET=target,RNG_SITE=site').replace('tag,v,i,hit','tag,site,v,i,hit')
(w/'site_counts.py').write_text(s)
subprocess.run(['python3',w/'site_counts.py'],check=True)
