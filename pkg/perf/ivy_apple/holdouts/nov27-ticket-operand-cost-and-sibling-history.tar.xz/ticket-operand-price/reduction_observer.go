package smtcore

import (
"github.com/glycerine/g3/pkg/ast"
	"fmt"
	"os"
	"runtime"
	"syscall"
	"unsafe"
)

var studyfd uintptr
var studyempty, studycalls, studyinstructions, studydepth uint64

func studyreadCounter() uint64 {
	var values [3]uint64
	n, _, err := syscall.RawSyscall(syscall.SYS_READ, studyfd, uintptr(unsafe.Pointer(&values[0])), unsafe.Sizeof(values))
	if err != 0 || n != unsafe.Sizeof(values) || values[1] != values[2] {
		panic("incomplete replay instruction counter")
	}
	return values[0]
}

var studyordinal int
var studyactive bool

// studyScope measures one external GoIvy Push on its solver thread.
func studyScope() func() {
	runtime.LockOSThread()
	var attr struct {
		Type, Size                                    uint32
		Config, Period, SampleType, ReadFormat, Flags uint64
		Padding                                       [16]byte
	}
	attr.Size = uint32(unsafe.Sizeof(attr))
	attr.Config = 1          // PERF_COUNT_HW_INSTRUCTIONS
	attr.Flags = 1<<5 | 1<<6 // exclude kernel and hypervisor
	attr.ReadFormat = 3
	var err syscall.Errno
	studyfd, _, err = syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN, uintptr(unsafe.Pointer(&attr)), 0, ^uintptr(0), ^uintptr(0), 0, 0)
	if err != 0 {
		panic(err)
	}
	studycalls, studyinstructions, studydepth = 0, 0, 0
	studyordinal++
	studyactive = true
	lo := studyreadCounter()
	studyempty = studyreadCounter() - lo
	return func() {
		studyactive = false
		fmt.Fprintln(os.Stderr, "IVY-PUSH-STAGE", studyordinal, os.Getenv("IVY_PUSH_STAGE"), studycalls, studyinstructions)
		syscall.Close(int(studyfd))
		runtime.UnlockOSThread()
	}
}

func studyEnter() uint64 {
	if !studyactive {
		return 0
	}
	studycalls++
	studydepth++
	if studydepth == 1 {
		return studyreadCounter()
	}
	return 0
}

func studyLeave(start uint64) {
	if !studyactive {
		return
	}
	studydepth--
	if studydepth == 0 {
		n := studyreadCounter() - start
		if n > studyempty {
			studyinstructions += n - studyempty
		}
	}
}

func studyPass(name string, inputs int) func() {
	if !studyactive {
		return func() {}
	}
	start := studyreadCounter()
	return func() {
		n := studyreadCounter() - start
		if n > studyempty {
			n -= studyempty
		} else {
			n = 0
		}
		fmt.Fprintln(os.Stderr, "IVY-PUSH-PASS", studyordinal, name, inputs, n)
	}
}

var followup bool
var priorOutput map[ast.ASTHandle]bool
var rowStats [8]struct{n int;cycles uint64}
func finishRows(){
 for i,v:=range rowStats{fmt.Fprintln(os.Stderr,"ROWS",studyordinal,i,v.n,v.cycles)}
 priorOutput=nil
}
