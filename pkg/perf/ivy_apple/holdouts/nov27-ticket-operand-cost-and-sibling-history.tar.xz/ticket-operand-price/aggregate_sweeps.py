from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
with (w/'sweeps.csv').open() as f:
 rows=list(csv.DictReader(f))
groups=collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
for r in rows:
 key=r['case'],int(r['op'])
 for c in ('calls','changed','instructions','cache_lookups','cache_hits','cache_changed','subst_lookups','subst_hits','subst_changed'):
  if int(r['collect_events'])!=int(c.startswith(('cache','subst'))):continue
  if r[c]:groups[key][c][r['round']]+=int(r[c])
with (w/'sweep-summary.csv').open('w') as f:
 out=csv.writer(f);cols=['calls','changed','instructions','cache_lookups','cache_hits','cache_changed','subst_lookups','subst_hits','subst_changed'];out.writerow(['case','op',*cols])
 for (name,op),cs in groups.items():
  v=[int(statistics.median(cs[c].values())) if cs[c] else '' for c in cols]
  out.writerow([name,op,*v]); print(name.split('/')[-1],op,*v)
