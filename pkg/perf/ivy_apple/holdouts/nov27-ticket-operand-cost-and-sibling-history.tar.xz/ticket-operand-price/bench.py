from pathlib import Path
import subprocess,os,csv,re
w=Path(__file__).resolve().parent
with (w/'registration.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round mode ns_per_op bytes_per_op allocs_per_op'.split())
 for i in range(9):
  for mode in ['original','lazy'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','14',w/(mode+'.test'),'-test.run=^$','-test.bench=^BenchmarkSMTCongruenceDeclarationRegistration$','-test.benchtime=1000x'],capture_output=True,env=dict(os.environ,GOMAXPROCS='1'),check=True)
   vals=re.search(rb'1000\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout)
   assert vals,r.stdout
   out.writerow((i,mode,*[v.decode() for v in vals.groups()]));f.flush()
