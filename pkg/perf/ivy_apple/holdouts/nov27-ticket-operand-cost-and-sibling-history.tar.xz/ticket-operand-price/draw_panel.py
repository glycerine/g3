from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
s=(w/'compare.py').read_text().replace("Path('/tmp/g3-reduction-rows/release') if m=='base' else w/m","w/'draw0'").replace('ACTION_SCOPE=m','ACTION_SCOPE=("draw0" if m=="base" else m)')
(w/'draw_compare.py').write_text(s)
names=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines()
procs=[subprocess.Popen([sys.executable,w/'draw_compare.py',f'panel{i}_base_draw1',str(cpu),'3',*names[i::4]]) for i,cpu in enumerate([2,4,14,16])]
assert [p.wait() for p in procs]==[0]*4
