from pathlib import Path
import sys,subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;mode=sys.argv[1]
src=p/'smtcore/smt_qi_instance.go';s=src.read_text()
old='lemma, err = b.manager.MkOr(negatedQuantifier, simplified)'
assert s.count(old)==1
s=s.replace(old,old+'''
            if arguments != nil && err == nil {
                *arguments = []ast.ASTHandle{negatedQuantifier,simplified}
            }''')
file=w/'binary-smt_qi_instance.go.txt';file.write_text(s)
ov={str(src):str(file)}
if mode=='stack':
 src=p/'smtcore/smt_internalizer.go';s=src.read_text();old='literals := make([]SMTLiteral, len(arguments))\n\t\t\tfor index, argument := range arguments'
 assert s.count(old)==1
 s=s.replace(old,'''var small [8]SMTLiteral
            var literals []SMTLiteral
            if len(arguments)<=len(small) { literals=small[:len(arguments)] } else { literals=make([]SMTLiteral,len(arguments)) }
            for index, argument := range arguments''');file=w/'stack-smt_internalizer.go.txt';file.write_text(s);ov[str(src)]=str(file)
o=w/(mode+'.json');o.write_text(json.dumps({'Replace':ov}))
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',o,'-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
