from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent
ov=json.loads((w/'detail-g3.json').read_text())['Replace'];f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();key=str(f/'z3bridge_solver_model.go');s=Path(ov[key]).read_text()
a='batchCheck, proveGoal, release = z3solver.BeginVerificationGoalBatch(len(finalCond))';assert s.count(a)==1
s=s.replace(a,a+'''
                switch os.Getenv("TICKET_POLICY") {
                case "no-early": proveGoal=nil
                case "no-post": batchCheck=z3solver.Check
                case "ordinary","all": proveGoal=nil; batchCheck=z3solver.Check
                }''')
dst=w/'history-bridge.go.txt';dst.write_text(s);ov[key]=str(dst)
src=p/'tactic/portfolio/strategic_solver_factory.go';s=src.read_text()
for feature,mode in [('SimplifyInitialPushOnce','full-prep'),('PreferConnectedMultiPatterns','source-triggers'),('CheckUninterpretedModelTables','aux-model')]:
 a='config.'+feature+' = true';assert s.count(a)==1;s=s.replace(a,'config.'+feature+' = os.Getenv("TICKET_POLICY")!="'+mode+'" && os.Getenv("TICKET_POLICY")!="all"')
dst=w/'history-factory.go.txt';dst.write_text(s);ov[str(src)]=str(dst)
o=w/'history.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo=off','-tags','xtrace_off','-overlay',o,'-o',w/'history','./cmd/goivy_check'],cwd=f,check=True)
