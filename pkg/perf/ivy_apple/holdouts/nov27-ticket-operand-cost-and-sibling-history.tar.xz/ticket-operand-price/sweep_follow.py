"""Count changed rows in the ordinary post-propagation reduction, plus a skip upper bound."""
import csv,json,os,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov={'Replace':{}}
def emit(k,s):
 d=w/('follow-'+k.name+'.txt');d.write_text(s);ov['Replace'][str(k)]=str(d)
k=p/'smtcore/smt_asserted_propagate.go';s=k.read_text();a=s.index('func (k *SMTKernel) propagatePendingAssertions()');t=s[a:];key='return k.reducePendingAssertions()';assert t.count(key)==1
emit(k,s[:a]+t.replace(key,'''if studyFollow=="skip"{return nil}
 if studyFollow=="observe"{studyVisit=true; defer func(){println("FOLLOW",studyRows,studyDiff,studyProof);studyVisit=false;studyRows=0;studyDiff=0;studyProof=0}()}
 '''+key))
k=p/'smtcore/smt_asserted_reduce.go';s=k.read_text().replace('import (','import (\n"os"',1);key='err = k.appendTransformedAssertion(batch, row, formula, proof)'
assert s.count(key)==1;emit(k,s.replace(key,'''if studyVisit{studyRows++;if formula!=row.Formula{studyDiff++};if proof!=row.Proof{studyProof++}}
 '''+key)+'\nvar studyFollow=os.Getenv("ACTION_SCOPE")\nvar studyRows,studyDiff,studyProof int\nvar studyVisit bool\n')
o=w/'follow.json';o.write_text(json.dumps(ov));exe=w/'follow'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
d=w/'follow_compare.py';d.write_text((w/'compare.py').read_text().replace("Path('/tmp/g3-reduction-rows/release') if m=='base' else w/m","w/'follow'"))
names=list(dict.fromkeys(r['case'] for r in csv.DictReader((w/'seed0_base_draw1.csv').open())))
survey=Path('/tmp/g3-ivy-pgo');codes={r['spec']:int(r['exit']) for g in (survey/'survey').glob('cpu-*.csv') for r in csv.DictReader(g.open()) if r['engine']=='native'};cases=(survey/'prior-gaps.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'follow-counts.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','invocations','rows','changed','different_proof'])
 for name in names:
  ref=survey/'survey'/str(cases.index(name)+1)/'1/native'
  r=subprocess.run(['taskset','-c','4',exe,ex/name],env=dict(os.environ,GOMAXPROCS='1',ACTION_SCOPE='observe',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=75)
  err=[];v=[]
  for l in r.stderr.splitlines(True):
   if l.startswith(b'FOLLOW '):v.append(list(map(int,l.split()[1:])))
   else:err.append(l)
  assert v and (r.returncode,r.stdout,b''.join(err))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
  out.writerow([name,len(v),*map(sum,zip(*v))]);f.flush()
subprocess.run([sys.executable,d,'follow_base_skip','4','3',*names],check=True)
