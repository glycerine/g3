from pathlib import Path
import json,subprocess,sys,os,csv,collections
p=Path.cwd();w=Path(__file__).resolve().parent
f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();o=json.loads((w/'detail-g3.json').read_text());ov=o['Replace']
ov.update(json.loads((w/'original.json').read_text())['Replace'])
ov[str(f/'smt/g3_solver.go')]=str(w/'learn-solver.go.txt')
key=str(f/'z3bridge_solver_model.go');s=Path(ov[key]).read_text()
k='res, err := s.decideZ3With(z3solver, finalCheck)';assert s.count(k)==1
s=s.replace(k,'''tag:=fmt.Sprintf("%d/%d",batch,ordinal+1)
                z3solver.ConsumePrivate()
                if tag==os.Getenv("FORCE_ORDINARY"){finalCheck=z3solver.Check}
                '''+k)
k='end("check")';s=s.replace(k,k+'\n if z3solver.ConsumePrivate(){fmt.Fprintln(os.Stderr,"PRIVATE",tag)}')
dst=w/'sibling-bridge.go.txt';dst.write_text(s);ov[key]=str(dst)
o=w/'sibling.json';o.write_text(json.dumps({'Replace':ov}))
exe=w/'sibling'
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo=off','-tags','xtrace_off','-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');gold=Path('/tmp/g3-reduction-rows');ns=(gold/'compat.txt').read_text().splitlines()
with (w/'siblings.csv').open('w') as dest:
 out=csv.writer(dest);out.writerow('case target forced round instances root_operands target_instructions all_check_instructions forced_check_instructions'.split())
 for nr,target in [(3,'4/55'),(6,'14/44'),(8,'12/8')]:
  ref=gold/'compat'/str(nr)/'1/native';batch,g=map(int,target.split('/'));modes=['none']
  for force in modes:
   for i in range(2):
    r=subprocess.run(['taskset','-c','10',exe,ex/ns[nr-1]],cwd=w,env=dict(os.environ,FORCE_ORDINARY=force,TICKET_TARGET=target,XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),GOGC='off',GOMAXPROCS='1'),capture_output=True,timeout=60)
    private=[];err=bytearray();n=collections.Counter();checks={}
    for line in r.stderr.splitlines(keepends=True):
     if line.startswith(b'PRIVATE '):private.append(line.decode().split()[1])
     elif line.startswith(b'IC-PRICE '):
      _,k,c,v=line.split();n[int(k)]+=int(c)
     elif line.startswith(b'STAGE-COUNT '):
      _,b,h,stage,val,empty,en,active,ns_=line.decode().split();assert en==active
      if stage=='check':checks[b+'/'+h]=int(val)
      if b+'/'+h==target and stage=='check':cost=n.copy()
      n.clear()
     else:err.extend(line)
    assert (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(nr,err[:300])
    if force=='none' and i==0:
     modes.extend([t for t in private if int(t.split('/')[0])==batch and int(t.split('/')[1])<g])
    out.writerow([nr,target,force,i,cost[14],cost[6],checks[target],sum(checks.values()),checks.get(force,0)]);dest.flush()
