"""Exclusive intervals on instance-operand enode construction, including nested congruence probes."""
import json,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'detail-g3.json').read_text())
k=p/'smtcore/smt_internalizer_state.go'
s=Path(ov['Replace'][str(k)]).read_text()
a=s.index('func (s *SMTInternalizerState) mkEnode(');b=s.index('func (s *SMTInternalizerState) PendingCongruences',a)
part=s[a:b]
marks=['if err := s.open();','node, err := newSMTEnode','count := node.NumArgs()','if err = s.context.registerEnode','s.enodeStack = append','s.traceAttachEnode(node)','return node, nil']
for i,key in enumerate(marks):
 assert part.count(key)==1
 if i==0:
  prefix='fd:=activeFD;var start,over uint64;if fd>=0 {v:=priceRead(fd);start=priceRead(fd);over=start-v};'
 else:
  prefix=f'if fd>=0 {{end:=priceRead(fd);priceN[{31+i}]++;priceI[{31+i}]+=int64(end-start)-int64(over);start=priceRead(fd)}};'
 part=part.replace(key,prefix+key)
dst=w/'parts-state.go.txt';dst.write_text(s[:a]+part+s[b:]);ov['Replace'][str(k)]=str(dst)
k=p/'smtcore/smt_internalizer.go';s=Path(ov['Replace'][str(k)]).read_text();assert '[32]' in s
dst=w/'parts-meter.go.txt';dst.write_text(s.replace('[32]','[38]'));ov['Replace'][str(k)]=str(dst)
ovpath=w/'parts.json';ovpath.write_text(json.dumps(ov))
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',ovpath,'-o',w/'detail-parts','./cmd/goivy_check'],cwd=f,check=True)
subprocess.run([sys.executable,w/'run.py','parts','20'],check=True)
