from pathlib import Path
import subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent
src=p/'smtcore/smt_cg_table.go';s=src.read_text()
a='bucket := t.tables[smtHandleKey(node.declaration)]\n\tif bucket != nil {\n\t\tnode.functionDeclID = bucket.id'
assert s.count(a)==1
s=s.replace(a,'''slot := &t.appBuckets[node.declaration.Slot()%uint32(len(t.appBuckets))]
 bucket:=*slot
 if bucket == nil || bucket.declaration!=node.declaration {
  bucket=t.tables[smtHandleKey(node.declaration)]
  if bucket != nil { *slot=bucket }
 }
 if bucket != nil {
  node.functionDeclID = bucket.id''')
dst=w/'bucket.go.txt';dst.write_text(s);o=w/'bucket.json';o.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',o,'-o',w/'bucket','./cmd/goivy_check'],cwd=f,check=True)
s=(w/'compare.py').read_text().replace("Path('/tmp/g3-reduction-rows/release') if m=='base'", "w/'lazy' if m=='base'")
(w/'lazycompare.py').write_text(s)
