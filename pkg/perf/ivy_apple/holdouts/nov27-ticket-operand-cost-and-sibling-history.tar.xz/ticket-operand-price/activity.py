from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
src=p/'smtcore/smt_internalizer_state.go';s=src.read_text()
if '"os"' not in s:s=s.replace('import (','import (\n "os"',1)
a='func (s *SMTInternalizerState) publishBoolVar(';s=s.replace(a,'var studyInitialActivity=os.Getenv("ACTION_SCOPE")\n\n'+a)
a='initialActivity = -float64(s.random.Next()%1000) / 1000';assert s.count(a)==1
s=s.replace(a,a+'''
 switch studyInitialActivity {
 case "zero": initialActivity=0
 case "stable": hash,err:=s.manager.GetHash(expression);if err!=nil{return SMTNullBoolVar,err};initialActivity=-float64(hash%1000)/1000
 case "slot": hash:=expression.Slot()*2654435761;initialActivity=-float64(hash>>22)/1024
 }''')
dst=w/'activity.go.txt';dst.write_text(s);ov=json.loads((w/'original.json').read_text())['Replace'];ov[str(src)]=str(dst);o=w/'activity.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',w/'zero','./cmd/goivy_check'],cwd=f,check=True)
for n in ['stable','slot','control']:(w/n).symlink_to(w/'zero')
