from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();obs=sys.argv[1]=='meter'
ov=json.loads((w/('detail-g3.json' if obs else 'original.json')).read_text())['Replace'];ov.update(json.loads((w/'original.json').read_text())['Replace'])
ov[str(f/'smt/g3_solver.go')]=str(w/'learn-solver.go.txt')
k=f/'z3bridge_solver_model.go'
s=Path(ov.get(str(k),k)).read_text();a=s.index('func (s *Solver) GetSmallModelWithCond(');pre,s=s[:a],s[a:]
if not obs:
 s=s.replace('if finalCond != nil {','batch:=0; if finalCond != nil {',1).replace('for _, fc := range finalCond {','for ordinal, fc := range finalCond {',1)
key='res, err := s.decideZ3With(z3solver, finalCheck)';s=s.replace(key,'z3solver.ConsumePrivate()\n'+key,1)
key='z3solver.Pop()\n'+('\t\t\t\t\tend("pop")\n' if obs else '')+'\t\t\t\t}\n\t\t\t}'
assert s.count(key)==1,key
s=s.replace(key,'''tag:=os.Getenv("DRAW_GOAL")
 if z3solver.ConsumePrivate() && (tag=="" || tag==fmt.Sprintf("%d/%d",batch,ordinal+1)){
   os.Setenv("G3_TRIAL_ADVANCE",os.Getenv("ACTION_SCOPE"))
 }
 z3solver.Pop()
 os.Unsetenv("G3_TRIAL_ADVANCE")
'''+key[key.index('Pop()')+6:])
dst=w/('draw-'+sys.argv[1]+'-bridge.go.txt');dst.write_text(pre+s);ov[str(k)]=str(dst)
src=p/'smtcore/smt_kernel.go';s=src.read_text().replace('"runtime"','"runtime"\n"os"\n"strconv"')
key='func (k *SMTKernel) Pop(count uint32) error {'
s=s.replace(key,key+'''
 if c:=os.Getenv("G3_TRIAL_ADVANCE");strings.HasPrefix(c,"draw"){
   n,_:=strconv.Atoi(c[4:]);for j:=0;j<n;j++{k.internalizer.random.Next()}
   if os.Getenv("DRAW_GOAL")!=""{println("STUDY-DRAW",n)}
   os.Unsetenv("G3_TRIAL_ADVANCE")
 }
''')
dst=w/'draw-kernel.go.txt';dst.write_text(s);ov[str(src)]=str(dst);o=w/('draw-'+sys.argv[1]+'.json');o.write_text(json.dumps({'Replace':ov}))
exe=w/('meter' if obs else 'draw0')
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+('off' if obs else str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
if not obs:
 for n in [1,4,16]:(w/('draw'+str(n))).symlink_to(exe)
