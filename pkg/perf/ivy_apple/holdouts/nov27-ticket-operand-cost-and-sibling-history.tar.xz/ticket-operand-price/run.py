from pathlib import Path
import csv,subprocess,os,sys,collections
w=Path(__file__).resolve().parent;p=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
names=(p/'compat.txt').read_text().splitlines();eng=sys.argv[1]
with (w/(eng+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('input target round slot calls instructions'.split())
 for i in range(5):
  for nr,target in [(3,'4/55'),(6,'14/44'),(8,'12/8')]:
   ref=p/'compat'/str(nr)/'1/native'
   r=subprocess.run(['taskset','-c',sys.argv[2],w/('detail-'+eng),ex/names[nr-1]],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TICKET_TARGET=target),cwd=w,capture_output=True,timeout=100)
   counts=collections.Counter();cost=collections.Counter();err=bytearray();hit=False
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'IC-PRICE '):
     _,k,c,v=line.split();counts[int(k)]+=int(c);cost[int(k)]+=int(v)
    elif line.startswith(b'STAGE-COUNT '):
     _,b,g,stage,num,empty,en,active,ns=line.decode().split();assert en==active
     if b+'/'+g==target and stage=='check':
      assert counts[14]>0
      for k in counts:out.writerow((nr,target,i,k,counts[k],cost[k]))
      hit=True
     counts.clear();cost.clear()
    else:err.extend(line)
   assert hit and (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(nr,eng,r.returncode,err[:300]);f.flush()
