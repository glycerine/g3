from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
src=f/'z3bridge_solver_model.go';s=src.read_text();at=s.index('func (s *Solver) GetSmallModelWithCond(');pre,s=s[:at],s[at:]
k='if finalCond != nil {';s=s.replace(k,'''warm:=0
 switch os.Getenv("ACTION_SCOPE") {case "warm1":warm=1;case "warm2":warm=2;case "warm4":warm=4;case "warm8":warm=8}
 '''+k,1)
k='finalCheck := check';assert s.count(k)==1
s=s.replace(k,k+'\n if proveGoal==nil && warm>0 { finalCheck=z3solver.Check; warm-- }')
dst=w/'warm.go.txt';dst.write_text(pre+s);ov=json.loads((w/'original.json').read_text())['Replace'];ov[str(src)]=str(dst)
o=w/'warm.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',o,'-o',w/'warm1','./cmd/goivy_check'],cwd=f,check=True)
for m in ['warm2','warm4','warm8']:(w/m).symlink_to(w/'warm1')
