"""Use the verified solver's public SMT random seed and compare matched pairs."""
from pathlib import Path
import csv,json,os,subprocess,sys
w=Path(__file__).resolve().parent
pkg=Path.cwd()
f=(pkg/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'draw-release.json').read_text())
src=f/'z3bridge_solver_model.go'
s=Path(ov['Replace'][str(src)]).read_text()
a=s.index('func (s *Solver) GetSmallModelWithCond(')
needle='z3solver := s.newZ3Solver()'
start=s.index(needle,a)+len(needle)
out=w/'cross-seed-bridge.go.txt'
out.write_text(s[:start]+'\n if seed:=os.Getenv("TICKET_SEED");seed!="" {z3solver.SetParam("random_seed",seed)}\n'+s[start:])
ov['Replace'][str(src)]=str(out)
o=w/'cross-seed.json';o.write_text(json.dumps(ov))
exe=w/'cross-seed'
subprocess.run(['go','build','-mod=readonly','-modfile',(pkg/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
d=w/'cross_driver.py';s=(w/'draw_compare.py').read_text();assert "w/'draw0'" in s
d.write_text(s.replace("w/'draw0'","w/'cross-seed'"))
names=list(dict.fromkeys(r['case'] for r in csv.DictReader((w/'seed_base_draw0_draw1_draw4_draw16.csv').open())))
children=[subprocess.Popen([sys.executable,d,f'seed{seed}_base_draw1',str(cpu),'3',*names],env=dict(os.environ,TICKET_SEED=str(seed))) for seed,cpu in zip([0,1,2,3,4],[2,4,14,16,18])]
assert all(p.wait()==0 for p in children)
