import collections,csv,statistics,sys
from pathlib import Path
for f in map(Path,sys.argv[1:]):
 groups=collections.defaultdict(lambda:collections.defaultdict(dict))
 for r in csv.DictReader(f.open()):
  m=r.get('mode',r.get('engine'))
  if r.get('status','match')!='match':print(f.name,r['status'],r['case'],m);continue
  groups[r['case']][m][r['round']]=r
 for case,modes in groups.items():
  for m,rs in modes.items():
   b=modes['base'];ids=set(b)&set(rs)
   if not ids or m=='base':continue
   cols=['instructions','cycles','ms' if 'ms' in next(iter(rs.values())) else 'milliseconds']
   print(f.stem,case.split('/')[-1],m,len(ids),*[round(statistics.median(100*(float(rs[i][k])/float(b[i][k])-1) for i in ids),2) for k in cols])
