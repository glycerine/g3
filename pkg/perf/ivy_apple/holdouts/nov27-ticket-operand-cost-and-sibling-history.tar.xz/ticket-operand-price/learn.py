from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent
f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads((w/'original.json').read_text())['Replace']
src=f/'smt/g3_solver.go';s=src.read_text().replace('type Z3Solver struct {','type Z3Solver struct {\n studyPrivate bool')
k='if proved, err := prove(); err == nil && proved {';assert s.count(k)==1;s=s.replace(k,k+'\n s.studyPrivate=true')
s+='\nfunc (s *Z3Solver) ConsumePrivate()bool{v:=s.studyPrivate;s.studyPrivate=false;return v}\n'
dst=w/'learn-solver.go.txt';dst.write_text(s);ov[str(src)]=str(dst)
src=f/'z3bridge_solver_model.go';s=src.read_text();start=s.index('func (s *Solver) GetSmallModelWithCond(');a,s=s[:start],s[start:]
k='if finalCond != nil {';s=s.replace(k,'policy:=os.Getenv("ACTION_SCOPE")\n'+k,1)
s=s.replace('for _, fc := range finalCond {','for ordinal, fc := range finalCond {',1)
s=s.replace('if proved {\n','if proved {\n if (policy=="early"||policy=="both") && ordinal+1<len(finalCond) {z3solver.Assert(s.tr.Ctx.Not(zCond))}\n',1)
k='res, err := s.decideZ3With(z3solver, finalCheck)';assert s.count(k)==1
s=s.replace(k,'z3solver.ConsumePrivate()\n if policy=="nopost"{finalCheck=z3solver.Check}\n'+k)
k='z3solver.Pop()\n\t\t\t\t}\n\t\t\t}';assert s.count(k)==1
s=s.replace(k,'z3solver.Pop()\n if (policy=="post"||policy=="both") && ordinal+1<len(finalCond) && z3solver.ConsumePrivate(){z3solver.Assert(s.tr.Ctx.Not(zCond))}\n\t\t\t\t}\n\t\t\t}')
dst=w/'learn-bridge.go.txt';dst.write_text(a+s);ov[str(src)]=str(dst)
o=w/'learn.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',o,'-o',w/'post','./cmd/goivy_check'],cwd=f,check=True)
for name in ['both','early','nopost']:(w/name).symlink_to(w/'post')
