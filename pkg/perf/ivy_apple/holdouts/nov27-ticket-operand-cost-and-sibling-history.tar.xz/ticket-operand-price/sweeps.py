"""Measure assertion propagation per direction and record substitution and cache outcomes."""
from pathlib import Path
import json,subprocess,os,csv,sys
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov={'Replace':{}}
def emit(k,s):
 dst=w/('sweep-'+k.name+'.txt');dst.write_text(s);ov['Replace'][str(k)]=str(dst)
key='sub, subProof, found, e := r.cfg.GetSubst(t)'
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text();assert s.count(key)==1
emit(k,s.replace(key,key+'\n if SweepCounts!=nil{SweepCounts[0]++;if found{SweepCounts[1]++;if sub!=t{SweepCounts[2]++}}}'))
k=p/'ast/rewriter/rewriter_core.go';s=k.read_text();key='return c.cache.Find(k)';assert s.count(key)==1
emit(k,s.replace(key,'v,e:=c.cache.Find(k);if SweepCounts!=nil{SweepCounts[3]++;if !v.IsNull(){SweepCounts[4]++;if k!=v{SweepCounts[5]++}}};return v,e')+'\nvar SweepCounts *[6]int\n')
k=p/'smtcore/smt_asserted_propagate.go';s=k.read_text();a=s.index('func (k *SMTKernel) propagatePendingAssertions()');pre,s=s[:a],s[a:]
src=Path('/tmp/g3-reduction-rows/reduction_observer.go').read_text()
lo=src.index('var studyfd');hi=src.index('func studyEnter')
helper=src[lo:hi].replace('fmt.Fprintln(os.Stderr, "IVY-PUSH-STAGE", studyordinal, os.Getenv("IVY_PUSH_STAGE"), studycalls, studyinstructions)','fmt.Fprintln(os.Stderr,"SWEEP",studyordinal,stats,events);stats=[8][3]int64{};events=[2][6]int{}')
helper+='''
var stats [8][3]int64
var events [2][6]int
func delta(id int,start uint64){stats[id][0]++;stats[id][1]+=int64(studyreadCounter()-start)-int64(studyempty)}
func measured(id int, f func() error)error{start:=studyreadCounter();e:=f();delta(id,start);return e}
'''
pre=pre.replace('import (','import (\n"fmt"\n"os"\n"runtime"\n"syscall"\n"unsafe"\n"github.com/glycerine/g3/pkg/ast/rewriter"')
key='if err := k.flushAssertedCache();';assert s.count(key)==1
s=s.replace(key,'defer studyScope()(); direction:=0\n'+key)
s=s.replace('k.flushAssertedCache()','measured(4+direction,k.flushAssertedCache)')
s=s.replace('i := k.assertedHead + step','i := k.assertedHead + step')
key='one, result = k.rewritePendingAssertion(i)';s=s.replace(key,'''start:=studyreadCounter();'''+key+'''
 delta(direction,start);if one{stats[direction][2]++}''')
key='result = k.addAssertionSubstitution(k.assertions[i], depth)';s=s.replace(key,'start=studyreadCounter();'+key+';delta(2+direction,start)')
key='depth := make(map';s=s.replace(key,'if reverse { direction=1 }; if os.Getenv("SWEEP_COUNT")!="" {rewriter.SweepCounts=&events[direction];defer func(){rewriter.SweepCounts=nil}()};'+key)
s=s.replace('return k.reducePendingAssertions()','return measured(6,k.reducePendingAssertions)')
emit(k,pre+s+helper);o=w/'sweep.json';o.write_text(json.dumps(ov));exe=w/'sweep'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
import re
survey=Path('/tmp/g3-ivy-pgo');codes={r['spec']:int(r['exit']) for g in (survey/'survey').glob('cpu-*.csv') for r in csv.DictReader(g.open()) if r['engine']=='native'};cases=(survey/'prior-gaps.txt').read_text().splitlines()
names=list(dict.fromkeys(r['case'] for r in csv.DictReader((w/'seed0_base_draw1.csv').open())))
with (w/'sweeps.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','round','collect_events','invocation','op','calls','instructions','changed','subst_lookups','subst_hits','subst_changed','cache_lookups','cache_hits','cache_changed'])
 for i in range(3):
  for name in names:
   for events in [0,1] if i==0 else [0]:
    ref=survey/'survey'/str(cases.index(name)+1)/'1/native';ex=Path('/home/jaten/ivy/ivy-lang-examples')
    r=subprocess.run(['taskset','-c','16',exe,ex/name],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',SWEEP_COUNT='1' if events else '',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=75)
    raw=[];rows=[]
    for line in r.stderr.splitlines(keepends=True):
     if not line.startswith(b'SWEEP '):raw.append(line);continue
     nums=list(map(int,re.findall(rb'-?\d+',line)));assert len(nums)==37,nums
     for j in range(7):
      extras=nums[25+6*j:31+6*j] if j<2 else ['']*6
      rows.append([name,i,events,nums[0],j,*nums[1+3*j:4+3*j],*extras])
    assert rows and (r.returncode,r.stdout,b''.join(raw))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,raw[:5])
    out.writerows(rows);f.flush()
