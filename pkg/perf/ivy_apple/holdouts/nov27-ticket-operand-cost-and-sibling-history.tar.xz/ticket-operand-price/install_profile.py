"""Aggregate complete verifier stacks measured by the previous Ticket study."""
import collections,csv,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
with (w/'install-profile.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','caller','callee','mean_million_instructions_summed_three_cases'])
 for e,root in [('g3','(*SMTKernel).internalizePending'),('native','smt::context::internalize_assertions')]:
  paths=collections.Counter()
  for r in csv.DictReader((Path('/tmp/g3-ticket-stages')/('stacks-'+e+'.csv')).open()):
   if r['case'] not in ('3','6','8'):continue
   s=r['stack'].splitlines()
   if any(t in r['stack'] for t in ('(*SMTModelChecker).checkQuantifier','smt::model_checker::check(quantifier*)','(*SMTQuantifierManager).instantiate','(*SMTQuantifierManager).Propagate.func1','(*SMTQIInstanceBuilder).MaterializeAndInternalize','smt::qi_queue::instantiate(smt::qi_queue::entry&)')):continue
   ix=next((j for j,v in enumerate(s) if root in v and (e=='native' or v.endswith(root))),None)
   if ix is None:continue
   rev=s[:ix+1][::-1]
   for k in range(min(8,len(rev))):
    caller=' > '.join(x.split('g3/pkg/')[-1] for x in rev[:k]);callee=rev[k].split('g3/pkg/')[-1];paths[caller,callee]+=int(r['count'])*int(r['period'])
  for (caller,callee),n in paths.most_common():
   out.writerow([e,caller,callee,round(n/3e6,2)])
