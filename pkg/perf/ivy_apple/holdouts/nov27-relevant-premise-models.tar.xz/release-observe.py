from pathlib import Path
import subprocess,sys,json
p=Path.cwd();w=Path(__file__).resolve().parent;mode=sys.argv[1];front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
k=p/'api/api_private_premise_model.go';s=k.read_text()
f=w/(mode+'.go.txt');f.write_text(s)
for kind in ['subset']:
 o=json.loads(Path('/tmp/g3-hybrid-gates/released/final.json' if kind=='whole' else w/'observer.json').read_text());o['Replace'][str(k)]=str(f);j=w/(mode+'-'+kind+'.json');j.write_text(json.dumps(o))
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/(mode if kind=='whole' else mode+'-observer'),'./cmd/goivy_check'],cwd=front,check=True)
