(declare-datatypes ((op_type 0)) ((op_type (nop) (ld) (st) (lda) (stl))))
(declare-sort ltime.t)
(declare-sort addr_type.t)
(declare-sort proc.t)
(declare-fun __ref.evs.op (ltime.t) op_type)
(declare-fun |__ts0__ts0__ts0__new_fml:lt_a| () ltime.t)
(declare-fun __ts0__ts0__ts0_a_b () Bool)
(declare-fun __ts0__ts0_b_b () Bool)
(declare-fun |__ts0__ts0__new_fml:lt_a| () ltime.t)
(declare-fun __ts0__ts0_a_a () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun ref.evs.op (ltime.t) op_type)
(declare-fun ref.evs.addr (ltime.t) addr_type.t)
(declare-fun |__ts0__ts0__new_loc:a_a| () addr_type.t)
(declare-fun __ts0__ts0__ts0__ts0_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0_b_a () Bool)
(declare-fun __arm.pnd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun |__fml:t| () ltime.t)
(declare-fun |__fml:a| () addr_type.t)
(declare-fun |__fml:p| () proc.t)
(declare-fun arm.pnd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.isd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.isd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__new_loc:a_a| () addr_type.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0_b_a () Bool)
(declare-fun @A () addr_type.t)
(declare-fun @T () ltime.t)
(declare-fun @P () proc.t)
(declare-fun ref.evs.p (ltime.t) proc.t)
(assert (forall ((|V0:ltime.t| ltime.t))
  (let ((a!1 (ite __ts0__ts0_b_b
                  (ite __ts0__ts0__ts0_a_b
                       (ite (= |V0:ltime.t| |__ts0__ts0__ts0__new_fml:lt_a|)
                            nop
                            (__ref.evs.op |V0:ltime.t|))
                       (__ref.evs.op |V0:ltime.t|))
                  (__ref.evs.op |V0:ltime.t|))))
  (let ((a!2 (ite __ts0_c
                  (ite __ts0__ts0_a_a
                       (ite (= |V0:ltime.t| |__ts0__ts0__new_fml:lt_a|)
                            nop
                            (__ref.evs.op |V0:ltime.t|))
                       (__ref.evs.op |V0:ltime.t|))
                  a!1)))
    (= (ref.evs.op |V0:ltime.t|) a!2)))))
(assert (= |__ts0__ts0__new_loc:a_a| (ref.evs.addr |__ts0__ts0__new_fml:lt_a|)))
(assert (= __ts0__ts0__ts0__ts0_a_a_a
   (or (= (ref.evs.op |__ts0__ts0__new_fml:lt_a|) st)
       (= (ref.evs.op |__ts0__ts0__new_fml:lt_a|) stl))))
(assert (= __ts0__ts0__ts0_b_a
   (or (= (ref.evs.op |__ts0__ts0__new_fml:lt_a|) ld)
       (= (ref.evs.op |__ts0__ts0__new_fml:lt_a|) lda))))
(assert (forall ((|V0:proc.t| proc.t)
         (|V1:addr_type.t| addr_type.t)
         (|V2:ltime.t| ltime.t))
  (let ((a!1 (and (not (and (= |V0:proc.t| |__fml:p|)
                            (= |V1:addr_type.t| |__fml:a|)
                            (= |V2:ltime.t| |__fml:t|)))
                  (__arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))
    (= (arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
       (ite __ts0_c
            (ite __ts0__ts0_a_a
                 a!1
                 (__arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))
            (__arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))))
(assert (forall ((|V0:proc.t| proc.t)
         (|V1:addr_type.t| addr_type.t)
         (|V2:ltime.t| ltime.t))
  (let ((a!1 (and (not (and (= |V0:proc.t| |__fml:p|)
                            (= |V1:addr_type.t| |__fml:a|)
                            (= |V2:ltime.t| |__fml:t|)))
                  (__arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))
    (= (arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
       (ite __ts0_c
            (ite __ts0__ts0_a_a
                 a!1
                 (__arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))
            (__arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))))
(assert (= |__ts0__ts0__ts0__new_loc:a_a|
   (ref.evs.addr |__ts0__ts0__ts0__new_fml:lt_a|)))
(assert (= __ts0__ts0__ts0__ts0__ts0_a_a_a
   (or (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a|) st)
       (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a|) stl))))
(assert (= __ts0__ts0__ts0__ts0_b_a
   (or (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a|) ld)
       (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a|) lda))))
(assert (= (not (and (arm.pnd_ld @P @A @T) (arm.isd_ld @P @A @T)))
   (and (= (ref.evs.p @T) @P) (= (ref.evs.op @T) ld) (= (ref.evs.addr @T) @A))))

(check-sat)
