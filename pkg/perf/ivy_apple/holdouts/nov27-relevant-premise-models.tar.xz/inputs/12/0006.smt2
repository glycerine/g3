(declare-sort ticket_protocol.thread)
(declare-sort ticket_protocol.ticket)
(declare-fun __l2s_saved () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun __l2s_s_0 (ticket_protocol.thread ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun l2s_s_0 (ticket_protocol.thread ticket_protocol.ticket) Bool)
(declare-fun @K () ticket_protocol.ticket)
(declare-fun ticket_protocol.t0 () ticket_protocol.thread)
(assert (= l2s_saved (ite __ts0_d __l2s_saved (or __ts0_b __l2s_saved))))
(assert (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread)
         (|V1:ticket_protocol.ticket| ticket_protocol.ticket))
  (= (l2s_s_0 |V0:ticket_protocol.thread| |V1:ticket_protocol.ticket|)
     (ite __ts0_d
          (__l2s_s_0 |V0:ticket_protocol.thread| |V1:ticket_protocol.ticket|)
          (ite __ts0_b
               (ticket_protocol.m
                 |V0:ticket_protocol.thread|
                 |V1:ticket_protocol.ticket|)
               (__l2s_s_0 |V0:ticket_protocol.thread|
                          |V1:ticket_protocol.ticket|))))))
(assert l2s_saved)
(assert (not (= (l2s_s_0 ticket_protocol.t0 @K)
        (ticket_protocol.m ticket_protocol.t0 @K))))

(check-sat)
