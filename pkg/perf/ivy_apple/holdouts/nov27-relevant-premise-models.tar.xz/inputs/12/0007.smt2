(declare-sort ticket_protocol.ticket)
(declare-fun ticket_protocol.le
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun __ticket_protocol.service () ticket_protocol.ticket)
(declare-fun l2s_s_5 () ticket_protocol.ticket)
(declare-fun l2s_saved () Bool)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun l2s_s_4 () ticket_protocol.ticket)
(declare-fun |__new_fml:x| () ticket_protocol.ticket)
(declare-fun |__fml:y| () ticket_protocol.ticket)
(declare-fun ticket_protocol.zero () ticket_protocol.ticket)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(assert (or (not l2s_saved) (ticket_protocol.le l2s_s_5 __ticket_protocol.service)))
(assert (or (not l2s_saved) (ticket_protocol.le l2s_s_4 ticket_protocol.next_ticket)))
(assert (ticket_protocol.le __ticket_protocol.service ticket_protocol.next_ticket))
(assert (not (ticket_protocol.le |__fml:y| |__new_fml:x|)))
(assert (forall ((|Z:ticket_protocol.ticket| ticket_protocol.ticket))
  (or (ticket_protocol.le |Z:ticket_protocol.ticket| |__new_fml:x|)
      (ticket_protocol.le |__fml:y| |Z:ticket_protocol.ticket|))))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
  (ticket_protocol.le |X:ticket_protocol.ticket| |X:ticket_protocol.ticket|)))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Y:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Z:ticket_protocol.ticket| ticket_protocol.ticket))
  (or (not (and (ticket_protocol.le
                  |X:ticket_protocol.ticket|
                  |Y:ticket_protocol.ticket|)
                (ticket_protocol.le
                  |Y:ticket_protocol.ticket|
                  |Z:ticket_protocol.ticket|)))
      (ticket_protocol.le |X:ticket_protocol.ticket| |Z:ticket_protocol.ticket|))))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
  (or (not (and (ticket_protocol.le
                  |X:ticket_protocol.ticket|
                  |Y:ticket_protocol.ticket|)
                (ticket_protocol.le
                  |Y:ticket_protocol.ticket|
                  |X:ticket_protocol.ticket|)))
      (= |X:ticket_protocol.ticket| |Y:ticket_protocol.ticket|))))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
  (or (ticket_protocol.le |X:ticket_protocol.ticket| |Y:ticket_protocol.ticket|)
      (ticket_protocol.le |Y:ticket_protocol.ticket| |X:ticket_protocol.ticket|))))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
  (ticket_protocol.le ticket_protocol.zero |X:ticket_protocol.ticket|)))
(assert l2s_saved)
(assert (not (ticket_protocol.le l2s_s_5 ticket_protocol.service)))

(check-sat)
