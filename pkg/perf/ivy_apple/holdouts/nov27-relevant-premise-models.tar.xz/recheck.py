from pathlib import Path
import os,sys,csv,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;variant=sys.argv[1];s=(w/'subsets.py').read_text()
src=Path('/tmp/g3-hybrid-gates/post/proofs.py').read_text().split('rank=Path(')[1];s=s[s.index('s=s.replace("w/\'proofs\''):s.index('front=(p/')].replace('s=s.replace','s=s.replace',1)
scope={'s':'rank=Path('+src};exec(s,scope);src=scope['s'].replace("w/'observer'","w/(variant+'-observer')").replace("w/'subsets.csv'","w/(variant+'-subsets.csv')").replace("range(3)","range(1)")
exec(src)
