from pathlib import Path
import csv,subprocess,json,os,re,concurrent.futures,collections
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
o=json.loads((w/'observer.json').read_text());k=p/'api/api_goal_instances_check.go';s=Path(o['Replace'][str(k)]).read_text().replace('import (','import ("os";"path/filepath";',1)
s=s.replace('answer, err := aux.child.Check()', '''if subsetCheck{snapshotNumber++;txt,e:=aux.child.String();if e!=nil{panic(e)};if e=os.WriteFile(filepath.Join(os.Getenv("SNAP"),fmt.Sprintf("%04d.smt2",snapshotNumber)),[]byte(txt+"\\n(check-sat)\\n"),0600);e!=nil{panic(e)}}
 answer, err := aux.child.Check()''')+'\nvar snapshotNumber int\n'
f=w/'dump.go.txt';f.write_text(s);o['Replace'][str(k)]=str(f);j=w/'dump.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'dump','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
rows=list(csv.DictReader((w/'subsets.csv').open()));jobs=[]
for nr in [2,3,4,12]:
 name=cases[nr-1];dir=w/'inputs'/str(nr);dir.mkdir(exist_ok=True,parents=True);ref=rank/'compat'/str(nr)/'1/native'
 r=subprocess.run([w/'dump',ex/name],cwd=w,env=dict(os.environ,SNAP=str(dir),GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True)
 lines=r.stderr.splitlines(keepends=True);assert (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith((b'SUBSET ',b'PRIVATE-COST '))))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
 chosen=[x for x in rows if x['case']==name and x['round']=='0' and x['answer']!='skipped'];inputs=sorted(dir.glob('*.smt2'));assert len(inputs)==len(chosen);jobs.extend(zip(chosen,inputs))
def run(pair):
 r,f=pair;txt=f.read_text();sorts=re.findall(r'^\(declare-sort ([^ ()]+)(?: 0)?\)$',txt,re.M);assert len(sorts)==txt.count('(declare-sort ')
 ans=[]
 for n in [0,1,2]:
  extra=''
  for j,sort in enumerate(sorts):
   cs=['|study!%d!%d|'%(j,i) for i in range(n)]
   if cs:
    assert all(c not in txt for c in cs)
    extra+=''.join('(declare-const '+c+' '+sort+')\n' for c in cs)+'(assert (forall ((x '+sort+')) (or '+' '.join('(= x '+c+')' for c in cs)+')))\n'
  dst=w/'bound'/str(n)/f.parent.name/f.name;dst.parent.mkdir(exist_ok=True,parents=True);dst.write_text(txt.replace('(check-sat)',extra+'(check-sat)'))
  try: v=subprocess.check_output([w/'native',dst,'1'],timeout=6,text=True).strip();assert v in ['sat','unknown','unsat'],v
  except subprocess.TimeoutExpired:v='timeout'
  ans.append(v)
 return [r['case'],r['ordinal'],r['allowance'],r['answer'],r['selected_indices'],str(f.relative_to(w)),*ans]
with (w/'answers.csv').open('w') as f,concurrent.futures.ThreadPoolExecutor(5) as pool:
 out=csv.writer(f);out.writerow('case ordinal allowance answer indices input unrestricted one two'.split());out.writerows(pool.map(run,jobs))
