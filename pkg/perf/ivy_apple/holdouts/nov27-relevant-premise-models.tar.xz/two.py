"""Offline pure UF control. Each bit is a fully assigned two-element structure."""
from pathlib import Path
import csv, itertools, operator, functools, random, re, time, statistics
w=Path(__file__).resolve().parent
class Unsupported(Exception): pass
def parse(txt):
 stack=[[]]
 for word in re.findall(r'\(|\)|\|[^|]*\||[^\s()]+',txt):
  if word=='(': stack.append([])
  elif word==')': value=stack.pop();stack[-1].append(value)
  else: stack[-1].append(word)
 return stack[0]
def solve(commands,width):
 rng=random.Random(42); ones=(1<<width)-1; decl={}; sorts={'Bool'}; left=ones
 def ev(e,env):
  if isinstance(e,str):
   if e in env:return env[e]
   if e in ('true','false'):return ones if e=='true' else 0
   e=[e]
  op,*args=e
  if op in ('forall','exists'):
   bind,body=args
   if len(bind)>5 or any(sort not in sorts for _,sort in bind):raise Unsupported
   universal=op=='forall'; value=ones if universal else 0
   for vals in itertools.product((0,ones),repeat=len(bind)):
    result=ev(body,dict(env,**dict(zip((n for n,_ in bind),vals))))
    value=(value&result) if universal else (value|result)
   return value
  if op=='let':
   bindings,body=args
   return ev(body,dict(env,**{n:ev(t,env) for n,t in bindings}))
  v=[ev(x,env) for x in args]
  if op=='not':return ones^v[0]
  if op=='and':return functools.reduce(operator.and_,v,ones)
  if op=='or':return functools.reduce(operator.or_,v,0)
  if op=='=>':return (ones^v[0])|v[1]
  if op=='=' and len(v)==2:return ones^v[0]^v[1]
  if op=='ite':return (v[0]&v[1])|((ones^v[0])&v[2])
  if op not in decl:raise Unsupported
  table=decl[op]
  for x in reversed(v):table=[((ones^x)&a)|(x&b) for a,b in zip(table[::2],table[1::2])]
  assert len(table)==1
  return table[0]
 for op,*args in commands:
  if op=='declare-sort' and len(args) in (1,2):sorts.add(args[0])
  elif op=='declare-fun':
   name,params,result=args
   if result not in sorts or any(t not in sorts for t in params) or len(params)>4:raise Unsupported
   decl[name]=[rng.getrandbits(width) for _ in range(1<<len(params))]
  elif op=='assert':
   left &= ev(args[0],{})
   if not left:return False
  elif op!='check-sat':raise Unsupported
 return bool(left)
with (w/'two.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['input','width','answer','us'])
 for r in csv.DictReader((w/'answers.csv').open()):
  commands=parse((w/r['input']).read_text())
  for n in [64,256,1024,4096]:
   times=[]
   for i in range(5):
    start=time.perf_counter_ns()
    try: answer=solve(commands,n)
    except Unsupported:answer='unsupported'
    times.append((time.perf_counter_ns()-start)/1000)
   assert answer is not True or r['two']=='sat'
   o.writerow([r['input'],n,answer,statistics.median(times)])
