from pathlib import Path
import csv,os,json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;prev=Path('/tmp/g3-hybrid-gates/post')
o=json.loads((prev/'proofs.json').read_text())
def edit(name,fn):
 k=p/'api'/name;f=w/(name+'.txt');f.write_text(fn(Path(o['Replace'].get(str(k),k)).read_text()));o['Replace'][str(k)]=str(f)
edit('private_observer_trial.go',lambda s:s.replace('ivyThreadIoctl(fd, enable)\n return','ivyThreadIoctl(fd, enable); subsetFD=fd\n return')+'\nvar subsetFD uintptr\nvar subsetCheck bool\nvar subsetAnswer string\n')
def observe(s):
 s=s.replace('import "github','import "fmt"\nimport "github')
 s=s.replace('input := append(subset, goal)','''indices:=[]int{};for _,h:=range subset{found:=false;for j,row:=range base.rows{if row.root==h{indices=append(indices,j);found=true;break}};if !found{panic("row")}}
    subsetAnswer="skipped";subsetCheck=true;defer func(){subsetCheck=false}();input := append(subset, goal)''')
 s=s.replace('return p.checkProofPlan(m, &shortPremisePlan{source: assertions, selected: input}, steps)','''a:=ivyThreadRead(subsetFD); b:=ivyThreadRead(subsetFD)
    yes,e:=p.checkProofPlan(m,&shortPremisePlan{source: assertions,selected:input},steps);c:=ivyThreadRead(subsetFD)
    println("SUBSET",steps,len(base.rows),subsetAnswer,yes,int64(c[0]-b[0])-int64(b[0]-a[0]),fmt.Sprint(indices));return yes,e''')
 return s
edit('api_verification_goal.go',observe)
edit('api_goal_instances_check.go',lambda s:s.replace('aux, err := p.plans.acquire','if subsetCheck{subsetAnswer="setup"};aux, err := p.plans.acquire').replace('answer, err := aux.child.Check()','answer, err := aux.child.Check();if subsetCheck{subsetAnswer=fmt.Sprint(int(answer));if limit.Limit!=0 && limit.Steps>limit.Limit{subsetAnswer+=":limit"}}').replace('import (','import ("fmt";',1))
j=w/'observer.json';j.write_text(json.dumps(o))
s=(prev/'proofs.py').read_text();s=s[s.index("subprocess.run(['go','build'"):];s=s.replace("w/'proofs'","w/'observer'").replace("w/'proofs.csv'","w/'subsets.csv'").replace('batch_width opening_attempts outcome instructions','private_outcome allowance base_rows answer proved instructions selected_indices').replace('err=[];ordinal=0','err=[];ordinal=0;pending=[]').replace("if line.startswith(b'PRIVATE-COST '):","if line.startswith(b'SUBSET '):\n     _,steps,n,answer,yes,cost,ids=line.decode().strip().split(' ',6);pending.append([steps,n,answer,yes,cost,ids])\n    elif line.startswith(b'PRIVATE-COST '):").replace('out.writerow([name,i,ordinal,width,opening,result,ins])','out.writerows([name,i,ordinal,result,*v] for v in pending);pending.clear()')
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();exec(s)
