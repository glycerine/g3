from pathlib import Path
import subprocess,shutil,os,concurrent.futures
p=Path.cwd();w=Path('/tmp/g3-relevant/release');v=w/'verified';v.mkdir(exist_ok=True)
old=Path('/tmp/g3-selective/final');shutil.copy(old/'overlay.json',w/'final.json');shutil.copy(old/'verify.py',v)
for path,target in [(w/'abc','/home/jaten/go/bin/abc'),(v/'abc','/home/jaten/go/bin/abc'),(v/'release',w/'final'),(v/'base',w/'base'),(v/'apple-base',Path('/tmp/g3-hybrid-gates/released/verified/apple-release')),(w/'native','/tmp/g3-flash-marginal/abc-control/native')]:
 if not path.exists(): path.symlink_to(target)
def build(apple):
 f=(p/('build/.boolean-enode-cost/apple-source/goivy' if apple else 'build/.boolean-enode-cost/frontend/goivy')).resolve()
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',old/('apple.json' if apple else 'overlay.json'),*([] if apple else ['-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve()]),'-o',v/'apple-release' if apple else w/'final','./cmd/goivy_check'],cwd=f,check=True)
def run(cmd,env={}): subprocess.run(['python3',*cmd],env=dict(os.environ,**env),check=True)
build(False);build(True)
(v/'long.py').write_text('from pathlib import Path\n'+(old/'long.py').read_text().split('exec(s)')[0].split('s=Path(\'/tmp/g3-plan-budget/long.py\')')[1].join(["s=Path('/tmp/g3-plan-budget/long.py')","exec(s)\n"]))
with concurrent.futures.ThreadPoolExecutor(4) as pool:
 jobs=[pool.submit(run,[v/'verify.py'],{'PANEL':'1'}),pool.submit(run,[w/'whole.py','release-whole','base','final','native'],{'CASES':'2 3 4 12 5 6 8 11','ROUNDS':'7'}),pool.submit(run,[w/'heap.py','final'],{'STEM':'release-alloc'}),pool.submit(run,[v/'long.py'])]
 for j in jobs:j.result()
