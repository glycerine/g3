from pathlib import Path
s=Path('/tmp/g3-plan-budget/long.py').read_text();s=s[:s.index('bin=Path')]+s[s.index("ex=Path"):]
s=s.replace("modes=['base','256','512']","modes=['base','release']").replace('for m in modes[i:]+modes[:i]:','for m in modes[i%2:]+modes[:i%2]:').replace("exe=bin/m if apple else (Path('/tmp/g3-live-frame-cost/recheck/baseline') if m=='base' else w/m/'release')","exe=w/(('apple-'+m) if apple else m)")
exec(s)
