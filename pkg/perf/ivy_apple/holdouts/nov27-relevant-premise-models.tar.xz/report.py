from pathlib import Path
import csv,collections,statistics as st,re
w=Path(__file__).resolve().parent
def rows(p):return list(csv.DictReader(p.open()))
def short(s):return s.rsplit('/',1)[-1]
old=rows(w/'subsets.csv');answers=rows(w/'answers.csv');p=rows(Path('/tmp/g3-hybrid-gates/post/proofs.csv'))
for case in dict.fromkeys(r['case'] for r in answers):
 batches={};b=0
 for r in p:
  if r['case']==case and r['round']=='0':
   if int(r['opening_attempts'])==0:b+=1
   batches[r['ordinal']]=b
 count=collections.Counter((batches[r['ordinal']],(w/r['input']).read_bytes()) for r in answers if r['case']==case)
 a=[r for r in old if r['case']==case and r['round']=='0']
 pairs=collections.defaultdict(list)
 for r in a:pairs[r['ordinal']].append(set(r['selected_indices'][1:-1].split()))
 print(short(case),'same batch repeats',sum(n-1 for n in count.values()),'paired sets',collections.Counter('equal' if x==y else 'subset' if x<y else 'superset' if x>y else 'incomparable' for x,y in pairs.values() if False) if False else collections.Counter(('equal' if v[0]==v[1] else 'subset' if v[0]<v[1] else 'superset' if v[0]>v[1] else 'incomparable') for v in pairs.values() if len(v)==2))
 print('base',collections.Counter((r['allowance'],r['answer']) for r in a))
 if (w/'final-subsets.csv').exists():
  new=[r for r in rows(w/'final-subsets.csv') if r['case']==case]
  print('new',collections.Counter((r['allowance'],r['answer']) for r in new))
for file in [w/'release/release-whole.csv',*(w/'release/verified').glob('*/long.csv')]:
 data=rows(file)
 for case in dict.fromkeys(r['case'] for r in data):
  v={m:[int(r['instructions']) for r in data if r['case']==case and r['mode']==m] for m in dict.fromkeys(r['mode'] for r in data)}
  a,b=list(v.values())[:2];ms={m:round(st.median(float(r['ms']) for r in data if r['case']==case and r['mode']==m)) for m in v}
  print(short(case),len(b),'%=',round(st.median((y/x-1)*100 for x,y in zip(a,b)),2),'ms=',ms)
for f in w.glob('bench-*.log'):
 print(f.name,[(n,st.median(map(float,v))) for n,v in [(n,re.findall(n+r'\s+500\s+([\d.]+) ns/op',f.read_text())) for n in ('BenchmarkPrivateSatisfiablePremisePlan','BenchmarkPrivateHybridMemberPlan')]])
