from pathlib import Path
import subprocess,sys,json
p=Path.cwd();w=Path(__file__).resolve().parent;mode=sys.argv[1];front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
k=p/'api/api_private_premise_model.go';s=k.read_text()
if mode=='forced':
 s=s.replace('visits        int','variables int\n visits int')
 # Extract only requested literal polarities. The original evaluator validates the whole model.
 s=s.replace('possible := ^uint64(0)','''for i:=len(roots)-1;i>=0;i--{v.seed(roots[i],true,0)}
 possible := ^uint64(0)''')
 s=s.replace('len(v.predicates) == len(columns)','v.variables == len(columns)').replace('columns[len(v.predicates)]','columns[v.variables];v.variables++')
 s+='''
func(v *premiseModel) seed(h ast.ASTHandle,positive bool,depth int) {
 if depth>16 || v.visits>=256{return};v.visits++
 hd,e:=v.manager.NodeHeader(h);if e!=nil{return}
 if hd.Kind==ast.ASTQuantifier {b,e:=v.manager.GetQuantifierBody(h);if e==nil{v.seed(b,positive,depth+1)};return}
 if hd.Kind!=ast.ASTApp{return}
 if hd.Family==ast.NullFamilyID {b,e:=v.manager.HasBoolSort(h);if e==nil&&b {if positive{v.predicates[hd.Decl]=^uint64(0)}else{v.predicates[hd.Decl]=0}};return}
 if hd.Family!=v.manager.BasicFamilyID(){return}
 switch hd.DeclKind {
 case ast.ASTOpNot: a,e:=v.manager.GetArg(h,0);if e==nil{v.seed(a,!positive,depth+1)}
 case ast.ASTOpAnd,ast.ASTOpOr:
 if (hd.DeclKind==ast.ASTOpAnd)==positive && hd.NumArgs<=64 {for i:=uint32(0);i<hd.NumArgs;i++{a,e:=v.manager.GetArg(h,i);if e==nil{v.seed(a,positive,depth+1)}}}
 }
}
'''
 s=s.replace('v.seed(roots[i],true,0)}','v.seed(roots[i],true,0)};v.visits=0')
elif mode=='columns':
 s=s.replace('if len(v.predicates) == len(columns) {\n\t\t\treturn premiseTruth{}\n\t\t}\n\t\tmask = columns[len(v.predicates)]','''n:=len(v.predicates)
 if n<6 {mask=columns[n]} else {mask=columns[n%6]^columns[(n/6+n+1)%6]}''')
elif mode in ('enumerate','random'):
 # Block 0 preserves the six independent columns. Subsequent blocks
 # assign higher columns explicitly, without traversing untouched declarations.
 s=s.replace('visits        int','block int; overflow bool; names map[ast.ASTHandle]int; visits int')
 a=s.index('possible :=');b=s.index('\n}',a)
 body=s[a:b].replace('return false','break').replace('return !v.collapsedSort || purePremiseTerms(m, roots)','if possible!=0 && !m.ResourceLimit().CancelFlag() && (!v.collapsedSort || purePremiseTerms(m, roots)){return true}')
 s=s[:a]+"""v.names=make(map[ast.ASTHandle]int)
 for {v.overflow=false
 """+body+"""
 if !v.overflow || v.block>=63 || (len(v.names)<12 && (1<<(len(v.names)-6))<=v.block+1) || m.ResourceLimit().CancelFlag(){return false}
 v.block++;clear(v.values);clear(v.predicates);v.collapsedSort=false;v.visits=0
 }"""+s[b:]
 a=s.index('if len(v.predicates) == len(columns)');b=s.index('v.predicates[decl] = mask',a)
 frag="""n,found:=v.names[decl];if !found{n=len(v.names);v.names[decl]=n}
 if n<6 {mask=columns[n]}else if n<12{v.overflow=true;if v.block&(1<<(n-6))!=0{mask=^uint64(0)}}else{return premiseTruth{}}
 """
 if mode=='random':
  frag="""n:=len(v.predicates);if n<6{mask=columns[n]}else{mask=uint64(n)*0x9e3779b97f4a7c15;mask=(mask^(mask>>30))*0xbf58476d1ce4e5b9;mask=(mask^(mask>>27))*0x94d049bb133111eb;mask ^= mask>>31}
 """
 s=s[:a]+frag+s[b:]
else:raise Exception(mode)
f=w/(mode+'.go.txt');f.write_text(s)
for kind in ['whole','subset']:
 o=json.loads(Path('/tmp/g3-hybrid-gates/released/final.json' if kind=='whole' else w/'observer.json').read_text());o['Replace'][str(k)]=str(f);j=w/(mode+'-'+kind+'.json');j.write_text(json.dumps(o))
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/(mode if kind=='whole' else mode+'-observer'),'./cmd/goivy_check'],cwd=front,check=True)
