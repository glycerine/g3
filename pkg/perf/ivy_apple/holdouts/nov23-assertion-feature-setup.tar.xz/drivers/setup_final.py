from study import *
import setup_release as sr, setup_controls as ctrl
d=sr.d/'final';d.mkdir(exist_ok=True)
def focused():
 with(w/'build.lock').open('a')as lk:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for n,cmd in [('packages',['go','test','-p','5','-count=1','./ast','./smtcore','./tactic/portfolio','./api','./cmd/g3']),('diagnostics',['go','test','-p','5','-count=1','-tags=g3debug,g3trace','-run','(?i)setup|staticfeatures|assertedbounds','./smtcore','./ast','./cmd/g3'])]:
   with(d/(n+'.txt')).open('w')as f:run(cmd,cwd=pkg,stdout=f,stderr=f)
def benches():
 with(w/'build.lock').open('a')as lk:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','5','-c','-o',d/'setup.test','./smtcore'],cwd=pkg)
 bs={'previous':w/'setup-features-trials/control/setup.test','release':d/'setup.test'}
 with(d/'bench.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['round','variant','case','ns','bytes','allocs'])
  for i in range(9):
   for n in list(bs)[::1 if i%2==0 else -1]:
    p=run(['taskset','-c','5',bs[n],'-test.cpu','1','-test.run','^$','-test.bench','^BenchmarkSMTAssertionFeatureSetup$','-test.benchtime','50x','-test.benchmem'],cwd=pkg/'smtcore',capture_output=True,text=True);ls=[l.split()for l in p.stdout.splitlines()if l.startswith('Benchmark')];assert len(ls)==4
    for a in ls:z.writerow([i+1,n,a[0],a[2],a[a.index('B/op')-1],a[a.index('allocs/op')-1]])
    f.flush()
def shells():
 b=build(d/'shell',shell=True);ctrl.d=d;ctrl.shell({'control':w/'setup-features-trials/control/shell/g3','release':b})
if __name__=='__main__':
 with ThreadPoolExecutor(3)as e:
  fs=[e.submit(x)for x in (focused,benches,shells)]
  for f in fs:f.result()
