from study import *
import setup_limit_audit as au,setup_features_trials as old,setup_panels as pans,setup_controls as ctrl,guarded_live as gl,simplifier_rebuild as sh
d=w/'setup-bound-release';d.mkdir(exist_ok=True)
def budgets():
 dest=d/'limits';dest.mkdir(exist_ok=True);src=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'))
 fam={'int':'(declare-const i Int)(assert (> (* 5 i) 13))(assert (< i 12))','real':'(declare-const x Real)(assert (> (+ x (/ 12345678987654321 1234567)) 0))','fpa':'(declare-const x Float32)(assert (fp.isNaN x))','array':'(declare-const a (Array Int (Array Bool Real)))(assert (> (select (select a 0) true) 0))','bv':'(declare-const x (_ BitVec 77))(assert (bvult x (_ bv2312331 77)))','qs':'(declare-fun f (Int) Int)(assert (forall ((x Int)) (! (> (f x) x) :pattern ((f x)))))','strings':'(declare-const s String)(assert (= (str.++ s s) "ab"))','shared':'(declare-const a Bool)(declare-const b Bool)(define-fun ab () Bool (and a b))(assert (or ab (not ab) ab))'}
 cases={p.name:re.sub(rb'\(set-option\s+:rlimit\s+\d+\)','',p.read_bytes()) if False else re.sub(rb'\(set-option\s+:rlimit\s+\d+\)',b'',p.read_bytes())for p in src[::6]}
 for n,v in fam.items():
  for action,suff in [('check','(check-sat)'),('incremental','(push)(check-sat)(pop)(check-sat)'),('profile','(set-option :smt.string_solver auto)(check-sat)')]:
   cases[n+'-'+action]='(set-logic ALL)'.encode()+v.encode()+suff.encode()
 bs={'previous':old.d/'control/shell/g3','shared':au.d/'shared/shell/g3'}
 def lane(item):
  cpu,fs=item
  with(dest/(str(cpu)+'.csv')).open('w')as f:
   z=csv.writer(f);z.writerow('case limit mode exit results count match timedout'.split())
   for n,base in fs:
    for steps in (1,2,4,8,16,31,64,127,255,512,1024,2048,4096,6000,8000,16384,65536,80000,100000,0xffffffff):
     data=f'(set-option :rlimit {steps})\n'.encode()+base+b'\n(get-info :all-statistics)\n';exp=None
     for mode,b in bs.items():
      try:r=subprocess.run(['taskset','-c',str(cpu),b,'-smt2','-in'],input=data,capture_output=True,timeout=16,env=dict(env,GOMAXPROCS='1'));rc,o,e=r.returncode,r.stdout,r.stderr
      except subprocess.TimeoutExpired:rc,o,e=124,b'',b''
      sig=(rc,[v.strip()for v in o.splitlines() if v.strip() in (b'sat',b'unknown',b'unsat')or v.startswith(b'(error')],re.findall(rb':rlimit-count\s+(\d+)',o),e)
      if exp is None:exp=sig
      z.writerow([n,steps,mode,rc,b'|'.join(sig[1]).decode(),b':'.join(sig[2]).decode(),int(sig==exp),int(rc==124)]);f.flush()
      if sig!=exp:(dest/f'{n}-{steps}-{mode}.txt').write_text(repr(exp)+'\n'+repr(sig))
 with ThreadPoolExecutor(8)as e:list(e.map(lane,[(c,list(cases.items())[i::8])for i,c in enumerate([0,3,6,8,12,16,18,24])]))
def panels():
 bs={'previous':old.d/'control/checker/goivy_check','g3':au.d/'shared/checker/goivy_check','native':pans.bs['native']};gl.d=d;js=pans.jobs
 sh.d=d/'phases';sh.d.mkdir(exist_ok=True);cs=[0,3,6,8,12,16];fs=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));ss={'previous':old.d/'control/shell/g3','release':au.d/'shared/shell/g3','native':pkg.parent/'build/z3'}
 with ThreadPoolExecutor(len(js)+len(cs))as e:
  fx=[e.submit(gl.measure_job,j,bs)for j in js]+[e.submit(sh.lane,(c,fs[i::len(cs)],ss))for i,c in enumerate(cs)]
  for f in fx:f.result()
def controls():
 ctrl.d=d;ctrl.shell({'control':old.d/'control/shell/g3','release':au.d/'shared/shell/g3'})
if __name__=='__main__':{'budgets':budgets,'panels':panels,'controls':controls}[sys.argv[1]]()
