from study import *
import setup_features_trials as se,setup_controls as sc, guard_sort_trials as gst,pristine_simplify as pp
from panel import CASES
d=w/'setup-limit-audit';d.mkdir(exist_ok=True)
def buildAudit():
 r=pkg/'smtcore/smt_setup_real.go';s=r.read_text();s=once(s,'import (','import (\n"os"');a='features, err := ast.NewStaticFeatures(k.manager)';s=once(s,a,'''limit:=k.manager.ResourceLimit();initial:=limit.Count();defer func(){fmt.Fprintf(os.Stderr,"COLLECT-AUDIT %d %d %t %t %t %d\\n",limit.Limit,limit.Count()-initial, limit.CancelFlag(), k.manager.TraceStream!=nil,k.manager.NumeralService().RuntimeOwner().AllocationLimited(),len(k.assertions))}();'''+a)
 q=pp.q;t=pp.edit('guards')[q];a='func(t *SimplifyTactic) trialPristine() bool {';t=once(t,a,a+'''
  defer func(){m:=t.manager;fmt.Fprintf(os.Stderr,"PRISTINE-GUARDS %t %t %t %t %d %t\\n", t.trace!=nil, m.TraceStream!=nil,m.Budget().InjectionArmed(),m.NumeralService().RuntimeOwner().AllocationLimited(),m.ResourceLimit().Limit,m.ResourceLimit().CancelFlag())}()
 ''');t=once(t,'import (','import (\n"fmt"\n"os"')
 o=overlay(d/'audit/overlay',{r:s,q:t})
 return build(d/'audit/checker',o=o),build(d/'audit/shell',o=o,shell=True)
def trial():
 q=pkg/'smtcore/smt_asserted_bounds.go';s=q.read_text();s=once(s,'k.manager.ResourceLimit().Limit != 0 || k.manager.ResourceLimit().CancelFlag()','k.manager.ResourceLimit().CancelFlag()')
 o=overlay(d/'shared/overlay',{q:s});return build(d/'shared/checker',o=o),build(d/'shared/shell',o=o,shell=True)
def census(bs):
 from collections import Counter
 ck,s=bs;files=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'))
 jobs=[(f.name,[s,'-smt2',f])for f in files]
 for n in ['ordinary','tlb','rfn2','cf_live','toy-consensus']:
  sp,iso=('jea/hermes_rmw_o3.ivy','')if n=='ordinary'else CASES[n][:2];jobs.append((n,[ck,*(['isolate='+iso]if iso else[]),examples/sp]))
 o=d/'census';o.mkdir(exist_ok=True)
 def one(item):
  n,a=item;od=o/n;od.mkdir(exist_ok=True);p=subprocess.run(a,cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100'));lines=p.stderr.splitlines();c=Counter(l.decode()for l in lines if l.startswith((b'PRISTINE-',b'COLLECT-')));(od/'report.csv').write_text('observations,line\n'+''.join(str(x)+','+l+'\n'for l,x in sorted(c.items())));print(n,len(lines),sum(x for l,x in c.items()if l.startswith('COLLECT')and int(l.split()[2])!=0),flush=True)
 with ThreadPoolExecutor(6)as e:list(e.map(one,jobs))
def comparisons(bs):
 # Sweep step limits over arithmetic and quantified inputs and preserve diagnostics and result transitions.
 ss={'previous':se.d/'control/shell/g3','release':w/'setup-features-release/final/shell/g3','shared':bs[1]};dest=d/'bounded';dest.mkdir(exist_ok=True);fs=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'))[:9]+sorted((w/'simplifier-rebuild/inputs').glob('quantified*.smt2'))[:9]
 fs += sorted((w/'setup-features-release/final/setup-inputs').glob('True-*-*-check.smt2'))
 fs += sorted((w/'branch-controls/inputs').glob('*-stats.smt2'))
 def one(item):
  cpu,items=item
  with(dest/f'{cpu}.csv').open('w')as f:
   z=csv.writer(f);z.writerow(['case','limit','version','rc','answers','rlimit-count','same','timeout'])
   for p in items:
    data=p.read_bytes()
    for limit in (1,16,64,256,1024,4096,16384,65536,0xffffffff):
     expected=None
     for n,b in ss.items():
      try:r=subprocess.run(['taskset','-c',str(cpu),b,'-in','-smt2','rlimit='+str(limit)],input=data+b'\n(get-info :all-statistics)\n',capture_output=True,timeout=22,env=dict(env,GOMAXPROCS='1'));rc,out,er=r.returncode,r.stdout,r.stderr
      except subprocess.TimeoutExpired:rc,out,er=124,b'',b''
      counts=re.findall(rb':rlimit-count\s+(\d+)',out)
      text=b'\n'.join(l for l in out.splitlines()if l.strip() in (b'sat',b'unsat',b'unknown')or l.startswith(b'(error'))
      sig=(rc,text,counts,er)
      if expected is None:expected=sig
      z.writerow([p.name,limit,n,rc,text.decode().replace('\n','|'),':'.join(v.decode()for v in counts),int(sig==expected),int(rc==124)]);f.flush()
 with ThreadPoolExecutor(8)as e:list(e.map(one,[(c,fs[i::8])for i,c in enumerate([0,3,6,8,12,16,18,24])]))
if __name__=='__main__':
 with ThreadPoolExecutor(2)as e:
  a=e.submit(lambda:census(buildAudit()));b=e.submit(lambda:comparisons(trial()));a.result();b.result()
