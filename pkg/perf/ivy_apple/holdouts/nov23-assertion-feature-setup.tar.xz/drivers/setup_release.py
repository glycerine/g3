from study import *
import setup_features_trials as exp
d=w/'setup-features-release';d.mkdir(exist_ok=True)
src=exp.core
methods='arithmeticSetupFeatures|setupIntegerDifferencePolicy|setupRealDifferencePolicy|setupUFIntegerDifferencePolicy|setupIntegerLogicPolicy|setupRealLogicPolicy|setupSimpleLogicPolicy|setupArrayLogicPolicy|setupQuantifiedLogicPolicy|setupUnknownStaticPolicy|setupSequenceBackend|setupProfilePlugins|setupPluginSet|installMissingSetupPlugin|setupBasicArithmetic'
def edits():
 ed={}
 # Source files below are the pristine copies from git, to allow rebuilding the trial after installing it.
 for n in ['smt_setup.go','smt_setup_real.go','smt_setup_difference.go','smt_setup_integer.go','smt_setup_simple.go','smt_setup_array.go','smt_setup_quantified.go','smt_setup_unknown.go','smt_setup_basic_arithmetic.go','smt_asserted_bounds.go','smt_verbose_progress.go']:
  f=src/n
  s=run(['git','show','65c839c66:pkg/smtcore/'+n],cwd=pkg,capture_output=True,text=True).stdout
  s=re.sub(r'func \(k \*SMTKernel\) ('+methods+r')\(',r'func (k *smtSetup) \1(',s)
  if n.startswith('smt_setup'):
   s=s.replace('features.Close()', 'k.releaseFeatures(features)')
  if n=='smt_setup_real.go':
   s=once(s,'func (k *SMTKernel) setupStaticFeatures(enabled bool) (*ast.StaticFeatures, error) {\n\tif !enabled {\n\t\treturn nil, nil\n\t}', 'func (k *SMTKernel) collectSetupFeatures() (*ast.StaticFeatures, error) {')
   s=once(s,'errors.Join(err, k.releaseFeatures(features))','errors.Join(err, features.Close())')
  elif n=='smt_verbose_progress.go':
   s=s.replace('k.setupStaticFeatures(true)','k.collectSetupFeatures()')
  elif n=='smt_asserted_bounds.go':
   a=s.index('// Source setup_AUFLIA')
   s=s[:a]+'''// smtSetup owns the read-only formula statistics for one first push or check.
 // Setup may install theories and adjust options. Its asserted formulas stay
 // fixed until all policies have finished, including on a failed attempt.
 type smtSetup struct {
    *SMTKernel
    features *ast.StaticFeatures
    preserveAllocations bool
 }

 func (k *smtSetup) setupStaticFeatures(enabled bool)(*ast.StaticFeatures,error) {
    if !enabled {return nil,nil}
    if k.preserveAllocations {return k.collectSetupFeatures()}
    if k.features==nil {
       features,err:=k.collectSetupFeatures()
       if err!=nil{return nil,err}
       k.features=features
    }
    return k.features,nil
 }

 // A policy borrows the shared summary. Diagnostic and allocation-failure
 // runs own a separate summary at each original collection point.
 func(k *smtSetup)releaseFeatures(features *ast.StaticFeatures)error{
     if features==nil || features==k.features{return nil}
     return features.Close()
 }

'''+s[a:]
   s=once(s,'\t// setup::operator()', '''    setup:=smtSetup{
        SMTKernel:k,
        preserveAllocations: ast.ASTSourceDebug || diagnostic.VerboseProgress || k.manager.TraceStream!=nil ||
                k.manager.Budget().InjectionArmed() || k.manager.NumeralService().RuntimeOwner().AllocationLimited() ||
                k.manager.ResourceLimit().Limit!=0 || k.manager.ResourceLimit().CancelFlag(),
    }
    err:=setup.configure(useStaticFeatures)
    if setup.features!=nil {err=errors.Join(err, setup.features.Close())}
    if err==nil {k.preprocessingSetupDone=true}
    return err
 }

 func(k *smtSetup)configure(useStaticFeatures bool) error {
    // setup::operator()''')
  elif n=='smt_setup_basic_arithmetic.go':
   a=s.index('// Basic setup');b=s.index('\tarithmetic :=',a)
   s=s[:a]+'''// The retained arithmetic specializations keep int_only and fixnum false.
 // The arithmetic mode selects the backend without inspecting the formulas.
 func (k *smtSetup) setupBasicArithmetic() (result error) {
    if k.preserveAllocations {
       features,err:=k.setupStaticFeatures(true)
       if err!=nil{return err}
       defer func(){result=errors.Join(result,k.releaseFeatures(features))}()
    }
'''+s[b:]
  elif n=='smt_setup.go':
   s=once(s,'features, err := k.setupStaticFeatures(true)','inspectProfile := k.smtState.AutoConfig && useStaticFeatures\n\t\tfeatures, err := k.setupStaticFeatures(inspectProfile || k.preserveAllocations)')
   s=once(s,'if k.smtState.AutoConfig && useStaticFeatures && !smtUnknownSetupUsesSequences(features) {','if inspectProfile && !smtUnknownSetupUsesSequences(features) {')
   s=once(s,'case "auto":\n\t\t\tlegacy =', '''case "auto":
           if features==nil {
              features,err=k.setupStaticFeatures(true)
              if err!=nil{return err}
           }
           legacy =''')
  if n=='smt_asserted_bounds.go':s=s.replace('\n\t\tk.preprocessingSetupDone = true','').replace('\n\tk.preprocessingSetupDone = true','')
  ed[f]=s
 return ed
def main():
 sources=edits();o=overlay(d/'overlay',sources)
 if '--apply'in sys.argv:
  for k in sources:k.write_bytes((d/'overlay'/k.name).read_bytes())
 if '--build'in sys.argv:
  bs=[(d/'shell','g3',True),(d/'checker','g3',False)]
  with ThreadPoolExecutor(2)as e:list(e.map(lambda a:build(a[0],a[1],o,a[2]),bs))
if __name__=='__main__':main()
