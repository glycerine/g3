from study import *
import guarded_live as gl,setup_features_trials as se,setup_release as sr
from panel import CASES
from verification_frontier import cases,reference
d=sr.d;gl.d=d;bs={'previous':se.d/'control/checker/goivy_check','g3':d/'checker/goivy_check','native':w/'key-release/native/goivy_check'}
jobs=[(4,'ordinary','jea/hermes_rmw_o3.ivy','',0,4,w/'guarded-live/ordinary-11/1-native'),(9,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native'),(13,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native')]
for c,n in zip([0,1,2,3,6,7,8,10,12],['tlb','rfn2','cf_live','hybrid_reliable_broadcast_cisa','flash2','raftok','toy-consensus','dramc_nb2','raft_no_assume_test']):
 sp,iso,_,f,u=CASES[n];jobs.append((c,n,sp,iso,int(bool(f or u)),4,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
for j,c in zip([5,6,7,8,9],[11,14,16,17,18]):
 sp=cases[j];rf=reference(sp);jobs.append((c,'corpus-'+str(j),sp,'',int(b'[FAIL]'in (rf/'stdout').read_bytes()),4,rf))
if __name__=='__main__':
 with ThreadPoolExecutor(len(jobs))as e:
  fs=[e.submit(gl.measure_job,j,bs) for j in jobs]
  for f in fs:f.result()
