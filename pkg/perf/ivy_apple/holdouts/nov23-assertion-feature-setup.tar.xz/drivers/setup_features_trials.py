from study import *
from collections import Counter
import simplifier_rebuild as shell,guarded_live as gl
from panel import CASES
d=w/'setup-features-trials';d.mkdir(exist_ok=True)
core=pkg/'smtcore';real=core/'smt_setup_real.go';basic=core/'smt_setup_basic_arithmetic.go';seq=core/'smt_setup.go';bounds=core/'smt_asserted_bounds.go'
def get(v):
 ed={}
 def read(f):return ed.get(f,f.read_text())
 if v=='census':
  s=once(real.read_text(),'"errors"','"errors"\n"runtime"\n"os"')
  ed[real]=s.replace('return features, nil','pc,_,_,_:=runtime.Caller(1); caller:=runtime.FuncForPC(pc).Name(); fmt.Fprintf(os.Stderr,"SETUPFEATURES %p %s %s %d %d %d %d %d %d\\n",k,k.setupLogic,caller,len(k.assertions),features.NumRoots,features.NumExprs,features.NumSharing,features.NumQuantifiers,features.NumBoolExprs);return features,nil',1)
  return ed
 if v=='control':return ed
 if 'demand'in v:
  s=basic.read_text();s=s[:s.index('\tfeatures, err :=')]+s[s.index('\tarithmetic :='):];ed[basic]=s.replace('import "errors"','')
  s=seq.read_text();a=s.index('\t\tfeatures, err :=');b=s.index('\t\t\t// setup_unknown(st)',a)
  s=s[:a]+'''        choice,_,err:=k.manager.Symbols.BareString(k.smtState.StringSolver);if err!=nil{return err}
                 inspect:=k.smtState.AutoConfig && useStaticFeatures
                 features, err:=k.setupStaticFeatures(inspect || choice=="auto");if err!=nil{return err}
                 if features!=nil{defer func(){result=errors.Join(result,features.Close())}()}
                 if inspect && !smtUnknownSetupUsesSequences(features) {
'''+s[b:]
  s=once(s,'\t\tchoice, _, err := k.manager.Symbols.BareString(k.smtState.StringSolver)\n\t\tif err != nil {\n\t\t\treturn err\n\t\t}\n','')
  ed[seq]=s
 if 'share'in v:
  # Feature summaries belong to a single setup invocation, including early exits.
  # The instrumented verbose implementation keeps its separate source diagnostics.
  s=read(real)
  s=once(s,'func (k *SMTKernel) setupStaticFeatures(enabled bool)', '''type smtSetup struct {
     *SMTKernel
     features *ast.StaticFeatures
  }
  func(k *smtSetup) setupStaticFeatures(enabled bool)(*ast.StaticFeatures,error){
     if !enabled{return nil,nil}
     if k.features==nil {v,e:=k.SMTKernel.setupStaticFeatures(true);if e!=nil{return nil,e};k.features=v}
     return k.features,nil
  }
  func (k *SMTKernel) setupStaticFeatures(enabled bool)''')
  s=once(s,'return nil, errors.Join(fmt.Errorf("Benchmark contains uninterpreted function symbols, but specified logic does not support them."), features.Close())','return nil,fmt.Errorf("Benchmark contains uninterpreted function symbols, but specified logic does not support them.")');ed[real]=s
  for f in [real,seq,basic,*[core/('smt_setup_'+n+'.go')for n in ('array','integer','quantified','difference','unknown','simple')]]:
   s=read(f)
   funcs='arithmeticSetupFeatures|setupIntegerDifferencePolicy|setupRealDifferencePolicy|setupUFIntegerDifferencePolicy|setupIntegerLogicPolicy|setupRealLogicPolicy|setupSimpleLogicPolicy|setupArrayLogicPolicy|setupQuantifiedLogicPolicy|setupUnknownStaticPolicy|setupSequenceBackend|setupProfilePlugins|setupPluginSet|installMissingSetupPlugin|setupBasicArithmetic'
   s=re.sub(r'func \(k \*SMTKernel\) ('+funcs+r')\(',r'func (k *smtSetup) \1(',s)
   s=re.sub(r'(?m)^\s*defer func\(\) \{ result = errors.Join\(result, features.Close\(\)\) \}\(\)\n','\n',s)
   s=s.replace('if features!=nil{defer func(){result=errors.Join(result,features.Close())}()}','')
   s=re.sub(r'\bif features != nil \{\s*\}', '',s)
   if 'errors.'not in s:s=s.replace('import "errors"','').replace('\t"errors"\n','')
   if f==basic and v=='share':s=s.replace('features, err := k.setupStaticFeatures(true)','_, err := k.setupStaticFeatures(true)')
   ed[f]=s
  s=once(read(bounds),'func (k *SMTKernel) setupAssertedBounds(useStaticFeatures bool) error {','''func (kernel *SMTKernel) setupAssertedBounds(useStaticFeatures bool)(result error){
    k:=smtSetup{SMTKernel:kernel}
    defer func(){if k.features!=nil {result=errors.Join(result,k.features.Close())}}()
''');ed[bounds]=s
 return ed
def do_census():
 dr=d/'census';ov=overlay(dr/'overlay',get('census'));s=build(dr/'shell',o=ov,shell=True);b=build(dr/'checker',o=ov)
 files=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'))
 def record(i):
  p=run([s,'-smt2',i],capture_output=True,env=dict(env,GOMAXPROCS='1'));assert p.stdout.strip() in (b'sat',b'unsat',b'unknown');return i.name,p.stderr
 with ThreadPoolExecutor(4)as x:
  with(dr/'shell.csv').open('w')as f:
   z=csv.writer(f);z.writerow(['case','solver','logic','caller','assertions','roots','exprs','shared','quantifiers','bools'])
   for name,raw in x.map(record,files):
    for l in raw.decode().splitlines():
     if l.startswith('SETUPFEATURES '):z.writerow([name,*l.split(' ')[1:]])
 def job(n,sp,iso,rc):
  o=dr/n;o.mkdir(exist_ok=True);cmd=[b]+(['isolate='+iso] if iso else[])+[examples/sp]
  with(o/'stdout').open('w')as out,(o/'stderr').open('w')as err:
   p=subprocess.run(cmd,cwd=o,stdout=out,stderr=err,env=dict(env,GOMAXPROCS='1'));assert p.returncode==rc,(p.returncode,sp)
 with ThreadPoolExecutor(4)as e:
  fs=[e.submit(job,'ordinary','jea/hermes_rmw_o3.ivy','',0)]
  for n in ['tlb','rfn2','raftok']:
   sp,iso,_,f,u=CASES[n];fs.append(e.submit(job,n,sp,iso,int(bool(f or u))))
  for f in fs:f.result()
def main():
 vs=['control','share','share-demand','demand']
 def buildone(v):
  dr=d/v;ov=overlay(dr/'overlay',get(v));return build(dr/'shell',o=ov,shell=True),build(dr/'checker',o=ov)
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(buildone,vs)))
 sh={v:b[0]for v,b in bs.items()};sh['native']=pkg.parent/'build/z3';gl.d=d;bs={v:p[1]for v,p in bs.items()}
 files=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));shell.d=d/'phases';shell.d.mkdir(exist_ok=True);cs=[0,3,6,8,12,16]
 jobs=[(4,'ordinary','jea/hermes_rmw_o3.ivy','',0,3,w/'guarded-live/ordinary-11/1-native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native')]
 for c,n in zip([1,2,7,9,10,13,14,18],['tlb','hybrid_reliable_broadcast_cisa','flash2','toy-consensus','rfn2','dramc_nb2','raftok','raft_no_assume_test']):
  sp,iso,_,f,u=CASES[n];jobs.append((c,n,sp,iso,int(bool(f or u)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(len(cs)+len(jobs))as e:
  fs=[e.submit(shell.lane,(c,files[i::len(cs)],sh))for i,c in enumerate(cs)]+[e.submit(gl.measure_job,j,bs)for j in jobs]
  for f in fs:f.result()
if __name__=='__main__':
 if 'census'in sys.argv:do_census()
 else:main()
