from study import *
import simplifier_rebuild as sh,guarded_live as gl,setup_controls as ctrl
from panel import CASES
d=w/'pristine-simplify';d.mkdir(exist_ok=True)
q=pkg/'tactic/core/simplify_tactic.go'
def edit(v):
 if v=='control':return {}
 s=q.read_text()
 s=once(s,'paramsReady bool','paramsReady bool\n pristine bool')
 if v=='guards':
  extra='''
  func(t *SimplifyTactic) trialPristine() bool {
   if ast.ASTSourceDebug || t.trace!=nil || t.manager.TraceStream!=nil || t.manager.Budget().InjectionArmed() || t.manager.NumeralService().RuntimeOwner().AllocationLimited() || t.manager.ResourceLimit().Limit!=0 || t.manager.ResourceLimit().CancelFlag() {return false}
   proofs,e:=t.manager.ProofsEnabled();if e!=nil||proofs{return false}
   if e=t.globals.CheckOwner(t.context,t.manager.Budget());e!=nil{return false}
   params,e:=t.globals.SourceGetModuleName("rewriter");if e!=nil{return false}
   empty,e:=t.context.Empty(&params);closeErr:=t.context.Del(&params);return e==nil&&closeErr==nil&&empty
  }
  '''
  start='t.trialPristine()';can='t.trialPristine()'
 else:extra='';start='true';can='true'
 x='return t, nil\n}';s=once(s,x,'t.pristine='+start+'\n'+x+extra)
 x='return t.rewriteGoal(goal)';s=once(s,x,'t.pristine=false\n'+x)
 x='if err := t.context.Assign(&t.params, params)';s=once(s,x,'t.pristine=false\n'+x)
 x='// A previous reconstruction can fail';s=once(s,x,'if t.pristine && t.rewriter!=nil && '+can+' {t.steps=0;return nil};t.pristine=false\n'+x)
 x='t.steps = 0\n\treturn err';s=once(s,x,'t.pristine=err==nil && '+start+'\n'+x)
 return {q:s}
def main():
 vs=['control','pristine','guards']
 def mk(v):
  dr=d/v;o=overlay(dr/'overlay',edit(v));return build(dr/'shell',o=o,shell=True),build(dr/'checker',o=o)
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 sh.d=d/'phases';sh.d.mkdir(exist_ok=True);gl.d=d
 cs=[0,3,6,8,12,16];files=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));ss={v:b[0]for v,b in bs.items()};ss['native']=pkg.parent/'build/z3';bb={v:b[1]for v,b in bs.items()}
 js=[(4,'ordinary','jea/hermes_rmw_o3.ivy','',0,3,w/'guarded-live/ordinary-11/1-native')]
 for c,n in zip([1,2,7,9,10,13,14,18],['tlb','hybrid_reliable_broadcast_cisa','flash2','toy-consensus','rfn2','dramc_nb2','raftok','raft_no_assume_test']):
  sp,iso,_,f,u=CASES[n];js.append((c,n,sp,iso,int(bool(f or u)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(len(cs)+len(js))as e:
  fs=[e.submit(sh.lane,(c,files[i::len(cs)],ss))for i,c in enumerate(cs)]+[e.submit(gl.measure_job,j,bb)for j in js]
  for f in fs:f.result()
def controls():
 ctrl.d=d;ctrl.shell({n:d/n/'shell/g3'for n in ('control','guards')})
if __name__=='__main__':
 if 'controls'in sys.argv:controls()
 else:main()
