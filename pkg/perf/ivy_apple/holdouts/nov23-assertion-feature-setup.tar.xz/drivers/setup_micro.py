from study import *
import setup_features_trials as s
d=s.d/'micro';d.mkdir(exist_ok=True)
vs=sys.argv[1:]or['control','share','share-demand','demand']
def make(n):
 dr=s.d/n;o=dr/'overlay/overlay.json';b=dr/'setup.test'
 with(w/'build.lock').open('a')as lk,(dr/'test-build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','4','-overlay='+str(o),'-c','-o',b,'./smtcore'],cwd=pkg,stdout=log,stderr=log)
 p=run([b,'-test.run','(?i)setup|sequencebackend|quantifiedlogic','-test.count','1'],cwd=pkg/'smtcore',capture_output=True)
 (dr/'focused.txt').write_bytes(p.stdout+p.stderr)
 return b
with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(make,vs)))
with(d/('bench-'+'-'.join(vs)+'.csv')).open('w')as f:
 z=csv.writer(f);z.writerow(['round','variant','case','ns','bytes','allocs'])
 for i in range(1,8):
  for v in vs[i%len(vs):]+vs[:i%len(vs)]:
   p=run(['taskset','-c','5',bs[v],'-test.run','^$','-test.bench','^BenchmarkSMTAssertionFeatureSetup$','-test.benchtime','30x','-test.benchmem','-test.cpu','1'],cwd=pkg/'smtcore',capture_output=True,text=True);lines=[l.split() for l in p.stdout.splitlines()if l.startswith('Benchmark')];assert len(lines)==4, p.stdout
   for a in lines:z.writerow([i,v,a[0],a[2],a[a.index('B/op')-1],a[a.index('allocs/op')-1]])
   f.flush()
