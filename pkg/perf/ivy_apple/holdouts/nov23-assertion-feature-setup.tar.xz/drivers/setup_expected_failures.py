from study import *
import setup_panels as pa,guarded_live as gl
from verification_frontier import reference
n='examples/ivy/flash2.ivy';ref=reference(n)
p=w/'predicate-verification/corpus'
rc={r['spec']:int(r['exit'])for f in p.glob('cpu-*.csv')for r in csv.DictReader(f.open())}[n]
assert rc==1
for nm,cur in [('setup-features-release',pa.bs['g3']),('setup-release-pairs',w/'setup-release-pairs/checker/goivy_check'),('setup-bound-release',w/'setup-limit-audit/shared/checker/goivy_check')]:
    gl.d=w/nm
    lane=gl.d/'corpus-7-16'
    if (lane/'runs.csv').read_text().count('\n')<3:
        lane.rename(gl.d/'expected-exit-correction')
        gl.measure_job((16,'corpus-7',n,'',rc,4,ref),{**pa.bs,'g3':cur})
