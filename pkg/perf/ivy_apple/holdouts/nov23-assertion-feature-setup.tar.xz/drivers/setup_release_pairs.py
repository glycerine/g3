from study import *
import setup_panels as pa,guarded_live as gl,setup_features_trials as tr,simplifier_rebuild as sh
d=w/'setup-release-pairs';d.mkdir(exist_ok=True)
def main():
 b=build(d/'checker');cur=d/'checker/goivy_check';before=pa.bs['previous'];sh.d=d/'phases';sh.d.mkdir(exist_ok=True);gl.d=d
 files=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));cs=[0,3,6,8,12,16]
 shells={'previous':tr.d/'control/shell/g3','release':w/'setup-features-release/final/shell/g3','native':pkg.parent/'build/z3'}
 jobs=pa.jobs
 with ThreadPoolExecutor(len(cs)+len(jobs))as e:
  fs=[e.submit(sh.lane,(c,files[i::len(cs)],shells))for i,c in enumerate(cs)]+[e.submit(gl.measure_job,j,{'previous':before,'g3':cur,'native':pa.bs['native']}) for j in jobs]
  for f in fs:f.result()
if __name__=='__main__':main()
