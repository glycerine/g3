(set-logic ALL)(set-option :auto_config true)(set-option :smt.string_solver z3str3)(declare-const x (Seq Int))(assert (= (seq.len x) 1))(push)(set-option :smt.string_solver seq)(push)(check-sat)
