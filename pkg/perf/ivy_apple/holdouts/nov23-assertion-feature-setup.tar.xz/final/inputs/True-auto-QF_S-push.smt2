(set-logic QF_S)(set-option :auto_config true)(set-option :smt.string_solver auto)(declare-const x String)(assert (str.contains x "x"))(push)(check-sat)(pop)(check-sat)
