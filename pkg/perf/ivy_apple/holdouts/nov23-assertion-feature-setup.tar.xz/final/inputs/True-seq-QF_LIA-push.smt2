(set-logic QF_LIA)(set-option :auto_config true)(set-option :smt.string_solver seq)(declare-const x Int)(assert (= x 4))(push)(check-sat)(pop)(check-sat)
