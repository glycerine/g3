(set-logic AUFLIA)(set-option :auto_config true)(set-option :smt.string_solver z3str3)(declare-fun f (Int) Int)(assert (forall ((i Int)) (>= (f i) 0)))(check-sat)
