(set-logic AUFLIA)(set-option :auto_config true)(set-option :smt.string_solver bad)(declare-fun f (Int) Int)(assert (forall ((i Int)) (>= (f i) 0)))(push)(check-sat)(pop)(check-sat)
