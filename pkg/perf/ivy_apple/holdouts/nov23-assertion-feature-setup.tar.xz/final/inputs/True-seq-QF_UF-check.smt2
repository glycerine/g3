(set-logic QF_UF)(set-option :auto_config true)(set-option :smt.string_solver seq)(declare-sort A 0)(declare-const a A)(assert (= a a))(check-sat)
