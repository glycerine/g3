(set-logic QF_AX)(set-option :auto_config true)(set-option :smt.string_solver seq)(declare-sort A 0)(declare-const a (Array A A))(declare-const x A)(assert (= (select a x) x))(check-sat)
