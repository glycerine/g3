(set-logic QF_UF)(set-option :auto_config true)(set-option :smt.string_solver bad)(declare-sort A 0)(declare-const a A)(assert (= a a))(push)(check-sat)(pop)(check-sat)
