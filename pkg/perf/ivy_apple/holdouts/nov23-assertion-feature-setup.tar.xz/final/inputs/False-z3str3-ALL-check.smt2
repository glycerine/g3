(set-logic ALL)(set-option :auto_config false)(set-option :smt.string_solver z3str3)(declare-const x (Seq Int))(assert (= (seq.len x) 1))(check-sat)
