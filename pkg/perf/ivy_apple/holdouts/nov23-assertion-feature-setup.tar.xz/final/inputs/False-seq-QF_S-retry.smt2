(set-logic QF_S)(set-option :auto_config false)(set-option :smt.string_solver seq)(declare-const x String)(assert (str.contains x "x"))(push)(set-option :smt.string_solver seq)(push)(check-sat)
