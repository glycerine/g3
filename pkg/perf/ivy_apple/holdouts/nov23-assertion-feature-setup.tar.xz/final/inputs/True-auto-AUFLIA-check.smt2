(set-logic AUFLIA)(set-option :auto_config true)(set-option :smt.string_solver auto)(declare-fun f (Int) Int)(assert (forall ((i Int)) (>= (f i) 0)))(check-sat)
