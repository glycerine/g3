(set-logic QF_AX)(set-option :auto_config false)(set-option :smt.string_solver z3str3)(declare-sort A 0)(declare-const a (Array A A))(declare-const x A)(assert (= (select a x) x))(check-sat)
