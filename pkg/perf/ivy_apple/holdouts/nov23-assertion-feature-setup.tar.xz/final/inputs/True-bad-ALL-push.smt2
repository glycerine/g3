(set-logic ALL)(set-option :auto_config true)(set-option :smt.string_solver bad)(declare-const x (Seq Int))(assert (= (seq.len x) 1))(push)(check-sat)(pop)(check-sat)
