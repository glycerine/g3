(set-logic ALL)(set-option :auto_config true)(set-option :smt.string_solver auto)(declare-const x (Seq Int))(assert (= (seq.len x) 1))(push)(set-option :smt.string_solver seq)(push)(check-sat)
