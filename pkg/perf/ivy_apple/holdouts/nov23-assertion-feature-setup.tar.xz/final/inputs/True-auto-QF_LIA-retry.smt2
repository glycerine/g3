(set-logic QF_LIA)(set-option :auto_config true)(set-option :smt.string_solver auto)(declare-const x Int)(assert (= x 4))(push)(set-option :smt.string_solver seq)(push)(check-sat)
