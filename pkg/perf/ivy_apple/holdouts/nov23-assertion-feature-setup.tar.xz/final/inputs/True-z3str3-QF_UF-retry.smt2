(set-logic QF_UF)(set-option :auto_config true)(set-option :smt.string_solver z3str3)(declare-sort A 0)(declare-const a A)(assert (= a a))(push)(set-option :smt.string_solver seq)(push)(check-sat)
