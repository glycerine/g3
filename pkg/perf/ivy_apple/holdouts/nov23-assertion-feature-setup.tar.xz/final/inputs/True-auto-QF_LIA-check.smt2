(set-logic QF_LIA)(set-option :auto_config true)(set-option :smt.string_solver auto)(declare-const x Int)(assert (= x 4))(check-sat)
