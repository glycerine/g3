(set-logic QF_LIA)(set-option :auto_config false)(set-option :smt.string_solver bad)(declare-const x Int)(assert (= x 4))(check-sat)
