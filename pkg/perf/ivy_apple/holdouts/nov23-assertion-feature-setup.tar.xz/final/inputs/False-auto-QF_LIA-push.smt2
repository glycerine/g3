(set-logic QF_LIA)(set-option :auto_config false)(set-option :smt.string_solver auto)(declare-const x Int)(assert (= x 4))(push)(check-sat)(pop)(check-sat)
