(set-logic QF_UF)(set-option :auto_config false)(set-option :smt.string_solver bad)(declare-sort A 0)(declare-const a A)(assert (= a a))(check-sat)
