(set-logic AUFLIA)(set-option :auto_config false)(set-option :smt.string_solver bad)(declare-fun f (Int) Int)(assert (forall ((i Int)) (>= (f i) 0)))(check-sat)
