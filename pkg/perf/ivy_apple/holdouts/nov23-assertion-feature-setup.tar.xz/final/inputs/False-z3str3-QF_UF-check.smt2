(set-logic QF_UF)(set-option :auto_config false)(set-option :smt.string_solver z3str3)(declare-sort A 0)(declare-const a A)(assert (= a a))(check-sat)
