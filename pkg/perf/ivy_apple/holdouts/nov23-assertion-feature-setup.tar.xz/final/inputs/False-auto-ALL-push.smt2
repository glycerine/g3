(set-logic ALL)(set-option :auto_config false)(set-option :smt.string_solver auto)(declare-const x (Seq Int))(assert (= (seq.len x) 1))(push)(check-sat)(pop)(check-sat)
