(set-logic ALL)(set-option :auto_config false)(set-option :smt.string_solver bad)(declare-const x (Seq Int))(assert (= (seq.len x) 1))(push)(set-option :smt.string_solver seq)(push)(check-sat)
