(set-logic QF_UF)(set-option :auto_config false)(set-option :smt.string_solver seq)(declare-sort A 0)(declare-const a A)(assert (= a a))(push)(check-sat)(pop)(check-sat)
