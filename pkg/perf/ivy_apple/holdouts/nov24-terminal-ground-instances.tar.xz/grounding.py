"""Finite ground projection used in the captured terminal proof experiments."""
from collections import Counter, defaultdict
from functools import lru_cache
from itertools import islice, product, zip_longest
import re
def parse(text):
    tokens = re.compile(r';[^\n]*|\(|\)|\|(?:\\.|[^|\\])*\||"(?:[^"]|"")*"|[^\s();]+')
    stack = [[]]
    for token in tokens.findall(text):
        if token.startswith(";"):
            continue
        if token == "(":
            stack.append([])
        elif token == ")":
            if len(stack) == 1:
                raise ValueError("unexpected closing parenthesis")
            term = tuple(stack.pop())
            stack[-1].append(term)
        else:
            stack[-1].append(token)
    if len(stack) != 1:
        raise ValueError("incomplete input")
    return stack[0]

def smt(term):
    if isinstance(term, str):
        return term
    return "(" + " ".join(map(smt, term)) + ")"

def inv(t):
 if t=='true': return 'false'
 if t=='false': return 'true'
 if isinstance(t,tuple) and t[0]=='not':return t[1]
 return ('not',t)

def join(h,kids):
 drop,absorber=('true','false')if h=='and'else('false','true');out={}
 for x in kids:
  if x==absorber or inv(x)in out:return absorber
  if x!=drop:out[x]=None
 if len(out)==0:return drop
 if len(out)==1:return next(iter(out))
 return(h,*out)

@lru_cache(maxsize=30000)
def signed(node,neg):
 if isinstance(node,str):return ('leaf',node,neg)
 op,*xs=node
 if op=='not':return signed(xs[0],not neg)
 if op=='=>':
  assert len(xs)==2
  return ('and'if neg else 'or',signed(xs[0],not neg),signed(xs[1],neg))
 if op in ('and','or'):
  return (('or' if op=='and'else'and')if neg else op,*(signed(x,neg)for x in xs))
 if op in ('forall','exists'):
  return (('forall'if op=='exists'else'exists')if neg else op,xs[0],signed(xs[1],neg))
 # Dropping a literal of unknown polarity weakens the signed formula. Never
 # commute a quantifier through Boolean equivalence, XOR, ITE or a predicate.
 if any(t in ('forall','exists','lambda','let','!')for t in atoms(node)):
  return ('leaf','true',False)
 return('leaf',node,neg)

def atoms(x):
 if isinstance(x,str):yield x
 else:
  for y in x:yield from atoms(y)

def subst(x,env):
 if isinstance(x,str):return env.get(x,x)
 # Function names are not replaced by bound variable substitutions.
 op=x[0];args=tuple(subst(y,env)for y in x[1:])
 if op=='=' and len(args)==2 and args[0]==args[1]:return 'true'
 if op=='not':return inv(args[0])
 if op in ('and','or'):return join(op,args)
 if op=='ite'and len(args)==3:
  if args[0]=='true':return args[1]
  if args[0]=='false':return args[2]
  if args[1]==args[2]:return args[1]
 return (op,*args)

@lru_cache(maxsize=65536)
def quantified(n):
 return isinstance(n,tuple)and (n[0]in ('forall','exists') or any(quantified(x)for x in n[1:]if x and not(isinstance(x,tuple)and isinstance(x[0],tuple))))

def expand(header,rows,direction):
 ds={x[1]:x[3]for l in header.splitlines() if(x:=parse(l)[0])[0]=='declare-fun'}
 stats=Counter()
 def boolean(n,env):
  if isinstance(n,str):return n in ('true','false')or env.get(n,ds.get(n))=='Bool'
  if n[0] in ('forall','exists','and','or','=>','not','=','distinct','xor','<','<=','>','>='):return True
  if n[0]=='ite':return boolean(n[2],env)
  return ds.get(n[0])=='Bool'
 def walk(n,env,neg):
  if isinstance(n,str)or not quantified(n):return ('not',n)if neg else n
  op=n[0]
  if op in ('forall','exists'):
   es={**env,**dict(n[1])}
   return (('forall'if op=='exists'else'exists')if neg else op,n[1],walk(n[2],es,neg))
  if op=='not':return walk(n[1],env,not neg)
  if op in ('and','or'):
   return (('or'if op=='and'else'and')if neg else op,*(walk(x,env,neg)for x in n[1:]))
  if op=='=>':
   return ('and'if neg else'or',walk(n[1],env,not neg),walk(n[2],env,neg))
  if op=='ite'and boolean(n,env):
   stats['ite']+=1
   return ('and',('or',walk(n[1],env,True),walk(n[2],env,neg)),('or',walk(n[1],env,False),walk(n[3],env,neg)))
  if op in ('=','distinct','xor')and len(n)==3 and boolean(n[1],env)and boolean(n[2],env):
   stats['eq']+=1;same=(op=='=')!=neg
   # Both clauses are jointly equivalent. Using one clause alone weakens the signed formula.
   forward=('or',walk(n[1],env,True),walk(n[2],env,not same))
   reverse=('or',walk(n[1],env,False),walk(n[2],env,same))
   if direction=='forward':return forward
   if direction=='reverse':return reverse
   return('and',forward,reverse)
  stats['opaque']+=1;return ('not',n)if neg else n
 return [walk(x,{},False)for x in rows],stats

def compile_query(header,rows):
 ds={t[1]:(t[2],t[3])for l in header.splitlines() if(t:=parse(l)[0])[0]=='declare-fun'}
 taken={a.strip('|')for r in rows for a in atoms(r)}|{a.strip('|')for a in ds};counter=0;decl=[];skolems=set()
 def name(prefix):
  nonlocal counter
  while True:
   counter+=1;n='@ground_'+prefix+'_'+str(counter)
   if n not in taken:taken.add(n);return n
 def fresh(sort,outer):
  f=name('w');sorts=tuple(s for x,s in outer);decl.append('(declare-fun '+f+' ('+' '.join(smt(t) for t in sorts)+') '+smt(sort)+')');ds[f]=(sorts,sort);skolems.add(f)
  return (f,*(v for v,s in outer)) if outer else f
 def walk(n,env,outer):
  op=n[0]
  if op=='leaf':
   x=subst(n[1],env);return ('leaf',inv(x)if n[2]else x)
  if op in ('forall','exists'):
   local=env.copy();bindings=[]
   for v,s in n[1]:
    if op=='exists':local[v]=fresh(s,outer)
    else:new=name('v');local[v]=new;bindings.append((new,s))
   inner=walk(n[2],local,outer+tuple(bindings))
   return ('forall',tuple(bindings),inner)if bindings else inner
  return(op,*(walk(x,env,outer)for x in n[1:]))
 roots=[walk(signed(x,False),{},())for x in rows]
 return ds,decl,skolems,roots,fresh

def generate(header,rows,k,more,passes,rowcap=1536,apps='skolem'):
 expanded,_=expand(header,rows,'full');ds,decs,sk,roots,fresh=compile_query(header,expanded);source=Counter(a for r in rows for a in atoms(r)if a in ds and not ds[a][0]);uf={};seen=defaultdict(Counter);terms=defaultdict(list);total=0
 def root(x):
  while x in uf:
   p=uf[x]
   if p in uf:uf[x]=uf[p]
   x=p
  return x
 def typ(n):
  if isinstance(n,str):return ds.get(n,((),None))[1]
  if not isinstance(n[0],str)or n[0]not in ds:return None
  args,sort=ds[n[0]]
  if len(args)!=len(n)-1 or any(typ(x)!=s for x,s in zip(n[1:],args)):return None
  return sort
 def unions(n):
  if n[0]=='and':
   for x in n[1:]:unions(x)
  elif n[0]=='leaf'and isinstance(n[1],tuple)and n[1][0]=='=' and len(n[1])==3:
   x,y=n[1][1:];s=typ(x)
   if s not in ('Bool',None) and typ(y)==s and root(x)!=root(y):uf[root(x)]=root(y)
 for n in roots:unions(n)
 for sort in {s for args,s in ds.values()if s!='Bool'}:
  ws=[v for v,(args,s)in ds.items()if not args and s==sort and v in sk]
  cs=[v for v,n in source.most_common()if ds[v][1]==sort]
  uniq={}
  for pair in zip_longest(ws,cs):
   for v in pair:
    if v is not None:uniq.setdefault(root(v),v)
  terms[sort]=list(uniq.values())[:k]
 def learn(t):
  if isinstance(t,str):return
  for x in t[1:]:learn(x)
  if t[0]in ds and ds[t[0]][1]!='Bool'and (apps=='all'or t[0]in sk):
   seen[ds[t[0]][1]][t]+=1
 def ground(n,env,allow):
  nonlocal total
  if n[0]=='leaf':
   t=subst(n[1],env);learn(t);return t
  if n[0]in ('and','or'):return join(n[0],(ground(x,env,allow)for x in n[1:]))
  assert n[0]=='forall';opts=[]
  for name,sort in n[1]:
   if sort=='Bool':opts.append(['true','false']);continue
   if not terms[sort]:terms[sort].append(fresh(sort,()))
   opts.append(terms[sort])
  parts=[]
  for vs in islice(product(*opts),allow[0]):
   if allow[0]<=0:break
   allow[0]-=1;total+=1;parts.append(ground(n[2],dict(env,**{x:v for (x,s),v in zip(n[1],vs)}),allow))
  return join('and',parts)
 formulas={};refs=0
 for i in range(passes):
  for n in roots:
   x=ground(n,{},[rowcap])
   if x!='true':formulas.setdefault(x,None)
  if i+1==passes:break
  additions=0
  for sort,candidates in seen.items():
   existing={root(v)for v in terms[sort]};added=0
   # Prefer witnesses used more than once. Break ties in first traversal order.
   for term,cnt in candidates.most_common():
    if root(term)in existing:continue
    terms[sort].append(term);existing.add(root(term));additions+=1;added+=1
    if added==more:break
  refs+=additions
  if additions==0:break
 text=header+'\n'.join(decs)+'\n'+''.join('(assert '+smt(x)+')\n'for x in formulas)
 return text,total,len(sk),refs
