package api

import "github.com/glycerine/g3/pkg/model"

func (m *APIModel) StudyEvaluator() (*model.ModelEvaluator, error) {
	c, err := m.owner.command.ModelEvaluatorConfig()
	if err != nil {
		return nil, err
	}
	e, err := model.NewModelEvaluator(m.core, c)
	if err != nil {
		return nil, err
	}
	if err = e.SetModelCompletion(true); err != nil {
		e.Close()
		return nil, err
	}
	return e, nil
}
