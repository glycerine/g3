package main

import (
	"fmt"
	"github.com/glycerine/g3/pkg/api"
	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/util/lbool"
	"os"
	"sort"
	"strconv"
)

func check(e error) {
	if e != nil {
		panic(e)
	}
}

type candidate struct {
	term          ast.ASTHandle
	ordinal, size int
	installed     bool
}

func main() {
	if len(os.Args) != 5 {
		panic("input budget policy rows")
	}
	limit, e := strconv.Atoi(os.Args[2])
	check(e)
	policy := os.Args[3]
	expected, e := strconv.Atoi(os.Args[4])
	check(e)
	ctx, e := api.NewSMTContext()
	check(e)
	defer func() { check(ctx.Close()) }()
	m, e := ctx.Manager()
	check(e)
	input, e := ctx.ParseSMT2File(os.Args[1], api.SMT2Bindings{})
	check(e)
	defer func() { check(m.DelRef(&input)) }()
	root, e := m.RefGet(input)
	check(e)
	n, e := m.GetNumArgs(root)
	check(e)
	if int(n) != expected {
		panic(fmt.Sprintf("root has %d children, want %d", n, expected))
	}
	solver, e := ctx.NewSimpleSolver()
	check(e)
	defer func() { check(solver.Close()) }()
	sizes := map[ast.ASTHandle]int{}
	var cost func(ast.ASTHandle) int
	cost = func(x ast.ASTHandle) int {
		if n := sizes[x]; n != 0 {
			return n
		}
		k, e := m.GetNumArgs(x)
		check(e)
		n := 1
		for i := uint32(0); i < k; i++ {
			c, e := m.GetArg(x, i)
			check(e)
			n += cost(c)
		}
		sizes[x] = n
		return n
	}
	rows := make([]candidate, n)
	for i := range rows {
		x, e := m.GetArg(root, uint32(i))
		check(e)
		rows[i] = candidate{term: x, ordinal: i, size: cost(x)}
	}
	if policy == "small" {
		sort.SliceStable(rows, func(i, j int) bool { return rows[i].size < rows[j].size })
	}
	installed, tried, evaluated := 0, 0, 0
	add := func(i int) { row := &rows[i]; check(solver.Assert(row.term)); row.installed = true; installed++ }
	for i, row := range rows {
		if policy == "eager" || row.size <= 4 {
			add(i)
		}
	}
	result := "unknown"
	for round := 0; round < 96; round++ {
		tried++
		status, e := solver.Check()
		check(e)
		if status == lbool.False {
			result = "unsat"
			break
		}
		if status != lbool.True {
			break
		}
		snapshot, e := solver.Model()
		check(e)
		ev, e := snapshot.StudyEvaluator()
		check(e)
		out, e := m.NewRef(ast.ASTHandle{})
		check(e)
		added := make([]int, 0, limit)
		undecided := false
		for i, row := range rows {
			if row.installed {
				continue
			}
			check(ev.Evaluate(row.term, out))
			v, e := m.RefGet(out)
			check(e)
			evaluated++
			if m.IsFalse(v) {
				added = append(added, i)
				if len(added) == limit {
					break
				}
			} else if !m.IsTrue(v) {
				undecided = true
			}
		}
		check(m.DelRef(&out))
		check(ev.Close())
		check(snapshot.Close())
		if len(added) == 0 {
			if !undecided {
				result = "sat"
			}
			break
		}
		for _, i := range added {
			add(i)
		}
	}
	fmt.Println(result, installed, tried, evaluated)
	if result == "unsat" {
		for _, r := range rows {
			if r.installed {
				fmt.Printf("%d ", r.ordinal)
			}
		}
		fmt.Println()
	}
}
