"""Replay one captured quantified goal or one finite projection independently."""
import argparse
import csv
import gzip
import json
from pathlib import Path
import subprocess
import sys
import grounding
ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case")
    parser.add_argument("--engine", type=Path, help="g3 or Z3 executable; omit to write SMT-LIB")
    parser.add_argument("--mode", choices=("source", "generate", "full", "core", "complement", "prefix", "lazy", "miniscope"), default="source")
    parser.add_argument("--initial", type=int, default=8)
    parser.add_argument("--additional", type=int, default=5)
    parser.add_argument("--passes", type=int, default=2)
    parser.add_argument("--policy", default="small-32")
    args = parser.parse_args()
    if min(args.initial, args.passes) < 1 or args.additional < 0:
        parser.error("initial and passes must be positive and additional must be nonnegative")
    if Path(args.case).name != args.case or not (ROOT/"cases"/args.case/"header.smt2").is_file():
        parser.error("unknown case")
    case = ROOT/"cases"/args.case
    header = (case/"header.smt2").read_text()
    if args.mode == "source":
        query = (case/"input.smt2").read_text()
    elif args.mode == "generate":
        rows = [grounding.parse(text)[0] for text in json.loads((case/"rows.json").read_text())]
        query, *_ = grounding.generate(header, rows, args.initial, args.additional, args.passes, apps="all")
    elif args.mode == "miniscope":
        with gzip.open(case/"miniscope.smt2.gz","rt") as f:
            query = f.read()
    else:
        data = case/"ground"
        if not data.is_dir():
            parser.error("case has no saved finite projection")
        header = (data/"header.smt2").read_text()
        with gzip.open(data/"instances.json.gz","rt") as source:
            rows = json.load(source)
        selected = set(json.loads((data/"selection.json").read_text())["indices"])
        if args.mode in ("core", "complement", "prefix") and not selected:
            parser.error("case is a satisfiable control")
        if args.mode=="lazy":
            if args.policy not in {"source-32", "source-128", "small-8", "small-32", "small-128", "small-512", "eager-32"}:
                parser.error("unknown lazy selection")
            selected = set(map(int,(data/(args.policy+".ids")).read_text().split()))
        terms = (t for i,t in enumerate(rows) if args.mode=="full" or args.mode in ("core","lazy") and i in selected
                 or args.mode=="prefix" and i<len(selected) or args.mode=="complement" and i not in selected)
        query = header+"".join("(assert "+t+")\n" for t in terms)
    text = query + "\n(check-sat-using smt)\n"
    if args.engine is None:
        sys.stdout.write(text)
    else:
        result = subprocess.run([str(args.engine.resolve()), "-in", "-smt2"], input=text, text=True)
        raise SystemExit(result.returncode)

if __name__=="__main__":
    main()
