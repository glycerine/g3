"""Build the committed verifier with only the frontend stage observer enabled."""
import json,os,subprocess
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent;b=(p/'build/.boolean-enode-cost').resolve()
ov=json.loads((p/'build/.hybrid-obligations/observer.json').read_text())
ov['Replace'].update({str(Path(k).resolve()):str(Path(v).resolve()) for k,v in list(ov['Replace'].items())})
cfg=w/'observer.json';cfg.write_text(json.dumps(ov))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',cfg,'-o',w/'release-cost','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
