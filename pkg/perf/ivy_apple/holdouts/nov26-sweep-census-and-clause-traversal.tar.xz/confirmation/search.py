"""Retarget observer to 31/34 and 11/5, preserving the release solver."""
from pathlib import Path
import json,os,subprocess,csv
p=Path.cwd();w=Path(__file__).resolve().parent;old=p/'build/.witness-origin';b=(p/'build/.boolean-enode-cost').resolve();front=b/'frontend/goivy';ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=p/'build/.bool-scan/golden/reference/hybrid'
def save(k,s):
 dst=w/('obs-'+e+'-'+k.name);dst.write_text(s);files[str(k)]=files[str(k.resolve())]=str(dst)
for e in ['z3','g3']:
 files={}
 for k,v in json.loads((old/('search-'+e+'.json')).read_text())['Replace'].items():
    k=Path(k);v=Path(v)
    if k.name=='phase_observer_trial.go':
        s=v.read_text();assert 'batch==35 && goal==1 || batch==19 && goal==29' in s
        save(k,s.replace('batch==35 && goal==1 || batch==19 && goal==29','batch==31 && goal==34 || batch==11 && goal==5'))
    elif k.name in ['z3bridge_solver_model.go','quantifier.go']:save(k,v.read_text())
    elif k.name in ['smt_model_checker.go','smt_search.go','smt_conflict_resolver.go','smt_quantifier_manager.go']:
        s=k.read_text();vs=v.read_text()
        if k.name=='smt_model_checker.go':
            i=vs.index('func trialTree(');s+='\n'+vs[i:]
            for dep in ['os','strings','strconv']:
                if '"'+dep+'"' not in s:s=s.replace('import (','import (\n"'+dep+'"',1)
            anchor='func (c *SMTModelChecker) Check(model *protomodel.ProtoModel, quantifiers []ast.ASTHandle) (bool, error) {'
            assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\nif witnessTrace(){trialOwner=c.state;println("WT candidate")}')
        else:
            anchor,tag={'smt_search.go':('k.internalizer.statistics.NumDecisions++','WT decision'),'smt_conflict_resolver.go':('r.state.statistics.NumConflicts++','WT conflict'),'smt_quantifier_manager.go':('lemma, lemmaErr := instance.Lemma()','WT formula')}[k.name]
            hook=next(l for l in vs.splitlines() if tag in l);assert s.count(anchor)==1
            s=s.replace(anchor,anchor+'\n'+hook)
        save(k,s)
 ov=w/('search-'+e+'.json');ov.write_text(json.dumps({'Replace':files}))
 binary=w/('search-'+e);subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',ov,'-o',binary,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
 r=subprocess.run(['taskset','-c','14',binary,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',G3_WITNESS_TRACE='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=True)
 keep=[];pending=[];cand=0;found=set()
 with (w/('events-'+e+'.csv')).open('w') as file:
    wr=csv.writer(file);wr.writerow(['batch','goal','candidate','event','value'])
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'WT '):
            parts=line.rstrip().decode().split(' ',2);cand+=parts[1]=='candidate'
            pending.append((cand,parts[1],parts[2] if len(parts)>2 else ''))
        elif line.startswith(b'STAGE-COUNT '):
            _,bt,g,ph,*_=line.decode().split()
            if (bt,g) in [('31','34'),('11','5')] and ph=='check':
                found.add((bt,g));assert pending
                for row in pending:wr.writerow((bt,g,*row))
            pending=[];cand=0
        else: keep.append(line)
 assert len(found)==2 and r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
