"""Compare emitted lemma syntax under a consistent bijection of generated names."""
import csv,collections,re
from pathlib import Path
w=Path(__file__).resolve().parent
ev={e:list(csv.DictReader((w/('events-'+e+'.csv')).open())) for e in ['g3','z3']}
def tokens(text):return re.findall(r'\(|\)|[^\s()]+',text)
def match(left,right,links):
    a,b=tokens(left),tokens(right)
    if len(a)!=len(b):return False
    trial=links.copy();rev={v:k for k,v in trial.items()}
    for x,y in zip(a,b):
        gx=re.fullmatch(r'(.+)!\d+',x);gy=re.fullmatch(r'(.+)!\d+',y)
        if gx and gy and gx[1]==gy[1]:
            if trial.setdefault(x,y)!=y or rev.setdefault(y,x)!=x:return False
        elif x!=y:return False
    links.update(trial);return True
for bt in ['31','11']:
 for e,rows in ev.items():
    seq=[r for r in rows if r['batch']==bt];c=collections.Counter(r['event'] for r in seq)
    print(bt,e,c)
    for k in ['formula','decision','conflict']:
        print(k,sorted(collections.Counter(int(r['candidate']) for r in seq if r['event']==k).items()))
 seq=[[r['value'] for r in ev[e] if r['batch']==bt and r['event']=='formula'] for e in ['g3','z3']]
 links={};n=0
 for a,b in zip(*seq):
    if not match(a,b,links):break
    n+=1
 print('ordered lemma prefix',bt,n,'of',*[len(s) for s in seq])
 if n<min(map(len,seq)):print('next emitted formulas',*[s[n][:190] for s in seq],sep='\n')
# Compare one tree at a time with independent bijections to distinguish
# reordering from families absent in the entire pre-candidate prefix.
def normalized(text):
    labels={}
    def rename(m):
        prefix=m[1];k=m[0]
        if k not in labels:labels[k]=len(labels)
        return prefix+'!@'+str(labels[k])
    return re.sub(r'([^\s()!]+)!\d+(?=[()\s]|$)',rename,text)
for bt,n in [('31',12),('11',6)]:
    seq=[[normalized(r['value']) for r in ev[e] if r['batch']==bt and r['candidate']=='0' and r['event']=='formula'] for e in ['g3','z3']]
    common=collections.Counter(seq[0])&collections.Counter(seq[1])
    print(bt,'pre-candidate shape bag overlap',sum(common.values()),'next-Go positions in native',[i+1 for i,v in enumerate(seq[1]) if v==seq[0][n]],'next-native positions in Go',[i+1 for i,v in enumerate(seq[0]) if v==seq[1][n]])
