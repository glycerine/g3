"""Reuse validation and retire both cache references together when their AST survives."""
from pathlib import Path
import json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost';prev=w.parent/'.push-gap'
k=p/'ast/ast_activity_cache.go';s=k.read_text()
a='''if !v.IsNull() {
			valueNode = m.activityOperand(v)
		}'''
assert s.count(a)==1
s=s.replace(a,'''if k == v {
            valueNode = keyNode
        } else '''+a)
a='func (c *ActivityCache) retire(entry *astActivityEntry) error {'
s=s.replace(a,a+'''
    if !astValidateHandles && entry.keyHeld && entry.valueHeld && entry.key == entry.value && c.manager.lockFree() {
        n := c.manager.nodeAt(entry.key.slot)
        if n.rc > 2 {
            n.rc -= 2
            entry.keyHeld, entry.valueHeld = false, false
            return nil
        }
    }''')
dst=w/('alias-'+k.name);dst.write_text(s)
for label,base in [('alias',{}),('alias-cost',json.loads((prev/'core.json').read_text())['Replace'])]:
 files=dict(base);files[str(k)]=str(dst)
 ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':files}))
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
