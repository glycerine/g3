from pathlib import Path
import os,subprocess,csv,re,sys
p=Path.cwd();w=Path(__file__).resolve().parent;env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache',GOMAXPROCS='1')
engines=['base','forbid']
for e in engines:
 subprocess.run(['go','test','-c','-o',w/('walk-'+e+'.test'),*(['-overlay',w/(e+'.json')] if e!='base' else []),'./ast/macros'],env=env,check=True)
wr=csv.writer(sys.stdout);wr.writerow(['round','engine','case','ns','bytes','allocs'])
for i in range(7):
 for e in engines[::(-1 if i%2 else 1)]:
    s=subprocess.check_output(['taskset','-c','15',w/('walk-'+e+'.test'),'-test.run=^$','-test.bench=^BenchmarkMacroForbiddenWalk$','-test.benchtime=1000x'],env=env,text=True)
    rows=re.findall(r'^BenchmarkMacroForbiddenWalk/(\d+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',s,re.M)
    assert len(rows)==3,s
    for name,ns,b,a in rows:wr.writerow([i+1,e,name,ns,b,a])
    sys.stdout.flush()
