"""Join same-position rewrite events and counter windows on every first push."""
import csv,statistics
from collections import defaultdict,Counter
from pathlib import Path
w=Path(__file__).resolve().parent;prev=w.parent/'.push-gap'
def rows(p):
 with p.open() as f:return list(csv.DictReader(f))
g=rows(w/'g3.csv');z=rows(w/'z3.csv')
assert len(g)==len(z)==5116 and all({k:v for k,v in a.items() if k!='resume_probes'}=={k:v for k,v in b.items() if k!='resume_probes'} for a,b in zip(g,z))
def windows(path,engine,phase):
 by_run=defaultdict(list);d=defaultdict(list)
 for row in rows(path):
    if row['engine']==engine and row['phase']==phase:by_run[int(row['round']),int(row['batch'])].append(int(row['instructions']))
 for (i,b),seq in by_run.items():
    for idx,v in enumerate(seq):d[b,idx].append(v)
 assert len(d)==5116 and all(len(v)==7 for v in d.values())
 return {k:statistics.median(v) for k,v in d.items()}
go=windows(prev/'core.csv','g3','core');native=windows(prev/'detail.csv','z3','rewrite')
summary=defaultdict(Counter)
for row in g:
 k=int(row['batch']),int(row['row']); n=int(row['visits']);label=next(limit for limit in [1,4,16,64,256,4096] if n<=limit)
 summary[label].update(rows=1,visits=n,g3=go[k],z3=native[k])
for name,ctr in sorted(summary.items()): print(name,dict(ctr))
print('Largest single-row gap',max((v-native[k],k) for k,v in go.items()))
