"""Add identical event counters around the rewriter calls of both value sweeps."""
from pathlib import Path
import json, os, re, shlex, shutil, subprocess, sys
p=Path.cwd(); w=Path(__file__).resolve().parent; prev=w.parent/'.push-gap'; qi=w.parent/'.nov26-qi-frames'
b=w.parent/'.boolean-enode-cost'; f=b/'frontend/goivy'
mode=sys.argv[1]
files=json.loads((prev/'detail-g3.json').read_text())['Replace']
files={k:v for k,v in files.items() if k.startswith(str(f))}
def overlay(k,s):
 dst=w/(mode+'-'+k.name);dst.write_text(s);files[str(k)]=str(dst)
if mode=='g3':
 src=(qi/'go_observer.py').read_text().split("replace('smtcore/smt_qi_instance.go'")[0]
 src=src.replace("out = Path(__file__).resolve().parent / 'go-observer'","out = w / 'go-observer'")
 ns={'w':w};exec(src,ns)
 paths=ns['paths']; fields=ns['fields']
 k=p/'ast/rewriter/qi_frame_observation.go'; s=paths[k].read_text()
 a=s.index('func (r *TheoryRewriter) Observe');z=s.index('func Print',a)
 s=s[:a]+'''func (r *TheoryRewriter) ObserveSweepRow() func() {
 qiFrameObserver.active=true
 qiFrameObserver.results=&r.traversal.engine.core.results
 qiFrameObserver.calls++
 return func(){qiFrameObserver.active=false;PrintQuantifierFrameObservation()}
}
'''+s[z:]
 paths[k].write_text(s)
 files.update({str(k):str(v) for k,v in paths.items()})
 k=p/'smtcore/smt_asserted_propagate.go';s=k.read_text().replace('"io"','"io"\n"os"')
 a='one, result = k.rewritePendingAssertion(i)';assert s.count(a)==1
 overlay(k,s.replace(a,'var observed func(); if os.Getenv("G3_PUSH_PHASES")=="1" {observed=k.preprocessor.ObserveSweepRow()};'+a+'; if observed!=nil {observed()}'))
else:
 n=qi/'native'; build=p.parent/'build'; k=p.parent/'src/smt/asserted_formulas.cpp';s=k.read_text()
 a=s.index('unsigned asserted_formulas::propagate_values(unsigned i)');z=s.index('void asserted_formulas::update_substitution',a)
 call='m_rewriter(n, new_n, new_pr);';assert s[a:z].count(call)==1
 # Print running totals after each observed call. Go exits via the runtime, so do not depend on static destructors.
 hdr=(n/'observe.hpp').read_text();printer=hdr.split('~qi_observation() {')[1].split('\n    }')[0]
 printer=re.sub(r', (\w+)\);',r', qi_observed.\1);',printer)
 replacement='if (std::getenv("G3_PUSH_PHASES")) {qi_observation_scope scope; '+call+printer+'} else { '+call+' }'
 dst=w/k.name;dst.write_text('#include <cstdlib>\n#include "observe.hpp"\nqi_observation qi_observed;\n'+s[:a]+s[a:z].replace(call,replacement)+s[z:])
 flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 obj=w/'asserted_formulas.o';lib=w/'libcensus.a';shutil.copyfile(f/'z3vendor/native_lib/libz3.a',lib)
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),'-I'+str(n),*inc,'-o',obj,dst],cwd=build,check=True)
 subprocess.run(['ar','r',lib,obj,n/'th_rewriter.o',n/'rewriter.o'],check=True)
 k=f/'smt/quantifier.go';overlay(k,k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off'+(',classic_z3' if mode=='z3' else ''),'-overlay',ov,'-o',w/mode,'./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
