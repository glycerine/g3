"""Measure the three disjoint operations after first-push preprocessing."""
from pathlib import Path
import os, subprocess, re, json, shutil, shlex, sys
p=Path.cwd();w=Path(__file__).resolve().parent;prev=w.parent/'.push-gap';b=w.parent/'.boolean-enode-cost';f=b/'frontend/goivy';e=sys.argv[1]
files={k:v for k,v in json.loads((prev/'detail-g3.json').read_text())['Replace'].items() if k.startswith(str(f)) or 'zz_first_push' in k}
def once(s,a,t):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,t)
def emit(k,s):
 dst=w/('install-'+k.name);dst.write_text(s);files[str(k)]=str(dst)
if e=='g3':
 k=p/'smtcore/smt_kernel.go';s=k.read_text()
 a='head := k.assertedHead\n\tfor head < len(k.assertions)';s=once(s,a,'endInstall:=samplePushPass();'+a)
 s=once(s,'head++\n\t}\n\treturn k.commitAssertedTo(head)','head++\n\t}\nendInstall("install");return k.commitAssertedTo(head)')
 a='rows := make([]ast.ASTHandle, 0, head-k.assertedHead)';s=once(s,a,'endMark:=samplePushPass();'+a)
 a='depth := make(map[ast.ASTHandle]uint32)\n\tfor _, row := range k.assertions[k.assertedHead:head]'
 s=once(s,a,'endMark("forbid");defer samplePushPass()("bind");'+a);emit(k,s)
else:
 build=p.parent/'build';hdr=(prev/'nested-smt_context.cpp').read_text().split((p.parent/'src/smt/smt_context.cpp').read_text()[:80],1)[0]
 assert 'struct measure_push_pass' in hdr and len(hdr)<3000
 lib=w/'libinstall.a';shutil.copyfile(f/'z3vendor/native_lib/libz3.a',lib)
 flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 for name in ['smt_context','asserted_formulas']:
    k=p.parent/'src/smt'/(name+'.cpp');s=k.read_text()
    if name=='smt_context':
        a='unsigned qhead = m_asserted_formulas.get_qhead();';s=once(s,a,a+'{measure_push_pass measured("install");')
        a='qhead++;\n            }\n            m_asserted_formulas.commit();';s=once(s,a,a.replace('m_asserted_formulas.commit();','} m_asserted_formulas.commit();'))
    else:
        a='m_macro_manager.mark_forbidden(new_qhead - m_qhead, m_formulas.c_ptr() + m_qhead);'
        s=once(s,a,'{measure_push_pass measured("forbid");'+a+'}measure_push_pass measured("bind");')
    src=w/('install-'+k.name);src.write_text(hdr+s);obj=w/(name+'.o')
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,src],cwd=build,check=True)
    subprocess.run(['ar','r',lib,obj],check=True)
 k=f/'smt/quantifier.go';emit(k,k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=w/('install-'+e+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',ov,'-o',w/('install-'+e),'./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
