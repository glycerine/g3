"""Rotate three binaries through the held live-key benchmark with a pinned CPU."""
from pathlib import Path
import os,subprocess,csv,re,sys
p=Path.cwd();w=Path(__file__).resolve().parent;env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache',GOMAXPROCS='1')
engines=['base','miss','shared']
for e in engines:
 subprocess.run(['go','test','-c','-o',w/(e+'.test'),*(['-overlay',w/(e+'.json')] if e!='base' else []),'./ast'],env=env,check=True)
wr=csv.writer(sys.stdout);wr.writerow(['round','engine','case','ns','bytes','allocs'])
for i in range(7):
 for e in engines[i%3:]+engines[:i%3]:
    s=subprocess.check_output(['taskset','-c','17',w/(e+'.test'),'-test.run=^$','-test.bench=^BenchmarkExprSubstitutionFind$','-test.benchtime=3000000x'],env=env,text=True)
    rows=re.findall(r'^BenchmarkExprSubstitutionFind/(\w+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',s,re.M)
    assert len(rows)==3,s
    for name,ns,b,a in rows:wr.writerow([i+1,e,name,ns,b,a])
    sys.stdout.flush()
