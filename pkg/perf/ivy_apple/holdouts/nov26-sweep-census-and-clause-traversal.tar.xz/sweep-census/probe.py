"""Compare two ways to return early when a validated expression has never been a substitution key."""
from pathlib import Path
import json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost';prev=w.parent/'.push-gap'
k=p/'ast/ast_expr_substitution_ops.go';s=k.read_text()
a='return m.substLookupOutputs(state, astNodeRef{key.slot, key.generation}, def, proof, dep)'
assert s.count(a)==1
s=s.replace(a,'''if key.slot != 0 && key.slot < m.nextNode {
                rec := m.nodeAt(key.slot)
                if rec.live && rec.generation == key.generation && rec.kind <= ASTQuantifier && !rec.hasFlag(astWasSubstitutionKey) {
                    return false, nil
                }
            }
            '''+a)
dst=w/('miss-'+k.name);dst.write_text(s)
for label,base in [('miss',{}),('miss-cost',json.loads((prev/'core.json').read_text())['Replace'])]:
 files=dict(base);files[str(k)]=str(dst)
 ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':files}))
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
