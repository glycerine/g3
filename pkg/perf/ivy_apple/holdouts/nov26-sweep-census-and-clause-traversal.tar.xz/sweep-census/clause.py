from pathlib import Path
import json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost'
for label,extra in [('clause',[]),('clause-cost',['-overlay',w/'install-g3.json'])]:
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off',*extra,'-o',w/label,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
