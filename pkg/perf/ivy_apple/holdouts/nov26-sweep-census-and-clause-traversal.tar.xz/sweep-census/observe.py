"""Check complete proof transcripts and export the per-row counts."""
from pathlib import Path
import csv, os, subprocess, sys
w=Path(__file__).resolve().parent; ex=Path('/home/jaten/ivy/ivy-lang-examples')
gold=w.parent/'.bool-scan/golden/reference/hybrid'
e=sys.argv[1]; r=subprocess.run(['taskset','-c','21',w/e,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
pending=[];out=[];stderr=[];last={};first=0
for line in r.stderr.splitlines(keepends=True):
 if line.startswith(b'QI-FRAMES '):
    d={k:int(v) for k,v in (p.split('=') for p in line.decode().split()[1:])}
    pending.append({k:v-last.get(k,0) for k,v in d.items()})
    assert pending[-1]['calls']==1
    last=d
 elif line.startswith(b'STAGE-COUNT '):
    _,batch,goal,stage,*_=line.decode().split()
    if stage=='first':
        first+=1
        out.extend(dict(batch=batch,row=i,**d) for i,d in enumerate(pending));pending=[]
    assert not pending
 else:stderr.append(line)
assert r.returncode==0 and r.stdout==(gold/'stdout').read_bytes() and b''.join(stderr)==(gold/'stderr').read_bytes(),(r.returncode,b''.join(stderr)[-4096:])
assert first==34 and not pending and len(out)>4000
with (w/(e+'.csv')).open('w') as file:
 writer=csv.DictWriter(file,fieldnames=list(out[0]));writer.writeheader();writer.writerows(out)
print(e,first,len(out),last)
