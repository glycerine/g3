from pathlib import Path
import os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-o',w/'release','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
