"""Trial separating marked keys from the validation and common miss path."""
from pathlib import Path
import json,os,subprocess
p=Path.cwd(); w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost'
k=p/'ast/ast_expr_substitution_ops.go';s=k.read_text();a='\ta, found := state.base.entries.Get2(token)'
assert s.count(a)==1
s=s.replace(a,'''    return m.substLookupMarked(state, token, def, proof, dep)
}

func (m *ASTManager) substLookupMarked(state *astExprSubstState, token uint64, def, proof *ASTHandle, dep *ASTDependency) (bool,error) {
'''+a)
a='return m.substLookupOutputs(state, astNodeRef{key.slot, key.generation}, def, proof, dep)'
s=s.replace(a,'''if record := m.activityOperand(key); record != nil {
                if !record.hasFlag(astWasSubstitutionKey) {return false,nil}
                return m.substLookupMarked(state, uint64(key.slot)<<32|uint64(key.generation),def,proof,dep)
            }''')
dst=w/('shared-'+k.name); dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'shared.json';ov.write_text(json.dumps({'Replace':{str(k):str(dst)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'shared','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=env,check=True)
