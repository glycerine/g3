"""Assign each matched sweep-rewriter sample to its innermost named operation."""
from collections import Counter
import csv
from pathlib import Path
w=Path(__file__).resolve().parent
phases=[
 ('substitution lookup',('GetSubst','ExprSubstitutionFind','substLookupOutputs'),('::get_subst(','expr_substitution::find(')),
 ('scoped cache lifetime',('beginScope','endScope','NewActivityCache','(*ActivityCache).Close'),('begin_scope(','end_scope(','act_cache::~act_cache','act_cache::act_cache')),
 ('rewrite cache',('ActivityCache','activityChashtable','getCached','cacheResult'),('act_cache::','get_cached(','cache_result(')),
 ('application rules',('ReduceApp','reduceAppCore','(*BoolRewriter)','(*BasicRewriter)'),('::reduce_app(','_rewriter::mk_','th_rewriter_cfg::mk_')),
 ('quantifier reduction',('ReduceQuantifier','ElimUnused'),('::reduce_quantifier(','elim_unused_vars')),
 ('result stack',('appendRewriterRoot','shrinkRewriterRoots','popResult'),('obj_ref_vector','dec_refs(','push_result(')),
 ('AST reference',('RefHeld','SetRef','IncRef','DecRef','DelRef','RefGet'),('ast_manager::dec_ref','ast_manager::inc_ref')),
 ('scope frame',('pushFrame','beginScope','endScope'),('push_frame(','begin_scope(','end_scope(')),
 ('app or boolean child',('processApp','constantFold'),('process_app<','constant_fold(')),
 ('quantifier children',('processQuantifier',),('process_quantifier<',)),
 ('visit',('rewriterEngine).visit','mustCacheShape'),('::visit<','must_cache(')),
 ]
counts={'g3':Counter(),'z3':Counter()}
for row in csv.DictReader((w.parent/'.push-gap/samples.csv').open()):
 e=row['engine'];stack=row['stack'].split('\t')
 scopes=['goivy/smt.(*Z3Solver).Push','(*SMTKernel).rewritePendingAssertion','(*TheoryRewriter).Rewrite'] if e=='g3' else ['Z3_solver_push','asserted_formulas::propagate_values(unsigned int)','rewriter_tpl<th_rewriter_cfg>']
 if not all(any(frag in f for f in stack) for frag in scopes):continue
 name='other'
 for frame in stack:
    matched=next((label for label,go,cpp in phases if any(p in frame for p in (go if e=='g3' else cpp))),None)
    if matched:
        name=matched;break
 counts[e][name]+=1
for name in sorted(counts['g3'].keys()|counts['z3'].keys(),key=lambda n:counts['g3'][n]-counts['z3'][n],reverse=True):
 print(name,counts['g3'][name],counts['z3'][name])
