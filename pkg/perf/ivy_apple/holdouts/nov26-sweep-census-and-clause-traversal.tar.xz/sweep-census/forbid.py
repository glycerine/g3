"""Try bounded direct indexing with a full-handle collision set on macro walks."""
from pathlib import Path
import json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost';k=p/'ast/macros/macro_manager.go'
s=k.read_text();i=s.index('func (m *Manager) MarkForbidden(');j=s.index('m.publishForbidden()',i);s1=s[i:j]
a='seen := make(map[ast.ASTHandle]struct{})';assert s1.count(a)==1
s1=s1.replace(a,'var local [256]ast.ASTHandle; var spill map[ast.ASTHandle]struct{}')
a='''if _, yes := seen[e]; yes {
			continue
		}
		seen[e] = struct{}{}'''
assert a in s1
s1=s1.replace(a,'''slot:=&local[e.Slot()%uint32(len(local))]
        if !slot.IsNull() {
            if *slot == e {continue}
            if _, ok := spill[e]; ok {continue}
            if spill == nil {spill=make(map[ast.ASTHandle]struct{})}
            spill[e]=struct{}{}
        } else {*slot=e}''')
a='kind, err := m.manager.GetKind(e)';s1=s1.replace(a,'kind, _, n, err := m.manager.NodeShape(e)')
a='''n, e2 := m.manager.GetNumArgs(e)
			if e2 != nil {
				return e2
			}''';assert a in s1;s1=s1.replace(a,'')
s1=s1.replace('body, e2 := m.manager.GetQuantifierBody(e)','body, _, patterns, noPatterns, e2 := m.manager.QuantifierChildren(e)')
for name,method in [('patterns','GetNumPatterns'),('noPatterns','GetNumNoPatterns')]:
 a=f'{name}, e2 := m.manager.{method}(e)\n\t\t\tif e2 != nil {{\n\t\t\t\treturn e2\n\t\t\t}}';assert a in s1;s1=s1.replace(a,'')
dst=w/('forbid-'+k.name);dst.write_bytes(subprocess.check_output(['gofmt'],input=(s[:i]+s1+s[j:]).encode()))
for label,base in [('forbid',{}),('forbid-cost',json.loads((w/'install-g3.json').read_text())['Replace'])]:
 base=dict(base);base[str(k)]=str(dst);ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':base}))
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
