from common import *
root=d/'fallback-fixture';root.mkdir(exist_ok=True)
def src(mode,mbqi):
 patterns=['(R x a) (R y b) (R x c)']
 if mode in ('connected','fallback'):patterns.insert(0,patterns[0]+' (S b a)')
 if mode=='connected':patterns=patterns[:1]
 ann=' '.join(':pattern ('+p+')' for p in patterns)
 return '''(set-option :smt.mbqi '''+mbqi+''')
(set-option :smt.macro_finder false)
(declare-sort T 0)
(declare-sort V 0)
(declare-fun R (T V) Bool)
(declare-fun S (V V) Bool)
(declare-const t T)
(declare-const v V)
(assert (forall ((x T) (y T) (a V) (b V) (c V)) (! (=> (and (R x a) (R y b) (R x c)) (S b a)) '''+ann+''')))
(assert (forall ((a V)(b V)) (! (not (S a b)) :pattern ((S a b)))))
(push 1)
(assert (R t v))
(check-sat)
(get-info :reason-unknown)
'''
for m in ['original','connected','fallback']:
 for mbqi in ['false','true']:
  s=src(m,mbqi);(root/f'{m}-{mbqi}.smt2').write_text(s)
  for v,b in [('g3',w/'rows-final/shell/g3'),('z3',pkg.parent/'build/z3')]:
   p=subprocess.run([b,'-in','-smt2','-st'],input=s.encode(),capture_output=True,cwd=root,env=dict(env,GOMAXPROCS='1'),timeout=15);(root/f'{m}-{mbqi}-{v}.out').write_bytes(p.stdout+p.stderr);print(m,mbqi,v,p.returncode,p.stdout.splitlines()[:2])
