from common import *
import holdouts as ho,macro_identity as mi,connected_triggers as ct,ground_release_controls as gc,binder_exits as binder,substitution_release as sr
root=d/'production-connected';root.mkdir(exist_ok=True)
def focused(tags):
 args=['go','test','-count=1','-p','4']
 if tags:args+=['-tags='+tags]
 args+=['./ast/pattern','./smtcore','./tactic/portfolio','./cmd_context','./api','-run','Test(SMTConnected|SMTAssertedPattern|SMTAssertedMacro|PatternInference|PatternRewriter|SMTLazyMAM|StrategicSolver|SMTSolverInstallsQuantifier|SMTQuantifierManager|API.*Incremental)']
 with(w/'build.lock').open('a')as f,(root/f'focused-{tags or "release"}.log').open('w')as out:
  fcntl.flock(f,fcntl.LOCK_SH);p=subprocess.run(args,cwd=pkg,env=env,stdout=out,stderr=out)
 print('focused',tags,p.returncode,flush=True);return p.returncode
def timed(bs):
 out=root/'elapsed';out.mkdir(exist_ok=True);j=mi.jobs()[0]
 # The same CPU is used across one triplet. The checker accepts only complete
 # triplets with >=95% CPU use and idle sibling.
 a=subprocess.run([sys.executable,d/'quiet_triggers.py','production',bs['connected']],env=dict(env,PYTHONPATH=str(pkg/'perf/ivy_apple/holdouts')),capture_output=True,text=True)
 (out/'driver.log').write_text(a.stdout+a.stderr);assert a.returncode==0
def source_trace():
 dest=root/'trace';sd=dest/'checker';sd.mkdir(parents=True,exist_ok=True)
 b=sd/'goivy_check'
 with(w/'build.lock').open('a')as f,(sd/'build.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-modfile='+str(w/'local-checkout.mod'),'-o',b,'./cmd/goivy_check'],cwd=ivy,stdout=log,stderr=log)
 (sd/'build-info.txt').write_text(linked(b));(sd/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc');binder.root=dest;binder.trace({'before-trace':w/'rows-final/trace/after/goivy_check','after-trace':b})
def main():
 with ThreadPoolExecutor(3)as ex:
  a=ex.submit(build,root/'checker');b=ex.submit(build,root/'shell','g3',None,True);tests=[ex.submit(focused,t)for t in ['','g3checked','g3debug']]
  binary=a.result();shell=b.result();(root/'build-info.txt').write_text(linked(binary))
  assert all(f.result()==0 for f in tests)
 bs={'baseline':base,'connected':binary,'native':native};ho.root=root;gc.d=root;sr.d=root;sr.old_shell=w/'rows-final/shell/g3'
 js=ho.jobs()+[(c,*j[1:5],j[-1])for c,j in zip([9,11,13,15,17,19],(j for j in mi.jobs()if j[1]in ('tlb','raft_no_assume_test','rfn2','dramc_nb2','cf_live','hybrid_reliable_broadcast_cisa')))]
 with ThreadPoolExecutor(18)as ex:
  tasks=[ex.submit(ho.measure_spec,j,bs,3)for j in js]+[ex.submit(gc.corpus,binary),ex.submit(timed,bs),ex.submit(source_trace),ex.submit(sr.shell,shell)]
  for p in tasks:p.result()
if __name__=='__main__':main()
