from common import *
import macro_identity as mi,guarded_live as gl,conditional_datatypes as cd
from panel import CASES
root=d/'connected-triggers';root.mkdir(exist_ok=True)
multi=pkg/'ast/pattern/multi_pattern.go'
helper='''
func(c *patternCandidates)trialBridge(terms,pool []ast.ASTHandle)([]ast.ASTHandle,bool){
 if len(terms)<MIN || len(terms)>12 || c.numBindings<3 || c.numBindings>32 || len(pool)>128{return terms,false}
 mask:=func(h ast.ASTHandle)uint32{var bits uint32;for v:=range c.info[h].freeVars{if v>=32{return 0};bits |=uint32(1)<<v};return bits}
 var groups [12]uint32
 add:=func(bits uint32,n int) int{for j:=0;j<n;{if groups[j]&bits!=0{bits|=groups[j];n--;groups[j]=groups[n]}else{j++}};groups[n]=bits;return n+1}
 n:=0;for _,h:=range terms{n=add(mask(h),n)};if n<2{return terms,false}
 bestScore:=0;var best ast.ASTHandle
 for _,h:=range pool{
  b:=mask(h);hits:=0;for _,g:=range groups[:n]{if g&b!=0{hits++}};if hits<2{continue}
  score:=hits*512;d,e:=c.manager.GetDecl(h);if e!=nil{return terms,false}
  if RARE {for _,p:=range pool{f,e:=c.manager.GetDecl(p);if e!=nil{return terms,false};if d==f{score--}}}
  if score>bestScore{bestScore=score;best=h}
 }
 if bestScore==0{return terms,false}
 if SUBSTITUTE {
  for i:=range terms{all:=mask(best);n:=add(all,0);for j,h:=range terms{if j!=i{bits:=mask(h);n=add(bits,n);all|=bits}};if n==1 && all==(uint32(1)<<c.numBindings)-1{out:=append([]ast.ASTHandle(nil),terms...);out[i]=best;return out,true}}
  return terms,false
 }
 joined:=make([]ast.ASTHandle,0,len(terms)+1)
 if FIRST{joined=append(joined,best)};joined=append(joined,terms...);if !FIRST{joined=append(joined,best)};return joined,true
}
'''
def edits(v):
 if v=='control':return {}
 ed=cd.ed('data256')if v.startswith('factored')else {}
 s=multi.read_text();x='pattern, err := c.manager.MkFamilyApp(2, 0, nil, current.exprs)'
 s=once(s,x,'terms,joined:=c.trialBridge(current.exprs,candidates);_=joined;pattern,err:=c.manager.MkFamilyApp(2,0,nil,terms)')
 if 'fallback'in v:
  x='result = append(result, owned)';s=once(s,x,x+'''\nif joined{original,e:=c.manager.MkFamilyApp(2,0,nil,current.exprs);if e!=nil{return result,e};old,e:=c.manager.NewRef(original);if e!=nil{return result,e};result=append(result,old)}''')
 es=helper.replace('MIN','3'if 'wide'in v else'2').replace('SUBSTITUTE',str('swap'in v).lower()).replace('RARE',str('rare'in v or 'first'in v or 'fallback'in v).lower()).replace('FIRST',str('first'in v).lower())
 ed[multi]=s+es;return ed
def mk(v):
 if v=='control':return base
 od=root/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v));b=build(od/'checker',o=o);(od/'build-info').write_text(linked(b));return b
def lane(j,bb):
 cpu,n,sp,iso,rc,rep,ref=j;od=root/n;od.mkdir(exist_ok=True)
 with(od/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['round','variant','result','match','instructions','wall']);vs=list(bb)
  for i in range(rep):
   for v in vs[i%len(vs):]+vs[:i%len(vs)]:
    td=od/f'{i+1}-{v}';td.mkdir(exist_ok=True);counter=td/'counts';cmd=['taskset','-c',str(cpu),perf,'stat','-x,','-e','instructions:u','-o',counter,'--','timeout','-k','3','150',bb[v],*(['isolate='+iso]if iso else[]),examples/sp];st=time.perf_counter();p=subprocess.run(cmd,cwd=td,env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True);wall=time.perf_counter()-st;ok=p.returncode==rc and (p.stdout,p.stderr)==tuple((ref/k).read_bytes()for k in('stdout','stderr'));cnt=next((int(row[0])for row in csv.reader(counter.open())if len(row)>4 and row[2]=='instructions:u'and float(row[4])==100),0)
    if not ok:(td/'stdout').write_bytes(p.stdout);(td/'stderr').write_bytes(p.stderr)
    z.writerow([i+1,v,p.returncode,int(ok),cnt,wall]);f.flush();print(n,i+1,v,p.returncode,ok,round(cnt/1e9,3),flush=True)
if __name__=='__main__':
 vs=['control','connect','rare','first','swap','fallback','wide-fallback','factored-fallback']
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(mk,vs)))
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([1,3,5,7,9,11,13,15,17],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 n='raft_no_assume';sp,iso,_,f,u=CASES[n];js.append((19,n,sp,iso,int(bool(f or u)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(10)as ex:list(ex.map(lambda j:lane(j,bb),js))
