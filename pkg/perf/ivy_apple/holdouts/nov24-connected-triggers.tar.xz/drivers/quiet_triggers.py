from common import *
import macro_identity as mi,rotating_verification as rv
from types import SimpleNamespace
from panel import measure,EVENTS
root=d/('quiet-'+(sys.argv[1] if len(sys.argv)>1 else 'connected'));root.mkdir(exist_ok=True)
j=mi.jobs()[0];b=d/'connected-triggers/fallback/checker/goivy_check'if len(sys.argv)<3 else Path(sys.argv[2]);bs={'connected':b,'baseline':base,'native':native};rng=range(48)
with(root/'runs.csv').open('w')as f:
 z=csv.writer(f);z.writerow(['round','attempt','engine','cpu','before','sibling','occupancy','match','wall','user','sys','rss',*EVENTS])
 attempts=0;rounds=0
 while rounds<7 and attempts<60:
  a=rv.ticks(rng);time.sleep(3);e=rv.ticks(rng)
  idle={c:min(rv.idle(a,e,c),rv.idle(a,e,c+24))for c in range(24)if c not in [0,2,4,6,8,10,14,16,18]}
  eligible=[c for c,t in idle.items() if t>=.95]
  if not eligible:time.sleep(12);continue
  eligible=sorted(eligible,key=lambda i:(idle[i],(i+attempts)%24),reverse=True);c=eligible[0];attempts+=1
  vs=list(bs);order=vs[rounds%3:]+vs[:rounds%3]
  ok=True
  for v in order:
   td=root/f'{rounds+1}-{attempts}-{v}';cfg=SimpleNamespace(cpu=c,perf=perf,spec=examples/j[2],isolate='')
   t0=rv.ticks([c,c+24]);rc,t,cts=measure(bs[v],cfg,td,0,100);t1=rv.ticks([c,c+24]);sg=rv.idle(t0,t1,c+24);frac=(float(t[1])+float(t[2]))/float(t[0]);match=rc==0 and all((td/k).read_bytes()==(j[-1]/k).read_bytes()for k in ['stdout','stderr'])
   z.writerow([rounds+1,attempts,v,c,idle[c],sg,frac,int(match),*t,*cts]);f.flush();assert match
   if min(sg,frac)<.95:ok=False;break
  if ok:rounds+=1
  print(rounds,attempts,c,ok,flush=True)
 assert rounds==7
