from common import *
import connected_triggers as ct,macro_identity as mi,holdouts as ho,ground_release_controls as gc
root=d/'retained-triggers';root.mkdir(exist_ok=True)
multi=ct.multi
helper='''package pattern

import "github.com/glycerine/g3/pkg/ast"

// A multi-pattern with disjoint groups of variables can enumerate a Cartesian
// product of matches. A further term from the filtered pool can join two or
// more groups before the matcher proposes a substitution. The ordinary
// pattern remains available for a later matching round.
func (c *patternCandidates) connectingTerm(selected, candidates []ast.ASTHandle) (ast.ASTHandle, error) {
 const maxTerms = 12
 if len(selected) < 2 || len(selected)>maxTerms || c.numBindings > 32 || c.numBindings < 3 || len(candidates)>128 {
  return ast.ASTHandle{}, nil
 }
 variables:=func(term ast.ASTHandle)uint32{
  var mask uint32
  for variable:=range c.info[term].freeVars{mask|=uint32(1)<<variable}
  return mask
 }
 var groups [maxTerms]uint32
 count:=0
 for _,term:=range selected{
  mask:=variables(term)
  for i:=0;i<count;{
   if groups[i]&mask==0{i++;continue}
   mask|=groups[i]
   count--
   groups[i]=groups[count]
  }
  groups[count]=mask
  count++
 }
 if count<2{return ast.ASTHandle{},nil}
 // Resolve equal scores by the number of candidate terms with the same
 // declaration. A single relation mentioned many ways can match a large
 // number of tuples. A further tie retains the existing candidate order.
 var best ast.ASTHandle
 maxGroups:=1
 minUses:=len(candidates)+1
 var uses map[ast.ASTHandle]int
 for _,term:=range candidates{
  mask:=variables(term)
  joined:=0
  for _,group:=range groups[:count]{if group&mask!=0{joined++}}
  if joined<2 || joined<maxGroups{continue}
  if uses==nil{
    uses=make(map[ast.ASTHandle]int,len(candidates))
    for _,h:=range candidates{decl,err:=c.manager.GetDecl(h);if err!=nil{return ast.ASTHandle{},err};uses[decl]++}
  }
  decl,err:=c.manager.GetDecl(term);if err!=nil{return ast.ASTHandle{},err};freq:=uses[decl]
  if joined>maxGroups || freq<minUses{best,maxGroups,minUses=term,joined,freq}
 }
 return best,nil
}
'''
def ed(v):
 if v=='control':return {}
 c=multi.with_name('candidates.go');s=multi.read_text();a=s.index('pattern, err := c.manager.MkFamilyApp');b=s.index('if uint64(len(result))',a)
 s=s[:a]+'''var err error
  if c.preferConnected && len(result)==0 && maxPatterns==1 && GUARD {
   term,e:=c.connectingTerm(current.exprs,candidates);if e!=nil{return result,e}
   if !term.IsNull(){joined:=make([]ast.ASTHandle,len(current.exprs)+1);copy(joined,current.exprs);joined[len(current.exprs)]=term;result,err=c.appendMultiPattern(result,joined);if err!=nil{return result,err}}
  }
  result,err=c.appendMultiPattern(result,current.exprs);if err!=nil{return result,err}
  '''+s[b:]
 s+='''
func(c *patternCandidates)appendMultiPattern(patterns []ast.ASTRef,terms []ast.ASTHandle)([]ast.ASTRef,error){
 pattern,err:=c.manager.MkFamilyApp(2,0,nil,terms);if err!=nil{return patterns,err}
 ref,err:=c.manager.NewRef(pattern);if err!=nil{return patterns,err}
 return append(patterns,ref),nil
}
'''
 s=s.replace('GUARD','c.manager.TraceStream==nil && !c.manager.Budget().InjectionArmed() && !c.manager.NumeralService().RuntimeOwner().AllocationLimited() && c.manager.ResourceLimit().Limit==0 && !c.manager.ResourceLimit().CancelFlag()'if v!='broad'else'true')
 es={multi:s,c:once(c.read_text(),'blockLoops         bool','blockLoops         bool\n preferConnected bool'),multi.with_name('connected_multi_pattern.go'):helper}
 opt=multi.with_name('options.go')
 es[opt]=once(opt.read_text(),'MaxMultiPatterns          uint32','''// PreferConnectedMultiPatterns tries a more selective inferred trigger
 // before its ordinary fallback. It is fixed for this rewriter's lifetime.
 PreferConnectedMultiPatterns bool
 MaxMultiPatterns          uint32''')
 rw=multi.with_name('rewriter.go');x='candidates.avoidSkolems = options.AvoidSkolems\n\tif'
 es[rw]=once(rw.read_text(),x,'candidates.preferConnected=options.PreferConnectedMultiPatterns && !proofs && !ast.ASTSourceDebug && !diagnostic.TraceCompiled()\n\t'+x);es[rw]=once(es[rw],'"errors"','"errors"\n"github.com/glycerine/g3/pkg/util/diagnostic"')
 k=pkg/'smtcore/smt_kernel.go';s=once(k.read_text(),'simplifyInitialPushOnce   bool','simplifyInitialPushOnce   bool\n preferConnectedMultiPatterns bool')
 x='k.patternInference, err = pattern.NewInferenceRewriterWithOptions';s=once(s,x,'patternOptions.PreferConnectedMultiPatterns=k.preferConnectedMultiPatterns\n\t'+x);es[k]=s
 sf=pkg/'smtcore/smt_solver.go';s=once(sf.read_text(),'SimplifyInitialPushOnce bool','''SimplifyInitialPushOnce bool
 // PreferConnectedMultiPatterns enables selective and fallback E-matching
 // triggers for incremental verification.
 PreferConnectedMultiPatterns bool''');es[sf]=once(s,'kernel.simplifyInitialPushOnce = config.SimplifyInitialPushOnce','kernel.preferConnectedMultiPatterns=config.PreferConnectedMultiPatterns\n\tkernel.simplifyInitialPushOnce = config.SimplifyInitialPushOnce')
 factory=pkg/'tactic/portfolio/strategic_solver_factory.go';es[factory]=once(factory.read_text(),'config.SimplifyInitialPushOnce = true','config.SimplifyInitialPushOnce = true\n config.PreferConnectedMultiPatterns=true')
 return es
def mk(v):
 if v=='control':return base
 od=root/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',ed(v));b=build(od/'checker',o=o);(od/'build-info').write_text(linked(b));return b
def main():
 vs=['control','guarded','broad']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 bs['native']=native;ct.root=root
 js=[(c,*j[1:5],5,j[-1])for c,j in zip([0,2,4,6,8,10,12,14,16],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 gc.d=root
 with ThreadPoolExecutor(10)as e:
  fs=[e.submit(ct.lane,j,bs)for j in js]+[e.submit(gc.corpus,bs['guarded'])]
  for f in fs:f.result()
if __name__=='__main__':main()
