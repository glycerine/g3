from study import *
import branch_controls as bc, setup_release as sr, setup_features_trials as ex, ground_release_controls as gc
import guard_sort_trials as gst
from collections import Counter
import itertools
d=sr.d
def shell(bs):
 cases=sorted((w/'branch-controls/inputs').glob('*.smt2'))
 add=d/'setup-inputs';add.mkdir(exist_ok=True)
 for conf,mode,casespec,action in itertools.product((True,False),['seq','z3str3','auto','bad'],['ALL','QF_S','QF_UF','QF_LIA','AUFLIA','QF_AX'],['push','check','retry']):
  ss={'ALL':'(declare-const x (Seq Int))(assert (= (seq.len x) 1))','QF_S':'(declare-const x String)(assert (str.contains x "x"))','QF_UF':'(declare-sort A 0)(declare-const a A)(assert (= a a))','QF_LIA':'(declare-const x Int)(assert (= x 4))','AUFLIA':'(declare-fun f (Int) Int)(assert (forall ((i Int)) (>= (f i) 0)))','QF_AX':'(declare-sort A 0)(declare-const a (Array A A))(declare-const x A)(assert (= (select a x) x))'}[casespec]
  if action=='push':ss+='(push)(check-sat)(pop)(check-sat)'
  elif action=='retry':ss+='(push)(set-option :smt.string_solver seq)(push)(check-sat)'
  else:ss+='(check-sat)'
  f=add/f'{conf}-{mode}-{casespec}-{action}.smt2';f.write_text('(set-logic '+casespec+')(set-option :auto_config '+str(conf).lower()+')(set-option :smt.string_solver '+mode+')'+ss+'\n');cases.append(f)
 cs=[0,3,6,8,12,16,18,24]
 def runone(t):
  c,fs=t;dd=d/'shell-controls'/str(c);dd.mkdir(parents=True,exist_ok=True)
  with(dd/'results.csv').open('w')as f:
   z=csv.writer(f);z.writerow(['input','reference_exit','trial_exit','stdout','stderr','result_match','timeout'])
   for p in fs:
    vals=[]
    for v,b in bs.items():
     try:r=subprocess.run(['taskset','-c',str(c),b,'-in','-smt2'],input=p.read_bytes(),capture_output=True,timeout=25,env=dict(env,GOMAXPROCS='1'));o,e,rc=r.stdout,r.stderr,r.returncode
     except subprocess.TimeoutExpired as er:o,e,rc=er.stdout or b'',er.stderr or b'',124
     vals.append((rc,o,e))
    a,b=vals;answers=lambda a:[line for line in a.splitlines()if line.strip() in (b'sat',b'unsat',b'unknown')]
    flag=(a[0],answers(a[1]))==(b[0],answers(b[1]));z.writerow([p.name,a[0],b[0],int(a[1]==b[1]),int(a[2]==b[2]),int(flag),int(124 in(a[0],b[0]))]);f.flush()
    if a!=b:
     diff=dd/p.name;diff.mkdir(exist_ok=True)
     for name,(rc,o,e) in zip(bs,vals):(diff/(name+'.out')).write_bytes(o);(diff/(name+'.err')).write_bytes(e)
 with ThreadPoolExecutor(len(cs))as e:list(e.map(runone,[(c,cases[i::len(cs)])for i,c in enumerate(cs)]))
def main():
 o=d/'overlay/overlay.json'
 with(w/'build.lock').open('a')as lk:
  fcntl.flock(lk,fcntl.LOCK_SH)
  with(d/'packages.txt').open('w')as f:run(['go','test','-p','5','-count=1','-overlay='+str(o),'./ast','./smtcore','./api','./tactic/portfolio','./cmd/g3'],cwd=pkg,stdout=f,stderr=f)
  with(d/'debug.txt').open('w')as f:run(['go','test','-p','5','-count=1','-tags=g3debug,g3trace','-overlay='+str(o),'-run','(?i)setup|staticfeatures|assertedbounds','./ast','./smtcore','./cmd/g3'],cwd=pkg,stdout=f,stderr=f)
def corpus():
 gc.d=d;gc.corpus(d/'checker/goivy_check')
if __name__=='__main__':
 if sys.argv[1]=='shell':shell({'control':ex.d/'control/shell/g3','release':d/'shell/g3'})
 elif sys.argv[1]=='corpus':corpus()
 else:main()
