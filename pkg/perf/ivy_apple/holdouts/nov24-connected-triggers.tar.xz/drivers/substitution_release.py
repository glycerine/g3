from study import *
import guarded_live as gl,macro_identity as mi,ground_release_controls as gc,setup_controls as sc,proof_release_trace as tr,verification_frontier as vf,theory_traversal_steps as th,binder_exits as binder
from archive_plans_macros import rows
from quantifier_controls import normalize
d=w/'substitution-release';d.mkdir(exist_ok=True)
old=w/'frontend-owned-production/after-g3/goivy_check';native=w/'frontend-owned-production/after-native/goivy_check';old_shell=w/'symbol-codec-release/shell/g3'
def binaries():
 with ThreadPoolExecutor(2)as e:return list(e.map(lambda nm:build(d/nm,shell=nm=='shell'),['checker','shell']))
def micro():
 bs={};q=pkg/'smtcore/cached_var_subst.go';btest=pkg/'smtcore/smt_quantifier_substitution_benchmark_test.go';rt=pkg/'smtcore/cached_var_subst_ownership_regression_test.go';saved=lambda q:subprocess.check_output(['git','show','c6c84b31e:pkg/'+str(q.relative_to(pkg))],cwd=pkg,text=True)
 for v in ['previous','g3']:
  od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',{q:saved(q),rt:saved(rt),btest:btest.read_text()} if v=='previous'else{q:q.read_text(),rt:rt.read_text(),btest:btest.read_text()})
  b=od/'smt.test';bs[v]=b
  with(w/'build.lock').open('a')as f:
   fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-c','-p','4','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg)
 with(d/'batches.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round variant batch iterations ns bytes allocs'.split())
  for i in range(21):
   for v,b in list(bs.items())[::1 if i%2==0 else -1]:
    r=run(['taskset','-c','38',b,'-test.run','^$','-test.bench=^BenchmarkSMTQuantifierInstanceBatches$','-test.benchmem','-test.cpu=1','-test.benchtime=65536x'],cwd=pkg/'smtcore',capture_output=True,text=True)
    vs=re.findall(r'BenchmarkSMTQuantifierInstanceBatches/(\d+)\s+(65536)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(vs)==4;z.writerows([[i+1,v,*x]for x in vs]);f.flush()
def shell(s):
 sc.d=d;sc.shell({'control':old_shell,'release':s})
 with(d/'shell-comparison.csv').open('w')as f:
  z=csv.writer(f);z.writerow('input streams normalized'.split());rs=[r for p in d.glob('shell-controls/*/results.csv')for r in rows(p)]
  assert len(rs)==1799 and all(r['result_match']=='1'for r in rs)
  for p in sorted(d.glob('shell-controls/*/*')):
   if not p.is_dir():continue
   ds=[]
   for k in ['out','err']:
    a,b=[(p/(v+'.'+k)).read_bytes()for v in ['control','release']]
    if a!=b:ds.append(k)
    assert normalize(a)==normalize(b),(p,k)
   z.writerow([p.name,'|'.join(ds),1])
 with(d/'datalog.csv').open('w')as f:
  z=csv.writer(f);z.writerow('engine output'.split())
  for v,b in [('previous',old_shell),('g3',s)]:
   r=run([b,'smt.timeout=50','-in','-smt2'],input=(w/'branch-controls/inputs/repo-datalog_soft_timeout.smt2').read_bytes(),capture_output=True,timeout=25)
   assert r.stdout.splitlines()==[b'unknown',b'timeout']and not r.stderr;z.writerow([v,'unknown/timeout'])
def main():
 b,s=binaries();bb={'previous':old,'g3':b,'native':native};gl.d=d;gc.d=d;th.d=d
 js=[(cpu,*j[1:5],4,j[-1])for cpu,j in zip([25,26,27,28,29,30,31,32,33,34],mi.jobs())]
 js.extend([(6,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native'),(8,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native')])
 quiet=[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',b,'--previous',old,'--native',native,'--rounds','7','--max-attempts','24','--wait-seconds','3200','--cpu','23','--min-idle','.95','--spec',examples/'jea/hermes_rmw_o3.ivy','--reference',vf.reference('jea/hermes_rmw_o3.ivy'),'--perf',perf,'--output',d/'ordinary-quiet']
 with ThreadPoolExecutor(len(js)+9)as e:
  fs=[e.submit(gl.measure_job,j,bb)for j in js]+[e.submit(gc.corpus,b),e.submit(shell,s),e.submit(tr.trace,d),e.submit(micro),e.submit(run,quiet,stdout=subprocess.DEVNULL)]+[e.submit(th.replay,(c,n,{'previous':old_shell,'g3':s,'native':pkg.parent/'build/z3'}))for c,n in [(36,'ticket-127'),(37,'ticket-290'),(40,'toy-consensus-18')]]
  for f in fs:f.result()
if __name__=='__main__':main()
