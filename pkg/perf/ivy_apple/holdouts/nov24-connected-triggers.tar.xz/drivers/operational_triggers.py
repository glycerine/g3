from common import *
import macro_identity as mi,connected_triggers as ct,retained_triggers as rt
root=d/'operational-triggers';root.mkdir(exist_ok=True)
def ed(v):
 es=rt.ed('guarded');multi=ct.multi;candidate=multi.with_name('candidates.go');rw=multi.with_name('rewriter.go');k=pkg/'smtcore/smt_kernel.go';qm=pkg/'smtcore/smt_quantifier_manager.go';registry=pkg/'smtcore/smt_quantifier_registry.go';ss=es[multi]
 s=multi.read_text();x='result = append(result, owned)';s=once(s,x,'''if c.preferConnected && len(result)==0 && maxPatterns==1 && c.manager.TraceStream==nil && !c.manager.Budget().InjectionArmed(){edge,e:=c.connectingTerm(current.exprs,candidates);if e!=nil{return append(result,owned),e};if !edge.IsNull(){c.proposedPattern=pattern;c.proposedTerm=edge}}
  '''+x);es[multi]=s
 size='32'if v=='small'else'256'
 es[candidate]=once(es[candidate],'preferConnected bool','preferConnected bool\n proposedPattern,proposedTerm ast.ASTHandle')
 s=es[rw];x='var result ast.ASTRef';s=once(s,x,'r.candidates.proposedPattern=ast.ASTHandle{};r.candidates.proposedTerm=ast.ASTHandle{}\n'+x)
 x='if err == nil {\n\t\terr = r.manager.SetRef(out, quantifier)';s=once(s,x,'''if err==nil && !r.candidates.proposedTerm.IsNull() {
    nested,e:=r.manager.HasQuantifiers(body);if e!=nil{err=e}else if !nested {n,e:=r.manager.GetNumPatterns(quantifier);if e!=nil{err=e}else if n==1{p,e:=r.manager.GetPattern(quantifier,0);if e!=nil{err=e}else if p==r.candidates.proposedPattern{if r.suggestions==nil{r.suggestions=new(['''+size+''']trialSuggestion)};r.suggestions[quantifier.Slot()%'''+size+''']=trialSuggestion{quantifier,p,r.candidates.proposedTerm}}}}
  }
  '''+x)
 s=once(s,'type InferenceRewriter struct {','type trialSuggestion struct{q,p,term ast.ASTHandle}\ntype InferenceRewriter struct {\n suggestions *['+size+']trialSuggestion')
 s+='''
func(r *InferenceRewriter)SuggestedConnector(q,p ast.ASTHandle)ast.ASTHandle{
 if r==nil || r.suggestions==nil{return ast.ASTHandle{}};entry:=r.suggestions[q.Slot()%'''+size+'''];if entry.q==q && entry.p==p{return entry.term};return ast.ASTHandle{}
}''';es[rw]=s
 s=es[k];x='if err = k.configureQuantifiers(full, fullState, quantifiers); err != nil {\n\t\treturn err\n\t}';es[k]=once(s,x,x+'\n if k.preferConnectedMultiPatterns && k.patternInference!=nil{k.internalizer.quantifierManager.connector=k.patternInference.SuggestedConnector}')
 s=qm.read_text();x='maxEagerMultipatterns       uint32';s=once(s,x,x+'\n connector func(ast.ASTHandle,ast.ASTHandle)ast.ASTHandle')
 x='if recursive && i > 0 {';s=once(s,x,'''if q.connector!=nil && !recursive && !unary && count==1 && q.maxEagerMultipatterns==0 && q.maxLazyMultipatternMatching>0 && q.state.manager.TraceStream==nil && !q.state.manager.Budget().InjectionArmed() && q.state.manager.ResourceLimit().Limit==0 && !q.state.manager.ResourceLimit().CancelFlag(){
   term:=q.connector(quantifier,pattern);if !term.IsNull(){p,e:=q.registry.trialConnectedPattern(quantifier,pattern,term);if e!=nil{return e};if e=q.mam.AddPattern(quantifier,p);e!=nil{return e};return q.lazyMAM.AddPattern(quantifier,pattern)}
  }
  '''+x);es[qm]=s
 s=registry.read_text();x='type SMTQuantifierRegistry struct {';s=once(s,x,x+'\n extraPatterns map[ast.ASTHandle]ast.ASTRef')
 x='delete(r.statistics, quantifier)';s=once(s,x,'if e:=r.dropExtra(quantifier);e!=nil{return e}\n'+x);x='r.fingerprints.Reset()';s=once(s,x,'for h:=range r.extraPatterns{if e:=r.dropExtra(h);e!=nil{return e}}\n'+x)
 s+='''
func(r *SMTQuantifierRegistry)trialConnectedPattern(q,p,extra ast.ASTHandle)(ast.ASTHandle,error){
 if ref,ok:=r.extraPatterns[q];ok{return r.manager.RefGet(ref)}
 n,e:=r.manager.GetNumArgs(p);if e!=nil{return ast.ASTHandle{},e};terms:=make([]ast.ASTHandle,n+1)
 for i:=uint32(0);i<n;i++{terms[i],e=r.manager.GetArg(p,i);if e!=nil{return ast.ASTHandle{},e}};terms[n]=extra
 h,e:=r.manager.MkPattern(terms);if e!=nil{return ast.ASTHandle{},e};ref,e:=r.manager.NewRef(h);if e!=nil{return ast.ASTHandle{},e}
 if r.extraPatterns==nil{r.extraPatterns=make(map[ast.ASTHandle]ast.ASTRef)};r.extraPatterns[q]=ref;return h,nil
}
func(r *SMTQuantifierRegistry)dropExtra(q ast.ASTHandle)error{
 if r.extraPatterns==nil{return nil};ref,ok:=r.extraPatterns[q];if !ok{return nil}
 e:=r.manager.DelRef(&ref);if ref==(ast.ASTRef{}){delete(r.extraPatterns,q)}else{r.extraPatterns[q]=ref};return e
}
''';es[registry]=s
 return es
def mk(v):
 od=root/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',ed(v));b=build(od/'checker',o=o);(od/'build-info').write_text(linked(b));return b
if __name__=='__main__':
 vs=['small','large']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 bs={'control':base,**bs,'annotated':d/'retained-triggers/guarded/checker/goivy_check'};ct.root=root
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([1,3,5,7,9,11,13,15,17],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(9)as ex:list(ex.map(lambda j:ct.lane(j,bs),js))
