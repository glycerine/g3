# Warm enumeration resource limits

Run from the g3 pkg directory on Linux/amd64 with the Go toolchain specified by pkg/go.mod. The benchmark uses the checked-in apple_enumeration_search fixture at g3 32925b7f7. Keep each historical prefix at six million units and vary the final query only.

    go test -tags=xtrace_off -run '^$' -bench '^BenchmarkEnumerationWarmBudget$' -benchtime=1x -cpu=1 ./api

The raw files in benchmark were produced by one compiled test binary. Different query numbers ran concurrently on the host. Elapsed samples include the prefix and are unsuitable as timing comparisons between resource limits. final-resources/op measures the change in the private manager's resource count across just the terminal check. final-proofs/op distinguishes a refutation from exhaustion.

Each live comparison used the same GoIvy frontend, local g3 checkout, GOMAXPROCS=1 and trace-disabled build. The experimental policy lifted the six-million allowance to twelve million only for an already asserted goal with a surviving compatible private kernel. All source outcomes, exit codes and both output streams matched. The case apple2 is the entire doc/examples/apple/ord_live2.ivy, and sys_live is one isolate of that same file.

*-checks.csv records user instructions on the checking thread around the complete child enumeration check and the original solver check separately, with an empty interval subtracted. The fields enum_sequence list the private checks included in that frontend call. problems.csv compares the two captured private streams in sequence order by direct equality of their complete problem records, including SMT-LIB text and assertion boundaries. fresh indicates the start of a private solver lifetime. proved describes that particular private check.

The original complete replay fixtures and the general capture method are in the adjacent nov24-enumeration-replay.tar.xz and nov24-enumeration-symbol-history.tar.xz archives.
