"""Prototype quantifier-free subtree pruning during verifier pattern inference."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;pkg=Path.cwd()
front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3])
name=sys.argv[3]
ov={}
for fn in ['ast/pattern/rewriter.go','smtcore/smt_asserted_patterns.go']:
 src=pkg/fn;s=src.read_text()
 if fn.startswith('ast'):
  s=s.replace('owner *InferenceRewriter','prune bool\n owner *InferenceRewriter',1)
  i=s.index('func (c *inferenceConfiguration) ReduceQuantifier')
  s=s[:i]+'''func (c *inferenceConfiguration) PreVisit(t ast.ASTHandle) (bool,error) {
   if !c.prune {return true,nil}
   return c.owner.manager.HasQuantifiers(t)
  }
  func (r *InferenceRewriter) RewriteQuantified(t ast.ASTHandle,out ast.ASTRef) error {
   r.config.prune=true
   defer func(){r.config.prune=false}()
   return r.Rewrite(t,out)
  }
  '''+s[i:]
 else:
  s=s.replace('if k.connectedMultiPatterns {','prune:=false\n if k.connectedMultiPatterns {')
  s=s.replace('if err = k.patternInference.SetConnectedMultiPatterns(connected);','prune=connected && !ast.ASTValidateHandles\n if err = k.patternInference.SetConnectedMultiPatterns(connected);')
  s=s.replace('} else {\n\t\t\terr = k.patternInference.Rewrite(row.Formula, out)','} else if prune {\n err=k.patternInference.RewriteQuantified(row.Formula,out)\n } else {\n\t\t\terr = k.patternInference.Rewrite(row.Formula, out)')
 dst=w/(name+'-'+Path(fn).name);dst.write_text(s);ov[str(src)]=str(dst)
o=w/(name+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/name,'./cmd/goivy_check'],cwd=front,check=True)
