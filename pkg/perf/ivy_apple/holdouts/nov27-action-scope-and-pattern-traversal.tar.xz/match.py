"""Measure native pass costs on the specific action batches that g3 physically pushes."""
import csv,json,os,statistics,subprocess,sys
from collections import defaultdict
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3])
f=front/'z3bridge_solver_model.go';s=f.read_text()
key='func (s *Solver) GetSmallModelWithCond('
s=s.replace(key,'var studyBatch int\n\n'+key)
i=s.index(key);j=s.index('z3solver := s.newZ3Solver()',i)
s=s[:j]+'studyBatch++; id:=studyBatch; firstPhysical:=true\n '+s[j:]
key='if s.opts.Incremental {\n\t\t\t\t\tz3solver.Push()'
assert s.count(key)==1
s=s.replace(key,'if s.opts.Incremental {\n if firstPhysical{fmt.Fprintln(os.Stderr,"PHYSICAL",id);firstPhysical=false}\n z3solver.Push()')
d=w/'physical.go';d.write_text(s)
o=w/'physical.json';o.write_text(json.dumps({'Replace':{str(f):str(d)}}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'physical','./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');old=Path('/tmp/g3-ivy-pgo')
codes={r['spec']:int(r['exit']) for f in (old/'survey').glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
for name,stage in [('examples/ivy/flash2.ivy','flash'),('examples/liveness/hybrid_reliable_broadcast_cisa.ivy','hybrid'),('examples/liveness/tlb.ivy','tlb')]:
 idx=(old/'prior-gaps.txt').read_text().splitlines().index(name)+1;ref=old/'survey'/str(idx)/'1/native'
 r=subprocess.run([w/'physical',ex/name],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=120)
 lines=r.stderr.splitlines(keepends=True)
 assert (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith(b'PHYSICAL ')))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
 ids=[int(l.split()[1]) for l in lines if l.startswith(b'PHYSICAL ')]
 rows=list(csv.DictReader((w/('pass-'+stage+'.csv')).open()))
 with (w/('matched-'+stage+'.csv')).open('w') as f:
  out=csv.DictWriter(f,fieldnames=rows[0].keys());out.writeheader()
  for row in rows:
   if row['engine']=='native':
    if int(row['push']) not in ids:continue
   else:row['push']=ids[int(row['push'])-1]
   out.writerow(row)
 print(stage,len(ids),flush=True)
