import collections,csv,statistics as s,sys
for f in sys.argv[1:]:
 rows=collections.defaultdict(lambda:collections.defaultdict(collections.Counter))
 for r in csv.DictReader(open(f)):rows[r['engine']][int(r['round'])][r['stage']]+=int(r['instructions'])
 print(f)
 for stage in sorted(set(k for rounds in rows.values() for stages in rounds.values() for k in stages)):
  print(stage,*[round(s.median([stages[stage] for stages in rounds.values()])/1e6,2) for rounds in rows.values()])
 print([(eng,len(v)) for eng,v in rows.items()])
