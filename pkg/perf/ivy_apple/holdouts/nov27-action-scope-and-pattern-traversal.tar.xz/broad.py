from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
p=Path('/tmp/g3-ivy-pgo')
cases=(p/'prior-gaps.txt').read_text().splitlines()
i=int(sys.argv[1])
args=[sys.executable,str(w/'compare.py'),f'broad{i}_base_release',str(32+2*i),'2',*cases[i::4]]
subprocess.run(args,check=True)
