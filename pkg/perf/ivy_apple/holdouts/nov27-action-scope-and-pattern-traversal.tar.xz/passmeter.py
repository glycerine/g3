"""Isolate first-push pass costs with one binary and a traversal switch."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);ov={}
def file(fn,s):
 src=p/'smtcore'/fn;dst=w/('measure-'+fn);dst.write_text(s);ov[str(src)]=str(dst)
s=(p/'perf/ivy_apple/incremental_cost/push_stage_counter.go.txt').read_text().replace('package pushcounter','package smtcore')
for key in ['fd','empty','calls','instructions','depth','ordinal','active','readCounter','Scope','Enter','Leave','Pass']:
 import re
 s=re.sub(r'\b'+key+r'\b','study'+key,s)
s=s.replace('studyactive = true','studyactive = true').replace('lo := studyreadCounter()','lo := studyreadCounter()').replace('return func() {\n\t\tstudyactive = false','start:=studyreadCounter();return func() {\n total:=studyreadCounter()-start; fmt.Fprintln(os.Stderr,"IVY-PUSH-TOTAL",studyordinal,total);\n\t\tstudyactive = false')
file('first_push_meter.go',s)
for fn in ['smt_kernel.go','smt_asserted_driver.go','smt_asserted_patterns.go']:
 src=p/'smtcore'/fn;s=src.read_text()
 if fn=='smt_kernel.go':
  key='k.simplifyInitialPushOnce = false';s=s.replace(key,'defer studyScope()()\n '+key)
 elif fn=='smt_asserted_driver.go':
  key='if err := assertedVerbose(10, "(smt."+pass';s=s.replace(key,'if studyactive {defer studyPass(pass.sourceName(),len(k.assertions)-k.assertedHead)()}\n '+key)
 else:
  s=s.replace('"errors"','"errors"\n "os"').replace('skipUnchangedSubtrees = connected && !ast.ASTValidateHandles','skipUnchangedSubtrees = connected && !ast.ASTValidateHandles && os.Getenv("WALK")!="full"')
 file(fn,s)
o=w/'meter.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'meter','./cmd/goivy_check'],cwd=front,check=True)
