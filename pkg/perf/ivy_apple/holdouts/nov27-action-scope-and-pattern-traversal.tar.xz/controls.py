"""Build a verification-only prototype with worker-local action scopes."""
import json,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
pkg=Path.cwd()
front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3])
ov={}
def replace(src,before,after):
 assert src.count(before)==1,before
 return src.replace(before,after)
def put(name,s):
 p=w/name;p.write_text(s);ov[str(front/name)]=str(p)
p='module.go';put(p,replace((front/p).read_text(),'type Module struct {','type Module struct {\n actionStudy *actionScopeStudy'))
p='z3bridge_solver_model.go';s=(front/p).read_text()
i=s.index('func (s *Solver) GetSmallModelWithCond(')
s=s[:i]+'''type actionScopeStudy struct {
 ctx *smt.Z3Context
 params string
 previous map[smt.Z3Expr]bool
 cache *smt.Z3Solver
 prefix []smt.Z3Expr
}

func (s *Solver) studyAction(root smt.Z3Expr, assumptions []smt.Z3Expr) (*actionScopeStudy,*smt.Z3Solver) {
 ctx:=s.tr.Ctx
 params:=fmt.Sprint(solverOptionParamValues(s.opts))
 st:=s.mod.actionStudy
 if st==nil || st.ctx!=ctx || st.params!=params {
  st=&actionScopeStudy{ctx:ctx,params:params};s.mod.actionStudy=st
 }
 zs:=st.cache
 st.cache=nil
 seen:=make(map[smt.Z3Expr]bool)
 var shared,rest []smt.Z3Expr
 var collect func(smt.Z3Expr)
 collect=func(e smt.Z3Expr){
  if e.IsAppOf(smt.DeclAnd){for i,n:=0,e.NumArgs();i<n;i++{collect(e.Arg(i))};return}
  if seen[e]{return};seen[e]=true
  if st.previous[e]{shared=append(shared,e)}else{rest=append(rest,e)}
 }
 collect(root);st.previous=seen
 prefix:=st.prefix
 keep:=zs!=nil
 for _,e:=range prefix{if !seen[e]{keep=false;break}}
 mode:=os.Getenv("ACTION_SCOPE")
 if mode=="transfer" || mode=="flat"{
  zs=s.newZ3Solver()
  if mode=="transfer"{zs.Assert(root)}else{zs.Assert(ctx.And(append(shared,rest...)...))}
  for _,e:=range assumptions{zs.Assert(e)}
  return nil,zs
 }
 if mode=="fresh"{keep=false}
 if !keep || len(prefix)==0 && len(shared)>0 {
  if zs!=nil{zs.Reset()}else{zs=s.newZ3Solver()}
  prefix=shared;st.prefix=prefix
  if len(prefix)>0{zs.Assert(ctx.And(prefix...))}
 }else{
  active:=make(map[smt.Z3Expr]bool,len(prefix))
  for _,e:=range prefix{active[e]=true}
  for _,e:=range shared{if !active[e]{rest=append(rest,e)}}
  // A retained prefix can include new-to-the-previous-batch leaves only
  // when ownership changed. Reasserting an identical leaf is harmless.
 }
 zs.Push()
 if len(rest)>0{zs.Assert(ctx.And(rest...))}
 for _,e:=range assumptions{zs.Assert(e)}
 return st,zs
}

'''+s[i:]
s=replace(s,'var assumes []*Clauses','var action *actionScopeStudy\n var studyAssumes []smt.Z3Expr\n var assumes []*Clauses')
s=replace(s,'assumes = append(assumes, fc.Cond())','studyAssumes=append(studyAssumes,zCond)\n assumes = append(assumes, fc.Cond())')
key='proveGoal = nil\n\t\t\t\t\tfinalCheck = z3solver.Check'
s=replace(s,key,'''proveGoal = nil
 if s.mod!=nil && s.opts.Incremental {
  original:=z3solver
  defer original.Reset()
  action,z3solver=s.studyAction(zc,studyAssumes)
  // Every subsequent concrete check sees the active assertions on its own solver.
  var end func()
  check,end=z3solver.BeginVerificationChecks()
  defer end()
 }
 finalCheck = z3solver.Check''')
key='if overallResult == smt.Unsat {\n\t\t// No model'
s=replace(s,key,'''if overallResult == smt.Unsat {
 if action!=nil {z3solver.Pop();action.cache=z3solver;return nil,nil}
 // No model''')
put(p,s)
o=w/'overlay.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'controls','./cmd/goivy_check'],cwd=front,check=True)
