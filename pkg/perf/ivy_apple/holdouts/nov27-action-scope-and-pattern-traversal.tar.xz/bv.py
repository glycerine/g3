"""Try pruning the first BV-sharing traversal, retaining unconditional theory reduction."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);ov={}
for fn in ['smtcore/smt_kernel.go','smtcore/smt_asserted_bv.go','ast/rewriter/maximize_ac_sharing.go']:
 src=p/fn;s=src.read_text()
 if fn.endswith('smt_kernel.go'):
  s=s.replace('simplifyInitialPushOnce   bool','studyPruneBV bool\n simplifyInitialPushOnce bool')
  s=s.replace('k.simplifyInitialPushOnce = false','''k.studyPruneBV= !ast.ASTValidateHandles && !diagnostic.TraceCompiled() && !k.manager.NumeralService().RuntimeOwner().AllocationLimited()
 defer func(){k.studyPruneBV=false}()
 k.simplifyInitialPushOnce = false''')
  if 'util/diagnostic' not in s:s=s.replace('import (','import (\n "github.com/glycerine/g3/pkg/util/diagnostic"')
 elif fn.endswith('smt_asserted_bv.go'):
  key='if err = k.bvSharing.Rewrite(row.Formula, out, proof); err != nil {'
  assert s.count(key)==1
  s=s.replace(key,'''if k.studyPruneBV {err=k.bvSharing.StudyRewrite(row.Formula,out,proof)}else{err=k.bvSharing.Rewrite(row.Formula,out,proof)}
  if err!=nil {''')
 else:
  s=s.replace('initialized bool','studyPrune bool\n initialized bool')
  key='func (r *MaximizeBVSharing) Rewrite(root'
  assert s.count(key)==1
  s=s.replace(key,'''func (c *MaximizeBVSharingConfiguration) PreVisit(t ast.ASTHandle)(bool,error){
  if c.studyPrune {return c.manager.HasQuantifiersOrITE(t)}
  return true,nil
 }
 func (r *MaximizeBVSharing) StudyRewrite(t ast.ASTHandle,out,proof ast.ASTRef)error{
  r.config.studyPrune=!r.config.initialized && !r.proofs
  defer func(){r.config.studyPrune=false}()
  return r.Rewrite(t,out,proof)
 }
 '''+key)
 dst=w/('bv-'+src.name);dst.write_text(s);ov[str(src)]=str(dst)
o=w/'bv.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'bv','./cmd/goivy_check'],cwd=front,check=True)
