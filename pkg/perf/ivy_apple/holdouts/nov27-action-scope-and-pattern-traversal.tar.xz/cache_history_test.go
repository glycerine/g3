package rewriter

import "testing"

func TestFirstPushSharingCacheHistoryStudy(t *testing.T) {
 f:=newMaximizeBVFixture(t,false)
 inner:=maximizeBVApp(t,f,4,f.vars[:4]...)
 astTestPin(t,f.m,inner)
 before:=maximizeBVApp(t,f,30,inner,f.vars[4])
 after:=maximizeBVApp(t,f,30,inner,f.vars[5])
 astTestPin(t,f.m,before);astTestPin(t,f.m,after)
 for _,prune:=range []bool{false,true}{
  rw,err:=NewMaximizeBVSharing(f.m);astTestMust(t,err)
  out,proof:=maximizeBVOutput(t,f.m)
  if prune{astTestMust(t,rw.StudyRewrite(before,out,proof))}else{astTestMust(t,rw.Rewrite(before,out,proof))}
  astTestMust(t,rw.PushScope())
  astTestMust(t,rw.Rewrite(after,out,proof))
  got,err:=f.m.RefGet(out);astTestMust(t,err)
  term,err:=f.m.GetArg(got,0);astTestMust(t,err)
  n,err:=f.m.GetNumArgs(term);astTestMust(t,err)
  t.Logf("pruned %t, scoped addition has %d arguments",prune,n)
  if !prune && n!=4 || prune && n!=2 {t.Fatalf("unexpected scoped arity %d",n)}
  astTestMust(t,rw.Close())
 }
}
