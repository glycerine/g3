from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'controls.py').read_text().replace('if mode=="transfer" || mode=="flat"{','if mode=="historybare" || mode=="historyflat"{').replace('if mode=="transfer"{zs.Assert(root)}','if mode=="historybare"{zs.Assert(root)}')
s=s.replace('var action *actionScopeStudy\\n','var originalProof func(smt.Z3Expr) bool\\n var originalSolver *smt.Z3Solver\\n var action *actionScopeStudy\\n')
s=s.replace('studyAssumes=append(studyAssumes,zCond)\\n','if originalSolver!=nil {originalSolver.Assert(zCond)}\\n studyAssumes=append(studyAssumes,zCond)\\n')
s=s.replace("'''proveGoal = nil","'''originalProof=proveGoal\n proveGoal = nil").replace('  defer original.Reset()','  originalSolver=original\n  defer original.Reset()').replace('  var end func()\n  check,end=z3solver.BeginVerificationChecks()\n  defer end()','  check=z3solver.Check')
key="put(p,s)"
s=s.replace(key,'''key='finalCheck := check'
s=replace(s,key,\'''if originalProof!=nil && originalSolver!=nil && originalProof(zCond) {
 overallResult=smt.Unsat; fc.Unsat();continue
 }
 finalCheck := check\''')
'''+key).replace("w/'controls'","w/'historytrial'")
(w/'history.py').write_text(s)
