"""Read disjoint first-push pass counters and check the verification transcript."""
import os,csv,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path('/tmp/g3-ivy-pgo');ex=Path('/home/jaten/ivy/ivy-lang-examples')
case,stem,cpu,rounds=sys.argv[1:];idx=(p/'prior-gaps.txt').read_text().splitlines().index(case)+1
ref=p/'survey'/str(idx)/'1/native'
codes={r['spec']:int(r['exit']) for f in (p/'survey').glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
with (w/('split-'+stem+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('round engine push stage inputs instructions'.split())
 modes=['release']
 for i in range(int(rounds)):
  for m in modes[i%len(modes):]+modes[:i%len(modes)]:
   exe=Path('build/.push-gap/pass-z3').resolve() if m=='native' else w/'splitmeter'
   r=subprocess.run(['taskset','-c',cpu,exe,ex/case],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),WALK=m),cwd=w,capture_output=True,timeout=120)
   other=[];rows=[];nativeRows=[]
   for line in r.stderr.splitlines(keepends=True):
    words=line.decode().split()
    if words[:1]==['IVY-PUSH-PASS']:
     _,push,stage,n,ins=words;rows.append((i,m,push,stage,n,ins))
    elif words[:1]==['IVY-PUSH-TOTAL']:
     _,push,ins=words;rows.append((i,m,push,'TOTAL','',ins))
    elif words[:1]==['IVY-PUSH-STAGE']:pass
    elif words[:1]==['PASS-COUNT']:
     _,stage,ins,empty,enabled,active,_=words;assert enabled==active;nativeRows.append((stage,ins))
    elif words[:1]==['STAGE-COUNT']:
     _,batch,goal,phase,ins,empty,enabled,active,_=words;assert enabled==active
     if phase=='first' or nativeRows:
      assert phase=='first',(phase,nativeRows)
      rows.extend((i,m,batch,stage,'',x) for stage,x in nativeRows);nativeRows.clear()
      rows.append((i,m,batch,'TOTAL','',ins))
    else:other.append(line)
   assert not nativeRows and (r.returncode,r.stdout,b''.join(other))==(codes[case],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(m,case,r.returncode,b''.join(other)[:500],r.stderr[-250:])
   assert any(x[3]=='pattern-inference' for x in rows),(m,rows[:8])
   out.writerows(rows);f.flush()
