from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3])
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
