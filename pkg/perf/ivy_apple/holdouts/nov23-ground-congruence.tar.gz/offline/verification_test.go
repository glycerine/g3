package api

import (
	"encoding/csv"
	"fmt"
	"github.com/glycerine/g3/pkg/api/internal/order"
	"github.com/glycerine/g3/pkg/solver"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestGroundProjectionExperiment(t *testing.T) {
	d := os.Getenv("OFFLINE_INPUTS")
	if d == "" {
		return
	}
	paths, e := filepath.Glob(d + "/*.smt2")
	if e != nil {
		t.Fatal(e)
	}
	shard, _ := strconv.Atoi(os.Getenv("OFFLINE_SHARD"))
	jobs, _ := strconv.Atoi(os.Getenv("OFFLINE_WORKERS"))
	f, e := os.Create(os.Getenv("OFFLINE_OUTPUT"))
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	w := csv.NewWriter(f)
	w.Write([]string{"file", "project", "reduce", "proved", "complete", "work", "elapsed_us", "used_bytes"})
	for i, path := range paths {
		if i%jobs != shard {
			continue
		}
		s, e := os.ReadFile(path)
		if e != nil {
			t.Fatal(e)
		}
		t.Run(filepath.Base(path), func(t *testing.T) {
			c, src := orderSolver(t, strings.TrimSuffix(string(s), "(check-sat)\n"))
			m, e := c.Manager()
			astTestMust(t, e)
			roots, e := solver.Assertions(src.solver)
			astTestMust(t, e)
			var mem, runtimeEnd runtime.MemStats
			runtime.ReadMemStats(&mem)
			start := time.Now()
			const steps = 160000
			bits, e := order.ProjectGroundEqualities(m, roots, steps)
			astTestMust(t, e)
			var proved, complete, unit bool
			var work uint32
			if bits != nil {
				work = bits.Work
				if os.Getenv("OFFLINE_UNIT") != "" {
					l := m.ResourceLimit()
					astTestMust(t, l.Push(steps))
					if l.IncOffset(work) {
						unit, complete = bits.Reduce(16, l)
					}
					l.Pop()
					proved = unit
				} else {
					p := orderProofState{source: src}
					proved, e = p.checkBooleanInput(m, bits, steps, roots)
					astTestMust(t, e)
					astTestMust(t, p.release())
					complete = true
				}
			}
			elapsed := time.Since(start).Microseconds()
			runtime.ReadMemStats(&runtimeEnd)
			w.Write([]string{filepath.Base(path), fmt.Sprint(bits != nil), fmt.Sprint(unit), fmt.Sprint(proved), fmt.Sprint(complete), fmt.Sprint(work), fmt.Sprint(elapsed), fmt.Sprint(runtimeEnd.TotalAlloc - mem.TotalAlloc)})
			w.Flush()
			if e = w.Error(); e != nil {
				t.Fatal(e)
			}
		})
	}
}
