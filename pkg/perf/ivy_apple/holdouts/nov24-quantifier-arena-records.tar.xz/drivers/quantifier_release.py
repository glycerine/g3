from study import *
import guarded_live as gl,macro_identity as mi,ground_release_controls as gc,verification_frontier as vf,setup_controls as sc,proof_release_trace as tr
d=w/'quantifier-release';d.mkdir(exist_ok=True)
def main():
 with ThreadPoolExecutor(2)as e:
  b,s=list(e.map(lambda v:build(d/v,shell=v=='shell'),['checker','shell']))
 prev=w/'macro-release/checker/goivy_check';native=w/'key-release/native/goivy_check'
 bs={'previous':prev,'g3':b,'native':native};gl.d=d;gc.d=d;sc.d=d
 js=[(21,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native'),(23,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native')]
 js += [(cpu,n,sp,iso,rc,3,ref)for cpu,n,sp,iso,rc,_,ref in mi.jobs()if n in ['tlb','hybrid_reliable_broadcast_cisa','rfn2','dramc_nb2','raftok','raft_no_assume_test','cf_live']]
 with ThreadPoolExecutor(len(js)+4)as e:
  fs=[e.submit(gl.measure_job,j,bs)for j in js]
  fs+=[e.submit(gc.corpus,b),e.submit(sc.shell,{'control':w/'macro-release/shell/g3','release':s}),e.submit(tr.trace,d),e.submit(run,[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',b,'--previous',prev,'--native',native,'--rounds','7','--max-attempts','35','--wait-seconds','4500','--min-idle','.95','--cpu','15','--spec',examples/'jea/hermes_rmw_o3.ivy','--reference',vf.reference('jea/hermes_rmw_o3.ivy'),'--perf',perf,'--output',d/'ordinary-quiet'],stdout=subprocess.DEVNULL)]
  for f in fs:f.result()
if __name__=='__main__':main()
