from study import *
import guarded_live as gl,macro_identity as mi,simplifier_rebuild as sh,verification_frontier as vf
d=w/'quantifier-blocks';d.mkdir(exist_ok=True)
u=pkg/'ast/ast_core_update.go';p=pkg/'ast/ast_core_payload.go';t=pkg/'ast/rewriter/th_rewriter.go';region=pkg/'arena/bytes_region.go';catalog=pkg/'util/params/util_gparams_catalog.go'
def edits(v):
 ed={}
 if v in ('copy','quant','all'):
  s=u.read_text();i=s.index('for i := uint32(0); i < bytes;');j=s.index('return out, nil',i)
  s=s[:i]+'''src,e:=m.allocator.View(p)
  if e==nil && uint64(len(src))<uint64(bytes){e=arena.ErrBounds}
  if e==nil{var dst []byte;dst,e=m.allocator.Borrow(out);if e==nil{copy(dst,src[:bytes])}}
  if e!=nil{m.allocator.Deallocate(bytes,out);return arena.SmallBytesRef{},e}
  '''+s[j:];ed[u]=s
 if v in ('symbols','quant','all'):
  s=p.read_text();i=s.index('for i := range v {',s.index('func (m *ASTManager) readSymbol('));j=s.index('return m.Symbols.DecodeSymbolWords',i)
  s=s[:i]+'''if e=m.allocator.ReadUint32LEs(p,offset,v[:]);e!=nil{return usymbol.Symbol{},e}
  '''+s[j:];i=s.index('words := s.SymbolWords()');j=s.index('return nil\n}',i)
  s=s[:i]+'''data,e:=m.allocator.Borrow(p);if e!=nil{return e};if uint64(off)+uint64(astSymbolBytes)>uint64(len(data)){return arena.ErrBounds};dst:=data[off:off+astSymbolBytes]
  for i,word:=range s.SymbolWords(){binary.LittleEndian.PutUint32(dst[4*i:],word)}
  binary.LittleEndian.PutUint32(dst[20:],0)
  '''+s[j:];ed[p]=s
 if v in ('patterns','quant','all'):
  s=t.read_text();a=s.index('uniquePatterns, e := theoryUniqueArguments(patterns)');b=s.index('\n\t}',a)
  s=s[:a]+'''if patterns.Count()<2 && noPatterns.Count()<2 { updated,err=m.UpdateQuantifierArguments(old,body,patterns,noPatterns) } else {'''+s[a:b]+'}'+s[b:];ed[t]=s
 if v in ('catalog','all'):
  s=region.read_text()+'''\nfunc(r *BytesRegion)WriteCString(ref BytesRegionRef,value string)error{d,e:=r.descriptor(ref);if e!=nil{return e};if uint64(len(value))>=uint64(d.length){return ErrBounds};p:=&r.pages[d.page];start:=uint64(p.header)+uint64(d.offset);out:=p.data[start:start+uint64(d.length)];n:=copy(out,value);out[n]=0;return nil}\n''';ed[region]=s
  s=catalog.read_text();a=s.index('for j := range row.text {');b=s.index('owner.descriptions[i] = ref',a)
  ed[catalog]=s[:a]+'''if e=owner.Region.WriteCString(ref,row.text);e!=nil{return fail(e)}
  '''+s[b:]
 return ed
def mk(v):
 if v=='control':return w/'macro-release/checker/goivy_check',w/'macro-release/shell/g3'
 od=d/v;o=overlay(od/'overlay',edits(v));return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def main():
 vs=['control','copy','symbols','patterns','quant','catalog','all']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 bb={v:b[0]for v,b in bs.items()};ss={v:b[1]for v,b in bs.items()};ss['native']=pkg.parent/'build/z3'
 gl.d=d;sh.d=d/'phases';sh.d.mkdir(exist_ok=True);js=mi.jobs()
 js=[(cpu,n,sp,iso,rc,3,ref)for cpu,n,sp,iso,rc,r,ref in js if n not in ['dramc_nb2']]
 # Include less frequently used physical cores to avoid serializing other panels.
 lanes=[27,29,31,32,34,36,37,40,41]
 fs=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));cs=[0,3,6,8,16,24]
 with ThreadPoolExecutor(len(js)+len(cs))as e:
  fut=[e.submit(gl.measure_job,(lanes[i],*j[1:]),bb)for i,j in enumerate(js)]+[e.submit(sh.lane,(c,fs[i::6],ss))for i,c in enumerate(cs)]
  for f in fut:f.result()
if __name__=='__main__':main()
