from study import *
import io
import quantifier_blocks as qb,guarded_live as gl,macro_identity as mi
sys.path.insert(0,str(pkg/'perf/ivy_apple'));from native_benchmark import build_native
d=w/'quantifier-layouts';d.mkdir(exist_ok=True)
def edit(mode):
 if mode=='old':
  return {qb.u:subprocess.check_output(['git','show','3ae6121be:pkg/ast/ast_core_update.go'],cwd=pkg,text=True)}
 if mode=='copy':return {}
 if mode in ('symbols','patterns'):return qb.edits(mode)
 if mode=='shared':return shared()
 if mode=='codec':return qb.edits('symbols')|qb.edits('patterns')
 width=int(mode.removeprefix('inline'))
 ed={};ad=pkg/'ast';p=ad/'ast_core_storage.go'
 ed[p]=once(p.read_text(),'type astQuantifierRecord struct {',f'type astQuantifierRecord struct {{\n inlineSorts [{width}]astNodeRef\n inlineNames [{width}]usymbol.Symbol\n inline bool')
 p=ad/'ast_core_factories.go';s=p.read_text()
 anchor='if v.sorts, e = m.newASTPayload(spec.Sorts); e == nil {'
 ed[p]=once(s,anchor,'''if v.count<=uint32(len(v.inlineSorts)) && !ASTSourceDebug && !astValidateHandles && m.TraceStream==nil && !m.Budget().InjectionArmed() && !m.NumeralService().RuntimeOwner().AllocationLimited() {
  v.inline=true
  for i,sort:=range spec.Sorts{v.inlineSorts[i]=astNodeRef{sort.slot,sort.generation}}
  for i,n:=range spec.Names{if _,e=m.Symbols.Hash(n);e!=nil{break};v.inlineNames[i]=n}
 } else '''+anchor)
 p=qb.u;s=p.read_text();a=s.index('v.sorts, e = m.copyQuantifierPayload');b=s.index('if e == nil {\n\t\tif flags',a);ed[p]=s[:a]+'if !old.inline{'+s[a:b]+'}\n'+s[b:]
 for name in ('ast_core_register','ast_core_query','ast_low_level_printer','ast_translation','ast_fpa_contains','ast_lt','ast_table_hash'):
  p=ad/(name+'.go');s=p.read_text()
  s=re.sub(r'm.readInternal\((\w+)\.sorts, ([^)]+)\)',r'm.trialQuantSort(\1, \2)',s)
  s=re.sub(r'm.readSymbol\((\w+)\.names, ([^)]+)\)',r'm.trialQuantName(\1, \2)',s)
  if name=='ast_table_hash':
   s=once(s,'a, e := m.hashPayload(v.sorts, v.count, init)','''var a uint32;var e error
   if v.inline {a=astHashArray(v.count,init,func(i uint32)uint32{return m.nodeAt(v.inlineSorts[i].slot).hash})}else{a,e=m.hashPayload(v.sorts,v.count,init)}''')
   s=once(s,'same, e := m.equalPayload(x.sorts, y.sorts, x.count)','''var same bool;var e error
   if x.inline && y.inline{same=x.inlineSorts==y.inlineSorts}else if x.inline || y.inline{same=true;for i:=uint32(0);i<x.count;i++{var a,b astNodeRef;a,e=m.trialQuantSort(x,i);if e==nil{b,e=m.trialQuantSort(y,i)};if e!=nil||a!=b{same=false;break}}}else{same,e=m.equalPayload(x.sorts,y.sorts,x.count)}''')
  ed[p]=s
 p=qb.p;ed[p]=p.read_text()+'''
 func(m *ASTManager)trialQuantSort(q *astQuantifierRecord,i uint32)(astNodeRef,error){if q.inline && i<q.count{return q.inlineSorts[i],nil};return m.readInternal(q.sorts,i)}
 func(m *ASTManager)trialQuantName(q *astQuantifierRecord,i uint32)(usymbol.Symbol,error){if q.inline && i<q.count{return m.Symbols.FromToken(q.inlineNames[i].Token())};return m.readSymbol(q.names,i)}
 '''
 return ed
def shared():
 ed={};ad=pkg/'ast';p=ad/'ast_core_storage.go';s=p.read_text();s=once(s,'type ASTManager struct {','type ASTManager struct {\n trialBinderOwners map[arena.SmallBytesRef]uint32');ed[p]=s
 p=qb.u;s=p.read_text();a=s.index('v.sorts, e = m.copyQuantifierPayload');b=s.index('if e == nil {\n\t\tif flags',a)
 s=s[:a]+'''if old.count>0 && !ASTSourceDebug && !astValidateHandles && m.TraceStream==nil && !m.Budget().InjectionArmed() && !m.NumeralService().RuntimeOwner().AllocationLimited() {
 if m.trialBinderOwners==nil{m.trialBinderOwners=make(map[arena.SmallBytesRef]uint32)}
 m.trialBinderOwners[old.names]++;v.sorts=old.sorts;v.names=old.names
 }else{'''+s[a:b]+'}\n'+s[b:];ed[p]=s
 p=ad/'ast_core_allocate.go';s=p.read_text();a=s.index('if e = m.freePayload(v.sorts');b=s.index('if e == nil {',a)
 s=s[:a]+'''if extra:=m.trialBinderOwners[v.names];extra!=0{if extra==1{delete(m.trialBinderOwners,v.names)}else{m.trialBinderOwners[v.names]=extra-1}}else{'''+s[a:b]+'}\n'+s[b:];ed[p]=s
 return ed
def mk(v,checker):
 out=d/v;out.mkdir(exist_ok=True)
 if v=='native':
  p=out/'native.test';build_native(pkg.parent/'build',p,pkg.parent/'src/test/perf/quantifier_body_update.cpp');return p,None
 o=overlay(out/'overlay',edit(v));b=out/'ast.test'
 with(w/'build.lock').open('a')as lk,(out/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','4','-c','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',b,'./ast'],cwd=pkg,stdout=log,stderr=log)
 c=build(out/'checker',o=o)if checker else None
 return b,c
def measure(bs):
 with (d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round cpu mode binders lifetime iterations ns_per_op bytes allocs'.split())
  for i in range(11):
   vs=list(bs);seq=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in(seq if i%2==0 else seq[::-1]):
    b=bs[v][0];cmd=['taskset','-c','19',b]
    if v!='native':cmd+=['-test.run','^TestCopiedQuantifierPayloadOwnershipAndRollback$','-test.bench','^BenchmarkASTQuantifierBodyUpdate$','-test.cpu=1','-test.benchtime=20000x','-test.benchmem']
    r=run(cmd,cwd=pkg/'ast',capture_output=True,text=True)
    if v=='native':rows=[[*row.values(),'','']for row in csv.DictReader(io.StringIO(r.stdout))]
    else:rows=re.findall(r'BenchmarkASTQuantifierBodyUpdate/(\d+)/(\w+)\s+(\d+)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout)
    assert len(rows)==10 and all(int(r[2])==20000 for r in rows),(v,r.stdout);z.writerows([[i+1,19,v,*r]for r in rows]);f.flush()
def main():
 vs=['old','copy','inline1','inline2','inline4','shared','codec','native']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(lambda v:mk(v,v not in ('old','native')),vs)))
 bb={v:c for v,(b,c)in bs.items()if c};js=[(cpu,*j[1:5],4,j[-1])for cpu,j in zip([27,29,31,32,34,36,37,40,41],(j for j in mi.jobs()if j[1]!='dramc_nb2'))];gl.d=d
 with ThreadPoolExecutor(len(js)+2)as e:
  fs=[e.submit(measure,bs)]+[e.submit(gl.measure_job,j,bb)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
