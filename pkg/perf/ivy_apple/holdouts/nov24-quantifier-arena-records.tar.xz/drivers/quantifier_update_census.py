from study import *
import quantifier_blocks as qb,macro_identity as mi
from collections import Counter
d=w/'quantifier-update-census';d.mkdir(exist_ok=True)
def mk():
 q=qb.u;s=q.read_text();s=once(s,'import (','import (\n"fmt"\n"os"')
 x='old := *m.quantifierAt(q.slot)';s=once(s,x,x+'''
   outcome:="same";defer func(){fmt.Fprintf(os.Stderr,"QUPDATE %s %d %d %d %d\\n",outcome,old.count,old.patternCount,old.noPatternCount,flags)}()''')
 x='original := r';s=once(s,x,'outcome="candidate";'+x)
 x='if e == nil && r == original {';s=once(s,x,'if e==nil{if r==original{outcome="fresh"}else{outcome="matched"}};'+x)
 h=pkg/'ast/ast_core_factories.go';t=h.read_text();x='original := r';idx=t.index('func (m *ASTManager) MkQuantifier(');pre,t=t[:idx],t[idx:];t=once(t,'r, e = m.registerNode(r)\n\tif e == nil && r == original {','r,e=m.registerNode(r);if e==nil{fmt.Fprintf(os.Stderr,"QMAKE %t %d %d %d\\n",r==original,len(spec.Sorts),len(spec.Patterns),len(spec.NoPatterns))}\n if e == nil && r == original {');t=pre+t;t=once(t,'import (','import (\n"os"'+('\n"fmt"'if '"fmt"'not in t else''))
 return build(d/'checker',o=overlay(d/'overlay',{q:s,h:t}))
def job(j,b):
 cpu,n,sp,iso,rc,_,ref=j;sd=d/n;sd.mkdir(exist_ok=True);counts=Counter()
 with (sd/'stdout').open('wb')as so:
  with subprocess.Popen(['taskset','-c',str(cpu),b,*(['isolate='+iso]if iso else[]),examples/sp],stdout=so,stderr=subprocess.PIPE,cwd=sd,env=dict(env,GOMAXPROCS='1'))as proc:
   other=[];assert proc.stderr is not None
   for line in proc.stderr:
    if line.startswith((b'QUPDATE ',b'QMAKE ')):counts[tuple(line.decode().split())]+=1
    else:other.append(line)
   assert proc.wait()==rc and b''.join(other)==(ref/'stderr').read_bytes(),(n,other[-2:])
 assert (sd/'stdout').read_bytes()==(ref/'stdout').read_bytes()
 with (sd/'updates.csv').open('w')as f:
  z=csv.writer(f);z.writerow('operation outcome binders patterns no_patterns flags calls'.split())
  for k,num in counts.items():z.writerow([*k,*(['']if len(k)==5 else[]),num])
 print(n,sum(counts.values()),flush=True)
if __name__=='__main__':
 b=mk();js=mi.jobs()+[(23,'apple','doc/examples/apple/ord_live.ivy','',0,1,w/'apple-original-pairs/14-native'),(21,'testing','jea/hermes_rmw_o3_testing.ivy','',0,1,w/'extended-phases/long/1/1/native')]
 with ThreadPoolExecutor(8)as e:list(e.map(lambda j:job(j,b),js))
