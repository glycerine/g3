from study import *
import guarded_live as gl,macro_identity as mi,ground_release_controls as gc,setup_controls as sc,proof_release_trace as tr,verification_frontier as vf,io
sys.path.insert(0,str(pkg/'perf/ivy_apple'));from native_benchmark import build_native
d=w/'symbol-codec-release';d.mkdir(exist_ok=True)
def packages():
 with(w/'build.lock').open('a')as f:
  fcntl.flock(f,fcntl.LOCK_SH)
  for name,tags,exp in [('packages','','.'),('diagnostics','g3checked,g3debug,g3trace','SymbolPayload|QuantifierBody|CopiedQuantifier|PatternInferenceGuards')]:
   with(d/(name+'.txt')).open('w')as log:run(['go','test','-p','4','-count=1',*(['-tags='+tags]if tags else[]),'-run',exp,'./ast','./ast/pattern','./smtcore','./ast/rewriter','./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
def micro():
 f=pkg/'ast/ast_core_payload.go';old=subprocess.check_output(['git','show','1aa5419d9:pkg/ast/ast_core_payload.go'],cwd=pkg,text=True)
 bs={}
 for v in ('old','codec','native'):
  if v=='native':
   b=d/'native.test';build_native(pkg.parent/'build',b,pkg.parent/'src/test/perf/quantifier_body_update.cpp')
  else:
   o=overlay(d/(v+'-overlay'),{f:old}if v=='old'else{});b=d/(v+'.test')
   with(w/'build.lock').open('a')as lk:
    fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','4','-pgo=off','-c','-overlay='+str(o),'-o',b,'./ast'],cwd=pkg)
  bs[v]=b
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round cpu mode operation binders lifetime iterations ns_per_op bytes allocs'.split())
  for i in range(15):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in vs:
    for op,go in [('update','BodyUpdate'),('construct','Construction')]:
     cmd=['taskset','-c','44',bs[v]]
     if v=='native':
      if op=='construct':cmd+=['construct']
     else:cmd+=['-test.run','^TestASTSymbolPayload','-test.bench','^BenchmarkASTQuantifier'+go+'$','-test.cpu=1','-test.benchtime=20000x','-test.benchmem']
     r=run(cmd,cwd=pkg/'ast',capture_output=True,text=True)
     if v=='native':rows=[[*row.values(),'','']for row in csv.DictReader(io.StringIO(r.stdout))]
     else:rows=re.findall(r'BenchmarkASTQuantifier\w+/(\d+)/(\w+)\s+(\d+)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout)
     assert len(rows)==10 and all(r[2]=='20000'for r in rows),(cmd,r.stdout[-800:]);z.writerows([[i+1,44,v,op,*r]for r in rows]);f.flush()
def main():
 with ThreadPoolExecutor(2)as e:b,s=list(e.map(lambda v:build(d/v,shell=v=='shell'),['checker','shell']))
 prev=w/'quantifier-release/checker/goivy_check';nat=w/'key-release/native/goivy_check';bs={'previous':prev,'g3':b,'native':nat}
 gl.d=d;gc.d=d;sc.d=d
 js=[(cpu,*j[1:5],4,j[-1])for cpu,j in zip([25,26,27,28,29,30,31,32,34],(j for j in mi.jobs()if j[1]!='ordinary'))]
 js.extend([(7,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native'),(5,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native')])
 with ThreadPoolExecutor(len(js)+6)as e:
  fs=[e.submit(gl.measure_job,j,bs)for j in js]+[e.submit(gc.corpus,b),e.submit(sc.shell,{'control':w/'quantifier-release/shell/g3','release':s}),e.submit(packages),e.submit(micro),e.submit(tr.trace,d),e.submit(run,[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',b,'--previous',prev,'--native',nat,'--rounds','7','--max-attempts','35','--wait-seconds','4500','--cpu','20','--min-idle','.95','--spec',examples/'jea/hermes_rmw_o3.ivy','--reference',vf.reference('jea/hermes_rmw_o3.ivy'),'--perf',perf,'--output',d/'ordinary-quiet'],stdout=subprocess.DEVNULL)]
  for f in fs:f.result()
if __name__=='__main__':main()
