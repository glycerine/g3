from study import *
import quantifier_blocks as qb, io
sys.path.insert(0,str(pkg/'perf/ivy_apple'));from native_benchmark import build_native
d=w/'quantifier-micro';d.mkdir(exist_ok=True)
def mk(v):
 path=d/(v+'.test')
 if v=='native':
  build_native(pkg.parent/'build',path,pkg.parent/'src/test/perf/quantifier_body_update.cpp');return path
 edits=qb.edits(v);o=overlay(d/v,edits);cmd=['go','test','-c','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',path,'./ast']
 with (w/'build.lock').open('a')as lk,(d/(v+'.log')).open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(cmd,cwd=pkg,stdout=log,stderr=log)
 return path
def main():
 vs=['control','copy','symbols','quant','native']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 with(d/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round cpu mode binders lifetime iterations ns_per_op bytes allocs'.split())
  for i in range(13):
   seq=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in (seq if i%2==0 else seq[::-1]):
    cmd=['taskset','-c','15',bs[v]]
    if v!='native':cmd+=['-test.run','^$','-test.bench','^BenchmarkASTQuantifierBodyUpdate$','-test.cpu=1','-test.benchtime=20000x','-test.benchmem']
    r=run(cmd,cwd=pkg/'ast',capture_output=True,text=True)
    if v=='native':rows=[[*row.values(),'','']for row in csv.DictReader(io.StringIO(r.stdout))]
    else:rows=re.findall(r'BenchmarkASTQuantifierBodyUpdate/(\d+)/(\w+)\s+(\d+)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout)
    assert len(rows)==6 and all(int(r[2])==20000 for r in rows),(v,r.stdout)
    z.writerows([[i+1,15,v,*r]for r in rows]);f.flush()
if __name__=='__main__':main()
