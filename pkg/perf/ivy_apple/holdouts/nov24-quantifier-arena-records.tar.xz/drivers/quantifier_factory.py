from study import *
import guarded_live as gl,macro_identity as mi,quantifier_blocks as qb,io
sys.path.insert(0,str(pkg/'perf/ivy_apple'));from native_benchmark import build_native
d=w/'quantifier-factory';d.mkdir(exist_ok=True)
factory=pkg/'ast/ast_core_factories.go';bench=pkg/'ast/ast_quantifier_update_benchmark_test.go';native=pkg.parent/'src/test/perf/quantifier_body_update.cpp'
def ed(v):
 e={}
 if v in ('codec','both','direct-codec'):e.update(qb.edits('symbols'))
 if v not in ('control','codec'):
  text=factory.read_text()
  if 'uhash "' not in text:text=once(text,'udiag "', 'uhash "github.com/glycerine/g3/pkg/util/hash"\nudiag "')
  x='v := m.quantifierAt(r.slot)\n\tv.body = body'
  gate='!ASTSourceDebug && !astValidateHandles && !udiag.TraceCompiled() && m.TraceStream == nil && !m.BudgetField.InjectionArmed() && !m.NumeralService().RuntimeOwner().AllocationLimited()'
  text=once(text,x,'''var prepared bool
   var hash uint32
   if '''+gate+''' {
    prepared=true
    seed:=uint32(19);if spec.Forall{seed=31}
    bh:=astHashArray(uint32(len(spec.Sorts)),seed,func(i uint32)uint32{return m.nodeAt(spec.Sorts[i].slot).hash})
    hash=uhash.Mix(bh,uint32(len(spec.Patterns)),m.nodeAt(body.slot).hash)
    if existing:=m.trialFindQuantifier(&spec,body,astTableHash(hash));existing.slot!=0{
     m.freeKindRecord(r.slot);m.returnNodeSlot(r.slot)
     return m.external(existing),nil
    }
   }
  '''+x)
  ix=text.index('func (m *ASTManager) MkQuantifier(');a,b=text[:ix],text[ix:];b=once(b,'r, e = m.registerNode(r)','if prepared {r,e=m.registerHashedNode(r,hash)}else{r,e=m.registerNode(r)}')
  sub='''
  func (m *ASTManager) trialFindQuantifier(spec *ASTQuantifierSpec,body astNodeRef,h uint64) astNodeRef{
   t:=&m.table;if t.size==0{return astNodeRef{}}
   tag:=astTableTag(h)
   for i,perturb:=h&t.mask,h;t.tags[i]!=astTagEmpty;i=(i*5+perturb+1)&t.mask{
    if t.tags[i]==tag{entry:=&t.entries[t.indices[i]]
     if entry.hash==h && m.nodeAt(entry.ref.slot).kind==ASTQuantifier && m.trialMatchQuantifier(m.quantifierAt(entry.ref.slot),spec,body){return entry.ref}
    }
    perturb>>=5
   }
   return astNodeRef{}
  }
  func(m *ASTManager)trialMatchQuantifier(q *astQuantifierRecord,s *ASTQuantifierSpec,body astNodeRef)bool{
    if q.body!=body || q.forall!=s.Forall || q.count!=uint32(len(s.Sorts)) || q.weight!=s.Weight || q.patternCount!=uint32(len(s.Patterns)) || q.noPatternCount!=uint32(len(s.NoPatterns)){return false}
    for i,n:=range s.Names{v,err:=m.readSymbol(q.names,uint32(i));if err!=nil || v!=n{return false}}
    return m.trialMatchQuantArgs(q.sorts,s.Sorts) && m.trialMatchQuantArgs(q.patterns,s.Patterns) && m.trialMatchQuantArgs(q.noPatterns,s.NoPatterns)
  }
  func(m *ASTManager)trialMatchQuantArgs(p arena.SmallBytesRef,hs []ASTHandle)bool{
    for i,h:=range hs{v,e:=m.readInternal(p,uint32(i));if e!=nil || v!=(astNodeRef{h.slot,h.generation}){return false}}
    return true
  }
  '''
  if v in ('direct','direct-codec'):sub=once(sub,'perturb>>=5','break')
  e[factory]=a+b+sub
 s=bench.read_text().replace('BenchmarkASTQuantifierBodyUpdate','BenchmarkASTQuantifierConstruction')
 s=once(s,'newBody, err := m.MkNot(body)','spec:=ASTQuantifierSpec{Forall:true,Sorts:sorts,Names:names}\nnewBody, err := m.MkNot(body)')
 s=once(s,'astTestPin(b, m, newBody)','astTestPin(b, m, newBody);spec.Body=newBody')
 s=s.replace('m.UpdateQuantifierBody(root, newBody)','m.MkQuantifier(spec)')
 e[bench]=s
 return e
def make(v):
 od=d/v;od.mkdir(exist_ok=True)
 if v=='native':
  s=native.read_text().replace('m.update_quantifier(original, next_body)','m.mk_forall(binders,sorts.data(),names.data(),next_body)')
  dest=od/'native.cpp';dest.write_text(s);b=od/'ast.test';build_native(pkg.parent/'build',b,dest);return b,None
 o=overlay(od/'overlay',ed(v));b=od/'ast.test'
 with (w/'build.lock').open('a')as f,(od/'ast.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-pgo=off','-c','-overlay='+str(o),'-o',b,'./ast'],cwd=pkg,stdout=log,stderr=log)
 c=w/'quantifier-release/checker/goivy_check'if v=='control'else build(od/'checker',o=o)
 return b,c
def micros(bs):
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round cpu mode binders lifetime iterations ns_per_op bytes allocs'.split())
  for i in range(13):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in (vs if i%2==0 else vs[::-1]):
    cmd=['taskset','-c','19',bs[v][0]]
    if v!='native':cmd+=['-test.run','^$','-test.bench','^BenchmarkASTQuantifierConstruction$','-test.benchtime=20000x','-test.cpu=1','-test.benchmem']
    res=run(cmd,cwd=pkg/'ast',capture_output=True,text=True)
    if v=='native':rows=[[*r.values(),'','']for r in csv.DictReader(io.StringIO(res.stdout))]
    else:rows=re.findall(r'BenchmarkASTQuantifierConstruction/(\d+)/(\w+)\s+(\d+)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',res.stdout)
    assert len(rows)==10 and all(x[2]=='20000'for x in rows),(v,res.stdout);z.writerows([[i+1,19,v,*r]for r in rows]);f.flush()
def main():
 vs=['control','probe','direct','codec','both','direct-codec','native']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(make,vs)))
 gl.d=d;bb={v:c for v,(b,c)in bs.items()if c};js=[(cpu,*j[1:5],3,j[-1])for cpu,j in zip([27,29,31,32,34,36,37,40,41],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 # Long representative workloads use the per-symbol and the full probe approaches only.
 longbs={k:bb[k]for k in ('control','probe','codec','both')}
 ext=[((17,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native'),longbs),((22,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native'),longbs)]
 with ThreadPoolExecutor(len(js)+3)as e:
  fs=[e.submit(micros,bs)]+[e.submit(gl.measure_job,j,bb)for j in js]+[e.submit(gl.measure_job,j,b)for j,b in ext]
  for f in fs:f.result()
if __name__=='__main__':main()
