from study import *
import io, shutil
sys.path.insert(0,str(pkg/'perf/ivy_apple'));from relevance_counts import make_value
d=w/'row-native';d.mkdir(exist_ok=True);bd=pkg.parent/'build';q=w/'asserted_batch_replacement.cpp';src=pkg.parent/'src'
def native():
 conf=(bd/'config.mk').read_text();mk=(bd/'Makefile').read_text();inc=re.search(r'\$\((includes_\d+)\).*\.\./src/smt/asserted_formulas\.cpp$',mk,re.M)
 obj=d/'fixture.o';exe=d/'native'
 run([*make_value(conf,'CXX'),*make_value(conf,'CXXFLAGS'),*make_value(mk,inc[1]),'-fno-access-control','-o',obj,q],cwd=bd)
 run(['g++',obj,bd/'libz3.a','-fopenmp','-lpthread','-ldl','-lrt','-o',exe]);return exe
def main():
 bins={v:w/'asserted-row-release'/(v+'-time')/'bench.test' for v in ('previous','g3')};bins['native']=native();sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import rotating_verification as rv
 with(d/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine position width iterations ns sibling_idle'.split())
  for i in range(21):
   vs=list(bins);vs=vs[i%3:]+vs[:i%3]
   for v in vs:
    cmd=['taskset','-c','44',bins[v]]
    if v!='native':cmd+=['-test.run=^$','-test.bench=^BenchmarkSMTAssertedBatchReplacement$','-test.benchmem','-test.benchtime=3000x','-test.cpu=1']
    before=rv.ticks([20]);r=run(cmd,cwd=pkg/'smtcore',capture_output=True,text=True);after=rv.ticks([20])
    a=[(r['position'],r['width'],r['iterations'],r['ns'])for r in csv.DictReader(io.StringIO(r.stdout))]if v=='native' else re.findall(r'BenchmarkSMTAssertedBatchReplacement/(\w+)/(\d+)\s+(3000)\s+([.\d]+) ns/op',r.stdout)
    assert len(a)==9 and all(t[2]=='3000'for t in a);z.writerows([[i+1,v,*t,rv.idle(before,after,20)]for t in a]);f.flush()
if __name__=='__main__':main()
