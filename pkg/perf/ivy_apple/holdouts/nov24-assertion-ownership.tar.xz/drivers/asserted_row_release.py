from study import *
import guarded_live as gl,macro_identity as mi,ground_release_controls as gc,substitution_release as sr,proof_release_trace as tr,theory_traversal_steps as th
from types import SimpleNamespace
d=w/'asserted-row-release';d.mkdir(exist_ok=True);old=w/'substitution-release/checker/goivy_check';old_shell=w/'substitution-release/shell/g3';native=w/'frontend-owned-production/after-native/goivy_check'
q=pkg/'smtcore/smt_asserted_macros.go';bt=q.with_name('smt_asserted_batch_benchmark_test.go')
probe='''package smtcore
import("syscall";"runtime";"unsafe";"fmt";"os";"testing")
func rowBenchStart(b *testing.B) func(){runtime.LockOSThread();var attr struct{Type,Size uint32;Config,Period,SampleType,ReadFormat,Flags uint64;Pad [16]byte};attr.Size=uint32(unsafe.Sizeof(attr));attr.Config=1;attr.Flags=1<<5|1<<6;attr.ReadFormat=3
 fd,_,e:=syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN,uintptr(unsafe.Pointer(&attr)),0,^uintptr(0),^uintptr(0),0,0);if e!=0{panic(e)}
 read:=func()uint64{var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,fd,uintptr(unsafe.Pointer(&v[0])),24);if e!=0||n!=24||v[1]!=v[2]{panic("counter")};return v[0]};a:=read();empty:=read()-a;begin:=read()
 return func(){end:=read();syscall.Close(int(fd));runtime.UnlockOSThread();fmt.Fprintln(os.Stderr,"ROWBENCH",b.Name(),b.N,end-begin,empty)}}
'''
def micro():
 bs={};file=bt.read_text()
 for en in ['previous','g3']:
  ed={q:subprocess.check_output(['git','show','4e073e78e:pkg/smtcore/smt_asserted_macros.go'],cwd=pkg,text=True) if en=='previous'else q.read_text()}
  for mode in ['time','counter']:
   if mode=='counter':ed[bt]=once(once(file,'b.ResetTimer()','b.ResetTimer()\nend:=rowBenchStart(b)'),'b.StopTimer()','end();b.StopTimer()');ed[q.with_name('row_counter_benchmark_test.go')]=probe
   od=d/(en+'-'+mode);o=overlay(od/'overlay',ed);b=od/'bench.test';bs[en,mode]=b
   with(w/'build.lock').open('a')as lk:
    fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-p','4','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg)
 sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import rotating_verification as rv
 for mode in ['counter','time']:
  with(d/(mode+'.csv')).open('w')as f:
   z=csv.writer(f);z.writerow('round engine position width iterations ns bytes allocs instructions empty sibling_idle'.split())
   for i in range(13):
    for en in ['previous','g3'][::1 if i%2==0 else -1]:
     c=44;before=rv.ticks([c-24]);r=run(['taskset','-c',str(c),bs[en,mode],'-test.run=^$','-test.bench=^BenchmarkSMTAssertedBatchReplacement$','-test.benchmem','-test.benchtime=3000x','-test.cpu=1'],cwd=pkg/'smtcore',capture_output=True,text=True);after=rv.ticks([c-24])
     vals=re.findall(r'BenchmarkSMTAssertedBatchReplacement/(\w+)/(\d+)\s+(3000)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout)
     m={(n,j):[a,b] for n,j,a,b in re.findall(r'ROWBENCH BenchmarkSMTAssertedBatchReplacement/(\w+)/(\d+) 3000 (\d+) (\d+)',r.stderr+r.stdout)}
     assert len(vals)==9 and (mode=='time'or len(m)==9),(r.stdout[-600:],r.stderr[-600:]);z.writerows([[i+1,en,*v,*m.get(tuple(v[:2]),['','']),rv.idle(before,after,c-24)]for v in vals]);f.flush()
def full(j,b):
 c,n,sp,iso,rc,nruns,ref=j;gl.measure_job(j,{'g3':b,'previous':old,'native':native})
def checks():
 for i,args in enumerate([['-count=1','./smtcore','./ast/macros','./cmd/g3'],['-tags=g3checked,g3debug','-count=1','-run','SMTAsserted|FormulaBatch','./smtcore','./ast/macros']]):
  with(w/'build.lock').open('a')as lk,(d/f'focused-{i}.log').open('w')as f:fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','4',*args],cwd=pkg,stdout=f,stderr=f)
def main():
 gl.d=d;gc.d=d;th.d=d;sr.d=d;sr.old_shell=old_shell
 with ThreadPoolExecutor(2)as e:
  b,s=list(e.map(lambda v:build(d/v,shell=v=='shell'),['checker','shell']))
 js=[(c,*j[1:5],5,j[-1])for c,j in zip([5,7,9,11,13,15,17,19,21,23],mi.jobs())]
 js.extend([(35,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native'),(39,'testing','jea/hermes_rmw_o3_testing.ivy','',0,2,w/'extended-phases/long/1/1/native')])
 with ThreadPoolExecutor(19)as e:
  fs=[e.submit(full,j,b)for j in js]+[e.submit(gc.corpus,b),e.submit(sr.shell,s),e.submit(tr.trace,d),e.submit(micro),e.submit(checks)]+[e.submit(th.replay,(c,n,{'previous':old_shell,'g3':s,'native':pkg.parent/'build/z3'}))for c,n in [(30,'ticket-127'),(32,'aux-012725'),(34,'toy-consensus-18')]]
  for f in fs:f.result()
if __name__=='__main__':main()
