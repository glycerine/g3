from study import *
import guarded_live as gl,macro_identity as mi,ground_release_controls as gc,theory_traversal_steps as th
d=w/'asserted-row-reuse';d.mkdir(exist_ok=True)
q=pkg/'smtcore/smt_asserted_macros.go';test=q.with_name('smt_asserted_batch_benchmark_test.go')
template='''package smtcore
import ("testing";"fmt";"github.com/glycerine/g3/pkg/ast/macros")
// BenchmarkSMTAssertedBatchReplacement measures publication after a preprocessing
// pass. Both batches own their rows throughout. Each iteration checks the same
// ordered prefix but can replace the first or last pending assertion.
func BenchmarkSMTAssertedBatchReplacement(b *testing.B){
 for _,width:=range []int{8,128,1024}{for _,change:=range []string{"Identical","Last","First"}{b.Run(fmt.Sprintf("%s/%d",change,width),func(b *testing.B){
  m:=astTestManager(b); sort,e:=m.MkBoolSort();astTestMust(b,e)
  k:=&SMTKernel{manager:m};var batches [2]*macros.FormulaBatch
  for v:=range batches{
   batches[v],e=macros.NewFormulaBatch(m);astTestMust(b,e)
   for j:=0;j<width;j++{
    index:=j;if v==1 && (change=="Last" && j==width-1 || change=="First" && j==0){index=width}
    h,e:=m.MkVar(uint32(index),sort);astTestMust(b,e);astTestMust(b,batches[v].Insert(macros.Formula{Expression:h}))
   }
  }
  b.Cleanup(func(){for _,a:=range k.assertions{astTestMust(b,m.DecRef(a.Formula))};for _,batch:=range batches{astTestMust(b,batch.Close())}})
  astTestMust(b,k.swapPendingFormulaBatch(batches[0]))
  b.ReportAllocs();b.ResetTimer()
  for i:=0;i<b.N;i++{if e:=k.swapPendingFormulaBatch(batches[(i+1)&1]);e!=nil{b.Fatal(e)}}
  b.StopTimer()
  if len(k.assertions)!=width{b.Fatal(len(k.assertions))}
  for j,a:=range k.assertions{row,e:=batches[b.N&1].At(j);astTestMust(b,e);if a.Formula!=row.Expression||a.Proof!=row.Proof{b.Fatal(j)}}
 })}}
}
'''
def edit(v):
 es={test:template}
 if v=='control':return es
 s=q.read_text();s=once(s,'"slices"','"slices"\n"github.com/glycerine/g3/pkg/util/diagnostic"');a=s.index('// Save just the displaced');b=s.index('\n\tdefer func()',a);c=s.index('\n\treturn nil\n}',b)
 prefix='''head:=k.assertedHead
 count:=batch.Len()
 first:=0
 if !ast.ASTValidateHandles && !ast.ASTSourceDebug && !diagnostic.TraceCompiled() && count!=0 && head<len(k.assertions) && k.manager.TraceStream==nil && !k.manager.Budget().InjectionArmed(){
  disabled,err:=k.manager.ProofsDisabled()
  if err!=nil{return err}
  if disabled {
   for first<count && head<len(k.assertions) {
    row,err:=batch.At(first);if err!=nil{return err}
    old:=k.assertions[head]
    if row.Expression!=old.Formula || row.Proof!=old.Proof{break}
    head++;first++
   }
  }
 }
 if first==count && head==len(k.assertions){return nil}
 '''
 if v=='equal':prefix+='first=0;head=k.assertedHead\n'
 if v=='audit':prefix=prefix.replace('if first==count', 'fmt.Fprintf(os.Stderr,"ROWPREFIX %d %d %d\\n",len(k.assertions)-k.assertedHead,count,first)\n if first==count');s=once(s,'"io"','"io"\n"os"');a=s.index('// Save just the displaced');b=s.index('\n\tdefer func()',a);c=s.index('\n\treturn nil\n}',b)
 s=s[:a]+prefix+s[a:b].replace('count := batch.Len()','remaining:=count-first').replace('k.assertedHead','head').replace(', count)',', remaining)').replace('+ count','+ remaining').replace('+count','+remaining')+s[b:c].replace('k.assertedHead','head').replace('for i := 0;', 'for i := first;')+s[c:]
 es[q]=s;return es
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edit(v));b=od/'smt.test'
 with(w/'build.lock').open('a')as lk,(od/'focused.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-p','5','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=log,stderr=log);run([b,'-test.run','SMTAsserted|Assertion.*Batch|Macro|SMTKernelAsserted','-test.count=1'],cwd=pkg/'smtcore',stdout=log,stderr=log)
 return b,build(od/'checker',o=o)
def micro(bs):
 with(d/'bench.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine position width iterations ns bytes allocs'.split())
  for i in range(13):
   vs=list(bs);vs=vs[i%3:]+vs[:i%3]
   for v in vs:
    r=run(['taskset','-c','22',bs[v][0],'-test.run=^$','-test.bench=^BenchmarkSMTAssertedBatchReplacement$','-test.benchmem','-test.benchtime=1000x','-test.cpu=1'],cwd=pkg/'smtcore',capture_output=True,text=True);res=re.findall(r'BenchmarkSMTAssertedBatchReplacement/(\w+)/(\d+)\s+(1000)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(res)==9,r.stdout
    z.writerows([[i+1,v,*r]for r in res]);f.flush()
def audit(j,bin):
 c,n,sp,iso,rc,_,ref=j;od=d/'audit'/n;od.mkdir(exist_ok=True);r=subprocess.run(['taskset','-c',str(c),bin,*(['isolate='+iso]if iso else []),examples/sp],cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1'));ls=r.stderr.splitlines(keepends=True);obs=[x[10:] for x in ls if x.startswith(b'ROWPREFIX ')];assert r.returncode==rc and b''.join(x for x in ls if not x.startswith(b'ROWPREFIX '))==(ref/'stderr').read_bytes()and r.stdout==(ref/'stdout').read_bytes()
 with(od/'coverage.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['old','new','prefix']);z.writerows([x.decode().split()for x in obs])
def main():
 vs=['control','equal','prefix'];js=[(c,*j[1:5],3,j[-1])for c,j in zip([14,15,18,20,24,30,32,33,34,37],mi.jobs())]
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 gl.d=d;bb={v:b[1]for v,b in bs.items()}
 oa=overlay(d/'audit/overlay',edit('audit'));ab=build(d/'audit/checker',o=oa)
 with ThreadPoolExecutor(11)as ex:
  fs=[ex.submit(micro,bs)]+[ex.submit(gl.measure_job,j,bb)for j in js]
  for j in js:audit(j,ab)
  for f in fs:f.result()
if __name__=='__main__':main()
