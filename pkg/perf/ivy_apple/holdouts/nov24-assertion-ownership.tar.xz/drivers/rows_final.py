from study import *
import asserted_row_release as rr,guarded_live as gl,macro_identity as mi,ground_release_controls as gc,substitution_release as sr,binder_exits as binder,theory_traversal_steps as th,row_native as nr
d=w/'rows-final';d.mkdir(exist_ok=True);rr.d=d
def verify_info(b):
 info=run(['go','version','-m',b],capture_output=True,text=True).stdout;assert '=>\t/home/jaten/g3/pkg\t(devel)'in info;(b.parent/'build-info.txt').write_text(info)
def trace():
 dest=d/'trace';sd=dest/'after';sd.mkdir(parents=True,exist_ok=True);b=sd/'goivy_check'
 with(w/'build.lock').open('a')as lk,(sd/'build.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-mod=readonly','-modfile='+str(w/'local-checkout.mod'),'-o',b,'./cmd/goivy_check'],cwd=ivy,stdout=f,stderr=f)
 verify_info(b)
 if not(sd/'abc').exists():(sd/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
 binder.root=dest;binder.trace({'before-trace':w/'conditional-evidence/trace/control/goivy_check','after-trace':b})
def native_micro():
 rr.micro()
 import inspect
 orig=inspect.getsource(nr.main);src=orig.replace("w/'asserted-row-release'","w/'rows-final'").replace("bins['native']=native()","bins['native']=w/'row-native/native'").replace("with(d/'runs.csv')","with(d/'native-micro.csv')")
 ns=dict(nr.__dict__);ns['d']=d;exec(src,ns);ns['main']()
def main():
 gl.d=d;gc.d=d;sr.d=d;sr.old_shell=rr.old_shell;th.d=d
 with ThreadPoolExecutor(2)as e:b,s=list(e.map(lambda v:build(d/v,shell=v=='shell'),['checker','shell']))
 verify_info(b)
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([7,9,11,13,15,17,19,21,23,25],mi.jobs())]
 js.extend([(46,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native'),(43,'testing','jea/hermes_rmw_o3_testing.ivy','',0,2,w/'extended-phases/long/1/1/native')])
 with ThreadPoolExecutor(20)as e:
  fs=[e.submit(rr.full,j,b)for j in js]+[e.submit(gc.corpus,b),e.submit(sr.shell,s),e.submit(trace),e.submit(native_micro),e.submit(rr.checks)]+[e.submit(th.replay,(c,n,{'previous':rr.old_shell,'g3':s,'native':pkg.parent/'build/z3'}))for c,n in [(28,'ticket-127'),(30,'aux-012725'),(32,'toy-consensus-18')]]
  for f in fs:f.result()
if __name__=='__main__':main()
