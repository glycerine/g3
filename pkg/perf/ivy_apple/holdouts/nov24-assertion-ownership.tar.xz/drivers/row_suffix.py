from study import *
import macro_identity as mi,guarded_live as gl,asserted_row_release as rr
from collections import defaultdict
d=w/'row-suffix';d.mkdir(exist_ok=True);q=rr.q;bt=rr.bt;batch=pkg/'ast/macros/macro_finder.go'
method='''
// MatchesJustification reports whether the row still owns this expression
// and proof. Dependencies are separate from the solver's justified rows.
func (b *FormulaBatch) MatchesJustification(i int, expression, proof ast.ASTHandle) bool {
 if b==nil || b.self!=b || b.closed || uint(i)>=uint(len(b.rows)){return false}
 row:=&b.rows[i];return row.Expression==expression && row.Proof==proof
}
'''
def edit(v):
 if v=='control':return {}
 s=q.read_text();es={}
 if 'matches'in v:
  a=s.index('row, err := batch.At(first)');b=s.index('break\n',s.index('if row.Expression',a));s=s[:a]+'if !batch.MatchesJustification(first,old.Formula,old.Proof){\n'+s[b:];es[batch]=batch.read_text()+method
 if 'suffix'in v:
  s=once(s,'first := 0','first,suffix:=0,0');x='first++\n\t\t\t}'
  comp='if !batch.MatchesJustification(i,old.Formula,old.Proof){break}' if 'matches'in v else 'row,err:=batch.At(i);if err!=nil{return err};if old.Formula!=row.Expression || old.Proof!=row.Proof{break}'
  s=once(s,x,x+'''
  if count==len(k.assertions)-k.assertedHead && first<count {
   for i:=count-1;i>first;i--{old:=k.assertions[k.assertedHead+i];'''+comp+''';suffix++}
  }''')
  s=once(s,'remaining := count - first','remaining := count-first-suffix');s=once(s,'end := head + remaining','end:=k.assertedHead+count');s=once(s,'original[head:])','original[head:len(original)-suffix])');s=once(s,'// m_formulas.shrink','k.assertions=original[:end]\n// m_formulas.shrink');s=once(s,'for i := first; i < count;','for i := first; i < count-suffix;')
 es[q]=s;return es
def mk(v):
 od=d/v;o=overlay(od/'overlay',edit(v));b=od/'smt.test'
 with(w/'build.lock').open('a')as lk,(od/'focused.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-p','4','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=f,stderr=f)
  run([b,'-test.run','SMTAsserted|SMTPendingAssertionSwapRollback'],cwd=pkg/'smtcore',stdout=f,stderr=f)
 return b,build(od/'checker',o=o)
def micro(bs):
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine position width iterations ns bytes allocs'.split())
  for i in range(15):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in vs:
    r=run(['taskset','-c','45',bs[v][0],'-test.run=^$','-test.bench=^BenchmarkSMTAssertedBatchReplacement$','-test.benchtime=3000x','-test.cpu=1','-test.benchmem'],cwd=pkg/'smtcore',capture_output=True,text=True)
    vals=re.findall(r'BenchmarkSMTAssertedBatchReplacement/(\w+)/(\d+)\s+(3000)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(vals)==9;z.writerows([[i+1,v,*x]for x in vals]);f.flush()
def main():
 vs=['control','matches','suffix','matches-suffix']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;bb={v:b[1]for v,b in bs.items()};js=[(c,*j[1:5],4,j[-1])for c,j in zip([0,2,4,6,8,10,12,14,16],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(10)as e:
  a=e.submit(micro,bs);list(e.map(lambda j:gl.measure_job(j,bb),js));a.result()
if __name__=='__main__':main()
