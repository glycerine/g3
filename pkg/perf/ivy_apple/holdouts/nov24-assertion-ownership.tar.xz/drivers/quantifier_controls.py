from study import *
from archive_plans_macros import rows
from collections import Counter
def normalize(out):
 x=re.sub(rb'\s*:(?:max-memory|memory|num-allocs|time)\s+[0-9]+(?:\.[0-9]+)?',b'',out)
 return re.sub(rb'(fps:\s*)[0-9]+(?:\.[0-9]+)?',rb'\g<1>measured',x)
def main(name):
 d=w/name;bs=[w/'macro-release/shell/g3' if name=='quantifier-release'else w/'quantifier-release/shell/g3',d/'shell/g3']
 dat=(w/'branch-controls/inputs/repo-datalog_soft_timeout.smt2').read_bytes()
 with (d/'shell-comparison.csv').open('w')as f:
  z=csv.writer(f);z.writerow('input differing_streams matched_after_volatile_fields'.split())
  allrows=[r for p in d.glob('shell-controls/*/results.csv')for r in rows(p)]
  assert len(allrows)==1799 and all(r['result_match']=='1'for r in allrows)and sum(r['timeout']=='1'for r in allrows)==1
  for p in sorted(d.glob('shell-controls/*/*')):
   if not p.is_dir():continue
   changed=[]
   for stream in ('out','err'):
    x,y=[(p/(n+'.'+stream)).read_bytes()for n in ('control','release')]
    if x!=y:changed.append(stream)
    assert normalize(x)==normalize(y),(name,p,stream)
   z.writerow([p.name,'|'.join(changed),1])
 with(d/'datalog.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['build','exit','response','stderr'])
  for n,b in zip(['before','after'],bs):
   r=run([b,'smt.timeout=50','-in','-smt2'],input=dat,capture_output=True,timeout=25);o='|'.join(r.stdout.decode().splitlines());assert o=='unknown|timeout'and not r.stderr,r;z.writerow([n,0,o,''])
if __name__=='__main__':
 for nm in ['quantifier-release','symbol-codec-release']:main(nm)
