from study import *
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import rotating_verification as rv
d=w/'quiet-rows';d.mkdir(exist_ok=True)
cpus=list(range(48));a=rv.ticks(cpus);time.sleep(3);b=rv.ticks(cpus)
cs=sorted((i for i in range(24)if i not in (0,4,6,10,11,14,15,16,19,20,21,22)),key=lambda i:min(rv.idle(a,b,i),rv.idle(a,b,i+24)),reverse=True)[:2]
def lane(t):
 c,(n,sp,ref)=t;print('start',n,c,flush=True)
 args=[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',w/'rows-final/checker/goivy_check','--native',w/'frontend-owned-production/after-native/goivy_check','--cpu',str(c),'--rounds','2','--max-attempts','3','--wait-seconds','75','--min-idle','.95','--spec',examples/sp,'--reference',ref,'--output',d/n,'--perf',perf];r=subprocess.run(args,env=env,capture_output=True,text=True);(d/(n+'.log')).write_text(r.stdout+r.stderr);print('finished',n,r.returncode,flush=True)
with ThreadPoolExecutor(2)as ex:list(ex.map(lane,zip(cs,[('apple','doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native'),('testing','jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native')])))
