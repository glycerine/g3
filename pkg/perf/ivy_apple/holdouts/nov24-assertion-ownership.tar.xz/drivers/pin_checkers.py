from study import *
import flat_unary as flat,row_suffix as suff,numeral_read_cache as nums,macro_identity as mi,guarded_live as gl,pattern_pairs as pair
from collections import defaultdict
def main():
 s=sys.argv[1];mod={'flat-unary':flat,'row-suffix':suff,'numeral-read-cache':nums}[s];out=w/('pinned-'+s);out.mkdir(exist_ok=True);mod.d=out
 modes={'flat-unary':['control','simple','cached','audit'],'row-suffix':['control','matches','suffix','matches-suffix'],'numeral-read-cache':['control','negative','records','positive-4','mixed-8','mixed-32','mixed-128']}[s]
 def mk(v):
  od=out/v;o=overlay(od/'overlay',mod.ed(v) if mod==flat else mod.edit(v));b=build(od/'checker',o=o);info=run(['go','version','-m',b],text=True,capture_output=True).stdout;(od/'build-info.txt').write_text(info);assert '=>\t/home/jaten/g3/pkg\t(devel)'in info
  return b
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(modes,ex.map(mk,modes)))
 gl.d=out;pair.d=out
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([0,2,4,6,8,10,12,14,16],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 if mod==nums:js=[j for j in js if j[1]in ('ordinary','tlb','rfn2','toy-consensus')]
 a=bs.pop('audit',None)
 with ThreadPoolExecutor(11)as ex:
  fs=[ex.submit(gl.measure_job,j,bs)for j in js]
  if a:
   for j in mi.jobs():
    pair.audit(j,a)
    p=out/'audit'/j[1]/'coverage.csv';assert p.stat().st_size>30
  for f in fs:f.result()
if __name__=='__main__':main()
