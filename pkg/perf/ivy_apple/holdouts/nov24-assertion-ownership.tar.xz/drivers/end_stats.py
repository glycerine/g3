from study import *
from archive_plans_macros import rows
from collections import defaultdict,Counter
def stage():
 for dr in (w/'first-push-frontier').iterdir():
  p=dr/'1-g3/totals.csv'
  if not p.exists() or not p.stat().st_size:continue
  a=defaultdict(Counter)
  for r in rows(p):
   if r['category']in ['leaf','inclusive','stage']:a[r['measured_pass'],r['category']][r['name'].replace('github.com/glycerine/g3/pkg/','')]+=int(r['samples'])
  print(dr.name)
  for key,cts in a.items():
   if key[1]=='leaf' and sum(cts.values())>100:print(key[0],sum(cts.values()),cts.most_common(7))
def warm(dr):
 for p in sorted((w/dr).glob('warm-*/runs.csv')):
  rs=rows(p);g=defaultdict(dict);s=defaultdict(list)
  for r in rs:g[r['variant'],r['round']][int(r['iterations'])]=int(r['instructions'])
  for (k,r),v in g.items():
   if len(v)==2:s[k].append((v[max(v)]-v[min(v)])/(max(v)-min(v))/1e6)
  print(p.parent.name,[(k,round(median(v),2))for k,v in s.items()])
def lanes(dr):
 for p in sorted((w/dr).glob('*/runs.csv')):
  a=defaultdict(list)
  for r in rows(p):
   if r.get('instructions:u'):a[r['engine']].append(int(r['instructions:u'])/1e9)
  if a:print(p.parent.name,[(k,round(median(v),3))for k,v in a.items()])
if __name__=='__main__':
 if len(sys.argv)<2:stage()
 else:
  for dr in sys.argv[1:]:print(dr);warm(dr);lanes(dr)
