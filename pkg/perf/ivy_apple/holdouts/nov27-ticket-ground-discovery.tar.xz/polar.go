package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
)

type node struct {
	Op              string
	Sort, Sym, Slot int
	A, B, D         []int
}
type query struct {
	Nodes        []node
	Roots, Sorts []int
	Domains      [][]int
	Aliases      [][2]int
}
type binding struct {
	node   int
	values [4]int
}
type application struct {
	symbol int
	args   [3]int
}
type appRow struct {
	app     application
	result  int
	boolean bool
}
type equality struct{ a, b int }
type compiler struct {
	gates                    map[int][]int
	emitted                  map[int]bool
	q                        query
	width                    int
	terms                    [][]int
	assignment, alias, fixed []int
	cache                    map[binding]int
	applications             map[application]int
	groups                   map[int][]appRow
	symbols                  []int
	equalities               map[equality]int
	clauses                  [][]int
	next                     int
}

func (c *compiler) variable() int { c.next++; return c.next }
func (c *compiler) find(i int) int {
	for c.alias[i] != 0 {
		i = c.alias[i]
	}
	return i
}
func (c *compiler) eq(a, b int) int {
	if a == b {
		return 1
	}
	if a > b {
		a, b = b, a
	}
	key := equality{a, b}
	if v := c.equalities[key]; v != 0 {
		return v
	}
	v := c.variable()
	c.equalities[key] = v
	return v
}

// Use the signed literals of the conjuncts. Negating this construction gives OR.
func (c *compiler) conjunction(args []int) int {
	kept := args[:0]
	for _, v := range args {
		if v == -1 {
			return -1
		}
		if v != 1 {
			kept = append(kept, v)
		}
	}
	switch len(kept) {
	case 0:
		return 1
	case 1:
		return kept[0]
	}
	v := c.variable()
	c.gates[v] = kept

	return v
}
func (c *compiler) enumerate(n node, pos int, rows *[]int) {
	if pos == len(n.B) {
		*rows = append(*rows, c.eval(n.A[0]))
		return
	}
	slot := n.B[pos]
	st := c.q.Sorts[slot]
	for _, v := range c.terms[st] {
		if pos >= c.width {
			count := 1
			for j, prior := range n.B[:pos] {
				if c.q.Sorts[prior] != st || c.assignment[prior] == v {
					continue
				}
				first := true
				for _, earlier := range n.B[:j] {
					if c.q.Sorts[earlier] == st && c.assignment[earlier] == c.assignment[prior] {
						first = false
						break
					}
				}
				if first {
					count++
				}
			}
			if count > c.width {
				continue
			}
		}
		c.assignment[slot] = v
		c.enumerate(n, pos+1, rows)
	}
}
func (c *compiler) eval(i int) int {
	i = c.find(i)
	if c.fixed[i] != 0 {
		return c.fixed[i]
	}
	n := c.q.Nodes[i]
	if n.Op == "v" {
		return c.assignment[n.Slot]
	}
	var k binding
	k.node = i
	if len(n.D) > 0 {
		for j, slot := range n.D {
			k.values[j] = c.assignment[slot]
		}
		if v := c.cache[k]; v != 0 {
			return v
		}
	}
	var v int
	switch n.Op {
	case "true":
		v = 1
	case "false":
		v = -1
	case "not":
		v = -c.eval(n.A[0])
	case "and", "or":
		xs := make([]int, len(n.A))
		for j, a := range n.A {
			xs[j] = c.eval(a)
			if n.Op == "or" {
				xs[j] = -xs[j]
			}
		}
		v = c.conjunction(xs)
		if n.Op == "or" {
			v = -v
		}
	case "forall":
		var xs []int
		c.enumerate(n, 0, &xs)
		v = c.conjunction(xs)
	case "=":
		a, b := c.eval(n.A[0]), c.eval(n.A[1])
		if c.q.Nodes[n.A[0]].Sort != 0 {
			v = c.eq(a, b)
		} else {
			switch {
			case a == b:
				v = 1
			case a == -b:
				v = -1
			case a == 1:
				v = b
			case b == 1:
				v = a
			case a == -1:
				v = -b
			case b == -1:
				v = -a
			default:
				v = c.conjunction([]int{-c.conjunction([]int{a, -b}), -c.conjunction([]int{-a, b})})
			}
		}
	case "app":
		k := application{symbol: n.Sym}
		for j, id := range n.A {
			k.args[j] = c.eval(id)
		}
		v = c.applications[k]
		if v == 0 {
			v = c.variable()
			c.applications[k] = v
			if len(n.A) > 0 {
				if len(c.groups[n.Sym]) == 0 {
					c.symbols = append(c.symbols, n.Sym)
				}
				c.groups[n.Sym] = append(c.groups[n.Sym], appRow{k, v, n.Sort == 0})
			}
		}
	default:
		panic(n.Op)
	}
	if len(n.D) == 0 {
		c.fixed[i] = v
	} else {
		c.cache[k] = v
	}
	return v
}
func (c *compiler) congruence(unary bool) {
	for _, s := range c.symbols {
		group := c.groups[s]
		for i, a := range group {
			if unary && a.app.args[1] != 0 {
				break
			}
			for _, b := range group[:i] {
				var guard int
				for j, x := range a.app.args {
					y := b.app.args[j]
					if x == y {
						continue
					}
					if guard != 0 {
						guard = 0
						break
					}
					if x > y {
						x, y = y, x
					}
					guard = c.equalities[equality{x, y}]
					if guard == 0 {
						break
					}
				}
				if guard == 0 {
					continue
				}
				if a.boolean {
					c.clauses = append(c.clauses, []int{-guard, -a.result, b.result}, []int{-guard, a.result, -b.result})
				} else {
					c.clauses = append(c.clauses, []int{-guard, c.eq(a.result, b.result)})
				}
			}
		}
	}
}
func (c *compiler) require(v int) {
	if c.emitted[v] {
		return
	}
	if children := c.gates[v]; children != nil {
		c.emitted[v] = true
		for _, a := range children {
			c.clauses = append(c.clauses, []int{-v, a})
			c.require(a)
		}
	} else if children := c.gates[-v]; children != nil {
		c.emitted[v] = true
		clause := make([]int, 1, len(children)+1)
		clause[0] = -v
		for _, a := range children {
			clause = append(clause, -a)
			c.require(-a)
		}
		c.clauses = append(c.clauses, clause)
	}
}
func (c *compiler) assert(v int) {
	if children := c.gates[v]; children != nil {
		for _, a := range children {
			c.assert(a)
		}
	} else if children := c.gates[-v]; children != nil {
		clause := make([]int, 0, len(children))
		for _, a := range children {
			clause = append(clause, -a)
			c.require(-a)
		}
		c.clauses = append(c.clauses, clause)
	} else {
		c.clauses = append(c.clauses, []int{v})
	}
}
func (c *compiler) compile(unary bool) {
	c.gates = make(map[int][]int)
	c.emitted = make(map[int]bool)
	c.cache = make(map[binding]int)
	c.applications = make(map[application]int)
	c.groups = make(map[int][]appRow)
	c.equalities = make(map[equality]int)
	c.assignment = make([]int, len(c.q.Sorts))
	c.alias = make([]int, len(c.q.Nodes))
	c.fixed = make([]int, len(c.alias))
	for _, pair := range c.q.Aliases {
		a, b := c.find(pair[0]), c.find(pair[1])
		if a != b {
			c.alias[a] = b
		}
	}
	c.next = 1
	c.clauses = append(c.clauses, []int{1})
	c.terms = make([][]int, len(c.q.Domains))
	for st, ds := range c.q.Domains {
		seen := make(map[int]bool)
		for _, n := range ds {
			v := c.eval(n)
			if !seen[v] {
				seen[v] = true
				c.terms[st] = append(c.terms[st], v)
			}
		}
	}
	for _, r := range c.q.Roots {
		c.assert(c.eval(r))
	}
	c.congruence(unary)
}

// Finish unit propagation and pure literal elimination before sending the residual to SAT.
func (c *compiler) reduce() {
	val := make([]int8, c.next+1)
	polarity := make([]int8, c.next+1)
	for {
		changed := false
		kept := c.clauses[:0]
		for _, cl := range c.clauses {
			clause := cl[:0]
			sat := false
			for _, l := range cl {
				i, sign := l, int8(1)
				if i < 0 {
					i, sign = -i, -1
				}
				switch val[i] * sign {
				case 1:
					sat = true
				case 0:
					clause = append(clause, l)
				}
				if sat {
					break
				}
			}
			if sat {
				continue
			}
			if len(clause) == 0 {
				c.clauses = [][]int{nil}
				return
			}
			if len(clause) == 1 {
				i, sign := clause[0], int8(1)
				if i < 0 {
					i, sign = -i, -1
				}
				val[i] = sign
				changed = true
				continue
			}
			kept = append(kept, clause)
		}
		c.clauses = kept
		if changed {
			continue
		}
		clear(polarity)
		for _, cl := range kept {
			for _, l := range cl {
				i, p := l, int8(1)
				if i < 0 {
					i, p = -i, 2
				}
				polarity[i] |= p
			}
		}
		for i, v := range polarity {
			if v == 1 {
				val[i] = 1
				changed = true
			} else if v == 2 {
				val[i] = -1
				changed = true
			}
		}
		if !changed {
			return
		}
	}
}
func main() {
	f, err := os.Open(os.Args[1])
	if err != nil {
		panic(err)
	}
	var c compiler
	if err = json.NewDecoder(f).Decode(&c.q); err != nil {
		panic(err)
	}
	f.Close()
	c.width, err = strconv.Atoi(os.Args[2])
	if err != nil || c.width <= 0 {
		panic("invalid width")
	}
	c.compile(os.Args[3] == "unary")
	before := len(c.clauses)
	if os.Args[4] == "reduce" {
		c.reduce()
	}
	fmt.Fprintln(os.Stderr, c.next, before, len(c.clauses))
	out := bufio.NewWriter(os.Stdout)
	fmt.Fprintf(out, "p cnf %d %d\n", c.next, len(c.clauses))
	var line []byte
	for _, cl := range c.clauses {
		line = line[:0]
		for _, v := range cl {
			line = strconv.AppendInt(line, int64(v), 10)
			line = append(line, ' ')
		}
		line = append(line, '0', '\n')
		out.Write(line)
	}
	out.Flush()
}
