from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'ground.go').read_text()
s=s.replace('q                        query','gates map[int][]int\n emitted map[int]bool\n q query')
a=s.index('\tv := c.variable()\n\trev :=');b=s.index('\n\treturn v',a)
s=s[:a]+''' v:=c.variable()
 c.gates[v]=kept
'''+s[b:]
a=s.index('\t\t\tdefault:\n\t\t\t\tv = c.variable()');b=s.index('\n\t\t\t}',a)
s=s[:a]+'''            default:
                v=c.conjunction([]int{-c.conjunction([]int{a,-b}),-c.conjunction([]int{-a,b})})'''+s[b:]
s=s.replace('func (c *compiler) compile(unary bool) {','''func (c *compiler) require(v int) {
 if c.emitted[v]{return}
 if children:=c.gates[v];children!=nil{
   c.emitted[v]=true
   for _,a:=range children{c.clauses=append(c.clauses,[]int{-v,a});c.require(a)}
 }else if children:=c.gates[-v];children!=nil{
   c.emitted[v]=true
   clause:=make([]int,1,len(children)+1);clause[0]=-v
   for _,a:=range children{clause=append(clause,-a);c.require(-a)}
   c.clauses=append(c.clauses,clause)
 }
}
func (c *compiler) assert(v int){
 if children:=c.gates[v];children!=nil{
   for _,a:=range children{c.assert(a)}
 }else if children:=c.gates[-v];children!=nil{
   clause:=make([]int,0,len(children))
   for _,a:=range children{clause=append(clause,-a);c.require(-a)}
   c.clauses=append(c.clauses,clause)
 }else{c.clauses=append(c.clauses,[]int{v})}
}
func (c *compiler) compile(unary bool) {
 c.gates=make(map[int][]int);c.emitted=make(map[int]bool)''')
s=s.replace('v := c.eval(r)\n\t\tc.clauses = append(c.clauses, []int{v})','c.assert(c.eval(r))')
(w/'polar.go').write_text(s)
