"""Find ground consequences falsified by successive finite models of accepted rows."""
import argparse
import collections
import csv
import functools
import itertools
import os
from pathlib import Path
import subprocess
import sys
import time

p=Path.cwd()
previous=Path(os.environ.get('TICKET_INPUTS','/tmp/g3-repeat-qi'))
sys.path[:0]=[str(p.parent/'build/python'),str(previous),str(p/'perf/ivy_apple/goal_instances/finite_models')]
import z3
from hints import expand,conjuncts
from syntax import parse,smt

def normalize(path):
    original=parse(path.read_text())
    old={row[1] for row in original if row[0]=='declare-fun'}
    tactic=z3.Then('simplify',z3.With(z3.Tactic('nnf'),mode='full'))
    solver=z3.Solver()
    solver.add(*list(tactic(z3.parse_smt2_file(str(path)))[0]))
    forms=parse(solver.sexpr())
    declarations=[row for row in forms if row[0].startswith('declare')]
    rules=[r for row in forms if row[0]=='assert' for r in conjuncts(expand(row[1],{}))]
    sig={row[1]:(row[2],row[3]) for row in declarations if row[0]=='declare-fun'}
    pool=collections.defaultdict(set)
    for key,(dom,sort) in sig.items():
        if not dom and sort!='Bool' and key not in old:pool[sort].add(key)
    for rule in rules:
        atom=rule[1] if isinstance(rule,tuple) and rule[0]=='not' else rule
        if isinstance(atom,tuple) and (atom[0]=='=' or atom[0] in sig):
            for arg in atom[1:]:
                if arg in sig and not sig[arg][0] and sig[arg][1]!='Bool':
                    pool[sig[arg][1]].add(arg)
    seed={sort:sorted(terms) for sort,terms in pool.items()}
    for key,(dom,sort) in sig.items():
        if dom and sort!='Bool' and key not in old:
            for args in itertools.product(*(seed.get(s,()) for s in dom)):
                pool[sort].add((key,*args))
    return declarations,rules,{s:sorted(ts,key=repr) for s,ts in pool.items()}

def discover(path,width,rounds,output,mode):
    start=time.monotonic()
    decls,rules,pool=normalize(path)
    sorts={'Bool':z3.BoolSort()}
    symbols={}
    unquote=lambda s:s.strip('|')
    for d in decls:
        if d[0]=='declare-sort':sorts[d[1]]=z3.DeclareSort(unquote(d[1]))
        elif d[0]=='declare-fun':
            symbols[d[1],tuple(str(sorts[k]) for k in d[2])]=z3.Function(unquote(d[1]),*[sorts[s] for s in d[2]],sorts[d[3]])
        else:raise ValueError(d)
    direct={k:v for (k,dom),v in symbols.items() if sum(other==k for other,ds in symbols)==1}
    @functools.cache
    def expr(t):
        if isinstance(t,str):
            if t in ('true','false'):return z3.BoolVal(t=='true')
            return symbols[t,()]()
        op=t[0];args=[expr(c) for c in t[1:]]
        if op=='=':return args[0]==args[1]
        if op=='not':return z3.Not(*args)
        if op=='and':return z3.And(*args)
        if op=='or':return z3.Or(*args)
        if op=='ite':return z3.If(*args)
        if op=='distinct':return z3.Distinct(*args)
        if op in direct:return direct[op](*args)
        return symbols[op,tuple(str(a.sort()) for a in args)](*args)
    @functools.cache
    def quantified(t):
        return isinstance(t,tuple) and (t[0]=="forall" or any(quantified(c) for c in t[1:]))
    def strip(t):
        if isinstance(t,str):return t
        if t[0]=='forall':return 'true'
        if t[0]=='!':return strip(t[1])
        return tuple(strip(c) for c in t)
    def audit(t,positive=True):
        if isinstance(t,str):return
        if t[0]=='!':return audit(t[1],positive)
        if t[0]=='forall':
            assert positive
            return audit(t[2])
        assert t[0]!='exists'
        for c in t[1:]:audit(c,positive and t[0] in ('and','or'))
    s=z3.Solver();rows=set();bound=[]
    for r in rules:
        audit(r)
        weak=strip(r)
        if weak!=r:bound.append(r)
        if weak!='true':rows.add(weak);s.add(expr(weak))
    candidates=0;scans=0;probes=0;adds=0;answer='budget'
    for i in range(rounds+1):
        res=s.check()
        if res==z3.unsat:answer='unsat';break
        assert res==z3.sat
        if i==rounds:break
        model=s.model()
        reps={}
        for sort,terms in pool.items():
            by_value={}
            for t in terms:
                value=model.eval(expr(t),model_completion=True).get_id()
                by_value.setdefault(value,t)
            reps[sort]=list(by_value.values())
        @functools.cache
        def satisfied(t):
            nonlocal probes
            probes+=1
            return z3.is_true(model.eval(expr(t),model_completion=True))
        def violated(t,env):
            nonlocal candidates
            if isinstance(t,str):return None if satisfied(t) else t
            if mode in ('whole','batch') and not quantified(t):
                leaf=expand(t,env)
                return None if satisfied(leaf) else leaf
            op=t[0]
            if op=='!':return violated(t[1],env)
            if op=='forall':
                binds=t[1]
                missed=[]
                for values in itertools.product(*(reps.get(st,()) for _,st in binds)):
                    if width and any(len({v for (_,s),v in zip(binds,values) if s==st})>width for _,st in binds):continue
                    candidates+=1
                    result=violated(t[2],dict(env,**dict(zip((n for n,_ in binds),values))))
                    if result is not None:
                        missed.append(result)
                        if mode!='batch' or len(missed)>=8:break
                if not missed:return None
                return missed[0] if len(missed)==1 else ('and',*missed)
            if op=='and':
                for c in t[1:]:
                    r=violated(c,env)
                    if r is not None:return r
                return None
            if op=='or':
                children=[]
                for c in t[1:]:
                    r=violated(c,env)
                    if r is None:return None
                    children.append(r)
                return ('or',*children)
            leaf=expand(t,env)
            return None if satisfied(leaf) else leaf
        learned=[]
        for rule in bound:
            scans+=1
            lemma=violated(rule,{})
            if lemma is not None:
                assert lemma not in rows and not satisfied(lemma)
                if lemma not in learned:learned.append(lemma)
                if mode=='first':break
        if not learned:answer='exhausted';break
        for lemma in learned:
            rows.add(lemma);s.add(expr(lemma));adds+=1
    elapsed=time.monotonic()-start
    if answer=='unsat':
        script='\n'.join(map(smt,decls+[('assert',r) for r in sorted(rows,key=repr)]+[('check-sat',)]))
        output.write_text(script)
        for exe in ('/tmp/g3-witness-match/g3',p.parent/'build/z3'):
            result=subprocess.run([exe,'-in'],input=script,text=True,capture_output=True,timeout=15,check=True)
            assert result.stdout.strip()=='unsat' and not result.stderr
    return answer,i,scans,candidates,probes,adds,len(rows),round(elapsed,3)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('input',type=Path);a.add_argument('width',type=int);a.add_argument('output',type=Path);a.add_argument('--rounds',type=int,default=80);a.add_argument('--mode',default='all');args=a.parse_args()
    print(*discover(args.input,args.width,args.rounds,args.output,args.mode),sep=',')
