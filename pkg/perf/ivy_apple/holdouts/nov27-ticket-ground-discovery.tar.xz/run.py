from pathlib import Path
import os,csv,subprocess as sp
w=Path(__file__).resolve().parent
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'results.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal width mode answer round scans candidates probes learned rows seconds instructions'.split())
 for mode in ['batch','whole','all']:
  for b,g,width in [(15,8,1),(16,1,1),(12,8,2),(13,8,2),(14,8,2),(14,8,0)]:
   pre=f'{b}-{g}-{width}-{mode}';stat=w/(pre+'.stat')
   cmd=['taskset','-c','30',perf,'stat','-x,','-e','instructions:u','-o',stat,'--','python3',w/'discover.py',f'/tmp/g3-repeat-qi/captures/8-{b}-{g}.smt2',str(width),w/(pre+'.smt2'),'--mode',mode]
   r=sp.run(cmd,capture_output=True,text=True,check=True,timeout=90,env=dict(os.environ,GOMAXPROCS='1',PYTHONHASHSEED='0'));ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
   out.writerow([b,g,width,mode,*r.stdout.strip().split(','),ins]);f.flush()
