from pathlib import Path
import csv,sys,os,subprocess as sp
p=Path.cwd();wk=Path(__file__).resolve().parent;prev=Path('/tmp/g3-repeat-qi');sys.path.insert(0,str(wk))
import observed as cn
exec((prev/'diagonal.py').read_text().split("with (w/'diagonal.csv'")[0].replace('w=Path(__file__).resolve().parent','w=prev',1).replace("exec((w/'expand.py').read_text().split(\"with (w/'expanded.csv'\")[0])","exec((w/'expand.py').read_text().split(\"with (w/'expanded.csv'\")[0].replace('w=Path(__file__).resolve().parent','w=prev'))"))
from hints import conjuncts
with (wk/'observed.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal width vars clauses eq setup_ms check_instructions engine answer'.split())
 import time
 for b,g,width in [(15,8,1),(16,1,1),(12,8,2),(13,8,2),(14,8,2),(14,8,3)]:
  decl,rules,pool,sig,old=ground(prev/'captures'/f'8-{b}-{g}.smt2','facts');args={k:sorted(v,key=repr) for k,v in pool.items()};extra=collections.defaultdict(set)
  for r in rules:apps(inst(r,{},args),extra)
  for sort,v in extra.items():pool[sort].update(v)
  args={k:sorted(v,key=repr) for k,v in pool.items()}
  start=time.monotonic();rows=list(dict.fromkeys(x for r in rules for x in conjuncts(narrow(r,{},args))))
  for mode in ['single-observed-unary','single-observed']:
   n,clauses=cn.encode(decl,rows,'units',mode);elapsed=round(1000*(time.monotonic()-start),2)
   text=f'p cnf {n} {len(clauses)}\n'+''.join(' '.join(map(str,cl))+' 0\n' for cl in clauses)
   for engine,exe in [('g3','/tmp/g3-witness-match/g3'),('native',p.parent/'build/z3')]:
    stat=wk/'observed.stat';r=sp.run(['taskset','-c','27','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,'-dimacs','-in'],input=text,capture_output=True,text=True,timeout=15,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'))
    ans=r.stdout.splitlines()[0];assert ans in ('sat','unsat'),(r.stderr,r.stdout[:100]);ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([b,g,width,n,len(clauses),mode,elapsed,ins,engine,ans]);f.flush()
