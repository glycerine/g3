"""Price the need for equality reasoning in the ground proof fixtures."""
from pathlib import Path
import collections,csv,sys,functools,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;d=Path('/tmp/g3-repeat-qi')
sys.path[:0]=[str(d),str(p/'perf/ivy_apple/goal_instances/finite_models')]
from hints import conjuncts,expand
from syntax import parse,smt
def encode(decls,rules,mode,axioms="off"):
    sig={(f[1],len(f[2])):f[3] for f in decls if f[0]=='declare-fun'}
    rep={}
    def find(x):
        while x in rep:x=rep[x]
        return x
    def boolean(t):
        if isinstance(t,str):return t in ('true','false') or sig[t,0]=='Bool'
        return t[0] in ('and','not','or','=>','=') or sig[t[0],len(t)-1]=='Bool'
    if mode=='units':
        for r in rules:
            if isinstance(r,tuple) and r[0]=='=' and all(isinstance(a,str) for a in r[1:]) and not boolean(r[1]):
                a,b=map(find,r[1:])
                if a!=b:rep[a]=b
    @functools.cache
    def canon(t):
        if isinstance(t,str):return find(t)
        return (t[0],*(canon(a) for a in t[1:]))
    atoms={};clauses=[];variables=0
    def new():
        nonlocal variables
        variables+=1;return variables
    truth=new();clauses.append((truth,))
    @functools.cache
    def lit(t):
        if t=='true':return truth
        if t=='false':return -truth
        if isinstance(t,tuple):
            op=t[0]
            if op=='not':return -lit(t[1])
            if op in ('and','or'):
                sign=1 if op=='and' else -1
                args=set(sign*lit(a) for a in t[1:])
                if -truth in args or any(-a in args for a in args):return -sign*truth
                args.discard(truth)
                if not args:return sign*truth
                if len(args)==1:return sign*next(iter(args))
                v=new()
                for l in sorted(args):clauses.append((-v,l))
                clauses.append((v,*sorted(-a for a in args)))
                return sign*v
            if op=='=':
                if boolean(t[1]):
                    a,b=lit(t[1]),lit(t[2])
                    if a==b:return truth
                    if a==-b:return -truth
                    v=new();clauses.extend([(-v,-a,b),(-v,a,-b),(v,a,b),(v,-a,-b)])
                    return v
                a,b=map(canon,t[1:])
                if a==b:return truth
                t=('=',*sorted([a,b],key=repr))
            else:
                assert op not in ('forall','exists','ite','=>')
                t=canon(t)
        if t not in atoms:atoms[t]=new()
        return atoms[t]
    for r in rules:clauses.append((lit(r),))
    if axioms!='off':
        terms=collections.defaultdict(set);apps=collections.defaultdict(set)
        def term(t):
            if isinstance(t,str):
                if t not in ("true","false") and sig[t,0]!="Bool":terms[sig[t,0]].add(t)
                return
            if t[0] in ("not","and","or","="):
                for a in t[1:]:term(a)
                return
            for a in t[1:]:term(a)
            apps[t[0],len(t)-1].add(t)
            if not boolean(t):terms[sig[t[0],len(t)-1]].add(t)
        for a in list(atoms):term(a)
        def eq(a,b):return lit(('=',a,b))
        import itertools
        if 'trans' in axioms:
            for group in terms.values():
                for a,b,c in itertools.combinations(sorted(group,key=repr),3):
                    ab,bc,ac=eq(a,b),eq(b,c),eq(a,c)
                    clauses.extend([(-ab,-bc,ac),(-ab,-ac,bc),(-bc,-ac,ab)])
        for group in apps.values():
            for a,b in itertools.combinations(sorted(group,key=repr),2):
                diffs=[(x,y) for x,y in zip(a[1:],b[1:]) if x!=y]
                if 'single' in axioms and len(diffs)>1:continue
                guards=tuple(-eq(x,y) for x,y in diffs)
                if boolean(a):
                    x,y=lit(a),lit(b);clauses.extend([(*guards,-x,y),(*guards,x,-y)])
                else:clauses.append((*guards,eq(a,b)))
    return variables,clauses
def propagate(clauses):
    bylit=collections.defaultdict(list);live=[len(cl) for cl in clauses];todo=collections.deque()
    for i,cl in enumerate(clauses):
        if len(cl)==1:todo.append(cl[0])
        for l in cl:bylit[l].append(i)
    seen=set()
    while todo:
        l=todo.popleft()
        if l in seen:continue
        if -l in seen:return True,len(seen)
        seen.add(l)
        for i in bylit[l]:live[i]=-1
        for i in bylit[-l]:
            if live[i]<0:continue
            live[i]-=1
            if live[i]==0:return True,len(seen)
            if live[i]==1:todo.extend(a for a in clauses[i] if -a not in seen)
    return False,len(seen)
if __name__=='__main__':
 with (w/'congruence.csv').open('w') as f:
    out=csv.writer(f);out.writerow('case source equality vars clauses unit_conflict assignments result'.split())
    for path in sorted(d.glob('sparse-*.smt2'))+sorted(w.glob('*-batch.smt2')):
        forms=parse(path.read_text());decls=[f for f in forms if f[0].startswith('declare')];rules=[r for f in forms if f[0]=='assert' for r in conjuncts(expand(f[1],{}))]
        for mode in ['single','all','single-trans','all-trans']:
            n,cs=encode(decls,rules,"units",mode);conf,steps=propagate(cs)
            text=f'p cnf {n} {len(cs)}\n'+''.join(' '.join(map(str,cl))+' 0\n' for cl in cs)
            results=[]
            for exe in (p.parent/'build/z3','/tmp/g3-witness-match/g3'):
                rr=sp.run([exe,'-dimacs','-in'],input=text,text=True,capture_output=True,timeout=20)
                results.append(rr.stdout.splitlines()[0])
            assert results[0]==results[1] and (not conf or results[0]=='unsat')
            out.writerow([path.stem,'sparse' if path.parent==d else 'discovered',mode,n,len(cs),int(conf),steps,results[0]]);f.flush()
