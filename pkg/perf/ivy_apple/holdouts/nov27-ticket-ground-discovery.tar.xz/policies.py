"""Compare original pushed workloads with the engine's own counterexample search."""
from pathlib import Path
import csv,sys,subprocess as sp,os,re
w=Path(__file__).resolve().parent
d=Path('/tmp/g3-repeat-qi');sys.path.insert(0,str(d))
from split import generate
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
configs={'default':[],'model_only':['smt.ematching=false'],'match_only':['smt.mbqi=false'],'eager_model':['smt.qi.eager_threshold=0','smt.qi.lazy_threshold=0']}
with (w/'policies.csv').open('w') as f:
 out=csv.writer(f);out.writerow('goal engine policy answer instructions instances decisions conflicts'.split())
 for path in sorted((d/'captures').glob('*.smt2')):
  script,_=generate(path,'off')
  for name,exe in [('g3','/tmp/g3-witness-match/g3'),('native',Path.cwd().parent/'build/z3')]:
   for policy,args in configs.items():
    stat=w/'policy.stat'
    r=sp.run(['taskset','-c','23',perf,'stat','-x,','-e','instructions:u','-o',stat,'--',exe,'smt.macro_finder=true','-T:2',*args,'-in'],input=script,capture_output=True,text=True,timeout=8,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'))
    a=dict(re.findall(r':([\w-]+)\s+(\d+)',r.stdout));answer=r.stdout.splitlines()[0] if r.stdout else 'error'
    if answer not in ('unsat','sat','unknown','timeout'):raise RuntimeError((path,policy,r.stdout[:300],r.stderr[:300]))
    ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([path.stem,name,policy,answer,ins,*[a.get(k,0) for k in ('quant-instantiations','decisions','conflicts')]]);f.flush()
