from pathlib import Path
import re,json,os,subprocess as sp,tempfile,csv
w=Path(__file__).resolve().parent;p=Path.cwd()
base=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
source=front/'z3bridge_solver_model.go'
s=Path(base['Replace'][str(source)]).read_text().replace('s.showVCsBase(clauses)','s.showVCsBase(clauses)\npriceBatch++;priceCurrent:=priceBatch',1)
key='if s.opts.Incremental {\n\t\t\t\t\tz3solver.Push()'
assert s.count(key)==1
s=s.replace(key,'''if priceCheck(priceCurrent,index+1){overallResult=smt.Unsat;fc.Unsat();continue}
                 '''+key)
f=w/'verify_bridge.go';f.write_text(s);base['Replace'][str(source)]=str(f)
s=(w/'integrated.go').read_text().split('func counter()')[0].replace('package main','package goivy').replace('"runtime"','').replace('"syscall"','').replace('"unsafe"','').replace('"strconv"','')
for name in ['node','query','binding','application','appRow','equality','compiler','must','solve']:
 s=re.sub(r'\b'+name+r'\b','ticketPrice'+name[0].upper()+name[1:],s)
r=list(csv.DictReader((w/'screen.csv').open()));eligible={tuple(map(int,x['case'].split('-')[1:])):(x['answer']=='unsatisfiable') for x in r if x['expected']=='unsat'}
s+='\nvar priceBatch int\nvar priceMode=os.Getenv("GROUND_PRICE")\nvar priceCases=map[[2]int]bool{'+','.join('{%d,%d}:%s'%(k[0],k[1],str(v).lower()) for k,v in eligible.items())+'}\n'
s+='''func priceCheck(b,g int)bool{
 if priceMode=="" {return false}
 proved,ok:=priceCases[[2]int{b,g}];if !ok || priceMode=="hits" && !proved || priceMode=="one" && (b!=15 || g!=8){return false}
 f,e:=os.Open(fmt.Sprintf("/tmp/g3-model-proof/8-%d-%d.json",b,g));ticketPriceMust(e)
 var c ticketPriceCompiler;ticketPriceMust(json.NewDecoder(f).Decode(&c.q));ticketPriceMust(f.Close())
 c.q.Domains=c.q.Seeds["fresh"];c.width=1;c.compile(true);c.reduce()
 answer:=ticketPriceSolve(&c)=="unsatisfiable";if answer!=proved{panic("ground fixture mismatch")};return answer
}
'''
f=w/'verify_ground.go';f.write_text(s);base['Replace'][str(front/'phase_observer_trial.go')]=str(f)
j=w/'verification.json';j.write_text(json.dumps(base))
with tempfile.TemporaryDirectory(dir=Path.home()/'tmp') as t:
 sp.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'verifier','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=t,GOTMPDIR=t),check=True)
