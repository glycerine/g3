package goivy

import (
	"encoding/json"
	"fmt"
	"github.com/glycerine/g3/pkg/arena"
	"github.com/glycerine/g3/pkg/sat"
	"github.com/glycerine/g3/pkg/util/control"
	numeral "github.com/glycerine/g3/pkg/util/numeral"
	params "github.com/glycerine/g3/pkg/util/params"
	symbol "github.com/glycerine/g3/pkg/util/symbol"
	"os"
	
	
	
	
)

type ticketPriceNode struct {
	Op              string
	Sort, Sym, Slot int
	A, B, D         []int
}
type ticketPriceQuery struct {
	Seeds        map[string][][]int
	Nodes        []ticketPriceNode
	Roots, Sorts []int
	Domains      [][]int
	Aliases      [][2]int
}
type ticketPriceBinding struct {
	ticketPriceNode   int
	values [4]int
}
type ticketPriceApplication struct {
	symbol int
	args   [3]int
}
type ticketPriceAppRow struct {
	app     ticketPriceApplication
	result  int
	boolean bool
}
type ticketPriceEquality struct{ a, b int }
type ticketPriceCompiler struct {
	gates                    map[int][]int
	emitted                  map[int]bool
	q                        ticketPriceQuery
	width                    int
	terms                    [][]int
	assignment, alias, fixed []int
	cache                    map[ticketPriceBinding]int
	applications             map[ticketPriceApplication]int
	groups                   map[int][]ticketPriceAppRow
	symbols                  []int
	equalities               map[ticketPriceEquality]int
	clauses                  [][]int
	next                     int
}

func (c *ticketPriceCompiler) variable() int { c.next++; return c.next }
func (c *ticketPriceCompiler) find(i int) int {
	for c.alias[i] != 0 {
		i = c.alias[i]
	}
	return i
}
func (c *ticketPriceCompiler) eq(a, b int) int {
	if a == b {
		return 1
	}
	if a > b {
		a, b = b, a
	}
	key := ticketPriceEquality{a, b}
	if v := c.equalities[key]; v != 0 {
		return v
	}
	v := c.variable()
	c.equalities[key] = v
	return v
}

// Use the signed literals of the conjuncts. Negating this construction gives OR.
func (c *ticketPriceCompiler) conjunction(args []int) int {
	kept := args[:0]
	for _, v := range args {
		if v == -1 {
			return -1
		}
		if v != 1 {
			kept = append(kept, v)
		}
	}
	switch len(kept) {
	case 0:
		return 1
	case 1:
		return kept[0]
	}
	v := c.variable()
	c.gates[v] = kept

	return v
}
func (c *ticketPriceCompiler) enumerate(n ticketPriceNode, pos int, rows *[]int) {
	if pos == len(n.B) {
		*rows = append(*rows, c.eval(n.A[0]))
		return
	}
	slot := n.B[pos]
	st := c.q.Sorts[slot]
	for _, v := range c.terms[st] {
		if pos >= c.width {
			count := 1
			for j, prior := range n.B[:pos] {
				if c.q.Sorts[prior] != st || c.assignment[prior] == v {
					continue
				}
				first := true
				for _, earlier := range n.B[:j] {
					if c.q.Sorts[earlier] == st && c.assignment[earlier] == c.assignment[prior] {
						first = false
						break
					}
				}
				if first {
					count++
				}
			}
			if count > c.width {
				continue
			}
		}
		c.assignment[slot] = v
		c.enumerate(n, pos+1, rows)
	}
}
func (c *ticketPriceCompiler) eval(i int) int {
	i = c.find(i)
	if c.fixed[i] != 0 {
		return c.fixed[i]
	}
	n := c.q.Nodes[i]
	if n.Op == "v" {
		return c.assignment[n.Slot]
	}
	var k ticketPriceBinding
	k.ticketPriceNode = i
	if len(n.D) > 0 {
		for j, slot := range n.D {
			k.values[j] = c.assignment[slot]
		}
		if v := c.cache[k]; v != 0 {
			return v
		}
	}
	var v int
	switch n.Op {
	case "true":
		v = 1
	case "false":
		v = -1
	case "not":
		v = -c.eval(n.A[0])
	case "and", "or":
		xs := make([]int, len(n.A))
		for j, a := range n.A {
			xs[j] = c.eval(a)
			if n.Op == "or" {
				xs[j] = -xs[j]
			}
		}
		v = c.conjunction(xs)
		if n.Op == "or" {
			v = -v
		}
	case "forall":
		var xs []int
		c.enumerate(n, 0, &xs)
		v = c.conjunction(xs)
	case "=":
		a, b := c.eval(n.A[0]), c.eval(n.A[1])
		if c.q.Nodes[n.A[0]].Sort != 0 {
			v = c.eq(a, b)
		} else {
			switch {
			case a == b:
				v = 1
			case a == -b:
				v = -1
			case a == 1:
				v = b
			case b == 1:
				v = a
			case a == -1:
				v = -b
			case b == -1:
				v = -a
			default:
				v = c.conjunction([]int{-c.conjunction([]int{a, -b}), -c.conjunction([]int{-a, b})})
			}
		}
	case "app":
		k := ticketPriceApplication{symbol: n.Sym}
		for j, id := range n.A {
			k.args[j] = c.eval(id)
		}
		v = c.applications[k]
		if v == 0 {
			v = c.variable()
			c.applications[k] = v
			if len(n.A) > 0 {
				if len(c.groups[n.Sym]) == 0 {
					c.symbols = append(c.symbols, n.Sym)
				}
				c.groups[n.Sym] = append(c.groups[n.Sym], ticketPriceAppRow{k, v, n.Sort == 0})
			}
		}
	default:
		panic(n.Op)
	}
	if len(n.D) == 0 {
		c.fixed[i] = v
	} else {
		c.cache[k] = v
	}
	return v
}
func (c *ticketPriceCompiler) congruence(unary bool) {
	for _, s := range c.symbols {
		group := c.groups[s]
		for i, a := range group {
			if unary && a.app.args[1] != 0 {
				break
			}
			for _, b := range group[:i] {
				var guard int
				for j, x := range a.app.args {
					y := b.app.args[j]
					if x == y {
						continue
					}
					if guard != 0 {
						guard = 0
						break
					}
					if x > y {
						x, y = y, x
					}
					guard = c.equalities[ticketPriceEquality{x, y}]
					if guard == 0 {
						break
					}
				}
				if guard == 0 {
					continue
				}
				if a.boolean {
					c.clauses = append(c.clauses, []int{-guard, -a.result, b.result}, []int{-guard, a.result, -b.result})
				} else {
					c.clauses = append(c.clauses, []int{-guard, c.eq(a.result, b.result)})
				}
			}
		}
	}
}
func (c *ticketPriceCompiler) require(v int) {
	if c.emitted[v] {
		return
	}
	if children := c.gates[v]; children != nil {
		c.emitted[v] = true
		for _, a := range children {
			c.clauses = append(c.clauses, []int{-v, a})
			c.require(a)
		}
	} else if children := c.gates[-v]; children != nil {
		c.emitted[v] = true
		clause := make([]int, 1, len(children)+1)
		clause[0] = -v
		for _, a := range children {
			clause = append(clause, -a)
			c.require(-a)
		}
		c.clauses = append(c.clauses, clause)
	}
}
func (c *ticketPriceCompiler) assert(v int) {
	if children := c.gates[v]; children != nil {
		for _, a := range children {
			c.assert(a)
		}
	} else if children := c.gates[-v]; children != nil {
		clause := make([]int, 0, len(children))
		for _, a := range children {
			clause = append(clause, -a)
			c.require(-a)
		}
		c.clauses = append(c.clauses, clause)
	} else {
		c.clauses = append(c.clauses, []int{v})
	}
}
func (c *ticketPriceCompiler) compile(unary bool) {
	c.gates = make(map[int][]int)
	c.emitted = make(map[int]bool)
	c.cache = make(map[ticketPriceBinding]int)
	c.applications = make(map[ticketPriceApplication]int)
	c.groups = make(map[int][]ticketPriceAppRow)
	c.equalities = make(map[ticketPriceEquality]int)
	c.assignment = make([]int, len(c.q.Sorts))
	c.alias = make([]int, len(c.q.Nodes))
	c.fixed = make([]int, len(c.alias))
	for _, pair := range c.q.Aliases {
		a, b := c.find(pair[0]), c.find(pair[1])
		if a != b {
			c.alias[a] = b
		}
	}
	c.next = 1
	c.clauses = append(c.clauses, []int{1})
	c.terms = make([][]int, len(c.q.Domains))
	for st, ds := range c.q.Domains {
		seen := make(map[int]bool)
		for _, n := range ds {
			v := c.eval(n)
			if !seen[v] {
				seen[v] = true
				c.terms[st] = append(c.terms[st], v)
			}
		}
	}
	for _, r := range c.q.Roots {
		c.assert(c.eval(r))
	}
	c.congruence(unary)
}

// Finish unit propagation and pure literal elimination before sending the residual to SAT.
func (c *ticketPriceCompiler) reduce() {
	val := make([]int8, c.next+1)
	polarity := make([]int8, c.next+1)
	for {
		changed := false
		kept := c.clauses[:0]
		for _, cl := range c.clauses {
			clause := cl[:0]
			sat := false
			for _, l := range cl {
				i, sign := l, int8(1)
				if i < 0 {
					i, sign = -i, -1
				}
				switch val[i] * sign {
				case 1:
					sat = true
				case 0:
					clause = append(clause, l)
				}
				if sat {
					break
				}
			}
			if sat {
				continue
			}
			if len(clause) == 0 {
				c.clauses = [][]int{nil}
				return
			}
			if len(clause) == 1 {
				i, sign := clause[0], int8(1)
				if i < 0 {
					i, sign = -i, -1
				}
				val[i] = sign
				changed = true
				continue
			}
			kept = append(kept, clause)
		}
		c.clauses = kept
		if changed {
			continue
		}
		clear(polarity)
		for _, cl := range kept {
			for _, l := range cl {
				i, p := l, int8(1)
				if i < 0 {
					i, p = -i, 2
				}
				polarity[i] |= p
			}
		}
		for i, v := range polarity {
			if v == 1 {
				val[i] = 1
				changed = true
			} else if v == 2 {
				val[i] = -1
				changed = true
			}
		}
		if !changed {
			return
		}
	}
}

func ticketPriceMust(err error) {
	if err != nil {
		panic(err)
	}
}
func ticketPriceSolve(c *ticketPriceCompiler) string {
	b := arena.NewBudget(^uint64(0))
	sy, e := symbol.NewManager(symbol.Config{Budget: b})
	ticketPriceMust(e)
	defer func() { ticketPriceMust(sy.Close()) }()
	q, e := numeral.NewRationalService(numeral.RationalServiceConfig{Integers: numeral.IntegerConfig{Cells: arena.Config{Budget: b}, Words: arena.VectorConfig{Descriptors: arena.Config{Budget: b}}}})
	ticketPriceMust(e)
	defer func() { ticketPriceMust(q.Close()) }()
	ctx, e := params.NewParamsContext(sy, q, params.ParamsConfig{Budget: b})
	ticketPriceMust(e)
	defer func() { ticketPriceMust(ctx.Close()) }()
	p, e := ctx.NewValue()
	ticketPriceMust(e)
	defer func() { ticketPriceMust(ctx.Del(&p)) }()
	for _, k := range []string{"asymm_branch", "probing", "scc", "resolution", "subsumption", "elim_vars"} {
		ticketPriceMust(ctx.SetBoolName(&p, &k, false))
	}
	rt, e := sat.NewRuntime(sat.RuntimeConfig{Budget: b, ParamsContext: ctx})
	ticketPriceMust(e)
	defer func() { ticketPriceMust(rt.Close()) }()
	lim, e := control.NewReslimit(b)
	ticketPriceMust(e)
	defer lim.Close()
	s, e := sat.NewSATSolver(sat.SolverConfig{Budget: b, Runtime: rt, ParamsContext: ctx, Params: p, RLimit: lim})
	ticketPriceMust(e)
	defer func() { ticketPriceMust(s.Close()) }()
	vars := make([]sat.BoolVar, c.next+1)
	ready := make([]bool, len(vars))
	var lits []sat.Literal
	for _, cl := range c.clauses {
		lits = lits[:0]
		for _, n := range cl {
			v := n
			if v < 0 {
				v = -v
			}
			if !ready[v] {
				vars[v], e = s.MkVar(true, true)
				ticketPriceMust(e)
				ready[v] = true
			}
			lits = append(lits, sat.MakeLiteral(vars[v], n < 0))
		}
		ticketPriceMust(s.MkClause(lits))
	}
	status, e := s.Check(nil)
	ticketPriceMust(e)
	return status.SATString()
}

var priceBatch int
var priceMode=os.Getenv("GROUND_PRICE")
var priceCases=map[[2]int]bool{{11,15}:false,{11,16}:true,{11,20}:false,{11,5}:false,{11,6}:false,{11,7}:false,{11,8}:true,{12,13}:false,{12,15}:false,{12,16}:false,{12,19}:false,{12,2}:false,{12,20}:true,{12,3}:false,{12,5}:false,{12,7}:false,{12,8}:false,{13,16}:true,{13,8}:false,{14,10}:false,{14,16}:true,{14,19}:false,{14,20}:true,{14,8}:false,{15,13}:false,{15,15}:false,{15,16}:false,{15,19}:false,{15,2}:false,{15,20}:true,{15,5}:false,{15,7}:false,{15,8}:true,{16,1}:false,{6,9}:false}
func priceCheck(b,g int)bool{
 if priceMode=="" {return false}
 proved,ok:=priceCases[[2]int{b,g}];if !ok || priceMode=="hits" && !proved || priceMode=="one" && (b!=15 || g!=8){return false}
 f,e:=os.Open(fmt.Sprintf("/tmp/g3-model-proof/8-%d-%d.json",b,g));ticketPriceMust(e)
 var c ticketPriceCompiler;ticketPriceMust(json.NewDecoder(f).Decode(&c.q));ticketPriceMust(f.Close())
 c.q.Domains=c.q.Seeds["fresh"];c.width=1;c.compile(true);c.reduce()
 answer:=ticketPriceSolve(&c)=="unsatisfiable";if answer!=proved{panic("ground fixture mismatch")};return answer
}
