from pathlib import Path
import sys,statistics,csv,collections
w=Path(__file__).resolve().parent
for f,modes in [('lazy',['off','lazy']),('operand',['off','predicate','literal','both'])]:
 r=list(csv.DictReader((w/(f+'.csv')).open()))
 print(f,len(r))
 for k in dict.fromkeys(x['case'] for x in r):
  a={m:[int(x['instructions']) for x in r if x['case']==k and x['policy']==m] for m in modes}
  if min(map(len,a.values())):print(k,*[round(100*(statistics.median(a[m])/statistics.median(a['off'])-1),2) for m in modes[1:]],set(x['status'] for x in r if x['case']==k))
