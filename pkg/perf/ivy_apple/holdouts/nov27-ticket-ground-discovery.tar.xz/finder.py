from pathlib import Path
import subprocess as sp,json,os,tempfile
w=Path(__file__).resolve().parent;p=Path.cwd();path=p/'smtcore/smt_model_finder.go';s=path.read_text().replace('import (','import ("os";',1)
s=s.replace('type SMTModelFinder struct {','var trialFinder = os.Getenv("FINDER_ANALYSIS")\ntype SMTModelFinder struct {')
key='\tcandidates, err := macros.NewCandidates(f.manager)'
assert s.count(key)==1
s=s.replace(key,''' if trialFinder=="lazy" {return nil}
 return f.analyzeRegistration(quantifier)
}
func (f *SMTModelFinder) analyzeRegistration(quantifier ast.ASTHandle) error {
'''+key)
key='// cleanup_quantifier_infos:'
s=s.replace(key,'''if trialFinder=="lazy" {
 for _,q:=range f.quantifiers {if f.candidates[q]==nil {if e:=f.analyzeRegistration(q);e!=nil{return e}}}
 }
 '''+key)
f=w/path.name;f.write_text(s)
base=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());base['Replace'][str(path)]=str(f)
j=w/'finder.json';j.write_text(json.dumps(base))
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
with tempfile.TemporaryDirectory(dir=Path.home()/'tmp') as t:
 sp.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'finder','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=t,GOTMPDIR=t),check=True)
