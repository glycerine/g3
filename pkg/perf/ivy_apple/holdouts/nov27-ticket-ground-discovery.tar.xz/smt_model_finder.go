package smtcore

// Source: src/smt/smt_model_finder.h; src/smt/smt_model_finder.cpp model_finder
// registration, scope, search and candidate-model lifecycle.

import ("os";
	"errors"

	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/ast/macros"
	"github.com/glycerine/g3/pkg/ast/pattern"
	"github.com/glycerine/g3/pkg/model"
	protomodel "github.com/glycerine/g3/pkg/smtcore/proto_model"
	"github.com/glycerine/g3/pkg/tactic"
	"github.com/glycerine/g3/pkg/util/lbool"
)

// SMTModelFinder owns the quantified-formula analysis used to extend a ground
// candidate model before MBQI checks it. The macro and AUF algorithms attach
// their per-quantifier state to this lifecycle.
var trialFinder = os.Getenv("FINDER_ANALYSIS")
type SMTModelFinder struct {
	manager     *ast.ASTManager
	state       *SMTInternalizerState
	quantifiers []ast.ASTHandle
	registered  map[ast.ASTHandle]struct{}
	// sets is quantifier_info::m_uvar_inst_sets (macro-based sets, indexed
	// by flat variable index); a quantifier is present once populated.
	sets map[ast.ASTHandle][]*smtModelFinderInstantiationSet
	// aufSolver is m_auf_solver: it lives with the model finder and is
	// reset at the start of each process_auf.
	aufSolver          *smtModelFinderAUFGraph
	flat               map[ast.ASTHandle]smtModelFinderFlatQuantifier
	macroUtil          *macros.Util
	candidates         map[ast.ASTHandle]*macros.Candidates
	nonGround          map[ast.ASTHandle]*ast.ObjMap // m_ng_decls (func_decl_set)
	auf                map[ast.ASTHandle]bool
	qinfos             map[ast.ASTHandle]*smtModelFinderQInfo // quantifier_info::m_qinfo_vect
	chosen             map[ast.ASTHandle]ast.ASTHandle
	hint               *hintSearchState
	dependencies       *ast.FuncDeclDependencies
	forceTemplate      uint32
	pendingConstraints []ast.ASTRef
	scopes             []int
	closed             bool
}

type smtModelFinderFlatQuantifier struct {
	quantifier ast.ASTHandle
	reference  ast.ASTRef
}

func (f *SMTModelFinder) flatQuantifier(quantifier ast.ASTHandle) ast.ASTHandle {
	if flat, found := f.flat[quantifier]; found {
		return flat.quantifier
	}
	return quantifier
}

func NewSMTModelFinder(state *SMTInternalizerState) (*SMTModelFinder, error) {
	if state == nil || state.manager == nil || state.context == nil {
		return nil, ast.ErrASTHandle
	}
	util, err := macros.NewUtil(state.manager)
	if err != nil {
		return nil, err
	}
	dependencies, err := ast.NewFuncDeclDependencies(state.manager)
	if err != nil {
		return nil, err
	}
	f := &SMTModelFinder{
		manager: state.manager, state: state, registered: make(map[ast.ASTHandle]struct{}),
		sets: make(map[ast.ASTHandle][]*smtModelFinderInstantiationSet), macroUtil: util,
		flat:       make(map[ast.ASTHandle]smtModelFinderFlatQuantifier),
		candidates: make(map[ast.ASTHandle]*macros.Candidates), nonGround: make(map[ast.ASTHandle]*ast.ObjMap),
		auf: make(map[ast.ASTHandle]bool), qinfos: make(map[ast.ASTHandle]*smtModelFinderQInfo), chosen: make(map[ast.ASTHandle]ast.ASTHandle), hint: newHintSearchState(state.manager), dependencies: dependencies,
	}
	f.aufSolver = newSMTModelFinderAUFGraph(f)
	return f, nil
}

func (f *SMTModelFinder) open() error {
	if f == nil || f.manager == nil || f.state == nil || f.registered == nil || f.sets == nil || f.macroUtil == nil || f.candidates == nil || f.auf == nil || f.hint == nil || f.dependencies == nil || f.closed {
		return ast.ErrASTHandle
	}
	return nil
}

// checkpoint corresponds to model_finder::checkpoint: model-finder work must
// honor the owning manager's cancellation and resource limit.
func (f *SMTModelFinder) checkpoint() error {
	canceled, err := f.manager.Canceled()
	if err != nil {
		return err
	}
	if canceled {
		// model_finder::checkpoint: throw tactic_exception(get_cancel_msg()).
		return tactic.NewTacticException(f.manager.ResourceLimit().CancelMessage())
	}
	return nil
}

func (f *SMTModelFinder) SetForceTemplate(value uint32) {
	if f != nil && !f.closed {
		f.forceTemplate = value
	}
}

func (f *SMTModelFinder) RegisterQuantifier(quantifier ast.ASTHandle) (result error) {
	if err := f.open(); err != nil {
		return err
	}
	// register_quantifier has no checkpoint; the analyzer's
	// process_formulas_on_stack and insert_qinfo do.
	kind, err := f.manager.GetKind(quantifier)
	if err != nil {
		return err
	}
	if kind != ast.ASTQuantifier {
		return ast.ErrASTDomain
	}
	if _, found := f.registered[quantifier]; found {
		return ast.ErrASTDomain
	}
	f.registered[quantifier] = struct{}{}
	f.quantifiers = append(f.quantifiers, quantifier)
	defer func() {
		if result != nil {
			result = errors.Join(result, f.releaseQuantifier(quantifier))
			f.quantifiers = f.quantifiers[:len(f.quantifiers)-1]
		}
	}()
 if trialFinder=="lazy" {return nil}
 return f.analyzeRegistration(quantifier)
}
func (f *SMTModelFinder) analyzeRegistration(quantifier ast.ASTHandle) error {
	candidates, err := macros.NewCandidates(f.manager)
	if err != nil {
		return err
	}
	f.candidates[quantifier] = candidates
	f.nonGround[quantifier] = ast.NewObjMap(f.manager)
	body, err := f.manager.GetQuantifierBody(quantifier)
	if err != nil {
		return err
	}
	nested, err := f.manager.HasQuantifiers(body)
	if err != nil {
		return err
	}
	var flatRef ast.ASTRef
	if nested {
		flatRef, err = pattern.PullQuantifierNoProof(f.manager, quantifier)
	} else {
		flatRef, err = f.manager.NewRef(quantifier)
	}
	if err != nil {
		return err
	}
	flat, err := f.manager.RefGet(flatRef)
	if err != nil {
		return errors.Join(err, f.manager.DelRef(&flatRef))
	}
	f.flat[quantifier] = smtModelFinderFlatQuantifier{quantifier: flat, reference: flatRef}
	body, err = f.manager.GetQuantifierBody(flat)
	if err != nil {
		return err
	}
	nested, err = f.manager.HasQuantifiers(body)
	if err != nil {
		return err
	}
	if nested {
		return ast.ErrASTPending
	}
	// quantifier_analyzer::operator(): the body's qinfos, m_ng_decls (the
	// analyzer's process_app calls) and m_is_auf, then
	// collect_macro_candidates.
	if f.auf[quantifier], err = f.analyzeQInfos(quantifier); err != nil {
		return err
	}
	bodyKind, err := f.manager.GetKind(body)
	if err != nil {
		return err
	}
	if bodyKind == ast.ASTApp {
		if err = f.macroUtil.CollectQuantifierCandidates(flat, candidates); err != nil {
			return err
		}
	}
	ngEntries := f.nonGround[quantifier].Entries()
	info := &hintQuantifierInfo{nonGround: make([]ast.ASTHandle, 0, len(ngEntries))}
	for _, entry := range ngEntries {
		info.nonGround = append(info.nonGround, entry.Key)
	}
	for i := 0; i < candidates.Len(); i++ {
		candidate, err := candidates.At(i)
		if err != nil {
			return err
		}
		info.macros = append(info.macros, hintConditionalMacro{
			function: candidate.Declaration, definition: candidate.Definition, satisfyAtom: candidate.SatisfyAtom,
		})
	}
	f.hint.infos[quantifier] = info
	return nil
}

// instantiationSet is model_finder::get_uvar_inst_set(q, i), where
// variable is the declaration position of the original quantifier (i is
// its de Bruijn index). The AUF solver's node for the flat variable is
// used when present; otherwise the macro-based set of the quantifier's
// chosen head (quantifier_info::get_macro_based_inst_set(i)), which the
// source indexes with the unadjusted i.
func (f *SMTModelFinder) instantiationSet(quantifier ast.ASTHandle, variable uint32, create bool) (*smtModelFinderInstantiationSet, error) {
	if err := f.open(); err != nil {
		return nil, err
	}
	if _, found := f.registered[quantifier]; !found {
		return nil, ast.ErrASTDomain
	}
	originalCount, err := f.manager.GetNumDeclarations(quantifier)
	if err != nil {
		return nil, err
	}
	if variable >= originalCount {
		return nil, ast.ErrASTDomain
	}
	flatCount, err := f.manager.GetNumDeclarations(f.flatQuantifier(quantifier))
	if err != nil {
		return nil, err
	}
	if node := f.aufSolver.uvars[smtModelFinderAUFKey{quantifier, flatCount - variable - 1}]; node != nil {
		return node.root().set, nil
	}
	index := originalCount - variable - 1
	if create {
		// Test entry: a macro-based set slot created on demand.
		sets := f.sets[quantifier]
		for uint32(len(sets)) <= index {
			sets = append(sets, nil)
		}
		if sets[index] == nil {
			value, err := newSMTModelFinderInstantiationSet(f.manager)
			if err != nil {
				return nil, err
			}
			sets[index] = value
		}
		f.sets[quantifier] = sets
		return sets[index], nil
	}
	if _, found := f.sets[quantifier]; !found {
		if f.chosen[quantifier].IsNull() {
			return nil, nil
		}
		if err := f.populateMacroInstantiationSets(quantifier); err != nil {
			return nil, err
		}
	}
	sets := f.sets[quantifier]
	if index >= uint32(len(sets)) {
		return nil, nil
	}
	return sets[index], nil
}

func (f *SMTModelFinder) InsertInstantiationTerm(quantifier ast.ASTHandle, variable uint32, term ast.ASTHandle, generation uint32) (bool, error) {
	set, err := f.instantiationSet(quantifier, variable, true)
	if err != nil {
		return false, err
	}
	return set.Insert(term, generation)
}

func (f *SMTModelFinder) Inverse(quantifier ast.ASTHandle, variable uint32, value ast.ASTHandle) (term ast.ASTHandle, generation uint32, found bool, err error) {
	set, err := f.instantiationSet(quantifier, variable, false)
	if err != nil || set == nil {
		return term, 0, false, err
	}
	return set.Inverse(value)
}

func (f *SMTModelFinder) InstantiationValues(quantifier ast.ASTHandle, variable uint32) ([]ast.ASTHandle, error) {
	set, err := f.instantiationSet(quantifier, variable, false)
	if err != nil || set == nil {
		return nil, err
	}
	return set.Values()
}

func (f *SMTModelFinder) releaseQuantifier(quantifier ast.ASTHandle) (result error) {
	// ~quantifier_info deletes m_qinfo_vect first, front to back.
	if info := f.qinfos[quantifier]; info != nil {
		result = info.close(f.manager)
	}
	result = errors.Join(result, f.closeMacroSets(quantifier))
	if candidates := f.candidates[quantifier]; candidates != nil {
		result = errors.Join(result, candidates.Close())
	}
	if flat, found := f.flat[quantifier]; found {
		err := f.manager.DelRef(&flat.reference)
		if flat.reference == (ast.ASTRef{}) {
			delete(f.flat, quantifier)
		} else {
			f.flat[quantifier] = flat
		}
		result = errors.Join(result, err)
	}
	if result == nil {
		delete(f.sets, quantifier)
		delete(f.candidates, quantifier)
		delete(f.nonGround, quantifier)
		delete(f.auf, quantifier)
		delete(f.qinfos, quantifier)
		delete(f.chosen, quantifier)
		delete(f.hint.infos, quantifier)
		delete(f.registered, quantifier)
	}
	return result
}

func (f *SMTModelFinder) macroOccursElsewhere(declaration, except ast.ASTHandle, quantifiers []ast.ASTHandle) bool {
	for _, quantifier := range quantifiers {
		if quantifier == except {
			continue
		}
		if set := f.nonGround[quantifier]; set != nil {
			if found, _ := set.Contains(declaration); found {
				return true
			}
		}
	}
	return false
}

func (f *SMTModelFinder) publishFunctionDefinition(declaration, definition ast.ASTHandle, proto *protomodel.ProtoModel) error {
	interpretation, err := proto.Core().FunctionInterpretation(declaration)
	if err != nil {
		return err
	}
	if interpretation == nil {
		arity, err := f.manager.GetArity(declaration)
		if err != nil {
			return err
		}
		interpretation, err = model.NewFunctionInterpretation(f.manager, arity)
		if err != nil {
			return err
		}
		if err = proto.Core().RegisterFunction(declaration, interpretation); err != nil {
			return errors.Join(err, interpretation.Close())
		}
	}
	return interpretation.SetElse(definition)
}

func (f *SMTModelFinder) processSimpleMacros(proto *protomodel.ProtoModel, quantifiers []ast.ASTHandle) ([]ast.ASTHandle, error) {
	current := append([]ast.ASTHandle(nil), quantifiers...)
	for {
		removed := false
		next := make([]ast.ASTHandle, 0, len(current))
		for _, quantifier := range current {
			selected := false
			candidates := f.candidates[quantifier]
			for i := 0; candidates != nil && i < candidates.Len(); i++ {
				candidate, err := candidates.At(i)
				if err != nil {
					return nil, err
				}
				if !candidate.SatisfyAtom || f.macroOccursElsewhere(candidate.Declaration, quantifier, current) {
					continue
				}
				if err = f.publishFunctionDefinition(candidate.Declaration, candidate.Definition, proto); err != nil {
					return nil, err
				}
				f.chosen[quantifier] = candidate.Declaration
				selected, removed = true, true
				break
			}
			if !selected {
				next = append(next, quantifier)
			}
		}
		if !removed {
			return next, nil
		}
		current = next
	}
}

func (f *SMTModelFinder) processHintMacros(proto *protomodel.ProtoModel, quantifiers []ast.ASTHandle) ([]ast.ASTHandle, error) {
	for {
		plan, found, err := f.hint.planSubset(f.manager, quantifiers)
		if err != nil {
			return quantifiers, err
		}
		if !found {
			// hint_solver::process fills new_qs with the non-candidates,
			// then (search failed) every candidate: candidates move last.
			return plan.remaining, nil
		}
		for _, pair := range plan.definitions {
			if err = f.publishFunctionDefinition(pair.function, pair.definition, proto); err != nil {
				return nil, err
			}
		}
		for _, quantifier := range quantifiers {
			if info := f.hint.infos[quantifier]; info != nil && !info.theOne.IsNull() {
				f.chosen[quantifier] = info.theOne
			}
		}
		if len(plan.remaining) >= len(quantifiers) {
			return nil, ast.ErrASTDomain
		}
		quantifiers = plan.remaining
	}
}

type smtModelFinderFullMacro struct {
	quantifier ast.ASTHandle
	candidate  macros.Candidate
}

func (f *SMTModelFinder) addNonAUFMacro(proto *protomodel.ProtoModel, candidate macros.Candidate) (bool, error) {
	dependencies := ast.NewFuncDeclSet(f.manager)
	if err := f.dependencies.CollectNonGround(candidate.Definition, dependencies); err != nil {
		return false, err
	}
	inserted, err := f.dependencies.Insert(candidate.Declaration, dependencies)
	if err != nil || !inserted {
		return false, err
	}
	if err = f.publishFunctionDefinition(candidate.Declaration, candidate.Definition, proto); err != nil {
		return false, errors.Join(err, f.dependencies.Erase(candidate.Declaration))
	}
	return true, nil
}

// processNonAUFMacros ports non_auf_macro_solver. Full macros are available to
// non-AUF quantifiers and to every quantifier forced by mbqi.force_template;
// remaining conditional definitions are combined into an ordered ITE else.
// The returned AUF input includes survivors from every pass, matching the
// source's final new_qs plus residue sequence, including repeated quantifiers.
func (f *SMTModelFinder) processNonAUFMacros(proto *protomodel.ProtoModel, quantifiers []ast.ASTHandle) ([]ast.ASTHandle, error) {
	current := append([]ast.ASTHandle(nil), quantifiers...)
	var residue []ast.ASTHandle
	for {
		// obj_map<func_decl, mq_pair> full_macros and func_decl_set
		// cond_macros: both are walked in hash-table order.
		full := ast.NewObjMap(f.manager)
		fullMacros := make([]smtModelFinderFullMacro, 0)
		cond := ast.NewObjMap(f.manager)
		for _, quantifier := range current {
			weight, err := f.manager.GetQuantifierWeight(f.flatQuantifier(quantifier))
			if err != nil {
				return nil, err
			}
			forced := weight >= 0 && uint32(weight) >= f.forceTemplate
			candidates := f.candidates[quantifier]
			for i := 0; candidates != nil && i < candidates.Len(); i++ {
				candidate, err := candidates.At(i)
				if err != nil {
					return nil, err
				}
				if candidate.Hint {
					continue
				}
				if f.manager.IsTrue(candidate.Condition) && (!f.auf[quantifier] || forced) {
					fullMacros = append(fullMacros, smtModelFinderFullMacro{quantifier: quantifier, candidate: candidate})
					if err = full.InsertNum(candidate.Declaration, uint64(len(fullMacros)-1)); err != nil {
						return nil, err
					}
					if err = cond.Erase(candidate.Declaration); err != nil {
						return nil, err
					}
					continue
				}
				isFull, err := full.Contains(candidate.Declaration)
				if err != nil {
					return nil, err
				}
				if !isFull && !f.auf[quantifier] {
					if err = cond.Insert(candidate.Declaration, [2]ast.ASTHandle{}); err != nil {
						return nil, err
					}
				}
			}
		}
		removed := make(map[ast.ASTHandle]struct{})
		for _, entry := range full.Entries() {
			declaration := entry.Key
			macro := fullMacros[entry.Num]
			added, err := f.addNonAUFMacro(proto, macro.candidate)
			if err != nil {
				return nil, err
			}
			if added {
				f.chosen[macro.quantifier] = declaration
				removed[macro.quantifier] = struct{}{}
			}
		}
		for _, entry := range cond.Entries() {
			declaration := entry.Key
			var definition ast.ASTHandle
			selected := make([]ast.ASTHandle, 0)
			ignore := false
			for _, quantifier := range current {
				if _, alreadyRemoved := removed[quantifier]; alreadyRemoved {
					continue
				}
				candidates := f.candidates[quantifier]
				var candidate macros.Candidate
				found := false
				for i := 0; candidates != nil && i < candidates.Len(); i++ {
					row, err := candidates.At(i)
					if err != nil {
						return nil, err
					}
					if row.Declaration == declaration && !row.Hint {
						candidate, found = row, true
					}
				}
				if !found {
					continue
				}
				if f.manager.IsTrue(candidate.Condition) {
					ignore = true
					break
				}
				selected = append(selected, quantifier)
				if definition.IsNull() {
					definition = candidate.Definition
				} else {
					next, err := f.manager.MkIte(candidate.Condition, candidate.Definition, definition)
					if err != nil {
						return nil, err
					}
					definition = next
				}
			}
			if ignore || definition.IsNull() {
				continue
			}
			added, err := f.addNonAUFMacro(proto, macros.Candidate{Declaration: declaration, Definition: definition})
			if err != nil {
				return nil, err
			}
			if added {
				for _, quantifier := range selected {
					f.chosen[quantifier] = declaration
					removed[quantifier] = struct{}{}
				}
			}
		}
		next := make([]ast.ASTHandle, 0, len(current)-len(removed))
		for _, quantifier := range current {
			if _, found := removed[quantifier]; !found {
				next = append(next, quantifier)
				// Source non_auf_macro_solver preserves this pass's
				// survivors for AUF, even if a later macro removes them.
				residue = append(residue, quantifier)
			}
		}
		if len(removed) == 0 {
			return append(next, residue...), nil
		}
		current = next
	}
}

func (f *SMTModelFinder) PushScope() error {
	if err := f.open(); err != nil {
		return err
	}
	f.scopes = append(f.scopes, len(f.quantifiers))
	return nil
}

func (f *SMTModelFinder) PopScopes(count uint32) error {
	if err := f.open(); err != nil {
		return err
	}
	if count == 0 || count > uint32(len(f.scopes)) {
		return ast.ErrASTDomain
	}
	level := len(f.scopes) - int(count)
	limit := f.scopes[level]
	for _, quantifier := range f.quantifiers[limit:] {
		if err := f.releaseQuantifier(quantifier); err != nil {
			return err
		}
	}
	f.quantifiers = f.quantifiers[:limit]
	f.scopes = f.scopes[:level]
	return nil
}

func (f *SMTModelFinder) InitSearch() error { return f.open() }

func (f *SMTModelFinder) relevantQuantifiers() ([]ast.ASTHandle, error) {
	if err := f.open(); err != nil {
		return nil, err
	}
	result := make([]ast.ASTHandle, 0, len(f.quantifiers))
	for _, quantifier := range f.quantifiers {
		if f.state.isRelevant(quantifier) && f.state.context.assignments.get(quantifier) == lbool.True {
			result = append(result, quantifier)
		}
	}
	return result, nil
}

// FixModel is the production entry used during candidate-model construction.
// Quantifier-specific macro and AUF passes progressively extend this method.
func (f *SMTModelFinder) FixModel(model *protomodel.ProtoModel) error {
	if err := f.open(); err != nil {
		return err
	}
	if model == nil || model.Core() == nil {
		return ast.ErrASTHandle
	}
	// model_finder::fix_model has no checkpoint on entry; with no relevant
	// quantifiers it returns before any cancellation check, so a resource
	// limit hit during search does not abort mk_proto_model.
	relevant, err := f.relevantQuantifiers()
	if err != nil {
		return err
	}
	if len(relevant) == 0 {
		return nil
	}
	if trialFinder=="lazy" {
 for _,q:=range f.quantifiers {if f.candidates[q]==nil {if e:=f.analyzeRegistration(q);e!=nil{return e}}}
 }
 // cleanup_quantifier_infos: reset_the_one deletes the macro-based sets.
	for _, quantifier := range relevant {
		delete(f.chosen, quantifier)
		if info := f.hint.infos[quantifier]; info != nil {
			info.theOne = ast.ASTHandle{}
		}
		if err := f.closeMacroSets(quantifier); err != nil {
			return err
		}
	}
	if err = f.dependencies.Reset(); err != nil {
		return err
	}
	relevant, err = f.processSimpleMacros(model, relevant)
	if err != nil {
		return err
	}
	relevant, err = f.processHintMacros(model, relevant)
	if err != nil {
		return err
	}
	relevant, err = f.processNonAUFMacros(model, relevant)
	if err != nil {
		return err
	}
	return f.populateAUFInstantiationSets(relevant, model)
}

// closeMacroSets deletes quantifier_info::m_uvar_inst_sets.
func (f *SMTModelFinder) closeMacroSets(quantifier ast.ASTHandle) (result error) {
	sets, found := f.sets[quantifier]
	if !found {
		return nil
	}
	for _, set := range sets {
		if set != nil {
			result = errors.Join(result, set.Close())
		}
	}
	if result == nil {
		delete(f.sets, quantifier)
	}
	return result
}

func (f *SMTModelFinder) Close() error {
	if f == nil {
		return ast.ErrASTHandle
	}
	if f.closed {
		return nil
	}
	if f.manager == nil {
		return ast.ErrASTHandle
	}
	var result error
	for _, quantifier := range f.quantifiers {
		result = errors.Join(result, f.releaseQuantifier(quantifier))
	}
	if result != nil {
		return result
	}
	if err := f.dependencies.Close(); err != nil {
		return err
	}
	for i := range f.pendingConstraints {
		if err := f.manager.DelRef(&f.pendingConstraints[i]); err != nil {
			return err
		}
	}
	f.pendingConstraints = nil
	// ~auf_solver runs as a later member destructor of ~model_finder.
	if err := f.aufSolver.close(); err != nil {
		return err
	}
	f.aufSolver = nil
	f.closed = true
	f.quantifiers = nil
	f.scopes = nil
	f.registered = nil
	f.sets = nil
	f.flat = nil
	f.macroUtil = nil
	f.candidates = nil
	f.nonGround = nil
	f.auf = nil
	f.qinfos = nil
	f.chosen = nil
	f.hint = nil
	f.dependencies = nil
	f.state = nil
	f.manager = nil
	return result
}
