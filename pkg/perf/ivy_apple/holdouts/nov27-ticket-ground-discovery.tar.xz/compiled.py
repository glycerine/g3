from pathlib import Path
import csv,sys,subprocess as sp,os,json
w=Path(__file__).resolve().parent;p=Path.cwd()
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
def measure(cmd,text=None):
 stat=w/'compiled.stat'
 r=sp.run(['taskset','-c','23',perf,'stat','-x,','-e','instructions:u','-o',stat,'--',*cmd],input=text,capture_output=True,timeout=30,check=True,env=dict(os.environ,GOMAXPROCS='1'))
 ins=next(int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
 return r,ins
with (w/'compiled.csv').open('w') as f:
 o=csv.writer(f);o.writerow('batch goal width congruence reduce round variables before after bytes compile engine solve answer'.split())
 for b,g,width in [(15,8,1),(16,1,1),(12,8,2),(13,8,2),(14,8,2),(14,8,3)]:
  path=w/f'8-{b}-{g}.json';data=json.loads(path.read_text());nodes=data['Nodes'];assert all(nodes[i]['Sort']>0 for n in nodes if n.get('Op')=='app' for i in n['A'])
  for congruence in ['unary','all']:
   for reduce in ['reduce','raw']:
    for i in range(3):
     r,ci=measure([w/'ground',path,str(width),congruence,reduce]);n,before,after=r.stderr.decode().strip().split();answers=[]
     for name,exe in [('g3','/tmp/g3-witness-match/g3'),('native',p.parent/'build/z3')]:
      s,si=measure([exe,'-dimacs','-in'],r.stdout);answer=s.stdout.decode().splitlines()[0];answers.append(answer);assert answer in ('unsat','sat')
      o.writerow([b,g,width,congruence,reduce,i,n,before,after,len(r.stdout),ci,name,si,answer]);f.flush()
     assert len(set(answers))==1
