from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'integrated.go').read_text()
s=s.replace('gates     map[int][]int','gates     map[int][]int') # raw spacing varies after formatting
s=s.replace('type compiler struct {','type compiler struct {\n known map[int]bool')
a=s.index('\t\txs := make([]int, len(n.A))');b=s.index('\n\tcase "forall":',a)
s=s[:a]+'''        xs:=make([]int,0,len(n.A))
        sign:=1;if n.Op=="or"{sign=-1}
        for _,a:=range n.A{
            x:=sign*c.eval(a)
            if x == -1 || c.known[-x]{xs=append(xs[:0],-1);break}
            if x!=1 && !c.known[x]{xs=append(xs,x)}
        }
        v=sign*c.conjunction(xs)'''+s[b:]
k='for _, r := range c.q.Roots {\n\t\tc.assert(c.eval(r))'
assert k in s;s=s.replace(k,'''c.known=make(map[int]bool)
 for _,r:=range c.q.Roots{if c.isUnit(r){v:=c.eval(r);c.seed(v)}}
 for _, r := range c.q.Roots {
  if c.isUnit(r){continue}
  c.assert(c.eval(r))''')
i=s.index('func (c *compiler) compile(');s=s[:i]+'''func(c *compiler)isUnit(i int)bool{
 n:=c.q.Nodes[i];switch n.Op{
 case "forall","not":if n.Op=="not" && c.q.Nodes[n.A[0]].Op!="app"{return false};return c.isUnit(n.A[0])
 case "app":return n.Sort==0
 case "=":return c.q.Nodes[n.A[0]].Sort!=0
 };return false
}
func(c *compiler)seed(v int){
 if xs:=c.gates[v];xs!=nil{for _,x:=range xs{c.seed(x)};return}
 c.clauses=append(c.clauses,[]int{v});c.known[v]=true
}
'''+s[i:]
(w/'early.go').write_text(s)
