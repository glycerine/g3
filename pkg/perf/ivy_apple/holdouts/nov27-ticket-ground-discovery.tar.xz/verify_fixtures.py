"""Rebuild the Go encoder and replay all 45 finite abstractions using two SAT shells."""
import argparse
import csv
import json
from pathlib import Path
import subprocess
import tempfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('g3',type=Path)
parser.add_argument('z3',type=Path)
args=parser.parse_args()
here=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as tmp:
    binary=Path(tmp)/'polar'
    subprocess.run(['go','build','-o',binary,here/'polar.go'],check=True)
    cases={r['case']:r for r in csv.DictReader((here/'screen.csv').open())}
    for case,expected in cases.items():
        ir=json.loads((here/(case+'.json')).read_text())
        ir['Domains']=ir['Seeds']['fresh']
        path=Path(tmp)/'query.json'
        path.write_text(json.dumps(ir))
        encoded=subprocess.run([binary,path,'1','unary','reduce'],capture_output=True,check=True)
        for shell in (args.g3,args.z3):
            proc=subprocess.run([shell.resolve(),'-dimacs','-in'],input=encoded.stdout,
                                capture_output=True,check=True,timeout=30)
            answer=proc.stdout.splitlines()[0].decode()
            if answer!={'satisfiable':'sat','unsatisfiable':'unsat'}[expected['answer']]:
                raise RuntimeError((case,shell,answer))
    print('Replayed',len(cases),'abstractions with both SAT shells.')
