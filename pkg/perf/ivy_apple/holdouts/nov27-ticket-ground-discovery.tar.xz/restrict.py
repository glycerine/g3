"""Weaken only positive universal and negative existential binders under monotone contexts."""
from pathlib import Path
import csv,itertools,os,re,sys,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent
d=Path('/tmp/g3-repeat-qi');sys.path.insert(0,str(d))
from split import generate,parse,smt,expand
def partitions(names,width):
    if len(names)<=width:return [(names,{})]
    # Any assignment using at most width distinct values refines at least one such partition.
    out=[]
    def more(groups,env,i):
        if i==len(names):
            if len(groups)==width:out.append((groups,env))
            return
        for g in groups:more(groups,dict(env,**{names[i]:g}),i+1)
        if len(groups)<width:more(groups+[names[i]],env,i+1)
    more([],{},0);return out
def restrict(t,positive,width,env,changes):
    if isinstance(t,str):return env.get(t,t)
    op=t[0]
    if op in ('forall','exists'):
        binds=t[1];local={n:v for n,v in env.items() if n not in dict(binds)}
        # Substitution values are globally fresh binder names, so nested binders cannot capture them.
        if (op=='forall' and positive==1) or (op=='exists' and positive==-1):
            sorts={}
            for n,s in binds:sorts.setdefault(s,[]).append(n)
            if any(len(ns)>width for ns in sorts.values()):
                changes[0]+=1;rows=[]
                for choices in itertools.product(*(partitions(ns,width) for ns in sorts.values())):
                    keep=set();sub=local.copy()
                    for ns,m in choices:keep.update(ns);sub.update(m)
                    rows.append((op,tuple(b for b in binds if b[0] in keep),restrict(t[2],positive,width,sub,changes)))
                return rows[0] if len(rows)==1 else ('and' if op=='forall' else 'or',*rows)
        return (op,binds,restrict(t[2],positive,width,local,changes))
    if op=='!':return restrict(t[1],positive,width,env,changes)
    return (op,*(restrict(c,positive if op in ('and','or') or op=='=>' and i==len(t)-1 or op=='ite' and i>1 else -positive if op in ('not','=>') else 0,width,env,changes) for i,c in enumerate(t[1:],1)))
def rename(t,env,gen):
    if isinstance(t,str):return env.get(t,t)
    op=t[0]
    if op in ('forall','exists'):
        binds=tuple((next(gen),s) for n,s in t[1])
        return (op,binds,rename(t[2],dict(env,**{n:new for (n,s),(new,_) in zip(t[1],binds)}),gen))
    if op=='!':return rename(t[1],env,gen)
    return (op,*(rename(c,env,gen) for c in t[1:]))
def scripts(path,width):
    from syntax import fresh_names
    forms=parse(path.read_text());gen=fresh_names(forms,'diag!');changes=[0]
    base,goal=[rename(expand(f[1],{}),{},gen) for f in forms if f[0]=='assert']
    decl=[f for f in forms if f[0].startswith('declare-')]
    a,b=(restrict(x,1,width,{},changes) for x in (base,goal))
    def script(base,goal):return '\n'.join(map(smt,[*decl,('assert',base),('push',),('assert',goal),('check-sat',),('get-info',':all-statistics')]))
    return changes[0],{'renamed':script(base,goal),'weak':script(a,b)}
if __name__=='__main__':
 perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
 with (w/'restrict.csv').open('w') as f:
    out=csv.writer(f);out.writerow('goal width mode changes engine answer instructions instances decisions'.split())
    for path in sorted((d/'captures').glob('*.smt2')):
        for width in [1,2]:
            n,variants=scripts(path,width)
            for mode,text in variants.items():
                if width==2 and mode=='renamed':continue
                for name,exe in [('g3','/tmp/g3-witness-match/g3'),('native',p.parent/'build/z3')]:
                    stat=w/'restrict.stat';r=sp.run(['taskset','-c','27',perf,'stat','-x,','-o',stat,'-e','instructions:u','--',exe,'smt.macro_finder=true','-T:2','-in'],input=text,capture_output=True,text=True,timeout=8,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'))
                    answer=r.stdout.splitlines()[0];assert answer in ('sat','unsat','unknown','timeout'),(r.stdout[:300],r.stderr[:300])
                    if mode=='renamed':assert answer=='unsat'
                    a=dict(re.findall(r':([\w-]+)\s+(\d+)',r.stdout));ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
                    out.writerow([path.stem,width,mode,n,name,answer,ins,a.get('quant-instantiations',0),a.get('decisions',0)]);f.flush()
