from pathlib import Path
import csv,os,subprocess as sp,sys
w=Path(__file__).resolve().parent
modes=[('1','unary','fresh'),('1','unary','fresh-apps'),('1','unary','source-apps'),('1','unary','full'),('2','all','fresh'),('2','all','fresh-apps'),('2','all','source-apps'),('2','all','full'),('3','all','full')]
files=list(sys.argv[1:]) or [f'8-{b}-{g}' for b,g in [(15,8),(16,1),(12,8),(13,8),(14,8)]]
with (w/(os.getenv('STEM','integrated')+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round width congruence seed answer variables clauses compile reduce solve'.split())
 for k in files:
  for i in range(int(os.getenv('ROUNDS','3'))):
   for width,policy,seed in modes[i:]+modes[:i]:
    rr=sp.run(['taskset','-c','30',w/os.getenv('EXE','integrated'),w/(k+'.json'),width,policy,seed],capture_output=True,text=True,timeout=30,env=dict(os.environ,GOMAXPROCS='1',GOGC=os.getenv('GOGC','100')))
    assert rr.returncode==0,(rr.stderr,k);out.writerow([k,i,width,policy,seed,*rr.stdout.split()]);f.flush()
