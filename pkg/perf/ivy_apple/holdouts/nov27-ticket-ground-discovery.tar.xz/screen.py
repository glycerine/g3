from pathlib import Path
import csv,subprocess as sp,os,sys
from ir import emit,previous,w
from hints import expand,conjuncts
from syntax import parse,smt
paths=sorted((previous/'captures').glob('*.smt2'))
positive=list(paths)
for i,r in enumerate([r for r in csv.DictReader((previous/'intersections.csv').open()) if r['result']=='sat'][:10]):
 def rows(b,g):
  src=parse((previous/'captures'/f'8-{b}-{g}.smt2').read_text());base,goal=[expand(x[1],{}) for x in src if x[0]=='assert'];return [x for x in src if x[0].startswith('declare')],list(dict.fromkeys(conjuncts(base))),goal
 decl,a,goal=rows(r['batch'],r['goal']);_,b,g=rows(r['prior_batch'],r['prior_goal']);assert goal==g
 path=w/f'common-{i}.smt2';path.write_text('\n'.join(map(smt,decl+[('assert',x) for x in a if x in b]+[('assert',goal),('check-sat',)])))
 for exe in [Path.cwd().parent/'build/z3','/tmp/g3-witness-match/g3']:
  rr=sp.run([exe,'smt.macro_finder=true',path],capture_output=True,text=True,timeout=15,check=True);assert rr.stdout.strip()=='sat'
 paths.append(path)
with (w/'screen.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case expected round answer variables clauses compile reduce solve'.split())
 for path in paths:
  emit(path)
  for i in range(3):
   rr=sp.run(['taskset','-c','30',w/'integrated',w/(path.stem+'.json'),'1','unary','fresh'],capture_output=True,text=True,env=dict(os.environ,GOMAXPROCS='1'),timeout=10,check=True)
   if path not in positive:assert rr.stdout.startswith('satisfiable '),rr.stdout
   o.writerow([path.stem,'unsat' if path in positive else 'sat',i,*rr.stdout.split()]);f.flush()
