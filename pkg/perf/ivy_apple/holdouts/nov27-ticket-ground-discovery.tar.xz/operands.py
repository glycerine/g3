from pathlib import Path
import subprocess as sp,json,os,tempfile
w=Path(__file__).resolve().parent;p=Path.cwd();base=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
def put(name,s):
 f=w/name;f.write_text(s);base['Replace'][str(p/'smtcore'/name)]=str(f)
name='smt_enode_core.go';s=(p/'smtcore'/name).read_text().replace('header   ast.ASTNodeHeader','boolean bool\n header   ast.ASTNodeHeader',1).replace('header = term.header','header, boolean = term.header,term.boolean',1);put(name,s)
name='smt_internalizer.go';s=(p/'smtcore'/name).read_text().replace('import (','import ("os";',1)
s=s.replace('func (s *SMTInternalizerState) internalizeFormulaCoreOp(','''var operandTrial=os.Getenv("OPERAND_TRIAL")
func (s *SMTInternalizerState) internalizeFormulaCoreOp(''')
i=s.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp');head,tail=s[:i],s[i:]
tail=tail.replace('for index := uint32(0); index < count; index++ {','''var inputs *smtTermInputs
 if (operandTrial=="predicate" || operandTrial=="both") && knownBoolean && !isGate && count>0 && count<=2 && !ast.ASTValidateHandles && !smtcoreSourceDebug && !ast.ASTSourceDebug && s.manager.TraceStream==nil && !s.manager.Budget().InjectionArmed() {
   children,ok,e:=s.existingTermChildren(expression,count);if e!=nil{return e}
   if ok{ inputs=&smtTermInputs{header:*header,boolean:true,children:children} }
 }
 for index := uint32(0); inputs==nil && index < count; index++ {''',1)
tail=tail.replace('if _, err = s.attachBooleanEnode(expression, variable, isGate, !gateContext, true); err != nil {','''if inputs!=nil {
   if _,err=s.mkEnode(expression,false,!gateContext,true,inputs);err!=nil{return err}
   s.setEnodeFlag(variable,s.booleanData[variable].InternalLevel()==s.scopeLevel)
  }else if _, err = s.attachBooleanEnode(expression, variable, isGate, !gateContext, true); err != nil {''',1)
put(name,head+tail)
name='smt_internalizer_state.go';s=(p/'smtcore'/name).read_text();i=s.index('func (s *SMTInternalizerState) Literal(');head,tail=s[:i],s[i:]
k='header, err := s.manager.NodeHeader(expression)';tail=tail.replace(k,'''if operandTrial=="literal" || operandTrial=="both" {
 if v,found:=s.boolVar.lookup(expression);found && s.notChild(v).IsNull(){return NewSMTLiteral(v,false),nil}
 }
 '''+k,1);put(name,head+tail)
j=w/'operands.json';j.write_text(json.dumps(base));front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
with tempfile.TemporaryDirectory(dir=Path.home()/'tmp') as t:
 sp.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'operands','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=t,GOTMPDIR=t),check=True)
