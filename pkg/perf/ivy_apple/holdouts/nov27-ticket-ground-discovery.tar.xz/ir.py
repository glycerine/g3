"""Emit binder-aware numeric rule DAGs for the standalone Go experiment."""
from pathlib import Path
import collections,json,sys,itertools
w=Path(__file__).resolve().parent
from discover import normalize,previous
def emit(path):
    decl,rules,pool=normalize(path)
    sorts={'Bool':0}
    syms={}
    for f in decl:
        if f[0]=='declare-sort':sorts[f[1]]=len(sorts)
        if f[0]=='declare-fun':syms[f[1],tuple(sorts[s] for s in f[2])]=(len(syms)+1,sorts[f[3]])
    nodes=[{}];ids={};slotSort=[];deps=[set()]
    def node(op,sort,children=(),bind=(),sym=0,slot=0):
        key=op,sort,tuple(children),tuple(bind),sym,slot
        if key in ids:return ids[key]
        i=len(nodes);ids[key]=i
        dep=set.union(set(),*(deps[c] for c in children))-set(bind)
        if op=='v':dep={slot}
        nodes.append(dict(Op=op,Sort=sort,A=children,B=bind,Sym=sym,Slot=slot,D=sorted(dep)));deps.append(dep);return i
    def visit(t,env):
        if isinstance(t,str):
            if t in env:return env[t]
            if t in ('true','false'):return node(t,0)
            sym,sort=syms[t,()];return node('app',sort,sym=sym)
        op=t[0]
        if op=='!':return visit(t[1],env)
        if op=='forall':
            new=env.copy();slots=[]
            for n,st in t[1]:
                slot=len(slotSort);slotSort.append(sorts[st]);slots.append(slot);new[n]=node('v',sorts[st],slot=slot)
            return node('forall',0,[visit(t[2],new)],slots)
        kids=[visit(c,env) for c in t[1:]]
        if op in ('and','or','not','='):return node(op,0,kids)
        sym,sort=syms[op,tuple(nodes[k]['Sort'] for k in kids)];return node('app',sort,kids,sym=sym)
    roots=[visit(r,{}) for r in rules];domains=[[] for s in sorts]
    for st,terms in pool.items():domains[sorts[st]]=[visit(t,{}) for t in terms]
    from syntax import parse
    originals={row[1] for row in parse(path.read_text()) if row[0]=='declare-fun'}
    seeds={}
    for mode in ('full','fresh','fresh-apps','source-apps'):
        ds=[[] for _ in sorts]
        for st,ts in pool.items():
            for t in ts:
                if isinstance(t,str):
                    keep=mode!='fresh' or t not in originals
                else:
                    keep=mode=='full' or all((v in originals)==(mode=='source-apps') for v in t[1:])
                if keep:ds[sorts[st]].append(visit(t,{}))
        seeds[mode]=ds
    aliases=[n['A'] for i in roots for n in [nodes[i]] if n['Op']=='=' and all(nodes[c]['Op']=='app' and not nodes[c]['A'] and nodes[c]['Sort'] for c in n['A'])]
    assert max(map(len,deps))<=4 and max(len(n.get('A',())) for n in nodes if n.get('Op')=='app')<=3
    out=w/(path.stem+'.json');out.write_text(json.dumps(dict(Nodes=nodes,Roots=roots,Domains=domains,Sorts=slotSort,Aliases=aliases,Seeds=seeds)))
if __name__=='__main__':
 for b,g in [(15,8),(16,1),(12,8),(13,8),(14,8)]:emit(previous/'captures'/f'8-{b}-{g}.smt2')
