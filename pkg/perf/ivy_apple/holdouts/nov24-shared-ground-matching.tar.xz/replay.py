"""Run the shared ground matcher history checks from the unpacked study."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--pkg", type=Path, required=True, help="g3 module checkout")
parser.add_argument("--output", type=Path, required=True, help="new temporary directory")
parser.add_argument("--mode", choices=["base", "trigger", "flat"], default="trigger")
parser.add_argument("--all", action="store_true", help="exercise all configurations")
args = parser.parse_args()
source = Path(__file__).resolve().parent
pkg = args.pkg.resolve(strict=True)
out = args.output.resolve()
out.mkdir(parents=True)
originals = json.loads((source / "manifest.json").read_text())[args.mode]
paths = {}
for name in originals:
    original = pkg / name
    local = out / "g3" / "pkg" / name
    local.parent.mkdir(parents=True, exist_ok=True)
    if original.is_file():
        shutil.copyfile(original, local)
    paths[str(original)] = str(local)
patch = source / "overlays" / (args.mode + "-api.patch")
subprocess.run(["patch", "-p1", "--batch", "--fuzz=0", "-i", patch], cwd=out, check=True)
overlay = out / "overlay.json"
overlay.write_text(json.dumps({"Replace": paths}))
binary = out / "api.test"
subprocess.run(["go", "test", "-pgo=off", "-tags=xtrace_off", "-overlay=" + str(overlay),
                "-c", "-o", binary, "./api"], cwd=pkg, check=True)

if args.mode == "base":
    configs = [(b, g, s, "0", "repeat", "0", "no") for b in ("ground", "signed")
               for g in ("direct", "nnf") for s in ("unit", "dpll")]
elif args.mode == "trigger":
    configs = [(b, "nnf", "unit", cap, u, "0", "no") for b in ("ground", "signed")
               for cap in ("0", "4", "16", "64") for u in ("repeat", "cache")]
else:
    configs = [("ground", "nnf", s, cap, "cache", f, w) for f, w in (("0", "yes"), ("1", "no"), ("1", "yes"))
               for cap in ("0", "4", "16", "64") for s in ("unit", "dpll")]
for base, goal, search, cap, units, flat, witness in configs if args.all else [configs[-1]]:
    env = dict(os.environ, GOMAXPROCS="1", SHARED_BASE=base, SHARED_GOAL=goal,
               SHARED_SEARCH=search, SHARED_TRIGGER=cap, SHARED_UNITS=units,
               FLAT_AST=flat, FLAT_WITNESS=witness, GROUND_CAP="2500",
               GROUND_POLICY="canon-memo", GROUND_DOMAIN="seen", SIGNED_MATCH="unit-observed")
    subprocess.run([binary, "-test.cpu=1", "-test.run=^(TestStudyShared|TestSharedGroundAgainstFiniteTables)",
                    "-test.count=1"], cwd=pkg / "api", env=env, check=True)
