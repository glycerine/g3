package main

import (
	"fmt"
	"math/rand"
	"slices"
	"strings"
)

func abs(x int32) int32 {
	if x < 0 {
		return -x
	}
	return x
}

// A bounded chronological search over the private residual CNF. Every conflict
// requires either a falsified clause or conflicts on both signs of a variable.
type trialDPLL struct {
	rows                                        [][]int32
	watch                                       [][]int
	values                                      []int8
	trail                                       []int32
	queue                                       int
	scores                                      []int
	visits, decisions, workLimit, decisionLimit int
	firstPositive                               bool
}

func trialLiteralIndex(x int32) int {
	if x < 0 {
		return int(-2*x + 1)
	}
	return int(2 * x)
}
func (p *trialDPLL) value(x int32) int8 {
	if x < 0 {
		return -p.values[-x]
	}
	return p.values[x]
}
func (p *trialDPLL) set(x int32) bool {
	if v := p.value(x); v != 0 {
		return v > 0
	}
	if x < 0 {
		p.values[-x] = -1
	} else {
		p.values[x] = 1
	}
	p.trail = append(p.trail, x)
	return true
}
func (p *trialDPLL) unit() int {
	for p.queue < len(p.trail) {
		lit := -p.trail[p.queue]
		p.queue++
		id := trialLiteralIndex(lit)
		ws := p.watch[id]
		dst := ws[:0]
		for j, ri := range ws {
			p.visits++
			cl := p.rows[ri]
			if cl[0] == lit {
				cl[0], cl[1] = cl[1], cl[0]
			}
			other := cl[0]
			if p.value(other) > 0 {
				dst = append(dst, ri)
				continue
			}
			moved := false
			for k := 2; k < len(cl); k++ {
				p.visits++
				if p.value(cl[k]) >= 0 {
					cl[k], cl[1] = cl[1], cl[k]
					to := trialLiteralIndex(cl[1])
					p.watch[to] = append(p.watch[to], ri)
					moved = true
					break
				}
			}
			if moved {
				continue
			}
			dst = append(dst, ri)
			if !p.set(other) {
				p.watch[id] = append(dst, ws[j+1:]...)
				return -1
			}
		}
		p.watch[id] = dst
		if p.visits >= p.workLimit {
			return 0
		}
	}
	return 1
}
func (p *trialDPLL) undo(mark int) {
	for _, l := range p.trail[mark:] {
		p.values[abs(l)] = 0
	}
	p.trail = p.trail[:mark]
	p.queue = mark
}
func (p *trialDPLL) search() bool {
	switch p.unit() {
	case -1:
		return true
	case 0:
		return false
	}
	if p.decisions >= p.decisionLimit || p.visits >= p.workLimit {
		return false
	}
	clear(p.scores)
	var best int32
	high := 0
	for _, cl := range p.rows {
		open := 0
		sat := false
		for _, l := range cl {
			v := p.value(l)
			if v > 0 {
				sat = true
				break
			}
			if v == 0 {
				open++
			}
		}
		p.visits += len(cl)
		if p.visits > p.workLimit {
			return false
		}
		if sat {
			continue
		}
		if open == 0 {
			return true
		}
		weight := 1 << max(0, 8-min(8, open))
		for _, l := range cl {
			if p.value(l) == 0 {
				idx := trialLiteralIndex(l)
				p.scores[idx] += weight
			}
		}
	}
	for i := int32(2); int(i) < len(p.values); i++ {
		a, b := p.scores[2*i], p.scores[2*i+1]
		wt := (a + b) + min(a, b)*8
		if wt > high {
			high = wt
			best = i
			if a < b {
				best = -best
			}
		}
	}
	if best == 0 {
		return false
	}
	p.decisions++
	m := len(p.trail)
	if !p.firstPositive {
		best = -best
	}
	p.set(best)
	conflict := p.search()
	p.undo(m)
	if !conflict {
		return false
	}
	p.set(-best)
	conflict = p.search()
	p.undo(m)
	return conflict
}
func trialRefute(rows [][]int32, vars int32, options string) (bool, int, int) {
	p := trialDPLL{rows: rows, watch: make([][]int, 2*(vars+1)), values: make([]int8, vars+1), scores: make([]int, 2*(vars+1)), workLimit: 1000000, decisionLimit: 64}
	if strings.Contains(options, "long") {
		p.workLimit = 12000000
		p.decisionLimit = 512
	}
	if strings.Contains(options, "flip") {
		p.firstPositive = true
	}
	for i, r := range rows {
		switch len(r) {
		case 0:
			return true, 0, 0
		case 1:
			if !p.set(r[0]) {
				return true, 0, 0
			}
		default:
			for _, l := range r[:2] {
				id := trialLiteralIndex(l)
				p.watch[id] = append(p.watch[id], i)
			}
		}
	}
	yes := p.search()
	return yes, p.visits, p.decisions
}

func main() {
	r := rand.New(rand.NewSource(724))
	var models, contradictions, proved, withUnit, withEmpty int
	for i := 0; i < 12000; i++ {
		n := 1 + r.Intn(10)
		cls := make([][]int32, r.Intn(8*n+1))
		for j := range cls {
			m := 1 + r.Intn(min(n, 5))
			if i%17 == 0 && j == 0 {
				m = 0
				withEmpty++
			}
			var cl []int32
			for len(cl) < m {
				x := int32(2 + r.Intn(n))
				if slices.Contains(cl, x) || slices.Contains(cl, -x) {
					continue
				}
				if r.Intn(2) == 0 {
					x = -x
				}
				cl = append(cl, x)
			}
			if len(cl) == 1 {
				withUnit++
			}
			cls[j] = cl
		}
		isSat := false
		for model := 0; model < (1<<n) && !isSat; model++ {
			ok := true
			for _, cl := range cls {
				found := false
				for _, x := range cl {
					v := model&(1<<(abs(x)-2)) != 0
					if (x > 0) == v {
						found = true
						break
					}
				}
				if !found {
					ok = false
					break
				}
			}
			isSat = ok
		}
		if isSat {
			models++
		} else {
			contradictions++
		}
		for _, mode := range []string{"short", "short-flip", "long", "long-flip"} {
			copyRows := make([][]int32, len(cls))
			for j, r := range cls {
				copyRows[j] = slices.Clone(r)
			}
			refuted, _, _ := trialRefute(copyRows, int32(n+1), mode)
			if refuted {
				proved++
				if isSat {
					panic(fmt.Sprint(i, mode, cls))
				}
			}
		}
	}
	fmt.Println("formulas SAT UNSAT searches proved units empty")
	fmt.Println(12000, models, contradictions, 48000, proved, withUnit, withEmpty)
}
