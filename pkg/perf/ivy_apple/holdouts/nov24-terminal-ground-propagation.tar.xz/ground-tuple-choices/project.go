package main

import (
	"encoding/binary"
	"math/bits"
	"os"
	"slices"
	"strconv"
	"strings"

	"github.com/glycerine/g3/pkg/api"
	"github.com/glycerine/g3/pkg/ast"
	nf "github.com/glycerine/g3/pkg/ast/normal_forms"
)

// A source node is an arena term, a de Bruijn variable, or a universal binder.
// Grounding owns a finite list of terms per sort. A missing universal instance
// weakens a positive formula, so quantifiers in opaque contexts are rejected.
type pattern struct {
	op          uint32
	sort        int32
	args        []int32
	binds       []int32
	index       int
	open, quant bool
}
type groundKey struct {
	op      uint32
	n       uint32
	a, b, c int32
}
type jointSlot struct {
	a, b int
	key  [3]int32
}
type project struct {
	tupleMode                         string
	joint                             map[int32][]jointSlot
	observed                          map[[3]int32]map[[2]int32]bool
	tupleChecks                       int
	positions                         map[[2]int32][][2]int32
	choices                           map[[2]int32][]int32
	weighted                          bool
	alias, canon, memo, preferWitness bool
	reps                              []int32
	mask                              []uint64
	cached                            map[[4]int32]int32
	graph
	m                              *ast.ASTManager
	nodes                          []pattern
	compiled                       map[ast.ASTHandle]int32
	declarations                   map[ast.ASTHandle]uint32
	source                         map[ast.ASTHandle]int
	sorts                          map[ast.ASTHandle]int32
	opSort                         []int32
	spell                          map[string]uint32
	witnesses                      []bool
	use                            []int
	templates                      []int32
	domains                        [][]int32
	counted                        []int
	freq                           []int
	termSort                       []int32
	fixed                          map[groundKey]int32
	long                           map[string]int32
	shortCache                     []int32
	rootSet                        map[int32]bool
	tuples, visits, universalCount int
	boolSort                       int32
	t, f                           int32
}

func (p *project) sort(h ast.ASTHandle) int32 {
	if v, ok := p.sorts[h]; ok {
		return v
	}
	i := int32(len(p.sorts))
	p.sorts[h] = i
	return i
}
func (p *project) addOp(name string, sort int32, b, decl, wit bool, uses int) uint32 {
	opID := uint32(len(p.ops))
	p.ops = append(p.ops, op{name, b, decl})
	p.opSort = append(p.opSort, sort)
	p.witnesses = append(p.witnesses, wit)
	p.use = append(p.use, uses)
	return opID
}
func (p *project) init(m *ast.ASTManager) {
	pattern := os.Getenv("GROUND_POLICY")
	p.alias = strings.Contains(pattern, "alias") || strings.Contains(pattern, "canon")
	p.canon = strings.Contains(pattern, "canon")
	p.memo = strings.Contains(pattern, "memo")
	p.preferWitness = strings.Contains(pattern, "witness")
	p.cached = map[[4]int32]int32{}
	p.weighted = strings.Contains(pattern, "weighted")
	p.m = m
	p.compiled = map[ast.ASTHandle]int32{}
	p.declarations = map[ast.ASTHandle]uint32{}
	p.source = map[ast.ASTHandle]int{}
	p.sorts = map[ast.ASTHandle]int32{}
	p.spell = map[string]uint32{}
	p.fixed = map[groundKey]int32{}
	p.long = map[string]int32{}
	p.rootSet = map[int32]bool{}
	bs, e := m.MkTrue()
	must(e)
	sh, e := m.GetSort(bs)
	must(e)
	p.boolSort = p.sort(sh)
	for _, n := range []string{"true", "false", "and", "or", "not", "="} {
		p.spell[n] = p.addOp(n, p.boolSort, true, false, false, 0)
	}
	p.t = p.intern(p.spell["true"], nil)
	p.f = p.intern(p.spell["false"], nil)
}
func (p *project) sourceUses(h ast.ASTHandle, seen map[ast.ASTHandle]bool) {
	type source struct {
		decl     ast.ASTHandle
		children []int
	}
	memo := map[ast.ASTHandle]int{}
	var nodes []source
	var build func(ast.ASTHandle) int
	build = func(h ast.ASTHandle) int {
		if i, ok := memo[h]; ok {
			return i
		}
		m := p.m
		k, e := m.GetKind(h)
		must(e)
		var n source
		if k == ast.ASTQuantifier {
			b, e := m.GetQuantifierBody(h)
			must(e)
			n.children = []int{build(b)}
		}
		if k == ast.ASTApp {
			n.decl, e = m.GetDecl(h)
			must(e)
			a, e := m.GetNumArgs(h)
			must(e)
			for i := uint32(0); i < a; i++ {
				x, e := m.GetArg(h, i)
				must(e)
				n.children = append(n.children, build(x))
			}
		}
		i := len(nodes)
		memo[h] = i
		nodes = append(nodes, n)
		return i
	}
	root := build(h)
	count := make([]int, len(nodes))
	count[root] = 1
	for i := len(nodes) - 1; i >= 0; i-- {
		n := nodes[i]
		if !n.decl.IsNull() {
			p.source[n.decl] = min(1<<28, p.source[n.decl]+count[i])
		}
		for _, j := range n.children {
			cnt := 1
			if p.weighted {
				cnt = count[i]
			}
			count[j] = min(1<<28, count[j]+cnt)
		}
	}
}
func (p *project) compile(h ast.ASTHandle) int32 {
	if id, ok := p.compiled[h]; ok {
		return id
	}
	m := p.m
	k, e := m.GetKind(h)
	must(e)
	sh, e := m.GetSort(h)
	must(e)
	n := pattern{sort: p.sort(sh), index: -1}
	switch k {
	case ast.ASTVar:
		v, e := m.GetVarIndex(h)
		must(e)
		n.index = int(v)
		n.open = true
	case ast.ASTQuantifier:
		b, e := m.IsForall(h)
		must(e)
		if !b || n.sort != p.boolSort {
			panic("unsupported binder")
		}
		n.open = true
		n.quant = true
		count, e := m.GetNumDeclarations(h)
		must(e)
		for i := uint32(0); i < count; i++ {
			s, e := m.GetDeclarationSort(h, i)
			must(e)
			n.binds = append(n.binds, p.sort(s))
		}
		a, e := m.GetQuantifierBody(h)
		must(e)
		n.args = []int32{p.compile(a)}
		p.universalCount++
	case ast.ASTApp:
		decl, e := m.GetDecl(h)
		must(e)
		id, ok := p.declarations[decl]
		if !ok {
			fam, e := m.GetFamilyID(decl)
			must(e)
			name := "term"
			recognized := false
			if fam == m.BasicFamilyID() {
				kind, e := m.GetDeclKind(decl)
				must(e)
				switch kind {
				case ast.ASTOpTrue:
					name = "true"
				case ast.ASTOpFalse:
					name = "false"
				case ast.ASTOpAnd:
					name = "and"
				case ast.ASTOpOr:
					name = "or"
				case ast.ASTOpImplies:
					name = "=>"
				case ast.ASTOpNot:
					name = "not"
				case ast.ASTOpIff, ast.ASTOpEq:
					name = "="
				case ast.ASTOpXor:
					name = "xor"
				case ast.ASTOpDistinct:
					name = "distinct"
				case ast.ASTOpIte:
					name = "ite"
				}
				recognized = name != "term"
			}
			if canon, ok := p.spell[name]; ok {
				id = canon
			} else {
				id = p.addOp(name, n.sort, n.sort == p.boolSort, !recognized, p.source[decl] == 0, p.source[decl])
			}
			p.declarations[decl] = id
		}
		n.op = id
		size, e := m.GetNumArgs(h)
		must(e)
		for i := uint32(0); i < size; i++ {
			child, e := m.GetArg(h, i)
			must(e)
			x := p.compile(child)
			n.args = append(n.args, x)
			n.open = n.open || p.nodes[x].open
			n.quant = n.quant || p.nodes[x].quant
		}
		if n.quant && p.ops[id].Name != "and" && p.ops[id].Name != "or" {
			panic("unsupported binder polarity")
		}
	default:
		panic("unexpected AST kind")
	}
	id := int32(len(p.nodes))
	p.compiled[h] = id
	var mask uint64
	if n.index >= 0 {
		if n.index < 63 {
			mask = uint64(1) << n.index
		} else {
			mask = ^uint64(0)
		}
	} else if n.binds == nil {
		for _, i := range n.args {
			mask |= p.mask[i]
		}
	}
	p.mask = append(p.mask, mask)
	p.nodes = append(p.nodes, n)
	p.shortCache = append(p.shortCache, -1)
	return id
}
func (p *project) intern(op uint32, args []int32) int32 {
	var k groundKey
	var long string
	if len(args) <= 3 {
		k.op = op
		k.n = uint32(len(args))
		switch len(args) {
		case 3:
			k.c = args[2]
			fallthrough
		case 2:
			k.b = args[1]
			fallthrough
		case 1:
			k.a = args[0]
		}
		if id, ok := p.fixed[k]; ok {
			return id
		}
	} else {
		raw := make([]byte, 4*(len(args)+1))
		binary.LittleEndian.PutUint32(raw, op)
		for i, v := range args {
			binary.LittleEndian.PutUint32(raw[4*(i+1):], uint32(v))
		}
		long = string(raw)
		if id, ok := p.long[long]; ok {
			return id
		}
	}
	if len(p.terms) >= 180000 {
		panic("ground term limit")
	}
	id := int32(len(p.terms))
	p.terms = append(p.terms, node{op, slices.Clone(args)})
	p.termSort = append(p.termSort, p.opSort[op])
	p.freq = append(p.freq, 0)
	if len(args) <= 3 {
		p.fixed[k] = id
	} else {
		p.long[long] = id
	}
	return id
}
func (p *project) app(op uint32, args []int32) int32 {
	switch p.ops[op].Name {
	case "=":
		if len(args) == 2 && args[0] == args[1] {
			return p.t
		}
	case "not":
		if args[0] == p.t {
			return p.f
		}
		if args[0] == p.f {
			return p.t
		}
		a := p.terms[args[0]]
		if p.ops[a.op].Name == "not" {
			return a.args[0]
		}
	case "ite":
		if args[0] == p.t || args[1] == args[2] {
			return args[1]
		}
		if args[0] == p.f {
			return args[2]
		}
	case "and", "or":
		unit, absorb := p.t, p.f
		if p.ops[op].Name == "or" {
			unit, absorb = absorb, unit
		}
		v := args[:0]
		for _, a := range args {
			if a == absorb {
				return absorb
			}
			if a != unit {
				v = append(v, a)
			}
		}
		args = v
		if len(args) == 0 {
			return unit
		}
		if len(args) == 1 {
			return args[0]
		}
	}
	return p.intern(op, args)
}
func (p *project) split(n int32) {
	x := p.nodes[n]
	if x.index < 0 && x.binds == nil && p.ops[x.op].Name == "and" {
		for _, a := range x.args {
			p.split(a)
		}
		return
	}
	p.templates = append(p.templates, n)
}
func (p *project) domain(k int) {
	p.domains = make([][]int32, len(p.sorts))
	p.domains[p.boolSort] = []int32{p.t, p.f}
	type entry struct {
		term int32
		rank int
	}
	orig := make([][]entry, len(p.sorts))
	sk := make([][]entry, len(p.sorts))
	for i, n := range p.nodes {
		if n.index >= 0 || n.open || len(n.args) != 0 || n.sort == p.boolSort {
			continue
		}
		id := p.intern(n.op, nil)
		p.shortCache[i] = id
		x := entry{id, p.use[n.op]}
		if p.witnesses[n.op] {
			sk[n.sort] = append(sk[n.sort], x)
		} else {
			orig[n.sort] = append(orig[n.sort], x)
		}
	}
	p.reps = make([]int32, len(p.terms))
	for i := range p.reps {
		p.reps[i] = int32(i)
	}
	if p.alias {
		for _, id := range p.templates {
			n := p.nodes[id]
			if n.open || p.ops[n.op].Name != "=" || len(n.args) != 2 {
				continue
			}
			x, y := n.args[0], n.args[1]
			if p.nodes[x].sort == p.boolSort || p.shortCache[x] < 0 || p.shortCache[y] < 0 {
				continue
			}
			a, b := p.find(p.shortCache[x]), p.find(p.shortCache[y])
			if a != b {
				p.reps[max(a, b)] = min(a, b)
			}
		}
		if p.canon {
			for i, n := range p.shortCache {
				if n >= 0 {
					p.shortCache[i] = p.find(n)
				}
			}
		}
	}
	for s := range p.domains {
		if int32(s) == p.boolSort {
			continue
		}
		a, b := orig[s], sk[s]
		slices.SortStableFunc(a, func(x, y entry) int { return y.rank - x.rank })
		for i := 0; i < max(len(a), len(b)) && len(p.domains[s]) < k; i++ {
			if i < len(b) {
				p.addDomain(s, b[i].term)
			}
			if i < len(a) && len(p.domains[s]) < k {
				p.addDomain(s, a[i].term)
			}
		}
		if len(p.domains[s]) == 0 {
			id := p.addOp("witness", int32(s), false, true, true, 0)
			p.domains[s] = []int32{p.intern(id, nil)}
		}
	}
}
func (p *project) ground(id int32, env []int32, left *int) int32 {
	p.visits++
	if p.visits > 3500000 {
		panic("ground visit limit")
	}
	n := p.nodes[id]
	if x := p.shortCache[id]; x >= 0 {
		return x
	}
	if n.index >= 0 {
		return env[len(env)-1-n.index]
	}
	if n.binds != nil {
		out := make([]int32, 0, 8)
		var walk func(int, int, []int32)
		walk = func(pos, rank int, bindings []int32) {
			if *left <= 0 {
				return
			}
			if pos == len(n.binds) {
				if p.tupleMode != "" {
					p.tupleChecks++
					if p.tupleChecks > 400000 {
						panic("tuple candidate limit")
					}
					vals := bindings[len(bindings)-len(n.binds):]
					hits, checks := 0, 0
					if !(p.tupleMode == "diagonal" || p.tupleMode == "diagonal-wide") {
						for _, f := range p.joint[id] {
							seen := p.observed[f.key]
							if len(seen) == 0 {
								continue
							}
							checks++
							if seen[[2]int32{vals[f.a], vals[f.b]}] {
								hits++
							}
						}
					}
					switch p.tupleMode {
					case "all":
						if checks > 0 && hits < checks {
							return
						}
					case "any":
						if checks > 0 && hits == 0 {
							return
						}
					case "any-diagonal":
						if checks > 0 && hits == 0 && rank > len(vals) {
							return
						}
					case "any-slack":
						if checks > 0 && hits == 0 && rank > len(vals)+2 {
							return
						}
					case "diagonal":
						if len(vals) > 1 && rank >= 2+len(vals) {
							return
						}
					case "diagonal-wide":
						if len(vals) > 1 && rank >= 4+len(vals) {
							return
						}
					}
				}
				*left--
				p.tuples++
				out = append(out, p.ground(n.args[0], bindings, left))
				return
			}
			choices := p.domains[n.binds[pos]]
			if local := p.choices[[2]int32{id, int32(pos)}]; len(local) > 0 {
				choices = local
			}
			for ri, x := range choices {
				if *left <= 0 {
					break
				}
				walk(pos+1, rank+ri, append(bindings, x))
			}
		}
		walk(0, 0, env)
		return p.app(p.spell["and"], out)
	}
	var memoKey [4]int32
	memo := p.memo && n.open && !n.quant && len(n.args) > 0 && bits.OnesCount64(p.mask[id]) <= 3
	if memo {
		memoKey[0] = id
		mask := p.mask[id]
		for i := 1; mask != 0; i++ {
			j := bits.TrailingZeros64(mask)
			memoKey[i] = 1 + env[len(env)-1-j]
			mask &= mask - 1
		}
		if x, ok := p.cached[memoKey]; ok {
			return x
		}
	}
	var small [4]int32
	args := small[:0]
	for _, a := range n.args {
		args = append(args, p.ground(a, env, left))
	}
	x := p.app(n.op, args)
	if memo {
		p.cached[memoKey] = x
	}
	if !n.open {
		p.shortCache[id] = x
	}
	if n.sort != p.boolSort && len(n.args) > 0 && p.ops[n.op].Declared {
		p.freq[x]++
	}
	return x
}
func (p *project) rounds(k, more, passes, cap int) {
	p.domain(k)
	mode := os.Getenv("GROUND_DOMAIN")
	p.tupleMode = os.Getenv("GROUND_TUPLES")
	if mode != "" {
		p.observePositions()
	}
	for j := 0; j < passes; j++ {
		if mode != "" {
			p.choosePositions(k+j*more, mode)
		}
		for _, root := range p.templates {
			left := cap
			x := p.ground(root, nil, &left)
			p.assertRoot(x)
		}
		if j+1 == passes {
			break
		}
		by := make([][]int32, len(p.sorts))
		for i, n := range p.freq {
			if n == 0 {
				continue
			}
			if p.preferWitness && !p.witnesses[p.terms[i].op] {
				continue
			}
			s := p.termSort[i]
			if s == p.boolSort || slices.Contains(p.domains[s], int32(i)) {
				continue
			}
			by[s] = append(by[s], int32(i))
		}
		added := 0
		for s, v := range by {
			slices.SortStableFunc(v, func(a, b int32) int { return p.freq[b] - p.freq[a] })
			v = v[:min(more, len(v))]
			p.domains[s] = append(p.domains[s], v...)
			added += len(v)
		}
		if added == 0 {
			break
		}
	}
}
func (p *project) assertRoot(x int32) {
	if x == p.t || p.rootSet[x] {
		return
	}
	p.rootSet[x] = true
	t := p.terms[x]
	if p.ops[t.op].Name == "and" {
		for _, y := range t.args {
			p.assertRoot(y)
		}
		return
	}
	p.roots = append(p.roots, x)
}
func fromInput(input string, args []string) (graph, [5]int) {
	ctx, e := api.NewSMTContext()
	must(e)
	defer func() { must(ctx.Close()) }()
	m, e := ctx.Manager()
	must(e)
	r, e := ctx.ParseSMT2File(input, api.SMT2Bindings{})
	must(e)
	defer func() { must(m.DelRef(&r)) }()
	h, e := m.RefGet(r)
	must(e)
	var p project
	p.init(m)
	p.sourceUses(h, map[ast.ASTHandle]bool{})
	names, e := nf.NewDefinedNames(m)
	must(e)
	defer func() { must(names.Close()) }()
	o := nf.DefaultNNFOptions()
	o.Mode = nf.NNFFull
	o.IgnoreLabels = true
	n, e := nf.NewNNF(m, names, o)
	must(e)
	defer func() { must(n.Close()) }()
	out, e := m.NewRef(ast.ASTHandle{})
	must(e)
	defer func() { must(m.DelRef(&out)) }()
	proof, e := m.NewRef(ast.ASTHandle{})
	must(e)
	defer func() { must(m.DelRef(&proof)) }()
	var defs, proofs []ast.ASTRef
	defer func() {
		for i := range defs {
			must(m.DelRef(&defs[i]))
		}
		for i := range proofs {
			must(m.DelRef(&proofs[i]))
		}
	}()
	must(n.Transform(h, &defs, &proofs, out, proof))
	term, e := m.RefGet(out)
	must(e)
	p.split(p.compile(term))
	for _, r := range defs {
		term, e = m.RefGet(r)
		must(e)
		p.split(p.compile(term))
	}
	config := [4]int{8, 5, 2, 1536}
	for i, arg := range args {
		v, e := strconv.Atoi(arg)
		must(e)
		config[i] = v
	}
	p.rounds(config[0], config[1], config[2], config[3])
	stats := [5]int{len(p.templates), p.universalCount, p.tuples, p.visits, len(p.nodes)}
	return p.graph, stats
}

func (p *project) find(x int32) int32 {
	for int(x) < len(p.reps) && x != p.reps[x] {
		p.reps[x] = p.reps[p.reps[x]]
		x = p.reps[x]
	}
	return x
}
func (p *project) addDomain(s int, x int32) {
	if !p.alias {
		p.domains[s] = append(p.domains[s], x)
		return
	}
	r := p.find(x)
	for _, d := range p.domains[s] {
		if p.find(d) == r {
			return
		}
	}
	if p.canon {
		x = r
	}
	p.domains[s] = append(p.domains[s], x)
}

func (p *project) observePositions() {
	p.positions = map[[2]int32][][2]int32{}
	p.joint = map[int32][]jointSlot{}
	for i, n := range p.nodes {
		if !n.open {
			left := 1
			p.ground(int32(i), nil, &left)
		}
	}
	visits := 0
	var walk func(int32, [][2]int32)
	walk = func(id int32, scope [][2]int32) {
		visits++
		if visits > 600000 {
			panic("position limit")
		}
		n := p.nodes[id]
		if !n.open || n.index >= 0 {
			return
		}
		if n.binds != nil {
			for i := range n.binds {
				scope = append(scope, [2]int32{id, int32(i)})
			}
			walk(n.args[0], scope)
			return
		}
		if p.tupleMode != "" && p.ops[n.op].Declared && len(n.args) <= 8 {
			for i, aid := range n.args {
				a := p.nodes[aid]
				if a.index < 0 || a.sort == p.boolSort {
					continue
				}
				va := scope[len(scope)-1-a.index]
				for j := i + 1; j < len(n.args); j++ {
					b := p.nodes[n.args[j]]
					if b.index < 0 || b.sort == p.boolSort {
						continue
					}
					vb := scope[len(scope)-1-b.index]
					if va[0] != vb[0] || va[1] == vb[1] {
						continue
					}
					f := jointSlot{int(va[1]), int(vb[1]), [3]int32{int32(n.op), int32(i), int32(j)}}
					if !slices.Contains(p.joint[va[0]], f) {
						p.joint[va[0]] = append(p.joint[va[0]], f)
					}
				}
			}
		}
		for i, child := range n.args {
			x := p.nodes[child]
			if x.index >= 0 && p.ops[n.op].Declared && x.sort != p.boolSort {
				v := scope[len(scope)-1-x.index]
				slot := [2]int32{int32(n.op), int32(i)}
				if !slices.Contains(p.positions[v], slot) {
					p.positions[v] = append(p.positions[v], slot)
				}
			}
			walk(child, scope)
		}
	}
	for _, n := range p.templates {
		walk(n, nil)
	}
}
func (p *project) choosePositions(k int, mode string) {
	if p.tupleMode != "" {
		p.observed = map[[3]int32]map[[2]int32]bool{}
		wanted := map[uint32][][3]int32{}
		for _, v := range p.joint {
			for _, f := range v {
				if p.observed[f.key] == nil {
					p.observed[f.key] = map[[2]int32]bool{}
					wanted[uint32(f.key[0])] = append(wanted[uint32(f.key[0])], f.key)
				}
			}
		}
		for _, t := range p.terms {
			for _, key := range wanted[t.op] {
				p.observed[key][[2]int32{t.args[key[1]], t.args[key[2]]}] = true
			}
		}
	}
	slots := map[[2]int32]map[int32]int{}
	for _, ls := range p.positions {
		for _, pos := range ls {
			if slots[pos] == nil {
				slots[pos] = map[int32]int{}
			}
		}
	}
	for _, n := range p.terms {
		for i, x := range n.args {
			if ct := slots[[2]int32{int32(n.op), int32(i)}]; ct != nil {
				ct[x]++
			}
		}
	}
	p.choices = map[[2]int32][]int32{}
	for v, ls := range p.positions {
		sort := p.nodes[v[0]].binds[v[1]]
		score := map[int32]int{}
		for _, pos := range ls {
			for x, n := range slots[pos] {
				if p.termSort[x] == sort {
					score[x] += n
				}
			}
		}
		local := make([]int32, 0, len(score))
		for x := range score {
			local = append(local, x)
		}
		slices.SortFunc(local, func(x, y int32) int {
			if a, b := score[x], score[y]; a != b {
				return b - a
			}
			return int(x - y)
		})
		var out []int32
		seen := map[int32]bool{}
		add := func(x int32) {
			key := p.find(x)
			if !seen[key] && len(out) < k {
				out = append(out, x)
				seen[key] = true
			}
		}
		global := p.domains[sort]
		switch mode {
		case "direct":
			for _, x := range local {
				add(x)
			}
			for _, x := range global {
				add(x)
			}
		case "mix", "first":
			for i := 0; i < max(len(global), len(local)); i++ {
				if mode == "first" && i < len(global) {
					add(global[i])
				}
				if i < len(local) {
					add(local[i])
				}
				if mode == "mix" && i < len(global) {
					add(global[i])
				}
			}
		case "seen":
			for _, x := range global {
				if score[x] > 0 {
					add(x)
				}
			}
			for _, x := range local {
				add(x)
			}
			for _, x := range global {
				add(x)
			}
		}
		p.choices[v] = out
	}
}
