from pathlib import Path
s=Path(__file__).with_name('release.py').read_text().replace('bv_polynomial_config.go','cleanup.go').replace('bfc6ef339','bf57568ff').replace('ast/rewriter','smtcore/proto_model')
exec(compile(s,'clean-release','exec'))
