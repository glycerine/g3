from trial import panel
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_candidate_body.go';s=p.read_text().replace('candidateEqual\n)','candidateEqual\n candidateBoundApplication\n)').replace('op         smtCandidateOp','bindings [2]uint8\n op         smtCandidateOp')
    a='if node.op == candidateIff {'
    s=s.replace(a,'''if node.op==candidateApplication && header.NumArgs>=1 && header.NumArgs<=2{
            direct:=true
            for j,child:=range p.arguments[node.first:node.end]{v:=&p.nodes[child];if v.op!=candidateVariable || v.operand>255{direct=false;break};p.nodes[id].bindings[j]=uint8(v.operand)}
            if direct{p.nodes[id].op=candidateBoundApplication}
        }
        '''+a)
    yield p,s
    p=pkg/'smtcore/smt_checker_candidate.go';s=p.read_text();a='if len(ids) <= 2 {'
    s=s.replace(a,'''if n.op==candidateBoundApplication {
            var args [2]*SMTEnode
            for j:=range ids{index:=int(n.bindings[j]);if index>=len(c.bindings){return nil,nil};args[j]=c.bindings[len(c.bindings)-1-index]}
            return c.congruentEnodeWithFlags(decl.handle,decl.commutative,args[:len(ids)])
        }
        '''+a)
    yield p,s
def run(s):return s.replace('((1,3),(4,8),(6,227))','((4,3,1),(8,5),(6,2,227))')
if __name__=='__main__':panel(['base','trial'],patch,run)
