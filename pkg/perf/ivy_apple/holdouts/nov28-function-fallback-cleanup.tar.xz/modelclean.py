from trial import panel
from adaptive import run
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/proto_model/cleanup.go';s=p.read_text()
    if name in ['buffer','both']:
        s=s.replace('todo := []ast.ASTHandle{root}','var args []ast.ASTHandle\n todo := []ast.ASTHandle{root}').replace('args := make([]ast.ASTHandle, 0, n)','args=args[:0];if uint32(cap(args))<n{args=make([]ast.ASTHandle,0,n)}')
    if name in ['header','both']:
        a=s.index('d, constant, e := p.uninterpretedConstant(a)');b=s.index('todo = todo[:len(todo)-1]',a)
        s=s[:a]+'''h,e:=p.manager.NodeHeader(a)
        if e!=nil{return e}
        d:=h.Decl
        if h.Kind==ast.ASTApp && h.NumArgs==0 && h.Family==ast.NullFamilyID {
           '''+s[b:]
        a=s.index('kind, e := p.manager.GetKind(a)');b=s.index('cache[a] = a',a);s=s[:a]+'if h.Kind!=ast.ASTApp {\n'+s[b:]
        a=s.index('n, e := p.manager.GetNumArgs(a)');b=s.index('visited := true',a);s=s[:a]+'n:=h.NumArgs\n'+s[b:]
        a=s.index('d, e = p.manager.GetDecl(a)');b=s.index('if auxiliary',a);s=s[:a]+s[b:]
    yield p,s
if __name__=='__main__':panel(['base','buffer','header','both'],patch,run)
