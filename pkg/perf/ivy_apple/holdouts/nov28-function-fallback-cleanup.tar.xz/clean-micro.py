from pathlib import Path
s=Path(__file__).with_name('construct.py').read_text()
i=s.index('    for p,s in polyparams.patch');j=s.index("    j=t/'overlay.json'",i)
s=s[:i]+'''    if mode=='base':
        p=pkg/'smtcore/proto_model/cleanup.go'
        dest=t/p.name
        dest.write_bytes(sp.check_output(['git','show','bf57568ff:pkg/smtcore/proto_model/cleanup.go']))
        mp[str(p)]=str(dest)
'''+s[j:]
s=s.replace("'./ast/rewriter'","'./smtcore/proto_model'").replace("['Defaults','LocalAndGlobal']","['False','SharedApplication']").replace('BenchmarkTheoryRewriterConstruction','BenchmarkProtoModelCleanup').replace('[5,1005]','[32,10032]')
exec(compile(s,'clean-micro','exec'))
