from pathlib import Path
import csv,statistics as st,collections
d=Path(__file__).resolve().parent
for f in sorted((d/'rootprice').glob('*')):
    rows=[l.split() for l in f.read_text().splitlines()]
    v=[r for r in rows if r[1]=='true']
    print('repeat',f.name,len(rows),len(v),round(sum(int(r[-1]) for r in v)/1e6,3),sum(r[2]=='false' for r in v))
r=list(csv.DictReader((d/'clean-micro/runs.csv').open()))
for conf in ['False','SharedApplication']:
 for k in ['base','trial']:
    v=[x for x in r if x['config']==conf and x['engine']==k]
    p=[(int(b['instructions'])-int(a['instructions']))/10000 for a,b in zip(v[::2],v[1::2])]
    print(conf,k,round(st.median(p)),st.median(float(x['ns_op']) for x in v[1::2]),st.median(int(x['B_op']) for x in v[1::2]),st.median(int(x['allocs_op']) for x in v[1::2]))
for g in ['modelclean','cleanmemo','cleanreuse','clean-release']:
 for f in sorted((d/g).glob('time*.csv')):
    r=list(csv.DictReader(f.open()));v={k:[int(x['instructions']) for x in r if x['engine']==k] for k in set(x['engine'] for x in r)}
    if 'base' in v:print(g,f.stem,len(r),{k:round(100*(st.median(x)/st.median(v['base'])-1),2) for k,x in v.items() if k!='base'})
