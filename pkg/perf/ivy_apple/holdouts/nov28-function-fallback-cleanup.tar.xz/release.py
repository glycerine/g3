import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/release.py').read().decode()
s=s.replace("('smt_internalizer.go','smt_relevancy_asserted_or.go','smt_relevancy.go')","('bv_polynomial_config.go',)").replace("bf4a3f032:pkg/smtcore/","bfc6ef339:pkg/ast/rewriter/").replace("pkg/'smtcore'/fname","pkg/'ast/rewriter'/fname")
exec(compile(s,'release','exec'))
