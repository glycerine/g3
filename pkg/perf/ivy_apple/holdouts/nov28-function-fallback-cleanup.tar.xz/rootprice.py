import cleanprice,macroprice,subprocess
from trial import panel
def patch(pkg,name):
    p=pkg/'smtcore/proto_model/cleanup.go'
    s=p.read_text()
    s=s.replace('import (','import ("os";"syscall";"runtime";"unsafe";',1)+'\n'+macroprice.ns['src']
    s=s.replace('for _, d := range declarations {','seen:=make(map[ast.ASTHandle]bool);for _, d := range declarations {')
    a='if err = p.cleanFunctionElse(fi, found); err != nil {'
    assert s.count(a)==1
    yield p,s.replace(a,'''root,e:=fi.Else();if e!=nil{return e};h,e:=p.manager.NodeHeader(root);if e!=nil{return e}
    t:=StudyStart();err=p.cleanFunctionElse(fi,found);w:=t.finish()
    v,e:=fi.Else();if e!=nil{return e}
    println("MACROTIME",seen[root],root==v,h.NumArgs,w)
    seen[root]=root==v
    if err!=nil {''')
panel(['probe'],patch,macroprice.run)
