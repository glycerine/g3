from trial import panel
from bindings import run
def patch(pkg,name):
    if name=='base':return
    p=pkg/'ast/rewriter/bv_polynomial_config.go'
    s=p.read_text();i=s.index('if err = p.boolean(local, "flat"');j=s.index('if !p.state.Flat',i)
    slow=s[i:j]
    fast='''var options uparams.ScalarParams
    if p.context.ReadScalarParams(&options,local,&p.snapshots[0]) {
        p.state.Flat=settingFlat.read(&options)
        p.state.SumOfMonomials=settingSumOfMonomials.read(&options)
        p.state.HoistMultiplication=settingHoistMultiplication.read(&options)
        p.state.HoistCoefficients=settingHoistCoefficients.read(&options)
        p.state.MonomialLimit=settingSumOfMonomialsBlowup.read(&options)
    }else{'''
    yield p,s[:i]+fast+slow+'}\n'+s[j:].replace('key = "arith_ineq_lhs"','key := "arith_ineq_lhs"',1)
if __name__=='__main__':panel(['base','trial'],patch,run)
