import os,tempfile,json,csv,subprocess as sp
from pathlib import Path
import polyparams
d=Path(os.environ['RESULTS']);d.mkdir(exist_ok=True)
pkg=Path.cwd()
with tempfile.TemporaryDirectory() as wd:
 t=Path(wd)
 for mode in ['base','trial']:
    mp={}
    for p,s in polyparams.patch(pkg,mode):
        dest=t/p.name;dest.write_text(s);mp[str(p)]=str(dest)
    j=t/'overlay.json';j.write_text(json.dumps({'Replace':mp}))
    sp.run(['go','test','-c','-overlay',j,'-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',t/mode,'./ast/rewriter'],check=True)
 with (d/'runs.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['round','engine','config','n','instructions','ns_op','B_op','allocs_op'])
    for i in range(5):
     for mode in ['base','trial'][::1 if i%2==0 else -1]:
      for conf in ['Defaults','LocalAndGlobal']:
       for n in [5,1005]:
        r=sp.run(['taskset','-c',os.environ['PROBE_CPU'],os.environ['PERF'],'stat','-x,','-e','instructions:u','-o',t/'stat','--',t/mode,'-test.run','^$','-test.bench','^BenchmarkTheoryRewriterConstruction$/^'+conf+'$','-test.benchtime',str(n)+'x','-test.cpu','1'],capture_output=True,text=True,check=True)
        row=next(l.split() for l in r.stdout.splitlines() if l.startswith('Benchmark'))
        stat=next(row for row in csv.reader((t/'stat').open()) if len(row)>4 and row[2]=='instructions:u')
        assert float(stat[4])==100
        w.writerow([i,mode,conf,n,stat[0],row[2],row[4],row[6]]);f.flush()
