import cleanprice,cleanreuse,macroprice,os
from trial import panel
def patch(pkg,name):
    modes=dict(cleanreuse.patch(pkg,os.environ['CLEAN_MODE']))
    cleanprice.modelclean.patch=lambda pkg,mode:((p,s) for p,s in modes.items() if p.name=='cleanup.go')
    yield from cleanprice.patch(pkg,name)
    yield from ((p,s) for p,s in modes.items() if p.name!='cleanup.go')
panel(['probe'],patch,macroprice.run)
