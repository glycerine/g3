import os,macroprice,modelclean
from trial import panel
def patch(pkg,name):
    p=pkg/'smtcore/proto_model/cleanup.go'
    mode=os.environ['CLEAN_MODE']
    s=p.read_text() if mode=='base' else next(modelclean.patch(pkg,mode))[1]
    s=s.replace('import (','import ("os";"syscall";"runtime";"unsafe";',1)+'\n'+macroprice.ns['src']
    a='if err = p.cleanFunctionElse(fi, found); err != nil {'
    assert s.count(a)==1
    yield p,s.replace(a,'''root,e:=fi.Else();if e!=nil{return e};h,e:=p.manager.NodeHeader(root);if e!=nil{return e}
    t:=StudyStart();err=p.cleanFunctionElse(fi,found);w:=t.finish()
    println("MACROTIME",uint32(h.Kind),uint32(h.Family),h.DeclKind,h.NumArgs,w)
    if err!=nil {''')
if __name__=='__main__':panel(['probe'],patch,macroprice.run)
