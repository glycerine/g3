from trial import panel
from pathlib import Path
ns={}
s=Path(__file__).with_name('tail.py').read_text()
exec(s[:s.index('def patch')],ns)
def patch(pkg,name):
    p=pkg/'ast/macros/macro_expander.go'
    s=p.read_text().replace('import (','import ("os";"syscall";"runtime";"unsafe";',1)
    a='normalizer, err := newMacroTheoryNormalizer(m.manager, m.paramsContext, m.globals)'
    b='defer func() { result = errors.Join(result, normalizer.close()) }()'
    assert s.count(a)==1 and s.count(b)==1
    s=s.replace(a,'setup:=StudyStart();'+a+';work:=setup.finish()').replace(b,'defer func(){closeTime:=StudyStart(); result=errors.Join(result,normalizer.close());println("MACROTIME",work,closeTime.finish())}()')
    yield p,s+'\n'+ns['src']
    p=pkg/'ast/macros/macro_finder.go'
    s=p.read_text();a='func (f *Finder) pass(input *FormulaBatch) (output *FormulaBatch, found bool, result error) {'
    yield p,s.replace(a,a+'\n println("MACROPASS",len(input.rows));defer println("MACROEND")')
def run(s):
    s=s.replace('assert (r.returncode,r.stdout,r.stderr)',"""diagnostics=[l for l in r.stderr.splitlines(True) if l.startswith((b'MACROTIME ',b'MACROPASS ',b'MACROEND'))]
        (out/str(case)).write_bytes(b''.join(diagnostics))
        rest=b''.join(l for l in r.stderr.splitlines(True) if not l.startswith((b'MACROTIME ',b'MACROPASS ',b'MACROEND')))
        assert (r.returncode,r.stdout,rest)""")
    return s[:s.index(' def measure(')]+''' for case in [8,4,3,6,2,5,227,1]:run(case,'probe',cpus[0],False)
'''
if __name__=='__main__':panel(['probe'],patch,run)
