from pathlib import Path
import collections
d=Path(__file__).resolve().parent
for mode in ['base','both']:
 for p in sorted((d/('cleanprice-'+mode)).glob('*')):
    work=collections.Counter();rows=collections.Counter()
    for l in p.read_text().splitlines():
        a=l.split();shape=tuple(a[1:-1]);rows[shape]+=1;work[shape]+=int(a[-1])
    print(mode,p.name,sum(rows.values()),round(sum(work.values())/1e6,2),[(k,rows[k],round(cost/1e6,2)) for k,cost in work.most_common(3)])
