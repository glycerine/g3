from trial import panel
from adaptive import run
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/proto_model/cleanup.go';s=p.read_text()
    # Preserve discovery of auxiliary declarations before the optional shortcut.
    i=s.index('out, e := p.manager.NewRef(ast.ASTHandle{})')
    if name in ['bool','combined']:
        s=s[:i]+'''if n==0 && (p.manager.IsTrue(a)||p.manager.IsFalse(a)) && p.manager.TraceStream==nil && !p.manager.Budget().InjectionArmed() {
            cache[a]=a;todo=todo[:len(todo)-1];continue
        }
        '''+s[i:]
    if name in ['reuse','combined']:
        s=s.replace('visited := true','visited := true;changed:=false').replace('args = append(args, v)','args = append(args, v);changed=changed || arg!=v')
        a='if e = p.rewriter.MakeApp(d, ast.SliceArguments(args), out); e != nil {'
        s=s.replace(a,'''if !changed && p.manager.TraceStream==nil && !p.manager.Budget().InjectionArmed() {
            e=p.rewriter.StudyRebuild(a,d,ast.SliceArguments(args),out)
        }else{e=p.rewriter.MakeApp(d,ast.SliceArguments(args),out)}
        if e!=nil{''')
        q=pkg/'ast/rewriter/th_rewriter.go';v=q.read_text();i=v.index('func (r *TheoryRewriter) MakeApp(');j=v.index('func (r *TheoryRewriter) NumSteps()',i)
        fn=v[i:j].replace('MakeApp(decl','StudyRebuild(original,decl',1)
        z=fn.index('h, err := r.manager.RewriterMakeApp');fn=fn[:z]+'return r.manager.SetRef(out,original)\n}\n'
        yield q,v+fn
    yield p,s
if __name__=='__main__':panel(['base','bool','reuse','combined'],patch,run)
