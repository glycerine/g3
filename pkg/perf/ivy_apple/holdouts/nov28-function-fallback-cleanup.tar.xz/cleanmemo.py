from trial import panel
from adaptive import run
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/proto_model/cleanup.go';s=p.read_text()
    mark='for _, d := range declarations {'
    if name=='root':
        s=s.replace(mark,'same:=make(map[ast.ASTHandle]bool);'+mark)
        a='if err = p.cleanFunctionElse(fi, found); err != nil {\n\t\t\treturn err\n\t\t}'
        assert a in s
        s=s.replace(a,'''root,e:=fi.Else();if e!=nil{return e}
        if same[root]{continue}
        '''+a+'''
        v,e:=fi.Else();if e!=nil{return e};if root==v{same[root]=true}
        ''')
    else:
        s=s.replace(mark,'same:=make(map[ast.ASTHandle]bool);'+mark)
        s=s.replace('fi *model.FunctionInterpretation, found *ast.ObjMap)', 'fi *model.FunctionInterpretation, found *ast.ObjMap,same map[ast.ASTHandle]bool)')
        s=s.replace('p.cleanFunctionElse(fi, found)','p.cleanFunctionElse(fi, found,same)')
        a='d, constant, e := p.uninterpretedConstant(a)'
        s=s.replace(a,'if same[a]{cache[a]=a;todo=todo[:len(todo)-1];continue};'+a)
        a='cache[a] = v\n\t}'
        s=s.replace(a,'if a==v'+(' && n>0' if name=='apps' else '')+'{same[a]=true};'+a)
    yield p,s
if __name__=='__main__':panel(['base','root','nodes','apps'],patch,run)
