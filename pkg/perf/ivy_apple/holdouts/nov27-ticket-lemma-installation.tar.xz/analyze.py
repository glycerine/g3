from pathlib import Path
from collections import defaultdict
from statistics import median
import csv
d=Path(__file__).resolve().parent
rows=defaultdict(lambda:defaultdict(list))
for r in csv.DictReader((d/'install.csv').open()):
    key=tuple(int(r[k]) for k in ('batch','goal','phase','shape'))
    rows[key][r['engine']].append((int(r['calls']),int(r['instructions'])))
groups=defaultdict(lambda:[0]*6)
for (batch,goal,phase,shape),engines in rows.items():
    def val(engine):
        vs=engines[engine]
        if not vs:return (0,0)
        assert len(vs)==3 and len({n for n,v in vs})==1
        return vs[0][0],median(v for n,v in vs)
    g,x=val('g3');z,y=val('z3')
    excess=min(g,z)*(x/g-y/z) if g and z else 0
    for key in [(phase,'all'),(phase,'missing' if shape%1000000>=10000 else 'bound'),(phase,str(batch)+'/'+str(goal))]:
        values=groups[key]
        for i,v in enumerate([g,z,x,y,excess,x-y-excess]): values[i]+=v
with (d/'summary.csv').open('w') as f:
    w=csv.writer(f);w.writerow('phase group g3_calls z3_calls g3_ins z3_ins matched_rate residual'.split())
    for key,vs in sorted(groups.items()):w.writerow([*key,*map(round,vs)])
