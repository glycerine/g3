"""Release comparison of short literal buffers and the cached unary NOT operand."""
from pathlib import Path
import tarfile
def patches(pkg,mode):
    p=pkg/'smtcore/smt_internalizer.go'
    s=p.read_text()
    anchor='literals := make([]SMTLiteral, len(arguments))'
    i=s.index(anchor,s.index('func (s *SMTInternalizerState) assertExpression('))
    if mode in ('short','both'):
        s=s[:i]+s[i:].replace(anchor,'''var fixed [8]SMTLiteral
            var literals []SMTLiteral
            if len(arguments)<=len(fixed){ literals=fixed[:len(arguments)] }else{ literals=make([]SMTLiteral,len(arguments)) }''',1)
    yield p,s
    p=pkg/'ast/ast_core_boolean_factories.go'
    s=p.read_text()
    a='app := m.appAt(r.slot)\n\tfamily, kind, e := m.appIdentity(app)'
    assert s.count(a)==1
    if mode in ('unary','both'):
        s=s.replace(a,'''app := m.appAt(r.slot)
    if !ASTSourceDebug && app.declCached {
        if app.declFamily!=FamilyID(0)||app.declKind!=ASTOpNot{return false,ASTHandle{},nil}
        if app.count!=0{return true,m.external(app.inlineArgs[0]),nil}
    }
    family, kind, e := m.appIdentity(app)''')
    yield p,s
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['base','short','unary','both']
    for mode in modes:
        for p,source in patches(pkg,mode):put(p,source)
"""+s[b:]
exec(compile(s.replace("'notification.csv'","'trials.csv'"),'trials','exec'))
