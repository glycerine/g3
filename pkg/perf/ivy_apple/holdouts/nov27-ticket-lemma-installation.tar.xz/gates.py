"""Use signed child literals when registering ordinary AND and OR watches."""
from pathlib import Path
import tarfile
def patches(pkg,mode):
    p=pkg/'smtcore/smt_internalizer.go'
    s=p.read_text()
    if mode=='gates':
        for op in ['And','Or']:
            a='return s.relevancy.Add'+op+'Watches(expression)'
            assert s.count(a)==1
            s=s.replace(a,'return s.addResolvedGateWatches(expression,arguments,'+('true' if op=='Or' else 'false')+')')
        s+='''
func (s *SMTInternalizerState) addResolvedGateWatches(parent ast.ASTHandle, args []SMTLiteral, positive bool) error {
    p:=s.relevancy
    if p.internalizer!=s||p.context.assignments.s!=s||p.context.registeredEnodes!=nil||p.IsRelevant(parent)||p.interruptedPop!=0{
        if positive{return p.AddOrWatches(parent)};return p.AddAndWatches(parent)
    }
    kind:=smtRelevancyOr;if !positive{kind=smtRelevancyAnd}
    handler:=smtRelevancyHandler{kind:kind,target:parent}
    for i,l:=range args{
        if !positive{l=l.Negated()}
        v:=l.Var()
        if v<SMTFirstBoolVar || !s.notChild(v).IsNull(){
            arg,e:=s.manager.GetArg(parent,uint32(i));if e!=nil{return e}
            if e=p.addLiteralWatch(arg,positive,&handler);e!=nil{return e};continue
        }
        if e:=p.addWatchForAssignment(s.boolExpr[v],!l.Sign(),&handler,s.assignment[l.Index()]);e!=nil{return e}
    };return nil
}
'''
    yield p,s
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['base','gates']
    for mode in modes:
        for p,source in patches(pkg,mode):put(p,source)
"""+s[b:]
exec(compile(s.replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("'notification.csv'","'gates.csv'"),'gates','exec'))
