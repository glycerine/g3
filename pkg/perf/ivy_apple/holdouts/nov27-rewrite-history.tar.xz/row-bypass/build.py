from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
files={}
def alter(name,old,new):
 k=p/'smtcore'/name;s=k.read_text();assert s.count(old)>=1,old
 dst=w/name;dst.write_text(s.replace(old,new,1));files[str(k)]=str(dst)
alter('smt_kernel.go','type SMTKernel struct {','type SMTKernel struct {\n trialPublished [2]map[ast.ASTHandle]bool\n trialPostMacro bool')
alter('smt_asserted_macros.go','return k.replacePendingMacroBatch(batch)','k.trialPostMacro=true; defer func(){k.trialPostMacro=false}();return k.replacePendingMacroBatch(batch)')
alter('smt_asserted_formulas.go','err = k.preprocessor.Rewrite(formula, resultRef)','''i:=0;if k.assertedElimAnd{i=1};outputs:=k.trialPublished[i]
 if k.trialPostMacro && outputs[formula]{err=k.manager.SetRef(resultRef,formula)}else{
 err = k.preprocessor.Rewrite(formula, resultRef)
 if err==nil{out,e:=k.manager.RefGet(resultRef);if e==nil{if outputs==nil{outputs=make(map[ast.ASTHandle]bool);k.trialPublished[i]=outputs};outputs[out]=true}}}''')
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
