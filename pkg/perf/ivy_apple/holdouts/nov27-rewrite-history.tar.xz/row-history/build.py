from pathlib import Path
import sys, subprocess, json,shlex,re,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();engine=sys.argv[1];front,mod=map(lambda x:Path(x).resolve(),sys.argv[2:4])
def rep(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(n,s):
    path=w/n;path.write_text(s);return str(path)
files={}
stage=(w/'phase.go.txt').read_text()
files[str(front/'phase_observer_trial.go')]=save(engine+'-stage.go',stage.replace('start := time.Now()', 'os.Setenv("PASS_FD",fmt.Sprint(fd));start := time.Now()').replace('elapsed := time.Since(start)','os.Unsetenv("PASS_FD");elapsed := time.Since(start)'))
files[str(front/'z3bridge_solver_model.go')]=str(w/(engine+'-bridge.go.txt'))
if engine=='ordinary':
 k=p/'smtcore/smt_asserted_macros.go';s=rep(k.read_text(),'"fmt"','"fmt"\n "os"\n "strconv"\n "syscall"\n "unsafe"')
 s+='''
func passFD() int {v,e:=strconv.Atoi(os.Getenv("PASS_FD"));if e!=nil{return -1};return v}
func passRead(fd int) int64 {if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if n!=24||e!=0||c[1]!=c[2]{panic("counter")};return int64(c[0])}
func passLog(fd int,args ...any){if fd>=0{fmt.Fprint(os.Stderr,"PASS ");fmt.Fprintln(os.Stderr,args...)}}
'''
 s+="\nvar postFD = -1\nvar postSum [8]int64\nvar postCount [8]int\n"
 s=s.replace('return k.replacePendingMacroBatch(batch)',"""postFD=passFD();postSum=[8]int64{};postCount=[8]int{}
 a,b:=passRead(postFD),passRead(postFD);err=k.replacePendingMacroBatch(batch);total:=passRead(postFD)-2*b+a
 for i,key:=range []string{"swap","flush","same","changed","repeatSame","repeatChanged","oldOutputSame","oldOutputChanged"} {passLog(postFD,key,0,0,0,0,0,postCount[i],postSum[i])}
 passLog(postFD,"total",0,0,0,0,0,1,total);postFD=-1;return err""",1)
 a=s.index('func (k *SMTKernel) replacePendingMacroBatch');x=s.index('return k.reduceAndSolveAssertions()',a)
 s=s[:x]+'postSum[0]+=passRead(postFD)-2*b+a;postCount[0]++;'+s[x:]
 x=s.index('if err := k.swapPendingFormulaBatch',a);s=s[:x]+'a,b:=passRead(postFD),passRead(postFD);'+s[x:]
 files[str(k)]=save(k.name,s)
 k=p/'smtcore/smt_asserted_reduce.go';s=k.read_text();i=s.index('if err := k.flushAssertedCache()',s.index('func (k *SMTKernel) reduceAndSolveAssertions'));s=s[:i]+s[i:].replace('if err := k.flushAssertedCache(); err != nil {','a,b:=passRead(postFD),passRead(postFD);err:=k.flushAssertedCache();postSum[1]+=passRead(postFD)-2*b+a;postCount[1]++;if err!=nil {',1);files[str(k)]=save(k.name,s)
 k=p/'smtcore/smt_asserted_formulas.go';s=k.read_text()
 s+='''
type historyRow struct { kernel *SMTKernel; formula ast.ASTHandle; elimAnd bool }
var historyLast = make(map[historyRow]ast.ASTHandle)
var historyOutputs = make(map[historyRow]bool)
'''
 s=rep(s,'err = k.preprocessor.Rewrite(formula, resultRef)','''key:=historyRow{k,formula,k.assertedElimAnd}
 prior,seen:=historyLast[key];oldOutput:=historyOutputs[key]
 a,b:=passRead(postFD),passRead(postFD);err=k.preprocessor.Rewrite(formula,resultRef);n:=passRead(postFD)-2*b+a
 if err==nil{out,_:=k.manager.RefGet(resultRef);i:=2;if out!=formula{i=3}
 if postFD>=0{postSum[i]+=n;postCount[i]++
 if seen && prior==formula{postSum[i+2]+=n;postCount[i+2]++}
 if oldOutput{postSum[i+4]+=n;postCount[i+4]++}}
 historyLast[key]=out;historyOutputs[historyRow{k,out,k.assertedElimAnd}]=true}''')
 files[str(k)]=save(k.name,s)
ov=save(engine+'.json',json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if engine=='native' else ''),'-overlay',ov,'-o',w/engine,'./cmd/goivy_check'],cwd=front,check=True)
