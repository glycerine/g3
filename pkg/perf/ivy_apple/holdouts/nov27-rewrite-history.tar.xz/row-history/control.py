from pathlib import Path
import json,subprocess,os,sys
gold=Path(sys.argv[1]);ex=Path(sys.argv[2]);control=Path(sys.argv[3]);dest=Path(sys.argv[4])
defs=json.loads((gold/'cases.json').read_text());dest.mkdir(exist_ok=True)
(dest/'cases.json').write_text(json.dumps(defs))
for name in ('test_liveness2','gcd2','alternating_bit_protocol','tlb'):
 out=dest/'reference'/name;out.mkdir(parents=True,exist_ok=True)
 if name=='tlb':
  for f in ('stdout','stderr'): (out/f).write_bytes((gold/'reference'/name/f).read_bytes())
  continue
 spec,iso,code=defs[name];r=subprocess.run([control]+(['isolate='+iso] if iso else [])+[ex/spec],cwd=dest,capture_output=True,env=dict(os.environ,XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),GOMAXPROCS='1'));assert r.returncode==code
 (out/'stdout').write_bytes(r.stdout);(out/'stderr').write_bytes(r.stderr)
