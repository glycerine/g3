from pathlib import Path
import csv,json,os,subprocess,sys
w=Path(__file__).resolve().parent;gold,ex=map(Path,sys.argv[1:3]);name='test_liveness2';spec,_,code=json.loads((gold/'cases.json').read_text())[name]
r=subprocess.run(['taskset','-c',sys.argv[3],w/'ordinary',ex/spec],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
pending=[];err=bytearray()
with (w/'witness.csv').open('w') as f:
 out=csv.writer(f);out.writerow(('batch','goal','stage','rows','instructions'))
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'PASS '):
   a=line.split()
   if a[1]==b'oldOutputChanged' and int(a[-2]):pending.append(tuple(map(int,a[-2:])))
  elif line.startswith(b'STAGE-COUNT '):
   _,batch,goal,stage,*_=line.decode().split()
   for pair in pending:out.writerow((batch,goal,stage,*pair))
   pending.clear()
  else:err.extend(line)
 ref=gold/'reference'/name
 assert not pending and (r.returncode,r.stdout,err)==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
