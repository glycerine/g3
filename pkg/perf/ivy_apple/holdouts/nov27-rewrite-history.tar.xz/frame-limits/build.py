from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
src=p/'ast/rewriter/rewriter_engine.go';s=src.read_text()
s=s.replace('cfg                      Configuration','cfg                      Configuration\n theoryLimits *theoryRewriterConfiguration')
s=s.replace('_, theory := cfg.(*theoryRewriterConfiguration)','limits, theory := cfg.(*theoryRewriterConfiguration);r.theoryLimits=limits')
s=s.replace('if !r.substituteVariables {\n\t\t\texceeded, err := r.cfg.MaxStepsExceeded(r.numSteps)','''if limits:=r.theoryLimits;limits!=nil{
 if m.Budget().Used()>limits.maxMemory{return newRewriterException("max. memory exceeded")}
 if r.numSteps>limits.maxSteps{return newRewriterException(messages.MaxSteps)}
 }else if !r.substituteVariables {
 exceeded, err := r.cfg.MaxStepsExceeded(r.numSteps)''')
dst=w/src.name;dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
