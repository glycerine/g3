from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
src=p/'ast/rewriter/rewriter_engine.go';s=src.read_text()
s=s.replace('for i := uint32(0); i < nd; i++ {\n\t\t\tr.pushBinding(ast.ASTHandle{}, sz)\n\t\t}','''if _,theory:=r.cfg.(*theoryRewriterConfiguration);!theory || sz!=0 {
 for i:=uint32(0);i<nd;i++{r.pushBinding(ast.ASTHandle{},sz)}
 }''')
s=s.replace('if nd > uint32(len(r.bindings))', 'if len(r.bindings)!=0 {\n if nd > uint32(len(r.bindings))').replace('r.shifts = r.shifts[:uint32(len(r.shifts))-nd]', 'r.shifts = r.shifts[:uint32(len(r.shifts))-nd]\n }')
s=s.replace('index, e := m.GetVarIndex(t)','if len(r.bindings)==0{return appendRewriterRoot(m,&c.results,t)}\n index, e := m.GetVarIndex(t)',1)
dst=w/src.name;dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
