from pathlib import Path
import csv,subprocess
w=Path(__file__).resolve().parent
with (w/'bench.csv').open('w') as f:
 out=csv.writer(f);out.writerow(('round','engine','width','ns/op','bytes/op','allocs/op'))
 for i in range(7):
  for eng in ('base','trial')[::1 if i%2==0 else -1]:
   text=subprocess.check_output(['taskset','-c','20',w/(eng+'.test'),'-test.run=^$','-test.bench=^BenchmarkTheoryQuantifiedFrames$','-test.benchtime=20000x','-test.cpu=1'],text=True)
   for line in text.splitlines():
    if line.startswith('Benchmark'):
     n,_,ns,_,mem,_,alloc,_=line.split();out.writerow((i,eng,n.split('/')[1],ns,mem,alloc))
