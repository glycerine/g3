from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
src=p/'ast/rewriter/rewriter_engine.go';s=src.read_text()
s=s.replace('for len(c.frames) != 0 {','limits, _ := r.cfg.(*theoryRewriterConfiguration)\n for len(c.frames) != 0 {',1)
needle='exceeded, err := r.cfg.MaxStepsExceeded(r.numSteps)'
assert s.count(needle)==1
s=s.replace(needle,'''var exceeded bool
 var err error
 if limits!=nil {exceeded,err=limits.MaxStepsExceeded(r.numSteps)}else{exceeded,err=r.cfg.MaxStepsExceeded(r.numSteps)}''')
dst=w/src.name;dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
