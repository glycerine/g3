from common import *
import enumeration_replay as er
rd=d/'rename-history-cross';rd.mkdir(exist_ok=True)
token=re.compile(r'\b(?:ee|ef|es)\d+(?:_\d+)?\b')
def loadhist(spec,mode,pairs):
 roots={};got={};src=d/'selective-enumeration-history'/spec/mode;assert(src/'validated').exists()
 with gzip.open(src/'problems.jsonl.gz','rt')as f:
  for l in f:
   x=json.loads(l);owner=x['Owner']
   if x['New']:roots[owner]=[]
   roots[owner].append(x)
   coord=tuple(x['coord']or[])
   if coord in pairs:got[coord]=list(roots[owner])
 return got
def mapping(before,after):
 a=token.split(before);b=token.split(after);assert a==b
 a=token.findall(before);b=token.findall(after);fwd=dict(zip(a,b));rev=dict(zip(b,a));assert len(rev)==len(fwd) and all(fwd[k]==v and rev[v]==k for k,v in zip(a,b))
 # Complete the partial bijection on the union as disjoint cycles. This
 # preserves uniqueness for every other identifier in the preceding history.
 for start in fwd.keys()-rev.keys():
  t=start
  while t in fwd:t=fwd[t]
  fwd[t]=start
 assert set(fwd)==set(fwd.values());return fwd
def renametext(s,mp):return token.sub(lambda m:mp.get(m[0],m[0]),s)
def renamed(seq,mp):
 out=[]
 for x in seq:
  p=x['Problem'];a,z=p['AssertionsStart'],p['LastAssertionStart'];s=p['Text']
  assert len(s)==len(s.encode())
  a0,b0,c0=[renametext(t,mp)for t in [s[:a],s[a:z],s[z:]]]
  out.append(dict(x,Problem=dict(p,Text=a0+b0+c0,AssertionsStart=len(a0),LastAssertionStart=len(a0)+len(b0))))
 return out
def cases():
 jobs=[]
 for spec,batch,cs in [('apple2',14,[0,4,12,24]),('sys_live',10,[7,19,30,40])]:
  keys=[(str(batch),str(goal),'check')for goal in [110,132]]
  ls,rs=loadhist(spec,'before',keys),loadhist(spec,'after',keys)
  for key in keys:
   before,after=ls[key],rs[key]
   fwd=mapping(before[-1]['Problem']['Text'],after[-1]['Problem']['Text']);inv={v:k for k,v in fwd.items()}
   ab=renamed(before,fwd);ba=renamed(after,inv)
   assert ab[-1]['Problem']==after[-1]['Problem']and ba[-1]['Problem']==before[-1]['Problem']
   samecoords=[q['coord']for q in before]==[q['coord']for q in after]
   samehistory=samecoords and all(l['Problem']==r['Problem']for l,r in zip(ab,after))
   loc=rd/(spec+'-'+key[1]);loc.mkdir(exist_ok=True)
   (loc/'identity.json').write_text(json.dumps(dict(terminal_equal_after_renaming=True,renamed_names=sum(k!=v for k,v in fwd.items()),before_goals=len(before),after_goals=len(after),same_coordinates=samecoords,all_inputs_equal_after_renaming=samehistory))+'\n')
   for cpu,(name,qs)in zip(cs,[('before-before',before),('before-after',ab),('after-before',ba),('after-after',after)]):
    p=loc/(name+'.json');p.write_text(json.dumps(qs));jobs.append((cpu,loc,name,p))
 return jobs
def lane(j):
 c,loc,name,p=j;b=d/'enumeration-replay/api.test'
 with(loc/(name+'.csv')).open('w')as f:
  z=csv.writer(f);z.writerow('case history_names scope round reached total proved terminal_ns instructions cycles'.split())
  for scope in ('warm','cold'):
   for i in range(2):
    pf=loc/(name+'.perf');en=dict(env,GOMAXPROCS='1',ENUM_SEQUENCE=str(p),ENUM_SCOPE=scope,ENUM_REGIME='default',ENUM_STEPS='6000000')
    res=run(['taskset','-c',str(c),perf,'stat','-x,','-e','instructions:u,cycles:u','-o',pf,'--',b,'-test.run=^TestStudyEnumerationReplay$','-test.timeout=6m','-test.v'],env=en,capture_output=True,text=True)
    hit=re.findall(r'^REPLAY (\d+) (\d+) (true|false) (\d+)$',res.stdout,re.M);assert len(hit)==1,(name,scope,res.stdout[-600:]);cts=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];z.writerow([loc.name,name,scope,i+1,*hit[0],*cts]);f.flush();print(loc.name,name,scope,i+1,*hit[0][:3],flush=True)
def main():
 js=cases()
 # Each of the eight CPUs has its own serial lane.
 with ThreadPoolExecutor(8)as e:
  fs=[e.submit(lambda q:[lane(j)for j in q],[j for j in js if j[0]==c])for c in sorted({j[0]for j in js})]
  for f in fs:f.result()
if __name__=='__main__':main()
