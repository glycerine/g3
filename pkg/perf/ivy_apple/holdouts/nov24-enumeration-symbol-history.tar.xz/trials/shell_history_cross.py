from common import *
import rename_history_cross as hc
rd=d/'shell-history-cross';rd.mkdir(exist_ok=True)
def render(qs,limit=6000000):
 decls={};base='';out=[f'(set-option :smt.macro_finder true)\n(set-option :smt.relevancy 1)\n(set-option :global-declarations true)\n(set-option :rlimit {limit})\n']
 for q in qs:
  p=q['Problem'];s=p['Text'];a,z=p['AssertionsStart'],p['LastAssertionStart'];premises=s[a:z]
  for decl in s[:a].splitlines(keepends=True):
   key=decl.split()[1];old=decls.get(key)
   if old is None:decls[key]=decl;out.append(decl)
   else:assert old==decl,(key,old,decl)
  if not base or not premises.startswith(base):
   if base:out.append('(pop 1)\n')
   if premises:out.extend(['(push 1)\n',premises])
   base=premises;suffix=s[z:]
  else:suffix=s[a+len(base):]
  out+=['(push 1)\n',suffix,'(check-sat)\n(pop 1)\n']
 return ''.join(out)
def lane(task):
 c,spec,goal=task;src=hc.rd/(spec+'-'+str(goal));od=rd/src.name;od.mkdir()
 with (od/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('history names scope round engine results instances decisions conflicts resource instructions cycles'.split())
  for name in ('before-before','before-after','after-before','after-after'):
   qs=json.loads((src/(name+'.json')).read_text())
   for scope in ('cold','warm'):
    sub=qs[-1:]if scope=='cold'else qs;sm=render(sub);(od/(name+'-'+scope+'.smt2')).write_text(sm)
    for i in range(2):
     ref=None
     for engine,bin in [('g3',d/'release-arena-generation/g3'),('native',pkg.parent/'build/z3')][::1 if i==0 else -1]:
      pf=od/'perf';r=run(['taskset','-c',str(c),perf,'stat','-x,','-e','instructions:u,cycles:u','-o',pf,'--',bin,'-smt2','-in','-st'],input=sm,capture_output=True,text=True,env=dict(env,GOMAXPROCS='1'))
      assert not r.stderr and '(error' not in r.stdout,(src,name,scope,r.stderr[-500:],r.stdout[-500:])
      answers=[l for l in r.stdout.splitlines()if l in ('unsat','sat','unknown')];assert len(answers)==len(sub) and 'sat'not in answers,(src,name,scope,answers)
      st={k:v for k,v in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])',r.stdout)if not any(q in k for q in ('alloc','time','memory'))}
      ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];key=(answers,st);(od/(name+'-'+scope+'-'+engine+'.out')).write_text(r.stdout)
      # Report a real cross-engine difference if it occurs; the command-shell and live API have different setup and limits.
      z.writerow([*name.split('-'),scope,i+1,engine,' '.join(answers),*[st.get(k,0)for k in ('quant-instantiations','decisions','conflicts','rlimit-count')],*ct]);f.flush()
      if ref is not None and key!=ref:print('different search:',src.name,name,scope,i+1,answers,flush=True)
      ref=key
  print(src.name,'done',flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(4)as e:list(e.map(lane,[(4,'apple2',110),(9,'apple2',132),(28,'sys_live',110),(35,'sys_live',132)]))
