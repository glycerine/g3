from common import *
import shell_history_cross as hc
rd=d/'name-search-divergence';rd.mkdir(exist_ok=True)
def raw(od,name,goal):
 x=json.loads((d/'rename-history-cross'/name/(goal+'.json')).read_text())
 return hc.render(x[-1:])
def sample(case):
 cpu,case=case
 od=rd/case;od.mkdir(exist_ok=True)
 texts={nm:raw(od,case,'before-'+nm) for nm in ('before','after')}
 bs={'g3':d/'watch-release-frontier/g3','native':pkg.parent/'build/z3'}
 with (od/'checkpoints.csv').open('w')as f:
  keys='result rlimit-count quant-instantiations decisions conflicts propagations final-checks mk-clause mk-bool-var added-eqs restarts'.split()
  z=csv.writer(f);z.writerow(['budget','names','engine',*keys,'instructions','cycles'])
  for lim in (500,2000,5000,10000,20000,40000,80000,160000,320000,640000,1280000,2560000,5120000,6000000):
   for nm,txt in texts.items():
    st0=None
    for engine,b in bs.items():
     # Keeping the shell setup fixed across both names makes each prefix comparable.
     text=once(txt,'(set-option :rlimit 6000000)','')
     text=once(text,'(check-sat)','(set-option :rlimit '+str(lim)+')\n(check-sat)')
     pf=od/'perf';r=run(['taskset','-c',str(cpu),perf,'stat','-x,','-o',pf,'-e','instructions:u,cycles:u','--',b,'-in','-smt2','-st'],env=dict(env,GOMAXPROCS='1'),input=text,capture_output=True,text=True)
     assert '(error'not in r.stdout and not r.stderr,(case,lim,nm,engine,r.stdout[-300:],r.stderr)
     answer,=re.findall(r'^(unsat|unknown|sat)$',r.stdout,re.M);assert answer!='sat'
     st={k:int(v)for k,v in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])',r.stdout)if not any(x in k for x in ('time','alloc','memory'))}
     a=[answer,*[st.get(k,0)for k in keys[1:]]];ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];assert len(ct)==2
     z.writerow([lim,nm,engine,*a,*ct]);f.flush()
     if st0 is not None and st0!=(answer,st):print('cross-engine discrepancy',case,lim,nm,flush=True)
     st0=answer,st
   print(case,lim,flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as e:list(e.map(sample,[(26,'apple2-110'),(29,'apple2-132'),(34,'sys_live-110')]))
