from common import *
import live_checks as lc,selective_premise_release as rel,holdouts as ho
rd=d/'selective-enumeration-history';rd.mkdir(exist_ok=True)
def make(en):
 ed={};k=lc.bridge;s=k.read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('\n\tif overallResult == smt.Unsat',i);v=s[i:j]
 v=once(v,'z3solver := s.newZ3Solver()','trialOrdinal++;batch:=trialOrdinal;z3solver := s.newZ3Solver()')
 v=once(v,'for _, fc := range finalCond {','for j,fc:=range finalCond {')
 v=once(v,'if proveGoal(zCond) {','fmt.Fprintln(os.Stderr,"ENUMCOORD",batch,j+1,"early");earlyOK:=proveGoal(zCond);fmt.Fprintln(os.Stderr,"ENUMEND",batch,j+1,"early",earlyOK);if earlyOK{')
 x='res, err := s.decideZ3With(z3solver, finalCheck)';v=once(v,x,'fmt.Fprintln(os.Stderr,"ENUMCOORD",batch,j+1,"check");'+x+';fmt.Fprintln(os.Stderr,"ENUMEND",batch,j+1,"check",int(res))')
 s=s[:i]+v+s[j:]+'\nvar trialOrdinal int\n'
 if '"os"'not in s:s=once(s,'import (','import ("os";')
 ed[k]=s
 k=lc.core;s=k.read_text();i=s.index('func (s *Z3Solver) checkVerificationCondition(');j=s.index('\n}',i);t=s[i:j];x='r, err := s.c.Check()';t=once(t,x,'end:=trialPassBegin("original");'+x+';end()');ed[k]=s[:i]+t+s[j:];ed[k.parent/'original_check_study.go']=lc.helper
 k=pkg/'api/api_enumeration_refutation.go';s=once(k.read_text(),'import (','import ("os";"fmt";"encoding/json";')
 s=once(s,'if p.kernel == nil {','fresh:=p.kernel==nil;if p.kernel == nil {')
 x='proved, err := p.kernel.check(m, *problem, 6_000_000, true)';s=once(s,x,'end:=trialPassBegin("enumeration");'+x+''';end()
 info:=struct{Problem *order.Problem;New,Proved bool;Owner string}{problem,fresh,proved,fmt.Sprintf("%p",p)}
 data,e:=json.Marshal(info);if e!=nil{panic(e)};fmt.Fprintln(os.Stderr,"ENUMJSON",string(data))''')
 ed[k]=s;ed[k.parent/'enumeration_check_study.go']=lc.helper.replace('package smt','package api')
 if en=='after':
  k=pkg/'api/api_verification_goal.go';ed[k]=rel.sources()[k]
 return build(rd/en/'checker',o=overlay(rd/en/'overlay',ed))
def lane(j,en,b):
 c,n,sp,iso,rc,ref=j;sd=rd/n/en;sd.mkdir(parents=True);coord=None;cost=Counter();nodes=[];seq=0;other=bytearray()
 with(sd/'stdout').open('wb')as out,gzip.open(sd/'problems.jsonl.gz','wt',compresslevel=2)as raw,(sd/'checks.csv').open('w')as dest:
  wr=csv.writer(dest);wr.writerow('batch goal phase result source_checks source_instructions enum_checks enum_instructions enum_sequence'.split())
  with subprocess.Popen(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],stdout=out,stderr=subprocess.PIPE,cwd=sd,env=dict(env,GOMAXPROCS='1'))as pr:
   for l in pr.stderr:
    if l.startswith(b'ENUMCOORD '):
     assert coord is None;coord=l.decode().split()[1:];cost.clear();nodes=[]
    elif l.startswith(b'ENUMEND '):
     t=l.decode().split();assert t[1:4]==coord;wr.writerow([*coord,t[4],cost['original_n'],cost['original'],cost['enumeration_n'],cost['enumeration'],' '.join(map(str,nodes))]);dest.flush();coord=None
    elif l.startswith(b'INNER-CHECK '):
     _,k,tid,lo,hi,work,empty=l.decode().split()
     if coord:cost[k]+=int(work)-int(empty);cost[k+'_n']+=1
    elif l.startswith(b'ENUMJSON '):
     info=json.loads(l[len(b'ENUMJSON '):]);seq+=1
     if coord:nodes.append(seq)
     raw.write(json.dumps(dict(seq=seq,coord=coord,**info),separators=(',',':'))+'\n')
    else:other.extend(l)
   ret=pr.wait()
 assert coord is None and(ret,(sd/'stdout').read_bytes(),other)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(en,n,ret,other[-500:])
 (sd/'validated').write_text('matched expected exit, stdout and stderr\n');print(en,n,seq,flush=True)
def main():
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(('before','after'),ex.map(make,('before','after'))))
 a=ho.jobs()[0];sl=(0,'sys_live','doc/examples/apple/ord_live2.ivy','sys_live',0,w/'long-alternatives/ord2-sys/reference')
 with ThreadPoolExecutor(4)as e:
  fs=[e.submit(lane,(c,*j[1:]),en,bs[en])for cs,j in [([9,18],a),([31,41],sl)]for c,en in zip(cs,('before','after'))]
  for f in fs:f.result()
if __name__=='__main__':main()
