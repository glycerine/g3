from common import *
import selective_premise_release as rel,holdouts as ho
rd=d/'premise-layout-sensitivity';rd.mkdir(exist_ok=True)
def make(v):
 f=ivy.resolve()/'smt/g3.go';s=once(f.read_text(),'import (','import ("os";"strconv";')
 s=once(s,'return &Z3Context{c: c, roots: make(map[ast.ASTHandle]bool)}','''ctx:=&Z3Context{c:c,roots:make(map[ast.ASTHandle]bool)}
 if trialPadding>0 {
   m,e:=ctx.c.Manager();fail(e);sort:=handle(m.MkBoolSort())
   for i:=0;i<trialPadding;i++{ctx.keep(handle(m.MkVar(uint32(128+i),sort)))}
 }
 return ctx''')+'\nvar trialPadding=func()int{x,e:=strconv.Atoi(os.Getenv("G3_AST_PADDING"));if e!=nil{return 0};return x}()\n'
 ed={f:s}
 if v=='after':
  p=pkg/'api/api_verification_goal.go';ed[p]=rel.sources()[p]
 return build(rd/v/'checker',o=overlay(rd/v/'overlay',ed))
def lane(task,bs):
 from types import SimpleNamespace
 from panel import measure,EVENTS
 import shlex
 c,n,sp,iso,rc,ref,pad=task;sd=rd/f'{n}-pad{pad}';sd.mkdir();engines=list(bs);cfg=SimpleNamespace(cpu=c,perf=perf,spec=examples/sp,isolate=iso)
 with(sd/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['case','padding','round','engine','match','wall','user','sys','rss',*EVENTS])
  for i in range(2):
   reverse=(i+(1 if pad in(1,31)else 0))%2
   for en in engines[::-1 if reverse else 1]:
    path=sd/f'run-{i+1}-{en}';wrap=sd/(en+'.sh');wrap.write_text('#!/bin/sh\nG3_AST_PADDING='+str(pad)+' exec '+shlex.quote(str(bs[en]))+' "$@"\n');wrap.chmod(0o700)
    ret,t,ct=measure(wrap,cfg,path,rc,100);match=ret==rc and all((ref/k).read_bytes()==(path/k).read_bytes()for k in ('stdout','stderr'));z.writerow([n,pad,i+1,en,int(match),*t,*ct]);f.flush();assert match,(n,pad,en,ret);print(n,pad,i+1,en,round(ct[0]/1e9,2),flush=True)
def main():
 with ThreadPoolExecutor(2)as e:bs=dict(zip(('before','after'),e.map(make,('before','after'))))
 apple2=ho.jobs()[0];syslive=(25,'sys_live','doc/examples/apple/ord_live2.ivy','sys_live',0,w/'long-alternatives/ord2-sys/reference')
 jobs=[(c,*j[1:],pad) for j,cpus in ((apple2,[23,30,35,43]),(syslive,[7,10,21,39])) for c,pad in zip(cpus,(0,1,7,31))]
 with ThreadPoolExecutor(8)as e:list(e.map(lambda j:lane(j,bs),jobs))
if __name__=='__main__':main()
