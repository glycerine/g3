from pathlib import Path
import subprocess,json,collections
w=Path(__file__).resolve().parent;p=Path.cwd()
d={}
for file,hooks in [('smtcore/smt_asserted_driver.go',[('func (k *SMTKernel) reduceAssertedPending()', 'println("R+");defer println("R-")')]),('ast/rewriter/rewriter_engine.go',[('func (r *rewriterEngine) '+m,'if _,th:=r.cfg.(*theoryRewriterConfiguration); th && !r.core.proofGen { println("'+name+'") }') for m,name in [('visit(','VISIT'),('processApp(','PROCESS')]])]:
 a=p/file;s=a.read_text()
 for method,hook in hooks:
  i=s.index(' {',s.index(method))+2;s=s[:i]+'\n'+hook+s[i:]
 b=w/a.name;b.write_text(s);d[str(a)]=str(b)
ov=w/'visits.json';ov.write_text(json.dumps({'Replace':d}));subprocess.run(['go','build','-overlay',ov,'-o',w/'visit-observer','./cmd/g3'],check=True)
for n in [22,39]:
 r=subprocess.run([w/'visit-observer',f'/tmp/g3-arith-ops/{n}.smt2'],capture_output=True,check=True);assert r.stdout.startswith(b'unsat\n');active=0;c=collections.Counter()
 for k in r.stderr.decode().splitlines():
  if k=='R+':active+=1
  elif k=='R-':active-=1
  elif active:c[k]+=1
 assert active==0;(w/f'g3-visits-{n}.json').write_text(json.dumps(c))
