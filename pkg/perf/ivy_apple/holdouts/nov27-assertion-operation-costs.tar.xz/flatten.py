from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'ast/rewriter/rewriter_engine.go';s=a.read_text();i=s.index('// f->is_associative()',s.index('func (r *rewriterEngine) processApp()'));j=s.index('size :=',i)
s=s[:i]+'''// Flatten only consecutive applications of the same declaration.
		if fi > 0 {
			parent := &c.frames[fi-1]
			if parent.kind == ast.ASTApp && parent.state() == 0 {
				pd, err := m.GetDecl(parent.curr)
				if err != nil { return err }
				if pd == d {
					rc, err := m.GetRefCount(t)
					if err != nil { return err }
					if rc <= 1 {
						assoc, err := m.RewriterAssociative(d)
						if err != nil { return err }
						if assoc {
							flat, err := r.cfg.FlatAssoc(d)
							if err != nil { return err }
							if flat {
								c.frames = c.frames[:fi]
								return r.setNewChild(t)
							}
						}
					}
				}
			}
		}
		'''+s[j:]
g=w/'flatten.go';g.write_text(s);subprocess.run(['gofmt','-w',g],check=True)
d=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());d['Replace'][str(a)]=str(g);ov=w/'flatten.json';ov.write_text(json.dumps(d))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',ov,'-o',w/'flatten','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
