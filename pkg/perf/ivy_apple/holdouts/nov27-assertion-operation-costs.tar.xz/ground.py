from pathlib import Path
import re,json
w=Path(__file__).resolve().parent
def parse(src):
 root=[];stack=[root]
 for t in re.findall(r'\(|\)|\|[^|]*\||[^()\s]+',src):
  if t=='(':n=[];stack[-1].append(n);stack.append(n)
  elif t==')':stack.pop()
  else:stack[-1].append(t)
 assert len(stack)==1
 return root
def emit(x):return x if isinstance(x,str) else '('+' '.join(emit(i) for i in x)+')'
def weaken(x,env):
 if isinstance(x,str):return ('true',1) if env.get(x,False) else (x,0)
 if x[0]=='forall':return 'true',1
 if x[0]=='let':
  local=env.copy()
  for n,v in x[1]:local[n]=(isinstance(v,list) and v[0]=='forall') or (isinstance(v,str) and env.get(v,False))
  body,num=weaken(x[2],local)
  return ['let',x[1],body],num
 if x[0]=='and':
  pairs=[weaken(c,env) for c in x[1:]]
  return ['and']+[v for v,_ in pairs],sum(n for _,n in pairs)
 return x,0
counts={}
for goal in [22,36,37,39]:
 src=parse(Path(f'/tmp/g3-arith-ops/{goal}.smt2').read_text())
 counts[goal]=[]
 for cmd in src:
  if cmd[0]=='assert':
   cmd[1],n=weaken(cmd[1],{});counts[goal].append(n)
 (w/f'ground-{goal}.smt2').write_text('\n'.join(map(emit,src))+'\n')
(w/'ground-counts.json').write_text(json.dumps(counts))
