from pathlib import Path
import csv, collections
w=Path(__file__).resolve().parent
d=collections.Counter()
for r in csv.DictReader(open('/tmp/g3-arith-ops/profiles.csv')):
 s=r['stack'].splitlines();e=r['engine'];n=int(r['samples'])
 for i,f in enumerate(s):
  if f.endswith(').internalizePending') or f=='smt::context::internalize_assertions()':
   d[r['goal'],e,'internalize',s[i-1] if i else 'self']+=n
   for j,g in enumerate(s[:i]):
    if g.endswith(').invokeAssertedPass'):
     d[r['goal'],e,'invoke',s[j-1] if j else 'self']+=n
    if g=='asserted_formulas::reduce()' or g.endswith(').reduceAssertedPending'):
     if any('rewriter_tpl<th_rewriter_cfg>' in h for h in s[:j]) or any('theoryRewriterConfiguration' in h for h in s[:j]):
      d[r['goal'],e,'config-symbol-visible','any']+=n
   break
with (w/'stacks.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['goal','engine','boundary','child','samples','estimated-instructions']);o.writerows([*k,n,n*250003/80] for k,n in sorted(d.items()))
