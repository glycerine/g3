from pathlib import Path
import csv,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();modes=['base','trial','flatten'];perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
for mode in modes:
 subprocess.run(['go','build',*(['-overlay',w/(mode+'.json')] if mode!='base' else []),'-o',w/('cli-'+mode),'./cmd/g3'],check=True)
with (w/'replay.csv').open('w') as f:
 o=csv.writer(f);o.writerow('goal round mode repeats instructions'.split())
 for goal in [22,36,37,39]:
  one=Path(f'/tmp/g3-arith-ops/{goal}.smt2').read_text().split('(get-info')[0]
  for i in range(7):
   for mode in modes[i%3:]+modes[:i%3]:
    stat=w/'replay.stat';reps=24;r=subprocess.run(['taskset','-c','20',perf,'stat','-x,','-e','instructions:u','-o',stat,'--',w/('cli-'+mode),'-smt2','-in'],input=((one+'\n(reset)\n')*reps).encode(),env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,check=True)
    assert r.stdout==b'unsat\n'*reps and not r.stderr
    n,=[int(z[0]) for z in csv.reader(stat.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100];o.writerow([goal,i,mode,reps,n]);f.flush()
