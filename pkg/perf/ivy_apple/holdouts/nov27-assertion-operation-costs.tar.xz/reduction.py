from pathlib import Path
import csv,collections
w=Path(__file__).resolve().parent;d=collections.Counter()
for r in csv.DictReader(open('/tmp/g3-arith-ops/profiles.csv')):
 s=r['stack'].splitlines()
 if not any(f.endswith(').internalizePending') or f=='smt::context::internalize_assertions()' for f in s):continue
 for i,f in enumerate(s):
  if f.endswith(').reduceAssertedPending') or f=='asserted_formulas::reduce()':break
 else:continue
 for g in s[:i][::-1]:
  if '/ast.(*ASTManager).' in g or '/ast.(*ActivityCache).' in g:break
 else:g='other'
 d[r['goal'],r['engine'],g]+=int(r['samples'])
with (w/'reduction.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['goal','engine','outermost-manager-or-activity-cache','samples','estimated-instructions']);o.writerows([*k,n,n*250003/80] for k,n in d.most_common())
