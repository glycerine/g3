from pathlib import Path
import json,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'ast/rewriter/arith_rewriter.go';s=a.read_text();i=s.index('nodeKind, err :=',s.index('func (r *ArithRewriter) operation'));j=s.index('matched :=',i)
s=s[:i]+'''app, family, kind, err := r.manager.AppIdentity(h)
	if err != nil || !app || family != r.family {
		return 0, nil, false, err
	}
	'''+s[j:]
i=s.index('kind, err :=',s.index('func (r *ArithRewriter) arithmeticTerm'));j=s.index('\n}',i)
s=s[:i]+'''app, family, _, err := r.manager.AppIdentity(h)
	return err == nil && app && family == r.family, err'''+s[j:]
i=s.index('nodeKind, err :=',s.index('func (r *ArithRewriter) isITE'));j=s.index('\n}',i)
s=s[:i]+'''app, family, kind, err := r.manager.AppIdentity(h)
	return err == nil && app && family == r.manager.BasicFamilyID() && kind == ast.ASTOpIte, err'''+s[j:]
g=w/a.name;g.write_text(s);d=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());d['Replace'][str(a)]=str(g)
ov=w/'trial.json';ov.write_text(json.dumps(d))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',ov,'-o',w/'trial','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
