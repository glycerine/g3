import gdb,collections,os,json
d=collections.Counter()
class B(gdb.Breakpoint):
 def stop(self):
  f=gdb.newest_frame()
  while f:
   if f.name()=='smt::context::internalize_assertions()':
    d[self.location]+=1
    break
   f=f.older()
  return False
for sig in ['smt::context::mk_bool_var(expr*)','smt::context::internalize_assertion(expr*, app*, unsigned int)','smt::context::mk_enode(app*, bool, bool, bool)']:B(sig)
g=os.environ['GOAL_NR']
gdb.execute('run /tmp/g3-arith-ops/'+g+'.smt2')
open('/tmp/g3-assert-op/native-'+g+'.json','w').write(json.dumps(d))
