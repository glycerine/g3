from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off,classic_z3','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay','/tmp/g3-ticket-first/validation/final.json','-o',w/'linked','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
