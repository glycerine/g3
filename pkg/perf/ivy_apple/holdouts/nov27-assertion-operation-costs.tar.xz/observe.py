from pathlib import Path
import subprocess,json,collections
w=Path(__file__).resolve().parent;p=Path.cwd();d={}
for name,hooks in [('smt_kernel',[('internalizePending()', 'println("OP-begin"); defer println("OP-end")')]),('smt_scoped_clause',[('internalizePendingRow(', 'println("OP-row")')]),('smt_internalizer_state',[('mkBoolVar(', 'println("OP-var")'),('mkEnode(', 'println("OP-enode")')])]:
 a=p/'smtcore'/(name+'.go');s=a.read_text()
 for method,hook in hooks:
  i=s.index(' {',s.index(') '+method))+2;s=s[:i]+'\n'+hook+s[i:]
 b=w/a.name;b.write_text(s);d[str(a)]=str(b)
ov=w/'observe.json';ov.write_text(json.dumps({'Replace':d}));subprocess.run(['go','build','-overlay',ov,'-o',w/'observer','./cmd/g3'],check=True)
for n in [22,39]:
 r=subprocess.run([w/'observer',f'/tmp/g3-arith-ops/{n}.smt2'],capture_output=True,check=True);assert r.stdout.startswith(b'unsat\n');active=0;c=collections.Counter()
 for k in r.stderr.decode().splitlines():
  if k=='OP-begin':active+=1
  elif k=='OP-end':active-=1
  elif active:c[k]+=1
 assert active==0;(w/f'g3-{n}.json').write_text(json.dumps(c))
