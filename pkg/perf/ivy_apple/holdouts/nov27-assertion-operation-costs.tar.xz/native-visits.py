import gdb,collections,os,json
d=collections.Counter()
class B(gdb.Breakpoint):
 def stop(self):
  f=gdb.newest_frame()
  while f:
   if f.name()=='asserted_formulas::reduce()':
    d[self.location]+=1
    break
   f=f.older()
  return False
for sig in ['_ZN12rewriter_tplI15th_rewriter_cfgE5visitILb0EEEbP4exprj','_ZN12rewriter_tplI15th_rewriter_cfgE11process_appILb0EEEvP3appRN13rewriter_core5frameE']:B(sig)
g=os.environ['GOAL_NR']
gdb.execute('run /tmp/g3-arith-ops/'+g+'.smt2')
open('/tmp/g3-assert-op/native-visits-'+g+'.json','w').write(json.dumps(d))
