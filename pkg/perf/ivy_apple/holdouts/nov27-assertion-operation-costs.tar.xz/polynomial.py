from pathlib import Path
import subprocess,os,csv,time
w=Path(__file__).resolve().parent;perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'polynomial.csv').open('w') as f:
 o=csv.writer(f);o.writerow('goal round engine tactic status instructions'.split())
 for goal in [22,36,37,39]:
  one=Path(f'/tmp/g3-arith-ops/{goal}.smt2').read_text().split('(get-info')[0]
  for i in range(3):
   for engine,exe in [('g3',w/'cli-base'),('native',Path.cwd().parent/'build/z3')][::1 if i%2==0 else -1]:
    for tactic in ['default','som','arith_lhs','sort_sums','hoist_mul']:
     query=one if tactic=='default' else f'(set-option :rewriter.{tactic} true)\n'+one
     stat=w/'polynomial.stat'
     try:r=subprocess.run(['taskset','-c','22',perf,'stat','-x,','-e','instructions:u','-o',stat,'--',exe,'-smt2','-in'],input=query.encode(),capture_output=True,env=dict(os.environ,GOMAXPROCS='1'),timeout=3)
     except subprocess.TimeoutExpired:o.writerow([goal,i,engine,tactic,'timeout','']);continue
     n,=[int(z[0]) for z in csv.reader(stat.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100]
     o.writerow([goal,i,engine,tactic,(r.stdout+r.stderr).decode().strip()[:250],n]);f.flush()
