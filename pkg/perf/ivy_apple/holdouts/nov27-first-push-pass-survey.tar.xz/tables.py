from pathlib import Path
from statistics import median
from collections import defaultdict,Counter
import csv
w=Path(__file__).resolve().parent
for d in [w,w/'shape',w/'finish']:
 groups=defaultdict(list)
 for f in sorted(d.glob('rows*.csv')):
  for r in csv.DictReader(f.open()):groups[r['case'],r['stage']].append((int(r['rows']),int(r['instructions'])))
 with (d/'row-summary.csv').open('w') as f:
  o=csv.writer(f);o.writerow(['stage','rows','instructions'])
  for k in sorted(set(k for n,k in groups)):
   vals=[v for (n,z),v in groups.items() if k==z];assert len(vals)==10 and all(len(v)==3 for v in vals)
   o.writerow([k,*[sum(median(x[i] for x in v) for v in vals) for i in [0,1]]])
for d in [w,w/'publish']:
 groups=defaultdict(dict)
 for r in csv.DictReader((d/'whole.csv').open()):
  assert r['status']=='match';groups[r['case'],r['round']][r['mode']]=r
 with (d/'trial-summary.csv').open('w') as f:
  o=csv.writer(f);o.writerow(['input','pairs','instructions_pct','elapsed_pct'])
  for n in sorted(set(n for n,i in groups)):
   v=[z for (a,i),z in groups.items() if a==n and len(z)==2]
   o.writerow([n,len(v),*[round(median(100*(float(z['release'][k])/float(z['base'][k])-1) for z in v),2) for k in ['instructions','ms']]])
