from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import csv,os,subprocess
w=Path(__file__).resolve().parent;src=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
paths=(src/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((src/'ranking.csv').open())}
cases=[r['case'] for r in sorted((r for r in csv.DictReader(open('/tmp/g3-frame-child/frontier-phases.csv')) if r['stage']=='first'),key=lambda r:-int(r['difference']))[:10]]
def run(lane):
 with (w/f'rows{lane}.csv').open('w') as f:
  out=csv.writer(f);out.writerow('case round stage rows instructions'.split())
  for name in cases[lane::4]:
   d=src/'compat'/str(paths.index(name)+1)/'1/native'
   for i in range(3):
    r=subprocess.run(['taskset','-c',str(12+lane*2),w/'value',ex/name],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=150)
    keep=[];rows=Counter();ins=Counter()
    for line in r.stderr.splitlines(keepends=True):
     if line.startswith(b'IVY-PUSH-VALUE '):
      _,_,k,n,v=line.decode().split();rows[k]+=int(n);ins[k]+=int(v)
     elif not line.startswith((b'IVY-PUSH-PASS ',b'IVY-PUSH-TOTAL ',b'IVY-PUSH-STAGE ')):keep.append(line)
    assert (r.returncode,r.stdout,b''.join(keep))==(codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes())
    assert sum(rows[k+'-same'] for k in ['ground','open-app','quantifier'])>0
    for k in ['ground','open-app','quantifier']:
     assert rows[k+'-same']==rows[k+'-update-same'] and rows[k+'-changed']==rows[k+'-update-changed']
    for k,n in rows.items():out.writerow([name,i,k,n,ins[k]])
    f.flush()
with ThreadPoolExecutor(4) as pool:list(pool.map(run,range(4)))
