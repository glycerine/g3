from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads((w.parent/'shape/shape.json').read_text())['Replace']
def save(src,s):
 d=w/(src.name+'.txt');d.write_text(s);ov[str(src)]=str(d)
f=p/'ast/rewriter/th_rewriter.go';s=f.read_text()
i=s.index('func (c *theoryRewriterConfiguration) ReduceQuantifier(');j=s.index('m := c.owner.manager',i);s=s[:i]+'var StudyQuantifier func(int)\n\n'+s[i:j]+'''if StudyQuantifier!=nil {StudyQuantifier(0);defer StudyQuantifier(3)}
 '''+s[j:];i=s.index('updatedRef, err :=',j);s=s[:i]+'if StudyQuantifier!=nil {StudyQuantifier(1)}\n '+s[i:];i=s.index('value, err := m.RefGet(eliminated)',i);s=s[:i]+'if StudyQuantifier!=nil {StudyQuantifier(2)}\n '+s[i:];save(f,s)
f=p/'smtcore/first_push_meter.go';s=Path(ov[str(f)]).read_text().replace('[16]uint64','[22]uint64').replace('"followup-update-changed"}','"followup-update-changed","same-annotations","same-elim","same-return","changed-annotations","changed-elim","changed-return"}');s+='''
var qmark uint64
var qpart,qcalls [3]uint64
func studyQuantPart(which int){now:=studyreadCounter();if which>0{v:=now-qmark;if v>studyempty{qpart[which-1]+=v-studyempty};qcalls[which-1]++};qmark=studyreadCounter()}
''';save(f,s)
f=p/'smtcore/smt_asserted_propagate.go';s=Path(ov[str(f)]).read_text().replace('"errors"','"errors"\n"github.com/glycerine/g3/pkg/ast/rewriter"')
s=s.replace(';vt=studyreadCounter()};one, result',';if group==0{qpart=[3]uint64{};qcalls=[3]uint64{};rewriter.StudyQuantifier=studyQuantPart};vt=studyreadCounter()};one, result').replace('vstop(vi,vt)}','vstop(vi,vt);if group==0{rewriter.StudyQuantifier=nil;start:=16;if one{start=19};for j:=0;j<3;j++{vcounts[start+j]+=qpart[j];vrows[start+j]+=qcalls[j]}}}',1)
assert 'rewriter.StudyQuantifier=studyQuantPart' in s;save(f,s)
o=w/'finish.json';o.write_text(json.dumps({'Replace':ov}));src=(w.parent/'shape/build.py').read_text().split("front=(p/",1)[1];exec("front=(p/"+src)
