from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();src=p/'smtcore/smt_asserted_reduce.go';s=src.read_text()
a=s.index('batch, err := macros.NewFormulaBatch',s.index('func (k *SMTKernel) reducePendingAssertions'));b=s.index('return k.traceAssertedState',a)
s=s[:a]+'''var batch *macros.FormulaBatch
 defer func(){if batch!=nil{result=errors.Join(result,batch.Close())}}()
 for index,row:=range k.assertions[k.assertedHead:] {
  formula,proof,err:=k.preprocessAssertionMode(row.Formula,row.Proof,assertedProofSimplify)
  if err!=nil{return err}
  if batch==nil && formula!=row.Formula {
   batch,err=macros.NewFormulaBatch(k.manager)
   if err==nil{for _,prior:=range k.assertions[k.assertedHead:k.assertedHead+index]{err=batch.Insert(macros.Formula{Expression:prior.Formula,Proof:prior.Proof});if err!=nil{break}}}
  }
  if batch!=nil && err==nil{err=k.appendTransformedAssertion(batch,row,formula,proof)}
  err=errors.Join(err,k.manager.DecRef(formula),k.manager.DecRef(proof))
  if err!=nil{return err}
  if canceled,err:=k.manager.Canceled();canceled||err!=nil{return err}
 }
 if batch!=nil{if err:=k.swapPendingFormulaBatch(batch);err!=nil{return err}}
 '''+s[b:];dst=w/'reduce.go.txt';dst.write_text(s)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
s=(w.parent/'reftrial.py').read_text().split('script=Path',1)[1];exec('script=Path'+s)
