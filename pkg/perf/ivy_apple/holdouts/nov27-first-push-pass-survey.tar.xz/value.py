from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
ov=json.loads((w/'meter.json').read_text())['Replace']
def save(src,s):
 out=w/('value-'+src.name+'.txt');out.write_text(s);ov[str(src)]=str(out)
f=p/'smtcore/first_push_meter.go'
s=Path(ov[str(f)]).read_text()
i=s.index('start:=studyreadCounter();return func()')
s=s[:i]+s[i:].replace('start:=studyreadCounter();return func()','vcounts=[4]uint64{}; vrows=[4]uint64{}; start:=studyreadCounter();return func()',1).replace('studyactive = false','studyactive = false; for i,name:=range []string{"row-same","row-changed","update-same","update-changed"}{fmt.Fprintln(os.Stderr,"IVY-PUSH-VALUE",studyordinal,name,vrows[i],vcounts[i])}',1)
s+='\nvar vcounts,vrows [4]uint64\nfunc vstop(i int,start uint64){v:=studyreadCounter()-start;if v>studyempty{vcounts[i]+=v-studyempty};vrows[i]++}\n';save(f,s)
f=p/'smtcore/smt_asserted_propagate.go';s=f.read_text()
s=s.replace('one, result = k.rewritePendingAssertion(i)','var vt uint64;if studyactive {vt=studyreadCounter()};one, result = k.rewritePendingAssertion(i); vi:=0;if one {vi=1};if studyactive {vstop(vi,vt)}').replace('result = k.addAssertionSubstitution(k.assertions[i], depth)','if studyactive {vt=studyreadCounter()};result = k.addAssertionSubstitution(k.assertions[i], depth);if studyactive {vstop(vi+2,vt)}');save(f,s)
ovpath=w/'value.json';ovpath.write_text(json.dumps({'Replace':ov}))
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',ovpath,'-o',w/'value','./cmd/goivy_check'],cwd=front,check=True)
