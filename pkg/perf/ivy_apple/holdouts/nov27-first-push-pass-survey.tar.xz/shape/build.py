from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
ov=json.loads((w.parent/'value.json').read_text())['Replace']
for src in [p/'smtcore/first_push_meter.go',p/'smtcore/smt_asserted_propagate.go']:
 s=Path(ov[str(src)]).read_text()
 if src.name=='first_push_meter.go':
  s=s.replace('[4]uint64','[16]uint64').replace('"row-same","row-changed","update-same","update-changed"',','.join('"'+b+'-'+v+'"' for b in ['quantifier','ground','open-app','followup'] for v in ['same','changed','update-same','update-changed']))
 else:
  key='var vt uint64;if studyactive {vt=studyreadCounter()}'
  s=s.replace(key,'''var vt uint64;group:=0;if studyactive{f:=k.assertions[i].Formula;kind,e:=k.manager.GetKind(f);if e!=nil{panic(e)};if kind!=ast.ASTQuantifier{ground,e:=k.manager.IsGround(f);if e!=nil{panic(e)};if ground{group=4}else{group=8}};vt=studyreadCounter()}''').replace('vi:=0;if one {vi=1}','vi:=group;if one {vi++}')
  s=s.replace('if changed {\n\t\treturn k.reducePendingAssertions()', 'if changed {\n if studyactive {t:=studyreadCounter();e:=k.reducePendingAssertions();vstop(12,t);return e};return k.reducePendingAssertions()')
 d=w/(src.name+'.txt');d.write_text(s);ov[str(src)]=str(d)
o=w/'shape.json';o.write_text(json.dumps({'Replace':ov}));front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',o,'-o',w/'value','./cmd/goivy_check'],cwd=front,check=True)
