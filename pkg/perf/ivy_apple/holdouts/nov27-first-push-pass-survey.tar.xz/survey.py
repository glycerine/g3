from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import csv,os,sys,subprocess
w=Path(__file__).resolve().parent
native=w/'native'
ref=Path('/tmp/g3-reduction-rows'); ex=Path('/home/jaten/ivy/ivy-lang-examples')
paths=(ref/'compat.txt').read_text().splitlines()
codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
cases=sorted((r for r in csv.DictReader(open('/tmp/g3-frame-child/frontier-phases.csv')) if r['stage']=='first'),key=lambda r:-int(r['difference']))
all_names={r['case'] for f in Path('/tmp/g3-frame-child').glob('frontier-status*.csv') for r in csv.DictReader(f.open())}
cases.extend({'case':name} for name in sorted(all_names-{r['case'] for r in cases}))
def run(lane):
 dest=w/f'lane{lane}.csv'
 valid=[]
 if dest.exists():
  with dest.open() as old:valid=[r for r in csv.DictReader(old) if r['status']=='match']
 done={(r['case'],r['round'],r['engine']) for r in valid}
 with dest.open('w') as f:
  out=csv.writer(f);out.writerow('case round engine status pass calls instructions'.split())
  for r in valid:out.writerow(r.values())
  for row in cases[lane::6]:
   name=row['case'];d=ref/'compat'/str(paths.index(name)+1)/'1/native'
   expected=codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes()
   for i in range(3):
    for e,binary in [('g3',w/'meter'),('native',native)][::1 if i%2==0 else -1]:
     if (name,str(i),e) in done:continue
     r=subprocess.run(['taskset','-c',str(lane*2+2),binary,ex/name],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
     keep=[];work=Counter();calls=Counter();pending=[]
     def add(key,n):work[key]+=int(n);calls[key]+=1
     for line in r.stderr.splitlines(keepends=True):
      a=line.split()
      if line.startswith(b'IVY-PUSH-PASS '):add(a[2].decode(),a[4])
      elif line.startswith(b'IVY-PUSH-TOTAL '):add('TOTAL',a[2])
      elif line.startswith(b'IVY-PUSH-STAGE '):pass
      elif line.startswith(b'PASS-COUNT '):
       assert a[4]==a[5];pending.append((a[1].decode(),a[2]))
      elif line.startswith(b'STAGE-COUNT '):
       assert a[6]==a[7]
       if a[3]==b'first':
        add('TOTAL',a[4])
        for k,n in pending:add(k,n)
       else:assert not pending
       pending=[]
      else:keep.append(line)
     assert not pending
     ok=(r.returncode,r.stdout,b''.join(keep))==expected
     for k in sorted(work or {'TOTAL':0}):out.writerow([name,i,e,'match' if ok else 'different',k,calls[k],work[k]])
     f.flush()
with ThreadPoolExecutor(6) as pool:list(pool.map(run,map(int,sys.argv[1:]) if sys.argv[1:] else range(6)))
