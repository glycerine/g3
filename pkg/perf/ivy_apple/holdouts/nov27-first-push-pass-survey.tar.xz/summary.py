from pathlib import Path
from collections import defaultdict,Counter
from statistics import median
import csv
w=Path(__file__).resolve().parent
raw=defaultdict(dict); done=defaultdict(set)
for f in sorted(w.glob('lane*.csv')):
 for r in csv.DictReader(f.open()):
  if r['status']!='match':continue
  n,e,i,k=r['case'],r['engine'],int(r['round']),r['pass']
  raw[n,e,i][k]=int(r['instructions']);done[n].add((e,i))
rows=[];sums=Counter()
for n in sorted(done):
 if len(done[n])!=6:continue
 for k in sorted(set().union(*(raw[n,e,i] for e,i in done[n]))):
  a,b=[median(raw[n,e,i].get(k,0) for i in range(3)) for e in ['g3','native']]
  rows.append([n,k,a,b,a-b]);sums[k]+=a-b
with (w/'pass-summary.csv').open('w') as f:
 o=csv.writer(f);o.writerow('input pass g3 native excess'.split());o.writerows(rows)
print(len({r[0] for r in rows}),'complete inputs', sums.most_common())
