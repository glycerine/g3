(set-info :status unknown)
(declare-fun P (Int) Bool)
(assert
 (let (($x10 (exists ((x Int) )(! (and (= x 5) (P x)) :qid k!3))
 ))
 (not (= $x10 (P 5)))))
(check-sat-using (then simplify qe-light simplify smt))
