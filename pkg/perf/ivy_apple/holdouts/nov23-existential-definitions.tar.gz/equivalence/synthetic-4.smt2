(set-info :status unknown)
(assert
 (let (($x11 (exists ((x Int) )(! (and (= x 5) (= x 6)) :qid k!3))
 ))
 (not (= $x11 (= 5 6)))))
(check-sat-using (then simplify qe-light simplify smt))
