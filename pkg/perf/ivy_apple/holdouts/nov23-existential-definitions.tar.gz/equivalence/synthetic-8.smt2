(set-info :status unknown)
(assert
 (let (($x9 (exists ((x Bool) )(! (and (= x true) (not x)) :qid k!3))
 ))
 (not (= $x9 (not true)))))
(check-sat-using (then simplify qe-light simplify smt))
