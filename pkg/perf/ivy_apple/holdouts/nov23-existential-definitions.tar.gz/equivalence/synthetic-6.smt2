(set-info :status unknown)
(declare-fun f (Int) Int)
(declare-fun P (Int) Bool)
(assert
 (let (($x13 (exists ((x Int) )(! (and (= (f x) x) (= x (f 2)) (P x)) :qid k!3))
 ))
 (not (= $x13 (and (= (f (f 2)) (f 2)) (P (f 2)))))))
(check-sat-using (then simplify qe-light simplify smt))
