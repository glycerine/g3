"""Try sharing the assembled quantifier disjunction across instance phases."""

import argparse
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
scratch = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("trials", nargs="+")
parser.add_argument("--goivy", action="store_true")
args = parser.parse_args()


def build(name):
    parts = name.split("+")
    permitted = {"baseline", "share", "plan", "binding", "transfer"}
    if any(part not in permitted for part in parts):
        parser.error(f"unknown trial {name}")
    share = any(p in parts for p in ("share", "plan", "binding"))
    cached = "plan" in parts
    transfer = "transfer" in parts
    dst = scratch / name
    dst.mkdir(exist_ok=True)
    patches = {}

    def replace(file, before, after):
        path = pkg / "smtcore" / file
        source = patches.get(path, path).read_text()
        if source.count(before) != 1:
            raise ValueError((file, before))
        updated = dst / file
        updated.write_text(source.replace(before, after))
        patches[path] = updated

    if share:
        q = "smt_qi_instance.go"
        replace(q, '"github.com/glycerine/g3/pkg/ast/rewriter"', '"github.com/glycerine/g3/pkg/ast/rewriter"\n"github.com/glycerine/g3/pkg/util/diagnostic"')
        replace(q, "simplified, rewriteProof ast.ASTRef", "simplified, rewriteProof ast.ASTRef\n arguments []ast.ASTHandle")
        site = "func (b *SMTQIInstanceBuilder) finishLemma(prepared *SMTQIPreparedInstance, simplified ast.ASTHandle, stat *SMTQuantifierStat, scope uint32) (*SMTQIInstance, error) {"
        replace(q, site, site + """
            return b.finishLemmaWithArguments(prepared, simplified, stat, scope, nil)
        }
        func (b *SMTQIInstanceBuilder) finishLemmaWithArguments(prepared *SMTQIPreparedInstance, simplified ast.ASTHandle, stat *SMTQuantifierStat, scope uint32, arguments *[]ast.ASTHandle) (*SMTQIInstance, error) {""")
        replace(q, "\t\treturn b.Finish(prepared, rewritten, stat, scope)",
                """        if !ast.ASTValidateHandles && !ast.ASTSourceDebug && !smtcoreSourceDebug &&
                          !diagnostic.TraceCompiled() && b.manager.TraceStream == nil &&
                          !b.manager.Budget().InjectionArmed() {
                    return b.finishLemmaWithArguments(prepared, rewritten, stat, scope, &locals.arguments)
                }
                return b.Finish(prepared, rewritten, stat, scope)""")
        replace(q, "\t\t\tlemma, err = b.manager.MkOrArgs(args)",
                """            lemma, err = b.manager.MkOrArgs(args)
                if arguments != nil && len(args) > 1 {
                    *arguments = args
                }""")
        replace(q, "internalizer.InternalizeInstance(result)",
                "internalizer.internalizeInstanceWithArguments(result, locals.arguments)")
        f = "smt_internalizer.go"
        site = "func (s *SMTInternalizerState) InternalizeInstance(instance *SMTQIInstance) error {"
        replace(f, site, site + """
            return s.internalizeInstanceWithArguments(instance, nil)
        }
        func (s *SMTInternalizerState) internalizeInstanceWithArguments(instance *SMTQIInstance, arguments []ast.ASTHandle) error {""")
        replace(f, "return s.Assert(lemma, proof, instance.Generation())", "return s.assertWithArguments(lemma, proof, instance.Generation(), arguments)")
        site = "func (s *SMTInternalizerState) Assert(expression, proof ast.ASTHandle, generation uint32) error {"
        replace(f, site, site + """
            return s.assertWithArguments(expression, proof, generation, nil)
        }
        func (s *SMTInternalizerState) assertWithArguments(expression, proof ast.ASTHandle, generation uint32, operands []ast.ASTHandle) error {""")
        replace(f, """\tif basic && smtInternalizerGateOperation(op) {
        \t\targuments, err := s.argumentHandles(expression)
        \t\tif err != nil {
        \t\t\treturn err
        \t\t}""".replace("        \t", "\t"),
                """    if basic && smtInternalizerGateOperation(op) {
            arguments := operands
            if arguments == nil {
                arguments, err = s.argumentHandles(expression)
                if err != nil {
                    return err
                }
            }""")
        if "binding" in parts:
            replace(f, "\t\t\tfor index, argument := range arguments {\n\t\t\t\tif err = s.Internalize(argument, true);",
                    """            for index, argument := range arguments {
                    if operands != nil {
                        if literal, found := s.instanceBoundGateLiteral(argument); found {
                            literals[index] = literal
                            continue
                        }
                    }
                    if err = s.Internalize(argument, true);""")
            path = pkg / "smtcore" / f
            with patches[path].open("a") as stream:
                stream.write("""
func (s *SMTInternalizerState) instanceBoundGateLiteral(h ast.ASTHandle) (SMTLiteral, bool) {
    if s.closed || s.pendingPop != nil || s.closing {
        return SMTNullLiteral, false
    }
    if variable, found := s.boolVar.lookup(h); found && s.notChild(variable).IsNull() {
        return NewSMTLiteral(variable, false), true
    }
    if _, child, err := s.manager.IsNot(h); err == nil && !child.IsNull() {
        if variable, found := s.boolVar.lookup(child); found && s.notChild(variable).IsNull() {
            return NewSMTLiteral(variable, true), true
        }
    }
    return SMTNullLiteral, false
}
""")
        if cached:
            replace(q, "type SMTQIInstanceBuilder struct {", "type SMTQIInstanceBuilder struct {\n plans *[128]instanceArguments")
            first = "\t\t\targs := make([]ast.ASTHandle, 1+int(head.NumArgs))"
            end = "            lemma, err = b.manager.MkOrArgs(args)"
            path = pkg / "smtcore" / q
            source = patches[path].read_text()
            start = source.index(first)
            stop = source.index(end, start)
            replace(q, source[start:stop],
                    """            args, getErr := b.instanceArguments(prepared.quantifier, simplified, negatedQuantifier, head.NumArgs, arguments != nil)
                if getErr != nil {
                    return nil, getErr
                }
""")
            with patches[path].open("a") as stream:
                stream.write("""
type instanceArguments struct {
    quantifier, body ast.ASTHandle
    // Only the current body holds its child ASTs. Copy a hit out before
    // internalizing because callbacks may replace its cache row.
    children [8]ast.ASTHandle
}

func (b *SMTQIInstanceBuilder) instanceArguments(quantifier, body, guard ast.ASTHandle, count uint32, cache bool) ([]ast.ASTHandle, error) {
    args := make([]ast.ASTHandle, int(count)+1)
    args[0] = guard
    var hit *instanceArguments
    if cache && count <= 8 {
        if b.plans == nil {
            b.plans = new([128]instanceArguments)
        }
        slot := (quantifier.Slot()*31 + body.Slot()) % uint32(len(b.plans))
        hit = &b.plans[slot]
        if hit.quantifier == quantifier && hit.body == body {
            copy(args[1:], hit.children[:count])
            return args, nil
        }
    }
    for i := uint32(0); i < count; i++ {
        child, err := b.manager.GetArg(body, i)
        if err != nil {
            return nil, err
        }
        args[i+1] = child
    }
    if hit != nil {
        copy(hit.children[:count], args[1:])
        hit.quantifier, hit.body = quantifier, body
    }
    return args, nil
}
""")
    if transfer:
        q = "smt_quantifier_manager.go"
        replace(q, '"github.com/glycerine/g3/pkg/ast/rewriter"', '"github.com/glycerine/g3/pkg/ast/rewriter"\n"github.com/glycerine/g3/pkg/util/diagnostic"')
        replace(q, "\t\t\t\tlemmaErr = q.registry.schedule.RecordInstance(lemma)",
                """                if !instance.hasProof && !ast.ASTValidateHandles && !ast.ASTSourceDebug && !smtcoreSourceDebug &&
                      !diagnostic.TraceCompiled() && q.state.manager.TraceStream == nil && !q.state.manager.Budget().InjectionArmed() {
                    queue := q.registry.schedule
                    queue.instances = append(queue.instances, lemma)
                    queue.instanceRefs = append(queue.instanceRefs, instance.lemma)
                    queue.stats.Instances++
                    instance.closed = true
                } else {
                    lemmaErr = q.registry.schedule.RecordInstance(lemma)
                }""")
    for path in patches.values():
        subprocess.run(["gofmt", "-w", str(path)], check=True)
    cwd, output, command = pkg, "g3", ("./cmd/g3",)
    if args.goivy:
        for src, updated in list(patches.items()):
            patches[Path.home() / "g3/pkg" / src.relative_to(pkg)] = updated
        cwd, output, command = Path.home() / "ivy/goivy", "goivy_check", ("-tags=xtrace_off", "./cmd/goivy_check")
    overlay = dst / (output + ".json")
    overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k, v in patches.items()}}))
    subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", str(overlay),
                    "-o", str(dst / output), *command], cwd=cwd, check=True)


for name in args.trials:
    build(name)
