# Share constructed disjunction operands

The overlay starting point is g3 `16f6a80e0`. The earlier frozen comparator at `62d38dfa8` has identical solver source. The GoIvy frontend and examples are from `07cdeec61`, with the local g3 module replacement and the same ABC binary as the linked native control. Go used 1.27.3 on Linux amd64, with PGO off. The measurement CPU was logical CPU 11 on a Threadripper 3960X.

Run `instance_plans.py` from the root of the Go package at the starting revision. Its variants select sharing the actual argument vector, a weak recipe cache for the rewritten OR, resolving existing signed operands and transfer of lemma ownership. Build each GoIvy variant with `--goivy`, using the frontend in `~/ivy/goivy` and its local replacement at `~/g3/pkg`. The release uses the committed Go code built normally, with PGO off, and GoIvy built with `-tags=xtrace_off`.

For standalone comparisons, run the checked-in `perf/ivy_apple/holdouts/query_replay.py` with `--pairs 7 --routes incremental --cpu 11`. It checks answers, decisions, conflicts, instantiations and resource counts against the in-tree native CLI. The paired proof driver `verify.py` checks the exact exit status and both output streams for all three full verifiers. Reuse the reference files and case list from `nov24-verifier-instruction-stacks.tar.xz`, with the examples checkout in `~/ivy/ivy-lang-examples`. The runs used GOMAXPROCS 1. The separate GC-off comparison adds `--gc off`.

The ordinary tests ran `go test -count=1 ./smtcore ./api ./cmd/g3`. The instrumented run selected the SMT instance, relevance and asserted-OR tests with `-tags=g3checked,g3debug,g3trace`. Vet checked `./smtcore`.
