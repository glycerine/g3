"""Measure changes in TotalAlloc and Mallocs during seven incremental checks."""
from storage import variants
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    put(front/\'phase_observer');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+'''    put(front/'phase_observer_trial.go',timer)
    modes=['base','trial']
    for mode in modes:
        for p,source in variants(pkg):put(p,source if mode=='trial' else p.read_text())
'''+s[b:]
timer="""package goivy
import ("fmt";"os";"runtime")
var capturePush bool
var batchID int
func newStageBatch() int{batchID++;return batchID}
func startStage(b,g int)func(string){if !capturePush{return func(string){}};var start runtime.MemStats;runtime.ReadMemStats(&start);return func(phase string){var end runtime.MemStats;runtime.ReadMemStats(&end);fmt.Fprintln(os.Stderr,"STAGE-COUNT",b,g,phase,end.Mallocs-start.Mallocs,end.TotalAlloc-start.TotalAlloc,0,0)}}
"""
s=s.replace('cost[k]=int(a[4])','cost[k]=int(a[4]),int(a[5])').replace('mode,*k,v]','mode,*k,*v]').replace('goal instructions','goal allocations bytes').replace("'notification.csv'","'memory.csv'").replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]')
exec(compile(s,'memory','exec'))
