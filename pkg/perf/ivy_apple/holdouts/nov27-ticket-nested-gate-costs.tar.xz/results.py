import csv,re
from statistics import median
from pathlib import Path
from collections import Counter
d=Path(__file__).resolve().parent
for f in sorted((d/'release').glob('time-*.csv')):
    rows=list(csv.DictReader(f.open()))
    if len(rows)!=10: continue
    a,b=[median(int(r['instructions']) for r in rows if r['engine']==m) for m in ['base','trial']]
    print(f.stem,'instructions',a,b,round(100*(b/a-1),3))
c=Counter()
for r in csv.DictReader((d/'persisted-memory.csv').open()):
    for k in ['allocations','bytes']:c[r['mode'],r['case'],r['round'],k]+=int(r[k])
for case in ('4','8'):
    for k in ('allocations','bytes'):
        a,b=[median(v for key,v in c.items() if key[0]==mode and key[1]==case and key[3]==k) for mode in ('base','trial')]
        print(case,k,a,b,round(100*(b/a-1),3))
for f in sorted(d.glob('final-*.txt')):
    for n in (2,32):
        t=[list(map(int,re.findall(r'(\d+) (?:ns|B|allocs)/op',l))) for l in f.read_text().splitlines() if l.startswith(f'BenchmarkSMTInternalizeFormulaChildren/{n} ')]
        if t:print(f.name,n,list(map(median,zip(*t))))
