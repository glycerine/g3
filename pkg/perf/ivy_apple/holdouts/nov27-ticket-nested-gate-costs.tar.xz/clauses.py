"""Price each OR definition clause by input width and current SAT assignments."""
from pathlib import Path
import subprocess
d=Path(__file__).resolve().parent
exec((d/'tree.py').read_text().rsplit("exec(compile(driver,",1)[0])
tree_go,tree_cpp=prepare_go,native_sources
def prepare_go(pkg,put):
    src={};tree_go(pkg,lambda p,s:src.update({p:s}))
    for p,s in src.items():
        if p.name!='smt_internalizer.go':put(p,s);continue
        # Keep this study on the parent release even if the storage trial is in the worktree.
        baseline=subprocess.check_output(['git','show','6e92fb93b:pkg/smtcore/smt_internalizer.go']).decode()
        a='func (s *SMTInternalizerState) argumentLiterals('
        b='func (s *SMTInternalizerState) clauseLiteralExpressions('
        s=s[:s.index(a)]+baseline[baseline.index(a):baseline.index(b)]+s[s.index(b):]
        a='arguments, err := s.argumentLiterals(expression'
        b='add := func(values ...SMTLiteral)'
        i=s.index(a,s.index('func (s *SMTInternalizerState) addGateConstraints'));j=baseline.index(a,baseline.index('func (s *SMTInternalizerState) addGateConstraints'))
        s=s[:i]+baseline[j:baseline.index(b,j)]+s[s.index(b,i):]
        a=s.index('func (s *SMTInternalizerState) addGateConstraints')
        b=s.index('case ast.ASTOpIff:',a);v=s[a:b]
        v=edit(v,'return s.addGateClause(values)','return s.measureGateClause(values,track)')
        v=edit(v,'case ast.ASTOpOr:\n','case ast.ASTOpOr:\n')
        j=v.index('case ast.ASTOpOr:');v=v[:j]+edit(v[j:],'s.addGateClause(last)','s.measureGateClause(last,track)')
        s=s[:a]+v+s[b:]
        s+='''
func(s *SMTInternalizerState)measureGateClause(lits []SMTLiteral,track bool)error{
    if !track{return s.addGateClause(lits)}
    nfalse,ntrue:=0,0
    for _,l:=range lits{switch s.assignment[l.Index()]{case lbool.False:nfalse++;case lbool.True:ntrue++}}
    shape:=len(lits)*10000+nfalse*100+ntrue
    a,b:=installRead(installFD),installRead(installFD);err:=s.addGateClause(lits);installLog(installFD,4,shape,a,b);return err
}
'''
        put(p,s)
    for name in ('smt_justification_refs.go','smt_relevancy.go'):
        put(pkg/'smtcore'/name,subprocess.check_output(['git','show','6e92fb93b:pkg/smtcore/'+name]).decode())
def native_sources(pkg):
    it=tree_cpp(pkg);yield next(it);p,s=next(it)
    s=edit(s,'begin();mk_or_cnstr(to_app(n));end(2,depth);','begin();if(track)gate_meter_target=n;mk_or_cnstr(to_app(n));end(2,depth);')
    s=edit(s,'expr* measured_gate=nullptr;', 'expr* measured_gate=nullptr,*gate_meter_target=nullptr;')
    a=s.index('void context::mk_or_cnstr(');b=s.index('\n    }',a);v=s[a:b]
    v=edit(v,'literal l = get_literal(n);','''bool watch=n==gate_meter_target;if(watch)gate_meter_target=nullptr;
    auto add=[&](unsigned count,literal* lits){if(!watch){mk_gate_clause(count,lits);return;}int fd=install_fd,nfalse=0,ntrue=0;
    for(unsigned i=0;i<count;++i){auto val=get_assignment(lits[i]);if(val==l_true)++ntrue;else if(val==l_false)++nfalse;}
    auto a=operand_rd(fd),b=operand_rd(fd);mk_gate_clause(count,lits);auto used=operand_rd(fd)-2*b+a;
    fprintf(stderr,"INSTALL 4 %u %lld\\n",count*10000+nfalse*100+ntrue,used);};
    literal l = get_literal(n);''')
    v=edit(v,'mk_gate_clause(l, ~l_arg);','literal pair[]={l,~l_arg};add(2,pair);')
    v=edit(v,'mk_gate_clause(buffer.size(), buffer.c_ptr());','add(buffer.size(),buffer.c_ptr());')
    yield p,s[:a]+v+s[b:]
driver=driver.replace('==set(range(4))','==set(range(5))').replace("'tree.csv'","'clauses.csv'")
exec(compile(driver,'clauses','exec'))
