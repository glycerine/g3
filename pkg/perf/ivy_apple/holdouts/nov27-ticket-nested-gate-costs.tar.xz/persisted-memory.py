from pathlib import Path
import subprocess,tarfile
d=Path(__file__).resolve().parent
s=(d/'alloc.py').read_text().replace('from storage import variants','')
s=s.replace("for p,source in variants(pkg):put(p,source if mode=='trial' else p.read_text())","for fname in ('smt_internalizer.go','smt_relevancy.go','smt_justification_refs.go'):\n            p=pkg/'smtcore'/fname;put(p,p.read_text() if mode=='trial' else sp.check_output(['git','show','6e92fb93b:pkg/smtcore/'+fname]).decode())").replace("'memory.csv'","'persisted-memory.csv'")
exec(compile(s,'allocations','exec'))
