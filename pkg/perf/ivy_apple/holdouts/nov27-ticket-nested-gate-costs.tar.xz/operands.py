"""Attribute individual fresh operands using the TLB study's syntax classification."""
from pathlib import Path
import tarfile
d=Path(__file__).resolve().parent
exec((d/'install.py').read_text().split("exec(compile(driver,")[0])
original_go,original_cpp=prepare_go,native_sources
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    labels=t.extractfile('study/operand-kinds.py').read().decode()
def prepare_go(pkg,put):
    src={}
    original_go(pkg,lambda p,s:src.update({p:s}))
    p=pkg/'smtcore/smt_qi_instance.go';put(p,src[p])
    p=pkg/'smtcore/smt_internalizer.go'
    a=labels.index("g=Path(" ,labels.index('exec(src[:')+len('exec(src[:src.index("g=Path(")])'))
    b=labels.index("c=Path(",a)
    scope=dict(globals());exec(labels[a:b],scope);g=scope['g'].replace(' "os"',' "syscall"\n"unsafe"').replace('fd:=installMeter','fd:=installFD').replace('var start uint64;if code>=0{start=studyRd(fd)}','var a,b int64;if code>=0{a,b=installRead(fd),installRead(fd)}').replace('cost:=studyRd(fd)-start;fmt.Fprintln(os.Stderr,"F",code,cost)','installLog(fd,0,code,a,b)')
    put(p,g+src[p][src[p].index('var installFD = -1'):])
def native_sources(pkg):
    it=original_cpp(pkg);yield next(it)
    a=labels.index("c=Path(");b=labels.index('exec(src[src.index(',a)
    scope=dict(globals());exec(labels[a:b],scope);p,c=next(it)
    c=scope['c'].replace('install_meter','install_fd').replace('long long start=0','long long a0=0,start=0').replace('start=operand_rd(fd);','a0=operand_rd(fd);start=operand_rd(fd);').replace('operand_rd(fd)-start','operand_rd(fd)-2*start+a0').replace('"F %d','"INSTALL 0 %d')
    yield p,c
driver=driver.replace("{k[2] for k in totals}==set(range(4))","{k[2] for k in totals}=={0}").replace("'install.csv'","'operands.csv'")
exec(compile(driver,'operands','exec'))
