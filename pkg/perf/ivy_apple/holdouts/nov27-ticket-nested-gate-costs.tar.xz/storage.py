"""Prototype coallocated literal arrays for small AND/OR records."""
from pathlib import Path
import json,sys,tarfile

def variants(pkg):
    p=pkg/'smtcore/smt_justification_refs.go'
    s=p.read_text();a=s.index('if n <= 4 {',s.index('func newSMTBoolGate'));b=s.index('\n\treturn &smtBoolGate',a)
    def small(width):
        return f'''if n <= {width} {{
        block:=new(struct {{
            gate smtBoolGate
            children [{width}]ast.ASTHandle
            literals [{width}]SMTLiteral
        }})
        block.gate.args=block.children[:n:n]
        block.gate.literals=block.literals[:0:n]
        return &block.gate
    }}'''
    yield p,s[:a]+small(2)+'\n'+small(4)+s[b:]
    p=pkg/'smtcore/smt_internalizer.go';s=p.read_text()
    a=s.index('arguments, err := s.argumentLiterals(expression)');b=s.index('\n\tadd :=',a)
    s=s[:a]+'''var arguments []SMTLiteral
    var err error
    if gate:=s.boolGate(variable);gate!=nil{
        if cap(gate.literals)>=len(gate.args){arguments=gate.literals[:len(gate.args)]}else{arguments=make([]SMTLiteral,len(gate.args))}
        for i,child:=range gate.args{
            if arguments[i],err=s.Literal(child);err!=nil{return err}
        }
        gate.literals=arguments
    }else if arguments,err=s.argumentLiterals(expression);err!=nil{return err}'''+s[b:]
    yield p,s
    p=pkg/'smtcore/smt_relevancy.go'
    s=p.read_text().replace('if literals != nil {','if len(literals) != 0 {')
    yield p,s
def overlay(pkg,out):
    mp={}
    for p,s in variants(pkg):
        target=out/p.name;target.write_text(s);mp[str(p)]=str(target)
    (out/'overlay.json').write_text(json.dumps({'Replace':mp}))
if __name__=='__main__':
    if len(sys.argv)>1:
        overlay(Path.cwd(),Path(sys.argv[1]));sys.exit()
    with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/panel.py').read().decode()
    a=s.index("    if name=='trial':");b=s.index("    j=d/",a)
    s=s[:a]+"""    if name=='trial':
        for p,source in variants(pkg):
            file=d/p.name;file.write_text(source);mp[str(p)]=str(file)
"""+s[b:]
    exec(compile(s,'panels','exec'))
