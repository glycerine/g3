from pathlib import Path
from collections import defaultdict
from statistics import median
import csv
d=Path(__file__).resolve().parent
cells=defaultdict(list)
for r in csv.DictReader((d/'parts.csv').open()):
    cells[tuple(r[c] for c in ('engine','batch','goal','phase','shape'))].append((int(r['calls']),int(r['instructions'])))
out=defaultdict(lambda:[0]*4)
for (eng,batch,goal,phase,shape),rows in cells.items():
    assert len(rows)==3 and len(set(n for n,v in rows))==1
    n=rows[0][0];v=median(v for n,v in rows)
    shape=int(shape);arity=shape//10000 if phase=='0' else shape
    keys=[(phase,'all'),(phase,'arity '+str(arity))]
    if phase=='0':keys.append((phase,'kind '+str(shape%10000)))
    for k in keys:
        offset=0 if eng=='g3' else 2
        out[k][offset]+=n;out[k][offset+1]+=v
with (d/'summary.csv').open('w') as f:
    w=csv.writer(f);w.writerow('phase group g_calls g_instructions z_calls z_instructions'.split())
    for k,vs in sorted(out.items()):w.writerow([*k,*vs])
