"""Measure the whole chain of fresh negated disjunctions without charging a descendant twice."""
from pathlib import Path
d=Path(__file__).resolve().parent
exec((d/'parts.py').read_text().rsplit("exec(compile(driver,",1)[0])
parts_go,parts_cpp=prepare_go,native_sources
def prepare_go(pkg,put):
    src={};parts_go(pkg,lambda p,s:src.update({p:s}))
    p=pkg/'smtcore/smt_qi_instance.go';put(p,src[p])
    p=pkg/'smtcore/smt_internalizer.go';s=src[p]
    s=edit(s,'if track{measuredGate=ast.ASTHandle{}}','depth:=gateDepth;if track{measuredGate=ast.ASTHandle{};gateDepth++;defer func(){gateDepth--}()}')
    s=edit(s,'a,b=installRead(fd),installRead(fd)}\n        if err = s.Internalize','if tag==1000+int(ast.ASTOpOr){measuredGate=child}else{a,b=installRead(fd),installRead(fd)}}\n        if err = s.Internalize')
    s=edit(s,'if track{installLog(fd,0,int(count)*10000+tag,a,b)}','if track && tag!=1000+int(ast.ASTOpOr){installLog(fd,0,depth*10000+tag,a,b)}')
    s=edit(s,'installLog(fd,1,int(count),a,b)','installLog(fd,1,depth,a,b)')
    for op in (2,3):s=edit(s,f'installLog(fd,{op},len(arguments),a,b)',f'installLog(fd,{op},gateDepth-1,a,b)')
    put(p,s+'\nvar gateDepth int\n')
def native_sources(pkg):
    it=parts_cpp(pkg);yield next(it);p,s=next(it)
    s=edit(s,'expr* measured_gate=nullptr;', 'expr* measured_gate=nullptr; static thread_local int gate_depth=0;')
    s=edit(s,'if(track)measured_gate=nullptr;', 'int depth=gate_depth;if(track){measured_gate=nullptr;++gate_depth;}struct guard{bool track;~guard(){if(track)--gate_depth;}} restore{track};')
    s=edit(s,'else tag+=89;}}\n    begin();internalize(arg, _is_gate);end(0,num*10000+tag);','else tag+=89;}if(tag==1000+OP_OR)measured_gate=child;}\n    if(tag!=1000+OP_OR)begin();internalize(arg, _is_gate);if(tag!=1000+OP_OR)end(0,depth*10000+tag);')
    for op in (1,2,3):s=edit(s,f'end({op},num)',f'end({op},depth)')
    yield p,s
driver=driver.replace("'parts.csv'","'tree.csv'")
exec(compile(driver,'tree','exec'))
