"""Use ordinary clause publication directly for two distinct unassigned gate literals."""
from pathlib import Path
import tarfile
def variants(pkg,mode):
    p=pkg/'smtcore/smt_internalizer.go';s=p.read_text()
    anchor='return s.addWrappedProofClause(literals, false, proof)'
    assert s.count(anchor)==1
    extra='''
    if proof.IsNull() && len(literals)==2 {
        a,b:=literals[0],literals[1]
        if a.Var()!=b.Var() && a.Var()>=SMTFirstBoolVar && b.Var()>=SMTFirstBoolVar && uint(a.Index())<uint(len(s.assignment)) && uint(b.Index())<uint(len(s.assignment)) && s.assignment[a.Index()]==lbool.Undef && s.assignment[b.Index()]==lbool.Undef && s.open()==nil {
            if b<a{a,b=b,a}
            pair:=[2]SMTLiteral{a,b}
            return s.storeSimplifiedClause(pair[:],nil,false,SMTClauseAux,proof,nil,nil)
        }
    }
'''
    yield p,s.replace(anchor,extra+anchor) if mode=='trial' else s
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['base','trial']
    for mode in modes:
        for p,source in variants(pkg,mode):put(p,source)
"""+s[b:]
exec(compile(s.replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("'notification.csv'","'undefined.csv'"),'undefined','exec'))
