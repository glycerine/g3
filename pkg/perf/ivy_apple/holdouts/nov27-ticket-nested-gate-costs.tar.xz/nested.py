"""Follow only fresh negated OR children of the previously measured root ORs."""
from pathlib import Path
d=Path(__file__).resolve().parent
exec((d/'parts.py').read_text().rsplit("exec(compile(driver,",1)[0])
parts_go,parts_cpp=prepare_go,native_sources
def prepare_go(pkg,put):
    sources={};parts_go(pkg,lambda p,s:sources.update({p:s}))
    p=pkg/'smtcore/smt_qi_instance.go';put(p,sources[p])
    p=pkg/'smtcore/smt_internalizer.go';s=sources[p]
    s=edit(s,'track:=measuredGate==expression;if track{measuredGate=ast.ASTHandle{}}','root:=measuredGate==expression;track:=nestedGate==expression;if root{measuredGate=ast.ASTHandle{}};if track{nestedGate=ast.ASTHandle{}}')
    s=edit(s,'tag:=0;if track{','tag:=0;if track || root{')
    s=edit(s,'a,b=installRead(fd),installRead(fd)}\n        if err = s.Internalize','if root && tag==1000+int(ast.ASTOpOr){nestedGate=child};if track{a,b=installRead(fd),installRead(fd)}}\n        if err = s.Internalize')
    put(p,s+'\nvar nestedGate ast.ASTHandle\n')
def native_sources(pkg):
    it=parts_cpp(pkg);yield next(it)
    p,s=next(it)
    s=edit(s,'expr* measured_gate=nullptr;', 'expr* measured_gate=nullptr,*nested_gate=nullptr;')
    s=edit(s,'bool track=n==measured_gate;if(track)measured_gate=nullptr;', 'bool root=n==measured_gate;bool track=n==nested_gate;if(root)measured_gate=nullptr;if(track)nested_gate=nullptr;')
    s=edit(s,'int tag=0;if(track){expr* child','int tag=0;if(track||root){expr* child')
    s=edit(s,'else tag+=89;}}\n    begin();','else tag+=89;}if(root && tag==1000+OP_OR)nested_gate=child;}\n    begin();')
    yield p,s
driver=driver.replace("'parts.csv'","'nested.csv'")
exec(compile(driver,'nested-gates','exec'))
