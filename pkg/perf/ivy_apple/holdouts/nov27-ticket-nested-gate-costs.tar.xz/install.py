"""Collect Ticket installation instructions on complete incremental solver histories."""
from pathlib import Path
import tarfile

def prepare_go(pkg,put):
    p=pkg/'smtcore/smt_qi_instance.go'
    s=edit(p.read_text(),'import (','import (\n"os"')
    call='internalizer.internalizeInstance(result, locals.arguments)'
    s=edit(s,'if err = '+call+'; err != nil {','installFD=-1;if fd,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));e==nil{installFD=fd};err='+call+';installFD=-1;if err!=nil{')
    put(p,s)
    p=pkg/'smtcore/smt_internalizer.go'
    s=edit(p.read_text(),'import (','import (\n"syscall"\n"unsafe"')
    s+='''
var installFD = -1
func installRead(fd int)int64{if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if e!=0||n!=24||c[1]!=c[2]{panic("counter")};return int64(c[0])}
func installLog(fd,phase,shape int,a,b int64){if fd>=0{used:=installRead(fd)-2*b+a;println("INSTALL",phase,shape,used)}}
'''
    a=s.index('func (s *SMTInternalizerState) assertExpression(')
    pre,s=s[:a],s[a:]
    s=edit(s,'literals := make([]SMTLiteral, len(arguments))','''fd:=installFD;shape:=0
if fd>=0{missing:=0;for _,arg:=range arguments{if s.manager.IsFalse(arg){continue};_,child,e:=s.manager.IsNot(arg);if e!=nil{panic(e)};if !child.IsNull(){arg=child};if _,ok:=s.boolVar.lookup(arg);!ok{missing++}};if missing>=100||s.scopeLevel>=10000{panic("shape")};shape=len(arguments)*1000000+missing*10000+int(s.scopeLevel)}
a,b:=installRead(fd),installRead(fd);literals := make([]SMTLiteral, len(arguments))''')
    for i,anchor in enumerate(['if err = s.addRootClause(literals, proof);','if s.relevancy != nil {\n\t\t\t\tgate,','if err := s.relevancy.MarkRelevant(expression);']):
        s=edit(s,anchor,f'installLog(fd,{i},shape,a,b);a,b=installRead(fd),installRead(fd);'+anchor)
    s=edit(s,'return s.relevancy.propagateWithOr(expression, gate)','err=s.relevancy.propagateWithOr(expression,gate);installLog(fd,3,shape,a,b);return err')
    put(p,pre+s)

def native_sources(pkg):
    p=pkg.parent/'src/smt/qi_queue.cpp'
    call='m_context.internalize_instance(lemma, pr1, gen);'
    yield p,'#include <cstdlib>\nthread_local int install_fd=-1;\n'+edit(p.read_text(),call,'auto env=getenv("QI_COUNTER_FD");install_fd=env?atoi(env):-1;'+call+'install_fd=-1;')
    p=pkg.parent/'src/smt/smt_internalizer.cpp'
    s='#include <unistd.h>\nextern thread_local int install_fd;\nstatic long long rd(int fd){if(fd<0)return 0;unsigned long long x[3];if(read(fd,x,24)!=24||x[1]!=x[2])__builtin_trap();return x[0];}\n'+p.read_text()
    s=edit(s,'case OP_OR: {\n                literal_buffer lits;', '''case OP_OR: {
int fd=install_fd,shape=0;if(fd>=0){unsigned missing=0;for(expr*arg:*to_app(n))if(!lit_internalized(arg))++missing;if(missing>=100||get_scope_level()>=10000)__builtin_trap();shape=to_app(n)->get_num_args()*1000000+missing*10000+get_scope_level();}
auto a=rd(fd),b=rd(fd);literal_buffer lits;''')
    def stop(i):return 'if(fd>=0){auto used=rd(fd)-2*b+a;fprintf(stderr,"INSTALL '+str(i)+' %d %lld\\n",shape,used);}'
    seq=['mk_root_clause(lits.size(), lits.c_ptr(), pr);','add_or_rel_watches(to_app(n));','mark_as_relevant(n);']
    s=edit(s,seq[0]+'\n                '+seq[1]+'\n                break;', ''.join(stop(i)+'a=rd(fd);b=rd(fd);'+v for i,v in enumerate(seq))+stop(3)+'return;')
    yield p,s

with tarfile.open('perf/ivy_apple/holdouts/nov27-backjump-relevance-and-reductions.tar.xz') as t:
    driver=t.extractfile('study/phase.py').read().decode()
a=driver.index("            p=pkg/'smtcore");b=driver.index('        else:\n            build=',a)
driver=driver[:a]+'            prepare_go(pkg,put)\n'+driver[b:]
a=driver.index("            p=pkg.parent/'src/smt");b=driver.index("            k=front",a)
driver=driver[:a]+'''            lib=d/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
            for p,s in native_sources(pkg):
                src=d/p.name;src.write_text(s);obj=src.with_suffix('.o')
                sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-o',obj,src],cwd=build,check=True)
                sp.run(['ar','r',lib,obj],check=True)
'''+driver[b:]
driver=driver.replace('POP-PHASE','INSTALL').replace("key+(phase,)","key+(phase,n)").replace('a[1]+=n','a[1]+=1').replace('len(totals)==12','{k[2] for k in totals}==set(range(4))').replace('phase calls entries instructions','phase shape calls entries instructions').replace("'phase.csv'","'install.csv'").replace('range(5)','range(3)')
exec(compile(driver,'phase.py','exec'))
