"""Time direct child internalization, variable setup, gate clauses and watches."""
from pathlib import Path
d=Path(__file__).resolve().parent
exec((d/'operands.py').read_text().rsplit("exec(compile(driver,",1)[0])
oper_go,oper_cpp=prepare_go,native_sources
def prepare_go(pkg,put):
    sources={}
    oper_go(pkg,lambda p,s:sources.update({p:s}))
    p=pkg/'smtcore/smt_qi_instance.go';put(p,sources[p])
    p=pkg/'smtcore/smt_internalizer.go';s=sources[p]
    s=edit(s,'var a,b int64;if code>=0{a,b=installRead(fd),installRead(fd)}','if code==106{_,gate,_:=s.manager.IsNot(argument);measuredGate=gate}')
    s=edit(s,'installLog(fd,0,code,a,b)','measuredGate=ast.ASTHandle{}')
    a=s.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp');b=s.index('func (s *SMTInternalizerState) argumentLiterals',a)
    v=s[a:b]
    v=edit(v,'count := header.NumArgs','''count := header.NumArgs
    track:=measuredGate==expression;if track{measuredGate=ast.ASTHandle{}}
    fd:=installFD;var a,b int64
''')
    v=edit(v,'if err = s.Internalize(argument, isGate);','''tag:=0;if track{
        child:=argument;neg,h,e:=s.manager.IsNot(child);if e!=nil{panic(e)};if neg{tag=1000;child=h}
        if _,ok:=s.boolVar.lookup(child);ok{tag+=100};h2,e:=s.manager.NodeHeader(child);if e!=nil{panic(e)}
        if h2.Kind!=ast.ASTApp{tag+=90}else if h2.Family==s.manager.BasicFamilyID(){tag+=int(h2.DeclKind)}else if h2.Family==ast.NullFamilyID{tag+=80;if h2.NumArgs==0{tag++}}else{tag+=89}
        a,b=installRead(fd),installRead(fd)}
        if err = s.Internalize(argument, isGate);''')
    v=edit(v,'\n\t}\n\tvariable, isNew', '''
        if track{installLog(fd,0,int(count)*10000+tag,a,b)}
    }
    if track{a,b=installRead(fd),installRead(fd)}
    variable, isNew''')
    v=edit(v,'if isNew && basic', 'if track{installLog(fd,1,int(count),a,b);measuredClauses=expression};if isNew && basic')
    s=s[:a]+v+s[b:]
    a=s.index('func (s *SMTInternalizerState) addGateConstraints(');b=s.index('case ast.ASTOpIff:',a)
    v=s[a:b]
    v=edit(v,'variable :=','track:=measuredClauses==expression;fd:=installFD;var a,b int64;if track{measuredClauses=ast.ASTHandle{};a,b=installRead(fd),installRead(fd)};variable :=')
    v=edit(v,'return s.relevancy.AddOrWatches(expression)','if track{installLog(fd,2,len(arguments),a,b);a,b=installRead(fd),installRead(fd)};e:=s.relevancy.AddOrWatches(expression);if track{installLog(fd,3,len(arguments),a,b)};return e')
    put(p,s[:a]+v+s[b:]+'\nvar measuredGate,measuredClauses ast.ASTHandle\n')
def native_sources(pkg):
    it=oper_cpp(pkg);yield next(it)
    p,s=next(it)
    s=edit(s,'int fd=install_meter;', 'int fd=install_meter;') if 'int fd=install_meter;' in s else s
    a=s.index('namespace smt {')
    s=s[:a]+s[a:].replace('namespace smt {','namespace smt {\nstatic thread_local expr* measured_gate=nullptr;',1)
    s=edit(s,'a0=operand_rd(fd);start=operand_rd(fd);','if(code==106)measured_gate=atom;')
    a=s.index('if(code>=0){auto n=operand_rd(fd)');b=s.index(';}',a)+2;s=s[:a]+'measured_gate=nullptr;'+s[b:]
    a=s.index('void context::internalize_formula_core(');b=s.index('case OP_IFF:',a);v=s[a:b]
    v=edit(v,'bool _is_gate', '''bool track=n==measured_gate;if(track)measured_gate=nullptr;
    int fd=install_fd;long long a=0,b=0;auto begin=[&](){if(track){a=operand_rd(fd);b=operand_rd(fd);}};
    auto end=[&](int phase,int shape){if(track){auto used=operand_rd(fd)-2*b+a;fprintf(stderr,"INSTALL %d %d %lld\\n",phase,shape,used);}};
    bool _is_gate''')
    v=edit(v,'internalize(arg, _is_gate);','''int tag=0;if(track){expr* child=arg;if(m_manager.is_not(arg,child))tag+=1000;if(b_internalized(child))tag+=100;
    if(!is_app(child))tag+=90;else{auto* app=to_app(child);if(app->get_family_id()==m_manager.get_basic_family_id())tag+=app->get_decl_kind();else if(app->get_family_id()==null_family_id)tag+=app->get_num_args()?80:81;else tag+=89;}}
    begin();internalize(arg, _is_gate);end(0,num*10000+tag);''')
    v=edit(v,'bool is_new_var','begin();bool is_new_var')
    v=edit(v,'if (is_new_var &&','end(1,num);if (is_new_var &&')
    v=edit(v,'mk_or_cnstr(to_app(n));\n                add_or_rel_watches(to_app(n));','begin();mk_or_cnstr(to_app(n));end(2,num);begin();add_or_rel_watches(to_app(n));end(3,num);')
    yield p,s[:a]+v+s[b:]
driver=driver.replace("=={0}","==set(range(4))").replace("'operands.csv'","'parts.csv'")
exec(compile(driver,'gate-parts','exec'))
