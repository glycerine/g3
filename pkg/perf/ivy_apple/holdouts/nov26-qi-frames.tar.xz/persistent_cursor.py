"""Keep the borrowed arena app record in a live standard theory frame."""
from pathlib import Path
import argparse
import json
import subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--goivy',action='store_true')
a=p.parse_args()
pkg=Path.cwd()
out=Path(__file__).resolve().parent/'persistent'
out.mkdir(exist_ok=True)
mapping={}

def emit(rel,source):
    path=pkg/rel
    dest=out/path.name
    dest.write_bytes(subprocess.check_output(['gofmt'],input=source.encode()))
    mapping[str(path)]=str(dest)
    if a.goivy: mapping[str(Path.home()/'g3/pkg'/rel)]=str(dest)

rel='ast/ast_rewriter_access.go'
emit(rel,(pkg/rel).read_text()+'''
// RewriterFrameCursor borrows an application from its fixed arena page.
// Only use it while retaining the expression through the rewriter's live AST.
type RewriterFrameCursor struct { slot *astNodeSlot }

func (m *ASTManager) RewriterFrameShape(h ASTHandle) (ASTKind, uint32, uint32, RewriterFrameCursor, error) {
    if !m.fastHandle(h) || m.TraceStream != nil || h.origin!=m.origin || h.slot>=m.nextNode {
        kind,rc,n,err:=m.NodeShape(h)
        return kind,rc,n,RewriterFrameCursor{},err
    }
    slot:=m.nodeSlotAt(h.slot)
    if slot.node.kind!=ASTApp { return slot.node.kind,slot.node.rc,0,RewriterFrameCursor{},nil }
    if !slot.node.live || slot.node.generation!=h.generation { return 0,0,0,RewriterFrameCursor{},ErrASTHandle }
    return ASTApp,slot.node.rc,slot.app.count,RewriterFrameCursor{slot},nil
}
func (c RewriterFrameCursor) Valid() bool { return c.slot!=nil }
func (c RewriterFrameCursor) Arg(m *ASTManager,i uint32) (ASTHandle,error) {
    app:=&c.slot.app
    if i>=app.count {return ASTHandle{},ErrASTDomain}
    if i<astInlineArgs && !ASTSourceDebug {return m.external(app.inlineArgs[i]),nil}
    arg,err:=m.appArg(app,i)
    return m.external(arg),err
}
func (c RewriterFrameCursor) DeclAndRefCount(m *ASTManager) (ASTHandle,uint32) {
    return m.external(c.slot.app.decl),c.slot.node.rc
}
func (c RewriterFrameCursor) MayFoldITE(m *ASTManager) bool {
    app:=&c.slot.app
    return !app.declCached || (app.declFamily==m.BasicFamilyID() && app.declKind==ASTOpIte)
}
''')
rel='ast/rewriter/rewriter_core.go'
source=(pkg/rel).read_text()
assert source.count('type rewriterFrame struct {') == 1
emit(rel,source.replace('type rewriterFrame struct {','type rewriterFrame struct {\n    cursor ast.RewriterFrameCursor'))
rel='ast/rewriter/rewriter_engine.go'
source=(pkg/rel).read_text()
start=source.index('func (r *rewriterEngine) visit(t ')
end=source.index('\nfunc (r *rewriterEngine) processVar(', start)
visit=source[start:end]
old='kind, rc, n, e := m.NodeShape(t)'
assert visit.count(old)==1
visit=visit.replace(old,'''var kind ast.ASTKind
    var rc,n uint32
    var cursor ast.RewriterFrameCursor
    if r.skipResumeCacheProbe && !r.modelBooleanShortCircuit {
        kind,rc,n,cursor,e=m.RewriterFrameShape(t)
    } else {kind,rc,n,e=m.NodeShape(t)}''')
old='return false, r.pushFrame(t, cache, depth, kind, n)'
assert visit.count(old)==1
visit=visit.replace(old,'''if e=r.pushFrame(t,cache,depth,kind,n); e!=nil {return false,e}
    c.frames[len(c.frames)-1].cursor=cursor
    return false,nil''')
source=source[:start]+visit+source[end:]
start=source.index('func (r *rewriterEngine) processApp()')
end=source.index('\n// processAppMacroEnd',start)
body=source[start:end]
old='''		for c.frames[fi].index() < n {
			i := c.frames[fi].index()
			if i == 1 || i > 0 && r.modelBooleanShortCircuit {'''
assert body.count(old)==1
body=body.replace(old,'''        depth, cursor := fr.maxDepth(), fr.cursor
        for i := fr.index(); i < n; i++ {
            if i == 1 && (!cursor.Valid() || cursor.MayFoldITE(m)) || i > 0 && r.modelBooleanShortCircuit {''')
body=body.replace('arg, e := m.GetArg(t, i)', '''var arg ast.ASTHandle
            var e error
            if cursor.Valid() {arg,e=cursor.Arg(m,i)} else {arg,e=m.GetArg(t,i)}''')
body=body.replace('done, e := r.visit(arg, fr.maxDepth())', 'done, e := r.visit(arg, depth)')
start_read=body.index('\n\t\td, e := m.GetDecl(t)')
end_read=body.index('\n\t\tassoc := false',start_read)
body=body[:start_read]+'''
        var d ast.ASTHandle
        var rc uint32
        var e error
        if cursor.Valid() {
            d,rc=cursor.DeclAndRefCount(m)
        } else {
            d,e=m.GetDecl(t)
            if e!=nil {return e}
            rc,e=m.GetRefCount(t)
            if e!=nil {return e}
        }'''+body[end_read:]
emit(rel,source[:start]+body+source[end:])
name='goivy_check' if a.goivy else 'g3'
file=out/(name+'.json')
file.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',file,'-o',out/name,
                *(['-tags=xtrace_off','./cmd/goivy_check'] if a.goivy else ['./cmd/g3'])],
               cwd=(Path.home()/'ivy/goivy') if a.goivy else pkg,check=True)
