"""Try transferring a cleared result register's AST ownership onto the stack."""
from pathlib import Path
import argparse
import json
import subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--goivy',action='store_true')
a=p.parse_args()
pkg=Path.cwd()
out=Path(__file__).resolve().parent/'transfer'
out.mkdir(exist_ok=True)
paths={}

def emit(rel,source):
    dst=out/Path(rel).name
    dst.write_bytes(subprocess.check_output(['gofmt'],input=source.encode()))
    paths[str(pkg/rel)]=str(dst)
    if a.goivy: paths[str(Path.home()/'g3/pkg'/rel)]=str(dst)

ref='ast/ast_ref.go'
emit(ref,(pkg/ref).read_text()+'''
// TryStealRefHeld moves an ordinary, live reference out of its register
// without acquiring or dropping an AST reference.
func (m *ASTManager) TryStealRefHeld(ref ASTRef) (ASTHandle,bool) {
    if astValidateHandles || ASTSourceDebug || m.TraceStream!=nil || m.Budget().InjectionArmed() || !m.lockFree() {
        return ASTHandle{},false
    }
    rec:=m.referenceAt(ref.slot)
    if !rec.owned || len(rec.pending)!=0 {return ASTHandle{},false}
    h:=m.external(rec.node)
    rec.node = astNodeRef{}
    rec.owned = false
    return h,true
}
''')
engine='ast/rewriter/rewriter_engine.go'
s=(pkg/engine).read_text().replace('"github.com/glycerine/g3/pkg/ast"','"github.com/glycerine/g3/pkg/ast"\n"github.com/glycerine/g3/pkg/util/diagnostic"')
start=s.index('func (r *rewriterEngine) finish(')
end=s.index('// Called after at least one child',start)
body=s[start:end]
old='''	if e = appendRewriterRoot(m, &c.results, h); e != nil {
		return e
	}'''
assert body.count(old)==2
body=body.replace(old,'''    moved := false
    if clear && !diagnostic.TraceCompiled() && r.skipResumeCacheProbe && !r.substituteVariables {
        if held, ok := m.TryStealRefHeld(r.r); ok {
            c.results=append(c.results,held)
            moved=true
        }
    }
    if !moved {
        if e = appendRewriterRoot(m,&c.results,h); e!=nil {return e}
    }''')
assert body.count('if clear {')==2
body=body.replace('if clear {','if clear && !moved {')
emit(engine,s[:start]+body+s[end:])
name='goivy_check' if a.goivy else 'g3'
file=out/(name+'.json')
file.write_text(json.dumps({'Replace':paths}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',file,'-o',out/name,
                *(['-tags=xtrace_off','./cmd/goivy_check'] if a.goivy else ['./cmd/g3'])],
               cwd=(Path.home()/'ivy/goivy') if a.goivy else pkg,check=True)
