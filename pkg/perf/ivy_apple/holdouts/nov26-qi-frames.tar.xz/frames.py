"""Build proofless application child-loop trials without modifying source."""
from pathlib import Path
import argparse
import json
import subprocess

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('variants', nargs='+', choices=('local', 'borrow', 'fold'))
p.add_argument('--goivy', action='store_true')
a = p.parse_args()
pkg = Path.cwd()
base = Path(__file__).resolve().parent
engine = pkg / 'ast/rewriter/rewriter_engine.go'
ast = pkg / 'ast/ast_rewriter_access.go'

for name in a.variants:
    src = engine.read_text()
    start = src.index('func (r *rewriterEngine) processApp()')
    stop = src.index('\n// processAppMacroEnd', start)
    body = src[start:stop]
    old = '''		for c.frames[fi].index() < n {
			i := c.frames[fi].index()'''
    assert body.count(old) == 1
    body = body.replace(old, '\t\tfor i := fr.index(); i < n; i++ {')
    assert body.count('done, e := r.visit(arg, fr.maxDepth())') == 1
    body = body.replace('case 0:\n\t\tfor', 'case 0:\n\t\tdepth := fr.maxDepth()\n\t\tfor')
    body = body.replace('done, e := r.visit(arg, fr.maxDepth())', 'done, e := r.visit(arg, depth)')
    replacements = {}
    if name in ('borrow','fold'):
        method = '''
// RewriterChildCursor is a call-local view of the arguments of a held application.
// The application must stay live for every use of the cursor.
type RewriterChildCursor struct {
    manager *ASTManager
    app *astAppRecord
}

func (m *ASTManager) RewriterChildren(h ASTHandle) (RewriterChildCursor, error) {
    ref, err := m.readKind(h, ASTApp)
    if err != nil { return RewriterChildCursor{}, err }
    return RewriterChildCursor{m, m.appAt(ref.slot)}, nil
}

func (c RewriterChildCursor) IsNull() bool { return c.app == nil }

func (c RewriterChildCursor) Arg(i uint32) (ASTHandle, error) {
    if i >= c.app.count {return ASTHandle{}, ErrASTDomain}
    if i < astInlineArgs && !ASTSourceDebug {return c.manager.external(c.app.inlineArgs[i]),nil}
    arg, err := c.manager.appArg(c.app, i)
    return c.manager.external(arg), err
}

func (c RewriterChildCursor) MayFoldITE() bool {
    return !c.app.declCached || (c.app.declFamily == c.manager.BasicFamilyID() && c.app.declKind == ASTOpIte)
}
'''
        replacements[ast] = ast.read_text()+method
        body = body.replace('''		depth := fr.maxDepth()
		for''', '''		depth := fr.maxDepth()
        var cursor ast.RewriterChildCursor
        if r.skipResumeCacheProbe && !r.substituteVariables && !r.modelBooleanShortCircuit && n-fr.index() >= 2 {
            var err error
            cursor, err = m.RewriterChildren(t)
            if err != nil { return err }
        }
		for''')
        body = body.replace('''			arg, e := m.GetArg(t, i)''','''			var arg ast.ASTHandle
            var e error
            if cursor.IsNull() {arg,e = m.GetArg(t,i)} else {arg,e = cursor.Arg(i)}''')
        if name == 'fold':
            body = body.replace('if i == 1 || i > 0 && r.modelBooleanShortCircuit {','''if i == 1 && (cursor.IsNull() || cursor.MayFoldITE()) || i > 0 && r.modelBooleanShortCircuit {''')
    replacements[engine] = src[:start]+body+src[stop:]
    out = base / name
    out.mkdir(exist_ok=True)
    mapping = {}
    for path, changed in replacements.items():
        dest = out / path.name
        dest.write_bytes(subprocess.check_output(['gofmt'], input=changed.encode()))
        mapping[str(path)] = str(dest)
        if a.goivy:
            mapping[str(Path.home()/'g3/pkg'/path.relative_to(pkg))] = str(dest)
    label = 'goivy_check' if a.goivy else 'g3'
    target = ('-tags=xtrace_off', './cmd/goivy_check') if a.goivy else ('./cmd/g3',)
    cwd = Path.home()/'ivy/goivy' if a.goivy else pkg
    overlay = out/(label+'.json')
    overlay.write_text(json.dumps({'Replace':mapping}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/label,*target],cwd=cwd,check=True)
