"""Build a Go observer covering the same queue interval as native.py."""
from pathlib import Path
import json
import subprocess

pkg = Path.cwd()
out = Path(__file__).resolve().parent / 'go-observer'
out.mkdir(exist_ok=True)
fields = ('calls', 'visits', 'substitution_hits', 'visit_probes', 'visit_hits', 'resume_probes', 'resume_hits',
          'steps', 'app_steps', 'reductions', 'reduction_misses', 'constants', 'result_releases')
paths = {}

def replace(name, old, new, expected=1):
    path = pkg / name
    source = paths.get(path, path).read_text()
    if source.count(old) != expected:
        raise ValueError((name, old, source.count(old)))
    emit(name, source.replace(old, new, 1))

def emit(name, source):
    path = pkg/name
    dst = out / path.name
    dst.write_bytes(subprocess.check_output(['gofmt'], input=source.encode()))
    paths[path] = dst

emit('ast/rewriter/qi_frame_observation.go', '''package rewriter
import (
    "fmt"
    "os"
    "github.com/glycerine/g3/pkg/ast"
)
var qiFrameObserver struct {
    active bool
    results *[]ast.ASTHandle
''' + ''.join(f'    {name} uint64\n' for name in fields) + '''}
func (r *TheoryRewriter) ObserveQuantifierFrameRewrite(term ast.ASTHandle, out ast.ASTRef) error {
    obs := &qiFrameObserver
    prior, results := obs.active, obs.results
    obs.active = true
    obs.results = &r.traversal.engine.core.results
    obs.calls++
    defer func() { obs.active, obs.results = prior, results }()
    return r.Rewrite(term, out)
}
func PrintQuantifierFrameObservation() {
    fmt.Fprint(os.Stderr, "QI-FRAMES")
''' + ''.join(f'    fmt.Fprintf(os.Stderr, " {field}=%d", qiFrameObserver.{field})\n' for field in fields) + '''
    fmt.Fprintln(os.Stderr)
}
''')
engine = 'ast/rewriter/rewriter_engine.go'
replace(engine, 'func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32) (bool, error) {',
                'func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32) (bool, error) {\n if qiFrameObserver.active {qiFrameObserver.visits++}')
replace(engine, 'if found {\n\t\tif e = r.sameSort(t, sub);',
                'if found {\nif qiFrameObserver.active {qiFrameObserver.substitution_hits++}\n if e = r.sameSort(t, sub);')
replace(engine, '''if cache {
		h, e := c.getCached(t)
		if e != nil {
			return false, e
		}
		if !h.IsNull() {''', '''if cache {
    if qiFrameObserver.active {qiFrameObserver.visit_probes++}
    h, e := c.getCached(t)
    if e != nil {return false,e}
    if !h.IsNull() {
        if qiFrameObserver.active {qiFrameObserver.visit_hits++}''')
replace(engine, 'if !r.skipResumeCacheProbe && fr.state() == 0 && fr.index() == 0 && fr.cacheResult() {',
                'if !r.skipResumeCacheProbe && fr.state() == 0 && fr.index() == 0 && fr.cacheResult() {\n if qiFrameObserver.active {qiFrameObserver.resume_probes++}')
replace(engine, 'if !h.IsNull() {\n\t\t\t\tif e = appendRewriterRoot(m, &c.results, h);',
                'if !h.IsNull() {\n if qiFrameObserver.active {qiFrameObserver.resume_hits++}\n if e = appendRewriterRoot(m, &c.results, h);')
replace(engine, 'r.numSteps++', 'r.numSteps++\n if qiFrameObserver.active {qiFrameObserver.steps++}')
replace(engine, 'func (r *rewriterEngine) processConst(t ast.ASTHandle) error {',
                'func (r *rewriterEngine) processConst(t ast.ASTHandle) error {\n if qiFrameObserver.active {qiFrameObserver.constants++}')
replace(engine, 'func (r *rewriterEngine) processApp() (err error) {',
                'func (r *rewriterEngine) processApp() (err error) {\n if qiFrameObserver.active {qiFrameObserver.app_steps++}')
replace(engine, 'st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)',
                'st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)\nif qiFrameObserver.active {qiFrameObserver.reductions++; if st==brFailed {qiFrameObserver.reduction_misses++}}')
replace('ast/rewriter/rewriter_roots.go', 'func shrinkRewriterRoots(m *ast.ASTManager, roots *[]ast.ASTHandle, n uint32) error {',
        'func shrinkRewriterRoots(m *ast.ASTManager, roots *[]ast.ASTHandle, n uint32) error {\n if qiFrameObserver.active && roots == qiFrameObserver.results {qiFrameObserver.result_releases+=uint64(len(*roots))-uint64(n)}')
replace('smtcore/smt_qi_instance.go', 'if err = rw.Rewrite(instance, simplified); err != nil {',
                                   'if err = rw.ObserveQuantifierFrameRewrite(instance, simplified); err != nil {')
replace('cmd/g3/main.go', 'package main', 'package main\nimport "github.com/glycerine/g3/pkg/ast/rewriter"')
replace('cmd/g3/main.go', 'func main() {', 'func main() {\n defer rewriter.PrintQuantifierFrameObservation()')
overlay = out/'overlay.json'
overlay.write_text(json.dumps({'Replace': {str(path):str(dst) for path,dst in paths.items()}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'], cwd=pkg, check=True)
