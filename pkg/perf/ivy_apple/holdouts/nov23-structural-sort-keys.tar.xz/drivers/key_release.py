from study import *
from panel import CASES,measure,EVENTS
from types import SimpleNamespace
import ground_release_controls as gc
from verification_frontier import reference
d=w/'key-release';d.mkdir(exist_ok=True)
def one(arg,bins):
 cpu,name,en,n,sp,iso,ref,rc=arg;rd=d/(name+'-'+en);rd.mkdir();cfg=SimpleNamespace(cpu=cpu,perf=perf,spec=examples/sp,isolate=iso)
 bs={'previous':w/('guarded-release/checker/goivy_check'if en=='g3'else'frontend-controls/paired-build/native/goivy_check'),'current':bins[en]}
 with(rd/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('case round engine variant exit match wall user sys rss'.split()+list(EVENTS))
  for i in range(n):
   for mode in list(bs)[::1 if i%2==0 else -1]:
    sd=rd/f'{i+1}-{mode}';code,tm,cs=measure(bs[mode],cfg,sd,rc,100);ok=code==rc and all((sd/k).read_bytes()==(ref/k).read_bytes()for k in ('stdout','stderr'));assert ok,(sd,code);wr.writerow([name,i+1,en,mode,code,1,*tm,*cs]);f.flush();print(name,en,i+1,mode,round(cs[0]/1e9,3),flush=True)
def bench():
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['round','mode','bench','ns','bytes','allocs'])
  for i in range(7):
   for v in(['previous','current']if i%2==0 else['current','previous']):
    b=d/v/'frontend.test';cmd=['taskset','-c','5',b,'-test.cpu','1','-test.run','^$','-test.bench','^BenchmarkConstantStructuralKey$','-test.benchtime','100000x','-test.benchmem']
    p=run(cmd,cwd=ivy,capture_output=True,text=True);ls=[x.split()for x in p.stdout.splitlines()if x.startswith('Benchmark')];assert len(ls)>=3
    for a in ls:z.writerow([i+1,v,a[0],a[2],a[4],a[6]])
    f.flush()
def main():
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(['g3','native'],ex.map(lambda en:build(d/en,en),['g3','native'])))
 for v in ['current','previous']:
  od=d/v;od.mkdir();args=[]
  if v=='previous':
   paths=['logic_term.go','logic_sexp.go'];ed={ivy.resolve()/n:run(['git','show','95a9ad062:goivy/'+n],cwd=ivy,capture_output=True,text=True).stdout for n in paths}
   args=['-overlay='+str(overlay(od/'overlay',ed))]
  run(['go','test','-p','4','-tags=xtrace_off',*args,'-c','-o',od/'frontend.test','.'],cwd=ivy,stdout=subprocess.DEVNULL)
 gc.d=d
 js=[]
 for name,sp,ref,cp,n in [('testing','jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native',[1,7],3),('apple','doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native',[9,17],3),('ordinary','jea/hermes_rmw_o3.ivy',reference('jea/hermes_rmw_o3.ivy'),[4,11],5)]:
  for c,en in zip(cp,['g3','native']):js.append((c,name,en,n,sp,'',ref,0))
 for c,name in [(2,'tlb'),(6,'rfn2'),(12,'dramc_nb2'),(14,'cf_live'),(3,'flash2')]:
  sp,iso,_,f,u=CASES[name];ref=next((prior/'end-panel-final').glob('*/'+name+'/1/g3'));js.append((c,name,'g3',4,sp,iso,ref,int(bool(f or u))))
 with ThreadPoolExecutor(len(js)+2)as ex:
  fs=[ex.submit(bench),ex.submit(gc.corpus,bs['g3'])]+[ex.submit(one,j,bs)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
