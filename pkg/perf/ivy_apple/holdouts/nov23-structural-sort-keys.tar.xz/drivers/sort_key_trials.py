from study import *
from panel import CASES,measure,EVENTS
from types import SimpleNamespace
d=w/'sort-key-trials';d.mkdir(exist_ok=True)
root=ivy.resolve();q=root/'logic_sexp.go';c=root/'logic_term.go'
def edits(mode):
 if mode=='current':return {}
 s=q.read_text();t=c.read_text()
 x='return NodeKey("(Variable name:" + v.Name + " sort:" + string(v.VSort.Sexp()) + ")")';s=once(s,x,'return symbolSortKey("(Variable name:",v.Name,v.VSort)')
 a=t.index('var sortSexp NodeKey',t.index('func NewConst('));b=t.index('\n\treturn c',a)
 t=t[:a]+'''if sort==nil{c.sexp=NodeKey("(Symbol name:"+name+" sort:nil)")}else{c.sexp=symbolSortKey("(Symbol name:",name,sort)}'''+t[b:]
 simpler='''
switch k:=v.(type){
case *UninterpretedSort:return NodeKey(prefix+name+" sort:(UninterpretedSort name:"+k.Name+"))")
case *BooleanSort:return NodeKey(prefix+name+" sort:(BooleanSort))")
case *TopSort:return NodeKey(prefix+name+" sort:(TopSort name:"+k.Name+"))")
}
'''if 'simple'in mode else ''
 if mode=='simple':s+='\nfunc symbolSortKey(prefix,name string,v Sort)NodeKey{'+simpler+'return NodeKey(prefix+name+" sort:"+string(v.Sexp())+")")}\n';return{q:s,c:t}
 a=s.index('parts := make([]string, len(s.Sorts))');b=s.index('\n}',a)
 s=s[:a]+'''var space [24]string;ps:=appendSortParts(space[:0],s);return NodeKey(strings.Join(ps,""))'''+s[b:]
 s+='\nfunc symbolSortKey(prefix,name string,v Sort)NodeKey{'+simpler+'''
 var space [24]string
 ps:=append(space[:0],prefix,name," sort:")
 ps=appendSortParts(ps,v)
 ps=append(ps,")")
 return NodeKey(strings.Join(ps,""))
}
func appendSortParts(ps []string,v Sort)[]string{
 switch k:=v.(type){
 case *BooleanSort:return append(ps,"(BooleanSort)")
 case *UninterpretedSort:return append(ps,"(UninterpretedSort name:",k.Name,")")
 case *TopSort:return append(ps,"(TopSort name:",k.Name,")")
 case *LogicFunctionSort:
  ps=append(ps,"(FunctionSort sorts:[");for i,sub:=range k.Sorts{if i>0{ps=append(ps," ")};ps=appendSortParts(ps,sub)};return append(ps,"])")
 default:return append(ps,string(v.Sexp()))
 }
}
'''
 return{q:s,c:t}
def make(mode):
 sd=d/mode;o=overlay(sd/'overlay',edits(mode));res={}
 for n in ('g3','native'):res[n]=build(sd/n,n,o)
 with(sd/'tests').open('w')as f:run(['go','test','-p','3','-overlay='+str(o),'-tags=xtrace_off','-count=2','-run','Test(LogicSexp|.*NewConst|.*ConstStructural|RenameDistinct|RenameAST)','-bench','Benchmark(NewConst|RenameQuantifiedPredicate|RenameDistinctClauses)','-benchtime=2000x','-benchmem','-cpu=1','.'],cwd=ivy,stdout=f,stderr=f)
 return res
def lane(params):
 name,cpu,en,sp,iso,ref,rc=params
 cfg=SimpleNamespace(cpu=cpu,perf=perf,spec=examples/sp,isolate=iso)
 rd=d/(name+'-'+en);rd.mkdir()
 with(rd/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('round engine variant cpu case status wall user sys rss'.split()+list(EVENTS))
  for rnd in range(3):
   ms=['current','simple','parts','simple-parts'];ms=ms[rnd:]+ms[:rnd];ms=ms if rnd%2==0 else list(reversed(ms))
   for mode in ms:
    sub=rd/f'{rnd+1}-{mode}';code,tm,cs=measure(bs[mode][en],cfg,sub,0,100);assert code==rc and all((sub/k).read_bytes()==(ref/k).read_bytes()for k in ['stdout','stderr']),(name,en,mode);wr.writerow([rnd+1,en,mode,cpu,name,code,*tm,*cs]);f.flush();print(name,en,rnd+1,mode,round(cs[0]/1e9,2),flush=True)
if __name__=='__main__':
 ms=['current','simple','parts','simple-parts']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(ms,ex.map(make,ms)))
 js=[]
 for name,sp,iso,ref,cs in [('hermes','jea/hermes_rmw_o3_testing.ivy','',w/'extended-phases/long/1/1/native',[1,7]),('apple','doc/examples/apple/ord_live.ivy','',w/'apple-original-pairs/14-native',[9,17])]:
  js.extend((name,c,e,sp,iso,ref,0)for c,e in zip(cs,('g3','native')))
 for n,cpu in [('tlb',3),('dramc_nb2',11),('rfn2',12)]:
  sp,iso,_,a,b=CASES[n];ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'));js.append((n,cpu,'g3',sp,iso,ref,int(bool(a or b))))
 with ThreadPoolExecutor(7)as ex:list(ex.map(lane,js))
