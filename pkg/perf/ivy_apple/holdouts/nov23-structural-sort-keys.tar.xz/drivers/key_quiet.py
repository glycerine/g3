from study import *
from verification_frontier import reference
d=w/'key-quiet';d.mkdir(exist_ok=True);src=w/'key-release'
def one(j):
 n,c,sp,rf,r=j;out=d/(n+'-'+str(c));run([sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',src/'g3/goivy_check','--previous',w/'guarded-release/checker/goivy_check','--native',src/'native/goivy_check','--rounds',str(r),'--max-attempts','24','--wait-seconds','5000','--min-idle','.95','--cpu',str(c),'--spec',examples/sp,'--reference',rf,'--perf',perf,'--output',out],stdout=subprocess.DEVNULL);print(n,c,'done',flush=True)
js=[('ordinary',15,'jea/hermes_rmw_o3.ivy',reference('jea/hermes_rmw_o3.ivy'),5),('testing',19,'jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native',3),('apple',23,'doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native',3)]
with ThreadPoolExecutor(len(js))as e:list(e.map(one,js))
