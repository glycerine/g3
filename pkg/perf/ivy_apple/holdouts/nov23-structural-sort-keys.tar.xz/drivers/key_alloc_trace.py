from study import *
import current_verifier_heap as heap
import binder_exits as binder
d=w/'key-alloc-trace';d.mkdir(exist_ok=True);root=ivy.resolve()
def make(v):
 n,en,how=v.split('-');out=d/v;ed={}
 if n=='before':
  for q in ['logic_sexp.go','logic_term.go']:
   ed[root/q]=run(['git','show','95a9ad062:goivy/'+q],cwd=ivy,capture_output=True,text=True).stdout
 if how=='alloc':
  ed[root/'cmd/goivy_check/main.go']=(w/'current-verifier-heap/overlay/main.go').read_text()
  return build(out,en,overlay(out/'overlay',ed))
 o=overlay(out/'overlay',ed)
 with(w/'build.lock').open('a')as lk,(out/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-mod=readonly','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',out/'goivy_check','./cmd/goivy_check'],cwd=ivy,stdout=log,stderr=log)
 if not(out/'abc').exists():(out/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
 return out/'goivy_check'
if __name__=='__main__':
 vs=[n+'-'+en+'-alloc'for n in ('before','after')for en in ('g3','native')]+[n+'-g3-trace'for n in ('before','after')]
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(make,vs)))
 heap.d=d;binder.root=d
 jobs=[(n,v,c,bs[v])for n,cs in [('hermes',[25,26,27,28]),('apple',[29,30,31,32])]for v,c in zip(vs[:4],cs)]
 with ThreadPoolExecutor(9)as e:
  fs=[e.submit(heap.runone,j)for j in jobs]+[e.submit(binder.trace,{n+'-trace':bs[n+'-g3-trace']for n in ('before','after')})]
  for f in fs:f.result()
