from study import *
from collections import Counter
from panel import CASES
d=w/'current-verifier-heap';d.mkdir(exist_ok=True)
def instrument():
 q=ivy.resolve()/'cmd/goivy_check/main.go';s=once(q.read_text(),'import (','import ("runtime";"runtime/pprof"; "runtime/metrics";"encoding/json"')
 s=once(s,'os.Exit(goivy.MainWithConfig(args, cfg))','''runtime.MemProfileRate=2<<20
 code:=goivy.MainWithConfig(args,cfg)
 var mem runtime.MemStats;runtime.ReadMemStats(&mem);samples:=[]metrics.Sample{{Name:"/gc/scan/heap:bytes"},{Name:"/gc/scan/total:bytes"},{Name:"/gc/heap/live:bytes"}};metrics.Read(samples)
 f,err:=os.Create("gc.json");if err!=nil{panic(err)};json.NewEncoder(f).Encode([]uint64{uint64(mem.NumGC),mem.TotalAlloc,mem.Mallocs,mem.HeapAlloc,mem.HeapSys,samples[0].Value.Uint64(),samples[1].Value.Uint64(),samples[2].Value.Uint64()});f.Close()
 runtime.GC();runtime.GC();f,err=os.Create("alloc.pprof");if err!=nil{panic(err)};if err=pprof.WriteHeapProfile(f);err!=nil{panic(err)};f.Close();os.Exit(code)''')
 o=overlay(d/'overlay',{q:s})
 with ThreadPoolExecutor(2)as e:return dict(zip(['g3','native'],e.map(lambda k:build(d/k,k,o),['g3','native'])))
def runone(j):
 n,e,c,b=j
 if n=='hermes':sp,iso,ref,rc='jea/hermes_rmw_o3_testing.ivy','',w/'extended-phases/long/1/1/native',0
 elif n=='apple':sp,iso,ref,rc='doc/examples/apple/ord_live.ivy','',w/'apple-original-pairs/14-native',0
 else:sp,iso,_,fl,un=CASES[n];rc=int(bool(fl or un));ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))
 rd=d/(n+'-'+e);rd.mkdir()
 with(rd/'stdout').open('wb')as so,(rd/'stderr').open('wb')as se:
  res=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=rd,env=dict(env,GOGC='100',GOMAXPROCS='1'),stdout=so,stderr=se,timeout=2400)
 assert res.returncode==rc and all((rd/k).read_bytes()==(ref/k).read_bytes()for k in ['stdout','stderr']),rd
 for m in ['alloc_space','alloc_objects']:
  for scope in ['','g3/pkg','goivy.ComposeUpdates']:
   for cum in ('flat','cum'):
    res=run(['go','tool','pprof','-top',*(['-cum']if cum=='cum'else[]),'-sample_index='+m,'-nodecount=120','-nodefraction=0.0005',*(['-focus',scope]if scope else[]),b,rd/'alloc.pprof'],capture_output=True)
    (rd/(m+'-'+cum+'-'+scope.replace('/','-')+'.txt')).write_bytes(res.stdout)
 print(n,e,(rd/'gc.json').read_text().strip(),flush=True)
if __name__=='__main__':
 bs=instrument();js=[(n,k,c,bs[k])for n,cs in [('tlb',[1,8]),('hermes',[10,22]),('apple',[3,17]),('flash2',[6,9])]for k,c in zip(bs,cs)]
 with ThreadPoolExecutor(8)as e:list(e.map(runone,js))
