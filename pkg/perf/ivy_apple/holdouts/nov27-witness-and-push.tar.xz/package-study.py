from pathlib import Path
import csv,tarfile
root=Path(__file__).resolve().parent
dest=Path.cwd()/'perf/ivy_apple/holdouts/nov27-witness-and-push.tar.xz'
for stem in ('boundary','detail','quant','passes'):
    rows=list(csv.DictReader((root/(stem+'.csv')).open()))
    expected={3,6,12,10} if stem=='passes' else {3,6,2,12,10}
    assert {(int(r['case']),int(r['round'])) for r in rows}=={(n,i) for n in expected for i in range(3)}
    for case in expected:
        groups=[{(r['batch'],r['goal']) for r in rows if int(r['case'])==case and int(r['round'])==i} for i in range(3)]
        assert groups[0]==groups[1]==groups[2]
files=sorted({f for pattern in ('*.py','*.csv','*.go','*.go.txt','*.json','README.md','compat.txt','inputs/*.smt2') for f in root.glob(pattern)})
with tarfile.open(dest,'w:xz') as arch:
    for f in files: arch.add(f,arcname=str(f.relative_to(root)))
with tarfile.open(dest) as arch:
    for f in files: assert arch.extractfile(str(f.relative_to(root))).read()==f.read_bytes()
print(len(files),'verified files,',dest.stat().st_size,'bytes')
