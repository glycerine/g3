from pathlib import Path
import os,json,subprocess as sp,csv
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-arith-next/final/arith-stage.json').read_text())
def patch(path,s):
 to=w/(path.name+'.txt');to.write_text(s);ov['Replace'][str(path)]=str(to)
path=p/'api/api_order_abstraction.go';patch(path,path.read_text().replace('import (','import ("github.com/glycerine/g3/pkg/ast/rewriter";',1)+(w/'live-hints.go.txt').read_text())
path=front/'smt/g3_solver.go';patch(path,path.read_text()+'\nfunc(s *Z3Solver) TrialHints(mode string)int{n:=0;s.ctx.do(func(){n=s.c.TrialHints(mode)});return n}\n')
path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text();k='stopCheck:=startStage(batch,index+1);';s=s.replace(k,k+'if batch==7 && index==0 && hintMode!=""{n:=z3solver.TrialHints(hintMode);println("HINTS",n)};');patch(path,s+'\nvar hintMode=os.Getenv("HINT_MODE")\n')
j=w/'live.json';j.write_text(json.dumps(ov));sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'live','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');case=(rank/'compat.txt').read_text().splitlines()[2];ref=rank/'compat/3/1/native'
with (w/'live.csv').open('w') as f:
 o=csv.writer(f);o.writerow('round mode hints check_instructions process_instructions'.split())
 modes=['','both','negative','positive','fresh']
 for i in range(5):
  for mode in modes[i:]+modes[:i]:
   stat=w/'live.stat';r=sp.run(['taskset','-c','31','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/'live',ex/case],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),HINT_MODE=mode),capture_output=True,timeout=40);n=0;ins=None;rest=bytearray()
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'HINTS '):n=int(line.split()[1])
    elif line.startswith(b'STAGE-COUNT '):
     a=line.split()
     if a[1:4]==[b'7',b'1',b'check']:ins=int(a[4]);assert a[6]==a[7]
    else:rest.extend(line)
   assert (r.returncode,r.stdout,rest)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(r.returncode,rest[-2000:])
   instr,=[int(v[0]) for v in csv.reader(stat.open()) if len(v)>4 and v[2]=='instructions:u' and float(v[4])==100];assert ins;o.writerow([i,mode,n,ins,instr]);f.flush()
