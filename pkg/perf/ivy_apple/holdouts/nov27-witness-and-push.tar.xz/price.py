from pathlib import Path
import csv,subprocess as sp,os,re
w=Path(__file__).resolve().parent;p=Path.cwd()
with (w/'prices.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','scope','mode','engine','round','instructions','quant_instantiations','decisions','conflicts','rlimit'])
 for scope in ('flat','push'):
  for i in range(5):
   modes=['base','exists','fresh'];modes=modes[i%3:]+modes[:i%3]
   for mode in modes:
    text=(w/'inputs'/(mode+'.smt2')).read_text()
    if scope=='push':text=text.replace('(assert (and (not false)))','(push)\n(assert (and (not false)))')
    for e,exe in [('g3',Path(os.getenv('G3_CLI',w/'g3'))),('z3',p.parent/'build/z3')][::1 if i%2==0 else -1]:
     stat=w/'counter';r=sp.run(['taskset','-c',os.getenv('PERF_CPU','31'),os.getenv('PERF','/usr/lib/linux-tools/6.17.0-35-generic/perf'),'stat','-x,','-o',stat,'-e','instructions:u','--',exe,'smt.macro_finder=true','-in'],input=text+'(get-info :all-statistics)\n',text=True,capture_output=True,timeout=30,check=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
     assert r.stdout.startswith('unsat\n') and not r.stderr,r.stderr
     n,=[int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100];d=dict(re.findall(r':([\w-]+)\s+(\d+)',r.stdout))
     out.writerow(['7/1',scope,mode,e,i,n,*[d.get(k,'') for k in ('quant-instantiations','decisions','conflicts','rlimit-count')]]);f.flush()
