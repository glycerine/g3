package smtcore

// Source: src/smt/smt_kernel.h and src/smt/smt_kernel.cpp retained assertion,
// scope, setup, check, and context-access facade.

import ("github.com/glycerine/g3/pkg/util/control";
	"errors"
	"fmt"
	"io"
	"runtime"
	"strings"

	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/ast/macros"
	"github.com/glycerine/g3/pkg/ast/normal_forms"
	"github.com/glycerine/g3/pkg/ast/pattern"
	"github.com/glycerine/g3/pkg/ast/rewriter"
	"github.com/glycerine/g3/pkg/ast/rewriter/bit_blaster"
	"github.com/glycerine/g3/pkg/model"
	protomodel "github.com/glycerine/g3/pkg/smtcore/proto_model"
	"github.com/glycerine/g3/pkg/solver"
	"github.com/glycerine/g3/pkg/util/cooperate"
	"github.com/glycerine/g3/pkg/util/diagnostic"
	"github.com/glycerine/g3/pkg/util/lbool"
	uparams "github.com/glycerine/g3/pkg/util/params"
	usymbol "github.com/glycerine/g3/pkg/util/symbol"
	utext "github.com/glycerine/g3/pkg/util/text"
)

type SMTKernelAssertion struct {
	Formula ast.ASTHandle
	Proof   ast.ASTHandle
}

type SMTKernel struct {
	// activeSearch is the running search session (m_searching).
	activeSearch         *smtSearchSession
	trueProofInitialized bool                       // context::init's proof branch has run
	queueWarnings        *diagnostic.WarningService // Borrowed factory diagnostics; nil uses process warnings.
	caseSplitQueue       *SMTActivityCaseSplitQueue
	booleanSetupSeeded   bool
	smtParamsBorrowed    bool

	manager   *ast.ASTManager
	checker   *SMTCheckerContext
	relevancy *SMTRelevancyPropagator
	// contextRelevancyLvl is context::m_relevancy_lvl (fork backport of
	// upstream z3 5dfe4a4b4): first setup takes the parameter's level, and
	// later setups (check, push) may only lower it. relevancyConfigured marks
	// that the first setup_context has run.
	contextRelevancyLvl uint32
	relevancyConfigured bool
	internalizer        *SMTInternalizerState
	assertions          []SMTKernelAssertion
	assertedHead        int
	scopes              []int
	pendingPop          *smtKernelPendingPop
	unsatCore           []ast.ASTHandle
	unsatProof          ast.ASTRef
	// conflictResolver is m_conflict_resolution: one per context, so its
	// m_lemma_proof outlives each search until the next conflict.
	conflictResolver *SMTConflictResolver
	assumptions      map[SMTLiteral]ast.ASTHandle
	lastFailure      SMTFailure
	// lastSearch is the session of the latest search (its search level,
	// conflict base and restart state), which get_consequences resumes.
	lastSearch *smtSearchSession
	// consequenceVar2Val is context::m_var2val (get_consequences).
	consequenceVar2Val *seqObjHashtable
	unknown            string
	labels             []usymbol.Symbol
	assignments        []ast.ASTHandle
	relevantLiterals   []ast.ASTHandle
	relevantLabeled    []ast.ASTHandle
	guessed            []ast.ASTHandle
	// pendingResults records the literals of the latest satisfiable check;
	// the result expressions are built on the first query, as the source
	// getters build them, not when the check ends.
	pendingResults *smtPendingLiteralResults
	// spareResults is the last released capture, kept only to reuse its
	// slice storage for the next capture.
	spareResults *smtPendingLiteralResults
	callback     solver.ProgressCallback
	modelConfig  model.ModelEvaluatorConfig
	generated    *model.Model
	// staleModel is context::m_proto_model/m_model after a new check began:
	// no longer the result, but held until the next mk_proto_model replaces
	// it (or the context is destroyed).
	staleModel *model.Model
	// updateProto is the m_proto_model an update_model call left alive; it
	// goes when the next mk_proto_model replaces it, when a search's
	// scoped_mk_model clears it, or with the context.
	updateProto *protomodel.ProtoModel
	// generatorPins is model_generator::m_asts: the values a model
	// generation pinned stay alive until the next mk_proto_model resets the
	// generator (or the context is destroyed), and are released forward.
	generatorPins []ast.ASTRef
	// rootValueOrder is the m_root2value table of the context's one
	// model_generator, kept across models so its capacity carries over.
	rootValueOrder *ast.ObjMap
	// protoTrail is the value-factory trail of m_proto_model; it dies when
	// scoped_mk_model drops the proto model, or at the context's teardown.
	protoTrail       []ast.ASTRef
	preprocessor     *rewriter.TheoryRewriter
	patternInference *pattern.InferenceRewriter
	bvSharing        *rewriter.MaximizeBVSharing
	// asserted_formulas::m_apply_bit2int owns its bit2int, whose constructor
	// builds m_bit0; it lives as long as the asserted formulas.
	assertedBit2Int *rewriter.Bit2Int
	// The lift_ite, ng_lift_ite, cheap_quant_fourier_motzkin and
	// pull_nested_quantifiers members of asserted_formulas own their
	// rewriters, whose caches persist for the asserted formulas' lifetime.
	// They are built on first use; the lift-ite conservative flag is read
	// then, as the source reads it in the asserted_formulas constructor.
	assertedLiftITE           *rewriter.PushAppITE
	assertedNGLiftITE         *rewriter.PushAppITE
	assertedElimBounds        *rewriter.ElimBounds
	assertedPullNested        *normal_forms.PullNestedQuantifiers
	assertedMacros            *macros.Manager
	definedNames              *normal_forms.DefinedNames
	quantifierCosts           *SMTQICostModel
	modelCooperation          *cooperate.Cooperation
	paramContext              *uparams.ParamsContext
	paramGlobals              *uparams.GlobalParamsService
	smtParams                 *SMTParams
	smtState                  SMTParamsState
	arithState                SMTArithState
	bvState                   SMTBVState
	preprocessState           SMTPreprocessorState
	produceModel              bool
	preprocess                bool
	skipRepeatedPreprocessing bool
	simplifyInitialPushOnce   bool
	reduceIfSharingChanged    bool
	connectedMultiPatterns    bool
	reduceScopedClauses       bool
	timerClock                func() (uint64, error)
	closing                   bool
	closed                    bool

	// Source m_has_quantifiers is sticky, including across scope pops.
	assertedHasQuantifiers   bool
	assertedSubstitution     ast.ASTExprSubstitution
	assertedScopedSubst      ast.ASTScopedExprSubstitution
	assertedInconsistent     bool
	assertedScopeConflicts   []bool
	assertedParams           uparams.ParamsRef
	assertedParamsReady      bool
	assertedElimAnd          bool
	assertedPhaseReady       bool
	preprocessingSetupDone   bool
	setupLogic               string
	sequenceSetupPlaceholder SMTTheoryInternalizer
	copiedArithmeticPlugin   bool
	pendingSetupLRA          *SMTLRATheory
	copiedArithmeticOwner    *SMTArithParams
	copiedArithmeticConfig   SMTArithState
	copiedBVOwner            *SMTBVParams
	copiedBitBlasterOwner    *bit_blaster.SMTBitBlasterParams
	copiedArrayPlugin        bool
	copiedArrayOwner         *SMTArrayParams
	// presetupFamilies are the plugins context::register_plugin received
	// before setup (copy_plugins, ensure_pb), in registration order.
	presetupFamilies []ast.FamilyID
}

func (k *SMTKernel) readPreprocessorState(context *uparams.ParamsContext, globals *uparams.GlobalParamsService, params *uparams.ParamsRef) (state SMTPreprocessorState, result error) {
	value, err := NewSMTPreprocessorParams(context, params, globals, k.manager.Budget())
	if err != nil {
		if value != nil {
			result = errors.Join(err, value.Close())
			return state, result
		}
		return state, err
	}
	defer func() { result = errors.Join(result, value.Close()) }()
	return value.State()
}

func NewSMTKernel(manager *ast.ASTManager, quantifiers *SMTQuantifierRegistry) (*SMTKernel, error) {
	checker, err := NewSMTCheckerContext(manager)
	if err != nil {
		return nil, err
	}
	relevancy, err := NewSMTRelevancyPropagator(checker, true)
	if err != nil {
		return nil, err
	}
	internalizer, err := newSMTInternalizerState(manager, checker, quantifiers)
	if err != nil {
		return nil, err
	}
	proofs, err := manager.ProofsEnabled()
	if err != nil {
		return nil, errors.Join(err, internalizer.Close())
	}
	if !proofs {
		if err = internalizer.SetBinaryClauseOptimization(true); err != nil {
			return nil, errors.Join(err, internalizer.Close())
		}
	}
	if err = internalizer.SetRelevancy(relevancy); err != nil {
		return nil, errors.Join(err, internalizer.Close())
	}
	proof, err := manager.NewRef(ast.ASTHandle{})
	if err != nil {
		return nil, errors.Join(err, internalizer.Close())
	}
	macroManager, err := macros.NewManager(manager)
	if err != nil {
		return nil, errors.Join(err, manager.DelRef(&proof), internalizer.Close())
	}
	names, err := normal_forms.NewDefinedNames(manager)
	if err != nil {
		return nil, errors.Join(err, macroManager.Close(), manager.DelRef(&proof), internalizer.Close())
	}
	sharing, err := rewriter.NewMaximizeBVSharing(manager)
	if err != nil {
		if sharing != nil {
			err = errors.Join(err, sharing.Close())
		}
		return nil, errors.Join(err, names.Close(), macroManager.Close(), manager.DelRef(&proof), internalizer.Close())
	}
	bit2int, err := rewriter.NewBit2Int(manager)
	if err != nil {
		if bit2int != nil {
			err = errors.Join(err, bit2int.Close())
		}
		return nil, errors.Join(err, sharing.Close(), names.Close(), macroManager.Close(), manager.DelRef(&proof), internalizer.Close())
	}
	kernel := &SMTKernel{
		manager: manager, checker: checker, relevancy: relevancy, internalizer: internalizer, unsatProof: proof, assertedMacros: macroManager, definedNames: names, bvSharing: sharing, assertedBit2Int: bit2int,
		// context::context initializes m_unknown("unknown"); last_failure_as_string
		// returns it for an OK search failure.
		unknown: "unknown",
		smtState: SMTParamsState{
			MaxConflicts: ^uint32(0), InvDecay: 1.052, RandomInitialActivity: 1, RandomVarFreq: 0.01, CaseSplitStrategy: 1, RestartStrategy: 1, RestartInitial: 100, RestartFactor: 1.1,
			RestartAdaptive: true, AgilityFactor: 0.9999, RestartAgilityThreshold: 0.18, SimplifyClauses: true,
		},
	}
	internalizer.afterFlush = kernel.releaseContextModels
	internalizer.onQuantifierFlush = kernel.closeQuantifierCosts
	internalizer.resourceLimitsExceeded = kernel.resourceLimitsExceeded
	internalizer.setReasonUnknown = kernel.SetReasonUnknown
	// asserted_formulas::push_scope/pop_scope reach m_bv_sharing on every
	// context scope.
	internalizer.onScopePush = func() error {
		if kernel.bvSharing == nil {
			return nil
		}
		return kernel.bvSharing.PushScope()
	}
	internalizer.onScopePop = func(count uint32) error {
		if kernel.bvSharing == nil {
			return nil
		}
		return kernel.bvSharing.PopScope(count)
	}
	internalizer.assertedHasQuantifiers = &kernel.assertedHasQuantifiers
	internalizer.assertedInconsistent = &kernel.assertedInconsistent
	internalizer.assertedFormulas = &kernel.assertions
	kernel.assertedSubstitution, err = manager.NewExprSubstitution()
	if err != nil {
		return nil, errors.Join(err, kernel.Close())
	}
	kernel.assertedScopedSubst, err = manager.NewScopedExprSubstitution(kernel.assertedSubstitution)
	if err != nil {
		return nil, errors.Join(err, kernel.Close())
	}
	return kernel, nil
}

// ConfigurePreprocessing installs the source theory-rewrite pass used before
// asserted formulas enter the retained formula stack. It must be configured
// before the first assertion is stored.
func (k *SMTKernel) ConfigurePreprocessing(context *uparams.ParamsContext, globals *uparams.GlobalParamsService, params *uparams.ParamsRef) error {
	return k.configurePreprocessing(context, globals, params, nil)
}

func (k *SMTKernel) configurePreprocessing(context *uparams.ParamsContext, globals *uparams.GlobalParamsService, params *uparams.ParamsRef, sourceParams *SMTParams) error {
	return k.configurePreprocessingParams(context, globals, params, sourceParams, false)
}

// Nested source kernels borrow context::m_fparams. Solver copies retain the
// existing owned-clone path; the String expression solver uses the borrowed
// path and must close before the parent parameter owner.
func (k *SMTKernel) configurePreprocessingParams(context *uparams.ParamsContext, globals *uparams.GlobalParamsService, params *uparams.ParamsRef, sourceParams *SMTParams, borrowSource bool) error {
	if err := k.configurePreprocessingParamsCore(context, globals, params, sourceParams, borrowSource); err != nil {
		return err
	}
	// The source context constructor runs init() after its asserted-formula
	// and quantifier-manager members, whose setup this configuration ports.
	return k.internalizer.initContextEnodes()
}

func (k *SMTKernel) configurePreprocessingParamsCore(context *uparams.ParamsContext, globals *uparams.GlobalParamsService, params *uparams.ParamsRef, sourceParams *SMTParams, borrowSource bool) error {
	if err := k.open(); err != nil {
		return err
	}
	if borrowSource && sourceParams == nil {
		return uparams.ErrParamsOwner
	}
	if len(k.assertions) != 0 || k.assertedHead != 0 || len(k.scopes) != 0 || k.preprocessor != nil || k.smtParams != nil || k.assertedParamsReady {
		return ast.ErrASTDomain
	}
	if context == nil || globals == nil || context.SymbolsField != k.manager.Symbols || globals.Context != context {
		return uparams.ErrParamsOwner
	}
	k.paramContext = context
	k.paramGlobals = globals
	// expand_macros' th_rewriter(m) reads the process rewriter module.
	if err := k.assertedMacros.SetRewriterParams(context, globals); err != nil {
		return err
	}
	local, err := context.NewValue()
	if err != nil {
		return err
	}
	k.assertedParams, k.assertedParamsReady = local, true
	if params != nil {
		if err = context.Append(&k.assertedParams, params); err != nil {
			return err
		}
	}
	var full *SMTParams
	if sourceParams == nil {
		full, err = NewSMTParams(context, params, globals, k.manager.Budget())
	} else if sourceParams.Context != context || sourceParams.Globals != globals {
		return uparams.ErrParamsOwner
	} else if borrowSource {
		full = sourceParams
		_, err = full.State()
	} else {
		full, err = sourceParams.Clone()
	}
	if err != nil {
		if full != nil {
			err = errors.Join(err, closeSMTKernelParams(full, borrowSource))
		}
		return err
	}
	// Source constructs the inference functor with the initial params before
	// smt_solver applies its full update. Preserve constructor-only policies.
	patternOptions, err := full.preprocess.pattern.InferenceOptions(nil)
	if err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}

	// context constructs its queue against the borrowed constructor fparams.
	// The later solver update can restore case_split without replacing that queue.
	if k.caseSplitQueue == nil {
		if err = k.initializeQueueHeuristics(&full.state); err != nil {
			return errors.Join(err, closeSMTKernelParams(full, borrowSource))
		}
	}
	// smt_solver constructs smt_params and its context first, then invokes the
	// full updt_params overload. That second step updates embedded bases such as
	// dyn_ack_params, whose constructors intentionally saw an empty params_ref.
	if sourceParams == nil {
		if err = full.Update(params); err != nil {
			return errors.Join(err, closeSMTKernelParams(full, borrowSource))
		}
	}
	fullState, err := full.State()
	if err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	dynamic, err := full.DynamicAckState()
	if err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	arithmetic, err := full.ArithmeticState()
	if err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	bitVector, err := full.BitVectorState()
	if err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	quantifiers, err := full.QuantifierState()
	if err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	proofs, err := k.manager.ProofsEnabled()
	if err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	if err = k.internalizer.SetBinaryClauseOptimization(fullState.BinaryClauseOpt && !proofs); err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	if err = k.internalizer.ConfigureDynamicAck(dynamic); err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	if err = k.internalizer.ConfigureClauseMaintenance(smtClauseMaintenanceConfigFor(fullState)); err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	if err = k.configureQueueHeuristics(fullState, false); err != nil {
		return errors.Join(err, closeSMTKernelParams(full, borrowSource))
	}
	// context::context: m_relevancy_lvl(2) until the first setup_context.
	k.setContextRelevancy(2)
	k.internalizer.newCore2thEq = fullState.NewCore2thEq
	k.smtParams = full
	k.smtParamsBorrowed = borrowSource
	k.internalizer.smtParams = full
	k.caseSplitQueue.liveParams = full
	k.internalizer.contextParams = &k.assertedParams
	k.internalizer.paramsContext, k.internalizer.globals = context, globals
	k.patternInference, err = pattern.NewInferenceRewriterWithOptions(k.manager, patternOptions)
	if err != nil {
		return err
	}
	if err = full.preprocess.pattern.UpdateInferenceRewriter(k.patternInference, nil); err != nil {
		return err
	}
	k.smtState = fullState
	k.arithState = arithmetic
	k.bvState = bitVector
	var state SMTPreprocessorState
	if sourceParams == nil {
		state, err = k.readPreprocessorState(context, globals, params)
	} else {
		state, err = full.preprocess.State()
	}
	if err != nil {
		return err
	}
	k.preprocessState = state
	name := "preprocess"
	enabled, err := context.GetBoolName(params, &name, true)
	if err != nil {
		return err
	}
	if sourceParams != nil {
		enabled = fullState.Preprocess
	}
	value, err := rewriter.NewTheoryRewriter(k.manager, context, globals, params)
	// Construction may return a partial owner. Publish it before inspecting
	// the error so kernel destruction can retire the allocated configuration.
	k.preprocessor = value
	if err != nil {
		return err
	}
	k.internalizer.theoryRewriter = value
	k.internalizer.assertedPopFlush = k.flushAssertedCache
	k.internalizer.baseScopePop = k.dropUnsatProof
	if err = value.SetSubstitution(&k.assertedSubstitution); err != nil {
		return err
	}
	k.preprocess = enabled
	if err = k.setAssertedEliminateAnd(false); err != nil {
		return err
	}
	if k.modelConfig.Memory == nil {
		k.modelCooperation, err = cooperate.NewCooperation(k.manager.Budget())
		if err != nil {
			return err
		}
		k.modelConfig = model.ModelEvaluatorConfig{
			Context: context, Globals: globals, Memory: k.manager.NumeralService().RuntimeOwner(), Cooperation: k.modelCooperation,
		}
	}
	if err = k.configureQuantifiers(full, fullState, quantifiers); err != nil {
		return err
	}
	// The quantifier manager (and its qi_queue cost parser) is a context
	// member, built before the constructor body runs context::init.
	if !k.trueProofInitialized {
		k.trueProofInitialized = true
		return k.internalizer.initTrueProof()
	}
	return nil
}

func closeSMTKernelParams(full *SMTParams, borrowed bool) error {
	if full == nil || borrowed {
		return nil
	}
	return full.Close()
}

func (k *SMTKernel) configureQuantifiers(full *SMTParams, state SMTParamsState, qi SMTQIState) error {
	if k == nil || k.internalizer == nil || k.preprocessor == nil || full == nil {
		return ast.ErrASTHandle
	}
	if k.internalizer.quantifierManager != nil {
		return ast.ErrASTDomain
	}
	if k.internalizer.quantifiers == nil {
		costText, err := full.QuantifierCostText()
		if err != nil {
			return err
		}
		newGenerationText, err := full.QuantifierNewGenerationText()
		if err != nil {
			return err
		}
		costs, err := NewSMTQICostModel(k.manager, costText, newGenerationText, k.queueWarnings)
		if err != nil {
			return err
		}
		schedule := NewSMTQIQueueSchedule(k.manager, float32(qi.EagerThreshold), float32(qi.LazyThreshold), qi.ConservativeFinalCheck)
		registry, err := NewSMTQuantifierRegistry(k.manager, schedule, costs, qi.MaxInstances)
		if err != nil {
			return errors.Join(err, costs.Close())
		}
		registry.profile = qi.Profile
		registry.profileFrequency = qi.ProfileFrequency
		k.internalizer.quantifiers = registry
		k.quantifierCosts = costs
	}
	mbqiID, err := qi.MBQIId.String()
	if err != nil {
		return err
	}
	_, err = NewSMTQuantifierManager(k.internalizer, k.preprocessor, SMTQuantifierManagerConfig{
		MaxEagerMultipatterns:       qi.MaxEagerMultipatterns,
		MaxLazyMultipatternMatching: qi.MaxLazyMultipatternMatching,
		LazyInstantiation:           qi.LazyInstantiation,
		Ematching:                   state.Ematching,
		PromoteUnsat:                qi.PromoteUnsat,
		QuickUnsat:                  qi.QuickChecker >= 1,
		QuickNotSat:                 qi.QuickChecker >= 2,
		LazyQuick:                   qi.LazyQuickChecker,
		MBQI:                        qi.MBQI,
		MaxCexs:                     qi.MaxCexs,
		MaxIterations:               qi.MaxIterations,
		ForceTemplate:               qi.ForceTemplate,
		MBQIID:                      mbqiID,
		MBQITrace:                   qi.Trace,
		CandidateModel:              k.buildCandidateModelGenerator,
	})
	return err
}

func (k *SMTKernel) buildCandidateModelGenerator() (*SMTModelGenerator, error) {
	if err := k.open(); err != nil {
		return nil, err
	}
	// m_model_generator->reset() releases the previous model's values
	// before the new model is made.
	if err := k.releaseStaleModel(); err != nil {
		return nil, err
	}
	if err := k.releaseGeneratorPins(); err != nil {
		return nil, err
	}
	// A proto model left by an earlier update_model (scoped_mk_model drops
	// the search's own) stays m_proto_model until the new one replaces it.
	previousTrail := k.protoTrail
	k.protoTrail = nil
	releasePrevious := func() (result error) {
		for i := range previousTrail {
			result = errors.Join(result, k.manager.DelRef(&previousTrail[i]))
		}
		previousTrail = nil
		return result
	}
	generator, err := NewSMTModelGenerator(k.manager)
	if err != nil {
		return nil, errors.Join(err, releasePrevious())
	}
	generator.pinSink = &k.generatorPins
	if k.rootValueOrder == nil {
		k.rootValueOrder = ast.NewObjMap(k.manager)
	}
	generator.rootOrder = k.rootValueOrder
	generator.trailSink = &k.protoTrail
	fail := func(cause error) (*SMTModelGenerator, error) {
		return nil, errors.Join(cause, generator.Close(), releasePrevious())
	}
	if err = generator.SetContext(k.checker); err != nil {
		return fail(err)
	}
	generator.searchFailure = k.lastFailure
	if err = generator.InitializeModel(k.modelConfig); err != nil {
		return fail(err)
	}
	if err = generator.BuildStateValues(k.internalizer); err != nil {
		return fail(fmt.Errorf("build state model values: %w", err))
	}
	if err = generator.registerAssertedMacros(k.assertedMacros); err != nil {
		return fail(err)
	}
	// m_proto_model = m_model_generator->mk_model(): the previous proto
	// model goes now.
	// A predecessor MBQI rejected is that m_proto_model too.
	var retired error
	if manager := k.internalizer.quantifierManager; manager != nil {
		retired = manager.releaseRetiredProto()
	}
	if err = errors.Join(k.releaseUpdateProto(), retired, releasePrevious()); err != nil {
		return fail(err)
	}
	// m_qmanager->adjust_model: default_qm_plugin fixes the model only
	// with MBQI.
	if manager := k.internalizer.quantifierManager; manager != nil && manager.mbqi && manager.modelFinder != nil {
		if err = manager.modelFinder.FixModel(generator.model); err != nil {
			return fail(err)
		}
	}
	// Source context::mk_proto_model completes partial interpretations after
	// quantifier model adjustment, including arrays with unspecified defaults.
	if err = generator.model.CompletePartialFunctions(); err != nil {
		return fail(err)
	}
	if err = generator.model.Cleanup(); err != nil {
		return fail(err)
	}
	if k.smtState.ModelCompact {
		if err = generator.model.Compress(); err != nil {
			return fail(err)
		}
	}
	// IF_VERBOSE(11, model_pp(verbose_stream(), *m_proto_model);)
	// (AUDIT.md FUZZ-F5; g3trace builds only).
	if diagnostic.VerboseProgress {
		if err = k.protoModelVerbose(generator); err != nil {
			return fail(err)
		}
	}
	return generator, nil
}

// UpdateParams refreshes the assertion rewriter and the hidden preprocessing
// switch using the kernel's borrowed parameter services.
func (k *SMTKernel) UpdateParams(params *uparams.ParamsRef) error {
	if err := k.open(); err != nil {
		return err
	}
	if k.paramContext == nil || k.paramGlobals == nil || k.smtParams == nil {
		return uparams.ErrParamsOwner
	}
	if err := k.smtParams.Update(params); err != nil {
		return err
	}
	paramsState, err := k.smtParams.State()
	if err != nil {
		return err
	}
	dynamic, err := k.smtParams.DynamicAckState()
	if err != nil {
		return err
	}
	arithmetic, err := k.smtParams.ArithmeticState()
	if err != nil {
		return err
	}
	bitVector, err := k.smtParams.BitVectorState()
	if err != nil {
		return err
	}
	quantifiers, err := k.smtParams.QuantifierState()
	if err != nil {
		return err
	}
	mbqiID, err := quantifiers.MBQIId.String()
	if err != nil {
		return err
	}
	if err = k.internalizer.UpdateDynamicAck(dynamic); err != nil {
		return err
	}
	if err = k.configureQueueHeuristics(paramsState, false); err != nil {
		return err
	}
	// smt_solver::updt_params only changes the shared parameter; the context
	// level takes it at the first setup_context and afterwards only follows
	// it downward (check or push).
	k.internalizer.newCore2thEq = paramsState.NewCore2thEq
	k.smtState = paramsState
	if k.patternInference != nil {
		if err = k.smtParams.preprocess.pattern.UpdateInferenceRewriter(k.patternInference, nil); err != nil {
			return err
		}
	}
	k.arithState = arithmetic
	k.bvState = bitVector
	if k.internalizer.quantifierManager != nil {
		manager := k.internalizer.quantifierManager
		manager.mbqiTrace = quantifiers.Trace
		if err = manager.UpdateMBQI(quantifiers.MBQI, mbqiID, quantifiers.MaxCexs, quantifiers.MaxIterations, quantifiers.ForceTemplate); err != nil {
			return err
		}
		manager.ematching = paramsState.Ematching
		manager.maxEagerMultipatterns = quantifiers.MaxEagerMultipatterns
		manager.maxLazyMultipatternMatching = quantifiers.MaxLazyMultipatternMatching
		manager.lazyInstantiation = quantifiers.LazyInstantiation
		manager.registry.maxInstances = quantifiers.MaxInstances
		manager.registry.profile = quantifiers.Profile
		manager.registry.profileFrequency = quantifiers.ProfileFrequency
		manager.registry.schedule.lazyThreshold = float32(quantifiers.LazyThreshold)
		// Source qi_queue caches its eager threshold and parsed cost/new-gen
		// functions in the constructor; those remain unchanged on updates.
	}
	if err = k.configureArithmeticTheories(arithmetic); err != nil {
		return err
	}
	if err = k.configureBitVectorTheories(bitVector, k.smtParams.preprocess.bit); err != nil {
		return err
	}
	if err = k.configureArrayTheories(k.smtParams.array.state); err != nil {
		return err
	}
	name := "preprocess"
	enabled, err := k.paramContext.GetBoolName(params, &name, true)
	if err != nil {
		return err
	}
	// Source updates the existing embedded parameter object. Its hidden
	// fields include policy selected by setup and have no public getters.
	state, err := k.smtParams.preprocess.State()
	if err != nil {
		return err
	}
	if params != nil {
		if err = k.paramContext.Append(&k.assertedParams, params); err != nil {
			return err
		}
	}
	// Quantifier instantiation borrows this rewriter independently of the
	// assertion-preprocessing switch. Preserve its lifetime when that switch
	// is disabled, including across later parameter updates.
	// asserted_formulas sets the rewriter's substitution once, in its
	// constructor; updt_params only appends the parameters (set_substitution
	// would reset the rewriter's cache).
	created := k.preprocessor == nil
	if created {
		k.preprocessor, err = rewriter.NewTheoryRewriter(k.manager, k.paramContext, k.paramGlobals, params)
		if err == nil {
			err = k.preprocessor.SetSubstitution(&k.assertedSubstitution)
		}
	} else {
		// asserted_formulas::updt_params appends p to m_params; the rewriter
		// reads the accumulated m_params (the eliminate-and settings
		// included) at its next updt_params.
		err = k.preprocessor.UpdateParams(&k.assertedParams)
	}
	if err == nil {
		k.internalizer.theoryRewriter = k.preprocessor
		k.internalizer.assertedPopFlush = k.flushAssertedCache
		k.internalizer.baseScopePop = k.dropUnsatProof
		k.preprocess = enabled
		k.preprocessState = state
		// set_eliminate_and is a no-op while the flag is unchanged: a later
		// updt_params does not flush the rewriter's cache.
		if created {
			k.assertedPhaseReady = false
			err = k.setAssertedEliminateAnd(false)
		}
	}
	return err
}

// UpdateContextParams is context::updt_params: m_params.append(p) and
// m_asserted_formulas.updt_params(p), which also only appends. Unlike
// UpdateParams (smt_solver::updt_params) it leaves smt_params unchanged.
func (k *SMTKernel) UpdateContextParams(params *uparams.ParamsRef) error {
	if err := k.open(); err != nil {
		return err
	}
	if k.paramContext == nil || !k.assertedParamsReady {
		return uparams.ErrParamsOwner
	}
	if params == nil {
		return nil
	}
	return k.paramContext.Append(&k.assertedParams, params)
}

func (k *SMTKernel) open() error {
	if err := k.openOwner(); err != nil {
		return err
	}
	if k.pendingPop != nil {
		return ast.ErrASTPending
	}
	return nil
}

func (k *SMTKernel) openOwner() error {
	if k == nil || k.manager == nil || k.closed {
		return ast.ErrASTHandle
	}
	if k.closing {
		return ast.ErrASTPending
	}
	if k.internalizer == nil {
		return ast.ErrASTHandle
	}
	return nil
}

func (k *SMTKernel) Internalizer() (*SMTInternalizerState, error) {
	if err := k.open(); err != nil {
		return nil, err
	}
	return k.internalizer, nil
}

func (k *SMTKernel) RegisterTheory(theory SMTTheoryInternalizer) error {
	if err := k.open(); err != nil {
		return err
	}
	if datatype, ok := theory.(*SMTDatatypeTheory); ok && k.smtParams != nil && datatype.parameterOwner == nil {
		datatype.parameterOwner = &k.smtParams.datatype
	}
	if pb, ok := theory.(*SMTPseudoBooleanTheory); ok && k.smtParams != nil && !pb.configured {
		pb.parameterOwner = &k.smtParams.pb
	}
	if array := smtArrayCore(theory); array != nil && k.smtParams != nil {
		config := k.smtParams.array.state
		array.parameterOwner = &k.smtParams.array
		if k.copiedArrayOwner != nil {
			config = k.copiedArrayOwner.state
			array.parameterOwner = k.copiedArrayOwner
		}
		if err := array.ConfigureArray(config); err != nil {
			return err
		}
	}
	if bv, ok := theory.(*SMTBitVectorTheory); ok && k.smtParams != nil {
		bv.bitBlasterParams = k.smtParams.preprocess.bit
		if k.copiedBitBlasterOwner != nil {
			bv.bitBlasterParams = *k.copiedBitBlasterOwner
		}
	}
	if configurable, ok := theory.(interface{ ConfigureBitVector(SMTBVState) error }); ok {
		config := k.bvState
		if k.copiedBVOwner != nil {
			config = k.copiedBVOwner.state
		}
		if err := configurable.ConfigureBitVector(config); err != nil {
			return err
		}
	}
	if configurable, ok := theory.(interface{ ConfigureArithmetic(SMTArithState) error }); ok {
		config := k.arithState
		if k.copiedArithmeticOwner != nil {
			config = k.copiedArithmeticOwner.state
		}
		if err := configurable.ConfigureArithmetic(config); err != nil {
			return err
		}
	}
	return k.internalizer.RegisterTheory(theory)
}

func (k *SMTKernel) Assert(formula, proof ast.ASTHandle) (err error) {
	if err := k.open(); err != nil {
		return err
	}
	// context::assert_expr: timeit tt(get_verbosity_level() >= 100,
	// "smt.simplifying") around assert_expr_core (AUDIT.md FUZZ-F5).
	if diagnostic.VerboseProgress {
		tt, err := k.startTimeit("smt.simplifying")
		if err != nil {
			return err
		}
		return closeTimeit(tt, k.assertFormulaCore(formula, proof))
	}
	return k.assertFormulaCore(formula, proof)
}
func (k *SMTKernel) assertFormulaCore(formula, proof ast.ASTHandle) (resultErr error) {
	if err := k.open(); err != nil {
		return err
	}
	// Kernels used without preprocessing configuration finish context::init here.
	if err := k.internalizer.initContextEnodes(); err != nil {
		return err
	}
	// context::assert_expr_core: if (get_cancel_flag()) return;
	if canceled, err := k.manager.Canceled(); canceled || err != nil {
		return err
	}
	// Then pop_to_base_lvl.
	if err := k.popToBaseLevel(); err != nil {
		return err
	}
	sort, err := k.manager.GetSort(formula)
	if err != nil {
		return err
	}
	boolean, err := k.manager.MkBoolSort()
	if err != nil {
		return err
	}
	if sort != boolean {
		return ast.ErrASTDomain
	}
	if !proof.IsNull() {
		if isProof, err := k.manager.IsProof(proof); err != nil || !isProof {
			if err != nil {
				return err
			}
			return ast.ErrASTDomain
		}
	}
	if proof.IsNull() {
		proofs, err := k.manager.ProofsEnabled()
		if err != nil {
			return err
		}
		if proofs {
			proof, err = k.manager.MkProofAsserted(formula)
			if err != nil {
				return err
			}
		}
	}
	// The source owns expr_ref/proof_ref inputs before changing rewriter
	// parameters and flushing caches. Keep borrowed inputs alive across that
	// flush even when the previous rewriter cache supplied their last pin.
	scope := &smtAssertionScope{manager: k.manager}
	defer func() { resultErr = scope.finish(resultErr) }()
	scope.inputs[0], err = k.manager.NewRef(formula)
	if err != nil {
		return err
	}
	scope.inputs[1], err = k.manager.NewRef(proof)
	if err != nil {
		return err
	}
	if k.assertedFormulasInconsistent() {
		return nil
	}
	if k.preprocess {
		if err = k.traceAssertedExpression("assert_expr_bug", "assert_expr", 151, "", formula); err != nil {
			return err
		}
	}
	hasQuantifiers, err := k.manager.HasQuantifiers(formula)
	if err != nil {
		return err
	}
	if err = k.setAssertedEliminateAnd(false); err != nil {
		return err
	}
	// m_rewriter(e, r, pr) overwrites the local r(e): an input with no other
	// owner dies when the rewriter publishes its result, before push_assertion.
	input := formula
	control.StudyStep("before-assert-rewrite");formula, proof, err = k.preprocessAssertExpr(formula, proof, scope.inputs[0])
	control.StudyStep("assert-rewrite");if k.preprocess && k.preprocessor != nil {
		// The preprocessing call can return owning results together with a
		// cleanup error. Adopt them before examining that error or tracing.
		scope.rewritten = [2]ast.ASTHandle{formula, proof}
	}
	if err != nil {
		return err
	}
	if smtcoreSourceDebug {
		if err = k.debugAssertExprInputOwned(input); err != nil {
			return err
		}
	}
	if k.preprocess {
		if err = k.traceAssertedExpression("assert_expr_bug", "assert_expr", 160, "after...\n", formula); err != nil {
			return err
		}
	}
	k.assertedHasQuantifiers = k.assertedHasQuantifiers || hasQuantifiers
	limit := len(k.assertions)
	wasInconsistent := k.assertedInconsistent
	defer control.StudyStep("record-assertion");if err = k.pushAssertion(formula, proof); err == nil {
		err = k.traceAssertedBody("asserted_formulas_bug", "assert_expr", 166, func(out io.Writer) error {
			if _, traceErr := io.WriteString(out, "after assert_expr\n"); traceErr != nil {
				return traceErr
			}
			return k.DisplayAssertedFormulas(out)
		})
		if err == nil {
			return nil
		}
	}
	for index := len(k.assertions); index > limit; index-- {
		assertion := &k.assertions[index-1]
		if !assertion.Proof.IsNull() {
			err = errors.Join(err, k.manager.DecRef(assertion.Proof))
		}
		err = errors.Join(err, k.manager.DecRef(assertion.Formula))
	}
	k.assertions = k.assertions[:limit]
	k.assertedInconsistent = wasInconsistent
	return err
}

// ErrAssertExprInputUnowned reports, in g3debug builds, an assert_expr input
// that died when the rewriter published its result over expr_ref r(e) while
// the asserting caller holds no owner for it.
var ErrAssertExprInputUnowned = errors.New("g3: assert_expr input died at rewrite; caller holds no owner")

// debugAssertExprInputOwned checks the source's later read of e
// (m_has_quantifiers |= has_quantifiers(e) after m_rewriter(e, r, pr)): the
// input must outlive the rewrite, so the asserting caller must own it.
// Callers whose source passes a raw temporary, and test fixtures, are exempt.
// Release builds compile this away.
func (k *SMTKernel) debugAssertExprInputOwned(input ast.ASTHandle) error {
	_, err := k.manager.GetRefCount(input)
	if err == nil || !errors.Is(err, ast.ErrASTHandle) {
		return err
	}
	caller, exempt := debugAssertExprCaller()
	if exempt {
		return nil
	}
	return fmt.Errorf("%w (%s): %w", ErrAssertExprInputUnowned, caller, err)
}

// assertExprForwarders hand their caller's expression straight to
// assert_expr, as their sources do (smt_solver::assert_expr,
// Z3_solver_assert, spacer's pushed virtual_solver::assert_expr, ...): the
// owner obligation belongs to their caller.
var assertExprForwarders = []string{
	"/pkg/smtcore.(*SMTKernel).Assert",
	"/pkg/smtcore.(*SMTKernel).assertFormulaCore",
	"/pkg/smtcore.(*SMTSolver).Assert",
	"/pkg/smtcore.(*SMTSolver).AssertFormula",
	"/pkg/smtcore.(*SMTSolver).AssertTracked",
	"/pkg/muz/spacer.(*VirtualSolver).Assert",
	"/pkg/muz/spacer.(*PropSolver).Assert",
	"/pkg/muz/spacer.(*ItpSolver).Assert",
	"/pkg/muz/pdr.(*SMTContext).Assert",
	"/pkg/muz/pdr.(*PropSolver).AddFormula",
	"/pkg/api.(*APISimpleSolver).Assert",
	"/pkg/api.(*APISimpleSolver).AssertTracked",
	"/pkg/qe.(*qsatKernel).assertExpression",
}

// assertExprRawTemporaries pass a fresh temporary to assert_expr in their
// source too (for example unit_subsumption_tactic's
// m_context.assert_expr(m.mk_iff(new_clause(), g->form(i)))).
var assertExprRawTemporaries = []string{
	"/pkg/smtcore.(*UnitSubsumptionTactic).",
	// get_implied_equalities: m_solver.assert_expr(m.mk_not(m.mk_eq(s, t))).
	"/pkg/smtcore.(*smtImpliedEqualities).",
	// qsat's m_fa.assert_expr(m.mk_not(fml)).
	"/pkg/qe.(*qsatSearch).prepareKernels",
	// qe_sat_tactic weaken/extrapolate: m_solver.assert_expr(m.mk_not(B))
	// and assert_expr(m.mk_iff(proxies.back(), m_assignments[i])).
	"/pkg/qe.satWeaken",
	"/pkg/qe.satCoreExtrapolate",
}

// debugAssertExprExemptFixtures exempts test fixtures that assert fresh
// terms directly; the owner check's own test clears it.
var debugAssertExprExemptFixtures = true

// debugAssertExprCaller names the asserting caller (the first frame above
// the forwarders and the solver adapters) and reports whether it is exempt.
func debugAssertExprCaller() (string, bool) {
	pcs := make([]uintptr, 48)
	frames := runtime.CallersFrames(pcs[:runtime.Callers(3, pcs)])
	var names []string
	exempt := false
	for {
		frame, more := frames.Next()
		forwarder := strings.Contains(frame.File, "/pkg/solver/") && !strings.HasSuffix(frame.File, "_test.go")
		for _, name := range assertExprForwarders {
			if strings.HasSuffix(frame.Function, name) {
				forwarder = true
			}
		}
		if !forwarder || len(names) != 0 {
			if len(names) == 0 {
				exempt = debugAssertExprExemptFixtures && strings.HasSuffix(frame.File, "_test.go")
				for _, name := range assertExprRawTemporaries {
					if strings.Contains(frame.Function, name) {
						exempt = true
					}
				}
			}
			names = append(names, fmt.Sprintf("%s:%d", frame.Function, frame.Line))
			if len(names) == 4 {
				break
			}
		}
		if !more {
			break
		}
	}
	return strings.Join(names, " <- "), exempt
}

func (k *SMTKernel) Assertions() []SMTKernelAssertion {
	if k == nil {
		return nil
	}
	return append([]SMTKernelAssertion(nil), k.assertions...)
}

func (k *SMTKernel) internalizePending() (resultErr error) {
	// context::get_cancel_flag is a counted reslimit::inc, including when
	// the asserted manager is already inconsistent or has no pending rows.
	if canceled, err := k.manager.Canceled(); canceled || err != nil {
		return err
	}
	// timeit tt(get_verbosity_level() >= 100, "smt.preprocessing") for the
	// rest of internalize_assertions (AUDIT.md FUZZ-F5).
	if diagnostic.VerboseProgress {
		tt, err := k.startTimeit("smt.preprocessing")
		if err != nil {
			return err
		}
		defer func() { resultErr = closeTimeit(tt, resultErr) }()
	}
	ready, err := k.reduceAssertedPending()
	if err != nil || !ready {
		return err
	}
	if k.assertedFormulasInconsistent() {
		if k.internalizer.Inconsistent() {
			return nil
		}
		proof, err := k.AssertionInconsistencyProof()
		if err != nil {
			return err
		}
		// Set the Boolean conflict directly: pending expressions must never
		// enter theory/quantifier internalization on this source branch.
		// Without an inconsistency proof the source sets an axiom conflict.
		if proof.IsNull() {
			return k.internalizer.AssignLiteral(SMTFalseLiteral, NewSMTBooleanAxiom())
		}
		if err := k.internalizer.assignRootLiteral(SMTFalseLiteral, proof); err != nil {
			return err
		}
		if !proof.IsNull() {
			return k.manager.SetRef(k.unsatProof, proof)
		}
		return nil
	}
	head := k.assertedHead
	for head < len(k.assertions) {
		if canceled, err := k.manager.Canceled(); canceled || err != nil {
			return errors.Join(err, k.commitAssertedTo(head))
		}
		head, err = k.internalizePendingRow(head)
		if err != nil {
			return errors.Join(err, k.commitAssertedTo(head))
		}
	}
	return k.commitAssertedTo(head)
}

// Source commit forbids declarations and retains each completed row's binding
// in the same scoped substitution borrowed by subsequent assertion rewriting.
func (k *SMTKernel) commitAssertedTo(head int) error {
	if head < k.assertedHead || head > len(k.assertions) {
		return ast.ErrASTDomain
	}
	rows := make([]ast.ASTHandle, 0, head-k.assertedHead)
	for _, row := range k.assertions[k.assertedHead:head] {
		rows = append(rows, row.Formula)
	}
	if err := k.assertedMacros.MarkForbidden(rows); err != nil {
		return err
	}
	depth := make(map[ast.ASTHandle]uint32)
	for _, row := range k.assertions[k.assertedHead:head] {
		if err := k.addAssertionSubstitution(row, depth); err != nil {
			return err
		}
	}
	k.assertedHead = head
	return nil
}

// The initial verification push commits pending premises before saving the
// scope. Later checks and newly asserted formulas use the ordinary schedule.
func (k *SMTKernel) internalizePushBase() error {
	if !k.simplifyInitialPushOnce || k.skipRepeatedPreprocessing || len(k.scopes) != 0 ||
		k.assertedHead != 0 || len(k.assertions) == 0 || k.preprocessor == nil ||
		k.preprocessor.ProofGen() || ast.ASTSourceDebug || k.manager.TraceStream != nil ||
		k.manager.Budget().InjectionArmed() || k.manager.ResourceLimit().Limit != 0 ||
		k.manager.ResourceLimit().CancelFlag() || k.smtState.MaxConflicts != ^uint32(0) {
		return k.internalizePending()
	}
	proofs, err := k.manager.ProofsEnabled()
	if err != nil {
		return err
	}
	if proofs {
		return k.internalizePending()
	}
	// A base consisting entirely of definitions can reduce to zero rows.
	// Its next push must still use the ordinary schedule.
	k.simplifyInitialPushOnce = false
	k.skipRepeatedPreprocessing = true
	k.reduceIfSharingChanged = !ast.ASTValidateHandles && !diagnostic.TraceCompiled() &&
		!k.manager.NumeralService().RuntimeOwner().AllocationLimited()
	defer func() {
		k.skipRepeatedPreprocessing = false
		k.reduceIfSharingChanged = false
	}()
	return k.internalizePending()
}

func (k *SMTKernel) Push() error {
	control.StudyStep("second-child");if err := k.open(); err != nil {
		return err
	}
	// Kernels used without preprocessing configuration finish context::init here.
	if err := k.internalizer.initContextEnodes(); err != nil {
		return err
	}
	// context::push starts with pop_to_base_lvl.
	if err := k.popToBaseLevel(); err != nil {
		return err
	}
	if k.smtParams != nil {
		if err := k.configureArrayTheories(k.smtParams.array.state); err != nil {
			return err
		}
	}
	if k.copiedBVOwner != nil {
		if err := k.configureBitVectorTheories(k.bvState, k.smtParams.preprocess.bit); err != nil {
			return err
		}
	}
	if k.copiedArithmeticOwner != nil {
		if err := k.configureArithmeticTheories(k.arithState); err != nil {
			return err
		}
	}
	if err := k.setupAssertedBounds(false); err != nil {
		return err
	}
	k.setupContextRelevancy()
	if err := k.configureQueueHeuristics(k.smtState, !k.booleanSetupSeeded); err != nil {
		return err
	}
	k.booleanSetupSeeded = true
	if err := k.internalizer.SetupTheories(); err != nil {
		return err
	}
	control.StudyStep("configure-kernel");wasConsistent := !k.internalizer.Inconsistent()
	if err := k.internalizePushBase(); err != nil {
		return err
	}
	// Source context::push propagates the base assertions before saving a
	// scope. Otherwise relevance discovered during the next check is scoped
	// away, and surviving arithmetic terms can disappear from later models.
	control.StudyStep("internalize-pending");control.StudyProp=true;if _, err := k.internalizer.PropagateCore(); err != nil {
		return err
	}
	control.StudyProp=false;control.StudyStep("propagate");if wasConsistent && k.internalizer.Inconsistent() {
		if _, err := k.resolveCheckConflict(); err != nil {
			return err
		}
	}
	if err := k.assertedSourceAssertion(178, "inconsistent() || m_qhead == m_formulas.size() || m.canceled()", func() (bool, error) {
		if k.assertedInconsistent || k.assertedHead == len(k.assertions) {
			return true, nil
		}
		return k.manager.Canceled()
	}); err != nil {
		return err
	}
	if err := k.traceAssertedBody("asserted_formulas_scopes", "push_scope", 179, func(out io.Writer) error {
		_, err := fmt.Fprintf(out, "before push: %d\n", len(k.scopes))
		return err
	}); err != nil {
		return err
	}
	if err := k.manager.ScopedExprSubstitutionPush(k.assertedScopedSubst); err != nil {
		return err
	}
	if err := k.assertedMacros.PushScope(); err != nil {
		return errors.Join(err, k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1))
	}
	if err := k.definedNames.Push(); err != nil {
		return errors.Join(err, k.assertedMacros.PopScope(1), k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1))
	}
	// m_bv_sharing.push_scope() runs inside the context scope push.
	if err := k.internalizer.PushScope(); err != nil {
		return errors.Join(err, k.definedNames.Pop(1), k.assertedMacros.PopScope(1), k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1))
	}
	k.internalizer.pushBaseScope()
	// asserted_formulas::push_scope commits even an inconsistent manager.
	if err := k.commitAssertedTo(len(k.assertions)); err != nil {
		return errors.Join(err, k.internalizer.PopScopes(1), k.definedNames.Pop(1), k.assertedMacros.PopScope(1), k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1))
	}
	k.scopes = append(k.scopes, len(k.assertions))
	k.assertedScopeConflicts = append(k.assertedScopeConflicts, k.assertedInconsistent)
	if err := k.assertedSourceAssertion(184, "inconsistent() || s.m_formulas_lim == m_qhead || m.canceled()", func() (bool, error) {
		if k.assertedInconsistent || k.scopes[len(k.scopes)-1] == k.assertedHead {
			return true, nil
		}
		return k.manager.Canceled()
	}); err != nil {
		return err
	}
	return k.traceAssertedBody("asserted_formulas_scopes", "push_scope", 190, func(out io.Writer) error {
		_, err := fmt.Fprintf(out, "after push: %d\n", len(k.scopes))
		return err
	})
}

// dropUnsatProof is m_unsat_proof = nullptr at a base-scope pop.
func (k *SMTKernel) dropUnsatProof() error {
	if k.unsatProof == (ast.ASTRef{}) {
		return nil
	}
	return k.manager.ResetRef(k.unsatProof)
}

func (k *SMTKernel) Pop(count uint32) error {
	if err := k.openOwner(); err != nil {
		return err
	}
	if k.pendingPop != nil {
		if k.pendingPop.count != count {
			return ast.ErrASTPending
		}
	} else {
		if count == 0 || count > uint32(len(k.scopes)) {
			return ast.ErrASTDomain
		}
		// Source kernel literal queries read the live context, which pop
		// unwinds; drop the Go snapshot of the last search with it.
		if err := k.clearLiteralResults(); err != nil {
			return err
		}
		// context::pop starts with pop_to_base_lvl.
		if err := k.internalizer.popToBaseLevel(); err != nil {
			return err
		}
		if err := k.traceAssertedBody("asserted_formulas_scopes", "pop_scope", 194, func(out io.Writer) error {
			_, err := fmt.Fprintf(out, "before pop %d of %d\n", count, len(k.scopes))
			return err
		}); err != nil {
			return err
		}
		level := len(k.scopes) - int(count)
		k.pendingPop = &smtKernelPendingPop{count: count, level: level, assertions: k.scopes[level]}
	}
	pop := k.pendingPop
	if pop.stage == smtKernelPopInternalizer {
		k.internalizer.userPop = true
		err := k.internalizer.PopScopes(count)
		k.internalizer.userPop = false
		if err != nil {
			return err
		}
		pop.stage++
	}
	if pop.stage == smtKernelPopBVSharing {
		// m_bv_sharing was popped with the context scopes.
		pop.stage++
	}
	if pop.stage == smtKernelPopMacros {
		if err := k.assertedMacros.PopScope(count); err != nil {
			return err
		}
		pop.stage++
	}
	if pop.stage == smtKernelPopDefinedNames {
		if err := k.definedNames.Pop(count); err != nil {
			return err
		}
		pop.stage++
	}
	if pop.stage == smtKernelPopSubstitution {
		// The substitution owns its own deletion continuation and may report
		// an error after publishing the new depth. Observe that publication
		// before deciding whether another scope pop is needed.
		before, err := k.manager.ScopedExprSubstitutionScopeLevel(k.assertedScopedSubst)
		if err != nil {
			return err
		}
		err = k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, count)
		if err == nil {
			pop.stage++
		} else {
			after, depthErr := k.manager.ScopedExprSubstitutionScopeLevel(k.assertedScopedSubst)
			if depthErr == nil && before >= count && after == before-count {
				pop.stage++
			}
			return errors.Join(err, depthErr)
		}
	}
	if pop.stage == smtKernelPopAssertions {
		if err := k.restoreAssertions(pop.assertions); err != nil {
			return err
		}
		pop.stage++
	}
	if pop.stage == smtKernelPopPublish {
		k.scopes = k.scopes[:pop.level]
		k.assertedInconsistent = k.assertedScopeConflicts[pop.level]
		k.assertedScopeConflicts = k.assertedScopeConflicts[:pop.level]
		pop.stage++
	}
	return k.finishPop(count)
}

type smtKernelPopStage uint8

const (
	smtKernelPopInternalizer smtKernelPopStage = iota
	smtKernelPopBVSharing
	smtKernelPopMacros
	smtKernelPopDefinedNames
	smtKernelPopSubstitution
	smtKernelPopAssertions
	smtKernelPopPublish
	smtKernelPopFinish
)

// Each successful source pop is consumed exactly once. Go cleanup can refuse
// between owners, so the next call resumes the same source-order operation.
type smtKernelPendingPop struct {
	count             uint32
	level, assertions int
	stage             smtKernelPopStage
}

func (k *SMTKernel) restoreAssertions(limit int) error {
	// m_formulas.shrink and the vector destructor destroy justified_exprs
	// first to last, and ~justified_expr releases the formula, then the
	// proof. Released roots are cleared so a refused release can be retried.
	for i := limit; i < len(k.assertions); i++ {
		assertion := &k.assertions[i]
		for _, root := range []*ast.ASTHandle{&assertion.Formula, &assertion.Proof} {
			if root.IsNull() {
				continue
			}
			consumed, err := k.manager.DecRefConsumed(*root)
			if consumed {
				*root = ast.ASTHandle{}
			}
			if err != nil {
				return err
			}
		}
	}
	if limit < len(k.assertions) {
		k.assertions = k.assertions[:limit]
	}
	if k.assertedHead > limit {
		k.assertedHead = limit
	}
	return nil
}

// finishPop is the post-publication cleanup tail. Native solver retry must
// repeat this tail, not the already-consumed scopes, if cache reset refuses.
func (k *SMTKernel) finishPop(count uint32) error {
	if err := k.openOwner(); err != nil {
		return err
	}
	if k.pendingPop != nil && (k.pendingPop.count != count || k.pendingPop.stage != smtKernelPopFinish) {
		return ast.ErrASTPending
	}
	if k.preprocessor != nil {
		if err := k.flushAssertedCache(); err != nil {
			return err
		}
	}
	if err := k.traceAssertedBody("asserted_formulas_scopes", "pop_scope", 206, func(out io.Writer) error {
		_, err := fmt.Fprintf(out, "after pop %d\n", count)
		return err
	}); err != nil {
		return err
	}
	k.pendingPop = nil
	return nil
}

func (k *SMTKernel) ScopeLevel() uint32 {
	if k == nil {
		return 0
	}
	return uint32(len(k.scopes))
}

func (k *SMTKernel) prepareCheck(useStaticFeatures bool) error {
	if err := k.configureCheck(useStaticFeatures); err != nil {
		return err
	}
	return k.internalizeCheckAssertions()
}

func (k *SMTKernel) configureCheck(useStaticFeatures bool) error {
	if err := k.open(); err != nil {
		return err
	}
	if k.smtParams != nil {
		if err := k.configureArrayTheories(k.smtParams.array.state); err != nil {
			return err
		}
	}
	if k.copiedBVOwner != nil {
		if err := k.configureBitVectorTheories(k.bvState, k.smtParams.preprocess.bit); err != nil {
			return err
		}
	}
	if k.copiedArithmeticOwner != nil {
		if err := k.configureArithmeticTheories(k.arithState); err != nil {
			return err
		}
	}
	if err := k.setupAssertedBounds(useStaticFeatures); err != nil {
		return fmt.Errorf("smt kernel configure asserted bounds: %w", err)
	}
	k.setupContextRelevancy()
	if err := k.configureQueueHeuristics(k.smtState, !k.booleanSetupSeeded); err != nil {
		return fmt.Errorf("smt kernel configure Boolean heuristics: %w", err)
	}
	k.booleanSetupSeeded = true
	if err := k.internalizer.SetupTheories(); err != nil {
		return fmt.Errorf("smt kernel setup theories: %w", err)
	}
	return nil
}

func (k *SMTKernel) internalizeCheckAssertions() error {
	if err := k.internalizePending(); err != nil {
		return fmt.Errorf("smt kernel internalize assertions: %w", err)
	}
	if k.assertedFormulasInconsistent() || k.internalizer.Inconsistent() {
		return nil
	}
	return nil
}

func (k *SMTKernel) Check() (result lbool.LBool, resultErr error) {
	defer func() {
		if resultErr == nil && result != lbool.True {
			resultErr = k.captureUnsatLiteralResults()
		}
	}()
	ready, err := k.beginCheck()
	if err != nil || !ready {
		return lbool.Undef, err
	}
	if k.internalizer.Inconsistent() {
		return lbool.False, nil
	}
	if err := k.configureCheck(false); err != nil {
		return lbool.Undef, err
	}
	assumptions, refs, err := k.addTheoryAssumptions(nil)
	defer func() {
		resultErr = errors.Join(resultErr, k.releaseTheoryAssumptions(refs))
		if resultErr != nil {
			result = lbool.Undef
		}
	}()
	if err != nil {
		return lbool.Undef, err
	}
	if len(assumptions) != 0 {
		return k.checkConfiguredAssumptions(assumptions)
	}
	if err := k.internalizeCheckAssertions(); err != nil {
		return lbool.Undef, err
	}
	if k.assertedFormulasInconsistent() {
		return lbool.False, nil
	}
	if k.internalizer.Inconsistent() {
		return k.resolveCheckConflict()
	}
	return k.finalizeCheck(k.search())
}

func (k *SMTKernel) ConfigureModelGeneration(enabled bool, config model.ModelEvaluatorConfig) error {
	if err := k.open(); err != nil {
		return err
	}
	k.produceModel = enabled
	k.modelConfig = config
	return nil
}

// mkProtoModelEnabled is mk_proto_model's guard: m_fparams.m_model ||
// m_fparams.m_model_on_final_check || m_qmanager->model_based(), where the
// default plugin's model_based() is m_fparams->m_mbqi. So with smt.mbqi on
// (the default) a check builds its proto model, and ~scoped_mk_model its
// m_model, even when the caller turned m_model off (pdr's prop_solver).
func (k *SMTKernel) mkProtoModelEnabled() bool {
	if k.produceModel || k.smtState.Model || k.smtState.ModelOnFinalCheck {
		return true
	}
	manager := k.internalizer.quantifierManager
	return manager != nil && manager.mbqi
}

func (k *SMTKernel) buildGeneratedModel() error {
	var generator *SMTModelGenerator
	if manager := k.internalizer.quantifierManager; manager != nil {
		generator = manager.acceptedModel
		manager.acceptedModel = nil
	}
	// mk_proto_model runs when m_fparams.m_model (default true),
	// m_model_on_final_check or m_qmanager->model_based() (smt.mbqi) holds;
	// smt_solver ignores set_produce_models.
	if !k.mkProtoModelEnabled() {
		var err error
		if manager := k.internalizer.quantifierManager; manager != nil {
			err = manager.releaseRetiredProto()
		}
		if generator != nil {
			err = errors.Join(err, generator.Close())
		}
		return err
	}
	var err error
	if generator == nil {
		generator, err = k.buildCandidateModelGenerator()
		if err != nil {
			return err
		}
	}
	generated, err := k.finalizeGeneratedModel(generator)
	if err != nil {
		return err
	}
	if err = k.releaseStaleModel(); err != nil {
		return errors.Join(err, generated.Core().DecRef())
	}
	k.generated = generated
	// ~scoped_mk_model: m_proto_model = nullptr once m_model exists;
	// ~proto_model deletes its value factories (their m_trail) first.
	if err = k.releaseProtoTrail(); err != nil {
		return err
	}
	if manager := k.internalizer.quantifierManager; manager != nil {
		return manager.releaseRetiredProto()
	}
	return nil
}

// publishQuantifierCandidate is the end of a search that check_model gave
// up on: the candidate MBQI rejected is m_proto_model; without MBQI the
// proto model mk_proto_model(l_true) built before check_model is made now.
func (k *SMTKernel) publishQuantifierCandidate() error {
	if manager := k.internalizer.quantifierManager; manager != nil && manager.retiredProto != nil {
		return k.publishRetiredCandidate()
	}
	return k.buildGeneratedModel()
}

// publishRetiredCandidate is ~scoped_mk_model on an m_proto_model that MBQI
// rejected: m_model = m_proto_model->mk_model(), add_rec_funs_to_model().
func (k *SMTKernel) publishRetiredCandidate() error {
	manager := k.internalizer.quantifierManager
	if manager == nil || manager.retiredProto == nil {
		return nil
	}
	if !k.mkProtoModelEnabled() {
		return manager.releaseRetiredProto()
	}
	proto := manager.retiredProto
	manager.retiredProto = nil
	generated, err := proto.FinalModel()
	if err != nil {
		return errors.Join(err, proto.Close())
	}
	if err = k.addRecursiveFunctionsToModel(generated.Core()); err != nil {
		return errors.Join(err, generated.Close())
	}
	if err = generated.Core().IncRef(); err != nil {
		return errors.Join(err, generated.Close())
	}
	if err = k.releaseStaleModel(); err != nil {
		return errors.Join(err, generated.Core().DecRef())
	}
	k.generated = generated
	// ~proto_model deletes its value factories (their m_trail).
	return k.releaseProtoTrail()
}

// retireGeneratedModel starts a check: the previous model stops being the
// result but stays alive, as the source keeps m_model until it is replaced.
func (k *SMTKernel) retireGeneratedModel() error {
	if k == nil || k.generated == nil {
		return nil
	}
	if err := k.releaseStaleModel(); err != nil {
		return err
	}
	k.staleModel, k.generated = k.generated, nil
	return nil
}

// closeQuantifierCosts is ~qi_queue's release of the cost function.
func (k *SMTKernel) closeQuantifierCosts() error {
	if k.quantifierCosts == nil {
		return nil
	}
	if err := k.quantifierCosts.Close(); err != nil {
		return err
	}
	k.quantifierCosts = nil
	return nil
}

// releaseContextModels is the destruction of m_model, then m_proto_model
// (with its value factories' trails).
func (k *SMTKernel) releaseContextModels() error {
	if err := k.clearGeneratedModel(); err != nil {
		return err
	}
	if err := k.releaseStaleModel(); err != nil {
		return err
	}
	if err := k.releaseUpdateProto(); err != nil {
		return err
	}
	return k.releaseProtoTrail()
}

func (k *SMTKernel) releaseProtoTrail() error {
	for i := range k.protoTrail {
		if err := k.manager.DelRef(&k.protoTrail[i]); err != nil {
			k.protoTrail = k.protoTrail[i:]
			return err
		}
	}
	k.protoTrail = nil
	return nil
}

// releaseGeneratorPins is model_generator::reset's m_asts.reset().
func (k *SMTKernel) releaseGeneratorPins() error {
	for i := range k.generatorPins {
		if err := k.manager.DelRef(&k.generatorPins[i]); err != nil {
			k.generatorPins = k.generatorPins[i:]
			return err
		}
	}
	k.generatorPins = nil
	return nil
}

func (k *SMTKernel) releaseStaleModel() error {
	if k == nil || k.staleModel == nil {
		return nil
	}
	consumed, err := k.staleModel.Core().DecRefConsumed()
	if consumed {
		k.staleModel = nil
	}
	return err
}

// finalizeGeneratedModel consumes the generator and returns one model
// reference for the kernel, without changing the currently published model.
// releaseUpdateProto drops the proto model update_model kept.
func (k *SMTKernel) releaseUpdateProto() error {
	if k.updateProto == nil {
		return nil
	}
	proto := k.updateProto
	k.updateProto = nil
	return proto.Close()
}

func (k *SMTKernel) finalizeGeneratedModel(generator *SMTModelGenerator) (*model.Model, error) {
	return k.finalizeGeneratedModelKeep(generator, false)
}

// finalizeGeneratedModelKeep is finalizeGeneratedModel; with keep, the
// proto model stays m_proto_model (context::update_model).
func (k *SMTKernel) finalizeGeneratedModelKeep(generator *SMTModelGenerator, keep bool) (*model.Model, error) {
	fail := func(cause error) (*model.Model, error) { return nil, errors.Join(cause, generator.Close()) }
	var generated *model.Model
	var err error
	if keep {
		var proto *protomodel.ProtoModel
		generated, proto, err = generator.FinalModelRetained()
		if err != nil {
			return fail(err)
		}
		if err = k.releaseUpdateProto(); err != nil {
			return nil, errors.Join(err, proto.Close(), generated.Close(), generator.Close())
		}
		k.updateProto = proto
	} else {
		generated, err = generator.FinalModel()
	}
	if err != nil {
		return fail(err)
	}
	if err = k.addRecursiveFunctionsToModel(generated.Core()); err != nil {
		return nil, errors.Join(err, generated.Close(), generator.Close())
	}
	if err = generator.Close(); err != nil {
		return nil, errors.Join(err, generated.Close())
	}
	if err = generated.Core().IncRef(); err != nil {
		return nil, errors.Join(err, generated.Close())
	}
	return generated, nil
}

func (k *SMTKernel) clearGeneratedModel() error {
	if k == nil || k.generated == nil {
		return nil
	}
	consumed, err := k.generated.Core().DecRefConsumed()
	if consumed {
		k.generated = nil
	}
	return err
}

func (k *SMTKernel) GeneratedModel() *model.ModelCore {
	if k == nil || k.generated == nil {
		return nil
	}
	return k.generated.Core()
}

func (k *SMTKernel) LastFailure() (SMTFailure, error) {
	if err := k.open(); err != nil {
		return SMTFailureUnknown, err
	}
	return k.lastFailure, nil
}

func (k *SMTKernel) ReasonUnknown() (string, error) {
	if err := k.open(); err != nil {
		return "", err
	}
	switch k.lastFailure {
	case SMTFailureOK, SMTFailureUnknown:
		return k.unknown, nil
	case SMTFailureTimeout:
		return "timeout", nil
	case SMTFailureMemory:
		return "memout", nil
	case SMTFailureCanceled:
		return "canceled", nil
	case SMTFailureConflictLimit:
		return "max-conflicts-reached", nil
	case SMTFailureTheory:
		var reason strings.Builder
		reason.WriteString("(incomplete (theory")
		for _, theory := range k.internalizer.IncompleteTheories() {
			if named, ok := theory.(interface{ Name() string }); ok {
				if name := named.Name(); name != "" {
					reason.WriteByte(' ')
					reason.WriteString(name)
				}
			}
		}
		reason.WriteString("))")
		return reason.String(), nil
	case SMTFailureResourceLimit:
		return "(resource limits reached)", nil
	case SMTFailureQuantifiers:
		return "(incomplete quantifiers)", nil
	default:
		return "", ast.ErrASTDomain
	}
}

func (k *SMTKernel) SetReasonUnknown(message string) error {
	if err := k.open(); err != nil {
		return err
	}
	k.unknown = message
	return nil
}

func (k *SMTKernel) captureRelevantLabels() error {
	k.labels = nil
	for variable := int32(SMTFirstBoolVar); int(variable) < len(k.internalizer.boolExpr); variable++ {
		expression := k.internalizer.boolExpr[variable]
		if !k.relevancy.IsRelevant(expression) {
			continue
		}
		value, err := k.internalizer.Assignment(NewSMTLiteral(variable, false))
		if err != nil {
			return err
		}
		if value != lbool.True {
			continue
		}
		var names []usymbol.Symbol
		label, err := k.manager.IsLabelLit(expression, &names)
		if err != nil {
			return err
		}
		if label {
			k.labels = append(k.labels, names...)
		}
	}
	return nil
}

func (k *SMTKernel) Labels() ([]usymbol.Symbol, error) {
	if err := k.open(); err != nil {
		return nil, err
	}
	return append([]usymbol.Symbol(nil), k.labels...), nil
}

func (k *SMTKernel) SetProgressCallback(callback solver.ProgressCallback) error {
	if err := k.open(); err != nil {
		return err
	}
	k.callback = callback
	return nil
}

// Proof returns the retained proof established by assertion internalization or
// search. It is null when proof generation is disabled or no unsatisfiable
// result has been retained since the most recent result reset.
func (k *SMTKernel) Proof() (ast.ASTHandle, error) {
	if err := k.open(); err != nil {
		return ast.ASTHandle{}, err
	}
	return k.manager.RefGet(k.unsatProof)
}

func (k *SMTKernel) Inconsistent() bool {
	return k != nil && k.internalizer != nil && k.internalizer.Inconsistent()
}

func (k *SMTKernel) Statistics() SMTContextStatistics {
	if k == nil || k.internalizer == nil {
		return SMTContextStatistics{}
	}
	return k.internalizer.Statistics()
}

// ResetStatistics clears the cumulative counters retained by the kernel.
func (k *SMTKernel) ResetStatistics() error {
	// Source smt_kernel.cpp imp::reset_statistics intentionally has no
	// body. Tactics clear their separately stored statistics themselves.
	return k.open()
}

// Canceled performs the same resource-limit check used by the source context.
// The check accounts for one resource step before reporting the cancel state.
func (k *SMTKernel) Canceled() (bool, error) {
	if err := k.open(); err != nil {
		return false, err
	}
	return k.manager.Canceled()
}

// Display renders the retained asserted formulas as kernel::imp::display
// does, each with mk_ismt2_pp(f, m, 2): the indent applies after line
// breaks, and the format_ref releases each document after printing.
func (k *SMTKernel) Display(out io.Writer) error {
	if err := k.open(); err != nil {
		return err
	}
	if out == nil {
		return ast.ErrASTHandle
	}
	if _, err := io.WriteString(out, "(kernel"); err != nil {
		return err
	}
	for _, assertion := range k.assertions {
		if _, err := io.WriteString(out, "\n  "); err != nil {
			return err
		}
		if err := k.displayIndentedAssertion(out, assertion.Formula); err != nil {
			return err
		}
	}
	_, err := io.WriteString(out, ")")
	return err
}

func (k *SMTKernel) displayIndentedAssertion(out io.Writer, formula ast.ASTHandle) (err error) {
	f, err := k.manager.SMT2PPExprTree(formula, nil)
	if err != nil {
		return err
	}
	formats, err := k.manager.GetFormatManager()
	if err != nil {
		return err
	}
	ref, err := formats.NewRef(f)
	if err != nil {
		return err
	}
	defer func() { err = errors.Join(err, formats.DelRef(&ref)) }()
	if f, err = k.manager.FormatIndent(2, f); err != nil {
		return err
	}
	if err = formats.SetRef(ref, f); err != nil {
		return err
	}
	stream, err := utext.NewNumericTextStream(utext.NumericTextStreamConfig{Budget: k.manager.Budget()})
	if err != nil {
		return err
	}
	defer func() { err = errors.Join(err, stream.Close()) }()
	if err = k.manager.PrintFormat(stream, f, nil, nil, nil); err != nil {
		return err
	}
	text, err := stream.String()
	if err != nil {
		return err
	}
	_, err = io.WriteString(out, text)
	return err
}

func (k *SMTKernel) Close() error {
	if k == nil {
		return ast.ErrASTHandle
	}
	if k.closed {
		return nil
	}
	if k.manager == nil {
		return ast.ErrASTHandle
	}
	k.closing = true
	// Source destruction has no failing release. The Go owners can refuse;
	// leave later dependencies live and remember every completed child.
	if err := k.clearLiteralResults(); err != nil {
		return err
	}
	// context::flush begins with m_relevancy_propagator = nullptr, then
	// m_model_generator->reset() (m_asts).
	if err := k.relevancy.release(); err != nil {
		return err
	}
	if err := k.releaseGeneratorPins(); err != nil {
		return err
	}
	if err := k.clearUnsatCore(); err != nil {
		return err
	}
	// ~context runs flush() (undo_trail_stack(0) releases the enodes and
	// Boolean variables) before the members die in reverse declaration
	// order: m_unsat_proof and m_conflict_resolution go first, long before
	// the theories, the model generator and the asserted formulas.
	releaseConflictState := func() error {
		// m_model and m_proto_model are declared after m_unsat_proof and
		// m_conflict_resolution, so they are destroyed first.
		if err := k.releaseContextModels(); err != nil {
			return err
		}
		if k.unsatProof != (ast.ASTRef{}) {
			if err := k.manager.DelRef(&k.unsatProof); err != nil {
				return err
			}
		}
		if k.conflictResolver != nil {
			if err := k.conflictResolver.Close(); err != nil {
				return err
			}
			k.conflictResolver = nil
		}
		return nil
	}
	if k.pendingSetupLRA != nil {
		if err := k.pendingSetupLRA.Close(); err != nil {
			return err
		}
		k.pendingSetupLRA = nil
	}
	if k.internalizer != nil {
		previous := k.internalizer.afterFlush
		k.internalizer.afterFlush = func() error {
			if err := releaseConflictState(); err != nil {
				return err
			}
			if previous != nil {
				return previous()
			}
			return nil
		}
		if err := k.internalizer.Close(); err != nil {
			return err
		}
		k.internalizer = nil
	}
	if err := releaseConflictState(); err != nil {
		return err
	}
	if err := k.releaseContextModels(); err != nil {
		return err
	}
	// The internalizer (context::flush) is closed above, before the
	// asserted formulas' theory rewriter it borrows.
	// ~asserted_formulas destroys its simplify_fmls members (declared last)
	// in reverse order before the macro manager: m_apply_bit2int is
	// declared after m_pattern_inference, so it dies first.
	// m_ng_lift_ite and m_lift_ite are declared after m_apply_bit2int;
	// m_cheap_quant_fourier_motzkin and m_pull_nested_quantifiers before it.
	if k.assertedNGLiftITE != nil {
		if err := k.assertedNGLiftITE.Close(); err != nil {
			return err
		}
		k.assertedNGLiftITE = nil
	}
	if k.assertedLiftITE != nil {
		if err := k.assertedLiftITE.Close(); err != nil {
			return err
		}
		k.assertedLiftITE = nil
	}
	if k.assertedBit2Int != nil {
		if err := k.assertedBit2Int.Close(); err != nil {
			return err
		}
		k.assertedBit2Int = nil
	}
	if k.assertedElimBounds != nil {
		if err := k.assertedElimBounds.Close(); err != nil {
			return err
		}
		k.assertedElimBounds = nil
	}
	if k.assertedPullNested != nil {
		if err := k.assertedPullNested.Close(); err != nil {
			return err
		}
		k.assertedPullNested = nil
	}
	if k.patternInference != nil {
		if err := k.patternInference.Close(); err != nil {
			return err
		}
		k.patternInference = nil
	}
	// m_bv_sharing is declared after the macro finder and before the
	// simplify_fmls members, so it dies between them.
	if k.bvSharing != nil {
		if err := k.bvSharing.Close(); err != nil {
			return err
		}
		k.bvSharing = nil
	}
	if k.assertedMacros != nil {
		if err := k.assertedMacros.Close(); err != nil {
			return err
		}
		k.assertedMacros = nil
	}
	// ~asserted_formulas destroys its members in reverse order: the macro
	// manager, m_formulas, m_defined_names, m_scoped_substitution,
	// m_substitution and finally m_rewriter.
	if err := k.restoreAssertions(0); err != nil {
		return err
	}
	if k.definedNames != nil {
		if err := k.definedNames.Close(); err != nil {
			return err
		}
		k.definedNames = nil
	}
	if k.assertedScopedSubst != (ast.ASTScopedExprSubstitution{}) {
		if err := k.manager.DelScopedExprSubstitution(&k.assertedScopedSubst); err != nil {
			return err
		}
	}
	if k.assertedSubstitution != (ast.ASTExprSubstitution{}) {
		if err := k.manager.DelExprSubstitution(&k.assertedSubstitution); err != nil {
			return err
		}
	}
	if k.preprocessor != nil {
		if err := k.preprocessor.Close(); err != nil {
			return err
		}
		k.preprocessor = nil
	}
	if k.quantifierCosts != nil {
		if err := k.quantifierCosts.Close(); err != nil {
			return err
		}
		k.quantifierCosts = nil
	}
	if k.modelCooperation != nil {
		if err := k.modelCooperation.Close(); err != nil {
			return err
		}
		k.modelCooperation = nil
	}
	if k.smtParams != nil && !k.smtParamsBorrowed {
		if err := k.smtParams.Close(); err != nil {
			return err
		}
		k.smtParams = nil
	}
	if k.assertedParamsReady {
		if err := k.paramContext.Del(&k.assertedParams); err != nil {
			return err
		}
		k.assertedParamsReady = false
	}
	if err := k.restoreAssertions(0); err != nil {
		return err
	}
	k.assertions = nil
	k.scopes = nil
	k.pendingPop = nil
	k.assertedScopeConflicts = nil
	k.assertedInconsistent = false
	k.caseSplitQueue = nil
	k.queueWarnings = nil
	k.booleanSetupSeeded = false
	k.internalizer = nil
	k.checker = nil
	k.relevancy = nil
	k.paramContext = nil
	k.paramGlobals = nil
	k.smtParams = nil
	k.smtParamsBorrowed = false
	k.smtState = SMTParamsState{}
	k.preprocessState = SMTPreprocessorState{}
	k.quantifierCosts = nil
	k.modelCooperation = nil
	k.manager = nil
	k.closed = true
	return nil
}

// contextResolver is the context's conflict_resolution, created on first use.
func (k *SMTKernel) contextResolver() (*SMTConflictResolver, error) {
	if k.conflictResolver == nil {
		resolver, err := NewSMTConflictResolver(k.internalizer)
		if err != nil {
			return nil, err
		}
		k.conflictResolver = resolver
	}
	return k.conflictResolver, nil
}

// setContextRelevancy installs the context's relevancy level: relevancy()
// and the internalizer read it, not the shared parameter.
func (k *SMTKernel) setContextRelevancy(level uint32) {
	k.contextRelevancyLvl = level
	k.relevancy.enabled = level > 0
	k.internalizer.relevancyLevel = level
}

// setupContextRelevancy is setup_context's relevancy step (fork backport of
// upstream z3 5dfe4a4b4). The first setup takes the configured level; every
// later setup lowers it to min(parameter, context level). Raising
// smt.relevancy afterwards therefore cannot leave assertions that were
// internalized without relevancy unmarked (which made z3 4.7.1 report
// models violating them, e.g. test_vectors/relevancy_update_scopes.smt2).
func (k *SMTKernel) setupContextRelevancy() {
	level := k.smtState.RelevancyLvl
	if !k.relevancyConfigured || level < k.contextRelevancyLvl {
		k.setContextRelevancy(level)
	}
	k.relevancyConfigured = true
}
