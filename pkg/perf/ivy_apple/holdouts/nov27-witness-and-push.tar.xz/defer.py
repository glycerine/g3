from pathlib import Path
import subprocess as sp,json
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
path=p/'smtcore/smt_asserted_formulas.go';s=path.read_text().replace('import (','import ("os";',1);k='proofRef, err := k.manager.NewRef(ast.ASTHandle{})';i=s.index(k,s.index('func (k *SMTKernel) preprocessAssertExpr('))
s=s[:i]+'''if deferTrial!="" && k.simplifyInitialPushOnce && len(k.scopes)==0 && k.assertedHead==0 && hasPendingTrialShape(k,formula) && proof.IsNull() && !k.preprocessor.ProofGen(){
 if e:=k.manager.IncRef(formula);e!=nil{return ast.ASTHandle{},ast.ASTHandle{},e};return formula,proof,nil}
 '''+s[i:]+'''
var deferTrial=os.Getenv("SHARED_BIND")
func hasPendingTrialShape(k *SMTKernel,f ast.ASTHandle)bool{
 h,e:=k.manager.NodeHeader(f);if e!=nil || h.Family!=k.manager.BasicFamilyID() || h.DeclKind!=ast.ASTOpAnd{return false}
 if deferTrial=="all"{return true};if deferTrial=="flat"{return h.NumArgs>=8}
 if deferTrial=="nested"{if h.NumArgs!=2{return false};a,_:=k.manager.GetArg(f,0);h,_=k.manager.NodeHeader(a);return h.Family==k.manager.BasicFamilyID() && h.DeclKind==ast.ASTOpAnd}
 return false
}
'''
dst=w/'defer-formulas.go';dst.write_text(s);ov['Replace'][str(path)]=str(dst);j=w/'defer.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'defer','./cmd/goivy_check'],cwd=front,check=True)
