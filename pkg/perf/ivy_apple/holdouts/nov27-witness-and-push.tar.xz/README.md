# POPL18 witness matching and first-push cost

Measurements use g3 4ec97665f on linux/amd64 and this fork's native Z3. Run the following from pkg, substituting the unpacked directory for $study. The three SMT inputs are standalone and also work with either shell directly.

    go build -o "$study/g3" ./cmd/g3
    PERF=perf PERF_CPU=0 python3 "$study/price.py"
    python3 "$study/summarize.py"

Choose an available CPU. The timing script uses ../build/z3. prices.csv includes parsing and process startup. live.csv separately measures only the Check call, including construction and submission of experimental hints. summarize.py reports millions of retired userspace instructions. It sums per-batch events within each run before taking medians across runs.

The remaining drivers are the exact experiment sources for the local GoIvy study layout. They reference earlier scratch paths for the frontend, PGO overlays, examples, native reference transcripts and instrumentation. They require those fixtures to rebuild. The expanded Go source overlays are included for inspection. passes.py uses arm-pass-run.py (originally /tmp/g3-arm-pass/run.py). The prefixes in compat.txt identify the case numbers (one-based line numbers). Run histories include intentionally failing verification cases and compare stderr, stdout and exit code. base.smt2 is the submitted 7/1 query. exists.smt2 contains two ordinary universal instances. fresh.smt2 replaces their existential conclusions with fresh constants for this experiment. The modes are process-local experimental overlays.

The g3 and native TOTAL rows of passes.csv have different boundaries. Compare named passes across engines. boundary.csv splits the whole first physical Push of each batch in g3. Partial last propagation segments are charged to the next meter boundary. Process-level panel runs use normal GC and interleaved policy order. Phase experiments use GOGC=off. Source names in *.json are local machine paths.

quant.csv subdivides boundary.csv's quantifier interval. "match" includes MAM matching, "notify" is delivery of enode notifications, and "quantifier" is the remaining scheduling and instantiation. detail.csv further separates this last interval. "check-candidate" includes the context-based satisfiability check, "after-substitution" includes substitution through entry to materialization, "rewrite-finish" includes rewriting and building the lemma, and "assert-lemma" includes internalization of nontrivial lemmas. "queue-overhead" includes cleanup of the previous entry up to the next candidate check. Counts include the small meter overhead on paths with many calls. Treat these as separate runs and avoid adding corresponding intervals from different builds.
