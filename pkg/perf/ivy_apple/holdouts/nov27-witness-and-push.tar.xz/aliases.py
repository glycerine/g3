from pathlib import Path
import subprocess as sp,json
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
path=p/'api/internal/order/ground_instance_pool.go';s=path.read_text().replace('import (','import ("os";',1);k='if err := p.loadFacts();';s=s.replace(k,'if p.guardedCases && aliasTrial!="" && !p.loaded{if e:=p.trialAliases();e!=nil{return nil,e}};'+k)
s=s.replace('if p.guardedCases || len(by[st]) < 3 {','if p.guardedCases && aliasTrial!="" && slices.Contains(by[st],id){continue};if p.guardedCases || len(by[st]) < 3 {')
dst=w/'alias-pool.go';dst.write_text(s+'\nvar aliasTrial=os.Getenv("SHARED_BIND")\n'+(w/'aliases.go.txt').read_text());ov['Replace'][str(path)]=str(dst);j=w/'aliases.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'aliases','./cmd/goivy_check'],cwd=front,check=True)
