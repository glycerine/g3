from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd()
s=(w/'live.py').read_text().split('rank=Path')[0]
s=s.replace("'/tmp/g3-arith-next/final/arith-stage.json'","'/tmp/g3-ticket-first/validation/final.json'")
s=s.replace("to=w/(path.name+'.txt')","to=w/('general-'+path.name+'.txt')")
s=s.replace("(w/'live-hints.go.txt').read_text()","(w/'general-hints.go.txt').read_text()")
a=s.index("k='stopCheck");b=s.index("patch(path,s+",a);s=s[:a]+'''k='res, err := s.decideZ3With(z3solver, finalCheck)';assert s.count(k)==1
s=s.replace(k,'if s.opts.Incremental && hintMode!="" && index==0 && (hintMode!="single" || len(finalCond)==1){n:=z3solver.TrialHints(hintMode);if hintMode=="log" && n>0{println("WITNESS-HINT",n)}};'+k);'''+s[b:]
s=s.replace('os.Getenv("HINT_MODE")','os.Getenv("SHARED_BIND")').replace("w/'live.json'","w/'general.json'").replace("w/'live'","w/'general'")
h=(w/'live-hints.go.txt').read_text();k=' type signed struct';h=h.replace(k,''' if len(forms)<2{return 0};remaining:=5;goal,_,ok:=(signedRefutationGoal{term:forms[len(forms)-1]}).unwrap(m,&remaining);if !ok || !(goal.negated && m.IsFalse(goal.term) || !goal.negated && m.IsTrue(goal.term)){return 0}
'''+k)
k=' seen:=map[ast.ASTHandle]bool{}';h=h.replace(k,' candidates:=[]ast.ASTHandle{};var pos,neg bool;'+k).replace('seen[v]=true\n inst:=','seen[v]=true;candidates=append(candidates,v);if key.neg{neg=true}else{pos=true}\n }}};if (mode=="paired" || mode=="single") && !(pos && neg && len(candidates)>=2){continue};for _,v:=range candidates{\n inst:=').replace(' }}}}\n return count',' }}\n return count');(w/'general-hints.go.txt').write_text(h)
exec(s)
