from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-arm-pass/run.py').read_text().replace('for nr in [4,2]:','for nr in [6,3,12,10]:')
s=s.replace('capture_output=True,check=True);keep=[]', "capture_output=True);assert r.returncode==int(next(row['exit'] for row in csv.DictReader((ref/'ranking.csv').open()) if row['case']==name));keep=[]")
exec(s)
