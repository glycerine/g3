from pathlib import Path
import json,csv,subprocess as sp,os
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
def put(path,s):
 dest=w/('quant-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
s=Path('/tmp/g3-first-push-frontier/measure-first_push_meter.go').read_text().replace('package smtcore','package control',1)
a=s.index('func studyScope()');s=s[:a]+s[a:].replace('func studyScope() func()','func StudyOpen()',1)
a=s.index('start:=studyreadCounter()');s=s[:a]+'''studyLast=studyreadCounter();studyTicks=make(map[string]uint64)
}
var studyLast uint64
var studyTicks map[string]uint64
func StudyStep(name string){if !studyactive{return};now:=studyreadCounter();studyTicks[name]+=now-studyLast;studyLast=studyreadCounter()}
func StudyClose(b,g int){StudyStep("finish");studyactive=false;syscall.Close(int(studyfd));runtime.UnlockOSThread();for name,n:=range studyTicks{fmt.Fprintln(os.Stderr,"PUSH-COST",b,g,name,n)}}
'''
put(p/'util/control/first_push_study.go',s+'\nvar StudyProp bool\nfunc StudyPhase(name string){if StudyProp{StudyStep(name)}}\n')
path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/util/control";',1).replace('s.showVCsBase(clauses)','s.showVCsBase(clauses);studyBatch++;firstPush:=true',1)
i=s.index('func (s *Solver) GetSmallModelWithCond(');pre,s=s[:i],s[i:];k='z3solver.Push()';assert s.count(k)>=1;s=pre+s.replace(k,'if firstPush{control.StudyOpen()};'+k+';if firstPush{control.StudyClose(studyBatch,index+1);firstPush=false}',1)
put(path,s+'\nvar studyBatch int\n')
path=p/'solver/combined_solver.go';s=path.read_text();i=s.index('func (c *CombinedSolver) Push()');h,t=s[:i],s[i:];t=t.replace('if err := c.switchIncremental();','control.StudyStep("caller");if err := c.switchIncremental();',1).replace('if err := c.first.Push();','control.StudyStep("switch");if err := c.first.Push();',1).replace('return c.mutationResult(c.second.Push())','control.StudyStep("first-child");return c.mutationResult(c.second.Push())',1);put(path,h+t)
path=p/'smtcore/smt_kernel.go';s=path.read_text().replace('import (','import ("github.com/glycerine/g3/pkg/util/control";',1);k='formula, proof, err = k.preprocessAssertExpr';s=s.replace(k,'control.StudyStep("before-assert-rewrite");'+k);k='if k.preprocess && k.preprocessor != nil {\n\t\t// The preprocessing call';s=s.replace(k,'control.StudyStep("assert-rewrite");'+k);k='if err = k.pushAssertion(formula, proof);';s=s.replace(k,'defer control.StudyStep("record-assertion");'+k)
i=s.index('func (k *SMTKernel) Push()');h,t=s[:i],s[i:];t=t.replace('if err := k.open();','control.StudyStep("second-child");if err := k.open();',1).replace('wasConsistent :=','control.StudyStep("configure-kernel");wasConsistent :=',1).replace('if _, err := k.internalizer.PropagateCore();','control.StudyStep("internalize-pending");control.StudyProp=true;if _, err := k.internalizer.PropagateCore();',1).replace('if wasConsistent &&','control.StudyProp=false;control.StudyStep("propagate");if wasConsistent &&',1)
put(path,h+t)
path=p/'smtcore/smt_theory_propagation.go';s=path.read_text()
if '"github.com/glycerine/g3/pkg/util/control"' not in s:s=s.replace('import (','import ("github.com/glycerine/g3/pkg/util/control";',1)
i=s.index('func (s *SMTInternalizerState) PropagateCore()');h,t=s[:i],s[i:]
for k,label in [('s.relevancyBatch = smtRelevancyAssignmentBatch{head:', 'boolean'),('s.relevancyBatch.end =','case-splits'),('if err = s.propagateTheoryRelevancy()', 'assign-relevance'),('s.relevancyBatch = smtRelevancyAssignmentBatch{}\n\t\tif s.inconsistent', 'theory-relevance'),('if s.inconsistent { // if (!propagate_atoms())','theory-assign'),('// propagate_th_eqs();','theory-events'),('// m_qmanager->propagate()', 'theory-plugins'),('// if (resource_limits_exceeded())','quantifier')]:
 assert k in t,k
 t=t.replace(k,'control.StudyPhase("'+label+'");'+k,1)
put(path,h+t)
path=p/'smtcore/smt_quantifier_manager.go';s=path.read_text()
if '"github.com/glycerine/g3/pkg/util/control"' not in s:s=s.replace('import (','import ("github.com/glycerine/g3/pkg/util/control";',1)
i=s.index('func (q *SMTQuantifierManager) Propagate()');h,t=s[:i],s[i:]
t=t.replace('q.notifyNewEnodes()', 'control.StudyPhase("match");q.notifyNewEnodes();control.StudyPhase("notify")',1)
put(path,h+t)
j=w/'quant.json';j.write_text(json.dumps(ov));sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'quant','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
with (w/'quant.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case round batch goal operation instructions'.split())
 for nr in (3,6,2,12,10):
  case=cases[nr-1];ref=rank/'compat'/str(nr)/'1/native'
  for i in range(3):
   r=sp.run(['taskset','-c','29',w/'quant',ex/case],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=40);rest=bytearray()
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'PUSH-COST '):out.writerow([nr,i,*line.decode().split()[1:]])
    else:rest.extend(line)
   assert (r.returncode,r.stdout,rest)==(int(next(row['exit'] for row in csv.DictReader((rank/'ranking.csv').open()) if row['case']==case)),(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),rest[-1000:];f.flush()
