package control

import (
	"fmt"
	"os"
	"runtime"
	"syscall"
	"unsafe"
)

var studyfd uintptr
var studyempty, studycalls, studyinstructions, studydepth uint64

func studyreadCounter() uint64 {
	var values [3]uint64
	n, _, err := syscall.RawSyscall(syscall.SYS_READ, studyfd, uintptr(unsafe.Pointer(&values[0])), unsafe.Sizeof(values))
	if err != 0 || n != unsafe.Sizeof(values) || values[1] != values[2] {
		panic("incomplete replay instruction counter")
	}
	return values[0]
}

var studyordinal int
var studyactive bool

// studyScope measures one external GoIvy Push on its solver thread.
func StudyOpen() {
	runtime.LockOSThread()
	var attr struct {
		Type, Size                                    uint32
		Config, Period, SampleType, ReadFormat, Flags uint64
		Padding                                       [16]byte
	}
	attr.Size = uint32(unsafe.Sizeof(attr))
	attr.Config = 1          // PERF_COUNT_HW_INSTRUCTIONS
	attr.Flags = 1<<5 | 1<<6 // exclude kernel and hypervisor
	attr.ReadFormat = 3
	var err syscall.Errno
	studyfd, _, err = syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN, uintptr(unsafe.Pointer(&attr)), 0, ^uintptr(0), ^uintptr(0), 0, 0)
	if err != 0 {
		panic(err)
	}
	studycalls, studyinstructions, studydepth = 0, 0, 0
	studyordinal++
	studyactive = true
	lo := studyreadCounter()
	studyempty = studyreadCounter() - lo
	studyLast=studyreadCounter();studyTicks=make(map[string]uint64)
}
var studyLast uint64
var studyTicks map[string]uint64
func StudyStep(name string){if !studyactive{return};now:=studyreadCounter();studyTicks[name]+=now-studyLast;studyLast=studyreadCounter()}
func StudyClose(b,g int){StudyStep("finish");studyactive=false;syscall.Close(int(studyfd));runtime.UnlockOSThread();for name,n:=range studyTicks{fmt.Fprintln(os.Stderr,"PUSH-COST",b,g,name,n)}}

var StudyProp bool
func StudyPhase(name string){if StudyProp{StudyStep(name)}}
