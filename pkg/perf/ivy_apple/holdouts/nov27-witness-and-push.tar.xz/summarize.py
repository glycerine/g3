"""Summarize saved instruction counts. Run from any directory."""
from pathlib import Path
from collections import defaultdict
from statistics import median
import csv
root = Path(__file__).resolve().parent
for stem, dims, metric in [
    ('live', ['mode'], 'check_instructions'),
    ('panel', ['case','policy'], 'instructions'),
    ('aliases', ['case','policy'], 'instructions'),
    ('defer', ['case','policy'], 'instructions'),
    ('boundary', ['case','operation'], 'instructions'),
    ('quant', ['case','operation'], 'instructions'),
    ('detail', ['case','operation'], 'instructions'),
    ('passes', ['case','engine','pass'], 'instructions'),
]:
    groups = defaultdict(lambda: defaultdict(int))
    for row in csv.DictReader((root / (stem+'.csv')).open()):
        if 'status' in row:
            assert row['status']=='match', row
        groups[tuple(row[d] for d in dims)][row['round']] += int(row[metric])
    for group, totals in groups.items():
        print(stem, *group, len(totals), round(median(totals.values())/1e6, 2))
