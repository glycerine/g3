"""Measure the constructor, cache read and result publication on matched instances."""
from pathlib import Path
import sys,subprocess,json,shlex,re,shutil
w=Path(__file__).resolve().parent
base,mod=map(lambda x:Path(x).resolve(),sys.argv[2:4])
label=sys.argv[1]
p=Path.cwd()
files=json.loads((base/(label+'.json')).read_text())['Replace']
front=Path(next(k for k in files if k.endswith('/phase_observer_trial.go'))).parent
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b,1)
def overlay(k,s):
    f=w/k.name;f.write_text(s);files[str(k)]=str(f)
if label=='ordinary':
    k=p/'ast/ast_rewriter_access.go'
    s=k.read_text().replace('package ast','''package ast
import ("syscall";"unsafe";"fmt";"os")
var PriceFD int = -1
var PriceMake, PriceVisit bool
var PriceRows [8]int64
var PriceMade map[ASTHandle][2]int64
func PriceRead() int64 {
 var c [3]uint64
 n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(PriceFD),uintptr(unsafe.Pointer(&c)),24)
 if e!=0 || n!=24 || c[1]!=c[2] {panic("perf read")}
 return int64(c[0])
}
func PriceStart(fd int){PriceFD=fd;PriceMake=fd>=0;PriceRows=[8]int64{};if PriceMake{PriceMade=make(map[ASTHandle][2]int64)}}
func PriceEnd(){if PriceVisit{fmt.Fprintln(os.Stderr,"PRICE",PriceRows)};PriceVisit=false;PriceFD=-1}
''')
    ksig='func (m *ASTManager) RewriterMakeApp(d ASTHandle, args AppArguments) (ASTHandle, error) {'
    s=rep(s,ksig,ksig+'''
 if !PriceMake {return m.priceMakeApp(d,args)}
 a:=PriceRead();b:=PriceRead();h,e:=m.priceMakeApp(d,args);c:=PriceRead()
 n:=c-2*b+a
 pair:=PriceMade[h];pair[0]++;pair[1]+=n;PriceMade[h]=pair
 PriceRows[0]++;PriceRows[1]+=n
 return h,e
}
func (m *ASTManager) priceMakeApp(d ASTHandle,args AppArguments)(ASTHandle,error){''')
    overlay(k,s)
    k=p/'smtcore/smt_qi_instance.go';s=k.read_text().replace('"strconv"','"strconv"\n"os"')
    key='if _, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance); err != nil {'
    s=rep(s,key,'''fd,eFD:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));if eFD!=nil {fd=-1};ast.PriceStart(fd)
 _, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance);ast.PriceMake=false
 if err!=nil {''')
    key='if err = rw.Rewrite(instance, simplified); err != nil {'
    s=rep(s,key,'''ast.PriceVisit=ast.PriceFD>=0;err=rw.Rewrite(instance,simplified);ast.PriceEnd();if err!=nil {''')
    overlay(k,s)
    k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text()
    s=rep(s,'h, e := c.getCached(t)','''var a,b,cost int64
        if ast.PriceVisit {a=ast.PriceRead();b=ast.PriceRead()}
        h, e := c.getCached(t)
        if ast.PriceVisit {cost=ast.PriceRead()-2*b+a}''')
    s=rep(s,'if !h.IsNull() {\n\t\t\tif e = r.sameSort','''if !h.IsNull() {
            measured:=ast.PriceVisit && t!=h
            if measured { ast.PriceRows[4]++;ast.PriceRows[5]+=cost
                pair:=ast.PriceMade[t];ast.PriceRows[2]+=pair[0];ast.PriceRows[3]+=pair[1];delete(ast.PriceMade,t)
                a=ast.PriceRead();b=ast.PriceRead()
            }
            if e = r.sameSort''')
    s=rep(s,'return true, r.setNewChildIfDifferent(t, h)','''e=r.setNewChildIfDifferent(t,h)
            if measured {ast.PriceRows[6]+=ast.PriceRead()-2*b+a}
            return true,e''')
    overlay(k,s)
else:
    build=p.parent/'build'; src=p.parent/'src'
    hdr=w/'ast/rewriter/rewriter_def.h';hdr.parent.mkdir(parents=True,exist_ok=True)
    h=(src/'ast/rewriter/rewriter_def.h').read_text()
    key='expr * r = get_cached(t);'
    h=rep(h,key,'''int64_t a=0,b=0,cost=0; if(pc.visit){a=pc.read();b=pc.read();}
        '''+key+'''
        if(pc.visit)cost=pc.read()-2*b+a;''')
    key='SASSERT(m().get_sort(r) == m().get_sort(t));'
    h=rep(h,key,'''bool measured=pc.visit && r!=t;
            if(measured){pc.rows[4]++;pc.rows[5]+=cost;
                auto it=pc.made.find(t);if(it!=pc.made.end()){pc.rows[2]+=it->second.first;pc.rows[3]+=it->second.second;pc.made.erase(it);}
                a=pc.read();b=pc.read();}
            '''+key)
    h=rep(h,'result_pr_stack().push_back(pr);\n            }\n            return true;', 'result_pr_stack().push_back(pr);\n            }\n            if(measured)pc.rows[6]+=pc.read()-2*b+a;\n            return true;')
    key='m_r = m().mk_app(f, new_num_args, new_args);'
    h=rep(h,key,'''if(pc.make){auto a=pc.read();auto b=pc.read(); auto *app=m().mk_app(f,new_num_args,new_args);auto c=pc.read();m_r=app;
                         auto n=c-2*b+a;auto& pair=pc.made[app];pair.first++;pair.second+=n;pc.rows[0]++;pc.rows[1]+=n;
                    }else '''+key)
    hdr.write_text(h)
    counter=w/'price.hpp';counter.write_text('''#pragma once
#include <unistd.h>
#include <cstdint>
#include <unordered_map>
#include <utility>
#include <cstdlib>
#include <cstdio>
struct price_counter{
 int fd=-1;bool make=false,visit=false;long long rows[8]={};
 std::unordered_map<void*,std::pair<int64_t,int64_t>> made;
 int64_t read(){uint64_t v[3];if(::read(fd,v,sizeof(v))!=sizeof(v)||v[1]!=v[2]) std::abort();return v[0];}
};
extern price_counter pc;
''')
    k=src/'smt/qi_queue.cpp';s='price_counter pc;\n'+k.read_text()
    key='m_subst(q, num_bindings, bindings, instance);'
    s=rep(s,key,'''auto env=std::getenv("QI_COUNTER_FD");pc.fd=env?std::atoi(env):-1;pc.make=pc.fd>=0;
        if(pc.make){pc.made.clear();for(auto& n:pc.rows)n=0;}
        '''+key+' pc.make=false;')
    key='m_context.get_rewriter()(instance, s_instance, pr);'
    s=rep(s,key,'pc.visit=pc.fd>=0; '+key+'''
        if(pc.visit){std::fprintf(stderr,"PRICE [");for(int i=0;i<8;i++)std::fprintf(stderr,"%s%lld",i?" ":"",pc.rows[i]);std::fprintf(stderr,"]\\n");}pc.visit=false;pc.fd=-1;''')
    qi=w/'qi_queue.cpp';qi.write_text(s)
    flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l);mk=(build/'Makefile').read_text()
    objs=[]
    for source,num in [(qi,39),(src/'ast/rewriter/th_rewriter.cpp',12),(src/'ast/rewriter/rewriter.cpp',12)]:
        inc=shlex.split(re.search(f'^includes_{num} = (.*)$',mk,re.M)[1])
        obj=w/(source.stem+'.o');subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),'-I'+str(w),*inc,'-include',counter,'-o',obj,source],cwd=build,check=True);objs.append(obj)
    lib=w/'libprice.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
    subprocess.run(['ar','r',lib,*objs],check=True)
    k=front/'smt/quantifier.go';overlay(k,rep(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':files}))
tags='xtrace_off'+(',classic_z3' if label=='native' else '')
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags',tags,'-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=front,check=True)
