from pathlib import Path
import subprocess,csv,re,os
w=Path(__file__).resolve().parent
with (w/'micro.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['round','engine','case','ns','bytes','allocations'])
    for rnd in range(7):
        for name in ['base','trial'][::1 if rnd%2==0 else -1]:
            r=subprocess.run(['taskset','-c','16',w/(name+'.test'),'-test.run','^$','-test.bench','^BenchmarkTheoryReduction$/(Iff|UninterpretedEquality)/Core','-test.benchtime','250000x','-test.count','1'],env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,text=True,check=True)
            rows=re.findall(r'^BenchmarkTheoryReduction/(\w+)/Core(?:-\d+)?\s+250000\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout,re.M)
            assert len(rows)==2,r.stdout
            for row in rows:out.writerow((rnd,name,*row))
