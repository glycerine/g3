"""Recognize already-normal EQ and ITE operands in the Boolean reducer."""
from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;files={}
def save(k,s):
    dst=w/k.name;dst.write_text(s);files[str(k)]=str(dst)
k=p/'ast/ast_core_accessors.go';s=k.read_text()+'''
// PlainUninterpretedApp checks the live local node and its cached declaration family.
func (m *ASTManager) PlainUninterpretedApp(h ASTHandle) bool {
    if astValidateHandles || ASTSourceDebug || m==nil || h.origin!=m.origin || h.slot==0 || h.slot>=m.nextNode || !m.lockFree() {return false}
    n:=m.nodeAt(h.slot)
    if !n.live || n.generation!=h.generation || n.kind!=ASTApp{return false}
    a:=m.appAt(h.slot)
    return a.declCached && a.declFamily==NullFamilyID
}
'''
save(k,s)
for f,sig,test in [('eq','mkEqCore(lhs, rhs ast.ASTHandle, out ast.ASTRef)','lhs!=rhs && m.PlainUninterpretedApp(lhs) && m.PlainUninterpretedApp(rhs)'),('ite','mkITECore(c, t, f ast.ASTHandle, out ast.ASTRef)','c!=t && c!=f && t!=f && m.PlainUninterpretedApp(c) && m.PlainUninterpretedApp(t) && m.PlainUninterpretedApp(f)')]:
    k=p/('ast/rewriter/bool_rewriter_'+f+'.go');s=k.read_text();i=s.index('m := rw.manager',s.index('func (rw *boolRewriter) '+sig))+len('m := rw.manager')
    save(k,s[:i]+'\n if '+test+' {return brFailed,nil}\n'+s[i:])
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':files}))
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:])
for t,cwd,cmd in [('cli',p,'./cmd/g3'),('ivy',front,'./cmd/goivy_check')]:
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly',*(['-modfile',mod] if t=='ivy' else []),'-tags','xtrace_off','-overlay',ov,'-o',w/('trial-'+t),cmd],cwd=cwd,check=True)
