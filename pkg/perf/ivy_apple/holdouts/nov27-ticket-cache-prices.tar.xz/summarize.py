from pathlib import Path
import csv,statistics,sys,collections
w=Path(__file__).resolve().parent
r=list(csv.DictReader((w/sys.argv[1]).open()))
assert len(r)==8200
counts={'constructors','key_constructors','changed_hits','hits','probes','reducers','finish_calls','uf','or','not','ite','eq','other'}
def seq(s,n,k):
    return tuple(int(row[k]) for row in r if row['solver']==s and row['round']==str(n))
for k in list(r[0])[3:]:
    a=seq('ordinary',0,k);b=seq('native',0,k)
    for n in range(5):
        if k in counts:
            assert seq('ordinary',n,k)==a and seq('native',n,k)==b
    if k in counts:assert a==b,(k,'divergent per-instance count')
    g,z=[statistics.median(sum(seq(s,n,k)) for n in range(5)) for s in ['ordinary','native']]
    print(k,g,z,g-z,'same ordered counts' if k in counts and a==b else '')
