"""Avoid repeated classification and operand reads inside EQ and ITE reducers."""
import json,sys,subprocess
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent;files={}
def replace(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(k,s):
    dst=w/k.name;dst.write_text(s);files[str(k)]=str(dst)
k=p/'ast/rewriter/th_rewriter.go';s=k.read_text()
i=s.index('kind, err := c.owner.manager.GetKind(term)',s.index('func (c *theoryRewriterConfiguration) equalityBit'));j=s.index('if count, e :=',i)
s=s[:i]+'''app, family, op, err := c.owner.manager.AppIdentity(term)
    if err!=nil || !app || family!=c.owner.manager.BasicFamilyID() || op!=ast.ASTOpEq {return x,0,false,err}
    '''+s[j:]
i=s.index('if kind == ast.ASTOpEq {',s.index('func (c *theoryRewriterConfiguration) reduceAppCore'))
j=s.index('sort, err :=',i)
z=s.index('if kind == ast.ASTOpEq || kind == ast.ASTOpIff {',j)
end=s.index('if status, err := c.tamagotchi',z)
s=s[:i]+s[i:j].replace('kind == ast.ASTOpEq {','kind == ast.ASTOpEq || kind == ast.ASTOpIff {')+'if kind == ast.ASTOpEq {\n'+s[j:z]+s[end:]
save(k,s)
k=p/'ast/rewriter/bool_rewriter_ite.go';s=k.read_text()
i=s.index('tITE, c2, t1, t2, e := rw.ite(t)')
j=s.index('if changed {',i)
s=s[:i]+'if rw.iteExtraRules || ast.ASTValidateHandles || ast.ASTSourceDebug {\n'+s[i:j]+'}\n\t'+s[j:]
save(k,s)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':files}))
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:])
for t,cwd,cmd in [('cli',p,'./cmd/g3'),('ivy',front,'./cmd/goivy_check')]:
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly',*(['-modfile',mod] if t=='ivy' else []),'-tags','xtrace_off','-overlay',ov,'-o',w/('trial-'+t),cmd],cwd=cwd,check=True)
