"""Build the ordinary policy with per-instance and whole-stage counters."""
import json,sys,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
base,front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:])
f=json.loads((base/'ordinary.json').read_text())['Replace'];f.update(json.loads((w/'trial.json').read_text())['Replace'])
ov=w/'phase.json';ov.write_text(json.dumps({'Replace':f}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'phase','./cmd/goivy_check'],cwd=front,check=True)
