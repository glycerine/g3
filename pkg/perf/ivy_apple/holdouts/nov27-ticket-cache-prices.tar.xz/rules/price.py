from pathlib import Path
import csv,os,json,subprocess,sys
w=Path(__file__).resolve().parent
base,gold,examples=map(lambda x:Path(x),sys.argv[1:])
cases=json.loads((gold/'cases.json').read_text())
spec,_,code=cases['ticket_protocol'];ref=gold/'reference/ticket_protocol'
env=dict(os.environ,GOMAXPROCS='1',GOGC='off',GOIVY_INCLUDE=str(examples/'ivy/include'),XTRACE_OFF='1')
expected=None
with (w/'price.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['round','engine','check','rewrites','rewrite','assertion'])
    for rnd in range(5):
        for label,b in [('base',base),('trial',w/'phase')][::1 if rnd%2==0 else -1]:
            r=subprocess.run(['taskset','-c','14',b,examples/spec],cwd=w,env=env,capture_output=True,timeout=120)
            pending=[];extra=bytearray();n=0
            for line in r.stderr.splitlines(keepends=True):
                if line.startswith(b'QI '):pending.append(line.decode().split()[1:])
                elif line.startswith(b'STAGE-COUNT '):
                    if line.startswith(b'STAGE-COUNT 7 1 check '):
                        seq=[(x[0],*x[2:]) for x in pending]
                        if expected is None:expected=seq
                        assert seq==expected
                        n=sum(x[0]=='rewrite' for x in pending)
                        out.writerow([rnd,label,int(line.split()[4]),n,*[sum(int(x[1]) for x in pending if x[0]==k) for k in ('rewrite','assert')]])
                    pending.clear()
                else:extra.extend(line)
            assert (r.returncode,r.stdout,bytes(extra),n)==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes(),820)
