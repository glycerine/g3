"""Use the checked fallback for nonordinary activity-cache reads."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent
p=Path.cwd();k=p/'ast/ast_activity_cache.go';s=k.read_text()
start=s.index('func (c *ActivityCache) Find(')
end=s.index('func (c *ActivityCache) decRefs',start)
body=s[start:end]
old='entry := c.table.find(astNodeRef{k.slot, k.generation}, hash)'
new='return c.findEntry(k,hash)\n}\nfunc (c *ActivityCache) findEntry(k ASTHandle,hash uint32)(ASTHandle,error){\n\t'+old
body=body.replace(old,new)
old='if e := c.open(); e != nil {'
body=body.replace(old,'''if !astValidateHandles && c!=nil && c.self==c && !c.closed && c.cause==nil {
        m:=c.manager
        if m!=nil && m.lockFree() && k.slot!=0 && k.origin==m.origin {
            if c.activityCacheEntries==nil || c.table.size==0 {return ASTHandle{},nil}
            return c.findEntry(k,m.nodeAt(k.slot).hash)
        }
    }
    return c.findChecked(k)
}
func (c *ActivityCache) findChecked(k ASTHandle)(ASTHandle,error){
    '''+old)
dest=w/k.name;dest.write_text(s[:start]+body+s[end:])
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(k):str(dest)}}))
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:])
for t,cwd,cmd in [('cli',p,'./cmd/g3'),('ivy',front,'./cmd/goivy_check')]:
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly',*(['-modfile',mod] if t=='ivy' else []),'-tags','xtrace_off','-overlay',ov,'-o',w/('trial-'+t),cmd],cwd=cwd,check=True)
