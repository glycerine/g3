# Ticket batch 7, goal 1, cache and reducer costs

Use the fork at 40770cf99, the pinned GoIvy frontend and the golden references from the preceding nov27-ticket-instance-cost study. Extract both archives in external scratch. Follow that study's setup.py and build.py steps to produce the ordinary and native base overlays in BASE. From g3/pkg run each variant with the same build tree, baseline static library, FRONT, MOD, GOLD and EXAMPLES.

    for variant in . all frames ops; do
        python3 "$W/$variant/build.py" ordinary "$BASE" "$MOD"
        python3 "$W/$variant/build.py" native "$BASE" "$MOD"
        python3 "$W/$variant/run.py" "$GOLD" "$EXAMPLES"
        python3 "$W/summarize.py" "$variant/measurements.csv"
    done

Each pair checks the complete verifier outcome. The summary checks every per-instance event count against the other backend and every rotation, then reports the median of round totals. Each section uses two consecutive reads before the operation and one after. The narrow study counts the AST returned by each substitution constructor using its actual handle or pointer until the instance is rewritten. When a changed hit consumes that key, all matching construction events are attributed once and removed from the observer map. Application identities are local to the instance. Constructor means a call to intern/build the expression and includes calls that returned an existing application. A changed-hit publication runs through pushing the cached result and recording a changed child in the enclosing frame. The next visit or reduction runs outside that interval. 'all' adds every cache read in visit; the separate frame-resume probe is outside its scope. 'frames' prices nonconstant application reduction and the common failed-reduction completion path. Its cache column includes checking whether the frame requests insertion. 'ops' classifies the reducer after timing it. Columns in the four measurements overlap across observers.

Build each uninstrumented trial with its trial.py, passing FRONT and MOD. Use the previous archive's replays.py and verify.py and same-flag control binaries for the paired CLI and verification runs. To reproduce rules/price.csv and uninterpreted/price.csv use phase.py with BASE, FRONT and MOD followed by price.py with BASE/ordinary, GOLD and EXAMPLES. The two phase builds both include the earlier per-instance observers. To repeat the microbenchmark in uninterpreted, build ast/rewriter via go test -c as base.test, then apply the local trial.json overlay to build trial.test. Run micro.py in any directory.
