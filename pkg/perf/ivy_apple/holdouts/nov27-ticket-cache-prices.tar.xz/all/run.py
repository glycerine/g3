"""Five paired per-instance observations, gated by the complete verifier transcript."""
from pathlib import Path
import argparse,csv,json,os,subprocess,statistics,collections
w=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('gold',type=Path);p.add_argument('examples',type=Path);p.add_argument('--rounds',type=int,default=5);p.add_argument('--cpu',default='14');a=p.parse_args()
spec,_,code=json.loads((a.gold/'cases.json').read_text())['ticket_protocol']
env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(a.examples/'ivy/include'))
ref=a.gold/'reference/ticket_protocol'
with (w/'measurements.csv').open('w') as f:
    out=csv.writer(f)
    out.writerow('round solver instance constructors construction key_constructors key_construction changed_hits lookup publication probes probe_cost hits hit_cost'.split())
    for rnd in range(a.rounds):
        for label in ['native','ordinary'][::1 if rnd%2==0 else -1]:
            r=subprocess.run(['taskset','-c',a.cpu,w/label,a.examples/spec],cwd=w,env=env,capture_output=True,timeout=120)
            extra=bytearray();pending=[];n=0
            for line in r.stderr.splitlines(keepends=True):
                if line.startswith(b'PRICE ['):pending.append(list(map(int,line.strip()[7:-1].split())))
                elif line.startswith(b'STAGE-COUNT '):
                    if line.startswith(b'STAGE-COUNT 7 1 check '):
                        n+=len(pending)
                        for i,row in enumerate(pending):out.writerow((rnd,label,i,*row))
                    pending.clear()
                else:extra.extend(line)
            assert (r.returncode,r.stdout,bytes(extra),n)==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes(),820),(r.returncode,extra[:400],n)
            print(rnd,label,n,flush=True);f.flush()
