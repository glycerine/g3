"""Classify early proof attempts by whether the same goal reached a concrete check."""
from pathlib import Path
import csv,sys,statistics,collections
w=Path(__file__).resolve().parent
src=Path(sys.argv[1])
def table(label):
    result=collections.defaultdict(dict)
    for r in csv.DictReader((src/(label+'-counts.csv')).open()):
        k=(r['batch'],r['goal'],r['phase'])
        row=result[r['round']]
        assert k not in row
        row[k]=int(r['instructions'])
    return result
rel=table('release');ordinary=table('ordinary');native=table('native')
out=[]
for n,rows in rel.items():
    for k,count in rows.items():
        if k[-1]!='early':continue
        check=(*k[:2],'check')
        out.append((n,*k[:2],'fallback' if check in rows else 'proved',count,ordinary[n][check],native[n][check]))
with (w/'policies.csv').open('w') as f:
    writer=csv.writer(f);writer.writerow('round batch goal outcome early ordinary_check native_check'.split());writer.writerows(out)
for o in ('fallback','proved'):
    vals=[x for x in out if x[3]==o]
    print(o,*[statistics.median(sum(1 if c==0 else x[c] for x in vals if x[0]==n) for n in rel) for c in (0,4,5,6)])
for phase in ('check','first'):
    print(phase,*(statistics.median(sum(v for k,v in r.items() if k[-1]==phase) for r in d.values()) for d in (rel,ordinary,native)))
