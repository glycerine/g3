from common import *
import early_plan_budget as eb,stage_frontier as sf,macro_identity as mi,initial_pass_schedules as ips,shlex
rd=d/'wide-after-narrow';rd.mkdir(exist_ok=True)
def mk():
 q=pkg/'api/api_verification_goal.go';s=q.read_text();s=once(s,'import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast";"os")')
 s+='\nvar studyWideAfterNarrow=os.Getenv("G3_STUDY_WIDE_NARROW")\n'
 x='if yes, err := check(defs.selectRows(m, symbols, false, 32), 6000);'
 s=once(s,x,'narrow:=defs.selectRows(m,symbols,false,32)\nif yes, err := check(narrow,6000);')
 x='if yes, err := check(defs.selectRows(m, symbols, true, wideLimit), 100000);'
 s=once(s,x,'''wide:=defs.selectRows(m,symbols,true,wideLimit)
 if p.plans.reusable(m){
  skip:=false
  switch studyWideAfterNarrow{
  case "any":skip=len(narrow)>0
  case "no-wide":skip=true
  case "both":skip=len(narrow)>0&&len(wide)>32
  case "large":skip=len(narrow)>0&&len(wide)>64
  case "factor4":skip=len(narrow)>0&&len(wide)>=4*len(narrow)
  case "two-base":skip=len(narrow)>0&&len(base.rows)>2*maxWidePremises
  case "siblings":skip=p.studyTriedNarrow || len(narrow)>0
  case "prior-only":skip=p.studyTriedNarrow
  case "prior-wide":skip=p.studyTriedWide
  case "one-extra":skip=p.studyTriedWide&&len(narrow)>0
  case "one-total":skip=p.studyTriedNarrow||p.studyTriedWide||len(narrow)>0
  }
  if skip{wide=nil}
  p.studyTriedNarrow=p.studyTriedNarrow||len(narrow)>0
  p.studyTriedWide=p.studyTriedWide||len(wide)>0
 }
 if yes,err:=check(wide,100000);''')
 a=pkg/'api/api_order_abstraction.go';t=once(a.read_text(),'previousGoalProved bool','previousGoalProved bool\n studyTriedNarrow,studyTriedWide bool')
 return build(rd/'checker',o=overlay(rd/'overlay',{q:s,a:t}))
def main():
 b=mk();(rd/'build-info.txt').write_text(linked(b));vs={'control':d/'release-relevance-queue/checker/goivy_check','harness':b}
 for n in ('any','no-wide','both','large','factor4','two-base','siblings','prior-only','prior-wide','one-extra','one-total'):
  f=rd/(n+'.sh');f.write_text('#!/bin/sh\nG3_STUDY_WIDE_NARROW='+n+' exec '+shlex.quote(str(b))+' "$@"\n');f.chmod(0o700);vs[n]=f
 ips.root=rd;js=[j for j in sf.jobs()if j[1]in('tlb','hybrid','hermes_rmw_o3','ticket_protocol','flash2','arm_rules3','alternating_bit_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([2,4,6,8,10],(j for j in mi.jobs()if j[1]in('cf_live','dramc_nb2','rfn2','toy-consensus','raftok')))]
 with ThreadPoolExecutor(7)as ex:list(ex.map(lambda j:ips.lane(j,vs,3),js))
if __name__=='__main__':main()
