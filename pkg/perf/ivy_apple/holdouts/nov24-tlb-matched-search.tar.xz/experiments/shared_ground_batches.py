"""Instantiate universal premises with observed ground terms; test each repeated pool in one scoped native solver."""
from common import *
import ground_plan_cores as gp,itertools
from functools import lru_cache
from concurrent.futures import ProcessPoolExecutor,as_completed
br=gp.br;rd=d/'shared-ground-batches';rd.mkdir(exist_ok=True)
@lru_cache(24000)
def flat(h):
 if isinstance(h,tuple):
  if h[0]=='!':return flat(h[1])
  if h[0]=='and':return tuple(z for a in h[1:]for z in flat(a))
 return (h,)
@lru_cache(100000)
def nonground(h):
 return isinstance(h,tuple)and(h[0]in ('exists','forall','lambda')or any(map(nonground,h[1:])))
def replace(x,bindings):
 if not isinstance(x,tuple):return bindings.get(x,x)
 if x[0]=='!':return replace(x[1],bindings)
 return (x[0],*(replace(y,bindings)for y in x[1:]))
def context(n):
 pre,names,bs=br.prepare(d/'holdout-streams'/n/'events.csv.gz');ds=[br.parse(x)[0]for x in pre]
 defs=[a[-1]for a in ds if a[0]=='define-fun'];sorts={a[1]for a in ds if a[0]=='declare-sort'}
 tys=defaultdict(dict)
 for a in ds:
  if a[0]=='declare-fun':tys[a[1]][a[2]]=a[3]
 return '\n'.join(br.smt(a)for a in ds if a[0]!='define-fun')+'\n',defs,bs,sorts,tys
def trial(n,ids,mode,old,selector):
 data=ctx[n];prefix,defs,batches,sorts,tys=data
 @lru_cache(30000)
 def st(x):
  if not isinstance(x,tuple):return tys.get(x,{}).get(())
  return tys.get(x[0],{}).get(tuple(map(st,x[1:])))
 @lru_cache(24000)
 def terms(x):
  ts=defaultdict(list);seen=set();stack=[x]
  while stack:
   h=stack.pop()
   if h in seen:continue
   seen.add(h);s=st(h)
   if s in sorts:ts[s].append(h)
   if isinstance(h,tuple)and h and h[0]not in ('forall','exists','lambda'):stack.extend(reversed(h[1:]))
  return ts
 ans=[];mode0,extra,bound=mode;expanded=(mode0=='apps');which=null=0
 for bi,base,ls in batches:
  if bi not in ids:continue
  groups=defaultdict(list);tally=defaultdict(Counter)
  ground=[];patterns=[]
  for h in dict.fromkeys(row for j in base for row in flat(defs[j])):
   if not nonground(h):
    ground.append(h)
    for sort,ts in terms(h).items():tally[sort].update(x for x in ts if not isinstance(x,tuple)or expanded)
    continue
   if not isinstance(h,tuple):continue
   if h[0]=='not' and isinstance(h[1],tuple)and h[1][0]=='exists':h=('forall',h[1][1],('not',h[1][2]))
   if h[0]!='forall' or nonground(h[2])or len(h[1])>8:continue
   pats=h[1];body=h[2]
   if isinstance(body,tuple)and body[0]=='!':body=body[1]
   patterns.append((pats,body))
  for j,(i,want) in enumerate(ls,1):
   key=(bi,i);h=defs[i]
   if nonground(h)or (selector=='costly'and key not in old):continue
   pools={}
   sy=terms(h)
   for sort in sorts:
    roots=[v for v in sy.get(sort,())if expanded or not isinstance(v,tuple)]
    # Include every observed constant when it fits. Add a bounded source
    # term even for domains absent from this goal, without closing the sort.
    if len(roots)>bound:roots=roots[:bound]
    for v,cnt in tally[sort].most_common():
     if len(roots)>=bound or len(roots)>=len([x for x in sy.get(sort,())if expanded or not isinstance(x,tuple)])+extra:break
     if v not in roots:roots.append(v)
    if roots:pools[sort]=tuple(sorted(roots,key=str))
   groups[tuple(sorted(pools.items()))].append((i,want,h))
  for gi,(pool,goals)in enumerate(groups.items()):
   pd=dict(pool);seen=set(ground);inst=list(ground);attempt=0
   for vs,body in patterns:
    cols=[pd.get(ty,())for name,ty in vs]
    for tup in itertools.islice(itertools.product(*cols),32):
     attempt+=1
     if attempt>14000:break
     val=replace(body,dict(zip([nm for nm,ty in vs],tup)))
     if val not in seen:seen.add(val);inst.append(val)
    if attempt>14000:break
   text='(set-option :timeout 1000)\n'+prefix+'\n'.join('(assert '+br.smt(h)+')'for h in inst)+'\n'
   script=text+'\n'.join('(push 1)\n(assert '+br.smt(h)+')\n(check-sat)\n(pop 1)'for _,_,h in goals)+'\n'
   start=time.monotonic()
   p=subprocess.run([pkg.parent/'build/z3','-in','-smt2'],text=True,input=script,capture_output=True,timeout=len(goals)*2+120)
   verdicts=p.stdout.splitlines();assert len(verdicts)==len(goals)and p.returncode==0 and not p.stderr,(n,bi,p.stdout[:350],p.stderr[:350])
   for (i,want,h),res in zip(goals,verdicts):
    assert res in ('sat','unsat','unknown')and(res!='unsat'or want=='unsat'),(bi,i,res,want)
    c=old.get((bi,i),0)
    ans.append([n,bi,i,mode0,extra,bound,gi,len(goals),len(ground),len(inst),attempt,want,res,c])
   if bi in (3,32,35,45,60)and mode==('constants',1,3)and any(x[-1]=='unsat'for x in zip(goals,verdicts)):
    dest=rd/'examples'/n;dest.mkdir(parents=True,exist_ok=True)
    with gzip.open(dest/f'{bi}-{gi}.smt2.gz','wt',compresslevel=3)as f:f.write(script)
 st.cache_clear();terms.cache_clear();return ans
def expensive(n,bs):
 p=d/'stage-frontier'
 rows=list(csv.DictReader(gzip.open(p/'inner'/n/'1-g3/checks.csv.gz','rt')));co=[r for r in csv.DictReader(gzip.open(p/'outer/runs'/n/'1-g3/phases.csv.gz','rt'))if r['stage']=='check']
 actual=[(g,i,ans)for g,base,goals in bs for i,ans in goals]
 if len(actual)!=len(rows) or len(co)!=len(rows):return {}
 costs=Counter()
 for (g,i,ans),a,b in zip(actual,rows,co):
  assert str(g)==a['batch']==b['batch']
  if int(a['solver']) or int(a['proof'])>1_000_000 or int(a['proof'])==0:costs[g,i]+=int(b['instructions'])
 return costs
ctx={}
def main():
 global ctx
 names=['tlb','ticket_protocol','alternating_bit_protocol','arm_rules3','test_liveness2','hybrid','hermes_rmw_o3']
 for n in names:ctx[n]=context(n)
 with ProcessPoolExecutor(8)as ex,(rd/'runs.csv').open('w')as out:
  z=csv.writer(out);z.writerow('spec batch goal terms extra width group group_goals ground asserted instances expected answer original_instructions'.split())
  jobs=[]
  for n in names:
   bs=ctx[n][2];old=expensive(n,bs);allids=list(dict.fromkeys(g for g,_,_ in bs))
   for i in range(0,len(allids),3):
    ids=set(allids[i:i+3])
    for mode in [('constants',0,3),('constants',1,3),('constants',2,4),('apps',1,3)]:
     jobs.append(ex.submit(trial,n,ids,mode,old,'costly'if old else'all'))
  for f in as_completed(jobs):z.writerows(f.result());out.flush()
if __name__=='__main__':main()
