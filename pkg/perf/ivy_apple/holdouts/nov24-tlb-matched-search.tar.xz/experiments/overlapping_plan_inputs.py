from common import *
import stage_frontier as sf,macro_identity as mi
rd=d/'overlapping-plan-inputs';rd.mkdir(exist_ok=True)
def main():
 q=pkg/'api/api_verification_goal.go';s=subprocess.check_output(['git','show','d1954a9ce:pkg/api/api_verification_goal.go'],cwd=pkg,text=True)
 s=once(s,'import "github.com/glycerine/g3/pkg/ast"','import("github.com/glycerine/g3/pkg/ast";"os";"fmt";"compress/gzip")')+'\nvar studyOverlapCapture int\n'
 x='check := func(subset';s=once(s,x,'previous:=0;'+x);x='input := append(subset, goal)';s=once(s,x,'''if steps==100000 && previous>0 && len(subset)>32 && studyOverlapCapture<4{
 studyOverlapCapture++;ctx:=SMTContext{smtContextState:p.source.owner};raw,e:=ctx.BenchmarkSMT2(goal,APIBenchmarkConfig{Assumptions:assertions[:len(assertions)-1]});if e!=nil{panic(e)}
 f,e:=os.Create(fmt.Sprintf("query-%d.smt2.gz",studyOverlapCapture));if e!=nil{panic(e)};gz:=gzip.NewWriter(f);if _,e=fmt.Fprint(gz,raw);e!=nil{panic(e)};if e=gz.Close();e!=nil{panic(e)};if e=f.Close();e!=nil{panic(e)};fmt.Fprintln(os.Stderr,"OVERLAP",studyOverlapCapture,previous,len(subset),len(base.rows))
 };if steps==6000{previous=len(subset)}
 '''+x)
 b=build(rd/'checker',o=overlay(rd/'overlay',{q:s}));(rd/'build-info.txt').write_text(linked(b))
 js=[j for j in sf.jobs()if j[1]in('tlb','arm_rules3','hermes_rmw_o3','ticket_protocol','hybrid')]+[(4,*j[1:5],j[-1])for j in mi.jobs()if j[1]=='cf_live']
 def lane(j):
  c,n,sp,iso,rc,ref=j;dest=rd/n;dest.mkdir(exist_ok=True);p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=dest,capture_output=True,env=dict(env,GOMAXPROCS='1'))
  oth=bytearray();au=bytearray()
  for l in p.stderr.splitlines(keepends=True):
   if l.startswith(b'OVERLAP '):au.extend(l)
   else:oth.extend(l)
  assert(p.returncode,p.stdout,oth)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(n,p.returncode,oth[-500:]);(dest/'captured').write_bytes(au);print(n,len(au.splitlines()),flush=True)
 with ThreadPoolExecutor(6)as ex:list(ex.map(lane,js))
if __name__=='__main__':main()
