from common import *
import initial_pass_schedules as ips,stage_frontier as sf,macro_identity as mi,shlex
rd=d/'steady-ground-search';rd.mkdir(exist_ok=True)
def make():
 a=pkg/'api/api_order_abstraction.go';t=a.read_text();t=once(t,'previousGoalProved bool','previousGoalProved bool\n steadySearch studySteadySearch')
 t=once(t,'b.state.recent = nil','if err:=b.state.steadySearch.close();err!=nil{return err};b.state.steadySearch=studySteadySearch{}\nb.state.recent=nil')
 t=once(t,'return p.enumeration.check(parent, assertions)','''proved,err=p.enumeration.check(parent,assertions)
 if !proved&&err==nil&&steadyBackend!=""&&goal.IsNull()&&p.plans.reusable(parent)&&!limit.CancelFlag(){return p.steadySearch.prove(s,parent,assertions)}
 return proved,err''')
 q=pkg/'api/internal/order/steady_ground_benchmark_trial.go';s='package order\nimport("github.com/glycerine/g3/pkg/ast";"math/bits";"slices";"sort")\n'+(d/'steady_ground.go.txt').read_text()+(d/'steady_units.go.txt').read_text()
 s=once(s,'type StudyGroundPacket struct{ Base','type StudyGroundPacket struct{Version uint64;Base');s=once(s,'type StudyGroundDB struct{','type StudyGroundDB struct{\nversion uint64\nunits steadyUnits');s=once(s,'*z=StudyGroundDB{m:m','*z=StudyGroundDB{version:z.version+1,m:m');s=once(s,'&StudyGroundPacket{z,int(z.vars)','&StudyGroundPacket{z.version,z,int(z.vars)')
 f=pkg/'api/steady_search_benchmark_trial.go';b='package api\nimport("fmt";"os";"strconv";"errors";"github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/api/internal/order";"github.com/glycerine/g3/pkg/sat";"github.com/glycerine/g3/pkg/util/control";"github.com/glycerine/g3/pkg/util/lbool")\n'+(d/'steady_search.go.txt').read_text()
 return build(rd/'checker',o=overlay(rd/'overlay',{q:s,a:t,f:b}))
def audit(j,b):
 c,n,sp,iso,rc,rf=j;od=rd/('audit-'+n);od.mkdir(exist_ok=True);p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=od,env=dict(env,GOMAXPROCS='1',G3_STEADY_ENGINE='sat',G3_STEADY_MIN='192',G3_STEADY_REPEAT='2',G3_STEADY_CONGRUENCE='16',G3_STEADY_AUDIT='1'),capture_output=True);other=bytearray()
 with gzip.open(od/'trials.csv.gz','wt')as f:
  z=csv.writer(f);z.writerow('version vars clauses new_clauses compile solver_steps result proved no_error'.split())
  for l in p.stderr.splitlines(keepends=True):
   if l.startswith(b'STEADY '):z.writerow(l.decode().split()[1:])
   else:other.extend(l)
 assert (p.returncode,p.stdout,other)==(rc,(rf/'stdout').read_bytes(),(rf/'stderr').read_bytes()),(n,p.returncode,other[-450:]);print('audit',n,flush=True)
def main():
 b=make();(rd/'build-info.txt').write_text(linked(b));bs={'control':d/'release-repeat-plans/checker/goivy_check','harness':b}
 for v,cg,dc,mn in [('sat',16,0,192),('sat',48,0,192),('sat',4,0,192),('sat',0,0,192),('units',16,0,192),('units',16,12,192),('units',48,0,192),('both',16,12,192),('sat',16,0,64),('sat',16,0,384)]:
  n=f'{v}-{cg}-{dc}-{mn}';f=rd/(n+'.sh');f.write_text('#!/bin/sh\nG3_STEADY_ENGINE='+v+' G3_STEADY_MIN='+str(mn)+' G3_STEADY_CONGRUENCE='+str(cg)+' G3_STEADY_DECISIONS='+str(dc)+' G3_STEADY_REPEAT=2 exec '+shlex.quote(str(b))+' "$@"\n');f.chmod(0o700);bs[n]=f
 ips.root=rd;js=[j for j in sf.jobs()if j[1]in('tlb','arm_rules3','hermes_rmw_o3','hybrid','ticket_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([4,6,8],(j for j in mi.jobs()if j[1]in('rfn2','cf_live','raftok')))]
 with ThreadPoolExecutor(5)as e:
  fs=[e.submit(audit,j,b)for j in js]+[e.submit(ips.lane,j,bs,2)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
