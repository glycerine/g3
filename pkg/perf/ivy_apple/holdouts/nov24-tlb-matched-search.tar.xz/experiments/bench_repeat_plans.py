from common import *
rd=d/'release-repeat-plans/bench';rd.mkdir(exist_ok=True)
def binary(v):
 q=pkg/'api/api_verification_goal.go';o=[]
 if v=='before':
  s=subprocess.check_output(['git','show','d1954a9ce:pkg/api/api_verification_goal.go'],cwd=pkg,text=True)+'\nconst maxNarrowPremises=32\n';o=['-overlay='+str(overlay(rd/'overlay',{q:s}))]
 with(w/'build.lock').open('a')as lk,(rd/(v+'.build')).open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-p','3','-tags=xtrace_off','-pgo=off','-o',rd/(v+'.test'),*o,'./api'],cwd=pkg,stdout=log,stderr=log)
 return rd/(v+'.test')
def main():
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(['before','after'],ex.map(binary,['before','after'])))
 for j in range(9):
  for v,b in list(bs.items())[::1 if j%2==0 else -1]:
   with(rd/(v+'.bench')).open('a')as log:run(['taskset','-c','42',b,'-test.run=^$','-test.bench=^BenchmarkVerificationPremiseSearch$','-test.benchtime=15x','-test.cpu=1'],cwd=pkg/'api',stdout=log,stderr=log)
if __name__=='__main__':main()
