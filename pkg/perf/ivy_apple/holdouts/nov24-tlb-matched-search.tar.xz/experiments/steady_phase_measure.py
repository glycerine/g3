from common import *
import shared_phase_measure as old,steady_ground_search as st,stage_frontier as sf,inspect
rd=d/'steady-phase-measure';rd.mkdir(exist_ok=True)
def make():
 import live_checks as lc
 src=inspect.getsource(old.make);src=src[:src.index(" if variant!='control':")]+''' return ed
'''
 ns=old.__dict__.copy();exec(src,ns);ed=ns['make']('control');p=st.rd/'overlay';q=pkg/'api/steady_search_benchmark_trial.go';a=pkg/'api/api_order_abstraction.go';g=pkg/'api/internal/order/steady_ground_benchmark_trial.go'
 for f in [a,q,g]:ed[f]=(p/f.name).read_text()
 ed[pkg/'api/steady_meter_benchmark_trial.go']=lc.helper.replace('package smt','package api')
 s=ed[q];f=s.index('func (s *studySteadySearch) prove(')
 x='p, e := s.db.Project';i=s.index(x,f);j=s.index('if e != nil || p == nil',i);s=s[:i]+'done:=trialPassBegin("compile");'+s[i:j]+'done();'+s[j:]
 x='if b.solver == nil {';i=s.index(x,f);j=s.index('good := false',i);s=s[:i]+'done=trialPassBegin("start");'+s[i:j]+'done();'+s[j:]
 x='for len(b.vars) <= p.Variables {';i=s.index(x,f);j=s.index('s.rows = len(p.Clauses)',i);s=s[:i]+'done=trialPassBegin("install");'+s[i:j]+'done();'+s[j:]
 x='result, e = b.solver.Check([]sat.Literal{lit})';s=once(s,x,'done=trialPassBegin("query");'+x+';done()')
 x='if proved && err == nil && !s.validated {';i=s.index(x,f);j=s.index('if l.CancelFlag()',i);s=s[:i]+'timeValidate:=trialPassBegin("validate");'+s[i:j]+'timeValidate();'+s[j:]
 ed[q]=s;b=build(rd/'checker',o=overlay(rd/'overlay',ed));(rd/'build-info.txt').write_text(linked(b));return b
def main():
 b=make();fn=inspect.getsource(old.runone).replace('G3_STUDY_SHARED=','G3_STEADY_ENGINE="sat",G3_STEADY_REPEAT="2",G3_STEADY_MIN="192",G3_STEADY_CONGRUENCE="16",G3_STUDY_SHARED=').replace('proof general index start install push compile query','proof general start install compile query validate')
 ns=old.__dict__.copy();ns['root']=rd;exec(fn,ns);js=[j for j in sf.jobs()if j[1]in('tlb','hermes_rmw_o3','hybrid')];js=[(32,*j[1:])if j[1]=='tlb'else j for j in js]
 with ThreadPoolExecutor(3)as ex:list(ex.map(lambda j:ns['runone'](j,{'before':d/'shared-phase-measure/control/checker/goivy_check','steady16':b}),js))
if __name__=='__main__':main()
