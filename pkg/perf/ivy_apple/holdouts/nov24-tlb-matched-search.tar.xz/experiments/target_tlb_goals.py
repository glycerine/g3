from common import *
import ground_plan_cores as gp
def runjob(n):
 p=d/'stage-frontier';outer=lambda v:list(csv.DictReader(gzip.open(p/'outer/runs'/n/('1-'+v)/'phases.csv.gz','rt')))
 gz=lambda v:list(csv.DictReader(gzip.open(p/'inner'/n/('1-'+v)/'checks.csv.gz','rt')))
 og=[r for r in outer('g3')if r['stage']=='check'];oz={(r['batch'],r['condition']):r for r in outer('native')if r['stage']=='check'};cs=gz('g3');gs=gz('g3-stats');zs={(r['batch'],r['goal']):r for r in gz('native-stats')}
 pre,names,batches=gp.br.prepare(d/'holdout-streams'/n/'events.csv.gz');terms=[gp.br.parse(t)[0][4]for t in pre if t.startswith('(define-fun ')]
 gg=[(str(batch),i,ans)for batch,base,goals in batches for i,ans in goals];assert len(og)==len(gg)
 res=defaultdict(Counter);by=defaultdict(list)
 for a,b,c,h in zip(og,cs,gs,gg):
  k=a['batch'],a['condition'];assert k[0]==h[0] and c['goal']==k[1] and h[2]==('unsat'if a['result']=='-1'else'sat')
  i=h[1];s='fallback'if int(b['solver'])else'first'if int(b['proof'])==0 else'proved'
  if s!='fallback':continue
  r=res[i];r['g3']+=int(a['instructions']);r['native']+=int(oz[k]['instructions']);r['count']+=1
  for field in ['decisions','quant-instantiations','conflicts','mk-bool-var','propagations']:
   r['g-'+field]+=int(c[field]);r['n-'+field]+=int(zs[k][field])
  by[i].append(k)
 rd=d/'rank-fallback';rd.mkdir(exist_ok=True);lst=sorted(res,key=lambda i:res[i]['g3']-res[i]['native'],reverse=True)
 with(rd/(n+'.csv')).open('w')as f:
  z=csv.writer(f);ks=list(res[lst[0]]);z.writerow(['term',*ks,'positions','smt2'])
  for i in lst:z.writerow([i,*(res[i][s] for s in ks),' '.join('/'.join(x)for x in by[i]),gp.br.smt(terms[i])])
 print([(i,res[i]['count'],round((res[i]['g3']-res[i]['native'])/1e9,2),res[i]['g-quant-instantiations'],res[i]['n-quant-instantiations'])for i in lst[:12]])
if __name__=='__main__':runjob('tlb')
