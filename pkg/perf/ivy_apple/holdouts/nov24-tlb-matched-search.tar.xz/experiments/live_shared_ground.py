from common import *
import initial_pass_schedules as ips,stage_frontier as sf,macro_identity as mi,shlex
rd=d/'live-shared-ground';rd.mkdir(exist_ok=True)
def mk():
 q=pkg/'api/api_goal_instances_check.go';a=pkg/'api/api_order_abstraction.go';s=q.read_text();s=once(s,'import (','import("os";"fmt";"strconv";"sort";"slices";')+(d/'shared_ground_trial.go.txt').read_text();t=a.read_text()
 t=once(t,'previousGoalProved bool','previousGoalProved bool\n studyShared studyGroundShared')
 x='b.state.recent = nil';t=once(t,x,'if err:=b.state.studyShared.closeEngine();err!=nil{return err};b.state.studyShared=studyGroundShared{}\n'+x)
 x='return p.enumeration.check(parent, assertions)';t=once(t,x,'''proved,err=p.enumeration.check(parent,assertions)
 if !proved&&err==nil&&goal.IsNull()&&studySharedMode!=""&&!limit.CancelFlag(){return p.studySharedProof(parent,assertions)}
 return proved,err''')
 return build(rd/'checker',o=overlay(rd/'overlay',{a:t,q:s}))
def audit(j,b):
 c,n,sp,iso,rc,rf=j;s=rd/('audit-'+n);s.mkdir(exist_ok=True)
 with(s/'stdout').open('wb')as out,gzip.open(s/'events.csv.gz','wt')as f:
  z=csv.writer(f);z.writerow('terms rules facts pools instances uses new install_steps total_steps result abandoned'.split());p=subprocess.Popen(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=s,env=dict(env,GOMAXPROCS='1',GOGC='100',G3_STUDY_SHARED='grow',G3_STUDY_MIN_RULES='192',G3_STUDY_REPEAT='2',G3_STUDY_SHARED_AUDIT='1'),stdout=out,stderr=subprocess.PIPE);other=bytearray()
  for l in p.stderr:
   if l.startswith(b'SHARED-PROOF '):z.writerow(l.decode().split()[1:])
   else:other.extend(l)
  rc1=p.wait();(s/'stderr').write_bytes(other);assert rc1==rc and other==(rf/'stderr').read_bytes() and(s/'stdout').read_bytes()==(rf/'stdout').read_bytes(),(n,rc1,other[-600:])
 print('audited',n,flush=True)
def main():
 b=mk();(rd/'build-info.txt').write_text(linked(b));flags=[('grow',1,96),('grow',2,96),('grow',2,192),('grow',3,384),('grow',5,192),('single',2,192),('single',5,192),('grow',1,384)]
 bs={'control':d/'release-relevance-queue/checker/goivy_check','harness':b}
 for mode,rep,n in flags:
  v=f'{mode}-{rep}-{n}';f=rd/(v+'.sh');f.write_text('#!/bin/sh\nG3_STUDY_SHARED='+mode+' G3_STUDY_REPEAT='+str(rep)+' G3_STUDY_MIN_RULES='+str(n)+' exec '+shlex.quote(str(b))+' "$@"\n');f.chmod(0o700);bs[v]=f
 ips.root=rd;js=[j for j in sf.jobs()if j[1]in('tlb','hybrid','hermes_rmw_o3','ticket_protocol','flash2','arm_rules3','alternating_bit_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([2,4,6,8,10],(j for j in mi.jobs()if j[1]in('cf_live','dramc_nb2','rfn2','toy-consensus','raftok')))]
 with ThreadPoolExecutor(8)as ex:
  fs=[ex.submit(audit,j,b)for j in js]+[ex.submit(ips.lane,j,bs,2)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
