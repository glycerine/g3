from common import *
import stage_frontier as sf,holdouts as ho,macro_identity as mi,ground_release_controls as gc,production_triggers as pt
rd=d/'release-repeat-plans';rd.mkdir(exist_ok=True)
def tests(tags):
 cmd=['go','test','-count=1','-p','3',*(['-tags='+tags]if tags else []),'./api']
 if tags:cmd+=['-run','Test(Verification|OrderProof|TicketPrivate|ShortPremise|Witness|Enumeration|SMT.*Incremental)']
 with(w/'build.lock').open('a')as lk,(rd/('tests-'+(tags or 'release')+'.log')).open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(cmd,cwd=pkg,stdout=log,stderr=log)
 print('tests',tags,flush=True)
def main():
 ho.root=rd;gc.d=rd;pt.root=rd;before=d/'release-relevance-queue/checker/goivy_check'
 with ThreadPoolExecutor(15)as ex:
  cb=ex.submit(build,rd/'checker');fs=[ex.submit(tests,t)for t in ['','xtrace_off','g3debug','g3checked']]+[ex.submit(pt.source_trace)];b=cb.result();(rd/'build-info.txt').write_text(linked(b));fs.append(ex.submit(gc.corpus,b))
  js=[j for j in sf.jobs()if j[1]in('tlb','hermes_rmw_o3','arm_rules3','ticket_protocol','hybrid','flash2','alternating_bit_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([2,4,6,8,10,15],(j for j in mi.jobs()if j[1]in('rfn2','cf_live','dramc_nb2','raft_no_assume_test','raftok','toy-consensus')))]+ho.jobs()[:3]
  for j in js:fs.append(ex.submit(ho.measure_spec,j,{'before':before,'after':b,'native':native},5 if j[1]in ('tlb','cf_live','rfn2')else 3))
  for f in fs:f.result()
if __name__=='__main__':main()
