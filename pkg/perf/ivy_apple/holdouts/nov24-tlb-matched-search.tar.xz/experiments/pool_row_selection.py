from common import *
import shared_ground_batches as sg,inspect,itertools
from functools import lru_cache
from concurrent.futures import ProcessPoolExecutor,as_completed
rd=d/'pool-row-selection';rd.mkdir(exist_ok=True);br=sg.br
def evaluate(n,bi,gi,inst,ng,goals,prefix,old):
 decl=set(re.findall(r'^\(declare-fun ([^\s()]+)',prefix,re.M));safe='g3.ground.row!';assert all(not h.startswith(safe)for h in decl)
 def symbols(h):
  if isinstance(h,tuple):
   s=set().union(*(symbols(x)for x in h[1:]));op=h[0]
   if op in decl:s.add(op)
   return s
  return set()
 sig=[symbols(h)for h in inst];gs=[symbols(h)for _,_,h in goals];ct=Counter(v for s in sig for v in s)
 # Fewest occurrences and per-body Boolean definition heads; every selection is a subset of admissible instances.
 inv=defaultdict(set);head=defaultdict(set)
 def defined(h):
  if not isinstance(h,tuple):return ()
  if h[0]in ('=','=>','iff'):
   args=h[1:2]if h[0]!='=>'else h[2:3]
  else:args=(h,)
  for a in args:
   if isinstance(a,tuple)and a[0]=='not':a=a[1]
   if isinstance(a,tuple)and a[0]in decl:yield a[0]
 for j,s in enumerate(sig):
  for a in s:inv[a].add(j)
  for a in defined(inst[j]):head[a].add(j)
 sel=[];checks=[];core_answers={}
 T=lambda h:br.smt(h)
 opts='(set-option :timeout 800)\n(set-option :produce-unsat-cores true)\n';pre=[opts,prefix]
 for j,h in enumerate(inst):
  v=safe+str(j);pre.extend(['(declare-fun '+v+' () Bool)\n','(assert (=> '+v+' '+T(h)+'))\n'])
 labels=[safe+str(j)for j in range(len(inst))]
 def ask(go,ch,core=False):
  sub=' '.join(labels[j]for j in sorted(ch));q='(push 1)\n(assert '+T(go)+')\n(check-sat-assuming ('+sub+'))\n'
  return q+('(get-unsat-core)\n'if core else'')+'(pop 1)\n'
 def execute(script):
  p=subprocess.run([pkg.parent/'build/z3','-in','-smt2'],capture_output=True,text=True,input=''.join(pre)+script,timeout=120+len(goals)*4)
  return p
 control=execute(''.join(ask(g,range(len(inst)))for i,e,g in goals));ver=control.stdout.splitlines();assert not control.stderr and control.returncode==0 and len(ver)==len(goals)
 con=execute(''.join(ask(g,range(len(inst)),True)for (i,e,g),v in zip(goals,ver)if v=='unsat'));lines=con.stdout.splitlines();assert con.returncode==0 and not con.stderr and len(lines)==2*ver.count('unsat'),(n,bi,con.returncode,con.stdout[:300]);it=iter(lines)
 past=Counter();sets=[];hints=defaultdict(Counter)
 for k,((i,expected,g),v)in enumerate(zip(goals,ver)):
  assert v!='unsat'or expected=='unsat';core=set()
  if v=='unsat':
   assert next(it)=='unsat';row=next(it);core={int(t)for t in re.findall(re.escape(safe)+r'(\d+)',row)};assert all(j<len(inst)for j in core)
  active=gs[k];start=set(range(ng));whole=set(range(len(inst)))
  measures=[('all',whole),('core',core),('previous-32',start|set(t for t,c in past.most_common(32)))]
  for typ,tol in [('head',0),('rare',1),('rare2',2),('direct',10**8)]:
   seen=start.copy();sy=active.copy()
   for dep in range(1,5):
    candidates=set().union(*( (head if typ=='head'else inv)[x]for x in sy))
    for j in candidates:
     if typ=='head'or min(ct[x]for x in sig[j]&sy)<=tol*min(ct[x]for x in sig[j]):seen.add(j)
    sy=active|set().union(*(sig[j]for j in seen))
    if dep in (1,2,3,4):
     measures.append((typ+str(dep),seen.copy()))
     if typ in ('head','rare')and dep in (1,2):measures.append((typ+str(dep)+'+past',seen|set(t for t,c in past.most_common(48))))
  past.update(core);uniq={};qset=[]
  for m,ls in measures:
   selector=tuple(sorted(ls))
   if selector not in uniq:uniq[selector]=len(qset);qset.append(selector)
   sel.append((k,i,m,len(ls),len(inst),len(core),old.get((bi,i),0),uniq[selector],v))
  sets.append(qset);checks+= [ask(g,q)for q in qset]
 p=execute(''.join(checks));reads=p.stdout.splitlines();assert p.returncode==0 and not p.stderr and len(reads)==len(checks),(n,bi,gi,p.returncode,p.stdout[:200],p.stderr[:200]);rat=[];idx=[0,*itertools.accumulate(map(len,sets))]
 for k,i,m,l,full,cor,c,pos,v in sel:
  ans=reads[idx[k]+pos];assert ans in ('sat','unsat','unknown') and(ans!='unsat'or goals[k][1]=='unsat')
  rat.append([n,bi,gi,i,m,l,full,cor,v,ans,c])
 return rat
def rewrite():
 s=inspect.getsource(sg.trial);a=s.index("   text='(set-option");b=s.index(' st.cache_clear();',a);s=s[:a]+'''   ans.extend(evaluate(n,bi,gi,inst,len(ground),goals,prefix,old))
'''+s[b:];ns=sg.__dict__.copy();ns['evaluate']=evaluate;exec(s,ns);return ns['trial']
def task(j):return rewrite()(*j)
def main():
 names=['tlb','arm_rules3','ticket_protocol','hybrid','hermes_rmw_o3']
 for n in names:sg.ctx[n]=sg.context(n)
 with ProcessPoolExecutor(8)as ex,(rd/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('spec batch pool goal selector selected available core oracle result original_instructions'.split());jobs=[]
  for n in names:
   bs=sg.ctx[n][2];old=sg.expensive(n,bs)
   for i,_,_ in bs:jobs.append(ex.submit(task,(n,{i},('constants',0,3),old,'costly')))
  for job in as_completed(jobs):z.writerows(job.result());f.flush()
if __name__=='__main__':main()
