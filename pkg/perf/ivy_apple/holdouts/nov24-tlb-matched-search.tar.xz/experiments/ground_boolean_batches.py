from common import *
import shared_ground_batches as sg,plan_boolean_skeleton as sk,inspect,itertools
from functools import lru_cache
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor,as_completed
rd=d/'ground-boolean-batches';rd.mkdir(exist_ok=True)
def decision(rows,goals,ds,theta):
 e=sk.Kernel(rows,ds);gs=[e.literal(h)for h in goals]
 if theta!='bare':
  sig=defaultdict(dict)
  for a in ds:
   if a[0]=='declare-fun':sig[a[1]][a[2]]=a[3]
  @lru_cache(None)
  def st(x):
   if not isinstance(x,tuple):return sig.get(x,{}).get((),'Bool'if x in ('true','false')else None)
   if x[0]=='ite':return st(x[2])
   if x[0]in ('=','distinct','and','or','not','xor','=>','forall','exists'):return 'Bool'
   return sig.get(x[0],{}).get(tuple(map(st,x[1:])))
  relevant=defaultdict(list);objects=defaultdict(set);dataites=[];seen=set();stack=list(rows)+list(goals)
  while stack:
   h=stack.pop()
   if h in seen:continue
   seen.add(h);ty=st(h)
   if ty and ty!='Bool':objects[ty].add(h)
   if not isinstance(h,tuple)or h[0]in ('forall','exists'):continue
   if h[0]in sig:relevant[h[0],tuple(map(st,h[1:]))].append(h)
   if h[0]=='ite'and ty and ty!='Bool':dataites.append(h)
   stack.extend(h[1:])
  @lru_cache(None)
  def named(x,i):return e.fresh(('term-bit',x,i))
  @lru_cache(None)
  def equal(a,b):
   if a==b:return e.true
   ty=st(a);assert ty==st(b)and ty is not None,(a,b,ty,st(b))
   if ty=='Bool':return e.iff(e.literal(a),e.literal(b))
   return e.conj([e.iff(named(a,i),named(b,i))for i in range(max(1,(len(objects[ty])-1).bit_length()))])
  def constrain(l):e.clauses.append((l,))
  for key,v in list(e.ids.items()):
   if key[0]=='equality':
    a,b=tuple(key[1]);constrain(e.iff(v,equal(a,b)))
  for h in dataites:
   c,a,b=h[1:];l=e.literal(c);constrain(e.disj([-l,equal(h,a)]));constrain(e.disj([l,equal(h,b)]))
  if theta=='congruence':
   # Equality of all arguments entails equality of results for every UF.
   for apps in relevant.values():
    if len(apps)>48:continue
    for a,b in itertools.combinations(apps,2):
     args=[-equal(x,y)for x,y in zip(a[1:],b[1:]) if x!=y];constrain(e.disj(args+[equal(a,b)]))
  eqs=len(e.ids);st.cache_clear();named.cache_clear();equal.cache_clear()
 def lit(l):return ('v'+str(l))if l>0 else('(not v'+str(-l)+')')
 out=['(set-option :timeout 800)'];out+=['(declare-fun v'+str(i)+' () Bool)'for i in range(1,len(e.ids)+1)]
 out+=['(assert '+(lit(cl[0]) if len(cl)==1 else '(or '+' '.join(lit(l)for l in cl)+')')+')'for cl in e.clauses]
 out+=['(assert '+lit(l)+')'for l in e.premises];out+=['(check-sat-assuming ('+lit(l)+'))'for l in gs]
 p=subprocess.run([pkg.parent/'build/z3','-in','-smt2'],input='\n'.join(out)+'\n',text=True,capture_output=True,timeout=120+2*len(goals))
 answers=p.stdout.splitlines();assert p.returncode==0 and not p.stderr and len(answers)==len(goals),(p.stdout[:400],p.stderr)
 e.literal.cache_clear();e.is_bool.cache_clear();return answers,len(e.ids),len(e.clauses)
def adapt():
 t=inspect.getsource(sg.trial);i=t.index("   text='(set-option");j=t.index(' st.cache_clear();',i)
 t=t[:i]+'''   ds=[br.parse(l)[0]for l in prefix.splitlines()if l]
   for theta in ('bare','bits','congruence'):
    try:verdicts,nv,nc=decision(inst,[h for _,_,h in goals],ds,theta)
    except (AssertionError,ValueError) as e:
     if theta!='bare' and n!='tlb':continue
     raise
    for (i,want,h),res in zip(goals,verdicts):
     assert res in ('sat','unsat','unknown') and(res!='unsat' or want=='unsat'), (n,bi,i,mode,theta)
     ans.append([n,bi,i,mode0,extra,bound,gi,len(goals),len(ground),len(inst),nv,nc,theta,want,res,old.get((bi,i),0)])
'''+t[j:];local=sg.__dict__;local['decision']=decision;exec(t,local);return local['trial']
def main():
 names=['tlb','ticket_protocol','alternating_bit_protocol','arm_rules3','test_liveness2','hybrid','hermes_rmw_o3']
 for n in names:sg.ctx[n]=sg.context(n)
 trial=adapt()
 with ProcessPoolExecutor(7)as ex,(rd/'runs.csv').open('w')as out:
  z=csv.writer(out);z.writerow('spec batch goal terms extra width group group_goals ground asserted vars clauses theory expected answer original_instructions'.split());jobs=[]
  for n in names:
   bs=sg.ctx[n][2];old=sg.expensive(n,bs);ids=list(dict.fromkeys(g for g,_,_in in bs))
   for i in range(0,len(ids),2):
    jobs.append(ex.submit(trial,n,set(ids[i:i+2]),('constants',0,3),old,'costly'if old else'all'))
  for f in as_completed(jobs):z.writerows(f.result());out.flush()
if __name__=='__main__':main()
