import json,sys,subprocess
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent
files=json.loads((w.parent/'detail/obs.json').read_text())['Replace']
k=p/'api/api_order_abstraction.go';s=Path(files[str(k)]).read_text()
s=s.replace('order.PriceBegin();defer func(){order.PriceEnd(proved && err==nil)}();','')
a='func (b *OrderProofBatch) Prove() (bool, error) {'
assert s.count(a)==1
s=s.replace(a,'''func (b *OrderProofBatch) Prove() (proved bool, err error) {
    order.PriceBegin();defer func(){order.PriceEnd(proved && err==nil)}();defer order.PriceSection(0)()
    if inc,ok:=b.state.source.solver.(interface{HasInconsistentAssertions() bool});ok && inc.HasInconsistentAssertions(){order.PriceSection(49)()}
''')
dest=w/k.name;dest.write_text(s);files[str(k)]=str(dest)
ov=w/'post.json';ov.write_text(json.dumps({'Replace':files}))
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'observe','./cmd/goivy_check'],cwd=front,check=True)
