from pathlib import Path
from collections import defaultdict,Counter
import sys
w=Path(__file__).resolve().parent
for c in sys.argv[1:]:
 d=defaultdict(list);ground=Counter();history=defaultdict(list);dom=0
 for line in (w/(c+'.log')).read_text().splitlines():
    _,event,i,*s=line.split()
    if event=='subset':
        owner,steps,roots,count,*terms=s
        key=set(terms);dom+=any(key<=old for old in history[owner])
        last=(owner,key)
        d[i].append([int(steps),int(count),'incomplete'])
    if event=='answer':
        d[i][-1][-1]='SAT' if s[0]=='true' else 'UNSAT' if s[1]=='true' else 'unknown'
        if s[0]=='true':history[last[0]].append(last[1])
    if event=='ground':g=tuple(map(int,s))
    if event=='groundend':ground[s[0]]+=1
 outcomes=Counter(tuple((st,a) for st,n,a in seq) for seq in d.values())
 print(c,'SAT supersets',dom,'multiple strategies',[(k,n) for k,n in outcomes.items() if len(k)>1][:25],'ground',ground)
