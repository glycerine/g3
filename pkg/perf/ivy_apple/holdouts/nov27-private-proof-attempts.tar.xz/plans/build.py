from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3]);label=sys.argv[3]
files={}
def put(k,s):
 dst=w/k.name;dst.write_text(s);files[str(k)]=str(dst)
def add(s,imports):
 return s.replace('package api','package api\nimport ('+';'.join('"'+i+'"' for i in imports)+')',1)
k=p/'api/api_order_abstraction.go';s=add(k.read_text(),['fmt','os']);s+='\nvar earlyID int\nvar earlyOn bool\n'
a='p := b.state\n\tdefer func() { p.previousGoalProved'
s=s.replace(a,'earlyID++;earlyOn=true;defer func(){earlyOn=false;fmt.Fprintln(os.Stderr,"PLAN end",earlyID,proved)}();\n '+a);put(k,s)
k=p/'api/api_goal_instances_check.go';s=add(k.read_text(),['fmt','os'])
i=s.index('reuse := p.plans.reusable(parent)',s.index('func (p *orderProofState) checkProofPlan'))
s=s[:i]+'''if earlyOn {if sp,ok:=plan.(*shortPremisePlan);ok {
 fmt.Fprintf(os.Stderr,"PLAN subset %d %p %d %d %d",earlyID,p,maxSteps,len(sp.source),len(sp.selected))
 for _,h:=range sp.selected {fmt.Fprintf(os.Stderr," %d/%d/%d",h.Origin(),h.Slot(),h.Generation())}
 fmt.Fprintln(os.Stderr)
 defer func(){fmt.Fprintln(os.Stderr,"PLAN subsetend",earlyID,proved)}()
 }}
 '''+s[i:]
k2='answer, err := aux.child.Check()';s=s.replace(k2,k2+';if earlyOn {if _,ok:=plan.(*shortPremisePlan);ok {fmt.Fprintln(os.Stderr,"PLAN answer",earlyID,answer==lbool.True,answer==lbool.False)}}');put(k,s)
k=p/'api/api_short_premises.go';s=add(k.read_text(),['fmt','os'])
s=s.replace('groundSteps := min(maxSteps, 400_000)','if earlyOn {fmt.Fprintln(os.Stderr,"PLAN ground",earlyID,len(plan.selected),len(plan.conjuncts))}; groundSteps := min(maxSteps, 400_000)')
s=s.replace('if yes || err != nil || m.ResourceLimit().CancelFlag()', 'if earlyOn {fmt.Fprintln(os.Stderr,"PLAN groundend",earlyID,yes)};if yes || err != nil || m.ResourceLimit().CancelFlag()')
put(k,s)
ov=w/'plans.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=front,check=True)
