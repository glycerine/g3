import csv,sys,statistics,collections
from pathlib import Path
w=Path(__file__).resolve().parent
for case in sys.argv[1:]:
 rows=list(csv.DictReader((w/(case+'.csv')).open()))
 for ok in ['false','true']:
    rs=[r for r in rows if r['proved']==ok]
    if not rs:continue
    d={k:statistics.median(sum(int(x[k]) for x in rs if x['round']==n) for n in sorted({x['round'] for x in rs})) for k in list(rs[0])[3:]}
    print(case,ok,len([r for r in rs if r['round']=='0']),round(sum(d.values())/1e6,2),[(k,round(v/1e6,2)) for k,v in sorted(d.items(),key=lambda x:-x[1])[:6]])
