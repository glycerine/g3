from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;files={}
def save(k,s):
 dst=w/k.name;dst.write_text(s);files[str(k)]=str(dst)
k=p/'api/api_goal_instances_check.go';s=k.read_text();i=s.index('func (p *orderProofState) checkProofPlan(');j=s.index('\nfunc ',i+5);method=s[i:j]
a=method.index('reuse :=')
method=method[:a]+'''answer, err := p.checkProofPlanResult(parent, plan, maxSteps)
    return answer == lbool.False && err == nil, err
}

func (p *orderProofState) checkProofPlanResult(parent *ast.ASTManager, plan privateProofPlan, maxSteps uint32) (answer lbool.LBool, err error) {
    '''+method[a:].replace('return false,','return lbool.Undef,').replace('proved = false','answer = lbool.Undef').replace('answer, err := aux.child.Check()','answer, err = aux.child.Check()').replace('return err == nil && answer == lbool.False, err','return answer, err')
save(k,s[:i]+method+s[j:])
k=p/'api/api_verification_goal.go';s=k.read_text().replace('import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/util/lbool")')
s=s.replace('check := func(subset', 'definitionModel := false\n\tcheck := func(subset')
s=s.replace('return p.checkProofPlan(m, &shortPremisePlan{source: assertions, selected: input}, steps)','''answer,err:=p.checkProofPlanResult(m, &shortPremisePlan{source: assertions, selected: input}, steps)
        if err==nil && answer==lbool.True {definitionModel=true}
        return answer==lbool.False && err==nil,err''')
s=s.replace('var subset []ast.ASTHandle','if definitionModel {return false,nil}\n\tvar subset []ast.ASTHandle')
save(k,s)
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3]);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
