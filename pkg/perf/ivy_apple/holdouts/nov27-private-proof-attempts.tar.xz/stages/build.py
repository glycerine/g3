from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent
front,mod,stage=map(lambda x:Path(x).resolve(),sys.argv[1:4]);which=sys.argv[4]
f=json.loads(stage.read_text())['Replace']
if which!='base':f.update(json.loads((w.parent/which/'trial.json').read_text())['Replace'])
ov=w/(which+'.json');ov.write_text(json.dumps({'Replace':f}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/which,'./cmd/goivy_check'],cwd=front,check=True)
