"""Collect complete Ticket transcripts and separate search census from instruction runs."""
import argparse, csv, json, os, subprocess
from collections import defaultdict
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('golden', type=Path)
p.add_argument('examples', type=Path)
p.add_argument('binaries', nargs='+', help='label=path')
p.add_argument('--rounds', type=int, default=1)
p.add_argument('--trace', action='store_true')
p.add_argument('--cpu', default='14')
a = p.parse_args()
w = Path(__file__).resolve().parent
ref = a.golden / 'reference/ticket_protocol'
path, _, code = json.loads((a.golden/'cases.json').read_text())['ticket_protocol']
binaries = [x.split('=',1) for x in a.binaries]
env = dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(a.examples/'ivy/include'))
if a.trace:
    env.update(G3_WITNESS_TRACE='1',G3_WITNESS_STAGE='yes',G3_WITNESS_INDEX='0')
for rnd in range(a.rounds):
    for label,exe in (binaries if rnd%2==0 else reversed(binaries)):
        run = subprocess.run(['taskset','-c',a.cpu,exe,a.examples/path],cwd=w,env=env,capture_output=True,timeout=120)
        extra = bytearray()
        pending = []
        with (w/(label+'-counts.csv')).open('w' if rnd==0 else 'a') as c, (w/(label+'-events.csv')).open('w' if rnd==0 else 'a') as t:
            counts,events=csv.writer(c),csv.writer(t)
            if rnd==0:
                counts.writerow(['round','batch','goal','phase','instructions'])
                events.writerow(['batch','goal','event','value'])
            for line in run.stderr.splitlines(keepends=True):
                if line.startswith(b'WT ') and a.trace:
                    kind,_,value=line.decode().rstrip()[3:].partition(' ')
                    pending.append((kind,value))
                elif line.startswith(b'STAGE-COUNT '):
                    _,b,g,phase,n,empty,en,active,ns=line.decode().split()
                    assert en==active
                    counts.writerow((rnd,b,g,phase,n))
                    if b in ('6','7','8') and g=='1' and phase=='check':
                        events.writerows((b,g,k,v) for k,v in pending if k in ('formula','split','candidate','offer'))
                    pending.clear()
                else:
                    extra.extend(line)
        assert (run.returncode,run.stdout,bytes(extra))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()), (label,extra[:200])
        print(label,rnd,'verified',flush=True)
