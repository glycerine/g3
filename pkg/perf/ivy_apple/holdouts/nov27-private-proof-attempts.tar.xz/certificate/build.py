from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
k=p/'api/api_goal_instances_check.go';s=k.read_text();key='reuse := p.plans.reusable(parent)'
assert s.count(key)==1
s=s.replace(key,key+'\n if subset,ok:=plan.(*shortPremisePlan);reuse && ok && trialModel(parent, subset.selected) {return false,nil}')
dst=w/k.name;dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(k):str(dst),str(p/'api/constant_model_trial.go'):str(w/'constant.go.txt')}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
