from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
obs=json.loads((w.parent/'plans/plans.json').read_text())['Replace'];base=json.loads((w/'trial.json').read_text())['Replace']
k=next(k for k in obs if k.endswith('api_goal_instances_check.go'));s=Path(obs[k]).read_text()
s=s.replace('if earlyOn {if sp,ok:=plan.(*shortPremisePlan);ok {','if earlyOn {if sp,ok:=plan.(*shortPremisePlan);ok {fmt.Fprintln(os.Stderr,"PLAN model",earlyID,trialModel(parent, sp.selected))')
dst=w/'observer.go';dst.write_text(s);base.update(obs);base[k]=str(dst);ov=w/'coverage.json';ov.write_text(json.dumps({'Replace':base}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/sys.argv[3],'./cmd/goivy_check'],cwd=front,check=True)
