from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).resolve().parent
exe,src,reference,case,spec,cpu=sys.argv[1:]
env=dict(os.environ,GOIVY_INCLUDE=src+'/ivy/include',GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1')
cmd=['taskset','-c',cpu,exe]+(['isolate='+case] if case in ('rfn2','dramc_nb2') else [])+[src+'/'+spec]
r=subprocess.run(cmd,cwd=w,env=env,capture_output=True,timeout=240)
ref=Path(reference);extra=bytearray()
with (w/(case+'.log')).open('wb') as f:
 for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'PLAN '):f.write(line)
    else:extra.extend(line)
assert (r.returncode,r.stdout,bytes(extra))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(r.returncode,extra[:250])
