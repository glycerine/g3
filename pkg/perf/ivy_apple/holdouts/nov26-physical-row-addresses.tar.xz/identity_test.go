package arena

import (
	"encoding/binary"
	"testing"
)

// Payload words deliberately equal the current generation. An interior
// address must still fail, even if it would read a plausible generation.
func TestPhysicalAddressBoundaries(t *testing.T) {
	for size := uint32(8); size < 248; size += 4 {
		a, err := NewClauseBytes(SmallBytesConfig{})
		if err != nil {
			t.Fatal(err)
		}
		live := make(map[Slot]bool)
		var last Slot
		for i := 0; i < 81; i++ {
			ref, err := a.Allocate(size)
			if err != nil || ref.Generation != 1 {
				t.Fatal(size, ref, err)
			}
			b, err := a.Borrow(ref)
			if err != nil || len(b) != int(size) || cap(b) != int(size) {
				t.Fatal(size, ref, len(b), cap(b), err)
			}
			for j := 0; j < len(b); j += 4 {
				binary.LittleEndian.PutUint32(b[j:], 1)
			}
			live[ref.Slot] = true
			last = max(last, ref.Slot)
		}
		for slot := Slot(1); slot <= last+2048; slot++ {
			r := SmallBytesRef{slot, 1}
			if a.IsLive(r) != live[slot] || a.IsLive(SmallBytesRef{slot, 2}) {
				t.Fatalf("size %d slot %d", size, slot)
			}
			if live[slot] {
				if err := a.Deallocate(size, r); err != nil || a.IsLive(r) {
					t.Fatal(size, r, err)
				}
			}
		}
		a.Close()
	}
}
