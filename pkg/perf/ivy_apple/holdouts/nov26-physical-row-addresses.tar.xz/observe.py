"""Build an untimed high-water and wide-watch census for a complete solver."""
from pathlib import Path
import json,subprocess,sys,os
root=Path.cwd()
work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'perf/ivy_raft'))
from watch_propagation import check_output
for variant in sys.argv[1:]:
    out=work/variant/'observer'
    out.mkdir(exist_ok=True)
    changes={} if variant=='base' else json.loads((out.parent/'overlay.json').read_text())['Replace']
    def edit(path,anchor,addition):
        src=root/path
        s=Path(changes.get(str(src),src)).read_text()
        assert s.count(anchor)==1,anchor
        target=out/src.name
        target.write_bytes(subprocess.check_output(['gofmt'],input=s.replace(anchor,anchor+addition).encode()))
        changes[str(src)]=str(target)
    edit('arena/clause_pages.go','a.requested += uint64(size)','\n    StudyPeakArena=max(StudyPeakArena,a.resident+a.directory);StudyPeakRequested=max(StudyPeakRequested,a.requested);StudyMaxPages=max(StudyMaxPages,len(a.pages))')
    edit('arena/clause_pages.go','type clausePageClasses [clausePageDirectSize / 4]clausePageClass','\nvar StudyPeakArena,StudyPeakRequested uint64\nvar StudyMaxPages int\n')
    edit('sat/sat_solver_propagation.go','bits := data[pos]','\n if bits.val2&3==2 {StudyVisits++;if bits.val1>>satWatchSlotBits==satWatchWide {StudyWide++; if iter.backing.wide.values[pos].slot >= 1<<satWatchSlotBits {StudySlotWide++}}}')
    edit('sat/sat_watch_backing.go','type satWideWatchOffsets struct{ values []satClauseOffset }','\nvar StudyVisits,StudyWide,StudySlotWide uint64\n')
    main=(root/'cmd/g3/main.go').read_text()
    if '"github.com/glycerine/g3/pkg/arena"' not in main:edit('cmd/g3/main.go','import (','\n"github.com/glycerine/g3/pkg/arena"')
    edit('cmd/g3/main.go','stopProfile()\n','println("ROW-STUDY",arena.StudyPeakArena,arena.StudyPeakRequested,arena.StudyMaxPages,sat.StudyVisits,sat.StudyWide,sat.StudySlotWide)\n')
    f=out/'overlay.json';f.write_text(json.dumps({'Replace':changes}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',f,'-o',out/'g3','./cmd/g3'],check=True)
    records={}
    for name,status in [('random-208-3','unsat'),('random-208-4','sat'),('pigeon8-s0','unsat')]:
        fixture=root/'build/.nov26-clause-locality/fixtures'/(name+'.cnf')
        run=subprocess.run([out/'g3','-v:2','-st','-dimacs',fixture],capture_output=True,text=True,env=dict(os.environ,GOMAXPROCS='1'),timeout=120)
        if run.returncode not in (0,10 if status=='sat' else 20):raise ValueError(run.stderr)
        rows=[r for r in fixture.read_text().splitlines() if r and not r.startswith('c')]
        variables,count=map(int,rows[0].split()[2:])
        clauses=[list(map(int,r.split()[:-1])) for r in rows[1:]]
        assert len(clauses)==count
        stats=check_output(run.stdout,status,variables,clauses)
        observed={k:stats.get(k,0) for k in ('decisions','conflicts','propagations','ternary-propagations','binary-propagations')}
        lines=[r.split()[1:] for r in run.stderr.splitlines() if r.startswith('ROW-STUDY ')]
        assert len(lines)==1
        records[name]=dict(zip(('arena_bytes','requested_bytes','max_pages','long_visits','wide_visits','large_slot_visits'),map(int,lines[0])),stats=observed)
        if variant!='base':
            ref=json.loads((work/'base/observation.json').read_text())[name]
            assert observed==ref['stats'] and records[name]['long_visits']==ref['long_visits']
    (out.parent/'observation.json').write_text(json.dumps(records,indent=2)+'\n')
