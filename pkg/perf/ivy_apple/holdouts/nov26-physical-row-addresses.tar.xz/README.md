# Physical address, generation and borrow experiments

Baseline solver c11bbd0d1 on optmore. Work from pkg/ using the Go 1.27.3 toolchain, linux/amd64. The reference machine was a Threadripper 3960X. Extract this archive's files into an ignored scratch directory outside the package source directories. All builders emit overlays and binaries beside themselves. The native reference is this fork's build/z3. Tests and verifier runs require the repository's local Go module replacements.

trial.py word, aligned and inverse each build an address consisting of a page index and an 11-bit word offset inside an 8 KiB page. The packed variant checks the exact row boundary by division. The aligned version rounds physical strides to the next power of two, keeps the exact payload width and checks alignment by a mask. The inverse version multiplies by a precomputed inverse of the odd stride factor and rotates by the power-of-two factor. Only positions whose reconstructed index is below the allocated row count are valid. All three keep full generation validation. Their 32-bit address space also holds fewer pages than the released representation.

generation.py prefix and inline compare dense row IDs with generations in a page prefix or directory record. lookup.py builds lookup, bounded, split and compact variants on the dense layout. shared.py and release.py depend on the original baseline only. physical.py uses the shared output. Some experiments expose extra arena methods solely in the overlay. fast.py uses the shared output to try a separate cold function. flat.py moves fallback handling inside the out-of-range page branch. slice.py tail and absolute use the flat output. Compiler inlining and code placement differ between variants.

Run the following from pkg/, replacing S with the actual scratch directory and selecting an available CPU. Input files are in nov26-clause-locality.tar.xz. pigeon8-s2 is in nov26-sat-arena-hot.tar.xz. All measurement binaries use -buildvcs=false -pgo=off -mod=readonly. The archive nov26-native-watch-census.tar.xz contains measure.py, summary.py and verify.py.

    python3 S/trial.py word
    python3 S/trial.py aligned
    python3 S/trial.py inverse
    python3 S/generation.py prefix
    python3 S/generation.py inline
    python3 S/population.py base word aligned inverse prefix inline
    python3 S/tests.py base word aligned inverse prefix inline
    python3 S/observe.py base aligned inverse
    python3 S/cost.py --cpu CPU base word aligned inverse > cost.csv
    python3 S/slopes.py cost.csv

observe.py expects fixtures in build/.nov26-clause-locality/fixtures. It counts long-watch visits, all full-width visits and visits requiring a large slot. It records the largest physical-page and directory byte charge for one allocator and the maximum outstanding requested bytes. Peaks may occur at different times. It checks every SAT model, the expected exit status, five search counters and total long-watch visits across variants. The generated observers run outside the timing panel.

The population test retains real pooled SAT clauses and two actual watch entries per clause. It cycles widths 4–36 across 128 watch lists per allocator and takes forced-GC heap snapshots. The row boundary oracle writes generation-like words throughout live payloads and probes every candidate slot across 61 payload sizes, including holes, stale generations and addresses beyond the last issued row. The inline-directory experiment adapts only the generation-exhaustion fixture's internal test injection. Production SAT and arena suites run in each tests.py trial.

cost.py compiles a separate arena test executable per layout. The same 16,384 allocated rows are shuffled in both routes. Lookup calls the actual Borrow method and reads a word. SavedView reads the same word via a prevalidated slice, with no intervening allocator changes. Each instruction slope uses two process counts at 8 and 128 benchmark iterations, divided by 120 × 16,384 reads. GOMAXPROCS=1 and GOGC=off. The saved-view control does not include the memory or lifetime management costs of implementing such a scheme in production.

The DIMACS panels use rotated executable order, taskset, -v:2 -st -dimacs and perf stat. measure.py checks every SAT model and all five search counters. Different panels can be on separate CPUs concurrently. Each CSV records individual runs. panel.csv is the three-rotation address comparison. generations.csv, lookup.csv, compact.csv, shared.csv, fast.csv and slice.csv are follow-up prototypes. flat.csv uses seven rotations on the hard pair, ordinary pigeonhole and random-256 stdin. holdout.csv is the release rebuild with the second pigeonhole ordering, random-256 and planted8. verifiers.csv uses five rotations of four complete GoIvy verifiers (07cdeec61, local g3 replacement, xtrace_off) and checks expected stdout, stderr and exit codes. See also the confirmation timing panels.

confirm.csv compares the actual release rebuild with the previous binary and in-tree native Z3 on a second CPU in seven rotations. planted-gc.csv records 31 pairs with GODEBUG=gctrace=1 and includes the count of completed collections printed on stderr. planted-off.csv repeats 15 pairs with GOGC=off. The production arena benchmark is available directly under arena/clause_pages_benchmark_test.go. All values in the report's MB table are decimal megabytes.
