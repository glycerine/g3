"""Slope of whole-process user instructions and cycles for shuffled validated reads."""
from pathlib import Path
import argparse,csv,io,json,os,subprocess,sys
p=argparse.ArgumentParser()
p.add_argument('--perf',default='perf')
p.add_argument('--cpu',required=True)
p.add_argument('--rounds',type=int,default=5)
p.add_argument('variants',nargs='+')
a=p.parse_args()
root=Path.cwd()
work=Path(__file__).resolve().parent
for v in a.variants:
    out=work/v
    o={} if v=='base' else json.loads((out/'overlay.json').read_text())['Replace']
    o[str(root/'arena/clause_pages_benchmark_test.go')]=str(work/'cost_test.go')
    f=out/'cost.json';f.write_text(json.dumps({'Replace':o}))
    subprocess.run(['go','test','-pgo=off','-overlay',f,'-c','-o',out/'arena.test','./arena'],check=True)
w=csv.writer(sys.stdout);w.writerow(('round','variant','route','N','instructions','cycles'))
for i in range(a.rounds):
    for v in a.variants[i%len(a.variants):]+a.variants[:i%len(a.variants)]:
        for route in (('Lookup','SavedView') if i%2==0 else ('SavedView','Lookup')):
            for n in ((8,128) if i%2==0 else (128,8)):
                args=['taskset','-c',a.cpu,a.perf,'stat','-x,','-e','instructions:u,cycles:u','--',work/v/'arena.test','-test.run=^$','-test.bench=^BenchmarkPhysicalRowLookup$/^'+route+'$','-test.benchtime='+str(n)+'x']
                r=subprocess.run(args,capture_output=True,text=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'),check=True)
                if '16384 reads/op' not in r.stdout: raise ValueError(r.stdout)
                rows={x[2]:int(x[0]) for x in csv.reader(io.StringIO(r.stderr)) if len(x)>4 and x[2] in ('instructions:u','cycles:u') and float(x[4])==100}
                w.writerow((i+1,v,route,n,rows['instructions:u'],rows['cycles:u']));sys.stdout.flush()
