package sat

import (
	"fmt"
	"github.com/glycerine/g3/pkg/arena"
	"runtime"
	"testing"
)

// Each independent allocator owns the actual clause payloads and two watch
// entries per clause. Keep all watches live across the second forced GC.
func TestSATPhysicalAddressPopulation(t *testing.T) {
	live := func() int64 {
		runtime.GC()
		var m runtime.MemStats
		runtime.ReadMemStats(&m)
		return int64(m.HeapAlloc)
	}
	for _, fixture := range []struct{ workers, clauses int }{{128, 512}, {1, 600000}} {
		t.Run(fmt.Sprintf("%dx%d", fixture.workers, fixture.clauses), func(t *testing.T) {
			before := live()
			owners := make([]*ClauseAllocator, fixture.workers)
			stores := make([]*satSolverWatchStore, fixture.workers)
			var spill, rows, resident, directory, maxSlot uint64
			for i := range owners {
				budget := arena.NewBudget(^uint64(0))
				a, err := NewSATClauseAllocator(satClauseAllocatorConfig{Storage: arena.SmallBytesConfig{Descriptors: arena.Config{Budget: budget}}})
				satOK(t, err)
				store, err := newSATSolverWatchStore(budget)
				satOK(t, err)
				var lists [128]satSolverWatchListRef
				for j := range lists {
					lists[j], err = store.NewList()
					satOK(t, err)
				}
				var lits [36]Literal
				for j := range lits {
					lits[j] = Literal(j * 2)
				}
				for j := 0; j < fixture.clauses; j++ {
					width := 4 + j%33
					ref, err := a.MkClause(lits[:width], true)
					satOK(t, err)
					maxSlot = max(maxSlot, uint64(ref.slot))
					for side := 0; side < 2; side++ {
						w, err := newSATClauseWatch(lits[side], satClauseOffset(ref))
						satOK(t, err)
						satOK(t, store.Push(lists[(j+side*63)%len(lists)], w))
					}
				}
				for _, r := range lists {
					record, err := store.record(r)
					satOK(t, err)
					for _, w := range record.backing.data {
						if w.val1>>satWatchSlotBits == satWatchWide {
							spill++
						}
						rows++
					}
				}
				stats := a.storage.Stats()
				resident += stats.PayloadBytes + stats.MetadataBytes
				directory += stats.DirectoryBytes
				owners[i], stores[i] = a, store
			}
			delta := live() - before
			t.Logf("live-bytes=%d page-bytes=%d directory-bytes=%d slots-max=%d wide-watches=%d watches=%d", delta, resident, directory, maxSlot, spill, rows)
			for i, a := range owners {
				satOK(t, stores[i].Close())
				satOK(t, a.Close())
			}
		})
	}
}
