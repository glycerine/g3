"""Route unaddressable pages through compatibility and error handling."""
from pathlib import Path
import json,subprocess
root=Path.cwd()
out=Path(__file__).resolve().parent/'flat'
out.mkdir(exist_ok=True)
src=root/'arena/clause_pages.go'
s=src.read_text()
a=s.index('if a.compat != nil {',s.index('func (a *ClauseBytes) Borrow('))
b=s.index('n := uint32(r.Slot) - 1',a)
guards=s[a:b]
s=s[:a]+s[b:]
s=s.replace('if uint64(page) >= uint64(len(a.pages)) || r.Generation == 0 {','if uint64(page) >= uint64(len(a.pages)) {\n'+guards+'\n')
s=s.replace('if index >= p.taken {','if index >= p.taken || r.Generation == 0 {')
file=out/src.name
file.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(file)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
