from pathlib import Path
import json,subprocess,sys
root=Path.cwd()
work=Path(__file__).resolve().parent
for variant in sys.argv[1:]:
    out=work/variant
    out.mkdir(exist_ok=True)
    overlay={} if variant=='base' else json.loads((out/'overlay.json').read_text())['Replace']
    overlay[str(root/'sat/physical_address_population_test.go')]=str(work/'population_test.go')
    file=out/'pop.json'
    file.write_text(json.dumps({'Replace':overlay}))
    with (out/'population.txt').open('w') as log:
        subprocess.run(['go','test','-overlay',file,'-count=1','-run','^TestSATPhysicalAddressPopulation$','-v','./sat'],stdout=log,check=True)
