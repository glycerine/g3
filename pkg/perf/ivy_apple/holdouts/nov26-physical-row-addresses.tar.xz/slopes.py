"""Median high-minus-low counter slope per validated read."""
import csv,collections,statistics as st,sys
d=collections.defaultdict(dict)
for filename in sys.argv[1:]:
    for r in csv.DictReader(open(filename)):
        for key in ('instructions','cycles'):
            d[r['variant'],r['route'],r['round'],key][int(r['N'])]=int(r[key])
v=collections.defaultdict(list)
for (variant,route,turn,key),x in d.items():
    v[variant,route,key].append((x[128]-x[8])/(120*16384))
for variant,route in sorted({(a,b) for a,b,c in v}):
    print(variant,route,*(round(st.median(v[variant,route,key]),2) for key in ('instructions','cycles')))
