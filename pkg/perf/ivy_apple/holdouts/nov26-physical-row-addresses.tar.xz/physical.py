from pathlib import Path
import json,subprocess
root=Path.cwd()
base=Path(__file__).resolve().parent
out=base/'physical'
out.mkdir(exist_ok=True)
changes={}
for name in ('arena/clause_pages.go','sat/sat_solver_propagation.go'):
    src=root/name
    s=(base/'shared'/src.name).read_text()
    if name.startswith('arena/'):
        s+='''
// UsesPhysicalPages reports whether the allocator stores rows in physical pages.
func (a *ClauseBytes) UsesPhysicalPages() bool {return a.classes!=nil}
'''
    else:
        s=s.replace('iter.backing.owner == a.origin {','iter.backing.owner == a.origin && a.storage.UsesPhysicalPages() {')
        anchor='''}
				if clause == nil {
					clause, e = s.clauses.view(c)
				}
				if e != nil {
					return false, e
				}'''
        assert s.count(anchor)==1
        s=s.replace(anchor,'''    if clause==nil {return false,arena.ErrInvalidSlot}
                } else {
                    clause,e=s.clauses.view(c)
                    if e!=nil {return false,e}
                }''')
    target=out/src.name
    target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    changes[str(src)]=str(target)
file=out/'overlay.json'
file.write_text(json.dumps({'Replace':changes}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',file,'-o',out/'g3','./cmd/g3'],check=True)
