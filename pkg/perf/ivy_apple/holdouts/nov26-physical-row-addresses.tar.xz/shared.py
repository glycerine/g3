"""Use one checked row lookup in propagation and ordinary arena borrowing."""
import json,subprocess
from pathlib import Path
root=Path.cwd()
out=Path(__file__).resolve().parent/'shared'
out.mkdir(exist_ok=True)
changes={}
def emit(src,s):
    target=out/src.name
    target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    changes[str(src)]=str(target)
src=root/'arena/clause_pages.go'
s=src.read_text()
a=s.index('n := uint32(r.Slot) - 1',s.index('func (a *ClauseBytes) Borrow('))
b=s.index('\n}',a)
s=s[:a]+'''if data:=a.TryBorrowPooled(r.Slot, r.Generation);data!=nil {
        return data,nil
    }
    return nil,ErrInvalidSlot
}

// TryBorrowPooled returns the exact payload for a live physical row. It returns
// nil for stale references, closed arenas and configurations using SmallBytes.
func (a *ClauseBytes) TryBorrowPooled(slot Slot,generation Generation) []byte {
    n:=uint32(slot)-1
    if n>>clausePageShift < uint32(len(a.pages)) {
        p:=&a.pages[n>>clausePageShift]
        if n&(clausePageSlots-1) < p.taken {
            start:=(n&(clausePageSlots-1))*p.stride
            end:=start+p.stride
            row:=p.data[start:end:end]
            if generation!=0 && binary.LittleEndian.Uint32(row)==uint32(generation) {
                return row[clausePageHeaderBytes:]
            }
        }
    }
    return nil'''+s[b:]
emit(src,s)
src=root/'sat/sat_solver_propagation.go'
s=src.read_text().replace('clause, e = common.Borrow(','clause = common.TryBorrowPooled(').replace('Generation: arena.Generation(off.generation)})\n\t\t\t\t} else {','Generation: arena.Generation(off.generation)})\n                }\n                if clause==nil {')
s=s.replace('common.TryBorrowPooled(arena.SmallBytesRef{Slot: arena.Slot(off.slot), Generation: arena.Generation(off.generation)})','common.TryBorrowPooled(arena.Slot(off.slot),arena.Generation(off.generation))')
emit(src,s)
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':changes}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
