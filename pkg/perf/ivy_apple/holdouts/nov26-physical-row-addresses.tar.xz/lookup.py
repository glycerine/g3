"""Try a validated physical-only lookup with a checked fallback at the SAT caller."""
from pathlib import Path
import argparse,json,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('variant',choices=['lookup','bounded','split','compact'])
a=p.parse_args()
root=Path.cwd()
out=Path(__file__).resolve().parent/a.variant
out.mkdir(exist_ok=True)
changes={}
def emit(src,s):
    target=out/src.name
    target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    changes[str(src)]=str(target)
src=root/'arena/clause_pages.go'
s=src.read_text()
body='''
    n:=uint32(slot)-1
    if uint64(n>>clausePageShift)>=uint64(len(a.pages)) {return nil}
    p:=&a.pages[n>>clausePageShift]
    index:=n & (clausePageSlots-1)
    start:=index*p.stride
    end:=start+p.stride
    if index>=p.taken {return nil}
    row:=p.data[start:end:end]
'''
if a.variant=='bounded':body=body.replace('index>=p.taken','end>uint32(len(p.data))')
decl='''
// LookupPooled returns the exact payload of a live physical row. Other storage
// configurations and invalid references return nil.
func (a *ClauseBytes) LookupPooled(slot Slot,generation Generation) []byte {
'''
check='''if generation==0 || binary.LittleEndian.Uint32(row)!=uint32(generation) {return nil}
    return row[clausePageHeaderBytes:]
}
'''
if a.variant=='split':
    decl+='''row:=a.physicalRow(slot)
    if row==nil {return nil}
    '''+check+'''
func (a *ClauseBytes) physicalRow(slot Slot) []byte {'''
    check='return row\n}\n'
if a.variant=='compact':
    body='''
    n:=uint32(slot)-1
    if n>>6 < uint32(len(a.pages)) {
        p:=&a.pages[n>>6]
        if n&63 < p.taken {
            start:=(n&63)*p.stride
            end:=start+p.stride
            row:=p.data[start:end:end]
            if generation!=0 && binary.LittleEndian.Uint32(row)==uint32(generation) {
                return row[4:]
            }
        }
    }
    return nil
}
'''
    check=''
emit(src,s+decl+body+check)
src=root/'sat/sat_solver_propagation.go'
s=src.read_text()
anchor='clause, e = common.Borrow(arena.SmallBytesRef{Slot: arena.Slot(off.slot), Generation: arena.Generation(off.generation)})\n\t\t\t\t} else {'
assert s.count(anchor)==1
s=s.replace(anchor,'clause=common.LookupPooled(arena.Slot(off.slot),arena.Generation(off.generation))\n                }\n                if clause==nil {')
emit(src,s)
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':changes}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
