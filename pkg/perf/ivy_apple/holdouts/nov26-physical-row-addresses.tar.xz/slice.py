"""Measure address arithmetic and the final capacity-limited slice on dense row IDs."""
from pathlib import Path
import json,subprocess,sys
root=Path.cwd();base=Path(__file__).resolve().parent
v=sys.argv[1];out=base/v;out.mkdir(exist_ok=True)
src=root/'arena/clause_pages.go'
s=(base/'flat'/src.name).read_text()
start=s.index('start := index * p.stride',s.index('func (a *ClauseBytes) Borrow'))
end=s.index('\n}',start)
if v=='tail':
    b='''tail:=p.data[index*p.stride:]
        if binary.LittleEndian.Uint32(tail)!=uint32(r.Generation){return nil,ErrInvalidSlot}
        return tail[clausePageHeaderBytes:p.stride:p.stride],nil'''
elif v=='absolute':
    b='''start:=uint64(index)*uint64(p.stride)
        if binary.LittleEndian.Uint32(p.data[start:])!=uint32(r.Generation){return nil,ErrInvalidSlot}
        end:=start+uint64(p.stride)
        return p.data[start+clausePageHeaderBytes:end:end],nil'''
else:raise ValueError(v)
s=s[:start]+b+s[end:]
file=out/src.name;file.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json';overlay.write_text(json.dumps({'Replace':{str(src):str(file)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
