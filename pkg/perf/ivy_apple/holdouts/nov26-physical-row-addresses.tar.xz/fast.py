"""Use the physical lookup first and leave compatibility and errors on a cold path."""
from pathlib import Path
import json,subprocess
root=Path.cwd()
base=Path(__file__).resolve().parent
out=base/'fast'
out.mkdir(exist_ok=True)
src=root/'arena/clause_pages.go'
s=(base/'shared'/src.name).read_text()
a=s.index('if a.compat != nil {',s.index('func (a *ClauseBytes) Borrow('))
b=s.index('// TryBorrowPooled',a)
lookup=s.index('func (a *ClauseBytes) TryBorrowPooled',b)
body=s.index('n := uint32(slot) - 1',lookup)
end=s.index('\n}',body)
fast=s[body:end].replace('uint32(slot)','uint32(r.Slot)').replace('generation != 0','r.Generation != 0').replace('uint32(generation)','uint32(r.Generation)').replace('return row[clausePageHeaderBytes:]','return row[clausePageHeaderBytes:],nil').replace('return nil','return a.borrowMiss(r)')
miss=s[a:s.index('if data := a.TryBorrowPooled',a)]+'return nil,ErrInvalidSlot'
s=s[:a]+fast+'\n}\n\nfunc (a *ClauseBytes) borrowMiss(r SmallBytesRef) ([]byte,error) {\n'+miss+s[end:]
target=out/src.name
target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
file=out/'overlay.json'
file.write_text(json.dumps({'Replace':{str(src):str(target)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',file,'-o',out/'g3','./cmd/g3'],check=True)
