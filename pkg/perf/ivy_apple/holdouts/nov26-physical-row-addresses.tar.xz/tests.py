"""Verify exact row start membership and the production SAT and arena suites."""
from pathlib import Path
import json,subprocess,sys
root=Path.cwd()
work=Path(__file__).resolve().parent
for variant in sys.argv[1:]:
    out=work/variant
    overlay={} if variant=='base' else json.loads((out/'overlay.json').read_text())['Replace']
    overlay[str(root/'arena/physical_address_boundary_test.go')]=str(work/'identity_test.go')
    if variant=='inline':
        # The exhaustion fixture seeds a full generation without billions of reuses.
        file=root/'arena/clause_pages_test.go'
        tests=file.read_text().replace('"encoding/binary"','').replace('binary.LittleEndian.PutUint32(page.data, uint32(first.Generation))','page.generations[0]=uint32(first.Generation)')
        (out/file.name).write_text(tests)
        overlay[str(file)]=str(out/file.name)
    file=out/'tests.json'
    file.write_text(json.dumps({'Replace':overlay}))
    with (out/'tests.txt').open('w') as log:
        subprocess.run(['go','test','-overlay',file,'-count=1','./arena','./sat'],stdout=log,check=True)
