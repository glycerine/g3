"""Keep dense row IDs and validate their generations alongside each page."""
from pathlib import Path
import argparse,json,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('variant',choices=['prefix','inline'])
a=p.parse_args()
root=Path.cwd()
out=Path(__file__).resolve().parent/a.variant
out.mkdir(exist_ok=True)
src=root/'arena/clause_pages.go'
s=src.read_text()
s=s.replace('clausePageChunkBytes/stride','clausePageChunkBytes/(stride+clausePageHeaderBytes)')
s=s.replace('stride := size + clausePageHeaderBytes','stride := size')
s=s.replace('index*stride + clausePageHeaderBytes','index*stride')
s=s.replace('binary.LittleEndian.PutUint32(page.data[index*stride:], generation)','GEN_STORE')
s=s.replace('binary.LittleEndian.PutUint32(p.data[index*p.stride:], 0)','GEN_RESET')
start=s.index('if index >= p.taken {',s.index('func (a *ClauseBytes) Borrow'))
end=s.index('\n}',start)
if a.variant=='prefix':
    s=s.replace('uint64(count) * uint64(stride)','uint64(count) * uint64(stride+clausePageHeaderBytes)').replace('uint64(page.count) * uint64(stride)','uint64(page.count) * uint64(stride+clausePageHeaderBytes)')
    s=s.replace('start := index*stride','start := 4*page.count + index*stride')
    body='''if index >= p.taken || binary.LittleEndian.Uint32(p.data[4*index:]) != uint32(r.Generation) {
        return nil, ErrInvalidSlot
    }
    start:=4*p.count+index*p.stride
    end:=start+p.stride
    return p.data[start:end:end],nil'''
    s=s.replace('GEN_STORE','binary.LittleEndian.PutUint32(page.data[4*index:],generation)').replace('GEN_RESET','binary.LittleEndian.PutUint32(p.data[4*index:],0)')
else:
    s=s.replace('_               uint64 // Keep the directory stride at 64 bytes on amd64.','generations [clausePageSlots]uint32')
    body='''if p.generations[index] != uint32(r.Generation) {
        return nil, ErrInvalidSlot
    }
    start:=index*p.stride
    end:=start+p.stride
    return p.data[start:end:end],nil'''
    s=s.replace('GEN_STORE','page.generations[index]=generation').replace('GEN_RESET','p.generations[index]=0')
    s=s.replace('generations += uint64(p.count) * clausePageHeaderBytes','// Generation bytes are charged in the directory.')
start=s.index('if index >= p.taken {',s.index('func (a *ClauseBytes) Borrow'))
end=s.index('\n}',start)
s=s[:start]+body+s[end:]
target=out/src.name
target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(target)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
