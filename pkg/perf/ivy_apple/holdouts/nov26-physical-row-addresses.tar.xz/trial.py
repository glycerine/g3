"""Build a scratch Go overlay for a physical clause address experiment."""
from pathlib import Path
import argparse,json,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('variant',choices=['word','aligned','inverse'])
p.add_argument('--test',action='store_true')
a=p.parse_args()
root=Path.cwd()
out=Path(__file__).resolve().parent/a.variant
out.mkdir(exist_ok=True)
src=root/'arena/clause_pages.go'
s=src.read_text()
s=s.replace('clausePageShift       = 6','clausePageShift       = 11').replace('clausePageSlots       = 1 << clausePageShift','clausePageSlots       = 64')
s=s.replace('/clausePageSlots {','/(1<<clausePageShift) {').replace('(pageID-1)*clausePageSlots + index + 1','((pageID-1)<<clausePageShift) + index*(stride/4) + 1')
s=s.replace('index := n & (clausePageSlots - 1)\n\tif index >= p.taken {','start := (n & ((1<<clausePageShift)-1))*4\n\tif start % p.stride != 0 || start >= p.taken*p.stride {').replace('\n\tstart := index * p.stride','')
s=s.replace('index := n & (clausePageSlots - 1)\n\tp := &a.pages[page]','p := &a.pages[page]\n index := ((n & ((1<<clausePageShift)-1))*4)/p.stride')
if a.variant=='aligned':
    s=s.replace('"reflect"','"reflect"\n"math/bits"').replace('_               uint64','width,unused uint32')
    s=s.replace('addPage(stride, preferred uint32)','addPage(stride, preferred, width uint32)').replace('stride: stride, count: count,','stride: stride, width:width, count: count,')
    s=s.replace('stride := size + clausePageHeaderBytes','stride := uint32(1)<<bits.Len32(size+clausePageHeaderBytes-1)')
    s=s.replace('a.addPage(stride, preferred)','a.addPage(stride, preferred,size)')
    s=s.replace('start % p.stride != 0','start & (p.stride-1) != 0').replace('end := start + p.stride','end := start + clausePageHeaderBytes + p.width')
if a.variant=='inverse':
    s=s.replace('"reflect"','"reflect"\n"math/bits"').replace('_               uint64','inverse,shift uint32')
    anchor='a.pages = append(a.pages, clausePage{'
    s=s.replace(anchor,'''shift:=uint32(bits.TrailingZeros32(stride))
    odd:=stride>>shift
    inverse:=odd
    for range 4 {inverse*=2-odd*inverse}
    '''+anchor).replace('stride: stride, count: count,','stride: stride, inverse:inverse,shift:shift,count: count,')
    s=s.replace('start % p.stride != 0 || start >= p.taken*p.stride', 'bits.RotateLeft32(start*p.inverse,-int(p.shift)) >= p.taken')
target=out/src.name
target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(target)}}))
if a.test:
    subprocess.run(['go','test','-overlay',overlay,'-count=1','./sat','./arena'],check=True)
else:
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
