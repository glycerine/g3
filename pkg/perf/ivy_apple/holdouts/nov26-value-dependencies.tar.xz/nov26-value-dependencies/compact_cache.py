"""Try keeping a few identity entries in the existing activity queue."""
import argparse
import json
from pathlib import Path
import subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('capacities',type=int,nargs='+',choices=(4,8))
p.add_argument('--cli',action='store_true')
a=p.parse_args()
pkg=Path.cwd()
ivy=Path.home()/'ivy/goivy'
root=Path(__file__).resolve().parent
cache='ast/ast_activity_cache.go'
core='ast/rewriter/rewriter_core.go'
engine='ast/rewriter/rewriter_engine.go'
for capacity in a.capacities:
    out=root/('short-'+str(capacity))
    out.mkdir(exist_ok=True)
    paths={}
    def edit(file, old, new):
        src=pkg/file
        text=paths.get(src,src).read_text()
        assert text.count(old)==1,(file,old)
        dst=out/src.name
        dst.write_bytes(subprocess.check_output(['gofmt'],input=text.replace(old,new).encode()))
        paths[src]=dst
    edit(core,'proofGen, cancelCheck bool','proofGen, cancelCheck bool\ninlineIdentity bool')
    edit(core,'c.traceCacheAllocated(v, line)','if c.inlineIdentity { v.EnableShortIdentity() }\n c.traceCacheAllocated(v, line)')
    edit(engine,'r.skipResumeCacheProbe = r.substituteVariables || theory && !proofGen && !ast.ASTValidateHandles && !ast.ASTSourceDebug',
                'r.skipResumeCacheProbe = r.substituteVariables || theory && !proofGen && !ast.ASTValidateHandles && !ast.ASTSourceDebug\n r.core.inlineIdentity = theory && !proofGen')
    edit(cache,'closed    bool','closed    bool\n shortEnabled bool')
    edit(cache,'pending       bool','pending       bool\n shortAccess uint8')
    edit(cache,'func (c *ActivityCache) open() error {','''const maxShortActivity = SIZE

func (c *ActivityCache) EnableShortIdentity() {
    c.shortEnabled = !astValidateHandles && !ASTSourceDebug && c.manager.TraceStream == nil
}

func (c *ActivityCache) spillIdentity() {
    for i,key:=range c.queue {
        hash:=c.manager.nodeAt(key.slot).hash
        c.table.prepareInsert()
        entry:=c.table.put(key,hash,true)
        entry.value=key
        entry.keyHeld,entry.valueHeld=true,true
        entry.dummy=false
        entry.accessed=c.shortAccess&(1<<i)!=0
    }
    c.shortAccess=0
}

func (c *ActivityCache) tryReleaseIdentity() bool {
    if !c.manager.lockFree() {return false}
    var nodes [maxShortActivity]*astNodeRecord
    for i,key:=range c.queue {
        node:=c.manager.nodeAt(key.slot)
        if !node.live || node.generation!=key.generation || node.rc<=2 {return false}
        nodes[i]=node
    }
    for _,node:=range nodes[:len(c.queue)] {node.rc-=2}
    c.shortAccess=0
    c.queue=c.queue[:0]
    c.unused=0
    return true
}

func (c *ActivityCache) open() error {'''.replace('SIZE',str(capacity)))
    edit(cache,'if c.unused >= c.maxUnused {','''if c.shortEnabled && c.table.slots==0 {
        if ready && key==value && !key.slotIsZeroForInline() {
            for _, prev:=range c.queue {
                if prev==key { return nil }
            }
            if len(c.queue)<maxShortActivity {
                keyNode.rc+=2
                c.queue=append(c.queue,key)
                c.unused++
                return nil
            }
        }
        c.spillIdentity()
    }
    if c.unused >= c.maxUnused {'''.replace('!key.slotIsZeroForInline()', 'key.slot!=0'))
    edit(cache,'entry := c.table.find(astNodeRef{k.slot, k.generation}, hash)','''key:=astNodeRef{k.slot,k.generation}
    if c.shortEnabled && c.table.slots==0 {
        for i, prev:=range c.queue {
            if prev==key {
                mask:=uint8(1<<i)
                if c.shortAccess&mask==0 {
                    c.shortAccess|=mask
                    c.unused--
                }
                return k,nil
            }
        }
        return ASTHandle{},nil
    }
    entry := c.table.find(key, hash)''')
    edit(cache,'if c.incomingHeld {\n\t\tconsumed, e := c.manager.DecRefHeldConsumed(c.incoming)', '''if c.shortEnabled && c.table.slots == 0 && len(c.queue) != 0 {
        if c.tryReleaseIdentity() {return nil}
        c.spillIdentity()
    }
    if c.incomingHeld {
        consumed,e:=c.manager.DecRefHeldConsumed(c.incoming)''')
    edit(cache,'return uint32(c.table.size), nil','''if c.shortEnabled && c.table.slots==0 {return uint32(len(c.queue)),nil}
    return uint32(c.table.size),nil''')
    if not a.cli:
        for src,dst in list(paths.items()):
            paths[Path.home()/'g3/pkg'/src.relative_to(pkg)]=dst
    overlay=out/('g3.json' if a.cli else 'goivy.json')
    overlay.write_text(json.dumps({'Replace': {str(k):str(v) for k,v in paths.items()}}))
    exe='g3' if a.cli else 'goivy_check'
    target=['./cmd/g3'] if a.cli else ['-tags=xtrace_off','./cmd/goivy_check']
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/exe,*target],
                   cwd=pkg if a.cli else ivy,check=True)
