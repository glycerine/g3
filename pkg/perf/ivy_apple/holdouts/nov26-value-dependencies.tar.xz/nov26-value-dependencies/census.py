"""Check the untimed observer's whole verification outcome before saving counts."""
import argparse
import json
import os
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--reference',type=Path,required=True)
parser.add_argument('--tlb-reference',type=Path,required=True)
parser.add_argument('--cpu',type=int,required=True)
parser.add_argument('--case',action='append',required=True)
a=parser.parse_args()
out=Path(__file__).resolve().parent
cases=json.loads((a.reference/'cases.json').read_text())
cases['tlb']=('examples/liveness/tlb.ivy','',1)
census=out/'census'
census.mkdir(exist_ok=True)
examples=Path.home()/'ivy/ivy-lang-examples'
for case in a.case:
    path,isolate,code=cases[case]
    reference=a.tlb_reference if case=='tlb' else a.reference/'reference'/case
    args=['isolate='+isolate] if isolate else []
    run=subprocess.run(['taskset','-c',str(a.cpu),str(out/'observer/goivy_check'),*args,str(examples/path)],
                       cwd=census,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True,timeout=120)
    (census/(case+'.stdout')).write_bytes(run.stdout)
    (census/(case+'.stderr')).write_bytes(run.stderr)
    lines=run.stderr.splitlines(keepends=True)
    diagnostics=[line for line in lines if line.startswith(b'VALUE-SWEEPS ')]
    stderr=b''.join(line for line in lines if not line.startswith(b'VALUE-SWEEPS '))
    assert len(diagnostics)==1 and run.returncode==code, (case,run.returncode)
    assert run.stdout==(reference/'stdout').read_bytes() and stderr==(reference/'stderr').read_bytes(),case
    report=json.loads(diagnostics[0].split(b' ',1)[1])
    (census/(case+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(case,json.dumps(report),flush=True)
