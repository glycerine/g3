"""Validate all expected rotations and key sweep invariants in the archive."""
import collections
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent
panels = (
    ('depth-verifier', 'case', 4, 3, 9),
    ('depth-gc-off', 'case', 4, 3, 7),
    ('cache-verifier', 'case', 4, 3, 9),
    ('cache-tlb', 'case', 1, 4, 3),
    ('cache-gc-off-tlb', 'case', 1, 2, 3),
    ('depth-release-verifier', 'case', 4, 3, 9),
    ('depth-release-repeat', 'case', 4, 2, 9),
    ('depth-release-gc-off', 'case', 4, 2, 7),
    ('depth-release-tlb', 'case', 1, 2, 3),
    ('depth-release-replay', 'query', 3, 3, 5),
    ('depth-micro', 'depth', 3, 4, 7),
    ('depth-release-micro', 'depth', 3, 2, 9),
)
for name, key, cases, engines, rounds in panels:
    with (root / (name + '.csv')).open() as file:
        rows = list(csv.DictReader(file))
    counts = collections.Counter((row[key], row['engine']) for row in rows)
    assert len(counts) == cases * engines and set(counts.values()) == {rounds}, (name, counts)
    if name == 'depth-release-replay':
        stats = collections.defaultdict(set)
        for row in rows:
            stats[row[key]].add(tuple(row[k] for k in
                              ('decisions', 'conflicts', 'quant-instantiations', 'rlimit-count')))
        assert all(len(values) == 1 for values in stats.values())
for path in sorted((root / 'census').glob('*.json')):
    value = json.loads(path.read_text())
    assert value['Forward']['Rows'] == value['Reverse']['Rows']
    assert value['SameReadsChangedOutput'] == value['SameReadsChangedWithCache']
    assert value['SameReadsChangedWithoutCache'] == 0
    print(path.stem, value['Forward']['Rows'], value['SameInputSameReads'],
          value['SameReadsChangedOutput'], value['SameReadsChangedCharge'])
print('All twelve panels have the expected rotations and all observer checks pass.')
