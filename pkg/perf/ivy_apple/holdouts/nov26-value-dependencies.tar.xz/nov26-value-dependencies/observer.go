package ast

import (
	"encoding/json"
	"fmt"
	"os"
)

type valueRow struct {
	cacheHits, changedCacheHits         uint64
	input                               ASTHandle
	changed                             bool
	charge, probes, hits, temporaryHits uint64
	readings                            map[ASTHandle]ASTHandle
}

type valueSweepCounts struct {
	Rows, Changed, Charge, Probes, Hits, TemporaryHits, RowsWithTemporaryHit uint64
}
type valueCounts struct {
	SameReadsChangedWithCache, SameReadsChangedWithoutCache                          uint64
	SameReadsChangedChargeAndCacheHits                                               uint64
	Batches                                                                          uint64
	Forward, Reverse                                                                 valueSweepCounts
	SameInput, SameInputChanged, SameInputSteps                                      uint64
	SameInputSameReads, SameReadsChangedCharge, SameReadsChangedOutput               uint64
	SameUnchanged, SameUnchangedNoTemporaryRead, SameUnchangedNoTemporarySteps       uint64
	DifferentForwardRead, DifferentReverseRead, SharedKeySameValue                   uint64
	DepthCalls, DepthHits, GroundDepthMisses, OtherDepthMisses, SaturatedDepthMisses uint64
}

var valueReport valueCounts
var valueObservationActive, valueReverse bool
var valuePrevious []valueRow
var valueCurrent valueRow
var valueInserted map[ASTHandle]struct{}

func ValueObservationBegin(rows int) {
	valueReport.Batches++
	valuePrevious = make([]valueRow, rows)
}
func ValueObservationDirection(reverse bool) {
	valueReverse = reverse
	valueInserted = make(map[ASTHandle]struct{})
}
func ValueObservationRow(input ASTHandle) {
	valueCurrent = valueRow{input: input, readings: make(map[ASTHandle]ASTHandle)}
	valueObservationActive = true
}
func ValueObservationCache(key, value ASTHandle) {
	if !valueObservationActive {
		return
	}
	valueCurrent.cacheHits++
	if key != value {
		valueCurrent.changedCacheHits++
	}
}
func ValueObservationProbe(key, value ASTHandle, hit bool) {
	if !valueObservationActive {
		return
	}
	valueCurrent.probes++
	if hit {
		valueCurrent.hits++
		if _, ok := valueInserted[key]; ok {
			valueCurrent.temporaryHits++
		}
		valueCurrent.readings[key] = value
	}
}
func valueObservationInsert(key ASTHandle) {
	if valueInserted != nil {
		valueInserted[key] = struct{}{}
	}
}
func ValueObservationDepth(cached bool, ground bool, depth uint32) {
	valueReport.DepthCalls++
	if cached {
		valueReport.DepthHits++
		return
	}
	if !ground {
		valueReport.OtherDepthMisses++
		return
	}
	if depth == 65535 {
		valueReport.SaturatedDepthMisses++
		return
	}
	valueReport.GroundDepthMisses++
}
func ValueObservationEndRow(row int, charge uint64, changed bool) {
	valueObservationActive = false
	current := valueCurrent
	current.changed = changed
	current.charge = charge
	out := &valueReport.Forward
	if valueReverse {
		out = &valueReport.Reverse
	}
	out.Rows++
	if changed {
		out.Changed++
	}
	out.Charge += charge
	out.Probes += current.probes
	out.Hits += current.hits
	out.TemporaryHits += current.temporaryHits
	if current.temporaryHits != 0 {
		out.RowsWithTemporaryHit++
	}
	if !valueReverse {
		valuePrevious[row] = current
		return
	}
	previous := valuePrevious[row]
	if previous.input != current.input {
		return
	}
	valueReport.SameInput++
	valueReport.SameInputSteps += charge
	if changed {
		valueReport.SameInputChanged++
	}
	same := true
	for key, value := range previous.readings {
		if reverse, ok := current.readings[key]; ok && reverse == value {
			valueReport.SharedKeySameValue++
		} else {
			valueReport.DifferentForwardRead++
			same = false
		}
	}
	for key, value := range current.readings {
		if forward, ok := previous.readings[key]; !ok || forward != value {
			valueReport.DifferentReverseRead++
			same = false
		}
	}
	if same {
		valueReport.SameInputSameReads++
		if previous.charge != charge {
			valueReport.SameReadsChangedCharge++
			if current.cacheHits != previous.cacheHits {
				valueReport.SameReadsChangedChargeAndCacheHits++
			}
		}
		if changed != previous.changed {
			valueReport.SameReadsChangedOutput++
			if current.changedCacheHits != 0 {
				valueReport.SameReadsChangedWithCache++
			} else {
				valueReport.SameReadsChangedWithoutCache++
			}
		}
	}
	if !previous.changed && !changed {
		valueReport.SameUnchanged++
		if current.temporaryHits == 0 {
			valueReport.SameUnchangedNoTemporaryRead++
			valueReport.SameUnchangedNoTemporarySteps += charge
		}
	}
}
func ValueObservationFinish() {
	valueObservationActive = false
	valueInserted = nil
	valuePrevious = nil
}
func PrintValueObservation() {
	data, err := json.Marshal(valueReport)
	if err != nil {
		panic(err)
	}
	fmt.Fprintf(os.Stderr, "VALUE-SWEEPS %s\n", data)
}
