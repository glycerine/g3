# Value propagation dependencies and cached ground-term depth

The baseline is g3 `9106f927a`. The full builds use GoIvy `07cdeec61`, the local g3 replace and the same existing ABC executable. Native controls are this fork's `../build/z3` and the ordinary linked GoIvy build. Go builds used Go 1.27.3 for linux/amd64, no PGO and one Go processor per measurement. All timed rows rotate binaries on one pinned logical CPU. The TLB verifier has two expected failed checks and exit 1.

## Untimed sweep census

Run `build.py observer` from `pkg/` at the baseline revision. It builds an overlay for GoIvy and writes the executable beside the scripts. `census.py` requires a reference tree with `cases.json` and `reference/NAME/{stdout,stderr}` from `nov24-verifier-instruction-stacks.tar.xz`, plus the verified streams for TLB. It checks both streams and the expected exit after removing the observer's single diagnostic. The archive includes that diagnostic and the emitted outputs, including TLB.

For every call to value propagation the observer compares the two sweeps row by row. It tracks substitution keys inserted during the current sweep and the successful lookups issued during each rewrite. The same-input classification uses full AST identity. The same-read classification compares the sets of directly observed successful key/value pairs. It compares frame resource charges and counts rows with a cache hit that returned an AST other than the original subterm. This distinction matters because a cache hit can conceal earlier dependency reads. `DepthCalls` includes equality ordering at publication as well as the propagation loops.

## Timing and variants

`build.py baseline depth fused-depth known-depth` builds the ground-depth variants. `depth` checks that the handle is ground and reads the depth separately. `fused-depth` tries a single AST accessor. `known-depth` uses the existing depth accessor given the caller's ground-term guarantee. These experiments preserve the original traversal for saturated terms. The release expands only saturated nodes and uses exact cached depths for their unsaturated children.

The microbenchmark compares two nested ground uninterpreted applications at each depth. The greater-than result is checked on every iteration. It constructs all terms before the timer starts. Add `depth_benchmark_test.go` at `smtcore/smt_asserted_ground_depth_benchmark_test.go` with a Go overlay for the baseline and variants when building their test executables. `measure_depth.py` rotates at 4,000 iterations on CPU 10 and records time and allocations. The prototype panel uses seven rounds and the release panel uses nine. The release regression exercises two saturated inputs with the declaration-ID tie break pointing in the wrong direction for the actual term depths. The saved negative-control source treats a saturated depth as exact and fails that test.

`compact_cache.py 4 8` builds optional compact identity-only prefixes for the ordinary theory rewriter. The prototypes reuse the existing activity queue for keys, use one access mask, keep both owned references, and build the ordinary table on spill. Reset can release both references directly if every node survives. The measured prototypes remain experimental. In particular, a production spill needs to reproduce growth before insertion of duplicate keys, which can affect native table release order.

`verify.py` uses exact complete transcripts, the stated CPU, and normal GC unless `--gc off` is supplied. The depth and cache prototype panels ran on CPU 12 for nine rotations. The known-ground GC-off depth panel used seven rotations on CPU 13. The cache TLB panel used three rotations on CPU 14. `cache-counters/verify.py` adds L1 data and generic cache-miss counters to the GC-off TLB test. The release panel uses nine rotations on CPU 12, three TLB rotations on CPU 13, and a separate repeat on CPU 7 with default GC and GC off. The release standalone replays use five rotations on CPU 11, compare every search counter and resource count, and include their SMT2 inputs.

The uninstrumented drivers reject mismatched transcripts and incomplete hardware accounting. Counts from the observer are separate from elapsed performance. All comparison files contain the qualifying individual rotations.

The production revision is `465f0438f`. The full reference list includes TLB in `cases.json`. The clean TLB reference streams are in `tlb-reference/`. The other exact reference streams come from `nov24-verifier-instruction-stacks.tar.xz`.
