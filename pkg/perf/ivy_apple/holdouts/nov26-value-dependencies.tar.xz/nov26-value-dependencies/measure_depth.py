"""Rotate benchmark binaries for shallow and deep ground-term ordering."""
import argparse
import csv
import os
from pathlib import Path
import re
import subprocess
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cpu',type=int,required=True)
parser.add_argument('--rounds',type=int,default=7)
parser.add_argument('--iterations',type=int,default=4000)
parser.add_argument('engines',nargs='+')
a=parser.parse_args()
environments=dict(os.environ,GOMAXPROCS='1')
engines=[arg.split('=',1) for arg in a.engines]
writer=csv.writer(sys.stdout)
writer.writerow(('engine','round','depth','iterations','ns/op','B/op','allocs/op'))
for turn in range(a.rounds):
    offset=turn%len(engines)
    for label,binary in engines[offset:]+engines[:offset]:
        run=subprocess.run(['taskset','-c',str(a.cpu),str(Path(binary).resolve()),'-test.run=^$',
                            '-test.bench=^BenchmarkSMTAssertedGreaterGroundDepth$',
                            '-test.benchtime='+str(a.iterations)+'x','-test.benchmem'],
                           stdout=subprocess.PIPE,text=True,check=True,env=environments)
        matches=re.findall(r'^BenchmarkSMTAssertedGreaterGroundDepth/(\d+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',run.stdout,re.MULTILINE)
        if {int(m[0]) for m in matches}!={1,16,1024} or any(int(m[1])!=a.iterations for m in matches):
            raise ValueError(run.stdout)
        for match in matches:
            writer.writerow((label,turn+1,*match))
        sys.stdout.flush()
