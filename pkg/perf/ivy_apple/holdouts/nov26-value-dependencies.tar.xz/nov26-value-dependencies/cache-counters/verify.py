"""Compare complete verifiers and check exact transcripts."""

import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--examples", required=True, type=Path)
    parser.add_argument("--cpu", required=True, type=int)
    parser.add_argument("--perf", default="perf")
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--gc", default="100")
    parser.add_argument("--case", action="append", required=True)
    parser.add_argument("engines", nargs="+", help="label=executable")
    args = parser.parse_args()
    cases = json.loads((args.reference / "cases.json").read_text())
    engines = [entry.split("=", 1) for entry in args.engines]
    env = dict(os.environ, GOMAXPROCS="1", GOGC=args.gc, XTRACE_OFF="1")
    out = Path(__file__).resolve().parent
    writer = csv.writer(sys.stdout)
    writer.writerow(("case", "round", "engine", "instructions", "cycles", "l1_misses", "cache_misses", "milliseconds"))
    for name in args.case:
        path, isolate, exit_code = cases[name]
        reference = args.reference / "reference" / name
        expected = ((reference / "stdout").read_bytes(), (reference / "stderr").read_bytes())
        for turn in range(args.rounds):
            offset = turn % len(engines)
            for label, binary in engines[offset:] + engines[:offset]:
                directory = out / ("verifier-" + args.gc + "-" + label)
                directory.mkdir(exist_ok=True)
                counters = directory / "perf.csv"
                command = ["taskset", "-c", str(args.cpu), args.perf, "stat", "-x,", "-o", counters,
                           "-e", "instructions:u,cycles:u,L1-dcache-load-misses:u,cache-misses:u", "--", str(Path(binary).resolve())]
                if isolate:
                    command.append("isolate=" + isolate)
                command.append(str(args.examples / path))
                start = time.monotonic()
                trial_env = dict(env)
                if label in ("audit", "skip"):
                    trial_env["G3_INSTANCE_MEMO_TRIAL"] = label
                run = subprocess.run(command, cwd=directory, capture_output=True, env=trial_env, timeout=120)
                elapsed = (time.monotonic() - start) * 1e3
                stderr = run.stderr
                if label in ("audit", "skip"):
                    lines = stderr.splitlines(keepends=True)
                    memo = [line for line in lines if line.startswith(b"MEMO-TRIAL ")]
                    if len(memo) != 1:
                        raise ValueError((name, label, stderr))
                    log = directory / (f"{name}-{turn+1}.memo")
                    log.write_bytes(memo[0])
                    stderr = b"".join(line for line in lines if line not in memo)
                if run.returncode != exit_code or expected != (run.stdout, stderr):
                    (directory / "failure.stdout").write_bytes(run.stdout)
                    (directory / "failure.stderr").write_bytes(run.stderr)
                    raise ValueError((name, label, run.returncode))
                hw = {row[2]: int(row[0]) for row in csv.reader(counters.read_text().splitlines())
                      if len(row) > 4 and (row[2].endswith(":u") or row[2] == "L1-dcache-load-misses") and float(row[4]) == 100.0}
                writer.writerow((name, turn + 1, label, hw["instructions:u"], hw["cycles:u"], hw.get("L1-dcache-load-misses:u", hw.get("L1-dcache-load-misses")), hw["cache-misses:u"], f"{elapsed:.3f}"))
                sys.stdout.flush()


if __name__ == "__main__":
    main()
