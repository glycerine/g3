"""Replay captured Ivy goals and generated finite-model tests using the local g3 checkout."""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from quantified_control import make

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pkg', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seeds', type=int, default=16)
    parser.add_argument('--cases', nargs='*', default=['hybrid-normal-32-1','test_liveness2-normal-12-1','test_liveness2-sat-13-1'])
    parser.add_argument('--modes', nargs='+', default=['unit','unit-observed','unit-observed-join','unit-observed-join-seed'])
    parser.add_argument('--k', type=int, default=3)
    parser.add_argument('--passes', type=int, default=3)
    parser.add_argument('--cap', type=int, default=64)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True)
    binary = output/'refute'
    subprocess.run(['go','build','-tags=xtrace_off','-o',binary,*sorted((HERE/'checker').glob('*.go'))], cwd=args.pkg, check=True)
    truths = json.loads((HERE/'expected.json').read_text())
    inputs = [(name, HERE/'captures'/(name+'.smt2'),truths[name]) for name in args.cases]
    for seed in range(args.seeds):
        text, expected = make(seed)
        name = f'seed-{seed}'
        path = output/(name+'.smt2')
        path.write_text(text)
        inputs.append((name,path,expected))
    with (output/'runs.csv').open('w') as f:
        writer = csv.writer(f)
        writer.writerow(['case','expected','strategy','proved','watch_visits','branch_decisions'])
        for name, path, expected in inputs:
            for mode in args.modes:
                env = dict(os.environ,GOMAXPROCS='1',GROUND_POLICY='canon-memo',GROUND_DOMAIN='seen',
                           ENCODING='direction-pure',TRIAL='short',SIGNED_MATCH=mode if mode!='position' else '')
                result = subprocess.check_output([binary,path,'direct','12000',str(args.k),'2',str(args.passes),str(args.cap)],cwd=output,env=env,text=True)
                proved, visits, decisions = result.split()[:3]
                if proved == 'true' and expected == 'sat':
                    raise ValueError(f'{name}: refuted a formula with a model')
                writer.writerow([name,expected,mode,proved,visits,decisions])
                f.flush()
if __name__ == '__main__':
    main()
