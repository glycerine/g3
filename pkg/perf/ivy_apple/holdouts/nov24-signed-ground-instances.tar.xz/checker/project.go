package main

import (
	"encoding/binary"
	"math/bits"
	"os"
	"slices"
	"strconv"
	"strings"

	"github.com/glycerine/g3/pkg/api"
	"github.com/glycerine/g3/pkg/ast"
	nf "github.com/glycerine/g3/pkg/ast/normal_forms"
)

// A source node is an arena term, a de Bruijn variable, or a universal binder.
// Grounding owns a finite list of terms per sort. A missing universal instance
// weakens a positive formula, so quantifiers in opaque contexts are rejected.
type pattern struct {
	op          uint32
	sort        int32
	args        []int32
	binds       []int32
	index       int
	open, quant bool
}
type groundKey struct {
	op      uint32
	n       uint32
	a, b, c int32
}
type project struct {
	known                             []int8
	positions                         map[[2]int32][][2]int32
	choices                           map[[2]int32][]int32
	weighted                          bool
	alias, canon, memo, preferWitness bool
	reps                              []int32
	mask                              []uint64
	cached                            map[[4]int32]int32
	graph
	m                              *ast.ASTManager
	nodes                          []pattern
	compiled                       map[ast.ASTHandle]int32
	declarations                   map[ast.ASTHandle]uint32
	source                         map[ast.ASTHandle]int
	sorts                          map[ast.ASTHandle]int32
	opSort                         []int32
	spell                          map[string]uint32
	witnesses                      []bool
	use                            []int
	templates                      []int32
	domains                        [][]int32
	counted                        []int
	freq                           []int
	termSort                       []int32
	fixed                          map[groundKey]int32
	long                           map[string]int32
	shortCache                     []int32
	rootSet                        map[int32]bool
	tuples, visits, universalCount int
	boolSort                       int32
	t, f                           int32
}

func (p *project) sort(h ast.ASTHandle) int32 {
	if v, ok := p.sorts[h]; ok {
		return v
	}
	i := int32(len(p.sorts))
	p.sorts[h] = i
	return i
}
func (p *project) addOp(name string, sort int32, b, decl, wit bool, uses int) uint32 {
	opID := uint32(len(p.ops))
	p.ops = append(p.ops, op{name, b, decl})
	p.opSort = append(p.opSort, sort)
	p.witnesses = append(p.witnesses, wit)
	p.use = append(p.use, uses)
	return opID
}
func (p *project) init(m *ast.ASTManager) {
	pattern := os.Getenv("GROUND_POLICY")
	p.alias = strings.Contains(pattern, "alias") || strings.Contains(pattern, "canon")
	p.canon = strings.Contains(pattern, "canon")
	p.memo = strings.Contains(pattern, "memo")
	p.preferWitness = strings.Contains(pattern, "witness")
	p.cached = map[[4]int32]int32{}
	p.weighted = strings.Contains(pattern, "weighted")
	p.m = m
	p.compiled = map[ast.ASTHandle]int32{}
	p.declarations = map[ast.ASTHandle]uint32{}
	p.source = map[ast.ASTHandle]int{}
	p.sorts = map[ast.ASTHandle]int32{}
	p.spell = map[string]uint32{}
	p.fixed = map[groundKey]int32{}
	p.long = map[string]int32{}
	p.rootSet = map[int32]bool{}
	bs, e := m.MkTrue()
	must(e)
	sh, e := m.GetSort(bs)
	must(e)
	p.boolSort = p.sort(sh)
	for _, n := range []string{"true", "false", "and", "or", "not", "="} {
		p.spell[n] = p.addOp(n, p.boolSort, true, false, false, 0)
	}
	p.t = p.intern(p.spell["true"], nil)
	p.f = p.intern(p.spell["false"], nil)
}
func (p *project) sourceUses(h ast.ASTHandle, seen map[ast.ASTHandle]bool) {
	type source struct {
		decl     ast.ASTHandle
		children []int
	}
	memo := map[ast.ASTHandle]int{}
	var nodes []source
	var build func(ast.ASTHandle) int
	build = func(h ast.ASTHandle) int {
		if i, ok := memo[h]; ok {
			return i
		}
		m := p.m
		k, e := m.GetKind(h)
		must(e)
		var n source
		if k == ast.ASTQuantifier {
			b, e := m.GetQuantifierBody(h)
			must(e)
			n.children = []int{build(b)}
		}
		if k == ast.ASTApp {
			n.decl, e = m.GetDecl(h)
			must(e)
			a, e := m.GetNumArgs(h)
			must(e)
			for i := uint32(0); i < a; i++ {
				x, e := m.GetArg(h, i)
				must(e)
				n.children = append(n.children, build(x))
			}
		}
		i := len(nodes)
		memo[h] = i
		nodes = append(nodes, n)
		return i
	}
	root := build(h)
	count := make([]int, len(nodes))
	count[root] = 1
	for i := len(nodes) - 1; i >= 0; i-- {
		n := nodes[i]
		if !n.decl.IsNull() {
			p.source[n.decl] = min(1<<28, p.source[n.decl]+count[i])
		}
		for _, j := range n.children {
			cnt := 1
			if p.weighted {
				cnt = count[i]
			}
			count[j] = min(1<<28, count[j]+cnt)
		}
	}
}
func (p *project) compile(h ast.ASTHandle) int32 {
	if id, ok := p.compiled[h]; ok {
		return id
	}
	m := p.m
	k, e := m.GetKind(h)
	must(e)
	sh, e := m.GetSort(h)
	must(e)
	n := pattern{sort: p.sort(sh), index: -1}
	switch k {
	case ast.ASTVar:
		v, e := m.GetVarIndex(h)
		must(e)
		n.index = int(v)
		n.open = true
	case ast.ASTQuantifier:
		b, e := m.IsForall(h)
		must(e)
		if !b || n.sort != p.boolSort {
			panic("unsupported binder")
		}
		n.open = true
		n.quant = true
		count, e := m.GetNumDeclarations(h)
		must(e)
		for i := uint32(0); i < count; i++ {
			s, e := m.GetDeclarationSort(h, i)
			must(e)
			n.binds = append(n.binds, p.sort(s))
		}
		a, e := m.GetQuantifierBody(h)
		must(e)
		n.args = []int32{p.compile(a)}
		p.universalCount++
	case ast.ASTApp:
		decl, e := m.GetDecl(h)
		must(e)
		id, ok := p.declarations[decl]
		if !ok {
			fam, e := m.GetFamilyID(decl)
			must(e)
			name := "term"
			recognized := false
			if fam == m.BasicFamilyID() {
				kind, e := m.GetDeclKind(decl)
				must(e)
				switch kind {
				case ast.ASTOpTrue:
					name = "true"
				case ast.ASTOpFalse:
					name = "false"
				case ast.ASTOpAnd:
					name = "and"
				case ast.ASTOpOr:
					name = "or"
				case ast.ASTOpImplies:
					name = "=>"
				case ast.ASTOpNot:
					name = "not"
				case ast.ASTOpIff, ast.ASTOpEq:
					name = "="
				case ast.ASTOpXor:
					name = "xor"
				case ast.ASTOpDistinct:
					name = "distinct"
				case ast.ASTOpIte:
					name = "ite"
				}
				recognized = name != "term"
			}
			if canon, ok := p.spell[name]; ok {
				id = canon
			} else {
				id = p.addOp(name, n.sort, n.sort == p.boolSort, !recognized, p.source[decl] == 0, p.source[decl])
			}
			p.declarations[decl] = id
		}
		n.op = id
		size, e := m.GetNumArgs(h)
		must(e)
		for i := uint32(0); i < size; i++ {
			child, e := m.GetArg(h, i)
			must(e)
			x := p.compile(child)
			n.args = append(n.args, x)
			n.open = n.open || p.nodes[x].open
			n.quant = n.quant || p.nodes[x].quant
		}
		if n.quant && p.ops[id].Name != "and" && p.ops[id].Name != "or" {
			panic("unsupported binder polarity")
		}
	default:
		panic("unexpected AST kind")
	}
	id := int32(len(p.nodes))
	p.compiled[h] = id
	var mask uint64
	if n.index >= 0 {
		if n.index < 63 {
			mask = uint64(1) << n.index
		} else {
			mask = ^uint64(0)
		}
	} else if n.binds == nil {
		for _, i := range n.args {
			mask |= p.mask[i]
		}
	}
	p.mask = append(p.mask, mask)
	p.nodes = append(p.nodes, n)
	p.shortCache = append(p.shortCache, -1)
	return id
}
func (p *project) intern(op uint32, args []int32) int32 {
	var k groundKey
	var long string
	if len(args) <= 3 {
		k.op = op
		k.n = uint32(len(args))
		switch len(args) {
		case 3:
			k.c = args[2]
			fallthrough
		case 2:
			k.b = args[1]
			fallthrough
		case 1:
			k.a = args[0]
		}
		if id, ok := p.fixed[k]; ok {
			return id
		}
	} else {
		raw := make([]byte, 4*(len(args)+1))
		binary.LittleEndian.PutUint32(raw, op)
		for i, v := range args {
			binary.LittleEndian.PutUint32(raw[4*(i+1):], uint32(v))
		}
		long = string(raw)
		if id, ok := p.long[long]; ok {
			return id
		}
	}
	if len(p.terms) >= 180000 {
		panic("ground term limit")
	}
	id := int32(len(p.terms))
	p.terms = append(p.terms, node{op, slices.Clone(args)})
	p.termSort = append(p.termSort, p.opSort[op])
	p.freq = append(p.freq, 0)
	if len(args) <= 3 {
		p.fixed[k] = id
	} else {
		p.long[long] = id
	}
	return id
}
func (p *project) app(op uint32, args []int32) int32 {
	switch p.ops[op].Name {
	case "=":
		if len(args) == 2 && args[0] == args[1] {
			return p.t
		}
	case "not":
		if args[0] == p.t {
			return p.f
		}
		if args[0] == p.f {
			return p.t
		}
		a := p.terms[args[0]]
		if p.ops[a.op].Name == "not" {
			return a.args[0]
		}
	case "ite":
		if args[0] == p.t || args[1] == args[2] {
			return args[1]
		}
		if args[0] == p.f {
			return args[2]
		}
	case "and", "or":
		unit, absorb := p.t, p.f
		if p.ops[op].Name == "or" {
			unit, absorb = absorb, unit
		}
		v := args[:0]
		for _, a := range args {
			if a == absorb {
				return absorb
			}
			if a != unit {
				v = append(v, a)
			}
		}
		args = v
		if len(args) == 0 {
			return unit
		}
		if len(args) == 1 {
			return args[0]
		}
	}
	return p.intern(op, args)
}
func (p *project) split(n int32) {
	x := p.nodes[n]
	if x.index < 0 && x.binds == nil && p.ops[x.op].Name == "and" {
		for _, a := range x.args {
			p.split(a)
		}
		return
	}
	p.templates = append(p.templates, n)
}
func (p *project) domain(k int) {
	p.domains = make([][]int32, len(p.sorts))
	p.domains[p.boolSort] = []int32{p.t, p.f}
	type entry struct {
		term int32
		rank int
	}
	orig := make([][]entry, len(p.sorts))
	sk := make([][]entry, len(p.sorts))
	for i, n := range p.nodes {
		if n.index >= 0 || n.open || len(n.args) != 0 || n.sort == p.boolSort {
			continue
		}
		id := p.intern(n.op, nil)
		p.shortCache[i] = id
		x := entry{id, p.use[n.op]}
		if p.witnesses[n.op] {
			sk[n.sort] = append(sk[n.sort], x)
		} else {
			orig[n.sort] = append(orig[n.sort], x)
		}
	}
	p.reps = make([]int32, len(p.terms))
	for i := range p.reps {
		p.reps[i] = int32(i)
	}
	if p.alias {
		for _, id := range p.templates {
			n := p.nodes[id]
			if n.open || p.ops[n.op].Name != "=" || len(n.args) != 2 {
				continue
			}
			x, y := n.args[0], n.args[1]
			if p.nodes[x].sort == p.boolSort || p.shortCache[x] < 0 || p.shortCache[y] < 0 {
				continue
			}
			a, b := p.find(p.shortCache[x]), p.find(p.shortCache[y])
			if a != b {
				p.reps[max(a, b)] = min(a, b)
			}
		}
		if p.canon {
			for i, n := range p.shortCache {
				if n >= 0 {
					p.shortCache[i] = p.find(n)
				}
			}
		}
	}
	for s := range p.domains {
		if int32(s) == p.boolSort {
			continue
		}
		a, b := orig[s], sk[s]
		slices.SortStableFunc(a, func(x, y entry) int { return y.rank - x.rank })
		for i := 0; i < max(len(a), len(b)) && len(p.domains[s]) < k; i++ {
			if i < len(b) {
				p.addDomain(s, b[i].term)
			}
			if i < len(a) && len(p.domains[s]) < k {
				p.addDomain(s, a[i].term)
			}
		}
		if len(p.domains[s]) == 0 {
			id := p.addOp("witness", int32(s), false, true, true, 0)
			p.domains[s] = []int32{p.intern(id, nil)}
		}
	}
}
func (p *project) ground(id int32, env []int32, left *int) int32 {
	p.visits++
	if p.visits > 3500000 {
		panic("ground visit limit")
	}
	n := p.nodes[id]
	if x := p.shortCache[id]; x >= 0 {
		return x
	}
	if n.index >= 0 {
		return env[len(env)-1-n.index]
	}
	if n.binds != nil {
		out := make([]int32, 0, 8)
		var walk func(int, []int32)
		walk = func(pos int, bindings []int32) {
			if *left <= 0 {
				return
			}
			if pos == len(n.binds) {
				*left--
				p.tuples++
				out = append(out, p.ground(n.args[0], bindings, left))
				return
			}
			choices := p.domains[n.binds[pos]]
			if local := p.choices[[2]int32{id, int32(pos)}]; len(local) > 0 {
				choices = local
			}
			for _, x := range choices {
				if *left <= 0 {
					break
				}
				walk(pos+1, append(bindings, x))
			}
		}
		walk(0, env)
		return p.app(p.spell["and"], out)
	}
	var memoKey [4]int32
	memo := p.memo && n.open && !n.quant && len(n.args) > 0 && bits.OnesCount64(p.mask[id]) <= 3
	if memo {
		memoKey[0] = id
		mask := p.mask[id]
		for i := 1; mask != 0; i++ {
			j := bits.TrailingZeros64(mask)
			memoKey[i] = 1 + env[len(env)-1-j]
			mask &= mask - 1
		}
		if x, ok := p.cached[memoKey]; ok {
			return x
		}
	}
	var small [4]int32
	args := small[:0]
	for _, a := range n.args {
		args = append(args, p.ground(a, env, left))
	}
	x := p.app(n.op, args)
	if memo {
		p.cached[memoKey] = x
	}
	if !n.open {
		p.shortCache[id] = x
	}
	if n.sort != p.boolSort && len(n.args) > 0 && p.ops[n.op].Declared {
		p.freq[x]++
	}
	return x
}
func (p *project) rounds(k, more, passes, cap int) {
	if strategy := os.Getenv("SIGNED_MATCH"); strategy != "" {
		p.signedRounds(k, more, passes, cap, strategy)
		return
	}
	p.domain(k)
	mode := os.Getenv("GROUND_DOMAIN")
	if mode != "" {
		p.observePositions()
	}
	for j := 0; j < passes; j++ {
		if mode != "" {
			p.choosePositions(k+j*more, mode)
		}
		for _, root := range p.templates {
			left := cap
			x := p.ground(root, nil, &left)
			p.assertRoot(x)
		}
		if j+1 == passes {
			break
		}
		by := make([][]int32, len(p.sorts))
		for i, n := range p.freq {
			if n == 0 {
				continue
			}
			if p.preferWitness && !p.witnesses[p.terms[i].op] {
				continue
			}
			s := p.termSort[i]
			if s == p.boolSort || slices.Contains(p.domains[s], int32(i)) {
				continue
			}
			by[s] = append(by[s], int32(i))
		}
		added := 0
		for s, v := range by {
			slices.SortStableFunc(v, func(a, b int32) int { return p.freq[b] - p.freq[a] })
			v = v[:min(more, len(v))]
			p.domains[s] = append(p.domains[s], v...)
			added += len(v)
		}
		if added == 0 {
			break
		}
	}
}
func (p *project) assertRoot(x int32) {
	if x == p.t || p.rootSet[x] {
		return
	}
	p.rootSet[x] = true
	t := p.terms[x]
	if p.ops[t.op].Name == "and" {
		for _, y := range t.args {
			p.assertRoot(y)
		}
		return
	}
	p.roots = append(p.roots, x)
}
func fromInput(input string, args []string) (graph, [5]int) {
	ctx, e := api.NewSMTContext()
	must(e)
	defer func() { must(ctx.Close()) }()
	m, e := ctx.Manager()
	must(e)
	r, e := ctx.ParseSMT2File(input, api.SMT2Bindings{})
	must(e)
	defer func() { must(m.DelRef(&r)) }()
	h, e := m.RefGet(r)
	must(e)
	var p project
	p.init(m)
	p.sourceUses(h, map[ast.ASTHandle]bool{})
	names, e := nf.NewDefinedNames(m)
	must(e)
	defer func() { must(names.Close()) }()
	o := nf.DefaultNNFOptions()
	o.Mode = nf.NNFFull
	o.IgnoreLabels = true
	n, e := nf.NewNNF(m, names, o)
	must(e)
	defer func() { must(n.Close()) }()
	out, e := m.NewRef(ast.ASTHandle{})
	must(e)
	defer func() { must(m.DelRef(&out)) }()
	proof, e := m.NewRef(ast.ASTHandle{})
	must(e)
	defer func() { must(m.DelRef(&proof)) }()
	var defs, proofs []ast.ASTRef
	defer func() {
		for i := range defs {
			must(m.DelRef(&defs[i]))
		}
		for i := range proofs {
			must(m.DelRef(&proofs[i]))
		}
	}()
	must(n.Transform(h, &defs, &proofs, out, proof))
	term, e := m.RefGet(out)
	must(e)
	p.split(p.compile(term))
	for _, r := range defs {
		term, e = m.RefGet(r)
		must(e)
		p.split(p.compile(term))
	}
	config := [4]int{8, 5, 2, 1536}
	for i, arg := range args {
		v, e := strconv.Atoi(arg)
		must(e)
		config[i] = v
	}
	p.rounds(config[0], config[1], config[2], config[3])
	stats := [5]int{len(p.templates), p.universalCount, p.tuples, p.visits, len(p.nodes)}
	return p.graph, stats
}

func (p *project) find(x int32) int32 {
	for int(x) < len(p.reps) && x != p.reps[x] {
		p.reps[x] = p.reps[p.reps[x]]
		x = p.reps[x]
	}
	return x
}
func (p *project) addDomain(s int, x int32) {
	if !p.alias {
		p.domains[s] = append(p.domains[s], x)
		return
	}
	r := p.find(x)
	for _, d := range p.domains[s] {
		if p.find(d) == r {
			return
		}
	}
	if p.canon {
		x = r
	}
	p.domains[s] = append(p.domains[s], x)
}

func (p *project) observePositions() {
	p.positions = map[[2]int32][][2]int32{}
	for i, n := range p.nodes {
		if !n.open {
			left := 1
			p.ground(int32(i), nil, &left)
		}
	}
	visits := 0
	var walk func(int32, [][2]int32)
	walk = func(id int32, scope [][2]int32) {
		visits++
		if visits > 600000 {
			panic("position limit")
		}
		n := p.nodes[id]
		if !n.open || n.index >= 0 {
			return
		}
		if n.binds != nil {
			for i := range n.binds {
				scope = append(scope, [2]int32{id, int32(i)})
			}
			walk(n.args[0], scope)
			return
		}
		for i, child := range n.args {
			x := p.nodes[child]
			if x.index >= 0 && p.ops[n.op].Declared && x.sort != p.boolSort {
				v := scope[len(scope)-1-x.index]
				slot := [2]int32{int32(n.op), int32(i)}
				if !slices.Contains(p.positions[v], slot) {
					p.positions[v] = append(p.positions[v], slot)
				}
			}
			walk(child, scope)
		}
	}
	for _, n := range p.templates {
		walk(n, nil)
	}
}
func (p *project) choosePositions(k int, mode string) {
	slots := map[[2]int32]map[int32]int{}
	for _, ls := range p.positions {
		for _, pos := range ls {
			if slots[pos] == nil {
				slots[pos] = map[int32]int{}
			}
		}
	}
	for _, n := range p.terms {
		for i, x := range n.args {
			if ct := slots[[2]int32{int32(n.op), int32(i)}]; ct != nil {
				ct[x]++
			}
		}
	}
	p.choices = map[[2]int32][]int32{}
	for v, ls := range p.positions {
		sort := p.nodes[v[0]].binds[v[1]]
		score := map[int32]int{}
		for _, pos := range ls {
			for x, n := range slots[pos] {
				if p.termSort[x] == sort {
					score[x] += n
				}
			}
		}
		local := make([]int32, 0, len(score))
		for x := range score {
			local = append(local, x)
		}
		slices.SortFunc(local, func(x, y int32) int {
			if a, b := score[x], score[y]; a != b {
				return b - a
			}
			return int(x - y)
		})
		var out []int32
		seen := map[int32]bool{}
		add := func(x int32) {
			key := p.find(x)
			if !seen[key] && len(out) < k {
				out = append(out, x)
				seen[key] = true
			}
		}
		global := p.domains[sort]
		switch mode {
		case "direct":
			for _, x := range local {
				add(x)
			}
			for _, x := range global {
				add(x)
			}
		case "mix", "first":
			for i := 0; i < max(len(global), len(local)); i++ {
				if mode == "first" && i < len(global) {
					add(global[i])
				}
				if i < len(local) {
					add(local[i])
				}
				if mode == "mix" && i < len(global) {
					add(global[i])
				}
			}
		case "seen":
			for _, x := range global {
				if score[x] > 0 {
					add(x)
				}
			}
			for _, x := range local {
				add(x)
			}
			for _, x := range global {
				add(x)
			}
		}
		p.choices[v] = out
	}
}

func (p *project) groundFacts() {
	if n := len(p.terms) - len(p.known); n > 0 {
		p.known = append(p.known, make([]int8, n)...)
	}
	p.known[p.t] = 1
	p.known[p.f] = -1
	for iteration := 0; iteration < 5; iteration++ {
		changed := false
		var propagate func(int32, int8)
		propagate = func(id int32, want int8) {
			val := p.known[id]
			if val != 0 {
				if val != want {
					p.assertRoot(p.f)
				}
				return
			}
			t := p.terms[id]
			op := p.ops[t.op]
			switch op.Name {
			case "not":
				propagate(t.args[0], -want)
			case "and", "or":
				all := int8(1)
				if op.Name == "or" {
					all = -1
				}
				if want == all {
					for _, x := range t.args {
						propagate(x, want)
					}
					return
				}
				var free int
				var last int32
				for _, x := range t.args {
					v := p.known[x]
					if v == want {
						return
					}
					if v == 0 {
						free++
						last = x
					}
				}
				if free == 0 {
					p.assertRoot(p.f)
				} else if free == 1 {
					propagate(last, want)
				}
			case "=", "xor", "distinct":
				if len(t.args) == 2 && p.termSort[t.args[0]] == p.boolSort {
					a, b := t.args[0], t.args[1]
					if op.Name != "=" {
						want = -want
					}
					if p.known[a] != 0 {
						propagate(b, want*p.known[a])
					} else if p.known[b] != 0 {
						propagate(a, want*p.known[b])
					}
					return
				}
				p.known[id] = want
				changed = true
			case "ite":
				c, a, b := t.args[0], t.args[1], t.args[2]
				if p.known[c] > 0 {
					propagate(a, want)
				} else if p.known[c] < 0 {
					propagate(b, want)
				} else if p.known[a] == -want {
					propagate(c, -1)
					propagate(b, want)
				} else if p.known[b] == -want {
					propagate(c, 1)
					propagate(a, want)
				}
			case "=>":
				a, b := t.args[0], t.args[1]
				if want < 0 {
					propagate(a, 1)
					propagate(b, -1)
				} else if p.known[a] > 0 {
					propagate(b, 1)
				} else if p.known[b] < 0 {
					propagate(a, -1)
				}
			default:
				p.known[id] = want
				changed = true
			}
		}
		for _, x := range p.roots {
			propagate(x, 1)
		}
		if !changed || p.rootSet[p.f] {
			break
		}
	}
}

type signedKey struct {
	op    uint32
	value int8
}
type signedRule struct {
	root     int32
	triggers []signedTrigger
}
type signedTrigger struct {
	node int32
	key  signedKey
}
type signedBinding [8]int32 // Ground term IDs are stored plus one.
func (p *project) signedRules() []signedRule {
	var rules []signedRule
	for _, id := range p.templates {
		q := p.nodes[id]
		if q.binds == nil || len(q.binds) > 8 {
			continue
		}
		rule := signedRule{root: id}
		visited := make(map[[2]int32]bool)
		var walk func(int32, int8)
		walk = func(x int32, pol int8) {
			n := p.nodes[x]
			if !n.open || n.binds != nil || n.index >= 0 {
				return
			}
			key := [2]int32{x, int32(pol)}
			if visited[key] {
				return
			}
			visited[key] = true
			op := p.ops[n.op]
			if op.Declared && op.Bool {
				rule.triggers = append(rule.triggers, signedTrigger{x, signedKey{n.op, -pol}})
				return
			}
			switch op.Name {
			case "or", "and":
				for _, a := range n.args {
					walk(a, pol)
				}
			case "not":
				walk(n.args[0], -pol)
			case "=>":
				walk(n.args[0], -pol)
				walk(n.args[1], pol)
			case "ite":
				walk(n.args[0], 1)
				walk(n.args[0], -1)
				walk(n.args[1], pol)
				walk(n.args[2], pol)
			case "=", "xor", "distinct":
				if p.nodes[n.args[0]].sort == p.boolSort {
					for _, a := range n.args {
						walk(a, 1)
						walk(a, -1)
					}
				}
			}
		}
		walk(q.args[0], 1)
		rules = append(rules, rule)
	}
	return rules
}
func (p *project) signedUnify(id, term int32, sorts []int32, v *signedBinding) bool {
	n, t := p.nodes[id], p.terms[term]
	if n.sort != p.termSort[term] || n.binds != nil {
		return false
	}
	if n.index >= 0 {
		i := len(sorts) - 1 - n.index
		if i < 0 || sorts[i] != n.sort {
			return false
		}
		if v[i] != 0 {
			return v[i] == term+1
		}
		v[i] = term + 1
		return true
	}
	if x := p.shortCache[id]; x >= 0 {
		return x == term
	}
	if n.op != t.op || len(n.args) != len(t.args) {
		return false
	}
	for i, a := range n.args {
		if !p.signedUnify(a, t.args[i], sorts, v) {
			return false
		}
	}
	return true
}
func mixSigned(x, y signedBinding) (signedBinding, bool) {
	more := false
	for i, v := range y {
		if v == 0 {
			continue
		}
		if x[i] == 0 {
			x[i] = v
			more = true
		} else if x[i] != v {
			return x, false
		}
	}
	return x, more
}
func (p *project) signedRounds(k, more, passes, cap int, mode string) {
	p.domain(k)
	p.observePositions()
	rules := p.signedRules()
	seen := make(map[[9]int32]bool)
	for _, id := range p.templates {
		if !p.nodes[id].open {
			left := cap
			p.assertRoot(p.ground(id, nil, &left))
		}
	}
	for round := 0; round < passes; round++ {
		p.groundFacts()
		if p.rootSet[p.f] {
			break
		}
		facts := make(map[signedKey][]int32)
		for i, t := range p.terms {
			if !p.ops[t.op].Declared || p.termSort[i] != p.boolSort {
				continue
			}
			var truth int8
			if i < len(p.known) {
				truth = p.known[i]
			}
			if truth != 0 {
				key := signedKey{t.op, truth}
				facts[key] = append(facts[key], int32(i))
			}
			if strings.Contains(mode, "observed") {
				key := signedKey{t.op, 0}
				facts[key] = append(facts[key], int32(i))
			}
		}
		p.choosePositions(k+round*more, "seen")
		for _, rule := range rules {
			q := p.nodes[rule.root]
			width := len(q.binds)
			first := make([]signedBinding, 0)
			marked := map[signedBinding]bool{}
			for _, trigger := range rule.triggers {
				rows := facts[trigger.key]
				if len(rows) == 0 && strings.Contains(mode, "observed") {
					rows = facts[signedKey{trigger.key.op, 0}]
				}
				n := 0
				for _, row := range rows[:min(512, len(rows))] {
					var v signedBinding
					if p.signedUnify(trigger.node, row, q.binds, &v) && !marked[v] {
						marked[v] = true
						first = append(first, v)
						n++
					}
					if n == 32 || len(first) >= 128 {
						break
					}
				}
				if len(first) >= 128 {
					break
				}
			}
			choices := make([]signedBinding, 0, len(first))
			choices = append(choices, first...)
			if strings.Contains(mode, "join") {
				for _, x := range first {
					for _, y := range first {
						z, ok := mixSigned(x, y)
						if ok && !marked[z] {
							choices = append(choices, z)
							marked[z] = true
						}
						if len(choices) >= 256 {
							break
						}
					}
					if len(choices) >= 256 {
						break
					}
				}
			}
			specificity := func(x signedBinding) int {
				n := 0
				for _, v := range x[:width] {
					if v != 0 {
						n++
					}
				}
				return n
			}
			slices.SortStableFunc(choices, func(x, y signedBinding) int { return specificity(y) - specificity(x) })
			if len(choices) == 0 && strings.Contains(mode, "seed") {
				choices = append(choices, signedBinding{})
			}
			left := cap
			var complete func(int, signedBinding)
			complete = func(pos int, v signedBinding) {
				if left <= 0 {
					return
				}
				if pos == width {
					var key [9]int32
					key[0] = rule.root
					copy(key[1:], v[:width])
					if seen[key] {
						return
					}
					seen[key] = true
					var env [8]int32
					for i, x := range v[:width] {
						env[i] = x - 1
					}
					left--
					p.tuples++
					p.assertRoot(p.ground(q.args[0], env[:width], &left))
					return
				}
				if v[pos] != 0 {
					complete(pos+1, v)
					return
				}
				candidates := p.choices[[2]int32{rule.root, int32(pos)}]
				if len(candidates) == 0 {
					candidates = p.domains[q.binds[pos]]
				}
				for _, x := range candidates[:min(len(candidates), max(1, k))] {
					v[pos] = x + 1
					complete(pos+1, v)
					if left <= 0 {
						break
					}
				}
			}
			for _, v := range choices {
				complete(0, v)
				if left <= 0 {
					break
				}
			}
		}
	}
}
