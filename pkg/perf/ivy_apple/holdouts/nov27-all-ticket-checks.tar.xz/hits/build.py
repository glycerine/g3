from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
ov=json.loads((w.parent/'retained/128.json').read_text())['Replace'];k=p/'smtcore/cached_var_subst.go';s=Path(ov[str(k)]).read_text().replace('"errors"','"errors"\n "fmt"\n "os"')
a='return c.refs[e.start+1+e.count], true';assert s.count(a)==1
s=s.replace(a,'if int(i)<=c.lastSearchSize {fmt.Fprintln(os.Stderr,"PREVIOUS-TUPLE")}\n'+a)
dst=w/k.name;dst.write_text(s);ov[str(k)]=str(dst)
of=w/'overlay.json';of.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags','xtrace_off','-overlay',of,'-o',w/'observe','./cmd/goivy_check'],cwd=front,check=True)
