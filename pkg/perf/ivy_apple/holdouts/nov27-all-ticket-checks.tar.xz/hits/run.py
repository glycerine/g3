from pathlib import Path
import csv,subprocess,os,sys,json
w=Path(__file__).resolve().parent
gold,ex=map(Path,sys.argv[1:3])
cases=json.loads((gold/'cases.json').read_text())
env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
with (w/'hits.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','prior_search_tuple_hits'])
 for case in ('ticket_protocol','hybrid','arm_rules3','fba'):
    path,iso,code=cases[case];ref=gold/'reference'/case
    r=subprocess.run(['taskset','-c','17',w/'observe']+(['isolate='+iso] if iso else [])+[ex/path],env=env,cwd=w,capture_output=True,timeout=180)
    marker=b'PREVIOUS-TUPLE\n'
    assert (r.returncode,r.stdout,r.stderr.replace(marker,b''))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    n=r.stderr.count(marker);out.writerow([case,n]);print(case,n)
