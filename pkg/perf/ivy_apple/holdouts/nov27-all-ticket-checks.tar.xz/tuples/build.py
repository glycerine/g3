from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
src=p/'ast/rewriter/ground_instance.go';s=src.read_text()
def replace(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)
s=replace(s,'if s == nil {','label:=0; defer trialSection(&label,body.Slot(),body.Generation())(); if s == nil {')
s=replace(s,'plan := c.plan(m, body)','plan := c.plan(m, body)')
s=replace(s,'if plan == nil || !plan.bind(m, bindings) {','''if plan == nil {
        if c.bodies[body].uses==4 {label=3} else {label=2}
        return s.Substitute(body,bindings,out)
    }
    if !plan.bind(m,bindings) {label=4''')
s=replace(s,'if err != nil || !previous.IsNull() {','if err != nil || !previous.IsNull() {label=5')
s=replace(s,'return c.apply(r, plan, out)','label=6;return c.apply(r, plan, out)')
s=replace(s,'return s.Substitute(body, bindings, out)\n\t}\n\tplan :=','label=1;return s.Substitute(body, bindings, out)\n\t}\n\tplan :=')
s=replace(s,'label:=0; defer trialSection', 'if priceActive {defer trialTuple(s.reducer.engine.core.manager, body,bindings,out)()}; label:=0; defer trialSection')
dst=w/src.name;dst.write_text(s)
frm=front/'z3bridge_solver_model.go';txt=(w.parent/'ordinary.go.txt').read_text()
txt=replace(txt,'import (','import (\n "github.com/glycerine/g3/pkg/ast/rewriter"')
txt=replace(txt,'res, err := s.decideZ3With(z3solver, finalCheck)','rewriter.TrialStartSubsts();res, err := s.decideZ3With(z3solver, finalCheck);rewriter.TrialStopSubsts(batch,ordinal+1)')
fdst=w/frm.name;fdst.write_text(txt)
counter=(w/'counter.go.txt').read_text()
ov=w/'overlay.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst),str(frm):str(fdst),str(front/'phase_observer_trial.go'):str(w/'noop.go.txt'),str(src.parent/'trial_substs.go'):str(w/'counter.go.txt')}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',mod,'-mod=readonly','-overlay',ov,'-tags','xtrace_off','-o',w/'observe','./cmd/goivy_check'],cwd=front,check=True)
