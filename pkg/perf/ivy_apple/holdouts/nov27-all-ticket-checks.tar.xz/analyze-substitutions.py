from pathlib import Path
from collections import Counter,defaultdict
from statistics import median
import csv
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'substitution/substitution.csv').open()))
by=defaultdict(lambda:defaultdict(Counter))
for r in rows:
 for col in ['calls','instructions']:by[r['path']][col][r['round']]+=int(r[col])
for p,cols in by.items():print(p,*(median(d.values()) for d in cols.values()))
seen=defaultdict(set);counts=Counter();costs=Counter()
for r in csv.DictReader((w/'bodies/bodies.csv').open()):
 b,g,s,v,l,i=map(int,r.values());k=b,s,v
 if l==2:
    old=any(prev!=g for prev in seen[k]);counts[old]+=1;costs[old]+=i
 seen[k].add(g)
print('prior sibling',counts,costs)
counts=Counter();costs=Counter()
for r in csv.DictReader((w/'tuples/tuples.csv').open()):
 counts[r['prior']]+=1;costs[r['prior']]+=int(r['instructions'])
print('prior tuple',counts,costs)
