from pathlib import Path
import sys,os,csv,json,subprocess,time
w=Path(__file__).resolve().parent
base,trial,src,gold,longrefs,output,cpu,n,*cases=sys.argv[1:];gold=Path(gold);longrefs=Path(longrefs)
specs=json.loads((gold/'cases.json').read_text())
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=src+'/ivy/include');env.pop('GOGC',None)
with (w/(output+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round engine instructions cycles milliseconds'.split())
 for c in cases:
    if c in specs:
        spec,iso,code=specs[c];ref=gold/'reference'/c
    elif c=='raft':
        spec='examples/raft/raft_no_assume.ivy';iso='';code=0;ref=longrefs/'raft-holdout/raft_no_assume/1/g3'
    else:
        spec='doc/examples/apple/ord_live.ivy';iso=c;code=0;ref=longrefs/'apple-holdout'/c/'1/g3'
    expected=code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()
    for rnd in range(int(n)):
        for label,exe in [('base',base),('trial',trial)][::1 if rnd%2==0 else -1]:
            counters=w/(output+'.stat')
            cmd=['taskset','-c',cpu,'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',counters,'-e','instructions:u,cycles:u','--',exe]+(['isolate='+iso] if iso else [])+[src+'/'+spec]
            start=time.monotonic()
            r=subprocess.run(cmd,cwd=w,env=env,capture_output=True,timeout=180)
            ms=(time.monotonic()-start)*1000
            assert (r.returncode,r.stdout,r.stderr)==expected,(c, label,r.returncode,r.stderr[:250],len(r.stdout))
            d={x[2]:int(x[0]) for x in csv.reader(counters.read_text().splitlines()) if len(x)>2 and x[2] in ('instructions:u','cycles:u')}
            out.writerow([c,rnd,label,d['instructions:u'],d['cycles:u'],ms]);f.flush()
    print(c,n,flush=True)
