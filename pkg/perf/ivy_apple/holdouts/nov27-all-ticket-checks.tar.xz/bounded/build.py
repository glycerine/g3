from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
a=p/'ast/rewriter/ground_instance.go';c=p/'smtcore/cached_var_subst.go';key='if err := c.plans.Clear(); err != nil {'
assert c.read_text().count(key)==1
files={}
for src,txt in [(c,c.read_text().replace(key,'if err := c.plans.TrialReset(reuse && len(c.list)>0); err != nil {')),(a,a.read_text()+'''
// Preserve only small, recently used tables of weak body metadata.
func (c *GroundInstancePlans) TrialReset(active bool) error {
	if !active || c.size > 8192 || len(c.bodies) > 32 {return c.Clear()}
	if err := c.release(); err != nil {return err}
	c.held=nil
	c.args=nil
	return nil
}
''')]:
    dst=w/src.name;dst.write_text(txt);files[str(src)]=str(dst)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags','xtrace_off','-overlay',ov,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
