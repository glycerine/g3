from pathlib import Path
import subprocess,sys,os,json,re,csv,collections,statistics
w=Path(__file__).resolve().parent
gold,ex=map(Path,sys.argv[1:3])
spec=ex/json.loads((gold/'cases.json').read_text())['ticket_protocol'][0]
env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
labels=['tracing or canceled','budget','cold','compile refused','bind refused','previous result','compiled']
with (w/'substitution.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['round','batch','goal','path','calls','instructions'])
 for n in range(5):
    r=subprocess.run(['taskset','-c','17',w/'observe',spec],env=env,cwd=w,capture_output=True,timeout=120,check=True)
    ref=gold/'reference/ticket_protocol';clean=bytearray();seen=set()
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'SUBSTS '):
            b,g,a,d=re.fullmatch(rb'SUBSTS (\d+) (\d+) \[([^]]*)\] \[([^]]*)\]\n',line).groups()
            key=(int(b),int(g));assert key not in seen;seen.add(key)
            for label,cost,count in zip(labels,map(int,d.split()),map(int,a.split()),strict=True):writer.writerow([n,*key,label,count,cost])
        else:clean.extend(line)
    assert len(seen)==284 and r.stdout==(ref/'stdout').read_bytes() and clean==(ref/'stderr').read_bytes()
    print(n,len(seen),flush=True)
