"""Report mutually exclusive solver-thread instruction samples by sibling group."""
from pathlib import Path
from collections import Counter,defaultdict
import csv
root=Path(__file__).resolve().parent
counts=Counter(); rounds=defaultdict(set)
for r in csv.DictReader((root/'sample-stacks.csv').open()):
    b,g,n=map(int,(r['batch'],r['goal'],r['round']))
    label='repeated' if b in range(2,6) and g in (55,56) else 'late' if b in (6,7,8) and g==1 else 'other'
    s=r['stack']; go=r['engine']=='g3'
    entry='(*SMTQuantifierManager).instantiate\n' if go else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)'
    if entry in s:
        pairs=[('substitution',['(*SMTCachedVarSubstitution).Instantiate','cached_var_subst::operator()']),('rewrite',['(*TheoryRewriter).Rewrite','rewriter_tpl<th_rewriter_cfg>','th_rewriter::operator()']),('assertion',['(*SMTInternalizerState).assertExpression','smt::context::internalize_assertion']),('instance checker',['(*SMTChecker).run','smt::checker::is_sat'])]
        phase='other instance'
    else:
        pairs=[('rewriter settings',['setAssertedEliminateAnd','asserted_formulas::set_eliminate_and']),('conflict resolution',['(*SMTKernel).resolveSearchConflict','smt::context::resolve_conflict(']),('preprocessing',['(*SMTKernel).internalizeCheckAssertions','smt::context::internalize_assertions(']),('matching',['(*smtMAMImpl).Match','smt::mam_impl::match(']),('propagation',['(*SMTInternalizerState).PropagateCore','smt::context::propagate('])]
        phase='other solver'
    phase=next((k for k,markers in pairs if any(m in s for m in markers)),phase)
    rounds[r['engine']].add(n)
    counts[label,r['engine'],phase]+=int(r['period'])*int(r['samples'])
with (root/'phases.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['group','phase','g3_million','z3_million','excess_million'])
    for label in ('other','repeated','late'):
        items=[]
        for p in {k[-1] for k in counts}:
            a,z=[counts[label,e,p]/len(rounds[e])/1e6 for e in ['g3','z3']]
            items.append((a-z,p,a,z))
        for d,p,a,z in sorted(items,reverse=True):out.writerow([label,p,round(a,3),round(z,3),round(d,3)])
print(dict(rounds))
