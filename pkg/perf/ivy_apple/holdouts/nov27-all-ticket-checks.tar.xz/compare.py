"""Compare complete Ticket runs by logical goal; each phase has one counter per round."""
import csv, statistics, sys
from collections import defaultdict
from pathlib import Path
root=Path(__file__).resolve().parent
def read(path):
    rounds=defaultdict(dict)
    for row in csv.DictReader(open(path)):
        if row['phase']!='check': continue
        key=int(row['batch']),int(row['goal'])
        current=rounds[int(row['round'])]
        assert key not in current
        current[key]=int(row['instructions'])
    first=next(iter(rounds.values()))
    assert all(table.keys()==first.keys() for table in rounds.values())
    return {key:statistics.median(r[key] for r in rounds.values()) for key in first}
release,ordinary,native=map(read,sys.argv[1:4])
assert native.keys()==ordinary.keys() and release.keys()<=native.keys()
with (root/'ranking.csv').open('w') as f:
    w=csv.writer(f);w.writerow(('batch','goal','released_check','ordinary_check','native_check','ordinary_excess','released_excess'))
    for k in sorted(native,key=lambda k:native[k]-ordinary[k]):
        w.writerow((*k,release.get(k,''),ordinary[k],native[k],ordinary[k]-native[k],release.get(k,0)-native[k]))
groups=defaultdict(list)
for k in native:
    batch,goal=k
    key='lines 333/345' if batch in range(2,6) and goal in (55,56) else 'late goals' if batch in (6,7,8) and goal==1 else 'other'
    groups[key].append(k)
for name,keys in groups.items():
    print(name,len(keys),*[round(sum(data.get(k,0) for k in keys)/1e6,2) for data in (release,ordinary,native)])
print('ordinary top',[(k,round((ordinary[k]-native[k])/1e6,2)) for k in sorted(native,key=lambda k:native[k]-ordinary[k])[:10]])
