from pathlib import Path
import os,csv,subprocess,sys,json
w=Path(__file__).resolve().parent
gold,ex=map(Path,sys.argv[1:3]);spec=ex/json.loads((gold/'cases.json').read_text())['ticket_protocol'][0]
r=subprocess.run(['taskset','-c','17',w/'observe',spec],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,check=True)
clean=bytearray();pending=[];ng=0
with (w/'bodies.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['batch','goal','slot','generation','label','instructions'])
 for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'BODY '):pending.append(list(map(int,line.split()[1:])))
    elif line.startswith(b'SUBSTS '):
        b,g=map(int,line.split()[1:3]);ng+=1;out.writerows([b,g,*p] for p in pending);pending.clear()
    else:clean.extend(line)
ref=gold/'reference/ticket_protocol'
assert not pending and ng==284 and clean==(ref/'stderr').read_bytes() and r.stdout==(ref/'stdout').read_bytes()
