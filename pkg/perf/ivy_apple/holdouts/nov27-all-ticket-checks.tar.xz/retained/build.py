from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3]);bound=int(sys.argv[3])
q=p/'smtcore/smt_quantifier_manager.go';c=p/'smtcore/cached_var_subst.go'
src=q.read_text().replace('if err := q.substitute.Reset(); err != nil {','if err := q.substitute.trialSearchReset(); err != nil {')
assert src!=q.read_text()
cs=c.read_text().replace('closed bool','lastSearchSize int\n closed bool')
cs+=f'''
// Trial keeps a bounded tuple directory through searches that use it.
func (c *SMTCachedVarSubstitution) trialSearchReset() error {{
    n:=len(c.list)
    if n>c.lastSearchSize && n<={bound} && len(c.refs)<={bound*6} &&
       !ast.ASTValidateHandles && !ast.ASTSourceDebug && c.manager.TraceStream==nil &&
       !c.manager.Budget().InjectionArmed() && c.manager.ResourceLimit().Limit==0 && !c.manager.ResourceLimit().CancelFlag() {{
       c.lastSearchSize=n
       return c.plans.Clear()
    }}
    c.lastSearchSize=0
    return c.Reset()
}}
'''
files={}
for k,s in [(c,cs),(q,src)]:
 dst=w/(str(bound)+'-'+k.name);dst.write_text(s);files[str(k)]=str(dst)
ov=w/(str(bound)+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags','xtrace_off','-overlay',ov,'-o',w/('trial'+str(bound)),'./cmd/goivy_check'],cwd=front,check=True)
