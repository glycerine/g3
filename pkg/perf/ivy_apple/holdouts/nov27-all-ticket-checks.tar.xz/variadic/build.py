from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent;front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
src=Path.cwd()/'ast/ast_core_factories.go';s=src.read_text()
key='\t\t\tif args.count == d.arity {'
assert s.count(key)==1
s=s.replace(key,'''			if args.count != d.arity && args.count >= 2 && d.identityCached && d.identityFlags.FlatAssociative &&
				d.identityFlags.LeftAssociative && d.identityFlags.RightAssociative {
				return m.mkAppCoreArgumentsFramed(decl, &args, nil, d, true)
			}
'''+key)
dst=w/src.name;dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags','xtrace_off','-overlay',ov,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
