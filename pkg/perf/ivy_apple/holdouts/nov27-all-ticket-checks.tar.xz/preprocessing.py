"""Partition preprocessing stacks on the 273 previously unprofiled Ticket checks."""
from pathlib import Path
import csv,collections
w=Path(__file__).resolve().parent
counts=collections.Counter();rounds=collections.defaultdict(set)
for r in csv.DictReader((w/'sample-stacks.csv').open()):
    b,g=int(r['batch']),int(r['goal']);e=r['engine'];rounds[e].add(r['round'])
    if b in range(2,6) and g in (55,56) or b in (6,7,8) and g==1:continue
    s=r['stack']
    if '(*SMTKernel).internalizeCheckAssertions' not in s and 'smt::context::internalize_assertions(' not in s:continue
    if '(*SMTQuantifierManager).instantiate\n' in s or 'smt::qi_queue::instantiate(smt::qi_queue::entry&)' in s:continue
    tests=[
    ('phase settings','setAssertedEliminateAnd','asserted_formulas::set_eliminate_and'),
    ('whole macro finder','findPendingMacros','asserted_formulas::find_macros_core()'),
    ('value propagation','propagatePendingAssertions','asserted_formulas::propagate_values('),
    ('NNF','normalizePendingAssertions','asserted_formulas::nnf_cnf('),
]
    phase=next((k for k,go,z in tests if (go if e=='g3' else z) in s),'other preprocessing')
    counts[e,phase]+=int(r['period'])*int(r['samples'])
with (w/'preprocessing.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['group','g3_million','z3_million','excess_million'])
 for phase in sorted({k[1] for k in counts}):
    a,b=(counts[e,phase]/len(rounds[e])/1e6 for e in ['g3','z3']);out.writerow([phase,round(a,3),round(b,3),round(a-b,3)])
