"""Summarize paired verifier and fresh-replay measurements."""
import csv,statistics,sys
from pathlib import Path
w=Path(__file__).resolve().parent
for name in sys.argv[1:]:
    rows=list(csv.DictReader((w/name).open()));key='case' if 'case' in rows[0] else 'query'
    d={(r[key],int(r['round']),r['engine']):r for r in rows}
    base='native' if name=='native-comparison.csv' else 'base'
    for q in sorted({k[0] for k in d}):
        for e in sorted({k[2] for k in d}-{base}):
            pairs=sorted(i for n,i,k in d if n==q and k==e)
            if not pairs:continue
            vals=[statistics.median(float(d[q,i,e][c])/float(d[q,i,base][c]) for i in pairs) for c in ['instructions','cycles','milliseconds']]
            elapsed=[statistics.median(float(d[q,i,k]['milliseconds']) for i in pairs) for k in [e,base]]
            print(name,q,e,len(pairs),*[round(x,4) for x in vals],*[round(x,1) for x in elapsed])
