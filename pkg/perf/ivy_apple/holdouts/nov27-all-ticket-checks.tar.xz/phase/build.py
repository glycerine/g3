"""Experimental ceiling for toggling the asserted formula rewriter's elim_and phase."""
from pathlib import Path
import sys, subprocess, json
w=Path(__file__).resolve().parent; pkg=Path.cwd()
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
k=pkg/'smtcore/smt_asserted_reduce.go'; theory=pkg/'ast/rewriter/th_rewriter.go'
s=k.read_text(); needle='\tsettings := []struct {'
assert s.count(needle)==1
s=s.replace(needle,'''	if k.assertedPhaseReady {
		name := "elim_and"
		if err := k.paramContext.SetBoolName(&k.assertedParams, &name, flag); err != nil { return err }
		if err := k.preprocessor.TrialSetEliminateAnd(&k.assertedParams,flag); err != nil { return err }
		if err := k.flushAssertedCache(); err != nil { return err }
		k.assertedElimAnd = flag
		return nil
	}
'''+needle)
t=theory.read_text()+'''
func (r *TheoryRewriter) TrialSetEliminateAnd(p *uparams.ParamsRef,flag bool) error {
	if err:=r.context.Assign(&r.params,p);err!=nil{return err}
	return r.configuration.boolean.SetEliminateAnd(flag)
}
'''
files={}
for src,txt in [(k,s),(theory,t)]:
    dst=w/src.name;dst.write_text(txt);files[str(src)]=str(dst)
overlay=w/'trial.json';overlay.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags','xtrace_off','-overlay',overlay,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
