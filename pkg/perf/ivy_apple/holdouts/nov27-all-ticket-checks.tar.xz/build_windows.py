from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent
front,mod,base=map(lambda x:Path(x).resolve(),sys.argv[1:4])
for name,src,tags in [('g3','ordinary.go.txt','xtrace_off'),('z3','z3bridge_solver_model.go','xtrace_off,classic_z3')]:
    sources={str(front/'phase_observer_trial.go'):str(w/'windows.go.txt'),str(front/'z3bridge_solver_model.go'):str((w if name=='g3' else base)/src)}
    ov=w/(name+'-windows.json')
    ov.write_text(json.dumps({'Replace':sources}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags',tags,'-overlay',ov,'-o',w/(name+'-windows'),'./cmd/goivy_check'],cwd=front,check=True)
