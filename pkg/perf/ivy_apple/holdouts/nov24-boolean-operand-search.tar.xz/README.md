# Boolean reductions and compiled ground substitutions

These overlays apply to g3 ba98b3ada (also 27b16460e). Extract the archive into a temporary directory and run the commands with the path to this repository's Go module. The driver applies each patch to a temporary copy of its source file and gives Go a file overlay.

    python3 replay.py --pkg /path/to/g3/pkg --variant oracle
    python3 replay.py --pkg /path/to/g3/pkg --variant all --bench
    python3 replay.py --pkg /path/to/g3/pkg --variant all --case miss3 --native /path/to/g3/build/z3
    python3 replay.py --pkg /path/to/g3/pkg --variant bounded --case core3 --native /path/to/g3/build/z3

The direct benchmark compares 80,000 and 400,000 operations. micro.csv records both complete processes for each of five rotating pairs. Subtract process instructions and divide by 320,000 for an instructions-per-operation slope. Each whole-verifier instruction series has three rotating rounds per engine. The standalone shell comparison uses the original SMT-LIB and compares every integer statistic aside from memory, allocation and elapsed-time measures. Three full-budget UNKNOWN queries and three independently verified UNSAT subsets are included.

The oracle compares exact rewrite status, AST handle and local-context budget across 66,048 configurations and inputs. An earlier prototype mishandled the priority of constant and complement rewrites when the equality had operands true and (not true). Only the corrected variant and results are included.
