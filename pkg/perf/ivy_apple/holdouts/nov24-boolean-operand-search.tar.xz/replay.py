"""Build and replay a saved Boolean reduction or bounded substitution experiment."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--pkg', type=Path, required=True)
p.add_argument('--variant', choices=['before','eq','not','pair','all','oracle','bounded'], required=True)
p.add_argument('--case', choices=[s.stem for s in sorted((root/'queries').glob('*.smt2'))])
p.add_argument('--native', type=Path)
p.add_argument('--bench', action='store_true')
a = p.parse_args()
pkg = a.pkg.resolve()
env = dict(os.environ, GOMAXPROCS='1')
if not (a.variant == 'oracle' or a.bench or a.case):
    p.error('choose --case or --bench for this variant')

def search(binary, fixture):
    r = subprocess.run([binary, '-st', '-smt2', fixture], check=True, capture_output=True, text=True, env=env)
    if r.stderr:
        raise RuntimeError(r.stderr)
    stats = {k:int(v) for k,v in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])', r.stdout)
             if all(word not in k for word in ['memory','alloc','time'])}
    return r.stdout.splitlines()[0], stats

with tempfile.TemporaryDirectory() as td:
    base = Path(td)
    manifest = json.loads((root/'overlays'/a.variant/'manifest.json').read_text())
    replacements = {}
    for rel, resource in manifest.items():
        inp = root/resource
        out = base/rel
        out.parent.mkdir(parents=True, exist_ok=True)
        if inp.suffix == '.patch':
            subprocess.run(['patch','--batch','--fuzz=0','--silent','-o',out,pkg/rel,'-i',inp], check=True)
        else:
            out.write_bytes(inp.read_bytes())
        replacements[str(pkg/rel)] = str(out)
    overlay = base/'overlay.json'
    overlay.write_text(json.dumps({'Replace':replacements}))
    flags = ['-tags=xtrace_off','-overlay='+str(overlay)]
    if a.variant == 'oracle':
        subprocess.run(['go','test',*flags,'-count=1','-v','-run=^TestStudyOperandReductions$','./ast/rewriter'], cwd=pkg, env=env, check=True)
    if a.bench:
        subprocess.run(['go','test',*flags,'-cpu=1','-run=^$','-bench=^BenchmarkTheoryReduction$/.*/^Core$','-benchtime=400000x','./ast/rewriter'], cwd=pkg, env=env, check=True)
    if a.case:
        binary=base/'g3'
        subprocess.run(['go','build',*flags,'-pgo=off','-o',binary,'./cmd/g3'],cwd=pkg,env=env,check=True)
        fixture=root/'queries'/(a.case+'.smt2')
        answer, stats=search(binary,fixture)
        archived = root/('bounded/search' if a.variant=='bounded' else 'search')/(a.case+'.csv')
        with archived.open() as fp:
            row=next(csv.DictReader(fp))
        if answer!=row['answer'] or any(stats.get(k,0)!=int(row[c]) for k,c in
                [('decisions','decisions'),('conflicts','conflicts'),('quant-instantiations','qi'),('rlimit-count','resources')]):
            raise ValueError(f'{a.case} search counters changed')
        if a.native and (answer,stats)!=search(a.native.resolve(),fixture):
            raise ValueError(f'{a.case} differs from native')
        print(a.case,answer,stats.get('quant-instantiations',0),'instances',stats['rlimit-count'],'resource units')
