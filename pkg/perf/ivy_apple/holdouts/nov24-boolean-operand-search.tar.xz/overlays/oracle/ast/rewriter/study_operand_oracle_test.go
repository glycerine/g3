package rewriter

import (
	"github.com/glycerine/g3/pkg/ast"
	"testing"
)

func TestStudyOperandReductions(t *testing.T) {
	m, c, g, p := boolRewriterConfigFixture(t)
	a, err := NewTheoryRewriter(m, c, g, p)
	astTestMust(t, err)
	t.Cleanup(func() { astTestMust(t, a.Close()) })
	b, err := NewTheoryRewriter(m, c, g, p)
	astTestMust(t, err)
	t.Cleanup(func() { astTestMust(t, b.Close()) })
	hold := func(h ast.ASTHandle, e error) ast.ASTHandle { astTestMust(t, e); astTestPin(t, m, h); return h }
	st := hold(m.MkBoolSort())
	x := hold(m.MkConst(astTestSymbol(t, m, "x"), st))
	y := hold(m.MkConst(astTestSymbol(t, m, "y"), st))
	z := hold(m.MkConst(astTestSymbol(t, m, "z"), st))
	v := hold(m.MkVar(0, st))
	fun := hold(m.MkFuncDecl(astTestSymbol(t, m, "P"), []ast.ASTHandle{st, st}, st, ast.ASTFuncDeclInfo{}))
	h := []ast.ASTHandle{x, y, z, v, hold(m.MkTrue()), hold(m.MkFalse()), hold(m.MkApp(fun, []ast.ASTHandle{x, y})), hold(m.MkNot(x)), hold(m.MkNot(y)), hold(m.MkAnd(x, y)), hold(m.MkOr(y, z)), hold(m.MkIff(x, y)), hold(m.MkEq(x, y)), hold(m.MkIte(x, y, z)), hold(m.MkImplies(x, z)), hold(m.MkXor(x, y))}
	n := len(h)
	for _, v := range h[:n] {
		h = append(h, hold(m.MkNot(v)))
	}
	basis := []ast.ASTHandle{hold(m.MkNot(x)), hold(m.MkEq(x, y)), hold(m.MkIff(x, y)), hold(m.MkAnd(x, y)), hold(m.MkOr(x, y))}
	lo := astTestPin(t, m, x)
	hi := astTestPin(t, m, x)
	total := 0
	for options := range 16 {
		for _, rw := range []*TheoryRewriter{a, b} {
			rw.configuration.boolean.elimAnd = options&1 != 0
			rw.configuration.boolean.flat = options&2 != 0
			rw.configuration.boolean.localContext = options&4 != 0
			rw.configuration.boolean.iteExtraRules = options&8 != 0
		}
		for k, node := range basis {
			decl, e := m.GetDecl(node)
			astTestMust(t, e)
			for i, u := range h {
				for j, w := range h {
					av := []ast.ASTHandle{u, w}
					if k == 0 {
						if j != 0 {
							continue
						}
						av = av[:1]
					}
					args := ast.SliceArguments(av)
					astTestMust(t, m.SetRef(lo, z))
					astTestMust(t, m.SetRef(hi, z))
					want, e := a.configuration.studyOriginalReduction(decl, args, lo)
					astTestMust(t, e)
					got, e := b.configuration.reduceAppCore(decl, args, hi)
					astTestMust(t, e)
					lhs, e := m.RefGet(lo)
					astTestMust(t, e)
					rhs, e := m.RefGet(hi)
					astTestMust(t, e)
					if want != got || lhs != rhs || a.configuration.boolean.localContextCost != b.configuration.boolean.localContextCost {
						t.Fatalf("options %d, op %d, args %d %d: previous %v %v local %v, candidate %v %v local %v", options, k, i, j, want, lhs, a.configuration.boolean.localContextCost, got, rhs, b.configuration.boolean.localContextCost)
					}
					total++
				}
			}
		}
	}
	t.Log("identical reductions, results and local-context charges", total)
}
