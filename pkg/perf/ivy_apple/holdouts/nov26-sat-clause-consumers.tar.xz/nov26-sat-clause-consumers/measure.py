"""Rotate DIMACS runs on one CPU with matched search and model checks."""

import argparse
import csv
import io
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pkg", type=Path, default=Path.cwd())
    parser.add_argument("--perf", default="perf")
    parser.add_argument("--cpu", required=True, type=int)
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--case", action="append", required=True,
                        help="verdict:filename, or verdict:filename:stdin")
    parser.add_argument("engines", nargs="+", help="label=executable")
    args = parser.parse_args()
    sys.path.insert(0, str(args.pkg / "perf/ivy_raft"))
    from watch_propagation import check_output

    env = dict(os.environ, GOMAXPROCS="1", LC_ALL="C")
    engines = [entry.split("=", 1) for entry in args.engines]
    keys = ("conflicts", "decisions", "propagations", "ternary-propagations",
            "binary-propagations")
    write = csv.writer(sys.stdout)
    write.writerow(("case", "input", "engine", "round", "answer", "instructions",
                    "cycles", "milliseconds", *keys))

    for case in args.case:
        status, filename, *mode = case.split(":")
        file = Path(filename)
        source = file.read_text()
        rows = [row.split() for row in source.splitlines() if row.strip() and not row.lstrip().startswith("c")]
        variables, count = map(int, rows[0][2:])
        clauses, clause = [], []
        for row in rows[1:]:
            for lit in map(int, row):
                if lit:
                    clause.append(lit)
                else:
                    clauses.append(clause)
                    clause = []
        if clause or len(clauses) != count:
            raise ValueError(f"invalid DIMACS fixture {file}")
        expected = None
        for turn in range(args.rounds):
            offset = turn % len(engines)
            for label, binary in engines[offset:] + engines[:offset]:
                command = ["taskset", "-c", str(args.cpu), args.perf, "stat", "-x,", "-e",
                           "instructions:u,cycles:u", "--", binary, "-st", "-dimacs",
                           "-in" if mode else str(file)]
                start = time.monotonic()
                run = subprocess.run(command, input=source if mode else None,
                                     capture_output=True, text=True, env=env, timeout=90)
                elapsed = (time.monotonic() - start) * 1e3
                if run.returncode not in (0, 10 if status == "sat" else 20):
                    raise RuntimeError((case, label, run.returncode, run.stdout, run.stderr))
                stats = check_output(run.stdout, status, variables, clauses)
                values = tuple(stats.get(key, 0) for key in keys)
                if expected is None:
                    expected = values
                if values != expected or not values[1]:
                    raise RuntimeError((case, label, dict(zip(keys, values)), expected))
                counters = {}
                for row in csv.reader(io.StringIO(run.stderr)):
                    if len(row) >= 5 and row[2] in ("instructions:u", "cycles:u"):
                        if float(row[4]) < 99.5:
                            raise RuntimeError((case, label, "multiplexed counters", row))
                        counters[row[2]] = int(row[0])
                write.writerow((file.stem, "stdin" if mode else "file", label, turn + 1,
                                status, counters["instructions:u"], counters["cycles:u"],
                                f"{elapsed:.3f}", *values))
                sys.stdout.flush()


if __name__ == "__main__":
    main()
