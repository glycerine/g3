"""Attribute hot clause storage leaves to callers in a perf script recording."""
from collections import Counter, defaultdict
import csv
from pathlib import Path
import sys

for filepath in sys.argv[1:]:
    path = Path(filepath)
    total = 0
    groups = defaultdict(Counter)
    for block in path.read_text().split('\n\n'):
        lines = block.splitlines()
        if len(lines) < 2:
            continue
        total += 1
        leaf, stack = lines[1], '\n'.join(lines[1:])
        kinds = {
            'borrow': '(*SmallBytes).Borrow',
            'descriptor': '(*SmallBytes).descriptor',
            'scalar-read': '(*SmallBytes).ReadUint32LE',
            'scalar-write': '(*SmallBytes).WriteUint32LE',
            'clause-literal': '(*ClauseAllocator).Literal',
            'watch-move': 'satClauseView.moveWatch',
        }
        kind = next((k for k, symbol in kinds.items() if symbol in leaf), None)
        if kind is None:
            continue
        callers = {
            'glue': ('.numDiffLevels',),
            'first-UIP reason': ('.processConsequent',),
            'conflict minimization': ('.impliedByMarked', '.processAntecedentForMinimization'),
            'simplifier': ('(*satSimplifierKernel)', '(*satSolverSimplifier)'),
            'propagation': ('.propagateCore',),
            'watch detach and cleanup': ('.detachClause', '.removeClause', '.gcClauses'),
        }
        category = next((group for group, symbols in callers.items() if any(s in stack for s in symbols)), 'other')
        groups[kind][category] += 1
    w = csv.writer(sys.stdout)
    for kind, g in groups.items():
        for group, n in g.most_common():
            w.writerow((path.stem, kind, group, n, total, round(100*n/total,3)))
