"""Build the solver with counters for existing watch formats and writes."""

import json
import os
from pathlib import Path
import subprocess


pkg = Path.cwd()
out = Path(__file__).resolve().parent
overlay = {}


def replace(filename, changes):
    source = pkg / "sat" / filename
    code = source.read_text()
    for old, new in changes:
        if code.count(old) != 1:
            raise ValueError((source, old))
        code = code.replace(old, new)
    target = out / ("observe-" + filename)
    target.write_bytes(subprocess.check_output(["gofmt"], input=code.encode()))
    overlay[str(source)] = str(target)


replace("sat_solver_propagation_control.go", [
    ("type satSolverPropagationState struct {", """type satSolverPropagationState struct {
        watchVisits [4]uint64
        blocked, compactSmall, wideSmall, large, moves, appendedEncoded, identical uint64"""),
])
replace("sat_solver_propagation.go", [
    ("switch w.Kind() {", "s.watchVisits[w.Kind()]++\n switch w.Kind() {"),
    ("if assignment[blocked.index()] == lbool.True {",
     "if assignment[blocked.index()] == lbool.True {\n s.blocked++"),
    ("c := StoredClauseRef(off)", """if off.storageKind != 0 {
            s.large++
        } else if bits.val1>>satWatchSlotBits == satWatchWide {
            s.wideSmall++
        } else {
            s.compactSmall++
        }
        c := StoredClauseRef(off)"""),
    ("if moved {", "if moved {\n s.moves++"),
    ("dest.appendEncoded(satWatchWords{bits.val1, 2 + uint32(c0)<<2}, iter.backing.owner) {",
     "dest.appendEncoded(satWatchWords{bits.val1, 2 + uint32(c0)<<2}, iter.backing.owner) {\n s.appendedEncoded++"),
    ("if keep {\n\t\t\t\tdata[out]", """if keep {
        if destinations != nil && out == pos && w.val2 == bits.val2 {
            s.identical++
        }
        data[out]"""),
])
replace("sat_tactic_boundary.go", [
    ("return s.collectStatistics(st, keys)", """err := s.collectStatistics(st, keys)
    p := s.propagation
    if err == nil && p != nil {
        st.UpdateUint64("watch binary visits", p.watchVisits[0])
        st.UpdateUint64("watch ternary visits", p.watchVisits[1])
        st.UpdateUint64("watch long visits", p.watchVisits[2])
        st.UpdateUint64("watch extension visits", p.watchVisits[3])
        st.UpdateUint64("watch blocked", p.blocked)
        st.UpdateUint64("watch compact small", p.compactSmall)
        st.UpdateUint64("watch wide small", p.wideSmall)
        st.UpdateUint64("watch large", p.large)
        st.UpdateUint64("watch moves", p.moves)
        st.UpdateUint64("watch appended encoded", p.appendedEncoded)
        st.UpdateUint64("watch identical", p.identical)
    }
    return err"""),
])
config = out / "observe-overlay.json"
config.write_text(json.dumps({"Replace": overlay}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-overlay", str(config),
                "-o", str(out / "observe"), "./cmd/g3"], cwd=pkg, env=os.environ, check=True)
