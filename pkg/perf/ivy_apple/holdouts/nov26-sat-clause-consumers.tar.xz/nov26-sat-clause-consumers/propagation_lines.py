"""Locate propagation leaf samples by Go source line."""

from collections import Counter
import csv
from pathlib import Path
import subprocess
import sys


def main(binary, profiles):
    result = csv.writer(sys.stdout)
    result.writerow(("profile", "file", "line", "samples", "total", "percent"))
    for file in map(Path, profiles):
        addresses = Counter()
        total = 0
        for event in file.read_text().split("\n\n"):
            lines = event.splitlines()
            if len(lines) < 2:
                continue
            total += 1
            if "(*satSolverPropagationState).propagateCore+" in lines[1]:
                addresses[lines[1].split()[0]] += 1
        report = subprocess.run(["go", "tool", "addr2line", binary],
                                input="\n".join(addresses) + "\n", capture_output=True,
                                text=True, check=True).stdout.splitlines()
        by_line = Counter()
        for address, location in zip(addresses, report[1::2], strict=True):
            filename, line = location.rsplit(":", 1)
            by_line[(Path(filename).name, int(line))] += addresses[address]
        for (filename, line), count in by_line.most_common():
            result.writerow((file.stem, filename, line, count, total, f"{100*count/total:.3f}"))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2:])
