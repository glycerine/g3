# Matched SAT subsumption and propagation

Run from `pkg/`. The baseline is `b9dbd35bf`. The earlier baseline profiles used `981a99a13`, which has the same SAT source. The native executable is this fork's `../build/z3`. Build each Go variant with `go build -pgo=off -buildvcs=false -o /path/to/binary ./cmd/g3`. The `scan` binary contains the shipped collector patch. `borrowed` is the preliminary version with a separate borrowed iterator step that checks the occurrence record for each candidate. Only measurements of that preliminary version are retained here.

Extract this archive into a fresh output directory. With built binaries named `baseline` and `scan`, rerun the paired comparison from `pkg/`.

```sh
out=/path/to/unpacked/nov26-sat-clause-consumers
python3 "$out/measure.py" --cpu 11 --rounds 5 \
    --case "unsat:$out/fixtures/random-208-3.cnf" \
    --case "sat:$out/fixtures/random-208-4.cnf" \
    --case "sat:$out/fixtures/planted3.cnf:stdin" \
    --case "sat:$out/fixtures/planted8.cnf:stdin" \
    "baseline=$out/baseline" "scan=$out/scan" "z3=../build/z3"
```

Use `--perf` if your Linux installation has separate perf executables by kernel version. The measurement driver pins each solver, checks instruction-counter coverage, verifies satisfying models, and compares decisions, conflicts and propagations. The five-round table is in `confirmed.csv`. `gc-off.csv` confirms the stdin controls with `GOGC=off`. `skip-identical.csv` and `skip-repeat.csv` record the guarded watch-write experiment across four and seven rotations. `borrow-encoded.csv` records five rotations of the compact-word borrow experiment. Apply each trial patch to the updated collector source to rebuild it.

Build the watch census by copying `observe.py` to a writable output directory and running it from the updated `pkg/`. It checks that each overlay replacement occurs once and writes the instrumented binary next to the script. The two runs used `GOMAXPROCS=1 taskset -c 9 /path/to/observe -st -dimacs fixtures/random-208-3.cnf` and the equivalent seed 4 command. Any zero watch counts are omitted by the standard CLI statistics format.

The profiles sampled every 2,000,003 user instructions via `perf record -B -N --call-graph fp -e instructions:u -c 2000003`. The `profile/` and `after/` directories contain sample attribution, native and Go reports, the dumped stacks and lost/throttled-event counts. `classify.py` groups arena leaves by caller. `propagation_lines.py` maps Go leaf instruction addresses to source lines with the exact binary used to record them.
