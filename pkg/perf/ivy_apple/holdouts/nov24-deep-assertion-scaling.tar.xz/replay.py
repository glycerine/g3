"""Benchmark shared deep assertions with an adjustable live Boolean population."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--pkg',type=Path,required=True)
p.add_argument('--cpu',type=int,required=True)
p.add_argument('--perf',default='perf')
p.add_argument('--rounds',type=int,default=5)
p.add_argument('--output',type=Path,required=True)
args = p.parse_args()
pkg = args.pkg.resolve()
sys.path.insert(0,str(pkg/'perf/ivy_apple'))
from native_benchmark import build_native

with tempfile.TemporaryDirectory() as scratch, args.output.open('x',newline='') as out:
    tmp = Path(scratch)
    native = tmp/'native'
    build_native(pkg.parent/'build',native,pkg.parent/'src/test/perf/deep_shared_assertion.cpp')
    subst = {}
    for rel in ('smtcore/smt_internalizer.go','smtcore/smt_internalizer_order.go'):
        src = tmp/Path(rel).name
        src.write_bytes(subprocess.check_output(['git','show','0d489f264:pkg/'+rel],cwd=pkg))
        subst[str(pkg/rel)] = str(src)
    # The new correctness test refers to the new internal field.
    rel = 'smtcore/smt_internalizer_order_test.go'
    src = tmp/Path(rel).name
    src.write_bytes(subprocess.check_output(['git','show','0d489f264:pkg/'+rel],cwd=pkg))
    subst[str(pkg/rel)] = str(src)
    ov = tmp/'overlay.json'
    ov.write_text(json.dumps({'Replace':subst}))
    for name,flags in [('before',['-overlay='+str(ov)]),('indexed',[])]:
        subprocess.run(['go','test','-tags=xtrace_off',*flags,'-c','-o',tmp/name,'./smtcore'],cwd=pkg,check=True)
    writer = csv.writer(out)
    writer.writerow('round engine unrelated count ns bytes allocs instructions cycles'.split())
    engines = ['before','indexed','native']
    for i in range(args.rounds):
        for name in engines[i%3:]+engines[:i%3]:
            for n in [0,1024,16384]:
                for k in ([200,1000] if name=='before' else [5000,25000]):
                    if name=='native':
                        cmd = [native,str(n),str(k)]
                    else:
                        cmd = [tmp/name,'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTDeepSharedAssertion$/^Unrelated'+str(n)+'$','-test.benchtime='+str(k)+'x']
                    counter = tmp/'counter.csv'
                    v = subprocess.run(['taskset','-c',str(args.cpu),args.perf,'stat','-x,','-e','instructions:u,cycles:u','-o',counter,'--',*cmd],capture_output=True,text=True,check=True,env=dict(os.environ,GOMAXPROCS='1'))
                    if name=='native':
                        measured = [v.stdout.strip().split(',')[-1],'','']
                    else:
                        line = next(l for l in v.stdout.splitlines() if l.startswith('Benchmark'))
                        measured = [re.search(r'([0-9.]+) '+unit,line)[1] for unit in ['ns/op','B/op','allocs/op']]
                    with counter.open() as f:
                        counts = {r[2]:r[0] for r in csv.reader(f) if len(r)>4 and r[2] in ('instructions:u','cycles:u') and float(r[4])==100}
                    writer.writerow([i+1,name,n,k,*measured,counts['instructions:u'],counts['cycles:u']])
                    out.flush()
