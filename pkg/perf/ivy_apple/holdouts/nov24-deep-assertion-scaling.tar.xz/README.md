# Deep shared assertion scaling

Run with g3 38f049ffb and the configured static Z3 library in the same repository's build directory. Both engines create a 1,025-application Boolean function chain, assert it once, internalize unrelated Boolean atoms, then repeatedly push a decision scope, assert one more application and pop. Go and C++ check that the shared Boolean survived and the extension retired. The Go arena and C++ manager keep the extension owned between scopes.

    python3 replay.py --pkg /path/to/g3/pkg --cpu 2 --output results.csv

For each round, engine and population, subtract the low process instruction count from the high count and divide by the difference in iterations. precision.csv has five alternating rotations at three unrelated population sizes. The new g3 and native series use 5,000 and 25,000 operations to reduce the effect of process setup. The previous g3 uses 200 and 1,000. The host had concurrent workloads, so the instruction slopes are the primary comparison.

coverage.csv reports every visit to the deep prepass in 14 complete GoIvy invocations. The probe printed the expression depth and number of Boolean variables after the threshold check in preInternalizeDeep. Each exit status, stdout and stderr (after removing probe lines) matched the original reference. The calls column counts the probe lines.
