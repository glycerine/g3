"""Replay saved model-table witness choices on captured Apple verifier histories."""
import argparse
import csv
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--pkg', type=Path, required=True)
p.add_argument('--variant', choices=sorted(f.parent.name for f in (root/'overlays').glob('*/manifest.json')), required=True)
p.add_argument('--query', type=int, choices=range(1,7), required=True)
p.add_argument('--scope', choices=['warm','cold'], default='warm')
p.add_argument('--budget', type=int, choices=[6000000,12000000], default=12000000)
args = p.parse_args()
pkg = args.pkg.resolve()
with (root/'histories.csv').open() as f:
    cases = [r for r in csv.DictReader(f) if r['variant']==args.variant and int(r['query'])==args.query and r['scope']==args.scope and int(r['budget'])==args.budget]
if len(cases)!=1:
    p.error('No recorded run at the requested scope and budget')
case = cases[0]
with gzip.open(pkg/'api/test_vectors/apple_enumeration_search.json.gz','rt') as f:
    fixture = json.load(f)
with tempfile.TemporaryDirectory() as td:
    tmp = Path(td)
    repl = {}
    variant_dir = root/'overlays'/args.variant
    for rel, member in json.loads((variant_dir/'manifest.json').read_text()).items():
        src = root/member
        out = tmp/rel
        out.parent.mkdir(parents=True,exist_ok=True)
        if src.suffix == '.patch':
            subprocess.run(['patch','--batch','--fuzz=0','--silent','-o',out,pkg/rel,'-i',src],check=True)
        else:
            out.write_bytes(src.read_bytes())
        repl[str(pkg/rel)] = str(out)
    overlay = tmp/'overlay.json'
    overlay.write_text(json.dumps({'Replace':repl}))
    exe = tmp/'api.test'
    subprocess.run(['go','test','-tags=xtrace_off','-overlay='+str(overlay),'-c','-o',exe,'./api'],cwd=pkg,check=True)
    sequence=[]
    for q in fixture['Batches'][args.query-1]['History']:
        d=fixture['Declarations'][q['Declarations']]
        b=fixture['Premises'][q['Premises']]
        sequence.append({'Problem':{'Text':d+b+q['Goal'],'AssertionsStart':len(d.encode()),
                                    'LastAssertionStart':len((d+b).encode()),'DeclarationCount':d.count('\n')}})
    path = tmp/'sequence.json'
    path.write_text(json.dumps(sequence))
    r=subprocess.run([exe,'-test.run=^TestStudyEnumerationReplay$','-test.v','-test.timeout=20m'],env=dict(os.environ,GOMAXPROCS='1',ENUM_SEQUENCE=str(path),ENUM_SCOPE=args.scope,ENUM_REGIME='default',ENUM_STEPS=str(args.budget)),capture_output=True,text=True,check=True)
    proof=re.search(r'^REPLAY (\d+) (\d+) (true|false) (\d+)$',r.stdout,re.M)
    counts=re.search(r'^TABLES \[([\d ]+)\]$',r.stdout,re.M)
    if not proof or not counts or list(proof.groups()[:3]) != [case[n] for n in ('reached','total','proof')]:
        raise ValueError(r.stdout)
    want = case['counters'].split()
    if counts[1].split()[:len(want)] != want:
        raise ValueError(f'table counters differ: {counts[1]}, expected {want}')
    print(args.variant,args.query,args.scope,args.budget,*proof.groups()[:3],'table counters',counts[1])
