# Quantified candidate-model table witnesses

These solver overlays apply to g3 ba98b3ada. Each original formula in the six captured Apple enumeration histories comes from api/test_vectors/apple_enumeration_search.json.gz in the same checkout. The driver constructs the saved incremental query sequence, compiles the named policy with a temporary Go overlay and verifies the last verdict, number of completed siblings and all recorded table counters.

    python3 replay.py --pkg /path/to/g3/pkg --variant schedule-unique-terminal --query 1 --scope warm --budget 12000000
    python3 replay.py --pkg /path/to/g3/pkg --variant batch-two --query 6 --scope warm --budget 12000000

histories.csv lists the measured combinations. All warm histories run earlier siblings at 6 million steps and only change the terminal budget. A cold run starts a fresh solver with the terminal query alone. The evaluation group checks the model-evaluated quantified body directly or retries after an inconclusive check on the original body. The unique group can install the first explicit counterexample or insist on one distinct explicit counterexample. The schedule group restricts installation to particular portions of the solver history. The batch group collects two, eight or the requested number of explicit witnesses, also trying reversed order. In the batch raw files, the column named unique counts collected candidates. The installed column counts tuples added as actual instances. Each group has a separate previous-implementation control. Process counters include every sibling in the sequence.

The verification CSVs retain every output-matched full-verifier run under the four first-stage policies, with two rotations on the long Apple inputs and three on the other workloads. Results across policies should be compared within a workload.
