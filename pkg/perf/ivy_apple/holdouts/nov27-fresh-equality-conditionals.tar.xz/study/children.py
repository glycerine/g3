"""Price each immediate child of the measured positive equalities by kind and preexisting enode."""
from pathlib import Path
base=(Path(__file__).with_name('parts.py')).read_text();exec(base[:base.rindex('exec(compile(s,')])
a=g.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp');b=g.index('func (s *SMTInternalizerState) argumentLiterals',a)
v=g[a:b];v=edit(v,'if err = s.Internalize(argument, isGate);','''var ct uint64;key:=0;if track {
 h,e:=s.manager.NodeHeader(argument);if e!=nil{panic(e)}
 if h.Kind==ast.ASTApp && h.Family==ast.NullFamilyID {key=1;if h.NumArgs==0{key=2}} else if h.Kind==ast.ASTApp && h.Family==s.manager.BasicFamilyID() && h.DeclKind==ast.ASTOpIte {key=3} else {key=4}
 if s.context.enodes.get(argument)!=nil{key+=10};ct=studyRd(installMeter)}
 if err = s.Internalize(argument, isGate);''')
anchor='return fmt.Errorf("internalize formula child %d: %w", index, err)\n\t\t}'
v=edit(v,anchor,anchor+'\n if track{n:=studyRd(installMeter)-ct;fmt.Fprintln(os.Stderr,"J",key,n)}')
g=g[:a]+v+g[b:]
a=c.index('void context::internalize_formula_core');b=c.index('if (is_new_var &&',a)
v=edit(c[a:b],'internalize(arg, _is_gate);','''int key=0;long long ct=0;if(track){
 if(is_app(arg) && to_app(arg)->get_family_id()==null_family_id){key=to_app(arg)->get_num_args()?1:2;}
 else if(m_manager.is_ite(arg))key=3;else key=4;if(e_internalized(arg))key+=10;ct=operand_rd(install_meter);}
 internalize(arg, _is_gate);if(track){auto cost=operand_rd(install_meter)-ct;fprintf(stderr,"J %d %lld\\n",key,cost);}''')
c=c[:a]+v+c[b:];s=edit(s,"b'E',b'Q'","b'E',b'Q',b'J'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
