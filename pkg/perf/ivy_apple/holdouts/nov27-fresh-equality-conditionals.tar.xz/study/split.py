"""Compare full case splitting, assigned guards, and scope-local diagnostic bounds."""
from pathlib import Path
src=Path(__file__).with_name('rewrite.py').read_text()
a=src.index(' boolsrc=');b=src.index(' for f,archive',a)
src=src[:a]+''' p=pkg/'smtcore/smt_internalizer.go';v=p.read_text().replace('"fmt"','"fmt";"os";"strconv"')
 needle='return s.assertExpression(lemma, proof, instance.Generation(), arguments)'
 v=edit(v,needle,"""if os.Getenv("QI_COUNTER_FD")!="" && proof.IsNull(){
    mode,_:=strconv.Atoi(os.Getenv("ENCODING"));if mode!=0{applied,e:=s.trialSplit(lemma,instance.Generation(),arguments,mode);if e!=nil{return e};if applied{TrialEqualityChanges++;return nil}}
 };"""+needle)
 put(p,v+(here/'split.go.txt').read_text()+'\\nvar TrialEqualityChanges int\\n')
'''+src[b:]
src=src.replace('github.com/glycerine/g3/pkg/ast/rewriter','github.com/glycerine/g3/pkg/smtcore').replace('rewriter.TrialEqualityChanges','smtcore.TrialEqualityChanges')
exec(compile(src,'split','exec'))
