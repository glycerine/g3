"""Try direct simplification of short auxiliary clauses using current assignments."""
from pathlib import Path
import tarfile,tempfile,os
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel=t.extractfile('study/panel.py').read().decode()
p=Path.cwd()/'smtcore/smt_internalizer.go';g=p.read_text()
a=g.index('if ordered {',g.index('func (s *SMTInternalizerState) addClauseKindWithJustificationAndDeleteHandler('))
mode=os.environ.get('SHORT','sort')
if mode in ('sort','both'):
    pos=g.index('slices.Sort(literals)',a)
    g=g[:pos]+g[pos:].replace('slices.Sort(literals)','''switch len(literals) {
        case 2:
            if literals[1]<literals[0]{literals[0],literals[1]=literals[1],literals[0]}
        case 3:
            a,b,c:=literals[0],literals[1],literals[2]
            if b<a{a,b=b,a};if c<b{c,b=b,c};if b<a{a,b=b,a}
            literals[0],literals[1],literals[2]=a,b,c
        default:slices.Sort(literals)
        }''',1)
if mode in ('early','both'):
    # All three input variables must be valid; otherwise keep the ordinary error order.
    pos=g.index('if ordered {',a)
    g=g[:pos]+'''if kind==SMTClauseAux && len(literals)==3 && s.open()==nil {
        i,j,k:=uint(literals[0].Index()),uint(literals[1].Index()),uint(literals[2].Index())
        limit:=uint(len(s.assignment))
        if i<limit && j<limit && k<limit && (s.assignment[i]==lbool.True || s.assignment[j]==lbool.True || s.assignment[k]==lbool.True) {return nil}
    }
    '''+g[pos:]
with tempfile.TemporaryDirectory() as tmp:
    f=Path(tmp)/'trial.go';f.write_text(g)
    panel=panel.replace("mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp[str(pkg/'smtcore/smt_internalizer.go')]=trial")
    exec(compile(panel,'panel','exec'),{'trial':str(f),'__file__':__file__})
