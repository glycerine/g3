"""Survey current assignments along the else spine of fresh Boolean ITE equality children."""
from pathlib import Path
p=Path(__file__).with_name('children.py');body=p.read_text();exec(body[:body.rindex('exec(compile(s,')])
g=edit(g,'ct=studyRd(installMeter)','if key==3{trialChain(s,expression,argument)};ct=studyRd(installMeter)')
g+='''
func trialChain(s *SMTInternalizerState, eq,cur ast.ASTHandle){
 m:=s.manager
 for depth:=0;depth<100;depth++{
 h,e:=m.NodeHeader(cur);if e!=nil{panic(e)};if h.Family!=m.BasicFamilyID()||h.DeclKind!=ast.ASTOpIte{return}
 guard,e:=m.GetArg(cur,0);if e!=nil{panic(e)};other,e:=m.GetArg(cur,2);if e!=nil{panic(e)}
 key:=0
 if lit,e:=s.Literal(guard);e==nil{
    value,e:=s.Assignment(lit);if e!=nil{panic(e)};key=1
    if value!=lbool.Undef{key=2;if value==lbool.True{key=5};lvl:=s.booleanData[lit.Var()].ScopeLevel();if lvl<=s.baseLevel{key++};if lvl==0{key++}}
 }
 fmt.Fprintln(os.Stderr,"G",depth*10+key,0)
 cur=other
 }
 panic("chain too long")
}
'''
s=edit(s,"b'Q',b'J'","b'Q',b'J',b'G'");s=s.replace("('release','native')","('release',)").replace("modes=['release','native']","modes=['release']").replace("range(2):","range(1):")
import os
os.environ['METER_LIB']=os.environ.get('METER_LIB','/tmp/g3-first-qi/check.a')
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
