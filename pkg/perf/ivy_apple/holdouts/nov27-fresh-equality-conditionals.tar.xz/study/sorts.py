"""Split fresh conditional children by sort and Boolean variable already present."""
from pathlib import Path
body=Path(__file__).with_name('children.py').read_text();exec(body[:body.rindex('exec(compile(s,')])
g=edit(g,'if s.context.enodes.get(argument)!=nil{key+=10}', '''if key==3{
 boolean,e:=s.manager.HasBoolSort(argument);if e!=nil{panic(e)};if boolean{key+=100}
 if _,found:=s.boolVar.lookup(argument);found{key+=200}}
 if s.context.enodes.get(argument)!=nil{key+=10}''')
c=edit(c,'if(e_internalized(arg))key+=10;','if(key==3){if(m_manager.is_bool(arg))key+=100;if(b_internalized(arg))key+=200;}if(e_internalized(arg))key+=10;')
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
