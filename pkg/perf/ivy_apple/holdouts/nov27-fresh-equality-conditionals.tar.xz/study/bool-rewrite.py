"""Try rewriting surviving raw Boolean equalities whose operands include a conditional."""
from pathlib import Path
src=Path(__file__).with_name('rewrite.py').read_text()
a=src.index(' boolsrc=');b=src.index(' qi=',a)
src=src[:a]+''' th=pkg/'ast/rewriter/th_rewriter.go';v=th.read_text()
 v=edit(v,'return c.boolean.mkAppCoreKind(kind, args, out)',"""status,err:=c.boolean.mkAppCoreKind(kind,args,out)
 if err!=nil||status!=RewriteFailed||TrialEqualityPolicy==0||kind!=ast.ASTOpEq{return status,err}
 lhs,err:=args.At(0);if err!=nil{return RewriteFailed,err};rhs,err:=args.At(1);if err!=nil{return RewriteFailed,err}
 boolean,err:=m.HasBoolSort(lhs);if err!=nil||!boolean{return RewriteFailed,err}
 yes,cond,t,f,err:=c.boolean.ite(lhs);if err!=nil{return RewriteFailed,err}
 if !yes{lhs,rhs=rhs,lhs;yes,cond,t,f,err=c.boolean.ite(lhs);if err!=nil||!yes{return RewriteFailed,err}}
 var result ast.ASTHandle
 switch TrialEqualityPolicy{
 case 1:result,err=m.MkIff(lhs,rhs)
 case 2,3,4:
    rt,rf:=rhs,rhs;right,other,tt,ff,e:=c.boolean.ite(rhs);if e!=nil{return RewriteFailed,e}
    if right {if other!=cond{return RewriteFailed,nil};rt,rf=tt,ff}
    if TrialEqualityPolicy==3 && rt!=t && rf!=f{return RewriteFailed,nil}
    if TrialEqualityPolicy==4 && !right{return RewriteFailed,nil}
    r1,e:=m.MkIff(t,rt);if e!=nil{return RewriteFailed,e};r2,e:=m.MkIff(f,rf);if e!=nil{return RewriteFailed,e};result,err=m.MkIte(cond,r1,r2)
 };if err!=nil{return RewriteFailed,err};TrialEqualityChanges++;return Rewrite3,m.SetRef(out,result)""")
 put(th,v+'\\nvar TrialEqualityPolicy, TrialEqualityChanges int\\n')
'''+src[b:]
exec(compile(src,'bool-rewrite','exec'))
