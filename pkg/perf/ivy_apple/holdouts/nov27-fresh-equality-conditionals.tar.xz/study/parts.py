"""Price direct phases of each positive equality that is unbound on entry."""
import tarfile,tempfile
from pathlib import Path
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    op=t.extractfile('study/operand-kinds.py').read().decode()
    comp=t.extractfile('study/components.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp);(d/'components.py').write_text(comp)
    base={'__file__':str(d/'operand-kinds.py')}
    exec(op[:op.rindex("exec(compile(s,")],base)
g,c,s,edit=(base[k] for k in ('g','c','s','edit'))
g+='\nvar observedEquality ast.ASTHandle\n'
g=edit(g,'if code>=0{start=studyRd(fd)}','if code==2{observedEquality=argument};if code>=0{start=studyRd(fd)}')
g=edit(g,'if err = s.internalizeFormulaCoreOp(expression, gateContext, header, true);','track:=expression==observedEquality; if err = s.internalizeFormulaCoreOp(expression, gateContext, header, true);')
a=g.index('if basic && op == ast.ASTOpEq {',g.index('track:=expression'));b=g.index('\n\t}\n\treturn nil',a)
g=g[:a]+g[a:b].replace('variable, _ :=','var t uint64;if track{t=studyRd(installMeter)};variable, _ :=')+'\n if track{n:=studyRd(installMeter)-t;fmt.Fprintln(os.Stderr,"Q",0,n)}'+g[b:]
a=g.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp');b=g.index('func (s *SMTInternalizerState) argumentLiterals',a)
core=g[a:b]
core=edit(core,'for index :=','''track:=expression==observedEquality;var t uint64; missing:=0
    if track{observedEquality=ast.ASTHandle{}; for i:=uint32(0);i<count;i++{h,e:=s.manager.GetArg(expression,i);if e!=nil{panic(e)};if s.context.enodes.get(h)==nil{missing++}};t=studyRd(installMeter)}
    for index :=''')
for (before,opname) in [('variable, isNew :=','H'),('if (!gateContext','V'),('if isNew && basic','E')]:
    core=edit(core,before,'if track{n:=studyRd(installMeter)-t;fmt.Fprintln(os.Stderr,"'+opname+'",missing,n);t=studyRd(installMeter)};'+before)
g=g[:a]+core+g[b:]
c=edit(c,'extern thread_local int install_meter;','extern thread_local int install_meter; static thread_local void const *observed_eq=nullptr;')
c=edit(c,'if(neg)code+=100;start=operand_rd(fd);','if(neg)code+=100;if(code==2)observed_eq=arg;start=operand_rd(fd);')
a=c.index('void context::internalize_eq(');b=c.index('void context::internalize_distinct',a)
section=edit(c[a:b],'internalize_formula_core(n, gate_ctx);','bool track=n==observed_eq;internalize_formula_core(n, gate_ctx);auto t=track?operand_rd(install_meter):0;')
section=edit(section,'th->internalize_eq_eh(n, v);','th->internalize_eq_eh(n, v);if(track){auto cost=operand_rd(install_meter)-t;fprintf(stderr,"Q 0 %lld\\n",cost);}')
c=c[:a]+section+c[b:]
a=c.index('void context::internalize_formula_core');b=c.index('if (is_new_var && n->get_family_id()',a)
core=c[a:b]
core=edit(core,'for (unsigned i =','bool track=n==observed_eq;long long t=0;int missing=0;if(track){observed_eq=nullptr;for(expr* x:*n)if(!e_internalized(x))missing++;t=operand_rd(install_meter);}for (unsigned i =')
for before,name in [('bool is_new_var =','H'),('if (!e_internalized(n)','V')]:
    core=edit(core,before,'if(track){auto cost=operand_rd(install_meter)-t;fprintf(stderr,"'+name+' %d %lld\\n",missing,cost);t=operand_rd(install_meter);}'+before)
core+='if(track){auto cost=operand_rd(install_meter)-t;fprintf(stderr,"E %d %lld\\n",missing,cost);} '
c=c[:a]+core+c[b:]
s=edit(s,"b'M',b'F'","b'M',b'F',b'H',b'V',b'E',b'Q'")
qcpp,qgo=base['qcpp'],base['qgo']
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
