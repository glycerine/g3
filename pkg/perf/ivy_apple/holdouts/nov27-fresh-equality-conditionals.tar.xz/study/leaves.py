"""Partition Boolean conditional children by position, child operator, and reuse."""
from pathlib import Path
p=Path(__file__).with_name('bool-parts.py');src=p.read_text();exec(src[:src.rindex('exec(compile(s,')])
g=edit(g,'var ct uint64;key:=0;if track {','''var childAt uint64;childKey:=0;if ite {
 h,e:=s.manager.NodeHeader(argument);if e!=nil{panic(e)}
 op:=50;if h.Family==s.manager.BasicFamilyID(){op=int(h.DeclKind)}else if h.Family==ast.NullFamilyID{op=51}
 childKey=int(index)*1000000+op*1000+int(h.NumArgs)*10
 if _,bound:=s.boolVar.lookup(argument);bound{childKey++};childAt=studyRd(installMeter)}
 var ct uint64;key:=0;if track {''')
g=edit(g,'if track{n:=studyRd(installMeter)-ct;', 'if ite{n:=studyRd(installMeter)-childAt;fmt.Fprintln(os.Stderr,"Y",childKey,n)};if track{n:=studyRd(installMeter)-ct;')
c=edit(c,'int key=0;long long ct=0;if(track){','''int ck=0;long long child_at=0;if(ite){auto* ap=to_app(arg);
 int op=ap->get_family_id()==m_manager.get_basic_family_id()?int(ap->get_decl_kind()):(ap->get_family_id()==null_family_id?51:50);
 ck=i*1000000+op*1000+ap->get_num_args()*10+int(b_internalized(arg));child_at=operand_rd(install_meter);}
 int key=0;long long ct=0;if(track){''')
c=edit(c,'internalize(arg, _is_gate);if(track){','internalize(arg, _is_gate);if(ite){auto cost=operand_rd(install_meter)-child_at;fprintf(stderr,"Y %d %lld\\n",ck,cost);}if(track){')
s=edit(s,"b'J',b'B'","b'J',b'B',b'Y'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
