"""Try alternative Boolean encodings of ground term-ITE comparisons during QI rewrite."""
import subprocess as sp,tempfile,tarfile,os,json,csv
from pathlib import Path
pkg=Path.cwd();here=Path(__file__).resolve().parent;res=Path(os.environ['RESULTS']);res.mkdir(parents=True,exist_ok=True)
def old(archive,member):
 with tarfile.open(pkg/'perf/ivy_apple/holdouts'/archive) as t:return t.extractfile(member).read()
def edit(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']);gold=ref/'compat/1/1/native'
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp);mp={}
 def put(p,content):
    f=d/p.name;f.write_text(content);mp[str(p)]=str(f)
 boolsrc=pkg/'ast/rewriter/bool_rewriter_eq.go';b=boolsrc.read_text()
 idx=b.index('func (rw *boolRewriter) mkNotCore');b=edit(b[:idx],'if !boolean {\n\t\treturn brFailed, nil','if !boolean {\n if TrialEqualityPolicy!=0{return rw.trialConditionalEquality(lhs,rhs,out)};return brFailed,nil')+b[idx:]
 put(boolsrc,b+(here/'rewrite.go.txt').read_text())
 qi=pkg/'smtcore/smt_qi_instance.go';q=qi.read_text().replace('"strconv"','"strconv";"os"')
 q=edit(q,'if err = rw.Rewrite(instance, simplified); err != nil {','''policy:=0;if os.Getenv("QI_COUNTER_FD")!="" {policy,_=strconv.Atoi(os.Getenv("ENCODING"))};rewriter.TrialEqualityPolicy=policy
        err=rw.Rewrite(instance,simplified);rewriter.TrialEqualityPolicy=0;if err!=nil{''')
 put(qi,q)
 for f,archive,member in [('z3bridge_solver_model.go','nov27-terminal-conflict-replay.tar.xz','study/stage-bridge.go.txt'),('z3bridge_guarded_equalities.go','nov27-terminal-conflict-replay.tar.xz','study/guards.go.txt'),('phase_observer_trial.go','nov27-first-push-queue-comparison.tar.xz','check-g3-phase_observer_trial.go')]:
    src=old(archive,member).decode()
    if f.startswith('z3bridge_solver'):src=edit(src,'stopCheck:=startStage(batch,index+1);','capturePush=batch==60 && index==0;stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");capturePush=false')
    if f.startswith('phase_'):
        src=src.replace('"unsafe"','"unsafe";"github.com/glycerine/g3/pkg/ast/rewriter"')
        src=edit(src,'runtime.LockOSThread()','if !capturePush{return func(string){}};runtime.LockOSThread()')
        src=edit(src,'runtime.UnlockOSThread()','runtime.UnlockOSThread();fmt.Fprintln(os.Stderr,"CHANGES",rewriter.TrialEqualityChanges)')
    put(front/f,src)
 j=d/'overlay.json';j.write_text(json.dumps({'Replace':mp}))
 sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-overlay',j,'-o',d/'checker','./cmd/goivy_check'],env=dict(os.environ,GOCACHE=os.environ['TRIAL_CACHE']),cwd=front,check=True)
 with (res/'check.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['round','policy','replacements','instructions','elapsed_ns'])
    for i in range(3):
        modes=[0,1,2,3,4];modes=modes[i:]+modes[:i]
        for mode in modes:
            run=sp.run(['taskset','-c',os.environ['CPU'],d/'checker',ex/(ref/'compat.txt').read_text().splitlines()[0]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',ENCODING=str(mode),GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
            normal=[];stages=[];changes=[]
            for l in run.stderr.splitlines(keepends=True):
                a=l.split()
                if l.startswith(b'OPEN '):assert a[1:]==[b'60',b'1']
                elif l.startswith(b'STAGE-COUNT '):assert a[1:4]==[b'60',b'1',b'check'] and a[6]==a[7];stages.append([int(a[4]),int(a[8])])
                elif l.startswith(b'CHANGES '):changes.append(int(a[1]))
                else:normal.append(l)
            assert (run.returncode,run.stdout,b''.join(normal))==(1,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(mode,run.stderr[-1000:])
            assert len(stages)==len(changes)==1
            w.writerow([i,mode,*changes,*stages[0]]);f.flush()
