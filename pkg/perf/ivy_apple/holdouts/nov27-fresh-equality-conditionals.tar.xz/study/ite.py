"""Time construction of a fresh term conditional directly under a measured equality."""
from pathlib import Path
body=Path(__file__).with_name('children.py').read_text();exec(body[:body.rindex('exec(compile(s,')])
g+='\nvar measuredIte ast.ASTHandle\n'
g=edit(g,'ct=studyRd(installMeter)','if key==3{measuredIte=argument};ct=studyRd(installMeter)')
a=g.index('func (s *SMTInternalizerState) internalizeTermITE');b=g.index('func (s *SMTInternalizerState) preInternalizeDeep',a)
v=g[a:b]
v=edit(v,'condition, err :=','''track:=expression==measuredIte;var t uint64
 if track{measuredIte=ast.ASTHandle{};t=studyRd(installMeter)}
 log:=func(code int){if track{n:=studyRd(installMeter)-t;fmt.Fprintln(os.Stderr,"I",code,n);t=studyRd(installMeter)}}
 condition, err :=''')
for needle,flag in [('thenEquality, err :=',0),('if _, err = s.MkEnode',1),('for _, item :=',2),('if err = s.addGateClause([]SMTLiteral{conditionLiteral.Negated()',8),('if s.relevancy != nil',9)]:
 v=edit(v,needle,'log('+str(flag)+');'+needle)
v=edit(v,'for _, item :=','for i, item :=')
v=edit(v,'\n\t}\n\tconditionLiteral, err :=','\n log(3+i)\n\t}\n\tconditionLiteral, err :=')
v=edit(v,'return s.relevancy.AddTermITEWatches(expression, thenEquality, elseEquality)','err=s.relevancy.AddTermITEWatches(expression,thenEquality,elseEquality);log(10);return err')
g=g[:a]+v+g[b:]
c=edit(c,'static thread_local void const *observed_eq=nullptr;','static thread_local void const *observed_eq=nullptr,*measured_ite=nullptr;')
c=edit(c,'ct=operand_rd(install_meter);','if(key==3)measured_ite=arg;ct=operand_rd(install_meter);')
a=c.index('void context::internalize_ite_term');b=c.index('bool context::internalize_theory_term',a)
v=c[a:b]
v=edit(v,'expr * c  =','''bool track=n==measured_ite;long long stamp=0;if(track){measured_ite=nullptr;stamp=operand_rd(install_meter);}
 auto report=[&](int code){if(track){auto cost=operand_rd(install_meter)-stamp;fprintf(stderr,"I %d %lld\\n",code,cost);stamp=operand_rd(install_meter);}};
 expr * c  =''')
for flag,needle in enumerate(['app_ref eq1','mk_enode(n,','internalize(c, true);','internalize(t, false);','internalize(e, false);','internalize(eq1, true);','internalize(eq2, true);','literal c_lit','mk_gate_clause(~c_lit','if (relevancy())','SASSERT(e_internalized(n));']):
 v=edit(v,needle,'report('+str(flag)+');'+needle)
c=c[:a]+v+c[b:];s=edit(s,"b'Q',b'J'","b'Q',b'J',b'I'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
