"""Measure recursive children, variable, enode, and constraints on the fresh Boolean ITEs."""
from pathlib import Path
body=Path(__file__).with_name('children.py').read_text();exec(body[:body.rindex('exec(compile(s,')])
g+='\nvar observedBoolITE ast.ASTHandle\n';g=edit(g,'ct=studyRd(installMeter)','if key==3{observedBoolITE=argument};ct=studyRd(installMeter)')
g=edit(g,'track:=expression==observedEquality;var t','ite:=expression==observedBoolITE;if ite{observedBoolITE=ast.ASTHandle{}};track:=expression==observedEquality;var t')
g=edit(g,'for index := uint32(0); index < count; index++ {\n\t\targument, err := s.manager.GetArg(expression, index)\n\t\tif err != nil {\n\t\t\treturn err\n\t\t}\n\t\tvar ct','if ite{t=studyRd(installMeter)};for index := uint32(0); index < count; index++ {\n argument,err:=s.manager.GetArg(expression,index);if err!=nil{return err};var ct')
for tag,flag in [('H',0),('V',1),('E',2)]:
 anchor='fmt.Fprintln(os.Stderr,"'+tag+'",missing,n);t=studyRd(installMeter)};'
 g=edit(g,anchor,anchor+'if ite{n:=studyRd(installMeter)-t;fmt.Fprintln(os.Stderr,"B",'+str(flag)+',n);t=studyRd(installMeter)};')
a=g.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp');b=g.index('func (s *SMTInternalizerState) argumentLiterals',a)
v=g[a:b];v=edit(v,'\n\treturn nil\n}', '\n if ite{n:=studyRd(installMeter)-t;fmt.Fprintln(os.Stderr,"B",3,n)};return nil\n}')
g=g[:a]+v+g[b:]
c=edit(c,'static thread_local void const *observed_eq=nullptr;','static thread_local void const *observed_eq=nullptr,*observed_bool_ite=nullptr;')
c=edit(c,'ct=operand_rd(install_meter);','if(key==3)observed_bool_ite=arg;ct=operand_rd(install_meter);')
c=edit(c,'bool track=n==observed_eq;long long t=0;int missing','bool ite=n==observed_bool_ite;if(ite)observed_bool_ite=nullptr;bool track=n==observed_eq;long long t=ite?operand_rd(install_meter):0;int missing')
for tag,flag in [('H',0),('V',1),('E',2)]:
 start=c.index('if(track){auto cost=operand_rd(install_meter)-t;fprintf(stderr,"'+tag+' ')
 stop=c.index('}',start)+1
 c=c[:stop]+'if(ite){auto cost=operand_rd(install_meter)-t;fprintf(stderr,"B '+str(flag)+' %lld\\n",cost);t=operand_rd(install_meter);}'+c[stop:]
a=c.index('void context::internalize_formula_core');b=c.index('\n    }',a);c=c[:b]+'\n if(ite){auto cost=operand_rd(install_meter)-t;fprintf(stderr,"B 3 %lld\\n",cost);}'+c[b:]
s=edit(s,"b'Q',b'J'","b'Q',b'J',b'B'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
