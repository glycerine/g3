from pathlib import Path
import csv,re,subprocess,os,collections,sys
w=Path(__file__).resolve().parent;e=sys.argv[1];cpu=sys.argv[2]
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf';env=dict(os.environ,GOGC='100',GOMAXPROCS='1',DEBUGINFOD_URLS='')
exe=w/'cli' if e=='g3' else Path(sys.argv[3]).resolve()
with (w/('cli-stacks-'+e+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round period count stack'.split())
 for i in range(5):
  for name in ['6-16-1','8-12-8','3-4-55']:
   file=w/'fixtures'/(name+'.smt2');src=file.read_text();j=src.rindex('\n(assert ');src=src[:j]+'\n(push 1)'+src[j:];period=2500003+301*i
   data=w/('cli-'+e+'.data');r=subprocess.run(['taskset','-c',cpu,perf,'record','-q','-B','-N','-e','instructions:u','-c',str(period),'--call-graph','fp,48' if e=='g3' else 'dwarf,8192','-o',data,exe,'-in','-smt2'],cwd=w,env=env,input=src.encode(),capture_output=True,check=True)
   assert r.stdout.startswith(b'unsat\n') and b'(error' not in r.stdout and not r.stderr
   stats=subprocess.check_output([perf,'report','--stdio','--stats','-i',data],text=True);assert not re.search(r'(LOST|THROTTLE) events:',stats)
   raw=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',data],env=env,text=True);tally=collections.Counter()
   for sample in raw.strip().split('\n\n'):
    lines=sample.splitlines()
    if len(lines)>1:tally['\n'.join(re.sub(r'^\s*[0-9a-f]+\s+','',x).strip() for x in lines[1:])]+=1
   assert sum(tally.values())>25
   for stack,n in tally.items():out.writerow([name,i,period,n,stack])
   f.flush()
