from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
names=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines()
p=[subprocess.Popen([sys.executable,w/'compare.py',f'broad{i}_base_allphase',str(c),'3',*names[i::4]]) for i,c in enumerate([2,4,16,18])]
assert all(v==0 for v in [q.wait() for q in p])
