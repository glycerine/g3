from pathlib import Path
import csv,subprocess,os,sys
w=Path(__file__).resolve().parent
p=Path('/tmp/g3-reduction-rows/compat'); ex=Path('/home/jaten/ivy/ivy-lang-examples')
names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
codes={r['spec']:int(r['exit']) for f in p.glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
eng=sys.argv[1]
with (w/('stages-'+eng+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round batch goal stage instructions'.split())
 for i in range(3):
  for nr in [3,6,8,12]:
   name=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines()[nr-1]
   ref=p/str(names.index(name)+1)/'1'/'native'
   r=subprocess.run(['taskset','-c',sys.argv[2],w/('translated-'+eng),ex/name],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=120)
   err=bytearray()
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'STAGE-COUNT '):
     _,b,g,stage,num,empty,en,active,ns=line.decode().split();assert en==active
     out.writerow((name,i,b,g,stage,num))
    else:err.extend(line)
   assert (r.returncode,r.stdout,err)==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,eng,r.returncode,err[:300]);f.flush()
