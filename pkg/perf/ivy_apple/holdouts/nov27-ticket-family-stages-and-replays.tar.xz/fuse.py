from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;ov={}
for name in ['smt_qi_instance','smt_quantifier_manager']:
 src=p/'smtcore'/(name+'.go');s=src.read_text()
 if name=='smt_qi_instance':
  s=s.replace('alreadySatisfied bool\n','alreadySatisfied bool\n fused bool\n',1)
  tag='func (b *SMTQIInstanceBuilder) prepare(entry SMTQIQueueEntry, prepared *SMTQIPreparedInstance) error {'
  s=s.replace(tag,tag+'return b.prepareCombined(entry,prepared,nil)\n}\n'+tag.replace('prepare(','prepareCombined(').replace('Instance) error','Instance, rw *rewriter.TheoryRewriter) error'))
  tag='if _, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance); err != nil {'
  s=s.replace(tag,'''if rw != nil {
    proofs,e:=b.manager.ProofsEnabled();if e!=nil{return e}
    if !proofs {
     owners:=b.substitution.scratch[:0]
     for _,v:=range bindings {owners=append(owners,v.owner)}
     b.substitution.scratch=owners
     err=rw.RewriteWithBindings(body,owners,prepared.instance)
     if err=errors.Join(err,rw.Reset());err!=nil{return errors.Join(err,prepared.Close())}
     prepared.fused=true
     return nil
    }
   }
   '''+tag)
  s=s.replace('if err = rw.Rewrite(instance, simplified); err != nil {','if prepared.fused { err=b.manager.SetRef(simplified,instance) } else { err=rw.Rewrite(instance,simplified) }; if err != nil {')
 else:s=s.replace('q.builder.prepare(entry, &prepared)','q.builder.prepareCombined(entry, &prepared, q.rewriter)')
 dest=w/('fused-'+src.name+'.txt');dest.write_text(s);ov[str(src)]=str(dest)
o=w/'fused.json';o.write_text(json.dumps({'Replace':ov}))
f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',o,'-o',w/'fused','./cmd/goivy_check'],cwd=f,check=True)
