from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
d=collections.defaultdict(list);counts=collections.defaultdict(set)
for file in w.glob('replay-*.csv'):
 for r in csv.DictReader(file.open()):
  k=r['fixture'],r['shape'],r['engine'],r['setting']
  if r['verdict']!='unsat':print('failure',k);continue
  d[k].append(int(r['instructions']));counts[k].add(tuple(r[s] for s in ['decisions','conflicts','quant-instantiations','rlimit-count']))
for shape in ['fresh','incremental']:
 rows=[]
 for q in sorted({k[0] for k in d}):
  def val(e,m):
   v=d.get((q,shape,e,m));return statistics.median(v)/1e6 if v else 0
  g=val('g3','default');z=val('native','default');a=[val('g3',m) for m in ['relevancy=1','relevancy=0','phase_selection=0','phase_selection=2']]
  same=counts[q,shape,'g3','default']==counts[q,shape,'native','default']
  print(q,shape,same,*[round(t,1) for t in [g,z,*a]])
  rows.append([g,z,*a])
 print('sum',shape,*[round(sum(x),1) for x in zip(*rows)])
