from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent
f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();src=f/'z3bridge_solver_model.go'
s=src.read_text();pos=s.index('func (s *Solver) GetSmallModelWithCond(');a,s=s[:pos],s[pos:]
needle='z3solver := s.newZ3Solver()';assert s.index(needle)<800
s=s.replace(needle,needle+'\n policy := os.Getenv("ACTION_SCOPE")\n if policy=="allphase" || policy=="singlephase" && len(finalCond)==1 { z3solver.SetParam("phase_selection","2") }',1)
dest=w/'policy.go.txt';dest.write_text(a+s);ov=w/'policy.json';ov.write_text(json.dumps({'Replace':{str(src):str(dest)}}))
exe=w/'allphase';subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
for n in ['singlephase','both']:
 (w/n).symlink_to(exe)
