import csv,statistics as st,collections
from pathlib import Path
w=Path(__file__).resolve().parent
tot=collections.Counter();count=collections.Counter();goal=collections.Counter();cases=set()
for e in ['g3','native']:
 for r in csv.DictReader((w/('stages-'+e+'.csv')).open()):
  c=r['case'];cases.add(c);i=int(r['round']);s=r['stage'];k=(c,s,e,i);n=int(r['instructions'])
  tot[k]+=n;count[k]+=1
  if s in ('early','goal-simplify','check','assert','first','push','pop'):goal[c,int(r['batch']),int(r['goal']),e,i]+=n
with (w/'stage-summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case phase g3_calls native_calls g3_insns native_insns difference'.split())
 for c in sorted(cases):
  for s in sorted({k[1] for k in tot if k[0]==c}):
   g,z=[int(st.median(tot[c,s,e,i] for i in range(3))) for e in ['g3','native']]
   out.writerow((c,s,*[count[c,s,e,0] for e in ['g3','native']],g,z,g-z))
with (w/'goal-summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case batch goal g3_insns native_insns difference'.split())
 for c,b,g in sorted({k[:3] for k in goal}):
  a,z=[int(st.median(goal[c,b,g,e,i] for i in range(3))) for e in ['g3','native']]
  out.writerow((c,b,g,a,z,a-z))
