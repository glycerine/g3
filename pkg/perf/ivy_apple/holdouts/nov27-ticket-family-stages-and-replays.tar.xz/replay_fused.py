from pathlib import Path
import csv,re,subprocess,os,sys
w=Path(__file__).resolve().parent;perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
exe={'g3':w/'fused-cli','native':Path(sys.argv[1]).resolve()}
modes=sys.argv[2:];cpu=os.environ.get('REPLAY_CPU','14')
with (w/('replay-'+modes[0]+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('fixture round shape engine setting verdict instructions task_clock_ns decisions conflicts quant-instantiations rlimit-count'.split())
 for file in sorted((w/'fixtures').glob('*.smt2')):
  text=file.read_text();pos=text.rindex('\n(assert ')
  for i in range(3):
   for shape,base in [('fresh',text),('incremental',text[:pos]+'\n(push 1)'+text[pos:])]:
    for mode in modes:
     for e in (['g3'])[::1 if i%2==0 else -1]:
      option='' if mode=='fused' else '(set-option :smt.'+mode.replace('=',' ')+')\n'
      stat=w/('replay-'+modes[0]+'.stat')
      try:
       r=subprocess.run(['taskset','-c',cpu,perf,'stat','-x,','-o',stat,'-e','instructions:u,task-clock','--',exe[e],'-in','-smt2'],input=(option+base).encode(),env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,timeout=8)
       stdout=r.stdout.decode();kv=dict(re.findall(r':([\w-]+)\s+(\d+)\b',stdout))
       verdict=stdout.splitlines()[0];assert r.returncode==0 and verdict=='unsat' and '(error' not in stdout and not r.stderr,(file,mode,r.returncode,stdout[:450],r.stderr[:200])
       hw={a[2]:a[0] for a in csv.reader(stat.open()) if len(a)>4 and float(a[4])==100}
       out.writerow([file.stem,i,shape,e,mode,verdict,hw['instructions:u'],hw['task-clock'],*[kv.get(k,0) for k in ['decisions','conflicts','quant-instantiations','rlimit-count']]])
      except subprocess.TimeoutExpired:out.writerow([file.stem,i,shape,e,mode,'timeout']+['']*6)
      f.flush()
