"""Factor the unary search rule against the two binary-witness implementations."""
from pathlib import Path
import os,tarfile
p=Path.cwd();w=Path(os.environ['RESULTS'])
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-terminal-conflict-replay.tar.xz') as t:
    def read(name):return t.extractfile('study/'+name).read().decode()
    code=read('unit.py')
    for file in ['stage-bridge.go.txt','timer.go.txt','guards.go.txt']:
        (w/file).write_text(read(file))
    (w/'unit.go.txt').write_text(read('gate.go.txt'))
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t:
    for variant in ('base','candidate'):
        (w/(variant+'.go.txt')).write_bytes(t.extractfile('study/release-sources/'+variant+'.go.txt').read())
seed=(w/'unit.go.txt').read_text().replace('if trialMode=="active"||trialMode=="active-new"', 'if true')
seed+=Path(__file__).with_name('link.txt').read_text()
seed=seed.replace('var nodes []*SMTEnode','var nodes []*SMTEnode;var links map[ast.ASTHandle][]demandLink')
key='if nodes==nil{nodes=s.context.enodes.all()}'
seed=seed.replace(key,'''if links==nil{links=demandLinks(q)};match:=false;for _,l:=range links[head.Decl]{if l.neg==(trialMode=="negative"){match=true;break}};if !match{continue};'''+key)
key='for pos:=range nodes{'
seed=seed.replace(key,'var best,second *SMTEnode;'+key)
a=seed.index('triedUnits++;entry:=');b=seed.index('if e=q.instantiate',a)
seed=seed[:a]+'''if s.isRelevant(node.owner)||len(node.root.sourceParents)<2{continue}
   better:=func(candidate,other *SMTEnode)bool{
    if other==nil{return true};if trialMode=="first"{return false}
    a,b:=len(candidate.root.sourceParents),len(other.root.sourceParents)
    if trialMode=="high"{return a>b};return a<b
   }
   if better(node,best){second,best=best,node}else if better(node,second){second=node}
  }
  for i,node:=range [2]*SMTEnode{best,second}{
   if node==nil || i==1&&trialMode!="two"{break}
   '''+seed[a:]
(w/'unit.go.txt').write_text(seed)
for variant in ('candidate',):
    s=code.replace(" j=d/'ov.json'", " put(p/'smtcore/smt_model_checker.go',(w/(variant+'.go.txt')).read_text())\n j=d/'ov.json'").replace("w/'unit-verified.csv'","w/(variant+'.csv')")
    s=s.replace("for key,cases in [('12-8',[8]),('all',[8,4,1,2,3,5,6,7,9,10,11,12])]:","for repno in range(3):\n   key='all';cases=[1,8,6,10]")
    s=s.replace("for mode in ['base','first','last','all']:","for mode in (['base','two'][repno:]+['base','two'][:repno]):")
    s=s.replace("'case target mode status attempts target_check check_sum stage_sum'","'case target mode status attempts target_check check_sum stage_sum round nested_check'")
    s=s.replace("sum(v for _,_,v in stages)]","sum(v for _,_,v in stages),repno,sum(v for t,ph,v in stages if t==b'16-1' and ph==b'check')]")
    s=s.replace('stages=[];rest=bytearray();tries=0','stages=[];rest=bytearray();tries=0;offered={}')
    s=s.replace("if key=='all' or a[1]+b'-'+a[2]==key.encode():tries+=int(a[3])","offered[a[1]+b'-'+a[2]]=int(a[3]);tries+=int(a[3])")
    needle=';f.flush()'
    assert s.count(needle)==1
    s=s.replace(needle,needle+"\n     assert match,(n,mode,repno)\n     with (w/'rows.csv').open('a') as raw:csv.writer(raw).writerows([n,repno,mode,t.decode(),ph.decode(),v,offered.get(t,0)] for t,ph,v in stages)")
    if os.environ.get("PREBUILT"):
        a=s.index(";sp.run(['go','build'");b=s.index('check=True)',a)+len('check=True)')
        s=s[:a]+";import shutil;shutil.copyfile(os.environ['PREBUILT'],exe);exe.chmod(0o700)"+s[b:]
    exec(compile(s,'unit-factor','exec'),{'__file__':str(w/'run.py'),'variant':variant})
