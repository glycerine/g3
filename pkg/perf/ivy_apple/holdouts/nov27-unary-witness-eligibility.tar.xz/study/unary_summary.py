"""Compute medians after summing all selected pushes in each complete process."""
from pathlib import Path
import collections,csv,statistics
w=Path(__file__).resolve().parent
def read(name):
    with (w/name).open() as f:return list(csv.DictReader(f))
with (w/'unary.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['experiment','case','mode','stage_median','stage_change_percent','attempts','check_12_8','check_16_1'])
    for exp in ('interaction/base','interaction/candidate','dormant/candidate','polarity/candidate','rank/candidate','deferred/candidate','birth/candidate'):
        rows=read(exp+'.csv')
        for case in sorted({int(x['case']) for x in rows}):
            def med(mode,key):
                r=[int(x[key]) for x in rows if int(x['case'])==case and x['mode']==mode and x['target']=='all']
                assert len(r)==(2 if not exp.startswith('interaction') else 3)
                return statistics.median(r)
            for mode in sorted({x['mode'] for x in rows if x['target']=='all'}):
                total=med(mode,'stage_sum')
                out.writerow([exp,case,mode,total,100*(total/med('base','stage_sum')-1),med(mode,'attempts'),med(mode,'target_check'),med(mode,'nested_check')])
