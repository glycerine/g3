"""Factor the unary search rule against the two binary-witness implementations."""
from pathlib import Path
import os,tarfile
p=Path.cwd();w=Path(os.environ['RESULTS'])
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-terminal-conflict-replay.tar.xz') as t:
    def read(name):return t.extractfile('study/'+name).read().decode()
    code=read('unit.py')
    for file in ['stage-bridge.go.txt','timer.go.txt','guards.go.txt']:
        (w/file).write_text(read(file))
    (w/'unit.go.txt').write_text(read('gate.go.txt'))
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t:
    for variant in ('base','candidate'):
        (w/(variant+'.go.txt')).write_bytes(t.extractfile('study/release-sources/'+variant+'.go.txt').read())
seed=(w/'unit.go.txt').read_text().replace('if trialMode=="active"||trialMode=="active-new"', 'if true')
seed+=Path(__file__).with_name('link.txt').read_text()
seed=seed.replace('var nodes []*SMTEnode','var nodes []*SMTEnode;var links map[ast.ASTHandle][]demandLink')
key='if nodes==nil{nodes=s.context.enodes.all()}'
seed=seed.replace(key,'''if links==nil{links=demandLinks(q)};match:=false;for _,l:=range links[head.Decl]{if l.neg==(trialMode=="negative"){match=true;break}};if !match{continue};'''+key)
key='triedUnits++;entry:='
seed=seed.replace(key,'''if trialMode=="positiveShared" && len(node.root.sourceParents)<2 {continue}
    if trialMode=="positiveDormantShared" && (s.isRelevant(node.owner)||len(node.root.sourceParents)<2) {continue};'''+key)
(w/'unit.go.txt').write_text(seed)
for variant in ('candidate',):
    s=code.replace(" j=d/'ov.json'", " put(p/'smtcore/smt_model_checker.go',(w/(variant+'.go.txt')).read_text())\n j=d/'ov.json'").replace("w/'unit-verified.csv'","w/(variant+'.csv')")
    s=s.replace("for key,cases in [('12-8',[8]),('all',[8,4,1,2,3,5,6,7,9,10,11,12])]:","for repno in range(2):\n   key='all';cases=[8,6,2,4,3,12,9,5,7,10,11,1,227]")
    s=s.replace("for mode in ['base','first','last','all']:","for mode in (['base','positive','negative','positiveShared','positiveDormantShared'][repno:]+['base','positive','negative','positiveShared','positiveDormantShared'][:repno]):")
    s=s.replace("'case target mode status attempts target_check check_sum stage_sum'","'case target mode status attempts target_check check_sum stage_sum round nested_check'")
    s=s.replace("sum(v for _,_,v in stages)]","sum(v for _,_,v in stages),repno,sum(v for t,ph,v in stages if t==b'16-1' and ph==b'check')]")
    exec(compile(s,'unit-factor','exec'),{'__file__':str(w/'run.py'),'variant':variant})
