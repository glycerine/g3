"""Compare discovery and insertion at the check where the extra work appears."""
import csv,statistics
from collections import defaultdict
from pathlib import Path
w=Path(__file__).resolve().parent
import sys
for group in (sys.argv[1:] or ['rows','lookup','index','stack']):
    p=w/group/'final' if group in ('rows','lookup') else w/group
    counts=defaultdict(lambda:defaultdict(int));attempts=defaultdict(int)
    for n,i,m,t,phase,v,a in csv.reader((p/'rows.csv').open()):
        key=(int(n),int(i),m,t,phase)
        counts[key[0],key[1],m][t,phase]+=int(v)
        attempts[key[0],key[1],m,t]=int(a)
    with (p/'ranked.csv').open('w') as f:
        out=csv.writer(f);out.writerow(['case','batch_goal','phase','base','discover','two','two_minus_base','attempts'])
        for n in sorted({k[0] for k in counts}):
            applied='indexed' if group in ('index','stack') else 'two'
            probe='indexProbe' if group in ('index','stack') else 'probe'
            modes=['base',applied] if group=='rows' else ['base',probe,applied]
            keys={k for m in modes for i in range(3) for k in counts[n,i,m]}
            result=[]
            for t,ph in keys:
                def med(m):return statistics.median(counts[n,i,m].get((t,ph),0) for i in range(3))
                a,b=med('base'),med(applied)
                result.append([n,t,ph,a,med(probe) if probe in modes else '',b,b-a,statistics.median(attempts[n,i,applied,t] for i in range(3))])
            out.writerows(sorted(result,key=lambda r:(-r[6],r[1],r[2])))
