"""Factor the unary search rule against the two binary-witness implementations."""
from pathlib import Path
import os,tarfile
p=Path.cwd();w=Path(os.environ['RESULTS'])
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-terminal-conflict-replay.tar.xz') as t:
    def read(name):return t.extractfile('study/'+name).read().decode()
    code=read('unit.py')
    for file in ['stage-bridge.go.txt','timer.go.txt','guards.go.txt']:
        (w/file).write_text(read(file))
    (w/'unit.go.txt').write_text(read('gate.go.txt'))
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t:
    for variant in ('base','candidate'):
        (w/(variant+'.go.txt')).write_bytes(t.extractfile('study/release-sources/'+variant+'.go.txt').read())
(w/'unit.go.txt').write_text(Path(__file__).with_name('birth.go.txt').read_text()+Path(__file__).with_name('link.txt').read_text())
for variant in ('candidate',):
    key=" k=p/'smtcore/smt_search.go';s=k.read_text();a="
    code=code.replace(key,''' k=p/'smtcore/smt_internalizer_state.go';s=k.read_text();needle='s.boolExpr = append(s.boolExpr, expression)';put(k,s.replace(needle,needle+';if trialOwner==s{trialBirth(s,expression,variable)}'))
 k=p/'smtcore/smt_search.go';s=k.read_text().replace('import (','import ("os";');needle='variable, phase, err := queue.NextCaseSplit()';s=s.replace(needle,'if trialOwner==k.internalizer && len(trialNew)>0 {did,e:=flushBirth(k.internalizer);if e!=nil{return lbool.Undef,false,e};if did{continue}};'+needle);a=''')
    s=code.replace(" j=d/'ov.json'", " put(p/'smtcore/smt_model_checker.go',(w/(variant+'.go.txt')).read_text())\n j=d/'ov.json'").replace("w/'unit-verified.csv'","w/(variant+'.csv')")
    s=s.replace("for key,cases in [('12-8',[8]),('all',[8,4,1,2,3,5,6,7,9,10,11,12])]:","for repno in range(3):\n   key='12-8' if repno==2 else 'all';cases=[8] if repno==2 else [8,6,2,4,3,12,9,5,7,10,11,1,227]")
    s=s.replace("for mode in ['base','first','last','all']:","for mode in (['observe'] if repno==2 else ['base','source','tail','both'][repno:]+['base','source','tail','both'][:repno]):")
    s=s.replace("'case target mode status attempts target_check check_sum stage_sum'","'case target mode status attempts target_check check_sum stage_sum round nested_check'")
    s=s.replace("sum(v for _,_,v in stages)]","sum(v for _,_,v in stages),repno,sum(v for t,ph,v in stages if t==b'16-1' and ph==b'check')]")
    s=s.replace("elif l.startswith(b'UNIT_RESULT '):","elif l.startswith(b'BIRTH '):\n       with (w/'birth.log').open('ab') as log:log.write(l)\n      elif l.startswith(b'UNIT_RESULT '):")
    exec(compile(s,'unit-factor','exec'),{'__file__':str(w/'run.py'),'variant':variant})
