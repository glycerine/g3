"""Build structural Boolean reductions as independent Go overlays."""

import json
import os
from pathlib import Path
import subprocess
import sys


pkg = Path.cwd()
out = Path(__file__).resolve().parent


def replace(code, old, new):
    if code.count(old) != 1:
        raise ValueError(old)
    return code.replace(old, new)


trials = {
    "not": ("bool_rewriter_eq.go", "\tm := rw.manager\n\tnegative, inner, e := m.IsNot(arg)",
             "\tm := rw.manager\n\tif m.TryRecognizeIrreducibleNot(arg) {\n\t\treturn brFailed, nil\n\t}\n\tnegative, inner, e := m.IsNot(arg)"),
    "eq": ("th_rewriter.go", "\t\t\tstatus := RewriteFailed\n\t\t\tswitch sortFamily",
            """            if (sortFamily == ast.NullFamilyID || sortFamily == 4) && m.TryRecognizeOpaqueEquality(left, right) {
                if err := c.boolean.configuredOpen(); err != nil { return RewriteFailed, err }
                return RewriteFailed, nil
            }
            status := RewriteFailed
            switch sortFamily"""),
    "binary": ("rewriter_configuration.go", "func (rw *boolRewriter) mkAppCoreKind(op int32, args ast.AppArguments, out ast.ASTRef) (brStatus, error) {\n\tswitch op",
                """func (rw *boolRewriter) mkAppCoreKind(op int32, args ast.AppArguments, out ast.ASTRef) (brStatus, error) {
    if args.Count() == 2 && (op == ast.ASTOpOr && !rw.localContext || op == ast.ASTOpAnd && !rw.elimAnd) {
        lhs, err := args.At(0)
        if err != nil { return brFailed, err }
        rhs, err := args.At(1)
        if err != nil { return brFailed, err }
        if h, ok := rw.manager.TryReduceBinaryJunction(lhs, rhs, op == ast.ASTOpOr); ok {
            if h.IsNull() { return brFailed, nil }
            return brDone, rw.manager.SetRef(out, h)
        }
    }
    switch op"""),
}


def build(name, frontend):
    selected = name.split("+")
    directory = out / ("shape-" + name)
    directory.mkdir(exist_ok=True)
    patches = {pkg / "ast/rewriter_boolean_shapes.go": out / "shapes.go"}
    for feature in selected:
        filename, old, new = trials[feature]
        path = pkg / "ast/rewriter" / filename
        source = patches.get(path, path)
        code = replace(source.read_text(), old, new)
        target = directory / filename
        target.write_bytes(subprocess.check_output(["gofmt"], input=code.encode()))
        patches[path] = target
    if frontend:
        cwd = Path.home() / "ivy/goivy"
        for src, target in list(patches.items()):
            patches[Path.home() / "g3/pkg" / src.relative_to(pkg)] = target
        entry, mode, binary = "./cmd/goivy_check", ["-tags=xtrace_off"], directory / "goivy_check"
    else:
        cwd = pkg
        entry, mode, binary = "./cmd/g3", [], directory / "g3"
    overlay = directory / "overlay.json"
    overlay.write_text(json.dumps({"Replace": {str(src): str(target) for src, target in patches.items()}}))
    subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", str(overlay),
                    "-o", str(binary), *mode, entry], cwd=cwd, env=os.environ, check=True)


for name in (arg for arg in sys.argv[1:] if arg != "--goivy"):
    build(name, "--goivy" in sys.argv)
