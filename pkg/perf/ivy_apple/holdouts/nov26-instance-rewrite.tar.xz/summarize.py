"""Validate and summarize the saved counters from the quantifier experiments."""

from collections import defaultdict
import csv
from pathlib import Path
from statistics import median

here = Path(__file__).resolve().parent
panels = {
    "shape-replay": (7, 6, True),
    "gate-replay": (9, 4, True),
    "opaque-replay": (7, 5, True),
    "visit-replay": (7, 3, True),
    "verifier": (7, 4, False),
    "memo-verifier": (7, 3, False),
    "retain-replay": (7, 3, False),
    "retain-verifier": (7, 3, False),
    "repeated-replay": (7, 3, False),
    "repeated-verifier": (7, 3, False),
}
columns = ("decisions", "conflicts", "quant-instantiations", "rlimit-count")
for panel, (rounds, participants, matched) in panels.items():
    groups = defaultdict(list)
    for row in csv.DictReader((here / (panel + ".csv")).open()):
        groups[row.get("query", row.get("case"))].append(row)
    assert len(groups) == 3, (panel, groups.keys())
    for name, rows in groups.items():
        engines = defaultdict(list)
        for row in rows:
            engines[row["engine"]].append(row)
        assert len(engines) == participants, (panel, name, engines.keys())
        for label, engine in engines.items():
            assert len(engine) == rounds, (panel, name, label, len(engine))
            assert len({row.get("round", row.get("pair")) for row in engine}) == rounds
        if matched:
            assert all(row["answer"] == "unsat" for row in rows)
            assert len({tuple(row[key] for key in columns) for row in rows}) == 1
        baseline = median(int(row["instructions"]) for row in engines["g3"])
        for label, engine in engines.items():
            insns = median(int(row["instructions"]) for row in engine)
            elapsed = median(float(row.get("milliseconds", "nan")) for row in engine)
            print(f"{panel} {name} {label} {insns/1e6:.3f} M {100*(insns/baseline-1):+.3f}% {elapsed:.3f} ms")
