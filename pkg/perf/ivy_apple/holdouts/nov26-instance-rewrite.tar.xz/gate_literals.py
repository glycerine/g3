"""Compare reusing already-internalized Boolean bindings in asserted ORs."""

import argparse
import json
from pathlib import Path
import subprocess

root = Path.cwd()
scratch = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("trials", nargs="+")
parser.add_argument("--goivy", action="store_true")
args = parser.parse_args()

source = root / "smtcore/smt_internalizer.go"
native_loop = """			for index, argument := range arguments {
				if err = s.Internalize(argument, true); err != nil {"""
loop_with_reuse = """			tryBound := !ast.ASTValidateHandles && !smtcoreSourceDebug && !ast.ASTSourceDebug &&
                s.manager.TraceStream == nil && !s.manager.Budget().InjectionArmed()
            for index, argument := range arguments {
                if tryBound && !s.closed {
                    if literal, found := s.existingGateLiteral(argument); found {
                        literals[index] = literal
                        continue
                    }
                }
				if err = s.Internalize(argument, true); err != nil {"""
probe = """
func (s *SMTInternalizerState) existingGateLiteral(h ast.ASTHandle) (SMTLiteral, bool) {
    if variable, found := s.boolVar.lookup(h); found && s.notChild(variable).IsNull() {
        return NewSMTLiteral(variable, false), true
    }
    SIGNED
    return SMTNullLiteral, false
}
"""
signed = """
    if _, child, err := s.manager.IsNot(h); err == nil && !child.IsNull() {
        if variable, found := s.boolVar.lookup(child); found && s.notChild(variable).IsNull() {
            return NewSMTLiteral(variable, true), true
        }
    }
"""

for name in args.trials:
    if name not in ("baseline", "positive", "signed"):
        parser.error(f"unknown trial {name}")
    dest = scratch / ("gate-" + name)
    dest.mkdir(exist_ok=True)
    paths = {}
    if name != "baseline":
        text = source.read_text()
        assert text.count(native_loop) == 1
        changed = text.replace(native_loop, loop_with_reuse) + probe.replace("SIGNED", signed if name == "signed" else "")
        generated = dest / source.name
        generated.write_bytes(subprocess.check_output(["gofmt"], input=changed.encode()))
        paths[source] = generated
    cwd = root
    binary = dest / "g3"
    command = ["./cmd/g3"]
    if args.goivy:
        cwd = Path.home() / "ivy/goivy"
        binary = dest / "goivy_check"
        command = ["-tags=xtrace_off", "./cmd/goivy_check"]
        for path, replacement in list(paths.items()):
            paths[Path.home() / "g3/pkg" / path.relative_to(root)] = replacement
    overlay = dest / ("goivy.json" if args.goivy else "cli.json")
    overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k, v in paths.items()}}))
    subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", str(overlay),
                    "-o", str(binary), *command], cwd=cwd, check=True)
