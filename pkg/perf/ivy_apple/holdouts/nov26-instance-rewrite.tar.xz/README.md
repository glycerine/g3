# Repeating quantifier work across search branches

The profile and first structural tests use g3 `13f31c341`. The other CLI and GoIvy experiments use `62d38dfa8`. The frontend and spec checkout were both `07cdeec61f94725e452f97d269edc3ed60ca817d`. Go builds used amd64 Go 1.27.3 with PGO disabled. The native controls were the in-tree Z3 executable and the existing linked build from the same frontend revision, with the same ABC executable. The machine was a Threadripper 3960X. CLI rotations pinned CPU 10 or 11, as labelled in the driver invocations. Verifier rotations pinned CPU 11 with GOMAXPROCS 1 and GOGC 100.

Extract this archive to a scratch directory. Run its Python builders from the root of the Go package at the corresponding revision. They write Go overlays and binaries alongside the scripts. Frontend overlays expect GoIvy in `~/ivy/goivy` and its g3 replacement in `~/g3/pkg`. The builders leave tracked files alone.

## Saved inputs and profile

The three standalone inputs are exact incremental streams derived from the tracked gzip vectors by `perf/ivy_apple/holdouts/query_replay.py`, with an appended statistics command. In the matched panels, the driver requires the same answer, decisions, conflicts, instantiations and resource count. The four matched panels are in `shape-replay.csv`, `gate-replay.csv`, `opaque-replay.csv` and `visit-replay.csv`, alongside their counter and solver logs.

The nine profiles of each Ticket replay sampled every 800,003 user instructions with frame pointers, and ran the g3 binary from `13f31c341`. The saved throttle counters record zero throttle or loss records for all profiles. `attribute.py check-profile` reproduces `check-attribution.csv` from the decoded stacks. The original binary profile data, solver output and recorder diagnostics are included for inspection. To capture a new profile, use `perf record -B -N --call-graph fp -e instructions:u -c 800003 -- path/to/g3 -in -smt2` with the saved input on stdin, then `perf script` to decode it. These profiles isolate the check by stack, so they omit the parsing and first-push portion from the check denominator.

## Builds and observations

- `observe.py` builds the exact reducer-key census for CLI use. Run it on each saved input and compare the statistic counters. The census tuple includes the configuration pointer, complete declaration handle and up to four ordered arguments.
- `shapes.py not eq binary not+eq+binary` builds independent structural rewriter shortcuts. `--goivy` selects the full frontend.
- `gate_literals.py baseline positive signed` builds the bound-gate-literal variants. `--goivy` selects the full frontend.
- `opaque_rewrites.py` builds a single variant with `constant`, `application`, `both` or `visit`.
- `instance_observer.py` builds the quantifier, binding and scope census. Run the CLI version on the saved inputs. Build with `--goivy` for the three complete specs. Each solver keeps its own observed tuples. The tables hold plain AST handles and add no AST ownership.
- `memo_trial.py` builds the diagnostic identity memo. Set `G3_INSTANCE_MEMO_TRIAL=audit` to compare previous unchanged results and charges against current normal traversal. Set it to `skip` to elide those traversals and charge the previous count. The skip mode changes actual resource counts and is experimental.
- `retain_instances.py` builds the ground clause lifetime trial. `--after 1` requires at least one prior occurrence of the exact ordered signed clause in the current search. `search_variant.py` records all search counters and requires UNSAT on each replay, with search changes allowed and visible.

## Complete verifiers

Extract `nov24-verifier-instruction-stacks.tar.xz` for `cases.json` and `reference/`. Invoke `verify.py --reference DIR --examples ~/ivy/ivy-lang-examples --cpu 11 --rounds 7 --case ticket_protocol --case hybrid --case arm_rules3 label=/absolute/binary ...` with the built executables, including the linked native control for the baseline comparison. Each run verifies exit status and exact stdout and stderr. The labels `audit` and `skip` enable the corresponding memo mode and preserve its one extra diagnostic line separately. The `*.memo` files contain all audit and skip receipts. The saved census stdout and stderr provide separate correctness controls and are excluded from timings.
