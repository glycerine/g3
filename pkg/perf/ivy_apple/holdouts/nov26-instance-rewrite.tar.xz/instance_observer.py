"""Observe actual instantiated roots and the live bindings of their disjuncts."""

import json
from pathlib import Path
import subprocess
import sys

pkg = Path.cwd()
out = Path(__file__).resolve().parent
target = out / "instance-census"
target.mkdir(exist_ok=True)
patches = {pkg / "smtcore/instance_observer.go": out / "instance_observer.go"}


def replace(src, old, new):
    src = src if src.is_absolute() else pkg / src
    code = patches.get(src, src).read_text()
    if code.count(old) != 1:
        raise ValueError((src, old))
    dst = target / src.name
    dst.write_bytes(subprocess.check_output(["gofmt"], input=code.replace(old, new).encode()))
    patches[src] = dst


replace(Path("smtcore/smt_qi_instance.go"), "\tsatisfied, err := b.checker.run(",
        "\tcorpusInstances.Prepared++\n\tsatisfied, err := b.checker.run(")
replace(Path("smtcore/smt_qi_instance.go"), "\tif satisfied {\n\t\treturn nil", 
        "\tif satisfied {\n\t\tcorpusInstances.CheckerSatisfied++\n\t\treturn nil")
replace(Path("smtcore/smt_qi_instance.go"), "\t\treturn b.Finish(prepared, rewritten, stat, scope)",
        "\t\tsteps, _ := rw.NumSteps()\n\t\tb.observeInstanceRewrite(instance, rewritten, steps)\n\t\treturn b.Finish(prepared, rewritten, stat, scope)")
replace(Path("smtcore/smt_internalizer.go"), "\treturn s.Assert(lemma, proof, instance.Generation())",
        "\tobservedInstanceDepth++\n\tdefer func() { observedInstanceDepth-- }()\n\treturn s.Assert(lemma, proof, instance.Generation())")
replace(Path("smtcore/smt_internalizer.go"), "\t\tcase ast.ASTOpOr:\n\t\t\tliterals := make(",
        "\t\tcase ast.ASTOpOr:\n\t\t\ts.observeInstanceDisjunction(arguments)\n\t\t\tliterals := make(")

replace(Path("smtcore/smt_quantifier_manager.go"), "type SMTQuantifierManager struct {",
        "type SMTQuantifierManager struct {\n instanceObserverEpoch uint64\n instanceObserverLemmas map[ast.ASTHandle]struct{}\n instanceObserverTuples map[instanceTuple]uint64")
replace(Path("smtcore/smt_quantifier_manager.go"), "func (q *SMTQuantifierManager) InitSearch() error {",
        "func (q *SMTQuantifierManager) InitSearch() error {\n q.instanceObserverEpoch++")
replace(Path("smtcore/smt_quantifier_manager.go"), "lemmaErr = q.registry.schedule.RecordInstance(lemma)",
        "q.observeRecordedInstance(lemma, entry)\n lemmaErr = q.registry.schedule.RecordInstance(lemma)")

if "--goivy" in sys.argv:
    cwd = Path.home() / "ivy/goivy"
    entry = Path("cmd/goivy_check/main.go")
    replace(cwd / entry, "package main", 'package main\nimport "github.com/glycerine/g3/pkg/smtcore"')
    replace(cwd / entry, "os.Exit(goivy.MainWithConfig(args, cfg))",
            "code := goivy.MainWithConfig(args, cfg)\n smtcore.PrintInstanceCensus()\n os.Exit(code)")
    patches[(cwd / entry).resolve()] = patches[cwd / entry]
    for path, replacement in list(patches.items()):
        if path.is_relative_to(pkg):
            patches[Path.home() / "g3/pkg" / path.relative_to(pkg)] = replacement
    command = ("-tags=xtrace_off", "./cmd/goivy_check")
    binary = target / "goivy_check"
else:
    replace(Path("cmd/g3/main.go"), "package main", 'package main\nimport "github.com/glycerine/g3/pkg/smtcore"')
    replace(Path("cmd/g3/main.go"), "func main() {", "func main() {\n defer smtcore.PrintInstanceCensus()")
    cwd, command = pkg, ("./cmd/g3",)
    binary = target / "g3"
overlay = target / (binary.name + ".json")
overlay.write_text(json.dumps({"Replace": {str(src): str(dst) for src, dst in patches.items()}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", str(overlay), "-o", str(binary), *command],
               cwd=cwd, check=True)
