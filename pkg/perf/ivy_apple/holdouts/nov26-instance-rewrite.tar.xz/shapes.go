package ast

// TryRecognizeIrreducibleNot checks whether the source's NOT rules can
// apply at this operand's root. Values and equalities retain the full reducer.
func (m *ASTManager) TryRecognizeIrreducibleNot(h ASTHandle) bool {
	if !m.fastHandle(h) || m.lock() != nil {
		return false
	}
	defer m.mu.Unlock()
	r, err := m.internal(h)
	if err != nil {
		return false
	}
	if r == m.trueApp || r == m.falseApp {
		return false
	}
	if m.nodeAt(r.slot).kind != ASTApp {
		return true
	}
	family, op, err := m.appIdentity(m.appAt(r.slot))
	return err == nil && (family != m.BasicFamilyID() || op != ASTOpNot && op != ASTOpEq && op != ASTOpIff)
}

func (m *ASTManager) opaqueSort(r astNodeRef) (astNodeRef, bool) {
	switch m.nodeAt(r.slot).kind {
	case ASTVar:
		return m.varAt(r.slot).sort, true
	case ASTApp:
		a := m.appAt(r.slot)
		family, _, err := m.appIdentity(a)
		if err == nil && family == NullFamilyID {
			sort, err := m.sortOf(r)
			return sort, err == nil
		}
	}
	return astNodeRef{}, false
}

// TryRecognizeOpaqueEquality checks for distinct untyped-by-theory values
// of one uninterpreted sort. None of the retained equality rules reduce it.
func (m *ASTManager) TryRecognizeOpaqueEquality(lhs, rhs ASTHandle) bool {
	if lhs == rhs || !m.fastHandle(lhs) || !m.fastHandle(rhs) || m.lock() != nil {
		return false
	}
	defer m.mu.Unlock()
	l, err := m.internal(lhs)
	if err != nil {
		return false
	}
	r, err := m.internal(rhs)
	if err != nil {
		return false
	}
	ls, a := m.opaqueSort(l)
	rs, b := m.opaqueSort(r)
	if !a || !b || ls != rs {
		return false
	}
	fid, _, err := m.declIdentity(ls)
	return err == nil && staticFeatureUninterpretedSortFamily(fid)
}

type rewriterBinaryLiteral struct {
	atom     astNodeRef
	negative bool
}

func (m *ASTManager) rewriterBinaryOperand(r astNodeRef, op int32) (rewriterBinaryLiteral, bool) {
	a := rewriterBinaryLiteral{atom: r}
	if m.nodeAt(r.slot).kind != ASTApp {
		return a, true
	}
	app := m.appAt(r.slot)
	fam, kind, err := m.appIdentity(app)
	if err != nil {
		return a, false
	}
	if fam == m.BasicFamilyID() {
		if kind == op {
			return a, false
		}
		if kind == ASTOpNot {
			child, err := m.appArg(app, 0)
			return rewriterBinaryLiteral{atom: child, negative: true}, err == nil
		}
	}
	return a, true
}

// TryReduceBinaryJunction reduces a flat ordinary AND or OR. A null result
// indicates that neither operand changed and there was no Boolean identity.
func (m *ASTManager) TryReduceBinaryJunction(lhs, rhs ASTHandle, disjunction bool) (ASTHandle, bool) {
	if !m.fastHandle(lhs) || !m.fastHandle(rhs) || m.lock() != nil {
		return ASTHandle{}, false
	}
	defer m.mu.Unlock()
	l, err := m.internal(lhs)
	if err != nil {
		return ASTHandle{}, false
	}
	r, err := m.internal(rhs)
	if err != nil {
		return ASTHandle{}, false
	}
	unit, absorb, op := m.trueApp, m.falseApp, ASTOpAnd
	if disjunction {
		unit, absorb, op = m.falseApp, m.trueApp, ASTOpOr
	}
	a, aok := m.rewriterBinaryOperand(l, op)
	b, bok := m.rewriterBinaryOperand(r, op)
	if !aok || !bok {
		return ASTHandle{}, false
	}
	if l == absorb || r == absorb {
		return m.external(absorb), true
	}
	if l == unit {
		return rhs, true
	}
	if r == unit {
		return lhs, true
	}
	if a.atom == b.atom {
		if a.negative != b.negative {
			return m.external(absorb), true
		}
		return lhs, true
	}
	return ASTHandle{}, true
}
