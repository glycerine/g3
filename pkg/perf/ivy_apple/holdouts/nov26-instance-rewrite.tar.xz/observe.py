"""Build Go observers for exact reducer inputs and compiled ground plans."""

import json
import os
from pathlib import Path
import subprocess
import sys


pkg = Path.cwd()
out = Path(__file__).resolve().parent
patches = {}


def replace(path, old, new):
    source = patches.get(pkg / path, pkg / path)
    code = source.read_text()
    if code.count(old) != 1:
        raise ValueError((path, old))
    target = out / Path(path).name
    target.write_text(code.replace(old, new))
    patches[pkg / path] = target


replace("ast/rewriter/th_rewriter.go", ") (RewriteStatus, error) {\n\tm := c.owner.manager\n\tfamily, err := m.GetFamilyID(decl)\n\tif err != nil || family == ast.NullFamilyID {", ") (status RewriteStatus, result error) {\n\tdefer c.observeReduction(decl, args)(&status, &result)\n\tm := c.owner.manager\n\tfamily, err := m.GetFamilyID(decl)\n\tif err != nil || family == ast.NullFamilyID {")
replace("ast/rewriter/ground_instance.go", "\tplan := c.plan(m, body)", "\tobserverCalls++\n\tplan := c.plan(m, body)")
replace("ast/rewriter/ground_instance.go", "\treturn c.apply(r, plan, out)", "\tobserverPlans++\n\tobserverApplications += len(plan.apps)\n\treturn c.apply(r, plan, out)")
replace("ast/rewriter/ground_instance.go", "\t\tif retain {\n\t\t\tif err := r.core.cacheResult", "\t\tif retain {\n\t\t\tobserverPlanRetains++\n\t\t\tif err := r.core.cacheResult")

patches[pkg / "ast/rewriter/reduction_observer.go"] = out / "observer.go"
if "--goivy" in sys.argv:
    goivy = Path.home() / "ivy/goivy"
    main = goivy / "cmd/goivy_check/main.go"
    code = main.read_text().replace("package main", "package main\nimport \"github.com/glycerine/g3/pkg/ast/rewriter\"")
    assert code.count("func main() {") == 1
    target = out / "goivy-main.go"
    end = "os.Exit(goivy.MainWithConfig(args, cfg))"
    assert code.count(end) == 1
    target.write_text(code.replace(end, "code := goivy.MainWithConfig(args, cfg)\n rewriter.PrintReductionCensus()\n os.Exit(code)"))
    patches[main] = target
    patches[main.resolve()] = target
    for path, target in list(patches.items()):
        if path.is_relative_to(pkg):
            patches[Path.home() / "g3/pkg" / path.relative_to(pkg)] = target
    cwd, command, binary = goivy, ["-tags=xtrace_off", "./cmd/goivy_check"], out / "observe-goivy"
else:
    replace("cmd/g3/main.go", "package main", "package main\nimport \"github.com/glycerine/g3/pkg/ast/rewriter\"")
    replace("cmd/g3/main.go", "func main() {", "func main() {\n defer rewriter.PrintReductionCensus()")
    cwd, command, binary = pkg, ["./cmd/g3"], out / "observe-g3"
overlay = out / (binary.name + ".json")
overlay.write_text(json.dumps({"Replace": {str(src): str(target) for src, target in patches.items()}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", str(overlay), "-o", str(binary), *command],
               cwd=cwd, env=os.environ, check=True)
