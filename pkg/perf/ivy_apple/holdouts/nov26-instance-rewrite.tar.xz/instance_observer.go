package smtcore

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/glycerine/g3/pkg/ast"
)

type instanceCounts struct {
	Prepared, CheckerSatisfied, Rewritten, RewriteSteps, Unchanged, UnchangedSteps           uint64
	ReducedTrue, ReducedFalse, RepeatedInput, RepeatedUnchangedSteps                         uint64
	Disjunctions, Arguments, BoundPositive, BoundNegative, UntouchedClause                   uint64
	Widths                                                                                   [17]uint64
	Lemmas, LemmasWithBaseBindings, RepeatedLemma, LiveLemma, RetiredLemma                   uint64
	RepresentableTuple, RepeatedTuple, EarlierCheckTuple, SameCheckTuple, SameCheckBaseTuple uint64
}

var corpusInstances instanceCounts
var observedInstanceDepth int
var seenInstanceInputs = make(map[ast.ASTHandle]bool)

func (s *SMTInternalizerState) observeInstanceDisjunction(args []ast.ASTHandle) {
	if observedInstanceDepth == 0 {
		return
	}
	c := &corpusInstances
	c.Disjunctions++
	c.Widths[min(len(args), len(c.Widths)-1)]++
	allBound := true
	for _, h := range args {
		c.Arguments++
		if v, found := s.boolVar.lookup(h); found && s.notChild(v).IsNull() {
			c.BoundPositive++
		} else if _, child, err := s.manager.IsNot(h); err == nil && !child.IsNull() {
			if v, found := s.boolVar.lookup(child); found && s.notChild(v).IsNull() {
				c.BoundNegative++
			} else {
				allBound = false
			}
		} else {
			allBound = false
		}
	}
	if allBound {
		c.UntouchedClause++
	}
}

func (b *SMTQIInstanceBuilder) observeInstanceRewrite(raw, result ast.ASTHandle, steps uint32) {
	c := &corpusInstances
	c.Rewritten++
	c.RewriteSteps += uint64(steps)
	unchanged := raw == result
	previouslyUnchanged, repeat := seenInstanceInputs[raw]
	if repeat {
		c.RepeatedInput++
	}
	if unchanged {
		c.Unchanged++
		c.UnchangedSteps += uint64(steps)
		if previouslyUnchanged {
			c.RepeatedUnchangedSteps += uint64(steps)
		}
	}
	seenInstanceInputs[raw] = unchanged
	if b.manager.IsTrue(result) {
		c.ReducedTrue++
	}
	if b.manager.IsFalse(result) {
		c.ReducedFalse++
	}
}

func PrintInstanceCensus() {
	data, err := json.Marshal(corpusInstances)
	if err != nil {
		panic(err)
	}
	fmt.Fprintf(os.Stderr, "INSTANCE-CENSUS %s\n", data)
}

type instanceTuple struct {
	quantifier ast.ASTHandle
	bindings   [8]ast.ASTHandle
	arity      int
}

func (q *SMTQuantifierManager) observeRecordedInstance(lemma ast.ASTHandle, entry SMTQIQueueEntry) {
	c := &corpusInstances
	c.Lemmas++
	if _, ok := q.instanceObserverLemmas[lemma]; ok {
		c.RepeatedLemma++
		live := false
		for _, active := range q.registry.schedule.instances {
			if active == lemma {
				live = true
				break
			}
		}
		if live {
			c.LiveLemma++
		} else {
			c.RetiredLemma++
		}
	}
	if q.instanceObserverLemmas == nil {
		q.instanceObserverLemmas = make(map[ast.ASTHandle]struct{})
	}
	q.instanceObserverLemmas[lemma] = struct{}{}
	f := entry.Fingerprint
	tuple := instanceTuple{quantifier: f.data, arity: len(f.args)}
	if tuple.arity > len(tuple.bindings) {
		return
	}
	c.RepresentableTuple++
	base := true
	for i, node := range f.args {
		tuple.bindings[i] = node.owner
		base = base && node.internalScopeLevel <= q.state.searchLevel
	}
	if base {
		c.LemmasWithBaseBindings++
	}
	if prev, ok := q.instanceObserverTuples[tuple]; ok {
		c.RepeatedTuple++
		if prev == q.instanceObserverEpoch {
			c.SameCheckTuple++
			if base {
				c.SameCheckBaseTuple++
			}
		} else {
			c.EarlierCheckTuple++
		}
	}
	if q.instanceObserverTuples == nil {
		q.instanceObserverTuples = make(map[instanceTuple]uint64)
	}
	q.instanceObserverTuples[tuple] = q.instanceObserverEpoch
}
