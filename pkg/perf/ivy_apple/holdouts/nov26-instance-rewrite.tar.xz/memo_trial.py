"""Build a shadow audit and diagnostic identity-only quantifier rewrite memo."""

import json
from pathlib import Path
import subprocess
import sys

pkg = Path.cwd()
out = Path(__file__).resolve().parent
dest = out / "memo-trial"
dest.mkdir(exist_ok=True)
patches = {pkg / "smtcore/memo_trial.go": out / "memo_trial.go"}


def replace(path, pairs):
    text = path.read_text()
    for orig, edited in pairs:
        if text.count(orig) != 1:
            raise ValueError(orig)
        text = text.replace(orig, edited)
    target = dest / path.name
    target.write_bytes(subprocess.check_output(["gofmt"], input=text.encode()))
    patches[path] = target


replace(pkg / "smtcore/smt_qi_instance.go", (
    ("type SMTQIInstanceBuilder struct {", "type SMTQIInstanceBuilder struct {\n memoTrial map[ast.ASTHandle]memoTrialEntry"),
    ("rw.Rewrite(instance, simplified)", "b.trialRewrite(rw, instance, simplified)"),
))
if "--goivy" in sys.argv:
    cwd = Path.home() / "ivy/goivy"
    main = cwd / "cmd/goivy_check/main.go"
    replace(main, (
        ("package main", 'package main\nimport "github.com/glycerine/g3/pkg/smtcore"'),
        ("os.Exit(goivy.MainWithConfig(args, cfg))",
         "code := goivy.MainWithConfig(args, cfg)\n smtcore.PrintMemoTrial()\n os.Exit(code)"),
    ))
    patches[main.resolve()] = patches[main]
    for src, target in list(patches.items()):
        if src.is_relative_to(pkg):
            patches[Path.home() / "g3/pkg" / src.relative_to(pkg)] = target
    entry, name = ("-tags=xtrace_off", "./cmd/goivy_check"), "goivy_check"
else:
    replace(pkg / "cmd/g3/main.go", (
        ("package main", 'package main\nimport "github.com/glycerine/g3/pkg/smtcore"'),
        ("func main() {", "func main() {\n defer smtcore.PrintMemoTrial()"),
    ))
    cwd, entry, name = pkg, ("./cmd/g3",), "g3"
overlay = dest / (name + ".json")
overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k, v in patches.items()}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly",
                "-overlay", str(overlay), "-o", str(dest / name), *entry], cwd=cwd, check=True)
