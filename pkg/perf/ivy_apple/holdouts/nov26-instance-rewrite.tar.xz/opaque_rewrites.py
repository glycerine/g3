"""Test preserving the rewriter's frame/ref operations without dispatching opaque applications."""

import argparse
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
scratch = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("trial", choices=("constant", "application", "both", "visit"))
p.add_argument("--goivy", action="store_true")
a = p.parse_args()
dest = scratch / ("opaque-" + a.trial)
dest.mkdir(exist_ok=True)
original = pkg / "ast/rewriter/rewriter_engine.go"
text = original.read_text()
text = text.replace('"github.com/glycerine/g3/pkg/ast"', '"github.com/glycerine/g3/pkg/ast"\n"github.com/glycerine/g3/pkg/util/diagnostic"') if '"github.com/glycerine/g3/pkg/util/diagnostic"' not in text else text


def substitute(old, new):
    global text
    if text.count(old) != 1:
        raise ValueError(old)
    text = text.replace(old, new)


if a.trial in ("constant", "both"):
    substitute("""func (r *rewriterEngine) processConst(t ast.ASTHandle) error {
	c := &r.core
	m := c.manager
	d, e := m.GetDecl(t)""",
               """func (r *rewriterEngine) processConst(t ast.ASTHandle) error {
    c := &r.core
    m := c.manager
    if !c.proofGen && r.isUninterpretedApplication(t) {
        if err := m.ResetRefHeld(r.pr); err != nil {
            return err
        }
        return appendRewriterRoot(m, &c.results, t)
    }
    d, e := m.GetDecl(t)""")
if a.trial in ("application", "both"):
    substitute("""		d, e := m.GetDecl(t)
		if e != nil {
			return e
		}
		// f->is_associative()""",
               """        if !fr.newChild() && r.isUninterpretedApplication(t) {
            if err := m.ResetRefHeld(r.pr2); err != nil {
                return err
            }
            if err := m.SetRefHeld(r.r, t); err != nil {
                return err
            }
            return r.finish(fr, false, true)
        }
		d, e := m.GetDecl(t)
		if e != nil {
			return e
		}
		// f->is_associative()""")
if a.trial == "visit":
    substitute("""	m := c.manager
	sub, subProof, found, e := r.cfg.GetSubst(t)""",
               """    m := c.manager
    if depth != 0 && len(c.frames) != 0 && !c.proofGen && r.canVisitOpaqueConstant() {
        if proof, err := m.RefGetHeld(r.pr); err == nil && proof.IsNull() && m.TryIncRefHeldUninterpretedConstant(t) {
            c.results = append(c.results, t)
            return true, nil
        }
    }
    sub, subProof, found, e := r.cfg.GetSubst(t)""")
    text += """
func (r *rewriterEngine) canVisitOpaqueConstant() bool {
    if ast.ASTValidateHandles || ast.ASTSourceDebug || diagnostic.TraceCompiled() {
        return false
    }
    c, ok := r.cfg.(*theoryRewriterConfiguration)
    return ok && !c.hasSubstitution && !c.pushITEArithmetic && !c.pushITEBitVector && !c.pullCheapITE &&
        r.core.manager.TraceStream == nil && !r.core.manager.Budget().InjectionArmed()
}
"""
text += """
func (r *rewriterEngine) isUninterpretedApplication(t ast.ASTHandle) bool {
    if ast.ASTValidateHandles || ast.ASTSourceDebug || diagnostic.TraceCompiled() {
        return false
    }
    c, ok := r.cfg.(*theoryRewriterConfiguration)
    if !ok || c.pushITEArithmetic || c.pushITEBitVector || c.pullCheapITE ||
        r.core.manager.TraceStream != nil || r.core.manager.Budget().InjectionArmed() {
        return false
    }
    app, family, _, err := r.core.manager.AppIdentity(t)
    return err == nil && app && family == ast.NullFamilyID
}
"""
source = dest / original.name
source.write_bytes(subprocess.check_output(["gofmt"], input=text.encode()))
paths = {original: source}
cwd, name, command = pkg, "g3", ("./cmd/g3",)
if a.goivy:
    for src, replacement in list(paths.items()):
        paths[Path.home() / "g3/pkg" / src.relative_to(pkg)] = replacement
    cwd, name, command = Path.home() / "ivy/goivy", "goivy_check", ("-tags=xtrace_off", "./cmd/goivy_check")
overlay = dest / (name + ".json")
overlay.write_text(json.dumps({"Replace": {str(s): str(d) for s, d in paths.items()}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", str(overlay),
                "-o", str(dest/name), *command], cwd=cwd, check=True)
