"""Count instruction samples inside the incremental check by call path."""

from collections import Counter
import csv
from pathlib import Path
import sys


families = {
    "quantifier propagation": "(*SMTQuantifierManager).Propagate",
    "candidate checker": "(*SMTChecker).checkCandidateCore",
    "instantiation body": "(*SMTCachedVarSubstitution).Instantiate",
    "instantiate materialize": "(*SMTQIInstanceBuilder).MaterializeAndInternalize",
    "theory reduce": "(*theoryRewriterConfiguration).reduceAppCore",
    "theory traversal": "(*TheoryRewriter).Rewrite",
    "ground plan": "(*GroundInstancePlans).apply",
    "enode internalization": "(*SMTInternalizerState).Internalize",
    "matching": "(*smtMAMInterpreter).step",
    "subsumption": "(*satSimplifierKernel).collectSubsumed1Core",
}

writer = csv.writer(sys.stdout)
writer.writerow(("query", "kind", "call", "samples", "check_samples", "process_samples"))
for name in ("ticket-127", "ticket-290"):
    inline = Counter()
    leaf = Counter()
    checks = outside = 0
    paths = sorted(Path(sys.argv[1]).glob(name+"-*.stacks"))
    for path in paths:
        if int(path.with_suffix(".throttle").read_text()) != 0:
            raise ValueError(f"lost samples in {path}")
        for sample in path.read_text().split("\n\n"):
            rows = sample.splitlines()
            if len(rows) < 2:
                continue
            if "(*Context).CheckSatDisplay" not in sample:
                outside += 1
                continue
            checks += 1
            for label, symbol in families.items():
                if symbol in sample:
                    inline[label] += 1
            key = rows[1].split()[1].split("+0x")[0].removeprefix("github.com/glycerine/g3/pkg/")
            leaf[key] += 1
    for kind, counts in (("inclusive", inline), ("leaf", leaf)):
        for key, n in counts.most_common():
            writer.writerow((name, kind, key, n, checks, checks+outside))
