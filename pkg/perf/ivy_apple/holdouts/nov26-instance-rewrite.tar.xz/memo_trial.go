package smtcore

import (
	"fmt"
	"os"

	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/ast/rewriter"
)

// This experiment intentionally probes a weaker key than a production
// rewriter could use. In audit mode it checks that key against the real
// traversal while preserving all of the traversal's work and ownership.
type memoTrialEntry struct {
	charge    uint32
	unchanged bool
}

var memoTrialMode = os.Getenv("G3_INSTANCE_MEMO_TRIAL")
var memoTrialHits, memoTrialChanged, memoTrialChargeChanged, memoTrialSaved uint64

func PrintMemoTrial() {
	fmt.Fprintf(os.Stderr, "MEMO-TRIAL %s hits=%d changed=%d costs_changed=%d saved_polls=%d\n",
		memoTrialMode, memoTrialHits, memoTrialChanged, memoTrialChargeChanged, memoTrialSaved)
}

func (b *SMTQIInstanceBuilder) trialRewrite(rw *rewriter.TheoryRewriter, raw ast.ASTHandle, out ast.ASTRef) error {
	limit := b.manager.ResourceLimit()
	previous, seen := b.memoTrial[raw]
	candidate := seen && previous.unchanged
	if candidate && memoTrialMode == "skip" && limit.TryIncOffset(previous.charge) {
		memoTrialHits++
		memoTrialSaved += uint64(previous.charge)
		return b.manager.SetRef(out, raw)
	}
	before := limit.Steps
	if err := rw.Rewrite(raw, out); err != nil {
		return err
	}
	result, err := b.manager.RefGet(out)
	if err != nil {
		return err
	}
	delta := uint32(limit.Steps - before)
	if candidate {
		memoTrialHits++
		if raw != result {
			memoTrialChanged++
		}
		if previous.charge != delta {
			memoTrialChargeChanged++
		}
	}
	if b.memoTrial == nil {
		b.memoTrial = make(map[ast.ASTHandle]memoTrialEntry)
	}
	if len(b.memoTrial) == 2048 {
		clear(b.memoTrial)
	}
	b.memoTrial[raw] = memoTrialEntry{charge: delta, unchanged: raw == result}
	return nil
}
