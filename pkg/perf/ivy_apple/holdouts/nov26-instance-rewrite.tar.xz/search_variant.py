"""Rotate a search-changing g3 prototype against the release and in-tree Z3."""

import argparse
import csv
from pathlib import Path
import re
import subprocess
import sys
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--cpu", type=int, required=True)
p.add_argument("--perf", default="perf")
p.add_argument("--pairs", type=int, default=7)
p.add_argument("--query", required=True, action="append", type=Path)
p.add_argument("--output", required=True, type=Path)
p.add_argument("engines", nargs="+")
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=False)
engines = [e.split("=", 1) for e in a.engines]
stats = ("decisions", "conflicts", "quant-instantiations", "rlimit-count")
writer = csv.writer(sys.stdout, lineterminator="\n")
writer.writerow(("query", "round", "engine", "instructions", "cycles", "milliseconds", *stats))
for query in a.query:
    source = query.read_bytes()
    for i in range(a.pairs):
        n = i % len(engines)
        for label, path in engines[n:] + engines[:n]:
            row = a.output / f"{query.stem}-{i+1}-{label}"
            counts = row.with_suffix(".perf")
            cmd = ["taskset", "-c", str(a.cpu), a.perf, "stat", "-x,", "-o", counts,
                   "-e", "instructions:u,cycles:u", "--", path, "-in", "-smt2"]
            start = time.monotonic()
            run = subprocess.run(cmd, input=source, capture_output=True, timeout=120)
            ms = (time.monotonic() - start) * 1000
            row.with_suffix(".stdout").write_bytes(run.stdout)
            row.with_suffix(".stderr").write_bytes(run.stderr)
            if run.returncode or not run.stdout.startswith(b"unsat\n") or b"(error" in run.stdout or run.stderr:
                raise ValueError((row, run.returncode))
            gather = dict(re.findall(r":([\w-]+)\s+(\d+)\b", run.stdout.decode()))
            hardware = {record[2]: int(record[0]) for record in csv.reader(counts.read_text().splitlines())
                        if len(record) > 4 and record[2].endswith(":u") and float(record[4]) == 100.0}
            writer.writerow((query.stem, i+1, label, hardware["instructions:u"], hardware["cycles:u"], f"{ms:.3f}",
                             *(gather.get(col, "-") for col in stats)))
            sys.stdout.flush()
