"""Try learned-clause lifetime for ground quantifier clauses in the current search."""

import argparse
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
out = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--goivy", action="store_true")
p.add_argument("--after", type=int, choices=(0, 1, 2), default=0, help="earlier exact signed clauses required")
a = p.parse_args()
dst = out / ("retain-instances" if a.after == 0 else f"retain-after-{a.after}")
dst.mkdir(exist_ok=True)
src = pkg / "smtcore/smt_internalizer.go"
text = src.read_text()


def replace(old, new):
    global text
    if text.count(old) != 1:
        raise ValueError(old)
    text = text.replace(old, new)


replace(
    "func (s *SMTInternalizerState) Assert(expression, proof ast.ASTHandle, generation uint32) error {",
    """func (s *SMTInternalizerState) Assert(expression, proof ast.ASTHandle, generation uint32) error {
        return s.assertFormula(expression, proof, generation, false)
    }

    func (s *SMTInternalizerState) assertFormula(expression, proof ast.ASTHandle, generation uint32, quantifiedInstance bool) error {""")
replace("""			if err = s.addRootClause(literals, proof); err != nil {
				return err
			}
			if s.relevancy != nil {
				if err = s.relevancy.addAssertedOrWatches""",
        """        if quantifiedInstance && proof.IsNull() && s.canRetainInstance(literals) {
                err = s.addClauseKind(literals, true, SMTClauseAuxLemma, ast.ASTHandle{})
            } else {
                err = s.addRootClause(literals, proof)
            }
            if err != nil { return err }
			if s.relevancy != nil {
				if err = s.relevancy.addAssertedOrWatches""")
replace("return s.Assert(lemma, proof, instance.Generation())", "return s.assertFormula(lemma, proof, instance.Generation(), true)")
text += """
// Retain only complete signed clauses that refer to pre-decision variables
// and belong to the current search. The prototype exercises the existing
// learned-clause pop and reinit path. It keeps the quantifier guard.
func (s *SMTInternalizerState) canRetainInstance(literals []SMTLiteral) bool {
    if !s.searching || s.scopeLevel <= s.searchLevel || len(literals) < 2 || !literals[0].Sign() ||
        ast.ASTValidateHandles || smtcoreSourceDebug || s.manager.TraceStream != nil || s.manager.Budget().InjectionArmed() {
        return false
    }
    proofs, err := s.manager.ProofsEnabled()
    if err != nil || proofs {
        return false
    }
    first := literals[0].Var()
    if first < SMTFirstBoolVar || !s.booleanData[first].IsQuantifier() {
        return false
    }
    for _, lit := range literals {
        v := lit.Var()
        if v < SMTFirstBoolVar || s.booleanData[v].InternalLevel() > s.searchLevel {
            return false
        }
    }
    return true
}
"""
extra = {}
if a.after:
    ending = "    return true\n}\n"
    assert text.endswith(ending)
    text = text[:-len(ending)] + """
    if len(literals) > 8 {
        return false
    }
    key := retainedInstanceKey{width: uint8(len(literals))}
    copy(key.literals[:], literals)
    count := s.repeatedInstances[key]
    if count >= THRESHOLD {
        return true
    }
    if s.repeatedInstances == nil {
        s.repeatedInstances = make(map[retainedInstanceKey]uint8)
    }
    s.repeatedInstances[key] = count + 1
    return false
}

type retainedInstanceKey struct {
    literals [8]SMTLiteral
    width uint8
}
""".replace("THRESHOLD", str(a.after))
    for filename, old, new in (
        ("smt_internalizer_state.go", "type SMTInternalizerState struct {",
         "type SMTInternalizerState struct {\nrepeatedInstances map[retainedInstanceKey]uint8"),
        ("smt_learned_persistence.go", "\ts.searching = true\n\ts.searchBaseLevel",
         "\tclear(s.repeatedInstances)\n\ts.searching = true\n\ts.searchBaseLevel"),
    ):
        other = pkg / "smtcore" / filename
        original = other.read_text()
        assert original.count(old) == 1
        patch = dst / filename
        patch.write_bytes(subprocess.check_output(["gofmt"], input=original.replace(old, new).encode()))
        extra[other] = patch

generated = dst / src.name
generated.write_bytes(subprocess.check_output(["gofmt"], input=text.encode()))
paths = {src: generated, **extra}
cwd, name, command = pkg, "g3", ("./cmd/g3",)
if a.goivy:
    for src, replacement in list(paths.items()):
        paths[Path.home() / "g3/pkg" / src.relative_to(pkg)] = replacement
    cwd, name, command = Path.home() / "ivy/goivy", "goivy_check", ("-tags=xtrace_off", "./cmd/goivy_check")
overlay = dst / (name + ".json")
overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k, v in paths.items()}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", str(overlay),
                "-o", str(dst / name), *command], cwd=cwd, check=True)
