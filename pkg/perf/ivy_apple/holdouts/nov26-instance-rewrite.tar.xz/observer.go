package rewriter

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/glycerine/g3/pkg/ast"
)

type reductionKey struct {
	config *theoryRewriterConfiguration
	decl   ast.ASTHandle
	args   [4]ast.ASTHandle
	count  uint32
}

type reductionCounts struct {
	Calls, Failed, Done, Repeat, RepeatFailed, ChangedAfterFailure uint64
}

var reductionHistory = make(map[reductionKey]RewriteStatus)
var reductionCensus = make(map[string]reductionCounts)
var observerCalls, observerPlans, observerApplications, observerPlanRetains int

func (c *theoryRewriterConfiguration) observeReduction(decl ast.ASTHandle, args ast.AppArguments) func(*RewriteStatus, *error) {
	m := c.owner.manager
	family, _ := m.GetFamilyID(decl)
	kind, _ := m.GetDeclKind(decl)
	sortFamily := ast.NullFamilyID
	if family == m.BasicFamilyID() && kind == ast.ASTOpEq && args.Count() == 2 {
		left, _ := args.At(0)
		sort, _ := m.GetSort(left)
		sortFamily, _ = m.GetFamilyID(sort)
	}
	k := fmt.Sprintf("%d/%d/%d/%d", family, kind, sortFamily, args.Count())
	if family == ast.NullFamilyID {
		k = fmt.Sprintf("uninterpreted/%d", args.Count())
	}
	key := reductionKey{config: c, decl: decl, count: args.Count()}
	if args.Count() <= uint32(len(key.args)) {
		for i := uint32(0); i < args.Count(); i++ {
			key.args[i], _ = args.At(i)
		}
	}
	return func(status *RewriteStatus, result *error) {
		if *result != nil {
			return
		}
		count := reductionCensus[k]
		count.Calls++
		if *status == RewriteFailed {
			count.Failed++
		}
		if *status == RewriteDone {
			count.Done++
		}
		if key.count <= uint32(len(key.args)) {
			previous, seen := reductionHistory[key]
			if seen {
				count.Repeat++
				if previous == RewriteFailed && *status == RewriteFailed {
					count.RepeatFailed++
				}
				if previous == RewriteFailed && *status != RewriteFailed {
					count.ChangedAfterFailure++
				}
			}
			reductionHistory[key] = *status
		}
		reductionCensus[k] = count
	}
}

func PrintReductionCensus() {
	data, _ := json.Marshal(reductionCensus)
	fmt.Fprintf(os.Stderr, "REDUCTION-CENSUS %s\nGROUND-PLANS %d %d %d %d\n", data,
		observerCalls, observerPlans, observerApplications, observerPlanRetains)
}
