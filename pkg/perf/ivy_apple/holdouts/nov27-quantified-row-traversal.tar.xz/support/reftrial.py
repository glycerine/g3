from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
src=p/'smtcore/smt_asserted_formulas.go';s=src.read_text();i=s.index('proofRef, err :=',s.index('func (k *SMTKernel) preprocessAssertionMode'));j=s.index('return k.preprocessAssertionWithMode',i)
s=s[:i]+'''proofs, err := k.manager.ProofsEnabled()
 if err != nil {return ast.ASTHandle{}, ast.ASTHandle{}, err}
 var proofRef ast.ASTRef
 if proofs || k.preprocessor.ProofGen() {
  proofRef,err=k.manager.NewRef(ast.ASTHandle{})
  if err!=nil{return ast.ASTHandle{},ast.ASTHandle{},err}
  defer func(){err=errors.Join(err,k.manager.DelRef(&proofRef))}()
 }
 '''+s[j:];dst=w/'reftrial.go.txt';dst.write_text(s)
ov=w/'reftrial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().replace("Path('/tmp/g3-card-install/volume-release')","Path('/tmp/g3-live-literals/nextsplit/release')").replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy']","['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/flash2.ivy','examples/liveness/alternating_bit_protocol.ivy','test/arm_rules3.ivy']")
exec(compile(script,__file__,'exec'))
