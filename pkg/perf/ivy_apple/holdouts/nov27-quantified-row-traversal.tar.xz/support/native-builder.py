"""Build a fork-native Ticket rewrite census using three replacement objects."""
from pathlib import Path
import re
import shlex
import subprocess

pkg = Path.cwd()
root = pkg.parent
build = root / 'build'
out = Path(__file__).resolve().parent / 'native'
out.mkdir(exist_ok=True)
flags = dict(row.split('=', 1) for row in (build / 'config.mk').read_text().splitlines() if '=' in row)
makefile = (build / 'Makefile').read_text()
fields = ('calls', 'visits', 'substitution_hits', 'visit_probes', 'visit_hits', 'resume_probes', 'resume_hits',
          'steps', 'app_steps', 'reductions', 'reduction_misses', 'constants', 'result_releases')
observer = out / 'observe.hpp'
observer.write_text('''#pragma once
#include <cstdio>
struct qi_observation {
    bool active = false;
''' + ''.join('    unsigned long long %s = 0;\n' % field for field in fields) + '''    ~qi_observation() {
        std::fprintf(stderr, "QI-FRAMES");
''' + ''.join('        std::fprintf(stderr, " %s=%%llu", %s);\n' % (f, f) for f in fields) + '''        std::fprintf(stderr, "\\n");
    }
};
extern qi_observation qi_observed;
struct qi_observation_scope {
    bool previous;
    qi_observation_scope(): previous(qi_observed.active) { qi_observed.active = true; ++qi_observed.calls; }
    ~qi_observation_scope() { qi_observed.active = previous; }
};
#define QI_OBSERVE(field) do { if (qi_observed.active) ++qi_observed.field; } while (false)
#define QI_SHRINK(n) do { if (qi_observed.active) qi_observed.result_releases += result_stack().size() - (n); } while (false)
''')

def once(s, old, new):
    if s.count(old) != 1:
        raise ValueError((old, s.count(old)))
    return s.replace(old, new)

header_name = 'ast/rewriter/rewriter_def.h'
header = (root / 'src' / header_name).read_text()
header = once(header, 'bool rewriter_tpl<Config>::visit(expr * t, unsigned max_depth) {',
              'bool rewriter_tpl<Config>::visit(expr * t, unsigned max_depth) {\n    QI_OBSERVE(visits);')
header = once(header, 'if (m_cfg.get_subst(t, new_t, new_t_pr)) {',
              'if (m_cfg.get_subst(t, new_t, new_t_pr)) {\n        QI_OBSERVE(substitution_hits);')
for depth, name in ((8, 'visit'), (12, 'resume')):
    indent = ' ' * depth
    old = indent + 'expr * r = get_cached(t);\n' + indent + 'if (r) {'
    segment_marker = 'bool rewriter_tpl<Config>::visit(' if name == 'visit' else 'void rewriter_tpl<Config>::resume_core('
    split = header.index(segment_marker)
    end = header.index('\ntemplate<typename Config>', split) if name == 'visit' else len(header)
    new = indent + f'QI_OBSERVE({name}_probes);\n' + old + '\n' + indent + f'    QI_OBSERVE({name}_hits);'
    header = header[:split] + once(header[split:end], old, new) + header[end:]
header = once(header, '        m_num_steps++;', '        m_num_steps++;\n        QI_OBSERVE(steps);')
header = once(header, 'void rewriter_tpl<Config>::process_app(app * t, frame & fr) {',
              'void rewriter_tpl<Config>::process_app(app * t, frame & fr) {\n    QI_OBSERVE(app_steps);')
header = once(header, '        br_status st = m_cfg.reduce_app(f, new_num_args, new_args, m_r, m_pr2);',
              '        QI_OBSERVE(reductions);\n        br_status st = m_cfg.reduce_app(f, new_num_args, new_args, m_r, m_pr2);\n        if (st == BR_FAILED) QI_OBSERVE(reduction_misses);')
header = once(header, 'void rewriter_tpl<Config>::process_const(app * t) {',
              'void rewriter_tpl<Config>::process_const(app * t) {\n    QI_OBSERVE(constants);')
header = re.sub(r'result_stack\(\)\.shrink\(([^;]+)\);', r'QI_SHRINK(\1); result_stack().shrink(\1);', header)
header = re.sub(r'(?<!_)result_stack\(\)\.pop_back\(\);', r'QI_OBSERVE(result_releases); result_stack().pop_back();', header)
path = out / header_name
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(header)
queue_path = root / 'src/smt/qi_queue.cpp'
queue = once(queue_path.read_text(), 'namespace smt {', 'qi_observation qi_observed;\n\nnamespace smt {')
queue = once(queue, '        m_context.get_rewriter()(instance, s_instance, pr);',
             '        { qi_observation_scope observe; m_context.get_rewriter()(instance, s_instance, pr); }')
queue_out = out / queue_path.name
queue_out.write_text(queue)
core_path = root / 'src/ast/rewriter/rewriter.cpp'
core = core_path.read_text()
core = re.sub(r'm_result_stack\.shrink\(([^;]+)\);',
              r'if (qi_observed.active) qi_observed.result_releases += m_result_stack.size() - (\1); m_result_stack.shrink(\1);', core)
core = core.replace('m_result_stack.pop_back();', 'QI_OBSERVE(result_releases); m_result_stack.pop_back();')
core_out = out / core_path.name
core_out.write_text(core)
objects = []
for includes, source in (('includes_12', root / 'src/ast/rewriter/th_rewriter.cpp'), ('includes_39', queue_out), ('includes_12', core_out)):
    includes = re.search(r'^'+includes+r' = (.*)$', makefile, re.M)[1]
    dest = out / (source.stem + '.o')
    command = [flags['CXX'], *shlex.split(flags['CXXFLAGS']), '-I'+str(out), *shlex.split(includes),
               '-include', str(observer), '-o', str(dest), str(source)]
    subprocess.run(command, cwd=build, check=True)
    objects.append(str(dest))
link = re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$', makefile, re.M)[1]
objects_and_libs = shlex.split(link.split('$(LINK_FLAGS)', 1)[1].split('$(LINK_EXTRA_FLAGS)', 1)[0]
                             .replace('$(OBJ_EXT)', '.o').replace('$(LIB_EXT)', '.a'))
subprocess.run([flags['LINK'], '-o', str(out/'z3'), *objects, *objects_and_libs, *shlex.split(flags['LINK_EXTRA_FLAGS'])],
               cwd=build, check=True)
