#pragma once
#include <cstdio>
struct qi_observation {
    bool active = false;
    unsigned long long calls = 0;
    unsigned long long visits = 0;
    unsigned long long substitution_hits = 0;
    unsigned long long visit_probes = 0;
    unsigned long long visit_hits = 0;
    unsigned long long resume_probes = 0;
    unsigned long long resume_hits = 0;
    unsigned long long steps = 0;
    unsigned long long app_steps = 0;
    unsigned long long reductions = 0;
    unsigned long long reduction_misses = 0;
    unsigned long long constants = 0;
    unsigned long long result_releases = 0;
    ~qi_observation() {
        std::fprintf(stderr, "QI-FRAMES");
        std::fprintf(stderr, " calls=%llu", calls);
        std::fprintf(stderr, " visits=%llu", visits);
        std::fprintf(stderr, " substitution_hits=%llu", substitution_hits);
        std::fprintf(stderr, " visit_probes=%llu", visit_probes);
        std::fprintf(stderr, " visit_hits=%llu", visit_hits);
        std::fprintf(stderr, " resume_probes=%llu", resume_probes);
        std::fprintf(stderr, " resume_hits=%llu", resume_hits);
        std::fprintf(stderr, " steps=%llu", steps);
        std::fprintf(stderr, " app_steps=%llu", app_steps);
        std::fprintf(stderr, " reductions=%llu", reductions);
        std::fprintf(stderr, " reduction_misses=%llu", reduction_misses);
        std::fprintf(stderr, " constants=%llu", constants);
        std::fprintf(stderr, " result_releases=%llu", result_releases);
        std::fprintf(stderr, "\n");
    }
};
extern qi_observation qi_observed;
struct qi_observation_scope {
    bool previous;
    qi_observation_scope(): previous(qi_observed.active) { qi_observed.active = true; ++qi_observed.calls; }
    ~qi_observation_scope() { qi_observed.active = previous; }
};
#define QI_OBSERVE(field) do { if (qi_observed.active) ++qi_observed.field; } while (false)
#define QI_SHRINK(n) do { if (qi_observed.active) qi_observed.result_releases += result_stack().size() - (n); } while (false)
