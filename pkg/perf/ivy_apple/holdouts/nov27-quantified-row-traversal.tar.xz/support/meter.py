"""Price the operations in ordinary non-proof application frames on matched replay instances."""
from pathlib import Path
import sys,tarfile,subprocess
w=Path(__file__).resolve().parent/'meter';w.mkdir(exist_ok=True);p=Path.cwd()
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-ticket-instance-operators.tar.xz') as t:
 for name in ['build.py','run.py','go/zz_opstudy.go.txt','native/ops.hpp',*[m.name for m in t if m.name.startswith('fixtures/') and m.isfile()]]:
  d=w/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(t.extractfile(name).read())
def sub(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text();a=s.index('func (r *rewriterEngine) processApp()');b=s.index('// processAppMacroEnd',a);pre,x,post=s[:a],s[a:b],s[b:]
for key,i in [('arg, e := m.GetArg(t, i)',1),('done, e := r.visit(arg, fr.maxDepth())',2),('args, e := c.resultArguments(fr.spos, size-fr.spos)',3),('h, e = m.RewriterMakeApp(d, args)',4),('folded, e := r.constantFold(fi)',6)]:
 frag='stamp'+str(i)+':=opBegin(); '+key+';opEnd('+str(i)+',stamp'+str(i)+')';x=x.replace(key,frag)
key='return r.finish(fr, false, true)';i=x.rindex(key);x=x[:i]+x[i:].replace(key,'stamp:=opBegin();err=r.finish(fr,false,true);opEnd(5,stamp);return err',1)
(w/'go/rewriter_engine.go.txt').write_text(pre+x+post)
k=p.parent/'src/ast/rewriter/rewriter_def.h';s=k.read_text();a=s.index('::process_app(app * t');b=s.index('case REWRITE_BUILTIN:',a);pre,x,post=s[:a],s[a:b],s[b:]
x=sub(x,'expr * arg = t->get_arg(fr.m_i);','auto a1=measured_ops.start();expr * arg = t->get_arg(fr.m_i);measured_ops.end(1,a1);')
x=sub(x,'if (!visit<ProofGen>(arg, fr.m_max_depth))','auto a2=measured_ops.start();auto result=visit<ProofGen>(arg,fr.m_max_depth);measured_ops.end(2,a2);if (!result)')
x=sub(x,'unsigned new_num_args   =','auto a3=measured_ops.start();unsigned new_num_args   =')
x=sub(x,'app * new_t;', 'measured_ops.end(3,a3);app * new_t;')
x=sub(x,'m_r = m().mk_app(f, new_num_args, new_args);','auto a4=measured_ops.start();m_r = m().mk_app(f, new_num_args, new_args);measured_ops.end(4,a4);')
key='result_stack().shrink(fr.m_spos);';i=x.rindex(key);x=x[:i]+'auto a5=measured_ops.start();'+x[i:];i=x.rindex('m_r = nullptr;')+len('m_r = nullptr;');x=x[:i]+'measured_ops.end(5,a5);'+x[i:]
x=sub(x,'if (!ProofGen && constant_fold(t, fr))','auto a6=measured_ops.start();bool folded=!ProofGen && constant_fold(t,fr);measured_ops.end(6,a6);if (folded)')
dst=w/'native/ast/rewriter/rewriter_def.h';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(pre+x+post)
jobs=[subprocess.Popen([sys.executable,w/'build.py',e]) for e in ('g3','z3')]
assert [j.wait() for j in jobs]==[0,0]
subprocess.run([sys.executable,w/'run.py'],check=True)
