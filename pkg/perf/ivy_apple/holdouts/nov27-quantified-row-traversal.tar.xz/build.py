from pathlib import Path
import subprocess,json,sys,re,shlex,shutil
p=Path.cwd();w=Path(__file__).resolve().parent;e=sys.argv[1];front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();native=p/'build/.sweep-census'
files=json.loads((p/'build/.push-gap/detail-g3.json').read_text())['Replace']
ov={str(Path(k).resolve()):v for k,v in files.items() if 'frontend/goivy/' in k and '/smt/quantifier.go' not in k}
def add(k,s):
 d=w/(e+'-'+k.name+('' if k.name=='quantifier.go' else '.txt'));d.write_text(s);ov[str(k)]=str(d)
if e=='g3':
 f=p/'ast/rewriter/rewriter_engine.go';s=f.read_text()
 for key,idx in [('func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32) (bool, error) {',0),('func (r *rewriterEngine) processApp() (err error) {',1),('st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)',2)]:
  assert s.count(key)==1,key
  s=s.replace(key,key+'\nif StudyRow {StudyEvents['+str(idx)+']++'+(';if st==brFailed{StudyEvents[3]++}' if idx==2 else '')+'}')
 add(f,s+'\nvar StudyRow bool\nvar StudyEvents [4]int\n')
 f=p/'smtcore/smt_asserted_propagate.go';s=f.read_text().replace('"io"','"io"\n"os"\n"fmt"\n"github.com/glycerine/g3/pkg/ast/rewriter"');k='one, result = k.rewritePendingAssertion(i)';s=s.replace(k,'''active:=os.Getenv("G3_PUSH_PHASES")=="1";quant:=false;if active {kind,e:=k.manager.GetKind(k.assertions[i].Formula);if e!=nil{panic(e)};quant=kind==ast.ASTQuantifier;rewriter.StudyRow=quant;rewriter.StudyEvents=[4]int{}}
 '''+k+'''
 if active{rewriter.StudyRow=false;fmt.Fprintln(os.Stderr,"QROW",i-k.assertedHead,quant,one,rewriter.StudyEvents[0],rewriter.StudyEvents[1],rewriter.StudyEvents[2],rewriter.StudyEvents[3])}''');add(f,s)
else:
 n=p/'build/.nov26-qi-frames/native';f=p.parent/'src/smt/asserted_formulas.cpp';s=f.read_text();i=s.index('unsigned asserted_formulas::propagate_values(unsigned i)');k='m_rewriter(n, new_n, new_pr);';a=s[:i]+s[i:].replace(k,'''if(std::getenv("G3_PUSH_PHASES")){
 bool q=is_quantifier(n);auto before=qi_observed; if(q){qi_observation_scope scope;'''+k+'''}else{'''+k+'''}std::fprintf(stderr,"QROW %u %s %s %llu %llu %llu %llu\\n",i-m_qhead,q?"true":"false",n!=new_n?"true":"false",qi_observed.visits-before.visits,qi_observed.app_steps-before.app_steps,qi_observed.reductions-before.reductions,qi_observed.reduction_misses-before.reduction_misses);
 }else{'''+k+'}',1)
 # Snapshot scalar fields; the observer destructor prints totals.
 a=a.replace('auto before=qi_observed;', 'auto v=qi_observed.visits,h=qi_observed.app_steps,u=qi_observed.reductions,y=qi_observed.reduction_misses;').replace('before.visits','v').replace('before.app_steps','h').replace('before.reductions','u').replace('before.reduction_misses','y')
 d=w/'asserted_formulas.cpp';d.write_text('#include <cstdlib>\n#include "observe.hpp"\nqi_observation qi_observed;\n'+a)
 build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l);inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1]);obj=w/'asserted_formulas.o';lib=w/'lib.a'
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),'-I'+str(n),*inc,'-o',obj,d],cwd=build,check=True)
 shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj,n/'th_rewriter.o',n/'rewriter.o'],check=True)
 f=front/'smt/quantifier.go';add(f,f.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
o=w/(e+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='native' else ''),'-overlay',o,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
