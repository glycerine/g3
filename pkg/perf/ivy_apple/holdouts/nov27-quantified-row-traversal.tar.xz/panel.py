from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,csv,sys
w=Path(__file__).resolve().parent;src=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
paths=(src/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((src/'ranking.csv').open())}
cases=[r['case'] for r in sorted((r for r in csv.DictReader(open('/tmp/g3-frame-child/frontier-phases.csv')) if r['stage']=='first'),key=lambda r:-int(r['difference']))[:10]]
def run(lane):
 with (w/f'{engine}{lane}.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case batch row index quant changed visits app_steps reductions misses'.split())
  for name in cases[lane::4]:
   ref=src/'compat'/str(paths.index(name)+1)/'1/native'
   r=subprocess.run(['taskset','-c',str(2*lane+(10 if engine=='g3' else 3)),w/engine,ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
   keep=[];rows=[];pending=[]
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'QROW '):pending.append(line.decode().split()[1:])
    elif line.startswith(b'QI-FRAMES'):pass
    elif line.startswith(b'STAGE-COUNT '):
     _,batch,_,phase,*_=line.decode().split()
     if phase=='first':rows.extend([name,batch,i,*v] for i,v in enumerate(pending));pending=[]
     else:assert not pending
    else:keep.append(line)
   assert not pending and rows and (r.returncode,r.stdout,b''.join(keep))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,engine,r.returncode,len(rows),b''.join(keep)[:200])
   o.writerows(rows);f.flush()
engine=sys.argv[1]
with ThreadPoolExecutor(4) as pool:list(pool.map(run,range(4)))
