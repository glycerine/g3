# Rewriter traversal in first-push value propagation

Baseline 450b4dd06 (8f6d97d5c has the same solver). Run builders from g3/pkg, with generated sources in external scratch. CPU was a Ryzen Threadripper 3960X. The release binaries use the checked-in November 27 blended profile. Input manifests and golden transcripts are the same as in nov27-first-push-pass-survey. Counters are diagnostic and single-solver only.

build.py g3 and build.py native build census binaries. panel.py ENGINE records per-input, per-batch and per-sweep rows. compare.py pairs coordinates and asserts reducer counts before joining the previous hybrid price archive. Three classification fields plus four counters agree on all selected rows. No structural hash was computed.

For price and scope, build each engine, run panel.py ENGINE and then sums.py. Each matched row uses its own instruction counter and 16 empty reads. The frontend stage observer pins the solver thread. Price operations 1–6 are child read, visit, argument view, rebuild, failed completion and constant-fold test. Scope operations 1 and 2 are begin and end. Native counts for constant-fold checks include unproductive positions. All complete runs verify both output streams and exit code.

trial.py builds the subtree-metadata experiment. tree/build.py and tree/bench.py build the direct ITE tree experiment and its depth benchmark. whole.csv files retain all release pairs. Historical absolute scratch paths identify the previous tools. support/ contains the fallback source for the frame meter, C++ observer and release driver; the prior first-push and frame-cost archives contain the enclosing frontend and transcript setup. External verifier binaries, ABC and the corpus are required for the full panel.

identity/build.py replaces the exploratory NodeHeader design in tree/ with AppIdentity. Run tree/build.py first to generate its input overlay. The exact production build is under final/ in the survey and direct native comparison. The Go test below also exercises the retained public implementation without any verifier or profiling tools.

    go test ./ast/rewriter -run '^TestTheoryITEValueTreeSharedBranch$' -bench '^BenchmarkTheoryITEValueTree$' -benchtime=3000x -count=7 -cpu=1
