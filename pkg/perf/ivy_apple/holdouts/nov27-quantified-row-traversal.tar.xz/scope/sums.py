from pathlib import Path
from collections import defaultdict
from statistics import median
import csv
w=Path(__file__).resolve().parent
with (w/'totals.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['operation','g3_calls','native_calls','g3_instructions','native_instructions'])
 data={}
 for e in ['g3','native']:
  m=defaultdict(list)
  for fin in w.glob(e+'[0-9].csv'):
   for r in csv.DictReader(fin.open()):m[int(r['op']),r['case']].append((int(r['calls']),float(r['instructions'])))
  assert len(m)==20 and all(len(v)==3 and v[0][0]==v[1][0]==v[2][0] for v in m.values())
  data[e]=m
 for k in range(1,3):out.writerow([k,*[round(sum(median(a[i] for a in v) for (op,n),v in data[e].items() if op==k)) for i in range(2) for e in ['g3','native']]])
