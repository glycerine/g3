from pathlib import Path
import sys,json,subprocess,re,shlex,shutil
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();e=sys.argv[1];old=Path('/tmp/g3-frame-child')
ov={k:v for k,v in json.loads((w.parent/'g3.json').read_text())['Replace'].items() if 'frontend/goivy' in k}
if e=='g3':
 s=(old/'meter.py').read_text().split('def sub(',1)[1].split("k=p.parent/")[0];exec('def sub('+s)
 dst=w/'go/rewriter_engine.go.txt';s=(p/'ast/rewriter/rewriter_engine.go').read_text();i=s.index('func (r *rewriterEngine) processQuantifier()');pre,s=s[:i],s[i:]
 for k,no in [('r.beginScope()',1),('c.endScope()',2)]:
  needle='if e = '+k+'; e != nil {';assert s.count(needle)==1
  s=s.replace(needle,'stamp:=opBegin();e='+k+';opEnd('+str(no)+',stamp);if e!=nil{')
 dst.write_text(pre+s)
 ov[str(p/'ast/rewriter/rewriter_engine.go')]=str(w/'go/rewriter_engine.go.txt')
 obs=old/'meter/go/zz_opstudy.go.txt';ov[str(p/'ast/rewriter/zz_opstudy.go')]=str(obs)
 f=p/'smtcore/smt_asserted_propagate.go';s=f.read_text().replace('"io"','"io"\n"os"\n"fmt"\n"github.com/glycerine/g3/pkg/ast/rewriter"');k='one, result = k.rewritePendingAssertion(i)'
 s=s.replace(k,'''active:=os.Getenv("G3_PUSH_PHASES")=="1";quant:=false;if active {kind,e:=k.manager.GetKind(k.assertions[i].Formula);if e!=nil{panic(e)};quant=kind==ast.ASTQuantifier;if quant{rewriter.BeginObservedRow()}}
 '''+k+'''
 if active {if quant{rewriter.EndObservedRow()};fmt.Fprintln(os.Stderr,"ROW",i-k.assertedHead,quant,one)}''')
 dst=w/'sweep.go.txt';dst.write_text(s);ov[str(f)]=str(dst)
else:
 b=p.parent/'build';q=w/'native-src';hdr=q/'ast/rewriter/rewriter_def.h';shutil.copyfile(old/'meter/native/ast/rewriter/rewriter_def.h',hdr);shutil.copyfile(old/'meter/native/ops.hpp',q/'ops.hpp')
 s=(p.parent/'src/ast/rewriter/rewriter_def.h').read_text();i=s.index('::process_quantifier(quantifier * q, frame & fr)');pre,s=s[:i],s[i:]
 for k,no in [('begin_scope();',1),('end_scope();',2)]:s=s.replace(k,'{window meter('+str(no)+');'+k+'}',1)
 hdr.write_text(pre+s)
 f=p.parent/'src/smt/asserted_formulas.cpp';s=f.read_text();i=s.index('unsigned asserted_formulas::propagate_values(unsigned i)');k='m_rewriter(n, new_n, new_pr);'
 s=s[:i]+s[i:].replace(k,'''if(std::getenv("G3_PUSH_PHASES")){bool quant=is_quantifier(n);if(quant)measured_ops.begin();'''+k+'''if(quant)measured_ops.finish();std::fprintf(stderr,"ROW %u %s %s\\n",i-m_qhead,quant?"true":"false",n!=new_n?"true":"false");}else{'''+k+'}',1)
 dst=q/'asserted_formulas.cpp';dst.write_text('counter measured_ops;\n'+s)
 flags=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l);objs=[]
 for grp,f in [('39',dst),('12',p.parent/'src/ast/rewriter/th_rewriter.cpp')]:
  inc=shlex.split(re.search('^includes_'+grp+' = (.*)$',(b/'Makefile').read_text(),re.M)[1]);o=q/(f.stem+'.o')
  subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),'-I'+str(q),*inc,'-include',q/'ops.hpp','-o',o,f],cwd=b,check=True);objs.append(o)
 lib=q/'lib.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,*objs],check=True);f=front/'smt/quantifier.go';dst=q/'quantifier.go';dst.write_text(f.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));ov[str(f)]=str(dst)
o=w/(e+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='native' else ''),'-overlay',o,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
