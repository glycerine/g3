from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import os,csv,subprocess,sys,re
w=Path(__file__).resolve().parent;e=sys.argv[1]
src=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');paths=(src/'compat.txt').read_text().splitlines()
codes={r['case']:int(r['exit']) for r in csv.DictReader((src/'ranking.csv').open())}
a,b=[{(r['case'],r['batch'],int(r['row'])):r for f in w.parent.glob(m+'[0-9].csv') for r in csv.DictReader(f.open())} for m in ['g3','native']]
pick={k for k in a.keys()&b.keys() if a[k]['index']==b[k]['index'] and a[k]['quant']==b[k]['quant']=='true' and a[k]['changed']==b[k]['changed']=='false'}
names=sorted(set(n for n,_,_ in pick))
def run(lane):
 with (w/f'{e}{lane}.csv').open('w') as f:
  out=csv.writer(f);out.writerow('case round rows op calls instructions'.split())
  for name in names[lane::4]:
   ref=src/'compat'/str(paths.index(name)+1)/'1/native'
   for rnd in range(3):
    r=subprocess.run(['taskset','-c',str(lane*2+(10 if e=='g3' else 3)),w/e,ex/name],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
    keep=[];pending=[];meter=None;used=0;calls=Counter();price=Counter()
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'OPS '):
      assert meter is None
      meter=[list(map(int,v.split())) for v in re.findall(rb'\[([^\]]+)\]',l)]
     elif l.startswith(b'ROW '):
      _,i,q,ch=l.decode().split();assert (q=='true')==(meter is not None)
      pending.append((i,q,ch,meter));meter=None
     elif l.startswith(b'STAGE-COUNT '):
      _,batch,_,phase,*_=l.decode().split()
      if phase=='first':
       for row,(idx,q,ch,m) in enumerate(pending):
        k=(name,batch,row)
        if k not in pick:continue
        assert idx==a[k]['index'] and q=='true' and ch=='false'
        used+=1
        c,v=m;assert c[0]==16
        for j in range(1,3):calls[j]+=c[j];price[j]+=v[j]-c[j]*v[0]/16
       pending=[]
      else:assert not pending
     else:keep.append(l)
    assert used==sum(k[0]==name for k in pick) and not pending and meter is None
    assert (r.returncode,r.stdout,b''.join(keep))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    for j in range(1,3):out.writerow([name,rnd,used,j,calls[j],price[j]])
    f.flush()
with ThreadPoolExecutor(4) as pool:list(pool.map(run,range(4)))
