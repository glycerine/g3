from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'ast/rewriter/th_rewriter.go';s=f.read_text();i=s.index('rangeSort, err :=',s.index('func (c *theoryRewriterConfiguration) pullITE('))
s=s[:i]+'''// Every successful pull requires an ITE at one of the two operand roots.
 possible,err:=c.owner.manager.HasQuantifiersOrITE(left)
 if err!=nil{return RewriteFailed,err}
 if !possible{possible,err=c.owner.manager.HasQuantifiersOrITE(right);if err!=nil||!possible{return RewriteFailed,err}}
 '''+s[i:];dst=w/'trial.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
s=Path('/tmp/g3-first-push-frontier/reftrial.py').read_text().split('script=Path',1)[1];exec('script=Path'+s)
