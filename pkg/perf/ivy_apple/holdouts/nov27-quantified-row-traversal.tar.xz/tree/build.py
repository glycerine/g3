from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();src=p/'ast/rewriter/th_rewriter.go';s=src.read_text();i=s.index('func (c *theoryRewriterConfiguration) iteView(');j=s.index('condition, err =',i)
s=s[:i]+'''func (c *theoryRewriterConfiguration) iteHeader(term ast.ASTHandle) (ast.ASTNodeHeader, bool, error) {
 head,err:=c.owner.manager.NodeHeader(term)
 return head,head.Kind==ast.ASTApp && head.Family==c.owner.manager.BasicFamilyID() && head.DeclKind==ast.ASTOpIte && head.NumArgs==3,err
}
'''+s[i:s.index('kind, err :=',i)]+'''_,matched,err=c.iteHeader(term)
 if err!=nil||!matched{return}
 '''+s[j:]
i=s.index('func (c *theoryRewriterConfiguration) iteValueTree(');j=s.index('func (c *theoryRewriterConfiguration) pullITE(',i)
s=s[:i]+'''func (c *theoryRewriterConfiguration) iteValueTree(term ast.ASTHandle) (bool,error) {
 if _,ite,err:=c.iteHeader(term);err!=nil||!ite{return false,err}
 stack:=[]ast.ASTHandle{term}
 for len(stack)!=0 {
  current:=stack[len(stack)-1];stack=stack[:len(stack)-1]
  for i:=uint32(1);i<=2;i++ {
   branch,err:=c.owner.manager.GetArg(current,i);if err!=nil{return false,err}
   h,ite,err:=c.iteHeader(branch);if err!=nil{return false,err}
   if ite&&h.RefCount==1{stack=append(stack,branch);continue}
   value,err:=c.owner.manager.IsValue(branch);if err!=nil||!value{return false,err}
  }
 }
 return true,nil
}

'''+s[j:];s=s.replace('_, _, _, rightITE, err := c.iteView(right)','_, rightITE, err := c.iteHeader(right)').replace('_, _, _, matched, err := c.iteView(term)','_, matched, err := c.iteHeader(term)')
dst=w/'th.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
script=Path('/tmp/g3-first-push-frontier/reftrial.py').read_text().split('script=Path',1)[1];exec('script=Path'+script)
