from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0].replace('w=Path(__file__).resolve().parent;','')
exec(s[:s.index('subprocess.run([*flags')]+s[s.index('modes={'):])
run(16,'head-native',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],11,['release','native'])
