from pathlib import Path
from collections import defaultdict,Counter
from statistics import median
import tarfile,csv,io
w=Path(__file__).resolve().parent
events=['visits','app_steps','reductions','misses'];rs={}
for e in ['g3','native']:
 rs[e]={(r['case'],int(r['batch']),int(r['row'])):r for f in w.glob(e+'[0-9].csv') for r in csv.DictReader(f.open())}
a,b=rs.values();shared=set(a)&set(b);first='examples/liveness/hybrid_reliable_broadcast_cisa.ivy'
groups=defaultdict(Counter);pick=set()
for k in set(a)|set(b):
 n=k[0];g=groups[n]
 if k not in shared:g['unpaired']+=1;continue
 x,y=a[k],b[k];g['paired']+=1
 if any(x[f]!=y[f] for f in ['index','quant','changed']):g['different_class']+=1;continue
 if x['quant']!='true' or x['changed']!='false':continue
 g['unchanged_q']+=1
 if any(x[f]!=y[f] for f in events):g['different_work']+=1
 for f in events:g['g3_'+f]+=int(x[f]);g['native_'+f]+=int(y[f])
 if n==first:pick.add(k[1:])
with (w/'matched.csv').open('w') as f:
 fields=['input','paired','unpaired','different_class','unchanged_q','different_work']+[e+'_'+v for v in events for e in rs];out=csv.writer(f);out.writerow(fields)
 for n,g in sorted(groups.items()):out.writerow([n,*[g[k] for k in fields[1:]]])
print('inputs',len(groups),sum((g for g in groups.values()),Counter()))
if len(pick)!=3532:raise ValueError(len(pick))
archive=Path('perf/ivy_apple/holdouts/nov27-rewriter-reference-cost.tar.xz')
with tarfile.open(archive) as t,(w/'hybrid-prices.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['operation','engine','calls','instructions'])
 for engine,file in [('g3','operations.csv'),('native','native-operations.csv')]:
  sums=defaultdict(Counter);cnt=defaultdict(Counter)
  for r in csv.DictReader(io.TextIOWrapper(t.extractfile(file))):
   co=(int(r['batch']),int(r['row']));op=int(r['op'])
   if co not in pick or op not in range(1,6):continue
   i=int(r['round']);calls=int(r['calls']);sums[op][i]+=int(r['raw'])-calls*int(r['blank_total'])/16;cnt[op][i]+=calls
   if op==2:assert calls==int(rs[engine][(first,)+co]['reductions'])
  for op in sorted(sums):out.writerow([op,engine,median(cnt[op].values()),round(median(sums[op].values()))])
