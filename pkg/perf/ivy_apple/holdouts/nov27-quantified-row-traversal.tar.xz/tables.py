from pathlib import Path
from collections import defaultdict
from statistics import median
import csv
w=Path(__file__).resolve().parent
for d in [w,w/'tree',w/'identity']:
 groups=defaultdict(dict)
 for r in csv.DictReader((d/'whole.csv').open()):
  assert r['status']=='match'
  groups[r['case'],r['round']][r['mode']]=r
 with (d/'release-summary.csv').open('w') as f:
  out=csv.writer(f);out.writerow(['case','pairs','instructions_percent','ms_percent'])
  for n in sorted(set(n for n,i in groups)):
   vs=[v for (k,i),v in groups.items() if n==k];assert len(vs)==7 and all(len(v)==2 for v in vs)
   out.writerow([n,len(vs),*[round(median(100*(float(v['release'][k])/float(v['base'][k])-1) for v in vs),2) for k in ['instructions','ms']]])
 if d!=w:
  vals=defaultdict(list)
  for r in csv.DictReader((d/'bench.csv').open()):vals[r['depth'],r['mode']].append(float(r['ns']))
  with (d/'bench-summary.csv').open('w') as f:
   out=csv.writer(f);out.writerow(['depth','base_ns','trial_ns'])
   for width in ['0','1','16','128']:
    assert all(len(vals[width,m])==7 for m in ['base','trial'])
    out.writerow([width,*[median(vals[width,m]) for m in ['base','trial']]])
