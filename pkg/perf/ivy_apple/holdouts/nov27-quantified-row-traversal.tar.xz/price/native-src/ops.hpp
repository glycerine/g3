#pragma once
#include <unistd.h>
#include <sys/syscall.h>
#include <linux/perf_event.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
struct counter { int fd=-1;bool busy=false;unsigned long long costs[20]{},counts[20]{};
 unsigned long long rd(){unsigned long long v[3]{};if(read(fd,v,24)!=24||v[1]!=v[2]||!v[1])abort();return v[0];}
 unsigned long long start(){if(fd<0||busy)return 0;busy=true;return rd();}
 void end(int k,unsigned long long t){if(!t)return;costs[k]+=rd()-t;counts[k]++;busy=false;}
 void begin(){perf_event_attr a{};a.size=sizeof(a);a.type=PERF_TYPE_HARDWARE;a.config=PERF_COUNT_HW_INSTRUCTIONS;a.read_format=3;a.exclude_kernel=a.exclude_hv=1;fd=syscall(SYS_perf_event_open,&a,0,-1,-1,0);if(fd<0)abort();memset(costs,0,sizeof(costs));memset(counts,0,sizeof(counts));for(int i=0;i<16;i++){auto t=start();end(0,t);}}
 void finish(){if(busy||close(fd))abort();fd=-1;fprintf(stderr,"OPS [");for(int i=0;i<20;i++)fprintf(stderr,"%s%llu",i?" ":"",counts[i]);fprintf(stderr,"] [");for(int i=0;i<20;i++)fprintf(stderr,"%s%llu",i?" ":"",costs[i]);fprintf(stderr,"]\n");}
};extern counter measured_ops;
struct window {int k;unsigned long long t;window(int k):k(k),t(measured_ops.start()){}~window(){measured_ops.end(k,t);}};
