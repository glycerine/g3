from pathlib import Path
import tarfile
w=Path(__file__).resolve().parent;dst=Path('perf/ivy_apple/holdouts/nov27-quantified-row-traversal.tar.xz')
with tarfile.open(dst,'w:xz',preset=5) as t:
 for p in sorted(w.rglob('*')):
  if p.is_symlink() or not p.is_file():continue
  if p.suffix in ['.py','.md','.csv','.cpp','.hpp','.h','.go'] or p.name.endswith('.go.txt'):
   t.add(p,arcname=str(p.relative_to(w)))
 for src,name in [('build/.nov26-qi-frames/native.py','native-builder.py'),('build/.nov26-qi-frames/native/observe.hpp','observe.hpp'),('build/.push-gap/detail-phase-z3bridge_solver_model.go','bridge.go.txt'),('build/.hybrid-obligations/phase-counters/phase_observer_trial.go','phase.go.txt'),('/tmp/g3-frame-child/meter.py','meter.py'),('/tmp/g3-frame-child/meter/go/zz_opstudy.go.txt','go/zz_opstudy.go.txt'),('/tmp/g3-or-install/final/release.py','release.py'),('/tmp/g3-first-push-frontier/reftrial.py','reftrial.py'),('/tmp/g3-live-literals/screen.py','screen.py'),('/tmp/g3-frame-child/frontier-phases.csv','frontier-phases.csv'),('/tmp/g3-reduction-rows/ranking.csv','ranking.csv'),('/tmp/g3-reduction-rows/compat.txt','compat.txt')]:
  t.add(src,arcname='support/'+name)
with tarfile.open(dst) as t:print(len(t.getnames()),'files;',dst.stat().st_size,'bytes')
