package rewriter

import (
	"strconv"
	"testing"
)

// A chain of unshared if-then-else terms with Boolean values at its leaves.
func BenchmarkTheoryITEValueTree(b *testing.B) {
	for _, depth := range []int{0, 1, 16, 128} {
		b.Run(strconv.Itoa(depth), func(b *testing.B) {
			m, context, globals, local := boolRewriterConfigFixture(b)
			r, err := NewTheoryRewriter(m, context, globals, local)
			astTestMust(b, err)
			b.Cleanup(func() { astTestMust(b, r.Close()) })
			sort, err := m.MkBoolSort()
			astTestMust(b, err)
			root, err := m.MkFalse()
			astTestMust(b, err)
			leaf, err := m.MkTrue()
			astTestMust(b, err)
			for i := 0; i < depth; i++ {
				cond, err := m.MkConst(astTestSymbol(b, m, "cond-"+strconv.Itoa(i)), sort)
				astTestMust(b, err)
				root, err = m.MkIte(cond, root, leaf)
				astTestMust(b, err)
			}
			astTestPin(b, m, root)
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				found, err := r.configuration.iteValueTree(root)
				if err != nil || found != (depth > 0) {
					b.Fatal(found, err)
				}
			}
		})
	}
}
