from pathlib import Path
import json,sys
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'ast/rewriter/th_rewriter.go';s=(w.parent/'tree/th.go.txt').read_text();i=s.index('func (c *theoryRewriterConfiguration) iteHeader');j=s.index('func (c *theoryRewriterConfiguration) iteView',i)
s=s[:i]+'''func (c *theoryRewriterConfiguration) isITE(term ast.ASTHandle) (bool,error) {
 m:=c.owner.manager
 app,family,kind,err:=m.AppIdentity(term)
 if err!=nil||!app||family!=m.BasicFamilyID()||kind!=ast.ASTOpIte{return false,err}
 arity,err:=m.GetNumArgs(term)
 return arity==3 && err==nil,err
}
'''+s[j:]
s=s.replace('_,matched,err=c.iteHeader(term)','matched,err=c.isITE(term)').replace('_,ite,err:=c.iteHeader(term)','ite,err:=c.isITE(term)').replace('h,ite,err:=c.iteHeader(branch)','ite,err:=c.isITE(branch)').replace('if ite&&h.RefCount==1{stack=append(stack,branch);continue}', 'if ite {refs,err:=c.owner.manager.GetRefCount(branch);if err!=nil{return false,err};if refs==1 {stack=append(stack,branch);continue}}').replace('_, rightITE, err := c.iteHeader(right)','rightITE, err := c.isITE(right)').replace('_, matched, err := c.iteHeader(term)','matched, err := c.isITE(term)')
dst=w/'th.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
if len(sys.argv)>1:
 script=Path('/tmp/g3-first-push-frontier/reftrial.py').read_text().split('script=Path',1)[1];exec('script=Path'+script)
