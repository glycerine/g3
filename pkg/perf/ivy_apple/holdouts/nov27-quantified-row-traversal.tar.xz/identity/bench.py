from pathlib import Path
import subprocess,json,re,csv
w=Path(__file__).resolve().parent;p=Path.cwd()
for m in ['base','trial']:
 ov=json.loads((w/'trial.json').read_text())['Replace'] if m=='trial' else {}
 ov[str(p/'ast/rewriter/theory_ite_value_tree_benchmark_test.go')]=str(w/'bench.go')
 o=w/(m+'-bench.json');o.write_text(json.dumps({'Replace':ov}));subprocess.run(['go','test','-overlay',o,'-c','-o',w/(m+'.test'),'./ast/rewriter'],check=True)
with (w/'bench.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['mode','round','depth','ns','B','allocs'])
 for i in range(7):
  for m in ['base','trial'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','20',w/(m+'.test'),'-test.run','^$','-test.bench','^BenchmarkTheoryITEValueTree$','-test.benchtime','3000x','-test.cpu','1'],capture_output=True,text=True)
   assert r.returncode==0,r.stdout
   rows=re.findall(r'BenchmarkTheoryITEValueTree/(\d+)\s+3000\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(rows)==4,r.stdout
   out.writerows([m,i,*row] for row in rows);f.flush()
