from study import *
import guarded_live as gl,macro_identity as mi,verification_frontier as vf
d=w/'frontend-clause-ownership';d.mkdir(exist_ok=True);a=ivy.resolve()/'actions_annotation.go';cla=ivy.resolve()/'module_clauses.go';ops=ivy.resolve()/'module_ops.go';tr=ivy.resolve()/'actions_transrel.go'
def edit(v):
 ed={};a1=a.read_text();cs=cla.read_text();s=ops.read_text();r=tr.read_text()
 if v=='clone':
  a1=once(a1,'import (','import (\n"maps"');i=a1.index('copied := make(map[NodeKey]Expr');j=a1.index('return &RenameAnnotation',i);ed[a]=a1[:i]+'copied:=maps.Clone(m);if copied==nil {copied=make(map[NodeKey]Expr)}\n'+a1[j:]
 if v in ('owned','all'):
  anchor='result.Annot = result.Annot.Rename(exprSubs)'
  s=once(s,anchor,'''if len(exprSubs)>0{
  switch an:=result.Annot.(type){
  case EmptyAnnotation,*ConjAnnotation,*ComposeAnnotation,*RenameAnnotation,*IteAnnotation:
   result.Annot=&RenameAnnotation{Arg:an,Map:exprSubs}
  case *EmptyAnnotation:
   result.Annot=&RenameAnnotation{Arg:*an,Map:exprSubs}
  default:result.Annot=result.Annot.Rename(exprSubs)
  }}else{'''+anchor+'}')
 if v in ('temp','all'):
  sig='func andClausesImpl(annotOp AnnotOp, args []*Clauses) *Clauses {'
  s=once(s,sig,sig+'return andClausesMaterialize(annotOp,args,true)}\nfunc andClausesMaterialize(annotOp AnnotOp,args []*Clauses,indexed bool)*Clauses{')
  s=once(s,'return joinedClauses(args, annot)','return joinedClausesIndexed(args,annot,indexed)')
  sig='func joinedClauses(groups []*Clauses, annot Annotation) *Clauses {'
  s=once(s,sig,sig+'return joinedClausesIndexed(groups,annot,true)}\nfunc joinedClausesIndexed(groups []*Clauses,annot Annotation,indexed bool)*Clauses{')
  x='return clausesFromConjuncts(flat, defs, annot)';s=once(s,x,'''if !indexed{if len(flat)==0{flat=nil};return &Clauses{Fmlas:flat,Defs:defs,Annot:annot}};'''+x)
  for args in ['clauses1, clauses2','clauses2, midAx','pre2, midAx']:
   r=r.replace('AndClausesTyped('+args+')','andClausesMaterialize(nil,[]*Clauses{'+args+'},xtracer.Enabled)')
  ed[tr]=r
 if v in ('owned-formulas','all'):
  # An arbitrary Apply callback can still observe all calls in original order.
  # The formula slice was allocated here; safely use its backing array once all callbacks finish.
  sig='return NewClauses(fmlas, defs, c.Annot)';i=cs.index('func (c *Clauses) Apply(');j=cs.index(sig,i)
  cs=cs[:j]+'''written:=0
  for pos,f:=range fmlas{
   root:=dropUniversals(f)
   if _,split:=root.(*LogicAnd);split{
    // Expansion can overwrite as-yet unread input. Use a distinct destination for this tail.
    flat:=make([]Expr,written,len(fmlas));copy(flat,fmlas[:written]);flat=appendConjunct(flat,root)
    flat=appendClauseFormulas(flat,fmlas[pos+1:]);return clausesFromConjuncts(flat,defs,c.Annot)
   }
   fmlas[written]=root;written++
  }
  return clausesFromConjuncts(fmlas[:written],defs,c.Annot)'''+cs[j+len(sig):];ed[cla]=cs
 if s!=ops.read_text():ed[ops]=s
 return ed
def make(arg):
 v,en=arg;od=d/(v+'-'+en);eds=edit(v)
 p=ivy.resolve()/'cmd/goivy_check/main.go';s=once(p.read_text(),'import (','import (\n"runtime";"encoding/json"');s=once(s,'os.Exit(goivy.MainWithConfig(args, cfg))','''status:=goivy.MainWithConfig(args,cfg);var ms runtime.MemStats;runtime.ReadMemStats(&ms);f,e:=os.Create("alloc.json");if e!=nil{panic(e)};json.NewEncoder(f).Encode([]uint64{ms.TotalAlloc,ms.Mallocs,uint64(ms.NumGC)});if e=f.Close();e!=nil{panic(e)};os.Exit(status)''');eds[p]=s
 return build(od/'checker',en,overlay(od/'overlay',eds))
def main():
 vs=['control','clone','owned','temp','owned-formulas','all'];es=['g3','native']
 with ThreadPoolExecutor(3)as e:bs=dict(zip([(v,en)for v in vs for en in es],e.map(make,[(v,en)for v in vs for en in es])))
 gl.d=d;js=[]
 for n,sp,rf,cpus,nr in [('testing','jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native',[5,17],3),('apple','doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native',[7,22],3),('ordinary','jea/hermes_rmw_o3.ivy',vf.reference('jea/hermes_rmw_o3.ivy'),[13,18],5)]:
  for en,c in zip(es,cpus):js.append(((c,n+'-'+en,sp,'',0,nr,rf),{v:bs[v,en]for v in vs}))
 for c,j in zip([0,3,6,8,9,11,12,14],(j for j in mi.jobs()if j[1] not in ('ordinary','dramc_nb2'))):
  js.append(((c,*j[1:5],3,j[-1]),{v:bs[v,'g3']for v in vs}))
 with ThreadPoolExecutor(len(js))as e:
  fs=[e.submit(gl.measure_job,j,bb)for j,bb in js]
  for f in fs:f.result()
if __name__=='__main__':main()
