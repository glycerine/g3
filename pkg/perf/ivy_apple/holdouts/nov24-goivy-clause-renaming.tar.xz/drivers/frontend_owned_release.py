from study import *
import write_ownership as ow,ground_release_controls as gc,verification_frontier as vf,guarded_live as gl,macro_identity as mi,binder_exits as binder
d=w/'frontend-owned-production';d.mkdir(exist_ok=True)
src=ivy.resolve()
def make(mode,en):
 od=d/(mode+'-'+en);od.mkdir(exist_ok=True)
 original={src/n:subprocess.check_output(['git','show','2d422d3aa:goivy/'+n],cwd=ivy,text=True)for n in ['module_ops.go','actions_annotation.go']}
 cand={p:(d/'candidate'/p.name).read_text()for p in [*original,ow.test_file]}
 ed=cand if mode=='after'else original|{ow.test_file:cand[ow.test_file]}
 o=overlay(od/'overlay',ed)
 if en=='bench':
  b=od/'frontend.test'
  with(w/'build.lock').open('a')as lk,(od/'focused.txt').open('w')as f:
   fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-tags=xtrace_off','-p','4','-pgo=off','-mod=readonly','-c','-o',b,'-overlay='+str(o),'.'],cwd=ivy,stdout=f,stderr=f)
   run([b,'-test.run','Rename|ClauseConjunction|ComposeUpdate|ActionAnnotation','-test.count=1'],cwd=ivy,stdout=f,stderr=f)
  return b
 if en=='trace':
  b=od/'goivy_check'
  with(w/'build.lock').open('a')as lk,(od/'build.log').open('w')as log:
   fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-mod=readonly','-overlay='+str(o),'-o',b,'./cmd/goivy_check'],cwd=ivy,stdout=log,stderr=log)
  if not(od/'abc').exists():(od/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
  return b
 return build(od,en,o)
def bench(bs):
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round variant width iterations ns bytes allocs'.split())
  for i in range(17):
   for v in (['before','after']if i%2==0 else['after','before']):
    r=run(['taskset','-c','38',bs[v,'bench'],'-test.run=^$','-test.bench=^BenchmarkRenameClauseAnnotation$','-test.benchtime=10000x','-test.benchmem','-test.cpu=1'],cwd=ivy,capture_output=True,text=True)
    rows=re.findall(r'BenchmarkRenameClauseAnnotation/(\d+)\s+(\d+)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(rows)==3,(v,r.stdout);z.writerows([[i+1,v,*r]for r in rows]);f.flush()
def main():
 tasks=[(m,en)for en in ('g3','native','bench','trace')for m in ('before','after')]
 with ThreadPoolExecutor(3)as e:bs=dict(zip(tasks,e.map(lambda z:make(*z),tasks)))
 gl.d=d;binder.root=d/'trace';binder.root.mkdir(exist_ok=True);js=[]
 for n,sp,ref,cs,nr in [('apple','doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native',[0,2],3),('testing','jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native',[3,4],3),('ordinary','jea/hermes_rmw_o3.ivy',vf.reference('jea/hermes_rmw_o3.ivy'),[6,8],5)]:
  for en,c in zip(('g3','native'),cs):js.append(((c,n+'-'+en,sp,'',0,nr,ref),{v:bs[v,en]for v in ('before','after')}))
 for c,j in zip([9,10,11,12,14,16,17,18,19],(j for j in mi.jobs()if j[1]!='ordinary')):js.append(((c,*j[1:5],3,j[-1]),{v:bs[v,'g3']for v in ('before','after')}))
 rfn=w/'quantifier-release/trace/after/goivy_check';test=bs['after','g3']
 with ThreadPoolExecutor(len(js)+6)as e:
  fs=[e.submit(gl.measure_job,j,bb)for j,bb in js]+[e.submit(bench,bs),e.submit(binder.trace,{'before-trace':bs['before','trace'],'after-trace':bs['after','trace']})]+[e.submit(run,[sys.executable,__file__,'corpus',en,bs['after',en]],stdout=subprocess.DEVNULL)for en in ('g3','native')]
  fs+=[e.submit(run,[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',test,'--previous',bs['before','g3'],'--native',bs['after','native'],'--rounds','7','--max-attempts','30','--wait-seconds','4400','--min-idle','.95','--cpu','15','--spec',examples/'jea/hermes_rmw_o3.ivy','--reference',vf.reference('jea/hermes_rmw_o3.ivy'),'--perf',perf,'--output',d/'ordinary-quiet'],stdout=subprocess.DEVNULL)]
  for f in fs:f.result()
if __name__=='__main__':
 if len(sys.argv)>1:
  gc.d=d/('verified-'+sys.argv[2]);gc.d.mkdir(exist_ok=True);gc.corpus(Path(sys.argv[3]))
 else:main()
