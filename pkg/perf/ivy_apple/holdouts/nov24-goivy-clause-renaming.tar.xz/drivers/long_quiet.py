from study import *
from contextlib import ExitStack
d=w/'frontend-owned-production'
def lane(pair):
 cpu,sp,ref,gate,label=pair
 # Finish the short control on this same core first.
 while True:
  p=gate/'ordinary-quiet/runs.csv'
  if p.exists():
   with p.open()as f:rows=list(csv.DictReader(f))
   if len({(r['round'],r['engine'])for r in rows if r['match']=='1' and min(float(r['sibling_idle_during']),float(r['cpu_fraction']))>=.95})==21:break
  time.sleep(15)
 args=[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',d/'after-g3/goivy_check','--previous',d/'before-g3/goivy_check','--native',d/'after-native/goivy_check','--cpu',str(cpu),'--rounds','3','--max-attempts','8','--wait-seconds','3300','--spec',examples/sp,'--reference',ref,'--min-idle','.95','--perf',perf,'--output',d/('quiet-'+label)]
 with(d/('quiet-'+label+'.log')).open('w')as f:run(args,stdout=f,stderr=f)
if __name__=='__main__':
 js=[(15,'jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native',d,'testing'),(20,'doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native',w/'symbol-codec-release','apple')]
 with ThreadPoolExecutor(2)as e:list(e.map(lane,js))
