"""Move temporary equality ownership into the one reduction which uses it."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/bool_rewriter_eq.go'
s=(w/'negation.go').read_text()
a=s.index('func (rw *boolRewriter) mkNotCore')
b=s.index('func (rw *boolRewriter) mkEq(',a)
old=s[a:b]
body=old[old.index('a, e := m.GetArg(arg, 0)'):old.index('return brDone, rw.mkEq(neg, b, out)')+len('return brDone, rw.mkEq(neg, b, out)')]
s=s[:a]+'''func (rw *boolRewriter) mkNotCore(arg ast.ASTHandle, out ast.ASTRef) (brStatus, error) {
    m := rw.manager
    app, family, op, err := m.AppIdentity(arg)
    if err != nil || !app || family != 0 { return brFailed, err }
    switch op {
    case ast.ASTOpNot:
        inner, err := m.GetArg(arg, 0)
        if err != nil { return brFailed, err }
        return brDone, m.SetRef(out, inner)
    case ast.ASTOpTrue, ast.ASTOpFalse:
        var opposite ast.ASTHandle
        switch {
        case m.IsTrue(arg):
            opposite, err = m.MkFalse()
        case m.IsFalse(arg):
            opposite, err = m.MkTrue()
        default:
            return brFailed, nil
        }
        if err != nil { return brFailed, err }
        return brDone, m.SetRef(out, opposite)
    case ast.ASTOpEq, ast.ASTOpIff:
        return rw.negateEquality(arg, out)
    }
    return brFailed, nil
}

func (rw *boolRewriter) negateEquality(arg ast.ASTHandle, out ast.ASTRef) (status brStatus, err error) {
    m := rw.manager
    ''' + body+'\n}\n\n'+s[b:]
dst=w/'finish.go'
dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/'finish.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',w/'finish','./cmd/g3'],check=True)
