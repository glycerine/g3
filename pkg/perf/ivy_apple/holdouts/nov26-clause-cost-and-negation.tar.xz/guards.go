// Find calls feeding only the right-hand operand of a subsequent Boolean test.
// Results require inspection for side effects, errors and additional uses.
package main

import (
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
)

func main() {
	files := token.NewFileSet()
	for _, root := range os.Args[1:] {
		err := filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if d.IsDir() || !strings.HasSuffix(path, ".go") || strings.HasSuffix(path, "_test.go") {
				return nil
			}
			f, err := parser.ParseFile(files, path, nil, 0)
			if err != nil {
				return err
			}
			for _, decl := range f.Decls {
				fn, ok := decl.(*ast.FuncDecl)
				if !ok || fn.Body == nil {
					continue
				}
				ast.Inspect(fn.Body, func(node ast.Node) bool {
					block, ok := node.(*ast.BlockStmt)
					if !ok {
						return true
					}
					for i, stmt := range block.List {
						cond, ok := stmt.(*ast.IfStmt)
						if !ok {
							continue
						}
						test, ok := cond.Cond.(*ast.BinaryExpr)
						if !ok || (test.Op != token.LAND && test.Op != token.LOR) {
							continue
						}
						rhs := test.Y
						if unary, ok := rhs.(*ast.UnaryExpr); ok && unary.Op == token.NOT {
							rhs = unary.X
						}
						variable, ok := rhs.(*ast.Ident)
						if !ok || variable.Obj == nil {
							continue
						}
						assign, ok := variable.Obj.Decl.(*ast.AssignStmt)
						if !ok || len(assign.Rhs) != 1 {
							continue
						}
						id, ok := assign.Lhs[0].(*ast.Ident)
						if !ok || id.Name != variable.Name {
							continue
						}
						dependsOnCall := false
						ast.Inspect(test.X, func(n ast.Node) bool {
							ident, ok := n.(*ast.Ident)
							if ok {
								for _, lhs := range assign.Lhs {
									if other, ok := lhs.(*ast.Ident); ok && ident.Obj != nil && other.Obj == ident.Obj {
										dependsOnCall = true
									}
								}
							}
							return !dependsOnCall
						})
						if dependsOnCall {
							continue
						}
						call, ok := assign.Rhs[0].(*ast.CallExpr)
						if !ok {
							continue
						}
						sel, ok := call.Fun.(*ast.SelectorExpr)
						if !ok {
							continue
						}
						for j := i - 1; j >= 0 && i-j <= 5; j-- {
							if block.List[j] == assign {
								fmt.Printf("%s,%s,%s\n", files.Position(cond.If), fn.Name.Name, sel.Sel.Name)
								break
							}
						}
					}
					return true
				})
			}
			return nil
		})
		if err != nil {
			panic(err)
		}
	}
}
