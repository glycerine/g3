"""Remove only observer events and compare both streams to complete verifier references."""
from pathlib import Path
import csv,json,os,subprocess,sys
from collections import Counter
w=Path(__file__).resolve().parent
gold=Path(sys.argv[1]); examples=Path(sys.argv[2])
out=csv.writer(sys.stdout);out.writerow(('case','predicate','visited','avoidable'))
cases=json.loads((gold/'cases.json').read_text())
for case,(path,isolate,code) in cases.items():
    cmd=[w/'mac-goivy']+(['isolate='+isolate] if isolate else [])+[examples/path]
    r=subprocess.run(cmd,cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'))
    counts=Counter(); avoid=Counter(); stderr=[]
    for line in r.stderr.splitlines(keepends=True):
        if not line.startswith(b'MACRO '):stderr.append(line);continue
        _,kind,forbidden,occurs=line.decode().split()
        counts[kind]+=1
        if forbidden=='true' or occurs=='true':avoid[kind]+=1
    ref=gold/'reference'/case
    assert (r.returncode,r.stdout,b''.join(stderr))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),case
    for k in ('quasi','poly','pseudo'):out.writerow((case,k,counts[k],avoid[k]))
