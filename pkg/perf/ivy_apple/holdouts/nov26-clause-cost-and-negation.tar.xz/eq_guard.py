"""Restore the native short-circuit order for equality of an ITE and a value."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/bool_rewriter_eq.go'
s=(w/'finish.go').read_text()
a=s.index('leftITE, e := rw.isOperator(lhs, ast.ASTOpIte)',s.index('func (rw *boolRewriter) mkEqCore'))
b=s.index('status := brFailed',a)
s=s[:a]+'''leftITEValue, e := rw.isITEWithValue(lhs, rhs)
    if e!=nil{return brFailed,e}
    '''+s[b:]
s=s.replace('if leftITE && rightValue {','if leftITEValue {')
a=s.index('rightITE, e2 := rw.isOperator(rhs, ast.ASTOpIte)',a)
b=s.index('if rightITE && leftValue {',a)
s=s[:a]+'''rightITEValue,e2:=rw.isITEWithValue(rhs,lhs)
        if e2!=nil{return brFailed,e2}
        '''+s[b:].replace('if rightITE && leftValue {','if rightITEValue {',1)
idx=s.index('func (rw *boolRewriter) mkEqCore')
s=s[:idx]+'''func (rw *boolRewriter) isITEWithValue(term, value ast.ASTHandle) (bool, error) {
    ite, err := rw.isOperator(term, ast.ASTOpIte)
    if err != nil || !ite { return false, err }
    return rw.manager.IsValue(value)
}

'''+s[idx:]
dst=w/'guard.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/'guard.json';overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',w/'guard','./cmd/g3'],check=True)
