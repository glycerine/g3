"""Bucket self samples across whole standalone processes; report dynamic defer callers."""
import csv,re,subprocess,sys
from pathlib import Path
from collections import Counter
out=csv.writer(sys.stdout);out.writerow(('query','round','leaf','defer_caller','samples'))
for f in sorted(Path(sys.argv[1]).glob('*-g3.data')):
    query,i,_=f.stem.rsplit('-',2)
    c=Counter()
    for block in subprocess.check_output([sys.argv[2],'script','-i',f],text=True).split('\n\n'):
        frames=re.findall(r'^\s+[\da-fA-F]+ (.*?)\+0x',block,re.M)
        if not frames:continue
        caller=''
        if frames[0].startswith(('runtime.defer','runtime.(*_panic)')):
            caller=next((s for s in frames if 'glycerine/g3/pkg/' in s),'unknown')
        c[frames[0],caller]+=1
    for k,n in c.items():out.writerow((query,i,*k,n))
