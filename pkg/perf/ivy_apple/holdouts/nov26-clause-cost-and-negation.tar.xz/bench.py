from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for name,flags in [('base',[]),('finish',['-overlay',w/'finish.json'])]:
    subprocess.run(['go','test','-pgo=off','-mod=readonly',*flags,'-c','-o',w/(name+'.test'),'./ast/rewriter'],check=True)
for i in range(7):
    for name in (['base','finish'] if i%2==0 else ['finish','base']):
        r=subprocess.check_output(['taskset','-c','14',w/(name+'.test'),'-test.run=^$','-test.bench=^BenchmarkBoolNegationOperand$','-test.benchtime=500000x'],text=True)
        for row in r.splitlines():
            if row.startswith('Benchmark'):print(name,i+1,row,flush=True)
