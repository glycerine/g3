"""Count potentially avoidable occurrence walks on ordinary and pseudo macro candidates."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
mapping={}
for name,marker,msg in [
 ('macro_candidates.go','rest, e := u.restContains(declaration, atom)','println("MACRO", "quasi", u.forbiddenDecl(declaration), occurs)'),
 ('macro_numeric.go','contained, e := u.polynomialContains(lhs, declaration, argument)','println("MACRO", "poly", u.forbiddenDecl(declaration), false)'),
 ('macro_numeric.go','occurs, e := u.manager.OccursDecl(declaration, pair[1])','println("MACRO", "pseudo", u.forbiddenDecl(declaration), false)')]:
    src=Path.cwd()/'ast/macros'/name
    dest=w/name
    s=(dest if str(src) in mapping else src).read_text()
    assert s.count(marker)>0
    dest.write_text(s.replace(marker,msg+'\n'+marker,1))
    mapping[str(src)]=str(dest)
(w/'mac.json').write_text(json.dumps({'Replace':mapping}))
