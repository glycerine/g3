"""Classify stacks inside quantified clause construction in existing perf recordings."""
from pathlib import Path
from collections import Counter
import re, csv, sys, subprocess
writer = csv.writer(sys.stdout)
writer.writerow(('query','engine','round','stage','leaf','samples'))
for f in sorted(Path(sys.argv[1]).glob('ticket-*.data')):
    query,i,engine=f.stem.rsplit('-',2)
    go=engine=='g3'
    counts=Counter()
    for block in subprocess.check_output([sys.argv[2],'script','-i',f],text=True).split('\n\n'):
        if ('(*SMTQuantifierManager).instantiate' if go else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)') not in block: continue
        if ('.assertExpression' if go else '::internalize_assertion(') not in block:continue
        frames=re.findall(r'^\s+[\da-fA-F]+ (.*?)\+0x',block,re.M)
        needle='.addClauseKindWithJustificationAndDeleteHandler' if go else '::mk_clause('
        idx=next((j for j,s in enumerate(frames) if needle in s),None)
        if idx is None:continue
        frames=frames[:idx+1]
        choices=[('watch', ('.InsertClause','::add_watch_literal(','::insert_clause(')),('construct',('.newSMTClause','smtcore.newSMTClause','smtcore.smtNewClauseStorage','smt::clause::mk(')),('assign',('.AssignLiteral','.assignLiteral','::assign(')),('sort',('slices.Sort','slices.pdqsort','std::__introsort','std::__insertion_sort'))]
        stage=next((k for k,needles in choices if any(n in s for s in frames for n in needles)),'rest')
        counts[stage,frames[0].split('/pkg/')[-1]]+=1
    for key,n in counts.items():writer.writerow((query,engine,i,*key,n))
