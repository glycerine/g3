"""Build overlay using sequential non-recycled short clause slots, or direct watch reads."""
from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent
mode=sys.argv[1]
if mode=='defer':
    src=Path.cwd()/'smtcore/smt_internalizer.go'
    s=src.read_text()
    marker='// mk_clause: j = unit_resolution_justification'
    assert s.count(marker)==1
    s=s.replace(marker, """return s.storeSimplifiedClause(kept, removedFalse, root, kind, proof, justification, deleteHandler)
}

func (s *SMTInternalizerState) storeSimplifiedClause(kept, removedFalse []SMTLiteral, root bool, kind SMTClauseKind, proof ast.ASTHandle, justification SMTJustification, deleteHandler SMTClauseDeleteHandler) error {
    """ + marker)
elif mode=='watch':
    src=Path.cwd()/'smtcore/smt_boolean_propagation.go'
    s=src.read_text()
    i=s.index('literal, err := clause.Literal(index)',s.index('func (s *SMTInternalizerState) makeClauseWithJustificationAndDeleteHandler'))
    j=s.index('if err = s.watches',i)
    s=s[:i]+'literal := literals[index]\n\t\t'+s[j:]
else:
    n=int(mode)
    assert 0<n<=128
    src=Path.cwd()/'smtcore/smt_clause.go'
    s=src.read_text()
    s=s.replace('struct{ pages [4]*smtClauseAtomPage }','struct{ pages [4]*smtClauseAtomPage; fresh []smtClauseStorage4 }')
    k='clause := smtNewClauseStorage(literals, kind != SMTClauseAux || saveAtoms, needsDirectory)'
    assert s.count(k)==1
    s=s.replace(k,'''var clause *SMTClause
    if pool!=nil && !needsDirectory && kind==SMTClauseAux && !saveAtoms && len(literals)<=4 {
        if len(pool.fresh)==0 { pool.fresh=make([]smtClauseStorage4, COUNT) }
        slot:=&pool.fresh[0]
        pool.fresh=pool.fresh[1:]
        if len(pool.fresh)==0 {pool.fresh=nil}
        clause=&slot.clause
        clause.literals=slot.lits[:len(literals):len(literals)]
        copy(clause.literals,literals)
    } else {
        '''+k.replace('clause :=','clause =')+'\n}').replace('COUNT',str(n))
dest=w/(mode+'.go')
dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/(mode+'.json')
overlay.write_text(json.dumps({'Replace':{str(src):str(dest)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',w/mode,'./cmd/g3'],check=True)
