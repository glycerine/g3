"""Classify negation operands once before fetching arguments or constants."""
import json, subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/bool_rewriter_eq.go'
s=src.read_text()
a=s.index('negative, inner, e :=',s.index('func (rw *boolRewriter) mkNotCore'))
b=s.index('a, e := m.GetArg(arg, 0)',a)
s=s[:a]+'''app, family, op, e := m.AppIdentity(arg)
    if e!=nil || !app || family!=0 { return brFailed,e }
    switch op {
    case ast.ASTOpNot:
        negative,inner,e:=m.IsNot(arg)
        if e!=nil || !negative {return brFailed,e}
        return brDone,m.SetRef(out,inner)
    case ast.ASTOpTrue,ast.ASTOpFalse:
        truth,e:=m.MkTrue()
        if e!=nil{return brFailed,e}
        falsity,e:=m.MkFalse()
        if e!=nil{return brFailed,e}
        if arg==truth{return brDone,m.SetRef(out,falsity)}
        if arg==falsity{return brDone,m.SetRef(out,truth)}
    case ast.ASTOpEq, ast.ASTOpIff:
        '''+s[b:]
dst=w/'negation.go'
dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/'negation.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',w/'negation','./cmd/g3'],check=True)
