from collections import Counter
import csv,sys
from statistics import median
for filename in sys.argv[1:]:
    d=Counter(); modes=set(); queries=set()
    for r in csv.DictReader(open(filename)):
        modes.add(r['engine']);queries.add(r['query'])
        for p in ('total',r['phase']):
            d[r['query'],r['engine'],int(r['round']),p]+=int(r['instructions'])
    for q in sorted(queries):
        for m in sorted(modes-{'base'}):
            ns=[i for i in range(1,100) if d[q,m,i,'exit'] and d[q,'base',i,'exit']]
            if ns:print(q,m,len(ns),*[round(median([100*(d[q,m,i,p]/d[q,'base',i,p]-1) for i in ns]),3) for p in ('total','check')])
