from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=(p/'build/.boolean-enode-cost/frontend/goivy/smt/g3.go').resolve()
s=(w.parent/'split/candidate.go.txt').read_text();k='if all {\n m,e:=';assert s.count(k)==1;s=s.replace(k,'if studyDirectional && all {\n m,e:=')
s+='\nvar studyDirectional=os.Getenv("STUDY_SPLIT")=="sides"\n'
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'mode.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace('modes[m],ex/name',"(w/'release'),ex/name").replace('env=dict(os.environ,GOMAXPROCS','env=dict(os.environ,STUDY_SPLIT=m,GOMAXPROCS')
exec(compile(orig,__file__,'exec'))
run(14,'causal',['test/arm_rules3.ivy','examples/ivy/toy_consensus.ivy','test/ordered_set.ivy','examples/ivy/card2.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],13,['off','sides'])
