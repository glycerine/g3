from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
apple=(p/'build/.boolean-enode-cost/apple-source/goivy/smt/g3.go').resolve()
base=(p/'build/.boolean-enode-cost/frontend/goivy/smt/g3.go').resolve()
assert apple.read_bytes()==base.read_bytes()
ov=w/'apple.json';ov.write_text(json.dumps({'Replace':{str(apple):str(w/'candidate.go.txt')}}))
s=Path('/tmp/g3-card-install/volume_release_long.py').read_text().replace("'-o',w/'volume-release-apple'","'-overlay',ov,'-o',w/'apple'").replace('range(3)','range(2)').replace("('base','release')","('off','sides')").replace("if mode=='base':cap","if mode=='off':cap").replace("ACTION_SCOPE=mode,CARD_MODE=mode","STUDY_SPLIT=mode")
a=s.index('    exe=((');b=s.index('\n',a);s=s[:a]+"    exe=w/('apple' if apple else 'release')"+s[b:]
exec(s)
