from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'smtcore/smt_internalizer.go';s=f.read_text();k='for _, argument := range arguments {\n\t\t\tif err = add(literal, argument.Negated());'
assert s.count(k)==1
s=s.replace(k,'''proofs, err := s.manager.ProofsEnabled()
        if err != nil {return err}
        for _, argument := range arguments {
            if !proofs {
                other := argument.Negated()
                if s.assignment[literal.Index()] == lbool.True || s.assignment[other.Index()] == lbool.True {continue}
                pair := [2]SMTLiteral{literal,other}
                if err = s.addClause(pair[:],false,ast.ASTHandle{});err!=nil{return err};continue
            }
            if err = add(literal, argument.Negated());''')
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','release'])
