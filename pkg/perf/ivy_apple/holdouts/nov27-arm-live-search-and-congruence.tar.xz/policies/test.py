from pathlib import Path
import json,sys
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();f=frontend/'smt/g3_solver.go';s=f.read_text().replace('"strconv"','"strconv"\n"os"')
k='ctx.solvers = append(ctx.solvers, s)';assert s.count(k)==1;s=s.replace(k,k+'\n if v:=os.Getenv("STUDY_REL");v!=""{s.SetParam("smt.relevancy",v)}')
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'policy.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')").replace("modes[m],ex/name","(w/'release' if m.startswith('rel') else modes[m]),ex/name").replace("env=dict(os.environ,GOMAXPROCS","env=dict(os.environ,STUDY_REL=(m[3:] if m.startswith('rel') else ''),GOMAXPROCS").replace("timeout=120","timeout=20")
exec(compile(orig,__file__,'exec'))
run(14,'screen',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy','examples/liveness/ticket.ivy'],3,['base','rel0','rel1'])
