from pathlib import Path
import csv,subprocess,re
w=Path(__file__).resolve().parent
for mode in ['base','erase']:
 subprocess.run(['go','test','-c',*(['-overlay',w/'trial.json'] if mode=='erase' else []),'-o',w/(mode+'.test'),'./smtcore'],check=True)
 subprocess.run([w/(mode+'.test'),'-test.run','Congruence|SMTMergeAndUndo'],check=True)
with (w/'bench.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','mode','case','ns','bytes','allocs'])
 for i in range(9):
  for m in ['base','erase'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','16',w/(m+'.test'),'-test.run','^$','-test.bench','^BenchmarkSMTCongruenceProbes$','-test.benchtime','100000x','-test.cpu','1'],capture_output=True,text=True,check=True)
   vals=re.findall(r'BenchmarkSMTCongruenceProbes/(\w+)\s+100000\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(vals)==9,r.stdout
   out.writerows([i,m,*v] for v in vals);f.flush()
