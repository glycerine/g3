from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();rep={}
def save(name,s):
 f=p/'smtcore'/name;d=w/(name+'.txt');d.write_text(s);rep[str(f)]=str(d)
f=p/'smtcore/smt_cg_small_table.go';s=f.read_text();i=s.index('\tt.count--',s.index('func (t *smtCgSmallTable) del('))
s=s[:i]+''' t.deleteSlot(i)
}
func (t *smtCgSmallTable) deleteSlot(i int) {
 mask:=len(t.entries)-1
'''+s[i:]
s+='''
// eraseCongruent checks the stored node at the probed slot before deleting it.
func (t *smtCgSmallTable) eraseCongruent(key [2]*SMTEnode, query *SMTEnode) (bool,error) {
 if t.count==0 { return false,nil }
 mask:=len(t.entries)-1
 for i:=smtCgSmallSlot(key[0],key[1],t.shift);;i=(i+1)&mask {
  e:=&t.entries[i]
  if e.node==nil{return false,nil}
  if e.k0!=key[0] || e.k1!=key[1]{continue}
  equal,_,err:=SMTEnodesCongruent(e.node,query)
  if err!=nil || !equal{return false,err}
  if current:=smtCongruenceSmallKey(e.node);current!=key{
   // Preserve removal by the representative's current signature.
   t.del(current[0],current[1])
  }else{t.deleteSlot(i)}
  return true,nil
 }
}
''';save(f.name,s)
f=p/'smtcore/smt_cg_table.go';s=f.read_text();a=s.index('candidate, _, err := t.Find(node)',s.index('func (t *SMTCongruenceTable) Erase('));b=s.index('\n}',a)
s=s[:a]+'''if err:=t.validateNode(node);err!=nil{return false,err}
 bucket,err:=t.ensureTable(node);if err!=nil{return false,err}
 if len(node.arguments)<=2 {
 key:=smtCongruenceSmallKey(node);ok,err:=bucket.small.eraseCongruent(key,node)
 if ok||err!=nil||!node.commutative||bucket.flatAssociative||len(node.arguments)!=2||key[0]==key[1]{return ok,err}
 return bucket.small.eraseCongruent([2]*SMTEnode{key[1],key[0]},node)
 }
 candidate,_,err:=bucket.find(node);if err!=nil||candidate==nil{return false,err};bucket.remove(candidate);return true,nil'''+s[b:];save(f.name,s)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':rep}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(12,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','release'])
