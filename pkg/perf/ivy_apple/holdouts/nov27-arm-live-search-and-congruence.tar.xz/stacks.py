from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-ticket-stages/profile.py').read_text().replace('/tmp/g3-reduction-rows/release','/tmp/g3-card-install/volume-release').replace('for n in [3,6,8,12]:',"for n in [names.index('test/arm_rules3.ivy')+1]:").replace('1000003+100*i','650003+100*i')
exec(s)
