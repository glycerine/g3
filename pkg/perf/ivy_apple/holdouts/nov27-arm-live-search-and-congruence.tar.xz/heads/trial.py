from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
f=frontend/'smt/g3.go';s=f.read_text();k='return ctx.newExpr(handle(ctx.c.ConstantQuantifier(api.ConstantQuantifierSpec{Forall: all, Bound: exprHandles(bound), Body: body.c, Weight: 1})))';assert s.count(k)==1
s=s.replace(k,'''spec:=api.ConstantQuantifierSpec{Forall: all, Bound: exprHandles(bound), Body:body.c,Weight:1}
 if all {
 m,e:=ctx.c.Manager();fail(e);h,_,e:=m.ExpressionHeader(body.c);fail(e)
 if h.Kind==ast.ASTApp && h.Family==m.BasicFamilyID() && (h.DeclKind==ast.ASTOpEq||h.DeclKind==ast.ASTOpIff) && len(bound)<=64 {
 for i:=uint32(0);i<2;i++{
 side,e:=m.GetArg(body.c,i);fail(e);a,bo,e:=m.ExpressionHeader(side);fail(e);if !bo || a.Kind!=ast.ASTApp||a.Family!=ast.NullFamilyID || int(a.NumArgs)!=len(bound){continue}
 var seen uint64
 for j:=uint32(0);j<a.NumArgs;j++{arg,e:=m.GetArg(side,j);fail(e);for n,v:=range spec.Bound {if arg==v{seen|=uint64(1)<<uint(n);break}}}
 if seen==(uint64(1)<<uint(len(bound)))-1 {pat,e:=ctx.c.Pattern(side);fail(e);spec.Patterns=[]ast.ASTHandle{pat};break}
 }
 }
 }
 return ctx.newExpr(handle(ctx.c.ConstantQuantifier(spec)))''')
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'heads.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','release'])
