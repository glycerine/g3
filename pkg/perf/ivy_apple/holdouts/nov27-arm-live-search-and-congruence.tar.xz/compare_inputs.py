import csv,re,subprocess,os,tempfile
from pathlib import Path
w=Path(__file__).resolve().parent;orig=Path('/tmp/g3-arm-equality/fixtures')
with (w/'input-cost.csv').open('w') as f,tempfile.TemporaryDirectory() as tmp:
 out=csv.writer(f);out.writerow(['fixture','round','engine','input','instructions','decisions','conflicts','instances','rlimit'])
 for fixture in sorted(orig.glob('*.smt2')):
  for i in range(5):
   for e,exe in [('g3',Path('/tmp/g3-arm-equality/base')),('z3',Path.cwd().parent/'build/z3')]:
    for mode,d in [('same',orig),('ordering',w/'ordering'),('definitions',w/'definitions')][::1 if i%2==0 else -1]:
     stat=Path(tmp)/'stat'
     r=subprocess.run(['taskset','-c','12','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,'-in','-smt2'],input=(d/fixture.name).read_bytes(),capture_output=True,timeout=60,check=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
     assert r.stdout.startswith(b'unsat\n')
     v=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()))
     with stat.open() as sf:n=next(row[0] for row in csv.reader(sf) if len(row)>4 and row[2]=='instructions:u' and float(row[4])==100)
     out.writerow([fixture.stem,i,e,mode,n,*[v[k] for k in ['decisions','conflicts','quant-instantiations','rlimit-count']]]);f.flush()
