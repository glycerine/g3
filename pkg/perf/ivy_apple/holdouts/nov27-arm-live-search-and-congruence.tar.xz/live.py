from pathlib import Path
import csv,json,os,subprocess,collections
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();h=Path('/tmp/g3-ticket-stages')
ov=json.loads((h/'translated.json').read_text())
def add(f,k,z):
 s=f.read_text();assert s.count(k)==1;(dst:=w/('live-'+f.name+'.txt')).write_text(s.replace(k,z));ov['Replace'][str(f)]=str(dst)
f=p/'smtcore/smt_qi_instance.go';k='if err = internalizer.internalizeInstance(result, locals.arguments);'
add(f,k,'studyOuter=true;studyFresh=0;studyOr=0;defer func(){studyOuter=false;println("QI-COUNT",studyFresh,studyOr)}();'+k)
f=p/'smtcore/smt_internalizer.go';k='if err = s.Internalize(argument, isGate); err != nil {'
add(f,k,'''parent:=false
 if studyOuter && studyParent.IsNull() && basic && op==ast.ASTOpEq && s.context.enodes.get(argument)==nil {
 _,bound:=s.boolVar.lookup(argument);bo,e:=s.manager.HasBoolSort(argument);if e!=nil{panic(e)};if bo&&!bound{studyParent=argument;parent=true;studyFresh++}
 }
 if expression==studyParent{h,bo,e:=s.manager.ExpressionHeader(argument);if e!=nil{panic(e)};_,bound:=s.boolVar.lookup(argument);if bo&&h.Family==s.manager.BasicFamilyID()&&h.DeclKind==ast.ASTOpOr&&h.NumArgs==5&&!bound&&s.context.enodes.get(argument)==nil{studyOr++}}
 err=s.Internalize(argument,isGate);if parent{studyParent=ast.ASTHandle{}}
 if err!=nil {''')
dst=w/'live-globals.go.txt';dst.write_text('package smtcore\nimport "github.com/glycerine/g3/pkg/ast"\nvar studyOuter bool\nvar studyFresh,studyOr int\nvar studyParent ast.ASTHandle\n');ov['Replace'][str(p/'smtcore/zz_live_study.go')]=str(dst)
f=frontend/'smt/g3_solver.go';k='func (s *Z3Solver) SetParam(';s=f.read_text();a=s.index(k);b=s.index('{',a)+1
dst=w/'live-params.go.txt';dst.write_text(s[:b]+'println("LIVE-PARAM",key,value);'+s[b:]);ov['Replace'][str(f)]=str(dst)
f=w/'live.json';f.write_text(json.dumps(ov));exe=w/'live'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',f,'-o',exe,'./cmd/goivy_check'],cwd=frontend,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');name='test/arm_rules3.ivy';src=Path('/tmp/g3-reduction-rows');ref=src/'compat'/str((src/'compat.txt').read_text().splitlines().index(name)+1)/'1/native'
r=subprocess.run(['taskset','-c','12',exe,ex/name],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
raw=[];params=[];counts=[0,0,0]
with (w/'live.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['batch','goal','stage','instances','fresh_operands','five_ors'])
 for l in r.stderr.splitlines(keepends=True):
  if l.startswith(b'QI-COUNT '):
   _,n,m=l.split();counts=[counts[0]+1,counts[1]+int(n),counts[2]+int(m)]
  elif l.startswith(b'LIVE-PARAM '):params.append(l)
  elif l.startswith(b'STAGE-COUNT '):
   _,b,g,s,*_=l.decode().split();out.writerow([b,g,s,*counts]);counts=[0,0,0]
  else:raw.append(l)
assert counts==[0,0,0] and (r.returncode,r.stdout,b''.join(raw))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
(w/'params.txt').write_bytes(b''.join(params))
