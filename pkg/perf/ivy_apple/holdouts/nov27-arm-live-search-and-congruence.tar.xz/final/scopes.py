from pathlib import Path
import csv,subprocess
w=Path(__file__).resolve().parent
with (w/'scopes.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','mode','case','instructions'])
 for i in range(7):
  for name,repeat in [('BenchmarkSMTMergeAndUndo','10000x'),('BenchmarkSMTCongruenceScopeMemory','2x')]:
   for m in ['base','final'][::1 if i%2==0 else -1]:
    stat=w/'scopes.stat'
    subprocess.run(['taskset','-c','18','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/(m+'.test'),'-test.run','^$','-test.bench','^'+name+'$','-test.benchtime',repeat,'-test.cpu','1'],check=True,stdout=subprocess.DEVNULL)
    v=next(r[0] for r in csv.reader(stat.open()) if len(r)>4 and r[2]=='instructions:u' and float(r[4])==100)
    out.writerow([i,m,name,v]);f.flush()
