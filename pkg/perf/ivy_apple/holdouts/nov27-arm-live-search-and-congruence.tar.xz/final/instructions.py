from pathlib import Path
import csv,subprocess
w=Path(__file__).resolve().parent
with (w/'bench-ins.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','case','mode','instructions'])
 for i in range(5):
  for case in ['EraseInsert','EraseCommuted','EraseMiss','Ordered','Miss']:
   for m in ['base','final'][::1 if i%2==0 else -1]:
    stat=w/'bench.stat';r=subprocess.run(['taskset','-c','16','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/(m+'.test'),'-test.run','^$','-test.bench','^BenchmarkSMTCongruenceProbes$/^'+case+'$','-test.benchtime','200000x','-test.cpu','1'],capture_output=True,check=True)
    assert case.encode() in r.stdout
    with stat.open() as h:n=next(r[0] for r in csv.reader(h) if len(r)>4 and r[2]=='instructions:u' and float(r[4])==100)
    out.writerow([i,case,m,n]);f.flush()
