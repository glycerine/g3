from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'smtcore/smt_asserted_macros.go';s=f.read_text();k='inputs := make([]macros.Formula, 0, len(k.assertions)-k.assertedHead)';assert s.count(k)==1
s=s.replace(k,'''var held []ast.ASTRef
 defer func(){for i:=range held {result=errors.Join(result,k.manager.DelRef(&held[i]))}}()
 '''+k,1)
k='inputs = append(inputs, macros.Formula{Expression: assertion.Formula, Proof: assertion.Proof})'
s=s.replace(k,'''if k.reduceIfSharingChanged && assertion.Proof.IsNull(){
 m:=k.manager;n,e:=m.GetKind(assertion.Formula);if e!=nil{return e}
 if n==ast.ASTQuantifier {all,e:=m.IsForall(assertion.Formula);if e!=nil{return e};body,e:=m.GetQuantifierBody(assertion.Formula);if e!=nil{return e};h,_,e:=m.ExpressionHeader(body);if e!=nil{return e}
 if all && h.Kind==ast.ASTApp && h.Family==m.BasicFamilyID() && (h.DeclKind==ast.ASTOpEq||h.DeclKind==ast.ASTOpIff){
 a,e:=m.GetArg(body,0);if e!=nil{return e};b,e:=m.GetArg(body,1);if e!=nil{return e};ah,_,e:=m.ExpressionHeader(a);if e!=nil{return e};bh,_,e:=m.ExpressionHeader(b);if e!=nil{return e}
 if ah.Kind==ast.ASTApp && ah.Family==m.BasicFamilyID() && ah.DeclKind==ast.ASTOpAnd && bh.Family==ah.Family && bh.DeclKind==ah.DeclKind && bh.Kind==ast.ASTApp {
 np,e:=m.GetNumPatterns(assertion.Formula);if e!=nil{return e};nn,e:=m.GetNumNoPatterns(assertion.Formula);if e!=nil{return e}
 if np==0 && nn==0{
 sides:=[2]ast.ASTHandle{a,b}
 for i,side:=range sides{imp,e:=m.MkImplies(side,sides[1-i]);if e!=nil{return e};q,e:=m.UpdateQuantifierBody(assertion.Formula,imp);if e!=nil{return e};r,e:=m.NewRef(q);if e!=nil{return e};held=append(held,r);inputs=append(inputs,macros.Formula{Expression:q})}
 continue
 }
 }} }}
 '''+k,1)
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'rule.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],7,['base','release'])
