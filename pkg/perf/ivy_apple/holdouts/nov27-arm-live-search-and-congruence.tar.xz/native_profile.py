from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-arm-history/native.py').read_text()
s=s.replace('static thread_local void* freshTarget=nullptr;', 'static thread_local void* freshTarget=nullptr;static thread_local void* freshParent=nullptr;static thread_local bool gateActive=false;')
s=s.replace('costs[6],counts[6]','costs[11],counts[11]').replace('i<6;i++','i<11;i++')
s=s.replace('static void freshPrint()', 'struct gateMeasure{unsigned i;unsigned long long start=0;gateMeasure(unsigned j):i(j){if(gateActive)start=freshRead();}~gateMeasure(){if(start)freshAdd(i,start);}};\nstatic void freshPrint()')
s=s.replace('bool track=freshInstance && !freshTarget','bool parent=freshInstance && !freshParent').replace('unsigned long long total=0;if(track)', 'if(parent)freshParent=arg;bool track=n==freshParent && !freshTarget && is_app(arg) && m_manager.is_or(arg) && to_app(arg)->get_num_args()==5 && !e_internalized(arg) && !b_internalized(arg);unsigned long long total=0;if(track)').replace('if(track){freshAdd(0,total);','if(parent)freshParent=nullptr;if(track){freshAdd(0,total);')
s=s.replace('if(direct&&gate)tick=freshRead();','if(direct&&gate){gateActive=true;tick=freshRead();}').replace('if(direct&&gate)freshAdd(4,tick);','if(direct&&gate){freshAdd(4,tick);gateActive=false;}')
k="(w/'smt_internalizer.cpp').write_text(helper+pre+t+post)"
z="""
s=helper+pre+t+post
def add(name,extra):
 global s
 a=s.index(name);i=s.index('{',a)+1;s=s[:i]+extra+s[i:]
for fn,i in [('void context::mk_gate_clause(unsigned',7),('clause * context::mk_clause(unsigned',8),('void context::add_or_rel_watches(app',10)]:
 add(fn,'gateMeasure meter'+str(i)+'('+str(i)+');')
k='clause * context::mk_clause(unsigned';a=s.index(k);pos=s.index('if (!simplify_aux_clause_literals',a);s=s[:pos]+'gateMeasure storeMeter(99);'+s[pos:]
s=s.replace('if(gateActive)start=freshRead();','if(gateActive&&j!=99)start=freshRead();')
s=s.replace('gateMeasure storeMeter(99);','');i=s.index('switch (k)',a);s=s[:i]+'gateMeasure storeMeter(99);'+s[i:]
k='return nullptr; // clause is equivalent to true;';i=s.index(k,a)+len(k)+1;s=s[:i]+'if(gateActive){storeMeter.i=9;storeMeter.start=freshRead();}'+s[i:]
(w/'smt_internalizer.cpp').write_text(s)
"""
s=s.replace(k,z).replace("(w/'fresh.py')","(w/'run.py')")
(w/'native.py').write_text(s);subprocess.run([sys.executable,w/'native.py'],check=True)
