from pathlib import Path
import subprocess,re,shlex,csv
w=Path(__file__).resolve().parent;p=Path.cwd();b=p.parent/'build';src=p.parent/'src/smt'
q=(src/'qi_queue.cpp').read_text();k='m_context.internalize_instance(lemma, pr1, gen);';assert q.count(k)==1;(w/'qi_queue.cpp').write_text('extern thread_local bool freshInstance;\n'+q.replace(k,'freshInstance=true;'+k+'freshInstance=false;'))
s=(src/'smt_internalizer.cpp').read_text()
helper=r'''
#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <cstdio>
#include <cstdlib>
thread_local bool freshInstance=false;
static thread_local void* freshTarget=nullptr;static thread_local void* freshParent=nullptr;static thread_local bool gateActive=false;
static thread_local unsigned long long costs[11],counts[11];
static unsigned long long freshRead(){
 static thread_local int fd=-1;
 if(fd==-1){perf_event_attr a{};a.size=sizeof(a);a.type=PERF_TYPE_HARDWARE;a.config=PERF_COUNT_HW_INSTRUCTIONS;a.exclude_kernel=a.exclude_hv=1;a.read_format=3;fd=syscall(SYS_perf_event_open,&a,0,-1,-1,0);}
 unsigned long long v[3];if(read(fd,v,sizeof(v))!=sizeof(v)||!v[1]||v[1]!=v[2])abort();return v[0];}
static void freshAdd(unsigned k,unsigned long long t){costs[k]+=freshRead()-t;counts[k]++;}
struct gateMeasure{unsigned i;unsigned long long start=0;gateMeasure(unsigned j):i(j){if(gateActive)start=freshRead();}~gateMeasure(){if(start)freshAdd(i,start);}};
static void freshPrint(){freshAdd(5,freshRead());fputs("FRESH",stderr);for(int i=0;i<11;i++){fprintf(stderr," %llu %llu",counts[i],costs[i]);counts[i]=costs[i]=0;}fputc('\n',stderr);}
'''
a=s.index('void context::internalize_formula_core(');bnd=s.index('\n    }',a);pre,t,post=s[:a],s[a:bnd],s[bnd:]
def sub(k,z):
 global t
 assert t.count(k)==1,k;t=t.replace(k,z)
sub('// process args','bool direct=n==freshTarget;unsigned long long tick=direct?freshRead():0;\n // process args')
k='internalize(arg, _is_gate);';sub(k,'bool parent=freshInstance && !freshParent && m_manager.is_eq(n) && !e_internalized(arg) && m_manager.is_bool(arg) && !b_internalized(arg);if(parent)freshParent=arg;bool track=n==freshParent && !freshTarget && is_app(arg) && m_manager.is_or(arg) && to_app(arg)->get_num_args()==5 && !e_internalized(arg) && !b_internalized(arg);unsigned long long total=0;if(track){freshTarget=arg;total=freshRead();}'+k+'if(parent)freshParent=nullptr;if(track){freshAdd(0,total);freshTarget=nullptr;freshPrint();}')
sub('bool is_new_var = false;', 'if(direct)freshAdd(1,tick);bool is_new_var = false;')
k='v = mk_bool_var(n);';sub(k,'if(direct)tick=freshRead();'+k+'if(direct)freshAdd(2,tick);')
k='mk_enode(n, suppress_args, merge_tf, true);';sub(k,'if(direct)tick=freshRead();'+k)
k='set_enode_flag(v, is_new_var);';sub(k,k+'if(direct)freshAdd(3,tick);')
k='switch (n->get_decl_kind())';sub(k,'bool gate=_is_gate;if(direct&&gate){gateActive=true;tick=freshRead();}'+k)
idx=t.rindex('}');t=t[:idx]+'if(direct&&gate){freshAdd(4,tick);gateActive=false;}'+t[idx:]

s=helper+pre+t+post
def add(name,extra):
 global s
 a=s.index(name);i=s.index('{',a)+1;s=s[:i]+extra+s[i:]
for fn,i in [('void context::mk_gate_clause(unsigned',7),('clause * context::mk_clause(unsigned',8),('void context::add_or_rel_watches(app',10)]:
 add(fn,'gateMeasure meter'+str(i)+'('+str(i)+');')
k='clause * context::mk_clause(unsigned';a=s.index(k);pos=s.index('if (!simplify_aux_clause_literals',a);s=s[:pos]+'gateMeasure storeMeter(99);'+s[pos:]
s=s.replace('if(gateActive)start=freshRead();','if(gateActive&&j!=99)start=freshRead();')
s=s.replace('gateMeasure storeMeter(99);','');i=s.index('switch (k)',a);s=s[:i]+'gateMeasure storeMeter(99);'+s[i:]
k='return nullptr; // clause is equivalent to true;';i=s.index(k,a)+len(k)+1;s=s[:i]+'if(gateActive){storeMeter.i=9;storeMeter.start=freshRead();}'+s[i:]
(w/'smt_internalizer.cpp').write_text(s)

mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l);objs=[]
for q in [w/'qi_queue.cpp',w/'smt_internalizer.cpp']:
 o=w/(q.stem+'.o');subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',o,q],cwd=b,check=True);objs.append(o)
link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',mk,re.M)[1];libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
exe=w/'native';subprocess.run([conf['LINK'],'-o',exe,*objs,*libs,*shlex.split(conf['LINK_EXTRA_FLAGS'])],cwd=b,check=True)
import os
s=(w/'run.py').read_text().split("h=Path('/tmp/g3-frame-child');",1)[1].replace("'fresh-cost.csv'","'native-cost.csv'")
exec("h=Path('/tmp/g3-frame-child');"+s)
