from pathlib import Path
import csv,re
w=Path(__file__).resolve().parent
src=Path('/tmp/g3-arm-equality/fixtures')
prefix=Path('/tmp/g3-arm-history/enum/early.py').read_text()
exec(prefix[prefix.index('from dataclasses'):prefix.index('w=Path')]+prefix[prefix.index('@dataclass'):prefix.index('for file')])
for file in sorted(src.glob('*.smt2')):
 s=file.read_text();exec(prefix[prefix.index('stack=[];roots=[]'):prefix.index(' assert not stack')].replace('\n ','\n'))
 declared={k[1] for n in roots if (k:=n.key())[0]=='declare-fun' and k[-1]=='Bool' and k[2]}
 def render(x):return s[x.lo:x.hi] if isinstance(x,Node) else x
 for mode in ['definitions','ordering']:
  edits=[];heads=[]
  def visit(n):
   if not isinstance(n,Node):return
   v=n.terms
   if v and v[0]=='forall':
    pars=[x.terms[0] for x in v[1].terms];body=v[2];node=body
    while isinstance(node,Node) and node.terms[0]=='let':node=node.terms[2]
    if isinstance(node,Node) and node.terms[0]=='=':
     for side in node.terms[1:]:
      if isinstance(side,Node) and side.terms[0] in declared and len(side.terms[1:])==len(pars) and all(isinstance(x,str) for x in side.terms) and set(side.terms[1:])==set(pars):
       if mode=='definitions' or 'prevents' in side.terms[0]:
        heads.append(side.terms[0]);edits.extend([(body.lo,'(! '),(body.hi,' :pattern ('+render(side)+'))')]);break
   for x in v:visit(x)
  for n in roots:visit(n)
  result=s
  for i,val in sorted(edits,reverse=True):result=result[:i]+val+result[i:]
  print(file.name,mode,len(heads));dst=w/mode;dst.mkdir(exist_ok=True);(dst/file.name).write_text(result)
