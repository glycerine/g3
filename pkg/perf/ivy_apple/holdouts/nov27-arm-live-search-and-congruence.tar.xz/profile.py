from pathlib import Path
import sys,subprocess
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-arm-history/five/fresh.py').read_text()
k="edit('smtcore/smt_internalizer.go',instrument)"
code='''
def stageMeter(s):
 s=instrument(s)
 def mark(name,body):
  nonlocal s
  i=s.index('func (s *SMTInternalizerState) '+name+'(');j=s.index('{',i)+1;s=s[:j]+body+s[j:]
 mark('addGateConstraints','if expression==freshTarget {gateActive=true;defer func(){gateActive=false}()};')
 for fn,cat in [('argumentLiterals',6),('addGateClause',7),('addClauseKindWithJustificationAndDeleteHandler',8),('storeSimplifiedClause',9)]:
  mark(fn,'if gateActive{defer freshAdd('+str(cat)+',freshRead())};')
 k='return s.relevancy.AddOrWatches(expression)'
 assert s.count(k)==1;s=s.replace(k,'if gateActive{defer freshAdd(10,freshRead())};'+k)
 return s
edit('smtcore/smt_internalizer.go',stageMeter)
'''
s=s.replace(k,code).replace('var freshInstance bool','var freshInstance,gateActive bool').replace('[6]uint64','[11]uint64').replace('[0]*12','[0]*22').replace('len(vs)==12','len(vs)==22').replace("'gate','empty'","'gate','empty','arguments','emit','simplify-and-store','store','relevance'")
(w/'run.py').write_text(s);subprocess.run([sys.executable,w/'run.py'],check=True)
