from pathlib import Path
w=Path(__file__).resolve().parent
for mode in ['same','definitions','ordering']:
 src=Path('/tmp/g3-arm-equality/fixtures') if mode=='same' else w/mode
 dst=w/('macro-'+mode);dst.mkdir(exist_ok=True)
 for f in src.glob('*.smt2'):(dst/f.name).write_text('(set-option :smt.macro_finder true)\n'+f.read_text())
s=(w/'compare_inputs.py').read_text().replace("'input-cost.csv'","'macro-cost.csv'").replace("('same',orig),('ordering',w/'ordering'),('definitions',w/'definitions')","('same',w/'macro-same'),('ordering',w/'macro-ordering'),('definitions',w/'macro-definitions')")
exec(s)
