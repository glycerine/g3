from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
code=Path('/tmp/g3-ticket-stages/breakdown.py').read_text().replace("['cli-stacks','stacks']","['stacks']")
exec(code)
with (w/'callers.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','parent','child','mean_M'])
 for engine in ['g3','native']:
  tally=collections.Counter();rounds=set()
  for r in csv.DictReader((w/('stacks-'+engine+'.csv')).open()):
   rounds.add(r['round']);stack=r['stack'].splitlines();weight=int(r['period'])*int(r['count'])
   keys=(['(*SMTKernel).boundedSearch','(*SMTKernel).internalizePending','(*SMTKernel).search','(*SMTInternalizerState).Propagate','(*SMTInternalizerState).propagate','(*SMTQuantifierManager).Propagate','(*smtSetup).setup','(*SMTKernel).reduceAsserted','(*APISimpleSolver).Push','(*SMTKernel).resolveSearchConflict','(*SMTModelChecker).checkQuantifier'] if engine=='g3' else ['smt::context::bounded_search(','smt::context::internalize_assertions(','smt::context::propagate(','smt::context::propagate_core(','smt::context::resolve_conflict(','smt::model_checker::check(quantifier*)'])
   for k in keys:
    idx=next((i for i in reversed(range(len(stack))) if k in stack[i] and (engine=='native' or stack[i].endswith(k.split('.').pop()) or stack[i].endswith(k))),None)
    if idx is not None:tally[k,stack[max(0,idx-1)]]+=weight
  for (k,c),cost in tally.most_common():out.writerow([engine,k,c,round(cost/len(rounds)/1e6,2)])
