from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'smtcore/smt_theory_propagation.go';s=f.read_text();a=s.index('func (s *SMTInternalizerState) propagateAssignedAtom(');b=s.index('// appendAssignedLiteral',a);x=s[a:b];x=x.replace('if node := s.context.enodes.get(s.boolExpr[variable]); node != nil {','node := s.context.enodes.get(s.boolExpr[variable]); if node != nil {')
k='expression := s.boolExpr[variable]';x=x.replace(k,'var left,right *SMTEnode\n if node!=nil && node.IsEquality() && len(node.arguments)==2 {left,right=node.arguments[0],node.arguments[1]} else {\n'+k)
x=x.replace('left, right := s.context.enodes.get(leftExpression), s.context.enodes.get(rightExpression)','left, right = s.context.enodes.get(leftExpression), s.context.enodes.get(rightExpression)\n}');s=s[:a]+x+s[b:]
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(12,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],11,['base','release'])
