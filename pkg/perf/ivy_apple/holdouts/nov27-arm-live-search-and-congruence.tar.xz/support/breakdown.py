from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
for stem in ['cli-stacks','stacks']:
 sums=collections.Counter();seen=collections.defaultdict(set)
 for engine in ['g3','native']:
  for r in csv.DictReader((w/(stem+'-'+engine+'.csv')).open()):
   e=engine=='g3';s=r['stack'];q=r['case'];i=int(r['round'])
   if ('(*SMTModelChecker).checkQuantifier' if e else 'smt::model_checker::check(quantifier*)') in s:
    phase='mbqi-quantifier'
   elif ('(*SMTQuantifierManager).instantiate' in s or '(*SMTQuantifierManager).Propagate.func1' in s or '(*SMTQIInstanceBuilder).MaterializeAndInternalize' in s) if e else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)' in s:
    pairs=[('substitute','(*SMTCachedVarSubstitution).Instantiate' if e else 'cached_var_subst::operator()'),('assert','(*SMTInternalizerState).assertExpression' if e else 'smt::context::internalize_assertion'),('rewrite','(*rewriterEngine).Rewrite' if e else 'rewriter_tpl<th_rewriter_cfg>'),('checker','(*SMTChecker).run' if e else 'smt::checker::is_sat')]
    phase='queue-'+next((k for k,v in pairs if v in s),'other')
   elif ('(*SMTKernel).internalizePending' if e else 'smt::context::internalize_assertions') in s: phase='install'
   elif ('(*SMTKernel).boundedSearch' if e else 'smt::context::bounded_search') in s: phase='other-search'
   else: phase='remaining'
   sums[q,engine,i,phase]+=int(r['period'])*int(r['count'])
   seen[q,engine].add(i)
 with (w/(stem+'-summary.csv')).open('w') as f:
  out=csv.writer(f);out.writerow('case category g3_rounds native_rounds g3_M native_M gap_M'.split())
  for q in sorted({k[0] for k in sums}):
   for ph in ['mbqi-quantifier','queue-substitute','queue-rewrite','queue-assert','queue-checker','queue-other','install','other-search','remaining']:
    val=[statistics.mean(sums[q,e,i,ph] for i in seen[q,e])/1e6 if seen[q,e] else 0 for e in ['g3','native']]
    out.writerow((q,ph,len(seen[q,'g3']),len(seen[q,'native']),*[round(x,2) for x in [*val,val[0]-val[1]]]))
