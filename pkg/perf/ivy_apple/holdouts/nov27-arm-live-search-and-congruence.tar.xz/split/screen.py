from pathlib import Path
import concurrent.futures
w=Path(__file__).resolve().parent
s=(w/'holdouts.py').read_text().split("names=['")[0]
exec(s)
cpus=[0,2,4,6,8,16,18,20]
with concurrent.futures.ThreadPoolExecutor(len(cpus)) as pool:
 jobs=[pool.submit(run,cpu,'inventory'+str(i),cases[i::len(cpus)],1,['base','sides'] if i%2==0 else ['sides','base']) for i,cpu in enumerate(cpus)]
 for j in jobs:j.result()
