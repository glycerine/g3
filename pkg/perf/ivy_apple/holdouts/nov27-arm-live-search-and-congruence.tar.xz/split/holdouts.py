from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'trial.py').read_text().split("run(14,'whole'")[0]
s=s[s.index("orig=Path"):].replace("exec(compile(orig,__file__,'exec'))","orig='\\n'.join(l for l in orig.splitlines() if not l.startswith('subprocess.run([*flags'));exec(compile(orig,__file__,'exec'))")
exec(s)
names=['test/arm_rules3.ivy','examples/liveness/ticket.ivy','examples/liveness/ticket_nested.ivy','examples/ivy/toy_consensus2.ivy','examples/ivy/indexset_test.ivy','examples/ivy/card2.ivy','doc/examples/leader_election_ring.ivy','test/flash2.ivy','doc/examples/liveness/ticket_l2s_auto.ivy']
run(10,'holdouts',[n for n in names if n in cases],9,['base','sides'])
