from pathlib import Path
import csv
w=Path(__file__).resolve().parent;exec((w/'holdouts.py').read_text().split("names=['")[0])
names=sorted({r['case'] for f in w.glob('inventory*.csv') for r in csv.DictReader(f.open()) if r['status']!='match'})
run(18,'recheck',names,1,['sides','base'])
