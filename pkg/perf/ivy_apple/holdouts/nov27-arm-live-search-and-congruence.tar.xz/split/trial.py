from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
f=frontend/'smt/g3.go';s=f.read_text();k='return ctx.newExpr(handle(ctx.c.ConstantQuantifier(api.ConstantQuantifierSpec{Forall: all, Bound: exprHandles(bound), Body: body.c, Weight: 1})))';assert s.count(k)==1
s=s.replace(k,'''if all {
 m,e:=ctx.c.Manager();fail(e);h,_,e:=m.ExpressionHeader(body.c);fail(e)
 if h.Kind==ast.ASTApp && h.Family==m.BasicFamilyID() && (h.DeclKind==ast.ASTOpEq || h.DeclKind==ast.ASTOpIff){
 a,e:=m.GetArg(body.c,0);fail(e);b,e:=m.GetArg(body.c,1);fail(e);ah,_,e:=m.ExpressionHeader(a);fail(e);bh,_,e:=m.ExpressionHeader(b);fail(e)
 if ah.Kind==ast.ASTApp && bh.Kind==ast.ASTApp && ah.Family==m.BasicFamilyID() && bh.Family==ah.Family && ah.DeclKind==ast.ASTOpAnd && bh.DeclKind==ast.ASTOpAnd {
 ends:=[]ast.ASTHandle{a,b};args:=exprHandles(bound);var qs []Z3Expr
 for i,side:=range ends {other:=ends[1-i];otherHeader,_,e:=m.ExpressionHeader(other);fail(e);n:=uint32(1);if os.Getenv("STUDY_SPLIT")=="terms"{n=otherHeader.NumArgs}
 for j:=uint32(0);j<n;j++ {conclusion:=other;if os.Getenv("STUDY_SPLIT")=="terms"{conclusion,e=m.GetArg(other,j);fail(e)}
 implication:=ctx.newExpr(handle(ctx.c.Implies(side,conclusion)));qs=append(qs,ctx.newExpr(handle(ctx.c.ConstantQuantifier(api.ConstantQuantifierSpec{Forall:true,Bound:args,Body:implication.c,Weight:1}))))}}
 return ctx.And(qs...)
 }
 }
 }
 '''+k)
if '"os"' not in s:s=s.replace('import (','import (\n"os"')
dst=w/'candidate.go.txt';dst.write_text(s);ov=w/'split.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')").replace('modes[m],ex/name',"(w/'release' if m in ('sides','terms') else modes[m]),ex/name").replace('env=dict(os.environ,GOMAXPROCS','env=dict(os.environ,STUDY_SPLIT=m,GOMAXPROCS')
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],5,['base','sides','terms'])
