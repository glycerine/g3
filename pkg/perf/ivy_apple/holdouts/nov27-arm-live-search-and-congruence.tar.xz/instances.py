from pathlib import Path
import json,os,subprocess,csv,collections
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();h=Path('/tmp/g3-ticket-stages');ov=json.loads((h/'translated.json').read_text())
f=p/'smtcore/smt_qi_instance.go';s=f.read_text();k='result, err := b.materialize(prepared, rw, stat, scope, &locals)';assert s.count(k)==1
s=s.replace(k,'id:=studyName(b.manager,prepared.quantifier); t:=freshRead();defer func(){println("LIVE-Q",id,freshRead()-t)}();'+k)
dst=w/'instance.go.txt';dst.write_text(s);ov['Replace'][str(f)]=str(dst)
helper=(w/'fresh.go.txt').read_text().split('func freshAdd(',1)[0].replace('import("syscall";','import("strings";"syscall";')
helper+='''
var names=map[ast.ASTHandle]int{}
func studyName(m *ast.ASTManager,q ast.ASTHandle)int{
 if id,ok:=names[q];ok{return id};id:=len(names)+1;names[q]=id
 b,e:=m.GetQuantifierBody(q);if e!=nil{panic(e)};var w strings.Builder;shape(m,b,&w,4);println("LIVE-N",id,w.String());return id}
func shape(m *ast.ASTManager,h ast.ASTHandle,w *strings.Builder,depth int){
 n,e:=m.NodeHeader(h);if e!=nil{panic(e)}
 if n.Kind!=ast.ASTApp{w.WriteByte('_');return}
 if e=m.DisplayDeclarationHead(w,n.Decl);e!=nil{panic(e)}
 if depth==0||n.NumArgs==0{return};w.WriteByte('(')
 for i:=uint32(0);i<n.NumArgs;i++{if i>0{w.WriteByte(',')};a,e:=m.GetArg(h,i);if e!=nil{panic(e)};shape(m,a,w,depth-1)};w.WriteByte(')')}
'''
dst=w/'instance-helper.go.txt';dst.write_text(helper);ov['Replace'][str(p/'smtcore/zz_instance_study.go')]=str(dst)
f=w/'instance.json';f.write_text(json.dumps(ov));exe=w/'instance'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',f,'-o',exe,'./cmd/goivy_check'],cwd=frontend,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');name='test/arm_rules3.ivy';src=Path('/tmp/g3-reduction-rows');ref=src/'compat'/str((src/'compat.txt').read_text().splitlines().index(name)+1)/'1/native'
with (w/'instances.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','batch','goal','stage','shape','calls','instructions'])
 for it in range(3):
  r=subprocess.run(['taskset','-c','12',exe,ex/name],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
  raw=[];names={};group=collections.defaultdict(lambda:[0,0])
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'LIVE-N '):
    _,i,shape=l.decode().strip().split(' ',2);names[int(i)]=shape
   elif l.startswith(b'LIVE-Q '):
    _,i,v=l.split();record=group[names[int(i)]];record[0]+=1;record[1]+=int(v)
   elif l.startswith(b'STAGE-COUNT '):
    _,b,g,s,*_=l.decode().split()
    for shape,(n,v) in group.items():out.writerow([it,b,g,s,shape,n,v])
    group.clear()
   else:raw.append(l)
  assert not group and (r.returncode,r.stdout,b''.join(raw))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),raw[:3]
