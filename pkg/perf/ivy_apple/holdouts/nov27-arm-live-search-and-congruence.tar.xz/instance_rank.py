from pathlib import Path
import statistics,csv,collections
w=Path(__file__).resolve().parent
counts=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0]))
for r in csv.DictReader((w/'instances.csv').open()):
 v=counts[r['shape']][int(r['round'])];v[0]+=int(r['calls']);v[1]+=int(r['instructions'])
with (w/'instance-ranking.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['shape','calls','median_instructions'])
 for shape,vs in sorted(counts.items(),key=lambda it:-sum(n[1] for n in it[1].values())):
  assert len(vs)==3 and len(set(v[0] for v in vs.values()))==1
  out.writerow([shape,vs[0][0],statistics.median(v[1] for v in vs.values())])
