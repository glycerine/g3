from pathlib import Path
import sys,subprocess
w=Path(__file__).resolve().parent;old=Path('/tmp/g3-ticket-first')
s=(old/'arith_stages.py').read_text().replace("for eng in ['g3','native']:","for eng in ['g3']:").replace("w/('arith-stage-'+eng),ex/names[nr-1]","(old if eng=='native' else w)/('arith-stage-'+eng),ex/names[nr-1]").replace("'20'","'26'");exec(s)
sys.argv=['profile.py','g3','26'];s=(old/'arith_profile.py').read_text().replace("w/'validation/final'","w/'release'");exec(s)
