from pathlib import Path
import subprocess,os,concurrent.futures,shutil
w=Path(__file__).resolve().parent;old=w.parent;p=Path.cwd()
for n,t in [('abc',old/'abc'),('base',old/'base'),('native',old/'native'),('weak',old/'weak'),('apple-base',old/'apple-base')]:
 if not (w/n).exists():(w/n).symlink_to(t)
for n in ['long.py','verify.py','whole.py']:shutil.copyfile(old/n,w/n)
flags=['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')]
for apple in [False,True]:
 f=p/('build/.boolean-enode-cost/apple-source/goivy' if apple else 'build/.boolean-enode-cost/frontend/goivy')
 subprocess.run([*flags,'-overlay',Path('/tmp/g3-selective/final')/('apple.json' if apple else 'overlay.json'),*([] if apple else ['-modfile',p/'build/.boolean-enode-cost/heap/study.mod']),'-o',w/('apple-release' if apple else 'release'),'./cmd/goivy_check'],cwd=f,check=True)
def run(n,args=[],**env):subprocess.run(['python3',w/n,*args],env=dict(os.environ,**env),check=True)
with concurrent.futures.ThreadPoolExecutor(4) as pool:
 jobs=[pool.submit(run,'verify.py',PANEL='1'),pool.submit(run,'long.py'),pool.submit(run,'whole.py',['comparison','base','weak','release','native'],CASES='14 15',ROUNDS='11',CPU='20'),pool.submit(run,'whole.py',['holdout','weak','release'],CASES='2 3 4 12',ROUNDS='9',CPU='22')]
 for j in jobs:j.result()
