from census import *
k=p/'ast/rewriter/arith_rewriter.go';s=k.read_text();i=s.index('newLeft, newRight, powerChanged',s.index('func (r *ArithRewriter) rewriteComparison('))
s=s[:i]+'''// A variable or uninterpreted integer application has coefficient one.
 // Against an integer numeral on the right it is already in polynomial
 // normal form, with no powers, coercions, or common factor to reduce.
 head, err := r.manager.NodeHeader(left)
 if err != nil {return RewriteFailed, err}
 if head.Kind == ast.ASTVar || head.Kind == ast.ASTApp && head.Family == ast.NullFamilyID {
    bound, small, err := r.manager.ArithmeticSmallInteger(right)
    if err != nil {return RewriteFailed, err}
    if small && bound != -1<<31 {
        integer, err := r.integerTerm(left)
        if err != nil || integer {return RewriteFailed, err}
    }
 }
 '''+s[i:]
g=w/'normal.go';g.write_text(s)
for mode,jbase in [('normal','/tmp/g3-ticket-first/validation/final.json'),('arith-stage-normal','/tmp/g3-ticket-first/arith-stage.json')]:
 o=json.loads(Path(jbase).read_text());o['Replace'][str(k)]=str(g);j=w/(mode+'.json');j.write_text(json.dumps(o));build(j,mode)
src=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();src=src[src.index("rank=Path"):].replace("'g3','native'","'weak','normal'").replace("'arith-stages.csv'","'normal-stage.csv'").replace("'20'","'26'");exec(src)
subprocess.run(['python3',w/'whole.py','normal-whole','weak','normal','native'],env=dict(os.environ,CASES='14 15 2 3 4 12',ROUNDS='7',CPU='20'),check=True)
