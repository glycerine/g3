from pathlib import Path
from shutil import copyfile
import os,subprocess,concurrent.futures
p=Path.cwd();w=Path(__file__).resolve().parent
old=Path('/tmp/g3-ticket-first/validation/verified')
for name,target in [('release',w/'weak'),('apple-base',old/'apple-release')]:
 if not (w/name).exists():(w/name).symlink_to(target)
for n in ['verify.py','long.py']:copyfile(old/n,w/n)
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay','/tmp/g3-selective/final/apple.json','-o',w/'apple-release','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/apple-source/goivy',check=True)
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 jobs=[pool.submit(subprocess.run,['python3',w/n],env=dict(os.environ,PANEL='1'),check=True) for n in ['verify.py','long.py']]
 for j in jobs:j.result()
