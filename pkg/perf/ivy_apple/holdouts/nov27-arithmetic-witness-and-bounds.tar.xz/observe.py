from pathlib import Path
import json,re,os,subprocess,csv
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
o=json.loads(Path('/tmp/g3-ticket-first/arith-stage.json').read_text());old=Path('/tmp/g3-hybrid-gates/post')
def save(k,s):
 t=w/(k.name+'.txt');t.write_text(s);o['Replace'][str(k)]=str(t)
save(p/'api/private_observer_trial.go',(old/'phase-observer.go').read_text())
k=p/'api/api_order_abstraction.go';s=k.read_text();a='func (p *orderProofState) proveWithGoal(maxSteps uint32, reuse bool, goal ast.ASTHandle) (proved bool, err error) {';s=s.replace(a,a+'\nend:=startStage(int(p.expectedGoals),int(p.openingAttempts));defer func(){if proved{end("proved")}else{end("miss")}}()')
save(k,s)
src=(old/'stages.py').read_text();exec(src[src.index('hooks='):src.index("j=w/'stages.json'")],dict(w=w,p=p,o=o,re=re,Path=Path))
k=p/'api/api_goal_instances_check.go';s=Path(o['Replace'][str(k)]).read_text().replace('import (','import ("fmt";',1).replace('reuse := p.plans.reusable(parent)','answerTag:="skipped";defer func(){fmt.Println() }();reuse := p.plans.reusable(parent)',1).replace('fmt.Println()','println("PLAN",fmt.Sprintf("%T",plan),maxSteps,answerTag,proved)').replace('answer, err := aux.child.Check()','answer, err := aux.child.Check();answerTag=fmt.Sprint(int(answer))');save(k,s)
j=w/'observer.json';j.write_text(json.dumps(o));subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',j,'-o',w/'observe','./cmd/goivy_check'],cwd=f,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');ns=(rank/'compat.txt').read_text().splitlines()
with (w/'stages.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case round batch goal phase event details'.split())
 for nr in [14,15]:
  for i in range(3):
   ref=rank/'compat'/str(nr)/'1/native';r=subprocess.run(['taskset','-c','20',w/'observe',ex/ns[nr-1]],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,timeout=45);err=bytearray();events=[]
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith((b'PRIVATE-',b'PLAN ')):events.append(line.decode().strip().split(' ',1))
    elif line.startswith(b'STAGE-COUNT '):
     _,b,g,phase,n,empty,en,running,ms=line.split();assert en==running
     for event,detail in events:out.writerow([nr,i,int(b),int(g),phase.decode(),event,detail])
     events.clear()
    else:err.extend(line)
   assert not events and (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),err[-1000:];f.flush()
