from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-ticket-first/arith_capture.py').read_text().replace("2/3,2/22,2/25,2/30","2/22,2/36,2/37,2/39")
exec(s)
s=Path('/tmp/g3-ticket-first/arith_replay.py').read_text().replace("w/'g3-cli'","w/'cli'").replace("'arith-replay.csv'","'remaining.csv'")
s=s.replace("glob('14-*.smt2')","glob('*.smt2')");s='\n'.join(line for line in s.splitlines() if not line.strip().startswith('assert src.read_bytes()'))
exec(s)
