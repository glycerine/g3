from census import *
overlay=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
for mode in ['once','weak']:
 k=p/('api/api_witness_premises.go' if mode=='once' else 'api/api_witness_instances_plan.go');s=k.read_text()
 if mode=='once':
  s=s.replace('if len(selected) == 0 {','if len(selected) == 0 || !full.selectedOnly && full.width == 3 && full.rounds == 1 && len(selected) == len(index.rows) {')
 else:
  s=s.replace('return &p, nil','''// With only positive universals over one arithmetic domain, there is no
 // counterexample witness in the query to guide this one-round search.
 // Let the incremental arithmetic solver choose its own instances.
 if len(p.sorts) == 1 && bySort[p.sorts[0]].universals == witnessPositive {
    family, err := m.GetFamilyID(p.sorts[0])
    if err != nil {return nil, err}
    arith, err := m.ArithmeticFamilyID()
    if err != nil || family == arith {return nil, err}
 }
 return &p, nil''')
 g=w/(mode+'.go');g.write_text(s);j=w/(mode+'.json');j.write_text(json.dumps({'Replace':{**overlay['Replace'],str(k):str(g)}}));build(j,mode)
subprocess.run(['python3',w/'whole.py','refined','base','once','weak','native'],env=dict(os.environ,CASES='14 15',ROUNDS='9'),check=True)
