from census import *
k=p/'ast/rewriter/arith_polynomial.go';s=k.read_text()
s=s.replace('monomials(h ast.ASTHandle)', 'monomials(h ast.ASTHandle, singleton *[1]ast.ASTHandle)').replace('return []ast.ASTHandle{h}, nil\n}', 'singleton[0] = h\n return singleton[:], nil\n}',1)
# Restrict the substitution to the monomials helper.
i=s.index('func (r *ArithRewriter) monomials(');before=k.read_text();s=before[:before.index('func (r *ArithRewriter) monomials(')]+s[i:];i=s.index('func (r *ArithRewriter) monomials(');e=s.index('func (r *ArithRewriter) cancelMonomials(',i);s=s[:i]+s[i:e].replace('return []ast.ASTHandle{h}, nil','singleton[0] = h\n return singleton[:], nil')+s[e:]
s=s.replace('sides := [2][]ast.ASTHandle{}','var singles [2][1]ast.ASTHandle\n sides := [2][]ast.ASTHandle{}').replace('r.monomials(left)','r.monomials(left,&singles[0])').replace('r.monomials(right)','r.monomials(right,&singles[1])').replace('terms, err := r.monomials(h)','var one [1]ast.ASTHandle\n terms, err := r.monomials(h,&one)')
g=w/'singleton.go';g.write_text(s);o=json.loads((w/'recognize-stage.json').read_text());o['Replace'][str(k)]=str(g);j=w/'singleton.json';j.write_text(json.dumps(o));build(j,'arith-stage-singleton')
src=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();src=src[src.index("rank=Path"):].replace("'g3','native'","'recognize','singleton'").replace("'arith-stages.csv'","'single.csv'").replace("'20'","'24'");exec(src)
