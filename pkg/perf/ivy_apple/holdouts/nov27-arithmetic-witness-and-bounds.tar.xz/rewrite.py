from census import *
k=p/'ast/rewriter/arith_rewriter.go';s=k.read_text()
i=s.index('func (r *ArithRewriter) numeral(');e=s.index('// makeNumeral',i);t=s[i:e].replace('kind, err := r.manager.GetKind(h)','app, family, kind, err := r.manager.AppIdentity(h)').replace('kind != ast.ASTApp','!app || family != r.family || kind != arithOpNum');s=s[:i]+t+s[e:]
i=s.index('nodeKind, err :=',s.index('func (r *ArithRewriter) operation('));e=s.index('matched :=',i)
s=s[:i]+'''head, err := r.manager.NodeHeader(h)
 if err != nil || head.Kind != ast.ASTApp || head.Family != r.family {return 0,nil,false,err}
 kind := head.DeclKind
 '''+s[e:]
i=s.index('n, err := r.manager.GetNumArgs',i);e=s.index('for i := range args',i)
s=s[:i]+'''args := make([]ast.ASTHandle,head.NumArgs)
 '''+s[e:]
g=w/'recognize.go';g.write_text(s);j=w/'recognize.json';j.write_text(json.dumps({'Replace':{**json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())['Replace'],str(k):str(g)}}));build(j,'recognize')
subprocess.run(['python3',w/'whole.py','rewrite','weak','recognize'],env=dict(os.environ,CASES='14 15 2 3 4 12',ROUNDS='7',CPU='22'),check=True)
