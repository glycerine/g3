from pathlib import Path
from collections import Counter
from statistics import median
import csv
w=Path(__file__).resolve().parent
def rows(p):return list(csv.DictReader(p.open()))
for p in ['final/comparison','final/holdout','final/arith-stages']:
 a=rows(w/(p+'.csv'))
 for case in sorted(set(r['case'] for r in a)):
  for m in sorted(set(r.get('mode',r.get('engine')) for r in a)):
   rs=[r for r in a if r['case']==case and r.get('mode',r.get('engine'))==m and r.get('phase','check')=='check']
   if not rs: continue
   vals=[sum(int(r['instructions']) for r in rs if r['round']==i) for i in set(r['round'] for r in rs)]
   print(p,case,m,len(vals),round(median(vals)/1e6,2),round(median(float(r.get('ms',0)) for r in rs),2),[round(median(int(r['instructions']) for r in rs if r['batch']=='2' and r['goal']==str(n))/1e6,2) for n in [3,22,25,30]] if p.endswith('stages') else '')
for p in ['bound-base','bound-release']:
 import re
 a=Counter();d={}
 for l in (w/p).read_text().splitlines():
  if m:=re.match(r'Benchmark.*?/(\w+)-\d+\s+\d+\s+([\d.]+) ns/op',l):d.setdefault(m[1],[]).append(float(m[2]))
 print(p,{k:median(v) for k,v in d.items()})
for name,path in [('before',Path('/tmp/g3-ticket-first/stacks-g3.csv')),('after',w/'final/stacks-g3.csv'),('native',Path('/tmp/g3-ticket-first/stacks-native.csv'))]:
 for case in ['14','15']:
  groups={'compare':['.rewriteComparison','mk_le_ge_eq_core'],'cancel':['.cancelMonomials','::cancel_monomials'],'internalize':['.internalizeAssertions','::internalize_assertions'],'rewrite':['(*TheoryRewriter).Rewrite','th_rewriter::operator()'],'qi':['.addInstance','::add_instance']}
  cnt=Counter()
  for r in rows(path):
   if r['case']!=case:continue
   for k,needles in groups.items():
    if any(x in r['stack'] for x in needles):cnt[k]+=int(r['count'])*int(r['period'])/3e6
  print(name,case,{k:round(v,2) for k,v in cnt.items()})
