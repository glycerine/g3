from census import *
old=Path('/tmp/g3-ticket-first')
j=w/'recognize-stage.json';o=json.loads((old/'arith-stage.json').read_text());k=str(p/'ast/rewriter/arith_rewriter.go');o['Replace'][k]=str(w/'recognize.go');j.write_text(json.dumps(o))
build(old/'arith-stage.json','arith-stage-weak');build(j,'arith-stage-recognize')
s=(old/'arith_stages.py').read_text();s=s[s.index("rank=Path"):].replace("'g3','native'","'weak','recognize'").replace("'arith-stages.csv'","'matched.csv'").replace("'20'","'24'")
exec(s)
