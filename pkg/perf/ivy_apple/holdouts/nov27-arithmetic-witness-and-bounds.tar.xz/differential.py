from pathlib import Path
import csv,subprocess,itertools,os,re
w=Path(__file__).resolve().parent;old=Path('/tmp/g3-ticket-first');env=dict(os.environ,GOMAXPROCS='1')
subprocess.run(['go','build','-o',w/'cli','./cmd/g3'],check=True)
decl='(declare-const x Int)(declare-fun f (Int) Int)(declare-const y Real)(declare-fun h (Real) Real)\n'
with (w/'diff.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['fixture','mode','outputs','result'])
 for options in ['',':arith-ineq-lhs true',':gcd-rounding true',':arith-lhs true :gcd-rounding true :elim-to-real true']:
  fixtures=[]
  for kind in ('Int','Real'):
   lefts=(['x','(f x)','(+ x 1)','(* 2 x)','(mod x 3)'] if kind=='Int' else ['y','(h y)','(to_real x)','(* (/ 3.0 2.0) y)'])
   rights=['0','1','(- 1)','2147483647','(- 2147483648)','2147483648','99999999999999999999'] if kind=='Int' else ['0.0','(/ 2.0 3.0)','(- 1.5)']
   for relation,(l,r),flip in itertools.product(['<=','>=','<','>','='],itertools.product(lefts,rights),[False,True]):
    if flip:l,r=r,l
    fixtures.append(f'(simplify ({relation} {l} {r}) {options})')
  # The simplifier also reaches de Bruijn variables in quantifier bodies.
  fixtures+=[f'(simplify (forall ((b Int)) (=> (p b) ({op} b {bound}))) {options})' for op in ['<=','>='] for bound in ['0','(- 3)']]
  txt=decl+'(declare-fun p (Int) Bool)\n'+'\n'.join(fixtures)
  res=[subprocess.run([exe,'-in','-smt2'],input=txt.encode(),capture_output=True,env=env,check=True) for exe in [old/'g3-cli',w/'cli']]
  assert res[0].stdout==res[1].stdout and not res[0].stderr and not res[1].stderr and b'(error' not in res[0].stdout
  o.writerow(['simplify',options,len(fixtures),'identical'])
 for src in sorted((old/'arith-inputs').glob('14-*.smt2')):
  txt=src.read_text();parts=txt.split('\n(assert ')
  for inc in [False,True]:
   inp=('\n(assert '.join(parts[:2])+('\n(push 1)' if inc else '')+'\n(assert '+parts[2]).encode()
   res=[subprocess.run([exe,'-in','-smt2'],input=inp,capture_output=True,env=env,check=True) for exe in [old/'g3-cli',w/'cli']]
   assert all(r.stdout.startswith(b'unsat\n') and b'(error' not in r.stdout and not r.stderr for r in res)
   def search(r):
    d=dict(re.findall(rb':([\w-]+)\s+(\d+)\b',r.stdout));return [d.get(k,b'0') for k in [b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count']]
   assert search(res[0])==search(res[1]);o.writerow([src.stem,'push' if inc else 'fresh',1,'identical search counts'])
