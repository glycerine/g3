from census import *
from shutil import copyfile
overlay=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
k=p/'api/api_witness_instances_plan.go'
s=k.read_text().replace('p.sorts = append(p.sorts, st)','''family, err := m.GetFamilyID(st)
        if err != nil {return nil,err}
        if family != ast.NullFamilyID {
            ar, err := m.ArithmeticFamilyID()
            if err != nil {return nil,err}
            if family == ar {continue}
        }
        p.sorts = append(p.sorts, st)''').replace('switch {\n\t\tcase row','width, rounds := p.width, p.rounds\n\t\tswitch {\n\t\tcase row').replace('p.width, p.rounds = 6, 3','width, rounds = 6, 3').replace('p.width = max(p.width, 6)','width = max(p.width, 6)').replace('p.sorts = append','p.width, p.rounds = width, rounds\n        p.sorts = append')
g=w/'trial.go';g.write_text(s);overlay['Replace'][str(k)]=str(g);j=w/'trial.json';j.write_text(json.dumps(overlay));build(j,'trial')
for n,t in [('base','/tmp/g3-ticket-first/validation/final'),('native','/tmp/g3-flash-marginal/abc-control/native')]:
 if not (w/n).exists():(w/n).symlink_to(t)
copyfile('/tmp/g3-ticket-first/whole.py',w/'whole.py')
subprocess.run(['python3',w/'whole.py','compare','base','trial','native'],env=dict(os.environ,CASES='14 15',ROUNDS='7'),check=True)
