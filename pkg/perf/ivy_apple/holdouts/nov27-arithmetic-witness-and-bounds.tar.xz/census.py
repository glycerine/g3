from pathlib import Path
import csv,concurrent.futures,os,subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd()
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
k=p/'api/api_goal_instances_check.go'
s=k.read_text().replace('reuse := p.plans.reusable(parent)','''if wp,ok:=plan.(*witnessInstancePlan);ok{
 arithmetic:=0; ar,_:=parent.ArithmeticFamilyID()
 for _,st:=range wp.sorts{f,e:=parent.GetFamilyID(st);if e!=nil{panic(e)};if f==ar{arithmetic++}}
 defer func(){println("WPLAN",arithmetic,len(wp.sorts),wp.width,wp.rounds,len(wp.assertions),len(wp.source),wp.selectedOnly,proved)}()
 }
 reuse := p.plans.reusable(parent)''')
g=w/'census.go';g.write_text(s);j=w/'census.json';j.write_text(json.dumps({'Replace':{**json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())['Replace'],str(k):str(g)}}))
def build(j,out):
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/out,'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
if __name__=='__main__':
 build(j,'census')
 def run(i):
  rows=[];status=[]
  for nr in range(i+1,len(cases)+1,6):
   name=cases[nr-1];ref=rank/'compat'/str(nr)/'1/native'
   r=subprocess.run(['taskset','-c',str(2*i+1),w/'census',ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,timeout=120)
   err=bytearray()
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'WPLAN '):rows.append([name,*line.decode().split()[1:]])
    else:err.extend(line)
   status.append([name,(r.returncode,r.stdout,err)==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())])
  return rows,status
 with concurrent.futures.ThreadPoolExecutor(6) as pool:results=list(pool.map(run,range(6)))
 for idx,header in enumerate(['case arithmetic sorts width rounds assertions source selected proved','case match']):
  with (w/('census'+str(idx)+'.csv')).open('w') as f:
   o=csv.writer(f);o.writerow(header.split());o.writerows(row for pair in results for row in pair[idx])
