from census import *
k=p/'ast/rewriter/arith_polynomial.go';s=k.read_text().replace('sides := [2][]ast.ASTHandle{}','''// A non-arithmetic atom is one monomial with no numeral coefficient
 // to move. A numeral on the right cannot share its power product.
 app, family, _, err := r.manager.AppIdentity(left)
 if err != nil {return ast.ASTHandle{}, ast.ASTHandle{}, false, err}
 if !app || family != r.family {
    numeral, err := r.isNumeral(right)
    if numeral || err != nil {return ast.ASTHandle{}, ast.ASTHandle{}, false, err}
 }
 sides := [2][]ast.ASTHandle{}''')
g=w/'atom.go';g.write_text(s)
for mode,jbase in [('atom','/tmp/g3-ticket-first/validation/final.json'),('arith-stage-atom','/tmp/g3-ticket-first/arith-stage.json')]:
 o=json.loads(Path(jbase).read_text());o['Replace'][str(k)]=str(g);j=w/(mode+'.json');j.write_text(json.dumps(o));build(j,mode)
src=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();src=src[src.index("rank=Path"):].replace("'g3','native'","'weak','atom'").replace("'arith-stages.csv'","'atom-stage.csv'").replace("'20'","'24'");exec(src)
subprocess.run(['python3',w/'whole.py','atom-whole','weak','atom'],env=dict(os.environ,CASES='14 15 2 3 4 12',ROUNDS='7',CPU='22'),check=True)
