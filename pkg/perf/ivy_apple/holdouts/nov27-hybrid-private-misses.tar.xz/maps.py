from pathlib import Path
import subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;k=p/'ast/ast_obj_map.go';s=k.read_text().replace('return &ObjMap{manager: m, table: make([]ObjMapEntry, objMapInitialCapacity)}','return &ObjMap{manager: m}',1)
s=s.replace('func (o *ObjMap) Capacity() int { return len(o.table) }','func (o *ObjMap) Capacity() int {if len(o.table)==0{return objMapInitialCapacity};return len(o.table)}')
s=s.replace('if (o.size+o.numDeleted)<<2 > len(o.table)*3 {', 'if len(o.table)==0{o.table=make([]ObjMapEntry,objMapInitialCapacity)} else if (o.size+o.numDeleted)<<2 > len(o.table)*3 {')
s=s.replace('func (o *ObjMap) indexHash(key ASTHandle, hash uint32) int {','func (o *ObjMap) indexHash(key ASTHandle, hash uint32) int {if len(o.table)==0{return -1};')
f=w/'maps.go.txt';f.write_text(s);o=json.loads((w/'final.json').read_text());o['Replace'][str(k)]=str(f);j=w/'maps.json';j.write_text(json.dumps(o))
subprocess.run(['go','test','-overlay',j,'./ast','-run','ObjMap','-count=1'],check=True)
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'maps','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
