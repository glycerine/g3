from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;o=json.loads((w/'final.json').read_text())
k=p/'api/api_order_boolean.go';f=w/'boolean-probe.go';f.write_text(k.read_text().replace('return b.search(p.source, m, k)','if k.HasSatisfyingAssignment(limit){return false,nil};return b.search(p.source, m, k)'))
o['Replace'][str(k)]=str(f);o['Replace'][str(p/'api/internal/order/boolean_witness_trial.go')]=str(w/'probe.go.txt')
j=w/'probe.json';j.write_text(json.dumps(o))
subprocess.run(['go','test','-overlay',j,'./api','-run','Order|GroundEqualities|Observed','-count=1'],check=True)
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'probe','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
