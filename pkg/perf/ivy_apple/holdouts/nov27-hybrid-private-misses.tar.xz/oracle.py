from pathlib import Path
import csv,collections,json,subprocess,os,statistics
p=Path.cwd();w=Path(__file__).resolve().parent;k=p/'api/api_order_abstraction.go';s=k.read_text()
s=s.replace('import (','import ("os";',1) if '"os"' not in s else s
a='func (p *orderProofState) proveWithGoal(maxSteps uint32, reuse bool, goal ast.ASTHandle) (proved bool, err error) {'
s=s.replace(a,a+'''
 diagnosticOrdinal++
 ordinal:=diagnosticOrdinal
 action:=diagnosticRow[ordinal-1]
 defer func(){if proved!=(action==0) || err!=nil{println("PRIVATE-DIFFERENT",ordinal,action,proved)}}()
''')
a='proved, err = p.proveAssertions(parent, assertions, maxSteps, reuse)'
s=s.replace(a,'''if action==2 && diagnosticMode=="top" || action!=0 && diagnosticMode=="all" {return false,nil}
 '''+a)
s+='\nvar diagnosticOrdinal int\nvar diagnosticMode=os.Getenv("PRIVATE_MODE")\nvar diagnosticRow=map[string][]byte{\n'
d=collections.defaultdict(lambda:collections.defaultdict(list))
for r in csv.DictReader((w/'proofs.csv').open()):d[r['case']][int(r['ordinal'])].append((r['outcome'],int(r['instructions'])))
for name,vs in d.items():
 ranking=sorted((statistics.median(i for _,i in v),j) for j,v in vs.items() if v[0][0]=='miss');top={j for _,j in ranking[-10:]};assert all(len(v)==3 and len(set(s for s,i in v))==1 for v in vs.values())
 actions=[0 if vs[j][0][0]=='proved' else 2 if j in top else 1 for j in range(1,len(vs)+1)]
 s+=json.dumps(name)+':{'+','.join(map(str,actions))+'},\n'
s+='}[os.Getenv("PRIVATE_CASE")]\n'
f=w/'order-oracle.go';f.write_text(s);o=json.loads((w/'final.json').read_text());o['Replace'][str(k)]=str(f);j=w/'oracle.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'oracle','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
with (w/'oracle.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case round mode same_transcript changed_private_outcomes instructions'.split())
 for nr in [2,3,4,12]:
  name=cases[nr-1];ref=rank/'compat'/str(nr)/'1/native';modes=['control','top','all']
  for i in range(5):
   for mode in modes[i%3:]+modes[:i%3]:
    stat=w/'oracle.stat';r=subprocess.run(['taskset','-c','12','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/'oracle',ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,PRIVATE_CASE=name,PRIVATE_MODE=mode,GOGC='100',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,timeout=90)
    lines=r.stderr.splitlines(keepends=True);different=[l for l in lines if l.startswith(b'PRIVATE-DIFFERENT ')]
    same=(r.returncode,r.stdout,b''.join(l for l in lines if l not in different))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    if not same:(w/('oracle-'+str(nr)+'-'+mode+'.stderr')).write_bytes(r.stderr)
    ins,=[x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100]
    out.writerow([name,i,mode,int(same),len(different),ins]);f.flush()
