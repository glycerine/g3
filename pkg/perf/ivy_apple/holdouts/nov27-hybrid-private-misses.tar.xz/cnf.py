from pathlib import Path
import json,subprocess,os,csv,gzip
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
k=p/'api/api_order_boolean.go';s=k.read_text();a='return b.search(p.source, m, k)';assert s.count(a)==1
s=s.replace(a,'''yes, e:=b.search(p.source,m,k)
 println("CNF",k.Vars,len(k.Clauses),yes)
 for _,cl:=range k.Clauses {println("ROW",cl[0],cl[1],cl[2])}
 return yes,e''')
f=w/'boolean-observer.go';f.write_text(s);o=json.loads((w/'final.json').read_text());o['Replace'][str(k)]=str(f);j=w/'cnf.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'cnf','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
with gzip.open(w/'residuals.jsonl.gz','wt') as out:
 for nr in [2,3,4,12,5,6,8,11]:
  name=cases[nr-1];ref=rank/'compat'/str(nr)/'1/native';codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
  r=subprocess.run([w/'cnf',ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True);err=[];hi=0;rows=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'CNF '):_,n,hi,y=l.decode().split();hi=int(hi);rows=[];assert hi>0
   elif l.startswith(b'ROW '):
    rows.append([j for j in map(int,l.split()[1:]) if j]);hi-=1
    if hi==0:out.write(json.dumps([name,int(n),y=='true',rows],separators=(',',':'))+'\n')
   else:err.append(l)
  assert hi==0 and (r.returncode,r.stdout,b''.join(err))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
