from pathlib import Path
import csv,json,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd();o=json.loads((w/'lazy.json').read_text())
for name,a,tag in [('smt_model_checker','c.candidateTerms=g','candidate'),('smt_model_checker_instances','c.populateCandidateTerms(g.rootValues','used')]:
 k=str(p/'smtcore'/(name+'.go'));s=Path(o['Replace'][k]).read_text();f=w/(name+'-count.go');f.write_text(s.replace(a,'println("INVERSE","'+tag+'",len(g.rootValues));'+a));o['Replace'][k]=str(f)
j=w/'count.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'count','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
with (w/'inverse.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','event','roots'])
 codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
 for n in [2,3,4,12,5,6,8,11]:
  name=cases[n-1];ref=rank/'compat'/str(n)/'1/native'
  r=subprocess.run([w/'count',ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True);assert r.returncode==codes[name];err=[]
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'INVERSE '):
    _,ev,num=line.decode().split();out.writerow([name,ev,num])
   else:err.append(line)
  assert (r.stdout,b''.join(err))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
