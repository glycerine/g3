from pathlib import Path
import os
w=Path(__file__).resolve().parent
os.environ['FOCUS_BIN']=str(w)
s=Path('/tmp/g3-ticket-focus/aggregate/study.py').read_text().replace("w.parent/'prices'","Path('/tmp/g3-ticket-focus/prices')").replace('for nr in [3,6,8]:','for nr in [2,3]:')
exec(s)
