from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go';s=f.read_text()
# Input for addGateClause is borrowed until that call returns.
s=s.replace('last := []SMTLiteral{literal}\n\t\tfor _, argument := range arguments {\n\t\t\tlast = append(last, argument.Negated())','last := gateOperands[:]\n        if len(arguments)+1 > len(last) {last=make([]SMTLiteral,len(arguments)+1)} else {last=last[:len(arguments)+1]}\n        last[0]=literal\n        for i, argument := range arguments {\n            last[i+1]=argument.Negated()')
s=s.replace('last := []SMTLiteral{literal.Negated()}\n\t\tlast = append(last, arguments...)','last:=gateOperands[:]\n        if len(arguments)+1 > len(last) {last=make([]SMTLiteral,len(arguments)+1)} else {last=last[:len(arguments)+1]}\n        last[0]=literal.Negated(); copy(last[1:],arguments)')
s=s.replace('add := func(values ...SMTLiteral)', 'var gateOperands [8]SMTLiteral\n    add := func(values ...SMTLiteral)')
s=s.replace('literals := make([]SMTLiteral, len(arguments))','var local [8]SMTLiteral\n            literals:=local[:];if len(arguments)>len(local){literals=make([]SMTLiteral,len(arguments))}else{literals=literals[:len(arguments)]}')
assert s.count('gateOperands')==3 and s.count('var local [8]SMTLiteral')==1
k=w/'operands.go.txt';k.write_text(s);o=json.loads(Path('/tmp/g3-proj/final.json').read_text());o['Replace'][str(f)]=str(k)
j=w/'operands.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'operands','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
