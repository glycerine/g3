from pathlib import Path
import os,csv,json,subprocess,collections
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
k=p/'api/api_order_boolean.go';s=k.read_text().replace('if k.HasSatisfyingAssignment(limit) || !limit.IncOffset(0) {','witness:=k.HasSatisfyingAssignment(limit);println("LIVE-WITNESS",k.Vars,len(k.Clauses),witness);if witness || !limit.IncOffset(0) {')
f=w/'live-witness.go';f.write_text(s);o=json.loads((w/'final.json').read_text());o['Replace'][str(k)]=str(f);j=w/'live-witness.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'live-witness','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
with (w/'live-witness.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case projection_calls witnesses'.split())
 for nr,name in enumerate(cases,1):
  ref=rank/'compat'/str(nr)/'1/native';r=subprocess.run([w/'live-witness',ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,timeout=120)
  lines=r.stderr.splitlines(keepends=True);obs=[l for l in lines if l.startswith(b'LIVE-WITNESS ')]
  assert (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith(b'LIVE-WITNESS ')))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),name
  out.writerow([name,len(obs),sum(l.split()[-1]==b'true' for l in obs)]);f.flush()
