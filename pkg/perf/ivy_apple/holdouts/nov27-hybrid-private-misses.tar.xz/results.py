from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
for file in ['inverse','operands-whole','lazy-whole','alloc']:
 d=collections.defaultdict(list)
 for r in csv.DictReader((w/(file+'.csv')).open()):
  d[r['case'],r.get('mode',r.get('event'))].append(tuple(float(r[k]) for k in ('instructions','ms','total_bytes','objects','roots') if k in r))
 print(file)
 for (case,m),v in d.items():
  if file=='inverse':
   print(case,m,len(v),sum(a[0] for a in v))
  elif file=='alloc':
   print(case,m,[int(statistics.median(x)) for x in zip(*v)])
  elif m!='base':
   base=d[case,'base'];print(case,m,len(v),[round(statistics.median(100*(a[i]/b[i]-1) for a,b in zip(v,base)),2) for i in [0,1]])
