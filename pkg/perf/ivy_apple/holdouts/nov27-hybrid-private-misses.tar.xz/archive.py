from pathlib import Path
import csv,tarfile,io
w=Path(__file__).resolve().parent;out=Path('perf/ivy_apple/holdouts/nov27-hybrid-private-misses.tar.xz')
with tarfile.open(out,'w:xz') as t:
 for f in sorted(w.rglob('*')):
  if f.is_symlink() or not f.is_file():continue
  if f.suffix in {'.csv','.go','.json','.txt','.py','.md','.log','.gz'}:t.add(f,str(f.relative_to(w)))
 for f in ['/tmp/g3-ticket-focus/aggregate/study.py','/tmp/g3-ticket-focus/prices/detail-g3-focus_trial.go','/tmp/g3-ticket-focus/prices/build.py','/tmp/g3-selective/final/verify.py','/tmp/g3-or-install/final/release.py','/tmp/g3-plan-budget/long.py','/tmp/g3-selective/final/overlay.json','/tmp/g3-selective/final/heap-main.go.txt']:
  t.add(f,'dependencies/'+str(Path(f).relative_to('/tmp')))
with tarfile.open(out) as t:
 def rows(n):return list(csv.DictReader(io.TextIOWrapper(t.extractfile(n))))
 for n,count in [('combined.csv',108),('live-witness.csv',228),('transfer.csv',70),('released/release-whole.csv',168),('oracle.csv',60)]:
  assert len(rows(n))==count,n
 for d in ['', 'maprelease/','released/']:
  assert all(x['status']=='match' for i in range(6) for x in rows(d+'verified/panel'+str(i)+'.csv'))
  assert sum(len(rows(d+'verified/panel'+str(i)+'.csv')) for i in range(6))==228
  for c in ['raft_no_assume','rfn2','dramc_nb2']:
   rs=rows(d+'verified/'+c+'/long.csv');assert len(rs)==6 and all(r['status']=='match' for r in rs)
