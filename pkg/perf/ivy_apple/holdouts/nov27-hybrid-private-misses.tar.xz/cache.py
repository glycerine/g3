from pathlib import Path
import json,subprocess,csv,os,collections
w=Path(__file__).resolve().parent;p=Path.cwd();k=p/'ast/ast_activity_cache.go';src=k.read_text()
src=src.replace('type ActivityCache struct {','type ActivityCache struct {\n probes,emptyProbes,hits,changed,inserts, peak int')
a=src.index('func (c *ActivityCache) Find(');b=src.index('func (c *ActivityCache) decRefs()',a)
src=src[:a]+src[a:b].replace('hash, e :=','c.probes++;hash, e :=').replace('if c.activityCacheEntries == nil {','if c.activityCacheEntries == nil {c.emptyProbes++;').replace('if !entry.accessed {','c.hits++;if k!=c.manager.external(entry.value){c.changed++};if !entry.accessed {')+src[b:]
a=src.index('func (c *ActivityCache) Insert(');b=src.index('func (c *ActivityCache) Find(',a)
src=src[:a]+src[a:b].replace('return nil\n}', 'c.inserts++;if c.table.size>c.peak {c.peak=c.table.size};return nil\n}')+src[b:]
src=src.replace('c.manager.BudgetField.Release(activityCacheBytes())','println("REWRITE-CACHE",c.probes,c.emptyProbes,c.hits,c.changed,c.inserts,c.peak);c.manager.BudgetField.Release(activityCacheBytes())')
src=src.replace('if c.table.size>c.peak {c.peak=c.table.size}', 'if int(c.table.size)>c.peak {c.peak=int(c.table.size)}')
f=w/'cache.go.txt';f.write_text(src);j=w/'cache.json';o=json.loads((w/'final.json').read_text());o['Replace'][str(k)]=str(f);j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'cache','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
with (w/'cache.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case probes empty_probes hits changed_hits inserts peak caches'.split())
 for n in [2,3,4,12]:
  name=cases[n-1];ref=rank/'compat'/str(n)/'1/native';r=subprocess.run([w/'cache',ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=True);rows=collections.Counter();err=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'REWRITE-CACHE '):rows[tuple(map(int,l.split()[1:]))]+=1
   else:err.append(l)
  assert (r.stdout,b''.join(err))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
  for stats,num in rows.items():o.writerow([name,*stats,num])
