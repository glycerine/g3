from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
for fn in ['combined','released/release-whole','maprelease/release-whole','release-whole','oracle']:
 rows=collections.defaultdict(lambda:collections.defaultdict(list))
 for r in csv.DictReader((w/(fn+'.csv')).open()):rows[r['case']][r['mode']].append([int(r['instructions']),float(r.get('ms',0))])
 print(fn)
 for n,vs in rows.items():
  ctrl=vs.get('base') or vs.get('control')
  print(n.split('/')[-1],[(m,len(v),round(statistics.median(x[0]for x in v)/1e9,3),round(statistics.median(x[1]for x in v)),round(statistics.median(100*(a[0]/b[0]-1)for a,b in zip(v,ctrl)),2))for m,v in vs.items()])
for f in ('alloc','release-alloc','maprelease/release-alloc','released/release-alloc'):
 d=collections.defaultdict(list)
 for r in csv.DictReader((w/(f+'.csv')).open()):
  if f=='alloc' and r['mode']!='base':continue
  d[r['case']].append([int(r[n])for n in ['objects','total_bytes']])
 print(f,[(n.split('/')[-1],tuple(map(statistics.median,zip(*vs))))for n,vs in d.items()])
