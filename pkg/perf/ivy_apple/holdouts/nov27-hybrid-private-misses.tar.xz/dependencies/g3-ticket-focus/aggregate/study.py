from pathlib import Path
import os,sys,subprocess,json,csv,collections
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);e=sys.argv[1];p=Path.cwd();front=p/'build/.boolean-enode-cost/frontend/goivy';files=json.loads((w.parent/'prices'/('detail-'+e+'.json')).read_text())['Replace']
key=next(k for k in files if k.endswith('/focus_trial.go'));s=Path(files[key]).read_text();a='if (batch!=4 && batch!=5) || (goal!=55 && goal!=56) {return func(string){}}; ';assert a in s;s=s.replace(a,'').replace('target:=fmt.Sprint(batch,"/",goal)==os.Getenv("TICKET_TARGET")','target:=true');f=w/(e+'-window.go');f.write_text(s);files[key]=str(f)
o=w/(e+'.json');o.write_text(json.dumps({'Replace':files}));subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/('aggregate-'+e),'./cmd/goivy_check'],cwd=front,check=True)
names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');cpu=sys.argv[2]
with (w/(e+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('input batch goal round slot calls instructions'.split())
 for i in range(3):
  for nr in [3,6,8]:
   ref=Path('/tmp/g3-reduction-rows/compat')/str(nr)/'1/native'
   r=subprocess.run(['taskset','-c',cpu,d/('aggregate-'+e),ex/names[nr-1]],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=d,capture_output=True,timeout=120)
   counts=collections.Counter();cost=collections.Counter();keep=[];stages=0
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'IC-PRICE '):
     _,k,n,v=l.split();counts[int(k)]+=int(n);cost[int(k)]+=int(v)
    elif l.startswith(b'STAGE-COUNT '):
     _,b,g,phase,n,empty,en,run,ns=l.split();assert en==run and phase==b'check';stages+=1
     for k in counts:out.writerow([nr,int(b),int(g),i,k,counts[k],cost[k]])
     counts.clear();cost.clear()
    else:keep.append(l)
   assert not counts and stages>100
   assert (r.returncode,r.stdout,b''.join(keep))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
