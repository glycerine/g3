from pathlib import Path
import subprocess,csv,os,json,collections
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
o=json.loads((w/'final.json').read_text());k=p/'api/api_order_abstraction.go';s=k.read_text();a='func (p *orderProofState) proveWithGoal(maxSteps uint32, reuse bool, goal ast.ASTHandle) (proved bool, err error) {'
observer=Path('/tmp/g3-ticket-focus/prices/detail-g3-focus_trial.go').read_text()
observer=observer[:observer.index('target:=')]+'''ivyThreadIoctl(fd, enable)
 return func(phase string){
 ivyThreadIoctl(fd, disable);total:=ivyThreadRead(fd);if total[1]-empty[1]!=total[2]-empty[2]{panic("multiplexed")}
 if err:=syscall.Close(int(fd));err!=nil{panic(err)};runtime.UnlockOSThread()
 fmt.Fprintln(os.Stderr,"PRIVATE-COST",batch,goal,phase,total[0]-empty[0])
 }
}
'''
observer=observer.replace('package goivy','package api').replace('"time"','').replace('if (batch!=4 && batch!=5) || (goal!=55 && goal!=56) {return func(string){}};','')
f=w/'private-observer.go';f.write_text(observer);o['Replace'][str(p/'api/private_observer_trial.go')]=str(f)
s=s.replace(a,a+'\n end:=startStage(int(p.expectedGoals),int(p.openingAttempts));defer func(){if err!=nil {end("error")} else if proved {end("proved")} else {end("miss")}}()')
f=w/'order-observer.go';f.write_text(s);o['Replace'][str(k)]=str(f);j=w/'proofs.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'proofs','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines()
with (w/'proofs.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case round ordinal batch_width opening_attempts outcome instructions'.split())
 for n in [2,3,4,12]:
  name=cases[n-1];ref=rank/'compat'/str(n)/'1/native'
  for i in range(3):
   r=subprocess.run(['taskset','-c','8',w/'proofs',ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=True);err=[];ordinal=0
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'PRIVATE-COST '):
     _,width,opening,result,ins=line.decode().split();ordinal+=1;out.writerow([name,i,ordinal,width,opening,result,ins])
    else:err.append(line)
   assert (r.stdout,b''.join(err))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
