from pathlib import Path
import json,re,csv,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();o=json.loads((w/'proofs.json').read_text())
k=p/'api/private_observer_trial.go';s=Path(o['Replace'][str(k)]).read_text().replace('ivyThreadIoctl(fd, enable)\n return','ivyThreadIoctl(fd, enable); phaseFD=fd\n return').replace('ivyThreadIoctl(fd, disable);total','phaseFD=0;ivyThreadIoctl(fd, disable);total')
s+='''
var phaseFD uintptr
func privateStage(label string) func() {
 fd:=phaseFD;if fd==0{return func(){}}
 a:=ivyThreadRead(fd);b:=ivyThreadRead(fd)
 return func(){c:=ivyThreadRead(fd);fmt.Fprintln(os.Stderr,"PRIVATE-PHASE",label,int64(c[0]-b[0])-int64(b[0]-a[0]))}
}
'''
f=w/'phase-observer.go';f.write_text(s);o['Replace'][str(k)]=str(f)
hooks={'api_ground_instances':['proveObserved','prove'],'api_goal_instances_check':['proveGoalInstances','checkProofPlan'],'api_verification_goal':['proveRelevantPremises'],'api_order_boolean':['checkBooleanInput','search'],'api_short_premises':['checkShortPremises'],'api_order_abstraction':['release']}
for file,names in hooks.items():
 k=p/'api'/(file+'.go');s=Path(o['Replace'].get(str(k),k)).read_text()
 for n in names:
  pat=r'(^func \([^\n]+?\) '+n+r'\([^\n]*? \{)$'
  s,num=re.subn(pat,lambda m:m[0]+'\n defer privateStage("'+n+'")()',s,flags=re.M);assert num==1,(n,num)
 if file=='api_order_abstraction':
  for a,label in [('bits, err := parsed.Project(parent, assertions, maxSteps)','projection'),('proof, applicable, err := p.transitionPremises.ForProof(parent, assertions, maxSteps)','transition'),('bits, err = order.ProjectGroundBooleans(parent, assertions, maxSteps)','ground-bool')]:
   assert s.count(a)==1;s=s.replace(a,'finishPhase:=privateStage("'+label+'");'+a+';finishPhase()')
 f=w/(file+'-phases.go');f.write_text(s);o['Replace'][str(k)]=str(f)
j=w/'stages.json';j.write_text(json.dumps(o))
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'stages','./cmd/goivy_check'],cwd=front,check=True)
s=(w/'proofs.py').read_text().split("rank=Path(")[-1];s="rank=Path("+s;s=s.replace("w/'proofs.csv'","w/'stages.csv'").replace("w/'proofs'","w/'stages'").replace('batch_width opening_attempts outcome instructions','batch_width opening_attempts outcome label instructions').replace('err=[];ordinal=0','err=[];ordinal=0;phases=[]').replace("if line.startswith(b'PRIVATE-COST '):","if line.startswith(b'PRIVATE-PHASE '):\n     _,phase,v=line.decode().split();phases.append([phase,v])\n    elif line.startswith(b'PRIVATE-COST '):").replace('out.writerow([name,i,ordinal,width,opening,result,ins])','out.writerows([name,i,ordinal,width,opening,result,phase,v] for phase,v in phases);phases.clear()')
exec(s)
