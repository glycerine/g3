from pathlib import Path
import csv,gzip,json,collections
w=Path(__file__).resolve().parent
def candidate(n,rows,neg,rev,last,cap):
 values=[neg]*(n+1)
 for sweep in range(cap+1):
  changed=False
  for row in reversed(rows) if rev else rows:
   if any(values[abs(a)]==(a>0) for a in row):continue
   if sweep==cap:return False
   a=next((a for a in (reversed(row) if last else row) if (a>0)!=neg),0)
   if not a:return False
   values[abs(a)]=not neg;changed=True
  if not changed:break
 # Exact evaluation independently checks every positive verdict.
 assert all(any(values[abs(a)]==(a>0) for a in row) for row in rows)
 return True
with gzip.open(w/'residuals.jsonl.gz','rt') as f,(w/'witness.csv').open('w') as dest:
 out=csv.writer(dest);out.writerow('case ordinal variables clauses refuted constant_false constant_true forward_false reverse_false forward_true reverse_true alternative_false alternative_true'.split())
 for i,line in enumerate(f):
  name,n,yes,rows=json.loads(line)
  tests=[candidate(n,rows,bool(neg),rev,last,cap) for neg,rev,last,cap in [(0,0,0,0),(1,0,0,0),(0,0,0,4),(0,1,0,4),(1,0,0,4),(1,1,0,4),(0,0,1,4),(1,0,1,4)]]
  assert not yes or not any(tests)
  out.writerow([name,i,n,len(rows),int(yes),*map(int,tests)])
