from pathlib import Path
import csv,collections,gzip,json
w=Path(__file__).resolve().parent
def probe(rows,n,phase,rev):
 occ=[[] for _ in range(2*n+1)];work=0
 for row in rows:
  for lit in row:occ[lit].append(row)
 v=[0]*(n+1);queue=[];head=0;decisions=0
 for i in range(n,0,-1) if rev else range(1,n+1):
  if v[i]:continue
  v[i]=phase;queue.append(i*phase);decisions+=1
  while head<len(queue):
   x=queue[head];head+=1
   for row in occ[-x]:
    work+=1;last=0
    for lit in row:
     a=v[abs(lit)]
     if a==0:
      if last:break
      last=lit
     elif (lit>0)==(a>0):break
    else:
     if not last:return False,work,decisions
     v[abs(last)]=1 if last>0 else -1;queue.append(last)
 assert all(any((v[abs(l)]>0)==(l>0) for l in row)for row in rows)
 return True,work,decisions
with gzip.open(w/'residuals.jsonl.gz','rt') as f,(w/'propagate.csv').open('w') as dest:
 o=csv.writer(dest);o.writerow('case ordinal refuted phase reverse satisfied visits decisions'.split())
 for i,line in enumerate(f):
  name,n,yes,rows=json.loads(line)
  for phase in [-1,1]:
   for rev in [False,True]:
    b,vis,dec=probe(rows,n,phase,rev);assert not b or not yes
    o.writerow([name,i,int(yes),phase,int(rev),int(b),vis,dec])
