from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent
o=json.loads(Path('/tmp/g3-proj/final.json').read_text())
for nm in ['smt_model_checker','smt_quantifier_manager','smt_model_checker_instances']:
 k=p/'smtcore'/(nm+'.go');s=k.read_text()
 if nm=='smt_model_checker':
  s=s.replace('valueTerms       map','candidateTerms *SMTModelGenerator\n\tvalueTerms       map',1)
  a=s.index('c.valueTerms = make(');s=s[:a]+'''c.populateCandidateTerms(rootValues,order)
    return nil
}
func(c *SMTModelChecker) populateCandidateTerms(rootValues map[*SMTEnode]ast.ASTHandle, order []*SMTEnode) {
    '''+s[a:];s=s.replace('\n\treturn nil\n}\n\nfunc NewSMTModelChecker','\n}\n\nfunc NewSMTModelChecker',1)
  s+='''
func(c *SMTModelChecker) checkCandidate(g *SMTModelGenerator, active []ast.ASTHandle)(bool,error){
 c.valueTerms=nil
 c.candidateTerms=g
 defer func(){c.candidateTerms=nil;c.valueTerms=nil}()
 return c.Check(g.model,active)
}
'''
 elif nm=='smt_quantifier_manager':
  a=s.index('if err = q.modelChecker.SetCandidateTerms');b=s.index('active, activeErr',a);s=s[:a]+s[b:];s=s.replace('q.modelChecker.Check(generator.model, active)','q.modelChecker.checkCandidate(generator, active)')
 else:
  a=s.index('for i, value := range bindings');s=s[:a]+'''if g:=c.candidateTerms;g!=nil && !fromInverse && len(bindings)>0 && c.valueTerms==nil {
   c.populateCandidateTerms(g.rootValues,g.rootValuesInTableOrder())
 }
 '''+s[a:]
 f=w/(nm+'-lazy.go');f.write_text(s);o['Replace'][str(k)]=str(f)
j=w/'lazy.json';j.write_text(json.dumps(o))
subprocess.run(['go','test','-overlay',j,'./smtcore','-run','ModelChecker|QuantifierManager','-count=1'],check=True)
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-o',w/'lazy','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
