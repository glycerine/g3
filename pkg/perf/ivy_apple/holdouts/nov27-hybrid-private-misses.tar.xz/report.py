from pathlib import Path
import csv,statistics,collections
w=Path(__file__).resolve().parent;cost=collections.defaultdict(lambda:[0,0])
for e in ['g3','z3']:
 for r in csv.DictReader((w/(e+'.csv')).open()):
  k=int(r['slot']);n={6:'or-operands',7:'root-clauses',14:'asserted'}.get(k) or ['variable','enode','gate','gate-clause','congruence','term'][k%8]
  c=cost[r['input'],e,n,r['round']];c[0]+=int(r['calls']);c[1]+=int(r['instructions'])
with (w/'op-summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('input operation g3_calls z3_calls g3_instructions z3_instructions fixed_volume_saving'.split())
 for nr,n in sorted({(k[0],k[2]) for k in cost}):
  es=[]
  for e in ['g3','z3']:
   groups=[cost[nr,e,n,str(i)] for i in range(3)];assert len(set(c for c,v in groups))==1,(e,nr,n,groups)
   es.append((groups[0][0],statistics.median(v for c,v in groups)))
  (a,b),(c,d)=es;out.writerow([nr,n,a,c,b,d,round(b-a*d/c)])
