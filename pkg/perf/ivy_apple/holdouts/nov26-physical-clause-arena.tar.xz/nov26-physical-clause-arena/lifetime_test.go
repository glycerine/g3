package arena

import (
	"encoding/binary"
	"runtime"
	"testing"
)

func TestTrialClausePagesReclaimAndReopen(t *testing.T) {
	budget := NewBudget(1 << 24)
	a, err := NewTrialClausePages(SmallBytesConfig{Descriptors: Config{Budget: budget}})
	if err != nil {
		t.Fatal(err)
	}
	const size = 40
	refs := make([]SmallBytesRef, 80)
	for i := range refs {
		refs[i], err = a.Allocate(size)
		if err != nil {
			t.Fatal(err)
		}
		if err := a.WriteUint32LE(refs[i], 0, uint32(i+1)); err != nil {
			t.Fatal(err)
		}
	}
	original := refs[8]
	if err := a.Deallocate(size, original); err != nil {
		t.Fatal(err)
	}
	refs[8], err = a.Allocate(size)
	if err != nil || refs[8].Slot != original.Slot || refs[8].Generation <= original.Generation {
		t.Fatal("free-list reuse did not advance generation", original, refs[8], err)
	}
	for _, ref := range refs[:40] {
		if err := a.Deallocate(size, ref); err != nil {
			t.Fatal(err)
		}
	}
	if s := a.Stats(); s.Chunks != 2 || s.Live != 40 {
		t.Fatal("releasing two size-class pages should keep one warm", s)
	}
	charged := budget.Used()
	budget.FailAfter(0)
	if _, err := a.Allocate(size); err == nil || charged != budget.Used() || a.Stats().Live != 40 {
		t.Fatal("refused page reactivation changed state", err)
	}
	budget.FailAfter(-1)
	for _, old := range refs[8:40] {
		ref, err := a.Allocate(size)
		if err != nil || ref.Slot != old.Slot || ref.Generation <= old.Generation {
			t.Fatal("page reactivation lost slot or generation", ref, old, err)
		}
		if _, err := a.Borrow(old); err != ErrInvalidSlot {
			t.Fatal("stale reference survived page reactivation", old, err)
		}
	}
	for i, ref := range refs[40:] {
		if got, err := a.ReadUint32LE(ref, 0); err != nil || got != uint32(i+41) {
			t.Fatal("neighboring live page changed", i, got, err)
		}
	}
	a.Close()
	if budget.Used() != 0 {
		t.Fatal("budget remained charged after close", budget.Used())
	}
}

func TestTrialClausePagesRetireLastGeneration(t *testing.T) {
	budget := NewBudget(1 << 24)
	a, err := NewTrialClausePages(SmallBytesConfig{Descriptors: Config{Budget: budget}})
	if err != nil {
		t.Fatal(err)
	}
	// This size places one block on each page in every lifetime variant.
	const size = 8192
	old, err := a.Allocate(size)
	if err != nil {
		t.Fatal(err)
	}
	old.Generation = Generation(^uint32(0))
	page := &a.pages[0]
	page.maximum = uint32(old.Generation)
	binary.LittleEndian.PutUint32(page.data, uint32(old.Generation))
	if err := a.Deallocate(size, old); err != nil {
		t.Fatal(err)
	}
	next, err := a.Allocate(size)
	if err != nil || next.Slot == old.Slot || a.IsLive(old) {
		t.Fatal("a retired generation reentered the free list", old, next, err)
	}
	a.Close()
	if budget.Used() != 0 {
		t.Fatal("retired page remained charged after close", budget.Used())
	}
}

type trialClauseAllocator interface {
	Allocate(uint32) (SmallBytesRef, error)
	Deallocate(uint32, SmallBytesRef) error
	Close()
}

func BenchmarkTrialClauseMixedPopulation(b *testing.B) {
	for _, mode := range []string{"smallbytes", "physical"} {
		for _, shape := range []string{"mixed", "wide-tail"} {
			b.Run(mode+"/"+shape, func(b *testing.B) {
				const workers, base, scoped = 24, 32, 2048
				stores := make([]trialClauseAllocator, workers)
				refs := make([]SmallBytesRef, workers*scoped)
				sizes := make([]uint32, scoped)
				for i := range sizes {
					width := 3 + i%13
					if shape == "wide-tail" && i%4 == 0 {
						width = 64 + i/4
					}
					sizes[i] = uint32(width*4 + 20)
				}
				for i := range stores {
					cfg := SmallBytesConfig{Descriptors: Config{Budget: NewBudget(1 << 29)}}
					var err error
					if mode == "smallbytes" {
						stores[i], err = NewSmallBytes(cfg)
					} else {
						stores[i], err = NewTrialClausePages(cfg)
					}
					if err != nil {
						b.Fatal(err)
					}
					defer stores[i].Close()
					for range base {
						if _, err := stores[i].Allocate(32); err != nil {
							b.Fatal(err)
						}
					}
				}
				heap := func() int64 {
					runtime.GC()
					runtime.GC()
					var mem runtime.MemStats
					runtime.ReadMemStats(&mem)
					return int64(mem.HeapAlloc)
				}
				before := heap()
				b.ResetTimer()
				for j := range b.N {
					for i := range refs {
						var err error
						refs[i], err = stores[i/scoped].Allocate(sizes[i%scoped])
						if err != nil {
							b.Fatal(err)
						}
					}
					if j == b.N-1 {
						b.StopTimer()
						b.ReportMetric(float64(heap()-before)/workers, "peak-B/worker")
						b.StartTimer()
					}
					for i := len(refs) - 1; i >= 0; i-- {
						if err := stores[i/scoped].Deallocate(sizes[i%scoped], refs[i]); err != nil {
							b.Fatal(err)
						}
					}
				}
				b.StopTimer()
				b.ReportMetric(float64(heap()-before)/workers, "warm-B/worker")
			})
		}
	}
}
