package arena

// Experimental size-class arena for SAT clauses. The slot is its physical
// page and position. A live generation is stored adjacent to its payload.

import (
	"encoding/binary"
	"reflect"
)

const clausePageShift = 6
const clausePageSlots = 1 << clausePageShift

type trialClausePage struct {
	data          []byte
	stride, taken uint32
}

type trialClauseClass struct {
	page uint32 // one-based
	free Slot
}

type TrialClausePages struct {
	pages         []trialClausePage
	classes       map[uint32]trialClauseClass
	budget        *Budget
	compat        *SmallBytes
	directory     uint64
	requested     uint64
	bindings      uint64
	live, free    uint32
	closed        bool
}

func NewTrialClausePages(c SmallBytesConfig) (*TrialClausePages, error) {
	a := &TrialClausePages{budget: c.Descriptors.Budget}
	if c.DirectOnly || c.ChunkSize != 0 || c.Alignment != 0 || c.Descriptors.PageSize != 0 || c.Descriptors.SlotLimit != 0 {
		var err error
		a.compat, err = NewSmallBytes(c)
		return a, err
	}
	if err := a.budget.Reserve(uint64(reflect.TypeOf(TrialClausePages{}).Size())); err != nil {
		return nil, err
	}
	return a, nil
}

func (a *TrialClausePages) addPage(stride uint32) error {
	if uint64(len(a.pages)) >= uint64(^uint32(0))/clausePageSlots {
		return ErrSlotLimit
	}
	count := max(1, min(clausePageSlots, 8176/stride))
	bytes := uint64(count) * uint64(stride)
	pageCapacity := cap(a.pages)
	var directory uint64
	if len(a.pages) == pageCapacity {
		pageCapacity = max(1, pageCapacity*2)
		directory = uint64(pageCapacity) * uint64(reflect.TypeOf(trialClausePage{}).Size())
	}
	if bytes > uint64(^uint(0)>>1) || directory > uint64(^uint(0)>>1) {
		return ErrBounds
	}
	if err := a.budget.Reserve(bytes + directory); err != nil {
		return err
	}
	if directory != 0 {
		pages := make([]trialClausePage, len(a.pages), pageCapacity)
		copy(pages, a.pages)
		a.pages = pages
		a.budget.Release(a.directory)
		a.directory = directory
	}
	a.pages = append(a.pages, trialClausePage{data: make([]byte, int(bytes)), stride: stride})
	a.bindings += bytes
	return nil
}

func (a *TrialClausePages) Allocate(size uint32) (SmallBytesRef, error) {
	if a.compat != nil {
		return a.compat.Allocate(size)
	}
	if a.closed {
		return SmallBytesRef{}, ErrClosed
	}
	if size == 0 {
		return SmallBytesRef{}, nil
	}
	if size < 8 || size&3 != 0 || uint64(size)+4 > uint64(^uint32(0)) {
		return SmallBytesRef{}, ErrConfig
	}
	if a.classes == nil {
		a.classes = make(map[uint32]trialClauseClass)
	}
	stride := size + 4
	class := a.classes[size]
	if slot := class.free; slot != 0 {
		n := uint32(slot) - 1
		p := &a.pages[n>>clausePageShift]
		start := (n & (clausePageSlots - 1)) * stride
		body := p.data[start : start+12]
		class.free = Slot(binary.LittleEndian.Uint32(body[4:8]))
		gen := binary.LittleEndian.Uint32(body[8:12])
		binary.LittleEndian.PutUint32(body, gen)
		a.classes[size] = class
		a.free--
		a.live++
		a.requested += uint64(size)
		return SmallBytesRef{slot, Generation(gen)}, nil
	}
	if class.page == 0 || uint64(a.pages[class.page-1].taken)*uint64(stride) == uint64(len(a.pages[class.page-1].data)) {
		if err := a.addPage(stride); err != nil {
			return SmallBytesRef{}, err
		}
		class.page = uint32(len(a.pages))
		a.classes[size] = class
	}
	page := &a.pages[class.page-1]
	n := (class.page-1)*clausePageSlots + page.taken
	binary.LittleEndian.PutUint32(page.data[page.taken*stride:], 1)
	page.taken++
	a.live++
	a.requested += uint64(size)
	return SmallBytesRef{Slot(n + 1), 1}, nil
}

func (a *TrialClausePages) Borrow(r SmallBytesRef) ([]byte, error) {
	if a.compat != nil {
		return a.compat.Borrow(r)
	}
	if a.closed {
		return nil, ErrClosed
	}
	if r == (SmallBytesRef{}) {
		return nil, nil
	}
	n := uint32(r.Slot) - 1
	page := n >> clausePageShift
	if uint64(page) >= uint64(len(a.pages)) || r.Generation == 0 {
		return nil, ErrInvalidSlot
	}
	p := &a.pages[page]
	index := n & (clausePageSlots - 1)
	if index >= p.taken {
		return nil, ErrInvalidSlot
	}
	start := index * p.stride
	end := start + p.stride
	row := p.data[start:end:end]
	if binary.LittleEndian.Uint32(row) != uint32(r.Generation) {
		return nil, ErrInvalidSlot
	}
	return row[4:], nil
}

func (a *TrialClausePages) IsLive(r SmallBytesRef) bool {
	data, err := a.Borrow(r)
	return err == nil && data != nil
}

func (a *TrialClausePages) ReadUint32LE(r SmallBytesRef, offset uint32) (uint32, error) {
	data, err := a.Borrow(r)
	if err != nil {
		return 0, err
	}
	if uint64(offset)+4 > uint64(len(data)) {
		return 0, ErrBounds
	}
	return binary.LittleEndian.Uint32(data[offset:]), nil
}

func (a *TrialClausePages) WriteUint32LE(r SmallBytesRef, offset, value uint32) error {
	data, err := a.Borrow(r)
	if err != nil {
		return err
	}
	if uint64(offset)+4 > uint64(len(data)) {
		return ErrBounds
	}
	binary.LittleEndian.PutUint32(data[offset:], value)
	return nil
}

func (a *TrialClausePages) Deallocate(size uint32, r SmallBytesRef) error {
	if a.compat != nil {
		return a.compat.Deallocate(size, r)
	}
	if a.closed {
		return ErrClosed
	}
	if size == 0 {
		return nil
	}
	data, err := a.Borrow(r)
	if err != nil {
		return err
	}
	if data == nil {
		return ErrInvalidSlot
	}
	if uint64(len(data)) != uint64(size) {
		return ErrSizeMismatch
	}
	n := uint32(r.Slot) - 1
	p := &a.pages[n>>clausePageShift]
	start := (n & (clausePageSlots - 1)) * p.stride
	binary.LittleEndian.PutUint32(p.data[start:], 0)
	if r.Generation < Generation(^uint32(0)) {
		class := a.classes[size]
		binary.LittleEndian.PutUint32(data, uint32(class.free))
		binary.LittleEndian.PutUint32(data[4:], uint32(r.Generation)+1)
		class.free = r.Slot
		a.classes[size] = class
		a.free++
	}
	a.live--
	a.requested -= uint64(size)
	return nil
}

func (a *TrialClausePages) Stats() SmallBytesStats {
	if a.compat != nil {
		return a.compat.Stats()
	}
	if a.closed {
		return SmallBytesStats{}
	}
	return SmallBytesStats{OwnerBytes: uint64(reflect.TypeOf(TrialClausePages{}).Size()),
		Live: a.live, FreeObjects: a.free, Chunks: uint32(len(a.pages)), PayloadBytes: a.bindings,
		RequestedBytes: a.requested, DirectoryBytes: a.directory, SourceAllocationBytes: a.requested,
		WastedBytes: a.bindings - a.requested}
}

func (a *TrialClausePages) Close() {
	if a.compat != nil {
		a.compat.Close()
		return
	}
	if a.closed {
		return
	}
	a.budget.Release(a.bindings + a.directory + uint64(reflect.TypeOf(TrialClausePages{}).Size()))
	a.pages = nil
	a.classes = nil
	a.closed = true
}
