"""Use the existing direct large-clause storage beside the physical pages."""

import json
from pathlib import Path
import subprocess


pkg = Path.cwd()
out = Path(__file__).resolve().parent
allocator = (out / "sat_clause_storage.go").read_text()
old = "if satClauseWideExtent(bytes) {"
assert allocator.count(old) == 1
allocator = allocator.replace(old, "if satClauseWideExtent(bytes) || bytes >= 248 && a.storage.UsesPhysicalPages() {")
target = out / "hybrid-sat_clause_storage.go"
target.write_bytes(subprocess.check_output(["gofmt"], input=allocator.encode()))
arena = out / "hybrid-arena.go"
arena.write_text((out / "lifetime-wide-heads.go").read_text() +
                 "\nfunc (a *TrialClausePages) UsesPhysicalPages() bool { return a.compat == nil }\n")
overlay = out / "hybrid.json"
overlay.write_text(json.dumps({"Replace": {
    str(pkg / "sat/sat_clause_storage.go"): str(target),
    str(pkg / "arena/arena_trial_clause_pages.go"): str(arena),
}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-overlay", str(overlay),
                "-o", str(out / "hybrid"), "./cmd/g3"], check=True)
