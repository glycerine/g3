# Physical clause slots in the SAT arena

The baseline is g3 at `13a2fdf50` and the native executable is this fork's `../build/z3`. Run the scripts from `pkg/` with extracted files in a writable output directory. `build.py` constructs and builds the original three page-size variants and a plain baseline. The other scripts build incremental overlays. They leave the working source files alone.

```sh
out=/path/to/unpacked/nov26-physical-clause-arena
python3 "$out/build.py"
python3 "$out/lifetime.py"
python3 "$out/lifetime.py" --wide
python3 "$out/lifetime.py" --wide --heads
python3 "$out/hybrid.py"
python3 "$out/measure.py" --cpu 11 --rounds 5 \
    --case "unsat:$out/fixtures/random-208-3.cnf" \
    --case "sat:$out/fixtures/random-208-4.cnf" \
    --case "sat:$out/fixtures/planted3.cnf:stdin" \
    --case "sat:$out/fixtures/planted8.cnf:stdin" \
    "base=$out/base" "hybrid=$out/hybrid" "z3=../build/z3"
```

The driver checks hardware counter coverage, verifies submitted satisfying assignments against the input clauses, and compares decision, conflict and propagation counters. Add `--solver-arg=-v:2` for the two pigeonhole inputs. This disables the one-shot g3 capacity proof, so those rows time ordinary CDCL. All measurements use the same CPU for a given series and `GOMAXPROCS=1`.

Build the test fixtures by mapping `lifetime_test.go` to `pkg/arena/arena_trial_clause_pages_test.go` and `sat_population_test.go` to `pkg/sat/arena_trial_sat_population_test.go` in their respective JSON overlays. Overlay the SAT fixture alone for the plain baseline. Use `-run '^TestTrialClausePages'` with the lifetime variants to exercise reclamation and refused reactivation. The hybrid SAT suites also map `sat_scc_test.go` to the audit updated by `hybrid-owner-audit.patch`. The audit counts live direct clauses as well as inline clauses and still checks the complete budget.

For the arena fixture, use `-bench '^BenchmarkTrialClauseMixedPopulation$' -benchtime=1x -count=7 ./arena`. For the SAT fixture, use `-bench '^BenchmarkTrialSATClauseMixedChurn$' -benchtime=3x -count=7 ./sat`. The meter reports forced-GC deltas beyond 32 retained ternaries per worker and excludes the snapshots from measured time. The 24 stores are driven serially. The dense borrow control uses the checked-in `BenchmarkSATClauseBorrowPopulation` with `-benchtime=700x -count=5 ./sat`.

The lifetime variant retains a warm empty pooled page per size and frees the rest. The wide variant gives uncommon large strides an initial single-row page and releases all empty wide pages. The heads variant also replaces the small-size map lookups with dense class heads. The hybrid reuses the existing SAT direct allocator for widths at and above the ordinary `SmallBytes` direct threshold. Temporary or explicitly configured allocators use the existing compatibility path. These overlays are research code.
