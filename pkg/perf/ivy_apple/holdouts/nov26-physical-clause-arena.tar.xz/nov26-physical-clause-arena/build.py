"""Build the baseline and size-class page overlays from pkg/."""

import json
from pathlib import Path
import subprocess
import sys


pkg = Path.cwd()
out = Path(__file__).resolve().parent
text = (out / "clause_pages.go").read_text()
allocator = pkg / "sat/sat_clause_storage.go"
code = allocator.read_text().replace("storage                                *arena.SmallBytes",
                                     "storage                                *arena.TrialClausePages")
code = code.replace("arena.NewSmallBytes(c.Storage)", "arena.NewTrialClausePages(c.Storage)")
assert "storage                                *arena.TrialClausePages" in code
target = out / allocator.name
target.write_bytes(subprocess.check_output(["gofmt"], input=code.encode()))


def build(name, overlay=None):
    command = ["go", "build", "-pgo=off", "-buildvcs=false"]
    if overlay is not None:
        command += ["-overlay", str(overlay)]
    subprocess.run(command + ["-o", str(out / name), "./cmd/g3"], check=True)


for name in sys.argv[1:] or ("base", "pages32", "pages64", "pages128"):
    if name == "base":
        build(name)
    else:
        slots = int(name.removeprefix("pages"))
        file = out / f"{name}.go"
        data = text.replace("const clausePageShift = 6", f"const clausePageShift = {slots.bit_length()-1}")
        file.write_bytes(subprocess.check_output(["gofmt"], input=data.encode()))
        overlay = out / f"{name}.json"
        overlay.write_text(json.dumps({"Replace": {
            str(allocator): str(target),
            str(pkg / "arena/arena_trial_clause_pages.go"): str(file),
        }}))
        build(name, overlay)
