"""Build a variant that reclaims empty pages and advances their generation."""

import json
from pathlib import Path
import subprocess
import sys


pkg = Path.cwd()
out = Path(__file__).resolve().parent
source = (out / "clause_pages.go").read_text()
source = source.replace("stride, taken uint32", """stride, count uint32
    taken, live uint32
    firstFree, next uint32 // one-based slot and page
    epoch, maximum uint32
    _ uint64""")
source = source.replace("page uint32 // one-based\n\tfree Slot", "first, warm, created uint32")
source = source.replace("func (a *TrialClausePages) addPage(stride uint32) error {",
                        "func (a *TrialClausePages) addPage(stride, preferred uint32) error {")
source = source.replace("min(clausePageSlots, 8176/stride)", "min(preferred, 8176/stride)")
source = source.replace("stride: stride})", "stride: stride, count: count, epoch: 1, maximum: 1})")
source = source.replace("\tlive, free    uint32", "\tlive, free    uint32\n\tresident uint32")
source = source.replace("\ta.bindings += bytes\n", "\ta.bindings += bytes\n\ta.resident++\n")
start = source.index("\tif slot := class.free;")
end = source.index("\n}\n\nfunc (a *TrialClausePages) Borrow", start)
source = source[:start] + """    if class.first == 0 {
        preferred := uint32(clausePageSlots)
        if class.created == 0 {
            preferred = 8
        } else if class.created == 1 {
            preferred = 32
        }
        if err := a.addPage(stride, preferred); err != nil {
            return SmallBytesRef{}, err
        }
        class.first = uint32(len(a.pages))
        class.created++
    }
    pageID := class.first
    page := &a.pages[pageID-1]
    if page.data == nil {
        bytes := uint64(page.count) * uint64(stride)
        if err := a.budget.Reserve(bytes); err != nil {
            return SmallBytesRef{}, err
        }
        page.data = make([]byte, int(bytes))
        a.bindings += bytes
        a.resident++
    }
    if class.warm == pageID {
        class.warm = 0
    }
    var index uint32
    generation := page.epoch
    if page.firstFree != 0 {
        index = page.firstFree - 1
        row := page.data[index*stride : index*stride+12]
        page.firstFree = binary.LittleEndian.Uint32(row[4:])
        generation = binary.LittleEndian.Uint32(row[8:])
        a.free--
    } else {
        index = page.taken
        page.taken++
    }
    binary.LittleEndian.PutUint32(page.data[index*stride:], generation)
    page.maximum = max(page.maximum, generation)
    page.live++
    if page.firstFree == 0 && page.taken == page.count {
        class.first = page.next
        page.next = 0
    }
    a.classes[size] = class
    a.live++
    a.requested += uint64(size)
    return SmallBytesRef{Slot((pageID-1)*clausePageSlots+index+1), Generation(generation)}, nil""" + source[end:]
start = source.index("\tif r.Generation < Generation(^uint32(0))")
end = source.index("\ta.live--", start)
source = source[:start] + """    class := a.classes[size]
    pageID := n>>clausePageShift + 1
    if r.Generation < Generation(^uint32(0)) {
        if p.firstFree == 0 && p.taken == p.count {
            p.next = class.first
            class.first = pageID
        }
        binary.LittleEndian.PutUint32(data, p.firstFree)
        binary.LittleEndian.PutUint32(data[4:], uint32(r.Generation)+1)
        p.firstFree = (n & (clausePageSlots-1)) + 1
        a.free++
    }
    p.live--
    if p.live == 0 && p.maximum != ^uint32(0) {
        if p.count == 1 || class.warm != 0 {
            bytes := uint64(len(p.data))
            a.bindings -= bytes
            a.resident--
            a.free -= p.taken
            p.data = nil
            p.firstFree, p.taken = 0, 0
            p.epoch = p.maximum + 1
            a.budget.Release(bytes)
        } else {
            class.warm = pageID
        }
    }
    a.classes[size] = class
""" + source[end:]
source = source.replace("Chunks: uint32(len(a.pages))", "Chunks: a.resident")
wide = "--wide" in sys.argv[1:]
name = "lifetime-wide" if wide else "lifetime"
if wide:
    source = source.replace("if err := a.addPage(stride, preferred);", """if size >= 248 {
        if class.created == 0 {
            preferred = 1
        } else if class.created == 1 {
            preferred = 4
        }
    }
    if err := a.addPage(stride, preferred);""")
    source = source.replace("if p.count == 1 || class.warm != 0 {", "if size >= 248 || class.warm != 0 {")
if "--heads" in sys.argv[1:]:
    name += "-heads"
    source = source.replace("\tclasses       map[uint32]trialClauseClass", "\tclasses       map[uint32]trialClauseClass\n\tsmall [62]trialClauseClass")
    source = source.replace("if a.classes == nil {", "if size >= 248 && a.classes == nil {")
    source = source.replace("class := a.classes[size]", """var wide trialClauseClass
    class := a.class(size, &wide)""")
    source = source.replace("a.classes[size] = class", """if size >= 248 {
        a.classes[size] = wide
    }""")
    source += """
func (a *TrialClausePages) class(size uint32, wide *trialClauseClass) *trialClauseClass {
    if size < 248 {
        return &a.small[size>>2]
    }
    *wide = a.classes[size]
    return wide
}
"""
target = out / (name + ".go")
target.write_bytes(subprocess.check_output(["gofmt"], input=source.encode()))
overlay = out / (name + ".json")
overlay.write_text(json.dumps({"Replace": {
    str(pkg / "sat/sat_clause_storage.go"): str(out / "sat_clause_storage.go"),
    str(pkg / "arena/arena_trial_clause_pages.go"): str(target),
}}))
if "--overlay-only" not in sys.argv[1:]:
    subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-overlay", str(overlay),
                    "-o", str(out / name), "./cmd/g3"], cwd=pkg, check=True)
