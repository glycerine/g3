from driver import panel
def patch(pkg,name):
    for f,tag,needle,ret in [('quantified_goal.go','project','if len(assertions) < 2','return nil,nil'),('ground_premises.go','units','if len(assertions) < 2','return false,nil')]:
        p=pkg/'api/internal/order'/f;s=p.read_text()
        if name in (tag,'both'):
            assert s.count(needle)==1;s=s.replace(needle,'if len(assertions)>=0{'+ret+'};'+needle)
        yield p,s
def run(s):
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%4:]+modes[:i%4]").replace('for mode in modes:w.writerow','for mode in order:w.writerow')
    return s.replace('range(5):','range(4):').replace('((1,3),(4,8),(6,227))','((4,),(8,),(3,6))')
if __name__=='__main__':panel(['base','units','project','both'],patch,run)
