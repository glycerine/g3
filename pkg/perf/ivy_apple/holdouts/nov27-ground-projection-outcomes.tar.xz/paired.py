from driver import panel
from observe import patch as observe_patch,run as census
from pathlib import Path
def patch(pkg,name):return []
def run(s):
    source=next(observe_patch(Path.cwd(),'probe'))[1]
    instrument=source[source.index('type StudySample struct'):]
    s=census(s)
    a=s.index('    for p,src in patch')
    s=s[:a]+"""    v=dst.read_text();v=v.replace('import (','import ("runtime";"syscall";"unsafe";',1)
    v=v.replace('if proveGoal(zCond) {','counter:=StudyStart();proved:=proveGoal(zCond);counter.End("frontend","proveGoal",proved,0,0);if proved {')
    marker='if s.opts.Incremental {\\n\\t\\t\\t\\t\\tz3solver.Push()';v=v.replace(marker,'if s.opts.Incremental {\\n counter:=StudyStart();z3solver.Push();counter.End("frontend","push",true,0,0)')
    v=v.replace('res, err := s.decideZ3With(z3solver, finalCheck)','counter:=StudyStart();res, err := s.decideZ3With(z3solver, finalCheck);counter.End("frontend","decide",res==smt.Unsat,0,0)')
    dst.write_text(v+EXTRA)
""".replace('EXTRA',repr('\n'+instrument))+s[a:]
    a=s.index('    for unit in (');s=s[:a]+'''    for mode in ['base','native']:
        for i in range(2):
            os.environ.update(GROUND_UNIT='instructions',GROUND_SCOPE='outer',GROUND_OUT=str(out/f'{case}-{mode}-{i}.csv'))
            run(case,mode,cpus[0],False)
'''
    return s
if __name__=='__main__':panel(['base','native'],patch,run)
