from collections import defaultdict
import csv
from pathlib import Path
root=Path(__file__).resolve().parent
def rows(p):return list(csv.DictReader(p.open()))
def key(r):return int(r['batch']),int(r['goal'])
for c in [4,8,3,6]:
    fallback={key(r) for r in rows(root/'final'/f'{c}-instructions-outer-0.csv') if r['reason']=='quantified-sat'}
    for rep in [0,1]:
        totals=[]
        for mode in ['base','native']:
            data=rows(root/'paired'/f'{c}-{mode}-{rep}.csv')
            by=defaultdict(int)
            for r in data:
                if r['reason']=='decide':by[key(r)]+=int(r['value'])
            totals.append(by)
        g,z=totals
        keys=fallback if fallback else set(g)|set(z)
        print(c,rep,len(keys),*[round(sum(d[k] for k in keys)/1e6,2) for d in totals],[(k,round((g[k]-z[k])/1e6,2)) for k in sorted(keys,key=lambda k:z[k]-g[k])[:6]])
