from pathlib import Path
import tarfile
def panel(modes,patch,run=None):
    with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/panel.py').read().decode()
    s=s.replace("for name in ('base','trial'):","for name in modes:")
    a=s.index("    if name=='trial':");b=s.index('    j=d/',a)
    s=s[:a]+"""    for p,src in patch(pkg,name):
        file=d/(name+p.name);file.write_text(src);mp[str(p)]=str(file)
"""+s[b:]
    if run:s=run(s)
    exec(compile(s,'panel','exec'),dict(globals(),modes=modes,patch=patch))
