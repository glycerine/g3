import csv
from pathlib import Path
from driver import panel
def patch(pkg,name):
    if name=='base':return
    p=pkg/'api/api_order_abstraction.go';s=p.read_text();needle='bits, err := parsed.Project'
    yield p,s.replace(needle,'if StudyProjectionMiss {return false,nil};'+needle)+'\nvar StudyProjectionMiss bool\n'
def run(s):
    a=s.index('    j=d/')
    o="""    if name=='trial':
        path=Path(mp[str(frontend/'z3bridge_solver_model.go')]);src=path.read_text()
        src=src.replace('import (','import (\\nstudyapi "github.com/glycerine/g3/pkg/api"\\n',1)
        marker='overallResult := smt.Unsat';i=src.index(marker,src.index('func (s *Solver) GetSmallModelWithCond('));src=src[:i]+'studyBatch++;'+src[i:]
        src=src.replace('for index, fc := range finalCond {','for index, fc := range finalCond {studyapi.StudyProjectionMiss=studyMiss[[3]int{studyCase,studyBatch,index+1}];')
        src+='\\nvar studyBatch,studyCase int\\nfunc init(){fmt.Sscan(os.Getenv("GROUND_CASE"),&studyCase)}\\nvar studyMiss=map[[3]int]bool{\\n'
        for case in (3,4,6,8):
            census=Path(os.environ['CENSUS'])/f'{case}-instructions-outer-0.csv'
            for row in csv.DictReader(census.open()):
                if row['op']=='boolean' and row['reason']=='quantified-sat':
                    src+='{'+str(case)+','+row['batch']+','+row['goal']+'}:true,\\n'
        path.write_text(src+'}\\n')
"""
    return (s[:a]+o+s[a:]).replace("GOMAXPROCS='1'","GROUND_CASE=str(case),GOMAXPROCS='1'").replace('((1,3),(4,8),(6,227))','((3,),(4,8),(6,))')
if __name__=='__main__':panel(['base','trial'],patch,run)
