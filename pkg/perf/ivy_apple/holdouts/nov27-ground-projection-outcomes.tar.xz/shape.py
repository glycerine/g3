from driver import panel
from observe import edit,run as census
def patch(pkg,name):
    p=pkg/'api/internal/order/quantified_goal.go';s=p.read_text()
    a='problem, err := g.problem(assertions, false, p)';s=edit(s,a,a+'''
if err==nil{goal:=assertions[len(assertions)-1]; id:=g.sourceIDs[goal];if id==0 && g.parsedPremises!=nil{id=g.parsedPremises.sourceIDs[goal]}
    emit:=func(depth int,n *projectionNode){
        k:=int(n.operation);if n.kind==ast.ASTQuantifier{all,_:=m.IsForall(n.expr);k=-2;if all{k=-3}};println("GROUND","shape",depth,k,n.count,len(g.quantifiers),len(g.implications))
    }
    n:=&g.input[id];emit(0,n);for _,cid:=range g.children[n.start:n.start+n.count]{child:=&g.input[cid];emit(1,child)}
}''')
    yield p,s
def run(s):
    s=census(s).replace("for unit in ('instructions','bytes'):","for unit in ('shapes',):").replace("for scope in ('outer','build'):","for scope in ('input',):").replace('for i in range(2):','for i in range(1):')
    return s
if __name__=='__main__':panel(['probe'],patch,run)
