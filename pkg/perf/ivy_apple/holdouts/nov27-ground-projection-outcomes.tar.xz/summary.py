"""Summarize case-level costs. Run beside the archived CSV directories."""
import csv
from pathlib import Path
from statistics import median
root=Path(__file__).resolve().parent
def rows(path):return list(csv.DictReader(path.open()))
for case in [4,8,3,6]:
    print('case',case)
    for unit in ['instructions','bytes']:
        data=rows(root/'final'/f'{case}-{unit}-outer-0.csv')
        by_goal={(r['batch'],r['goal']):r['reason'] for r in data if r['op']=='boolean'}
        for answer in ['quantified-sat','quantified-refuted']:
            group=[r for r in data if by_goal.get((r['batch'],r['goal']))==answer]
            print(unit,answer,[(op,round(sum(int(r['value']) for r in group if r['op']==op)/1e6,3)) for op in ['project','boolean','check']])
for group in ['controls','inconsistent','enode','oracle']:
    for f in sorted((root/group).glob('time-*.csv')):
        data=rows(f); modes={r['engine'] for r in data}
        def mid(mode):return median(int(r['instructions']) for r in data if r['engine']==mode)
        print(group,f.stem,{m:round(100*(mid(m)/mid('base')-1),2) for m in sorted(modes)})
