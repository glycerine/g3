from driver import panel
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_enode_core.go';s=p.read_text()
    a='n := &SMTEnode{'
    v="""var n *SMTEnode
    var storage []*SMTEnode
    if term == nil && !options.SuppressArguments && header.NumArgs >= 1 && header.NumArgs <= 2 {
        pair := new(struct { node SMTEnode; args [2]*SMTEnode })
        n = &pair.node
        storage = pair.args[:header.NumArgs:header.NumArgs]
    } else {
        n = new(SMTEnode)
    }
    *n = SMTEnode{"""
    assert s.count(a)==1
    yield p,s.replace(a,v).replace('n.arguments = make([]*SMTEnode, count)','if storage != nil { n.arguments = storage } else { n.arguments = make([]*SMTEnode,count) }')
def run(s):return s
if __name__=='__main__':panel(['base','trial'],patch,run)
