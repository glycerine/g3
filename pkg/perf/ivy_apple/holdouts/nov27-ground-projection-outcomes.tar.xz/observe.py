from driver import panel
def edit(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def patch(pkg,name):
    p=pkg/'api/internal/order/quantified_goal.go';s=p.read_text()
    s=edit(s,'import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast";"os";"runtime";"syscall";"unsafe")')
    s+='''
type StudySample struct {fd uintptr;a,b uint64}
var studyMem=os.Getenv("GROUND_UNIT")=="bytes"
var StudyBuild=os.Getenv("GROUND_SCOPE")=="build"
func StudyStart()StudySample{if studyMem{var m runtime.MemStats;runtime.ReadMemStats(&m);return StudySample{a:m.TotalAlloc}}
runtime.LockOSThread();var attr struct{Type,Size uint32;Config,Period,SampleType,ReadFormat,Flags uint64; Rest [2]uint64};attr.Size=uint32(unsafe.Sizeof(attr));attr.Config=1;attr.ReadFormat=3;attr.Flags=1<<5|1<<6
fd,_,e:=syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN,uintptr(unsafe.Pointer(&attr)),0,^uintptr(0),^uintptr(0),0,0);if e!=0{panic(e)};r:=StudySample{fd:fd};r.a=r.read();r.b=r.read();return r}
func(r StudySample)read()uint64{var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,r.fd,uintptr(unsafe.Pointer(&v)),24);if e!=0||n!=24||v[1]!=v[2]{panic("bad counter")};return v[0]}
func(r StudySample)End(op,reason string,ok bool,width int,work int){var v uint64;if studyMem{var m runtime.MemStats;runtime.ReadMemStats(&m);v=m.TotalAlloc-r.a}else{end:=r.read();if end-r.b>r.b-r.a{v=end-r.b-(r.b-r.a)};syscall.Close(int(r.fd));runtime.UnlockOSThread()};println("GROUND",op,reason,ok,width,work,v)}
'''
    a=s.index('func (g *groundProjection) problem(');b=s.index('// Count occurrences',a);v=s[a:b]
    v=edit(v,'(*BooleanProblem, error) {','''(out *BooleanProblem, e error) {
phase:="parse";if StudyBuild{sample:=StudyStart();defer func(){op:="quantified";if seedGoal{op="units"};if e==nil{phase="built"};sample.End(op,phase,out!=nil,len(assertions),g.compiler.work)}()}''')
    for before,stage in [('if err := g.chooseConstants(inputs);','constants'),('for _, id := range inputs {','ground'),('for _, id := range g.quantifiers {','bindings'),('return g.booleanProblem()','compile')]:v=edit(v,before,'phase="'+stage+'";'+before)
    s=s[:a]+v+s[b:];yield p,s
    p=pkg/'api/api_order_abstraction.go';s=p.read_text()
    a=s.index('func (p *orderProofState) proveAssertions(');b=s.index('if reuse && p.needsNewDeclarations',a);v=s[a:b]
    v=edit(v,'s := p.source','kind:="transition";var sample order.StudySample;s := p.source')
    v=edit(v,'bits, err := parsed.Project','if !order.StudyBuild{sample=order.StudyStart()};bits, err := parsed.Project')
    v=edit(v,'searchSteps := maxSteps','if !order.StudyBuild{sample.End("project","quantified",bits!=nil,len(assertions),0)};kind="quantified";searchSteps := maxSteps')
    v=edit(v,'bits, err = order.ProjectGroundBooleans','kind="ground";if !order.StudyBuild{sample=order.StudyStart()};bits, err = order.ProjectGroundBooleans')
    v=edit(v,'if err != nil || limit.CancelFlag() {\n\t\t\t\t\treturn false, err','if !order.StudyBuild{sample.End("project","ground",bits!=nil,len(assertions),0)};if err != nil || limit.CancelFlag() {\n\t\t\t\t\treturn false, err')
    v=edit(v,'return p.checkBoolean(parent, proof.Boolean, proof.SearchSteps)','if !order.StudyBuild{sample=order.StudyStart()};yes,e:=p.checkBoolean(parent, proof.Boolean, proof.SearchSteps);if !order.StudyBuild{sample.End("boolean",kind+"-"+studyOutcome,yes,len(assertions),int(proof.Boolean.Work))};return yes,e')
    yield p,s[:a]+v+s[b:]
    p=pkg/'api/internal/order/ground_premises.go';s=p.read_text()
    needle='steps uint32) (bool, error) {'
    s=edit(s,needle,'''steps uint32) (yes bool, e error) {
state:="cold";if !StudyBuild{if p.PreparedFor(m,assertions){state="ready"};sample:=StudyStart();defer func(){sample.End("units",state,yes,len(assertions),0)}()}''')
    yield p,s
    p=pkg/'api/api_simple_solver_check.go';s=p.read_text().replace('import (','import (\n"github.com/glycerine/g3/pkg/api/internal/order"')
    s=edit(s,'(lbool.LBool, error) {','(result lbool.LBool, e error) {\nif !order.StudyBuild{sample:=order.StudyStart();defer func(){sample.End("check","solver",result==lbool.False,len(assumptions),0)}()}')
    yield p,s
    p=pkg/'api/api_order_boolean.go';s=p.read_text()+'\nvar studyOutcome string\n'
    s=edit(s,'if p.bits == nil {','studyOutcome="unknown";if p.bits == nil {')
    s=edit(s,'return complete && conflict, nil','if complete && conflict{studyOutcome="refuted"};return complete && conflict, nil')
    s=edit(s,'if len(k.Clauses) == 0 {','if len(k.Clauses) == 0 {studyOutcome="sat";')
    s=edit(s,'if k.HasSatisfyingAssignment(limit) || !limit.IncOffset(0) {','if k.HasSatisfyingAssignment(limit){studyOutcome="sat";return false,nil}; if !limit.IncOffset(0) {')
    s=edit(s,'if err != nil || answer != lbool.False {','if err==nil && answer==lbool.True{studyOutcome="sat"};if err==nil && answer==lbool.False{studyOutcome="refuted"};if err != nil || answer != lbool.False {')
    yield p,s
def run(s):
    i=s.index('    for p,src in patch')
    s=s[:i]+'''    p=front/'z3bridge_solver_model.go';dst=Path(mp[str(p)]);src=dst.read_text()
    anchor='overallResult := smt.Unsat';idx=src.index(anchor,src.index('func (s *Solver) GetSmallModelWithCond('));src=src[:idx]+'projectionBatch++;batch:=projectionBatch;'+src[idx:];src=src.replace('for index, fc := range finalCond {','for index, fc := range finalCond {println("GROUND-ID",batch,index+1)');dst.write_text(src+'\\nvar projectionBatch int\\n')
'''+s[i:]
    a=s.index(' def measure(index,case):');s=s[:a]+''' for case in [4,8,3,6]:
    for unit in ('instructions','bytes'):
        for scope in ('outer','build'):
            for i in range(2):
                os.environ.update(GROUND_UNIT=unit,GROUND_SCOPE=scope,GROUND_OUT=str(out/(str(case)+'-'+unit+'-'+scope+'-'+str(i)+'.csv')))
                run(case,'probe',cpus[0],False)
'''
    s=s.replace("assert (r.returncode,r.stdout,r.stderr)==",'''Path(os.environ['GROUND_OUT']+'.stderr').write_bytes(r.stderr)
        ordinary=[];key=('0','0')
        with open(os.environ['GROUND_OUT'],'w') as fp:
            w=csv.writer(fp);w.writerow('batch goal op reason success width work value'.split())
            for l in r.stderr.splitlines(keepends=True):
                fields=l.split()
                if l.startswith(b'GROUND-ID '):key=tuple(x.decode() for x in fields[1:])
                elif l.startswith(b'GROUND '):w.writerow([*key,*[x.decode() for x in fields[1:]]])
                else:ordinary.append(l)
        assert (r.returncode,r.stdout,b''.join(ordinary))==''')
    return s.replace("GOGC='100'","GOGC='off'")
if __name__=='__main__':panel(['probe'],patch,run)
