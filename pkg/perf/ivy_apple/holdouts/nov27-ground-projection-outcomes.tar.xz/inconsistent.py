from driver import panel
def patch(pkg,name):
    if name=='trial':
        p=pkg/'api/api_order_abstraction.go'
        s=p.read_text()
        a='if bits == nil {\n\t\t\t\tif original && !triedUnits'
        assert s.count(a)==1
        yield p,s.replace(a,'if bits == nil {\n\t\t\t\tif !consistent { return false,nil }; if original && !triedUnits')
def run(s):
    return s.replace('((1,3),(4,8),(6,227))','((1,3),(4,8),(6,227))')
if __name__=='__main__':panel(['base','trial'],patch,run)
