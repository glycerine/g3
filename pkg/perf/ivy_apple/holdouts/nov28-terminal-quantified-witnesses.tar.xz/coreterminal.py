import sys,subprocess as sp,os,re,csv
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,str(Path('perf/ivy_apple/holdouts').resolve()))
from batch_prefix_replay import parse,smt,standard_declarations,expression,conjuncts
d=Path(__file__).resolve().parent
out=d/'coreterminal';out.mkdir(exist_ok=True)
exe=Path('../build/z3').resolve()
def work(path):
    label=path.parent.name+'-'+path.stem
    forms=parse(standard_declarations(path.read_text()))
    decl=[smt(x) for x in forms if x[0]!='assert'];prefix='\n'.join(decl)
    rows=[list(conjuncts(expression(x[1],{},{}))) for x in forms if x[0]=='assert']
    assert len(rows)==2
    atoms=rows[0]+rows[1]
    def solve(ids,tracked=False):
        flags='(set-option :produce-unsat-cores true)\n' if tracked else ''
        term=lambda i:'(! '+smt(atoms[i])+' :named g3row!'+str(i)+')' if tracked else smt(atoms[i])
        payload=flags+'(set-option :timeout 2000)\n'+prefix+'\n'+'\n'.join('(assert '+term(i)+')' for i in ids)+'\n(check-sat)\n'+('(get-unsat-core)\n' if tracked else '')
        r=sp.run([exe,'-in','-smt2'],input=payload,capture_output=True,text=True,timeout=5)
        lines=r.stdout.strip().splitlines()
        if not lines or lines[0] not in ('sat','unsat','unknown'):raise ValueError((label,lines[:3]))
        return lines[0],[int(n) for n in re.findall(r'g3row!(\d+)',r.stdout)] if tracked else []
    base,_=solve(range(len(rows[0])))
    q,ids=solve(range(len(atoms)),True)
    if q!='unsat':return [label,len(rows[0]),smt(rows[1][0])[:100],base,q,0,0,0,0]
    assert ids and solve(ids)[0]=='unsat'
    initial=len(ids); unknown=0
    for i in ids[:]:
        cur=[j for j in ids if j!=i];verdict,_=solve(cur)
        if verdict=='unsat':ids=cur
        if verdict=='unknown':unknown+=1
    (out/(label+'.smt2')).write_text(prefix+'\n'+'\n'.join('; row '+str(i)+'\n(assert '+smt(atoms[i])+')' for i in ids)+'\n(check-sat)\n')
    return [label,len(rows[0]),smt(rows[1][0])[:100],base,q,initial,len(ids),sum('forall' in smt(atoms[i]) for i in ids),unknown]
with (out/'summary.csv').open('w') as f,ThreadPoolExecutor(3) as pool:
 w=csv.writer(f);w.writerow(['case-batch','base_rows','goal_first_conjunct','base_result','tracked_result','core_rows','reduced_rows','quantified_rows','unknown_deletions'])
 for row in pool.map(work,sorted((d/'captureterminal').glob('7/*.smt2'))):w.writerow(row);f.flush()
