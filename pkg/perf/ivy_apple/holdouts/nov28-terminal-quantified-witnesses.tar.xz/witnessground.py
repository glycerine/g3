from pathlib import Path
import csv
d=Path(__file__).resolve().parent
s=(d/'terminalwitness.py').read_text().split("out=d/'terminalwitness'")[0].replace("def test(path,mode):","def test(path,mode,extra):")
s=s.replace("consts[s] if mode in ('full','full-diag') else []","[v for v in consts[s] if extra=='all' or v==extra]")
s=s.replace(" sol='"," left=len(flat);flat=[t for t in flat if '(forall ' not in smt(t) and '(exists ' not in smt(t)]\n sol='")
s=s.replace("instances,r.stdout.strip()", "extra,instances,left-len(flat),r.stdout.strip()")
exec(s)
out=d/'witnessground';out.mkdir(exist_ok=True)
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['batch','mode','fresh','extra','instances','omitted','result'])
 for p in sorted((d/'captureterminal/7').glob('*.smt2')):
    defs=parse(standard_declarations(p.read_text()))
    opt=[a[1] for a in defs if a[0]=='declare-fun' and not a[2] and a[3]!='Bool']
    for v in ['none','all']+opt:
        w.writerow(test(p,'diag',v));f.flush()
