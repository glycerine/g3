from pathlib import Path
from itertools import product
import csv,sys,subprocess,collections
sys.path.insert(0,str(Path('perf/ivy_apple/holdouts').resolve()))
from batch_prefix_replay import parse,smt,standard_declarations,expression,conjuncts
d=Path(__file__).resolve().parent
out=d/'terminalground';out.mkdir(exist_ok=True)
def subst(t,env):
 if isinstance(t,str):return env.get(t,t)
 if t and t[0]=='!':return subst(t[1],env)
 if t and t[0] in ['forall','exists']:return (t[0],t[1],subst(t[2],{k:v for k,v in env.items() if k not in dict(t[1])}))
 return tuple(subst(a,env) for a in t)
def ground(path,mode):
 forms=parse(standard_declarations(path.read_text()));defs=[f for f in forms if f[0]!='assert']
 atoms=[a for f in forms if f[0]=='assert' for a in conjuncts(expression(f[1],{},{}))]
 terms=collections.defaultdict(list)
 for f in defs:
  if f[0]=='declare-fun' and not f[2]:terms[f[3]].append(f[1])
 def collect(t):
  if isinstance(t,str) or not t:return
  if t[0] in ('forall','exists'):
   for _,s in t[1]:
    if s not in fresh:fresh[s]='|terminal-ground!%d|'%len(fresh)
   collect(t[2])
  else:
   for a in t:collect(a)
 fresh={}
 for a in atoms:collect(a)
 for s,c in fresh.items():defs.append(('declare-fun',c,(),s))
 result=[];opened=left=0
 for a in atoms:
  if isinstance(a,tuple) and a[0]=='forall':
   opened+=1
   pools=[]
   for name,s in a[1]:
    choices=terms[s]
    if mode=='fresh':vs=[fresh[s]]
    elif mode=='first':vs=choices[:1] or [fresh[s]]
    elif mode=='last':vs=choices[-1:] or [fresh[s]]
    elif mode=='all':vs=choices+[fresh[s]]
    elif mode=='none':vs=[]
    pools.append(vs)
   for args in product(*pools):
    g=subst(a[2],dict(zip((n for n,s in a[1]),args)))
    result.append(g)
  else:result.append(a)
 payload='\n'.join([smt(f) for f in defs]+['(assert '+smt(a)+')' for a in result]+['(check-sat)'])
 r=subprocess.run(['../build/z3','-in','-smt2','-T:4'],input=payload,text=True,capture_output=True)
 assert r.returncode==0 and r.stdout.strip() in ('sat','unsat','unknown','timeout'),r.stdout[:600]
 return [path.stem,mode,len(atoms),opened,len(result),r.stdout.strip()]
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['batch','witness','original','opened','asserted','result'])
 for path in sorted((d/'captureterminal/7').glob('*.smt2')):
  for mode in ('none','fresh','first','last','all'):w.writerow(ground(path,mode));f.flush()
