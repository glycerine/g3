(declare-datatypes ((op_type 0)) ((op_type (nop) (ld) (st) (lda) (stl))))
(declare-sort ltime.t)
(declare-sort addr_type.t)
(declare-datatypes ((arm_ph_type 0)) ((arm_ph_type (arm_idle_ph) (arm_st_ph) (arm_stl_ph) (arm_ld_ph) (arm_lda_ph) (arm_rsp_ph) (arm_rspa_ph) (arm_st_isd_ph) (arm_ld_isd_ph) (arm_stl_isd_ph) (arm_lda_isd_ph))))
(declare-sort data_type.t)
(declare-sort gtime.t)
(declare-sort proc.t)
(declare-fun ref.evs.op (ltime.t) op_type)
(declare-fun ref.evs.addr (ltime.t) addr_type.t)
(declare-fun ref.evs.p (ltime.t) proc.t)
(declare-fun |<:ltime.t:ltime.t| (ltime.t ltime.t) Bool)
(declare-fun ref.evs.serialized (ltime.t) Bool)
(declare-fun ref.prevents (ltime.t ltime.t) Bool)
(declare-fun |__fml:ph| () arm_ph_type)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0__ts0_d_a () Bool)
(declare-fun __ts0__ts0__ts0_e_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0_d_a_a_a () Bool)
(declare-fun __arm.pnd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun |__fml:t| () ltime.t)
(declare-fun |__fml:a| () addr_type.t)
(declare-fun |__fml:p| () proc.t)
(declare-fun __ts0__ts0__ts0__ts0_c_a_a_a () Bool)
(declare-fun __arm.pnd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0_c_a () Bool)
(declare-fun __arm.isd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.isd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.pnd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.isd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.isd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.pnd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.isd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.lt () ltime.t)
(declare-fun arm.isd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.isd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0_b () Bool)
(declare-fun arm.lt () ltime.t)
(declare-fun __ts0_a () Bool)
(declare-fun __m_ref.evs.op (ltime.t) op_type)
(declare-fun __m_ref.evs.serialized (ltime.t) Bool)
(declare-fun __m_ref.prevents_d (ltime.t ltime.t) Bool)
(declare-fun __ref.mem (addr_type.t) data_type.t)
(declare-fun ref.mem (addr_type.t) data_type.t)
(declare-fun __m_ref.evs.data (ltime.t) data_type.t)
(declare-fun ref.evs.data (ltime.t) data_type.t)
(declare-fun |__loc:d| () data_type.t)
(declare-fun |__new_loc:d| () data_type.t)
(declare-fun |__loc:a| () addr_type.t)
(declare-fun |__new_loc:a| () addr_type.t)
(declare-fun __ref.gt () gtime.t)
(declare-fun ref.gt () gtime.t)
(declare-fun |__new_fml:lt_a| () ltime.t)
(declare-fun |__new_fml:p_a_b| () proc.t)
(declare-fun __ref.evs.serialized (ltime.t) Bool)
(declare-fun __m_ref.prevents_b (ltime.t ltime.t) Bool)
(declare-fun |__new_fml:lt| () ltime.t)
(declare-fun __ref.evs.data (ltime.t) data_type.t)
(declare-fun |__new_fml:d_a_a| () data_type.t)
(declare-fun __ref.evs.addr (ltime.t) addr_type.t)
(declare-fun __m_ref.prevents_a (ltime.t ltime.t) Bool)
(declare-fun |__new_fml:a_a_a| () addr_type.t)
(declare-fun __ref.evs.op (ltime.t) op_type)
(declare-fun __m_ref.prevents (ltime.t ltime.t) Bool)
(declare-fun |__new_fml:op| () op_type)
(declare-fun __ref.evs.p (ltime.t) proc.t)
(declare-fun |__new_fml:p_a_a| () proc.t)
(declare-fun |__fml:d| () data_type.t)
(declare-fun |__new_fml:d_a| () data_type.t)
(declare-fun |__new_fml:a_a| () addr_type.t)
(declare-fun |__new_fml:p_a| () proc.t)
(declare-fun arm.isd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ref.prevents (ltime.t ltime.t) Bool)
(declare-fun |<:gtime.t:gtime.t| (gtime.t gtime.t) Bool)
(declare-fun __T () ltime.t)
(assert (let ((a!1 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) st)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!2 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) stl)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!3 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) ld)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!4 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) lda)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!5 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!6 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!7 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!8 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!9 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (not (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!10 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!11 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!12 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!13 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!14 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!15 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_ld |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!16 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_lda |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!17 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_st |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!18 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!19 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_lda |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_lda |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!20 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P1:proc.t|
                                       |A1:addr_type.t|
                                       |T1:ltime.t|)
                        (__arm.pnd_st |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!21 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P1:proc.t|
                                       |A1:addr_type.t|
                                       |T1:ltime.t|)
                        (__arm.pnd_stl |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!22 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_st |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_st |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!23 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_st |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!24 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_stl |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_stl |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!25 (forall ((|X:ltime.t| ltime.t)
                     (|Y:ltime.t| ltime.t)
                     (|Z:ltime.t| ltime.t))
              (=> (and (|<:ltime.t:ltime.t| |X:ltime.t| |Y:ltime.t|)
                       (|<:ltime.t:ltime.t| |Y:ltime.t| |Z:ltime.t|))
                  (|<:ltime.t:ltime.t| |X:ltime.t| |Z:ltime.t|))))
      (a!26 (forall ((|X:ltime.t| ltime.t) (|Y:ltime.t| ltime.t))
              (not (and (|<:ltime.t:ltime.t| |X:ltime.t| |Y:ltime.t|)
                        (|<:ltime.t:ltime.t| |Y:ltime.t| |X:ltime.t|)))))
      (a!27 (forall ((|X:gtime.t| gtime.t)
                     (|Y:gtime.t| gtime.t)
                     (|Z:gtime.t| gtime.t))
              (=> (and (|<:gtime.t:gtime.t| |X:gtime.t| |Y:gtime.t|)
                       (|<:gtime.t:gtime.t| |Y:gtime.t| |Z:gtime.t|))
                  (|<:gtime.t:gtime.t| |X:gtime.t| |Z:gtime.t|))))
      (a!28 (forall ((|X:gtime.t| gtime.t) (|Y:gtime.t| gtime.t))
              (not (and (|<:gtime.t:gtime.t| |X:gtime.t| |Y:gtime.t|)
                        (|<:gtime.t:gtime.t| |Y:gtime.t| |X:gtime.t|)))))
      (a!29 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                             (= (__ref.evs.op |T1:ltime.t|) lda)
                             (= (__ref.evs.op |T1:ltime.t|) st)
                             (= (__ref.evs.op |T1:ltime.t|) stl)))
                    (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (__ref.evs.op |T2:ltime.t|) stl)
                             (= (__ref.evs.op |T2:ltime.t|) lda))))
                (= (__ref.prevents |T1:ltime.t| |T2:ltime.t|)
                   (and (not (__ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (__ref.evs.p |T1:ltime.t|)
                           (__ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!30 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt))))
                (= (arm.pnd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                   (ite __ts0_c
                        (ite a!1
                             true
                             (__arm.pnd_st |V0:proc.t|
                                           |V1:addr_type.t|
                                           |V2:ltime.t|))
                        (__arm.pnd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))))
      (a!31 (ite __ts0_c
                 __arm.lt
                 (ite __ts0__ts0_d_a
                      |__fml:t|
                      (ite __ts0__ts0__ts0_e_a_a __arm.lt |__fml:t|))))
      (a!32 (forall ((|V0:ltime.t| ltime.t))
              (= (ref.evs.p |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__new_fml:lt|))
                      |__new_fml:p_a_a|
                      (__ref.evs.p |V0:ltime.t|)))))
      (a!33 (forall ((|V0:ltime.t| ltime.t))
              (= (__m_ref.evs.op |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__new_fml:lt|))
                      |__new_fml:op|
                      (__ref.evs.op |V0:ltime.t|)))))
      (a!34 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                             (= (__ref.evs.op |T1:ltime.t|) lda)
                             (= (__ref.evs.op |T1:ltime.t|) st)
                             (= (__ref.evs.op |T1:ltime.t|) stl)))
                    (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (__ref.evs.op |T2:ltime.t|) stl)
                             (= (__ref.evs.op |T2:ltime.t|) lda))))
                (= (__m_ref.prevents |T1:ltime.t| |T2:ltime.t|)
                   (and (not (__ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!35 (forall ((|V0:ltime.t| ltime.t))
              (= (ref.evs.addr |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__new_fml:lt|))
                      |__new_fml:a_a_a|
                      (__ref.evs.addr |V0:ltime.t|)))))
      (a!36 (forall ((|V0:ltime.t| ltime.t))
              (= (__m_ref.evs.data |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__new_fml:lt|))
                      |__new_fml:d_a_a|
                      (__ref.evs.data |V0:ltime.t|)))))
      (a!37 (forall ((|V0:ltime.t| ltime.t))
              (= (__m_ref.evs.serialized |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__new_fml:lt|))
                      false
                      (__ref.evs.serialized |V0:ltime.t|)))))
      (a!38 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__m_ref.evs.op |T1:ltime.t|) ld)
                             (= (__m_ref.evs.op |T1:ltime.t|) lda)
                             (= (__m_ref.evs.op |T1:ltime.t|) st)
                             (= (__m_ref.evs.op |T1:ltime.t|) stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__m_ref.evs.op |T2:ltime.t|) stl)
                             (= (__m_ref.evs.op |T2:ltime.t|) lda))))
                (= (__m_ref.prevents_b |T1:ltime.t| |T2:ltime.t|)
                   (and (not (__ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!39 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__m_ref.evs.op |T1:ltime.t|) ld)
                             (= (__m_ref.evs.op |T1:ltime.t|) lda)
                             (= (__m_ref.evs.op |T1:ltime.t|) st)
                             (= (__m_ref.evs.op |T1:ltime.t|) stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__m_ref.evs.op |T2:ltime.t|) stl)
                             (= (__m_ref.evs.op |T2:ltime.t|) lda))))
                (= (__m_ref.prevents_d |T1:ltime.t| |T2:ltime.t|)
                   (and (not (__m_ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!40 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (not (__arm.pnd_lda |__fml:p| |A:addr_type.t| |T:ltime.t|)))))
      (a!41 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (or (not (__arm.pnd_lda |__fml:p| |A:addr_type.t| |T:ltime.t|))
                    (|<:ltime.t:ltime.t| |__fml:t| |T:ltime.t|)))))
      (a!42 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (not (or (__arm.pnd_ld |__fml:p| |A:addr_type.t| |T:ltime.t|)
                         (__arm.pnd_lda |__fml:p| |A:addr_type.t| |T:ltime.t|)
                         (__arm.pnd_st |__fml:p| |A:addr_type.t| |T:ltime.t|)
                         (__arm.pnd_stl |__fml:p| |A:addr_type.t| |T:ltime.t|))))))
      (a!43 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (let ((a!1 (not (or (__arm.pnd_ld |__fml:p|
                                                  |A:addr_type.t|
                                                  |T:ltime.t|)
                                    (__arm.pnd_lda |__fml:p|
                                                   |A:addr_type.t|
                                                   |T:ltime.t|)
                                    (__arm.pnd_st |__fml:p|
                                                  |A:addr_type.t|
                                                  |T:ltime.t|)
                                    (__arm.pnd_stl |__fml:p|
                                                   |A:addr_type.t|
                                                   |T:ltime.t|)))))
                  (or a!1
                      (|<:ltime.t:ltime.t| |__fml:t| |T:ltime.t|)
                      (= |__fml:t| |T:ltime.t|))))))
      (a!45 (forall ((|T:ltime.t| ltime.t))
              (not (or (__arm.pnd_ld |__fml:p| |__fml:a| |T:ltime.t|)
                       (__arm.pnd_lda |__fml:p| |__fml:a| |T:ltime.t|)
                       (__arm.pnd_st |__fml:p| |__fml:a| |T:ltime.t|)
                       (__arm.pnd_stl |__fml:p| |__fml:a| |T:ltime.t|)))))
      (a!47 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt))))
              (let ((a!2 (ite __ts0__ts0_d_a
                              (__arm.pnd_stl |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)
                              (ite __ts0__ts0__ts0_e_a_a
                                   (ite a!1
                                        true
                                        (__arm.pnd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|))
                                   (__arm.pnd_stl |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)))))
                (= (arm.pnd_stl |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                   (ite __ts0_c
                        (__arm.pnd_stl |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|)
                        a!2))))))
      (a!48 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt)))
                    (a!2 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| |__fml:t|))))
              (let ((a!3 (ite __ts0__ts0_d_a
                              (__arm.isd_stl |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)
                              (ite __ts0__ts0__ts0_e_a_a
                                   (ite a!1
                                        true
                                        (__arm.isd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|))
                                   (ite a!2
                                        true
                                        (__arm.isd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|))))))
                (= (arm.isd_stl |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                   (ite __ts0_c
                        (__arm.isd_stl |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|)
                        a!3)))))))
(let ((a!44 (= __ts0_a
               (ite __ts0_c
                    a!40
                    (ite __ts0__ts0_d_a
                         a!41
                         (ite __ts0__ts0__ts0_e_a_a a!42 a!43)))))
      (a!46 (ite __ts0__ts0_d_a
                 (not (__arm.isd_st |__fml:p| |__fml:a| |__fml:t|))
                 (ite __ts0__ts0__ts0_e_a_a
                      a!45
                      (not (__arm.isd_stl |__fml:p| |__fml:a| |__fml:t|))))))
  (and (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (not (__arm.isd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (not (__arm.isd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       a!1
       a!2
       a!3
       a!4
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       a!5
       a!6
       a!7
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       a!14
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|A1:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t)
                (|T1:ltime.t| ltime.t))
         (let ((a!1 (not (and (or (__arm.pnd_ld |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.pnd_lda |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|)
                                  (__arm.pnd_st |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.pnd_stl |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|))
                              (|<:ltime.t:ltime.t| |T1:ltime.t| |T:ltime.t|)))))
           (=> (__arm.isd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|) a!1)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|A1:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t)
                (|T1:ltime.t| ltime.t))
         (let ((a!1 (not (and (or (__arm.isd_ld |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.isd_lda |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|)
                                  (__arm.isd_st |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.isd_stl |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|))
                              (|<:ltime.t:ltime.t| |T:ltime.t| |T1:ltime.t|)))))
           (=> (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|) a!1)))
       a!15
       a!16
       a!17
       a!18
       a!19
       a!20
       a!21
       a!22
       a!23
       a!24
       (or (not __ts0_c)
           (or (not __ts0_b)
               (not __ts0_a)
               (__m_ref.prevents_d __T |__new_fml:lt_a|)))
       (or (not __ts0_c) (or (not __ts0_b) __ts0_a false))
       (or (not __ts0_c) (or __ts0_b false))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (or (not __ts0_b)
               (not __ts0_a)
               (__m_ref.prevents_d __T |__new_fml:lt_a|)))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (or (not __ts0_b) __ts0_a false))
       (or __ts0_c
           (not __ts0__ts0_d_a)
           (not __ts0__ts0__ts0_c_a)
           (or __ts0_b false))
       (or __ts0_c (not __ts0__ts0_d_a) __ts0__ts0__ts0_c_a false)
       (or __ts0_c
           __ts0__ts0_d_a
           (not __ts0__ts0__ts0_e_a_a)
           (or (not __ts0_b)
               (not __ts0_a)
               (__m_ref.prevents_d __T |__new_fml:lt_a|)))
       (or __ts0_c
           __ts0__ts0_d_a
           (not __ts0__ts0__ts0_e_a_a)
           (or (not __ts0_b) __ts0_a false))
       (or __ts0_c
           __ts0__ts0_d_a
           (not __ts0__ts0__ts0_e_a_a)
           (or __ts0_b false))
       (or __ts0_c
           __ts0__ts0_d_a
           __ts0__ts0__ts0_e_a_a
           (not __ts0__ts0__ts0__ts0_d_a_a_a)
           (not __ts0__ts0__ts0__ts0_c_a_a_a)
           (or (not __ts0_b)
               (not __ts0_a)
               (__m_ref.prevents_d __T |__new_fml:lt_a|)))
       (or __ts0_c
           __ts0__ts0_d_a
           __ts0__ts0__ts0_e_a_a
           (not __ts0__ts0__ts0__ts0_d_a_a_a)
           (not __ts0__ts0__ts0__ts0_c_a_a_a)
           (or (not __ts0_b) __ts0_a false))
       (or __ts0_c
           __ts0__ts0_d_a
           __ts0__ts0__ts0_e_a_a
           (not __ts0__ts0__ts0__ts0_d_a_a_a)
           (not __ts0__ts0__ts0__ts0_c_a_a_a)
           (or __ts0_b false))
       (or __ts0_c
           __ts0__ts0_d_a
           __ts0__ts0__ts0_e_a_a
           (not __ts0__ts0__ts0__ts0_d_a_a_a)
           __ts0__ts0__ts0__ts0_c_a_a_a
           false)
       (or __ts0_c
           __ts0__ts0_d_a
           __ts0__ts0__ts0_e_a_a
           __ts0__ts0__ts0__ts0_d_a_a_a
           false)
       a!25
       a!26
       (forall ((|X:ltime.t| ltime.t) (|Y:ltime.t| ltime.t))
         (or (|<:ltime.t:ltime.t| |X:ltime.t| |Y:ltime.t|)
             (= |X:ltime.t| |Y:ltime.t|)
             (|<:ltime.t:ltime.t| |Y:ltime.t| |X:ltime.t|)))
       a!27
       a!28
       (forall ((|X:gtime.t| gtime.t) (|Y:gtime.t| gtime.t))
         (or (|<:gtime.t:gtime.t| |X:gtime.t| |Y:gtime.t|)
             (= |X:gtime.t| |Y:gtime.t|)
             (|<:gtime.t:gtime.t| |Y:gtime.t| |X:gtime.t|)))
       a!29
       a!30
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| __arm.lt)))
               (a!2 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| |__fml:t|))))
         (let ((a!3 (ite __ts0_c
                         (ite a!1
                              true
                              (__arm.isd_st |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|))
                         (ite __ts0__ts0_d_a
                              (ite a!2
                                   true
                                   (__arm.isd_st |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|))
                              (__arm.isd_st |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)))))
           (= (arm.isd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|) a!3))))
       (= |__new_fml:p_a| |__fml:p|)
       (= |__new_fml:a_a| |__fml:a|)
       (= |__new_fml:d_a| |__fml:d|)
       (= |__new_fml:lt| a!31)
       (= |__new_fml:p_a_a| |__fml:p|)
       (= |__new_fml:op| (ite __ts0_c st (ite __ts0__ts0_d_a st stl)))
       (= |__new_fml:a_a_a| |__fml:a|)
       (= |__new_fml:d_a_a| |__fml:d|)
       a!32
       a!33
       a!34
       a!35
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__m_ref.evs.op |T1:ltime.t|) ld)
                        (= (__m_ref.evs.op |T1:ltime.t|) lda)
                        (= (__m_ref.evs.op |T1:ltime.t|) st)
                        (= (__m_ref.evs.op |T1:ltime.t|) stl))))
         (let ((a!2 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (__m_ref.evs.op |T2:ltime.t|) stl)
                             (= (__m_ref.evs.op |T2:ltime.t|) lda)))))
           (= (__m_ref.prevents_a |T1:ltime.t| |T2:ltime.t|) a!2))))
       a!36
       a!37
       a!38
       (= |__new_fml:p_a_b| |__fml:p|)
       (= |__new_fml:lt_a| a!31)
       (forall ((|V0:ltime.t| ltime.t))
         (= (ref.evs.serialized |V0:ltime.t|)
            (__m_ref.evs.serialized |V0:ltime.t|)))
       (forall ((|V0:ltime.t| ltime.t))
         (= (ref.evs.op |V0:ltime.t|) (__m_ref.evs.op |V0:ltime.t|)))
       (= ref.gt __ref.gt)
       (= |__new_loc:a| |__loc:a|)
       (= |__new_loc:d| |__loc:d|)
       (forall ((|V0:ltime.t| ltime.t))
         (= (ref.evs.data |V0:ltime.t|) (__m_ref.evs.data |V0:ltime.t|)))
       (forall ((|V0:addr_type.t| addr_type.t))
         (= (ref.mem |V0:addr_type.t|) (__ref.mem |V0:addr_type.t|)))
       a!39
       a!44
       (= arm.lt __arm.lt)
       (= __ts0_b (ite __ts0_c a!45 a!46))
       a!47
       a!48
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (= (arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
            (__arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)))
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (= (arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
            (__arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)))
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (= (arm.pnd_lda |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
            (__arm.pnd_lda |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)))
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (= (arm.isd_lda |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
            (__arm.isd_lda |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)))
       (= __ts0__ts0__ts0_c_a (__arm.pnd_st |__fml:p| |__fml:a| |__fml:t|))
       (= __ts0__ts0__ts0__ts0_c_a_a_a
          (__arm.pnd_stl |__fml:p| |__fml:a| |__fml:t|))
       (= __ts0__ts0__ts0__ts0_d_a_a_a (= |__fml:ph| arm_stl_isd_ph))
       (= __ts0__ts0__ts0_e_a_a (= |__fml:ph| arm_stl_ph))
       (= __ts0__ts0_d_a (= |__fml:ph| arm_st_isd_ph))
       (= __ts0_c (= |__fml:ph| arm_st_ph))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (and (not (ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         (or (= (ref.evs.op |T1:ltime.t|) ld)
                             (= (ref.evs.op |T1:ltime.t|) lda)
                             (= (ref.evs.op |T1:ltime.t|) st)
                             (= (ref.evs.op |T1:ltime.t|) stl))
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (ref.evs.op |T2:ltime.t|) stl)
                             (= (ref.evs.op |T2:ltime.t|) lda)))))
           (= (ref.prevents |T1:ltime.t| |T2:ltime.t|) a!1)))))))
(assert (and (not false)))
