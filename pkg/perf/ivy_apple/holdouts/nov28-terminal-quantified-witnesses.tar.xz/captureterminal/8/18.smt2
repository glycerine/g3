(declare-sort index)
(declare-fun |__new_fml:y| () Int)
(declare-fun |__fml:x| () Int)
(declare-fun __Y () Int)
(declare-fun ticket_protocol.ticket.succ (Int Int) Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun |0:index| () index)
(declare-fun index.succ (index index) Bool)
(assert (let ((a!1 (not (and (< |__fml:x| |__new_fml:y|)
                     (=> (< |__fml:x| __Y) (<= |__new_fml:y| __Y)))))
      (a!2 (forall ((|T:index| index) (|U:index| index) (|V:index| index))
             (=> (and (|<:index:index| |T:index| |U:index|)
                      (|<:index:index| |U:index| |V:index|))
                 (|<:index:index| |T:index| |V:index|))))
      (a!3 (forall ((|T:index| index) (|U:index| index))
             (not (and (|<:index:index| |T:index| |U:index|)
                       (|<:index:index| |U:index| |T:index|)))))
      (a!4 (forall ((|X:ticket_protocol.ticket| Int)
                    (|Y:ticket_protocol.ticket| Int)
                    (|Z:ticket_protocol.ticket| Int))
             (let ((a!1 (and (<= 0 |X:ticket_protocol.ticket|)
                             (<= 0 |Y:ticket_protocol.ticket|)
                             (<= 0 |Z:ticket_protocol.ticket|)))
                   (a!2 (and (< |X:ticket_protocol.ticket|
                                |Z:ticket_protocol.ticket|)
                             (not (and (< |X:ticket_protocol.ticket|
                                          |Y:ticket_protocol.ticket|)
                                       (< |Y:ticket_protocol.ticket|
                                          |Z:ticket_protocol.ticket|))))))
               (=> a!1
                   (=> (ticket_protocol.ticket.succ
                         |X:ticket_protocol.ticket|
                         |Z:ticket_protocol.ticket|)
                       a!2)))))
      (a!5 (forall ((|T:ticket_protocol.ticket| Int)
                    (|U:ticket_protocol.ticket| Int)
                    (|V:ticket_protocol.ticket| Int))
             (let ((a!1 (and (<= 0 |T:ticket_protocol.ticket|)
                             (<= 0 |U:ticket_protocol.ticket|)
                             (<= 0 |V:ticket_protocol.ticket|))))
               (=> a!1
                   (=> (and (< |T:ticket_protocol.ticket|
                               |U:ticket_protocol.ticket|)
                            (< |U:ticket_protocol.ticket|
                               |V:ticket_protocol.ticket|))
                       (< |T:ticket_protocol.ticket| |V:ticket_protocol.ticket|))))))
      (a!6 (forall ((|T:ticket_protocol.ticket| Int)
                    (|U:ticket_protocol.ticket| Int))
             (=> (and (<= 0 |T:ticket_protocol.ticket|)
                      (<= 0 |U:ticket_protocol.ticket|))
                 (not (and (< |T:ticket_protocol.ticket|
                              |U:ticket_protocol.ticket|)
                           (< |U:ticket_protocol.ticket|
                              |T:ticket_protocol.ticket|))))))
      (a!7 (forall ((|T:ticket_protocol.ticket| Int)
                    (|U:ticket_protocol.ticket| Int))
             (=> (and (<= 0 |T:ticket_protocol.ticket|)
                      (<= 0 |U:ticket_protocol.ticket|))
                 (or (< |T:ticket_protocol.ticket| |U:ticket_protocol.ticket|)
                     (= |T:ticket_protocol.ticket| |U:ticket_protocol.ticket|)
                     (< |U:ticket_protocol.ticket| |T:ticket_protocol.ticket|)))))
      (a!8 (forall ((|X:ticket_protocol.ticket| Int))
             (=> (and (<= 0 |X:ticket_protocol.ticket|))
                 (<= 0 |X:ticket_protocol.ticket|))))
      (a!9 (forall ((|X:ticket_protocol.ticket| Int)
                    (|Y:ticket_protocol.ticket| Int))
             (= (ticket_protocol.ticket.succ
                  |X:ticket_protocol.ticket|
                  |Y:ticket_protocol.ticket|)
                (= |Y:ticket_protocol.ticket| (+ |X:ticket_protocol.ticket| 1))))))
  (and a!1
       (forall ((|X:index| index) (|Y:index| index) (|Z:index| index))
         (let ((a!1 (and (|<:index:index| |X:index| |Z:index|)
                         (not (and (|<:index:index| |X:index| |Y:index|)
                                   (|<:index:index| |Y:index| |Z:index|))))))
           (=> (index.succ |X:index| |Z:index|) a!1)))
       a!2
       a!3
       (forall ((|T:index| index) (|U:index| index))
         (or (|<:index:index| |T:index| |U:index|)
             (= |T:index| |U:index|)
             (|<:index:index| |U:index| |T:index|)))
       (forall ((|X:index| index))
         (or (= |0:index| |X:index|) (|<:index:index| |0:index| |X:index|)))
       a!4
       a!5
       a!6
       a!7
       a!8
       (= |__new_fml:y| (+ |__fml:x| 1))
       (not (> 0 |__fml:x|))
       (not (> 0 |__new_fml:y|))
       a!9
       (not (> 0 __Y))
       (not (> 0 |__fml:x|))
       (not (> 0 |__new_fml:y|)))))
(assert (and (not false)))
