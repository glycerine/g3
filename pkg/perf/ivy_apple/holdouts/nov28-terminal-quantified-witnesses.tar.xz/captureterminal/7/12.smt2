(declare-sort abp.value)
(declare-sort abp.index_t)
(declare-sort abp.data_msg_t)
(declare-sort abp.ack_msg_t)
(declare-fun __abp.l2s.d_ack_msg (abp.ack_msg_t) Bool)
(declare-fun |__new_fml:a_a| () abp.ack_msg_t)
(declare-fun abp.l2s.d_ack_msg (abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.d_data_msg (abp.data_msg_t) Bool)
(declare-fun |__new_fml:m_a| () abp.data_msg_t)
(declare-fun abp.l2s.d_data_msg (abp.data_msg_t) Bool)
(declare-fun __abp.l2s.d_value (abp.value) Bool)
(declare-fun abp.d (abp.data_msg_t) abp.value)
(declare-fun abp.l2s.d_value (abp.value) Bool)
(declare-fun abp.l2s.eta_1 () Bool)
(declare-fun abp.l2s.monitor_level_1 () Bool)
(declare-fun __ts0_a_c () Bool)
(declare-fun __m_abp.l2s.w_4 () Bool)
(declare-fun abp.fair_4 () Bool)
(declare-fun abp.l2s.w_4 () Bool)
(declare-fun __m_abp.l2s.w_3 () Bool)
(declare-fun abp.fair_3 () Bool)
(declare-fun abp.l2s.w_3 () Bool)
(declare-fun __m_abp.l2s.w_2 () Bool)
(declare-fun abp.fair_2 () Bool)
(declare-fun abp.l2s.w_2 () Bool)
(declare-fun __m_abp.l2s.w_1 () Bool)
(declare-fun abp.fair_1 () Bool)
(declare-fun abp.l2s.w_1 () Bool)
(declare-fun |__new_fml:a| () abp.ack_msg_t)
(declare-fun |__fml:m_a| () abp.data_msg_t)
(declare-fun __abp.ack_no_send_flag () Bool)
(declare-fun __ts0_a_b () Bool)
(declare-fun __abp.data_no_send_flag () Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun __abp.sender_bit () Bool)
(declare-fun abp.abit (abp.ack_msg_t) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __abp.sender_i () abp.index_t)
(declare-fun |__fml:y| () abp.index_t)
(declare-fun abp.sender_i () abp.index_t)
(declare-fun |__ts0__new_fml:x| () abp.index_t)
(declare-fun abp.sender_bit () Bool)
(declare-fun |__fml:m| () abp.ack_msg_t)
(declare-fun __abp.ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun abp.ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0__m_abp.l2s.frozen_a () Bool)
(declare-fun __ts0__ts0_b_a () Bool)
(declare-fun abp.l2s.saved () Bool)
(declare-fun __ts0__ts0__ts0_a_a () Bool)
(declare-fun __abp.l2s.w_4 () Bool)
(declare-fun __abp.l2s.w_3 () Bool)
(declare-fun __abp.l2s.w_2 () Bool)
(declare-fun __abp.l2s.w_1 () Bool)
(declare-fun __abp.l2s.waiting () Bool)
(declare-fun __ts0__ts0_a_b () Bool)
(declare-fun __abp.l2s.frozen () Bool)
(declare-fun __abp.l2s.s_ack_no_send_flag () Bool)
(declare-fun abp.l2s.s_ack_no_send_flag () Bool)
(declare-fun __abp.l2s.s_data_no_send_flag () Bool)
(declare-fun abp.l2s.s_data_no_send_flag () Bool)
(declare-fun __abp.l2s.s_receiver_bit () Bool)
(declare-fun abp.receiver_bit () Bool)
(declare-fun abp.l2s.s_receiver_bit () Bool)
(declare-fun __abp.l2s.s_sender_bit () Bool)
(declare-fun abp.l2s.s_sender_bit () Bool)
(declare-fun __abp.l2s.s_receiver_i () abp.index_t)
(declare-fun abp.receiver_i () abp.index_t)
(declare-fun abp.l2s.s_receiver_i () abp.index_t)
(declare-fun __abp.l2s.s_sender_i () abp.index_t)
(declare-fun abp.l2s.s_sender_i () abp.index_t)
(declare-fun __abp.l2s.s_receiver_array (abp.index_t) abp.value)
(declare-fun abp.receiver_array (abp.index_t) abp.value)
(declare-fun abp.l2s.s_receiver_array (abp.index_t) abp.value)
(declare-fun __abp.l2s.s_sender_array (abp.index_t) abp.value)
(declare-fun abp.sender_array (abp.index_t) abp.value)
(declare-fun abp.l2s.s_sender_array (abp.index_t) abp.value)
(declare-fun __abp.l2s.s_ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun abp.l2s.s_ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.s_data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun abp.data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun abp.l2s.s_data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun __abp.l2s.a_ack_msg (abp.ack_msg_t) Bool)
(declare-fun abp.l2s.a_ack_msg (abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.a_data_msg (abp.data_msg_t) Bool)
(declare-fun abp.l2s.a_data_msg (abp.data_msg_t) Bool)
(declare-fun __abp.l2s.a_value (abp.value) Bool)
(declare-fun abp.l2s.a_value (abp.value) Bool)
(declare-fun __abp.l2s.a_index (abp.index_t) Bool)
(declare-fun abp.l2s.d_index (abp.index_t) Bool)
(declare-fun abp.l2s.a_index (abp.index_t) Bool)
(declare-fun abp.l2s.frozen () Bool)
(declare-fun abp.l2s.waiting () Bool)
(declare-fun abp.l2s.monitor_level_0 () Bool)
(declare-fun abp.index.le (abp.index_t abp.index_t) Bool)
(declare-fun abp.index.zero () abp.index_t)
(declare-fun abp.ack_no_send_flag () Bool)
(declare-fun abp.data_no_send_flag () Bool)
(declare-fun __abp.l2s.saved () Bool)
(declare-fun abp.dbit (abp.data_msg_t) Bool)
(declare-fun abp.i0 () abp.index_t)
(assert (let ((a!1 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                    (|Y:abp.data_msg_t| abp.data_msg_t)
                    (|Z:abp.data_msg_t| abp.data_msg_t))
             (=> (and (abp.data_msg.le |X:abp.data_msg_t| |Y:abp.data_msg_t|)
                      (abp.data_msg.le |Y:abp.data_msg_t| |Z:abp.data_msg_t|))
                 (abp.data_msg.le |X:abp.data_msg_t| |Z:abp.data_msg_t|))))
      (a!2 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                    (|Y:abp.data_msg_t| abp.data_msg_t))
             (=> (and (abp.data_msg.le |X:abp.data_msg_t| |Y:abp.data_msg_t|)
                      (abp.data_msg.le |Y:abp.data_msg_t| |X:abp.data_msg_t|))
                 (= |X:abp.data_msg_t| |Y:abp.data_msg_t|))))
      (a!3 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                    (|Y:abp.data_msg_t| abp.data_msg_t))
             (=> (abp.data_msg.le |X:abp.data_msg_t| |Y:abp.data_msg_t|)
                 (and (abp.data_msg.le |X:abp.data_msg_t| |X:abp.data_msg_t|)
                      (abp.data_msg.le |Y:abp.data_msg_t| |Y:abp.data_msg_t|)))))
      (a!4 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                    (|Y:abp.data_msg_t| abp.data_msg_t))
             (=> (and (abp.data_msg.le |X:abp.data_msg_t| |X:abp.data_msg_t|)
                      (abp.data_msg.le |Y:abp.data_msg_t| |Y:abp.data_msg_t|))
                 (or (abp.data_msg.le |X:abp.data_msg_t| |Y:abp.data_msg_t|)
                     (abp.data_msg.le |Y:abp.data_msg_t| |X:abp.data_msg_t|)))))
      (a!5 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                    (|Y:abp.ack_msg_t| abp.ack_msg_t)
                    (|Z:abp.ack_msg_t| abp.ack_msg_t))
             (=> (and (__abp.ack_msg.le |X:abp.ack_msg_t| |Y:abp.ack_msg_t|)
                      (__abp.ack_msg.le |Y:abp.ack_msg_t| |Z:abp.ack_msg_t|))
                 (__abp.ack_msg.le |X:abp.ack_msg_t| |Z:abp.ack_msg_t|))))
      (a!6 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                    (|Y:abp.ack_msg_t| abp.ack_msg_t))
             (=> (and (__abp.ack_msg.le |X:abp.ack_msg_t| |Y:abp.ack_msg_t|)
                      (__abp.ack_msg.le |Y:abp.ack_msg_t| |X:abp.ack_msg_t|))
                 (= |X:abp.ack_msg_t| |Y:abp.ack_msg_t|))))
      (a!7 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                    (|Y:abp.ack_msg_t| abp.ack_msg_t))
             (=> (__abp.ack_msg.le |X:abp.ack_msg_t| |Y:abp.ack_msg_t|)
                 (and (__abp.ack_msg.le |X:abp.ack_msg_t| |X:abp.ack_msg_t|)
                      (__abp.ack_msg.le |Y:abp.ack_msg_t| |Y:abp.ack_msg_t|)))))
      (a!8 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                    (|Y:abp.ack_msg_t| abp.ack_msg_t))
             (=> (and (__abp.ack_msg.le |X:abp.ack_msg_t| |X:abp.ack_msg_t|)
                      (__abp.ack_msg.le |Y:abp.ack_msg_t| |Y:abp.ack_msg_t|))
                 (or (__abp.ack_msg.le |X:abp.ack_msg_t| |Y:abp.ack_msg_t|)
                     (__abp.ack_msg.le |Y:abp.ack_msg_t| |X:abp.ack_msg_t|)))))
      (a!9 (forall ((|I:abp.index_t| abp.index_t))
             (=> (not (abp.index.le abp.receiver_i |I:abp.index_t|))
                 (= (abp.receiver_array |I:abp.index_t|)
                    (abp.sender_array |I:abp.index_t|)))))
      (a!10 (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (and (not __abp.sender_bit) (not abp.receiver_bit))
                       (__abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|))
                  (abp.abit |A:abp.ack_msg_t|))))
      (a!11 (forall ((|M1:abp.data_msg_t| abp.data_msg_t)
                     (|M2:abp.data_msg_t| abp.data_msg_t))
              (let ((a!1 (not (and (abp.dbit |M1:abp.data_msg_t|)
                                   (not (abp.dbit |M2:abp.data_msg_t|))))))
                (=> (and (and (not __abp.sender_bit) (not abp.receiver_bit))
                         (abp.data_msg.le |M1:abp.data_msg_t|
                                          |M2:abp.data_msg_t|))
                    a!1))))
      (a!12 (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (and __abp.sender_bit abp.receiver_bit)
                       (__abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|))
                  (not (abp.abit |A:abp.ack_msg_t|)))))
      (a!13 (forall ((|M1:abp.data_msg_t| abp.data_msg_t)
                     (|M2:abp.data_msg_t| abp.data_msg_t))
              (let ((a!1 (not (and (not (abp.dbit |M1:abp.data_msg_t|))
                                   (abp.dbit |M2:abp.data_msg_t|)))))
                (=> (and (and __abp.sender_bit abp.receiver_bit)
                         (abp.data_msg.le |M1:abp.data_msg_t|
                                          |M2:abp.data_msg_t|))
                    a!1))))
      (a!14 (forall ((|M:abp.data_msg_t| abp.data_msg_t))
              (=> (and (and (not __abp.sender_bit) abp.receiver_bit)
                       (abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|))
                  (not (abp.dbit |M:abp.data_msg_t|)))))
      (a!15 (forall ((|A1:abp.ack_msg_t| abp.ack_msg_t)
                     (|A2:abp.ack_msg_t| abp.ack_msg_t))
              (let ((a!1 (not (and (abp.abit |A1:abp.ack_msg_t|)
                                   (not (abp.abit |A2:abp.ack_msg_t|))))))
                (=> (and (and (not __abp.sender_bit) abp.receiver_bit)
                         (__abp.ack_msg.le |A1:abp.ack_msg_t|
                                           |A2:abp.ack_msg_t|))
                    a!1))))
      (a!16 (forall ((|M:abp.data_msg_t| abp.data_msg_t))
              (=> (and (and __abp.sender_bit (not abp.receiver_bit))
                       (abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|))
                  (abp.dbit |M:abp.data_msg_t|))))
      (a!17 (forall ((|A1:abp.ack_msg_t| abp.ack_msg_t)
                     (|A2:abp.ack_msg_t| abp.ack_msg_t))
              (let ((a!1 (not (and (not (abp.abit |A1:abp.ack_msg_t|))
                                   (abp.abit |A2:abp.ack_msg_t|)))))
                (=> (and (and __abp.sender_bit (not abp.receiver_bit))
                         (__abp.ack_msg.le |A1:abp.ack_msg_t|
                                           |A2:abp.ack_msg_t|))
                    a!1))))
      (a!18 (forall ((|I:abp.index_t| abp.index_t))
              (=> (not (abp.index.le |I:abp.index_t| __abp.sender_i))
                  (abp.index.le abp.receiver_i |I:abp.index_t|))))
      (a!20 (forall ((|M:abp.data_msg_t| abp.data_msg_t))
              (=> (and (abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|)
                       (= (abp.dbit |M:abp.data_msg_t|) __abp.sender_bit))
                  (= (abp.d |M:abp.data_msg_t|)
                     (abp.sender_array __abp.sender_i)))))
      (a!21 (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (__abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|)
                       (= (abp.abit |A:abp.ack_msg_t|) __abp.sender_bit))
                  (not (abp.index.le abp.receiver_i __abp.sender_i)))))
      (a!22 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                     (|Y:abp.data_msg_t| abp.data_msg_t)
                     (|Z:abp.data_msg_t| abp.data_msg_t))
              (=> (and (__abp.l2s.s_data_msg.le
                         |X:abp.data_msg_t|
                         |Y:abp.data_msg_t|)
                       (__abp.l2s.s_data_msg.le
                         |Y:abp.data_msg_t|
                         |Z:abp.data_msg_t|))
                  (__abp.l2s.s_data_msg.le
                    |X:abp.data_msg_t|
                    |Z:abp.data_msg_t|))))
      (a!23 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                     (|Y:abp.data_msg_t| abp.data_msg_t))
              (=> (and (__abp.l2s.s_data_msg.le
                         |X:abp.data_msg_t|
                         |Y:abp.data_msg_t|)
                       (__abp.l2s.s_data_msg.le
                         |Y:abp.data_msg_t|
                         |X:abp.data_msg_t|))
                  (= |X:abp.data_msg_t| |Y:abp.data_msg_t|))))
      (a!24 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                     (|Y:abp.data_msg_t| abp.data_msg_t))
              (=> (__abp.l2s.s_data_msg.le
                    |X:abp.data_msg_t|
                    |Y:abp.data_msg_t|)
                  (and (__abp.l2s.s_data_msg.le
                         |X:abp.data_msg_t|
                         |X:abp.data_msg_t|)
                       (__abp.l2s.s_data_msg.le
                         |Y:abp.data_msg_t|
                         |Y:abp.data_msg_t|)))))
      (a!25 (forall ((|X:abp.data_msg_t| abp.data_msg_t)
                     (|Y:abp.data_msg_t| abp.data_msg_t))
              (=> (and (__abp.l2s.s_data_msg.le
                         |X:abp.data_msg_t|
                         |X:abp.data_msg_t|)
                       (__abp.l2s.s_data_msg.le
                         |Y:abp.data_msg_t|
                         |Y:abp.data_msg_t|))
                  (or (__abp.l2s.s_data_msg.le
                        |X:abp.data_msg_t|
                        |Y:abp.data_msg_t|)
                      (__abp.l2s.s_data_msg.le
                        |Y:abp.data_msg_t|
                        |X:abp.data_msg_t|)))))
      (a!26 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                     (|Y:abp.ack_msg_t| abp.ack_msg_t)
                     (|Z:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (__abp.l2s.s_ack_msg.le
                         |X:abp.ack_msg_t|
                         |Y:abp.ack_msg_t|)
                       (__abp.l2s.s_ack_msg.le
                         |Y:abp.ack_msg_t|
                         |Z:abp.ack_msg_t|))
                  (__abp.l2s.s_ack_msg.le |X:abp.ack_msg_t| |Z:abp.ack_msg_t|))))
      (a!27 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                     (|Y:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (__abp.l2s.s_ack_msg.le
                         |X:abp.ack_msg_t|
                         |Y:abp.ack_msg_t|)
                       (__abp.l2s.s_ack_msg.le
                         |Y:abp.ack_msg_t|
                         |X:abp.ack_msg_t|))
                  (= |X:abp.ack_msg_t| |Y:abp.ack_msg_t|))))
      (a!28 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                     (|Y:abp.ack_msg_t| abp.ack_msg_t))
              (=> (__abp.l2s.s_ack_msg.le |X:abp.ack_msg_t| |Y:abp.ack_msg_t|)
                  (and (__abp.l2s.s_ack_msg.le
                         |X:abp.ack_msg_t|
                         |X:abp.ack_msg_t|)
                       (__abp.l2s.s_ack_msg.le
                         |Y:abp.ack_msg_t|
                         |Y:abp.ack_msg_t|)))))
      (a!29 (forall ((|X:abp.ack_msg_t| abp.ack_msg_t)
                     (|Y:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (__abp.l2s.s_ack_msg.le
                         |X:abp.ack_msg_t|
                         |X:abp.ack_msg_t|)
                       (__abp.l2s.s_ack_msg.le
                         |Y:abp.ack_msg_t|
                         |Y:abp.ack_msg_t|))
                  (or (__abp.l2s.s_ack_msg.le
                        |X:abp.ack_msg_t|
                        |Y:abp.ack_msg_t|)
                      (__abp.l2s.s_ack_msg.le
                        |Y:abp.ack_msg_t|
                        |X:abp.ack_msg_t|)))))
      (a!30 (forall ((|I:abp.index_t| abp.index_t))
              (=> __abp.l2s.saved
                  (=> (not (abp.index.le __abp.l2s.s_receiver_i |I:abp.index_t|))
                      (= (__abp.l2s.s_receiver_array |I:abp.index_t|)
                         (__abp.l2s.s_sender_array |I:abp.index_t|))))))
      (a!31 (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
              (=> __abp.l2s.saved
                  (=> (and (and __abp.l2s.s_sender_bit __abp.l2s.s_receiver_bit)
                           (__abp.l2s.s_ack_msg.le
                             |A:abp.ack_msg_t|
                             |A:abp.ack_msg_t|))
                      (not (abp.abit |A:abp.ack_msg_t|))))))
      (a!32 (forall ((|M1:abp.data_msg_t| abp.data_msg_t)
                     (|M2:abp.data_msg_t| abp.data_msg_t))
              (let ((a!1 (not (and (not (abp.dbit |M1:abp.data_msg_t|))
                                   (abp.dbit |M2:abp.data_msg_t|)))))
                (=> __abp.l2s.saved
                    (=> (and (and __abp.l2s.s_sender_bit
                                  __abp.l2s.s_receiver_bit)
                             (__abp.l2s.s_data_msg.le
                               |M1:abp.data_msg_t|
                               |M2:abp.data_msg_t|))
                        a!1)))))
      (a!33 (forall ((|I:abp.index_t| abp.index_t))
              (=> (not (abp.index.le |I:abp.index_t| __abp.l2s.s_sender_i))
                  (abp.index.le __abp.l2s.s_receiver_i |I:abp.index_t|))))
      (a!35 (forall ((|I:abp.index_t| abp.index_t))
              (=> (not __abp.l2s.waiting)
                  (=> (abp.index.le |I:abp.index_t| abp.i0)
                      (__abp.l2s.a_index |I:abp.index_t|)))))
      (a!36 (forall ((|M:abp.data_msg_t| abp.data_msg_t))
              (let ((a!1 (=> (and (abp.data_msg.le |M:abp.data_msg_t|
                                                   |M:abp.data_msg_t|)
                                  (= (abp.dbit |M:abp.data_msg_t|)
                                     (not __abp.sender_bit)))
                             (__abp.l2s.a_data_msg |M:abp.data_msg_t|))))
                (=> (and (not __abp.l2s.waiting) abp.l2s.monitor_level_1) a!1))))
      (a!37 (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
              (let ((a!1 (=> (and (__abp.ack_msg.le |A:abp.ack_msg_t|
                                                    |A:abp.ack_msg_t|)
                                  (= (abp.abit |A:abp.ack_msg_t|)
                                     abp.receiver_bit))
                             (__abp.l2s.a_ack_msg |A:abp.ack_msg_t|))))
                (=> (and (not __abp.l2s.waiting) abp.l2s.monitor_level_1) a!1))))
      (a!38 (=> (and __abp.l2s.saved abp.l2s.monitor_level_0)
                (or (not (abp.index.le __abp.sender_i __abp.l2s.s_sender_i))
                    (not (abp.index.le abp.receiver_i __abp.l2s.s_receiver_i)))))
      (a!39 (forall ((|M:abp.data_msg_t| abp.data_msg_t))
              (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1)
                       (abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|)
                       (= (abp.dbit |M:abp.data_msg_t|) (not __abp.sender_bit)))
                  (__abp.l2s.s_data_msg.le
                    |M:abp.data_msg_t|
                    |M:abp.data_msg_t|))))
      (a!40 (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1)
                       (__abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|)
                       (= (abp.abit |A:abp.ack_msg_t|) abp.receiver_bit))
                  (__abp.l2s.s_ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|))))
      (a!41 (exists ((|M:abp.data_msg_t| abp.data_msg_t))
              (and (__abp.l2s.a_data_msg |M:abp.data_msg_t|)
                   (not (abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|))
                   (__abp.l2s.s_data_msg.le
                     |M:abp.data_msg_t|
                     |M:abp.data_msg_t|)
                   (= (abp.dbit |M:abp.data_msg_t|) (not abp.receiver_bit)))))
      (a!42 (exists ((|A:abp.ack_msg_t| abp.ack_msg_t))
              (and (__abp.l2s.a_ack_msg |A:abp.ack_msg_t|)
                   (not (__abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|))
                   (__abp.l2s.s_ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|)
                   (= (abp.abit |A:abp.ack_msg_t|) (not __abp.sender_bit)))))
      (a!44 (forall ((|M1:abp.data_msg_t| abp.data_msg_t)
                     (|M2:abp.data_msg_t| abp.data_msg_t))
              (=> (and (abp.l2s.a_data_msg |M1:abp.data_msg_t|)
                       (abp.l2s.a_data_msg |M2:abp.data_msg_t|))
                  (= (abp.l2s.s_data_msg.le
                       |M1:abp.data_msg_t|
                       |M2:abp.data_msg_t|)
                     (abp.data_msg.le |M1:abp.data_msg_t| |M2:abp.data_msg_t|)))))
      (a!45 (forall ((|A1:abp.ack_msg_t| abp.ack_msg_t)
                     (|A2:abp.ack_msg_t| abp.ack_msg_t))
              (=> (and (abp.l2s.a_ack_msg |A1:abp.ack_msg_t|)
                       (abp.l2s.a_ack_msg |A2:abp.ack_msg_t|))
                  (= (abp.l2s.s_ack_msg.le
                       |A1:abp.ack_msg_t|
                       |A2:abp.ack_msg_t|)
                     (abp.ack_msg.le |A1:abp.ack_msg_t| |A2:abp.ack_msg_t|)))))
      (a!46 (forall ((|I:abp.index_t| abp.index_t) (|V:abp.value| abp.value))
              (=> (and (abp.l2s.a_index |I:abp.index_t|)
                       (abp.l2s.a_value |V:abp.value|))
                  (= (= (abp.l2s.s_sender_array |I:abp.index_t|) |V:abp.value|)
                     (= (abp.sender_array |I:abp.index_t|) |V:abp.value|)))))
      (a!47 (forall ((|I:abp.index_t| abp.index_t) (|V:abp.value| abp.value))
              (=> (and (abp.l2s.a_index |I:abp.index_t|)
                       (abp.l2s.a_value |V:abp.value|))
                  (= (= (abp.l2s.s_receiver_array |I:abp.index_t|)
                        |V:abp.value|)
                     (= (abp.receiver_array |I:abp.index_t|) |V:abp.value|)))))
      (a!48 (forall ((|I:abp.index_t| abp.index_t))
              (=> (abp.l2s.a_index |I:abp.index_t|)
                  (= (= abp.l2s.s_sender_i |I:abp.index_t|)
                     (= abp.sender_i |I:abp.index_t|)))))
      (a!49 (forall ((|I:abp.index_t| abp.index_t))
              (=> (abp.l2s.a_index |I:abp.index_t|)
                  (= (= abp.l2s.s_receiver_i |I:abp.index_t|)
                     (= abp.receiver_i |I:abp.index_t|)))))
      (a!50 (forall ((|X:abp.index_t| abp.index_t)
                     (|Y:abp.index_t| abp.index_t)
                     (|Z:abp.index_t| abp.index_t))
              (=> (and (abp.index.le |X:abp.index_t| |Y:abp.index_t|)
                       (abp.index.le |Y:abp.index_t| |Z:abp.index_t|))
                  (abp.index.le |X:abp.index_t| |Z:abp.index_t|))))
      (a!51 (forall ((|X:abp.index_t| abp.index_t)
                     (|Y:abp.index_t| abp.index_t))
              (=> (and (abp.index.le |X:abp.index_t| |Y:abp.index_t|)
                       (abp.index.le |Y:abp.index_t| |X:abp.index_t|))
                  (= |X:abp.index_t| |Y:abp.index_t|))))
      (a!52 (= abp.l2s.waiting
               (or __ts0_c (and (not __ts0__ts0_a_b) __abp.l2s.waiting))))
      (a!53 (and (not __ts0_c)
                 (ite __ts0__ts0_b_a
                      (and (not __ts0__ts0__ts0_a_a) __ts0__m_abp.l2s.frozen_a)
                      __ts0__m_abp.l2s.frozen_a)))
      (a!54 (= __m_abp.l2s.w_1
               (or __ts0_c
                   (ite __ts0__ts0_b_a
                        (or __ts0__ts0__ts0_a_a __abp.l2s.w_1)
                        __abp.l2s.w_1))))
      (a!55 (= __m_abp.l2s.w_2
               (or __ts0_c
                   (ite __ts0__ts0_b_a
                        (or __ts0__ts0__ts0_a_a __abp.l2s.w_2)
                        __abp.l2s.w_2))))
      (a!56 (= __m_abp.l2s.w_3
               (or __ts0_c
                   (ite __ts0__ts0_b_a
                        (or __ts0__ts0__ts0_a_a __abp.l2s.w_3)
                        __abp.l2s.w_3))))
      (a!57 (= __m_abp.l2s.w_4
               (or __ts0_c
                   (ite __ts0__ts0_b_a
                        (or __ts0__ts0__ts0_a_a __abp.l2s.w_4)
                        __abp.l2s.w_4))))
      (a!58 (forall ((|V0:abp.index_t| abp.index_t))
              (= (abp.l2s.a_index |V0:abp.index_t|)
                 (ite __ts0_c
                      (__abp.l2s.a_index |V0:abp.index_t|)
                      (ite __ts0__ts0_a_b
                           (abp.l2s.d_index |V0:abp.index_t|)
                           (__abp.l2s.a_index |V0:abp.index_t|))))))
      (a!59 (forall ((|V0:abp.value| abp.value))
              (= (abp.l2s.a_value |V0:abp.value|)
                 (ite __ts0_c
                      (__abp.l2s.a_value |V0:abp.value|)
                      (ite __ts0__ts0_a_b
                           (__abp.l2s.d_value |V0:abp.value|)
                           (__abp.l2s.a_value |V0:abp.value|))))))
      (a!60 (forall ((|V0:abp.data_msg_t| abp.data_msg_t))
              (= (abp.l2s.a_data_msg |V0:abp.data_msg_t|)
                 (ite __ts0_c
                      (__abp.l2s.a_data_msg |V0:abp.data_msg_t|)
                      (ite __ts0__ts0_a_b
                           (__abp.l2s.d_data_msg |V0:abp.data_msg_t|)
                           (__abp.l2s.a_data_msg |V0:abp.data_msg_t|))))))
      (a!61 (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t))
              (= (abp.l2s.a_ack_msg |V0:abp.ack_msg_t|)
                 (ite __ts0_c
                      (__abp.l2s.a_ack_msg |V0:abp.ack_msg_t|)
                      (ite __ts0__ts0_a_b
                           (__abp.l2s.d_ack_msg |V0:abp.ack_msg_t|)
                           (__abp.l2s.a_ack_msg |V0:abp.ack_msg_t|))))))
      (a!62 (= abp.l2s.s_sender_i
               (ite __ts0_c
                    __abp.l2s.s_sender_i
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              __abp.sender_i
                              __abp.l2s.s_sender_i)
                         __abp.l2s.s_sender_i))))
      (a!63 (= abp.l2s.s_receiver_i
               (ite __ts0_c
                    __abp.l2s.s_receiver_i
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              abp.receiver_i
                              __abp.l2s.s_receiver_i)
                         __abp.l2s.s_receiver_i))))
      (a!64 (= abp.l2s.s_sender_bit
               (ite __ts0_c
                    __abp.l2s.s_sender_bit
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              __abp.sender_bit
                              __abp.l2s.s_sender_bit)
                         __abp.l2s.s_sender_bit))))
      (a!65 (= abp.l2s.s_receiver_bit
               (ite __ts0_c
                    __abp.l2s.s_receiver_bit
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              abp.receiver_bit
                              __abp.l2s.s_receiver_bit)
                         __abp.l2s.s_receiver_bit))))
      (a!66 (= abp.l2s.s_data_no_send_flag
               (ite __ts0_c
                    __abp.l2s.s_data_no_send_flag
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              __abp.data_no_send_flag
                              __abp.l2s.s_data_no_send_flag)
                         __abp.l2s.s_data_no_send_flag))))
      (a!67 (= abp.l2s.s_ack_no_send_flag
               (ite __ts0_c
                    __abp.l2s.s_ack_no_send_flag
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              __abp.ack_no_send_flag
                              __abp.l2s.s_ack_no_send_flag)
                         __abp.l2s.s_ack_no_send_flag))))
      (a!68 (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t)
                     (|V1:abp.ack_msg_t| abp.ack_msg_t))
              (= (abp.ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|)
                 (ite (and (= |V1:abp.ack_msg_t| |__fml:m|))
                      false
                      (__abp.ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|)))))
      (a!69 (= abp.l2s.w_1
               (ite __ts0_a_c
                    (and __m_abp.l2s.w_1 (not abp.fair_1))
                    __m_abp.l2s.w_1)))
      (a!70 (= abp.l2s.w_2
               (ite __ts0_a_c
                    (and __m_abp.l2s.w_2 (not abp.fair_2))
                    __m_abp.l2s.w_2)))
      (a!71 (= abp.l2s.w_3
               (ite __ts0_a_c
                    (and __m_abp.l2s.w_3 (not abp.fair_3))
                    __m_abp.l2s.w_3)))
      (a!72 (= abp.l2s.w_4
               (ite __ts0_a_c
                    (and __m_abp.l2s.w_4 (not abp.fair_4))
                    __m_abp.l2s.w_4)))
      (a!73 (forall ((|V0:abp.data_msg_t| abp.data_msg_t))
              (= (abp.l2s.d_data_msg |V0:abp.data_msg_t|)
                 (ite (and (= |V0:abp.data_msg_t| |__new_fml:m_a|))
                      true
                      (__abp.l2s.d_data_msg |V0:abp.data_msg_t|)))))
      (a!74 (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t))
              (= (abp.l2s.d_ack_msg |V0:abp.ack_msg_t|)
                 (ite (and (= |V0:abp.ack_msg_t| |__new_fml:a_a|))
                      true
                      (__abp.l2s.d_ack_msg |V0:abp.ack_msg_t|))))))
(let ((a!19 (=> (= __abp.sender_bit (not abp.receiver_bit))
                (and (not (abp.index.le abp.receiver_i __abp.sender_i)) a!18)))
      (a!34 (=> (= __abp.l2s.s_sender_bit (not __abp.l2s.s_receiver_bit))
                (and (not (abp.index.le __abp.l2s.s_receiver_i
                                        __abp.l2s.s_sender_i))
                     a!33)))
      (a!43 (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1)
                     (not __abp.l2s.w_4)
                     (not __abp.ack_no_send_flag)
                     (= __abp.l2s.s_sender_bit (not __abp.l2s.s_receiver_bit)))
                a!42)))
  (and a!1
       a!2
       a!3
       a!4
       a!5
       a!6
       a!7
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       a!14
       a!15
       a!16
       a!17
       (=> (= __abp.sender_bit abp.receiver_bit)
           (= __abp.sender_i abp.receiver_i))
       a!19
       a!20
       a!21
       (or __abp.l2s.waiting __abp.l2s.frozen __abp.l2s.saved)
       (or (not __abp.l2s.waiting) (not __abp.l2s.frozen))
       (or (not __abp.l2s.waiting) (not __abp.l2s.saved))
       (or (not __abp.l2s.frozen) (not __abp.l2s.saved))
       a!22
       a!23
       a!24
       a!25
       a!26
       a!27
       a!28
       a!29
       a!30
       (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
         (let ((a!1 (=> (and (and (not __abp.l2s.s_sender_bit)
                                  (not __abp.l2s.s_receiver_bit))
                             (__abp.l2s.s_ack_msg.le
                               |A:abp.ack_msg_t|
                               |A:abp.ack_msg_t|))
                        (abp.abit |A:abp.ack_msg_t|))))
           (=> __abp.l2s.saved a!1)))
       (forall ((|M1:abp.data_msg_t| abp.data_msg_t)
                (|M2:abp.data_msg_t| abp.data_msg_t))
         (let ((a!1 (not (and (abp.dbit |M1:abp.data_msg_t|)
                              (not (abp.dbit |M2:abp.data_msg_t|))))))
         (let ((a!2 (=> (and (and (not __abp.l2s.s_sender_bit)
                                  (not __abp.l2s.s_receiver_bit))
                             (__abp.l2s.s_data_msg.le
                               |M1:abp.data_msg_t|
                               |M2:abp.data_msg_t|))
                        a!1)))
           (=> __abp.l2s.saved a!2))))
       a!31
       a!32
       (forall ((|M:abp.data_msg_t| abp.data_msg_t))
         (let ((a!1 (=> (and (and (not __abp.l2s.s_sender_bit)
                                  __abp.l2s.s_receiver_bit)
                             (__abp.l2s.s_data_msg.le
                               |M:abp.data_msg_t|
                               |M:abp.data_msg_t|))
                        (not (abp.dbit |M:abp.data_msg_t|)))))
           (=> __abp.l2s.saved a!1)))
       (forall ((|A1:abp.ack_msg_t| abp.ack_msg_t)
                (|A2:abp.ack_msg_t| abp.ack_msg_t))
         (let ((a!1 (not (and (abp.abit |A1:abp.ack_msg_t|)
                              (not (abp.abit |A2:abp.ack_msg_t|))))))
         (let ((a!2 (=> (and (and (not __abp.l2s.s_sender_bit)
                                  __abp.l2s.s_receiver_bit)
                             (__abp.l2s.s_ack_msg.le
                               |A1:abp.ack_msg_t|
                               |A2:abp.ack_msg_t|))
                        a!1)))
           (=> __abp.l2s.saved a!2))))
       (forall ((|M:abp.data_msg_t| abp.data_msg_t))
         (let ((a!1 (=> (and (and __abp.l2s.s_sender_bit
                                  (not __abp.l2s.s_receiver_bit))
                             (__abp.l2s.s_data_msg.le
                               |M:abp.data_msg_t|
                               |M:abp.data_msg_t|))
                        (abp.dbit |M:abp.data_msg_t|))))
           (=> __abp.l2s.saved a!1)))
       (forall ((|A1:abp.ack_msg_t| abp.ack_msg_t)
                (|A2:abp.ack_msg_t| abp.ack_msg_t))
         (let ((a!1 (not (and (not (abp.abit |A1:abp.ack_msg_t|))
                              (abp.abit |A2:abp.ack_msg_t|)))))
         (let ((a!2 (=> (and (and __abp.l2s.s_sender_bit
                                  (not __abp.l2s.s_receiver_bit))
                             (__abp.l2s.s_ack_msg.le
                               |A1:abp.ack_msg_t|
                               |A2:abp.ack_msg_t|))
                        a!1)))
           (=> __abp.l2s.saved a!2))))
       (=> __abp.l2s.saved
           (=> (= __abp.l2s.s_sender_bit __abp.l2s.s_receiver_bit)
               (= __abp.l2s.s_sender_i __abp.l2s.s_receiver_i)))
       (=> __abp.l2s.saved a!34)
       (forall ((|M:abp.data_msg_t| abp.data_msg_t))
         (let ((a!1 (=> (and (__abp.l2s.s_data_msg.le
                               |M:abp.data_msg_t|
                               |M:abp.data_msg_t|)
                             (= (abp.dbit |M:abp.data_msg_t|)
                                __abp.l2s.s_sender_bit))
                        (= (abp.d |M:abp.data_msg_t|)
                           (__abp.l2s.s_sender_array __abp.l2s.s_sender_i)))))
           (=> __abp.l2s.saved a!1)))
       (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
         (let ((a!1 (=> (and (__abp.l2s.s_ack_msg.le
                               |A:abp.ack_msg_t|
                               |A:abp.ack_msg_t|)
                             (= (abp.abit |A:abp.ack_msg_t|)
                                __abp.l2s.s_sender_bit))
                        (not (abp.index.le __abp.l2s.s_receiver_i
                                           __abp.l2s.s_sender_i)))))
           (=> __abp.l2s.saved a!1)))
       (forall ((|I:abp.index_t| abp.index_t))
         (=> (abp.index.le |I:abp.index_t| abp.i0)
             (abp.l2s.d_index |I:abp.index_t|)))
       (forall ((|M:abp.data_msg_t| abp.data_msg_t))
         (=> (abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|)
             (__abp.l2s.d_data_msg |M:abp.data_msg_t|)))
       (forall ((|A:abp.ack_msg_t| abp.ack_msg_t))
         (=> (__abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|)
             (__abp.l2s.d_ack_msg |A:abp.ack_msg_t|)))
       a!35
       a!36
       a!37
       (abp.index.le __abp.sender_i abp.i0)
       (abp.index.le abp.receiver_i abp.i0)
       (=> __abp.l2s.saved (abp.index.le __abp.l2s.s_sender_i abp.i0))
       (=> __abp.l2s.saved (abp.index.le __abp.l2s.s_receiver_i abp.i0))
       a!38
       a!39
       a!40
       (=> (and __abp.l2s.saved abp.l2s.monitor_level_1)
           (= __abp.l2s.s_sender_i __abp.sender_i))
       (=> (and __abp.l2s.saved abp.l2s.monitor_level_1)
           (= __abp.l2s.s_receiver_i abp.receiver_i))
       (=> (and __abp.l2s.saved abp.l2s.monitor_level_1)
           (= __abp.l2s.s_sender_bit __abp.sender_bit))
       (=> (and __abp.l2s.saved abp.l2s.monitor_level_1)
           (= __abp.l2s.s_receiver_bit abp.receiver_bit))
       (=> __abp.l2s.saved
           (=> __abp.l2s.s_data_no_send_flag __abp.data_no_send_flag))
       (=> __abp.l2s.saved
           (=> __abp.l2s.s_ack_no_send_flag __abp.ack_no_send_flag))
       (=> (and __abp.l2s.saved (not __abp.l2s.w_1))
           (not __abp.l2s.s_data_no_send_flag))
       (=> (and __abp.l2s.saved (not __abp.l2s.w_2))
           (not __abp.l2s.s_ack_no_send_flag))
       (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1)
                (not __abp.l2s.w_3)
                (not __abp.data_no_send_flag)
                (= __abp.l2s.s_sender_bit __abp.l2s.s_receiver_bit))
           a!41)
       a!43
       (or (not __ts0_c) (not abp.l2s.saved))
       (or __ts0_c __ts0__ts0_b_a (= abp.l2s.saved __abp.l2s.saved))
       (__abp.ack_msg.le |__fml:m| |__fml:m|)
       (forall ((|X:abp.ack_msg_t| abp.ack_msg_t))
         (=> (__abp.ack_msg.le |__fml:m| |X:abp.ack_msg_t|)
             (= |X:abp.ack_msg_t| |__fml:m|)))
       (or (not __ts0_a) (abp.index.le |__ts0__new_fml:x| |__fml:y|))
       (or (not __ts0_a) (not (= |__ts0__new_fml:x| |__fml:y|)))
       (forall ((|Z:abp.index_t| abp.index_t))
         (let ((a!1 (=> (and (abp.index.le |__ts0__new_fml:x| |Z:abp.index_t|)
                             (not (= |__ts0__new_fml:x| |Z:abp.index_t|)))
                        (abp.index.le |__fml:y| |Z:abp.index_t|))))
           (or (not __ts0_a) a!1)))
       (or __ts0_a_a (= abp.data_no_send_flag __abp.data_no_send_flag))
       (or __ts0_a_b (= abp.ack_no_send_flag __abp.ack_no_send_flag))
       (= abp.l2s.eta_1
          (and (= abp.sender_bit __abp.sender_bit)
               (= abp.receiver_bit abp.receiver_bit)))
       abp.l2s.saved
       (= abp.l2s.monitor_level_1 abp.l2s.eta_1)
       (not abp.l2s.w_1)
       (not abp.l2s.w_2)
       (not abp.l2s.w_3)
       (not abp.l2s.w_4)
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       (= abp.l2s.s_sender_bit abp.sender_bit)
       (= abp.l2s.s_receiver_bit abp.receiver_bit)
       (= abp.l2s.s_data_no_send_flag abp.data_no_send_flag)
       (= abp.l2s.s_ack_no_send_flag abp.ack_no_send_flag)
       (forall ((|X:abp.index_t| abp.index_t))
         (abp.index.le |X:abp.index_t| |X:abp.index_t|))
       a!50
       a!51
       (forall ((|X:abp.index_t| abp.index_t) (|Y:abp.index_t| abp.index_t))
         (or (abp.index.le |X:abp.index_t| |Y:abp.index_t|)
             (abp.index.le |Y:abp.index_t| |X:abp.index_t|)))
       (forall ((|X:abp.index_t| abp.index_t))
         (abp.index.le abp.index.zero |X:abp.index_t|))
       (or abp.l2s.monitor_level_0 abp.l2s.monitor_level_1)
       (or (not abp.l2s.monitor_level_0) (not abp.l2s.monitor_level_1))
       a!52
       (= abp.l2s.frozen a!53)
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       (forall ((|V0:abp.data_msg_t| abp.data_msg_t)
                (|V1:abp.data_msg_t| abp.data_msg_t))
         (let ((a!1 (ite __ts0_c
                         (__abp.l2s.s_data_msg.le
                           |V0:abp.data_msg_t|
                           |V1:abp.data_msg_t|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (abp.data_msg.le |V0:abp.data_msg_t|
                                                    |V1:abp.data_msg_t|)
                                   (__abp.l2s.s_data_msg.le
                                     |V0:abp.data_msg_t|
                                     |V1:abp.data_msg_t|))
                              (__abp.l2s.s_data_msg.le
                                |V0:abp.data_msg_t|
                                |V1:abp.data_msg_t|)))))
           (= (abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|)
              a!1)))
       (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t)
                (|V1:abp.ack_msg_t| abp.ack_msg_t))
         (let ((a!1 (ite __ts0_c
                         (__abp.l2s.s_ack_msg.le
                           |V0:abp.ack_msg_t|
                           |V1:abp.ack_msg_t|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (__abp.ack_msg.le |V0:abp.ack_msg_t|
                                                     |V1:abp.ack_msg_t|)
                                   (__abp.l2s.s_ack_msg.le
                                     |V0:abp.ack_msg_t|
                                     |V1:abp.ack_msg_t|))
                              (__abp.l2s.s_ack_msg.le
                                |V0:abp.ack_msg_t|
                                |V1:abp.ack_msg_t|)))))
           (= (abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|) a!1)))
       (forall ((|V0:abp.index_t| abp.index_t))
         (let ((a!1 (ite __ts0_c
                         (__abp.l2s.s_sender_array |V0:abp.index_t|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (abp.sender_array |V0:abp.index_t|)
                                   (__abp.l2s.s_sender_array |V0:abp.index_t|))
                              (__abp.l2s.s_sender_array |V0:abp.index_t|)))))
           (= (abp.l2s.s_sender_array |V0:abp.index_t|) a!1)))
       (forall ((|V0:abp.index_t| abp.index_t))
         (let ((a!1 (ite __ts0_c
                         (__abp.l2s.s_receiver_array |V0:abp.index_t|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (abp.receiver_array |V0:abp.index_t|)
                                   (__abp.l2s.s_receiver_array |V0:abp.index_t|))
                              (__abp.l2s.s_receiver_array |V0:abp.index_t|)))))
           (= (abp.l2s.s_receiver_array |V0:abp.index_t|) a!1)))
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       (= __ts0__m_abp.l2s.frozen_a (or __ts0__ts0_a_b __abp.l2s.frozen))
       (= __ts0__ts0_a_b
          (and __abp.l2s.waiting
               (not __abp.l2s.w_1)
               (not __abp.l2s.w_2)
               (not __abp.l2s.w_3)
               (not __abp.l2s.w_4)))
       (= __ts0__ts0__ts0_a_a abp.l2s.saved)
       (= __ts0__ts0_b_a
          (and __ts0__m_abp.l2s.frozen_a
               (= abp.l2s.monitor_level_1 abp.l2s.eta_1)))
       (= __ts0_c (and abp.l2s.monitor_level_1 (not abp.l2s.eta_1)))
       a!68
       (= |__new_fml:a| |__fml:m|)
       (= abp.sender_bit (ite __ts0_a (not __abp.sender_bit) __abp.sender_bit))
       (= |__ts0__new_fml:x| __abp.sender_i)
       (= abp.sender_i (ite __ts0_a |__fml:y| __abp.sender_i))
       (= __ts0_a (= (abp.abit |__new_fml:a|) __abp.sender_bit))
       (not abp.fair_1)
       (not abp.fair_2)
       (= abp.fair_3 __abp.data_no_send_flag)
       abp.fair_4
       (= __ts0_a_a (not __abp.data_no_send_flag))
       (= __ts0_a_b (not __abp.ack_no_send_flag))
       (= |__new_fml:m_a| |__fml:m_a|)
       (= |__new_fml:a_a| |__new_fml:a|)
       a!69
       a!70
       a!71
       a!72
       (= __ts0_a_c (=> abp.l2s.monitor_level_1 abp.l2s.eta_1))
       (forall ((|V0:abp.value| abp.value))
         (let ((a!1 (ite (and (= |V0:abp.value| (abp.d |__new_fml:m_a|)))
                         true
                         (__abp.l2s.d_value |V0:abp.value|))))
           (= (abp.l2s.d_value |V0:abp.value|) a!1)))
       a!73
       a!74))))
(assert (and (not false)))
