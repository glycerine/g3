(declare-sort hrb.quorum_b)
(declare-sort hrb.node)
(declare-sort hrb.quorum_a)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun __m_l2s_d_a (hrb.node) Bool)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_d (hrb.node) Bool)
(declare-fun __m_l2s_d (hrb.node) Bool)
(declare-fun hrb.n1 () hrb.node)
(declare-fun __l2s_d (hrb.node) Bool)
(declare-fun hrb.n0 () hrb.node)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun l2s_g_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun l2s_w_3 (hrb.node) Bool)
(declare-fun __l2s_w_2 (hrb.node) Bool)
(declare-fun l2s_g_3 (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_w_2 (hrb.node) Bool)
(declare-fun __l2s_w_4 () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_w_4 () Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_5 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun hrb.d (hrb.node) Bool)
(declare-fun l2s_w_5 () Bool)
(declare-fun __l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun __l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun __l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_s_12 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun __l2s_s_9 (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun __l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun __l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun __l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun __l2s_s_6 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun __l2s_s_3 (hrb.node hrb.quorum_b) Bool)
(declare-fun hrb.member_b (hrb.node hrb.quorum_b) Bool)
(declare-fun l2s_s_3 (hrb.node hrb.quorum_b) Bool)
(declare-fun __l2s_s_2 (hrb.node hrb.quorum_a) Bool)
(declare-fun hrb.member_a (hrb.node hrb.quorum_a) Bool)
(declare-fun l2s_s_2 (hrb.node hrb.quorum_a) Bool)
(declare-fun __l2s_saved () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_d (hrb.quorum_b) Bool)
(declare-fun __l2s_a_b (hrb.quorum_b) Bool)
(declare-fun l2s_a (hrb.quorum_b) Bool)
(declare-fun l2s_d (hrb.quorum_a) Bool)
(declare-fun __l2s_a_a (hrb.quorum_a) Bool)
(declare-fun l2s_a (hrb.quorum_a) Bool)
(declare-fun __l2s_a (hrb.node) Bool)
(declare-fun l2s_a (hrb.node) Bool)
(declare-fun __l2s_frozen () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun l2s_w_2 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun l2s_g_3 () Bool)
(assert (let ((a!1 (forall ((|A:hrb.quorum_a| hrb.quorum_a) (|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_2 |N:hrb.node| |A:hrb.quorum_a|)
                    (hrb.member_a |N:hrb.node| |A:hrb.quorum_a|)))))
      (a!2 (forall ((|B:hrb.quorum_b| hrb.quorum_b) (|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_3 |N:hrb.node| |B:hrb.quorum_b|)
                    (hrb.member_b |N:hrb.node| |B:hrb.quorum_b|)))))
      (a!3 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_6 |N:hrb.node|) (hrb.member_fc |N:hrb.node|)))))
      (a!4 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_7 |N:hrb.node|) (hrb.member_fi |N:hrb.node|)))))
      (a!5 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_8 |N:hrb.node|) (hrb.member_fs |N:hrb.node|)))))
      (a!6 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_5 |N:hrb.node|) (hrb.member_fa |N:hrb.node|)))))
      (a!7 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_9 |N:hrb.node|) (hrb.rcv_init |N:hrb.node|)))))
      (a!8 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
             (=> __l2s_saved
                 (=> (__l2s_s_1 |N1:hrb.node| |N2:hrb.node|)
                     (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|)))))
      (a!9 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (=> (__l2s_s_10 |N:hrb.node|) (hrb.sent_msg_proj |N:hrb.node|)))))
      (a!10 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> __l2s_saved
                  (=> (and (__l2s_s_0 |N1:hrb.node| |N2:hrb.node|)
                           (hrb.obedient |N2:hrb.node|))
                      (hrb.rcv_msg |N1:hrb.node| |N2:hrb.node|)))))
      (a!11 (forall ((|N:hrb.node| hrb.node))
              (=> __l2s_saved
                  (=> (and (__l2s_s_4 |N:hrb.node|) (hrb.obedient |N:hrb.node|))
                      (hrb.accept |N:hrb.node|)))))
      (a!12 (forall ((|M:hrb.node| hrb.node) (|N:hrb.node| hrb.node))
              (=> (and (hrb.correct |N:hrb.node|) (hrb.rcv_init |N:hrb.node|))
                  (not (l2s_g_2 |N:hrb.node| |M:hrb.node|)))))
      (a!13 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (l2s_g_0 |N1:hrb.node| |N2:hrb.node|)))
      (a!14 (exists ((|N:hrb.node| hrb.node))
              (and (hrb.correct |N:hrb.node|) (not (hrb.accept |N:hrb.node|)))))
      (a!15 (forall ((|N:hrb.node| hrb.node)) (hrb.d |N:hrb.node|)))
      (a!16 (forall ((|N:hrb.node| hrb.node))
              (=> (hrb.d |N:hrb.node|) (__l2s_d |N:hrb.node|))))
      (a!17 (forall ((|M:hrb.node| hrb.node) (|N:hrb.node| hrb.node))
              (=> (and __l2s_saved
                       (hrb.correct |N:hrb.node|)
                       (hrb.rcv_init |N:hrb.node|)
                       (not (__l2s_w_1 |N:hrb.node| |M:hrb.node|)))
                  (hrb.sent_msg |N:hrb.node| |M:hrb.node|))))
      (a!18 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> (and __l2s_saved
                       (hrb.correct |N2:hrb.node|)
                       (__l2s_s_1 |N1:hrb.node| |N2:hrb.node|)
                       (not (__l2s_w_0 |N1:hrb.node| |N2:hrb.node|)))
                  (hrb.rcv_msg |N1:hrb.node| |N2:hrb.node|))))
      (a!19 (exists ((|N:hrb.node| hrb.node))
              (and (hrb.obedient |N:hrb.node|) (hrb.accept |N:hrb.node|))))
      (a!20 (=> __l2s_saved
                (exists ((|N:hrb.node| hrb.node))
                  (and (hrb.obedient |N:hrb.node|) (__l2s_s_4 |N:hrb.node|)))))
      (a!21 (forall ((|B:hrb.quorum_b| hrb.quorum_b))
              (let ((a!1 (exists ((|M:hrb.node| hrb.node))
                           (and (hrb.member_b |M:hrb.node| |B:hrb.quorum_b|)
                                (not (hrb.rcv_msg |M:hrb.node| hrb.n1))))))
                (=> (and (hrb.correct hrb.n1) (not (hrb.accept hrb.n1))) a!1))))
      (a!22 (forall ((|A:hrb.quorum_a| hrb.quorum_a))
              (let ((a!1 (exists ((|M:hrb.node| hrb.node))
                           (and (hrb.member_a |M:hrb.node| |A:hrb.quorum_a|)
                                (not (hrb.rcv_msg |M:hrb.node| hrb.n2))))))
                (=> (and (hrb.correct hrb.n2) (not (hrb.sent_msg_proj hrb.n2)))
                    a!1))))
      (a!23 (=> (exists ((|N:hrb.node| hrb.node))
                  (and (hrb.correct |N:hrb.node|) (l2s_g_3 |N:hrb.node|)))
                (and (hrb.correct hrb.n1) l2s_g_5)))
      (a!24 (=> (exists ((|N:hrb.node| hrb.node))
                  (and (hrb.correct |N:hrb.node|) (l2s_g_4 |N:hrb.node|)))
                (and (hrb.correct hrb.n2) l2s_g_6)))
      (a!25 (forall ((|N:hrb.node| hrb.node))
              (=> (and __l2s_saved
                       (hrb.obedient |N:hrb.node|)
                       (not (__l2s_w_2 |N:hrb.node|)))
                  (or (hrb.accept |N:hrb.node|) (l2s_g_3 |N:hrb.node|)))))
      (a!26 (forall ((|N:hrb.node| hrb.node))
              (=> (and __l2s_saved
                       (hrb.obedient |N:hrb.node|)
                       (not (__l2s_w_3 |N:hrb.node|)))
                  (or (hrb.sent_msg_proj |N:hrb.node|) (l2s_g_4 |N:hrb.node|)))))
      (a!28 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> (and (hrb.obedient |N2:hrb.node|)
                       (hrb.rcv_msg |N1:hrb.node| |N2:hrb.node|))
                  (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|))))
      (a!29 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> (and (hrb.symmetric |N1:hrb.node|)
                       (hrb.sent_msg_proj |N1:hrb.node|))
                  (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|))))
      (a!30 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (let ((a!1 (exists ((|A:hrb.quorum_a| hrb.quorum_a))
                           (forall ((|M:hrb.node| hrb.node))
                             (=> (hrb.member_a |M:hrb.node| |A:hrb.quorum_a|)
                                 (hrb.sent_msg_proj |M:hrb.node|))))))
                (=> (and (hrb.obedient |N1:hrb.node|)
                         (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|)
                         (not (hrb.rcv_init |N1:hrb.node|)))
                    a!1))))
      (a!31 (forall ((|N1:hrb.node| hrb.node))
              (let ((a!1 (exists ((|B:hrb.quorum_b| hrb.quorum_b))
                           (forall ((|M:hrb.node| hrb.node))
                             (=> (hrb.member_b |M:hrb.node| |B:hrb.quorum_b|)
                                 (hrb.sent_msg_proj |M:hrb.node|))))))
                (=> (and (hrb.obedient |N1:hrb.node|)
                         (hrb.accept |N1:hrb.node|))
                    a!1))))
      (a!32 (exists ((|A:hrb.quorum_a| hrb.quorum_a))
              (forall ((|M:hrb.node| hrb.node))
                (=> (and (hrb.member_a |M:hrb.node| |A:hrb.quorum_a|)
                         (hrb.obedient |M:hrb.node|))
                    (hrb.sent_msg_proj |M:hrb.node|)))))
      (a!34 (forall ((|N:hrb.node| hrb.node))
              (= (hrb.obedient |N:hrb.node|)
                 (and (not (hrb.member_fs |N:hrb.node|))
                      (not (hrb.member_fa |N:hrb.node|))))))
      (a!35 (forall ((|N:hrb.node| hrb.node))
              (= (hrb.symmetric |N:hrb.node|)
                 (and (not (hrb.member_fi |N:hrb.node|))
                      (not (hrb.member_fa |N:hrb.node|))))))
      (a!36 (forall ((|N:hrb.node| hrb.node))
              (= (hrb.correct |N:hrb.node|)
                 (and (not (hrb.member_fc |N:hrb.node|))
                      (not (hrb.member_fi |N:hrb.node|))
                      (not (hrb.member_fs |N:hrb.node|))
                      (not (hrb.member_fa |N:hrb.node|))))))
      (a!37 (forall ((|B:hrb.quorum_b| hrb.quorum_b))
              (not (forall ((|N1:hrb.node| hrb.node))
                     (=> (hrb.member_b |N1:hrb.node| |B:hrb.quorum_b|)
                         (hrb.rcv_msg |N1:hrb.node| hrb.n0))))))
      (a!38 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (or (not __ts0_c)
                  (not __ts0_a)
                  (not (__l2s_w_1 |V0:hrb.node| |V1:hrb.node|)))))
      (a!39 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (or (not __ts0_c)
                  (not __ts0_a)
                  (not (__l2s_w_0 |V0:hrb.node| |V1:hrb.node|)))))
      (a!40 (forall ((|V0:hrb.node| hrb.node))
              (or (not __ts0_c) (not __ts0_a) (not (__l2s_w_2 |V0:hrb.node|)))))
      (a!41 (forall ((|V0:hrb.node| hrb.node))
              (or (not __ts0_c) (not __ts0_a) (not (__l2s_w_3 |V0:hrb.node|)))))
      (a!42 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (l2s_g_0 |V0:hrb.node| |V1:hrb.node|)
                  (=> (and (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)
                           (hrb.correct |V1:hrb.node|))
                      (not (l2s_g_1 |V0:hrb.node| |V1:hrb.node|))))))
      (a!43 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (l2s_g_1 |V0:hrb.node| |V1:hrb.node|)
                  (not (hrb.rcv_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!44 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (l2s_g_2 |V0:hrb.node| |V1:hrb.node|)
                  (not (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!45 (forall ((|V0:hrb.node| hrb.node))
              (=> (l2s_g_3 |V0:hrb.node|) (not (hrb.accept |V0:hrb.node|)))))
      (a!46 (forall ((|V0:hrb.node| hrb.node))
              (=> (l2s_g_4 |V0:hrb.node|)
                  (not (hrb.sent_msg_proj |V0:hrb.node|)))))
      (a!47 (not (forall ((|N:hrb.node| hrb.node))
                   (=> (hrb.correct |N:hrb.node|) (hrb.accept |N:hrb.node|)))))
      (a!48 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_a| hrb.quorum_a))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.quorum_a|))
                  (= (l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|)
                     (hrb.member_a |V0:hrb.node| |V1:hrb.quorum_a|)))))
      (a!49 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_b| hrb.quorum_b))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.quorum_b|))
                  (= (l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|)
                     (hrb.member_b |V0:hrb.node| |V1:hrb.quorum_b|)))))
      (a!50 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_6 |V0:hrb.node|) (hrb.member_fc |V0:hrb.node|)))))
      (a!51 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_7 |V0:hrb.node|) (hrb.member_fi |V0:hrb.node|)))))
      (a!52 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_8 |V0:hrb.node|) (hrb.member_fs |V0:hrb.node|)))))
      (a!53 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_5 |V0:hrb.node|) (hrb.member_fa |V0:hrb.node|)))))
      (a!54 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_9 |V0:hrb.node|) (hrb.rcv_init |V0:hrb.node|)))))
      (a!55 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.node|))
                  (= (l2s_s_1 |V0:hrb.node| |V1:hrb.node|)
                     (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!56 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_10 |V0:hrb.node|) (hrb.sent_msg_proj |V0:hrb.node|)))))
      (a!57 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.node|))
                  (= (l2s_s_0 |V0:hrb.node| |V1:hrb.node|)
                     (hrb.rcv_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!58 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_4 |V0:hrb.node|) (hrb.accept |V0:hrb.node|)))))
      (a!59 (=> (and (or (l2s_a l2s_s_11) (l2s_a hrb.n1))) (= l2s_s_11 hrb.n1)))
      (a!60 (=> (and (or (l2s_a l2s_s_12) (l2s_a hrb.n2))) (= l2s_s_12 hrb.n2)))
      (a!61 (exists ((|B:hrb.quorum_b| hrb.quorum_b))
              (forall ((|N:hrb.node| hrb.node))
                (=> (hrb.member_b |N:hrb.node| |B:hrb.quorum_b|)
                    (and (not (hrb.member_fa |N:hrb.node|))
                         (not (hrb.member_fc |N:hrb.node|))
                         (not (hrb.member_fs |N:hrb.node|))
                         (not (hrb.member_fi |N:hrb.node|)))))))
      (a!62 (forall ((|A_BP:hrb.quorum_a| hrb.quorum_a))
              (exists ((|N:hrb.node| hrb.node))
                (and (hrb.member_a |N:hrb.node| |A_BP:hrb.quorum_a|)
                     (not (hrb.member_fa |N:hrb.node|))
                     (not (hrb.member_fs |N:hrb.node|))))))
      (a!63 (forall ((|B_CF:hrb.quorum_b| hrb.quorum_b))
              (exists ((|A:hrb.quorum_a| hrb.quorum_a))
                (forall ((|N:hrb.node| hrb.node))
                  (=> (hrb.member_a |N:hrb.node| |A:hrb.quorum_a|)
                      (and (hrb.member_b |N:hrb.node| |B_CF:hrb.quorum_b|)
                           (not (hrb.member_fa |N:hrb.node|))
                           (not (hrb.member_fi |N:hrb.node|))))))))
      (a!64 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fc |N:hrb.node|)
                        (hrb.member_fi |N:hrb.node|)))))
      (a!65 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fc |N:hrb.node|)
                        (hrb.member_fs |N:hrb.node|)))))
      (a!66 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fc |N:hrb.node|)
                        (hrb.member_fa |N:hrb.node|)))))
      (a!67 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fi |N:hrb.node|)
                        (hrb.member_fs |N:hrb.node|)))))
      (a!68 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fi |N:hrb.node|)
                        (hrb.member_fa |N:hrb.node|)))))
      (a!69 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fs |N:hrb.node|)
                        (hrb.member_fa |N:hrb.node|)))))
      (a!70 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_a |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_a |V0:hrb.node|)
                      (ite __ts0_b
                           (__l2s_a |V0:hrb.node|)
                           (__l2s_d |V0:hrb.node|))))))
      (a!71 (forall ((|V0:hrb.quorum_a| hrb.quorum_a))
              (= (l2s_a |V0:hrb.quorum_a|)
                 (ite __ts0_d
                      (__l2s_a_a |V0:hrb.quorum_a|)
                      (ite __ts0_b
                           (__l2s_a_a |V0:hrb.quorum_a|)
                           (l2s_d |V0:hrb.quorum_a|))))))
      (a!72 (forall ((|V0:hrb.quorum_b| hrb.quorum_b))
              (= (l2s_a |V0:hrb.quorum_b|)
                 (ite __ts0_d
                      (__l2s_a_b |V0:hrb.quorum_b|)
                      (ite __ts0_b
                           (__l2s_a_b |V0:hrb.quorum_b|)
                           (l2s_d |V0:hrb.quorum_b|))))))
      (a!73 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_a| hrb.quorum_a))
              (= (l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|)
                 (ite __ts0_d
                      (__l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|)
                      (ite __ts0_b
                           (hrb.member_a |V0:hrb.node| |V1:hrb.quorum_a|)
                           (__l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|))))))
      (a!74 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_b| hrb.quorum_b))
              (= (l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|)
                 (ite __ts0_d
                      (__l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|)
                      (ite __ts0_b
                           (hrb.member_b |V0:hrb.node| |V1:hrb.quorum_b|)
                           (__l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|))))))
      (a!75 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_6 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_6 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fc |V0:hrb.node|)
                           (__l2s_s_6 |V0:hrb.node|))))))
      (a!76 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_7 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_7 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fi |V0:hrb.node|)
                           (__l2s_s_7 |V0:hrb.node|))))))
      (a!77 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_8 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_8 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fs |V0:hrb.node|)
                           (__l2s_s_8 |V0:hrb.node|))))))
      (a!78 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_5 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_5 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fa |V0:hrb.node|)
                           (__l2s_s_5 |V0:hrb.node|))))))
      (a!79 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_9 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_9 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.rcv_init |V0:hrb.node|)
                           (__l2s_s_9 |V0:hrb.node|))))))
      (a!80 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (= (l2s_s_1 |V0:hrb.node| |V1:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_1 |V0:hrb.node| |V1:hrb.node|)
                      (ite __ts0_b
                           (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)
                           (__l2s_s_1 |V0:hrb.node| |V1:hrb.node|))))))
      (a!81 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_10 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_10 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.sent_msg_proj |V0:hrb.node|)
                           (__l2s_s_10 |V0:hrb.node|))))))
      (a!82 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (= (l2s_s_0 |V0:hrb.node| |V1:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_0 |V0:hrb.node| |V1:hrb.node|)
                      (ite __ts0_b
                           (hrb.rcv_msg |V0:hrb.node| |V1:hrb.node|)
                           (__l2s_s_0 |V0:hrb.node| |V1:hrb.node|))))))
      (a!83 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_4 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_4 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.accept |V0:hrb.node|)
                           (__l2s_s_4 |V0:hrb.node|))))))
      (a!85 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (let ((a!1 (ite __ts0_b
                              (and (__l2s_d |V0:hrb.node|)
                                   (__l2s_d |V1:hrb.node|)
                                   (not (hrb.sent_msg |V0:hrb.node|
                                                      |V1:hrb.node|))
                                   (not (l2s_g_2 |V0:hrb.node| |V1:hrb.node|)))
                              (__l2s_w_1 |V0:hrb.node| |V1:hrb.node|))))
                (= (l2s_w_1 |V0:hrb.node| |V1:hrb.node|)
                   (ite __ts0_d (__l2s_w_1 |V0:hrb.node| |V1:hrb.node|) a!1)))))
      (a!86 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (let ((a!1 (ite __ts0_b
                              (and (__l2s_d |V0:hrb.node|)
                                   (__l2s_d |V1:hrb.node|)
                                   (not (hrb.rcv_msg |V0:hrb.node|
                                                     |V1:hrb.node|))
                                   (not (l2s_g_1 |V0:hrb.node| |V1:hrb.node|)))
                              (__l2s_w_0 |V0:hrb.node| |V1:hrb.node|))))
                (= (l2s_w_0 |V0:hrb.node| |V1:hrb.node|)
                   (ite __ts0_d (__l2s_w_0 |V0:hrb.node| |V1:hrb.node|) a!1)))))
      (a!88 (forall ((|V0:hrb.node| hrb.node))
              (let ((a!1 (ite __ts0_b
                              (and (__l2s_d |V0:hrb.node|)
                                   (not (hrb.accept |V0:hrb.node|))
                                   (not (l2s_g_3 |V0:hrb.node|)))
                              (__l2s_w_2 |V0:hrb.node|))))
                (= (l2s_w_2 |V0:hrb.node|)
                   (ite __ts0_d (__l2s_w_2 |V0:hrb.node|) a!1)))))
      (a!89 (forall ((|V0:hrb.node| hrb.node))
              (let ((a!1 (ite __ts0_b
                              (and (__l2s_d |V0:hrb.node|)
                                   (not (hrb.sent_msg_proj |V0:hrb.node|))
                                   (not (l2s_g_4 |V0:hrb.node|)))
                              (__l2s_w_3 |V0:hrb.node|))))
                (= (l2s_w_3 |V0:hrb.node|)
                   (ite __ts0_d (__l2s_w_3 |V0:hrb.node|) a!1)))))
      (a!90 (forall ((|V0:hrb.node| hrb.node))
              (= (__m_l2s_d |V0:hrb.node|)
                 (ite (and (= |V0:hrb.node| hrb.n0))
                      true
                      (__l2s_d |V0:hrb.node|)))))
      (a!91 (forall ((|V0:hrb.node| hrb.node))
              (= (__m_l2s_d_a |V0:hrb.node|)
                 (ite (and (= |V0:hrb.node| hrb.n1))
                      true
                      (__m_l2s_d |V0:hrb.node|)))))
      (a!92 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_d |V0:hrb.node|)
                 (ite (and (= |V0:hrb.node| hrb.n2))
                      true
                      (__m_l2s_d_a |V0:hrb.node|))))))
(let ((a!27 (=> a!19
                (exists ((|M:hrb.node| hrb.node))
                  (and (hrb.obedient |M:hrb.node|) (hrb.rcv_init |M:hrb.node|)))))
      (a!33 (=> a!32
                (exists ((|N:hrb.node| hrb.node))
                  (and (hrb.obedient |N:hrb.node|) (hrb.rcv_init |N:hrb.node|)))))
      (a!84 (ite __ts0_d
                 __l2s_w_5
                 (ite __ts0_b (and (not a!15) (not l2s_g_8)) __l2s_w_5)))
      (a!87 (ite __ts0_d
                 __l2s_w_4
                 (ite __ts0_b (and (not a!19) (not l2s_g_7)) __l2s_w_4))))
  (and (or __l2s_waiting __l2s_frozen __l2s_saved)
       (or (not __l2s_waiting) (not __l2s_frozen))
       (or (not __l2s_waiting) (not __l2s_saved))
       (or (not __l2s_frozen) (not __l2s_saved))
       a!1
       a!2
       a!3
       a!4
       a!5
       a!6
       a!7
       (=> __l2s_saved (= __l2s_s_11 hrb.n1))
       (=> __l2s_saved (= __l2s_s_12 hrb.n2))
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       (not l2s_g_7)
       l2s_g_9
       a!14
       (not l2s_g_8)
       (or __l2s_w_5 a!15)
       a!16
       (=> (not __l2s_waiting)
           (forall ((|N:hrb.node| hrb.node)) (__l2s_d |N:hrb.node|)))
       (=> (not __l2s_waiting)
           (forall ((|N:hrb.node| hrb.node)) (__l2s_a |N:hrb.node|)))
       a!17
       a!18
       (or __l2s_w_4 a!19)
       (=> (not __l2s_waiting) a!19)
       a!20
       a!21
       a!22
       a!23
       a!24
       a!25
       a!26
       a!27
       (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
         (=> (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|)
             (hrb.sent_msg_proj |N1:hrb.node|)))
       a!28
       a!29
       a!30
       a!31
       a!33
       a!34
       a!35
       a!36
       (or __l2s_waiting __l2s_frozen __l2s_saved)
       (or (not __l2s_waiting) (not __l2s_frozen))
       (or (not __l2s_waiting) (not __l2s_saved))
       (or (not __l2s_frozen) (not __l2s_saved))
       a!1
       a!2
       a!3
       a!4
       a!5
       a!6
       a!7
       (=> __l2s_saved (= __l2s_s_11 hrb.n0))
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       (forall ((|N1:hrb.node| hrb.node))
         (=> (hrb.obedient |N1:hrb.node|) (hrb.rcv_init |N1:hrb.node|)))
       l2s_g_3
       (not l2s_g_4)
       (or l2s_w_2 a!15)
       a!16
       (=> (not __l2s_waiting)
           (forall ((|N:hrb.node| hrb.node)) (__l2s_d |N:hrb.node|)))
       (=> (not __l2s_waiting)
           (forall ((|N:hrb.node| hrb.node)) (__l2s_a |N:hrb.node|)))
       a!17
       a!18
       (hrb.correct hrb.n0)
       a!37
       (or __ts0_c __ts0_d)
       (or (not __ts0_c) __ts0_a __ts0_b)
       (or (not __ts0_c) (not __ts0_a) __l2s_waiting)
       (or (not __ts0_c) (not __ts0_a) (not __l2s_w_5))
       a!38
       a!39
       (or (not __ts0_c) (not __ts0_a) (not __l2s_w_4))
       a!40
       a!41
       (or (not __ts0_c) (not __ts0_b) __l2s_frozen)
       a!42
       a!43
       a!44
       a!45
       a!46
       (=> l2s_g_5 (not (hrb.accept hrb.n1)))
       (=> l2s_g_6 (not (hrb.sent_msg_proj hrb.n2)))
       (=> l2s_g_7 (not a!19))
       (=> l2s_g_8 (not a!15))
       (=> l2s_g_9 a!47)
       l2s_saved
       (not l2s_w_5)
       (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
         (not (l2s_w_1 |V0:hrb.node| |V1:hrb.node|)))
       (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
         (not (l2s_w_0 |V0:hrb.node| |V1:hrb.node|)))
       (not l2s_w_4)
       (forall ((|V0:hrb.node| hrb.node)) (not (l2s_w_2 |V0:hrb.node|)))
       (forall ((|V0:hrb.node| hrb.node)) (not (l2s_w_3 |V0:hrb.node|)))
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       a!54
       a!55
       a!56
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67
       a!68
       a!69
       (= l2s_waiting
          (ite __ts0_d __l2s_waiting (ite __ts0_b __l2s_waiting false)))
       (= l2s_frozen (ite __ts0_d __l2s_frozen (ite __ts0_b false true)))
       a!70
       a!71
       a!72
       (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved)))
       a!73
       a!74
       a!75
       a!76
       a!77
       a!78
       a!79
       (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n1 __l2s_s_11)))
       (= l2s_s_12 (ite __ts0_d __l2s_s_12 (ite __ts0_b hrb.n2 __l2s_s_12)))
       a!80
       a!81
       a!82
       a!83
       (= l2s_w_5 a!84)
       a!85
       a!86
       (= l2s_w_4 a!87)
       a!88
       a!89
       a!90
       a!91
       a!92
       a!34
       a!35
       a!36))))
(assert (and (not false)))
