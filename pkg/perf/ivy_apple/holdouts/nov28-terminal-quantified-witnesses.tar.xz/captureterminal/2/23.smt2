(declare-sort hrb.quorum_b)
(declare-sort hrb.node)
(declare-sort hrb.quorum_a)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun __m_l2s_d_a (hrb.node) Bool)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_d (hrb.node) Bool)
(declare-fun __m_l2s_d (hrb.node) Bool)
(declare-fun hrb.n1 () hrb.node)
(declare-fun __l2s_d (hrb.node) Bool)
(declare-fun hrb.n0 () hrb.node)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_2 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.d (hrb.node) Bool)
(declare-fun l2s_w_2 () Bool)
(declare-fun __l2s_s_4 (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun __l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_s_10 (hrb.node) Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun __l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun __l2s_s_9 (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun __l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun __l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun __l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun __l2s_s_6 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun __l2s_s_3 (hrb.node hrb.quorum_b) Bool)
(declare-fun hrb.member_b (hrb.node hrb.quorum_b) Bool)
(declare-fun l2s_s_3 (hrb.node hrb.quorum_b) Bool)
(declare-fun __l2s_s_2 (hrb.node hrb.quorum_a) Bool)
(declare-fun hrb.member_a (hrb.node hrb.quorum_a) Bool)
(declare-fun l2s_s_2 (hrb.node hrb.quorum_a) Bool)
(declare-fun __l2s_saved () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_d (hrb.quorum_b) Bool)
(declare-fun __l2s_a_b (hrb.quorum_b) Bool)
(declare-fun l2s_a (hrb.quorum_b) Bool)
(declare-fun l2s_d (hrb.quorum_a) Bool)
(declare-fun __l2s_a_a (hrb.quorum_a) Bool)
(declare-fun l2s_a (hrb.quorum_a) Bool)
(declare-fun __l2s_a (hrb.node) Bool)
(declare-fun l2s_a (hrb.node) Bool)
(declare-fun __l2s_frozen () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_a () Bool)
(assert (let ((a!1 (forall ((|A:hrb.quorum_a| hrb.quorum_a) (|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_2 |N:hrb.node| |A:hrb.quorum_a|)
                    (hrb.member_a |N:hrb.node| |A:hrb.quorum_a|)))))
      (a!2 (forall ((|B:hrb.quorum_b| hrb.quorum_b) (|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_3 |N:hrb.node| |B:hrb.quorum_b|)
                    (hrb.member_b |N:hrb.node| |B:hrb.quorum_b|)))))
      (a!3 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_6 |N:hrb.node|) (hrb.member_fc |N:hrb.node|)))))
      (a!4 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_7 |N:hrb.node|) (hrb.member_fi |N:hrb.node|)))))
      (a!5 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_8 |N:hrb.node|) (hrb.member_fs |N:hrb.node|)))))
      (a!6 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_5 |N:hrb.node|) (hrb.member_fa |N:hrb.node|)))))
      (a!7 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (= (__l2s_s_9 |N:hrb.node|) (hrb.rcv_init |N:hrb.node|)))))
      (a!8 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
             (=> __l2s_saved
                 (=> (__l2s_s_1 |N1:hrb.node| |N2:hrb.node|)
                     (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|)))))
      (a!9 (forall ((|N:hrb.node| hrb.node))
             (=> __l2s_saved
                 (=> (__l2s_s_10 |N:hrb.node|) (hrb.sent_msg_proj |N:hrb.node|)))))
      (a!10 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> __l2s_saved
                  (=> (and (__l2s_s_0 |N1:hrb.node| |N2:hrb.node|)
                           (hrb.obedient |N2:hrb.node|))
                      (hrb.rcv_msg |N1:hrb.node| |N2:hrb.node|)))))
      (a!11 (forall ((|N:hrb.node| hrb.node))
              (=> __l2s_saved
                  (=> (and (__l2s_s_4 |N:hrb.node|) (hrb.obedient |N:hrb.node|))
                      (hrb.accept |N:hrb.node|)))))
      (a!12 (forall ((|M:hrb.node| hrb.node) (|N:hrb.node| hrb.node))
              (=> (and (hrb.correct |N:hrb.node|) (hrb.rcv_init |N:hrb.node|))
                  (not (l2s_g_2 |N:hrb.node| |M:hrb.node|)))))
      (a!13 (forall ((|N:hrb.node| hrb.node)) (hrb.d |N:hrb.node|)))
      (a!14 (forall ((|M:hrb.node| hrb.node) (|N:hrb.node| hrb.node))
              (=> (and __l2s_saved
                       (hrb.correct |N:hrb.node|)
                       (hrb.rcv_init |N:hrb.node|)
                       (not (__l2s_w_1 |N:hrb.node| |M:hrb.node|)))
                  (hrb.sent_msg |N:hrb.node| |M:hrb.node|))))
      (a!15 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> (and __l2s_saved
                       (hrb.correct |N2:hrb.node|)
                       (__l2s_s_1 |N1:hrb.node| |N2:hrb.node|)
                       (not (__l2s_w_0 |N1:hrb.node| |N2:hrb.node|)))
                  (hrb.rcv_msg |N1:hrb.node| |N2:hrb.node|))))
      (a!16 (forall ((|B:hrb.quorum_b| hrb.quorum_b))
              (not (forall ((|N1:hrb.node| hrb.node))
                     (=> (hrb.member_b |N1:hrb.node| |B:hrb.quorum_b|)
                         (hrb.rcv_msg |N1:hrb.node| hrb.n0))))))
      (a!17 (=> (exists ((|N:hrb.node| hrb.node))
                  (and (hrb.obedient |N:hrb.node|) (hrb.accept |N:hrb.node|)))
                (exists ((|M:hrb.node| hrb.node))
                  (and (hrb.obedient |M:hrb.node|) (hrb.rcv_init |M:hrb.node|)))))
      (a!18 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> (and (hrb.obedient |N2:hrb.node|)
                       (hrb.rcv_msg |N1:hrb.node| |N2:hrb.node|))
                  (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|))))
      (a!19 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (=> (and (hrb.symmetric |N1:hrb.node|)
                       (hrb.sent_msg_proj |N1:hrb.node|))
                  (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|))))
      (a!20 (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
              (let ((a!1 (exists ((|A:hrb.quorum_a| hrb.quorum_a))
                           (forall ((|M:hrb.node| hrb.node))
                             (=> (hrb.member_a |M:hrb.node| |A:hrb.quorum_a|)
                                 (hrb.sent_msg_proj |M:hrb.node|))))))
                (=> (and (hrb.obedient |N1:hrb.node|)
                         (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|)
                         (not (hrb.rcv_init |N1:hrb.node|)))
                    a!1))))
      (a!21 (forall ((|N1:hrb.node| hrb.node))
              (let ((a!1 (exists ((|B:hrb.quorum_b| hrb.quorum_b))
                           (forall ((|M:hrb.node| hrb.node))
                             (=> (hrb.member_b |M:hrb.node| |B:hrb.quorum_b|)
                                 (hrb.sent_msg_proj |M:hrb.node|))))))
                (=> (and (hrb.obedient |N1:hrb.node|)
                         (hrb.accept |N1:hrb.node|))
                    a!1))))
      (a!22 (exists ((|A:hrb.quorum_a| hrb.quorum_a))
              (forall ((|M:hrb.node| hrb.node))
                (=> (and (hrb.member_a |M:hrb.node| |A:hrb.quorum_a|)
                         (hrb.obedient |M:hrb.node|))
                    (hrb.sent_msg_proj |M:hrb.node|)))))
      (a!24 (forall ((|N:hrb.node| hrb.node))
              (= (hrb.obedient |N:hrb.node|)
                 (and (not (hrb.member_fs |N:hrb.node|))
                      (not (hrb.member_fa |N:hrb.node|))))))
      (a!25 (forall ((|N:hrb.node| hrb.node))
              (= (hrb.symmetric |N:hrb.node|)
                 (and (not (hrb.member_fi |N:hrb.node|))
                      (not (hrb.member_fa |N:hrb.node|))))))
      (a!26 (forall ((|N:hrb.node| hrb.node))
              (= (hrb.correct |N:hrb.node|)
                 (and (not (hrb.member_fc |N:hrb.node|))
                      (not (hrb.member_fi |N:hrb.node|))
                      (not (hrb.member_fs |N:hrb.node|))
                      (not (hrb.member_fa |N:hrb.node|))))))
      (a!27 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (or (not __ts0_c)
                  (not __ts0_a)
                  (not (__l2s_w_1 |V0:hrb.node| |V1:hrb.node|)))))
      (a!28 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (or (not __ts0_c)
                  (not __ts0_a)
                  (not (__l2s_w_0 |V0:hrb.node| |V1:hrb.node|)))))
      (a!29 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (l2s_g_0 |V0:hrb.node| |V1:hrb.node|)
                  (=> (and (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)
                           (hrb.correct |V1:hrb.node|))
                      (not (l2s_g_1 |V0:hrb.node| |V1:hrb.node|))))))
      (a!30 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (l2s_g_1 |V0:hrb.node| |V1:hrb.node|)
                  (not (hrb.rcv_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!31 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (l2s_g_2 |V0:hrb.node| |V1:hrb.node|)
                  (not (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!32 (not (exists ((|N2:hrb.node| hrb.node))
                   (and (hrb.correct |N2:hrb.node|) (hrb.accept |N2:hrb.node|)))))
      (a!33 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_a| hrb.quorum_a))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.quorum_a|))
                  (= (l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|)
                     (hrb.member_a |V0:hrb.node| |V1:hrb.quorum_a|)))))
      (a!34 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_b| hrb.quorum_b))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.quorum_b|))
                  (= (l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|)
                     (hrb.member_b |V0:hrb.node| |V1:hrb.quorum_b|)))))
      (a!35 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_6 |V0:hrb.node|) (hrb.member_fc |V0:hrb.node|)))))
      (a!36 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_7 |V0:hrb.node|) (hrb.member_fi |V0:hrb.node|)))))
      (a!37 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_8 |V0:hrb.node|) (hrb.member_fs |V0:hrb.node|)))))
      (a!38 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_5 |V0:hrb.node|) (hrb.member_fa |V0:hrb.node|)))))
      (a!39 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_9 |V0:hrb.node|) (hrb.rcv_init |V0:hrb.node|)))))
      (a!40 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.node|))
                  (= (l2s_s_1 |V0:hrb.node| |V1:hrb.node|)
                     (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!41 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_10 |V0:hrb.node|) (hrb.sent_msg_proj |V0:hrb.node|)))))
      (a!42 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|) (l2s_a |V1:hrb.node|))
                  (= (l2s_s_0 |V0:hrb.node| |V1:hrb.node|)
                     (hrb.rcv_msg |V0:hrb.node| |V1:hrb.node|)))))
      (a!43 (forall ((|V0:hrb.node| hrb.node))
              (=> (and (l2s_a |V0:hrb.node|))
                  (= (l2s_s_4 |V0:hrb.node|) (hrb.accept |V0:hrb.node|)))))
      (a!44 (=> (and (or (l2s_a l2s_s_11) (l2s_a hrb.n0))) (= l2s_s_11 hrb.n0)))
      (a!45 (exists ((|B:hrb.quorum_b| hrb.quorum_b))
              (forall ((|N:hrb.node| hrb.node))
                (=> (hrb.member_b |N:hrb.node| |B:hrb.quorum_b|)
                    (and (not (hrb.member_fa |N:hrb.node|))
                         (not (hrb.member_fc |N:hrb.node|))
                         (not (hrb.member_fs |N:hrb.node|))
                         (not (hrb.member_fi |N:hrb.node|)))))))
      (a!46 (forall ((|A_BP:hrb.quorum_a| hrb.quorum_a))
              (exists ((|N:hrb.node| hrb.node))
                (and (hrb.member_a |N:hrb.node| |A_BP:hrb.quorum_a|)
                     (not (hrb.member_fa |N:hrb.node|))
                     (not (hrb.member_fs |N:hrb.node|))))))
      (a!47 (forall ((|B_CF:hrb.quorum_b| hrb.quorum_b))
              (exists ((|A:hrb.quorum_a| hrb.quorum_a))
                (forall ((|N:hrb.node| hrb.node))
                  (=> (hrb.member_a |N:hrb.node| |A:hrb.quorum_a|)
                      (and (hrb.member_b |N:hrb.node| |B_CF:hrb.quorum_b|)
                           (not (hrb.member_fa |N:hrb.node|))
                           (not (hrb.member_fi |N:hrb.node|))))))))
      (a!48 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fc |N:hrb.node|)
                        (hrb.member_fi |N:hrb.node|)))))
      (a!49 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fc |N:hrb.node|)
                        (hrb.member_fs |N:hrb.node|)))))
      (a!50 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fc |N:hrb.node|)
                        (hrb.member_fa |N:hrb.node|)))))
      (a!51 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fi |N:hrb.node|)
                        (hrb.member_fs |N:hrb.node|)))))
      (a!52 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fi |N:hrb.node|)
                        (hrb.member_fa |N:hrb.node|)))))
      (a!53 (forall ((|N:hrb.node| hrb.node))
              (not (and (hrb.member_fs |N:hrb.node|)
                        (hrb.member_fa |N:hrb.node|)))))
      (a!54 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_a |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_a |V0:hrb.node|)
                      (ite __ts0_b
                           (__l2s_a |V0:hrb.node|)
                           (__l2s_d |V0:hrb.node|))))))
      (a!55 (forall ((|V0:hrb.quorum_a| hrb.quorum_a))
              (= (l2s_a |V0:hrb.quorum_a|)
                 (ite __ts0_d
                      (__l2s_a_a |V0:hrb.quorum_a|)
                      (ite __ts0_b
                           (__l2s_a_a |V0:hrb.quorum_a|)
                           (l2s_d |V0:hrb.quorum_a|))))))
      (a!56 (forall ((|V0:hrb.quorum_b| hrb.quorum_b))
              (= (l2s_a |V0:hrb.quorum_b|)
                 (ite __ts0_d
                      (__l2s_a_b |V0:hrb.quorum_b|)
                      (ite __ts0_b
                           (__l2s_a_b |V0:hrb.quorum_b|)
                           (l2s_d |V0:hrb.quorum_b|))))))
      (a!57 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_a| hrb.quorum_a))
              (= (l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|)
                 (ite __ts0_d
                      (__l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|)
                      (ite __ts0_b
                           (hrb.member_a |V0:hrb.node| |V1:hrb.quorum_a|)
                           (__l2s_s_2 |V0:hrb.node| |V1:hrb.quorum_a|))))))
      (a!58 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.quorum_b| hrb.quorum_b))
              (= (l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|)
                 (ite __ts0_d
                      (__l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|)
                      (ite __ts0_b
                           (hrb.member_b |V0:hrb.node| |V1:hrb.quorum_b|)
                           (__l2s_s_3 |V0:hrb.node| |V1:hrb.quorum_b|))))))
      (a!59 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_6 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_6 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fc |V0:hrb.node|)
                           (__l2s_s_6 |V0:hrb.node|))))))
      (a!60 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_7 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_7 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fi |V0:hrb.node|)
                           (__l2s_s_7 |V0:hrb.node|))))))
      (a!61 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_8 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_8 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fs |V0:hrb.node|)
                           (__l2s_s_8 |V0:hrb.node|))))))
      (a!62 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_5 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_5 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.member_fa |V0:hrb.node|)
                           (__l2s_s_5 |V0:hrb.node|))))))
      (a!63 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_9 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_9 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.rcv_init |V0:hrb.node|)
                           (__l2s_s_9 |V0:hrb.node|))))))
      (a!64 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (= (l2s_s_1 |V0:hrb.node| |V1:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_1 |V0:hrb.node| |V1:hrb.node|)
                      (ite __ts0_b
                           (hrb.sent_msg |V0:hrb.node| |V1:hrb.node|)
                           (__l2s_s_1 |V0:hrb.node| |V1:hrb.node|))))))
      (a!65 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_10 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_10 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.sent_msg_proj |V0:hrb.node|)
                           (__l2s_s_10 |V0:hrb.node|))))))
      (a!66 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (= (l2s_s_0 |V0:hrb.node| |V1:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_0 |V0:hrb.node| |V1:hrb.node|)
                      (ite __ts0_b
                           (hrb.rcv_msg |V0:hrb.node| |V1:hrb.node|)
                           (__l2s_s_0 |V0:hrb.node| |V1:hrb.node|))))))
      (a!67 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_s_4 |V0:hrb.node|)
                 (ite __ts0_d
                      (__l2s_s_4 |V0:hrb.node|)
                      (ite __ts0_b
                           (hrb.accept |V0:hrb.node|)
                           (__l2s_s_4 |V0:hrb.node|))))))
      (a!69 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (let ((a!1 (ite __ts0_b
                              (and (__l2s_d |V0:hrb.node|)
                                   (__l2s_d |V1:hrb.node|)
                                   (not (hrb.sent_msg |V0:hrb.node|
                                                      |V1:hrb.node|))
                                   (not (l2s_g_2 |V0:hrb.node| |V1:hrb.node|)))
                              (__l2s_w_1 |V0:hrb.node| |V1:hrb.node|))))
                (= (l2s_w_1 |V0:hrb.node| |V1:hrb.node|)
                   (ite __ts0_d (__l2s_w_1 |V0:hrb.node| |V1:hrb.node|) a!1)))))
      (a!70 (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
              (let ((a!1 (ite __ts0_b
                              (and (__l2s_d |V0:hrb.node|)
                                   (__l2s_d |V1:hrb.node|)
                                   (not (hrb.rcv_msg |V0:hrb.node|
                                                     |V1:hrb.node|))
                                   (not (l2s_g_1 |V0:hrb.node| |V1:hrb.node|)))
                              (__l2s_w_0 |V0:hrb.node| |V1:hrb.node|))))
                (= (l2s_w_0 |V0:hrb.node| |V1:hrb.node|)
                   (ite __ts0_d (__l2s_w_0 |V0:hrb.node| |V1:hrb.node|) a!1)))))
      (a!71 (forall ((|V0:hrb.node| hrb.node))
              (= (__m_l2s_d |V0:hrb.node|)
                 (ite (and (= |V0:hrb.node| hrb.n0))
                      true
                      (__l2s_d |V0:hrb.node|)))))
      (a!72 (forall ((|V0:hrb.node| hrb.node))
              (= (__m_l2s_d_a |V0:hrb.node|)
                 (ite (and (= |V0:hrb.node| hrb.n1))
                      true
                      (__m_l2s_d |V0:hrb.node|)))))
      (a!73 (forall ((|V0:hrb.node| hrb.node))
              (= (l2s_d |V0:hrb.node|)
                 (ite (and (= |V0:hrb.node| hrb.n2))
                      true
                      (__m_l2s_d_a |V0:hrb.node|))))))
(let ((a!23 (=> a!22
                (exists ((|N:hrb.node| hrb.node))
                  (and (hrb.obedient |N:hrb.node|) (hrb.rcv_init |N:hrb.node|)))))
      (a!68 (ite __ts0_d
                 __l2s_w_2
                 (ite __ts0_b (and (not a!13) (not l2s_g_4)) __l2s_w_2))))
  (and (or __l2s_waiting __l2s_frozen __l2s_saved)
       (or (not __l2s_waiting) (not __l2s_frozen))
       (or (not __l2s_waiting) (not __l2s_saved))
       (or (not __l2s_frozen) (not __l2s_saved))
       a!1
       a!2
       a!3
       a!4
       a!5
       a!6
       a!7
       (=> __l2s_saved (= __l2s_s_11 hrb.n0))
       a!8
       a!9
       a!10
       a!11
       a!12
       (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
         (l2s_g_0 |N1:hrb.node| |N2:hrb.node|))
       (forall ((|N1:hrb.node| hrb.node))
         (=> (hrb.obedient |N1:hrb.node|) (hrb.rcv_init |N1:hrb.node|)))
       l2s_g_3
       (not l2s_g_4)
       (or __l2s_w_2 a!13)
       (forall ((|N:hrb.node| hrb.node))
         (=> (hrb.d |N:hrb.node|) (__l2s_d |N:hrb.node|)))
       (=> (not __l2s_waiting)
           (forall ((|N:hrb.node| hrb.node)) (__l2s_d |N:hrb.node|)))
       (=> (not __l2s_waiting)
           (forall ((|N:hrb.node| hrb.node)) (__l2s_a |N:hrb.node|)))
       a!14
       a!15
       (hrb.correct hrb.n0)
       a!16
       a!17
       (forall ((|N1:hrb.node| hrb.node) (|N2:hrb.node| hrb.node))
         (=> (hrb.sent_msg |N1:hrb.node| |N2:hrb.node|)
             (hrb.sent_msg_proj |N1:hrb.node|)))
       a!18
       a!19
       a!20
       a!21
       a!23
       a!24
       a!25
       a!26
       (or __ts0_c __ts0_d)
       (or (not __ts0_c) __ts0_a __ts0_b)
       (or (not __ts0_c) (not __ts0_a) __l2s_waiting)
       (or (not __ts0_c) (not __ts0_a) (not __l2s_w_2))
       a!27
       a!28
       (or (not __ts0_c) (not __ts0_b) __l2s_frozen)
       a!29
       a!30
       a!31
       (=> l2s_g_3 a!32)
       (=> l2s_g_4 (not a!13))
       l2s_saved
       (not l2s_w_2)
       (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
         (not (l2s_w_1 |V0:hrb.node| |V1:hrb.node|)))
       (forall ((|V0:hrb.node| hrb.node) (|V1:hrb.node| hrb.node))
         (not (l2s_w_0 |V0:hrb.node| |V1:hrb.node|)))
       a!33
       a!34
       a!35
       a!36
       a!37
       a!38
       a!39
       a!40
       a!41
       a!42
       a!43
       a!44
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       a!51
       a!52
       a!53
       (= l2s_waiting
          (ite __ts0_d __l2s_waiting (ite __ts0_b __l2s_waiting false)))
       (= l2s_frozen (ite __ts0_d __l2s_frozen (ite __ts0_b false true)))
       a!54
       a!55
       a!56
       (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved)))
       a!57
       a!58
       a!59
       a!60
       a!61
       a!62
       a!63
       (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n0 __l2s_s_11)))
       a!64
       a!65
       a!66
       a!67
       (= l2s_w_2 a!68)
       a!69
       a!70
       a!71
       a!72
       a!73
       a!24
       a!25
       a!26))))
(assert (and (not false)))
