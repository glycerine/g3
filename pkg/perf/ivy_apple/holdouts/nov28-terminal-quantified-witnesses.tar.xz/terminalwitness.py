from pathlib import Path
import sys,subprocess,csv,itertools,collections
sys.path.insert(0,str(Path('perf/ivy_apple/holdouts').resolve()))
from batch_prefix_replay import parse,smt,standard_declarations,expression,conjuncts
d=Path(__file__).resolve().parent
ns={};src=(d/'terminalground.py').read_text();exec(src[src.index('def subst'):src.index('def ground')],ns);subst=ns['subst']
def test(path,mode):
 raw=path.read_text(); assert 'studyWitness!' not in raw
 forms=parse(standard_declarations(raw));defs=[f for f in forms if f[0]!='assert'];atoms=[a for f in forms if f[0]=='assert' for a in conjuncts(expression(f[1],{},{}))]
 witnesses=collections.defaultdict(list);consts=collections.defaultdict(list)
 for f in defs:
    if f[0]=='declare-fun' and not f[2]:consts[f[3]].append(f[1])
 def visit(t):
    if not isinstance(t,tuple) or not t:return t
    op=t[0]
    if op in ('and','or'):return (op,*(visit(x) for x in t[1:]))
    if op=='=>':return(op,*t[1:-1],visit(t[-1]))
    if op=='exists':
        env={}
        for x,s in t[1]:
            c='|studyWitness!%d|'%len(defs);defs.append(('declare-fun',c,(),s));witnesses[s].append(c);env[x]=c
        return visit(subst(t[2],env))
    return t
 atoms=[visit(a) for a in atoms];flat=[];instances=0
 for a in atoms:
    if not isinstance(a,tuple) or a[0]!='forall':flat.append(a);continue
    bind=a[1];names,sorts=zip(*bind)
    pools=[witnesses[s]+(consts[s] if mode in ('full','full-diag') else []) for s in sorts]
    for args in itertools.product(*pools):
        if mode in ('diag','full-diag') and any(x==y and u!=v for (x,u),(y,v) in itertools.combinations(zip(sorts,args),2)):continue
        flat.append(subst(a[2],dict(zip(names,args))));instances+=1
 sol='\n'.join([smt(f) for f in defs]+['(assert '+smt(a)+')' for a in flat]+['(check-sat)'])
 r=subprocess.run(['../build/z3','-in','-smt2','-T:4'],input=sol,capture_output=True,text=True);assert r.stdout.strip() in ('sat','unsat','unknown','timeout'),r.stdout[:800]
 return [path.stem,mode,sum(map(len,witnesses.values())),instances,r.stdout.strip()]
out=d/'terminalwitness';out.mkdir(exist_ok=True)
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['batch','mode','fresh','instances','result'])
 for path in sorted((d/'captureterminal/7').glob('*.smt2')):
    for mode in ['diag','cross','full-diag','full']:w.writerow(test(path,mode));f.flush()
