import lastgoal
from trial import panel
def patch(pkg,name):
    if name!='inc':return
    p=pkg/'solver/combined_solver.go';s=p.read_text().replace('if c.incMode {\n\t\tif c.timeout','if StudyTerminal && !c.incMode {if e:=c.switchIncremental();e!=nil{return lbool.Undef,e}}\n if c.incMode {\n\t\tif c.timeout',1)
    assert 'if StudyTerminal' in s
    yield p,s+'\nvar StudyTerminal bool\n'
def run(s):
    s=lastgoal.run(s).replace('cond="len(finalCond)>1" if name=="single" else "index+1<len(finalCond)"','cond="len(finalCond)>1"')
    a="        path.write_text(v[:i]+tail+v[j:])"
    s=s.replace(a,"""        if name=='assume':
            tail=tail.replace('z3solver.Assert(zCond)','z3solver.Assert(zCond);if len(finalCond)==1 {finalCheck=func()smt.Z3CheckResult{return z3solver.CheckAssumptions([]smt.Z3Expr{s.tr.Ctx.BoolVal(true)})}}')
        if name=='inc':
            tail=tail.replace('z3solver.Assert(zCond)','z3solver.Assert(zCond);if len(finalCond)==1 {old:=finalCheck;finalCheck=func()smt.Z3CheckResult{study.StudyTerminal=true;defer func(){study.StudyTerminal=false}();return old()}}')
        v=v[:i]+tail+v[j:]
        if name=='inc':v=v.replace('import (','import (study "github.com/glycerine/g3/pkg/solver";',1)
        path.write_text(v)""")
    return s
if __name__=='__main__':panel(['base','assume','inc'],patch,run)
