from trial import panel
def patch(pkg,name):return []
def run(s):
    a=s.index("    for p,src in patch")
    s=s[:a]+'''    if name!='base':
        path=d/(name+'z3bridge_solver_model.go')
        v=path.read_text()
        i=v.index('if s.opts.Incremental {\\n\\t\\t\\t\\t\\tz3solver.Push()',v.index('finalCheck := check'));j=v.index('// No final conditions:',i)
        tail=v[i:j]
        cond="len(finalCond)>1" if name=="single" else "index+1<len(finalCond)"
        tail=tail.replace('if s.opts.Incremental {', 'if s.opts.Incremental && ('+cond+') {')
        assert tail.count('&& ('+cond+')')==3
        path.write_text(v[:i]+tail+v[j:])
'''+s[a:]
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%3:]+modes[:i%3]").replace('for mode in modes:w.writerow','for mode in order:w.writerow')
    return s.replace('range(5):','range(6):').replace('((1,3),(4,8),(6,227))','((7,3,9),(2,4,227),(8,6,5))')
if __name__=='__main__':panel(['base','single','last'],patch,run)
