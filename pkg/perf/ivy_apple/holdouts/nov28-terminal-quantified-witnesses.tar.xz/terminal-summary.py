from pathlib import Path
import statistics as st,csv,collections
d=Path(__file__).resolve().parent
v=collections.defaultdict(list)
for r in csv.DictReader((d/'terminalcost/results.csv').open()):v[r['engine'],r['form'],int(r['batch'])].append(int(r['instructions']))
for k in sorted({x[:2] for x in v}):
 vals=[st.median(v[k+(b,)]) for b in range(8,14)]
 print(k,round(sum(vals)/1e6,2),[round(x/1e6,2) for x in vals])
for g in ['lastgoal','lastbackend']:
 for f in sorted((d/g).glob('*.csv')):
    rows=list(csv.DictReader(f.open()));v2={k:st.median(int(x['instructions']) for x in rows if x['engine']==k) for k in set(x['engine'] for x in rows)}
    print(g,f.stem,len(rows),{k:round(100*(n/v2['base']-1),2) for k,n in v2.items() if k!='base'})
