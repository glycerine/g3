(declare-sort abp.value 0)
(declare-sort abp.index_t 0)
(declare-sort abp.data_msg_t 0)
(declare-sort abp.ack_msg_t 0)
(declare-fun __abp.l2s.d_ack_msg (abp.ack_msg_t) Bool)
(declare-fun |__new_fml:a_a| () abp.ack_msg_t)
(declare-fun abp.l2s.d_ack_msg (abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.d_data_msg (abp.data_msg_t) Bool)
(declare-fun |__new_fml:m_a_a| () abp.data_msg_t)
(declare-fun abp.l2s.d_data_msg (abp.data_msg_t) Bool)
(declare-fun __abp.l2s.d_value (abp.value) Bool)
(declare-fun abp.d (abp.data_msg_t) abp.value)
(declare-fun abp.l2s.d_value (abp.value) Bool)
(declare-fun abp.l2s.eta_1 () Bool)
(declare-fun abp.l2s.monitor_level_1 () Bool)
(declare-fun __ts0_a_c () Bool)
(declare-fun __m_abp.l2s.w_4 () Bool)
(declare-fun abp.fair_4 () Bool)
(declare-fun abp.l2s.w_4 () Bool)
(declare-fun __m_abp.l2s.w_3 () Bool)
(declare-fun abp.fair_3 () Bool)
(declare-fun abp.l2s.w_3 () Bool)
(declare-fun __m_abp.l2s.w_2 () Bool)
(declare-fun abp.fair_2 () Bool)
(declare-fun abp.l2s.w_2 () Bool)
(declare-fun __m_abp.l2s.w_1 () Bool)
(declare-fun abp.fair_1 () Bool)
(declare-fun abp.l2s.w_1 () Bool)
(declare-fun |__fml:a| () abp.ack_msg_t)
(declare-fun |__fml:m| () abp.data_msg_t)
(declare-fun __abp.ack_no_send_flag () Bool)
(declare-fun __ts0_a_b () Bool)
(declare-fun __abp.data_no_send_flag () Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __m_abp.data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun |__new_fml:m_a| () abp.data_msg_t)
(declare-fun abp.data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun __abp.data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0__m_abp.l2s.frozen_a () Bool)
(declare-fun __ts0__ts0_b_a () Bool)
(declare-fun abp.l2s.saved () Bool)
(declare-fun __ts0__ts0__ts0_a_a () Bool)
(declare-fun __abp.l2s.w_4 () Bool)
(declare-fun __abp.l2s.w_3 () Bool)
(declare-fun __abp.l2s.w_2 () Bool)
(declare-fun __abp.l2s.w_1 () Bool)
(declare-fun __abp.l2s.waiting () Bool)
(declare-fun __ts0__ts0_a_b () Bool)
(declare-fun __abp.l2s.frozen () Bool)
(declare-fun __abp.l2s.s_ack_no_send_flag () Bool)
(declare-fun abp.l2s.s_ack_no_send_flag () Bool)
(declare-fun __abp.l2s.s_data_no_send_flag () Bool)
(declare-fun abp.l2s.s_data_no_send_flag () Bool)
(declare-fun __abp.l2s.s_receiver_bit () Bool)
(declare-fun abp.receiver_bit () Bool)
(declare-fun abp.l2s.s_receiver_bit () Bool)
(declare-fun __abp.l2s.s_sender_bit () Bool)
(declare-fun abp.sender_bit () Bool)
(declare-fun abp.l2s.s_sender_bit () Bool)
(declare-fun __abp.l2s.s_receiver_i () abp.index_t)
(declare-fun abp.receiver_i () abp.index_t)
(declare-fun abp.l2s.s_receiver_i () abp.index_t)
(declare-fun __abp.l2s.s_sender_i () abp.index_t)
(declare-fun abp.sender_i () abp.index_t)
(declare-fun abp.l2s.s_sender_i () abp.index_t)
(declare-fun __abp.l2s.s_receiver_array (abp.index_t) abp.value)
(declare-fun abp.receiver_array (abp.index_t) abp.value)
(declare-fun abp.l2s.s_receiver_array (abp.index_t) abp.value)
(declare-fun __abp.l2s.s_sender_array (abp.index_t) abp.value)
(declare-fun abp.sender_array (abp.index_t) abp.value)
(declare-fun abp.l2s.s_sender_array (abp.index_t) abp.value)
(declare-fun __abp.l2s.s_ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun abp.ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun abp.l2s.s_ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.s_data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun abp.l2s.s_data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun __abp.l2s.a_ack_msg (abp.ack_msg_t) Bool)
(declare-fun abp.l2s.a_ack_msg (abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.a_data_msg (abp.data_msg_t) Bool)
(declare-fun abp.l2s.a_data_msg (abp.data_msg_t) Bool)
(declare-fun __abp.l2s.a_value (abp.value) Bool)
(declare-fun abp.l2s.a_value (abp.value) Bool)
(declare-fun __abp.l2s.a_index (abp.index_t) Bool)
(declare-fun abp.l2s.d_index (abp.index_t) Bool)
(declare-fun abp.l2s.a_index (abp.index_t) Bool)
(declare-fun abp.l2s.frozen () Bool)
(declare-fun abp.l2s.waiting () Bool)
(declare-fun abp.l2s.monitor_level_0 () Bool)
(declare-fun abp.index.le (abp.index_t abp.index_t) Bool)
(declare-fun abp.index.zero () abp.index_t)
(declare-fun abp.ack_no_send_flag () Bool)
(declare-fun abp.data_no_send_flag () Bool)
(declare-fun abp.dbit (abp.data_msg_t) Bool)
(declare-fun __abp.l2s.saved () Bool)
(declare-fun abp.abit (abp.ack_msg_t) Bool)
(declare-fun abp.i0 () abp.index_t)
; row 23
(assert (or (not __abp.l2s.waiting) (not __abp.l2s.saved)))
; row 61
(assert (=> (and __abp.l2s.saved abp.l2s.monitor_level_1) (= __abp.l2s.s_sender_bit abp.sender_bit)))
; row 66
(assert (=> (and __abp.l2s.saved (not __abp.l2s.w_2)) (not __abp.l2s.s_ack_no_send_flag)))
; row 67
(assert (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1) (not __abp.l2s.w_3) (not __abp.data_no_send_flag) (= __abp.l2s.s_sender_bit __abp.l2s.s_receiver_bit)) (exists ((|M:abp.data_msg_t| abp.data_msg_t)) (and (__abp.l2s.a_data_msg |M:abp.data_msg_t|) (not (__abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|)) (__abp.l2s.s_data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|) (= (abp.dbit |M:abp.data_msg_t|) (not abp.receiver_bit))))))
; row 68
(assert (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1) (not __abp.l2s.w_4) (not __abp.ack_no_send_flag) (= __abp.l2s.s_sender_bit (not __abp.l2s.s_receiver_bit))) (exists ((|A:abp.ack_msg_t| abp.ack_msg_t)) (and (__abp.l2s.a_ack_msg |A:abp.ack_msg_t|) (not (abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|)) (__abp.l2s.s_ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|) (= (abp.abit |A:abp.ack_msg_t|) (not abp.sender_bit))))))
; row 70
(assert (or __ts0_c __ts0__ts0_b_a (= abp.l2s.saved __abp.l2s.saved)))
; row 72
(assert (= (abp.dbit |__fml:m|) abp.sender_bit))
; row 74
(assert (or (not __ts0_a) false))
; row 76
(assert (or __ts0_a_b (= abp.ack_no_send_flag __abp.ack_no_send_flag)))
; row 77
(assert (= abp.l2s.eta_1 (and (= abp.sender_bit abp.sender_bit) (= abp.receiver_bit abp.receiver_bit))))
; row 78
(assert abp.l2s.saved)
; row 79
(assert (= abp.l2s.monitor_level_1 abp.l2s.eta_1))
; row 81
(assert (not abp.l2s.w_2))
; row 82
(assert (not abp.l2s.w_3))
; row 83
(assert (not abp.l2s.w_4))
; row 84
(assert (forall ((|M1:abp.data_msg_t| abp.data_msg_t) (|M2:abp.data_msg_t| abp.data_msg_t)) (=> (and (abp.l2s.a_data_msg |M1:abp.data_msg_t|) (abp.l2s.a_data_msg |M2:abp.data_msg_t|)) (= (abp.l2s.s_data_msg.le |M1:abp.data_msg_t| |M2:abp.data_msg_t|) (abp.data_msg.le |M1:abp.data_msg_t| |M2:abp.data_msg_t|)))))
; row 85
(assert (forall ((|A1:abp.ack_msg_t| abp.ack_msg_t) (|A2:abp.ack_msg_t| abp.ack_msg_t)) (=> (and (abp.l2s.a_ack_msg |A1:abp.ack_msg_t|) (abp.l2s.a_ack_msg |A2:abp.ack_msg_t|)) (= (abp.l2s.s_ack_msg.le |A1:abp.ack_msg_t| |A2:abp.ack_msg_t|) (abp.ack_msg.le |A1:abp.ack_msg_t| |A2:abp.ack_msg_t|)))))
; row 91
(assert (= abp.l2s.s_receiver_bit abp.receiver_bit))
; row 93
(assert (= abp.l2s.s_ack_no_send_flag abp.ack_no_send_flag))
; row 104
(assert (= __m_abp.l2s.w_2 (or __ts0_c (ite __ts0__ts0_b_a (or __ts0__ts0__ts0_a_a __abp.l2s.w_2) __abp.l2s.w_2))))
; row 105
(assert (= __m_abp.l2s.w_3 (or __ts0_c (ite __ts0__ts0_b_a (or __ts0__ts0__ts0_a_a __abp.l2s.w_3) __abp.l2s.w_3))))
; row 106
(assert (= __m_abp.l2s.w_4 (or __ts0_c (ite __ts0__ts0_b_a (or __ts0__ts0__ts0_a_a __abp.l2s.w_4) __abp.l2s.w_4))))
; row 109
(assert (forall ((|V0:abp.data_msg_t| abp.data_msg_t)) (= (abp.l2s.a_data_msg |V0:abp.data_msg_t|) (ite __ts0_c (__abp.l2s.a_data_msg |V0:abp.data_msg_t|) (ite __ts0__ts0_a_b (__abp.l2s.d_data_msg |V0:abp.data_msg_t|) (__abp.l2s.a_data_msg |V0:abp.data_msg_t|))))))
; row 110
(assert (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t)) (= (abp.l2s.a_ack_msg |V0:abp.ack_msg_t|) (ite __ts0_c (__abp.l2s.a_ack_msg |V0:abp.ack_msg_t|) (ite __ts0__ts0_a_b (__abp.l2s.d_ack_msg |V0:abp.ack_msg_t|) (__abp.l2s.a_ack_msg |V0:abp.ack_msg_t|))))))
; row 111
(assert (forall ((|V0:abp.data_msg_t| abp.data_msg_t) (|V1:abp.data_msg_t| abp.data_msg_t)) (= (abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (ite __ts0_c (__abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a (__abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (__abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|)) (__abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|))))))
; row 112
(assert (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t) (|V1:abp.ack_msg_t| abp.ack_msg_t)) (= (abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|) (ite __ts0_c (__abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|) (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a (abp.ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|) (__abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|)) (__abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|))))))
; row 118
(assert (= abp.l2s.s_receiver_bit (ite __ts0_c __abp.l2s.s_receiver_bit (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a abp.receiver_bit __abp.l2s.s_receiver_bit) __abp.l2s.s_receiver_bit))))
; row 120
(assert (= abp.l2s.s_ack_no_send_flag (ite __ts0_c __abp.l2s.s_ack_no_send_flag (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a __abp.ack_no_send_flag __abp.l2s.s_ack_no_send_flag) __abp.l2s.s_ack_no_send_flag))))
; row 122
(assert (= __ts0__ts0_a_b (and __abp.l2s.waiting (not __abp.l2s.w_1) (not __abp.l2s.w_2) (not __abp.l2s.w_3) (not __abp.l2s.w_4))))
; row 123
(assert (= __ts0__ts0__ts0_a_a abp.l2s.saved))
; row 126
(assert (= |__new_fml:m_a| |__fml:m|))
; row 127
(assert (forall ((|V0:abp.data_msg_t| abp.data_msg_t) (|V1:abp.data_msg_t| abp.data_msg_t)) (= (__m_abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (ite (and (= |V0:abp.data_msg_t| |__new_fml:m_a|) (= |V1:abp.data_msg_t| |__new_fml:m_a|)) true (__abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|)))))
; row 128
(assert (forall ((|V0:abp.data_msg_t| abp.data_msg_t) (|V1:abp.data_msg_t| abp.data_msg_t)) (= (abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (ite (and (= |V0:abp.data_msg_t| |__new_fml:m_a|)) (__m_abp.data_msg.le |V1:abp.data_msg_t| |V1:abp.data_msg_t|) (__m_abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|)))))
; row 130
(assert (not abp.fair_2))
; row 131
(assert (= abp.fair_3 __abp.data_no_send_flag))
; row 132
(assert (= abp.fair_4 __abp.ack_no_send_flag))
; row 133
(assert (= __ts0_a __abp.data_no_send_flag))
; row 135
(assert (= __ts0_a_b (not __abp.ack_no_send_flag)))
; row 139
(assert (= abp.l2s.w_2 (ite __ts0_a_c (and __m_abp.l2s.w_2 (not abp.fair_2)) __m_abp.l2s.w_2)))
; row 140
(assert (= abp.l2s.w_3 (ite __ts0_a_c (and __m_abp.l2s.w_3 (not abp.fair_3)) __m_abp.l2s.w_3)))
; row 141
(assert (= abp.l2s.w_4 (ite __ts0_a_c (and __m_abp.l2s.w_4 (not abp.fair_4)) __m_abp.l2s.w_4)))
(check-sat)
