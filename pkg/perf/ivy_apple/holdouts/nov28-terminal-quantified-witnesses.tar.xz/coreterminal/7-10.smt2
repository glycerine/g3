(declare-sort abp.value 0)
(declare-sort abp.index_t 0)
(declare-sort abp.data_msg_t 0)
(declare-sort abp.ack_msg_t 0)
(declare-fun __abp.l2s.d_ack_msg (abp.ack_msg_t) Bool)
(declare-fun |__new_fml:a_a| () abp.ack_msg_t)
(declare-fun abp.l2s.d_ack_msg (abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.d_data_msg (abp.data_msg_t) Bool)
(declare-fun |__new_fml:m_a| () abp.data_msg_t)
(declare-fun abp.l2s.d_data_msg (abp.data_msg_t) Bool)
(declare-fun __abp.l2s.d_value (abp.value) Bool)
(declare-fun abp.d (abp.data_msg_t) abp.value)
(declare-fun abp.l2s.d_value (abp.value) Bool)
(declare-fun abp.l2s.eta_1 () Bool)
(declare-fun abp.l2s.monitor_level_1 () Bool)
(declare-fun __ts0_a_c () Bool)
(declare-fun __m_abp.l2s.w_4 () Bool)
(declare-fun abp.fair_4 () Bool)
(declare-fun abp.l2s.w_4 () Bool)
(declare-fun __m_abp.l2s.w_3 () Bool)
(declare-fun abp.fair_3 () Bool)
(declare-fun abp.l2s.w_3 () Bool)
(declare-fun __m_abp.l2s.w_2 () Bool)
(declare-fun abp.fair_2 () Bool)
(declare-fun abp.l2s.w_2 () Bool)
(declare-fun __m_abp.l2s.w_1 () Bool)
(declare-fun abp.fair_1 () Bool)
(declare-fun abp.l2s.w_1 () Bool)
(declare-fun |__fml:a| () abp.ack_msg_t)
(declare-fun |__new_fml:m| () abp.data_msg_t)
(declare-fun __abp.ack_no_send_flag () Bool)
(declare-fun __ts0_a_b () Bool)
(declare-fun __abp.data_no_send_flag () Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun __abp.receiver_bit () Bool)
(declare-fun abp.dbit (abp.data_msg_t) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __abp.receiver_i () abp.index_t)
(declare-fun |__fml:y| () abp.index_t)
(declare-fun abp.receiver_i () abp.index_t)
(declare-fun |__ts0__new_fml:x| () abp.index_t)
(declare-fun __abp.receiver_array (abp.index_t) abp.value)
(declare-fun abp.receiver_array (abp.index_t) abp.value)
(declare-fun abp.receiver_bit () Bool)
(declare-fun |__fml:m_a| () abp.data_msg_t)
(declare-fun __abp.data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun abp.data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0__m_abp.l2s.frozen_a () Bool)
(declare-fun __ts0__ts0_b_a () Bool)
(declare-fun abp.l2s.saved () Bool)
(declare-fun __ts0__ts0__ts0_a_a () Bool)
(declare-fun __abp.l2s.w_4 () Bool)
(declare-fun __abp.l2s.w_3 () Bool)
(declare-fun __abp.l2s.w_2 () Bool)
(declare-fun __abp.l2s.w_1 () Bool)
(declare-fun __abp.l2s.waiting () Bool)
(declare-fun __ts0__ts0_a_b () Bool)
(declare-fun __abp.l2s.frozen () Bool)
(declare-fun __abp.l2s.s_ack_no_send_flag () Bool)
(declare-fun abp.l2s.s_ack_no_send_flag () Bool)
(declare-fun __abp.l2s.s_data_no_send_flag () Bool)
(declare-fun abp.l2s.s_data_no_send_flag () Bool)
(declare-fun __abp.l2s.s_receiver_bit () Bool)
(declare-fun abp.l2s.s_receiver_bit () Bool)
(declare-fun __abp.l2s.s_sender_bit () Bool)
(declare-fun abp.sender_bit () Bool)
(declare-fun abp.l2s.s_sender_bit () Bool)
(declare-fun __abp.l2s.s_receiver_i () abp.index_t)
(declare-fun abp.l2s.s_receiver_i () abp.index_t)
(declare-fun __abp.l2s.s_sender_i () abp.index_t)
(declare-fun abp.sender_i () abp.index_t)
(declare-fun abp.l2s.s_sender_i () abp.index_t)
(declare-fun __abp.l2s.s_receiver_array (abp.index_t) abp.value)
(declare-fun abp.l2s.s_receiver_array (abp.index_t) abp.value)
(declare-fun __abp.l2s.s_sender_array (abp.index_t) abp.value)
(declare-fun abp.sender_array (abp.index_t) abp.value)
(declare-fun abp.l2s.s_sender_array (abp.index_t) abp.value)
(declare-fun __abp.l2s.s_ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun abp.ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun abp.l2s.s_ack_msg.le (abp.ack_msg_t abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.s_data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun abp.l2s.s_data_msg.le (abp.data_msg_t abp.data_msg_t) Bool)
(declare-fun __abp.l2s.a_ack_msg (abp.ack_msg_t) Bool)
(declare-fun abp.l2s.a_ack_msg (abp.ack_msg_t) Bool)
(declare-fun __abp.l2s.a_data_msg (abp.data_msg_t) Bool)
(declare-fun abp.l2s.a_data_msg (abp.data_msg_t) Bool)
(declare-fun __abp.l2s.a_value (abp.value) Bool)
(declare-fun abp.l2s.a_value (abp.value) Bool)
(declare-fun __abp.l2s.a_index (abp.index_t) Bool)
(declare-fun abp.l2s.d_index (abp.index_t) Bool)
(declare-fun abp.l2s.a_index (abp.index_t) Bool)
(declare-fun abp.l2s.frozen () Bool)
(declare-fun abp.l2s.waiting () Bool)
(declare-fun abp.l2s.monitor_level_0 () Bool)
(declare-fun abp.index.le (abp.index_t abp.index_t) Bool)
(declare-fun abp.index.zero () abp.index_t)
(declare-fun abp.ack_no_send_flag () Bool)
(declare-fun abp.data_no_send_flag () Bool)
(declare-fun abp.i0 () abp.index_t)
(declare-fun __abp.l2s.saved () Bool)
(declare-fun abp.abit (abp.ack_msg_t) Bool)
; row 23
(assert (or (not __abp.l2s.waiting) (not __abp.l2s.saved)))
; row 49
(assert (forall ((|I:abp.index_t| abp.index_t)) (=> (not __abp.l2s.waiting) (=> (abp.index.le |I:abp.index_t| abp.i0) (__abp.l2s.a_index |I:abp.index_t|)))))
; row 50
(assert (forall ((|M:abp.data_msg_t| abp.data_msg_t)) (=> (and (not __abp.l2s.waiting) abp.l2s.monitor_level_1) (=> (and (__abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|) (= (abp.dbit |M:abp.data_msg_t|) (not abp.sender_bit))) (__abp.l2s.a_data_msg |M:abp.data_msg_t|)))))
; row 52
(assert (abp.index.le abp.sender_i abp.i0))
; row 55
(assert (=> __abp.l2s.saved (abp.index.le __abp.l2s.s_receiver_i abp.i0)))
; row 56
(assert (=> (and __abp.l2s.saved abp.l2s.monitor_level_0) (or (not (abp.index.le abp.sender_i __abp.l2s.s_sender_i)) (not (abp.index.le __abp.receiver_i __abp.l2s.s_receiver_i)))))
; row 57
(assert (forall ((|M:abp.data_msg_t| abp.data_msg_t)) (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1) (__abp.data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|) (= (abp.dbit |M:abp.data_msg_t|) (not abp.sender_bit))) (__abp.l2s.s_data_msg.le |M:abp.data_msg_t| |M:abp.data_msg_t|))))
; row 61
(assert (=> (and __abp.l2s.saved abp.l2s.monitor_level_1) (= __abp.l2s.s_sender_bit abp.sender_bit)))
; row 66
(assert (=> (and __abp.l2s.saved (not __abp.l2s.w_2)) (not __abp.l2s.s_ack_no_send_flag)))
; row 68
(assert (=> (and (and __abp.l2s.saved abp.l2s.monitor_level_1) (not __abp.l2s.w_4) (not __abp.ack_no_send_flag) (= __abp.l2s.s_sender_bit (not __abp.l2s.s_receiver_bit))) (exists ((|A:abp.ack_msg_t| abp.ack_msg_t)) (and (__abp.l2s.a_ack_msg |A:abp.ack_msg_t|) (not (abp.ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|)) (__abp.l2s.s_ack_msg.le |A:abp.ack_msg_t| |A:abp.ack_msg_t|) (= (abp.abit |A:abp.ack_msg_t|) (not abp.sender_bit))))))
; row 70
(assert (or __ts0_c __ts0__ts0_b_a (= abp.l2s.saved __abp.l2s.saved)))
; row 71
(assert (__abp.data_msg.le |__fml:m_a| |__fml:m_a|))
; row 73
(assert (or (not __ts0_a) (abp.index.le |__ts0__new_fml:x| |__fml:y|)))
; row 78
(assert (or __ts0_a_b (= abp.ack_no_send_flag __abp.ack_no_send_flag)))
; row 80
(assert abp.l2s.saved)
; row 83
(assert (not abp.l2s.w_2))
; row 85
(assert (not abp.l2s.w_4))
; row 86
(assert (forall ((|M1:abp.data_msg_t| abp.data_msg_t) (|M2:abp.data_msg_t| abp.data_msg_t)) (=> (and (abp.l2s.a_data_msg |M1:abp.data_msg_t|) (abp.l2s.a_data_msg |M2:abp.data_msg_t|)) (= (abp.l2s.s_data_msg.le |M1:abp.data_msg_t| |M2:abp.data_msg_t|) (abp.data_msg.le |M1:abp.data_msg_t| |M2:abp.data_msg_t|)))))
; row 87
(assert (forall ((|A1:abp.ack_msg_t| abp.ack_msg_t) (|A2:abp.ack_msg_t| abp.ack_msg_t)) (=> (and (abp.l2s.a_ack_msg |A1:abp.ack_msg_t|) (abp.l2s.a_ack_msg |A2:abp.ack_msg_t|)) (= (abp.l2s.s_ack_msg.le |A1:abp.ack_msg_t| |A2:abp.ack_msg_t|) (abp.ack_msg.le |A1:abp.ack_msg_t| |A2:abp.ack_msg_t|)))))
; row 90
(assert (forall ((|I:abp.index_t| abp.index_t)) (=> (abp.l2s.a_index |I:abp.index_t|) (= (= abp.l2s.s_sender_i |I:abp.index_t|) (= abp.sender_i |I:abp.index_t|)))))
; row 91
(assert (forall ((|I:abp.index_t| abp.index_t)) (=> (abp.l2s.a_index |I:abp.index_t|) (= (= abp.l2s.s_receiver_i |I:abp.index_t|) (= abp.receiver_i |I:abp.index_t|)))))
; row 93
(assert (= abp.l2s.s_receiver_bit abp.receiver_bit))
; row 95
(assert (= abp.l2s.s_ack_no_send_flag abp.ack_no_send_flag))
; row 99
(assert (forall ((|X:abp.index_t| abp.index_t) (|Y:abp.index_t| abp.index_t)) (or (abp.index.le |X:abp.index_t| |Y:abp.index_t|) (abp.index.le |Y:abp.index_t| |X:abp.index_t|))))
; row 101
(assert (or abp.l2s.monitor_level_0 abp.l2s.monitor_level_1))
; row 106
(assert (= __m_abp.l2s.w_2 (or __ts0_c (ite __ts0__ts0_b_a (or __ts0__ts0__ts0_a_a __abp.l2s.w_2) __abp.l2s.w_2))))
; row 108
(assert (= __m_abp.l2s.w_4 (or __ts0_c (ite __ts0__ts0_b_a (or __ts0__ts0__ts0_a_a __abp.l2s.w_4) __abp.l2s.w_4))))
; row 109
(assert (forall ((|V0:abp.index_t| abp.index_t)) (= (abp.l2s.a_index |V0:abp.index_t|) (ite __ts0_c (__abp.l2s.a_index |V0:abp.index_t|) (ite __ts0__ts0_a_b (abp.l2s.d_index |V0:abp.index_t|) (__abp.l2s.a_index |V0:abp.index_t|))))))
; row 111
(assert (forall ((|V0:abp.data_msg_t| abp.data_msg_t)) (= (abp.l2s.a_data_msg |V0:abp.data_msg_t|) (ite __ts0_c (__abp.l2s.a_data_msg |V0:abp.data_msg_t|) (ite __ts0__ts0_a_b (__abp.l2s.d_data_msg |V0:abp.data_msg_t|) (__abp.l2s.a_data_msg |V0:abp.data_msg_t|))))))
; row 112
(assert (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t)) (= (abp.l2s.a_ack_msg |V0:abp.ack_msg_t|) (ite __ts0_c (__abp.l2s.a_ack_msg |V0:abp.ack_msg_t|) (ite __ts0__ts0_a_b (__abp.l2s.d_ack_msg |V0:abp.ack_msg_t|) (__abp.l2s.a_ack_msg |V0:abp.ack_msg_t|))))))
; row 113
(assert (forall ((|V0:abp.data_msg_t| abp.data_msg_t) (|V1:abp.data_msg_t| abp.data_msg_t)) (= (abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (ite __ts0_c (__abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a (__abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (__abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|)) (__abp.l2s.s_data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|))))))
; row 114
(assert (forall ((|V0:abp.ack_msg_t| abp.ack_msg_t) (|V1:abp.ack_msg_t| abp.ack_msg_t)) (= (abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|) (ite __ts0_c (__abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|) (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a (abp.ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|) (__abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|)) (__abp.l2s.s_ack_msg.le |V0:abp.ack_msg_t| |V1:abp.ack_msg_t|))))))
; row 117
(assert (= abp.l2s.s_sender_i (ite __ts0_c __abp.l2s.s_sender_i (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a abp.sender_i __abp.l2s.s_sender_i) __abp.l2s.s_sender_i))))
; row 118
(assert (= abp.l2s.s_receiver_i (ite __ts0_c __abp.l2s.s_receiver_i (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a __abp.receiver_i __abp.l2s.s_receiver_i) __abp.l2s.s_receiver_i))))
; row 120
(assert (= abp.l2s.s_receiver_bit (ite __ts0_c __abp.l2s.s_receiver_bit (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a __abp.receiver_bit __abp.l2s.s_receiver_bit) __abp.l2s.s_receiver_bit))))
; row 122
(assert (= abp.l2s.s_ack_no_send_flag (ite __ts0_c __abp.l2s.s_ack_no_send_flag (ite __ts0__ts0_b_a (ite __ts0__ts0__ts0_a_a __abp.ack_no_send_flag __abp.l2s.s_ack_no_send_flag) __abp.l2s.s_ack_no_send_flag))))
; row 124
(assert (= __ts0__ts0_a_b (and __abp.l2s.waiting (not __abp.l2s.w_1) (not __abp.l2s.w_2) (not __abp.l2s.w_3) (not __abp.l2s.w_4))))
; row 125
(assert (= __ts0__ts0__ts0_a_a abp.l2s.saved))
; row 128
(assert (forall ((|V0:abp.data_msg_t| abp.data_msg_t) (|V1:abp.data_msg_t| abp.data_msg_t)) (= (abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|) (ite (and (= |V1:abp.data_msg_t| |__fml:m_a|)) false (__abp.data_msg.le |V0:abp.data_msg_t| |V1:abp.data_msg_t|)))))
; row 129
(assert (= |__new_fml:m| |__fml:m_a|))
; row 130
(assert (= abp.receiver_bit (ite __ts0_a (not __abp.receiver_bit) __abp.receiver_bit)))
; row 132
(assert (= |__ts0__new_fml:x| __abp.receiver_i))
; row 133
(assert (= abp.receiver_i (ite __ts0_a |__fml:y| __abp.receiver_i)))
; row 134
(assert (= __ts0_a (= (abp.dbit |__new_fml:m|) __abp.receiver_bit)))
; row 136
(assert (not abp.fair_2))
; row 138
(assert (= abp.fair_4 __abp.ack_no_send_flag))
; row 140
(assert (= __ts0_a_b (not __abp.ack_no_send_flag)))
; row 144
(assert (= abp.l2s.w_2 (ite __ts0_a_c (and __m_abp.l2s.w_2 (not abp.fair_2)) __m_abp.l2s.w_2)))
; row 146
(assert (= abp.l2s.w_4 (ite __ts0_a_c (and __m_abp.l2s.w_4 (not abp.fair_4)) __m_abp.l2s.w_4)))
(check-sat)
