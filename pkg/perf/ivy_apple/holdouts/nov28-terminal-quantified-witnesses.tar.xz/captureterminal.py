from trial import panel
def patch(pkg,name):return []
def run(s):
    a=s.index('    for p,src in patch')
    s=s[:a]+'''    path=d/(name+'z3bridge_solver_model.go')
    v=path.read_text()
    i=v.index('overallResult := smt.Unsat',v.index('func (s *Solver) GetSmallModelWithCond('))
    v=v[:i]+'studyBatch++;batch:=studyBatch;'+v[i:]
    a='finalCheck := check'
    v=v.replace(a,'if len(finalCond)==1 {tmp:=s.newZ3Solver();tmp.Assert(zc);tmp.Assert(zCond);e:=os.WriteFile(fmt.Sprintf("%s/%d.smt2",os.Getenv("CAPTURE"),batch),[]byte(tmp.String()),0600);if e!=nil{panic(e)};tmp.Reset()};'+a)
    path.write_text(v+'\\nvar studyBatch int\\n')
'''+s[a:]
    return s[:s.index(' def measure(')]+''' for case in [7,3,8,2,4]:
    dest=out/str(case);dest.mkdir(exist_ok=True);os.environ['CAPTURE']=str(dest);run(case,'native',cpus[0],False)
'''
if __name__=='__main__':panel(['native'],patch,run)
