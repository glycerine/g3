from pathlib import Path
import csv,sys,subprocess as sp,os,statistics as st
d=Path(__file__).resolve().parent
ns={'__file__':str(d/'terminalwitness.py')}
src=(d/'terminalwitness.py').read_text().split("out=d/'terminalwitness'")[0].replace(" sol='"," flat=[t for t in flat if '(forall ' not in smt(t) and '(exists ' not in smt(t)]\n sol='")
src=src[:src.index(' r=subprocess.run')]+''' return sol
'''
exec(src,ns);out=d/'terminalcost';out.mkdir(exist_ok=True)
bins=[str(d/'g3'),str(Path('../build/z3').resolve())]
cpu=os.environ['CPU'];perf=os.environ['PERF']
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['batch','round','engine','form','verdict','instructions'])
 for i in range(5):
  for p in sorted((d/'captureterminal/7').glob('*.smt2')):
   forms={'original':ns['standard_declarations'](p.read_text())+'\n(check-sat)','diag':ns['test'](p,'diag'),'full-diag':ns['test'](p,'full-diag')}
   for exe in bins[::1 if i%2==0 else -1]:
    for k in list(forms)[i%3:]+list(forms)[:i%3]:
     inp=forms[k].replace('(check-sat)','(push 1)\n(check-sat)');stat=out/'stat'
     r=sp.run(['taskset','-c',cpu,perf,'stat','-x,','-e','instructions:u','-o',stat,'--',exe,'-in','-smt2'],input=inp,text=True,capture_output=True,timeout=30,env=dict(os.environ,GOMAXPROCS='1'))
     verdict=r.stdout.strip()
     assert r.returncode==0 and verdict==('sat' if k=='diag' and p.stem in ('10','12') else 'unsat'),(p,k,verdict[:1000],r.stderr[:250])
     ins=next(x for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u');assert float(ins[4])==100
     w.writerow([p.stem,i,Path(exe).name,k,verdict,ins[0]]);f.flush()
