"""Summarize sampled engine owners and instruction leaves."""
from collections import Counter,defaultdict
import csv
from pathlib import Path
import sys
groups=defaultdict(Counter)
rounds=defaultdict(set)
for r in csv.DictReader(Path(sys.argv[1]).open()):
    key=(r['engine'],r['phase'])
    rounds[key].add((r['round'],r['query']))
    for col in ['operation','self']:
        groups[key,col][r[col]]+=int(r['samples'])
for (key,col),g in groups.items():
    print(key,col,'samples',g.total(),'runs',len(rounds[key]))
    for name,n in g.most_common(8):
        print(f'  {100*n/g.total():4.1f}% {n:5d} {name}')
