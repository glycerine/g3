"""Read the declaration's family and operator in one checked lookup."""
from pathlib import Path
import json,subprocess
work=Path(__file__).resolve().parent
src=Path.cwd()/'ast/ast_core_accessors.go'
s=src.read_text()+'''
func (m *ASTManager) DeclarationIdentity(h ASTHandle) (FamilyID, int32, error) {
	r, err := m.readNode(h)
	if err != nil {return -1,-1,err}
	if m.nodeAt(r.slot).kind == ASTApp {return m.appIdentity(m.appAt(r.slot))}
	return m.declIdentity(r)
}
'''
dst=work/'decl_accessors.go'
dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
mapping={str(src):str(dst)}
src=Path.cwd()/'ast/rewriter/th_rewriter.go'
s=src.read_text()
i=s.index('family, err := m.GetFamilyID(decl)',s.index('func (c *theoryRewriterConfiguration) reduceAppCore('))
j=s.index('if kind == ast.ASTOpEq {',i)
s=s[:i]+'''family, kind, err := m.DeclarationIdentity(decl)
	if err != nil || family == ast.NullFamilyID {
		return RewriteFailed, err
	}
	if family == m.BasicFamilyID() {
		'''+s[j:]
dst=work/'decl_rewriter.go'
dst.write_text(s)
mapping[str(src)]=str(dst)
overlay=work/'decl.json'
overlay.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'decl','./cmd/g3'],check=True)
