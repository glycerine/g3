"""Borrow the equality operands once and read an operand's application identity once."""
from pathlib import Path
import json,subprocess
work=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/th_rewriter.go'
code=src.read_text()
i=code.index('kind, err := c.owner.manager.GetKind(term)',code.index('func (c *theoryRewriterConfiguration) equalityBit'))
j=code.index('if count,',i)
code=code[:i]+'''app, family, op, err := c.owner.manager.AppIdentity(term)
	if err != nil || !app || family != c.owner.manager.BasicFamilyID() || op != ast.ASTOpEq {
		return x, 0, false, err
	}
	'''+code[j:]
i=code.index('if kind == ast.ASTOpEq {',code.index('func (c *theoryRewriterConfiguration) reduceAppCore'))
j=code.index('sort, err := m.GetSort(left)',i)
k=code.index('if kind == ast.ASTOpEq || kind == ast.ASTOpIff',j)
l=code.index('if status, err := c.tamagotchi',k)
code=code[:i]+code[k:l]+'if kind == ast.ASTOpEq {\n'+code[j:k]+code[l:]
dst=work/'equality_th_rewriter.go'
dst.write_bytes(subprocess.check_output(['gofmt'],input=code.encode()))
overlay=work/'equality.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'equality','./cmd/g3'],check=True)
