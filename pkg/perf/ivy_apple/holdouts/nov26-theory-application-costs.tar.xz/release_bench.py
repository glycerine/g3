"""Compare two compiled rewriter benchmark binaries on one CPU in alternating order."""
import subprocess,sys
for i in range(11):
    pair=[('base',sys.argv[2]),('release',sys.argv[3])]
    for label,exe in pair if i%2==0 else reversed(pair):
        result=subprocess.check_output(['taskset','-c',sys.argv[1],exe,'-test.run=^$','-test.bench=^BenchmarkTheoryConstantRewrite$','-test.benchtime=400000x'],text=True)
        for line in result.splitlines():
            if line.startswith('Benchmark'):
                print(label,i+1,line,flush=True)
