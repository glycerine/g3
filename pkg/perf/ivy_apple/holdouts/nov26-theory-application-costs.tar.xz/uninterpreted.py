"""Skip general reduction dispatch for unchanged uninterpreted theory applications."""
from pathlib import Path
import json,subprocess
work=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/rewriter_engine.go'
code=src.read_text()
i=code.index('\n\t\td, e := m.GetDecl(t)',code.index('// The beta reducer has no application rule'))
code=code[:i]+'''
		if theory, ok := r.cfg.(*theoryRewriterConfiguration); ok && !fr.newChild() && (!theory.pullCheapITE || n != 2) && !ast.ASTValidateHandles && !ast.ASTSourceDebug {
			if family, err := m.GetFamilyID(t); err == nil && family == ast.NullFamilyID {
				if e := m.SetRef(r.pr2, ast.ASTHandle{}); e != nil {
					return e
				}
				if e := m.SetRefHeld(r.r, t); e != nil {
					return e
				}
				return r.finish(fr, false, true)
			}
		}'''+code[i:]
dst=work/'uf_engine.go'
dst.write_text(code)
overlay=work/'uninterpreted.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'uninterpreted','./cmd/g3'],check=True)
