"""Median percentage change of trial relative to its paired baseline."""
import csv,collections,statistics,sys
for name in sys.argv[1:]:
    rows=collections.defaultdict(dict)
    for x in csv.DictReader(open(name)):
        rows[x['case'],x['round']][x['engine']]=x
    for case in sorted(set(c for c,i in rows)):
        pairs=[v for (c,i),v in rows.items() if c==case and len(v)==2]
        if pairs:
            print(case,len(pairs),*[round(statistics.median((float(p['trial'][k])/float(p['base'][k])-1)*100 for p in pairs),3) for k in ('instructions','cycles','milliseconds')])
