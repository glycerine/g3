"""Build both verifiers with one fixed GoIvy source export and a local g3 replace."""
from pathlib import Path
import subprocess
import tarfile
import tempfile
import sys
work=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(dir=work) as path:
    with subprocess.Popen(['git','-C',Path.home()/'ivy','archive','77f7733de','goivy'],stdout=subprocess.PIPE) as proc:
        with tarfile.open(fileobj=proc.stdout,mode='r|') as tar:
            tar.extractall(path,filter='data')
    assert proc.returncode==0
    src=Path(path)/'goivy'
    subprocess.run(['go','mod','edit','-replace','github.com/glycerine/g3/pkg='+str(Path.cwd())],cwd=src,check=True)
    for name in sys.argv[1:] or ['base','quantifier']:
        flags = [] if name in ('base','release') else ['-overlay',work/(name+'.json')]
        subprocess.run(['go','build','-mod=readonly','-pgo=off','-buildvcs=false','-tags=xtrace_off',*flags,'-o',work/(name+'-goivy'),'./cmd/goivy_check'],cwd=src,check=True)
