"""Finish an uninterpreted theory constant in one pass when the proof register is empty."""
from pathlib import Path
import json,subprocess
work=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/rewriter_engine.go'
code=src.read_text()
i=code.index('d, e := m.GetDecl(t)',code.index('func (r *rewriterEngine) processConst'))
code=code[:i]+'''if r.skipResumeCacheProbe && !r.substituteVariables {
		proof, err := m.RefGetHeld(r.pr)
		if err == nil && proof.IsNull() && m.TryIncRefHeldUninterpretedConstant(t) {
			c.results = append(c.results, t)
			return nil
		}
	}
	'''+code[i:]
dst=work/'constant_engine.go'
dst.write_text(code)
overlay=work/'constant.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'constant','./cmd/g3'],check=True)
