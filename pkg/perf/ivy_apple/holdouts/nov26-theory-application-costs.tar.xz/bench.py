"""Build the benchmark on both engines, then alternate on one CPU."""
from pathlib import Path
import json,subprocess,sys
work=Path(__file__).resolve().parent
for name in ('base','constant'):
    mapping={} if name=='base' else json.loads((work/'constant.json').read_text())['Replace']
    mapping[str(Path.cwd()/'ast/rewriter/leaf_benchmark_test.go')]=str(work/'leaf_benchmark_test.go')
    overlay=work/(name+'-bench.json')
    overlay.write_text(json.dumps({'Replace':mapping}))
    subprocess.run(['go','test','-mod=readonly','-pgo=off','-buildvcs=false','-overlay',overlay,'-c','-o',work/(name+'-bench'),'./ast/rewriter'],check=True)
for turn in range(11):
    for name in (('base','constant') if turn%2==0 else ('constant','base')):
        r=subprocess.check_output(['taskset','-c',sys.argv[1],work/(name+'-bench'),'-test.run=^$','-test.bench=^BenchmarkTheoryConstantRewrite$','-test.benchtime=200000x'],text=True)
        for line in r.splitlines():
            if line.startswith('Benchmark'): print(name,turn+1,line,flush=True)
