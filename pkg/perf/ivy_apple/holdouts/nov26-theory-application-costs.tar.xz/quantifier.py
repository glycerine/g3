"""Read each quantifier frame's immutable body and child counts in one arena lookup."""
import json
from pathlib import Path
import subprocess
work = Path(__file__).resolve().parent
pkg = Path.cwd()
replacements = {}
def save(src, code):
    dst = work / src.name
    dst.write_text(code)
    replacements[str(src)] = str(dst)
src = pkg / 'ast/ast_core_query.go'
save(src,src.read_text()+'''
func (m *ASTManager) QuantifierChildren(h ASTHandle) (ASTHandle, uint32, uint32, uint32, error) {
	r, err := m.readKind(h, ASTQuantifier)
	if err != nil {
		return ASTHandle{}, 0, 0, 0, err
	}
	q := m.quantifierAt(r.slot)
	return m.external(q.body), q.count, q.patternCount, q.noPatternCount, nil
}
''')
src = pkg / 'ast/rewriter/rewriter_engine.go'
code = src.read_text()
i = code.index('nd, e := m.GetNumDeclarations(q)',code.index('func (r *rewriterEngine) processQuantifier()'))
j = code.index('if e != nil',code.index('body, e := m.GetQuantifierBody(q)',i))
save(src, code[:i]+'body, nd, np, nn, e := m.QuantifierChildren(q)\n\t'+code[j:])
overlay = work / 'quantifier.json'
overlay.write_text(json.dumps({'Replace': replacements}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'quantifier','./cmd/g3'],check=True)
