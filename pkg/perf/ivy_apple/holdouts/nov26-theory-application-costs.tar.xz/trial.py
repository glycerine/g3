"""Build a CLI overlay that clears an initial-size activity table in place on reset."""
import json
from pathlib import Path
import subprocess

work = Path(__file__).resolve().parent
src = Path.cwd() / 'ast/ast_activity_chashtable.go'
code = src.read_text()
key = '\tt.init(activityChashInitSlots, activityChashInitCellar)\n}'
assert code.count(key) == 1
code = code.replace(key, '''	if t.slots == activityChashInitSlots && len(t.cells) == activityChashInitSlots+activityChashInitCellar {
		clear(t.cells)
		t.usedSlots, t.size = 0, 0
		t.nextCell, t.freeCell = t.slots, activityChashNil
		return
	}
''' + key)
dst = work / src.name
dst.write_text(code)
overlay = work / 'trial.json'
overlay.write_text(json.dumps({'Replace': {str(src): str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'trial','./cmd/g3'],check=True)
