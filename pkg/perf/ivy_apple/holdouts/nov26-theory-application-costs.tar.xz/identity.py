"""Use the existing cached declaration family and kind on the visited application."""
from pathlib import Path
import json,subprocess
work=Path(__file__).resolve().parent
base=Path.cwd()/'ast/rewriter'
mapping={}
def save(src,code):
    dst=work/('identity_'+src.name)
    dst.write_bytes(subprocess.check_output(['gofmt'],input=code.encode()))
    mapping[str(src)]=str(dst)
src=base/'th_rewriter.go'
s=src.read_text()
key='family, err := m.GetFamilyID(decl)\n\tif err != nil || family == ast.NullFamilyID'
assert s.count(key)==1
s=s.replace('reduceAppCore(decl ast.ASTHandle, args','reduceKnownAppCore(app, decl ast.ASTHandle, args',1)
s=s.replace(key,'''var family ast.FamilyID
	var kind int32
	var err error
	if app.IsNull() {
		family, err = m.GetFamilyID(decl)
	} else {
		_, family, kind, err = m.AppIdentity(app)
	}
	if err != nil || family == ast.NullFamilyID''')
key='kind, err := m.GetDeclKind(decl)\n\t\tif err != nil {\n\t\t\treturn RewriteFailed, err\n\t\t}'
i=s.index(key,s.index('func (c *theoryRewriterConfiguration) reduceKnownAppCore'))
s=s[:i]+s[i:].replace(key,'''if app.IsNull() {
			kind, err = m.GetDeclKind(decl)
			if err != nil { return RewriteFailed, err }
		}''',1)
key='func (c *theoryRewriterConfiguration) ReduceApp(decl ast.ASTHandle, args ast.AppArguments, out, proof ast.ASTRef) (RewriteStatus, error) {'
s=s.replace(key,key+'''
	return c.reduceKnownApp(ast.ASTHandle{},decl,args,out,proof)
}

func (c *theoryRewriterConfiguration) reduceKnownApp(app,decl ast.ASTHandle,args ast.AppArguments,out,proof ast.ASTRef)(RewriteStatus,error){''')
s=s.replace('c.reduceAppCore(decl, args, out)','c.reduceKnownAppCore(app, decl, args, out)')
save(src,s)
src=base/'rewriter_engine.go'
s=src.read_text()
for old,new in [('st, e := r.cfg.ReduceApp(d, ast.AppArguments{}, r.r, r.pr)','st, e := r.reduceApp(t,d, ast.AppArguments{}, r.pr)'),('st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)','st, e := r.reduceApp(t,d,args,r.pr2)')]:
    assert s.count(old)==1
    s=s.replace(old,new)
s+='''
func (r *rewriterEngine) reduceApp(app,decl ast.ASTHandle,args ast.AppArguments,proof ast.ASTRef)(RewriteStatus,error){
	if c,ok:=r.cfg.(*theoryRewriterConfiguration); ok && !ast.ASTValidateHandles && !ast.ASTSourceDebug {
		return c.reduceKnownApp(app,decl,args,r.r,proof)
	}
	return r.cfg.ReduceApp(decl,args,r.r,proof)
}
'''
save(src,s)
overlay=work/'identity.json'
overlay.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'identity','./cmd/g3'],check=True)
