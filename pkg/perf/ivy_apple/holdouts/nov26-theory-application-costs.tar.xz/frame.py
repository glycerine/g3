"""Initialize the frame directly in its stack slot, preserving truncation and checks."""
import json, subprocess
from pathlib import Path
work=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/rewriter_core.go'
code=src.read_text()
i=code.index('fr := rewriterFrame{curr: t')
j=code.index('return nil',i)
code=code[:i]+'''c.frames = append(c.frames, rewriterFrame{})
	fr := &c.frames[len(c.frames)-1]
	fr.curr, fr.spos, fr.kind, fr.numArgs = t, n, kind, numArgs
	fr.setState(state)
	fr.setDepth(depth)
	if cache {
		fr.flags |= 1
	}
	'''+code[j:]
dst=work/src.name
dst.write_text(code)
overlay=work/'frame.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'frame','./cmd/g3'],check=True)
