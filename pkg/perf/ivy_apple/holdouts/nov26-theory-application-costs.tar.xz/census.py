"""Count cache construction, actual table capacities, resets and closes for each Ticket process."""
import collections
import csv
import json
from pathlib import Path
import subprocess
import sys

pkg = Path.cwd()
work = Path(__file__).resolve().parent
src = pkg / 'ast/ast_activity_cache.go'
code = src.read_text()
for label, marker in [('create', 'c.self = c'), ('first', 'c.activityCacheEntries = new(activityCacheEntries)'), ('cleanup', 'c.activityCacheEntries = nil\n\t} else if'), ('reset','c.table.reset()'), ('close','c.manager.BudgetField.Release(activityCacheBytes())')]:
    assert code.count(marker) == 1
    expr = '0' if label in ('create','first','close') else 'len(c.table.cells)'
    if label == 'cleanup':
        expr = '0'
    code = code.replace(marker, 'println("cache-'+label+'", '+expr+')\n\t'+marker)
dst = work / src.name
dst.write_text(code)
overlay = work / 'census.json'
overlay.write_text(json.dumps({'Replace': {str(src): str(dst)}}))
exe = work / 'census'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',exe,'./cmd/g3'],check=True)
out = csv.writer(sys.stdout)
out.writerow(('query','event','cells','count'))
for q,counts in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
    import re
    src = Path(sys.argv[1]) / (q+'.smt2')
    r = subprocess.run([exe,'-in','-smt2'],input=src.read_bytes(),capture_output=True,check=True)
    stats = dict(re.findall(rb':([\w-]+)\s+(\d+)\b',r.stdout))
    assert r.stdout.startswith(b'unsat\n') and tuple(int(stats[k]) for k in (b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count')) == counts
    events = collections.Counter()
    for line in r.stderr.decode().splitlines():
        label,n = line.split()
        assert label.startswith('cache-')
        events[label[6:],int(n)] += 1
    for (label,n),cnt in sorted(events.items()):
        out.writerow((q,label,n,cnt))
