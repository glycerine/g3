"""Combine first insertion allocations for cache metadata, initial cells and queue."""
import json
from pathlib import Path
import subprocess

work = Path(__file__).resolve().parent
src = Path.cwd() / 'ast/ast_activity_cache.go'
code = src.read_text()
key = 'c.activityCacheEntries = new(activityCacheEntries)'
assert code.count(key) == 1
code = code.replace(key, '''storage := new(struct {
			activityCacheEntries
			cells [activityChashInitSlots+activityChashInitCellar]activityChashCell
			keys [activityChashInitSlots]astNodeRef
		})
		c.activityCacheEntries = &storage.activityCacheEntries
		c.table.spare = storage.cells[:]
		c.queue = storage.keys[:0]''')
dst = work / 'inline_cache.go'
dst.write_text(code)
overlay = work / 'inline.json'
overlay.write_text(json.dumps({'Replace': {str(src): str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'inline','./cmd/g3'],check=True)
