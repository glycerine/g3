from study import *
import guarded_live as gl,macro_identity as mi,theory_traversal_steps as th
from collections import Counter
d=w/'arithmetic-bounds';d.mkdir(exist_ok=True)
q=pkg/'ast/rewriter/arith_rewriter.go';p=pkg/'ast/rewriter/arith_polynomial.go'
helper='''
func(r *ArithRewriter)trialAtomicBound(lhs,rhs ast.ASTHandle,width int)bool{
 m:=r.manager
 if ast.ASTSourceDebug || ast.ASTValidateHandles || diagnostic.TraceCompiled() || m.TraceStream!=nil || m.Budget().Limit()!=^uint64(0) || m.Budget().InjectionArmed() || m.NumeralService().RuntimeOwner().AllocationLimited(){return false}
 hd,e:=m.NodeHeader(lhs);if e!=nil{return false}
 simple:=func(h ast.ASTNodeHeader)bool{return h.Kind==ast.ASTVar || h.Kind==ast.ASTApp && h.Family==ast.NullFamilyID}
 sum:=width>0 && hd.Kind==ast.ASTApp && hd.Family==r.family && hd.DeclKind==arithOpAdd && hd.NumArgs>1 && hd.NumArgs<=uint32(width)
 if !simple(hd)&& !sum{return false}
 _,ok,e:=m.ArithmeticIntegralInt32(rhs);if e!=nil||!ok{return false}
 l,e:=m.GetSort(lhs);if e!=nil{return false};z,e:=m.GetSort(rhs);if e!=nil || z!=l{return false}
 if sum{for j:=uint32(0);j<hd.NumArgs;j++{child,e:=m.GetArg(lhs,j);if e!=nil{return false};term,e:=m.NodeHeader(child);if e!=nil{return false}
 if simple(term){continue}
 if j==0 || term.Kind!=ast.ASTApp || term.Family!=r.family || term.DeclKind!=arithOpMul || term.NumArgs!=2{return false}
 coeff,e:=m.GetArg(child,0);if e!=nil{return false};v,ok,e:=m.ArithmeticIntegralInt32(coeff);if e!=nil || !ok || v==0{return false}
 base,e:=m.GetArg(child,1);if e!=nil{return false};varInfo,e:=m.NodeHeader(base);if e!=nil||!simple(varInfo){return false}
 }}
 return true
}
'''
def ed(v):
 if v=='control':return {}
 s=q.read_text();changes={}
 x='newLeft, newRight, powerChanged, err := r.reduceComparisonPowers(left, right, '
 if v not in ('header','cancel'):
  s=once(s,'import (','import (\n"github.com/glycerine/g3/pkg/util/diagnostic"'+('\n"fmt";"os"' if v=='audit' else''))+helper
  width=0 if v=='atom'else 12
  for eq in ['false','true']:
   target=x+eq+')';check='if r.trialAtomicBound(left,right,'+str(width)+'){return RewriteFailed,nil}\n'
   if v=='audit':check='''if hit:=r.trialAtomicBound(left,right,12);hit{before:=r.manager.ResourceLimit().Steps;defer func(){fmt.Fprintln(os.Stderr,"BOUND-TRIAL",'''+eq+''',status==RewriteFailed,err==nil,before==r.manager.ResourceLimit().Steps)}()}else{fmt.Fprintln(os.Stderr,"BOUND-OTHER",'''+eq+''')}\n'''
   s=once(s,target,check+target)
 if v in ('header','all'):
  i=s.index('nodeKind, err :=',s.index('func (r *ArithRewriter) operation('));j=s.index('matched :=',i);s=s[:i]+'''hd,err:=r.manager.NodeHeader(h);if err!=nil || hd.Kind!=ast.ASTApp || hd.Family!=r.family{return 0,nil,false,err};kind:=hd.DeclKind
  '''+s[j:];s=once(s,'n, err := r.manager.GetNumArgs(h)\n\tif err != nil {\n\t\treturn 0, nil, false, err\n\t}\n\targs := make([]ast.ASTHandle, n)','args:=make([]ast.ASTHandle,hd.NumArgs)')
 if v in ('cancel','all'):
  poly=p.read_text();anchor='sides := [2][]ast.ASTHandle{}';poly=once(poly,anchor,'''if !ast.ASTSourceDebug && !ast.ASTValidateHandles && !diagnostic.TraceCompiled() && r.manager.TraceStream==nil && r.manager.Budget().Limit()==^uint64(0) && !r.manager.Budget().InjectionArmed() && !r.manager.NumeralService().RuntimeOwner().AllocationLimited(){
   if rightIsNum,e:=r.manager.IsArithmeticNumeral(right);e==nil && rightIsNum{
    h,e:=r.manager.NodeHeader(left);if e==nil && (h.Kind==ast.ASTVar || h.Kind==ast.ASTApp && h.Family==ast.NullFamilyID){return ast.ASTHandle{},ast.ASTHandle{},false,nil}
   }}
  '''+anchor);changes[p]=once(poly,'import (','import (\n"github.com/glycerine/g3/pkg/util/diagnostic"')
 changes[q]=s;return changes
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);base=pkg/'smtcore/cached_var_subst.go'; src=subprocess.check_output(['git','show','c6c84b31e:pkg/smtcore/cached_var_subst.go'],cwd=pkg,text=True); o=overlay(od/'overlay',ed(v)|{base:src})
 with(w/'build.lock').open('a')as f,(od/'focused.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-overlay='+str(o),'-run','Test(ArithRewriter|TheoryRewriter|Arithmetic|QFNRA)','-count=1','./ast/rewriter','./smtcore'],cwd=pkg,stdout=log,stderr=log)
 return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def audit(v):
 b=v;ns=['toy-consensus-18','aux-012725','aux-017026','aux-011440','ticket-127','ticket-290']
 with(d/'audit'/'predictions.csv').open('w')as f:
  z=csv.writer(f);z.writerow('query calls matched wrong'.split())
  for n in ns:
   r=run(['taskset','-c','38',b,'-in','-smt2'],input=th.warm.script(n,12,False),text=True,capture_output=True,env=dict(env,GOMAXPROCS='1'));assert len(r.stdout.split())==12
   ls=[x.split()for x in r.stderr.splitlines()if x.startswith('BOUND-')];hits=[x for x in ls if x[0]=='BOUND-TRIAL'];z.writerow([n,len(ls),len(hits),sum(x[-3:]!=['true']*3 for x in hits)]);f.flush()
def main():
 vs=['control','atom','sum','cancel','header','all','audit']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 a=bs.pop('audit');bb={v:b[0]for v,b in bs.items()};ss={v:b[1]for v,b in bs.items()}|{'native':pkg.parent/'build/z3'};gl.d=d;th.d=d
 qs=['toy-consensus-18','aux-012725','aux-017026','aux-011440','ticket-127'];js=[(c,*j[1:5],3,j[-1])for c,j in zip([2,6,8,10,12,14],(j for j in mi.jobs()if j[1] in ('tlb','ordinary','toy-consensus','rfn2','hybrid_reliable_broadcast_cisa','cf_live')))]
 with ThreadPoolExecutor(13)as e:
  fs=[e.submit(gl.measure_job,j,bb)for j in js]+[e.submit(th.replay,(c,n,ss))for c,n in zip([25,27,29,31,32],qs)]+[e.submit(audit,a[1])]
  for f in fs:f.result()
if __name__=='__main__':main()
