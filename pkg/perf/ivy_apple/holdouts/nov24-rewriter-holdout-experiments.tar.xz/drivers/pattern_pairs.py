from study import *
import flat_pattern_collect as fc,macro_identity as mi,guarded_live as gl
from collections import Counter
d=w/'pattern-pairs';d.mkdir(exist_ok=True);q=pkg/'ast/pattern/infer.go';fn=fc.fn
direct='''
type patternPairPrediction struct{args [2][2]ast.ASTHandle; widths [2]int;num int}
func(p *patternPairPrediction)run(c *patternCandidates,body ast.ASTHandle,limit uint32,t *flatTrial)bool{
 if len(c.preferred)!=0 || c.numBindings==0 || c.numBindings>64 || t.num>2{return false}
 var el [2]*flatInfoTrial;used:=0
 for _,i:=range t.selected[:t.num]{a:=&t.slots[i];skip:=false;for _,x:=range c.noPatterns{if x==a.h{skip=true;break}};if !skip{el[used]=a;used++}}
 if used==2 && el[0].vars==el[1].vars{
  if el[0].size!=el[1].size{return false}
  if c.blockLoops{a,e:=c.manager.GetDecl(el[0].h);if e!=nil{return false};b,e:=c.manager.GetDecl(el[1].h);if e!=nil || a==b{return false}}
 }
 var mask uint64=(uint64(1)<<c.numBindings)-1
 for _,a:=range el[:used]{if a.vars==mask{p.args[p.num][0]=a.h;p.widths[p.num]=1;p.num++}}
 if p.num>0 || used<2 || el[0].vars|el[1].vars!=mask || limit+1==0{return true}
 a,b:=el[0],el[1];na,nb:=bits.OnesCount64(a.vars),bits.OnesCount64(b.vars);if na<nb || na==nb && a.size>b.size{a,b=b,a}
 p.args[0]=[2]ast.ASTHandle{a.h,b.h};p.widths[0]=2;p.num=1
 return true
}
func(p *patternPairPrediction)emit(c *patternCandidates)([]ast.ASTRef,error){
 var out []ast.ASTRef;for i,n:=range p.widths[:p.num]{h,e:=c.manager.MkFamilyApp(2,0,nil,p.args[i][:n]);if e!=nil{return out,e};r,e:=c.manager.NewRef(h);if e!=nil{return out,e};out=append(out,r)};return out,nil
}
'''
def edit(v):
 if v=='control':return {}
 if v=='flat':return fc.edits('flat-64')
 s=q.read_text();s=once(s,'import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/util/diagnostic"'+(';"os";"fmt"'if v=='audit'else'')+')')if 'import "'in s else once(s,'import (','import (\n"github.com/glycerine/g3/pkg/util/diagnostic"'+(';"os";"fmt"' if v=='audit'else''))
 gate='if '+fc.guard+'{inner,e:=c.manager.HasQuantifiers(body);rc,e2:=c.manager.GetRefCount(body);if e==nil && e2==nil && rc!=0 && !inner{arith,e:=c.manager.ArithmeticFamilyID();if e!=nil{return nil,e};var t flatTrial;if _,ok:=t.visit(c,body,arith,0);ok{var pred patternPairPrediction;if pred.run(c,body,maxExtraMulti,&t){ACTION};OTHER}}}'
 act='return pred.emit(c)';other='if e:=t.publish(c);e!=nil{return nil,e};return c.selectPatterns(maxExtraMulti)'if v in ('combined','small')else''
 if v=='audit':act='''defer func(){if err!=nil{return};if len(patterns)!=pred.num{panic("pattern count")};for i,ref:=range patterns{h,e:=c.manager.RefGet(ref);if e!=nil{panic(e)};n,e:=c.manager.GetNumArgs(h);if e!=nil||int(n)!=pred.widths[i]{panic("pattern width")};for j:=uint32(0);j<n;j++{a,e:=c.manager.GetArg(h,j);if e!=nil||a!=pred.args[i][j]{panic("pattern order")}}};fmt.Fprintln(os.Stderr,"PAIR-PRED",t.num,pred.num,pred.widths)}()''';gate='defer func(){fmt.Fprintln(os.Stderr,"PAIR-ALL")}()\n'+gate
 a='if err = c.collect(body);';s=once(s,a,gate.replace('ACTION',act).replace('OTHER',other)+'\n'+a)
 width=32 if v=='small'else 64
 return {q:s,fn:fc.templ.replace('WIDTH',str(width)).replace('slot.size+=ch.size','if ch.size>65535-slot.size{return nil,false};slot.size+=ch.size')+direct}
def mk(v):
 od=d/v;o=overlay(od/'overlay',edit(v))
 with(w/'build.lock').open('a')as f,(od/'focused.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-overlay='+str(o),'-count=1','./ast/pattern'],cwd=pkg,stdout=log,stderr=log)
 return build(od/'checker',o=o)
def audit(j,b):
 c,n,sp,iso,rc,_,ref=j;od=d/'audit'/n;od.mkdir(exist_ok=True);ct=Counter()
 with (od/'stdout').open('wb')as so,(od/'stderr').open('wb')as se,subprocess.Popen(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=od,env=dict(env,GOMAXPROCS='1'),stdout=so,stderr=subprocess.PIPE)as proc:
  for l in proc.stderr:
   if l.startswith(b'PAIR-'):ct[l.decode().strip()]+=1
   else:se.write(l)
  code=proc.wait()
 assert code==rc and all((od/k).read_bytes()==(ref/k).read_bytes()for k in ('stdout','stderr')),(n,code,(od/'stderr').read_bytes()[-300:])
 with(od/'coverage.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['prediction','calls']);z.writerows(ct.items())
def main():
 vs=['control','flat','pair','combined','small','audit']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 a=bs.pop('audit');gl.d=d
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([13,15,17,19,21,23,25,27,29],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(11)as ex:
  fs=[ex.submit(gl.measure_job,j,bs)for j in js]
  for j in mi.jobs():audit(j,a)
  for f in fs:f.result()
if __name__=='__main__':main()
