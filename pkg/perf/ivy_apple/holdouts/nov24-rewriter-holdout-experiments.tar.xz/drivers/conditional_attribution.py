from end_stats import *
for n in ('ordinary','tlb','raft_no_assume_test'):
 a=defaultdict(lambda:defaultdict(dict))
 for p in (w/'conditional-cost'/n).glob('*/phases.csv.gz'):
  i,v=p.parent.name.split('-')
  try:rs=list(csv.DictReader(gzip.open(p,'rt')))
  except EOFError:continue
  if not rs:continue
  for r in rs:
   key=r['batch'],r['condition'],r['stage']
   if key in a[i][v]:raise ValueError(key)
   a[i][v][key]=(int(r['instructions']),r['result'])
 gaps=defaultdict(list);ks=defaultdict(list);results=Counter()
 for i,groups in a.items():
  if 'control'not in groups or 'data256'not in groups:continue
  one,two=groups['control'],groups['data256']
  excess=set(one)^set(two);tot=Counter();diff=Counter()
  for k in set(one)|set(two):
   x,y=one.get(k,(0,'-')),two.get(k,(0,'-'));s=x[0]-y[0];tot[k[2]]+=s;ks[k].append(s);results[x[1],y[1]]+=1
   if x[1]!=y[1]:diff[k[2]]+=1
  for k,v in tot.items():gaps[k].append(v)
  print(n,i,'rows',len(one),len(two),'key diff',len(excess),'verdict diffs',diff)
 print(n,[(k,round(median(v)/1e9,4))for k,v in sorted(gaps.items(),key=lambda t:-median(t[1]))])
 print('largest',[(k,round(median(v)/1e9,3))for k,v in sorted(ks.items(),key=lambda t:-median(t[1]))[:3]])
