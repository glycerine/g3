from study import *
import conditional_changes as ch,conditional_shared as cs,conditional_datatypes as cd,guarded_live as gl,macro_identity as mi
from panel import CASES
d=w/'conditional-local-forms';d.mkdir(exist_ok=True)
def edits(v):
 if v=='control':return {}
 if v=='base256':return cd.ed('data256')
 ed=cs.ed('compound');s=ed[ch.ite];x='return (boolean||datatype)&&compound'
 if v=='only-data':y='_=boolean;return datatype && compound'
 elif v=='bool-with-data':y='''if !compound{return false};if datatype{return true};if !boolean{return false};if h.Family==dt{return true};for j:=uint32(0);j<h.NumArgs && j<8;j++{a,e:=m.GetArg(shared,j);if e!=nil{continue};s,e:=m.GetSort(a);if e!=nil{continue};f,e:=m.GetFamilyID(s);if e==nil && f==dt{return true}};return false'''
 elif v in ('condition-data','branch-data'):
  term='c'if v=='condition-data'else'key';y='''if !compound{return false};if datatype{return true};if !boolean{return false};TERMS;for _,key:=range terms{t,e:=m.NodeHeader(key);if e!=nil || t.Kind!=ast.ASTApp{continue};if t.Family==dt{return true};for j:=uint32(0);j<t.NumArgs && j<8;j++{a,e:=m.GetArg(key,j);if e!=nil{continue};s,e:=m.GetSort(a);if e!=nil{continue};f,e:=m.GetFamilyID(s);if e==nil && f==dt{return true}}};return false'''.replace('TERMS','terms:=[1]ast.ASTHandle{c}'if v=='condition-data'else'terms:=[3]ast.ASTHandle{c,t,f}')
 else:raise ValueError(v)
 ed[ch.ite]=once(s,x,y);return ed
def mk(v):
 od=d/v;o=overlay(od/'overlay',edits(v));b=build(od/'checker',o=o);info=run(['go','version','-m',b],capture_output=True,text=True).stdout;assert '=>\t/home/jaten/g3/pkg\t(devel)'in info;(od/'build-info.txt').write_text(info);return b
def main():
 gl.d=d;vs=['control','base256','only-data','bool-with-data','condition-data','branch-data']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([1,4,6,8,10,12],(j for j in mi.jobs()if j[1]in ('ordinary','tlb','toy-consensus','raftok','rfn2','raft_no_assume_test')))];n='raft_no_assume';sp,iso,_,f,u=CASES[n];js.append((14,n,sp,iso,int(bool(f or u)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(7)as ex:list(ex.map(lambda j:gl.measure_job(j,bs),js))
if __name__=='__main__':main()
