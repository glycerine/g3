from study import *
import macro_identity as mi,guarded_live as gl,theory_traversal_steps as th,numeral_shapes as shape
d=w/'numeral-read-cache';d.mkdir(exist_ok=True);q=pkg/'ast/ast_arith_numeral_text.go';own=pkg/'ast/ast_arith_plugin.go';bt=q.with_name('numeral_read_trial_test.go')
bench='''package ast
import("testing";"fmt";"github.com/glycerine/g3/pkg/util/numeral")
func BenchmarkNumericReadTrial(b *testing.B){
 for _,width:=range []int{1,8,32,128}{for _,mix:=range []bool{false,true}{b.Run(fmt.Sprintf("%d/%t",width,mix),func(b *testing.B){
 m:=astTestManager(b);ss,e:=m.MkBoolSort();astTestMust(b,e);hs:=make([]ASTHandle,width);for j:=range hs{if mix && j%2==1{hs[j],e=m.MkVar(uint32(j),ss)}else{v:=numeral.Rational{Num:numeral.NewInt(int32(j-3)),Den:numeral.NewInt(1)};hs[j],e=m.ArithmeticNumeralFromRational(&v,j%3==0)};astTestMust(b,e);astTestPin(b,m,hs[j])};b.ReportAllocs();b.ResetTimer()
 for i:=0;i<b.N;i++{j:=i&(width-1);v,ok,e:=m.ArithmeticIntegralInt32(hs[j]);if e!=nil || ok==(mix && j%2==1) || ok && v!=int32(j-3){b.Fatal(j,v,ok,e)}}
 })}}}
'''
def edit(v):
 ed={bt:bench}
 if v=='control':return ed
 s=q.read_text();i=s.index('r, err := m.requireExpr(h)',s.index('func (m *ASTManager) arithmeticNumeralParameter'))
 neg='''if h.origin==m.origin && h.slot!=0 && h.slot<m.nextNode{n:=m.nodeSlotAt(h.slot);if n.node.live && n.node.generation==h.generation && n.node.kind<=ASTQuantifier{if n.node.kind!=ASTApp || m.arithmeticPlugin==nil || n.app.declCached && (n.app.declFamily!=m.arithmeticPlugin.family || n.app.declKind!=0){return}}}'''
 if v=='negative':s=s[:i]+'if !astValidateHandles{'+neg+'}\n'+s[i:]
 elif v=='records':
  pat=gzip.decompress((pkg/'perf/ivy_apple/holdouts/rewriter_trials/nov22b-atomic-comparison-experiment.patch.gz').read_bytes()).decode().split('--- a/pkg/ast/rewriter')[0];extra='\n'.join(l[1:]for l in pat.splitlines()if l.startswith('+')and not l.startswith('+++'));s=s[:i]+extra+'\n'+s[i:]
 else:
  width=int(v.split('-')[-1]);pos='positive'in v
  osrc=once(own.read_text(),'type astArithmeticPluginOwner struct {','type trialNumeralRead struct{key astNodeRef; param ASTParameter; integer bool}\n type astArithmeticPluginOwner struct {\n reads ['+str(width)+']trialNumeralRead');ed[own]=osrc
  a='''if p:=m.arithmeticPlugin;!astValidateHandles && p!=nil && p.published && h.origin==m.origin && h.slot!=0 && h.slot<m.nextNode{
   slot:=m.nodeSlotAt(h.slot);if slot.node.live && slot.node.generation==h.generation && slot.node.kind<=ASTQuantifier{
    NEG
    e:=p.reads[h.slot%uint32(len(p.reads))];if e.key.slot==h.slot && e.key.generation==h.generation{first,err:=m.parameter(e.param);if err==nil && first.Kind==ASTParameterRational{return &first.Rational,e.integer,true,nil}}
   }
  }\n'''.replace('NEG',''if pos else 'if slot.node.kind!=ASTApp || slot.app.declCached && (slot.app.declFamily!=p.family || slot.app.declKind!=0){return}')
  s=s[:i]+a+s[i:];start=s.index('func (m *ASTManager) arithmeticNumeralParameter');pre,s=s[:start],s[start:];s=once(s,'first, err := m.parameter(p)','firstParam:=p;first, err := m.parameter(p)');s=once(s,'return &first.Rational, second.integer != 0, true, nil','if !astValidateHandles && !info.lexical && m.arithmeticPlugin.published{m.arithmeticPlugin.reads[h.slot%'+str(width)+']=trialNumeralRead{r,firstParam,second.integer!=0}}\n return &first.Rational, second.integer != 0, true,nil');s=pre+s
 ed[q]=s;return ed
def mk(v):
 od=d/v;o=overlay(od/'overlay',edit(v));b=od/'ast.test'
 with(w/'build.lock').open('a')as lk,(od/'focused.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-p','4','-pgo=off','-overlay='+str(o),'-o',b,'./ast'],cwd=pkg,stdout=log,stderr=log);run([b,'-test.run','Arithmetic|ArithPlugin|Numeral','-test.count=1'],cwd=pkg/'ast',stdout=log,stderr=log)
 return b,build(od/'shell',o=o,shell=True),build(od/'checker',o=o)
def micro(bs):
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine width mixed iterations ns bytes allocs'.split())
  for i in range(15):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in vs:
    r=run(['taskset','-c','43',bs[v][0],'-test.run=^$','-test.bench=^BenchmarkNumericReadTrial$','-test.benchmem','-test.cpu=1','-test.benchtime=100000x'],cwd=pkg/'ast',capture_output=True,text=True);data=re.findall(r'BenchmarkNumericReadTrial/(\d+)/(true|false)\s+(100000)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(data)==8,r.stdout
    z.writerows([[i+1,v,*x]for x in data]);f.flush()
def main():
 vs=['control','negative','records','positive-4','mixed-8','mixed-32','mixed-128']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 gl.d=d;th.d=d;ss={v:b[1]for v,b in bs.items()}|{'native':pkg.parent/'build/z3'};bb={v:b[2]for v,b in bs.items()}
 ns=d/'models';ns.mkdir(exist_ok=True);shape.d=ns;shape.bs=ss
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([2,4,8,10],(j for j in mi.jobs()if j[1]in ('ordinary','tlb','toy-consensus','rfn2')))]
 with ThreadPoolExecutor(20)as ex:
  fs=[ex.submit(micro,bs)]+[ex.submit(gl.measure_job,j,bb)for j in js]+[ex.submit(th.replay,(c,n,ss))for c,n in zip([25,26,27,28,29],['toy-consensus-18','aux-012725','aux-017026','ticket-127','aux-011440'])]+[ex.submit(shape.lane,(c,shape.cases[i::4]))for i,c in enumerate([14,15,16,17])]+[ex.submit(shape.validate,v)for v in vs]
  for f in fs:f.result()
if __name__=='__main__':main()
