from study import *
import guarded_live as gl,macro_identity as mi
from collections import Counter
d=w/'sharing-identity';d.mkdir(exist_ok=True)
q=pkg/'ast/rewriter/maximize_ac_sharing.go';h=q.with_name('sharing_identity_trial.go')
helper='''package rewriter
import("github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/util/diagnostic")
type trialShareSlot struct{root ast.ASTHandle; safe bool}
func(r *MaximizeBVSharing) trialNeutral(h ast.ASTHandle,depth int)bool{
 if depth>128{return false};m:=r.manager;id,e:=m.GetASTID(h);if e!=nil{return false}
 if r.trialSlots==nil{r.trialSlots=make([]trialShareSlot,CAP)}
 index:=id%uint32(len(r.trialSlots));if ent:=r.trialSlots[index];ent.root==h{return ent.safe}
 hd,e:=m.NodeHeader(h);if e!=nil{return false};safe:=true
 switch hd.Kind{
 case ast.ASTVar:
 case ast.ASTApp:
 if hd.Family==m.BasicFamilyID() && hd.DeclKind==ast.ASTOpIte{safe=false;break}
 if hd.NumArgs>2 {assoc,e:=m.RewriterAssociative(hd.Decl);if e!=nil || assoc{safe=false;break}}
 for j:=uint32(0);j<hd.NumArgs;j++{a,e:=m.GetArg(h,j);if e!=nil || !r.trialNeutral(a,depth+1){safe=false;break}}
 case ast.ASTQuantifier:
 b,e:=m.GetQuantifierBody(h);safe=e==nil && r.trialNeutral(b,depth+1)
 if safe {n,e:=m.GetNumPatterns(h);safe=e==nil;for j:=uint32(0);j<n && safe;j++{a,e:=m.GetPattern(h,j);safe=e==nil && r.trialNeutral(a,depth+1)}}
 if safe {n,e:=m.GetNumNoPatterns(h);safe=e==nil;for j:=uint32(0);j<n && safe;j++{a,e:=m.GetNoPattern(h,j);safe=e==nil && r.trialNeutral(a,depth+1)}}
 default:safe=false
 };r.trialSlots[index]=trialShareSlot{h,safe};return safe
}
func(r *MaximizeBVSharing) trialEligible()bool{return !ast.ASTValidateHandles && !ast.ASTSourceDebug && !diagnostic.TraceCompiled() && r.manager.TraceStream==nil && !r.manager.Budget().InjectionArmed() && !r.proofs}
'''
def ed(v):
 if v=='control':return {}
 a=q.read_text();a=once(a,'type MaximizeBVSharing struct {','type MaximizeBVSharing struct {\ntrialSlots []trialShareSlot');x='if e := r.traversal.Rewrite(root, out); e != nil {'
 if v=='audit':
  a=once(a,'"errors"','"errors"\n"fmt";"os"')
  s='''if r.trialEligible(){
    predicted:=r.trialNeutral(root,0);before:=len(r.config.entries);steps:=r.manager.ResourceLimit().Count()
    defer func(){outH,e:=r.manager.RefGet(out);if e!=nil{panic(e)};fmt.Fprintln(os.Stderr,"BV-CENSUS",predicted,outH==root,len(r.config.entries)==before,r.manager.ResourceLimit().Count()-steps)}()
  }
  '''+x
 else:s='''if r.trialEligible() && r.trialNeutral(root,0){if e:=r.manager.SetRef(out,root);e!=nil{return e}}else '''+x
 return {q:once(a,x,s),h:helper.replace('CAP','256'if v=='small'else'4096')}
def mk(v):
 od=d/v;o=overlay(od/'overlay',ed(v));b=build(od/'checker',o=o);info=run(['go','version','-m',b],capture_output=True,text=True).stdout;assert '=>\t/home/jaten/g3/pkg\t(devel)'in info;(od/'build-info.txt').write_text(info);return b
def audit(j,b):
 c,n,sp,iso,rc,_,ref=j;od=d/'audit'/n;od.mkdir(parents=True,exist_ok=True)
 p=subprocess.run(['taskset','-c',str((c+20)%48),b,*(['isolate='+iso]if iso else []),examples/sp],cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1'))
 a=Counter();cost=Counter();other=bytearray()
 for l in p.stderr.splitlines(keepends=True):
  if l.startswith(b'BV-CENSUS '):
   _,*k,num=l.decode().split();k=tuple(k);a[k]+=1;cost[k]+=int(num)
  else:other.extend(l)
 assert p.returncode==rc and p.stdout==(ref/'stdout').read_bytes() and other==(ref/'stderr').read_bytes(),n
 with(od/'coverage.csv').open('w')as f:
  z=csv.writer(f);z.writerow('predicted identity entries_unchanged calls resource_steps'.split());z.writerows([*k,v,cost[k]]for k,v in a.items())
 print('audit',n,a,flush=True)
def main():
 gl.d=d;vs=['control','small','large','audit']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 obs=bs.pop('audit');js=[(c,*j[1:5],3,j[-1])for c,j in zip([1,3,5,7,9,11,13,15,17],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(14)as e:
  fs=[e.submit(gl.measure_job,j,bs) for j in js]+[e.submit(audit,j,obs)for j in mi.jobs()]
  for f in fs:f.result()
if __name__=='__main__':main()
