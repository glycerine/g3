from study import *
import arithmetic_numeral_paths as old,guarded_live as gl,macro_identity as mi,theory_traversal_steps as th,numeral_shapes as shape
d=w/'numeral-checked';d.mkdir(exist_ok=True)
fac=old.fac;q=old.q;test=old.test
def edit(v):
 es={test:old.template}
 if v=='control':return es
 if v in ('after-copy','before-copy','both'):
  s=fac.read_text();s=once(s,'unumeral "','udiag "github.com/glycerine/g3/pkg/util/diagnostic"\nunumeral "')
  key='return m.ArithmeticNumeral(&value, integer)' if v!='before-copy'else'if err = service.Manager.Copy(&value.Raw, r);'
  i=s.index(key,s.index('func (m *ASTManager) ArithmeticNumeralFromRational('))
  guard='''if !astValidateHandles && !udiag.TraceCompiled() && m.TraceStream==nil && m.lockFree() && !m.BudgetField.InjectionArmed() && !service.RuntimeOwner().AllocationLimited(){
   if n,ok:=SOURCE.SmallInt32();ok && uint32(n)<16{
    p:=m.arithmeticPlugin
    if p!=nil && p.published && !p.numeral.active && service.Manager.CheckOwnerReady()==nil{
     bank:=1;if integer && !p.convertIntNumerals{bank=0}
     if uint32(n)<uint32(len(p.small[bank])){if h:=p.small[bank][n];h.slot!=0{return m.external(h),nil}}
    }
   }}
  '''.replace('SOURCE','r'if v=='before-copy'else'value.Raw')
  es[fac]=s[:i]+guard+s[i:]
 if v in ('scalar','both'):
  s=q.read_text();i=s.index('if integer && !zero {');j=s.index('which, sortIndex, flag',i);original=once(s[i:j],'u, cached := uint32(0), zero','')
  s=s[:i]+'''u,cached:=uint32(0),zero;inline:=false
  if !zero && value!=nil && !astValidateHandles{if v,ok:=value.Raw.SmallInt32();ok{
   integral,e:=m.numerals.IsInt(value);if e!=nil{return result,e};if integral{u=uint32(v);cached=u<16;inline=true}
  }}
  if !inline{'''+original+'}\n'+s[j:];es[q]=s
 return es
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edit(v));b=od/'ast.test'
 with(w/'build.lock').open('a')as lk,(od/'focused.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-p','4','-pgo=off','-overlay='+str(o),'-o',b,'./ast'],cwd=pkg,stdout=log,stderr=log);run([b,'-test.run','ASTArithmetic|Arithmetic.*Numeral|ArithmeticIntegral|NumeralOwner','-test.count=1'],cwd=pkg/'ast',stdout=log,stderr=log)
 return b,build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def main():
 vs=['control','before-copy','after-copy','scalar','both']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 gl.d=d;th.d=d;old.d=d;bb={v:b[1]for v,b in bs.items()};ss={v:b[2]for v,b in bs.items()}|{'native':pkg.parent/'build/z3'}
 ns=d/'models';ns.mkdir(exist_ok=True);shape.d=ns;shape.bs=ss
 names=['ordinary','tlb','rfn2','toy-consensus','cf_live'];js=[(c,*j[1:5],3,j[-1])for c,j in zip([0,2,3,6,8],(j for j in mi.jobs()if j[1]in names))]
 with ThreadPoolExecutor(19)as ex:
  fs=[ex.submit(gl.measure_job,j,bb) for j in js]+[ex.submit(th.replay,(c,n,ss))for c,n in [(25,'toy-consensus-18'),(27,'aux-012725'),(29,'aux-017026')]]+[ex.submit(old.micro,{v:b[0]for v,b in bs.items()})]+[ex.submit(shape.lane,(c,shape.cases[i::4]))for i,c in enumerate([4,5,10,11])]+[ex.submit(shape.validate,v)for v in vs]
  for f in fs:f.result()
if __name__=='__main__':main()
