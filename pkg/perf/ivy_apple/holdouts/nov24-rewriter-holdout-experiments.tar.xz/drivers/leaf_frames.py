from study import *
import guarded_live as gl,macro_identity as mi,theory_traversal_steps as th
d=w/'leaf-frames';d.mkdir(exist_ok=True);e=pkg/'ast/rewriter/rewriter_engine.go';q=e.with_name('th_rewriter.go');bv=e.with_name('maximize_ac_sharing.go');src=e.with_name('leaf_fast_trial.go')
helper='''package rewriter
import("github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/util/diagnostic")
func(r *rewriterEngine)trialCanProbeLeaves()bool{
 m:=r.core.manager
 return !r.core.proofGen && !ast.ASTValidateHandles && !ast.ASTSourceDebug && !diagnostic.TraceCompiled() && m.TraceStream==nil && !m.Budget().InjectionArmed() && !m.NumeralService().RuntimeOwner().AllocationLimited()
}
func(r *rewriterEngine)trialTerminal(h ast.ASTHandle,bv bool)bool{
 m:=r.core.manager;hd,e:=m.NodeHeader(h);if e!=nil{return false}
 if hd.Kind==ast.ASTVar{
  if len(r.bindings)==0{return true};idx,e:=m.GetVarIndex(h);return e==nil && (idx>=uint32(len(r.bindings)) || r.bindings[len(r.bindings)-1-int(idx)].IsNull())
 };return hd.Kind==ast.ASTApp && hd.NumArgs==0 && (bv || hd.Family==ast.NullFamilyID)
}
func(r *rewriterEngine)trialIdentityFrame(fr rewriterFrame)bool{
 if fr.state()!=0 || fr.index()!=0 || fr.newChild() || fr.numArgs>2{return false};m:=r.core.manager
 bv:=r.trialFrame==2
 if !bv{a,f,_,e:=m.AppIdentity(fr.curr);if e!=nil || !a || f!=ast.NullFamilyID{return false}}
 for j:=uint32(0);j<fr.numArgs;j++{child,e:=m.GetArg(fr.curr,j);if e!=nil || !r.trialTerminal(child,bv){return false}}
 return true
}
'''
def ed(v):
 if v=='control':return {}
 s=e.read_text();t=q.read_text();u=bv.read_text();s=once(s,'modelBooleanShortCircuit bool','modelBooleanShortCircuit bool\ntrialNoSub bool\ntrialFrame uint8\ntrialChildren bool')
 if v in ('empty','both','all','theory','children'):
  x='return r.traversal.Rewrite(term, out)'
  s1='''eng:=&r.traversal.engine;if eng.trialCanProbeLeaves(){c:=&r.configuration;empty:=!c.hasSubstitution;if !empty{empty,_=r.manager.ExprSubstitutionEmpty(c.substitution)};if empty{
   eng.trialNoSub=true;eng.trialFrame=FRAME;eng.trialChildren=CHILD
   defer func(){eng.trialNoSub=false;eng.trialFrame=0;eng.trialChildren=false}()
  }}\n'''.replace('FRAME','1'if v in ('theory','both','all')else'0').replace('CHILD',str(v in ('children','all')).lower())
  t=t.replace(x,s1+x,1)
 if v in ('bv','both','all'):
  x='if e := r.traversal.Rewrite(root, out); e != nil {'
  u=once(u,x,'''eng:=&r.traversal.engine;if eng.trialCanProbeLeaves(){eng.trialFrame=2;eng.trialChildren=CHILD;defer func(){eng.trialFrame=0;eng.trialChildren=false}()}
  '''.replace('CHILD',str(v=='all').lower())+x)
 if v in ('empty','all','children'):
  x='sub, subProof, found, e := r.cfg.GetSubst(t)';s=once(s,x,'''var sub,subProof ast.ASTHandle;var found bool;var e error
  if !r.trialNoSub{sub,subProof,found,e=r.cfg.GetSubst(t)}''')
 if v!='empty':
  i=s.index('switch fr.state()',s.index('func (r *rewriterEngine) processApp()'))
  s=s[:i]+'''if r.trialFrame!=0 && r.trialIdentityFrame(fr){if e:=m.SetRefHeld(r.r,t);e!=nil{return e};return r.finish(fr,false,true)}
  '''+s[i:]
 if v in ('children','all'):
  i=s.index('done, e := r.visit(arg, fr.maxDepth())',s.index('func (r *rewriterEngine) processApp()'))
  s=s[:i]+'''if r.trialChildren && r.trialTerminal(arg,r.trialFrame==2){if e:=appendRewriterRoot(m,&c.results,arg);e!=nil{return e};continue}
  '''+s[i:]
 return {e:s,q:t,bv:u,src:helper}
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',ed(v))
 with(w/'build.lock').open('a')as f,(od/'focused.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-overlay='+str(o),'-run','TheoryRewriter|Rewriter.*Fold|MaximizeBVSharing|SMTAsserted|ExprSubstitution','-count=1','./ast/rewriter','./smtcore','./ast'],cwd=pkg,stdout=log,stderr=log)
 return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def main():
 vs=['control','empty','bv','theory','both','children','all']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 gl.d=d;th.d=d;bb={v:b[0]for v,b in bs.items()};ss={v:b[1]for v,b in bs.items()}|{'native':pkg.parent/'build/z3'}
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([0,2,3,6,8,9,10,11,12],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(14)as ex:
  fs=[ex.submit(gl.measure_job,j,bb)for j in js]+[ex.submit(th.replay,(c,n,ss))for c,n in [(25,'toy-consensus-18'),(27,'ticket-127'),(29,'ticket-290'),(31,'aux-012725')]]
  for f in fs:f.result()
if __name__=='__main__':main()
