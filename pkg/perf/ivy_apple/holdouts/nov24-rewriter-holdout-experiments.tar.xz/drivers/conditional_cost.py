from study import *
import corpus_phases as cp,conditional_datatypes as cd,macro_identity as mi
d=w/'conditional-cost';d.mkdir(exist_ok=True);cp.root=d
q=ivy.resolve()/'z3bridge_solver_model.go'
base={Path(n).resolve():Path(f).read_text()for n,f in json.loads(cp.instrumentation().read_text())['Replace'].items()}
def build_one(v):
 ed=cd.ed(v) if v not in ('native','control')else {}
 probes=base.copy()
 if q in ed:
  s=(w/'conditional-datatypes'/v/'overlay'/q.name).read_text();ax=s.index('newSolver := s.tr.Ctx.NewZ3Solver',s.index('func (s *Solver) GetSmallModelWithCond('));bx=s.index('s.applyZ3SolverOptions(z3solver)',ax)+len('s.applyZ3SolverOptions(z3solver)')
  probes[q]=once(probes[q],'z3solver := s.newZ3Solver()\n\tobs.put(t, "new", 0)',s[ax:bx]+'\n\tobs.put(t, "new", 0)')
 od=d/v;o=overlay(od/'overlay',ed|probes)
 return build(od/'checker','native'if v=='native'else'g3',o)
def lane(j,bs):
 c,n,sp,iso,rc,_,ref=j;od=d/n;od.mkdir(exist_ok=True);vs=list(bs)
 for i in range(3):
  for v in vs[i:]+vs[:i]:
   sd=od/f'{i+1}-{v}';sd.mkdir(exist_ok=True);r=subprocess.run(['taskset','-c',str(c),bs[v],*(['isolate='+iso] if iso else []),examples/sp],cwd=sd,env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True)
   other=bytearray()
   with gzip.open(sd/'phases.csv.gz','wt')as f:
    z=csv.writer(f);z.writerow('batch condition stage result instructions'.split())
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'VC-PHASE '):z.writerow(l.decode().split()[1:])
     else:other.extend(l)
   assert r.returncode==rc and (r.stdout,other)==tuple((ref/k).read_bytes()for k in ['stdout','stderr']);print(n,i+1,v,flush=True)
vs=['control','data256','native']
with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(build_one,vs)))
js=[(c,*j[1:])for c,j in zip([22,24,26],(j for j in mi.jobs()if j[1]in ('ordinary','tlb','raft_no_assume_test')))]
with ThreadPoolExecutor(3)as ex:list(ex.map(lambda j:lane(j,bs),js))
