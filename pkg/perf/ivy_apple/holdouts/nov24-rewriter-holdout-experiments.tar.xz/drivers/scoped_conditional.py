from study import *
import guarded_live as gl,setup_panels as pa,ground_release_controls as gc
from panel import CASES
d=w/'scoped-conditional';d.mkdir(exist_ok=True)
def edits(v):
 if v=='control':return{}
 k=pkg/'smtcore/smt_kernel.go';s=pkg/'smtcore/smt_solver.go';a=pkg/'smtcore/smt_asserted_formulas.go';rw=pkg/'ast/rewriter/th_rewriter.go';b=pkg/'ast/rewriter/bool_rewriter.go';ite=pkg/'ast/rewriter/bool_rewriter_ite.go';factory=pkg/'tactic/portfolio/strategic_solver_factory.go'
 ed={};ed[b]=once(b.read_text(),'type boolRewriter struct {','type boolRewriter struct {\n factorNestedITE bool')
 src=ite.read_text();assert src.count('&& rw.iteExtraRules')==2;ed[ite]=src.replace('&& rw.iteExtraRules','&& (rw.iteExtraRules || rw.factorNestedITE)')
 s1=rw.read_text();old='// FreshDefault realizes';s1=once(s1,old,'''// RewriteScopedGoal also factors nested conditionals that share branches.
 // The incremental verification strategy uses it for temporary assertions.
 func(r *TheoryRewriter)RewriteScopedGoal(term ast.ASTHandle,out ast.ASTRef)error{
  if err:=r.open();err!=nil{return err}
  b:=r.configuration.boolean
  old:=b.factorNestedITE;b.factorNestedITE=true
  defer func(){b.factorNestedITE=old}()
  return r.traversal.Rewrite(term,out)
 }
 
 '''+old);ed[rw]=s1
 ed[k]=once(k.read_text(),'simplifyInitialPushOnce   bool','simplifyInitialPushOnce   bool\n factorScopedConditionals bool')
 code=s.read_text();x='SimplifyInitialPushOnce bool';code=once(code,x,x+'''
 // FactorScopedConditionals enables shared-branch ITE rewrites for scoped
 // assertions in verification batches.
 FactorScopedConditionals bool''');x='kernel.simplifyInitialPushOnce = config.SimplifyInitialPushOnce';ed[s]=once(code,x,x+'\nkernel.factorScopedConditionals=config.FactorScopedConditionals')
 x='config.SimplifyInitialPushOnce = true';ed[factory]=once(factory.read_text(),x,x+'\n config.FactorScopedConditionals=true')
 code=a.read_text()
 x='err = k.preprocessor.RewriteWithProof(formula, resultRef, proofRef)\n\t} else {'
 guard='!proofs && k.factorScopedConditionals && len(k.scopes)>0'
 if v not in ('raw','raw-collect'):
  guard+=' && !ast.ASTSourceDebug && !diagnostic.TraceCompiled() && k.manager.TraceStream==nil && !k.manager.Budget().InjectionArmed() && !k.manager.NumeralService().RuntimeOwner().AllocationLimited() && !k.manager.ResourceLimit().CancelFlag() && k.smtState.MaxConflicts==^uint32(0)'
  code=once(code,'import (','import (\n "github.com/glycerine/g3/pkg/util/diagnostic"')
  if v!='without-limit':guard+=' && k.manager.ResourceLimit().Limit==0'
 if v=='submit':guard+=' && mode==assertedProofAssertExpr'
 if v=='reduce':guard+=' && mode!=assertedProofAssertExpr'
 if v=='simplifier':guard+=' && mode==assertedProofSimplify'
 new='err = k.preprocessor.RewriteWithProof(formula, resultRef, proofRef)\n} else if '+guard+' {err=k.preprocessor.RewriteScopedGoal(formula,resultRef)\n} else {'
 ed[a]=once(code,x,new)
 return ed
def mk(v):
 od=d/v;o=overlay(od/'overlay',edits(v));return build(od/'checker',o=o)
def main():
 vs=['control','raw','guarded','without-limit','submit','reduce','simplifier']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d
 js=[(4,'ordinary','jea/hermes_rmw_o3.ivy','',0,3,w/'guarded-live/ordinary-11/1-native')]
 for c,n in zip([0,1,2,3,6,7,8,9,10,12,14],['tlb','toy-consensus','rfn2','flash2','dramc_nb2','raftok','raft_no_assume_test','hybrid_reliable_broadcast_cisa','cf_live','raft_no_assume','ticket']):
  sp,iso,_,f,u=CASES[n];js.append((c,n,sp,iso,int(bool(f or u)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(len(js)+3)as e:
  fs=[e.submit(gl.measure_job,j,bs)for j in js]
  for c,n,sp,rf in [(19,'full-hermes','jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native'),(22,'full-apple','doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native')]:
   fs.append(e.submit(gl.measure_job,(c,n,sp,'',0,3,rf),{v:bs[v]for v in ['control','guarded','raw']}))
  gc.d=d;fs.append(e.submit(gc.corpus,bs['guarded']))
  for f in fs:f.result()
if __name__=='__main__':main()
