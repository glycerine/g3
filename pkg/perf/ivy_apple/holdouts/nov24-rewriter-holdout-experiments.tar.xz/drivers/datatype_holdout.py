from study import *
import ground_release_controls as gc, guarded_live as gl, verification_frontier as vf
d=w/'conditional-datatype-controls';d.mkdir(exist_ok=True);gc.d=d;gl.d=d
bs={v:w/'conditional-datatypes'/v/'checker/goivy_check' for v in ('control','data256')}
bs['native']=w/'frontend-owned-production/after-native/goivy_check'
js=[(38,'testing','jea/hermes_rmw_o3_testing.ivy','',0,2,w/'extended-phases/long/1/1/native'),(40,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native')]
quiet=[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',bs['data256'],'--previous',bs['control'],'--native',bs['native'],'--rounds','5','--max-attempts','20','--min-idle','.95','--wait-seconds','600','--cpu','35','--spec',examples/'jea/hermes_rmw_o3.ivy','--reference',vf.reference('jea/hermes_rmw_o3.ivy'),'--perf',perf,'--output',d/'ordinary-quiet']
with ThreadPoolExecutor(4)as ex:
 fs=[ex.submit(gc.corpus,bs['data256']),ex.submit(run,quiet,stdout=subprocess.DEVNULL)]+[ex.submit(gl.measure_job,j,bs)for j in js]
 for f in fs:f.result()
