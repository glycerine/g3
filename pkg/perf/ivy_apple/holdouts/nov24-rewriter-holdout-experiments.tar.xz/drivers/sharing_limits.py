from study import *
import sharing_identity as sh,macro_identity as mi,guarded_live as gl
d=w/'sharing-limits';d.mkdir(exist_ok=True)
def ed(v):
 if v=='control':return {}
 es=sh.ed('large')
 if v=='raw':return es
 x='if r.trialEligible() && r.trialNeutral(root,0)'
 z='r.manager.ResourceLimit().Limit==0 && !r.manager.ResourceLimit().CancelFlag()'
 if v=='nofuel':z+=' && r.manager.Budget().Limit()==^uint64(0)'
 es[sh.q]=once(es[sh.q],x,'if '+z+' && r.trialEligible() && r.trialNeutral(root,0)')
 return es
def mk(v):
 od=d/v;o=overlay(od/'overlay',ed(v));b=build(od/'checker',o=o);info=run(['go','version','-m',b],capture_output=True,text=True).stdout;assert '=>\t/home/jaten/g3/pkg\t(devel)'in info;(od/'build-info.txt').write_text(info);return b
gl.d=d;vs=['control','raw','unlimited','nofuel']
with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
js=[(c,*j[1:5],3,j[-1])for c,j in zip([1,3,11,13,15,17],(j for j in mi.jobs()if j[1]in ('tlb','ordinary','toy-consensus','hybrid_reliable_broadcast_cisa','raftok','raft_no_assume_test')))]
with ThreadPoolExecutor(6)as ex:list(ex.map(lambda j:gl.measure_job(j,bs),js))
