from study import *
import arithmetic_bounds as ab,theory_traversal_steps as th,guarded_live as gl,macro_identity as mi
from collections import Counter
d=w/'bound-shapes';d.mkdir(exist_ok=True)
def edit(v):
 if v=='control':return {}
 if v=='audit':
  s=ab.ed('audit')[ab.q];s=s.replace('m.Budget().Limit()!=^uint64(0) || ','')
  i=s.index('func(r *ArithRewriter)trialAtomicBound')
  s=s[:i]+'''func(r *ArithRewriter)trialReportBound(lhs,rhs ast.ASTHandle,eq bool,st RewriteStatus,err error,initial uint64,same bool){
   m:=r.manager;a,_:=m.NodeHeader(lhs);b,_:=m.NodeHeader(rhs);first:=int32(-99);fold:=int32(-99);if a.Kind==ast.ASTApp && a.NumArgs>0{h,_:=m.GetArg(lhs,0);n,_:=m.NodeHeader(h);first=n.DeclKind;if n.NumArgs>0{h,_=m.GetArg(h,0);if c,ok,_:=m.ArithmeticIntegralInt32(h);ok{fold=c}}}
   _,num,_:=m.ArithmeticIntegralInt32(rhs);aa,_:=m.GetSort(lhs);bb,_:=m.GetSort(rhs);v,ok:=r.manager.ArithmeticIntegralInt32(rhs);_=v;_=ok
   fmt.Fprintln(os.Stderr,"BOUND-MORPH",eq,a.Kind,a.Family,a.DeclKind,a.NumArgs,first,fold,b.Kind,b.Family,b.DeclKind,b.NumArgs,num,aa==bb,m.Budget().Limit(),m.NumeralService().RuntimeOwner().AllocationLimited(),int(st),err==nil,initial==m.ResourceLimit().Count(),same)
  }
  '''.replace('v,ok:=r.manager.ArithmeticIntegralInt32(rhs);_=v;_=ok','')+s[i:]
  for eq in ['true','false']:
   i=s.index('if hit:=r.trialAtomicBound(left,right,12);hit{' if eq=='false' else 'if hit:=r.trialAtomicBound(left,right,12);hit{',0 if eq=='false' else s.index('func (r *ArithRewriter) MkEqCore'))
   j=s.index('newLeft, newRight, powerChanged, err :=',i)
   s=s[:i]+'''before:=r.manager.ResourceLimit().Count();hit:=r.trialAtomicBound(left,right,12);defer func(){r.trialReportBound(left,right,'''+eq+''',status,err,before,hit)}()
   '''+s[j:]
  return {ab.q:s}
 s=ab.ed('sum')[ab.q]
 s=s.replace('m.Budget().Limit()!=^uint64(0) || ',('m.Budget().Limit()-m.Budget().Used()<1<<20 || ' if v=='headroom'else''))
 if v=='broad':s=s.replace('h.Family==ast.NullFamilyID','h.Family!=r.family && h.Family!=m.BasicFamilyID()')
 return {ab.q:s}
def job(v):
 od=d/v;o=overlay(od/'overlay',edit(v));return build(od/'shell',o=o,shell=True),build(od/'checker',o=o)
def census(pair):
 cpu,q,b=pair;od=d/'audit'/q;od.mkdir();payload=th.warm.script(q,12,False);(od/'input.smt2').write_text(payload);ct=Counter()
 with (od/'input.smt2').open('rb')as inp,(od/'stdout').open('wb')as out,subprocess.Popen(['taskset','-c',str(cpu),b,'-in','-smt2'],cwd=od,stdin=inp,stdout=out,stderr=subprocess.PIPE,env=dict(env,GOMAXPROCS='1'))as p:
  for l in p.stderr:
   assert l.startswith(b'BOUND-MORPH '),l[:150];ct[tuple(l.decode().split()[1:])]+=1
  assert not p.wait()
 assert (od/'stdout').read_text().split()==[th.warm.NUMERIC_ANSWERS.get(q,'unsat')]*12
 with(od/'shapes.csv').open('w')as f:
  z=csv.writer(f);z.writerow('eq left_kind left_family left_op left_arity first_op coefficient right_kind right_family right_op right_arity numeral same_sort budget allocation_limited status clean same_steps eligible calls'.split());z.writerows([*k,v]for k,v in ct.items())
def main():
 vs=['control','headroom','shapes','broad','audit']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(job,vs)))
 a,_=bs.pop('audit');gl.d=d;th.d=d;ss={v:b[0]for v,b in bs.items()}|{'native':pkg.parent/'build/z3'};bb={v:b[1]for v,b in bs.items()};qs=['toy-consensus-18','aux-012725','aux-017026','aux-011440']
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([0,2,3,6],(j for j in mi.jobs()if j[1]in ('tlb','ordinary','toy-consensus','hybrid_reliable_broadcast_cisa')))]
 with ThreadPoolExecutor(12)as ex:
  fs=[ex.submit(census,(c,n,a))for c,n in zip([25,26,27,29],qs)]+[ex.submit(th.replay,(c,n,ss))for c,n in zip([30,31,32,33],qs)]+[ex.submit(gl.measure_job,j,bb)for j in js]
  for f in fs:f.result()
if __name__=='__main__':main()
