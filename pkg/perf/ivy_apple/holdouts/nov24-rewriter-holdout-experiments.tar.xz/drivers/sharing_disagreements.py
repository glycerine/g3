from study import *
import sharing_identity as si,macro_identity as mi
d=w/'sharing-disagreements';d.mkdir(exist_ok=True)
ed=si.ed('audit');s=ed[si.q];s=once(s,'"fmt";"os"','"fmt";"os";"bytes"')
s=once(s,'fmt.Fprintln(os.Stderr,"BV-CENSUS"','''if predicted && root!=outH{pp,e:=ast.NewLegacySMTPrinter(r.manager);if e!=nil{panic(e)};var a,b bytes.Buffer;if e=pp.DisplayExpr(&a,root,nil);e!=nil{panic(e)};if e=pp.DisplayExpr(&b,outH,nil);e!=nil{panic(e)};fmt.Fprintf(os.Stderr,"BV-DIFF %q %q\\n",a.String(),b.String())};fmt.Fprintln(os.Stderr,"BV-CENSUS"''')
s=once(s,'ast.ASTRef) error {\n\tif e := r.open();','ast.ASTRef) (trialError error) {\n\tif e := r.open();').replace('if e=pp.DisplayExpr(&b,outH,nil);e!=nil{panic(e)}','if outH.IsNull(){b.WriteString("<null>")}else if e=pp.DisplayExpr(&b,outH,nil);e!=nil{fmt.Fprintf(&b,"<print: %v>",e)}').replace('a.String(),b.String())','a.String(),fmt.Sprintf("%s, return=%v, limit=%v",b.String(),trialError,r.manager.ResourceLimit().Limit))')
ed[si.q]=s;o=overlay(d/'overlay',ed);b=build(d/'checker',o=o)
def lane(j):
 c,n,sp,iso,rc,_,ref=j;od=d/n;od.mkdir(exist_ok=True)
 r=subprocess.run(['taskset','-c',str(20+c),b,*(['isolate='+iso]if iso else []),examples/sp],cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1'))
 other=bytearray()
 with(od/'examples.txt').open('wb')as f:
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'BV-DIFF '):f.write(l)
   elif not l.startswith(b'BV-CENSUS '):other.extend(l)
 assert r.returncode==rc and (r.stdout,other)==tuple((ref/v).read_bytes()for v in ['stdout','stderr'])
with ThreadPoolExecutor(4)as ex:list(ex.map(lane,(j for j in mi.jobs()if j[1]in ('tlb','dramc_nb2','ordinary','toy-consensus'))))
