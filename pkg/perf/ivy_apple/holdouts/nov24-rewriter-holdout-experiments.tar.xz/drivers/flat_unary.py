from study import *
import macro_identity as mi,guarded_live as gl,pattern_pairs as pairs,flat_pattern_collect as fc
d=w/'flat-unary';d.mkdir(exist_ok=True);q=pairs.q;f=q.with_name('flat_unary_trial.go')
helper='''package pattern
import ("github.com/glycerine/g3/pkg/ast";"math/bits")
type inferredFlat struct{terms [8]ast.ASTHandle; heads [8]ast.ASTHandle; bijective [8]bool; num int; fuel int; seen [32]ast.ASTHandle; nseen int}
func(t *inferredFlat)visit(c *patternCandidates,h ast.ASTHandle,mask uint64)bool{
 if t.fuel<=0{return false};t.fuel--
 m:=c.manager;ground,err:=m.IsGround(h);if err!=nil{return false};if ground{return true}
 hd,err:=m.NodeHeader(h);if err!=nil{return false};if hd.Kind==ast.ASTVar{return true};if hd.Kind!=ast.ASTApp{return false}
 if CACHE && hd.RefCount>1{for _,n:=range t.seen[:t.nseen]{if n==h{return true}};if t.nseen<len(t.seen){t.seen[t.nseen]=h;t.nseen++}}
 if hd.Family==m.BasicFamilyID(){for j:=uint32(0);j<hd.NumArgs;j++{a,e:=m.GetArg(h,j);if e!=nil || !t.visit(c,a,mask){return false}};return true}
 if hd.Family!=ast.NullFamilyID || hd.NumArgs>32{return false}
 var vars uint64
 for j:=uint32(0);j<hd.NumArgs;j++{a,e:=m.GetArg(h,j);if e!=nil{return false};ah,e:=m.NodeHeader(a);if e!=nil{return false}
  if ah.Kind!=ast.ASTVar{ground,e:=m.IsGround(a);if e!=nil||!ground{return false};continue}
  v,e:=m.GetVarIndex(a);if e!=nil || v>=c.numBindings{return false};vars|=uint64(1)<<v}
 excluded,e:=c.forbiddenApp(h);if e!=nil{return false};if excluded || vars==0{return true}
 if vars!=mask{return false}
 simple:=bits.OnesCount64(vars)==int(hd.NumArgs)
 for i,n:=range t.terms[:t.num]{if n==h{return true};if c.blockLoops && t.heads[i]==hd.Decl && (!simple || !t.bijective[i]){return false}}
 if t.num==len(t.terms){return false};t.terms[t.num]=h;t.heads[t.num]=hd.Decl;t.bijective[t.num]=simple;t.num++;return true
}
func(t *inferredFlat)emit(c *patternCandidates)(out []ast.ASTRef,err error){
 for i:=0;i<t.num;i++{h,e:=c.manager.MkFamilyApp(2,0,nil,t.terms[i:i+1]);if e!=nil{return out,e};ref,e:=c.manager.NewRef(h);if e!=nil{return out,e};out=append(out,ref)};return out,nil}
'''
def ed(v):
 if v=='control':return {}
 s=q.read_text();insert='import ("github.com/glycerine/g3/pkg/util/diagnostic"'+(';"fmt";"os"' if v=='audit'else'')+';"github.com/glycerine/g3/pkg/ast")';s=once(s,'import "github.com/glycerine/g3/pkg/ast"',insert)if 'import "'in s else once(s,'import (','import (\n"github.com/glycerine/g3/pkg/util/diagnostic"'+(';"fmt";"os"' if v=='audit'else''))
 x='if err = c.collect(body);';act='return trial.emit(c)'
 if v=='audit':act='''defer func(){if err!=nil{return};if len(patterns)!=trial.num{panic("wrong flat count")};for i,ref:=range patterns{p,e:=c.manager.RefGet(ref);if e!=nil{panic(e)};n,e:=c.manager.GetNumArgs(p);if e!=nil||n!=1{panic("wrong flat width")};a,e:=c.manager.GetArg(p,0);if e!=nil||a!=trial.terms[i]{panic("wrong flat element")}};fmt.Fprintln(os.Stderr,"PAIR-PRED",trial.num)}()'''
 y='''if GUARD && c.numBindings>0 && len(c.preferred)==0 && len(noPatterns)==0 {
 if alive,e:=c.manager.GetRefCount(body);e==nil && alive>0{trial:=inferredFlat{fuel:64};if trial.visit(c,body,(uint64(1)<<c.numBindings)-1){ACTION}}}'''.replace('GUARD',fc.guard).replace('ACTION',act)
 if v=='audit':y='defer func(){fmt.Fprintln(os.Stderr,"PAIR-ALL")}()\n'+y
 return {q:once(s,x,y+'\n'+x),f:helper.replace('CACHE',str(v=='cached').lower())}
def mk(v):
 od=d/v;o=overlay(od/'overlay',ed(v))
 with(w/'build.lock').open('a')as lk,(od/'focused.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-count=1','-p','4','-overlay='+str(o),'./ast/pattern'],cwd=pkg,stdout=log,stderr=log)
 return build(od/'checker',o=o)
def main():
 vs=['control','simple','cached','audit']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 a=bs.pop('audit');gl.d=d;pairs.d=d
 js=[(c,*j[1:5],4,j[-1])for c,j in zip([4,6,8,10,12,14,16,18,20],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(11)as ex:
  fs=[ex.submit(gl.measure_job,j,bs)for j in js]
  for j in mi.jobs():pairs.audit(j,a)
  for x in fs:x.result()
if __name__=='__main__':main()
