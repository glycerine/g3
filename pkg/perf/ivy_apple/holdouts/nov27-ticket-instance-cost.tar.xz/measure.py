"""Join actual rewrite/assert events to the guarded lemmas in the matched Ticket trace."""
import argparse, collections, csv, json, os, re, statistics, subprocess
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('golden',type=Path)
p.add_argument('examples',type=Path)
p.add_argument('trace',type=Path)
p.add_argument('--rounds',type=int,default=5)
p.add_argument('--cpu',default='14')
args=p.parse_args()
w=Path(__file__).resolve().parent
ref=args.golden/'reference/ticket_protocol'
spec,_,code=json.loads((args.golden/'cases.json').read_text())['ticket_protocol']
env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(args.examples/'ivy/include'))
def guards(path):
    out=[]
    with path.open() as f:
        for r in csv.DictReader(f):
            if (r['batch'],r['goal'],r['event'])!=('7','1','formula'):continue
            s=r['value']
            assert s.startswith('(or (not (forall ')
            start=len('(or (not ')
            d=0
            for i in range(start,len(s)):
                d+=(s[i]=='(')-(s[i]==')')
                if not d:break
            out.append(s[start:i+1])
    return out

with (w/'cost.csv').open('w') as f:
    out=csv.writer(f)
    out.writerow(['round','solver','instance','guard_id','unchanged','true','rewrite','assert'])
    for rnd in range(args.rounds):
        order=['ordinary','native']
        for label in order[::1 if rnd%2==0 else -1]:
            gs=guards(args.trace/(label+'-events.csv'))
            ids={q:i+1 for i,q in enumerate(dict.fromkeys(gs))}
            (w/('guards-'+label+'.json')).write_text(json.dumps(list(ids),indent=1))
            run=subprocess.run(['taskset','-c',args.cpu,w/label,args.examples/spec],cwd=w,env=env,capture_output=True,timeout=120)
            extra=bytearray()
            events=[]
            found=0
            for line in run.stderr.splitlines(keepends=True):
                if line.startswith(b'QI '):events.append(line.decode().split()[1:])
                elif line.startswith(b'STAGE-COUNT '):
                    _,b,g,phase,*_=line.decode().split()
                    if (b,g,phase)==('7','1','check'):
                        j=i=0
                        while events:
                            typ,ins,unchanged,reduced=events.pop(0)
                            assert typ=='rewrite'
                            ai,qid=0,0
                            if reduced=='false':
                                op,ai=events.pop(0)
                                assert op=='assert'
                                qid=ids[gs[j]]
                                j+=1
                            out.writerow([rnd,label,i,qid,unchanged,reduced,ins,ai])
                            i+=1
                        assert j==len(gs)==820
                        found+=1
                    events.clear()
                else:extra.extend(line)
            assert (found,run.returncode,run.stdout,bytes(extra))==(1,code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(label,run.returncode,extra[:320])
            print(label,rnd,i,j,flush=True)
            f.flush()
