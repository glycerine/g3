# Per-instance Ticket instruction costs and substitution experiment

Use solver source at 432a0ee8b. Extract into external scratch. Run the commands from g3/pkg with W set to the extracted directory, FRONT to the pinned GoIvy 77f7733de tree, MOD to its Go module file using the local solver, GOLD to the Ticket golden directory (cases.json and reference/), and EXAMPLES to the Ivy examples repository. The native control needs the built C++ tree from this fork and the matching static library at FRONT/z3vendor/native_lib/libz3.a. The Linux hardware counter must be accessible. Use the same path spelling for EXAMPLES as the golden transcripts.

    python3 "$W/setup.py" "$FRONT"
    python3 "$W/build.py" ordinary "$W/ordinary-base.json" "$MOD"
    python3 "$W/build.py" native "$W/native-base.json" "$MOD"
    python3 "$W/measure.py" "$GOLD" "$EXAMPLES" "$W"
    python3 "$W/analyze.py"
    python3 "$W/trees.py" "$GOLD" "$EXAMPLES" "$MOD" "$W/tree-printer.fragment"
    python3 "$W/maps.py" "$GOLD" "$EXAMPLES" "$MOD" "$W/tree-printer.fragment"
    python3 "$W/cache_maps.py" "$GOLD" "$EXAMPLES" "$MOD" "$W/tree-printer.fragment"
    python3 "$W/fusion.py"
    python3 "$W/mapped_fusion.py"
    python3 "$W/cache_fusion.py"
    python3 "$W/origins.py"
    python3 "$W/bindings.py"
    python3 "$W/valid_shape.py" "$FRONT" "$MOD"

The ordinary and native event CSVs are the three ordered check traces from the previous study. Each asserted formula starts with its negated quantifier, which supplies the per-assertion guard identity. Guard IDs in ranking.csv are one-based indices into the corresponding ordered guard JSON. Instance IDs in bindings.csv and cost.csv are zero-based. The replay programs operate offline on actual solver ASTs. Their coverage assumes the recorded lookups are available for free. Use replays.py and verify.py with pinned cores and equal build flags to measure the separate uninstrumented shape trial. The complete verifier CSVs compare stock and trial with normal GC. equal-flags.csv uses disabled GC for incremental CLI replays.
