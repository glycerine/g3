import json,sys
from pathlib import Path
w=Path(__file__).resolve().parent
front=Path(sys.argv[1]).resolve()
for b in ['native','ordinary']:
    files={str(front/'z3bridge_solver_model.go'):str(w/(b+'-bridge.go.txt')),
           str(front/'phase_observer_trial.go'):str(w/'stage.go.txt')}
    (w/(b+'-base.json')).write_text(json.dumps({'Replace':files}))
