"""Replay a context-free Boolean simplifier bottom up on exact solver inputs."""
import collections,csv,json,re
from pathlib import Path
w=Path(__file__).resolve().parent

def parse(s):
    stack=[[]]
    for word in re.findall(r'\(|\)|[^()\s]+',s):
        if word=='(':stack.append([])
        elif word==')':
            x=tuple(stack.pop());stack[-1].append(x)
        else:stack[-1].append(word)
    assert len(stack)==1 and len(stack[0])==1
    return stack[0][0]

T=('true',)
F=('false',)
def neg(arg):
    if arg==F:return T
    if arg==T:return F
    if arg[0]=='not':return arg[1]
    return ('not',arg)

def fold(term):
    if term in mapping:return mapping[term]
    op,*args=term
    args=list(map(fold,args))
    if op=='not':return neg(args[0])
    if op=='=':
        a,b=args
        if a==b:return T
        if a==T:return b
        if b==T:return a
        if a==F:return neg(b)
        if b==F:return neg(a)
    if op=='if':
        c,a,b=args
        if c==T or a==b:return a
        if c==F:return b
        if a==T and b==F:return c
        if a==F and b==T:return neg(c)
        if a==T:return ('or',c,b)
        if b==T:return ('or',neg(c),a)
    if op in ('and','or'):
        stop,unit=(T,F) if op=='or' else (F,T)
        seen=set()
        out=[]
        for a in args:
            if a==stop or neg(a) in seen:return stop
            if a in seen or a==unit:continue
            seen.add(a);out.append(a)
        if not out:return unit
        if len(out)==1:return out[0]
        args=out
    return (op,*args)

guards=json.loads((w/'guards-ordinary.json').read_text())
costs=[r for r in csv.DictReader((w/'cost.csv').open()) if r['round']=='0' and r['solver']=='ordinary']
trees=list(csv.DictReader((w/'maps.csv').open()))
other=[r for r in csv.DictReader((w/'cost.csv').open()) if r['round']=='0' and r['solver']=='native']
assert len(trees)==len(costs)==len(other)==820
buckets=collections.Counter()
with (w/'mapped-fusion.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['instance','guard','changed','exact','differs_from_raw','rewrite_g','rewrite_z'])
    for i,(r,c,z) in enumerate(zip(trees,costs,other,strict=True)):
        q=guards.index(r['quantifier'])+1
        assert int(c['guard_id'])==int(z['guard_id'])==q
        raw,result=map(parse,(r['raw'],r['result']))
        assert (raw==result)==(c['unchanged']=='true')==(z['unchanged']=='true')
        mapping={parse(k):parse(v) for k,v in json.loads(r["hits"])}
        trial=fold(raw)
        key=(raw!=result,trial==result,trial!=raw)
        buckets[key]+=1
        out.writerow((i,q,*key,c['rewrite'],z['rewrite']))
for k,n in sorted(buckets.items()):print(k,n)
