"""Capture input and output trees on the same ordinary g3 solver in a separate run."""
import csv,json,os,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
gold,examples,mod,observer=map(Path,sys.argv[1:])
files=json.loads((w/'ordinary.json').read_text())['Replace']
path=next(k for k in files if k.endswith('/smt_qi_instance.go'))
s=Path(files[path]).read_text()
s=s.replace('"strconv"','"strconv"\n"strings"')
ss=observer.read_text()
s+='\n'+ss[ss.index('func trialTree('):ss.index('func witnessTrace(')]+ss[ss.index('func witnessTree('):ss.index('var trialOwner')]
key='fmt.Fprintln(os.Stderr,"QI rewrite"'
assert s.count(key)==1
s=s.replace(key,'fmt.Fprintln(os.Stderr,"TREES",witnessTree(b.manager,prepared.quantifier),"|",witnessTree(b.manager,instance),"|",witnessTree(b.manager,rewritten)); '+key)
s=s.replace('if err = rw.Rewrite(instance, simplified); err != nil {','rewriter.TrialCollectKeys = ferr==nil; err = rw.Rewrite(instance, simplified); rewriter.TrialCollectKeys = false; if err != nil {')
dest=w/'map-trees.go.txt';dest.write_text(s);files[path]=str(dest)
rp=Path(path).parents[1]/'ast/rewriter/th_rewriter.go'
rs=rp.read_text()
for pkg in ('strings','strconv','os','fmt'):
    quoted='"'+pkg+'"'
    if quoted not in rs:rs=rs.replace('import (','import (\n'+quoted,1)
key='if err != nil || !found || dependency.IsNull() {'
assert rs.count(key)==1
rs=rs.replace(key,'if TrialCollectKeys && err==nil && found {fmt.Fprintln(os.Stderr,"MAP",witnessTree(c.owner.manager,term),"|",witnessTree(c.owner.manager,value))}; '+key)
rs+='\nvar TrialCollectKeys bool\n'+ss[ss.index('func trialTree('):ss.index('func witnessTrace(')]+ss[ss.index('func witnessTree('):ss.index('var trialOwner')]
dest=w/'map-rewriter.go.txt';dest.write_text(rs);files[str(rp)]=str(dest)
ov=w/'maps.json';ov.write_text(json.dumps({'Replace':files}))
front=Path(next(k for k in files if k.endswith('/phase_observer_trial.go'))).parent
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod.resolve(),'-tags','xtrace_off','-overlay',ov,'-o',w/'maps','./cmd/goivy_check'],cwd=front,check=True)
spec,_,code=json.loads((gold/'cases.json').read_text())['ticket_protocol']
env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include'))
r=subprocess.run(['taskset','-c','16',w/'maps',examples/spec],cwd=w,env=env,capture_output=True)
extra=bytearray();pending=[];hits=[]
with (w/'maps.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['quantifier','raw','result','hits'])
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'TREES '):pending.append([*line.decode().strip()[6:].split(' | '),json.dumps(hits)]);hits.clear()
        elif line.startswith(b'MAP '):hits.append(line.decode().strip()[4:].split(' | '))
        elif line.startswith(b'STAGE-COUNT '):
            if line.startswith(b'STAGE-COUNT 7 1 check '):out.writerows(pending)
            pending.clear()
        elif not line.startswith(b'QI '):extra.extend(line)
ref=gold/'reference/ticket_protocol'
assert (r.returncode,r.stdout,bytes(extra))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
