"""Offline binding-first experiment using only substitutions actually observed."""
import collections,csv,json
import cache_fusion as model
from pathlib import Path
w=Path(__file__).resolve().parent
counts=collections.Counter()
with (w/'bindings.csv').open('w') as out_file:
    out=csv.writer(out_file)
    out.writerow(['instance','raw_changed','exact','affected_apps','ancestor_keys'])
    for i,r in enumerate(csv.DictReader((w/'cache-maps.csv').open())):
        template=model.parse(r['quantifier'])[-1]
        raw,result=map(model.parse,(r['raw'],r['result']))
        hits={model.parse(k):model.parse(v) for k,v in json.loads(r['hits'])}
        model.mapping={model.parse(k):model.parse(v) for k,v in json.loads(r['cached'])}
        model.mapping.update(hits)
        touched=set()
        def bind(t,a):
            if isinstance(t,str):return hits.get(a,a)
            b=(a[0],*(bind(x,y) for x,y in zip(t[1:],a[1:])))
            if a!=b:touched.add(a)
            return b
        trial=bind(template,raw)
        exact=model.fold(trial)==result
        ancestors=len(touched.intersection(model.mapping))
        counts[trial!=raw,exact,ancestors!=0]+=1
        out.writerow([i,trial!=raw,exact,len(touched),ancestors])
for k,n in sorted(counts.items()):print(k,n)
