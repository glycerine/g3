"""Locate context replacements relative to exact quantifier-body substitutions."""
import csv,json,collections
from pathlib import Path
from fusion import parse
w=Path(__file__).resolve().parent
counts=collections.Counter()
def walk(template,raw,origins):
    if isinstance(template,str):
        assert template[0]=='v' and template[1:].isdigit()
        origins[raw].add('binding')
        def descend(t):
            for c in t[1:]:
                origins[c].add('inside binding')
                descend(c)
        descend(raw)
        return True
    assert template[0]==raw[0] and len(template)==len(raw)
    variable=any([walk(t,r,origins) for t,r in zip(template[1:],raw[1:])])
    origins[raw].add('variable-dependent application' if variable else 'fixed subtree')
    return variable
with (w/'origins.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['instance','source','origin','events'])
    for i,row in enumerate(csv.DictReader((w/'cache-maps.csv').open())):
        origins=collections.defaultdict(set)
        walk(parse(row['quantifier'])[-1],parse(row['raw']),origins)
        for source in ('hits','cached'):
            c=collections.Counter()
            for key,val in json.loads(row[source]):
                s=' + '.join(sorted(origins[parse(key)])) or 'new during rewriting'
                c[s]+=1
            for k,n in c.items():
                out.writerow([i,source,k,n]);counts[source,k]+=n
for k,n in counts.most_common():print(*k,n)
