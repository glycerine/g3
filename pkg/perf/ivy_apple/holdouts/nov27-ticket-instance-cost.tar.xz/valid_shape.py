"""Try a single validated node read on theory-rewriter substitution misses."""
import json, subprocess, sys
from pathlib import Path
w=Path(__file__).resolve().parent
pkg=Path.cwd()
files={}
def overlay(path,src):
    dest=w/('valid-'+path.name)
    dest.write_text(src)
    files[str(path)]=str(dest)
path=pkg/'ast/ast_core_accessors.go'; s=path.read_text()
s+='''
// RewriteShapeWithoutSubstitution reports a validated expression shape when
// this live AST node has never been used as a substitution key.
func (m *ASTManager) RewriteShapeWithoutSubstitution(h ASTHandle, s ASTExprSubstitution) (ASTKind,uint32,uint32,bool) {
    if m==nil || !m.lockFree() || h.origin!=m.origin || s.origin!=m.origin || !m.fastHandle(h) || m.lastExprSubstitution==nil || m.lastExprSubstitution.record!=s.record { return 0,0,0,false }
    _, n, err := m.substKey(astNodeRef{h.slot,h.generation})
    if err!=nil || n.hasFlag(astWasSubstitutionKey) { return 0,0,0,false }
    if n.kind==ASTApp {return n.kind,n.rc,m.appAt(h.slot).count,true}
    return n.kind,n.rc,0,true
}
'''
overlay(path,s)
path=pkg/'ast/rewriter/rewriter_engine.go';s=path.read_text()
key='sub, subProof, found, e := r.cfg.GetSubst(t)'
assert s.count(key)==1
s=s.replace(key,'''if cfg, ok := r.cfg.(*theoryRewriterConfiguration); ok && cfg.hasSubstitution && depth!=0 {
        if kind, rc, n, miss := m.RewriteShapeWithoutSubstitution(t,cfg.substitution); miss {
            return r.visitShape(t,depth,kind,rc,n)
        }
    }
    '''+key)
key='cache, e := r.mustCacheShape(t, kind, rc, n)'
assert s.count(key)==1
s=s.replace(key,'''return r.visitShape(t,depth,kind,rc,n)
}
func (r *rewriterEngine) visitShape(t ast.ASTHandle, depth uint32, kind ast.ASTKind, rc,n uint32)(bool,error) {
    c:=&r.core
    m:=c.manager
    '''+key)
overlay(path,s)
ov=w/'valid-shape.json';ov.write_text(json.dumps({'Replace':files}))
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3])
for target,cwd,cmd in [('cli',pkg,'./cmd/g3'),('ivy',front,'./cmd/goivy_check')]:
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly',*(['-modfile',mod] if target=='ivy' else []),'-tags','xtrace_off','-overlay',ov,'-o',w/('valid-shape-'+target),cmd],cwd=cwd,check=True)
