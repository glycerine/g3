"""Aggregate paired per-instance instruction measurements across verifier rotations."""
import collections,csv,json,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'cost.csv').open()))
def signature(label):
    guards=json.loads((w/('guards-'+label+'.json')).read_text())
    return [__import__('re').sub(r'!\d+','!N',q) for q in guards]
assert signature('ordinary')==signature('native')
def sequence(label,rnd):
    return [(r['guard_id'],r['unchanged'],r['true']) for r in rows if r['solver']==label and r['round']==str(rnd)]
for label in ('ordinary','native'):
    for rnd in {r['round'] for r in rows}:assert sequence(label,rnd)==sequence('ordinary',0)
def group(tag):
    groups=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0,0]))
    for r in rows:
        v=groups[tag(r)][int(r['round']),r['solver']]
        v[0]+=1;v[1]+=int(r['rewrite']);v[2]+=int(r['assert'])
    results=[]
    for key,d in groups.items():
        med=lambda label,i:statistics.median(v[i] for (n,s),v in d.items() if s==label)
        g=[med('ordinary',i) for i in range(3)]
        z=[med('native',i) for i in range(3)]
        assert g[0]==z[0]
        results.append([key,*g,*z[1:],sum(g[1:])-sum(z[1:])])
    return sorted(results,key=lambda x:-x[-1])
for tag in (lambda r:'total',lambda r:r['unchanged'],lambda r:r['guard_id']):
    ans=group(tag)
    for row in ans[:8]:print(*row)
    if len(ans)>2:
        with (w/'ranking.csv').open('w') as f:
            out=csv.writer(f);out.writerow(['guard','count','g_rewrite','g_assert','z_rewrite','z_assert','gap']);out.writerows(ans)
gs=json.loads((w/'guards-ordinary.json').read_text())
for row in ans[:4]:print(row[0],gs[int(row[0])-1][:500])
