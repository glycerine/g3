"""Build per-instance observers from the existing Ticket phase overlays."""
import argparse, json, re, shlex, shutil, subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('backend', choices=['ordinary','native'])
p.add_argument('overlay', type=Path)
p.add_argument('modfile', type=Path)
a = p.parse_args()
w = Path(__file__).resolve().parent
pkg = Path.cwd()
files = json.loads(a.overlay.read_text())['Replace']
phase = next(k for k in files if k.endswith('/phase_observer_trial.go'))
front = Path(phase).parent
def replace(s, old, new):
    assert s.count(old) == 1, old
    return s.replace(old,new)
def write(name,s):
    path=w/name
    path.write_text(s)
    return str(path)
src=Path(files[phase]).read_text()
src=replace(src,'start := time.Now()', '''if batch == 7 && goal == 1 { os.Setenv("QI_COUNTER_FD",fmt.Sprint(fd)) }
    start := time.Now()''')
src=replace(src,'elapsed := time.Since(start)','os.Unsetenv("QI_COUNTER_FD")\n        elapsed := time.Since(start)')
files[phase]=write('stage-'+a.backend+'.go.txt',src)
if a.backend=='ordinary':
    path=pkg/'smtcore/smt_qi_instance.go'
    s=replace(path.read_text(),'"strconv"','"strconv"\n "os"\n "syscall"\n "unsafe"')
    s += '''
func qiRead(fd int) int64 {
    var c [3]uint64
    n,_,err:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24)
    if err!=0 || n!=24 || c[1]!=c[2] {panic("QI perf read")}
    return int64(c[0])
}
'''
    s=replace(s,'if err = rw.Rewrite(instance, simplified);', '''fd, ferr := strconv.Atoi(os.Getenv("QI_COUNTER_FD"))
        var a,b0,c int64
        if ferr==nil { a=qiRead(fd); b0=qiRead(fd) }
        if err = rw.Rewrite(instance, simplified);''')
    s=replace(s,'var arguments *[]ast.ASTHandle','''if ferr==nil { c=qiRead(fd); fmt.Fprintln(os.Stderr,"QI rewrite",c-2*b0+a,rewritten==instance,b.manager.IsTrue(rewritten)) }
        var arguments *[]ast.ASTHandle''')
    s=replace(s,'if err = internalizer.internalizeInstance(result, locals.arguments); err != nil {','''fd, ferr := strconv.Atoi(os.Getenv("QI_COUNTER_FD"))
    var a,b0 int64
    if ferr==nil { a=qiRead(fd); b0=qiRead(fd) }
    err = internalizer.internalizeInstance(result, locals.arguments)
    if ferr==nil {fmt.Fprintln(os.Stderr,"QI assert",qiRead(fd)-2*b0+a)}
    if err != nil {''')
    files[str(path)]=write(path.name+'.txt',s)
else:
    path=pkg.parent/'src/smt/qi_queue.cpp'
    s='#include <unistd.h>\n#include <cstdlib>\n#include <cstdio>\n#include <cstdint>\n'+path.read_text()
    s=replace(s,'    void qi_queue::instantiate(entry & ent)', '''    static int64_t qi_read(int fd) {
        uint64_t c[3];
        if(read(fd,c,sizeof(c))!=sizeof(c) || c[1]!=c[2]) std::abort();
        return c[0];
    }
    void qi_queue::instantiate(entry & ent)''')
    op='m_context.get_rewriter()(instance, s_instance, pr);'
    s=replace(s,op,'''const char* env = std::getenv("QI_COUNTER_FD");
        int fd=env?std::atoi(env):-1;
        int64_t a=0,b=0;
        if(fd>=0){a=qi_read(fd);b=qi_read(fd);}
        '''+op+'''
        if(fd>=0){auto c=qi_read(fd); std::fprintf(stderr,"QI rewrite %lld %s %s\\n",(long long)(c-2*b+a),(instance==s_instance?"true":"false"),(m_manager.is_true(s_instance)?"true":"false"));}''')
    op='m_context.internalize_instance(lemma, pr1, gen);'
    s=replace(s,op,'if(fd>=0){a=qi_read(fd);b=qi_read(fd);}\n        '+op+'\n        if(fd>=0){auto c=qi_read(fd);std::fprintf(stderr,"QI assert %lld\\n",(long long)(c-2*b+a));}')
    build=pkg.parent/'build'
    flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
    inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    obj=w/'qi_queue.o'
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,write('qi_queue.cpp',s)],cwd=build,check=True)
    lib=w/'libqi.a'
    shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
    subprocess.run(['ar','r',lib,obj],check=True)
    k=front/'smt/quantifier.go'
    files[str(k)]=write('quantifier.go',replace(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=write(a.backend+'.json',json.dumps({'Replace':files}))
tags='xtrace_off'+(',classic_z3' if a.backend=='native' else '')
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',a.modfile.resolve(),'-tags',tags,'-overlay',ov,'-o',w/a.backend,'./cmd/goivy_check'],cwd=front,check=True)
