"""Validate complete rotations and compare actual checks under each interval."""
import csv
import re
import statistics
import sys
from collections import defaultdict
from semantic import equality_order
from pathlib import Path

root = Path(sys.argv[1]).resolve()
def selected(key, goal):
    if key == "all":
        return True
    b,g = map(int,goal.split("-"))
    low,high = map(int,key.split(".."))
    return low <= 10000*b+g <= high

for group,expected in (("run",48),("detail",39),("traces",12)):
    folder=root/group
    samples=list(csv.DictReader((folder/"candidate.csv").open()))
    assert len(samples)==expected and all(v['status']=='match' for v in samples)
    actual=defaultdict(int)
    costs=defaultdict(dict)
    for n,i,key,t,phase,v,a in csv.reader((folder/"rows.csv").open()):
        if phase!="check":continue
        # EndUnitTrial may return its last count on a check that never armed it.
        actual[n,i,key]+=int(a) if selected(key,t) else 0
        if t in ('43-70','54-80','60-1','12-8'):
            costs[n,i,key][t]=int(v)
    result=defaultdict(list)
    for r in samples:
        n,i,key=r['case'],r['round'],r['target']
        d=costs[n,i,key]
        result[n,key].append([actual[n,i,key],int(r['stage_sum']),*(d.get(t,0) for t in ('43-70','54-80','60-1','12-8'))])
    with (folder/"summary.csv").open("w") as f:
        writer=csv.writer(f)
        writer.writerow(['case','interval','runs','attempts','all_stages','43-70','54-80','60-1','12-8'])
        for (n,key),rs in result.items():
            assert len(rs)==(1 if group=="traces" else 3)
            writer.writerow([n,key,len(rs),*map(statistics.median,zip(*rs))])

fresh=re.compile(r'([^\s()!]+)!(\d+)')
def events(path):
    data=defaultdict(list)
    names=defaultdict(dict)
    for l in path.read_text().splitlines():
        _,row,typ,val=l.split(" ",3)
        def norm(m):
            stem=m[1];seen=names[row].setdefault(stem,{})
            return stem+"!"+str(seen.setdefault(m[2],len(seen)))
        value=fresh.sub(norm,val)
        data[row,typ].append(value)
        if typ in ("D","Q"):
            number,expr=value.split(" ",1)
            data[row,typ+"-semantic"].append((str(int(number)%2) if typ=="D" else number)+" "+equality_order(expr))
            if typ=="D":data[row,"D-id"].append(number)
    return data

folder=root/'traces'
with (folder/'events.csv').open('w') as f:
    writer=csv.writer(f)
    writer.writerow(['case','interval','check','event','base_count','count','common_prefix','base_first_difference','first_difference'])
    for n in ('1','8'):
        base=events(folder/f'{n}-0..0.log')
        for path in sorted(folder.glob(f'{n}-*.log')):
            key=path.stem.split('-',1)[1];curr=events(path)
            for row,typ in sorted(base.keys()|curr.keys()):
                a,b=base[row,typ],curr[row,typ]
                p=next((i for i,(x,y) in enumerate(zip(a,b)) if x!=y),min(len(a),len(b)))
                writer.writerow([n,key,row,typ,len(a),len(b),p,a[p] if p<len(a) else '',b[p] if p<len(b) else ''])

with (root/'model-costs.csv').open('w') as f:
    out=csv.writer(f)
    out.writerow(['experiment','policy','counter','runs','initial_counter','check','stage_sum'])
    for group,reps,cells in [('fresh',3,9),('natural',3,8),('merge',2,12),('inverse',2,16)]:
        rows=defaultdict(list)
        for i,k,v,c,n,st in csv.reader((root/group/'fresh.csv').open()):
            rows[k,v].append((int(i),int(c),int(n),int(st)))
        runs=list(csv.DictReader((root/group/'candidate.csv').open()))
        assert len(rows)==cells and len(runs)==cells*reps and all(r['status']=='match' for r in runs)
        for (k,v),rr in rows.items():
            rounds,initial,check,stages=zip(*rr)
            assert len(set(initial))==1 and sorted(rounds)==list(range(reps))
            out.writerow([group,k,v,reps,initial[0],statistics.median(check),statistics.median(stages)])
for group,count in [('native',6),('origin',2)]:
    p=root/group/('costs.csv' if group=='native' else 'candidate.csv')
    rows=list(csv.DictReader(p.open()))
    assert len(rows)==count and all(r['status']=='match' for r in rows)
