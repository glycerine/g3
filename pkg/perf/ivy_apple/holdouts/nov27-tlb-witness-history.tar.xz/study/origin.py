"""Record how the quantifier queue received the first different binding."""
def origin(s):
    block="""
 k=p/'smtcore/smt_search.go';v=Path(rep[str(k)]).read_text();v=v.replace('historyRow="";switch','historyRow="";historyOrdinal=0;historyOrigins=nil;if b==60&&g==1{historyOrigins=make(map[*SMTFingerprint]string)};switch')
 put(k,v+'\\nvar historyOrigins map[*SMTFingerprint]string;var historyOrdinal int;var historyModel bool\\n')
 k=p/'smtcore/smt_quantifier_registry.go';v=Path(rep[str(k)]).read_text();n='r.traceNewMatch(fingerprint';assert v.count(n)==1
 put(k,v.replace(n,'if historyOrigins!=nil{kind:="pattern";if pattern.IsNull(){kind="quick";if historyModel{kind="model"}};historyOrigins[fingerprint]=kind};'+n))
 k=p/'smtcore/smt_model_checker_instances.go';v=k.read_text();a='if _, err := c.registry.AddInstance';v=v.replace(a,'historyModel=true;'+a);a='return c.ResetNewInstances()';assert v.count(a)==1;put(k,v.replace(a,'historyModel=false;'+a))
 k=p/'smtcore/smt_qi_instance.go';v=Path(rep[str(k)]).read_text();a='if historyRow!=""{h,e:=result.Lemma()';assert v.count(a)==1
 put(k,v.replace(a,'if historyOrigins!=nil{historyOrdinal++;if historyOrdinal>=1415&&historyOrdinal<=1426{fp:=result.fingerprint;fmt.Fprint(os.Stderr,"HIST ",historyRow," O ",historyOrdinal," ",historyOrigins[fp]);for _,arg:=range fp.args{fmt.Fprint(os.Stderr," ",witnessTree(result.manager,arg.owner))};fmt.Fprintln(os.Stderr)}};'+a))
"""
    point=" j=d/'ov.json'"
    s=s.replace(point,block+point)
    a=s.index('   for n in [1,8]:');b=s.index('    for key in intervals[repno:]',a)
    return s[:a]+"""   for n in [1]:
    golden=ref/'compat'/str(n)/'1/native'
    intervals=['0..0','all']
"""+s[b:]
