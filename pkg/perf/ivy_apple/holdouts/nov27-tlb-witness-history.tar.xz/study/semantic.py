"""Canonicalize equality orientation in diagnostic event expressions."""
import re
from functools import lru_cache

@lru_cache(maxsize=32768)
def equality_order(expr):
    # Print equality operands in lexical order, preserving every other argument order.
    if "(= " not in expr:return expr
    stack=[];result=""
    for token in re.findall(r"\(|\)|[^()\s]+",expr):
        if token=="(":stack.append([])
        elif token==")":
            items=stack.pop()
            if len(items)==3 and items[0]=="=":items[1:]=sorted(items[1:])
            result="("+" ".join(items)+")"
            if stack:stack[-1].append(result)
        else:stack[-1].append(token)
    return result

