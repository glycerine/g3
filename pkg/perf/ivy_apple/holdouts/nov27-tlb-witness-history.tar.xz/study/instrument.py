"""Add event observers to a separate diagnostic build of the interval replay."""
import os
import tarfile
from pathlib import Path

def instrument(s):
    if not os.environ.get("HISTORY_ORIGIN"):
        s=s.replace('smtcore.StartUnitTrial(os.Getenv("UNIT_MODE"))}}',
                    'smtcore.StartUnitTrial(os.Getenv("UNIT_MODE"))}else{smtcore.StartUnitTrial("base")}}')
    with tarfile.open("perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz") as archive:
        go=archive.extractfile("study/sources/events-smt_search.go.txt").read().decode()
    tree=go[go.index("func trialTree("):go.index("func witnessTrace(")]
    tree+='func witnessTree(m *ast.ASTManager,t ast.ASTHandle) string {var b strings.Builder;trialTree(m,t,&b);return b.String()}\n'
    tree+='var historyRow string\nfunc TraceHistoryRow(b,g int){historyRow="";switch 10000*b+g{case 430070,540080,600001,120008:historyRow=fmt.Sprintf("%d-%d",b,g)}}\n'
    edits="""
 k=p/'smtcore/smt_search.go';v=Path(rep[str(k)]).read_text().replace('import (','import ("os";"strconv";"strings";')
 v=v.replace('k.internalizer.traceDecide(variable', 'if historyRow!=""{fmt.Fprintln(os.Stderr,"HIST",historyRow,"D",smtDecisionLiteral(variable,phase).Index(),witnessTree(k.manager,k.internalizer.boolExpr[variable]))};k.internalizer.traceDecide(variable')
 v=v.replace('if !resolution.Resolved {','if historyRow!=""{fmt.Fprintln(os.Stderr,"HIST",historyRow,"C",k.internalizer.scopeLevel,resolution.NewScopeLevel,resolution.Lemma)};if !resolution.Resolved {')
 put(k,v+TREE)
 k=p/'smtcore/smt_qi_instance.go';v=k.read_text().replace('import (','import ("os";');point='if err = internalizer.internalizeInstance';assert point in v
 put(k,v.replace(point,'if historyRow!=""{h,e:=result.Lemma();if e!=nil{panic(e)};fmt.Fprintln(os.Stderr,"HIST",historyRow,"Q",result.generation,witnessTree(result.manager,h))};'+point))
 k=front/'phase_observer_trial.go';v=Path(rep[str(k)]).read_text().replace('func unitBegin(b,g int){','func unitBegin(b,g int){smtcore.TraceHistoryRow(b,g);').replace('func unitEnd(b,g int){','func unitEnd(b,g int){smtcore.TraceHistoryRow(0,0);');put(k,v)
"""
    a=" j=d/'ov.json'"
    assert s.count(a)==1
    s=s.replace(a,edits.replace("v+TREE","v+"+repr(tree))+a)
    s=s.replace('range(3):','range(1):').replace("if n==1:intervals.extend(","if False:intervals.extend(")
    s=s.replace("stages=[];rest", "history=[];stages=[];rest")
    s=s.replace("else:rest.extend(l)", "elif l.startswith(b'HIST '):history.append(l)\n      else:rest.extend(l)")
    s=s.replace("assert match,(n,mode,repno)", "assert match,(n,mode,repno)\n     (w/f'{n}-{key}.log').write_bytes(b''.join(history))")
    return s
