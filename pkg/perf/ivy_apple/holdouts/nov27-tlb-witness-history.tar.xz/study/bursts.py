"""Compare contiguous instance emissions before the first changed TLB search decision."""
import csv
import re
import sys
from collections import Counter
from pathlib import Path
root=Path(sys.argv[1])
from semantic import equality_order
def split(path):
    seq=[];counts=Counter();names={}
    for l in path.open():
        if not l.startswith('HIST 60-1 '):continue
        _,row,event,more=l.rstrip().split(' ',3)
        def rename(m):
            group=names.setdefault(m[1],{})
            return m[1]+"!"+str(group.setdefault(m[2],len(group)))
        more=re.sub(r'([^\s()!]+)!(\d+)',rename,more)
        if event in ('D','Q'):
            n,expr=more.split(' ',1);more=n+' '+equality_order(expr)
        if event=='Q' and seq and seq[-1][0]=='Q':seq[-1][1].append(more)
        else:seq.append((event,[more],counts.copy()))
        counts[event]+=1
    return seq
base=split(root/'traces/1-0..0.log');applied=split(root/'traces/1-all.log')
with (root/'bursts.csv').open('w') as f:
    o=csv.writer(f);o.writerow(['seq','baseline','applied','prior_D','prior_C','prior_Q','base_size','applied_size','common_multiset','first_different'])
    for i,(a,b) in enumerate(zip(base,applied)):
        if a[:2]==b[:2]:continue
        same=sum((Counter(a[1])&Counter(b[1])).values())
        prefix=next((i for i,(x,y) in enumerate(zip(a[1],b[1])) if x!=y),min(len(a[1]),len(b[1])))
        o.writerow([i,a[0],b[0],a[2]['D'],a[2]['C'],a[2]['Q'],len(a[1]),len(b[1]),same,prefix])
        if a[0]!=b[0] or a[0]!='Q':break
