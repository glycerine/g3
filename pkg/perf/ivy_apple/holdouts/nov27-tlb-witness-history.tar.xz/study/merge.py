"""Change equal-size congruence-class merge ties only inside the selected check."""
def merge(s):
    a=s.index("   cases=[(key,c)");b=s.index("     mode='indexed'",a)
    s=s[:a]+"""   cases=[('0..0',c,tie) for c in range(407,411) for tie in ('base','slot','parents')]
   for key,counter,tie in cases[repno:]+cases[:repno]:
"""+s[b:]
    s=s.replace('range(3):','range(2):').replace('FRESH_AT=str(counter)','FRESH_AT=str(counter),MERGE_TIE=tie')
    edit="""
 k=p/'smtcore/smt_equality_propagation.go';v=k.read_text();a='if (r1.classSize > r2.classSize && !r2.interpreted) || r1.interpreted {';assert v.count(a)==1
 v=v.replace(a,'if (r1.classSize > r2.classSize || (r1.classSize==r2.classSize && ((HistoryMerge==1 && r1.owner.Slot()<r2.owner.Slot()) || (HistoryMerge==2 && len(r1.sourceParents)>len(r2.sourceParents))))) && !r2.interpreted || r1.interpreted {')
 put(k,v+'\\nvar HistoryMerge byte\\n')
 k=front/'phase_observer_trial.go';v=Path(rep[str(k)]).read_text().replace('func unitBegin(b,g int){','func unitBegin(b,g int){smtcore.HistoryMerge=0;if b==60&&g==1{switch os.Getenv("MERGE_TIE"){case "slot":smtcore.HistoryMerge=1;case "parents":smtcore.HistoryMerge=2}};');put(k,v.replace('func unitEnd(b,g int){','func unitEnd(b,g int){smtcore.HistoryMerge=0;'))
"""
    s=s.replace(" j=d/'ov.json'",edit+" j=d/'ov.json'")
    return s.replace('writerow([repno,key,counter,fresh_entry','writerow([repno,tie,counter,fresh_entry')
