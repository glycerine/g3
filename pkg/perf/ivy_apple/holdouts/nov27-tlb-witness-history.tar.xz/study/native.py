"""Run the archived linked-Z3 control on the same two complete inputs."""
import json
import os
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path
out = Path(os.environ['RESULTS']).resolve()
out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as temp, tarfile.open('perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as archive:
    scratch=Path(temp)
    def read(name):return archive.extractfile('study/'+name).read()
    plan=json.loads(read('plans/linked-z3.json'))
    (scratch/'plans').mkdir();(scratch/'sources').mkdir()
    for _,_,name in plan['sources']:(scratch/'sources'/name).write_bytes(read('sources/'+name))
    plan['runs']=[[n,str(i),'native','60-1' if n==1 else '12-8'] for i in range(3) for n in (1,8)]
    (scratch/'plans/linked-z3.json').write_text(json.dumps(plan))
    s=read('reproduce.py').decode().replace('            stream.flush()',"""            with (output/'targets.csv').open('a') as rf:
                csv.writer(rf).writerows([number,target,t,v] for t,ph,v in stages if ph==b'check' and t in ('43-70','54-80','60-1','12-8'))
            stream.flush()""")
    (scratch/'reproduce.py').write_text(s)
    subprocess.run([sys.executable,scratch/'reproduce.py','linked-z3','--output',out],check=True)
