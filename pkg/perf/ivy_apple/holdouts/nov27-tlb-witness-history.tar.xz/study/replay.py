"""Replay selected check intervals against the tracked dense witness benchmark."""
import os
import tarfile
from pathlib import Path

root = Path.cwd()
out = Path(os.environ["RESULTS"])
out.mkdir(parents=True, exist_ok=True)
with tarfile.open(root / "perf/ivy_apple/holdouts/nov27-unary-witness-eligibility.tar.xz") as archive:
    for name in ("run.py", "link.txt", "index.go.txt"):
        (out / name).write_bytes(archive.extractfile("study/stack/" + name).read())
driver = (out / "run.py").read_text()
# Change only the measurement schedule after the archived overlay has been assembled.
prefix, tail = driver.split("    exec(compile", 1)
original = 'if target=="all"||target==fmt.Sprintf("%d-%d",b,g)'
condition = '''lo,hi:=0,0;fmt.Sscanf(target,"%d..%d",&lo,&hi);pos:=10000*b+g;if target=="all" || lo<=pos && pos<=hi'''
schedule = """
    # Look up each check by its instrumented physical batch and goal.
    a=s.index('  for repno in range(3):')
    b=s.index('     r=sp.run(',a)
    s=s[:a]+'''  for repno in range(3):
   for n in [1,8]:
    golden=ref/'compat'/str(n)/'1/native'
    targets=[430070,540080,600001] if n==1 else [120008]
    intervals=['0..0','all']
    for t in targets:intervals.extend([f'{t}..{t}',f'1..{t-1}'])
    if n==1:intervals.extend(['1..300000','300001..450000','450001..599999','590001..599999'])
    if os.environ.get("DETAIL"):
     intervals=['0..0','all']
     if n==1:intervals+=['430001..430069','1..430000','540001..540079','1..540000','330001..339999','1..399999','400001..430069']
     else:intervals+=['120001..120007','1..120000']
    for key in intervals[repno:]+intervals[:repno]:
     mode='indexed'
'''+s[b:]
    s=s.replace(original,condition)
    assert condition in s
    # Each row retains its intervention interval even when two checks share a batch.
    s=s.replace('writerows([n,repno,mode,t.decode()', 'writerows([n,repno,key,t.decode()')
"""
# All transformations act on the same archived measurement harness.
import importlib
namespace={"__file__":str(out/"run.py"),"original":original,"condition":condition}
for env,module,fn in (("HISTORY_TRACE","instrument","instrument"),
                      ("HISTORY_FRESH","fresh","fresh"),
                      ("HISTORY_ORIGIN","origin","origin"),
                      ("HISTORY_MERGE","merge","merge"),
                      ("HISTORY_INVERSE","inverse","inverse")):
    if os.environ.get(env):
        namespace[fn]=getattr(importlib.import_module(module),fn)
        schedule+=f"    s={fn}(s)\n"
exec(compile(prefix+schedule+"    exec(compile"+tail,str(out/"run.py"),"exec"),namespace)
