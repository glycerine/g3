"""Test model-value representative choices across four natural fresh-name histories."""
def inverse(s):
    a=s.index("   cases=[(key,c)");b=s.index("     mode='indexed'",a)
    s=s[:a]+"""   cases=[('0..0',c,policy) for c in range(407,411) for policy in ('base','slot','ite','context')]
   for key,counter,policy in cases[repno:]+cases[:repno]:
"""+s[b:]
    s=s.replace('range(3):','range(2):').replace('FRESH_AT=str(counter)','FRESH_AT=str(counter),MODEL_POLICY=policy')
    edit="""
 k=p/'smtcore/smt_model_finder_instantiation_set.go';v=k.read_text();a='if generation < oldGeneration {';assert v.count(a)==1
 put(k,v.replace(a,'if generation < oldGeneration || generation==oldGeneration && (HistoryRep==1||HistoryRep==2) && historyPrefer(s.manager,term,old[0]) {')+'''
var HistoryRep byte
func historyPrefer(m *ast.ASTManager,a,b ast.ASTHandle)bool{
 if b.IsNull(){return true}
 if HistoryRep>=2{ah,e:=m.NodeHeader(a);if e!=nil{panic(e)};bh,e:=m.NodeHeader(b);if e!=nil{panic(e)}
 ai:=ah.Family==m.BasicFamilyID()&&ah.DeclKind==ast.ASTOpIte;bi:=bh.Family==m.BasicFamilyID()&&bh.DeclKind==ast.ASTOpIte
 if ai!=bi{return ai}}
 return a.Slot()<b.Slot()
}
''')
 k=p/'smtcore/smt_model_checker.go';v=Path(rep[str(k)]).read_text();a='c.valueTerms[value] = root.EqualityClassMinGeneration().owner';assert v.count(a)==1
 put(k,v.replace(a,'candidate:=root.EqualityClassMinGeneration().owner;if HistoryRep!=3||historyPrefer(c.manager,candidate,c.valueTerms[value]){c.valueTerms[value]=candidate}'))
 k=front/'phase_observer_trial.go';v=Path(rep[str(k)]).read_text().replace('func unitBegin(b,g int){','func unitBegin(b,g int){smtcore.HistoryRep=0;if b==60&&g==1{switch os.Getenv("MODEL_POLICY"){case "slot":smtcore.HistoryRep=1;case "ite":smtcore.HistoryRep=2;case "context":smtcore.HistoryRep=3}};');put(k,v.replace('func unitEnd(b,g int){','func unitEnd(b,g int){smtcore.HistoryRep=0;'))
"""
    s=s.replace(" j=d/'ov.json'",edit+" j=d/'ov.json'")
    return s.replace('writerow([repno,key,counter,fresh_entry','writerow([repno,policy,counter,fresh_entry')
