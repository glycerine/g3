# TLB and automatic Ticket witness history replays

Run from g3/pkg at 0b1ae991f on Linux with a CPU supporting perf_event_open. Set GOIVY_FRONTEND, GOIVY_MODFILE, IVY_EXAMPLES and NNF_REFERENCE using the tracked nov27-nnf-row-comparison archive. The benchmarks reuse the exact overlays in the tracked nov27-unary-witness-eligibility and nov27-unary-demand-and-fresh-symbols archives. Each Go build uses a temporary private cache. Set CPU to an available core and RESULTS to a new directory for each command. No observer is installed in g3 or GoIvy. Each process runs the complete input, pins the solver thread and compares stdout, stderr and exit status to linked Z3. Counters exclude kernel work and require equal enabled and running times. GC is off.

With the scripts from this archive together in one directory, run the following commands from g3/pkg. Set STUDY to that script directory and OUT to a fresh absolute output directory. Use the same exported frontend, module, examples, reference and CPU settings for every command.

    RESULTS="$OUT/run" python3 "$STUDY/replay.py"
    DETAIL=1 RESULTS="$OUT/detail" python3 "$STUDY/replay.py"
    HISTORY_TRACE=1 RESULTS="$OUT/traces" python3 "$STUDY/replay.py"
    HISTORY_TRACE=1 HISTORY_ORIGIN=1 RESULTS="$OUT/origin" python3 "$STUDY/replay.py"
    HISTORY_FRESH=1 RESULTS="$OUT/fresh" python3 "$STUDY/replay.py"
    HISTORY_FRESH=1 NATURAL_COUNTER=1 RESULTS="$OUT/natural" python3 "$STUDY/replay.py"
    HISTORY_FRESH=1 HISTORY_MERGE=1 RESULTS="$OUT/merge" python3 "$STUDY/replay.py"
    HISTORY_FRESH=1 HISTORY_INVERSE=1 RESULTS="$OUT/inverse" python3 "$STUDY/replay.py"
    RESULTS="$OUT/native" python3 "$STUDY/native.py"
    python3 "$STUDY/summarize.py" "$OUT"
    python3 "$STUDY/bursts.py" "$OUT"

The run and detail arms evaluate inclusive check intervals encoded as 10000 * batch + goal. Zero selects none. The shared process and AST manager run through all earlier batches. Each batch creates a fresh incremental solver. The counts of attempted instances in summary.csv include only checks that ran inside the interval. The original low-level EndUnitTrial observer can repeat the previous count on an unarmed check. The summary recomputes attempts from individual armed checks. Use these corrected counts. Stage instruction sums are independent of this reporting issue. The detail run used the same binary as run; the natural sweep reused the fresh binary. Set PREBUILT only when supplying the corresponding measurement executable.

Trace and origin runs are diagnostic. The first logs signed decisions (D), learned-conflict data (C), and quantified lemmas before internalization (Q). For semantic stream comparisons the analysis renumbers fresh suffixes within each stem by first appearance and sorts equality operands. A decision retains polarity and expression, and a lemma retains generation and expression. The registry diagnostic tags the recorded fingerprint at registration so the O rows at 60/1 identify the source of the first different emitted bindings. All process-global flags in these overlays belong to the sequential benchmark.

In fresh.csv the six columns are round, selection, requested counter, observed starting counter, check 60/1 instructions and stage sum. A requested zero preserves the counter. In the merge experiment the second field names the equal-size class-merge policy used only in 60/1. The preexisting rule preserves the second eligible root on ties. Slot keeps the lower arena slot; parents keeps the root with more source parents. Both preserve precedence for interpreted roots. The original benchmark uses three rotations for the main, detail, fresh and natural arms, two for merge and inverse, one per diagnostic condition and three linked-Z3 runs per complete input.

The inverse screen changes only batch 60 check 1. Slot breaks ties between equal-generation inverse terms by arena slot. Ite prefers an if-then-else term at equal generation and breaks other ties by slot. Context uses that preference for the unrestricted model value to ground-term map instead. Each alternate competes with a control in the same executable.
