"""At batch 60 fix the first fresh-function counter independently of prior search."""
def fresh(s):
    a=s.index('  for repno in range(3):')
    b=s.index('     r=sp.run(',a)
    s=s[:a]+'''  for repno in range(3):
   n=1;golden=ref/'compat'/str(n)/'1/native'
   # Each process verifies every obligation. Only the batch-60 fresh counter is changed.
   cases=[(key,c) for key in ['0..0','1..430000','all'] for c in [0,10000,10001]]
   if os.environ.get("NATURAL_COUNTER"):
    cases=[("0..0",i) for i in range(407,415)]
   for key,counter in cases[repno:]+cases[:repno]:
     mode='indexed'
'''+s[b:]
    s=s.replace('TARGET=key,UNIT_MODE=mode','TARGET=key,UNIT_MODE=mode,FRESH_AT=str(counter)')
    edit="""
 k=p/'ast/ast_core_fresh_factories.go';v=k.read_text().replace('import (','import ("fmt";"os";')
 a='if m.freshInfoActive ||';assert v.count(a)==1
 v=v.replace(a,'if ObserveHistoryCounter {ObserveHistoryCounter=false;fmt.Fprintln(os.Stderr,"FRESH_ENTRY",m.freshID,SetHistoryCounter);if SetHistoryCounter!=0 {if m.freshID>SetHistoryCounter{panic("counter would go backwards")};m.freshID=SetHistoryCounter}};'+a)
 put(k,v+'\\nvar ObserveHistoryCounter bool\\nvar SetHistoryCounter uint32\\n')
 k=front/'phase_observer_trial.go';v=Path(rep[str(k)]).read_text().replace('import (','import ("strconv";"github.com/glycerine/g3/pkg/ast";')
 put(k,v.replace('phaseBatch++; return','phaseBatch++;if phaseBatch==60{c,e:=strconv.Atoi(os.Getenv("FRESH_AT"));if e!=nil{panic(e)};ast.SetHistoryCounter=uint32(c);ast.ObserveHistoryCounter=true}; return'))
"""
    needle=" j=d/'ov.json'"
    assert s.count(needle)==1
    s=s.replace(needle,edit+needle)
    s=s.replace('stages=[];rest','fresh_entry=[];stages=[];rest').replace('else:rest.extend(l)',"elif l.startswith(b'FRESH_ENTRY '):fresh_entry.append(int(a[1]));assert int(a[2])==counter\n      else:rest.extend(l)")
    s=s.replace('assert match,(n,mode,repno)',"""assert match and len(fresh_entry)==1,(n,key,repno,counter,fresh_entry)
     with (w/'fresh.csv').open('a') as raw:csv.writer(raw).writerow([repno,key,counter,fresh_entry[0],sum(v for t,ph,v in stages if t==b'60-1' and ph==b'check'),sum(v for _,_,v in stages)])""")
    s=s.replace('o.writerow([n,key,mode','o.writerow([n,key,str(counter)')
    s=s.replace("writerows([n,repno,key,t.decode()", "writerows([n,repno,key+'@'+str(counter),t.decode()")
    return s
