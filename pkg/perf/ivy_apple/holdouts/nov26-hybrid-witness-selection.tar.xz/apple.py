from pathlib import Path
import os,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();f=w.parent/'.boolean-enode-cost/apple-source/goivy'
files={}
for name in ['smt_model_checker.go','smt_model_table_check.go']:
    dst=w/('pins-'+name);dst.write_bytes(subprocess.check_output(['git','show','5ec62616b:pkg/smtcore/'+name]));files[str(p/'smtcore'/name)]=str(dst)
ov=w/'apple-base.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-pgo=off','-tags=xtrace_off','-overlay',ov,'-o',w/'apple-base','./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
g=w/'proofs';cases=json.loads((g/'cases.json').read_text());cases['dramc_nb2']=['doc/examples/apple/ord_live.ivy','dramc_nb2',0];(g/'cases.json').write_text(json.dumps(cases));d=g/'reference/dramc_nb2';d.mkdir(exist_ok=True)
prev=w.parent/'.bool-scan/pinned-apple-with-includes/dramc_nb2/1/g3'
for stream in ['stdout','stderr']:(d/stream).write_bytes((prev/stream).read_bytes())
