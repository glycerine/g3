import os,json,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost'
for kind in ['release','release-cost']:
    ov=[] if kind=='release' else ['-overlay',w.parent/'.hybrid-obligations/observer.json']
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off',*ov,'-o',w/kind,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
