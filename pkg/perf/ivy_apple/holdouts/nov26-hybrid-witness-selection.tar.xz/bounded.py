"""Cap both the alternative domain scan and remaining expression evaluation budget."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();b=w.parent/'.boolean-enode-cost'
for src in ['alternate','repeat']:
    files=json.loads((w/(src+'.json')).read_text())['Replace']
    name=p/'smtcore/smt_model_table_check.go';s=Path(files[str(name)]).read_text()
    s=s.replace('for _,v:=range opts {','for _,v:=range opts[:min(len(opts),8)] {').replace('saved:=g.work;alt:=','alt:=').replace('g.work=saved;g.incomplete=false','g.incomplete=false')
    dst=w/(src+'-bounded.go');dst.write_text(s);files[str(name)]=str(dst)
    for timed in [False,True]:
        label=src+'-bounded'+('-cost' if timed else '')
        if timed:files.update(json.loads((w.parent/'.hybrid-obligations/observer.json').read_text())['Replace'])
        ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':files}))
        subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
