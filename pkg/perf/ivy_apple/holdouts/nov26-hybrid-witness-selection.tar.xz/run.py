"""Verify the complete transcript and record timed stages or ordered tuple events."""
import csv,os,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
ref=w.parent/'.bool-scan/golden/reference/hybrid'
ex=Path('/home/jaten/ivy/ivy-lang-examples')
mode=sys.argv[1];engines=sys.argv[2:]
out=csv.writer(sys.stdout,lineterminator='\n')
out.writerow(['engine','skip','round','batch','goal','phase','instructions'] if mode=='cost' else ['engine','skip','batch','goal','candidate','event','value'])
for rnd in range(3 if mode=='cost' else 1):
    for spec in engines[rnd%len(engines):]+engines[:rnd%len(engines)]:
        engine,bsel,skip=spec.split(':')
        env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),G3_SKIP_TABLE='0')
        env['G3_SKIP_BATCH_'+bsel]=skip
        if mode!='cost':env['G3_WITNESS_TRACE']='1'
        r=subprocess.run(['taskset','-c','14',w/engine,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=env,capture_output=True,check=True)
        keep,pending,n=[],[],0;checks=0
        for l in r.stderr.splitlines(keepends=True):
            if l.startswith(b'WT '):
                parts=l.rstrip().decode().split(' ',2);event=parts[1]
                if event=='candidate':n+=1
                pending.append([n,event,parts[2] if len(parts)>2 else ''])
            elif l.startswith(b'STAGE-COUNT '):
                _,batch,goal,phase,count,empty,enabled,running,ns=l.decode().split()
                if (batch,goal) in [('35','1'),('19','29')] and phase=='check':
                    checks+=1
                    assert enabled==running and int(enabled)>0
                    if mode=='cost':out.writerow([engine,bsel+'-'+skip,rnd+1,batch,goal,phase,count])
                    else:out.writerows([engine,bsel+'-'+skip,batch,goal,*row] for row in pending)
                pending=[];n=0
            else:keep.append(l)
        assert checks==2 and not pending and r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
        sys.stdout.flush()
