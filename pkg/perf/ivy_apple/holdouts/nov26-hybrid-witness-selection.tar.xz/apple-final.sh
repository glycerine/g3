set -eu
work=$(realpath build/.witness-origin)
front=$(realpath build/.boolean-enode-cost/apple-source/goivy)
export GOCACHE=/tmp/g3-nov23-day/cache
export GOIVY_INCLUDE=/home/jaten/ivy/ivy-lang-examples/ivy/include
go -C "$front" build -buildvcs=false -mod=readonly -pgo=off -tags=xtrace_off -o "$work/apple-release" ./cmd/goivy_check
python3 "$work/verify.py" --reference "$work/proofs" --examples /home/jaten/ivy/ivy-lang-examples --cpu 18 --perf /usr/lib/linux-tools/6.17.0-35-generic/perf --rounds 3 --case rfn2 --case dramc_nb2 previous="$work/apple-base" current="$work/apple-release" > "$work/final-apple.csv"
