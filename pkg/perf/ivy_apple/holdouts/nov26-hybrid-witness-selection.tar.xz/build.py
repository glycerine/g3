"""Build read-only tuple observers and a numbered table-witness intervention."""
import json,os,re,shlex,shutil,subprocess,sys
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent;old=w.parent/'.hybrid-obligations';prev=w.parent/'.lemma-pairs';base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
e=sys.argv[1];files=json.loads((old/'observer.json').read_text())['Replace']
def change(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def overlay(f,s):
    d=w/(e+'-'+f.name);d.write_text(s);files[str(f)]=str(d)
f=front/'phase_observer_trial.go';s=Path(files[str(f)]).read_text()
s=change(s,'start := time.Now()', '''target:=batch==35 && goal==1 || batch==19 && goal==29
if target { os.Setenv("G3_WITNESS_STAGE","yes");os.Setenv("G3_WITNESS_INDEX","0");os.Setenv("G3_SKIP_TABLE",os.Getenv(fmt.Sprintf("G3_SKIP_BATCH_%d",batch))) }
start := time.Now()''')
s=change(s,'elapsed := time.Since(start)','elapsed := time.Since(start);if target {os.Unsetenv("G3_WITNESS_STAGE")}')
overlay(f,s)
if e=='g3':
    f=p/'smtcore/smt_model_checker.go';s=f.read_text().replace('import (','import (\n"os"\n"strconv"\n"strings"')
    s=change(s,'tableScratch     *tableModel','trialTable bool\n tableScratch *tableModel')
    line='added, err := c.addFiniteCounterexample(quantifier, bindings)'
    s=change(s,line,'c.trialTable=true\n'+line+'\nc.trialTable=false')
    line='_, err = c.enqueueCounterexample(quantifier, bindings, true, maxGeneration)'
    s=change(s,line,'''if c.trialTable && os.Getenv("G3_WITNESS_STAGE")!="" {
      n,_:=strconv.Atoi(os.Getenv("G3_WITNESS_INDEX"));n++;os.Setenv("G3_WITNESS_INDEX",strconv.Itoa(n))
      skip:=os.Getenv("G3_SKIP_TABLE")
      if skip==strconv.Itoa(n)||skip=="all" { if witnessTrace(){println("WT skip",n)};return false,nil }
    }
    '''+line)
    line='func (c *SMTModelChecker) Check(model *protomodel.ProtoModel, quantifiers []ast.ASTHandle) (bool, error) {'
    s=change(s,line,line+'if witnessTrace(){println("WT candidate")}\n')
    tree=(prev/'shape-instance.go').read_text().split('func trialTree(')[1]
    s+='\nfunc trialTree('+tree+'\nfunc witnessTrace() bool { return os.Getenv("G3_WITNESS_TRACE")!="" && os.Getenv("G3_WITNESS_STAGE")!="" }\n'
    s+='func witnessTree(m *ast.ASTManager,t ast.ASTHandle) string {var b strings.Builder;trialTree(m,t,&b);return b.String()}\n'
    overlay(f,s)
    f=p/'smtcore/smt_model_checker_instances.go';s=f.read_text()
    line='c.newInstances = append(c.newInstances, instance)'
    s=change(s,line,line+'''\nif witnessTrace(){println("WT witness",generation,c.trialTable,witnessTree(c.manager,quantifier));for _,v:=range bindings{println("WT binding",witnessTree(c.manager,v))}}''')
    overlay(f,s)
    f=p/'smtcore/smt_quantifier_manager.go';s=f.read_text()
    line='if !instance.ReducedTrue() {'
    s=change(s,line,line+'\nif witnessTrace(){println("WT lemma",witnessTree(q.state.manager,entry.Fingerprint.data))}')
    overlay(f,s)
else:
    build=p.parent/'build';mk=(build/'Makefile').read_text()
    flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
    lib=w/'libwitness.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
    hdr=(prev/'shapes/qi_queue.cpp').read_text().split('static void emit')[0]+'\nstatic bool active(){return getenv("G3_WITNESS_TRACE") && getenv("G3_WITNESS_STAGE");}\n'
    for name in ['smt_model_checker','qi_queue']:
        src=p.parent/('src/smt/'+name+'.cpp');s=src.read_text()
        if name=='qi_queue':
            line='stat->inc_num_instances();';s=change(s,line,line+'\nif(active()){std::ostringstream o;shape(o,q);fprintf(stderr,"WT lemma %s\\n",o.str().c_str());}')
        else:
            line='m_new_instances.push_back(new_inst);';s=change(s,line,line+'\nif(active()){std::ostringstream o;shape(o,q);fprintf(stderr,"WT witness %u native %s\\n",max_generation,o.str().c_str());for(expr*b:bindings){std::ostringstream v;shape(v,b);fprintf(stderr,"WT binding %s\\n",v.str().c_str());}}')
            line='bool model_checker::check(proto_model * md, obj_map<enode, app *> const & root2value) {';s=change(s,line,line+'\nif(active()) fputs("WT candidate\\n",stderr);')
        dst=w/src.name;dst.write_text(hdr+s);obj=dst.with_suffix('.o')
        inc=shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]);subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dst],cwd=build,check=True);subprocess.run(['ar','r',lib,obj],check=True)
    q=front/'smt/quantifier.go';overlay(q,q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=w/(e+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if e=='z3' else 'xtrace_off','-overlay',ov,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'))
