"""Select sets of witness ordinals while retaining both complete solver paths."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
files=json.loads((w/'search-g3.json').read_text())['Replace']
f=Path.cwd()/'smtcore/smt_model_checker.go'
s=Path(files[str(f)]).read_text()
old='skip==strconv.Itoa(n)||skip=="all"'
assert s.count(old)==1
dst=w/'groups-checker.go';dst.write_text(s.replace(old,'strings.Contains(","+skip+",",","+strconv.Itoa(n)+",")||skip=="all"'));files[str(f)]=str(dst)
# Use the original instance record and checker implementation together for this historical observer.
f2=Path.cwd()/'smtcore/smt_model_checker_instances.go'
assert str(f2) in files
ov=w/'groups.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'groups','./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
