from pathlib import Path
import subprocess,json,os
w=Path(__file__).resolve().parent
ex=Path('/home/jaten/ivy/ivy-lang-examples')
cases={'raft':['examples/raft/raft_no_assume_test.ivy','',0],'toy':['examples/ivy/toy_consensus.ivy','',0],'rfn2':['doc/examples/apple/ord_live.ivy','rfn2',0]}
g=w/'proofs';g.mkdir(exist_ok=True);(g/'cases.json').write_text(json.dumps(cases))
for case,(path,iso,rc) in cases.items():
    d=g/'reference'/case;d.mkdir(exist_ok=True,parents=True)
    if case=='toy':
        r=subprocess.run([w.parent/'.operand-cost/split',ex/path],capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=d,timeout=120)
        assert r.returncode==rc,(case,r.stderr);(d/'stdout').write_bytes(r.stdout);(d/'stderr').write_bytes(r.stderr)
    else:
        prev=w.parent/'.bool-scan'/('updated-raft/raft_no_assume_test' if case=='raft' else 'pinned-apple-with-includes/rfn2')/'1/g3'
        for stream in ['stdout','stderr']:(d/stream).write_bytes((prev/stream).read_bytes())
