"""Delegate only a table witness that reused a term in separate argument positions."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
f=p/'smtcore/smt_model_checker.go';s=f.read_text()
old='added, err := c.addFiniteCounterexample(quantifier, bindings)'
assert s.count(old)==1
s=s.replace(old,'''var added bool
distinct:=true
for i,v:=range bindings {for _,u:=range bindings[:i]{if u==v{distinct=false;break}}}
if distinct {added,err=c.addFiniteCounterexample(quantifier, bindings)}''')
dst=w/'diagonal.go';dst.write_text(s);ov=w/'diagonal.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'diagonal','./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
