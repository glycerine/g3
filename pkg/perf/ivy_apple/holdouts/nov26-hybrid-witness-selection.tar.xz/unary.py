"""Try alternatives for a unary counterexample drawn from a later generation."""
from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
for mode in sys.argv[1:]:
    files=json.loads((w/'before.json').read_text())['Replace']
    def save(name,changes):
        f=p/'smtcore'/name;s=Path(files.get(str(f),f)).read_text()
        for a,b in changes:
            assert s.count(a)==1,a
            s=s.replace(a,b)
        dst=w/(mode+'-'+name);dst.write_text(s);files[str(f)]=str(dst)
    select='return lbool.Undef,nil,nil' if mode=='delegate' else 'return lbool.True,[]ast.ASTHandle{v},nil'
    save('smt_model_table.go',[('type tableModel struct {','type tableModel struct {\ntrialFinder *SMTModelFinder\ntrialQuantifier ast.ASTHandle')])
    line='status, bindings, err := c.tableScratch.check(c.manager, model, flat, body, count)'
    save('smt_model_checker.go',[(line,'c.tableScratch.trialFinder=c.modelFinder;c.tableScratch.trialQuantifier=quantifier\n'+line+'\nc.tableScratch.trialFinder=nil;c.tableScratch.trialQuantifier=ast.ASTHandle{}')])
    line='return lbool.True, witness, nil'
    save('smt_model_table_check.go',[('import (','import (\n"slices"'),(line,'''if !bounded && count==1 && flat==g.trialQuantifier && g.trialFinder!=nil {
        _,gen,ok,e:=g.trialFinder.Inverse(flat,0,witness[0]);if e!=nil{return lbool.Undef,nil,e}
        if ok && gen>0 {
            opts,e:=g.trialFinder.InstantiationValues(flat,0);if e!=nil{return lbool.Undef,nil,e}
            for _,v:=range opts {
                id:=g.valueIDs[v];if id==0 || id==bindings[0] || !slices.Contains(domains[0],id) {continue}
                saved:=g.work;alt:=g.evaluate(root,[]int{id},0);ok:=!g.incomplete && g.work>0;g.work=saved;g.incomplete=false
                if !ok {break};if alt==tableFalse {'''+select+'''}
            }
        }
    };'''+line)])
    ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':files}))
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
