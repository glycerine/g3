from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();b=w.parent/'.boolean-enode-cost'
files={}
for name in ['smt_model_checker.go','smt_model_checker_instances.go']:
    dst=w/('base-'+name);dst.write_bytes(subprocess.check_output(['git','show','9d39820e0:pkg/smtcore/'+name]))
    files[str(p/'smtcore'/name)]=str(dst)
(w/'before.json').write_text(json.dumps({'Replace':files}))
if '--cost' in sys.argv:
    files.update(json.loads((w.parent/'.hybrid-obligations/observer.json').read_text())['Replace'])
    ov=w/'base-cost.json';ov.write_text(json.dumps({'Replace':files}))
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'base-cost','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
