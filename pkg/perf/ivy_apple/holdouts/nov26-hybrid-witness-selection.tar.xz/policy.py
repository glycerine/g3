"""Build finite-domain traversal alternatives without changing which tuples are valid."""
from pathlib import Path
import os,sys,subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
for label in sys.argv[1:]:
    maps={}
    f=p/'smtcore/smt_model_table_check.go';s=f.read_text()
    if label=='distinct':
        needle='bindings := make([]int, count)'
        code='''if !bounded {
            for i:=range sorts { for j:=0;j<i;j++ { if sorts[i]==sorts[j] {positions[i]++} };positions[i]%=len(domains[i]) }
        }
        '''
        assert s.count(needle)==1
        s=s.replace(needle,code+needle)
    else:
        # Try the auxiliary restriction order after discovering a real witness.
        # Confirm the alternative independently in the compiled candidate model.
        take='0' if label=='first' else 'len(opts)-1'
        needle='return lbool.True, witness, nil'
        code='''if !bounded && g.trialFinder!=nil && flat==g.trialQuantifier {
            alternate:=append([]int(nil),bindings...);changed:=false
            for pos:=range domains {
                opts,e:=g.trialFinder.InstantiationValues(flat,uint32(pos));if e!=nil {return lbool.Undef,nil,e}
                if len(opts)==0 {continue}; id:=g.valueIDs[opts[CHOICE]]; if id!=0 && slices.Contains(domains[pos],id) {
                    j:=len(bindings)-1-pos;changed=changed || alternate[j]!=id;alternate[j]=id
                }
            }
            if changed {
                saveWork,saveIncomplete:=g.work,g.incomplete
                v:=g.evaluate(root,alternate,0);valid:=!g.incomplete && g.work>0 && v==tableFalse
                g.work,g.incomplete=saveWork,saveIncomplete
                if valid {return lbool.True,g.witness(alternate),nil}
            }
        }
        '''
        assert s.count(needle)==1
        s=s.replace('import (','import (\n"slices"').replace(needle,code.replace('CHOICE',take)+needle)
        for name,needle,repl in [
            ('smt_model_table.go','type tableModel struct {','type tableModel struct {\ntrialFinder *SMTModelFinder\ntrialQuantifier ast.ASTHandle'),
            ('smt_model_checker.go','status, bindings, err := c.tableScratch.check(c.manager, model, flat, body, count)','c.tableScratch.trialFinder=c.modelFinder;c.tableScratch.trialQuantifier=quantifier\nstatus, bindings, err := c.tableScratch.check(c.manager, model, flat, body, count)\nc.tableScratch.trialFinder=nil;c.tableScratch.trialQuantifier=ast.ASTHandle{}')]:
            f2=p/'smtcore'/name;t=f2.read_text();assert t.count(needle)==1
            dst=w/(label+name);dst.write_text(t.replace(needle,repl));maps[str(f2)]=str(dst)
    dst=w/(label+f.name);dst.write_text(s);maps[str(f)]=str(dst)
    ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':maps}))
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
