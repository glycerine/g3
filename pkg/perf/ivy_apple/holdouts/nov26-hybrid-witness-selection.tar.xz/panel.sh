#!/bin/bash
set -eu
work=build/.witness-origin
ref=$1
rounds=$2
shift 2
export GOIVY_INCLUDE=/home/jaten/ivy/ivy-lang-examples/ivy/include
python3 build/.lemma-pairs/verify.py --reference "$ref" --examples /home/jaten/ivy/ivy-lang-examples --cpu 12 --perf /usr/lib/linux-tools/6.17.0-35-generic/perf --rounds "$rounds" "$@"
