"""Try additional concrete counterexamples within the existing per-quantifier budget."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy';maps={}
def edit(name,changes):
    f=p/'smtcore'/name;s=f.read_text()
    for a,b in changes:
        assert s.count(a)==1,a
        s=s.replace(a,b)
    dst=w/('multi-'+name);dst.write_text(s);maps[str(f)]=str(dst)
edit('smt_model_table.go',[('type tableModel struct {','type tableModel struct {\n trialLimit uint32\ntrialWitnesses [][]ast.ASTHandle')])
edit('smt_model_table_check.go',[
('for j := 0; j < tuples; j++ {','for j := 0; j < tuples; j++ {'),
('return lbool.True, witness, nil','''if bounded || g.trialLimit<=1 {return lbool.True,witness,nil}
g.trialWitnesses=append(g.trialWitnesses,witness)
if uint32(len(g.trialWitnesses))>=g.trialLimit {return lbool.True,g.trialWitnesses[0],nil}'''),
('if hasAbstractWitness {','if len(g.trialWitnesses)>0 {return lbool.True,g.trialWitnesses[0],nil};if hasAbstractWitness {'),
('if g.incomplete || g.work <= 0 {\n\t\t\treturn lbool.Undef, nil, nil','if g.incomplete || g.work<=0 {if len(g.trialWitnesses)>0 {return lbool.True,g.trialWitnesses[0],nil};return lbool.Undef,nil,nil'),
('hasAbstractWitness = true','if len(g.trialWitnesses)==0 {hasAbstractWitness=true}')])
edit('smt_model_checker.go',[
('status, bindings, err := c.tableScratch.check(c.manager, model, flat, body, count)','''clear(c.tableScratch.trialWitnesses);c.tableScratch.trialWitnesses=c.tableScratch.trialWitnesses[:0]
c.tableScratch.trialLimit=0
if flat==quantifier && !auxiliary.config.CertifyBoundedModelTables {c.tableScratch.trialLimit=min(8,*remaining)}
status, bindings, err := c.tableScratch.check(c.manager, model, flat, body, count)
defer func(){clear(c.tableScratch.trialWitnesses);c.tableScratch.trialWitnesses=c.tableScratch.trialWitnesses[:0];c.tableScratch.trialLimit=0}()'''),
('if added && len(c.newInstances) > previous {\n\t\t\t\t*remaining--','''if added && len(c.newInstances)>previous {
*remaining--
for i:=1;i<len(c.tableScratch.trialWitnesses) && *remaining>0;i++ {
    mark:=len(c.newInstances)
    added,err:=c.addFiniteCounterexample(quantifier,c.tableScratch.trialWitnesses[i]);if err!=nil{return false,err}
    if added && len(c.newInstances)>mark {*remaining--} else {c.exhausted=exhausted}
}''')])
ov=w/'multi.json';ov.write_text(json.dumps({'Replace':maps}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'multi','./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
