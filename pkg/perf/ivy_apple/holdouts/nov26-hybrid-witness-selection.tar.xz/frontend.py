"""Relink the Go observer with per-batch treatment selection."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;b=w.parent/'.boolean-enode-cost';f=b/'frontend/goivy';src=w/'g3-phase_observer_trial.go'
s=src.read_text()
old='os.Setenv("G3_WITNESS_INDEX","0")'
if 'G3_SKIP_BATCH_' not in s:
    src.write_text(s.replace(old,old+';os.Setenv("G3_SKIP_TABLE",os.Getenv(fmt.Sprintf("G3_SKIP_BATCH_%d",batch)))'))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',w/'g3.json','-o',w/'trial','./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
