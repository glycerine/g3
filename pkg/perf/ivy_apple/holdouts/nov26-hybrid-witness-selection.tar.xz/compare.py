"""Compare signed decisions and emitted instance formulas with anchored symbol names."""
from analyze import *
from itertools import takewhile
w=Path(__file__).resolve().parent
m=names()
def events(name,skip,batch,candidate,key):
    return [r['value'] for r in read(name) if r['skip']==skip and r['batch']==str(batch) and r['candidate']==str(candidate) and r['event']==key]
def report():
    for batch in [35,19]:
        totals=collections.defaultdict(collections.Counter)
        for f in ['search-go.csv','search-native.csv']:
            for r in read(f):
                if r['batch']==str(batch):totals[r['engine'],r['skip'],int(r['candidate'])][r['event']]+=1
        for k,v in totals.items():
            print(batch,*k,*[v[x] for x in ('witness','formula','decision','conflict')])
    for key in ('decision','formula'):
        native=events('search-native.csv','0-0',35,1,key)
        for mode in ['0-0','35-1','35-all']:
            seq=[translate(s,m) for s in events('search-go.csv',mode,35,1,key)]
            n=sum(1 for _ in takewhile(lambda pair:pair[0]==pair[1],zip(native,seq)))
            print(key,mode,'prefix',n,'of',len(seq),len(native),'bag overlap',sum((collections.Counter(seq)&collections.Counter(native)).values()))
            if n<min(len(seq),len(native)):print('first difference',seq[n][:170],native[n][:170])
if __name__=='__main__':report()

def extend(a,b,m):
    trial=m.copy()
    reverse={v:k for k,v in trial.items()}
    left=re.findall(r'\(|\)|[^\s()]+',a)
    right=re.findall(r'\(|\)|[^\s()]+',b)
    if len(left)!=len(right):return False
    for x,y in zip(left,right):
        gx=re.fullmatch(r'(.+)!\d+',x);gy=re.fullmatch(r'(.+)!\d+',y)
        if gx and gy and gx[1]==gy[1]:
            if trial.setdefault(x,y)!=y or reverse.setdefault(y,x)!=x:return False
        elif x!=y:return False
    m.update(trial)
    return True
if __name__=='__main__':
    for kind in ('decision','formula'):
        for mode in ['0-0','35-1','35-all']:
            a=events('search-go.csv',mode,35,1,kind)
            b=events('search-native.csv','0-0',35,1,kind)
            links=names()
            n=sum(1 for _ in takewhile(lambda pair:extend(*pair,links),zip(a,b)))
            print('renamed',kind,mode,n,'of',len(a),len(b),'symbols',len(links))
            if n<min(len(a),len(b)):
                print('tokens at mismatch',[(x,y) for x,y in zip(translate(a[n],links).split(),b[n].split()) if x!=y][:3])
