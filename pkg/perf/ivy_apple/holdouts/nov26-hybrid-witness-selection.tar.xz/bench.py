"""Rotate the reference capture/reset benchmark binaries on a pinned CPU."""
import csv,os,re,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;engines=sys.argv[1:]
out=csv.writer(sys.stdout);out.writerow(['round','engine','width','ns','bytes','allocs'])
for i in range(9):
    for e in engines[i%len(engines):]+engines[:i%len(engines)]:
        r=subprocess.run(['taskset','-c','14',w/(e+'-test'),'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTModelCheckerInstancePins$','-test.benchtime=2000x'],capture_output=True,text=True,check=True)
        rows=re.findall(r'^BenchmarkSMTModelCheckerInstancePins/(\d+)\s+2000\s+([.\d]+) ns/op\s+16.00 instances/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout,re.M)
        assert len(rows)==3,r.stdout
        out.writerows([i+1,e,*row] for row in rows);sys.stdout.flush()
