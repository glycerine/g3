"""Rank check calls by the difference in median solver-thread instructions."""
import csv,statistics,collections,sys
d=collections.defaultdict(list)
for r in csv.DictReader(open(sys.argv[1])):
    d[int(r['batch']),int(r['goal']),r['phase'],r['engine']].append(int(r['instructions']))
for ph in ('check','push'):
    rows=[]
    for b,g in {(b,g) for b,g,p,e in d if p==ph}:
        vals=[statistics.median(d[b,g,ph,e])/1e6 if d[b,g,ph,e] else 0 for e in ['base','g3','z3']]
        rows.append((b,g,*vals))
    print(ph,'totals M',*[round(sum(r[i] for r in rows),1) for i in [2,3,4]])
    for label,delta in [('remaining',lambda r:r[3]-r[4]),('improved',lambda r:r[2]-r[3]),('regressed',lambda r:r[3]-r[2])]:
        print(label,[(r[0:2],*[round(n,1) for n in r[2:]]) for r in sorted(rows,key=delta,reverse=True)[:5]])
