from pathlib import Path
import os,subprocess
w=Path(__file__).resolve().parent
groups=[(w/'proofs',['toy','raft']),(w.parent/'.bool-scan/golden',['hybrid','ticket_protocol','arm_rules3','fba']),(w.parent/'.subtree/current',['test_liveness2','tlb']),(w.parent/'.nov26-value-dependencies/references',['alternating_bit_protocol','gcd2'])]
with (w/'controls.csv').open('w') as out:
    for i,(ref,cases) in enumerate(groups):
        flags=[v for case in cases for v in ['--case',case]]
        r=subprocess.run(['python3',w/'verify.py','--reference',ref,'--examples','/home/jaten/ivy/ivy-lang-examples','--cpu','15','--perf','/usr/lib/linux-tools/6.17.0-35-generic/perf','--rounds','3','--gc','off',*flags,'base='+str(w/'pins'),'release='+str(w/'release')],capture_output=True,text=True,env=dict(os.environ,GOIVY_INCLUDE='/home/jaten/ivy/ivy-lang-examples/ivy/include'))
        out.writelines(r.stdout.splitlines(keepends=True)[1 if i else 0:]);out.flush()
        if r.returncode:raise Exception(r.stderr)
