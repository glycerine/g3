"""Counter repeated unary inverse terms in the same pending model-checker batch."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();b=w.parent/'.boolean-enode-cost';f=b/'frontend/goivy'
def build(label,files):
    ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':files}))
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
for label in ['alternate','delegate','repeat']:
    files=json.loads((w/(('alternate' if label=='repeat' else label)+'.json')).read_text())['Replace']
    if label=='repeat':
        for name,subs in [('smt_model_table.go',[('trialFinder *SMTModelFinder','trialPending []smtModelCheckerInstance\ntrialFinder *SMTModelFinder')]),('smt_model_checker.go',[('c.tableScratch.trialFinder=c.modelFinder','c.tableScratch.trialPending=c.newInstances;c.tableScratch.trialFinder=c.modelFinder'),('c.tableScratch.trialFinder=nil','c.tableScratch.trialPending=nil;c.tableScratch.trialFinder=nil')]),('smt_model_table_check.go',[('_,gen,ok,e:=','term,gen,ok,e:='),('if ok && gen>0 {','''seen:=func(t ast.ASTHandle)bool{for _,inst:=range g.trialPending{if len(inst.bindings)==1 && inst.bindings[0]==t{return true}};return false}
        if ok && gen>0 && seen(term) {'''),('if !ok {break};if alt==tableFalse','if !ok {break};at,_,found,e:=g.trialFinder.Inverse(flat,0,v);if e!=nil{return lbool.Undef,nil,e};if alt==tableFalse && found && !seen(at)')])]:
            dest=p/'smtcore'/name;s=Path(files[str(dest)]).read_text()
            for a,z in subs:assert s.count(a)==1;s=s.replace(a,z)
            target=w/('repeat-'+name);target.write_text(s);files[str(dest)]=str(target)
        build(label,files)
    obs=json.loads((w.parent/'.hybrid-obligations/observer.json').read_text())['Replace']
    build(label+'-cost',dict(obs,**files))
