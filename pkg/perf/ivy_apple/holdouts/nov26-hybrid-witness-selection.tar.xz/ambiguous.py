"""Price auxiliary selection only when scalar enumeration finds alternate witnesses."""
from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
for window in sys.argv[1:]:
    label='amb'+window;f=p/'smtcore/smt_model_table_check.go';s=f.read_text()
    start=s.index('hasAbstractWitness := false')
    end=s.index('if hasAbstractWitness {',start)
    part=s[start:end].replace('for j :=','var first []ast.ASTHandle;stop:=tuples\nfor j :=').replace('j < tuples','j < stop')
    part=part.replace('return lbool.True, witness, nil','''if bounded {return lbool.True,witness,nil}
if first!=nil{return lbool.Undef,nil,nil};first=witness;stop=min(tuples,j+1+WINDOW)'''.replace('WINDOW',str(int(window))))
    part=part.replace('if g.incomplete || g.work <= 0 {','if g.incomplete || g.work <= 0 {if first!=nil{return lbool.True,first,nil};').replace('default:\n\t\t\treturn lbool.Undef','default:\n            if first!=nil{return lbool.True,first,nil};return lbool.Undef')
    s=s[:start]+part+'if first!=nil{return lbool.True,first,nil};'+s[end:]
    dst=w/(label+'.go');dst.write_text(s);ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
