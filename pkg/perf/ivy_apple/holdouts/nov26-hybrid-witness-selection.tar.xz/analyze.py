"""Group consecutive model witnesses with their bindings, and compare candidate epochs."""
import csv,collections,re,statistics,sys
from pathlib import Path
w=Path(__file__).resolve().parent
def read(name):
    with (w/name).open() as src:return list(csv.DictReader(src))
def trace(name):
    groups=collections.defaultdict(lambda:[[],collections.Counter()])
    for r in read(name):
        k=(r['engine'],r['skip'],int(r['batch']),int(r['candidate']))
        ws,lem=groups[k];v=r['value']
        if r['event']=='witness':
            generation,origin,q=v.split(' ',2);ws.append((q,int(generation),origin,[]))
        elif r['event']=='binding':ws[-1][3].append(v)
        elif r['event']=='lemma':lem[v]+=1
    return groups
def names():
    prev=w.parent/'.lemma-pairs'
    pairs={}
    for a,b in zip(csv.DictReader((prev/'g3-tree.csv').open()),csv.DictReader((prev/'z3-tree.csv').open()),strict=True):
        for x,y in zip(re.findall(r'[^\s()]+',a['expression']),re.findall(r'[^\s()]+',b['expression']),strict=True):
            if x!=y:
                assert pairs.setdefault(x,y)==y
    return pairs
def translate(s,m):
    return re.sub(r'[^\s()]+',lambda t:m.get(t[0],t[0]),s)
if __name__=='__main__':
    allgroups={}
    for name in sys.argv[1:]:allgroups.update(trace(name))
    for k,(ws,lems) in allgroups.items():
        print(k,'witnesses',len(ws),'lemmas',sum(lems.values()))
        if k[-1]==1 and k[1] in ('0','0-0'):print('first',ws[0] if ws else None)
