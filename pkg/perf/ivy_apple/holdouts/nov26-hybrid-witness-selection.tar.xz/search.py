"""Observe decisions, conflicts and complete emitted clauses after candidate checks."""
from pathlib import Path
import json,os,re,shlex,shutil,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy';e=sys.argv[1]
files=json.loads((w/(e+'.json')).read_text())['Replace']
def sub(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(f,s):
    dst=w/('search-'+e+'-'+f.name);dst.write_text(s);files[str(f)]=str(dst)
if e=='g3':
    f=p/'smtcore/smt_model_checker.go';s=Path(files[str(f)]).read_text()
    save(f,sub(s,'if witnessTrace(){println("WT candidate")}', 'if witnessTrace(){trialOwner=c.state;println("WT candidate")}')+'\nvar trialOwner *SMTInternalizerState\n')
    for name,mark,hook in [
        ('smt_search','k.internalizer.statistics.NumDecisions++','if k.internalizer==trialOwner && witnessTrace(){println("WT decision",smtDecisionLiteral(variable,phase).Sign(),witnessTree(k.manager,k.internalizer.boolExpr[variable]))}'),
        ('smt_conflict_resolver','r.state.statistics.NumConflicts++','if r.state==trialOwner && witnessTrace(){println("WT conflict")}'),
        ('smt_quantifier_manager','lemma, lemmaErr := instance.Lemma()','if witnessTrace() && lemmaErr==nil {println("WT formula",witnessTree(q.state.manager,lemma))}')]:
        f=p/('smtcore/'+name+'.go');s=Path(files.get(str(f),f)).read_text();save(f,sub(s,mark,mark+'\n'+hook))
else:
    build=p.parent/'build';flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
    inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    d=w/'search-native';d.mkdir(exist_ok=True);lib=d/'lib.a';shutil.copyfile(w/'libwitness.a',lib)
    hdr=(w/'qi_queue.cpp').read_text().split('/*++')[0]
    for name in ('smt_model_checker','smt_context','qi_queue'):
        f=p.parent/('src/smt/'+name+'.cpp')
        if name=='smt_context':
            s=hdr+'extern const void* witness_owner;\n'+f.read_text()
            mark='assign(literal(var, !is_pos), b_justification::mk_axiom(), true);'
            s=sub(s,mark,'if(active() && witness_owner==this){std::ostringstream o;shape(o,bool_var2expr(var));fprintf(stderr,"WT decision %s %s\\n",is_pos?"false":"true",o.str().c_str());}\n'+mark)
            s=sub(s,'m_stats.m_num_conflicts++;','m_stats.m_num_conflicts++;if(active() && witness_owner==this) fputs("WT conflict\\n",stderr);')
        elif name=='smt_model_checker':
            s='const void* witness_owner=nullptr;\n'+(w/f.name).read_text();s=sub(s,'if(active()) fputs("WT candidate\\n",stderr);','if(active()){witness_owner=m_context;fputs("WT candidate\\n",stderr);}')
        else:
            s=(w/f.name).read_text();mark='m_context.internalize_instance(lemma, pr1, gen);';s=sub(s,mark,'if(active()){std::ostringstream o;shape(o,lemma);fprintf(stderr,"WT formula %s\\n",o.str().c_str());}\n'+mark)
        dst=d/f.name;dst.write_text(s);obj=dst.with_suffix('.o')
        subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dst],cwd=build,check=True);subprocess.run(['ar','r',lib,obj],check=True)
    q=front/'smt/quantifier.go';save(q,q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
ov=w/('search-'+e+'.json');ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if e=='z3' else 'xtrace_off','-overlay',ov,'-o',w/('search-'+e),'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
