from pathlib import Path
import os,json,subprocess,csv,time
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();a=p/'smtcore/smt_model_checker.go';s=a.read_text().replace('import (','import (\n"os"',1) if '"os"' not in a.read_text() else a.read_text()
s=s.replace('if auxiliary.config.SkipTrivialMBQIChecks &&','if (auxiliary.config.SkipTrivialMBQIChecks || studyTrue) &&');k='if added || incomplete {';assert s.count(k)==1
i=s.index('if err = c.reportQuantifier("failed"',s.index(k));end=s.index('\n\t\t}',i);s=s[:end]+'\n if added && studyCap>0 && failures>=studyCap {break}'+s[end:]
s+='\nvar studyTrue=os.Getenv("MACRO_OPTION")=="true"\nvar studyCap=map[string]uint32{"one":1,"four":4}[os.Getenv("MACRO_OPTION")]\n'
b=w/'model.go';b.write_text(s);ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());ov['Replace'][str(a)]=str(b);j=w/'model.json';j.write_text(json.dumps(ov));exe=w/'model'
subprocess.run(['go','build','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
s=(w/'depth.py').read_text().split("ex=Path('/home/jaten/ivy/ivy-lang-examples')")[1];s="ex=Path('/home/jaten/ivy/ivy-lang-examples')"+s
i=s.index('  r=subprocess.run([exe,ex/name]');end=s.index('  failed=set()',i);s=s[:i]+s[end:];s=s.replace('depth.csv','model.csv').replace('depth.stat','model.stat').replace('[0,3,5,8,12]',"['','true','one','four']").replace('MACRO_DEPTH=str(n)','MACRO_OPTION=n');exec(s)
