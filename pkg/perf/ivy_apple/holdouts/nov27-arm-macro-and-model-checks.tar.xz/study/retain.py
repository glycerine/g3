from pathlib import Path
p=Path('smtcore/smt_model_checker.go');s=Path('/tmp/g3-arm-pass/temps.go').read_text();i=s.index('var evaluated, ground, negatedRef');j=s.index('ok, err := model.Eval',i)
s=s[:i]+'''evaluated, err := c.manager.NewRef(ast.ASTHandle{})
	if err != nil {return false, err}
	defer func() {
		if evaluated != (ast.ASTRef{}) {result = errors.Join(result,c.manager.DelRef(&evaluated))}
	}()
	'''+s[j:]
i=s.index('ground, err = c.manager.NewRef',s.index('func (c *SMTModelChecker) auxiliaryCounterexamples'));j=s.index('status, err := auxiliary.CheckSat',i)
s=s[:i]+'''if err = c.assertNegatedModelBody(auxiliary, evaluatedBody, skolems); err != nil {
		return false, err
	}
	if err = c.manager.DelRef(&evaluated); err != nil {
		return false, err
	}
	'''+s[j:]
i=s.index('// errSMTModelCheckerUnevaluatedQuantifier');s=s[:i]+'''// assertNegatedModelBody releases the instantiated body, substitution and
// negation before the auxiliary solver checks its new assertion.
func (c *SMTModelChecker) assertNegatedModelBody(auxiliary *SMTSolver, body ast.ASTHandle, skolems []ast.ASTHandle) (result error) {
	ground, err := c.manager.NewRef(ast.ASTHandle{})
	if err != nil {return err}
	defer func() {result = errors.Join(result,c.manager.DelRef(&ground))}()
	substitution, err := rewriter.NewVarSubstitution(c.manager, true)
	if substitution != nil {
		defer func() {result = errors.Join(result,substitution.Close())}()
	}
	if err != nil {return err}
	if err = substitution.Substitute(body,skolems,ground); err != nil {return err}
	groundBody, err := c.manager.RefGet(ground)
	if err != nil {return err}
	negated, err := c.manager.MkNot(groundBody)
	if err != nil {return err}
	ref, err := c.manager.NewRef(negated)
	if err != nil {return err}
	defer func() {result = errors.Join(result,c.manager.DelRef(&ref))}()
	return auxiliary.Assert(negated)
}

'''+s[i:]
p.write_text(s)
