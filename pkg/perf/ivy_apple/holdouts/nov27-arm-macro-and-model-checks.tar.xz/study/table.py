from pathlib import Path
import subprocess,json,os,csv
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());a=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(a)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";',1)
s=s.replace('s.showVCsBase(clauses)','s.showVCsBase(clauses);studyBatch++; batch:=studyBatch',1)+'\nvar studyBatch int\n'
key='res, err := s.decideZ3With(z3solver, finalCheck)';s=s.replace(key,'smtcore.StudyBatch=batch;smtcore.StudyGoal=index+1\n'+key+'\nsmtcore.StudyBatch=0')
b=w/'table-bridge.go.txt';b.write_text(s);ov['Replace'][str(a)]=str(b)
a=p/'smtcore/smt_model_table_check.go';s=a.read_text();i=s.index('func (g *tableModel) check(');j=s.index('func (g *tableModel) witness',i);pre,t,post=s[:i],s[i:j],s[j:]
t=t.replace('(lbool.LBool, []ast.ASTHandle, error) {','(st lbool.LBool, bind []ast.ASTHandle, cause error) {\n reason:="sort"; if StudyBatch!=0 { end:=startStage(StudyBatch,StudyGoal); defer func(){end(reason);println("TABLE",StudyBatch,StudyGoal,reason,int(st),count)}() }',1)
for key,why in [('root, err := g.compile','compile'),('domains := make','domain'),('if len(g.integers)','small-int'),('status, witness := g.checkDiagram','diagram'),('g.work = 100000','enumerate')]:t=t.replace(key,'reason="'+why+'"\n '+key,1)
b=w/'table-check.go';b.write_text(pre+t+post);ov['Replace'][str(a)]=str(b)
a=p/'smtcore/measure_table.go';b=w/'measure-table.go';b.write_text(Path('/tmp/g3-live-numeral/ticket/phase_observer_trial.go.txt').read_text().replace('package goivy','package smtcore')+'\nvar StudyBatch, StudyGoal int\n');ov['Replace'][str(a)]=str(b)
j=w/'table.json';j.write_text(json.dumps(ov));exe=w/'table'
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows')
with (w/'tables.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case round batch goal phase result arity instructions'.split())
 for nr in [4,2,3,6]:
  case=(ref/'compat.txt').read_text().splitlines()[nr-1];d=ref/'compat'/str(nr)/'1/native'
  for i in range(3):
   r=subprocess.run(['taskset','-c','24',exe,ex/case],env=dict(os.environ,GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),cwd=w,capture_output=True,check=True);keep=[];rec=None
   for l in r.stderr.splitlines(keepends=True):
    a=l.split()
    if l.startswith(b'STAGE-COUNT '):assert rec is None and a[6]==a[7]; rec=a
    elif l.startswith(b'TABLE '):assert rec[1:4]==a[1:4];o.writerow([nr,i,int(a[1]),int(a[2]),a[3].decode(),int(a[4]),int(a[5]),int(rec[4])]);rec=None
    else:keep.append(l)
   assert rec is None and (r.stdout,b''.join(keep))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes());f.flush()
