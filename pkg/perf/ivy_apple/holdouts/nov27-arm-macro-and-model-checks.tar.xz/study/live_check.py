from pathlib import Path
import os,subprocess,json,collections,csv,re
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();a=front/'z3bridge_solver_model.go';ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());s=Path(ov['Replace'][str(a)]).read_text();k='s.showVCsBase(clauses)';s=s.replace(k,k+';studyBatch++;batch:=studyBatch',1);k='res, err := s.decideZ3With(z3solver, finalCheck)';s=s.replace(k,'gate:=batch==8 && index==0; if gate {studyGate("enable")}\n'+k+'\nif gate {studyGate("disable")}',1)
s+='''
var studyBatch int
func studyGate(op string){ctl,e:=os.OpenFile("/tmp/g3-arm-pass/control",os.O_WRONLY,0);if e!=nil{panic(e)}; ack,e:=os.Open("/tmp/g3-arm-pass/ack");if e!=nil{panic(e)}
 ctl.WriteString(op+"\\n");var buf [32]byte;ack.Read(buf[:]);ack.Close();ctl.Close()}
'''
b=w/'live-check.go.txt';b.write_text(s);ov['Replace'][str(a)]=str(b);j=w/'live-check.json';j.write_text(json.dumps(ov));ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows/compat/4/1/native');perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'live-check.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','stack','samples'])
 for en,tags,unwind in [('g3','xtrace_off','fp,55'),('native','xtrace_off,classic_z3','dwarf,8192')]:
  exe=w/('live-'+en);subprocess.run(['go','build','-tags',tags,'-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
  c=collections.Counter()
  for i in range(6):
   data=w/'check.data'
   r=subprocess.run(['taskset','-c','22',perf,'record','-D','-1','--control=fifo:/tmp/g3-arm-pass/control,/tmp/g3-arm-pass/ack','-q','-B','-e','instructions:u','-c','320003','--call-graph',unwind,'-o',data,exe,ex/'test/arm_rules3.ivy'],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=True,timeout=30)
   assert r.stdout==(ref/'stdout').read_bytes() and all(x in [b'Events enabled',b'Events disabled'] for x in r.stderr.splitlines()),r.stderr
   raw=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',data],text=True)
   for block in raw.strip().split('\n\n'):
    if len(block.splitlines())>1:c['\n'.join(re.sub(r'^\s*[0-9a-f]+\s+','',l).strip() for l in block.splitlines()[1:])]+=1
  out.writerows([en,k,n] for k,n in c.items());f.flush()
