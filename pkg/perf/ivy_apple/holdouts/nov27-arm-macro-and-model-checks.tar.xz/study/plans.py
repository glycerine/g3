from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
def edit(name,*pairs):
 a=p/name;s=a.read_text()
 for before,after in pairs:
  assert s.count(before)==1,before;s=s.replace(before,after)
 g=w/('plan-'+a.name);g.write_text(s);ov['Replace'][str(a)]=str(g)
edit('ast/macros/macro_manager.go',('"reflect"','"reflect"\n"github.com/glycerine/g3/pkg/ast/rewriter"'),('type Manager struct {','type Manager struct {\n studyPlans *rewriter.GroundInstancePlans'))
edit('ast/macros/macro_finder.go',('current, err := NewFormulaBatch(f.manager)','''var plans rewriter.GroundInstancePlans
 plans.AllowOpenBindings=true
 f.macros.studyPlans=&plans
 defer func(){f.macros.studyPlans=nil;result=errors.Join(result,plans.Clear())}()
 current, err := NewFormulaBatch(f.manager)'''),('import (','import (\n"github.com/glycerine/g3/pkg/ast/rewriter"') if '"github.com/glycerine/g3/pkg/ast/rewriter"' not in (p/'ast/macros/macro_finder.go').read_text() else ('package macros','package macros'))
edit('ast/macros/macro_expander.go',('if err = substitution.Substitute(definition, arguments, replacement); err != nil {','''if c.owner.studyPlans!=nil { err=c.owner.studyPlans.Substitute(substitution,definition,arguments,replacement) } else { err=substitution.Substitute(definition,arguments,replacement) }
 if err!=nil {'''))
edit('ast/rewriter/ground_instance.go',('type GroundInstancePlans struct {','type GroundInstancePlans struct {\n AllowOpenBindings bool'),('!plan.bind(m, bindings)','!plan.bind(m, bindings,c.AllowOpenBindings)'),('bind(m *ast.ASTManager, bindings []ast.ASTHandle)','bind(m *ast.ASTManager, bindings []ast.ASTHandle,open bool)'),('if ground, err := m.IsGround(h); err != nil || !ground {\n\t\t\treturn false\n\t\t}', 'if !open {if ground, err := m.IsGround(h); err != nil || !ground {return false}}'))
j=w/'plans.json';j.write_text(json.dumps(ov))
subprocess.run(['go','build','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'plans','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
