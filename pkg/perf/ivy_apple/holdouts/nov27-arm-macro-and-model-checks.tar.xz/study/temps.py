from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'smtcore/smt_model_checker.go';s=a.read_text()
start=s.index('var temporaries []func() error');end=s.index('ok, err := model.Eval',start)
s=s[:start]+'''var evaluated, ground, negatedRef ast.ASTRef
	var substitution *rewriter.VarSubstitution
	releaseTemporaries := func() (err error) {
		if negatedRef != (ast.ASTRef{}) { err = c.manager.DelRef(&negatedRef) }
		if substitution != nil { err = errors.Join(err,substitution.Close()); substitution = nil }
		if ground != (ast.ASTRef{}) { err = errors.Join(err,c.manager.DelRef(&ground)) }
		if evaluated != (ast.ASTRef{}) { err = errors.Join(err,c.manager.DelRef(&evaluated)) }
		return err
	}
	defer func() { result = errors.Join(result, releaseTemporaries()) }()
	evaluated, err = c.manager.NewRef(ast.ASTHandle{})
	if err != nil {return false,err}
	'''+s[end:]
i=s.index('func (c *SMTModelChecker) auxiliaryCounterexamples');pre,t=s[:i],s[i:];t=t.replace('ground, err := c.manager.NewRef','ground, err = c.manager.NewRef',1).replace('holdTemporary(ground)','',1).replace('substitution, err := rewriter.NewVarSubstitution','substitution, err = rewriter.NewVarSubstitution',1).replace('if substitution != nil {\n\t\ttemporaries = append(temporaries, substitution.Close)\n\t}', '',1).replace('negatedRef, err := c.manager.NewRef','negatedRef, err = c.manager.NewRef',1).replace('holdTemporary(negatedRef)','',1)
t=t.replace('values := make([]ast.ASTHandle, count)\n\t','',1).replace('skolemDecls := make([]ast.ASTHandle, len(skolems))\n\t','',1).replace('skolems := make([]ast.ASTHandle, count)\n\tskolemRefs := make([]ast.ASTRef, 0, len(skolems))','var skolemRefs []ast.ASTRef',1)
t=t.replace('for i := len(skolems) - 1;','skolems := make([]ast.ASTHandle, count)\n skolemRefs=make([]ast.ASTRef,0,count)\n for i := len(skolems) - 1;',1).replace('skolemDecls[i], e = c.manager.GetDecl(skolems[i])\n\t\tif e != nil {\n\t\t\treturn false, e\n\t\t}\n\t\t','',1)
t=t.replace('first := complete','values := make([]ast.ASTHandle, count)\n skolemDecls:=make([]ast.ASTHandle,count)\n for i,h:=range skolems {skolemDecls[i],err=c.manager.GetDecl(h);if err!=nil{return false,err}}\n first := complete',1)
g=w/'temps.go';g.write_text(pre+t);subprocess.run(['gofmt','-w',g],check=True)
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());ov['Replace'][str(a)]=str(g);j=w/'temps.json';j.write_text(json.dumps(ov))
for name,flags in [('before',[]),('temps',['-overlay',j])]:subprocess.run(['go','test',*flags,'-c','-o',w/(name+'.test'),'./smtcore'],check=True)
for i in range(5):
 for name in ['before','temps'][::1 if i%2==0 else -1]:
  with (w/(name+'-bench.txt')).open('a') as f:subprocess.run(['taskset','-c','22',w/(name+'.test'),'-test.run=^$','-test.bench=^BenchmarkSMTAuxiliaryIdentityQuery$','-test.benchtime=250ms'],stdout=f,check=True)
subprocess.run(['go','build','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'temps','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
