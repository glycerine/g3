from pathlib import Path
import os,subprocess,csv,json,collections
w=Path(__file__).resolve().parent;p=Path.cwd();ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows')
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
def edit(a,s):
 g=w/a.name;g.write_text(s);ov['Replace'][str(a)]=str(g)
a=p/'smtcore/smt_kernel.go';edit(a,a.read_text().replace('k.simplifyInitialPushOnce = false','defer studyScope()()\n k.simplifyInitialPushOnce = false'))
a=p/'smtcore/smt_asserted_driver.go';k='if err := assertedVerbose(10, "(smt."+pass';edit(a,a.read_text().replace(k,'if studyactive {defer studyPass(pass.sourceName(),len(k.assertions)-k.assertedHead)()}\n '+k))
ov['Replace'][str(p/'smtcore/first_push_meter.go')]='/tmp/g3-first-push-frontier/measure-first_push_meter.go'
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();a=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(a)]).read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');pre,s=s[:i],s[i:];s=s.replace('s.showVCsBase(clauses)','s.showVCsBase(clauses)\n studyBatch++; batch:=studyBatch',1).replace('z3solver.Push()','println("ARM-PUSH",batch,index+1); z3solver.Push()',1);edit(a,pre+'var studyBatch int\n'+s)
j=w/'meter.json';j.write_text(json.dumps(ov))
subprocess.run(['go','build','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'meter','./cmd/goivy_check'],cwd=front,check=True)
with (w/'passes.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case round engine batch goal pass instructions'.split())
 for nr in [4,2]:
  name=(ref/'compat.txt').read_text().splitlines()[nr-1];d=ref/'compat'/str(nr)/'1/native'
  for i in range(3):
   for engine,exe in [('g3',w/'meter'),('native',Path('/tmp/g3-first-push-frontier/native'))][::1 if i%2==0 else -1]:
    r=subprocess.run(['taskset','-c','20',exe,ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=True);keep=[];pending=[]
    for l in r.stderr.splitlines(keepends=True):
     a=l.split()
     if l.startswith(b'ARM-PUSH '):batch,goal=a[1:]
     elif l.startswith(b'IVY-PUSH-PASS '):o.writerow([nr,i,engine,int(batch),int(goal),a[2].decode(),int(a[4])])
     elif l.startswith(b'IVY-PUSH-TOTAL '):o.writerow([nr,i,engine,int(batch),int(goal),'TOTAL',int(a[2])])
     elif l.startswith(b'IVY-PUSH-STAGE '):pass
     elif l.startswith(b'PASS-COUNT '):
      assert a[4]==a[5];pending.append((a[1].decode(),int(a[2])))
     elif l.startswith(b'STAGE-COUNT '):
      assert a[6]==a[7]
      if a[3]==b'first':
       for k,n in pending+[('TOTAL',int(a[4]))]:o.writerow([nr,i,engine,int(a[1]),int(a[2]),k,n])
      else:assert not pending
      pending=[]
     else:keep.append(l)
    assert not pending and (r.stdout,b''.join(keep))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes()),keep[:4];f.flush()
