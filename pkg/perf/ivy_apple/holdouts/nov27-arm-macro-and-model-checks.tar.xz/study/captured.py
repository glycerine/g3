from pathlib import Path
import subprocess,os,csv,re
w=Path(__file__).resolve().parent
with (w/'arith-replay.csv').open('w') as f:
 o=csv.writer(f);o.writerow('query mode engine round answer instructions decisions conflicts instances rlimit'.split())
 for src in sorted((w/'captures').glob('*.smt2')):
  txt='(set-option :smt.macro_finder true)\n'+src.read_text();parts=txt.split('\n(assert ');assert len(parts)==3
  for mode in ['fresh','push']:
   text=parts[0]+'\n(assert '+parts[1]+('\n(push 1)' if mode=='push' else '')+'\n(assert '+parts[2]
   for i in range(3):
    for engine,exe in [('g3',Path('/tmp/g3-assert-op/cli-base')),('z3',Path.cwd().parent/'build/z3')][::1 if i%2==0 else -1]:
     st=w/'arith-replay.stat';r=subprocess.run(['taskset','-c','24','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-e','instructions:u','-o',st,'--',exe,'-in','-smt2'],input=text.encode(),env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,timeout=8)
     assert r.returncode==0 and not r.stderr and r.stdout.startswith(b'unsat\n') and b'(error' not in r.stdout
     m=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));ins=next(int(z[0]) for z in csv.reader(st.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100);o.writerow([src.stem,mode,engine,i,'unsat',ins,*[m.get(k,0) for k in ['decisions','conflicts','quant-instantiations','rlimit-count']]]);f.flush()
