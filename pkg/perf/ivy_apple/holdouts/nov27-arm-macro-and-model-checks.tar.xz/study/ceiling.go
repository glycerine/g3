package smtcore

// Source: src/smt/asserted_formulas.cpp propagate_values(),
// update_substitution(), is_gt(), and compute_depth().

import ("os";
	"errors"
	"io"
	"math"

	"github.com/glycerine/g3/pkg/ast"
)

func (k *SMTKernel) assertedRelation(h ast.ASTHandle) (ast.ASTHandle, ast.ASTHandle, bool, error) {
	op, basic, err := k.internalizer.basicOperation(h)
	if err != nil || !basic || op != ast.ASTOpEq && op != ast.ASTOpIff {
		return ast.ASTHandle{}, ast.ASTHandle{}, false, err
	}
	left, err := k.manager.GetArg(h, 0)
	if err != nil {
		return ast.ASTHandle{}, ast.ASTHandle{}, false, err
	}
	right, err := k.manager.GetArg(h, 1)
	return left, right, err == nil, err
}

// assertedGroundDepth receives a side of a ground equality or one of its
// children. With no quantifiers, the arena's cached depth uses the same
// recurrence. Expand saturated nodes to recover the exact ordering.
func (k *SMTKernel) assertedGroundDepth(h ast.ASTHandle, cache map[ast.ASTHandle]uint32) (uint32, error) {
	depth, err := k.manager.GetDepth(h)
	if err != nil || depth < math.MaxUint16 {
		return depth, err
	}
	if value, found := cache[h]; found {
		return value, nil
	}
	count, err := k.manager.GetNumArgs(h)
	if err != nil {
		return 0, err
	}
	depth = 1
	for i := uint32(0); i < count; i++ {
		child, err := k.manager.GetArg(h, i)
		if err != nil {
			return 0, err
		}
		childDepth, err := k.assertedGroundDepth(child, cache)
		if err != nil {
			return 0, err
		}
		depth = max(depth, childDepth+1)
	}
	cache[h] = depth
	return depth, nil
}

func (k *SMTKernel) assertedGreater(left, right ast.ASTHandle, depth map[ast.ASTHandle]uint32) (bool, error) {
	if left == right {
		return false, nil
	}
	lv, err := k.manager.IsValue(left)
	if err != nil {
		return false, err
	}
	rv, err := k.manager.IsValue(right)
	if err != nil {
		return false, err
	}
	if lv != rv {
		return !lv, nil
	}
	if err := k.assertedSourceAssertion(545, "is_ground(lhs) && is_ground(rhs)", func() (bool, error) {
		leftGround, err := k.manager.IsGround(left)
		if err != nil || !leftGround {
			return false, err
		}
		return k.manager.IsGround(right)
	}); err != nil {
		return false, err
	}
	ld, err := k.assertedGroundDepth(left, depth)
	if err != nil {
		return false, err
	}
	rd, err := k.assertedGroundDepth(right, depth)
	if err != nil || ld != rd {
		return ld > rd, err
	}
	lk, err := k.manager.GetKind(left)
	if err != nil {
		return false, err
	}
	rk, err := k.manager.GetKind(right)
	if err != nil || lk != ast.ASTApp || rk != ast.ASTApp {
		return false, err
	}
	ldec, err := k.manager.GetDecl(left)
	if err != nil {
		return false, err
	}
	rdec, err := k.manager.GetDecl(right)
	if err != nil {
		return false, err
	}
	lid, err := k.manager.GetASTID(ldec)
	if err != nil {
		return false, err
	}
	rid, err := k.manager.GetASTID(rdec)
	if err != nil || lid != rid {
		return lid > rid, err
	}
	count, err := k.manager.GetNumArgs(left)
	if err != nil {
		return false, err
	}
	rcount, err := k.manager.GetNumArgs(right)
	if err != nil || count != rcount {
		return count > rcount, err
	}
	for i := uint32(0); i < count; i++ {
		la, err := k.manager.GetArg(left, i)
		if err != nil {
			return false, err
		}
		ra, err := k.manager.GetArg(right, i)
		if err != nil {
			return false, err
		}
		if la != ra {
			return k.assertedGreater(la, ra, depth)
		}
	}
	if err := k.assertedSourceAssertion(563, "UNREACHABLE", func() (bool, error) { return false, nil }); err != nil {
		return false, err
	}
	return false, nil
}

func (k *SMTKernel) addAssertionSubstitution(assertion SMTKernelAssertion, depth map[ast.ASTHandle]uint32) error {
	proofs, err := k.manager.ProofsEnabled()
	if err != nil {
		return err
	}
	ground, err := k.manager.IsGround(assertion.Formula)
	if err != nil {
		return err
	}
	if ground {
		left, right, relation, err := k.assertedRelation(assertion.Formula)
		if err != nil {
			return err
		}
		if relation {
			if greater, err := k.assertedGreater(left, right, depth); err != nil {
				return err
			} else if greater {
				if err = k.traceAssertedRewrite(506, "insert ", left, right); err != nil {
					return err
				}
				return k.manager.ScopedExprSubstitutionInsert(k.assertedScopedSubst, left, right, assertion.Proof, ast.ASTDependency{})
			}
			if greater, err := k.assertedGreater(right, left, depth); err != nil {
				return err
			} else if greater {
				if err = k.traceAssertedRewrite(511, "insert ", right, left); err != nil {
					return err
				}
				// m.proofs_enabled() ? m.mk_symmetry(pr) : nullptr
				proof := ast.ASTHandle{}
				if proofs {
					proof, err = k.manager.MkProofSymmetry(assertion.Proof)
					if err != nil {
						return err
					}
				}
				return k.manager.ScopedExprSubstitutionInsert(k.assertedScopedSubst, right, left, proof, ast.ASTDependency{})
			}
			// The source only traces here and falls through to n -> true.
			if err = k.traceAssertedExpression("propagate_values", "update_substitution", 515, "incompatible ", assertion.Formula); err != nil {
				return err
			}
		}
	}
	key := assertion.Formula
	value, err := k.manager.MkTrue()
	if err != nil {
		return err
	}
	// pr1 = m.proofs_enabled() ? m.mk_iff_{false,true}(pr) : nullptr
	proof := ast.ASTHandle{}
	if isNot, child, err := k.manager.IsNot(assertion.Formula); err != nil {
		return err
	} else if isNot {
		key = child
		value, err = k.manager.MkFalse()
		if err != nil {
			return err
		}
		if proofs && !assertion.Proof.IsNull() {
			proof, err = k.manager.MkProofIffFalse(assertion.Proof)
		}
	} else if proofs && !assertion.Proof.IsNull() {
		proof, err = k.manager.MkProofIffTrue(assertion.Proof)
	}
	if err != nil {
		return err
	}
	if proof.IsNull() || proof == assertion.Proof {
		return k.manager.ScopedExprSubstitutionInsert(k.assertedScopedSubst, key, value, proof, ast.ASTDependency{})
	}
	// proof_ref pr1 owns the new iff proof; it dies when the call returns,
	// so a proof the substitution does not keep is freed there.
	pr1, err := k.manager.NewRef(proof)
	if err != nil {
		return err
	}
	return errors.Join(k.manager.ScopedExprSubstitutionInsert(k.assertedScopedSubst, key, value, proof, ast.ASTDependency{}), k.manager.DelRef(&pr1))
}

func (k *SMTKernel) rewritePendingAssertion(index int) (bool, error) {
	old := k.assertions[index]
	formula, proof, err := k.preprocessAssertionMode(old.Formula, old.Proof, assertedProofAlways)
	if err != nil {
		return false, err
	}
	if k.manager.IsFalse(formula) {
		k.assertedInconsistent = true
	}
	// propagate_values(i) replaces m_formulas[i] with (new_n, new_pr) even
	// when new_n == n: new_pr is mp(pr, new_pr) with proofs, else the
	// rewriter's own proof (a reflexivity when it generates proofs).
	if formula == old.Formula && !(k.preprocess && proof != old.Proof) {
		if k.preprocess {
			err = k.manager.DecRef(formula)
			if !proof.IsNull() {
				err = errors.Join(err, k.manager.DecRef(proof))
			}
		}
		return false, err
	}
	changed := formula != old.Formula
	if !old.Proof.IsNull() {
		err = k.manager.DecRef(old.Proof)
	}
	err = errors.Join(err, k.manager.DecRef(old.Formula))
	k.assertions[index] = SMTKernelAssertion{Formula: formula, Proof: proof}
	return changed, err
}

func (k *SMTKernel) propagatePendingAssertions() (result error) {
	if !k.preprocess || !k.preprocessState.PropagateValues || k.preprocessor == nil {
		return nil
	}
	if err := k.flushAssertedCache(); err != nil {
		return err
	}
	if k.assertedInconsistent {
		return nil
	}
	// Source ++num_iterations < 2 permits one forward/reverse pair on the
	// persistent substitution. Temporary bindings die at each direction pop.
	changed := false
	for _, reverse := range []bool{false, true} {
		if err := k.manager.ScopedExprSubstitutionPush(k.assertedScopedSubst); err != nil {
			return err
		}
		label, line := "before:\n", 451
		if reverse {
			label, line = "middle:\n", 461
		}
		if err := k.traceAssertedBody("propagate_values", "propagate_values", line, func(out io.Writer) error {
			if _, err := io.WriteString(out, label); err != nil {
				return err
			}
			return k.DisplayAssertedFormulas(out)
		}); err != nil {
			if reverse {
				return errors.Join(err, k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1), k.flushAssertedCache())
			}
			return errors.Join(err, k.flushAssertedCache(), k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1))
		}
		func() {
			defer func() {
				if reverse {
					result = errors.Join(result, k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1), k.flushAssertedCache())
				} else {
					// Source forward cleanup flushes before popping; reverse
					// cleanup pops before its final flush.
					result = errors.Join(result, k.flushAssertedCache(), k.manager.ScopedExprSubstitutionPop(k.assertedScopedSubst, 1))
				}
			}()
			depth := make(map[ast.ASTHandle]uint32)
			for step := 0; step < len(k.assertions)-k.assertedHead && result == nil; step++ {
				i := k.assertedHead + step
				if reverse {
					i = len(k.assertions) - 1 - step
				}
				var one bool
				skip:=reverse && studyRow<len(studyEligible) && studyEligible[studyRow]=='1'
 if reverse {studyRow++}
 if !skip {one, result = k.rewritePendingAssertion(i)}
				changed = changed || one
				if result == nil {
					result = k.addAssertionSubstitution(k.assertions[i], depth)
				}
			}
		}()
		if result != nil {
			return result
		}
		if reverse {
			if err := k.traceAssertedBody("propagate_values", "propagate_values", 469, func(out io.Writer) error {
				if _, err := io.WriteString(out, "after:\n"); err != nil {
					return err
				}
				return k.DisplayAssertedFormulas(out)
			}); err != nil {
				return err
			}
		}
	}
	if changed {
		return k.reducePendingAssertions()
	}
	return nil
}

var studyRow int
var studyEligible=map[string]string{"2":"11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111101001111111111111111111111111100111001111111111111111111111111111111111111111111111111111111111111111111111111001110011111111111111111111111111111111111111111111111111111111111111111111111111111111111000001010000010000101011101111110001111111000010100000000011001111111111111111111111111111111000010100001000000000000010000010101110111111111110000000011000001111111111111111111111111111111111000010100000100001111111111111111111100001011111111111111111101111111111111111111111111100111111111111111111111110101111111111000111001111111111111111111101111111110111111100011111111111110011111111111111111111111111111100011111111111111111111011111111101111111000111111111100111111111111111111111111111111111111111100011111111111111111111011111111101111111000111111111001111111111011111111111111111101100111000111111111111111111110111111111011111110001111111111100111111111111111111111111111111111111000111111111111111111110111111111011111110001111111110011111111110011111111111111111111111111111110001111111111111111111101111111110111111100011111111110011111111111111111111110111111111111111111111110000111111111000111111111111111111110111111111011111110001111111111111001111111111111111111101111111111111111111111111000011111111110001111111111111111111101111111110111111100011111111111110011111111111001111111111011111111111111111111111111110000111111111100011111111111111111111011111111101111111000111111111001111111111111011111111111111110111111111100111011000111111111111111111011111111101111111000111111111111111001111100111001111111111101111111111110111011111111111111111111111111001110110001111111111111111110111111111011111110001111111111110111111011011111111111111111111111111100011111111111111110101100111111111001101011111010111111111100011011100011111111111110111111111111111111011111011111111111111111110001111111111111111111111001111111111111111111101001111111111111110110000011111111111101111111111110111110111110111111111111111111100011111111110011111111111111100011111111111111111111111111110100111111111110110000011111111111101111111111110111110111110111111111111111111100011111111100111111111110001111111101001111111111111111111100011100000011111111000010111111111110111111111011111111011111011111111111111111110001111111111111001111111111111110001111111111111111111111111111010011111111111011000001111111111110111111111111011111011111011111111111111111110001111111110011111111111000111111110011111111111111111111010011111111111111110110000011111111111101111111111110111110111110111111111111111111100011111111110011111111111000111111111111111111111101100111111111111111111111010011111111001100010000001111111111111100000011111111111011111111101111111101111101111111111111111111000111111111111111111111111100011000111111111111111111110110011111111111111111011101110100111111110011000100000011111111111111100000011111111111011111111101111111101111101111111111111111111000111111111110011111111111111111000110001111111110011111111111101100111111111111111111111101001111111111100011000100000011111111111111100000011111111111011111111101111111101111101111111111111111111000111111111110011111111111111111000110001101111111111110110111111111111111110111111111100011111110110111001111111011111111101111111101111101111111111111111111000111111111111111110011111001110011111111111111001111111111111001111000110001100011111110110111111111111101110111111111111111111111111111111000111111101101110011111110111111111011111111011111011111111111111111110001","4":"1111111111111111111111111111111111100001110010011111111111111111101000110010011111111111111111100000011001110011111000000100000000000000110011111111101111111111111111111111111111111111111111111001001111001111100100110110110110111011011011111111111011110011111101110011100100110101100110011110111001010011001010000011111011101110011100000000000010010000110001110101000111111100111111100000000111111111111111111111111110000111111111111111111111001001001000000000000000000100100110110110110111011011011101101110111110111111111111111111000011111111111111111111111111111111111111111111111111100001111111111111111111111111111111111110110111111101011100110101110011011111001101100000010111000101111010010000110011011110100001101000100000000011000010010000110100001000000000011111111111110011111111111011001010011110111001111111100000100010010111111111111111111111111110000111111100111001011100110111111111111111111110111101100110111101001000011001111000100001101111111111111111111111001111011110101101111110000000000000011110111000000000000000000110","3":"11111111110111111011111001111111111111111101100000101100001110000000010001111110001100011111111111101111111010111111111111111100111111111111111111001111111111110010011110000111111001100101110111011100110010011110000111011111111100101010011111101101111110001100010011000111111111111111001100001111100000000100011111011100011111111111101111111010111111111111111100111111111111111111111001100101110111011100110010011110000101111111100101011111111111100011000111110001001100001101111100000000100011111101110001111111111110111111101011111111111111110011111111111111111111111111111111111111111001100101110111011100110010011110000101111111100101011111111111100011000101110001111111111001100001111001111000000001000111110001100001111111111101110001010111111111111111100110001111111111111111111111111111111111100110010111011101110011001001111000010111111111111001010111111111111000110001101100010011000001011000011000000000100011111111111111100011000111111111111011111110101111111111111111001111111111111110011000011110000000001000111111111111110111000111111111111011111110101111111111111111001111111111111110011000011011110000000001000111111111111111011100011111111111101111111010111111111111111100111111111111111001100001111001110000000001000111111111111110001100001111111111101110001010111111111111111100110001111111111","6":"1111111110110111111111111111111111111111111111111111111111111111111111110011111111111111110011111001111111110010011110000111111111111111111111111111111100111110011110011111111111111111100111000111111111111110101100111111111111111111111111111101111111011111111111111111110011000011111111111111111111111010011111111111111110111111110011111111111111011111111001111110110000111111111111111111111111111111111111111010110111000111111110011111111111111111111111101111111111111111111110001111111001111111001111111111111111110101111111111111111111111101001100111100100111111111111111111111111111111111111111111110101101110001111111100111111101111100111111101101111110001110110001011101111011111011111000011111111111111111111111111111111111111100100111111111111111111111111111111111111111111110101101110001111111100111011111111111010111111111111111111110011111111110101111111111111111111110111111000000001111111101001111111100000111111111111111111111111111111111111111111110101101110001111111100111111111111100011111111111111111100011101100011111010011111111111111100111111111111110011110111111111111111111111111110111111000000001111111100111111000011111110001111111111100111111111111111110011010110101000111111110011111111101111111111111111101011101110011111100011111111111111111101101111111111111111110111111001001111111111111111111111111111111111111111111101011011100011111111001111111100011111111111111111101011111111111110011111111111011011111111111111111111111100111111011000011111111111111111111111111111111111111101011011100011111111001"}[os.Getenv("READ_CEILING")]
