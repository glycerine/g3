from pathlib import Path
import csv,collections,subprocess as sp,os,json
p=Path.cwd();w=Path(__file__).resolve().parent
rows=collections.defaultdict(list)
for r in csv.DictReader((w/'reads.csv').open()):
 rows[int(r['case'])].append(r['same_input']==r['forward_unchanged']==r['reverse_unchanged']=='true' and r['distinct']==r['same']==r['forward_distinct'] and r['hits']=='0')
a=p/'smtcore/smt_asserted_propagate.go';s=a.read_text().replace('import (','import ("os";',1)
s+='\nvar studyRow int\nvar studyEligible=map[string]string{'+','.join('"'+str(n)+'":"' + ''.join('1' if v else '0' for v in x)+'"' for n,x in rows.items())+'}[os.Getenv("READ_CEILING")]\n'
k='one, result = k.rewritePendingAssertion(i)'
s=s.replace(k,'''skip:=reverse && studyRow<len(studyEligible) && studyEligible[studyRow]=='1'
 if reverse {studyRow++}
 if !skip {'''+k+'}')
b=w/'ceiling.go';b.write_text(s);j=w/'ceiling.json';ov=json.loads((w/'release.json').read_text());ov['Replace'][str(a)]=str(b);j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'ceiling','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
src=(w/'whole.py').read_text().replace('XTRACE_OFF=','READ_CEILING=str(nr) if mode=="ceiling" else "",XTRACE_OFF=')
import sys
sys.argv=['whole.py','ceiling-whole','release','ceiling'];os.environ.update(CASES='2 4 3 6',ROUNDS='7',CPU='20')
exec(src)
