from pathlib import Path
import os,json,subprocess,csv,time
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();a=front/'z3bridge_solver.go';s=a.read_text();k='for key, value := range solverOptionParamValues(s.opts) {';assert s.count(k)==1
s=s.replace(k,'''if studyOption!="" {zs.SetParam(studyOption,"true")}
 '''+k)+'\nvar studyOption=os.Getenv("MACRO_OPTION")\n'
if '"os"' not in s:s=s.replace('import (','import (\n"os"',1)
b=w/'options.go.txt';b.write_text(s);ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());ov['Replace'][str(a)]=str(b);j=w/'options.json';j.write_text(json.dumps(ov));exe=w/'options'
subprocess.run(['go','build','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
s=(w/'depth.py').read_text().split("ex=Path('/home/jaten/ivy/ivy-lang-examples')")[1];s="ex=Path('/home/jaten/ivy/ivy-lang-examples')"+s
i=s.index('  r=subprocess.run([exe,ex/name]');end=s.index('  failed=set()',i);s=s[:i]+s[end:];s=s.replace('depth.csv','options.csv').replace('[0,3,5,8,12]',"['','smt.quasi_macros','smt.pull_nested_quantifiers']").replace('MACRO_DEPTH=str(n)','MACRO_OPTION=n');exec(s)
