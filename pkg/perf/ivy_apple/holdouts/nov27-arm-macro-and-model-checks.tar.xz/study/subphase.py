from pathlib import Path
import os, csv, subprocess as sp, json, collections
w=Path(__file__).resolve().parent
p=Path.cwd()
src=(p/'smtcore/smt_model_table_check.go').read_text().replace('import (','import ("os";',1)
src+='\nvar measurePart=os.Getenv("MODEL_TABLE_PART")\n'
mark='func (g *tableModel) check('
i=src.index(mark);j=src.index('boolean, err',i)
src=src[:j]+'''var end func(string)
 start:=func(part string){if StudyBatch!=0 && measurePart==part {end=startStage(StudyBatch,StudyGoal)}}
 stop:=func(){if end!=nil {end(measurePart);end=nil}}
 defer stop()
 start("setup")
 '''+src[j:]
for key,part in [('root, err := g.compile','compile'),('domains := make','domain'),('if len(g.integers)','evaluate')]:
 src=src.replace(key,'stop();start("'+part+'")\n '+key,1)
b=w/'subphase.go';b.write_text(src);ov=json.loads((w/'table.json').read_text());ov['Replace'][str(p/'smtcore/smt_model_table_check.go')]=str(b);j=w/'subphase.json';j.write_text(json.dumps(ov))
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'subphase','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'subphase.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case round batch goal part instructions'.split())
 for nr in (2,4):
  case=(rank/'compat.txt').read_text().splitlines()[nr-1];ref=rank/'compat'/str(nr)/'1/native'
  for n in range(3):
   for part in ['setup','compile','domain','evaluate']:
    r=sp.run(['taskset','-c','24',w/'subphase',ex/case],cwd=w,capture_output=True,check=True,env=dict(os.environ,MODEL_TABLE_PART=part,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
    rest=[];counts=collections.Counter()
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'STAGE-COUNT '):
      a=l.split(); assert a[6]==a[7];counts[int(a[1]),int(a[2])]+=int(a[4])
     else:rest.append(l)
    assert (r.stdout,b''.join(rest))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    for (batch,goal),v in counts.items():o.writerow([nr,n,batch,goal,part,v])
    f.flush()
