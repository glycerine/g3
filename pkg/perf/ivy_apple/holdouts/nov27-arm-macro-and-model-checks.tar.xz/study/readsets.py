from pathlib import Path
import csv,os,json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads((w/'release.json').read_text())
def replace(a,s):
 b=w/('reads-'+a.name);b.write_text(s);ov['Replace'][str(a)]=str(b)
a=p/'ast/rewriter/th_rewriter.go';s=a.read_text();s+='\nvar ObserveRead func(ast.ASTHandle,ast.ASTHandle,bool)\n';key='if err != nil || !found || dependency.IsNull()';s=s.replace(key,'if ObserveRead!=nil {ObserveRead(term,value,found)}\n '+key,1);replace(a,s)
a=p/'smtcore/smt_asserted_propagate.go';s=a.read_text().replace('import (','import ("github.com/glycerine/g3/pkg/ast/rewriter";',1)
s=s.replace('changed := false','''type read struct{value ast.ASTHandle;found bool}
 type row struct{ input,output ast.ASTHandle; reads map[ast.ASTHandle]read }
 var prior=map[int]row{}
 changed := false''',1)
key='one, result = k.rewritePendingAssertion(i)'
s=s.replace(key,'''input:=k.assertions[i].Formula
 reads:=map[ast.ASTHandle]read{};hits,calls:=0,0
 rewriter.ObserveRead=func(h,v ast.ASTHandle,found bool){calls++;if found{hits++};reads[h]=read{v,found}}
 '''+key+'''
 rewriter.ObserveRead=nil
 same:=0;seen:=0
 if reverse {
  old:=prior[i]
  for h,out:=range reads {if orig,ok:=old.reads[h];ok{seen++;if orig==out{same++}}}
  println("PROP-READS",i,calls,hits,len(reads),seen,same,len(old.reads),input==old.input,old.input==old.output,k.assertions[i].Formula==input)
 }else{prior[i]=row{input,k.assertions[i].Formula,reads}}''',1);replace(a,s)
j=w/'reads.json';j.write_text(json.dumps(ov))
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'reads','./cmd/goivy_check'],cwd=front,check=True)
ref=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'reads.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case row calls hits distinct overlap same forward_distinct same_input forward_unchanged reverse_unchanged'.split())
 for nr in [2,4,3,6]:
  name=(ref/'compat.txt').read_text().splitlines()[nr-1];d=ref/'compat'/str(nr)/'1/native'
  r=sp.run(['taskset','-c','24',w/'reads',ex/name],env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,check=True);rest=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'PROP-READS '):o.writerow([nr,*l.decode().split()[1:]])
   else:rest.append(l)
  assert (r.stdout,b''.join(rest))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes());f.flush()
