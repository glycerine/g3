from pathlib import Path
import csv,os,subprocess,json,collections,re
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());a=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(a)]).read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');pre,s=s[:i],s[i:];s=s.replace('s.showVCsBase(clauses)','s.showVCsBase(clauses);studyBatch++;batch:=studyBatch',1).replace('z3solver.Push()','if batch==6 && index==0 { studyArmPush(z3solver) } else { z3solver.Push() }',1)
pre=pre.replace('import (','import (\n "os"',1) if '"os"' not in pre else pre
b=w/'gated.go.txt';b.write_text(pre+'var studyBatch int\n//go:noinline\nfunc studyArmPush(s *smt.Z3Solver){control,_:=os.OpenFile("/tmp/g3-arm-pass/control",os.O_WRONLY,0);ack,_:=os.Open("/tmp/g3-arm-pass/ack");var buf [32]byte;control.WriteString("enable\\n");ack.Read(buf[:]);s.Push();control.WriteString("disable\\n");ack.Read(buf[:]);control.Close();ack.Close()}\n'+s);ov['Replace'][str(a)]=str(b);j=w/'gated.json';j.write_text(json.dumps(ov));subprocess.run(['go','build','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'gated','./cmd/goivy_check'],cwd=front,check=True)
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf';ex=Path('/home/jaten/ivy/ivy-lang-examples');d=Path('/tmp/g3-reduction-rows/compat/4/1/native');c=collections.Counter()
for i in range(4):
 data=w/'gated.data'
 r=subprocess.run(['taskset','-c','22',perf,'record','-D','-1','--control=fifo:/tmp/g3-arm-pass/control,/tmp/g3-arm-pass/ack','-q','-B','-e','instructions:u','-c','190003','--call-graph','fp,55','-o',data,w/'gated',ex/'test/arm_rules3.ivy'],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,check=True);assert r.stdout==(d/'stdout').read_bytes() and all(x in [b'Events enabled',b'Events disabled'] for x in r.stderr.splitlines()),r.stderr
 raw=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',data],text=True)
 for block in raw.strip().split('\n\n'):
  if len(block.splitlines())>1:c['\n'.join(re.sub(r'^\s*[0-9a-f]+\s+','',l).strip() for l in block.splitlines()[1:])]+=1
with (w/'gated.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['stack','samples']);o.writerows(c.items())
