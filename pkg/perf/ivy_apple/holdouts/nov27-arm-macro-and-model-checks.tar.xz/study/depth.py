from pathlib import Path
import subprocess,json,os,csv,time
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());a=p/'ast/macros/macro_finder.go';s=a.read_text().replace('import (','import (\n"os"\n"strconv"',1)
k='inserted, e = f.macros.Insert(declaration, expression, newProof, dependency)'
s=s.replace(k,'''eligible:=true
            if macroDepth!=0 || macroObserve {
                _,body,err:=f.macros.GetHeadDefinition(expression,declaration)
                if err!=nil {return fail(err)}
                depth,err:=f.manager.GetDepth(body);if err!=nil{return fail(err)}
                eligible=macroDepth==0 || int(depth)<=macroDepth
                if macroObserve {n,_:=f.manager.GetNumExprs(body);id,_:=f.manager.GetASTID(declaration);println("MACRO-DEF",id,depth,n)}
            }
            if eligible {'''+k+'}');s+='\nvar macroDepth,_=strconv.Atoi(os.Getenv("MACRO_DEPTH"))\nvar macroObserve=os.Getenv("MACRO_OBSERVE")!=""\n'
b=w/'depth.go';b.write_text(s);ov['Replace'][str(a)]=str(b);a=p/'ast/macros/macro_expander.go';s=a.read_text().replace('result, proof, ok, err := c.expand', 'if macroObserve {id,_:=m.GetASTID(declaration);println("MACRO-USE",id)}\n result, proof, ok, err := c.expand');b=w/'uses.go';b.write_text(s);ov['Replace'][str(a)]=str(b)
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();a=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(a)]).read_text();k='s.showVCsBase(clauses)';s=s.replace(k,k+'\n if os.Getenv("MACRO_OBSERVE")!=""{println("MACRO-BATCH")} ',1);b=w/'depth-bridge.go.txt';b.write_text(s);ov['Replace'][str(a)]=str(b);j=w/'depth.json';j.write_text(json.dumps(ov));exe=w/'depth'
subprocess.run(['go','build','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines();perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'depth.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case round threshold status instructions ms'.split())
 for nr in [4,2,3,6]:
  name=cases[nr-1];d=rank/'compat'/str(nr)/'1/native';expected=((d/'stdout').read_bytes(),(d/'stderr').read_bytes())
  env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1')
  r=subprocess.run([exe,ex/name],cwd=w,env=dict(env,MACRO_OBSERVE='1'),capture_output=True,check=True);raw=r.stderr.splitlines(keepends=True);assert (r.stdout,b''.join(l for l in raw if not l.startswith(b'MACRO-')))==expected;(w/f'defs-{nr}.txt').write_bytes(b''.join(l for l in raw if l.startswith(b'MACRO-')))
  failed=set()
  for i in range(3):
   modes=[0,3,5,8,12]
   for n in modes[i:]+modes[:i]:
    if n in failed:continue
    start=time.monotonic();stat=w/'depth.stat'
    try:r=subprocess.run(['taskset','-c','24',perf,'stat','-x,','-e','instructions:u','-o',stat,'--',exe,ex/name],cwd=w,env=dict(env,MACRO_DEPTH=str(n)),capture_output=True,timeout=8)
    except subprocess.TimeoutExpired:o.writerow([nr,i,n,'timeout',0,0]);failed.add(n);f.flush();continue
    ok=r.returncode==0 and (r.stdout,r.stderr)==expected
    ticks,=[int(z[0]) for z in csv.reader(stat.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100]
    o.writerow([nr,i,n,'match' if ok else 'different',ticks,round(1000*(time.monotonic()-start),2)]);f.flush()
