from pathlib import Path
import tarfile,json
w=Path(__file__).resolve().parent
out=Path.cwd()/'perf/ivy_apple/holdouts/nov27-arm-macro-and-model-checks.tar.xz'
extras=set()
for j in w.glob('*.json'):
 extras.update(Path(k) for k in json.loads(j.read_text())['Replace'].values() if not Path(k).is_relative_to(w))
for f in ['/tmp/g3-interval-products/verify.py','/tmp/g3-ticket-first/validation/final.json','/tmp/g3-reduction-rows/compat.txt','/tmp/g3-live-numeral/ticket/phase_observer_trial.go.txt']:
 extras.add(Path(f))
with tarfile.open(out,'w:xz',preset=3) as t:
 for f in sorted(w.rglob('*')):
  if not f.is_symlink() and f.is_file() and f.suffix in ('.go','.txt','.csv','.py','.log','.smt2','.json'):
   t.add(f,arcname='study/'+str(f.relative_to(w)))
 for f in sorted(extras):
  if f.is_file():t.add(f,arcname='support/'+str(f.relative_to('/tmp')))
