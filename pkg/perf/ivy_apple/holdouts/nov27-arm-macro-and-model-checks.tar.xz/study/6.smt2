(set-option :smt.macro_finder true)
(declare-datatypes ((op_type 0)) ((op_type (nop) (ld) (st) (lda) (stl))))
(declare-sort ltime.t)
(declare-sort addr_type.t)
(declare-datatypes ((arm_ph_type 0)) ((arm_ph_type (arm_idle_ph) (arm_st_ph) (arm_stl_ph) (arm_ld_ph) (arm_lda_ph) (arm_rsp_ph) (arm_rspa_ph) (arm_st_isd_ph) (arm_ld_isd_ph) (arm_stl_isd_ph) (arm_lda_isd_ph))))
(declare-sort data_type.t)
(declare-sort gtime.t)
(declare-sort proc.t)
(declare-fun ref.evs.op (ltime.t) op_type)
(declare-fun ref.evs.addr (ltime.t) addr_type.t)
(declare-fun ref.evs.p (ltime.t) proc.t)
(declare-fun |<:ltime.t:ltime.t| (ltime.t ltime.t) Bool)
(declare-fun ref.evs.serialized (ltime.t) Bool)
(declare-fun ref.prevents (ltime.t ltime.t) Bool)
(declare-fun |__fml:ph| () arm_ph_type)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0__ts0_c_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a () Bool)
(declare-fun __arm.isd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun |__fml:t| () ltime.t)
(declare-fun |__fml:a| () addr_type.t)
(declare-fun |__fml:p| () proc.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
             ()
             Bool)
(declare-fun __arm.pnd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.pnd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.pnd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun __arm.pnd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
             ()
             Bool)
(declare-fun __ref.evs.serialized (ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_a_a_a_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun __ref.evs.addr (ltime.t) addr_type.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_a_a_a_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun __ref.evs.op (ltime.t) op_type)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a_a_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__fml:d| () data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a_a_a_a|
             ()
             data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a_a_a_a|
             ()
             addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a_a_a_a_a|
             ()
             op_type)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a_a_a_a|
             ()
             proc.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a_a_a|
             ()
             ltime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a () Bool)
(declare-fun __arm.lt () ltime.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a_a_a_a|
             ()
             ltime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a () Bool)
(declare-fun __arm.isd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_a_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_a_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a_a|
             ()
             data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a_a|
             ()
             addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a_a_a|
             ()
             op_type)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a_a|
             ()
             proc.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|
             ()
             ltime.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_b_a_a_a| () ltime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_b_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_b_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_b_a_a_a|
             ()
             op_type)
(declare-fun __arm.isd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0_b_b_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0_b_b_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
             (ltime.t)
             op_type)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a_a_a
             (ltime.t)
             Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_d_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a| () ltime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.data_a_a_a
             (ltime.t)
             data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_loc:d_a_a_a|
             ()
             data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_loc:a_a_a_a|
             ()
             addr_type.t)
(declare-fun __ref.gt () gtime.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a|
             ()
             gtime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_b_a_a_a|
             ()
             proc.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a| () ltime.t)
(declare-fun __ref.evs.data (ltime.t) data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a|
             ()
             data_type.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a| () op_type)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a|
             ()
             addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a| () proc.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a|
             ()
             data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a|
             ()
             addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a| () proc.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_arm.isd_stl_a_a_a
             (proc.t addr_type.t ltime.t)
             Bool)
(declare-fun __ts0__ts0_a_b () Bool)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a| () ltime.t)
(declare-fun __ts0__ts0__ts0__ts0_a_b_a () Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a| () ltime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_b_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.evs.op_a (ltime.t) op_type)
(declare-fun __ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_b_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_b_a| () data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_b_a| () addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_b_a| () proc.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__m_arm.isd_stl_a_a
             (proc.t addr_type.t ltime.t)
             Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__m_arm.pnd_stl_a_a
             (proc.t addr_type.t ltime.t)
             Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0_a_b () Bool)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.evs.serialized_a (ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.prevents_d_a (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a| () ltime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0_b_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.evs.data_a (ltime.t) data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__new_loc:d_a| () data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__new_loc:a_a| () addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:inp_a| () gtime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a
             (ltime.t ltime.t)
             Bool)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:p_a_b_a| () proc.t)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.prevents_b_a (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:lt_b| () ltime.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a| () data_type.t)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.prevents_a_a (ltime.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__ts0__m_ref.prevents_e (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:op_a| () op_type)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a| () addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a| () proc.t)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:d_a_b| () data_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:a_a_b| () addr_type.t)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:p_a_c| () proc.t)
(declare-fun __arm.isd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__m_arm.isd_st_a
             (proc.t addr_type.t ltime.t)
             Bool)
(declare-fun arm.isd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_lda (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.isd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_ld (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.isd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_stl (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0_b () Bool)
(declare-fun |__fml:out_b| () ltime.t)
(declare-fun |__fml:out_a| () ltime.t)
(declare-fun arm.lt () ltime.t)
(declare-fun |__ts0__ts0__new_fml:inp_a| () ltime.t)
(declare-fun __ts0__ts0__ts0_a () Bool)
(declare-fun __ts0__ts0__ts0_b () Bool)
(declare-fun __ts0__ts0__ts0__m_arm.isd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.isd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__m_arm.pnd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun arm.pnd_st (proc.t addr_type.t ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__m_ref.evs.op_a (ltime.t) op_type)
(declare-fun __ts0__ts0__ts0__m_ref.evs.serialized_a (ltime.t) Bool)
(declare-fun __ts0__ts0__ts0__m_ref.prevents_d_a (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__new_fml:lt_a_a| () ltime.t)
(declare-fun __ts0__ts0__ts0__ts0__ts0_a_a () Bool)
(declare-fun __ref.mem (addr_type.t) data_type.t)
(declare-fun |__ts0__ts0__ts0__new_loc:d_a| () data_type.t)
(declare-fun |__ts0__ts0__ts0__new_loc:a_a| () addr_type.t)
(declare-fun ref.mem (addr_type.t) data_type.t)
(declare-fun __ts0__ts0__ts0__m_ref.evs.data_a (ltime.t) data_type.t)
(declare-fun ref.evs.data (ltime.t) data_type.t)
(declare-fun |__fml:out| () gtime.t)
(declare-fun ref.gt () gtime.t)
(declare-fun |__ts0__ts0__ts0__new_fml:inp_a| () gtime.t)
(declare-fun __ts0__ts0__ts0__m_ref.prevents_c_a (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__new_fml:p_a_b_a| () proc.t)
(declare-fun __ts0__ts0__ts0__m_ref.prevents_b_a (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__new_fml:lt_a| () ltime.t)
(declare-fun |__ts0__ts0__ts0__new_fml:d_a_a_a| () data_type.t)
(declare-fun __ts0__ts0__ts0__m_ref.prevents_a_a (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__new_fml:a_a_a_a| () addr_type.t)
(declare-fun __ts0__ts0__ts0__m_ref.prevents_c (ltime.t ltime.t) Bool)
(declare-fun |__ts0__ts0__ts0__new_fml:op_a| () op_type)
(declare-fun __ref.evs.p (ltime.t) proc.t)
(declare-fun |__ts0__ts0__ts0__new_fml:p_a_a_a| () proc.t)
(declare-fun |__ts0__ts0__ts0__new_fml:d_a_a| () data_type.t)
(declare-fun |__ts0__ts0__ts0__new_fml:a_a_a| () addr_type.t)
(declare-fun |__ts0__ts0__ts0__new_fml:p_a_a| () proc.t)
(declare-fun __ref.prevents (ltime.t ltime.t) Bool)
(declare-fun |<:gtime.t:gtime.t| (gtime.t gtime.t) Bool)
(declare-fun @T () ltime.t)
(declare-fun @A () addr_type.t)
(declare-fun @P () proc.t)
(assert (let ((a!1 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) st)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!2 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) stl)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!3 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) ld)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!4 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T:ltime.t| ltime.t))
             (= (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)
                     (__arm.isd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|))
                (and (= (__ref.evs.p |T:ltime.t|) |P:proc.t|)
                     (= (__ref.evs.op |T:ltime.t|) lda)
                     (= (__ref.evs.addr |T:ltime.t|) |A:addr_type.t|)))))
      (a!5 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!6 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!7 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!8 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (=> (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                      (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T2:ltime.t|))
                 (= |T1:ltime.t| |T2:ltime.t|))))
      (a!9 (forall ((|A:addr_type.t| addr_type.t)
                    (|P:proc.t| proc.t)
                    (|T1:ltime.t| ltime.t)
                    (|T2:ltime.t| ltime.t))
             (not (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!10 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!11 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!12 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!13 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!14 (forall ((|A:addr_type.t| addr_type.t)
                     (|P:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T2:ltime.t|)))))
      (a!15 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_ld |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!16 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_lda |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!17 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_st |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!18 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_ld |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!19 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_lda |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_lda |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!20 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P1:proc.t|
                                       |A1:addr_type.t|
                                       |T1:ltime.t|)
                        (__arm.pnd_st |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!21 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_lda |P1:proc.t|
                                       |A1:addr_type.t|
                                       |T1:ltime.t|)
                        (__arm.pnd_stl |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!22 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_st |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_st |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!23 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (not (and (__arm.pnd_st |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                        (__arm.pnd_stl |P2:proc.t|
                                       |A2:addr_type.t|
                                       |T2:ltime.t|)
                        (= |T1:ltime.t| |T2:ltime.t|)))))
      (a!24 (forall ((|A1:addr_type.t| addr_type.t)
                     (|A2:addr_type.t| addr_type.t)
                     (|P1:proc.t| proc.t)
                     (|P2:proc.t| proc.t)
                     (|T1:ltime.t| ltime.t)
                     (|T2:ltime.t| ltime.t))
              (=> (and (__arm.pnd_stl |P1:proc.t| |A1:addr_type.t| |T1:ltime.t|)
                       (__arm.pnd_stl |P2:proc.t| |A2:addr_type.t| |T2:ltime.t|)
                       (= |T1:ltime.t| |T2:ltime.t|))
                  (and (= |P1:proc.t| |P2:proc.t|)
                       (= |A1:addr_type.t| |A2:addr_type.t|)))))
      (a!25 (forall ((|X:ltime.t| ltime.t)
                     (|Y:ltime.t| ltime.t)
                     (|Z:ltime.t| ltime.t))
              (=> (and (|<:ltime.t:ltime.t| |X:ltime.t| |Y:ltime.t|)
                       (|<:ltime.t:ltime.t| |Y:ltime.t| |Z:ltime.t|))
                  (|<:ltime.t:ltime.t| |X:ltime.t| |Z:ltime.t|))))
      (a!26 (forall ((|X:ltime.t| ltime.t) (|Y:ltime.t| ltime.t))
              (not (and (|<:ltime.t:ltime.t| |X:ltime.t| |Y:ltime.t|)
                        (|<:ltime.t:ltime.t| |Y:ltime.t| |X:ltime.t|)))))
      (a!27 (forall ((|X:gtime.t| gtime.t)
                     (|Y:gtime.t| gtime.t)
                     (|Z:gtime.t| gtime.t))
              (=> (and (|<:gtime.t:gtime.t| |X:gtime.t| |Y:gtime.t|)
                       (|<:gtime.t:gtime.t| |Y:gtime.t| |Z:gtime.t|))
                  (|<:gtime.t:gtime.t| |X:gtime.t| |Z:gtime.t|))))
      (a!28 (forall ((|X:gtime.t| gtime.t) (|Y:gtime.t| gtime.t))
              (not (and (|<:gtime.t:gtime.t| |X:gtime.t| |Y:gtime.t|)
                        (|<:gtime.t:gtime.t| |Y:gtime.t| |X:gtime.t|)))))
      (a!29 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                             (= (__ref.evs.op |T1:ltime.t|) lda)
                             (= (__ref.evs.op |T1:ltime.t|) st)
                             (= (__ref.evs.op |T1:ltime.t|) stl)))
                    (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (__ref.evs.op |T2:ltime.t|) stl)
                             (= (__ref.evs.op |T2:ltime.t|) lda))))
                (= (__ref.prevents |T1:ltime.t| |T2:ltime.t|)
                   (and (not (__ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (__ref.evs.p |T1:ltime.t|)
                           (__ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!30 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt))))
                (= (__ts0__ts0__ts0__m_arm.pnd_st
                     |V0:proc.t|
                     |V1:addr_type.t|
                     |V2:ltime.t|)
                   (ite a!1
                        true
                        (__arm.pnd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))))
      (a!31 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt))))
                (= (__ts0__ts0__ts0__m_arm.isd_st
                     |V0:proc.t|
                     |V1:addr_type.t|
                     |V2:ltime.t|)
                   (ite a!1
                        true
                        (__arm.isd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))))
      (a!32 (forall ((|V0:ltime.t| ltime.t))
              (let ((a!1 (ite __ts0__ts0__ts0_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__new_fml:lt_a|))
                                   |__ts0__ts0__ts0__new_fml:p_a_a_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|)))
                    (a!2 (ite __ts0__ts0__ts0__ts0__ts0_a_b
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                                   |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|)))
                    (a!3 (ite __ts0__ts0__ts0__ts0_a_b_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                                   |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_b_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|)))
                    (a!4 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|)))
                    (a!5 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|)))
                    (a!6 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|)))
                    (a!7 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|)))
                    (a!8 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a_a_a_a|
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|))))
              (let ((a!9 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                                   (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
                                        a!8
                                        (__ref.evs.p |V0:ltime.t|))
                                   (__ref.evs.p |V0:ltime.t|))
                              (__ref.evs.p |V0:ltime.t|))))
              (let ((a!10 (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a
                                         a!6
                                         (__ref.evs.p |V0:ltime.t|))
                                    (__ref.evs.p |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                                         a!7
                                         (__ref.evs.p |V0:ltime.t|))
                                    a!9))))
              (let ((a!11 (ite __ts0__ts0__ts0_b_b_a
                               (ite __ts0__ts0__ts0__ts0_a_b_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!4
                                         (__ref.evs.p |V0:ltime.t|))
                                    (__ref.evs.p |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!5
                                         (__ref.evs.p |V0:ltime.t|))
                                    a!10))))
              (let ((a!12 (ite __ts0__ts0_c_a
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b
                                         a!2
                                         (__ref.evs.p |V0:ltime.t|))
                                    (__ref.evs.p |V0:ltime.t|))
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b_b_a
                                         a!3
                                         (__ref.evs.p |V0:ltime.t|))
                                    a!11))))
                (= (ref.evs.p |V0:ltime.t|)
                   (ite __ts0_d
                        (ite __ts0__ts0_b a!1 (__ref.evs.p |V0:ltime.t|))
                        a!12)))))))))
      (a!33 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__m_ref.evs.op_a |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__ts0__ts0__ts0__new_fml:lt_a|))
                      |__ts0__ts0__ts0__new_fml:op_a|
                      (__ref.evs.op |V0:ltime.t|)))))
      (a!34 (forall ((|V0:ltime.t| ltime.t))
              (let ((a!1 (ite __ts0__ts0__ts0_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__new_fml:lt_a|))
                                   |__ts0__ts0__ts0__new_fml:a_a_a_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|)))
                    (a!2 (ite __ts0__ts0__ts0__ts0__ts0_a_b
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                                   |__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|)))
                    (a!3 (ite __ts0__ts0__ts0__ts0_a_b_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                                   |__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_b_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|)))
                    (a!4 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|)))
                    (a!5 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|)))
                    (a!6 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|)))
                    (a!7 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|)))
                    (a!8 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a_a_a_a|
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|))))
              (let ((a!9 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                                   (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
                                        a!8
                                        (__ref.evs.addr |V0:ltime.t|))
                                   (__ref.evs.addr |V0:ltime.t|))
                              (__ref.evs.addr |V0:ltime.t|))))
              (let ((a!10 (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a
                                         a!6
                                         (__ref.evs.addr |V0:ltime.t|))
                                    (__ref.evs.addr |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                                         a!7
                                         (__ref.evs.addr |V0:ltime.t|))
                                    a!9))))
              (let ((a!11 (ite __ts0__ts0__ts0_b_b_a
                               (ite __ts0__ts0__ts0__ts0_a_b_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!4
                                         (__ref.evs.addr |V0:ltime.t|))
                                    (__ref.evs.addr |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!5
                                         (__ref.evs.addr |V0:ltime.t|))
                                    a!10))))
              (let ((a!12 (ite __ts0__ts0_c_a
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b
                                         a!2
                                         (__ref.evs.addr |V0:ltime.t|))
                                    (__ref.evs.addr |V0:ltime.t|))
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b_b_a
                                         a!3
                                         (__ref.evs.addr |V0:ltime.t|))
                                    a!11))))
                (= (ref.evs.addr |V0:ltime.t|)
                   (ite __ts0_d
                        (ite __ts0__ts0_b a!1 (__ref.evs.addr |V0:ltime.t|))
                        a!12)))))))))
      (a!35 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__m_ref.evs.data_a |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__ts0__ts0__ts0__new_fml:lt_a|))
                      |__ts0__ts0__ts0__new_fml:d_a_a_a|
                      (__ref.evs.data |V0:ltime.t|)))))
      (a!36 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__m_ref.evs.serialized_a |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__ts0__ts0__ts0__new_fml:lt_a|))
                      false
                      (__ref.evs.serialized |V0:ltime.t|)))))
      (a!37 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                ld)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                lda)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                st)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                lda))))
                (= (__ts0__ts0__ts0__m_ref.prevents_b_a
                     |T1:ltime.t|
                     |T2:ltime.t|)
                   (and (not (__ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!38 (forall ((|V0:ltime.t| ltime.t))
              (let ((a!1 (ite __ts0__ts0__ts0_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__new_fml:lt_a_a|))
                                   true
                                   (__ts0__ts0__ts0__m_ref.evs.serialized_a
                                     |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|)))
                    (a!2 (ite __ts0__ts0__ts0__ts0__ts0_a_b
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|))
                                   true
                                   (__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a
                                     |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|)))
                    (a!3 (ite __ts0__ts0__ts0__ts0_a_b_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|))
                                   true
                                   (__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a
                                     |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|)))
                    (a!4 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                                   true
                                   (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a_a_a
                                     |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|)))
                    (a!5 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                                   false
                                   (__ref.evs.serialized |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|)))
                    (a!6 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   false
                                   (__ref.evs.serialized |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|)))
                    (a!7 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   false
                                   (__ref.evs.serialized |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|)))
                    (a!8 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a_a_a|))
                                   false
                                   (__ref.evs.serialized |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|))))
              (let ((a!9 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                                   (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
                                        a!8
                                        (__ref.evs.serialized |V0:ltime.t|))
                                   (__ref.evs.serialized |V0:ltime.t|))
                              (__ref.evs.serialized |V0:ltime.t|))))
              (let ((a!10 (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a
                                         a!6
                                         (__ref.evs.serialized |V0:ltime.t|))
                                    (__ref.evs.serialized |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                                         a!7
                                         (__ref.evs.serialized |V0:ltime.t|))
                                    a!9))))
              (let ((a!11 (ite __ts0__ts0__ts0_b_b_a
                               (ite __ts0__ts0__ts0__ts0_a_b_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!4
                                         (__ref.evs.serialized |V0:ltime.t|))
                                    (__ref.evs.serialized |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!5
                                         (__ref.evs.serialized |V0:ltime.t|))
                                    a!10))))
              (let ((a!12 (ite __ts0__ts0_c_a
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b
                                         a!2
                                         (__ref.evs.serialized |V0:ltime.t|))
                                    (__ref.evs.serialized |V0:ltime.t|))
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b_b_a
                                         a!3
                                         (__ref.evs.serialized |V0:ltime.t|))
                                    a!11))))
                (= (ref.evs.serialized |V0:ltime.t|)
                   (ite __ts0_d
                        (ite __ts0__ts0_b
                             a!1
                             (__ref.evs.serialized |V0:ltime.t|))
                        a!12)))))))))
      (a!39 (forall ((|V0:ltime.t| ltime.t))
              (let ((a!1 (ite __ts0__ts0__ts0_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__new_fml:lt_a_a|))
                                   nop
                                   (__ts0__ts0__ts0__m_ref.evs.op_a
                                     |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|)))
                    (a!2 (ite __ts0__ts0__ts0__ts0__ts0_a_b
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|))
                                   nop
                                   (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                     |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|)))
                    (a!3 (ite __ts0__ts0__ts0__ts0_a_b_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|))
                                   nop
                                   (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                     |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|)))
                    (a!4 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                                   nop
                                   (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                     |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|)))
                    (a!5 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_b_a_a_a|
                                   (__ref.evs.op |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|)))
                    (a!6 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a_a_a|
                                   (__ref.evs.op |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|)))
                    (a!7 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a_a_a|
                                   (__ref.evs.op |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|)))
                    (a!8 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
                              (ite (and (= |V0:ltime.t|
                                           |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a_a_a|))
                                   |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a_a_a_a_a|
                                   (__ref.evs.op |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|))))
              (let ((a!9 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                                   (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
                                        a!8
                                        (__ref.evs.op |V0:ltime.t|))
                                   (__ref.evs.op |V0:ltime.t|))
                              (__ref.evs.op |V0:ltime.t|))))
              (let ((a!10 (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a
                                         a!6
                                         (__ref.evs.op |V0:ltime.t|))
                                    (__ref.evs.op |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                                         a!7
                                         (__ref.evs.op |V0:ltime.t|))
                                    a!9))))
              (let ((a!11 (ite __ts0__ts0__ts0_b_b_a
                               (ite __ts0__ts0__ts0__ts0_a_b_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!4
                                         (__ref.evs.op |V0:ltime.t|))
                                    (__ref.evs.op |V0:ltime.t|))
                               (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                                    (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                         a!5
                                         (__ref.evs.op |V0:ltime.t|))
                                    a!10))))
              (let ((a!12 (ite __ts0__ts0_c_a
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b
                                         a!2
                                         (__ref.evs.op |V0:ltime.t|))
                                    (__ref.evs.op |V0:ltime.t|))
                               (ite __ts0__ts0_a_b
                                    (ite __ts0__ts0__ts0_b_b_a
                                         a!3
                                         (__ref.evs.op |V0:ltime.t|))
                                    a!11))))
                (= (ref.evs.op |V0:ltime.t|)
                   (ite __ts0_d
                        (ite __ts0__ts0_b a!1 (__ref.evs.op |V0:ltime.t|))
                        a!12)))))))))
      (a!40 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                ld)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                lda)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                st)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                lda))))
                (= (__ts0__ts0__ts0__m_ref.prevents_c_a
                     |T1:ltime.t|
                     |T2:ltime.t|)
                   (and (not (ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!41 (ite __ts0__ts0__ts0_b_b_a
                 (ite __ts0__ts0__ts0__ts0_a_b_a
                      (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                           (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                                |__fml:out|
                                __ref.gt)
                           __ref.gt)
                      __ref.gt)
                 __ref.gt))
      (a!44 (= __ts0__ts0__ts0__ts0__ts0_a_a
               (or (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a_a|) st)
                   (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a_a|) stl))))
      (a!45 (ite __ts0_d
                 (or (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a_a|) ld)
                     (= (ref.evs.op |__ts0__ts0__ts0__new_fml:lt_a_a|) lda))
                 (not (__arm.isd_st |__fml:p| |__fml:a| |__fml:t|))))
      (a!46 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                ld)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                lda)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                st)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                                stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                lda))))
                (= (__ts0__ts0__ts0__m_ref.prevents_d_a
                     |T1:ltime.t|
                     |T2:ltime.t|)
                   (and (not (__ts0__ts0__ts0__m_ref.evs.serialized_a
                               |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!47 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (not (__arm.pnd_lda |__fml:p| |A:addr_type.t| |T:ltime.t|)))))
      (a!48 (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                 (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a |__fml:out_b| __arm.lt)
                 (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                      __arm.lt
                      (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                           (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                                |__fml:out_b|
                                __arm.lt)
                           __arm.lt))))
      (a!50 (forall ((|T:ltime.t| ltime.t))
              (not (or (__arm.pnd_ld |__fml:p| |__fml:a| |T:ltime.t|)
                       (__arm.pnd_lda |__fml:p| |__fml:a| |T:ltime.t|)
                       (__arm.pnd_st |__fml:p| |__fml:a| |T:ltime.t|)
                       (__arm.pnd_stl |__fml:p| |__fml:a| |T:ltime.t|)))))
      (a!51 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt)))
                    (a!3 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| |__fml:t|))))
              (let ((a!2 (ite __ts0__ts0__ts0_b_b_a
                              (ite __ts0__ts0__ts0__ts0_a_b_a
                                   (ite a!1
                                        false
                                        (__ts0__ts0__ts0__ts0__ts0__m_arm.pnd_stl_a_a
                                          |V0:proc.t|
                                          |V1:addr_type.t|
                                          |V2:ltime.t|))
                                   (ite a!1
                                        true
                                        (__arm.pnd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|)))
                              (__arm.pnd_stl |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)))
                    (a!4 (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                                   (ite a!3
                                        false
                                        (__arm.pnd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|))
                                   (__arm.pnd_stl |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|))
                              (__arm.pnd_stl |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|))))
              (let ((a!5 (ite __ts0__ts0_a_b
                              a!2
                              (ite __ts0__ts0__ts0_b_b_a
                                   (ite __ts0__ts0__ts0__ts0_a_b_a
                                        a!4
                                        (__arm.pnd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|))
                                   (__arm.pnd_stl |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)))))
                (= (arm.pnd_stl |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                   (ite __ts0_d
                        (__arm.pnd_stl |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|)
                        (ite __ts0__ts0_c_a
                             (__arm.pnd_stl |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)
                             a!5))))))))
      (a!52 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt)))
                    (a!3 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| |__fml:t|))))
              (let ((a!2 (ite __ts0__ts0__ts0_b_b_a
                              (ite __ts0__ts0__ts0__ts0_a_b_a
                                   (ite a!1
                                        false
                                        (__ts0__ts0__ts0__ts0__ts0__m_arm.isd_stl_a_a
                                          |V0:proc.t|
                                          |V1:addr_type.t|
                                          |V2:ltime.t|))
                                   (ite a!1
                                        false
                                        (__arm.isd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|)))
                              (__arm.isd_stl |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)))
                    (a!4 (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                                   (ite a!3
                                        false
                                        (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_arm.isd_stl_a_a_a
                                          |V0:proc.t|
                                          |V1:addr_type.t|
                                          |V2:ltime.t|))
                                   (__arm.isd_stl |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|))
                              (__arm.isd_stl |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|))))
              (let ((a!5 (ite __ts0__ts0_a_b
                              a!2
                              (ite __ts0__ts0__ts0_b_b_a
                                   (ite __ts0__ts0__ts0__ts0_a_b_a
                                        a!4
                                        (__arm.isd_stl |V0:proc.t|
                                                       |V1:addr_type.t|
                                                       |V2:ltime.t|))
                                   (__arm.isd_stl |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)))))
                (= (arm.isd_stl |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                   (ite __ts0_d
                        (__arm.isd_stl |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|)
                        (ite __ts0__ts0_c_a
                             (__arm.isd_stl |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)
                             a!5))))))))
      (a!53 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt))))
              (let ((a!2 (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                   (ite a!1
                                        true
                                        (__arm.pnd_ld |V0:proc.t|
                                                      |V1:addr_type.t|
                                                      |V2:ltime.t|))
                                   (__arm.pnd_ld |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|))
                              (__arm.pnd_ld |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|))))
              (let ((a!3 (ite __ts0__ts0_c_a
                              (__arm.pnd_ld |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)
                              (ite __ts0__ts0_a_b
                                   (__arm.pnd_ld |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|)
                                   (ite __ts0__ts0__ts0_b_b_a
                                        (__arm.pnd_ld |V0:proc.t|
                                                      |V1:addr_type.t|
                                                      |V2:ltime.t|)
                                        a!2)))))
                (= (arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                   (ite __ts0_d
                        (__arm.pnd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                        a!3)))))))
      (a!54 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt)))
                    (a!3 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| |__fml:t|))))
              (let ((a!2 (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                                   (ite a!1
                                        true
                                        (__arm.isd_ld |V0:proc.t|
                                                      |V1:addr_type.t|
                                                      |V2:ltime.t|))
                                   (ite a!1
                                        false
                                        (__arm.isd_ld |V0:proc.t|
                                                      |V1:addr_type.t|
                                                      |V2:ltime.t|)))
                              (__arm.isd_ld |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)))
                    (a!4 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a
                                   (ite a!3
                                        true
                                        (__arm.isd_ld |V0:proc.t|
                                                      |V1:addr_type.t|
                                                      |V2:ltime.t|))
                                   (__arm.isd_ld |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|))
                              (__arm.isd_ld |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|))))
              (let ((a!5 (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                              a!2
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                                   (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                                        a!4
                                        (__arm.isd_ld |V0:proc.t|
                                                      |V1:addr_type.t|
                                                      |V2:ltime.t|))
                                   (__arm.isd_ld |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|)))))
              (let ((a!6 (ite __ts0__ts0_c_a
                              (__arm.isd_ld |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)
                              (ite __ts0__ts0_a_b
                                   (__arm.isd_ld |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|)
                                   (ite __ts0__ts0__ts0_b_b_a
                                        (__arm.isd_ld |V0:proc.t|
                                                      |V1:addr_type.t|
                                                      |V2:ltime.t|)
                                        a!5)))))
                (= (arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                   (ite __ts0_d
                        (__arm.isd_ld |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|)
                        a!6))))))))
      (a!55 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| |__fml:t|))))
                (= (__ts0__ts0__ts0__ts0__ts0__m_arm.isd_st_a
                     |V0:proc.t|
                     |V1:addr_type.t|
                     |V2:ltime.t|)
                   (ite a!1
                        true
                        (__arm.isd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|))))))
      (a!56 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                      |__ts0__ts0__ts0__ts0__new_fml:op_a|
                      (__ref.evs.op |V0:ltime.t|)))))
      (a!57 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t| |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                      false
                      (__ref.evs.serialized |V0:ltime.t|)))))
      (a!58 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                ld)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                lda)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                st)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T2:ltime.t|)
                                lda))))
                (= (__ts0__ts0__ts0__ts0__m_ref.prevents_b_a
                     |T1:ltime.t|
                     |T2:ltime.t|)
                   (and (not (__ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!59 (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a
               (or (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|)
                      st)
                   (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|)
                      stl))))
      (a!60 (ite __ts0__ts0_c_a
                 (or (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|)
                        ld)
                     (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|)
                        lda))
                 (or (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|)
                        ld)
                     (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|)
                        lda))))
      (a!61 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                ld)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                lda)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                st)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T1:ltime.t|)
                                stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T2:ltime.t|)
                                lda))))
                (= (__ts0__ts0__ts0__ts0__m_ref.prevents_d_a
                     |T1:ltime.t|
                     |T2:ltime.t|)
                   (and (not (__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a
                               |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!62 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (or (not (__arm.pnd_lda |__fml:p| |A:addr_type.t| |T:ltime.t|))
                    (|<:ltime.t:ltime.t| |__fml:t| |T:ltime.t|)))))
      (a!63 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt))))
                (= (__ts0__ts0__ts0__ts0__ts0__m_arm.pnd_stl_a_a
                     |V0:proc.t|
                     |V1:addr_type.t|
                     |V2:ltime.t|)
                   (ite a!1
                        true
                        (__arm.pnd_stl |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|))))))
      (a!64 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| __arm.lt))))
                (= (__ts0__ts0__ts0__ts0__ts0__m_arm.isd_stl_a_a
                     |V0:proc.t|
                     |V1:addr_type.t|
                     |V2:ltime.t|)
                   (ite a!1
                        true
                        (__arm.isd_stl |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|))))))
      (a!65 (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_b_a
               (or (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|)
                      st)
                   (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|)
                      stl))))
      (a!66 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (not (or (__arm.pnd_ld |__fml:p| |A:addr_type.t| |T:ltime.t|)
                         (__arm.pnd_lda |__fml:p| |A:addr_type.t| |T:ltime.t|)
                         (__arm.pnd_st |__fml:p| |A:addr_type.t| |T:ltime.t|)
                         (__arm.pnd_stl |__fml:p| |A:addr_type.t| |T:ltime.t|))))))
      (a!67 (forall ((|V0:proc.t| proc.t)
                     (|V1:addr_type.t| addr_type.t)
                     (|V2:ltime.t| ltime.t))
              (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                              (= |V1:addr_type.t| |__fml:a|)
                              (= |V2:ltime.t| |__fml:t|))))
                (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_arm.isd_stl_a_a_a
                     |V0:proc.t|
                     |V1:addr_type.t|
                     |V2:ltime.t|)
                   (ite a!1
                        true
                        (__arm.isd_stl |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|))))))
      (a!68 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                   |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t|
                              |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a|))
                      |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a|
                      (__ref.evs.op |V0:ltime.t|)))))
      (a!69 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.data_a_a_a
                   |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t|
                              |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a|))
                      |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a|
                      (__ref.evs.data |V0:ltime.t|)))))
      (a!70 (forall ((|V0:ltime.t| ltime.t))
              (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a_a_a
                   |V0:ltime.t|)
                 (ite (and (= |V0:ltime.t|
                              |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a|))
                      false
                      (__ref.evs.serialized |V0:ltime.t|)))))
      (a!71 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                ld)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                lda)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                st)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T2:ltime.t|)
                                lda))))
                (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_a_a
                     |T1:ltime.t|
                     |T2:ltime.t|)
                   (and (not (__ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!73 (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a
               (or (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|)
                      ld)
                   (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|)
                      lda))))
      (a!74 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                ld)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                lda)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                st)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T1:ltime.t|)
                                stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T2:ltime.t|)
                                lda))))
                (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_d_a_a_a
                     |T1:ltime.t|
                     |T2:ltime.t|)
                   (and (not (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.serialized_a_a_a
                               |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2)))))
      (a!75 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (let ((a!1 (not (or (__arm.pnd_ld |__fml:p|
                                                  |A:addr_type.t|
                                                  |T:ltime.t|)
                                    (__arm.pnd_lda |__fml:p|
                                                   |A:addr_type.t|
                                                   |T:ltime.t|)
                                    (__arm.pnd_st |__fml:p|
                                                  |A:addr_type.t|
                                                  |T:ltime.t|)
                                    (__arm.pnd_stl |__fml:p|
                                                   |A:addr_type.t|
                                                   |T:ltime.t|)))))
                  (or a!1
                      (|<:ltime.t:ltime.t| |__fml:t| |T:ltime.t|)
                      (= |__fml:t| |T:ltime.t|))))))
      (a!76 (forall ((|T:ltime.t| ltime.t))
              (and (not (__arm.pnd_ld |__fml:p| |__fml:a| |T:ltime.t|))
                   (not (__arm.pnd_lda |__fml:p| |__fml:a| |T:ltime.t|))
                   (not (__arm.pnd_st |__fml:p| |__fml:a| |T:ltime.t|))
                   (not (__arm.pnd_stl |__fml:p| |__fml:a| |T:ltime.t|)))))
      (a!78 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (and (not (__arm.pnd_lda |__fml:p| |A:addr_type.t| |T:ltime.t|))
                     (not (__arm.pnd_ld |__fml:p| |A:addr_type.t| |T:ltime.t|))
                     (not (__arm.pnd_st |__fml:p| |A:addr_type.t| |T:ltime.t|))
                     (not (__arm.pnd_stl |__fml:p| |A:addr_type.t| |T:ltime.t|))))))
      (a!79 (forall ((|A:addr_type.t| addr_type.t))
              (forall ((|T:ltime.t| ltime.t))
                (let ((a!1 (and (not (__arm.pnd_lda |__fml:p|
                                                    |A:addr_type.t|
                                                    |T:ltime.t|))
                                (not (__arm.pnd_ld |__fml:p|
                                                   |A:addr_type.t|
                                                   |T:ltime.t|))
                                (not (__arm.pnd_st |__fml:p|
                                                   |A:addr_type.t|
                                                   |T:ltime.t|))
                                (not (__arm.pnd_stl |__fml:p|
                                                    |A:addr_type.t|
                                                    |T:ltime.t|)))))
                  (or a!1
                      (|<:ltime.t:ltime.t| |__fml:t| |T:ltime.t|)
                      (= |__fml:t| |T:ltime.t|))))))
      (a!80 (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
              (let ((a!1 (or (= (ref.evs.op |T1:ltime.t|) ld)
                             (= (ref.evs.op |T1:ltime.t|) lda)
                             (= (ref.evs.op |T1:ltime.t|) st)
                             (= (ref.evs.op |T1:ltime.t|) stl)))
                    (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                                (ref.evs.addr |T2:ltime.t|))
                             (= (ref.evs.op |T2:ltime.t|) stl)
                             (= (ref.evs.op |T2:ltime.t|) lda))))
                (= (ref.prevents |T1:ltime.t| |T2:ltime.t|)
                   (and (not (ref.evs.serialized |T1:ltime.t|))
                        (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                        a!1
                        (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                        a!2))))))
(let ((a!42 (ite __ts0__ts0_c_a
                 (ite __ts0__ts0_a_b
                      (ite __ts0__ts0__ts0_b
                           (ite __ts0__ts0__ts0__ts0__ts0_a_b
                                |__fml:out|
                                __ref.gt)
                           __ref.gt)
                      __ref.gt)
                 (ite __ts0__ts0_a_b
                      (ite __ts0__ts0__ts0_b_b_a
                           (ite __ts0__ts0__ts0__ts0_a_b_a |__fml:out| __ref.gt)
                           __ref.gt)
                      a!41)))
      (a!49 (ite __ts0_d
                 (ite __ts0__ts0_b |__fml:out_a| __arm.lt)
                 (ite __ts0__ts0_c_a
                      __arm.lt
                      (ite __ts0__ts0_a_b
                           (ite __ts0__ts0__ts0_b_b_a |__fml:out_a| __arm.lt)
                           (ite __ts0__ts0__ts0_b_b_a __arm.lt a!48)))))
      (a!72 (ite __ts0__ts0__ts0_b_b_a
                 (or (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|)
                        st)
                     (= (ref.evs.op |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|)
                        stl))
                 a!62))
      (a!77 (= __ts0__ts0__ts0__ts0__ts0_b_b_a_a
               (ite __ts0__ts0__ts0_b_b_a
                    (not (__arm.isd_stl |__fml:p| |__fml:a| |__fml:t|))
                    a!76))))
(let ((a!43 (= ref.gt
               (ite __ts0_d
                    (ite __ts0__ts0_b
                         (ite __ts0__ts0__ts0_a |__fml:out| __ref.gt)
                         __ref.gt)
                    a!42))))
  (and (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (not (__arm.isd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (not (__arm.isd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       a!1
       a!2
       a!3
       a!4
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (|<:ltime.t:ltime.t| |T:ltime.t| __arm.lt)))
       a!5
       a!6
       a!7
       a!8
       a!9
       a!10
       a!11
       a!12
       a!13
       a!14
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_st |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_stl |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_ld |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t))
         (=> (__arm.isd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)
             (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|A1:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t)
                (|T1:ltime.t| ltime.t))
         (let ((a!1 (not (and (or (__arm.pnd_ld |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.pnd_lda |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|)
                                  (__arm.pnd_st |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.pnd_stl |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|))
                              (|<:ltime.t:ltime.t| |T1:ltime.t| |T:ltime.t|)))))
           (=> (__arm.isd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|) a!1)))
       (forall ((|A:addr_type.t| addr_type.t)
                (|A1:addr_type.t| addr_type.t)
                (|P:proc.t| proc.t)
                (|T:ltime.t| ltime.t)
                (|T1:ltime.t| ltime.t))
         (let ((a!1 (not (and (or (__arm.isd_ld |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.isd_lda |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|)
                                  (__arm.isd_st |P:proc.t|
                                                |A1:addr_type.t|
                                                |T1:ltime.t|)
                                  (__arm.isd_stl |P:proc.t|
                                                 |A1:addr_type.t|
                                                 |T1:ltime.t|))
                              (|<:ltime.t:ltime.t| |T:ltime.t| |T1:ltime.t|)))))
           (=> (__arm.pnd_lda |P:proc.t| |A:addr_type.t| |T:ltime.t|) a!1)))
       a!15
       a!16
       a!17
       a!18
       a!19
       a!20
       a!21
       a!22
       a!23
       a!24
       (or (not __ts0_d)
           (not __ts0__ts0_b)
           (not __ts0__ts0__ts0_a)
           (|<:gtime.t:gtime.t| |__ts0__ts0__ts0__new_fml:inp_a| |__fml:out|))
       (or (not __ts0_d)
           (not __ts0__ts0_b)
           (|<:ltime.t:ltime.t| |__ts0__ts0__new_fml:inp_a| |__fml:out_a|))
       (or __ts0_d
           (not __ts0__ts0_c_a)
           (not __ts0__ts0_a_b)
           (not __ts0__ts0__ts0_b)
           (not __ts0__ts0__ts0__ts0__ts0_a_b)
           (|<:gtime.t:gtime.t|
             |__ts0__ts0__ts0__ts0__new_fml:inp_a|
             |__fml:out|))
       (or __ts0_d
           __ts0__ts0_c_a
           (not __ts0__ts0_a_b)
           (not __ts0__ts0__ts0_b_b_a)
           (not __ts0__ts0__ts0__ts0_a_b_a)
           (|<:gtime.t:gtime.t|
             |__ts0__ts0__ts0__ts0__new_fml:inp_a|
             |__fml:out|))
       (or __ts0_d
           __ts0__ts0_c_a
           (not __ts0__ts0_a_b)
           (not __ts0__ts0__ts0_b_b_a)
           (|<:ltime.t:ltime.t|
             |__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a|
             |__fml:out_a|))
       (or __ts0_d
           __ts0__ts0_c_a
           __ts0__ts0_a_b
           (not __ts0__ts0__ts0_b_b_a)
           (not __ts0__ts0__ts0__ts0_a_b_a)
           (not __ts0__ts0__ts0__ts0__ts0_b_b_a_a)
           (not __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a)
           (|<:gtime.t:gtime.t|
             |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a|
             |__fml:out|))
       (or __ts0_d
           __ts0__ts0_c_a
           __ts0__ts0_a_b
           __ts0__ts0__ts0_b_b_a
           (not __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a)
           (not __ts0__ts0__ts0__ts0__ts0_b_b_a_a)
           (|<:ltime.t:ltime.t|
             |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_b_a_a_a|
             |__fml:out_b|))
       (or __ts0_d
           __ts0__ts0_c_a
           __ts0__ts0_a_b
           __ts0__ts0__ts0_b_b_a
           __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
           __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
           (not __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a)
           (not __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a)
           (|<:ltime.t:ltime.t|
             |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a_a_a_a|
             |__fml:out_b|))
       a!25
       a!26
       (forall ((|X:ltime.t| ltime.t) (|Y:ltime.t| ltime.t))
         (or (|<:ltime.t:ltime.t| |X:ltime.t| |Y:ltime.t|)
             (= |X:ltime.t| |Y:ltime.t|)
             (|<:ltime.t:ltime.t| |Y:ltime.t| |X:ltime.t|)))
       a!27
       a!28
       (forall ((|X:gtime.t| gtime.t) (|Y:gtime.t| gtime.t))
         (or (|<:gtime.t:gtime.t| |X:gtime.t| |Y:gtime.t|)
             (= |X:gtime.t| |Y:gtime.t|)
             (|<:gtime.t:gtime.t| |Y:gtime.t| |X:gtime.t|)))
       a!29
       a!30
       a!31
       (= |__ts0__ts0__ts0__new_fml:p_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__new_fml:a_a_a| |__fml:a|)
       (= |__ts0__ts0__ts0__new_fml:d_a_a| |__fml:d|)
       (= |__ts0__ts0__ts0__new_fml:lt_a| __arm.lt)
       (= |__ts0__ts0__ts0__new_fml:p_a_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__new_fml:op_a| st)
       (= |__ts0__ts0__ts0__new_fml:a_a_a_a| |__fml:a|)
       (= |__ts0__ts0__ts0__new_fml:d_a_a_a| |__fml:d|)
       a!32
       a!33
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                        (= (__ref.evs.op |T1:ltime.t|) lda)
                        (= (__ref.evs.op |T1:ltime.t|) st)
                        (= (__ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                           (__ref.evs.addr |T2:ltime.t|))
                        (= (__ref.evs.op |T2:ltime.t|) stl)
                        (= (__ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__m_ref.prevents_c |T1:ltime.t| |T2:ltime.t|) a!3))))
       a!34
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|) ld)
                        (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|) lda)
                        (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|) st)
                        (= (__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|) stl))))
         (let ((a!2 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                                lda)))))
           (= (__ts0__ts0__ts0__m_ref.prevents_a_a |T1:ltime.t| |T2:ltime.t|)
              a!2))))
       a!35
       a!36
       a!37
       (= |__ts0__ts0__ts0__new_fml:p_a_b_a| |__fml:p|)
       (= |__ts0__ts0__ts0__new_fml:lt_a_a| __arm.lt)
       a!38
       a!39
       a!40
       (= |__ts0__ts0__ts0__new_fml:inp_a| __ref.gt)
       a!43
       (= |__ts0__ts0__ts0__new_loc:a_a|
          (ref.evs.addr |__ts0__ts0__ts0__new_fml:lt_a_a|))
       (= |__ts0__ts0__ts0__new_loc:d_a|
          (__ts0__ts0__ts0__m_ref.evs.data_a |__ts0__ts0__ts0__new_fml:lt_a_a|))
       (forall ((|V0:ltime.t| ltime.t))
         (let ((a!1 (ite __ts0__ts0__ts0_b
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__new_fml:lt_a_a|))
                              (__ref.mem |__ts0__ts0__ts0__new_loc:a_a|)
                              (__ts0__ts0__ts0__m_ref.evs.data_a |V0:ltime.t|))
                         (__ts0__ts0__ts0__m_ref.evs.data_a |V0:ltime.t|)))
               (a!2 (ite __ts0__ts0__ts0__ts0__ts0_b_a
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|))
                              (__ref.mem |__ts0__ts0__ts0__ts0__new_loc:a_a|)
                              (__ts0__ts0__ts0__ts0__m_ref.evs.data_a
                                |V0:ltime.t|))
                         (__ts0__ts0__ts0__ts0__m_ref.evs.data_a |V0:ltime.t|)))
               (a!4 (ite __ts0__ts0__ts0__ts0__ts0_b_a
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|))
                              (__ref.mem |__ts0__ts0__ts0__ts0__new_loc:a_a|)
                              (__ts0__ts0__ts0__ts0__m_ref.evs.data_a
                                |V0:ltime.t|))
                         (__ts0__ts0__ts0__ts0__m_ref.evs.data_a |V0:ltime.t|)))
               (a!5 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                              (__ref.mem |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_loc:a_a_a_a|)
                              (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.data_a_a_a
                                |V0:ltime.t|))
                         (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.data_a_a_a
                           |V0:ltime.t|)))
               (a!7 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
                              |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a|
                              (__ref.evs.data |V0:ltime.t|))
                         (__ref.evs.data |V0:ltime.t|)))
               (a!8 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                              |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a_a|
                              (__ref.evs.data |V0:ltime.t|))
                         (__ref.evs.data |V0:ltime.t|)))
               (a!9 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|))
                              |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a_a|
                              (__ref.evs.data |V0:ltime.t|))
                         (__ref.evs.data |V0:ltime.t|)))
               (a!10 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
                          (ite (and (= |V0:ltime.t|
                                       |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a_a_a|))
                               |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a_a_a_a|
                               (__ref.evs.data |V0:ltime.t|))
                          (__ref.evs.data |V0:ltime.t|))))
         (let ((a!3 (ite __ts0__ts0_a_b
                         (ite __ts0__ts0__ts0_b
                              (ite __ts0__ts0__ts0__ts0__ts0_a_b
                                   a!2
                                   (__ref.evs.data |V0:ltime.t|))
                              (__ref.evs.data |V0:ltime.t|))
                         (__ref.evs.data |V0:ltime.t|)))
               (a!6 (ite __ts0__ts0__ts0__ts0_a_b_a
                         (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                                   a!5
                                   (__ref.evs.data |V0:ltime.t|))
                              (__ref.evs.data |V0:ltime.t|))
                         (__ref.evs.data |V0:ltime.t|)))
               (a!11 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                          (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
                                    a!10
                                    (__ref.evs.data |V0:ltime.t|))
                               (__ref.evs.data |V0:ltime.t|))
                          (__ref.evs.data |V0:ltime.t|))))
         (let ((a!12 (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                          (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a
                                    a!8
                                    (__ref.evs.data |V0:ltime.t|))
                               (__ref.evs.data |V0:ltime.t|))
                          (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                                    a!9
                                    (__ref.evs.data |V0:ltime.t|))
                               a!11))))
         (let ((a!13 (ite __ts0__ts0__ts0_b_b_a
                          a!6
                          (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                               (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                                    a!7
                                    (__ref.evs.data |V0:ltime.t|))
                               a!12))))
         (let ((a!14 (ite __ts0__ts0_a_b
                          (ite __ts0__ts0__ts0_b_b_a
                               (ite __ts0__ts0__ts0__ts0_a_b_a
                                    a!4
                                    (__ref.evs.data |V0:ltime.t|))
                               (__ref.evs.data |V0:ltime.t|))
                          a!13)))
         (let ((a!15 (ite __ts0_d
                          (ite __ts0__ts0_b
                               (ite __ts0__ts0__ts0_a
                                    a!1
                                    (__ref.evs.data |V0:ltime.t|))
                               (__ref.evs.data |V0:ltime.t|))
                          (ite __ts0__ts0_c_a a!3 a!14))))
           (= (ref.evs.data |V0:ltime.t|) a!15))))))))
       (forall ((|V0:addr_type.t| addr_type.t))
         (let ((a!1 (ite __ts0__ts0__ts0__ts0__ts0_a_a
                         (ite (and (= |V0:addr_type.t|
                                      |__ts0__ts0__ts0__new_loc:a_a|))
                              |__ts0__ts0__ts0__new_loc:d_a|
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|)))
               (a!3 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a
                         (ite (and (= |V0:addr_type.t|
                                      |__ts0__ts0__ts0__ts0__new_loc:a_a|))
                              |__ts0__ts0__ts0__ts0__new_loc:d_a|
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|)))
               (a!5 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_b_a
                         (ite (and (= |V0:addr_type.t|
                                      |__ts0__ts0__ts0__ts0__new_loc:a_a|))
                              |__ts0__ts0__ts0__ts0__new_loc:d_a|
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|)))
               (a!7 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a
                         (ite (and (= |V0:addr_type.t|
                                      |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_loc:a_a_a_a|))
                              |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_loc:d_a_a_a|
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|))))
         (let ((a!2 (ite __ts0__ts0_b
                         (ite __ts0__ts0__ts0_a
                              (ite __ts0__ts0__ts0_b
                                   (__ref.mem |V0:addr_type.t|)
                                   a!1)
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|)))
               (a!4 (ite __ts0__ts0__ts0_b
                         (ite __ts0__ts0__ts0__ts0__ts0_a_b
                              (ite __ts0__ts0__ts0__ts0__ts0_b_a
                                   (__ref.mem |V0:addr_type.t|)
                                   a!3)
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|)))
               (a!6 (ite __ts0__ts0__ts0_b_b_a
                         (ite __ts0__ts0__ts0__ts0_a_b_a
                              (ite __ts0__ts0__ts0__ts0__ts0_b_a
                                   (__ref.mem |V0:addr_type.t|)
                                   a!5)
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|)))
               (a!8 (ite __ts0__ts0__ts0__ts0__ts0_b_b_a_a
                         (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a
                                   (__ref.mem |V0:addr_type.t|)
                                   a!7)
                              (__ref.mem |V0:addr_type.t|))
                         (__ref.mem |V0:addr_type.t|))))
         (let ((a!9 (ite __ts0__ts0_a_b
                         a!6
                         (ite __ts0__ts0__ts0_b_b_a
                              (ite __ts0__ts0__ts0__ts0_a_b_a
                                   a!8
                                   (__ref.mem |V0:addr_type.t|))
                              (__ref.mem |V0:addr_type.t|)))))
         (let ((a!10 (ite __ts0_d
                          a!2
                          (ite __ts0__ts0_c_a
                               (ite __ts0__ts0_a_b
                                    a!4
                                    (__ref.mem |V0:addr_type.t|))
                               a!9))))
           (= (ref.mem |V0:addr_type.t|) a!10))))))
       a!44
       (= __ts0__ts0__ts0_b a!45)
       a!46
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| __arm.lt)))
               (a!3 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| |__fml:t|))))
         (let ((a!2 (ite __ts0__ts0_b
                         (ite __ts0__ts0__ts0_a
                              (ite a!1
                                   false
                                   (__ts0__ts0__ts0__m_arm.pnd_st
                                     |V0:proc.t|
                                     |V1:addr_type.t|
                                     |V2:ltime.t|))
                              (ite a!1
                                   true
                                   (__arm.pnd_st |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|)))
                         (__arm.pnd_st |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|)))
               (a!4 (ite __ts0__ts0__ts0_b
                         (ite __ts0__ts0__ts0__ts0__ts0_a_b
                              (ite a!3
                                   false
                                   (__arm.pnd_st |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|))
                              (__arm.pnd_st |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|))
                         (__arm.pnd_st |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|))))
         (let ((a!5 (ite __ts0_d
                         a!2
                         (ite __ts0__ts0_c_a
                              (ite __ts0__ts0_a_b
                                   a!4
                                   (__arm.pnd_st |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|))
                              (__arm.pnd_st |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)))))
           (= (arm.pnd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|) a!5)))))
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| __arm.lt)))
               (a!3 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| |__fml:t|))))
         (let ((a!2 (ite __ts0__ts0_b
                         (ite __ts0__ts0__ts0_a
                              (ite a!1
                                   false
                                   (__ts0__ts0__ts0__m_arm.isd_st
                                     |V0:proc.t|
                                     |V1:addr_type.t|
                                     |V2:ltime.t|))
                              (ite a!1
                                   false
                                   (__arm.isd_st |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|)))
                         (__arm.isd_st |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|)))
               (a!4 (ite __ts0__ts0__ts0_b
                         (ite __ts0__ts0__ts0__ts0__ts0_a_b
                              (ite a!3
                                   false
                                   (__ts0__ts0__ts0__ts0__ts0__m_arm.isd_st_a
                                     |V0:proc.t|
                                     |V1:addr_type.t|
                                     |V2:ltime.t|))
                              (__arm.isd_st |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|))
                         (__arm.isd_st |V0:proc.t|
                                       |V1:addr_type.t|
                                       |V2:ltime.t|))))
         (let ((a!5 (ite __ts0_d
                         a!2
                         (ite __ts0__ts0_c_a
                              (ite __ts0__ts0_a_b
                                   a!4
                                   (__arm.isd_st |V0:proc.t|
                                                 |V1:addr_type.t|
                                                 |V2:ltime.t|))
                              (__arm.isd_st |V0:proc.t|
                                            |V1:addr_type.t|
                                            |V2:ltime.t|)))))
           (= (arm.isd_st |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|) a!5)))))
       (= __ts0__ts0__ts0_a a!47)
       (= |__ts0__ts0__new_fml:inp_a| __arm.lt)
       (= arm.lt a!49)
       (= __ts0__ts0_b a!50)
       a!51
       a!52
       a!53
       a!54
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| __arm.lt))))
         (let ((a!2 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                         (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                              (ite a!1
                                   true
                                   (__arm.pnd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|))
                              (__arm.pnd_lda |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|))
                         (__arm.pnd_lda |V0:proc.t|
                                        |V1:addr_type.t|
                                        |V2:ltime.t|))))
         (let ((a!3 (ite __ts0__ts0__ts0_b_b_a
                         (__arm.pnd_lda |V0:proc.t|
                                        |V1:addr_type.t|
                                        |V2:ltime.t|)
                         (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                              (__arm.pnd_lda |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                                   (__arm.pnd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)
                                   a!2)))))
         (let ((a!4 (ite __ts0_d
                         (__arm.pnd_lda |V0:proc.t|
                                        |V1:addr_type.t|
                                        |V2:ltime.t|)
                         (ite __ts0__ts0_c_a
                              (__arm.pnd_lda |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)
                              (ite __ts0__ts0_a_b
                                   (__arm.pnd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)
                                   a!3)))))
           (= (arm.pnd_lda |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|) a!4))))))
       (forall ((|V0:proc.t| proc.t)
                (|V1:addr_type.t| addr_type.t)
                (|V2:ltime.t| ltime.t))
         (let ((a!1 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| __arm.lt)))
               (a!3 (and (= |V0:proc.t| |__fml:p|)
                         (= |V1:addr_type.t| |__fml:a|)
                         (= |V2:ltime.t| |__fml:t|))))
         (let ((a!2 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                         (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                              (ite a!1
                                   true
                                   (__arm.isd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|))
                              (ite a!1
                                   false
                                   (__arm.isd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)))
                         (__arm.isd_lda |V0:proc.t|
                                        |V1:addr_type.t|
                                        |V2:ltime.t|)))
               (a!4 (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
                         (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
                              (ite a!3
                                   true
                                   (__arm.isd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|))
                              (__arm.isd_lda |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|))
                         (__arm.isd_lda |V0:proc.t|
                                        |V1:addr_type.t|
                                        |V2:ltime.t|))))
         (let ((a!5 (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
                         a!2
                         (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
                                   a!4
                                   (__arm.isd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|))
                              (__arm.isd_lda |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)))))
         (let ((a!6 (ite __ts0__ts0__ts0_b_b_a
                         (__arm.isd_lda |V0:proc.t|
                                        |V1:addr_type.t|
                                        |V2:ltime.t|)
                         (ite __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a
                              (__arm.isd_lda |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)
                              (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
                                   (__arm.isd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)
                                   a!5)))))
         (let ((a!7 (ite __ts0_d
                         (__arm.isd_lda |V0:proc.t|
                                        |V1:addr_type.t|
                                        |V2:ltime.t|)
                         (ite __ts0__ts0_c_a
                              (__arm.isd_lda |V0:proc.t|
                                             |V1:addr_type.t|
                                             |V2:ltime.t|)
                              (ite __ts0__ts0_a_b
                                   (__arm.isd_lda |V0:proc.t|
                                                  |V1:addr_type.t|
                                                  |V2:ltime.t|)
                                   a!6)))))
           (= (arm.isd_lda |V0:proc.t| |V1:addr_type.t| |V2:ltime.t|) a!7)))))))
       a!55
       (= |__ts0__ts0__ts0__ts0__new_fml:p_a_c| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__new_fml:a_a_b| |__fml:a|)
       (= |__ts0__ts0__ts0__ts0__new_fml:d_a_b| |__fml:d|)
       (= |__ts0__ts0__ts0__ts0__new_fml:lt_b|
          (ite __ts0__ts0_c_a |__fml:t| __arm.lt))
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__new_fml:op_a| (ite __ts0__ts0_c_a st stl))
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a| |__fml:a|)
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a| |__fml:d|)
       a!56
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                        (= (__ref.evs.op |T1:ltime.t|) lda)
                        (= (__ref.evs.op |T1:ltime.t|) st)
                        (= (__ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                           (__ref.evs.addr |T2:ltime.t|))
                        (= (__ref.evs.op |T2:ltime.t|) stl)
                        (= (__ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__m_ref.prevents_e |T1:ltime.t| |T2:ltime.t|)
              a!3))))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           ld)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           lda)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           st)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           stl))))
         (let ((a!2 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a
                                  |T2:ltime.t|)
                                lda)))))
           (= (__ts0__ts0__ts0__ts0__m_ref.prevents_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!2))))
       (forall ((|V0:ltime.t| ltime.t))
         (let ((a!1 (ite __ts0__ts0_c_a
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                              |__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a|
                              (__ref.evs.data |V0:ltime.t|))
                         (ite (and (= |V0:ltime.t|
                                      |__ts0__ts0__ts0__ts0__new_fml:lt_b|))
                              |__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_b_a|
                              (__ref.evs.data |V0:ltime.t|)))))
           (= (__ts0__ts0__ts0__ts0__m_ref.evs.data_a |V0:ltime.t|) a!1)))
       a!57
       a!58
       (= |__ts0__ts0__ts0__ts0__new_fml:p_a_b_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a| |__fml:t|)
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           ld)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           lda)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           st)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           stl)))
               (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                           (ref.evs.addr |T2:ltime.t|))
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                           stl)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                           lda))))
         (let ((a!3 (and (not (ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       (= |__ts0__ts0__ts0__ts0__new_fml:inp_a| __ref.gt)
       (= |__ts0__ts0__ts0__ts0__new_loc:a_a|
          (ite __ts0__ts0_c_a
               (ref.evs.addr |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|)
               (ref.evs.addr |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|)))
       (= |__ts0__ts0__ts0__ts0__new_loc:d_a|
          (ite __ts0__ts0_c_a
               (__ts0__ts0__ts0__ts0__m_ref.evs.data_a
                 |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a|)
               (__ts0__ts0__ts0__ts0__m_ref.evs.data_a
                 |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a|)))
       a!59
       (= __ts0__ts0__ts0__ts0__ts0_b_a a!60)
       a!61
       (= __ts0__ts0__ts0__ts0__ts0_a_b a!62)
       (= __ts0__ts0_a_b
          (ite __ts0__ts0_c_a
               (__arm.pnd_st |__fml:p| |__fml:a| |__fml:t|)
               (= |__fml:ph| arm_stl_ph)))
       a!63
       a!64
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_b_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_b_a| |__fml:a|)
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_b_a| |__fml:d|)
       (= |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_b_a| __arm.lt)
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           ld)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           lda)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           st)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T1:ltime.t|)
                           stl)))
               (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                           (ref.evs.addr |T2:ltime.t|))
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                           stl)
                        (= (__ts0__ts0__ts0__ts0__m_ref.evs.op_a |T2:ltime.t|)
                           lda))))
         (let ((a!3 (and (not (ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_b_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       a!65
       (= __ts0__ts0__ts0__ts0_a_b_a
          (ite __ts0__ts0_a_b
               a!66
               (__arm.pnd_stl |__fml:p| |__fml:a| |__fml:t|)))
       (= |__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a| __arm.lt)
       (= __ts0__ts0__ts0_b_b_a
          (ite __ts0__ts0_a_b a!50 (= |__fml:ph| arm_stl_isd_ph)))
       a!67
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a| |__fml:a|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a| |__fml:d|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a| |__fml:t|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a| stl)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a| |__fml:a|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a| |__fml:d|)
       a!68
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                        (= (__ref.evs.op |T1:ltime.t|) lda)
                        (= (__ref.evs.op |T1:ltime.t|) st)
                        (= (__ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                           (__ref.evs.addr |T2:ltime.t|))
                        (= (__ref.evs.op |T2:ltime.t|) stl)
                        (= (__ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           ld)
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           lda)
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           st)
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           stl))))
         (let ((a!2 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T2:ltime.t|)
                                stl)
                             (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                                  |T2:ltime.t|)
                                lda)))))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!2))))
       a!69
       a!70
       a!71
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_b_a_a_a| |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|
          (ite __ts0__ts0__ts0_b_b_a |__fml:t| __arm.lt))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           ld)
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           lda)
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           st)
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T1:ltime.t|)
                           stl)))
               (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                           (ref.evs.addr |T2:ltime.t|))
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T2:ltime.t|)
                           stl)
                        (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.op_a_a_a
                             |T2:ltime.t|)
                           lda)))
               (a!3 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                        (= (__ref.evs.op |T1:ltime.t|) lda)
                        (= (__ref.evs.op |T1:ltime.t|) st)
                        (= (__ref.evs.op |T1:ltime.t|) stl)))
               (a!4 (or (= (__ref.evs.addr |T1:ltime.t|)
                           (__ref.evs.addr |T2:ltime.t|))
                        (= (__ref.evs.op |T2:ltime.t|) stl)
                        (= (__ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!5 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!3
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!4)))
         (let ((a!6 (ite __ts0__ts0__ts0_b_b_a
                         (and (not (ref.evs.serialized |T1:ltime.t|))
                              (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                              a!1
                              (= (ref.evs.p |T1:ltime.t|)
                                 (ref.evs.p |T2:ltime.t|))
                              a!2)
                         a!5)))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!6)))))
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a| __ref.gt)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_loc:a_a_a_a|
          (ref.evs.addr |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_loc:d_a_a_a|
          (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.evs.data_a_a_a
            |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a|))
       (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a a!72)
       a!73
       a!74
       (= __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a
          (ite __ts0__ts0__ts0_b_b_a a!75 a!47))
       a!77
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_b_a_a_a| ld)
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (ref.evs.op |T1:ltime.t|) ld)
                        (= (ref.evs.op |T1:ltime.t|) lda)
                        (= (ref.evs.op |T1:ltime.t|) st)
                        (= (ref.evs.op |T1:ltime.t|) stl))))
         (let ((a!2 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (ref.evs.op |T2:ltime.t|) stl)
                             (= (ref.evs.op |T2:ltime.t|) lda)))))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_b_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!2))))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (ref.evs.op |T1:ltime.t|) ld)
                        (= (ref.evs.op |T1:ltime.t|) lda)
                        (= (ref.evs.op |T1:ltime.t|) st)
                        (= (ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                           (ref.evs.addr |T2:ltime.t|))
                        (= (ref.evs.op |T2:ltime.t|) stl)
                        (= (ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_b_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_b_a_a_a| __arm.lt)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a|
          (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a |__fml:t| __arm.lt))
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a_a|
          |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a_a_a|
          (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a ld lda))
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a_a|
          |__fml:a|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a_a|
          |__fml:d|)
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                        (= (__ref.evs.op |T1:ltime.t|) lda)
                        (= (__ref.evs.op |T1:ltime.t|) st)
                        (= (__ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                           (__ref.evs.addr |T2:ltime.t|))
                        (= (__ref.evs.op |T2:ltime.t|) stl)
                        (= (__ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (ref.evs.op |T1:ltime.t|) ld)
                        (= (ref.evs.op |T1:ltime.t|) lda)
                        (= (ref.evs.op |T1:ltime.t|) st)
                        (= (ref.evs.op |T1:ltime.t|) stl))))
         (let ((a!2 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (ref.evs.op |T2:ltime.t|) stl)
                             (= (ref.evs.op |T2:ltime.t|) lda)))))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_a_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!2))))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (ref.evs.op |T1:ltime.t|) ld)
                        (= (ref.evs.op |T1:ltime.t|) lda)
                        (= (ref.evs.op |T1:ltime.t|) st)
                        (= (ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                           (ref.evs.addr |T2:ltime.t|))
                        (= (ref.evs.op |T2:ltime.t|) stl)
                        (= (ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_a_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a
          (not (__arm.isd_ld |__fml:p| |__fml:a| |__fml:t|)))
       (= __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
          (ite __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
               (__arm.pnd_ld |__fml:p| |__fml:a| |__fml:t|)
               (= |__fml:ph| arm_lda_ph)))
       (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a_a
          (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
               a!78
               (__arm.pnd_lda |__fml:p| |__fml:a| |__fml:t|)))
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:inp_a_a_a_a_a_a|
          __arm.lt)
       (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_b_a_a_a_a_a
          (ite __ts0__ts0__ts0__ts0__ts0__ts0_a_b_a_a_a_a
               a!76
               (= |__fml:ph| arm_lda_isd_ph)))
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a_a_a_a_a_a|
          |__fml:t|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:p_a_a_a_a_a_a_a_a|
          |__fml:p|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:op_a_a_a_a_a_a_a|
          lda)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:a_a_a_a_a_a_a_a_a|
          |__fml:a|)
       (= |__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:d_a_a_a_a_a_a_a_a|
          |__fml:d|)
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (__ref.evs.op |T1:ltime.t|) ld)
                        (= (__ref.evs.op |T1:ltime.t|) lda)
                        (= (__ref.evs.op |T1:ltime.t|) st)
                        (= (__ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (__ref.evs.addr |T1:ltime.t|)
                           (__ref.evs.addr |T2:ltime.t|))
                        (= (__ref.evs.op |T2:ltime.t|) stl)
                        (= (__ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_c_a_a_a_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (ref.evs.op |T1:ltime.t|) ld)
                        (= (ref.evs.op |T1:ltime.t|) lda)
                        (= (ref.evs.op |T1:ltime.t|) st)
                        (= (ref.evs.op |T1:ltime.t|) stl))))
         (let ((a!2 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         (or (= (__ref.evs.addr |T1:ltime.t|)
                                (__ref.evs.addr |T2:ltime.t|))
                             (= (ref.evs.op |T2:ltime.t|) stl)
                             (= (ref.evs.op |T2:ltime.t|) lda)))))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_a_a_a_a_a_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!2))))
       (forall ((|T1:ltime.t| ltime.t) (|T2:ltime.t| ltime.t))
         (let ((a!1 (or (= (ref.evs.op |T1:ltime.t|) ld)
                        (= (ref.evs.op |T1:ltime.t|) lda)
                        (= (ref.evs.op |T1:ltime.t|) st)
                        (= (ref.evs.op |T1:ltime.t|) stl)))
               (a!2 (or (= (ref.evs.addr |T1:ltime.t|)
                           (ref.evs.addr |T2:ltime.t|))
                        (= (ref.evs.op |T2:ltime.t|) stl)
                        (= (ref.evs.op |T2:ltime.t|) lda))))
         (let ((a!3 (and (not (__ref.evs.serialized |T1:ltime.t|))
                         (|<:ltime.t:ltime.t| |T1:ltime.t| |T2:ltime.t|)
                         a!1
                         (= (ref.evs.p |T1:ltime.t|) (ref.evs.p |T2:ltime.t|))
                         a!2)))
           (= (__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__m_ref.prevents_b_a_a_a_a_a_a_a
                |T1:ltime.t|
                |T2:ltime.t|)
              a!3))))
       (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a_a_a_a_a
          a!79)
       (= __ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0__ts0_b_a_a_a_a_a_a_a
          (not (__arm.isd_lda |__fml:p| |__fml:a| |__fml:t|)))
       (= __ts0__ts0__ts0__ts0__ts0__ts0_c_a_a_a_a_a
          (= |__fml:ph| arm_ld_isd_ph))
       (= __ts0__ts0__ts0__ts0__ts0_d_a_a_a_a (= |__fml:ph| arm_ld_ph))
       (= __ts0__ts0_c_a (= |__fml:ph| arm_st_isd_ph))
       (= __ts0_d (= |__fml:ph| arm_st_ph))
       a!80)))))
(push 1)
(assert (and (arm.isd_st @P @A @T)))

(check-sat)
(get-info :all-statistics)
