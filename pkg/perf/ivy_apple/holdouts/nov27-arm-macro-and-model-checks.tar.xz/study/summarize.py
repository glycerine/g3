from pathlib import Path
import csv,collections as c,statistics as st
w=Path(__file__).resolve().parent
def medians(name,keys,column):
 d=c.defaultdict(list)
 for r in csv.DictReader((w/(name+'.csv')).open()):
  if r.get('status','match')=='match':d[tuple(r[k] for k in keys)].append(int(r[column]))
 return {k:st.median(v) for k,v in d.items()}
p=c.defaultdict(c.Counter)
for r in csv.DictReader((w/'passes.csv').open()):
 if r['case']=='2' or r['batch']=='6':
  p[r['case'],r['pass'],r['engine']][r['round']]+=int(r['instructions'])
with (w/'pass-summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','pass','g3','native','difference'])
 for case,name in sorted(set(k[:2] for k in p)):
  x=[st.median(p[case,name,en].values()) for en in ('g3','native')];out.writerow([case,name,*x,x[0]-x[1]])
for trial in ['probe-whole','plan-whole','depth','options','model','temps-whole']:
 if not (w/(trial+'.csv')).exists():continue
 whole='whole' in trial;d=medians(trial,['case','mode' if whole else 'threshold'],'instructions')
 for case in sorted(set(k[0] for k in d)):
  print(trial,case,[(mode,round((v/d[case,'base' if whole else ('0' if trial=='depth' else '')]-1)*100,2)) for (k,mode),v in d.items() if k==case])
