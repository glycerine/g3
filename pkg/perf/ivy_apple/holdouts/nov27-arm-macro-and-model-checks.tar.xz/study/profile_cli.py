from pathlib import Path
import subprocess,os,re,csv,collections
w=Path(__file__).resolve().parent;perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'profiles.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['goal','engine','repeats','period','samples','stack'])
 for goal in [6,8]:
  one=(w/f'{goal}.smt2').read_text().split('(get-info')[0]
  for en,exe in [('g3',Path('/tmp/g3-assert-op/cli-base')),('native',Path.cwd().parent/'build/z3')]:
   binary=w/(en+'.perf');reps=12;period=400003
   r=subprocess.run(['taskset','-c','26',perf,'record','-q','-B','-N','-e','instructions:u','-c',str(period),'--call-graph','fp,40' if en=='g3' else 'dwarf,8192','-o',binary,exe,'-smt2','-in'],env=dict(os.environ,GOMAXPROCS='1'),input=((one+'\n(reset)\n')*reps).encode(),capture_output=True,check=True)
   assert r.stdout==b'unsat\n'*reps and not r.stderr,r.stderr
   raw=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',binary],env=dict(os.environ,DEBUGINFOD_URLS=''),text=True)
   counter=collections.Counter()
   for block in raw.strip().split('\n\n'):
    lines=block.splitlines()
    if len(lines)>1:counter['\n'.join(re.sub(r'^\s*[0-9a-f]+\s+','',l).strip() for l in lines[1:])]+=1
   for stack,n in counter.items():out.writerow([goal,en,reps,period,n,stack])
   f.flush()
