from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'ast/macros/macro_expander.go';s=a.read_text()
k='\t\tchanged = true\n\t}';assert s.count(k)==1
s=s.replace(k,'''		changed = true
		next, e := m.manager.RefGet(oldTerm)
		if e != nil { return resultDependency, e }
		if !proofs && m.chargeUnchangedExpansion(next) { break }
	}''')
g=w/'macro_expander.go';g.write_text(s);subprocess.run(['gofmt','-w',g],check=True)
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());ov['Replace'][str(a)]=str(g);j=w/'trial.json';j.write_text(json.dumps(ov))
subprocess.run(['go','build','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'trial','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
