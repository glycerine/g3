from pathlib import Path
import os,json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'smtcore/smt_model_table_check.go';src=a.read_text()
for mode in ('carry','leaf'):
 s=src
 if mode=='carry':
  i=s.index('\t\t// Quantified declarations');j=s.index('\t\tvalue := g.evaluate',i)
  s=s[:i]+s[j:]
  key='\thasAbstractWitness := false'
  s=s.replace(key,'\tfor i, domain := range domains { bindings[len(bindings)-1-i]=domain[0] }\n'+key)
  s=s.replace('if positions[i] < len(domains[i]) {','if positions[i] < len(domains[i]) {\n bindings[len(bindings)-1-i]=domains[i][positions[i]]').replace('positions[i] = 0','positions[i] = 0\n bindings[len(bindings)-1-i]=domains[i][0]')
 else:
  key='return g.evaluate(term.args[i], bindings, depth+1)'
  s=s.replace(key,'''id:=term.args[i]
 child:=&g.terms[id]
 if g.work>1 && depth<64 {
   if child.op==tableConstant {g.work--;return int(child.index)}
   if child.op==tableVariable && uint64(child.index)<uint64(len(bindings)) {v:=bindings[child.index];if v!=0 && g.sorts[v]==child.sort {g.work--;return v}}
 }
 return g.evaluate(id, bindings, depth+1)''')
 b=w/(mode+'.go');b.write_text(s);sp.run(['gofmt','-w',b],check=True)
 ov=json.loads((w/'release.json').read_text());ov['Replace'][str(a)]=str(b);j=w/(mode+'.json');j.write_text(json.dumps(ov))
 sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/mode,'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
sp.run(['python3',w/'whole.py','eval-whole','release','carry','leaf'],check=True,env=dict(os.environ,CASES='2 4 3 6',ROUNDS='7',CPU='20'))
