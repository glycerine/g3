from common import *
import enum_matched_profiles as mp
rd=d/'normal-bool-args';rd.mkdir(exist_ok=True)
def edit(mode):
    a=pkg/'ast/ast_core_span_factories.go';r=pkg/'ast/rewriter/rewriter_configuration.go'
    s=a.read_text();t=r.read_text()
    method='''func(m *ASTManager)UnchangedBooleanArguments(args AppArguments,op int32,flat bool)bool{
      const maxSmall=MAX
      if astValidateHandles||m==nil||!m.lockFree()||args.count<2||args.count>maxSmall{return false}
      var seen [maxSmall]astNodeRef
      ACCESS
      for i:=uint32(0);i<args.count;i++{
        GET
        if h.origin!=m.origin||h.slot==0||h.slot>=m.nextNode{return false}
        slot:=m.nodeSlotAt(h.slot);if !slot.node.live||slot.node.generation!=h.generation{return false}
        ref:=astNodeRef{h.slot,h.generation}
        if slot.node.kind==ASTApp{
          app:=&slot.app;if !app.declCached{return false}
          if app.declFamily==m.BasicFamilyID(){
            if flat&&app.declKind==op||ref==m.trueApp||ref==m.falseApp{return false}
            if app.declKind==ASTOpNot{if app.count!=1{return false};ref=app.inlineArgs[0]}
          }
        }
        for j:=uint32(0);j<i;j++{if seen[j]==ref{return false}}
        seen[i]=ref
      }
      return true
    }
    '''
    access='';get='h,e:=args.At(i);if e!=nil{return false}'
    if 'slice' in mode:
        access='if args.appOwner!=nil||args.raw||uint64(args.argumentOffset)+uint64(args.count)>uint64(len(args.slice)){return false};xs:=args.slice[args.argumentOffset:args.argumentOffset+args.count]'
        get='h:=xs[i]'
    s+='\n'+method.replace('MAX',str(int(re.search(r'\d+',mode)[0]))).replace('GET',get).replace('ACCESS',access)
    t=once(t,'case ast.ASTOpOr:\n\t\tif rw.flat {','case ast.ASTOpOr:\n if (!rw.localContext || rw.localContextCost>rw.localContextLimit) && rw.manager.UnchangedBooleanArguments(args,op,rw.flat){return brFailed,nil}\n if rw.flat {')
    t=once(t,'case ast.ASTOpAnd:\n\t\tif rw.elimAnd {','case ast.ASTOpAnd:\n if !rw.elimAnd && rw.manager.UnchangedBooleanArguments(args,op,rw.flat){return brFailed,nil}\n if rw.elimAnd {')
    return {a:s,r:t}
def make(mode):
    q=rd/mode;q.mkdir(exist_ok=True);o=overlay(q/'overlay',edit(mode));b=q/'g3'
    with(w/'build.lock').open('a')as lk,(q/'build.log').open('w')as l:
        fcntl.flock(lk,fcntl.LOCK_SH)
        run(['go','test','-p','3','-count=1','-overlay='+str(o),'-run','BoolRewriter|BoolGate|TheoryRewriter|RewriterEngine|ScopeRestor','./ast/rewriter','./smtcore'],cwd=pkg,stdout=l,stderr=l)
        run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
    return b
def probe(tag,c,bs):
    sd=rd/tag;sd.mkdir(exist_ok=True);src=mp.rd/tag/'input.smt2' if tag.startswith('miss')else d/'qi-repeat-cost'/tag/'input.smt2';ref=None
    with(sd/'runs.csv').open('w')as f:
        wr=csv.writer(f);wr.writerow('round engine answer decisions conflicts qi resource instructions cycles'.split())
        for i in range(3):
            vs=list(bs)
            for name in vs[i:]+vs[:i]:
                pf=sd/'perf';res=run(['taskset','-c',str(c),perf,'stat','-x,','-e','instructions:u,cycles:u','-o',pf,'--',bs[name],'-st','-smt2',src],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
                st={k:v for k,v in mp.pars.findall(res.stdout) if not any(x in k for x in ('time','alloc','memory'))}
                key=(res.stdout.splitlines()[0],st);assert ref is None or key==ref,(tag,name,key,ref);ref=key
                counts=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l]
                wr.writerow([i+1,name,key[0],*[st.get(k,0)for k in ('decisions','conflicts','quant-instantiations','rlimit-count')],*counts]);f.flush()
if __name__=='__main__':
    vs=['any8','slice8','slice16','any16']
    with ThreadPoolExecutor(2)as ex:bs={'release':d/'release-arena-generation/g3',**dict(zip(vs,ex.map(make,vs)))}
    with ThreadPoolExecutor(6)as ex:list(ex.map(lambda j:probe(*j,bs),zip(['miss1','miss3','miss6','core1','core3','core6'],[1,5,16,21,28,34])))
