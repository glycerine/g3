from common import *
import enum_matched_profiles as mp
rd=d/'qi-root-shapes';rd.mkdir(exist_ok=True)
def make():
    p=pkg/'smtcore/smt_qi_instance.go';u=pkg/'smtcore/smt_quantifier_manager.go';r=pkg/'ast/rewriter/th_rewriter.go'
    a=r.read_text()+'''
    func(r *TheoryRewriter) StudyHasRootMapping(h ast.ASTHandle)(bool,error){
       if !r.configuration.hasSubstitution{return false,nil}
       return r.manager.ExprSubstitutionContains(r.configuration.substitution,h)
    }'''
    s=once(p.read_text(),'import (','import ("os";')
    s=once(s,'type SMTQIInstanceBuilder struct {','''type rootShape struct{op,arity int; depth,shared,sharedApp,equal,truth,neg,disj,ite,uninterp,others,subst uint16}
    type rootCounts struct{seen,work,repeats,repeatedSteps uint64}
    type SMTQIInstanceBuilder struct {
        rootShape map[rootShape]*rootCounts
        rootIdentity map[ast.ASTHandle]bool''')
    i=s.index('return b.Finish(prepared, rewritten, stat, scope)')
    s=s[:i]+'''if err=b.studyShape(instance,rewritten,rw);err!=nil{return nil,err}
    '''+s[i:]
    s+='''
    func(b *SMTQIInstanceBuilder)studyShape(in,out ast.ASTHandle,rw *rewriter.TheoryRewriter)error{
        if b.rootShape==nil{b.rootShape=make(map[rootShape]*rootCounts);b.rootIdentity=make(map[ast.ASTHandle]bool)}
        same:=in==out;prior:=b.rootIdentity[in];b.rootIdentity[in]=same
        if !same{return nil}
        n,_:=rw.NumSteps();var sh rootShape
        var visit func(ast.ASTHandle,int)error
        visit=func(h ast.ASTHandle,depth int)error{
            if depth>12{return nil}
            hd,e:=b.manager.NodeHeader(h);if e!=nil{return e}
            if hd.RefCount>1 {sh.shared++;if hd.NumArgs>0{sh.sharedApp++}}
            if uint16(depth)>sh.depth{sh.depth=uint16(depth)}
            if depth==0 {sh.op=int(hd.DeclKind);if hd.Family!=b.manager.BasicFamilyID(){sh.op=-1};sh.arity=int(hd.NumArgs)}
            mapping,e:=rw.StudyHasRootMapping(h);if e!=nil{return e};if mapping{sh.subst++}
            switch {
            case hd.Kind!=ast.ASTApp:sh.others++
            case hd.Family==ast.NullFamilyID:sh.uninterp++
            case hd.Family!=b.manager.BasicFamilyID():sh.others++
            default:switch hd.DeclKind{
            case ast.ASTOpEq,ast.ASTOpIff:sh.equal++
            case ast.ASTOpTrue,ast.ASTOpFalse:sh.truth++
            case ast.ASTOpNot:sh.neg++
            case ast.ASTOpOr,ast.ASTOpAnd:sh.disj++
            case ast.ASTOpIte:sh.ite++
            default:sh.others++
            }}
            for i:=uint32(0);i<hd.NumArgs;i++{ch,e:=b.manager.GetArg(h,i);if e!=nil{return e};if e=visit(ch,depth+1);e!=nil{return e}}
            return nil
        }
        if e:=visit(in,0);e!=nil{return e};c:=b.rootShape[sh];if c==nil{c=&rootCounts{};b.rootShape[sh]=c};c.seen++;c.work+=uint64(n)
        if prior{c.repeats++;c.repeatedSteps+=uint64(n)};return nil
    }
    func(b *SMTQIInstanceBuilder)dumpRootShapes(){if b==nil{return};for s,r:=range b.rootShape{fmt.Fprintf(os.Stderr,"ROOTSHAPE %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\\n",s.op,s.arity,s.depth,s.shared,s.sharedApp,s.equal,s.truth,s.neg,s.disj,s.ite,s.uninterp,s.others,s.subst,r.seen,r.work,r.repeats,r.repeatedSteps)};b.rootShape=nil;b.rootIdentity=nil}'''
    z=once(u.read_text(),'func (q *SMTQuantifierManager) Close() error {','func (q *SMTQuantifierManager) Close() error {\n if q!=nil{q.builder.dumpRootShapes()}')
    o=overlay(rd/'overlay',{p:s,u:z,r:a});b=rd/'g3'
    with(w/'build.lock').open('a')as lk,(rd/'build.log').open('w') as l:
        fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','3','-tags=xtrace_off','-buildvcs=false','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
    return b
def probe(job,b):
    tag,c=job;src=mp.rd/tag/'input.smt2' if tag.startswith('miss')else d/'qi-repeat-cost'/tag/'input.smt2'
    ref=(mp.rd/tag/'1-g3/stdout').read_text()if tag.startswith('miss') else (d/'qi-repeat-cost'/tag/'release.stdout').read_text()
    p=run(['taskset','-c',str(c),b,'-st','-smt2',src],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
    stats=lambda s:{k:v for k,v in mp.pars.findall(s)if not any(w in k for w in ('memory','alloc','time'))}
    assert p.stdout.splitlines()[0]==ref.splitlines()[0] and stats(p.stdout)==stats(ref)
    ls=p.stderr.splitlines();assert ls and all(l.startswith('ROOTSHAPE ')for l in ls)
    with(rd/(tag+'.csv')).open('w')as f:
        wr=csv.writer(f);wr.writerow('op arity depth shared sharedApp equal truth neg disj ite uninterp others subst seen steps repeats repeatSteps'.split());wr.writerows(l.split()[1:]for l in ls)
if __name__=='__main__':
    b=make()
    with ThreadPoolExecutor(6)as ex:list(ex.map(lambda j:probe(j,b),zip(['miss1','miss3','miss6','core1','core3','core6'],[4,6,9,16,21,32])))
