from common import *
import enum_matched_profiles as mp
rd=d/'qi-repeat-cost';rd.mkdir(exist_ok=True)
def make():
    p=pkg/'smtcore/smt_qi_instance.go';u=pkg/'smtcore/smt_quantifier_manager.go'
    s=once(p.read_text(),'import (','import ("os";')
    s=once(s,'type SMTQIInstanceBuilder struct {','''type qiRootCost struct {input ast.ASTHandle; charge uint64; steps uint32}
    type qiRepeatCost struct {all,identity,hits,loss,stepDiff,costDiff,savedSteps,seenSteps,savedCharge,seenCharge uint64}
    type SMTQIInstanceBuilder struct {
    rootCache []qiRootCost
    rootTotals qiRepeatCost''')
    src='if err = rw.Rewrite(instance, simplified); err != nil {'
    src2='''mode:=studyCacheKind
        if mode!="" && b.rootCache==nil{b.rootCache=make([]qiRootCost, 16384)}
        index:=int(instance.Slot()&16383)
        limit:=b.manager.ResourceLimit()
        prev:=qiRootCost{}
        if b.rootCache!=nil {prev=b.rootCache[index]}
        start:=limit.Count()
        if mode=="replay" && prev.input==instance && prev.charge<=uint64(^uint32(0)) && limit.TryIncOffset(uint32(prev.charge)){
            b.rootTotals.hits++;b.rootTotals.savedCharge+=prev.charge
            if err=b.manager.SetRef(simplified,instance);err!=nil{return nil,err}
            return b.Finish(prepared,instance,stat,scope)
        }
        '''+src
    s=once(s,src,src2)
    t='return b.Finish(prepared, rewritten, stat, scope)'
    s=once(s,t,'''if mode!=""{
       n,_:=rw.NumSteps();charge:=limit.Count()-start
       r:=&b.rootTotals;r.all++;r.seenSteps+=uint64(n);r.seenCharge+=charge
       if prev.input==instance{r.hits++;if rewritten!=instance{r.loss++};if prev.steps!=n{r.stepDiff++};if prev.charge!=charge{r.costDiff++};r.savedSteps+=uint64(n);r.savedCharge+=charge}
       if rewritten==instance{r.identity++;b.rootCache[index]=qiRootCost{instance,charge,n}}else{b.rootCache[index]=qiRootCost{}}
    };'''+t)
    s+='''
    var studyCacheKind=os.Getenv("G3_QI_REPEAT")
    func(b *SMTQIInstanceBuilder)dumpStudyCost(){if b==nil||b.rootCache==nil{return};r:=b.rootTotals;fmt.Fprintf(os.Stderr,"ROOTCOST %d %d %d %d %d %d %d %d %d %d\\n",r.all,r.identity,r.hits,r.loss,r.stepDiff,r.costDiff,r.savedSteps,r.seenSteps,r.savedCharge,r.seenCharge);b.rootCache=nil}
    '''
    z=once(u.read_text(),'func (q *SMTQuantifierManager) Close() error {','func (q *SMTQuantifierManager) Close() error {\n if q!=nil{q.builder.dumpStudyCost()}')
    # Deliberately scoped to the current search, including all remaining ResourceLimit accounting.
    for sig in ('InitSearch()','PushScope()','PopScopes(count uint32)'):
        start=z.index('func (q *SMTQuantifierManager) '+sig+' error {')+len('func (q *SMTQuantifierManager) '+sig+' error {')
        z=z[:start]+'\n if studyCacheKind=="scope"||studyCacheKind=="replay"{if q!=nil && q.builder!=nil{clear(q.builder.rootCache)}}\n'+z[start:]
    o=overlay(rd/'overlay',{p:s,u:z});b=rd/'g3'
    with(w/'build.lock').open('a')as lk,(rd/'build.log').open('w')as l:
        fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','3','-tags=xtrace_off','-buildvcs=false','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
    return b
def probe(j,b):
    tag,c=j;sd=rd/tag;sd.mkdir(exist_ok=True)
    if tag.startswith('miss'):
        src=mp.rd/tag/'input.smt2'
    else:
        import importlib.util
        spec=importlib.util.spec_from_file_location('portable',pkg/'perf/ivy_apple/holdouts/enumeration_budget.py')
        portable=importlib.util.module_from_spec(spec);spec.loader.exec_module(portable)
        import gzip
        with gzip.open(portable.FIXTURE,'rt')as f:fixture=json.load(f)
        src=sd/'input.smt2';src.write_text(portable.query_text(fixture,int(tag[-1]),'core',6000000))
    stats=lambda s:{k:v for k,v in mp.pars.findall(s)if not any(w in k for w in ('memory','alloc','time'))}
    with(sd/'runs.csv').open('w')as f:
        wr=csv.writer(f);wr.writerow('mode answer exact differing instructions cycles'.split());ref=None
        for mode in ['release','audit','scope','replay']:
            pf=sd/'perf';e=dict(env,GOMAXPROCS='1',G3_QI_REPEAT=mode if mode!='release'else'')
            p=run(['taskset','-c',str(c),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',pf,'--',d/'release-arena-generation/g3' if mode=='release'else b,'-st','-smt2',src],env=e,capture_output=True,text=True)
            key=p.stdout.splitlines()[0],stats(p.stdout)
            if ref is None:ref=key
            assert key[0] in ('unknown','unsat') and (mode=='replay' or key==ref)
            (sd/(mode+'.stdout')).write_text(p.stdout)
            lines=p.stderr.splitlines();assert all(l.startswith('ROOTCOST ')for l in lines) and (mode=='release' or lines)
            with(sd/(mode+'.csv')).open('w')as sf:
                z=csv.writer(sf);z.writerow('executed identity hits lost_identity step_mismatch charge_mismatch saved_steps all_steps saved_charge all_charge'.split());z.writerows(l.split()[1:]for l in lines)
            ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];wr.writerow([mode,key[0],int(key==ref),' '.join(k for k in ref[1].keys()|key[1].keys()if ref[1].get(k)!=key[1].get(k)),*ct]);f.flush()
if __name__=='__main__':
    b=make()
    with ThreadPoolExecutor(6)as ex:list(ex.map(lambda j:probe(j,b),zip(['miss1','miss3','miss6','core1','core3','core6'],[2,4,10,16,30,34])))
