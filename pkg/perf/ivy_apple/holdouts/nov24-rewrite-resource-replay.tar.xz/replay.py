#!/usr/bin/env python3
"""Build one or more archived Go overlays and compare the complete searches on Linux."""
import argparse
import csv
import gzip
import json
import os
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
MODES = ("release", "audit", "scope", "replay", "shape", "any8", "slice8", "slice16", "any16")
STAT = re.compile(r":([\w-]+)\s+(\d+)(?=[\s)])")


def build(pkg, output, mode):
    changes = [] if mode == "release" else sorted((HERE / "overlays" / mode).glob("**/*.go"))
    if mode != "release" and not changes:
        raise ValueError(f"missing overlay for {mode}")
    flags = []
    if changes:
        base = HERE / "overlays" / mode
        replacements = {str(pkg / p.relative_to(base)): str(p) for p in changes}
        overlay = output / "overlay.json"
        overlay.write_text(json.dumps({"Replace": replacements}))
        flags = ["-overlay=" + str(overlay)]
    binary = output / "g3"
    subprocess.run(["go", "build", "-pgo=off", "-tags=xtrace_off", *flags,
                    "-o", binary, "./cmd/g3"], cwd=pkg, check=True)
    return binary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pkg", required=True, type=Path, help="pkg directory of commit ef71a41c5")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--modes", nargs="+", choices=MODES, default=MODES)
    parser.add_argument("--queries", nargs="+", choices=["miss1", "miss3", "miss6", "core1", "core3", "core6"],
                        default=["miss1", "miss3", "miss6", "core1", "core3", "core6"])
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--cpu", type=int, required=True)
    parser.add_argument("--perf", help="perf executable for retired user instructions and cycles")
    args = parser.parse_args()
    if args.rounds < 1:
        parser.error("--rounds must be positive")
    modes = list(dict.fromkeys(["release", *args.modes]))
    pkg = args.pkg.resolve(strict=True)
    root = args.output.resolve()
    root.mkdir(parents=True)
    binaries = {}
    for mode in modes:
        source = "audit" if mode in ("scope", "replay") else mode
        if source not in binaries:
            folder = root / source
            folder.mkdir()
            binaries[source] = build(pkg, folder, source)
        binaries[mode] = binaries[source]
    with (root / "results.csv").open("w") as f:
        writer = csv.writer(f)
        writer.writerow(("query", "round", "mode", "answer", "resources", "instructions", "cycles"))
        for query in args.queries:
            reference = None
            for rotation in range(args.rounds):
                offset = rotation % len(modes)
                for mode in modes[offset:] + modes[:offset]:
                    name = f"{query}-{rotation + 1}-{mode}"
                    command = ["taskset", "-c", str(args.cpu)]
                    counter = root / (name + ".stat")
                    if args.perf:
                        command += [args.perf, "stat", "-x,", "-e", "instructions:u,cycles:u", "-o", counter, "--"]
                    command += [binaries[mode], "-st", "-smt2", HERE / "queries" / (query + ".smt2")]
                    proc = subprocess.run(command, env=dict(os.environ, GOMAXPROCS="1", XTRACE_OFF="1",
                                          G3_QI_REPEAT=mode if mode in ("audit", "scope", "replay") else ""),
                                          capture_output=True, text=True, check=True)
                    answer = proc.stdout.splitlines()[0]
                    stats = {k: v for k, v in STAT.findall(proc.stdout)
                             if not any(s in k for s in ("memory", "alloc", "time"))}
                    expected = "unknown" if query.startswith("miss") else "unsat"
                    if answer != expected or "rlimit-count" not in stats:
                        raise ValueError((name, answer, stats))
                    if reference is not None and (answer, stats) != reference:
                        raise ValueError((name, reference, answer, stats))
                    reference = answer, stats
                    prefix = "ROOTCOST " if mode in ("audit", "scope", "replay") else "ROOTSHAPE " if mode == "shape" else None
                    lines = proc.stderr.splitlines()
                    if (prefix and (not lines or any(not line.startswith(prefix) for line in lines))) or (not prefix and lines):
                        raise ValueError((name, proc.stderr[:400]))
                    with gzip.open(root / (name + ".stderr.gz"), "wt") as log:
                        log.write(proc.stderr)
                    (root / (name + ".stdout")).write_text(proc.stdout)
                    counts = [int(row.split(",")[0]) for row in counter.read_text().splitlines() if ":u" in row] if args.perf else ["", ""]
                    if len(counts) != 2:
                        raise ValueError((name, counts))
                    writer.writerow([query, rotation + 1, mode, answer, stats["rlimit-count"], *counts])
                    f.flush()


if __name__ == "__main__":
    main()
