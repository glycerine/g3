package ast

// Source: src/ast/ast_util.cpp:173-180; src/ast/ast.cpp:2064-2211.

// This concrete call-local argument reader selects actual borrowed storage.
// It never clones a pointer array or grants ownership of its elements.
type AppArguments struct {
	argumentOffset uint32
	app            ASTHandle
	appOwner       *ASTManager
	slice          []ASTHandle
	spanOwner      *ASTLiteralVector
	count          uint32
	raw            bool
}

func (a *AppArguments) at(i uint32) (ASTHandle, error) {
	if i >= a.count || i > ^uint32(0)-a.argumentOffset {
		return ASTHandle{}, ErrASTDomain
	}
	i += a.argumentOffset
	if a.appOwner != nil {
		m := a.appOwner
		r, e := m.requireKind(a.app, ASTApp)
		if e != nil {
			return ASTHandle{}, e
		}
		app := m.appAt(r.slot)
		if i >= app.count {
			return ASTHandle{}, ErrASTDomain
		}
		child, e := m.appArg(app, i)
		return m.external(child), e
	}
	if a.raw {
		return (ASTLiteralVectorSpan{owner: a.spanOwner, values: a.slice}).At(i)
	}
	return a.slice[i], nil
}

func (a AppArguments) size() uint64 { return uint64(a.count) }
func (m *ASTManager) MkOrSpan(n uint32, span ASTLiteralVectorSpan) (ASTHandle, error) {
	if e := m.lock(); e != nil {
		return ASTHandle{}, e
	}
	defer m.mu.Unlock()
	switch n {
	case 0:
		return m.external(m.falseApp), nil
	case 1:
		return span.At(0)
	}
	// Source basic-plugin expr overload uses this same OR declaration.
	if !m.pluginAt(0).present {
		return ASTHandle{}, nil
	}
	r, e := m.mkAppArguments(m.basic.declarations[ASTOpOr], AppArguments{spanOwner: span.owner, slice: span.values, count: n, raw: true})
	return m.external(r), e
}

// At reads a borrowed argument without acquiring ownership.
func (a AppArguments) At(i uint32) (ASTHandle, error) { return a.at(i) }
func (a AppArguments) Count() uint32                  { return a.count }
func (a AppArguments) Size() uint64                   { return a.size() }
func SliceArguments(values []ASTHandle) AppArguments {
	return AppArguments{slice: values, count: uint32(len(values))}
}
func (m *ASTManager) UpdateQuantifierArguments(q, body ASTHandle, patterns, noPatterns AppArguments) (ASTHandle, error) {
	return m.updateQuantifierArguments(q, body, false, 0, patterns, noPatterns, astUpdatePatterns|astUpdateNoPatterns)
}

// Range borrows a checked subrange without copying its backing arguments.
func (a AppArguments) Range(offset, count uint32) (AppArguments, error) {
	if offset > a.count || count > a.count-offset {
		return AppArguments{}, ErrASTDomain
	}
	if offset > ^uint32(0)-a.argumentOffset {
		return AppArguments{}, ErrASTDomain
	}
	a.argumentOffset += offset
	a.count = count
	return a, nil
}

func (a *AppArguments) hasPreparedSlice() bool {
	return a.appOwner == nil && !a.raw && a.count <= astPreparedAppArgs &&
		uint64(a.argumentOffset)+uint64(a.count) <= uint64(len(a.slice))
}

func (m *ASTManager) UnchangedBooleanArguments(args AppArguments, op int32, flat bool) bool {
	const maxSmall = 8
	if astValidateHandles || m == nil || !m.lockFree() || args.count < 2 || args.count > maxSmall {
		return false
	}
	var seen [maxSmall]astNodeRef
	if args.appOwner != nil || args.raw || uint64(args.argumentOffset)+uint64(args.count) > uint64(len(args.slice)) {
		return false
	}
	xs := args.slice[args.argumentOffset : args.argumentOffset+args.count]
	for i := uint32(0); i < args.count; i++ {
		h := xs[i]
		if h.origin != m.origin || h.slot == 0 || h.slot >= m.nextNode {
			return false
		}
		slot := m.nodeSlotAt(h.slot)
		if !slot.node.live || slot.node.generation != h.generation {
			return false
		}
		ref := astNodeRef{h.slot, h.generation}
		if slot.node.kind == ASTApp {
			app := &slot.app
			if !app.declCached {
				return false
			}
			if app.declFamily == m.BasicFamilyID() {
				if flat && app.declKind == op || ref == m.trueApp || ref == m.falseApp {
					return false
				}
				if app.declKind == ASTOpNot {
					if app.count != 1 {
						return false
					}
					ref = app.inlineArgs[0]
				}
			}
		}
		for j := uint32(0); j < i; j++ {
			if seen[j] == ref {
				return false
			}
		}
		seen[i] = ref
	}
	return true
}
