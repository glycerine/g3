package smtcore

// Source: src/smt/smt_quantifier.cpp quantifier_manager propagation, queue
// instantiation, quick checking, final-check arbitration, and scope lifecycle.

import (
	"errors"
	"fmt"
	"strings"

	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/ast/rewriter"
	protomodel "github.com/glycerine/g3/pkg/smtcore/proto_model"
	"github.com/glycerine/g3/pkg/util/diagnostic"
	"github.com/glycerine/g3/pkg/util/lbool"
	usymbol "github.com/glycerine/g3/pkg/util/symbol"
)

// SMTQuantifierManager composes the concrete quantifier components owned by
// the Go SMT context. Pattern matching and model-based checking add instances
// through Registry; this manager schedules and internalizes those instances.
type SMTQuantifierManager struct {
	state           *SMTInternalizerState
	registry        *SMTQuantifierRegistry
	rewriter        *rewriter.TheoryRewriter
	checker         *SMTChecker
	substitute      *SMTCachedVarSubstitution
	builder         *SMTQIInstanceBuilder
	mam             *smtMAMImpl
	lazyMAM         *smtMAMImpl
	modelFinder     *SMTModelFinder
	modelChecker    *SMTModelChecker
	auxiliarySolver smtAuxiliarySolverFactory
	candidateModel  func() (*SMTModelGenerator, error)
	acceptedModel   *SMTModelGenerator
	// retiredProto is context::m_proto_model after MBQI rejected it: it
	// stays alive until the next mk_proto_model has built its successor, or
	// the search starts or ends.
	retiredProto *protomodel.ProtoModel
	// active is default_qm_plugin::m_active: set by add (MBQI) and
	// assign_eh, never reset.
	pluginActive                bool
	newEnodeHead                int
	newEnodeScopes              []int
	lazyMatchingIndex           uint32
	lazyMatchingTrail           []uint32
	lazyMatchingScopes          []int
	maxEagerMultipatterns       uint32
	maxLazyMultipatternMatching uint32
	lazyInstantiation           bool
	promoteUnsat                bool
	ematching                   bool
	quickUnsat                  bool
	quickNotSat                 bool
	lazyQuick                   bool
	mbqi                        bool
	mbqiID                      string
	mbqiTrace                   bool
	closed                      bool
	flushed                     bool // flush ran; Close finishes the teardown
	pendingPop                  *smtQuantifierPendingPop
}

type smtQuantifierPendingPop struct {
	count uint32
	// A completed child scope cannot be popped again when a later owner
	// refuses native cleanup.
	stage uint8
}

type SMTQuantifierManagerConfig struct {
	MaxEagerMultipatterns       uint32
	MaxLazyMultipatternMatching uint32
	LazyInstantiation           bool
	Ematching                   bool
	PromoteUnsat                bool
	QuickUnsat                  bool
	QuickNotSat                 bool
	LazyQuick                   bool
	MBQI                        bool
	MaxCexs                     uint32
	MaxIterations               uint32
	ForceTemplate               uint32
	MBQIID                      string
	MBQITrace                   bool
	CandidateModel              func() (*SMTModelGenerator, error)
}

func NewSMTQuantifierManager(state *SMTInternalizerState, rw *rewriter.TheoryRewriter, config SMTQuantifierManagerConfig) (*SMTQuantifierManager, error) {
	if state == nil || state.manager == nil || state.quantifiers == nil || rw == nil || rw.Manager() != state.manager {
		return nil, ast.ErrASTHandle
	}
	if state.quantifierManager != nil {
		return nil, ast.ErrASTDomain
	}
	checker, err := NewSMTChecker(state.context)
	if err != nil {
		return nil, err
	}
	substitute, err := NewSMTCachedVarSubstitution(state.manager)
	if err != nil {
		if substitute != nil {
			err = errors.Join(err, substitute.Close())
		}
		return nil, err
	}
	builder, err := NewSMTQIInstanceBuilder(state.manager, checker, substitute, state.quantifiers.costs)
	if err != nil {
		return nil, errors.Join(err, substitute.Close())
	}
	builder.registry = state.quantifiers
	mam := newSMTMAMImpl(state, state.quantifiers, true)
	lazyMAM := newSMTMAMImpl(state, state.quantifiers, true)
	modelFinder, err := NewSMTModelFinder(state)
	if err != nil {
		return nil, errors.Join(err, substitute.Close())
	}
	modelFinder.SetForceTemplate(config.ForceTemplate)
	result := &SMTQuantifierManager{
		state: state, registry: state.quantifiers, rewriter: rw, checker: checker,
		substitute: substitute, builder: builder, mam: mam, lazyMAM: lazyMAM, modelFinder: modelFinder,
		maxEagerMultipatterns:       config.MaxEagerMultipatterns,
		maxLazyMultipatternMatching: config.MaxLazyMultipatternMatching,
		lazyInstantiation:           config.LazyInstantiation,
		promoteUnsat:                config.PromoteUnsat, ematching: config.Ematching,
		quickUnsat: config.QuickUnsat, quickNotSat: config.QuickNotSat, lazyQuick: config.LazyQuick,
		mbqi: config.MBQI, mbqiID: config.MBQIID, mbqiTrace: config.MBQITrace, candidateModel: config.CandidateModel,
	}
	if config.MBQI {
		result.modelChecker, err = NewSMTModelChecker(state, config.MaxCexs)
		if err != nil {
			return nil, errors.Join(err, modelFinder.Close(), substitute.Close())
		}
		result.modelChecker.trace = config.MBQITrace
		if err = result.modelChecker.ConfigureLifecycle(config.MaxCexs, config.MaxIterations); err != nil {
			return nil, errors.Join(err, result.modelChecker.Close(), modelFinder.Close(), substitute.Close())
		}
		if err = result.modelChecker.SetModelFinder(modelFinder); err != nil {
			return nil, errors.Join(err, result.modelChecker.Close(), modelFinder.Close(), substitute.Close())
		}
	}
	state.quantifierManager = result
	return result, nil
}

func (q *SMTQuantifierManager) UpdateMBQI(enabled bool, identifier string, maxCexs, maxIterations, forceTemplate uint32) error {
	if err := q.open(); err != nil {
		return err
	}
	if enabled && q.modelChecker == nil {
		checker, err := NewSMTModelChecker(q.state, maxCexs)
		if err != nil {
			return err
		}
		if err = checker.ConfigureLifecycle(maxCexs, maxIterations); err != nil {
			return errors.Join(err, checker.Close())
		}
		if err = checker.SetModelFinder(q.modelFinder); err != nil {
			return errors.Join(err, checker.Close())
		}
		if err = checker.SetAuxiliarySolverFactory(q.auxiliarySolver); err != nil {
			return errors.Join(err, checker.Close())
		}
		q.modelChecker = checker
	} else if enabled {
		if err := q.modelChecker.ConfigureLifecycle(maxCexs, maxIterations); err != nil {
			return err
		}
	} else if q.modelChecker != nil {
		if err := q.modelChecker.Close(); err != nil {
			return err
		}
		q.modelChecker = nil
	}
	if q.modelChecker != nil {
		q.modelChecker.trace = q.mbqiTrace
	}
	q.mbqi = enabled
	q.mbqiID = identifier
	q.modelFinder.SetForceTemplate(forceTemplate)
	return nil
}

func (q *SMTQuantifierManager) SetAuxiliarySolverFactory(factory smtAuxiliarySolverFactory) error {
	if err := q.open(); err != nil {
		return err
	}
	q.auxiliarySolver = factory
	if q.modelChecker == nil {
		return nil
	}
	return q.modelChecker.SetAuxiliarySolverFactory(factory)
}

func (q *SMTQuantifierManager) open() error {
	if err := q.openOwner(); err != nil {
		return err
	}
	if q.pendingPop != nil {
		return ast.ErrASTPending
	}
	return nil
}

func (q *SMTQuantifierManager) openOwner() error {
	if q == nil || q.state == nil || q.registry == nil || q.builder == nil || q.closed {
		return ast.ErrASTHandle
	}
	return nil
}

func (q *SMTQuantifierManager) InitSearch() error {
	if studyCacheKind == "scope" || studyCacheKind == "replay" {
		if q != nil && q.builder != nil {
			clear(q.builder.rootCache)
		}
	}

	if err := q.open(); err != nil {
		return err
	}
	q.lazyMatchingIndex = 0
	if err := q.releaseRetiredProto(); err != nil {
		return err
	}
	if q.acceptedModel != nil {
		if err := q.acceptedModel.Close(); err != nil {
			return err
		}
		q.acceptedModel = nil
	}
	if err := q.substitute.Reset(); err != nil {
		return err
	}
	if err := q.modelFinder.InitSearch(); err != nil {
		return err
	}
	if q.modelChecker != nil {
		if err := q.modelChecker.InitSearch(); err != nil {
			return err
		}
	}
	return q.registry.InitSearch()
}

func (q *SMTQuantifierManager) CanPropagate() bool {
	if q == nil || q.closed || q.registry == nil {
		return false
	}
	// quantifier_manager::can_propagate: m_qi_queue.has_work() ||
	// m_plugin->can_propagate() (m_mam->has_work()).
	// Enodes created since the last scan are not work: propagate() scans
	// them on its next (unconditional) call.
	return q.registry.schedule.HasWork() || q.mam.HasWork()
}

// propagates reports whether context::propagate's unconditional
// m_qmanager->propagate() reaches this manager.
func (q *SMTQuantifierManager) propagates() bool {
	return q != nil && !q.closed && q.registry != nil
}

// Source default_qm_plugin::propagate scans newly internalized enodes when
// relevancy is disabled, since no relevant_eh notifications will arrive.
func (q *SMTQuantifierManager) hasNewEnodes() bool {
	return q.ematching && !q.registry.Empty() && q.state.relevancy != nil && !q.state.relevancy.enabled && q.newEnodeHead < len(q.state.enodeStack)
}

func (q *SMTQuantifierManager) notifyNewEnodes() {
	if !q.hasNewEnodes() {
		return
	}
	for _, node := range q.state.enodeStack[q.newEnodeHead:] {
		q.mam.RelevantEh(node, false)
		q.lazyMAM.RelevantEh(node, true)
	}
	q.newEnodeHead = len(q.state.enodeStack)
}

// AssignQuantifier is default_qm_plugin::assign_eh, called when a
// quantifier atom is propagated with value true (context::assign_quantifier).
func (q *SMTQuantifierManager) AssignQuantifier(quantifier ast.ASTHandle) error {
	if err := q.open(); err != nil {
		return err
	}
	q.pluginActive = true
	if !q.ematching {
		return nil
	}
	count, err := q.state.manager.GetNumPatterns(quantifier)
	if err != nil {
		return err
	}
	hasUnary := false
	for i := uint32(0); i < count; i++ {
		pattern, err := q.state.manager.GetPattern(quantifier, i)
		if err != nil {
			return err
		}
		terms, err := q.state.manager.GetNumArgs(pattern)
		if err != nil {
			return err
		}
		if terms == 1 {
			hasUnary = true
			break
		}
	}
	eagerLimit := q.maxEagerMultipatterns
	if !hasUnary {
		eagerLimit++
	}
	recursive, err := q.state.manager.IsRecursiveFunctionDefinition(quantifier)
	if err != nil {
		return err
	}
	for i, j := uint32(0), uint32(0); i < count; i++ {
		pattern, err := q.state.manager.GetPattern(quantifier, i)
		if err != nil {
			return err
		}
		terms, err := q.state.manager.GetNumArgs(pattern)
		if err != nil {
			return err
		}
		unary := terms == 1
		if recursive && i > 0 {
			// add only the first pattern
		} else if !unary && j >= eagerLimit {
			err = q.lazyMAM.AddPattern(quantifier, pattern)
		} else {
			err = q.mam.AddPattern(quantifier, pattern)
		}
		if err != nil {
			return err
		}
		if !unary {
			j++
		}
	}
	return nil
}

func (q *SMTQuantifierManager) PushScope() error {
	if studyCacheKind == "scope" || studyCacheKind == "replay" {
		if q != nil && q.builder != nil {
			clear(q.builder.rootCache)
		}
	}

	if err := q.open(); err != nil {
		return err
	}
	if err := q.modelFinder.PushScope(); err != nil {
		return err
	}
	q.mam.PushScope()
	q.lazyMAM.PushScope()
	q.newEnodeScopes = append(q.newEnodeScopes, q.newEnodeHead)
	q.lazyMatchingScopes = append(q.lazyMatchingScopes, len(q.lazyMatchingTrail))
	return nil
}

func (q *SMTQuantifierManager) PopScopes(count uint32) error {
	if studyCacheKind == "scope" || studyCacheKind == "replay" {
		if q != nil && q.builder != nil {
			clear(q.builder.rootCache)
		}
	}

	if err := q.openOwner(); err != nil {
		return err
	}
	if q.pendingPop != nil && q.pendingPop.count != count {
		return ast.ErrASTPending
	}
	if count == 0 || count > uint32(len(q.newEnodeScopes)) {
		return ast.ErrASTDomain
	}
	level := len(q.newEnodeScopes) - int(count)
	if q.pendingPop == nil {
		q.pendingPop = &smtQuantifierPendingPop{count: count}
	}
	pop := q.pendingPop
	if pop.stage == 0 {
		q.mam.PopScope(count)
		q.lazyMAM.PopScope(count)
		pop.stage = 2
	}
	if pop.stage == 2 && !q.flushed {
		if err := q.modelFinder.PopScopes(count); err != nil {
			return err
		}
		pop.stage++
	}
	q.newEnodeHead = q.newEnodeScopes[level]
	q.newEnodeScopes = q.newEnodeScopes[:level]
	for len(q.lazyMatchingTrail) > q.lazyMatchingScopes[level] {
		last := len(q.lazyMatchingTrail) - 1
		q.lazyMatchingIndex = q.lazyMatchingTrail[last]
		q.lazyMatchingTrail = q.lazyMatchingTrail[:last]
	}
	q.lazyMatchingScopes = q.lazyMatchingScopes[:level]
	q.pendingPop = nil
	return nil
}

// promoteUnsatEntry is m_qi_promote_unsat && m_checker.is_unsat(...).
func (q *SMTQuantifierManager) promoteUnsatEntry(entry SMTQIQueueEntry) (bool, error) {
	if !q.promoteUnsat {
		return false, nil
	}
	if entry.Fingerprint == nil {
		return false, ast.ErrASTDomain
	}
	body, err := q.state.manager.GetQuantifierBody(entry.Fingerprint.data)
	if err != nil {
		return false, err
	}
	return q.checker.IsUnsatisfiable(body, entry.Fingerprint.args)
}

func (q *SMTQuantifierManager) instantiate(entries []SMTQIQueueEntry) (resultErr error) {
	for _, entry := range entries {
		var prepared SMTQIPreparedInstance
		if err := q.builder.prepare(entry, &prepared); err != nil {
			return fmt.Errorf("prepare quantified instance: %w", err)
		}
		instance, err := q.builder.MaterializeAndInternalize(&prepared, q.rewriter, q.registry.statistics[entry.Fingerprint.data], q.state.scopeLevel, q.state)
		err = errors.Join(err, prepared.Close())
		if err != nil {
			return fmt.Errorf("materialize quantified instance: %w", err)
		}
		if instance == nil {
			continue
		}
		if !instance.ReducedTrue() {
			lemma, lemmaErr := instance.Lemma()
			if lemmaErr == nil {
				lemmaErr = q.registry.schedule.RecordInstance(lemma)
			}
			if lemmaErr != nil {
				return errors.Join(lemmaErr, instance.Close())
			}
		}
		if err = instance.Close(); err != nil {
			return err
		}
	}
	return nil
}

func (q *SMTQuantifierManager) Propagate() error {
	if err := q.open(); err != nil {
		return err
	}
	// default_qm_plugin::propagate: m_mam->match(), then without
	// relevancy the new enodes are reported as relevant.
	if err := q.mam.Match(); err != nil {
		return err
	}
	q.notifyNewEnodes()
	// qi_queue::instantiate: entries are decided and instantiated one at a
	// time, so a promoted entry's check sees the earlier instances.
	return q.registry.schedule.instantiateNew(q.promoteUnsatEntry, func(entry SMTQIQueueEntry) error {
		return q.instantiate([]SMTQIQueueEntry{entry})
	}, q.state.resourceLimitsExceeded)
}

func (q *SMTQuantifierManager) active(quantifier ast.ASTHandle) bool {
	return q.state.isRelevant(quantifier) && q.state.context.assignments.get(quantifier) == lbool.True
}

func (q *SMTQuantifierManager) quickCheck() (bool, error) {
	if !q.quickUnsat && !q.quickNotSat {
		return true, nil
	}
	// IF_VERBOSE(10, "quick checking quantifiers (unsat)...") once
	// m_quantifiers is known to be nonempty (AUDIT.md FUZZ-F5).
	if diagnostic.VerboseProgress && !q.registry.Empty() {
		if err := progressVerbose(10, "quick checking quantifiers (unsat)...\n"); err != nil {
			return false, err
		}
	}
	// quick_check_quantifiers builds a fresh quick_checker mc per call, so
	// the collector's sets start empty each time.
	quick, err := NewSMTQuickChecker(q.state.context, q.rewriter, q.registry)
	if err != nil {
		return false, err
	}
	quick.state = q.state
	result := true
	for _, quantifier := range q.registry.quantifiers {
		if !q.active(quantifier) {
			continue
		}
		generated, err := quick.InstantiateUnsat(quantifier)
		if err != nil {
			return false, err
		}
		if generated {
			result = false
		}
	}
	if !result || !q.quickNotSat {
		if err := q.Propagate(); err != nil {
			return false, err
		}
		return result, nil
	}
	if diagnostic.VerboseProgress {
		if err := progressVerbose(10, "quick checking quantifiers (not sat)...\n"); err != nil {
			return false, err
		}
	}
	for _, quantifier := range q.registry.quantifiers {
		if !q.active(quantifier) {
			continue
		}
		generated, err := quick.InstantiateNotSat(quantifier)
		if err != nil {
			return false, err
		}
		if generated {
			result = false
		}
	}
	if err := q.Propagate(); err != nil {
		return false, err
	}
	return result, nil
}

func (q *SMTQuantifierManager) FinalCheck(full bool) (SMTFinalCheckStatus, error) {
	if err := q.open(); err != nil {
		return SMTFinalCheckGiveUp, err
	}
	if !full {
		if q.lazyInstantiation {
			if err := q.matchLazyPatterns(); err != nil {
				return SMTFinalCheckGiveUp, err
			}
		}
		return SMTFinalCheckDone, nil
	}
	if q.registry.Empty() {
		return SMTFinalCheckDone, nil
	}
	// IF_VERBOSE(100, if (!m_quantifiers.empty()) "(smt.final-check
	// \"quantifiers\")") (AUDIT.md FUZZ-F5).
	if err := progressVerbose(100, "(smt.final-check \"quantifiers\")\n"); err != nil {
		return SMTFinalCheckGiveUp, err
	}
	done, entries, err := q.registry.schedule.FinalCheck()
	if err != nil {
		return SMTFinalCheckGiveUp, err
	}
	if err = q.instantiate(entries); err != nil {
		return SMTFinalCheckGiveUp, err
	}
	if err = q.matchLazyPatterns(); err != nil {
		return SMTFinalCheckGiveUp, err
	}
	if !done || q.state.canPropagate() {
		return SMTFinalCheckContinue, nil
	}
	if !q.lazyQuick {
		done, err = q.quickCheck()
		if err != nil {
			return SMTFinalCheckGiveUp, err
		}
		if !done {
			return SMTFinalCheckContinue, nil
		}
	}
	return SMTFinalCheckDone, nil
}

// Source default_qm_plugin::final_check_quant rematches the separate lazy MAM
// a bounded number of times. Each increment is trailed; init_search resets the
// current counter without removing earlier scope trails.
func (q *SMTQuantifierManager) matchLazyPatterns() error {
	if !q.ematching || q.registry.Empty() || q.lazyMatchingIndex >= q.maxLazyMultipatternMatching {
		return nil
	}
	if err := q.lazyMAM.Rematch(false); err != nil {
		return err
	}
	q.lazyMatchingTrail = append(q.lazyMatchingTrail, q.lazyMatchingIndex)
	q.lazyMatchingIndex++
	return nil
}

func (q *SMTQuantifierManager) IsShared(node *SMTEnode) bool {
	return q != nil && !q.closed && q.pluginActive && (q.mam.IsShared(node) || q.lazyMAM.IsShared(node))
}

func (q *SMTQuantifierManager) NotifyRelevant(node *SMTEnode) {
	if node != nil && q != nil && !q.closed && q.ematching && !q.registry.Empty() {
		q.mam.RelevantEh(node, false)
		q.lazyMAM.RelevantEh(node, true)
	}
}

// Source quantifier_manager::check_model is called after ground final checking,
// separately from the round-robin full quantifier-instantiation slot.
type SMTQuantifierModelCheckResult uint8

const (
	SMTQuantifierModelSAT SMTQuantifierModelCheckResult = iota
	SMTQuantifierModelUnknown
	SMTQuantifierModelRestart
)

// CheckModel validates and retains a candidate only after the context's ground
// final-check cycle has completed. It reports UNKNOWN when MBQI is unavailable.
func (q *SMTQuantifierManager) CheckModel() (SMTQuantifierModelCheckResult, error) {
	if err := q.open(); err != nil {
		return SMTQuantifierModelUnknown, err
	}
	if q.registry.Empty() {
		return SMTQuantifierModelSAT, nil
	}
	// default_qm_plugin::check_model: IF_VERBOSE(10, "(smt.mbqi)") when
	// m_mbqi (AUDIT.md FUZZ-F5), after mk_proto_model built (and, at
	// level 11, printed) the candidate.
	if q.mbqi && q.modelChecker != nil && q.candidateModel != nil {
		generator, err := q.candidateModel()
		if err != nil {
			return SMTQuantifierModelUnknown, err
		}
		if err = progressVerbose(10, "(smt.mbqi)\n"); err != nil {
			return SMTQuantifierModelUnknown, errors.Join(err, generator.Close())
		}
		if err = q.modelChecker.SetCandidateTerms(generator.rootValues, generator.rootValuesInTableOrder()); err != nil {
			return SMTQuantifierModelUnknown, errors.Join(err, generator.Close())
		}
		active, activeErr := q.activeQuantifiers()
		if activeErr != nil {
			return SMTQuantifierModelUnknown, errors.Join(activeErr, generator.Close())
		}
		modelSatisfied, checkErr := q.modelChecker.Check(generator.model, active)
		if checkErr != nil {
			return SMTQuantifierModelUnknown, errors.Join(checkErr, generator.Close())
		}
		if !modelSatisfied {
			if err = q.retireCandidate(generator); err != nil {
				return SMTQuantifierModelUnknown, err
			}
			if q.modelChecker.HasNewInstances() {
				return SMTQuantifierModelRestart, nil
			}
			return SMTQuantifierModelUnknown, nil
		}
		if q.acceptedModel != nil {
			if err = q.acceptedModel.Close(); err != nil {
				return SMTQuantifierModelUnknown, errors.Join(err, generator.Close())
			}
		}
		q.acceptedModel = generator
		return SMTQuantifierModelSAT, nil
	}
	if q.mbqi {
		if err := progressVerbose(10, "(smt.mbqi)\n"); err != nil {
			return SMTQuantifierModelUnknown, err
		}
	}
	return SMTQuantifierModelUnknown, nil
}

// retireCandidate closes a rejected candidate's generator (its pins go to
// the kernel's model_generator m_asts) but keeps its proto model.
func (q *SMTQuantifierManager) retireCandidate(generator *SMTModelGenerator) error {
	proto := generator.model
	generator.model = nil
	err := generator.Close()
	if proto == nil {
		return err
	}
	if q.retiredProto != nil {
		err = errors.Join(err, q.retiredProto.Close())
	}
	q.retiredProto = proto
	return err
}

// releaseRetiredProto drops m_proto_model's rejected candidate.
func (q *SMTQuantifierManager) releaseRetiredProto() error {
	if q == nil || q.retiredProto == nil {
		return nil
	}
	proto := q.retiredProto
	q.retiredProto = nil
	return proto.Close()
}

func (q *SMTQuantifierManager) mbqiEnabled(quantifier ast.ASTHandle) (bool, error) {
	if q.mbqiID == "" {
		return true, nil
	}
	identifier, _, err := q.state.manager.GetQuantifierIDs(quantifier)
	if err != nil {
		return false, err
	}
	if identifier == (usymbol.Symbol{}) || identifier.IsNumerical() {
		return false, nil
	}
	text, present, err := q.state.manager.Symbols.BareString(identifier)
	return present && strings.HasPrefix(text, q.mbqiID), err
}

func (q *SMTQuantifierManager) activeQuantifiers() ([]ast.ASTHandle, error) {
	result := make([]ast.ASTHandle, 0, len(q.registry.quantifiers))
	for _, quantifier := range q.registry.quantifiers {
		enabled, err := q.mbqiEnabled(quantifier)
		if err != nil {
			return nil, err
		}
		if q.active(quantifier) && enabled {
			result = append(result, quantifier)
		}
	}
	return result, nil
}

// flush is ~quantifier_manager::imp as context::flush runs it (m_qmanager =
// nullptr), before the context's enodes go: m_plugin (default_qm_plugin:
// m_model_checker, then m_model_finder), then m_qi_queue (m_instances,
// then m_subst). The proto model is a context member, released by Close.
func (q *SMTQuantifierManager) flush() error {
	if q.flushed {
		return nil
	}
	var err error
	if q.modelChecker != nil {
		err = q.modelChecker.Close()
	}
	err = errors.Join(err, q.modelFinder.Close())
	if err == nil && q.registry != nil {
		err = q.registry.schedule.releaseInstancesForFlush()
	}
	err = errors.Join(err, q.substitute.Close())
	if err == nil {
		q.flushed = true
	}
	return err
}

func (q *SMTQuantifierManager) Close() error {
	if q != nil {
		q.builder.dumpStudyCost()
	}
	if q == nil || q.state == nil {
		return ast.ErrASTHandle
	}
	if q.closed {
		return nil
	}
	if err := q.releaseRetiredProto(); err != nil {
		return err
	}
	if q.acceptedModel != nil {
		if err := q.acceptedModel.Close(); err != nil {
			return err
		}
		q.acceptedModel = nil
	}
	err := q.flush()
	if err == nil {
		if q.state.quantifierManager == q {
			q.state.quantifierManager = nil
		}
		q.closed = true
		q.builder = nil
		q.mam = nil
		q.lazyMAM = nil
		q.modelFinder = nil
		q.modelChecker = nil
		q.candidateModel = nil
		q.checker = nil
		q.rewriter = nil
		q.registry = nil
		q.state = nil
		q.pendingPop = nil
	}
	return err
}
