from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;k=p/'ast/rewriter/arith_polynomial.go'
s=k.read_text();i=s.index('func (r *ArithRewriter) rewriteAdd(');j=s.index('func (r *ArithRewriter) rewriteSub(',i);a=s[i:j]
a=a.replace('counts := make([]int, 0, len(values))','original := make([]ast.ASTHandle, 0, len(values))\n duplicate := false')
a=a.replace('counts = append(counts, 0)','original = append(original, value)\n } else {\n duplicate = true\n original[pos] = ast.ASTHandle{}')
a=a.replace('counts[pos]++','')
a=a.replace('duplicate := false\n\tfor pos','for pos').replace('duplicate = duplicate || counts[pos] > 1','')
a=a.replace('h, e := r.coefficientProduct(&coefficients[pos], product, first)','''if !original[pos].IsNull() && !coefficients[pos].IsOne() {
            resultArgs = append(resultArgs, original[pos])
            continue
        }
        h, e := r.coefficientProduct(&coefficients[pos], product, first)''')
s=s[:i]+a+s[j:];d=w/'trial.go.txt';d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));o=w/'trial.json';o.write_text(json.dumps({'Replace':{str(k):str(d)}}));subprocess.run(['go','build','-buildvcs=false','-pgo=off','-overlay',o,'-o',w/'trial','./cmd/g3'],check=True)
