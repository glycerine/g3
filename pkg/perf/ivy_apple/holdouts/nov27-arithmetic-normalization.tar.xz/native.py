from pathlib import Path
import tarfile,re,shlex,subprocess,sys
p=Path.cwd();b=p.parent/'build';w=Path(__file__).resolve().parent/('native-values' if 'values' in sys.argv else 'native');w.mkdir(exist_ok=True)
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-ticket-instance-operators.tar.xz') as t:(w/'ops.hpp').write_bytes(t.extractfile('native/ops.hpp').read())
cfg=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l);mk=(b/'Makefile').read_text();objs=[]
for f,no in [(('ast/arith_decl_plugin.cpp',11) if 'values' in sys.argv else ('ast/rewriter/arith_rewriter.cpp',12)),('smt/qi_queue.cpp',39)]:
 s=(p.parent/'src'/f).read_text()
 if no==39:
    a='m_context.get_rewriter()(instance, s_instance, pr);';assert s.count(a)==1
    s='counter measured_ops;\n'+s.replace(a,'measured_ops.begin();'+a+'measured_ops.finish();')
 elif no==11:
    a='app * arith_decl_plugin::mk_numeral(rational const & val, bool is_int) {'
    assert s.count(a)==1
    s=s.replace(a,a+"""int k=5;if(measured_ops.fd>=0 && val.is_int64()) {auto v=val.get_int64(); k=v==-1?1:v<0?2:v<16?3:4;}window sample(k);""")
 else:
    for key,n in [('mk_add_core(num_args, args, result)',1),('mk_le_core(args[0], args[1], result)',2),('mk_ge_core(args[0], args[1], result)',2)]:
        a='st = '+key+';';assert s.count(a)==1
        s=s.replace(a,'{window sample('+str(n)+');'+a+' if(st==BR_FAILED)sample.k+=10;}')
 dest=w/Path(f).name;dest.write_text(s);o=dest.with_suffix('.o')
 inc=shlex.split(re.search('^includes_'+str(no)+' = (.*)$',mk,re.M)[1]);subprocess.run([cfg['CXX'],*shlex.split(cfg['CXXFLAGS']),*inc,'-include',w/'ops.hpp','-o',o,dest],cwd=b,check=True);objs.append(o)
link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',mk,re.M)[1];libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
subprocess.run([cfg['LINK'],'-o',w/'z3',*objs,*libs,*shlex.split(cfg['LINK_EXTRA_FLAGS'])],cwd=b,check=True)
