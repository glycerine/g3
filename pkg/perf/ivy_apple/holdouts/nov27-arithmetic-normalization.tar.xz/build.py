"""Build an instruction-counting overlay from pkg. Keep all generated files in scratch."""
from pathlib import Path
import json, tarfile, sys, re, subprocess
p=Path.cwd(); w=Path(__file__).resolve().parent;mode=sys.argv[1]
d=w/mode;d.mkdir(exist_ok=True);files={}
def save(name,src):
    dest=d/(Path(name).name+'.txt');dest.write_text(src);files[str(p/name)]=str(dest)
arc=p/'perf/ivy_apple/holdouts/nov27-ticket-instance-operators.tar.xz'
with tarfile.open(arc) as a:
    obs=a.extractfile('go/zz_opstudy.go.txt').read().decode().replace('[20]','[48]')
save('ast/rewriter/zz_opstudy.go',obs)
k='cmd/g3/main.go'
s=(p/k).read_text().replace('package main','package main\nimport "runtime"').replace('func main() {','func main() { runtime.LockOSThread(); defer runtime.UnlockOSThread()')
save(k,s)
k='smtcore/smt_qi_instance.go'
a='if err = rw.Rewrite(instance, simplified); err != nil {';s=(p/k).read_text();assert s.count(a)==1
save(k,s.replace(a,'rewriter.BeginObservedRow();err = rw.Rewrite(instance, simplified); rewriter.EndObservedRow(); if err != nil {'))
groups={
 'values':'makeNumeral',
 'top':'rewriteAdd rewriteComparison rewriteAlgebraicFold',
 'stage':'flattenArguments addAlreadyNormal coefficientProduct hoistEqualCoefficients hoistCommonMultiplication cancelMonomials rewriteBound reduceComparisonPowers eliminateToRealComparison reducePolynomialGCD rewriteNegativePolynomialComparison',
 'leaf':'numeral isNumeral operation makeNumeral app monomialLess',
}
names=groups[mode].split(); seen=[]
for f in sorted((p/'ast/rewriter').glob('arith*.go')):
    s=f.read_text();orig=s
    for i,n in enumerate(names,1):
        rx=r'(func \(r \*ArithRewriter\) '+n+r'\([^\n]+? \{)'
        if re.search(rx,s):
            ins=f'\n defer opEnd({i},opBegin())\n'
            if mode=='values':
                ins="""\nif rowActive { k:=5;if v,ok:=value.SmallInt32();ok { switch {case v == -1:k=1;case v<0:k=2;case v<16:k=3;default:k=4} };defer opEnd(k,opBegin()) }\n"""
            if mode=='top':
                a=re.search(rx,s)[1]
                if '_ RewriteStatus' in a:
                    s=s.replace(a,a.replace('_ RewriteStatus','status RewriteStatus'));a=a.replace('_ RewriteStatus','status RewriteStatus')
                assert 'status RewriteStatus' in a
                ins=f'\n start:=opBegin();defer func(){{k:={i};if status==RewriteFailed{{k+=10}};opEnd(k,start)}}()\n'
            s=re.sub(rx,lambda m:m[1]+ins,s);seen.append(n)
    if s!=orig:save(f.relative_to(p),s)
assert sorted(seen)==sorted(names),seen
(d/'names').write_text(' '.join(names))
o=d/'overlay.json';o.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',d/'g3','./cmd/g3'],check=True)
