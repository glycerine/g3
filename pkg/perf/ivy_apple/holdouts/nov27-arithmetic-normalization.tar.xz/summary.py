import collections,csv,statistics
from pathlib import Path
for d in sorted(Path(__file__).resolve().parent.glob('*/rows.csv')):
    names=(['minus-one','other-negative','zero-to-fifteen','sixteen-plus','other'] if d.parent.name in ('values','native-values','reuse-values') else ['rewriteAdd','rewriteComparison'] if d.parent.name=='native' else (d.parent/'names').read_text().split()); costs=collections.defaultdict(collections.Counter);calls=collections.Counter()
    for r in csv.DictReader(d.open()):
        n,k,v,b,c=(int(r[x]) for x in ['round','category','raw','calibration16','calls'])
        costs[k][n]+=v-c*b/16
        if n==0:calls[k]+=c
    for k in sorted(costs,key=lambda k:-statistics.median(costs[k].values())):
        fail=d.parent.name in ('top','native') and k>10
        print(d.parent.name,names[k-1-10*fail], 'unchanged' if fail else '',calls[k],round(statistics.median(costs[k].values())/1e6,3))
