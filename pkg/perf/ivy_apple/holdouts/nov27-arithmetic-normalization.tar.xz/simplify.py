from pathlib import Path
import gzip,tarfile,subprocess,sys
with tarfile.open('perf/ivy_apple/holdouts/nov24-arithmetic-comparison-stages.tar.xz') as t:
 s=gzip.decompress(t.extractfile('simplifications/formulas.smt2.gz').read())
 outputs=[subprocess.run([f,'-in','-smt2'],input=s,capture_output=True,check=True) for f in sys.argv[1:]]
 assert all((x.stdout,x.stderr)==(outputs[0].stdout,outputs[0].stderr) for x in outputs)
 print(len(s.splitlines()),len(outputs[0].stdout.splitlines()),len(outputs[0].stderr))
