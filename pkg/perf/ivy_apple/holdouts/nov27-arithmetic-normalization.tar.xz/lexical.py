from pathlib import Path
import subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;k=p/'ast/ast_arith_numeral.go';s=k.read_text()
i=s.index('epoch := m.formatLexical.epoch * 2');j=s.index('nameIndex :=',i);s=s[:i]+s[j:]
a='m.pluginDecl(p.names[nameIndex], p.family, 0, ps[:], nil, p.fields[sortIndex], ASTFuncFlags{}, false)'
assert s.count(a)==1;s=s.replace(a,'m.mkFuncDecl(p.names[nameIndex], nil, m.external(p.fields[sortIndex]), ASTFuncDeclInfo{m.origin, math.MaxUint32 - 1, m.formatLexical.epoch})')
d=w/'lexical.go.txt';d.write_text(s);o=w/'lexical.json';o.write_text(json.dumps({'Replace':{str(k):str(d)}}));subprocess.run(['go','build','-buildvcs=false','-pgo=off','-overlay',o,'-o',w/'lexical','./cmd/g3'],check=True)
