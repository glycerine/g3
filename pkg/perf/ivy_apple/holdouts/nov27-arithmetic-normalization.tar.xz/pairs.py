import csv,statistics,sys
for path in sys.argv[1:]:
 rows=list(csv.DictReader(open(path)));key='case' if 'case' in rows[0] else 'query'
 d={(r[key],r['engine'],int(r['round'])):r for r in rows}
 for q in sorted({k[0] for k in d}):
  ii=sorted(i for n,e,i in d if n==q and e=='trial')
  print(q,len(ii),*[round(statistics.median(100*(float(d[q,'trial',i][c])/float(d[q,'base',i][c])-1) for i in ii),3) for c in ['instructions','cycles','milliseconds']])
