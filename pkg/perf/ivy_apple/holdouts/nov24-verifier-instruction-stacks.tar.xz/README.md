# Whole-verifier instruction sampling

The seven pairs use GoIvy 832e392ef, the g3 borrowed-declaration release (1911b04a8) and linked Z3 from the in-tree fork. Both checkers used the same frontend, xtrace_off, GOGC 100, GOMAXPROCS 1 and an adjacent abc executable. Each comparison alternated both engines on one CPU for nine rounds. The period was 3,000,017 retired user instructions. All 126 perf streams were checked for throttle and loss records. Expected stdout, stderr and exit status were compared for every process. The verification failure in test_liveness2 is expected from both engines.

Unpack this archive and run the following command with paths to your built GoIvy checkers and example checkout.

    python3 replay.py --g3 /path/to/g3/goivy_check --native /path/to/native/goivy_check --examples /path/to/ivy-lang-examples --cpu 4 --rounds 2 --case ticket_protocol --output /tmp/ticket-profiles

To recompute all totals from the decoded observations:

    python3 summarize.py profiles > totals.csv

The leaf tables count each sample once. Inclusive counts count unique names on each stack. The saved stack CSVs stop at 32 names. C++ frame-pointer unwinding often stops inside the native library, so native inclusive counts cover only the frames that perf could unwind. Category labels use explicit symbol prefixes in summarize.py. The category for garbage collection covers named collector, object lookup and write-barrier routines in the Go runtime. It is an approximate leaf classification. Non-solver work is included in the process measurements. Individual sample counts are estimates and may fluctuate with sampling phase. The portable replay substitutes the examples checkout path in archived diagnostics before comparing their bytes.
