"""Summarize decoded profiles. Pass the directory containing per-case profiles."""
import csv
from collections import Counter
import gzip
from pathlib import Path
import sys

def group(name):
    if name.startswith("runtime."):
        routine = name[8:]
        if routine.startswith(("gc", "scan", "tryDeferToSpanScan", "greyobject",
                               "findObject", "markroot", "wbBufFlush", "bulkBarrier",
                               "shade", "deductAssist", "sweep", "typePointers")):
            return "Go garbage collector"
        return "Other Go runtime"
    if name.startswith("internal/runtime/maps."):
        return "Go maps"
    if name.startswith("ast/rewriter."):
        return "g3 rewriter"
    if name.startswith("ast."):
        return "g3 AST manager"
    if name.startswith("smtcore."):
        return "g3 SMT core"
    if "github.com/glycerine/ivy/" in name:
        return "GoIvy"
    if name.startswith(("smt::", "ast_manager::", "rewriter_tpl<", "th_rewriter", "insdict<",
                        "expr_substitution::", "symbol::", "sregion", "region::", "obj_hashtable<")):
        return "Z3 identified families"
    if "unknown" in name.lower():
        return "Unresolved leaf"
    return "Other identified leaves"

def main(directory):
    writer = csv.writer(sys.stdout)
    writer.writerow(["case", "engine", "metric", "name", "samples"])
    for case in sorted(directory.iterdir()):
        if not (case / "1-g3").is_dir():
            continue
        for engine in ("g3", "native"):
            for metric in ("leaf", "inclusive"):
                names, groups = Counter(), Counter()
                for path in sorted(case.glob(f"*-{engine}/{metric}.csv.gz")):
                    with gzip.open(path, "rt") as stream:
                        for row in csv.DictReader(stream):
                            names[row["name"]] += int(row["samples"])
                for name, count in names.most_common():
                    writer.writerow([case.name, engine, metric, name, count])
                    if metric == "leaf":
                        groups[group(name)] += count
                for name, count in groups.most_common():
                    writer.writerow([case.name, engine, "exclusive group", name, count])
if __name__ == "__main__":
    main(Path(sys.argv[1]))
