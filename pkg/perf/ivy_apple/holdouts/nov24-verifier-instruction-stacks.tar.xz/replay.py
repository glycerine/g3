"""Repeat paired Linux instruction sampling for the archived verifier cases."""
import argparse
import csv
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
from collections import Counter

base = Path(__file__).resolve().parent
header = re.compile(r"^\s*\d+\s+\d+\.\d+:\s+instructions:u:\s*$")
frame = re.compile(r"^\s*[0-9a-fA-F]+\s+(.+)\s+\(.+\)\s*$")

def save_counts(path, counts):
    with gzip.open(path, "wt") as stream:
        writer = csv.writer(stream)
        writer.writerow(["samples", "name"])
        writer.writerows((count, name) for name, count in counts.most_common())

def decode(perf, directory):
    data = directory / "perf.data"
    leaf, inclusive, stacks = Counter(), Counter(), Counter()
    frames = []
    def record():
        if frames:
            leaf[frames[0]] += 1
            inclusive.update(set(frames))
            stacks[" <- ".join(frames[:32])] += 1
    with subprocess.Popen([perf, "script", "--ns", "--no-inline", "-F",
                           "tid,time,event,ip,sym,dso", "-i", data],
                          stdout=subprocess.PIPE, text=True) as proc:
        for line in proc.stdout:
            if header.match(line):
                record()
                frames.clear()
            elif match := frame.match(line):
                symbol = re.sub(r"\+0x[\da-f]+$", "", match[1])
                frames.append(symbol.removeprefix("github.com/glycerine/g3/pkg/"))
        record()
        if proc.wait() or not leaf:
            raise RuntimeError("no complete instruction profile")
    with subprocess.Popen([perf, "script", "-D", "-i", data], stdout=subprocess.PIPE,
                          text=True, errors="replace") as proc:
        lost = Counter()
        for line in proc.stdout:
            for token in ("PERF_RECORD_THROTTLE", "PERF_RECORD_LOST"):
                if token in line:
                    lost[token] += 1
        if proc.wait():
            raise RuntimeError("could not check for lost records")
    (directory / "throttle-counts.json").write_text(json.dumps(lost) + "\n")
    if lost:
        raise RuntimeError(f"incomplete profile in {directory}: {lost}")
    for name, counts in (("leaf", leaf), ("inclusive", inclusive), ("stacks", stacks)):
        save_counts(directory / (name + ".csv.gz"), counts)
    data.unlink()

def main():
    parser = argparse.ArgumentParser(__doc__)
    for name in ("g3", "native", "examples", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cpu", type=int, required=True)
    parser.add_argument("--case", action="append")
    parser.add_argument("--rounds", type=int, default=9)
    parser.add_argument("--perf", default="perf")
    args = parser.parse_args()
    cases = json.loads((base / "cases.json").read_text())
    if args.rounds < 1 or set(args.case or []) - set(cases):
        parser.error("supply a known case and at least one round")
    for name in args.case or sorted(cases):
        spec, isolate, status = cases[name]
        references = base / "reference" / name
        for i in range(args.rounds):
            engines = ["g3", "native"] if i % 2 == 0 else ["native", "g3"]
            for engine in engines:
                wd = args.output.resolve() / name / f"{i+1}-{engine}"
                wd.mkdir(parents=True)
                cmd = ["taskset", "-c", str(args.cpu), args.perf, "record", "-q", "--no-buildid",
                       "-e", "instructions:u", "-c", "3000017", "--call-graph", "fp",
                       "-o", str(wd / "perf.data"), "--", str(getattr(args, engine).resolve())]
                if isolate:
                    cmd.append("isolate=" + isolate)
                cmd.append(str(args.examples.absolute() / spec))
                result = subprocess.run(cmd, cwd=wd, capture_output=True,
                                        env=dict(os.environ, GOGC="100", GOMAXPROCS="1"))
                if result.returncode != status:
                    raise RuntimeError(f"{name} {engine} exited {result.returncode}, expected {status}")
                for key in ("stdout", "stderr"):
                    actual = getattr(result, key)
                    (wd / key).write_bytes(actual)
                    expected = (references / key).read_bytes().replace(
                        b"/home/jaten/ivy/ivy-lang-examples/",
                        os.fsencode(args.examples.absolute()) + b"/")
                    if actual != expected:
                        raise RuntimeError(f"{name} {engine} changed {key}")
                decode(args.perf, wd)

if __name__ == "__main__":
    main()
