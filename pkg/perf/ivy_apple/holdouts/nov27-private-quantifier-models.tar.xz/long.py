from pathlib import Path
s=Path('/tmp/g3-plan-budget/long.py').read_text().replace('g3-nov27-private-budget','g3-nov27-private-models').replace("'256','512'","'singleton','mbqi'").replace('/tmp/g3-live-frame-cost/recheck/baseline','/tmp/g3-plan-budget/production/release')
exec(s)
