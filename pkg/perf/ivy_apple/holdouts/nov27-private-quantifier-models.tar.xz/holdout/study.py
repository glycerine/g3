from pathlib import Path
import json,csv,subprocess,sys,os
w=Path(__file__).resolve().parent;mode=sys.argv[1];p=Path.cwd();d=w/mode;d.mkdir(exist_ok=True)
ov={};k=p/'api/api_goal_instances_check.go';s=k.read_text();defs=json.loads((w.parent/'usersort/trial.json').read_text())['Replace'];k2=str(p/'api/private_singleton_trial.go');ov[k2]=defs[k2]
key='reuse := p.plans.reusable(parent)';assert s.count(key)==1
s=s.replace('import (','import ("fmt";"os";',1).replace(key,key+'''
 if sp,ok:=plan.(*shortPremisePlan);ok && reuse {
 yes:=trialModel(parent,sp.selected);defer func(){fmt.Fprintf(os.Stderr,"CERT use %v %v %d\\n",yes,proved,len(sp.selected))}()
 '''+('if yes{return false,nil}' if mode=='filter' else '')+'''
 }''')
f=d/'plan.go.txt';f.write_text(s);ov[str(k)]=str(f);k=p/'api/api_order_abstraction.go';s=k.read_text().replace('import (','import ("fmt";"os";',1).replace('defer func() { p.previousGoalProved = proved && err == nil }()','defer func() { p.previousGoalProved = proved && err == nil;fmt.Fprintln(os.Stderr,"CERT early",proved) }()');f=d/'batch.go.txt';f.write_text(s);ov[str(k)]=str(f)
o=d/'trial.json';o.write_text(json.dumps({'Replace':ov}));exe=Path('/wd_black1tb/home/jaten/tmp/g3-nov27-private-models')/('explain-'+mode)
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
for spec in ['examples/ivy/toy_consensus.ivy','test/skolem1.ivy','test/toma8.ivy','examples/liveness/ticket.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy']:
 r=subprocess.run([exe,ex/spec],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True);keep=[];data=[]
 for line in r.stderr.splitlines(keepends=True):(data if line.startswith(b'CERT ') else keep).append(line)
 ref=rank/'compat'/str(cases.index(spec)+1)/'1/native';assert (r.returncode,r.stdout,b''.join(keep))==(codes[spec],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
 (d/(Path(spec).stem+'.txt')).write_bytes(b''.join(data))
