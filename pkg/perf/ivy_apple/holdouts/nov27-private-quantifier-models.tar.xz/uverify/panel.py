from pathlib import Path
s=Path('/tmp/g3-plan-budget/broad.py').read_text().replace("w=Path(__file__).resolve().parent;d=w/'panel'","w=Path(__file__).resolve().parent.parent;d=w/'uverify/panel'").replace('/tmp/g3-live-frame-cost/recheck/baseline','/tmp/g3-plan-budget/production/release').replace("['256','512']","['usersort']")
exec(s)
