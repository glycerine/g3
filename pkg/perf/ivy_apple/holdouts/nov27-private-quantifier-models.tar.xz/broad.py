from pathlib import Path
s=Path('/tmp/g3-plan-budget/broad.py').read_text().replace('/tmp/g3-live-frame-cost/recheck/baseline','/tmp/g3-plan-budget/production/release').replace("['256','512']","['singleton','quantified']")
exec(s)
