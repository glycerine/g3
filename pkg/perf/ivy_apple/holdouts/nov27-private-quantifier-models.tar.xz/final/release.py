from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-or-install/final/release.py').read_text().replace("'/tmp/g3-card-install/volume-release'","'/tmp/g3-plan-budget/production/release'")
s=s[:s.index('run(12,')]+"""run(12,'whole',['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy','doc/examples/cav2024/examp1.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','test/skolem1.ivy','examples/liveness/ticket.ivy','examples/ivy/toy_consensus.ivy'],9,['base','release','native'])"""
exec(s)
