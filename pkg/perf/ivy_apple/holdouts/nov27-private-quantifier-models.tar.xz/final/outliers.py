from pathlib import Path
import subprocess,sys,csv,time,os,concurrent.futures
w=Path(__file__).resolve().parent;p=Path.cwd();h=Path('/tmp/g3-frame-child');ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();flags=['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')]
modes={'base':Path('/tmp/g3-plan-budget/production/release'),'release':w/'release','native':Path('/tmp/g3-flash-marginal/abc-control/native')}
def run(cpu,stem,names,rounds,engines):
 with (w/(stem+'.csv')).open('w') as f:
  out=csv.writer(f);out.writerow(['case','round','mode','status','instructions','ms'])
  for name in names:
   ref=rank/'compat'/str(cases.index(name)+1)/'1/native';expect=codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()
   for i in range(rounds):
    for m in engines[i%len(engines):]+engines[:i%len(engines)]:
     stat=w/(stem+'.stat');t=time.monotonic()
     try:r=subprocess.run(['taskset','-c',str(cpu),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',modes[m],ex/name],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=h,capture_output=True,timeout=120)
     except subprocess.TimeoutExpired:out.writerow([name,i,m,'timeout','',120000]);f.flush();continue
     ok=(r.returncode,r.stdout,r.stderr)==expect;ms=1000*(time.monotonic()-t)
     if not ok:(w/(stem+'-'+str(cases.index(name))+'-'+m+'.stdout')).write_bytes(r.stdout);(w/(stem+'-'+str(cases.index(name))+'-'+m+'.stderr')).write_bytes(r.stderr)
     ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
     out.writerow([name,i,m,'match' if ok else 'different',ins,round(ms,3)]);f.flush()
run(12,'outliers',['examples/ivy/toy_consensus.ivy','doc/examples/cav2024/examp5.ivy','test/skolem1.ivy'],15,['base','release'])
