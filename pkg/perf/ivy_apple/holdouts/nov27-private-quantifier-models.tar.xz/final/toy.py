from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'outliers.py').read_text().split("run(12,'outliers'")[0].replace("Path('/tmp/g3-plan-budget/production/release')","w/'toggle'").replace("w/'release'","w/'toggle'").replace("dict(os.environ,GOMAXPROCS","dict(os.environ,MODEL_FILTER=('on' if m=='release' and stem=='toy' else 'off'),GOMAXPROCS")
exec(s)
for stem in ['toy','aa']:run(12,stem,['examples/ivy/toy_consensus.ivy'],101 if stem=='toy' else 51,['base','release'])
