from pathlib import Path
s=Path('/tmp/g3-plan-budget/long.py').read_text()
a=s.index('for mode in');b=s.index('ex=Path',a)
s=s[:a]+"""subprocess.run([*flags,'-o',bin/'final','./cmd/goivy_check'],cwd=front,check=True)
"""+s[b:]
s=s.replace("modes=['base','256','512']", "modes=['base','final']").replace("for m in modes[i:]+modes[:i]:","for m in modes[i%2:]+modes[:i%2]:").replace("exe=bin/m if apple", "exe=(Path('/wd_black1tb/home/jaten/tmp/g3-nov27-usersort-model/base') if m=='base' else bin/m) if apple").replace('g3-nov27-private-budget','g3-nov27-final-model').replace('/tmp/g3-live-frame-cost/recheck/baseline','/tmp/g3-plan-budget/production/release').replace("w/m/'release'","w/'release'")
exec(s)
