from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-plan-budget/broad.py').read_text().replace("['256','512']", "['unused']").replace("modes={'base':"+ "Path('/tmp/g3-live-frame-cost/recheck/baseline'),**{i:w/i/'release' for i in ['unused']}}","modes={'final':w/'release'}")
exec(s)
