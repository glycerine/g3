from pathlib import Path
import os,subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'api/api_goal_instances_check.go';s=f.read_text().replace('import (','import ("os";',1).replace('type privateProofPlan interface','var studyModelEnabled = os.Getenv("MODEL_FILTER") == "on"\n\ntype privateProofPlan interface').replace('ok && reuse && has','ok && reuse && studyModelEnabled && has')
d=w/'toggle.go.txt';d.write_text(s);o=w/'toggle.json';o.write_text(json.dumps({'Replace':{str(f):str(d)}}))
s=(w/'outliers.py').read_text()
driver=Path('/tmp/g3-or-install/final/release.py').read_text()
a=driver.index('subprocess.run([*flags');b=driver.index('modes=',a)
build=driver[a:b].replace("[*flags,","[*flags,'-overlay',o,").replace("w/'release'","w/'toggle'")
s=s[:s.index('modes=')]+build+"modes={'base':w/'toggle','release':w/'toggle'}\n"+s[s.index('def run'):]
s=s.replace("dict(os.environ,GOMAXPROCS","dict(os.environ,MODEL_FILTER=('on' if m=='release' else 'off'),GOMAXPROCS").replace("'outliers'","'toggle'").replace("'doc/examples/cav2024/examp5.ivy'","'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'").replace('],15,','],11,')
exec(s)
