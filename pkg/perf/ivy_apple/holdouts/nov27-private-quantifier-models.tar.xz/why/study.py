from pathlib import Path
import json,sys,os,subprocess,csv
w=Path(__file__).resolve().parent;p=Path.cwd()
s=(w.parent/'qcover/coverage.py').read_text()
a=s.index("o=w/'cover.json'")
s=s[:a]+'''q=Path(ov[k]).read_text().replace('import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast";"fmt";"os")')
q=q.replace('if len(roots)==0', 'if studyActive {fmt.Fprintf(os.Stderr,"DIAG %d roots %d\\\\n",studyCheck,len(roots))}; if len(roots)==0')
q=q.replace('possible &= v.eval(roots[i],0).yes','t:=v.eval(roots[i],0);possible &= t.yes;if studyActive {fmt.Fprintf(os.Stderr,"DIAG %d root %d pos %x yes %x no %x preds %d visits %d\\\\n",studyCheck,i,possible,t.yes,t.no,len(v.predicates),v.visits)}')
dd=w/'diag.go.txt';dd.write_text(q);ov[k]=str(dd)
'''+s[a:]
s=s.replace("exec(s)", """s=s.replace('else:keep.append(line)','elif line.startswith(b"DIAG "):cert.append(line.decode())\\n  else:keep.append(line)');exec(s)""")
exec(s)
