from pathlib import Path
import csv,json,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd();ov={}
def edit(key,replace):
 f=p/key;d=w/(f.name+'.txt');d.write_text(replace(f.read_text()));ov[str(f)]=str(d)
edit('api/api_order_abstraction.go',lambda s:s.replace('p := b.state\n\tdefer func() { p.previousGoalProved','studyAttempt++;studyActive=true;defer func(){studyActive=false}();p := b.state\n\tdefer func() { p.previousGoalProved')+'\nvar studyAttempt int\nvar studyActive bool\nvar studyCheck int\n')
key='answer, err := aux.child.Check()'
def plan(s):
 assert s.count(key)==1
 return s.replace('import (','import ("os";"fmt";"path/filepath";',1).replace(key,'''if studyActive {
 studyCheck++;text,e:=aux.child.String();if e!=nil{panic(e)};path:=filepath.Join(os.Getenv("PLAN_DUMP"),fmt.Sprintf("%04d.smt2",studyCheck));if e=os.WriteFile(path,[]byte(text+"\\n(check-sat)\\n"),0600);e!=nil{panic(e)}
 };'''+key+''';if studyActive{fmt.Fprintf(os.Stderr,"PLAN %d %d %d %d\\n",studyCheck,studyAttempt,maxSteps,answer)}''')
edit('api/api_goal_instances_check.go',plan)
o=w/'overlay.json';o.write_text(json.dumps({'Replace':ov}));front=p/'build/.boolean-enode-cost/frontend/goivy'
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',o,'-o',w/'g3','./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
rows=list(csv.DictReader(Path('/tmp/g3-plan-budget/plans.csv').open()))
for spec in dict.fromkeys(r['input'] for r in rows):
 d=w/Path(spec).stem;d.mkdir(exist_ok=True);r=subprocess.run([w/'g3',ex/spec],cwd=w,env=dict(os.environ,PLAN_DUMP=str(d),GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
 keep=[];actual=[]
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'PLAN '):actual.append(tuple(map(int,line.split()[1:])))
  else:keep.append(line)
 ref=rank/'compat'/str(cases.index(spec)+1)/'1/native'
 assert (r.returncode,r.stdout,b''.join(keep))==(codes[spec],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(spec,r.returncode,b''.join(keep)[-500:])
 expected=[(i,int(q['attempt']),int(q['allowance']),int(q['answer'])) for i,q in enumerate([q for q in rows if q['input']==spec and q['round']=='0'],1)]
 assert actual==expected,(spec,actual,expected)
