from pathlib import Path
import csv,subprocess,concurrent.futures,collections
w=Path(__file__).resolve().parent
def run(r):
 f=w/r['input']/('%04d.smt2'%int(r['check']))
 vals=[]
 for m in ['0','1']:
  z=subprocess.run([w/'native',f,m],capture_output=True,check=True,timeout=10);v=z.stdout.decode().strip();assert v in ('sat','unsat','unknown');vals.append(v)
 return {**r,'ematch':vals[0],'mbqi':vals[1]}
with concurrent.futures.ThreadPoolExecutor(6) as pool:
 rows=list(pool.map(run,csv.DictReader((w/'answers.csv').open())))
with (w/'modes.csv').open('w') as f:
 o=csv.DictWriter(f,rows[0]);o.writeheader();o.writerows(rows)
print(collections.Counter((r['private'],r['ematch'],r['mbqi']) for r in rows))
