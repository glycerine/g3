(declare-sort ticket_protocol.ticket)
(declare-sort ticket_protocol.thread)
(declare-fun __ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.zero () ticket_protocol.ticket)
(declare-fun ticket_protocol.le
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun __ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun |__fml:t| () ticket_protocol.thread)
(declare-fun ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun @T () ticket_protocol.thread)
(assert (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
  (or (not (ticket_protocol.pc1 |T:ticket_protocol.thread|))
      (not (__ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
(assert (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
         (|T2:ticket_protocol.thread| ticket_protocol.thread))
  (not (and (not (ticket_protocol.pc1 |T1:ticket_protocol.thread|))
            (not (ticket_protocol.pc1 |T2:ticket_protocol.thread|))
            (ticket_protocol.m |T1:ticket_protocol.thread| ticket_protocol.zero)
            (ticket_protocol.m |T2:ticket_protocol.thread| ticket_protocol.zero)
            (not (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))))
(assert (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
         (|T:ticket_protocol.thread| ticket_protocol.thread))
  (let ((a!1 (not (and (ticket_protocol.pc1 |T:ticket_protocol.thread|)
                       (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|)
                       (not (= |M:ticket_protocol.ticket| ticket_protocol.zero))))))
    (or a!1
        (not (ticket_protocol.le
               ticket_protocol.service
               |M:ticket_protocol.ticket|))))))
(assert (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
  (let ((a!1 (not (and (not (ticket_protocol.le
                              ticket_protocol.next_ticket
                              |K:ticket_protocol.ticket|))
                       (ticket_protocol.le
                         ticket_protocol.service
                         |K:ticket_protocol.ticket|))))
        (a!2 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
               (and (ticket_protocol.m
                      |T:ticket_protocol.thread|
                      |K:ticket_protocol.ticket|)
                    (not (ticket_protocol.pc1 |T:ticket_protocol.thread|))))))
    (or a!1 a!2))))
(assert (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
  (= (ticket_protocol.pc3 |V0:ticket_protocol.thread|)
     (or (= |V0:ticket_protocol.thread| |__fml:t|)
         (__ticket_protocol.pc3 |V0:ticket_protocol.thread|)))))
(assert (ticket_protocol.pc1 @T))
(assert (ticket_protocol.pc3 @T))

(check-sat)
