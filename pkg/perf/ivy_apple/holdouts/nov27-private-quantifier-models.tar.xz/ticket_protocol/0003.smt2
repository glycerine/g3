(declare-sort ticket_protocol.ticket)
(declare-fun ticket_protocol.le
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.zero () ticket_protocol.ticket)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
  (ticket_protocol.le |X:ticket_protocol.ticket| |X:ticket_protocol.ticket|)))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Y:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Z:ticket_protocol.ticket| ticket_protocol.ticket))
  (or (not (and (ticket_protocol.le
                  |X:ticket_protocol.ticket|
                  |Y:ticket_protocol.ticket|)
                (ticket_protocol.le
                  |Y:ticket_protocol.ticket|
                  |Z:ticket_protocol.ticket|)))
      (ticket_protocol.le |X:ticket_protocol.ticket| |Z:ticket_protocol.ticket|))))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
  (or (not (and (ticket_protocol.le
                  |X:ticket_protocol.ticket|
                  |Y:ticket_protocol.ticket|)
                (ticket_protocol.le
                  |Y:ticket_protocol.ticket|
                  |X:ticket_protocol.ticket|)))
      (= |X:ticket_protocol.ticket| |Y:ticket_protocol.ticket|))))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
         (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
  (or (ticket_protocol.le |X:ticket_protocol.ticket| |Y:ticket_protocol.ticket|)
      (ticket_protocol.le |Y:ticket_protocol.ticket| |X:ticket_protocol.ticket|))))
(assert (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
  (ticket_protocol.le ticket_protocol.zero |X:ticket_protocol.ticket|)))
(assert (not (ticket_protocol.le ticket_protocol.service ticket_protocol.next_ticket)))

(check-sat)
