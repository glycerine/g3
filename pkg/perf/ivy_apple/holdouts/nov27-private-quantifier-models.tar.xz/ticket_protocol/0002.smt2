(declare-sort ticket_protocol.ticket)
(declare-fun ticket_protocol.zero () ticket_protocol.ticket)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun ticket_protocol.le
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(assert (= ticket_protocol.service ticket_protocol.zero))
(assert (= ticket_protocol.next_ticket ticket_protocol.zero))
(assert (not (ticket_protocol.le ticket_protocol.service ticket_protocol.next_ticket)))

(check-sat)
