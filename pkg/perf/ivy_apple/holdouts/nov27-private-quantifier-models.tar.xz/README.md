# Private premise study

The four directories named for Ivy inputs hold all 123 selected formulas in private-check order. Run each file in a fresh process. The native harness uses GoIvy's linked archive. From the g3 pkg directory with the archive extracted in SCRATCH, build it with

    cc -I../src/api -c "$SCRATCH/native.c" -o "$SCRATCH/native.o"
    c++ -fopenmp "$SCRATCH/native.o" build/.boolean-enode-cost/frontend/goivy/z3vendor/native_lib/libz3.a -lpthread -ldl -o "$SCRATCH/native"
    python3 "$SCRATCH/replay.py"
    python3 "$SCRATCH/modes.py"
    python3 "$SCRATCH/flash.py"

replay.py emits bounds/ and answers.csv. modes.py joins those with explicit macro-finder and MBQI settings. flash_core/instance5.smt2 is the single-instance Flash positive control. To verify it directly run native with the file path and 0 for E-matching, 1 for MBQI.

costs.csv is the earlier three-rotation private-call counter capture. Each capture has an independent ordinal sequence per verifier. The shadow observers preserved the original private solver invocation and joined model decisions by ordinal. final/shadow contains the released recognizer's decisions. singleton, quantified and usersort refer to exploratory implementations. production is the pre-guard candidate. final is the committed version. final/bench.log and final/basebench.log contain the microbenchmark samples. To run on a fresh checkout:

    go test ./api -run '^$' -bench '^BenchmarkPrivateSatisfiablePremisePlan$' -benchmem -count=5

For the baseline, use Go's -overlay to replace api/api_goal_instances_check.go with final/baseline.go.txt, keeping the same benchmark. The driver scripts and CSV files retain the study machine paths and CPU assignments. deps contains the shared release, panel and long drivers used through those paths. The larger GoIvy and Ivy checkouts, native reference transcripts and PGO profile are external inputs described in PERF_STUDY.md and previous holdout archives. final/panel checked return code and both output streams against the 228 archived native references. final/long.py uses the Apple-specific frontend on the two Apple isolates. final/isolated contains the follow-up Apple run after builds finished. The release samples use normal GC. Cost captures use the settings in capture.py. Avoid comparing elapsed times across CPUs or process sets.
