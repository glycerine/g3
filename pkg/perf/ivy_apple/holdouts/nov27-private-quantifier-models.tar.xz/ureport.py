from pathlib import Path
from statistics import median
import collections,csv
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'modes.csv').open()));costs=list(csv.DictReader((w/'costs.csv').open()));costmap={}
for q in {r['input'] for r in costs}:
 runs=[[int(r['instructions']) for r in costs if r['input']==q and r['round']==str(i)] for i in range(3)]
 for i,v in enumerate(zip(*runs),1):costmap[Path(q).stem,i]=median(v)
for k in sorted({r['input'] for r in rows}):
 cert=[z.split()[2]=='true' for z in (w/'ucover/shadow'/k/'cert.txt').read_text().splitlines()]
 d=[r for r in rows if r['input']==k];assert len(d)==len(cert)
 v=[x for x in d if x['private']=='0'];yes=[r for r in d if cert[int(r['check'])-1]]
 assert all(r['unrestricted']=='sat' for r in yes)
 print(k,len(v),*[sum(r[a]=='sat' for r in v) for a in ['unrestricted','one','two']],collections.Counter(r['private'] for r in yes),round(sum(costmap[k,int(r['check'])] for r in yes if r['private']=='0')/1e6,2))
for f in [*w.glob('*/whole.csv'),*w.glob('uverify/*/long.csv')]:
 d=list(csv.DictReader(f.open()))
 for c in dict.fromkeys(x['case'] for x in d):
  rows={(r['mode'],r['round']):r for r in d if r['case']==c}
  for m in sorted({k[0] for k in rows}-{'base'}):
   pairs=[(r,rows['base',i]) for (e,i),r in rows.items() if e==m and ('base',i) in rows]
   if not pairs:continue
   assert all(a['status']==b['status']=='match' for a,b in pairs)
   print(f.parent.name,Path(c).stem,m,len(pairs),*[round(median(100*(float(a[k])/float(b[k])-1) for a,b in pairs),2) for k in ['instructions','ms']])
