from pathlib import Path
import csv,re,subprocess,collections,concurrent.futures
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'costs.csv').open()));seq=collections.Counter()
jobs=[]
for r in rows:
 if r['round']!='0':continue
 name=Path(r['input']).stem;seq[name]+=1;f=w/name/('%04d.smt2'%seq[name]);jobs.append((name,seq[name],r,f))
def run(job):
 name,i,r,f=job;txt=f.read_text();sorts=re.findall(r'^\(declare-sort ([^ ()]+)(?: 0)?\)$',txt,re.M);assert len(sorts)==txt.count('(declare-sort '),(name,i)
 out=[]
 for n in (0,1,2):
  extra=''
  for j,s in enumerate(sorts):
   constants=['|study!%d!%d|'%(j,k) for k in range(n)]
   if not n:continue
   assert all(c not in txt for c in constants)
   extra+=''.join('(declare-const '+c+' '+s+')\n' for c in constants)
   extra+='(assert (forall ((x '+s+')) (or '+ ' '.join('(= x '+c+')' for c in constants)+')))\n'
  d=w/'bounds'/str(n)/name;d.mkdir(parents=True,exist_ok=True);path=d/f.name;path.write_text(txt.replace('(check-sat)',extra+'(check-sat)'))
  try:
   z=subprocess.run([w/'native',path],check=True,capture_output=True,timeout=5);v=z.stdout.decode().strip();assert v in ('sat','unknown','unsat'),(path,v)
  except subprocess.TimeoutExpired:v='timeout'
  out.append(v)
 return [name,i,r['answer'],r['instructions'],len(sorts),*out]
with concurrent.futures.ThreadPoolExecutor(6) as pool:
 with (w/'answers.csv').open('w') as f:
  o=csv.writer(f);o.writerow('input check private instructions sorts unrestricted one two'.split());o.writerows(pool.map(run,jobs))
