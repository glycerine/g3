from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent/sys.argv[1];w.mkdir(exist_ok=True);ov={}
def save(k,s):
 f=p/k;d=w/(f.name+'.txt');d.write_text(s);ov[str(f)]=str(d)
if w.name in ('singleton','quantified','usersort'):
 k='api/api_goal_instances_check.go';s=(p/k).read_text();key='reuse := p.plans.reusable(parent)';assert s.count(key)==1
 save(k,s.replace(key,key+'\n if subset,ok:=plan.(*shortPremisePlan);reuse && ok && trialModel(parent,subset.selected){return false,nil}'))
 s=Path('/tmp/g3-early-cost/certificate/constant.go.txt').read_text().replace('if lhs==rhs{return trialTruth{yes:all}}','''if lhs==rhs{return trialTruth{yes:all}}
    sort,e:=m.GetSort(lhs);if e!=nil{return trialTruth{}};family,e:=m.GetFamilyID(sort);if e!=nil{return trialTruth{}}
    if family==ast.NullFamilyID{return trialTruth{yes:all}}''')
 if w.name in ('quantified','usersort'):s=s.replace('forall,e:=m.IsForall(h);if e!=nil || !forall{return trialTruth{}}','')
 if w.name=='usersort':s=s.replace('family,e:=m.GetFamilyID(sort)','singleton,e:=m.IsUninterpretedSort(sort)').replace('if family==ast.NullFamilyID','if singleton')
 save('api/private_singleton_trial.go',s)
else:
 k='api/api_order_abstraction.go';s=(p/k).read_text();key='params.SetBool("smt.mbqi", false)';assert s.count(key)==1;save(k,s.replace(key,'params.SetBool("smt.mbqi", true)'))
o=w/'trial.json';o.write_text(json.dumps({'Replace':ov}))
s=Path('/tmp/g3-plan-budget/hash/study.py').read_text().split('s=Path(\'/tmp/g3-or-install',1)[1];s="s=Path('/tmp/g3-or-install"+s;s=s.replace('/tmp/g3-live-frame-cost/recheck/baseline','/tmp/g3-plan-budget/production/release').replace("run(12,'whole'",f"run({12 if w.name=='singleton' else 14},'whole'")
exec(s)
