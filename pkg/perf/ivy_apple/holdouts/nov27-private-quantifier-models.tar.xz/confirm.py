from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-plan-budget/broad.py').read_text().replace('/tmp/g3-live-frame-cost/recheck/baseline','/tmp/g3-plan-budget/production/release').replace("['256','512']","['usersort']").split('with concurrent.futures.ThreadPoolExecutor')[0];exec(s)
run(10,'confirm',['examples/ivy/toy_consensus.ivy','test/toma8.ivy','examples/pldi16/leader_election_ring_bug.ivy','test/skolem1.ivy','examples/liveness/ticket.ivy','examples/ivy/card2.ivy','test/oddeven4.ivy','test/SC_2.ivy','test/vsync_paxos.ivy','doc/examples/leader_election_ring.ivy'],9,['base','usersort'])
