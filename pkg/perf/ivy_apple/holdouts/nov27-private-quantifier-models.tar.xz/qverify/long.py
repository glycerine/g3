from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-plan-budget/long.py').read_text().replace('g3-nov27-private-budget','g3-nov27-quantified-model').replace("['base','256','512']","['base','quantified']").replace("w/mode/'trial.json'","w.parent/mode/'trial.json'").replace("w/m/'release'","w.parent/m/'release'").replace('/tmp/g3-live-frame-cost/recheck/baseline','/tmp/g3-plan-budget/production/release').replace('for m in modes[i:]+modes[:i]:','for m in modes[i%2:]+modes[:i%2]:')
exec(s)
