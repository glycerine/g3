from pathlib import Path
import subprocess,csv,re
w=Path(__file__).resolve().parent;s=(w/'flash2/0011.smt2').read_text()
a=s.index('(assert ');head=s[:a];forms=re.split(r'(?=^\(assert )',s[a:s.index('(check-sat)')],flags=re.M)[1:]
d=w/'flash_core';d.mkdir(exist_ok=True)
def test(name,fs,mode):
 f=d/(name+'.smt2');f.write_text(head+''.join(fs)+'(check-sat)\n')
 return subprocess.check_output([w/'native',f,mode],timeout=5,text=True).strip()
keep=list(range(len(forms)))
for i in tuple(keep):
 trial=[j for j in keep if j!=i]
 if test('test', [forms[j] for j in trial],'1')=='unsat':keep=trial
print('irreducible', [j+1 for j in keep],test('core',[forms[j] for j in keep],'0'))
def ground(i,subst):
 q=forms[i-1];a=q.index('\n',q.index('(forall'));body=q[a:].strip();assert body.endswith(')))');body=body[:-2]
 for k,v in subst.items():body=body.replace(k,v)
 return '(assert '+body+')\n'
g1=ground(5,{'|X:id|':'@X','|Y:id|':'@Y','|Z:id|':'@Z'})
g2=ground(7,{'|V0:id|':'@Y','|V1:id|':'@Z'})
with (d/'evidence.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['variant','ematch','mbqi'])
 for name,fs in [('original',forms),('instance5',forms+[g1]),('instance7',forms+[g2]),('both',forms+[g1,g2]),('ground-only',forms[-2:]+[g1,g2]),('without5',forms[-2:]+[g2]),('without7',forms[-2:]+[g1])]:
  o.writerow([name,*[test(name,fs,m) for m in ['0','1']]])
