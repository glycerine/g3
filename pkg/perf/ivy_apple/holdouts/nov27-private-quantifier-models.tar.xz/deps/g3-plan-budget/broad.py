from pathlib import Path
import concurrent.futures
w=Path(__file__).resolve().parent;d=w/'panel';d.mkdir(exist_ok=True)
s=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0].replace('w=Path(__file__).resolve().parent;','');s=s[:s.index('subprocess.run([*flags')]+s[s.index('def run'):]
modes={'base':Path('/tmp/g3-live-frame-cost/recheck/baseline'),**{i:w/i/'release' for i in ['256','512']}};w=d;exec(s)
for file in modes.values():
 abc=file.parent/'abc'
 if not abc.exists():abc.symlink_to('/tmp/g3-frame-child/abc')
with concurrent.futures.ThreadPoolExecutor(8) as pool:
 jobs=[pool.submit(run,1+2*i,'panel'+str(i),cases[i::8],1,list(modes)[i%3:]+list(modes)[:i%3]) for i in range(8)]
 for job in jobs:job.result()
