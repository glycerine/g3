#include <stdio.h>
#include "z3.h"
int main(int argc, char **argv) {
    if (argc < 2 || argc > 3) return 2;
    Z3_config config = Z3_mk_config();
    Z3_context ctx = Z3_mk_context(config);
    Z3_del_config(config);
    Z3_solver s = Z3_mk_simple_solver(ctx);
    Z3_solver_inc_ref(ctx, s);
    if (argc == 3) {
        Z3_params params = Z3_mk_params(ctx);
        Z3_params_inc_ref(ctx, params);
        Z3_params_set_bool(ctx, params, Z3_mk_string_symbol(ctx, "macro_finder"), true);
        Z3_params_set_bool(ctx, params, Z3_mk_string_symbol(ctx, "mbqi"), argv[2][0] == '1');
        Z3_solver_set_params(ctx, s, params);
        Z3_params_dec_ref(ctx, params);
    }
    Z3_solver_from_file(ctx, s, argv[1]);
    Z3_lbool result = Z3_solver_check(ctx, s);
    puts(result == Z3_L_TRUE ? "sat" : result == Z3_L_FALSE ? "unsat" : "unknown");
    Z3_solver_dec_ref(ctx, s);
    Z3_del_context(ctx);
    return 0;
}
