from pathlib import Path
import json,csv,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd();ov=json.loads((w.parent/'overlay.json').read_text())['Replace']
f=p/'api/api_goal_instances_check.go';s=Path(ov[str(f)]).read_text().replace('studyCheck++;text,e:=aux.child.String();','''studyCheck++;candidate:=false;if sp,ok:=plan.(*shortPremisePlan);ok &&reuse {candidate=trialModel(parent,sp.selected)};fmt.Fprintf(os.Stderr,"CERT %d %v\\n",studyCheck,candidate);text,e:=aux.child.String();''')
d=w/'cover.go.txt';d.write_text(s);ov[str(f)]=str(d);k=str(p/'api/private_singleton_trial.go');ov[k]=json.loads((w.parent/'usersort/trial.json').read_text())['Replace'][k]
o=w/'cover.json';o.write_text(json.dumps({'Replace':ov}))
s=(w.parent/'capture.py').read_text();a=s.index("front=p/'build/");s=s[a:].replace("w/'g3'","w/'observer'").replace("d=w/Path(spec).stem;d.mkdir(exist_ok=True)","d=w/'shadow'/Path(spec).stem;d.mkdir(exist_ok=True,parents=True)").replace("keep=[];actual=[]","keep=[];actual=[];cert=[]").replace('else:keep.append(line)','elif line.startswith(b"CERT "):cert.append(line.decode())\n  else:keep.append(line)').replace('assert actual==expected','(d/"cert.txt").write_text("".join(cert));assert actual==expected')
exec(s)
