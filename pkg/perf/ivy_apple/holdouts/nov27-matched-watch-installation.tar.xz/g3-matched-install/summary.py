"""Report paired differences for complete verifier runs and per-stage medians."""
import csv, statistics as st
from pathlib import Path
d=Path(__file__).resolve().parent
def rows(p):return list(csv.DictReader(p.open()))
for p in sorted(d.glob('*panel/*.csv')):
    r=rows(p)
    def ratios(col):
        pairs={}
        for x in r:pairs.setdefault(x['round'],{})[x['engine']]=float(x[col])
        return [100*(v['trial']/v['base']-1) for v in pairs.values() if len(v)==2]
    if ratios('instructions'):print(p.parent.name,p.stem,len(ratios('instructions')),round(st.median(ratios('instructions')),2),round(st.median(ratios('wall_ms')),2))
for dirname in ['watch','final','guard-final','gates-controlled']:
    p=d/dirname/'check.csv'
    if not p.exists():continue
    r=rows(p)
    for name in sorted({x['engine'] for x in r}):
        ns=[int(x['instructions']) for x in r if x['engine']==name]
        print(dirname,name,len(ns),round(st.median(ns)/1e6,3))
for dirname in ['components','components-final','components-guard']:
    p=d/dirname/'phases.csv'
    if not p.exists():continue
    r=rows(p)
    for eng in ('release','native'):
        print(dirname,eng,{op:round(st.median(vals)/1e6,3) for op in ('K','L','M','W') if (vals:=[int(x['instructions']) for x in r if x['op']==op and x['engine']==eng])})
