from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-scoped-binary-reasons.tar.xz') as t:
    body=t.extractfile('study/check.py').read().decode()
a=body.index("        if mode == 'base':")
b=body.index('        mapping =',a)
body=body[:a]+'''        if mode=='fixed':
            p=pkg/'smtcore/smt_relevancy_asserted_or.go'
            src=p.read_text()
            a=src.index('p.context.exprs.write(parent)')
            b=src.index('return gate, nil',a)
            src=src[:a]+"""for i, literal := range literals {
        gate.children[i].slot=args[i].Slot()
        if literal.Sign(){
            p.context.exprs.write(args[i])
            gate.children[i].negated=p.internalizer.boolExpr[literal.Var()].Slot()
        }
    }
    handler := smtRelevancyHandler{kind:smtRelevancyAssertedOr,target:parent,assertedOr:gate}
    for i,literal:=range literals {
        v:=literal.Var()
        if !p.internalizer.notChild(v).IsNull(){
            if err:=p.addLiteralWatch(args[i],true,&handler);err!=nil{return nil,err}
            continue
        }
        switch p.internalizer.assignment[literal.Index()] {
        case lbool.True:
            if err:=p.invoke(&handler);err!=nil{return nil,err}
        case lbool.Undef:
            src:=p.internalizer.boolExpr[v]
            table,kind:=&p.positiveWatch,smtRelevancyPositiveWatchTrail
            if literal.Sign(){table,kind=&p.negativeWatch,smtRelevancyNegativeWatchTrail}
            if err:=p.register(table,kind,src,&handler);err!=nil{return nil,err}
        }
    }
    """+src[b:]
            trial=d/'trial-watch.go'
            trial.write_text(src)
            overlay[str(p)]=str(trial)
'''+body[b:]
exec(compile(body,'watch','exec'))
