from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-scoped-binary-reasons.tar.xz') as t:
    body=t.extractfile('study/check.py').read().decode()
a=body.index("        if mode == 'base':")
b=body.index('        mapping =',a)
body=body[:a]+'''        for filename in ('smt_relevancy.go','smt_relevancy_asserted_or.go'):
            original=d/('base-'+filename)
            original.write_bytes(sp.check_output(['git','show','dc5d2d13e:pkg/smtcore/'+filename]))
            overlay[str(pkg/'smtcore'/filename)]=str(original)
        if mode!='base':
            p=pkg/'smtcore/smt_internalizer.go'
            src=p.read_text()
            if mode in ('children','both'):
                a=src.index('if err = s.Internalize(argument, isGate);')
                src=src[:a]+"""if isGate {
                    if _, bound := s.boundInstanceLiteral(argument); bound {continue}
                }
                """+src[a:]
            if mode in ('arguments','both'):
                a=src.index('arguments, err := s.argumentLiterals(expression)')
                b=src.index('add := func(',a)
                src=src[:a]+"""var arguments []SMTLiteral
                var err error
                if gate:=s.boolGate(variable);gate!=nil {
                    arguments=make([]SMTLiteral,len(gate.args))
                    for i,child:=range gate.args {
                        if literal,ok:=s.boundInstanceLiteral(child);ok{arguments[i]=literal;continue}
                        arguments[i],err=s.Literal(child)
                        if err!=nil{return err}
                    }
                    gate.literals=arguments
                } else {
                    arguments,err=s.argumentLiterals(expression)
                    if err!=nil{return err}
                }
                """+src[b:]
            trial=d/(mode+'.go')
            trial.write_text(src)
            overlay[str(p)]=str(trial)
'''+body[b:]
body=body.replace("for mode in ('base','fixed'):","modes=['base','children','arguments','both']\n    for mode in modes:").replace('range(7)','range(4)').replace("(('fixed','base') if i%2 else ('base','fixed'))","modes[i:]+modes[:i]")
exec(compile(body,'gate','exec'))
