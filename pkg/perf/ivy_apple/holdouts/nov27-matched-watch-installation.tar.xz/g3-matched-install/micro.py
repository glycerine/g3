from pathlib import Path
import subprocess as sp,os,tempfile,json
d=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as temp:
    work=Path(temp);overlays={}
    for name in ('smt_relevancy.go','smt_relevancy_asserted_or.go'):
        p=work/name
        p.write_bytes(sp.check_output(['git','show','dc5d2d13e:pkg/smtcore/'+name]))
        overlays[str(Path('smtcore',name).resolve())]=str(p)
    mapping=work/'base.json'
    mapping.write_text(json.dumps({'Replace':overlays}))
    for policy in ('base','guard'):
        sp.run(['go','test','-c','-o',work/policy,*(['-overlay',mapping] if policy=='base' else []),'./smtcore'],check=True)
    with (d/'micro.bench').open('w') as out:
        for i in range(7):
            for p in (('guard','base') if i%2 else ('base','guard')):
                print('policy:',p,file=out,flush=True)
                sp.run(['taskset','-c',os.environ['CPU'],work/p,'-test.run=^$','-test.bench=^BenchmarkSMTAssertedOrWatchRegistration$','-test.benchtime=50000x','-test.cpu=1'],stdout=out,check=True)
