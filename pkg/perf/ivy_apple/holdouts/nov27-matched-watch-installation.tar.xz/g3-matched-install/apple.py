"""Measure the Apple frontend and native-reference isolates in alternating pairs."""
from pathlib import Path
import tarfile,subprocess as sp
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    s=t.extractfile('study/panel.py').read().decode()
s=s.replace("apple=name=='apple'","apple=True").replace("apple=mode=='apple'","apple=True")
i=s.index("    if name=='trial':")
j=s.index("    j=d/",i)
s=s[:i]+"""    if name=='base':
        for filename in ('smt_relevancy.go','smt_relevancy_asserted_or.go'):
            f=d/filename
            f.write_bytes(sp.check_output(['git','show','dc5d2d13e:pkg/smtcore/'+filename]))
            mp[str(pkg/'smtcore'/filename)]=str(f)
"""+s[j:]
s=s.replace("((1,3),(4,8),(6,227))","(('rfn2',),('dramc_nb2',))").replace('range(5)','range(3)')
exec(compile(s,'apple','exec'))
