from pathlib import Path
import tarfile
src=Path(__file__).resolve().parent.parent/'g3-gate-origin/matched-cost.py'
d={'__file__':str(src)}
s=src.read_text()
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    components=t.extractfile('study/components.py').read().decode()
components=components.replace('if err = s.relevancy.addAssertedOrWatches','gate, err := s.relevancy.addAssertedOrWatches')
i=components.index("g=edit(g,'\\n")
j=components.index('g=pre+g',i)
components=components[:i]+"""g=edit(g,'if err := s.relevancy.MarkRelevant(expression);','studyLog(fd,a,"W",false);a=studyRd(fd);if err := s.relevancy.MarkRelevant(expression);')
g=edit(g,'return s.relevancy.propagateWithOr(expression, gate)','err=s.relevancy.propagateWithOr(expression, gate);studyLog(fd,a,"M",false);return err')
"""+components[j:]
a=s.index("r=here.joinpath('origin.py')")
b=s.index('more={}',a)
s=s[:a]+components[:components.index('import os\nassert')]+s[b:]
exec(compile(s,str(src),'exec'),d)
