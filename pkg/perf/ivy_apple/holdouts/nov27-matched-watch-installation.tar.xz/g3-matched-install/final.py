import os,tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-scoped-binary-reasons.tar.xz') as t:
    load=lambda name:t.extractfile('study/'+name).read().decode()
    kind=os.environ['STUDY']
    if kind=='panel':
        s=load('final-panel.py').replace("'smt_clause.go','smt_internalizer.go','smt_boolean_propagation.go'","'smt_relevancy.go','smt_relevancy_asserted_or.go'")
    elif kind=='verify':s=load('verify.py')
    else:s=load('check.py').replace("'smt_internalizer_state.go','smt_enode_core.go'","'smt_relevancy.go','smt_relevancy_asserted_or.go'")
    s=s.replace('658c3136c:pkg/','dc5d2d13e:pkg/').replace('cd0b1a5f0:pkg/','dc5d2d13e:pkg/')
exec(compile(s,kind,'exec'))
