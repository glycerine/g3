"""Compute stage medians after summing all goals inside each verifier run."""
import collections,csv,statistics as st
from pathlib import Path
d=Path(__file__).resolve().parent/'batches'
work=collections.Counter()
for r in csv.DictReader((d/'stages.csv').open()):
    k=int(r['case']),int(r['round']),r['engine'],int(r['batch']),r['phase']
    work[k]+=int(r['instructions'])
groups={'prepare':['early-decline','early-success','batch-init','assert-base','first-push'],'search':['check']}
for case in sorted({k[0] for k in work}):
    phases={k[-1] for k in work if k[0]==case}
    def costs(phases,batch=None):
        c=collections.Counter()
        for (q,i,e,b,p),v in work.items():
            if q==case and p in phases and (batch is None or batch==b):c[i,e]+=v
        rounds={i for q,i,*_ in work if q==case}
        return [st.median(c[i,e] for i in rounds)/1e6 for e in ('g3','native')]
    with (d/f'case-{case}.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['phase','g3_M','native_M','gap_M'])
        for phase,ps in [*[(p,[p]) for p in sorted(phases)],*groups.items(),('all-metered',phases)]:
            g,n=costs(ps);w.writerow([phase,round(g,2),round(n,2),round(g-n,2)])
    print(case,[(k,round(g-n,1)) for k,v in groups.items() for g,n in [costs(v)]],
          sorted([(round(g-n,1),b) for b in {k[3] for k in work if k[0]==case} for g,n in [costs(groups['prepare'],b)]],reverse=True)[:3])
