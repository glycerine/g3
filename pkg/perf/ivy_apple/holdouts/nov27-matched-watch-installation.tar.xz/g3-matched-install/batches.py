"""Measure complete incremental batches on the same GoIvy frontend for five outstanding cases."""
from pathlib import Path
import csv,json,os,subprocess as sp,tarfile,tempfile
pkg=Path.cwd()
front=Path(os.environ['GOIVY_FRONTEND']).resolve()
ex=Path(os.environ['IVY_EXAMPLES'])
ref=Path(os.environ['NNF_REFERENCE'])
out=Path(os.environ['RESULTS'])
out.mkdir(parents=True,exist_ok=True)
names=(ref/'compat.txt').read_text().splitlines()
codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
def member(archive,name):
    with tarfile.open(pkg/'perf/ivy_apple/holdouts'/('nov27-'+archive+'.tar.xz')) as t:return t.extractfile(name).read().decode()
def instrument(src):
    i=src.index(' batch:=newStageBatch()')
    j=src.index('z3solver.Reset()',i)
    head,body,end=src[:i],src[i:j],src[j:]
    def edit(a,b):
        nonlocal body
        assert body.count(a)==1,a
        body=body.replace(a,b)
    edit('z3solver := s.newZ3Solver()', 'stopInit:=startStage(batch,0);z3solver := s.newZ3Solver();stopInit("solver")')
    edit('zc, err := s.ClausesToZ3(clauses)','stopBase:=startStage(batch,0);zc, err := s.ClausesToZ3(clauses);stopBase("translate-base")')
    edit('\n\tz3solver.Assert(zc)','\n\tstopAssert:=startStage(batch,0);z3solver.Assert(zc);stopAssert("assert-base")')
    edit('batchCheck, proveGoal, release = z3solver.BeginVerificationGoalBatch(len(finalCond))','stop:=startStage(batch,0);batchCheck, proveGoal, release = z3solver.BeginVerificationGoalBatch(len(finalCond));stop("batch-init")')
    body=body.replace('zCond, err := s.ClausesToZ3(cond)','stopTranslate:=startStage(batch,index+1);zCond, err := s.ClausesToZ3(cond);stopTranslate("translate-goal")')
    edit('stop("early");if proved','if proved {stop("early-success")} else {stop("early-decline")};if proved')
    edit('zCond = z3solver.SimplifyVerificationCondition(zCond)','stop:=startStage(batch,index+1);zCond = z3solver.SimplifyVerificationCondition(zCond);stop("simplify")')
    edit('count >= 3 && s.proveGuardedEqualities(z3solver, zCond, finalCond[index+1:nextGroup])','count >= 3 && func()bool{stop:=startStage(batch,index+1);ok:=s.proveGuardedEqualities(z3solver,zCond,finalCond[index+1:nextGroup]);stop("group");return ok}()')
    body=body.replace('z3solver.Assert(zCond)','stopGoal:=startStage(batch,index+1);z3solver.Assert(zCond);stopGoal("assert-goal")')
    body=body.replace('z3solver.Pop()','stopPop:=startStage(batch,index+1);z3solver.Pop();stopPop("pop")')
    return head+body+end
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp)
    def build(engine):
        native=engine=='native'
        mode='native' if native else 'g3'
        files={}
        def put(name,src):
            p=d/(engine+name)
            p.write_text(src)
            files[str(front/name)]=str(p)
        if native:
            bridge=member('unary-demand-and-fresh-symbols','study/sources/native-z3bridge_solver_model.go.txt')
            guards=member('unary-demand-and-fresh-symbols','study/sources/native-z3bridge_guarded_equalities.go.txt')
        else:
            bridge=member('terminal-conflict-replay','study/stage-bridge.go.txt')
            guards=member('terminal-conflict-replay','study/guards.go.txt')
        put('z3bridge_solver_model.go',instrument(bridge))
        put('z3bridge_guarded_equalities.go',guards)
        put('phase_observer_trial.go',member('first-push-queue-comparison','check-'+mode+'-phase_observer_trial.go'))
        j=d/'overlay.json';j.write_text(json.dumps({'Replace':files}))
        sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off,classic_z3' if native else 'xtrace_off','-pgo='+('off' if native else str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-overlay',j,'-o',d/engine,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=os.environ['TRIAL_CACHE']),check=True)
    for e in ('g3','native'):build(e)
    with (out/'stages.csv').open('w') as f:
        w=csv.writer(f);w.writerow('case round engine batch goal phase instructions ns'.split())
        for i in range(3):
            for case in (2,3,4,6,8):
                for e in (('native','g3') if i%2 else ('g3','native')):
                    cmd=['taskset','-c',os.environ['CPU'],d/e,ex/names[case-1]]
                    r=sp.run(cmd,cwd=d,capture_output=True,timeout=180,env=dict(os.environ,GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
                    clean=[];rows=[];pushed=set()
                    for line in r.stderr.splitlines(keepends=True):
                        if not line.startswith(b'STAGE-COUNT '):
                            clean.append(line);continue
                        _,batch,goal,phase,ins,empty,on,ran,ns=line.split()
                        assert on==ran,(case,e,line)
                        phase=phase.decode()
                        if phase=='push' and batch not in pushed:
                            phase='first-push';pushed.add(batch)
                        rows.append([case,i,e,int(batch),int(goal),phase,int(ins),int(ns)])
                    golden=ref/'compat'/str(case)/'1/native'
                    assert (r.returncode,r.stdout,b''.join(clean))==(codes[names[case-1]],(golden/'stdout').read_bytes(),(golden/'stderr').read_bytes()),(case,e,r.stderr[-800:])
                    assert rows
                    w.writerows(rows);f.flush()
