"""Match the phase windows directly to the obligation printed by the frontend."""
import csv,json,os,re,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;ref=Path(sys.argv[1]);examples=Path(sys.argv[2]).absolute();name='ticket_protocol'
path,_,status=json.loads((ref/'cases.json').read_text())[name]
p=subprocess.run(['taskset','-c','14',w/'ticket/g3',examples/path],cwd=w/'ticket/run-g3',env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
assert p.returncode==status and not (ref/'reference'/name/'stderr').read_bytes()
events=re.compile(rb'STAGE-COUNT (\d+) (\d+) ([\w-]+) \d+ \d+ \d+ \d+ \d+\n')
assert events.sub(b'',p.stdout)==(ref/'reference'/name/'stdout').read_bytes()
out=[]
for match in events.finditer(p.stdout):
 b,i,phase=match.groups()
 if phase!=b'check' or int(b) not in range(2,6) or int(i) not in (55,56):continue
 before=events.sub(b'',p.stdout[:match.start()]).decode()
 actions=re.findall(r'\(internal\) (ticket_protocol\.\w+)\n',before)
 lines=re.findall(r'ticket_protocol\.ivy: line (\d+):[^\n]*\.\.\.',before)
 out.append((int(b),int(i),actions[-1],int(lines[-1])))
assert len(out)==8
with (w/'ticket/labels.csv').open('w') as f:
 c=csv.writer(f);c.writerow(('batch','goal','action','line'));c.writerows(out)
print(out)
