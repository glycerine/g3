from pathlib import Path
import re,statistics,collections
w=Path(__file__).resolve().parent
for file in sorted([*w.glob('*-layout.txt'),*w.glob('*-bench.txt')]):
    values=collections.defaultdict(list)
    for name,ns,size,alloc in re.findall(r'^Benchmark(\S+)\s+\d+\s+(\S+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op', file.read_text(),re.M):
        values[name].append((float(ns),int(size),int(alloc)))
    for name,rows in values.items():
        print(file.name,name,len(rows),*[statistics.median(x) for x in zip(*rows)])
