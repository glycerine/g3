"""Count matched negative-one requests inside quantifier-instance rewrites. Run from pkg."""
from pathlib import Path
import json,re,tarfile,sys,subprocess,shlex
p=Path.cwd();w=Path(__file__).resolve().parent;mode=sys.argv[1];d=w/mode;d.mkdir(exist_ok=True)
a=p/'perf/ivy_apple/holdouts/nov27-ticket-instance-operators.tar.xz'
def src(k):return subprocess.check_output(['git','show','5fdebcf11:pkg/'+k],text=True)
if mode=='native':
 b=p.parent/'build';cfg=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l);mk=(b/'Makefile').read_text();objs=[]
 with tarfile.open(a) as ar:(d/'ops.hpp').write_bytes(ar.extractfile('native/ops.hpp').read())
 for f,no in [('ast/arith_decl_plugin.cpp',11),('smt/qi_queue.cpp',39)]:
    s=(p.parent/'src'/f).read_text()
    if no==39:
      x='m_context.get_rewriter()(instance, s_instance, pr);';assert s.count(x)==1
      s='counter measured_ops;\n'+s.replace(x,'measured_ops.begin();'+x+'measured_ops.finish();')
    else:
      x='parameter p[2] = { parameter(val), parameter(static_cast<int>(is_int)) };';assert s.count(x)==1
      s=s.replace(x,'''bool observe=measured_ops.fd>=0 && val.is_minus_one();
        auto tick=observe?measured_ops.start():0;
        '''+x+''' measured_ops.end(1,tick);tick=observe?measured_ops.start():0;''')
      x='return m_manager->mk_const(decl);';i=s.index(x,s.index('bool observe='));s=s[:i]+s[i:].replace(x,'''measured_ops.end(2,tick);tick=observe?measured_ops.start():0;
        auto result=m_manager->mk_const(decl);measured_ops.end(3,tick);return result;''',1)
    dst=d/Path(f).name;dst.write_text(s);obj=dst.with_suffix('.o')
    inc=shlex.split(re.search('^includes_'+str(no)+' = (.*)$',mk,re.M)[1]);subprocess.run([cfg['CXX'],*shlex.split(cfg['CXXFLAGS']),*inc,'-include',d/'ops.hpp','-o',obj,dst],cwd=b,check=True);objs.append(obj)
 link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',mk,re.M)[1];libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
 subprocess.run([cfg['LINK'],'-o',d/'z3',*objs,*libs,*shlex.split(cfg['LINK_EXTRA_FLAGS'])],cwd=b,check=True)
else:
 files={}
 def save(k,s):
    dst=d/(Path(k).name+'.txt');dst.write_text(s);files[str(p/k)]=str(dst)
 with tarfile.open(a) as ar:s=ar.extractfile('go/zz_opstudy.go.txt').read().decode().replace('package rewriter','package ast',1)
 s+='\nvar ObserveNumeral bool\nfunc numeralBegin()uint64{if !ObserveNumeral{return 0};return opBegin()}\n'
 save('ast/zz_opstudy.go',s)
 for k in ('util/numeral/mpq.go','util/numeral/rational_service.go','ast/ast_core_storage.go','ast/ast_info.go','ast/ast_arith_numeral.go'):save(k,src(k))
 k='cmd/g3/main.go';save(k,src(k).replace('package main','package main\nimport "runtime"').replace('func main() {','func main() { runtime.LockOSThread(); defer runtime.UnlockOSThread()'))
 k='smtcore/smt_qi_instance.go';x='if err = rw.Rewrite(instance, simplified); err != nil {';s=src(k);assert s.count(x)==1;save(k,s.replace(x,'ast.BeginObservedRow();err = rw.Rewrite(instance, simplified);ast.EndObservedRow();if err != nil {'))
 k='ast/rewriter/arith_rewriter.go';s=src(k);x='return r.manager.ArithmeticNumeralFromRational(value, integer)';assert s.count(x)==1
 save(k,s.replace(x,'if value.IsMinusOne(){ast.ObserveNumeral=true;defer func(){ast.ObserveNumeral=false}()};'+x))
 k='ast/rewriter/arith_polynomial.go';save(k,(w/'matched-add.go.txt').read_text())
 if mode=='phases':
    funcs=[('ast/ast_builtin_plugins.go','pluginDecl',2),('ast/ast_core_factories.go','mkApp',3),('ast/ast_arith_numeral.go','destroy',4)]
    k='ast/ast_arith_numeral.go';s=src(k);x='if err = m.numerals.CopyWithInvocation(&f.value, value, &f.copy); err != nil {';assert s.count(x)==1
    save(k,s.replace(x,'tick:=numeralBegin();err=m.numerals.CopyWithInvocation(&f.value,value,&f.copy);opEnd(1,tick);if err!=nil{'))
 else:
    funcs=[('ast/ast_info.go','newInfo',1),('ast/ast_info.go','dropInfoStorage',2),('ast/ast_table_hash.go','nodeHash',3),('ast/ast_table.go','tableInsert',4)]
 for k,n,category in funcs:
    s=Path(files[str(p/k)]).read_text() if str(p/k) in files else src(k)
    rx=r'(func \([^\n]+\) '+n+r'\([^\n]+ \{)';assert len(re.findall(rx,s))==1,n
    save(k,re.sub(rx,lambda m:m[1]+'\n defer opEnd('+str(category)+',numeralBegin())\n',s))
 o=d/'overlay.json';o.write_text(json.dumps({'Replace':files}));subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',d/'g3','./cmd/g3'],check=True)
