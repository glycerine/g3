"""Build two copies of the pinned GoIvy frontend with identical phase timers."""
from pathlib import Path
import tarfile,json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;d=w/'ticket';d.mkdir(exist_ok=True)
f=Path(sys.argv[1]).resolve();mod=Path(sys.argv[2]).resolve();k='z3bridge_solver_model.go'
with tarfile.open(p/'perf/ivy_apple/holdouts/nov26-ticket-hybrid-sat.tar.xz') as a:
    diff=a.extractfile('phase-counters/goivy-solver.patch').read()
    (d/'phase_observer_trial.go.txt').write_bytes(a.extractfile('phase-counters/phase_observer_trial.go').read())
(d/k).write_bytes((f/k).read_bytes());subprocess.run(['patch','--fuzz=0',d/k],input=diff,cwd=d,check=True)
o=d/'overlay.json';o.write_text(json.dumps({'Replace':{str(f/k):str(d/k),str(f/'phase_observer_trial.go'):str(d/'phase_observer_trial.go.txt')}}))
for n,tags in [('g3','xtrace_off'),('native','xtrace_off,classic_z3')]:
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags',tags,'-overlay',o,'-o',d/n,'./cmd/goivy_check'],cwd=f,check=True)
