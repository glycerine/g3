from pathlib import Path
import csv,sys,tarfile,os,subprocess,re
p=Path.cwd();w=Path(__file__).resolve().parent
with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-ticket-instance-operators.tar.xz') as a:
    source=a.extractfile('fixtures/toy-consensus-18.smt2').read()
    ref=next(r for r in csv.DictReader(a.extractfile('fixtures/census-full.csv').read().decode().splitlines()) if r['query']=='toy-consensus-18')
for mode in sys.argv[1:]:
    d=w/mode
    with (d/'rows.csv').open('w') as out:
        wr=csv.writer(out);wr.writerow(('round','instance','category','calls','raw','calibration16'))
        for n in range(3):
            r=subprocess.run(['taskset','-c','14',d/('z3' if mode.startswith('native') else 'g3'),'-in','-smt2'],input=source,capture_output=True,check=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
            assert r.stdout.startswith(b'unsat\n');stats=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()))
            assert all(stats[k]==ref[k] for k in ('decisions','conflicts','rlimit-count','quant-instantiations'))
            lines=r.stderr.decode().splitlines();assert len(lines)==int(ref['calls'])
            for j,l in enumerate(lines):
                assert l.startswith('OPS [');ns,vs=[list(map(int,z.split())) for z in l[5:-1].split('] [')];assert ns[0]==16
                for k in range(1,len(ns)):
                    if ns[k]:wr.writerow((n,j,k,ns[k],vs[k],vs[0]))
