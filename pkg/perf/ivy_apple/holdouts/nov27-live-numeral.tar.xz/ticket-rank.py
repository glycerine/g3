"""Rank concrete and early-proof call costs on the complete Ticket checker."""
import collections,csv,json,os,statistics,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;d=w/'ticket';ref=Path(sys.argv[1]).resolve();examples=Path(sys.argv[2]).absolute()
q='ticket_protocol';p,_,rc=json.loads((ref/'cases.json').read_text())[q]
expected=[(ref/'reference'/q/s).read_bytes() for s in ('stdout','stderr')]
rows=[]; keys=set()
for n in range(5):
    for e in (('g3','native') if n%2==0 else ('native','g3')):
        scratch=d/('run-'+e);scratch.mkdir(exist_ok=True)
        run=subprocess.run(['taskset','-c','14',d/e,examples/p],cwd=scratch,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,timeout=90)
        lines=run.stderr.splitlines(keepends=True);events=[l for l in lines if l.startswith(b'STAGE-COUNT ')]
        clean=b''.join(l for l in lines if not l.startswith(b'STAGE-COUNT '))
        if (run.returncode,run.stdout,clean)!=(rc,*expected):
            (scratch/'stderr').write_bytes(clean);(scratch/'stdout').write_bytes(run.stdout)
            raise ValueError((e,run.returncode,clean[:500],run.stdout[-200:],len(events)))
        assert events
        for l in events:
            _,batch,goal,phase,c,empty,en,active,wall=l.decode().split();assert en==active
            b,i=int(batch),int(goal);phase=phase.strip(); rows.append((n,e,b,i,phase,int(c),int(empty),int(wall)))
            if i:keys.add((b,i))
with (d/'counts.csv').open('w') as out:
    writer=csv.writer(out);writer.writerow(('round','engine','batch','goal','phase','instructions','empty','wall_ns'));writer.writerows(rows)
values=collections.Counter()
for n,e,b,i,phase,c,_,_ in rows:values[n,e,b,i,phase]+=c
def cost(e,b,i,phases):
    return statistics.median(sum(values[n,e,b,i,z] for z in phases) for n in range(5))
diffs=[]
for ordinal,(b,i) in enumerate(sorted(keys),1):
    g,z=[cost(e,b,i,['check','early']) for e in ('g3','native')]
    diffs.append((g-z,ordinal,b,i,g,z,cost('g3',b,i,['check']),cost('native',b,i,['check'])))
with (d/'rank.csv').open('w') as out:
    writer=csv.writer(out);writer.writerow(('excess','ordinal','batch','goal','go','native','go_check','native_check'));writer.writerows(sorted(diffs,reverse=True))
print('logical goals',len(keys),'total check+early excess',sum(q[0] for q in diffs))
for x in sorted(diffs,reverse=True)[:12]:print(*x)
