package main
import("debug/elf"; "debug/dwarf"; "fmt"; "os"; "strings")
func main(){for _,p:=range os.Args[1:]{f,e:=elf.Open(p);if e!=nil{panic(e)};d,e:=f.DWARF();if e!=nil{panic(e)};r:=d.Reader();for{ent,e:=r.Next();if e!=nil{panic(e)};if ent==nil{panic("type missing")};n,_:=ent.Val(dwarf.AttrName).(string);if ent.Tag==dwarf.TagStructType && strings.HasSuffix(n,"/ast.astInfoRecord"){fmt.Println(p,ent.Val(dwarf.AttrByteSize));break}};f.Close()}}
