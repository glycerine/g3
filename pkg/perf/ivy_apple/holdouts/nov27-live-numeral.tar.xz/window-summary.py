"""Summarize calibrated retired userspace instructions and match corresponding instances."""
from pathlib import Path
import csv,statistics,collections
w=Path(__file__).resolve().parent;counts={}
for d in ['native','phases','inner']:
    totals=collections.Counter();calls=collections.Counter();each=collections.Counter()
    for r in csv.DictReader((w/d/'rows.csv').open()):
        n,k,v,b,c,j=[int(r[x]) for x in ('round','category','raw','calibration16','calls','instance')]
        totals[n,k]+=v-b*c/16;each[n,j,k]+=c
        if n==0:calls[k]+=c
    counts[d]=each
    for k in sorted(calls):print(d,k,calls[k],round(statistics.median(totals[n,k] for n in range(3))/1e6,4))
for n in range(3):
    for j in range(906):
        c=counts['native'][n,j,1]
        assert all(counts[d][n,j,k]==c for d in ['native','phases','inner'] for k in (1,2,3))
        assert counts['phases'][n,j,4]==2*c and counts['inner'][n,j,4]==c
