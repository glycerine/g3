from pathlib import Path
import csv,statistics
for f in sorted(Path(__file__).resolve().parent.glob('warm-*/runs.csv')):
 rows=list(csv.DictReader(f.open()))
 d={(r['query'],int(r['iterations']),int(r['pair']),r['engine']):int(r['instructions']) for r in rows}
 for q in sorted(set(r['query'] for r in rows)):
    keys=[(q,n,k,e) for n in (4,16) for k in (1,2,3,4,5) for e in ('g3','native')]
    if not all(k in d for k in keys):continue
    deltas={e:[(d[q,16,k,e]-d[q,4,k,e])/12 for k in range(1,4)] for e in ('g3','native')}
    print(f.parent.name,q,round(statistics.median(100*(t/b-1) for t,b in zip(deltas['native'],deltas['g3'])),3))
 assert all(r['matched']=='1' for r in csv.DictReader((f.parent/'search.csv').open()))
