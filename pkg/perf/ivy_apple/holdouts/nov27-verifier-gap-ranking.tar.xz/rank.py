"""Rank the current paired instruction gaps and keep unmatched trials visible."""
from pathlib import Path
import csv,collections,statistics,sys
w=Path(__file__).resolve().parent
d=collections.defaultdict(dict)
for p in (w/'survey').glob('cpu-*.csv'):
 for r in csv.DictReader(p.open()):d[r['spec']][int(r['pair']),r['engine']]=r
def med(rows,field):return statistics.median(float(r[field]) for r in rows)
summary=[]
for spec,pairs in d.items():
 if len(pairs)!=6:continue
 g=[pairs[i,'g3'] for i in range(1,4)];z=[pairs[i,'native'] for i in range(1,4)]
 match=all(x['exit']==y['exit'] and x['same_stdout']==x['same_stderr']=='1' and x['timed_out']==y['timed_out']=='0' for x,y in zip(g,z))
 count=int(g[0]['pass'])+int(g[0]['fail'])
 summary.append((spec,int(match),count,round(med(g,'instructions')),round(med(z,'instructions')),int(statistics.median(int(x['instructions'])-int(y['instructions']) for x,y in zip(g,z))),round(med(g,'wall_s'),4),round(med(z,'wall_s'),4),round(statistics.median(float(x['wall_s'])/float(y['wall_s']) for x,y in zip(g,z)),4)))
with (w/'ranking.csv').open('w') as f:
 out=csv.writer(f);out.writerow('spec matched proof_results g3_insns z3_insns paired_gap g3_seconds z3_seconds paired_time_ratio'.split());out.writerows(sorted(summary,key=lambda x:-x[5]))
print('complete',len(summary),'matched',sum(x[1] for x in summary),'slower',sum(x[-1]>1 for x in summary if x[1]),'more instructions',sum(x[5]>0 for x in summary if x[1]))
