from pathlib import Path
import tarfile,csv,io,os,subprocess,sys
w=Path(__file__).resolve().parent;pkg=Path.cwd();ex=Path(sys.argv[1]);src=pkg/'perf/ivy_apple/holdouts'
with tarfile.open(src/'nov24-complete-solver-survey.tar.xz') as t:
 ranks=list(csv.DictReader(io.TextIOWrapper(t.extractfile('proofs-by-gap.csv'))))
cases=[r['spec'] for r in ranks if int(r['screen_difference'])>0]
assert len(cases)==37
(w/'prior-gaps.txt').write_text('\n'.join(cases)+'\n')
subprocess.run(['python3',src/'spec_survey.py','--examples',ex,'--cases',w/'prior-gaps.txt','--g3',w/'blendivy','--native',w/'native','--output',w/'survey','--cpu','12','14','16','18','20','22','--seconds','150','--pairs','3','--perf','/usr/lib/linux-tools/6.17.0-35-generic/perf'],env=dict(os.environ,GOIVY_INCLUDE=str(ex/'ivy/include')),check=True)
