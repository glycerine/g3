from pathlib import Path
import csv,re
from statistics import median as med
w=Path(__file__).resolve().parent
def panel(f):
 rows=list(csv.DictReader(f.open()))
 for c in dict.fromkeys(r['case'] for r in rows):
  r=[v for v in rows if v['case']==c];modes=list(dict.fromkeys(v['mode'] for v in r));reference='base';other=next(m for m in modes if m!=reference)
  a,b=([v for v in r if v['mode']==mode] for mode in (reference,other))
  if len(a)!=len(b):continue
  assert all(x['round']==y['round'] and x['status']==y['status']=='match' for x,y in zip(a,b))
  yield Path(c).stem,len(a),*[round(med(100*(float(y[k])/float(x[k])-1) for x,y in zip(a,b)),2) for k in ('instructions','ms')]
for mode in ['base','compact','indirect','fast']:
 f=w/mode/'micro.txt'
 if f.exists():
  z=re.findall(r'Read/(\w+)\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) B/view\s+(\d+) B/op\s+(\d+) allocs/op',f.read_text())
  print(mode,[(k,len(v),med(float(s[1]) for s in v),v[0][2:]) for k in sorted(set(x[0] for x in z)) if (v:=[x for x in z if x[0]==k])])
 for name in ['whole','confirm']:
  f=w/mode/(name+'.csv')
  if f.exists():print(mode,name,list(panel(f)))
