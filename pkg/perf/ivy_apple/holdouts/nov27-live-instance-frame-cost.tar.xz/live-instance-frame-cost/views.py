from pathlib import Path
import json,sys
p=Path.cwd();mode=sys.argv[1];w=Path(__file__).resolve().parent/mode;w.mkdir(exist_ok=True);ov={}
def file(n,s):
 f=p/'ast'/n;d=w/(n+'.txt');d.write_text(s);ov[str(f)]=str(d)
n='ast_core_span_factories.go';s=(p/'ast'/n).read_text();a=s.index('type AppArguments struct {');b=s.index('func (a AppArguments) size()',a)
if mode=='indirect':
 shape='''type AppArguments struct {
 slice []ASTHandle
 source *appArgumentSource
 argumentOffset, count uint32
}
type appArgumentSource struct {
 app ASTHandle
 manager *ASTManager
 span ASTLiteralVectorSpan
}
'''
 code='''if a.source==nil{return a.slice[i],nil}
 if m:=a.source.manager;m!=nil{''';get='a.source.app';span='a.source.span';init='source:&appArgumentSource{span:span},count:n';view='source:&appArgumentSource{app:app,manager:m}';plain='a.source == nil'
elif mode=='compact':
 shape='''type AppArguments struct {
 slice []ASTHandle
 appOwner *ASTManager
 span *ASTLiteralVectorSpan
 app ASTHandle
 argumentOffset, count uint32
}
'''
 code='''if a.appOwner==nil && a.span==nil{return a.slice[i],nil}
 if m:=a.appOwner;m!=nil{''';get='a.app';span='a.span';init='span:&span,count:n';view='app:app,appOwner:m';plain='a.appOwner == nil && a.span == nil'
else:raise ValueError(mode)
old=s[s.index('r, e := m.requireKind',a):s.index('if a.raw',a)]
s=s[:a]+shape+'''
func (a *AppArguments) at(i uint32)(ASTHandle,error){
 if i>=a.count || i>^uint32(0)-a.argumentOffset{return ASTHandle{},ErrASTDomain}
 i+=a.argumentOffset
 '''+code+old.replace('a.app, ASTApp',get+', ASTApp')+'return '+span+'.At(i)\n}\n'+s[b:]
s=s.replace('spanOwner: span.owner, slice: span.values, count: n, raw: true',init).replace('a.appOwner == nil && !a.raw',plain)
file(n,s)
n='ast_rewriter_access.go';s=(p/'ast'/n).read_text().replace('app: app, appOwner: m',view);file(n,s)
n='ast_core_factories.go';s=(p/'ast'/n).read_text().replace('args.appOwner == nil && !args.raw',plain.replace('a.','args.'));file(n,s)
n='ast_core_boolean_factories.go';s=(p/'ast'/n).read_text().replace('args.appOwner != nil || args.raw','!('+plain.replace('a.','args.')+')');file(n,s)
o=w/'trial.json';o.write_text(json.dumps({'Replace':ov}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().replace("Path('/tmp/g3-card-install/volume-release')","Path('/tmp/g3-quant-row-work/final/release')").replace("'-o',w/'release'","'-overlay',o,'-o',w/'release'").replace("['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy']","['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','examples/ivy/card3.ivy']").replace('run(12,','run('+('16' if mode=='compact' else '18')+',')
script=script.replace("w=Path(__file__).resolve().parent;", "w=Path(__file__).resolve().parent/mode;")
exec(compile(script,__file__,'exec'))
