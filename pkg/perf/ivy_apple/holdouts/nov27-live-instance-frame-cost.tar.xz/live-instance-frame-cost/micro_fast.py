from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
p=Path.cwd()
for mode in ['fast']:
 d=w/mode;d.mkdir(exist_ok=True)
 ov=json.loads((d/'trial.json').read_text()) if mode!='base' else {'Replace':{}}
 ov['Replace'][str(p/'ast/ast_argument_view_benchmark_test.go')]=str(w/'benchmark.go.txt')
 o=d/'micro.json';o.write_text(json.dumps(ov))
 subprocess.run(['go','test','-overlay',o,'-c','-o',d/'bench.test','./ast'],check=True)
for i in range(7):
 modes=['fast']
 for mode in modes[0:]+modes[:0]:
  d=w/mode
  with (d/'micro.txt').open('w' if i==0 else 'a') as f:subprocess.run(['taskset','-c','20',d/'bench.test','-test.run','^$','-test.bench','^BenchmarkBorrowedArgumentRead$','-test.cpu','1','-test.benchtime=1000000x'],stdout=f,check=True)
