from pathlib import Path
import sys,json,csv,os,subprocess,collections
w=Path(__file__).resolve().parent
exe,src,reference,case,spec,cpu,rounds=sys.argv[1:]
env=dict(os.environ,GOIVY_INCLUDE=src+'/ivy/include',GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1')
cmd=['taskset','-c',cpu,exe]
if case in ('rfn2','dramc_nb2'):cmd.append('isolate='+case)
cmd.append(src+'/'+spec)
names=json.loads((w/'labels.json').read_text())
ref=Path(reference)
with (w/(case+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow(['round','attempt','proved',*[x[1] for x in names]])
 for n in range(int(rounds)):
    r=subprocess.run(cmd,cwd=w,env=env,capture_output=True,timeout=240)
    extra=bytearray();i=0
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'EARLY-COST '):
            _,ok,raw=line.decode().strip().split(' ',2);values=list(map(int,raw[1:-1].split()))
            out.writerow([n,i,ok,*values[:len(names)]]);i+=1
        else:extra.extend(line)
    assert (r.returncode,r.stdout,bytes(extra))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(case,r.returncode,extra[:300],len(r.stdout),len((ref/'stdout').read_bytes()))
    assert i>0;print(case,n,i,flush=True);f.flush()
