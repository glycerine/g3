from pathlib import Path
w=Path(__file__).resolve().parent/'fast'
s=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0].replace('w=Path(__file__).resolve().parent;','')
s=s[:s.index('subprocess.run([*flags')]+s[s.index('modes={'):]
exec(s.replace('/tmp/g3-card-install/volume-release','/tmp/g3-quant-row-work/final/release'))
names=list(dict.fromkeys([r['case'] for r in csv.DictReader((rank/'ranking.csv').open())][:12]+['examples/ivy/card3.ivy']))
run(10,'confirm',names,7,['base','release'])
