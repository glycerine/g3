from pathlib import Path
import json,sys,shlex,shutil,subprocess,re
p=Path.cwd();w=Path(__file__).resolve().parent;e=sys.argv[1];src=Path('/tmp/g3-quant-row-work/price');front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-ticket-stages/translated.json').read_text())['Replace']
if e=='g3':
 for fn,target in [('go/rewriter_engine.go.txt','rewriter_engine.go'),('/tmp/g3-frame-child/meter/go/zz_opstudy.go.txt','zz_opstudy.go')]:ov[str(p/'ast/rewriter'/target)]=str(src/fn)
 f=p/'smtcore/smt_qi_instance.go';s=f.read_text();k='if err = rw.Rewrite(instance, simplified); err != nil {';assert s.count(k)==1
 s=s.replace(k,'rewriter.BeginObservedRow();err=rw.Rewrite(instance,simplified);rewriter.EndObservedRow();if err!=nil{');d=w/'instance.go.txt';d.write_text(s);ov[str(f)]=str(d)
else:
 b=p.parent/'build';f=p.parent/'src/smt/qi_queue.cpp';k='m_context.get_rewriter()(instance, s_instance, pr);';s=f.read_text();assert s.count(k)==1
 d=w/'qi_queue.cpp';d.write_text('counter measured_ops;\n'+s.replace(k,'measured_ops.begin();'+k+'measured_ops.finish();'))
 flags=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l);inc=shlex.split(re.search('^includes_39 = (.*)$',(b/'Makefile').read_text(),re.M)[1]);obj=w/'qi_queue.o'
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-include',src/'native-src/ops.hpp','-o',obj,d],cwd=b,check=True)
 lib=w/'lib.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj,src/'native-src/th_rewriter.o'],check=True)
 f=front/'smt/quantifier.go';d=w/'quantifier.go';d.write_text(f.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));ov[str(f)]=str(d)
o=w/(e+'.json');o.write_text(json.dumps({'Replace':ov}));subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='native' else ''),'-overlay',o,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
