from pathlib import Path
import json
p=Path.cwd();mode='fast';w=Path(__file__).resolve().parent/mode;w.mkdir(exist_ok=True)
f=p/'ast/ast_core_span_factories.go';s=f.read_text()
s=s.replace('return a.at(i) }','''if a.appOwner == nil && !a.raw && i < a.count {
		return a.slice[a.argumentOffset+i], nil
	}
	return a.at(i)
}''')
# SliceArguments starts at zero; every valid slice range fits its original uint32 count.
d=w/(f.name+'.txt');d.write_text(s);o=w/'trial.json';o.write_text(json.dumps({'Replace':{str(f):str(d)}}))
driver=(w.parent/'views.py').read_text().split('script=Path',1)[1]
exec('script=Path'+driver.replace("('16' if mode=='compact' else '18')","'16'"))
