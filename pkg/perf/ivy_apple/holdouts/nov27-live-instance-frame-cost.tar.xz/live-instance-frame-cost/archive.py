from pathlib import Path
import tarfile
w=Path(__file__).resolve().parent
root=Path('/tmp')
out=Path.cwd()/'perf/ivy_apple/holdouts/nov27-live-instance-frame-cost.tar.xz'
with tarfile.open(out,'w:xz',preset=3) as t:
 def add(f,n):t.add(f,'live-instance-frame-cost/'+str(n),recursive=False)
 for f in sorted(w.rglob('*')):
  if not f.is_file() or f.is_symlink():continue
  rel=f.relative_to(w)
  if str(rel) in ('whole.csv','whole.stat','quantifier.go','inner/quantifier.go'):continue
  if f.suffix in ('.py','.csv','.gz','.cpp','.h','.md','.txt') or f.name=='labels.json':add(f,rel)
 for rel in ['g3-quant-row-work/price/go/rewriter_engine.go.txt','g3-quant-row-work/price/native-src/ops.hpp','g3-quant-row-work/price/native-src/ast/rewriter/rewriter_def.h','g3-frame-child/meter/go/zz_opstudy.go.txt','g3-ticket-stages/translated.go.txt','g3-ticket-stages/translated.json','g3-ticket-stages/stage.go.txt','g3-or-install/final/release.py','g3-reduction-rows/compat.txt','g3-reduction-rows/ranking.csv','g3-early-cost/detail/build.py','g3-early-cost/detail/run.py','g3-early-cost/detail/counter.go.txt','g3-frame-child/cert-totals.csv']:
  add(root/rel,Path('dependencies')/rel)
