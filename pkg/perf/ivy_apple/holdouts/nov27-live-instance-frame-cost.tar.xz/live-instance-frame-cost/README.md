# Live quantifier rewrites, borrowed argument views and failed private proofs

The measurements use g3 c5cee6ba3, the frozen GoIvy frontend, its local g3 replacement, and the linked native library from the same fork. The layout trials are separate source overlays on the same baseline. The microbenchmarks also work without GoIvy. No binaries or compiler caches are in this archive.

## Analyze the recorded results

Extract the archive into an external scratch directory. From the extracted directory run the following with Python 3.

    python3 results.py . inner
    python3 report.py
    python3 recheck/report.py
    python3 private/report.py
    python3 private/split/report.py
    python3 private/setup/report.py
    python3 private/init/report.py
    python3 private/prefix/report.py

Outer columns 1–6 measure operand fetch, child visit, frame preparation, changed application rebuild, unsuccessful non-macro frame completion, and constant-fold test. Inner columns 1–6 measure substitution query, cache eligibility, cache lookup, stack replacement, conditional cache publication, and remaining completion. Read the generated sources to see the exact boundaries. Per-instance rows are annotated with batch, goal and frontend stage. Three rounds must reproduce each engine's sequence of operation counts. The matched_signature flag compares the two engines in order within the stage, using the first five outer counts or all six inner counts. Across all stages, total costs are medians of sums within a complete run.

control.csv compares normal-GC releases of g3 and linked Z3. Each layout directory contains its own complete rotated pairs and the output from the argument reader benchmark. fast/confirm.csv contains the independent 13-input panel. recheck/recheck.csv records fresh-baseline, identical-copy and formatted-prototype comparisons, with both cycles and instructions on the same CPU. recheck/survey files check transcripts. The two alternating-bit examples have the same basename; consult the CSV paths to distinguish them. private/ CSV files contain exclusive solver-thread instructions per attempted proof, including successful and unsuccessful calls. private/labels.json preserves the column mapping.

## Repeat the experiments

The Go benchmark is available directly in pkg/ast. Run from pkg with go test ./ast -run '^$' -bench '^BenchmarkBorrowedArgumentRead$' -benchmem. The overlay in each trial directory contains the alternative sources for that revision. Generate a Go overlay with absolute source paths in its Replace dictionary. For a microbenchmark on the checked-in tree, use the existing benchmark file or overlay benchmark.go.txt onto ast/ast_argument_view_benchmark_test.go. Compile and alternate binaries on the same physical CPU. The 72-byte direct read has both an initially generated source and the gofmt-formatted source (recheck/reader.go.txt).

The original verifier drivers expect external scratch paths and a Linux perf-enabled machine. The path /tmp/g3-live-frame-cost refers to the extracted directory. dependencies/ contains the earlier measurement and release-driver sources at their original paths relative to /tmp. Install these there or adapt the paths consistently. Supply the GoIvy frontend and study.mod paths, Ivy include path, in-tree Z3 build and libz3.a, compatible ABC, CPUs and perf executable for the test machine. The linked reference transcripts and saved exit statuses are from the 228-input control corpus. For a new frontend, record fresh references using the paired build and corpus drivers in pkg/perf/ivy_apple/holdouts. Ranking and case-list copies are in dependencies/g3-reduction-rows. The standalone readers above require only Python and the archived results.

For the outer native build, first compile src/ast/rewriter/th_rewriter.cpp with the in-tree group's includes_12 and CXXFLAGS from the configured build, adding -I/tmp/g3-quant-row-work/price/native-src and -include /tmp/g3-quant-row-work/price/native-src/ops.hpp. Place th_rewriter.o in that native-src directory. That object contains the instrumented template instantiation. build.py native compiles the queue wrapper, then links both objects into a copy of the native library. Run build.py and run.py for each engine (g3, native), followed by their inner/ equivalents. For release controls use control.py and the separate views.py compact, views.py indirect and fast.py trials. confirm.py and recheck.py implement the confirmation protocols. Run the scripts from pkg unless analyzing completed CSV files. Keep each variant's binary and output paths distinct.
