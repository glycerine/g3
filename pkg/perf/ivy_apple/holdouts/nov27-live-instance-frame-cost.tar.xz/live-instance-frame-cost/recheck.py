from pathlib import Path
import csv,shutil,os,time,subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;d=w/'recheck';d.mkdir(exist_ok=True)
s=Path('/tmp/g3-or-install/final/release.py').read_text();exec(s[s.index("h=Path"):s.index('subprocess.run([*flags')])
f=p/'ast/ast_core_span_factories.go'
trial=d/'reader.go.txt';trial.write_bytes(subprocess.check_output(['gofmt',str(w/'fast'/(f.name+'.txt'))]))
o=d/'trial.json';o.write_text(json.dumps({'Replace':{str(f):str(trial)}}))
for m,extra in [('baseline',[]),('trial',['-overlay',o])]:
 subprocess.run([*flags,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod',*extra,'-o',d/m,'./cmd/goivy_check'],cwd=frontend,check=True)
shutil.copy2(d/'baseline',d/'replica')
abc=d/'abc'
if not abc.exists():abc.symlink_to('/tmp/g3-frame-child/abc')
names=[cases[cases.index(n)] for n in ['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','examples/ivy/card3.ivy','test/test_liveness2.ivy','examples/ivy/flash2.ivy']]
with (d/'recheck.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','round','engine','instructions','cycles','ms'])
 for name in names:
  ref=rank/'compat'/str(cases.index(name)+1)/'1/native'
  want=(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
  import itertools
  orders=list(itertools.permutations(('baseline','replica','trial')))
  for i in range(12):
   for m in orders[i%6]:
    stat=d/'raw.stat';start=time.monotonic()
    r=subprocess.run(['taskset','-c','12','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u,cycles:u','--',d/m,ex/name],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=h,capture_output=True,timeout=120)
    ms=(time.monotonic()-start)*1000
    assert (r.returncode,r.stdout,r.stderr)==want,(m,name,r.stderr[:200])
    readings={c[2]:int(c[0]) for c in csv.reader(stat.open()) if len(c)>4 and float(c[4])==100}
    out.writerow([name,i,m,readings['instructions:u'],readings['cycles:u'],round(ms,3)]);f.flush()
