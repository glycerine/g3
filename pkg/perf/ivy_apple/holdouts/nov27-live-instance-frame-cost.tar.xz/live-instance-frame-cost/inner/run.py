from pathlib import Path
import csv,os,subprocess,sys,re,gzip
w=Path(__file__).resolve().parent;e=sys.argv[1];src=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
paths=(src/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((src/'ranking.csv').open())}
for name in ['test/arm_rules3.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy']:
 ref=src/'compat'/str(paths.index(name)+1)/'1/native'
 with gzip.open(w/(e+'-'+Path(name).stem+'.csv.gz'),'wt') as f:
  o=csv.writer(f);o.writerow(['round','batch','goal','stage','instance',*['n'+str(i) for i in range(1,7)],*['ins'+str(i) for i in range(1,7)]])
  for rnd in range(3):
   r=subprocess.run(['taskset','-c',str(12 if e=='g3' else 14),w/e,ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
   keep=[];pending=[];records=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'OPS '):
     counts,raw=[list(map(int,v.split())) for v in re.findall(rb'\[([^\]]+)\]',l)]
     assert counts[0]==16
     pending.append([*counts[1:7],*[raw[i]-counts[i]*raw[0]/16 for i in range(1,7)]])
    elif l.startswith(b'STAGE-COUNT '):
     _,b,g,s,_,_,en,active,_=l.decode().split();assert en==active
     records.extend([rnd,b,g,s,i,*q] for i,q in enumerate(pending));pending=[]
    else:keep.append(l)
   assert records and not pending and (r.returncode,r.stdout,b''.join(keep))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(e,name,r.returncode,len(records),len(pending),b''.join(keep)[:500])
   o.writerows(records);f.flush()
