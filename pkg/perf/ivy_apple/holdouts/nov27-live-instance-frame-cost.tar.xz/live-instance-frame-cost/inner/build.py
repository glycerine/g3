from pathlib import Path
import json,re,subprocess,sys,shlex,shutil
p=Path.cwd();w=Path(__file__).resolve().parent;e=sys.argv[1];front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w.parent/(e+'.json')).read_text())['Replace']
if e=='g3':
 f=p/'ast/rewriter/rewriter_engine.go';s=f.read_text()
 a=s.index('func (r *rewriterEngine) visit(');b=s.index('func (r *rewriterEngine) processVar(',a);h,x,t=s[:a],s[a:b],s[b:]
 for n,k in enumerate(['sub, subProof, found, e := r.cfg.GetSubst(t)','cache, e := r.mustCacheShape(t, kind, rc, n)','h, e := c.getCached(t)'],1):
  assert x.count(k)==1;x=x.replace(k,'stamp'+str(n)+':=opBegin();'+k+';opEnd('+str(n)+',stamp'+str(n)+')')
 s=h+x+t;a=s.index('func (r *rewriterEngine) finish(');b=s.index('func (r *rewriterEngine) rewritten',a);x=s[a:b].replace(') finish(',') finishObserved(')
 x=x.replace('if e = shrinkRewriterRoots','stamp:=opBegin();if e = shrinkRewriterRoots').replace('if e = r.cache','opEnd(4,stamp);stamp=opBegin();if e = r.cache').replace('c.frames = c.frames','opEnd(5,stamp);stamp=opBegin();c.frames = c.frames').replace('return m.ResetRefHeld(r.r)','e=m.ResetRefHeld(r.r);opEnd(6,stamp);return e')
 a=s.index('func (r *rewriterEngine) processApp()');b=s.index('// processAppMacroEnd',a);idx=s.rindex('return r.finish(fr, false, true)',a,b);s=s[:idx]+s[idx:].replace('return r.finish(fr, false, true)','return r.finishObserved(fr,false,true)',1)+x
 dst=w/'engine.go.txt';dst.write_text(s);ov[str(f)]=str(dst)
else:
 q=w/'src';h=q/'ast/rewriter/rewriter_def.h';h.parent.mkdir(parents=True,exist_ok=True);s=(p.parent/'src/ast/rewriter/rewriter_def.h').read_text();a=s.index('::visit(expr * t');b=s.index('\ntemplate<typename Config>',a);pre,x,post=s[:a],s[a:b],s[b:]
 x=x.replace('if (m_cfg.get_subst(t, new_t, new_t_pr))','auto t1=measured_ops.start();bool hit=m_cfg.get_subst(t,new_t,new_t_pr);measured_ops.end(1,t1);if(hit)').replace('bool c = must_cache(t);','auto t2=measured_ops.start();bool c=must_cache(t);measured_ops.end(2,t2);').replace('expr * r = get_cached(t);','auto t3=measured_ops.start();expr * r=get_cached(t);measured_ops.end(3,t3);')
 s=pre+x+post;i=s.index('// TODO: add rewrite rules support');j=s.index('case REWRITE_BUILTIN:',i);x=s[i:j].replace('result_stack().shrink(fr.m_spos);','auto t4=measured_ops.start();result_stack().shrink(fr.m_spos);',1).replace('cache_result<ProofGen>(t, m_r, m_pr, fr.m_cache_result);','measured_ops.end(4,t4);auto t5=measured_ops.start();cache_result<ProofGen>(t,m_r,m_pr,fr.m_cache_result);measured_ops.end(5,t5);auto t6=measured_ops.start();').replace('m_r = nullptr;','m_r=nullptr;measured_ops.end(6,t6);')
 h.write_text(s[:i]+x+s[j:]);b=p.parent/'build';flags=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l);inc=shlex.split(re.search('^includes_12 = (.*)$',(b/'Makefile').read_text(),re.M)[1]);o=w/'th_rewriter.o'
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),'-I'+str(q),*inc,'-include','/tmp/g3-quant-row-work/price/native-src/ops.hpp','-o',o,p.parent/'src/ast/rewriter/th_rewriter.cpp'],cwd=b,check=True)
 lib=w/'lib.a';shutil.copyfile(w.parent/'lib.a',lib);subprocess.run(['ar','r',lib,o],check=True);f=front/'smt/quantifier.go';d=w/'quantifier.go';d.write_text(f.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));ov[str(f)]=str(d)
out=w/(e+'.json');out.write_text(json.dumps({'Replace':ov}));subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='native' else ''),'-overlay',out,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
