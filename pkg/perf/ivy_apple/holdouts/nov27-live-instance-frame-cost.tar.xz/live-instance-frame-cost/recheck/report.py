from pathlib import Path
from statistics import median
import csv
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'recheck.csv').open()))
for key in dict.fromkeys(r['case'] for r in rows):
 d={(r['engine'],int(r['round'])):r for r in rows if r['case']==key}
 if len(d)!=36:continue
 print(key,[(m,*[round(median(100*(float(d[m,i][k])/float(d['baseline',i][k])-1) for i in range(12)),2) for k in ['instructions','cycles','ms']]) for m in ['replica','trial']])
