from pathlib import Path
from collections import defaultdict, Counter
from statistics import median
import gzip,sys,csv
w=Path(__file__).resolve().parent
for sub in sys.argv[1:] or ['.']:
 d=w/sub
 with (d/'stages.csv').open('w') as f,(d/'totals.csv').open('w') as ff:
  fields=['input','batch','goal','stage','g3_instances','native_instances','matched_signature']+['g3_'+str(i) for i in range(1,7)]+['native_'+str(i) for i in range(1,7)];out=csv.writer(f);out.writerow(fields);tot=csv.writer(ff);tot.writerow(['input','engine','instances',*['calls'+str(i) for i in range(1,7)],*['ins'+str(i) for i in range(1,7)]])
  for name in ['arm_rules3','ticket_protocol','hybrid_reliable_broadcast_cisa']:
   costs=defaultdict(lambda:[0.]*6);seq=defaultdict(list);calls=defaultdict(Counter);keys=set()
   for e in ['g3','native']:
    for r in csv.DictReader(gzip.open(d/(e+'-'+name+'.csv.gz'),'rt')):
     rnd=int(r['round']);key=(int(r['batch']),int(r['goal']),r['stage']);keys.add(key)
     k=(e,rnd,key);n=tuple(int(r['n'+str(i)]) for i in range(1,7));seq[k].append(n)
     for i in range(6):costs[k][i]+=float(r['ins'+str(i+1)]);calls[e,rnd][i]+=n[i]
    tot.writerow([name,e,sum(len(seq[e,0,k]) for k in keys),*[calls[e,0][i] for i in range(6)],*[round(median(sum(costs[e,rnd,k][i] for k in keys) for rnd in range(3))) for i in range(6)]])
   for k in sorted(keys):
    for e in ['g3','native']:assert seq[e,0,k]==seq[e,1,k]==seq[e,2,k],(e,k)
    a,b=seq['g3',0,k],seq['native',0,k];count=5 if sub=='.' else 6
    match=len(a)==len(b) and all(x[:count]==y[:count] for x,y in zip(a,b))
    out.writerow([name,*k,len(a),len(b),match,*[round(median(costs[e,i,k][j] for i in range(3))) for e in ['g3','native'] for j in range(6)]])
