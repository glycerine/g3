from pathlib import Path
import sys,json,subprocess,re
w=Path(__file__).resolve().parent;p=Path.cwd()
front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3]);label=sys.argv[3]
files={str(p/'api/internal/order/early_cost_trial.go'):str(w/'counter.go.txt')}
names=[
('api/api_order_abstraction.go','(*OrderProofBatch).ProveWithGoal'),
('api/api_order_abstraction.go','(*orderProofState).release'),
('api/api_order_abstraction.go','(*orderProofState).start'),
('api/api_order_abstraction.go','(*orderProofState).check'),
('api/api_order_boolean.go','(*orderProofState).checkBoolean'),
('api/api_enumeration_refutation.go','(*enumerationRefutation).release'),
('api/api_enumeration_refutation.go','(*enumerationRefutation).check'),
('api/api_ground_instances.go','(*groundInstanceSolver).proveObserved'),
('api/api_ground_instances.go','(*groundInstanceSolver).prove'),
('api/api_goal_instances_check.go','(*orderProofState).checkProofPlan'),
('api/api_goal_instances_check.go','(*orderProofState).proveGoalInstances'),
('api/api_verification_goal.go','(*orderProofState).proveRelevantPremises'),
('api/api_short_premises.go','(*orderProofState).shortPremises'),
('api/api_short_premises.go','(*orderProofState).checkShortPremises'),
('api/internal/order/quantified_goal.go','(*QuantifiedPremises).Project'),
('api/internal/order/ground_boolean.go','ProjectGroundBooleans'),
('api/internal/order/ground_premises.go','(*GroundPremises).Refutes'),

]
for method in ['ForProof','planGroundGoals','planWitnessInstances','selectWitnessPremises','checkPrivate','proveSelected','assertIn']:
    for k in (p/'api').rglob('*.go'):
        if k.name.endswith('_test.go'):continue
        for rec,fn in re.findall(r'^func (?:\(\w+ \*(\w+)\) )?('+method+r')\(',k.read_text(),re.M):
            names.append((str(k.relative_to(p)),('(*'+rec+').' if rec else '')+fn))
names.extend([
('api/api_goal_instances_check.go','assertTranslatedPremises'),('api/api_witness_input.go','validProofInput'),
('api/api_order_boolean.go','(*orderProofState).checkBooleanInput'),
('api/internal/order/ground_equalities.go','ProjectGroundEqualities'),
('api/internal/order/ground_equalities.go','(*groundProjection).mergeRequiredEqualities'),
('api/internal/order/ground_equalities.go','(*groundProjection).mergeCongruentTerms'),
('api/internal/order/ground_equalities.go','(*groundProjection).encodeGroundClasses'),
('api/internal/order/observed_ground_instances.go','(*groundProjection).addObservedInstances'),
('api/api_proof_plan_context.go','(*proofPlanContext).close')
])
assert len(names)<50
sources={}
for idx,(rel,method) in enumerate(names):
    k=p/rel;s=sources.get(k,k.read_text());prefix='' if 'internal/order' in rel else 'order.'
    if prefix and '"github.com/glycerine/g3/pkg/api/internal/order"' not in s:
        s=s.replace('package api','package api\nimport "github.com/glycerine/g3/pkg/api/internal/order"',1)
    pattern='^func '+(r'\(\w+ \*'+method[2:method.index(')')]+r'\) '+method.split('.')[-1] if method.startswith('(') else method)+r'\([^\n]*\) [^\n]*?\{'
    match=re.search(pattern,s,re.M);assert match,(k,pattern)
    code=('order.PriceBegin();defer func(){order.PriceEnd(proved && err==nil)}();' if idx==0 else '')+'defer '+prefix+'PriceSection('+str(idx)+')();'
    sources[k]=s[:match.end()]+'\n'+code+'\n'+s[match.end():]
k=p/'api/api_goal_instances_check.go';s=sources[k]
s=s.replace('answer, err := aux.child.Check()', 'end:=order.PriceSection('+str(len(names))+');answer, err := aux.child.Check();end()')
names.append(('api/api_goal_instances_check.go','private SMT Check'))
sources[k]=s
for k,s in sources.items():
    dst=w/(k.stem+'-obs.go');dst.write_text(s);files[str(k)]=str(dst)
(w/'labels.json').write_text(json.dumps(names,indent=1))
ov=w/'obs.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=front,check=True)
