from pathlib import Path
import csv,sys,subprocess,json,os
w=Path(__file__).resolve().parent;p=Path.cwd()
src=Path('/tmp/g3-early-cost/detail')
(w/'counter.go.txt').write_bytes((src/'counter.go.txt').read_bytes())
s=(src/'build.py').read_text().replace("'-pgo=off'","'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')")
s=s.replace("('api/internal/order/universal_premises.go','(*UniversalPremises).Refutes'),", '')
(w/'build.py').write_text(s)
subprocess.run([sys.executable,w/'build.py',p/'build/.boolean-enode-cost/frontend/goivy',p/'build/.boolean-enode-cost/heap/study.mod','g3'],check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows')
cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
for spec in ['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy']:
 s=(src/'run.py').read_text().replace('==(0,','==('+str(codes[spec])+',')
 (w/'run.py').write_text(s)
 subprocess.run([sys.executable,w/'run.py',w/'g3',ex,rank/'compat'/str(cases.index(spec)+1)/'1/native',Path(spec).stem,spec,'18','3'],check=True)
