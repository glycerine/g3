from pathlib import Path
import json,subprocess,sys,csv,gzip,os
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'api/api_goal_instances_check.go';s=f.read_text()
s=s.replace('"errors"','"errors"\n"fmt"\n"os"')
k='complete, err := plan.assertIn(parent, m, aux.child)';assert s.count(k)==1
s=s.replace(k,'''fmt.Fprintf(os.Stderr,"PLANROOT %p %p %T",aux,m,plan)
 if sp,ok:=plan.(*shortPremisePlan);ok {for _,h:=range sp.selected {fmt.Fprintf(os.Stderr," %d/%d/%d",h.Origin(),h.Slot(),h.Generation())}}
 fmt.Fprintln(os.Stderr)
 '''+k)
# Use explicit lifecycle boundaries to detect allocator address reuse.
f2=p/'api/api_proof_plan_context.go';s2=f2.read_text().replace('"errors"','"errors"\n"fmt"\n"os"');k='if c.aux == nil {';assert s2.count(k)==1
s2=s2.replace('c.uses++','if c.uses==0 {fmt.Fprintf(os.Stderr,"PLANNEW %p\\n",c.aux)};c.uses++')
ov={}
for f,s in [(f,s),(f2,s2)]:
 q=w/(f.name+'.txt');q.write_text(s);ov[str(f)]=str(q)
o=w/'trial.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',o,'-o',w/'g3','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
for spec in ['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy']:
 r=subprocess.run(['taskset','-c','18',w/'g3',ex/spec],env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True)
 keep=[];raw=[]
 for l in r.stderr.splitlines(keepends=True):(raw if l.startswith((b'PLANROOT ',b'PLANNEW ')) else keep).append(l)
 ref=rank/'compat'/str(cases.index(spec)+1)/'1/native'
 assert (r.returncode,r.stdout,b''.join(keep))==(codes[spec],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
 with gzip.open(w/(Path(spec).stem+'.txt.gz'),'wb') as out:out.writelines(raw)
