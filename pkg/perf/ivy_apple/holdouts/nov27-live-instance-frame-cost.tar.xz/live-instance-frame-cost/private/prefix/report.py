from pathlib import Path
import gzip,os
w=Path(__file__).resolve().parent
for f in w.glob('*.txt.gz'):
 last={};plans=short=terms=eligible=shared=whole=first=0
 for line in gzip.open(f,'rt'):
  kind,owner,*v=line.split()
  if kind=='PLANNEW':last[owner]=None;continue
  plans+=1
  assert owner in last
  if v[1]!='*api.shortPremisePlan':last[owner]=None;continue
  short+=1;roots=v[2:];terms+=len(roots);prior=last[owner]
  if prior is not None:
   eligible+=1;n=0
   for a,b in zip(roots,prior):
    if a!=b:break
    n+=1
   shared+=n;first+=n>0;whole+=len(roots)>0 and n==len(roots)==len(prior)
  last[owner]=roots
 print(f.name,dict(plans=plans,short=short,terms=terms,adjacent=eligible,nonempty=first,shared=shared,identical=whole))
