from pathlib import Path
from statistics import median
import csv,collections,json
w=Path(__file__).resolve().parent
for f in sorted(w.glob('*.csv')):
 with f.open() as fh:
  data=csv.reader(fh);head=next(data);rounds=collections.defaultdict(list)
  for n,i,ans,*v in data: rounds[int(n)].append((int(i),ans,tuple(map(int,v))))
 if len(rounds)!=3:continue
 assert all([(v[0],v[1]) for v in rows]==[(v[0],v[1]) for v in rounds[0]] for rows in rounds.values())
 miss=[v[0] for v in rounds[0] if v[1]=='false']
 totals=[(median(sum(rows[i][2][j] for i in miss) for rows in rounds.values()),j) for j in range(len(head)-3)]
 print(f.stem,len(miss),len(rounds[0]),round(sum(c for c,j in totals)/1e6,2),[(head[j+3],round(c/1e6,2)) for c,j in sorted(totals,reverse=True)[:7]])
