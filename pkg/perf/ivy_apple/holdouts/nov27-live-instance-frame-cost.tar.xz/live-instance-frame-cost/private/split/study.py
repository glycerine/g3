from pathlib import Path
import csv,sys,subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd();prev=w.parent
ov=json.loads((prev/'obs.json').read_text());labels=json.loads((prev/'labels.json').read_text())
f=p/'api/api_goal_instances_check.go';s=Path(ov['Replace'][str(f)]).read_text();k=s.index('func assertTranslatedPremises(');a,b=s[:k],s[k:]
for pattern,alias,stmt in [('value, err := translation.Translate(h)','translate root','value,err:=translation.Translate(h)'),('if err = m.IncRef(value); err != nil {','retain translated root','err=m.IncRef(value)'),('err = child.Assert(value)','assert translated root','err=child.Assert(value)'),('if err = errors.Join(err, m.DecRef(value)); err != nil {','release translated root','err=errors.Join(err,m.DecRef(value))')]:
 assert b.count(pattern)==1
 idx=len(labels);labels.append([str(f.relative_to(p)),alias]);b=b.replace(pattern,'s'+str(idx)+':=order.PriceSection('+str(idx)+');'+stmt+';s'+str(idx)+'()'+(';if err!=nil {' if 'if err' in pattern else ''))
d=w/'plan.go.txt';d.write_text(a+b);ov['Replace'][str(f)]=str(d);o=w/'split.json';o.write_text(json.dumps(ov));(w/'labels.json').write_text(json.dumps(labels))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',o,'-o',w/'g3','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
s=(prev/'study.py').read_text();exec(s[s.index('ex=Path'):].replace("'18','3'","'18','3'").replace("s=(src/'run.py').read_text()","s=Path('/tmp/g3-early-cost/detail/run.py').read_text()"))
