from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-or-install/final/release.py').read_text()
s=s[:s.index('subprocess.run([*flags')]+s[s.index('modes='):]
s=s.replace("'/tmp/g3-card-install/volume-release'","'/tmp/g3-quant-row-work/final/release'").replace("run(12,'whole'","run(14,'control'").replace("'examples/ivy/card3.ivy'","'jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy'").replace("7,['base','release']","5,['base','native']")
exec(s)
