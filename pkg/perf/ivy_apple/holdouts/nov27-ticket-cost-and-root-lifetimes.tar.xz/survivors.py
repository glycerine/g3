from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    p=pkg/'smtcore/smt_internalizer.go';s=p.read_text()
    a='return s.assertExpression(lemma, proof, instance.Generation(), arguments)'
    assert s.count(a)==1;s=s.replace(a,'if StudyGoal{previous:=studyInstance;studyInstance=s;defer func(){studyInstance=previous}()};'+a)+'\nvar StudyGoal bool\nvar studyInstance *SMTInternalizerState\n'
    a='if err = s.addRootClause(literals, proof); err != nil {'
    assert s.count(a)==1
    s=s.replace(a,'''old:=len(s.auxClauses);seen:=StudyGoal && studyInstance==s
            if seen { print("ROWBEGIN ",s," ",s.scopeLevel);for _,l:=range literals{print(" ",uint32(l.Index()))};println() }
            '''+a)
    a=s.index('if s.relevancy != nil {',s.index('old:=len(s.auxClauses)'))
    s=s[:a]+'if seen {println("ROWEND",len(s.auxClauses)>old)};'+s[a:];yield p,s
    p=pkg/'smtcore/smt_internalizer_state.go';s=p.read_text()
    a='level := len(s.scopes) - int(count)';i=s.index(a,s.index('func (s *SMTInternalizerState) PopScopes('))+len(a)
    yield p,s[:i]+';if StudyGoal {println("ROWOP",s,level,s.scopes[level].firstScopedBoolVar())}'+s[i:]
def run(s):
    p=Path(__file__).with_name('templates.py')
    ns={};exec(p.read_text().split("panel(['probe'],patch,run)")[0],ns)
    return ns['run'](s).replace('"github.com/glycerine/g3/pkg/ast/rewriter"','"github.com/glycerine/g3/pkg/smtcore"')
panel(['probe'],patch,run)
