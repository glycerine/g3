from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_quantifier_stat.go';s=p.read_text()
    if name.startswith('cache'):
        width=int(name[5:])
        s=s.replace('struct{ manager *ast.ASTManager }','''struct{ manager *ast.ASTManager; recent []smtQuantifierMetrics }
type smtQuantifierMetrics struct{body ast.ASTHandle;size,depth,factor,nested uint32}''')
        a='result := &SMTQuantifierStat'
        s=s.replace(a,'''if g.recent==nil{g.recent=make([]smtQuantifierMetrics,'''+str(width)+''')};memo:=&g.recent[body.Slot()%uint32(len(g.recent))]
        if memo.body==body{return &SMTQuantifierStat{generation:generation,size:memo.size,depth:memo.depth,caseSplitFactor:memo.factor,numNestedQuantifiers:memo.nested},nil}
        '''+a).replace('return result, nil','*memo=smtQuantifierMetrics{body,result.size,result.depth,result.caseSplitFactor,result.numNestedQuantifiers};return result,nil')
    elif name=='header':
        i=s.index('kind, err := g.manager.GetKind(entry.expression)')
        v=s[i:].replace('kind, err := g.manager.GetKind(entry.expression)','header, err := g.manager.NodeHeader(entry.expression);kind:=header.Kind')
        a=v.index('family, err :=');b=v.index('switch op',a)
        v=v[:a]+'if header.Family == g.manager.BasicFamilyID() { op,count:=header.DeclKind,header.NumArgs;'+v[b:]
        a=v.index('count, err := g.manager.GetNumArgs');b=v.index('for i := count',a)
        v=v[:a]+'count:=header.NumArgs;'+v[b:];s=s[:i]+v
    yield p,s
def run(s):
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%4:]+modes[:i%4]").replace("for mode in modes:w.writerow","for mode in order:w.writerow")
    return s.replace('range(5):','range(4):')
panel(['base','cache16','cache64','header'],patch,run)
