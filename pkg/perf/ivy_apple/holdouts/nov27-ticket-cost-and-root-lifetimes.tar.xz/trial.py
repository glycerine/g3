from pathlib import Path
import tarfile
d=Path(__file__).resolve().parent
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    if name=='trial':yield pkg/'smtcore/smt_qi_cost.go',(d/'cost.go.txt').read_text()
panel(['base','trial'],patch)
