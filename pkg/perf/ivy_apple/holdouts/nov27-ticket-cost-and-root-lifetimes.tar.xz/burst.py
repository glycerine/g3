from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_qi_queue_schedule.go';s=p.read_text()
    a='sinceLastCheck := 0\n\tfor i := range q.newEntries'
    assert s.count(a)==1
    s=s.replace(a,'var previous ast.ASTHandle;runLength:=0;'+a)
    a='if entry.Cost <= q.eagerThreshold {'
    s=s.replace(a,'''key:=entry.Fingerprint.data
        if key!=previous {runLength=0;previous=key}
        runLength++
        if entry.Cost <= q.eagerThreshold && (runLength <= '''+name[1:]+''' || entry.Cost > q.lazyThreshold) {''')
    yield p,s
def run(s):
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%4:]+modes[:i%4]").replace("for mode in modes:w.writerow","for mode in order:w.writerow")
    return s.replace('range(5):','range(4):').replace('((1,3),(4,8),(6,227))','((4,3),(8,5),(6,2))')
panel(['base','q4','q16','q64'],patch,run)
