from pathlib import Path
from collections import defaultdict,Counter
root=Path(__file__).resolve().parent
bins=defaultdict(Counter);sources=defaultdict(Counter)
for line in (root/'operands/events').open():
 op,*v=line.split()
 if op=='ROWGOAL':goal=tuple(v);states={}
 elif op=='ROWARG':
    s,origin,slot,generation,lit,work=v;h=(origin,slot,generation);work=int(work)
    live,retired=states.setdefault(s,({},set()))
    tag='recreated' if h in retired else 'seen live' if h in live else 'first seen'
    bins[goal,tag]['calls']+=1;bins[goal,tag]['instructions']+=work;sources[goal,tag][h]+=work
    live[h]=int(lit)//2;retired.discard(h)
 elif op=='ROWOP':
    s,level,first=v;live,retired=states.setdefault(s,({},set()))
    for h,i in list(live.items()):
        if i>=int(first):del live[h];retired.add(h)
for (g,k),v in bins.items():print(g,k,v['calls'],round(v['instructions']/1e6,3),len(sources[g,k]))
