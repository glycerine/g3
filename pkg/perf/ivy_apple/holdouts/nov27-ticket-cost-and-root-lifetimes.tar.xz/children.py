from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
ns={'__file__':__file__}
exec(Path(__file__).with_name('operands.py').read_text().rsplit("panel(['probe'],patch,run)",1)[0],ns)
def patch(pkg,name):
    for p,s in ns['patch'](pkg,name):
        if p.name=='smt_internalizer.go':
            a='if sampled{counter=StudyStart()}';assert s.count(a)==1
            s=s.replace(a,'''if sampled{
                effective:=argument;_,ch,_:=s.manager.IsNot(argument);if !ch.IsNull(){effective=ch}
                hd,e:=s.manager.NodeHeader(effective);if e!=nil{panic(e)}
                ready:=0
                for j:=uint32(0);j<hd.NumArgs;j++{arg,e:=s.manager.GetArg(effective,j);if e!=nil{panic(e)};if _,yes:=s.boundInstanceLiteral(arg);yes{ready++}}
                println("ROWMETA",hd.Kind,hd.Family,hd.DeclKind,hd.NumArgs,ready,argument!=effective)
                counter=StudyStart()
            }''')
        yield p,s
def run(s):return ns['run'](s).replace("b'ROWARG ')","b'ROWARG ',b'ROWMETA ')")
panel(['probe'],patch,run)
