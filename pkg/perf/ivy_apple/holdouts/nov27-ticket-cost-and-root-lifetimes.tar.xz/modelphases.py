from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
space={'__file__':__file__}
exec(Path(__file__).with_name('registry.py').read_text().rsplit("panel(['probe'],patch,run)",1)[0],space)
def patch(pkg,name):
    yield from space['patch'](pkg,name)
    p=pkg/'smtcore/smt_model_finder.go';s=p.read_text()
    for anchor,start,end in [('if f.auf[quantifier], err = f.analyzeQInfos(quantifier);','infos','bodyKind, err :='),('if err = f.macroUtil.CollectQuantifierCandidates(flat, candidates);','macros','\n\t}\n\tngEntries :='),('ngEntries :=','hints','f.hint.infos[quantifier] = info')]:
        i=s.index(anchor,s.index('func (f *SMTModelFinder) RegisterQuantifier('));j=s.index(end,i)
        group=s[i:j]
        s=s[:i]+'var count'+start+' StudySample;if StudyGoal{count'+start+'=StudyStart()};'+group+';if StudyGoal{println("ROWGEN",f,"'+start+'",quantifier.Slot(),quantifier.Generation(),count'+start+'.finish())};'+s[j:]
    yield p,s
panel(['probe'],patch,space['run'])
