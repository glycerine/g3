from pathlib import Path
import csv,collections
root=Path(__file__).resolve().parent
labels=[
 ('matcher', '(*smtMAMInterpreter).execute', 'smt::interpreter::execute_core'),
 ('candidate', '(*SMTChecker).run', 'smt::checker::is_sat'),
 ('substitution','(*SMTCachedVarSubstitution).','cached_var_subst::operator()'),
 ('solver rewrite','(*rewriterEngine).rewrite','rewriter_tpl<th_rewriter_cfg>::'),
 ('cost model','(*SMTQICostModel).','smt::qi_queue::set_values'),
 ('literal internalization','(*SMTInternalizerState).internalize','smt::context::internalize'),
 ('conflict resolution','(*SMTKernel).resolveSearchConflict','smt::context::resolve_conflict'),
 ('equality merge','(*SMTInternalizerState).merge','smt::context::merge'),
 ('relevance propagation','(*SMTRelevancyPropagator).','smt::relevancy_propagator_imp::')]
cost=collections.Counter()
for r in csv.DictReader((root/'stacks.csv').open()):
    k=0 if r['engine']=='g3' else 1
    for label,*patterns in labels:
        if patterns[k] in r['stack']:cost[label,r['engine']]+=int(r['samples'])*int(r['period'])/3e6
for label,*_ in labels:print(label,*[round(cost[label,e],1) for e in ['g3','z3']])
