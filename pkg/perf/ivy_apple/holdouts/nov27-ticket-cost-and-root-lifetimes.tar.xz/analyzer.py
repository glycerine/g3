from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_model_finder_auf_graph.go';s=p.read_text().replace('map[smtModelFinderAnalysisKey]uint8','map[ast.ASTHandle]uint8')
    a=s.index('for key := range g.analysisSeen');b=s.index('g.ftodo, g.ttodo',a)
    yield p,s[:a]+'clear(g.analysisSeen)\n\t'+s[b:]
    p=pkg/'smtcore/smt_model_finder_auf_analyzer.go';s=p.read_text()
    a=s.index('type smtModelFinderAnalysisKey');b=s.index('func smtModelFinderNormalizeLiteral',a)
    s=s[:a]+s[b:];s=s.replace('key := smtModelFinderAnalysisKey{quantifier, n}','flags := g.analysisSeen[n]').replace('g.analysisSeen[key]&','flags&').replace('g.analysisSeen[key] |=','g.analysisSeen[n] = flags |')
    s=s.replace('collector := newSMTModelFinderAUFGraph(f)','collector := smtModelFinderAUFGraph{finder:f, analysisSeen:make(map[ast.ASTHandle]uint8)}')
    yield p,s
def run(s):return s.replace('((1,3),(4,8),(6,227))','((4,3),(8,5),(6,2))')
panel(['base','trial'],patch,run)
