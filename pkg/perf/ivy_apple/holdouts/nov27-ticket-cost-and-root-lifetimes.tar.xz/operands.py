from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:
    exec(t.extractfile('driver.py').read())
    lib=t.extractfile('observe.py').read().decode().replace('from driver import panel','').split("if __name__==")[0];exec(lib);observe=patch
def patch(pkg,name):
    ns={'__file__':__file__};exec(Path(__file__).with_name('survivors.py').read_text().rsplit("panel(['probe'],patch,run)",1)[0],ns)
    for p,s in ns['patch'](pkg,name):
        if p.name=='smt_internalizer.go':
            a=s.index('if err = s.Internalize(argument, true);',s.index('func (s *SMTInternalizerState) assertExpression('));b=s.index('old:=len(s.auxClauses)',a)
            t=s[a:b];anchor='literals[index], err = s.Literal(argument)'
            t=t.replace('if err = s.Internalize','var counter StudySample;sampled:=StudyGoal && studyInstance==s;if sampled{counter=StudyStart()};if err = s.Internalize').replace(anchor,anchor+';if sampled{work:=counter.finish();println("ROWARG",s,argument.Origin(),argument.Slot(),argument.Generation(),literals[index].Index(),work)}')
            s=s[:a]+t+s[b:]
            src=next(observe(pkg,'probe'))[1];src=src[src.index('type StudySample struct'):]
            a=src.index('func(r StudySample)End');src=src[:a]+'''func(r StudySample)finish()uint64{end:=r.read(); syscall.Close(int(r.fd));runtime.UnlockOSThread();if end-r.b<r.b-r.a{return 0};return end-r.b-(r.b-r.a)}'''
            s=s.replace('import (','import ("runtime";"syscall";"unsafe";"os";',1)+src
        yield p,s
def run(s):
    ns={'__file__':__file__};exec(Path(__file__).with_name('survivors.py').read_text().rsplit("panel(['probe'],patch,run)",1)[0],ns)
    return ns['run'](s).replace("b'ROWGOAL ')", "b'ROWGOAL ', b'ROWARG ')")
panel(['probe'],patch,run)
