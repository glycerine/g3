from pathlib import Path
import csv,statistics
d=Path(__file__).resolve().parent
for c,keys in [(8,[(12,8),(12,16),(13,8),(14,8)]),(4,[(6,4),(6,5),(6,6)])]:
    out=[]
    for mode in ('base','trial'):
        trials=[]
        for f in sorted((d/'checks').glob(f'{c}-{mode}-*.csv')):
            v={(int(r['batch']),int(r['goal'])):int(r['value']) for r in csv.DictReader(f.open()) if r['reason']=='decide'}
            trials.append([v[k] for k in keys])
        out.append([statistics.median(v) for v in zip(*trials)])
    print(c,[(k,round(a/1e6,2),round(b/1e6,2)) for k,a,b in zip(keys,*out)],round(100*(sum(out[1])/sum(out[0])-1),2))
