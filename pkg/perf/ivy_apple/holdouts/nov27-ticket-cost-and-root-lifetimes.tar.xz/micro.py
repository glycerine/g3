from pathlib import Path
import json,subprocess as sp,os,tempfile,csv
d=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as x:
    tmp=Path(x)
    for mode in ['base','trial']:
        overlay=tmp/'overlay.json'
        overlay.write_text(json.dumps({'Replace':{str(Path('smtcore/smt_qi_cost.go').resolve()):str(d/'cost.go.txt')} if mode=='trial' else {}}))
        sp.run(['go','test','-c','-overlay',overlay,'-o',tmp/mode,'./smtcore'],check=True)
    with (d/'micro.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['round','engine','ns_per_op','instructions_per_op'])
        for i in range(7):
            for mode in (['base','trial'] if i%2==0 else ['trial','base']):
                stat=tmp/'stat';o=sp.check_output(['taskset','-c',os.environ['CPU'],os.environ['PERF'],'stat','-x,','-o',stat,'-e','instructions:u','--',tmp/mode,'-test.run','^$','-test.bench','^BenchmarkSMTQICostDefaults$','-test.benchtime','1500000x','-test.cpu','1'],text=True)
                line=next(l for l in o.splitlines() if l.startswith('BenchmarkSMTQICostDefaults'))
                w.writerow([i,mode,float(line.split()[2]),int(stat.read_text().split(',')[0].strip().splitlines()[-1])/1500000]);f.flush()
