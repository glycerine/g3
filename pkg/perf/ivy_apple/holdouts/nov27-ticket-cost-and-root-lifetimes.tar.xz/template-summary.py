from collections import defaultdict,Counter
from pathlib import Path
root=Path(__file__).resolve().parent
prior={}; totals=defaultdict(Counter); main=defaultdict(Counter); last={}; inputs=defaultdict(set)
for row in (root/'templates/events').open():
    op,*v=row.split()
    if op=='ROWGOAL':goal=tuple(v);bucket=totals[goal]
    elif op=='ROWBEGIN':key=(goal,*v[:2]);h=tuple(v[2:]);events=[]
    elif op=='ROWOP':events.append(tuple(v))
    elif op=='ROWEND':
        same,work=v;work=int(work);sig=(tuple(events),same,work)
        bucket['instances']+=1;bucket['operations']+=len(events);bucket['steps']+=work
        bucket['identity']+=same=='true'
        if key in last:
            bucket['previous quantifier']+=1
            if last[key][1]==sig:bucket['same schedule previous']+=1
            if h not in inputs[key]:
                bucket['fresh for quantifier']+=1
                if last[key][1]==sig:
                    bucket['same schedule on fresh']+=1
                    bucket['steps on same fresh']+=work
        last[key]=(h,sig);inputs[key].add(h);main[key][sig]+=1
for goal,v in totals.items():print(goal,dict(v))
agg=sum(totals.values(),Counter());print('all',dict(agg))
print('shapes per quantifier',[(k,len(v),v.total()) for k,v in main.items() if v.total()>70][:20])
