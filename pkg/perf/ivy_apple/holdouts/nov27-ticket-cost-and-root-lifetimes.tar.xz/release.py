import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/release.py').read().decode()
s=s.replace("('smt_internalizer.go','smt_relevancy_asserted_or.go','smt_relevancy.go')","('smt_qi_cost.go',)").replace('bf4a3f032:','e0c97c17d:')
exec(compile(s,'release','exec'))
