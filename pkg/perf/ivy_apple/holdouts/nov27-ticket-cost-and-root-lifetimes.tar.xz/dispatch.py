from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_mam_interpreter.go';s=p.read_text()
    a=s.index('func (it *smtMAMInterpreter) step()')
    v=s[a:]
    v=v.replace('step() bool {','runInstructions() {\nfor {').replace('switch op := pc.op; {','switch op := pc.op; op {')
    for pat,op in [('op <= mamINITN','INIT'),('mamIsBind(op)','BIND'),('op >= mamYIELD1 && op <= mamYIELDN','YIELD'),('op >= mamGETCGR1 && op <= mamGETCGRN','GETCGR')]:
        v=v.replace('case '+pat+':','case '+', '.join('mam'+op+i for i in '123456N')+':')
    v=v.replace('case op == mamCFILTER || op == mamFILTER:', 'case mamCFILTER, mamFILTER:').replace('case op == mam','case mam').replace('return true','continue').replace('return false','return')
    s=s[:a]+v+'}\n';s=s.replace('ok := it.step()','it.runInstructions()').replace('\n\t\tif ok {\n\t\t\tcontinue\n\t\t}', '')
    yield p,s
panel(['base','trial'],patch)
