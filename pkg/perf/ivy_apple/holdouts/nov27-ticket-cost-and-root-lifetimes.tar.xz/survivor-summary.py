import collections
from pathlib import Path
root=Path(__file__).resolve().parent
totals=collections.defaultdict(collections.Counter)
for row in (root/'survivors/events').open():
    op,*args=row.split()
    if op=='ROWGOAL':
        key=tuple(args);stats=totals[key];states={};pending=None
    elif op=='ROWBEGIN':
        assert pending is None
        manager,*args=args;active,surviving=states.setdefault(manager,([],{}));level,*lits=map(int,args);clause=tuple(sorted(lits))
        if clause in surviving:
            stats['repeat with surviving variables']+=1
            stats['repeat from stored root']+=surviving[clause]
        pending=(level,clause)
    elif op=='ROWEND':
        assert pending
        stored=args[0]=='true'
        active.append((*pending,stored));pending=None
        stats['roots']+=1;stats['stored']+=stored
    elif op=='ROWOP':
        manager,*args=args;active,surviving=states.setdefault(manager,([],{}));level,first=map(int,args)
        surviving={c:stored for c,stored in surviving.items() if max(c)//2<first}
        keep=[]
        for lev,c,stored in active:
            if lev<=level:keep.append((lev,c,stored));continue
            stats['popped roots']+=1
            if max(c)//2<first:
                stats['all vars live']+=1
                stats['stored and all vars live']+=stored
                surviving[c]=surviving.get(c,False) or stored
        states[manager]=(keep,surviving)
for k,v in totals.items():print(k,dict(v))
