from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    if name=='base':return
    p=next(p for p in (pkg/'smtcore').glob('*.go') if 'type smtCandidateNode struct {' in p.read_text())
    s=p.read_text().replace('op         smtCandidateOp','shared     bool // two immutable argument edges in the prepared body\n\top         smtCandidateOp').replace('if id, found := ids[h]; found {','if id, found := ids[h]; found {\n\t\t\tp.nodes[id].shared = true')
    yield p,s
    p=pkg/'smtcore/smt_checker_candidate.go';s=p.read_text().replace('refs, err := c.context.manager.GetRefCount(n.expression)','if n.shared { return &c.candidateMemo[n.memo-1],nil };refs, err := c.context.manager.GetRefCount(n.expression)')
    a=s.index('if n.op == candidateVariable {');b=s.index('if page :=',a);snippet=s[a:b]
    s=s[:a]+s[b:];a=s.index('var slot *smtCandidateMemo',s.index('func (c *SMTChecker) candidateEnode('));s=s[:a]+snippet+s[a:]
    yield p,s
panel(['base','trial'],patch)
