from pathlib import Path
import tarfile
def source(archive,key):
    with tarfile.open(Path('perf/ivy_apple/holdouts')/archive) as t:return t.extractfile('study/'+key).read().decode()
s=source('nov27-arm-ticket-check-costs.tar.xz','stacks.py')
a=s.index('    bridge=');b=s.index('    mp={}',a)
s=s[:a]+"""    bridge=src('nov27-unary-demand-and-fresh-symbols.tar.xz','release-sources/regular.go.txt')
    guard=src('nov27-unary-demand-and-fresh-symbols.tar.xz','release-sources/regular-guards.go.txt')
    i=bridge.index(b'overallResult := smt.Unsat',bridge.index(b'func (s *Solver) GetSmallModelWithCond('))
    bridge=bridge[:i]+b'batch:=newStageBatch();'+bridge[i:]
    marker=b'res, err := s.decideZ3With(z3solver, finalCheck)'
    assert bridge.count(marker)==1
    bridge=bridge.replace(marker,b'stopCheck:=startStage(batch,index+1);'+marker+b';stopCheck("check")')
"""+s[b:]
s=s.replace("(here/'profile.go.txt').read_bytes()", "src('nov27-arm-ticket-check-costs.tar.xz','profile.go.txt')").replace('[(4,6,4),(4,6,5),(4,6,6),(8,12,8),(8,16,1),(8,14,8),(8,13,8)]','[(8,12,8),(8,12,16),(8,14,8),(8,13,8)]').replace('1500007+i*200','1500007+i*200')
exec(compile(s,'stack-trial','exec'))
