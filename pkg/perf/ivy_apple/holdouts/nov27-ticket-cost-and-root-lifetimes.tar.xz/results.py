import csv,statistics
from pathlib import Path
d=Path(__file__).resolve().parent
for group in ['panel','candidate','dispatch']:
 for f in sorted((d/group).glob('*.csv')):
    r=list(csv.DictReader(f.open()));comp={m:[int(x['instructions']) for x in r if x['engine']==m] for m in ('base','trial')}
    if all(comp.values()):print(group,f.stem,len(r),round(100*(statistics.median(comp['trial'])/statistics.median(comp['base'])-1),2))
