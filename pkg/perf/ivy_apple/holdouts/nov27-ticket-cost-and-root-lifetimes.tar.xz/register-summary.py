from collections import Counter,defaultdict
from pathlib import Path
d=Path(__file__).resolve().parent
v=defaultdict(Counter)
for row in (d/'registry/events').open():
    op,*a=row.split()
    if op=='ROWGOAL':memo={}
    elif op=='ROWGEN':
        manager,phase,slot,gen,work=a;key=(manager,phase,slot,gen);amount=int(work)
        v[phase]['calls']+=1;v[phase]['work']+=amount
        if key in memo:v[phase]['again']+=1;v[phase]['repeat_cost']+=amount
        memo[key]=True
for k,a in v.items():print(k,dict(a))
