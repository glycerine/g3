import tarfile
from pathlib import Path
import subprocess as sp
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:
    exec(t.extractfile('driver.py').read())
    lib=t.extractfile('observe.py').read().decode().replace('from driver import panel','').split("if __name__==")[0];exec(lib);observe_patch,census=patch,run
    lib=t.extractfile('paired.py').read().decode();exec(lib[lib.index('def patch'):lib.index("if __name__==")])
def patch(pkg,name):
    if name=='base':yield pkg/'smtcore/smt_qi_cost.go',sp.check_output(['git','show','e0c97c17d:pkg/smtcore/smt_qi_cost.go'],text=True)
orig=run
def measured(s):return orig(s).replace("['base','native']","['base','trial']").replace('for case in [4,8,3,6]:','for case in [4,8]:').replace('for i in range(2):','for i in range(4):')
panel(['base','trial'],patch,measured)
