import csv, statistics as st
from pathlib import Path
p=Path(__file__).resolve().parent
for group in ['release','confirm','stat','analyzer','burst']:
    for f in sorted((p/group).glob('time-*.csv')):
        rows=list(csv.DictReader(f.open()))
        if not rows:continue
        modes=sorted({r['engine'] for r in rows})
        def values(m):return [int(r['instructions']) for r in rows if r['engine']==m]
        a=values('base')
        print(group,f.stem,len(rows),[(m,round(100*(st.median(values(m))/st.median(a)-1),2)) for m in modes if m!='base'])
