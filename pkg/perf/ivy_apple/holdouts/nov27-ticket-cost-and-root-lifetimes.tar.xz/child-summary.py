from collections import defaultdict,Counter
from pathlib import Path
p=Path(__file__).resolve().parent
bins=defaultdict(Counter)
for line in (p/'children/events').open():
 op,*v=line.split()
 if op=='ROWGOAL':states={}
 elif op=='ROWMETA':meta=tuple(v)
 elif op=='ROWARG':
    s,*a=v;h=tuple(a[:3]);lit,work=map(int,a[3:]);live,dead=states.setdefault(s,({},set()))
    if h in dead:
        bins[meta]['count']+=1;bins[meta]['work']+=work
    live[h]=lit//2;dead.discard(h)
 elif op=='ROWOP':
    s,level,first=v;live,dead=states.setdefault(s,({},set()))
    for h,i in list(live.items()):
        if i>=int(first):del live[h];dead.add(h)
for k,v in sorted(bins.items(),key=lambda p:-p[1]['work'])[:24]:print(*k,v['count'],round(v['work']/1e6,3))
