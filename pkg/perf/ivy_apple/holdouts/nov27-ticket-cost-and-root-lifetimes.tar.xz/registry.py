from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
ns={'__file__':__file__};exec(Path(__file__).with_name('operands.py').read_text().rsplit("panel(['probe'],patch,run)",1)[0],ns)
def patch(pkg,name):
    for p,s in ns['patch'](pkg,name):
        if p.name=='smt_internalizer.go':
            a=s.index('type StudySample struct');extra=s[a:]
            s=p.read_text().replace('import (','import ("runtime";"syscall";"unsafe";"os";',1)+'\nvar StudyGoal bool\n'+extra
            a='if err = qm.modelFinder.RegisterQuantifier(expression); err != nil {'
            s=s.replace(a,'var sample StudySample;if StudyGoal{sample=StudyStart()};err=qm.modelFinder.RegisterQuantifier(expression);if StudyGoal{println("ROWGEN",s,"model",expression.Slot(),expression.Generation(),sample.finish())};if err!=nil {')
            yield p,s
    p=pkg/'smtcore/smt_quantifier_registry.go';s=p.read_text();a='stat, err := r.generator.Generate(quantifier, generation)';assert s.count(a)==1
    yield p,s.replace(a,'var counter StudySample;if StudyGoal{counter=StudyStart()};'+a+';if StudyGoal{work:=counter.finish();body,_:=r.manager.GetQuantifierBody(quantifier);println("ROWGEN",r,"stat",body.Slot(),body.Generation(),work)}')
def run(s):return ns['run'](s).replace("b'ROWARG ')","b'ROWARG ',b'ROWGEN ')")
panel(['probe'],patch,run)
