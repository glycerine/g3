import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/release.py').read().decode()
s=s[:s.index(' with ThreadPoolExecutor(4)')].replace("('base','trial','apple')","('base','trial')").replace("('smt_internalizer.go','smt_relevancy_asserted_or.go','smt_relevancy.go')","('smt_qi_cost.go',)").replace('bf4a3f032:','e0c97c17d:').replace('range(5):','range(16):').replace('((1,3),(4,8),(6,227))','((4,),(8,),(6,))')
exec(compile(s,'confirm','exec'))
