import tarfile
from pathlib import Path
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    p=pkg/'ast/rewriter/rewriter_engine.go';s=p.read_text()
    needle='st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)'
    assert s.count(needle)==1
    s=s.replace(needle,needle+'''
        if StudyInstance {kind,_:=m.GetDeclKind(d);family,_:=m.GetFamilyID(d);println("ROWOP",family,kind,n,fr.newChild(),st)}''')+'\nvar StudyGoal,StudyInstance bool\n'
    yield p,s
    p=pkg/'smtcore/smt_qi_instance.go';s=p.read_text().replace('if err = rw.Rewrite(instance, simplified);','''if rewriter.StudyGoal {rewriter.StudyInstance=true;println("ROWBEGIN", prepared.quantifier.Slot(),prepared.quantifier.Generation(),instance.Slot(),instance.Generation())}
        if err = rw.Rewrite(instance, simplified);''')
    a='var arguments *[]ast.ASTHandle'
    assert s.count(a)==1
    yield p,s.replace(a,'''if rewriter.StudyInstance{rewriter.StudyInstance=false;steps,_:=rw.NumSteps();println("ROWEND",instance==rewritten,steps)}
        '''+a)
def run(s):
    needle='    for p,src in patch'
    a=s.index(needle)
    s=s[:a]+"""    p=front/'z3bridge_solver_model.go';file=Path(mp[str(p)]);v=file.read_text().replace('import (','import (\\nstudy "github.com/glycerine/g3/pkg/ast/rewriter"\\n',1)
    i=v.index('overallResult := smt.Unsat',v.index('func (s *Solver) GetSmallModelWithCond('));v=v[:i]+'templateBatch++;batch:=templateBatch;'+v[i:]
    line='res, err := s.decideZ3With(z3solver, finalCheck)';v=v.replace(line,'study.StudyGoal=(batch==12&&(index==7||index==15))||((batch==13||batch==14)&&index==7);if study.StudyGoal{println("ROWGOAL",batch,index+1)};'+line+';study.StudyGoal=false')
    file.write_text(v+'\\nvar templateBatch int\\n')
"""+s[a:]
    s=s[:s.index(' def measure(')]+' run(8,"probe",cpus[0],False)\n'
    s=s.replace('assert (r.returncode,r.stdout,r.stderr)==',"""events=[];ordinary=[]
        for line in r.stderr.splitlines(keepends=True):
            if line.startswith((b'ROWOP ',b'ROWBEGIN ',b'ROWEND ',b'ROWGOAL ')):events.append(line)
            else:ordinary.append(line)
        with (out/'events').open('wb') as file:file.writelines(events)
        assert (r.returncode,r.stdout,b''.join(ordinary))==""")
    return s.replace("GOGC='100'","GOGC='off'")
panel(['probe'],patch,run)
