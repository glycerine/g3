import csv,collections
from pathlib import Path
root=Path(__file__).resolve().parent
counts=collections.defaultdict(collections.Counter);trials=collections.defaultdict(set)
for x in csv.DictReader((root/'stacks.csv').open()):
    frames=x['stack'].splitlines()
    if not frames:continue
    key=x['engine'];trials[key].add(x['round'])
    counts[key][frames[0]]+=int(x['samples'])*int(x['period'])
for k,v in counts.items():
    print(k,[(n.split('/pkg/')[-1][:100],round(num/len(trials[k])/1e6,1)) for n,num in v.most_common(30)])
