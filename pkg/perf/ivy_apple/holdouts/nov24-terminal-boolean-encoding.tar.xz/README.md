# Terminal ground proof experiments

The g3 module at 96951588e and GoIvy at 832e392ef supplied the baseline. Commands below assume an unpacked archive at $STUDY, Go modules available locally, and a working directory of g3/pkg. The study executables read retired user instructions on Linux using perf_event_open. Use GOMAXPROCS=1 and pin to an available logical CPU for comparisons.

    go build -tags=xtrace_off -o "$STUDY/ground" "$STUDY/position/main.go" "$STUDY/position/project.go"
    go build -tags=xtrace_off -o "$STUDY/from-dag" "$STUDY/dag-sat/main.go"
    go build -tags=xtrace_off -o "$STUDY/smt-dag" "$STUDY/dag-smt/main.go"
    GROUND_DOMAIN=seen GROUND_POLICY=canon-memo "$STUDY/ground" "$STUDY/captures/ticket_protocol-trivial-6-1.smt2" direct 12000 3 2 2 1536
    "$STUDY/from-dag" "$STUDY/dag/ticket_protocol-trivial-6-1" direct 10000
    "$STUDY/smt-dag" dag "$STUDY/dag/ticket_protocol-trivial-6-1"

The first output field is the result of the attempted refutation. A satisfiable weakening is inconclusive for its quantified source. The SMT-DAG control reports -1 for UNSAT and 1 for SAT. All captures have independent solver results in captures.tsv. Original input files contain assertions but omit check-sat. To check them independently, append (check-sat) and feed to g3 -in or this fork's build/z3 -in.

The ground checker arguments after the input give the congruence encoding, SAT step limit, initial terms per sort/position, extra terms per round, number of rounds, and limit per quantifier. The direct encoding adds implications for congruence between applications and Boolean relationships between observed equality atoms. The boolean encoding omits those lemmas. controls.py SEED emits the control input to stdout and its independently constructed verdict to stderr. Seeds 0 through 639 were tested. Directory original/ runs the initial typed-domain algorithm without occurrence-based term selection.

Each CSV gives the unit or phase in its header. process, instructions and per-phase figures are retired user instructions. Columns named cycles count CPU cycles. SAT steps and candidate tuples are separate algorithmic counts. Each original verifier invocation was compared with both output streams and expected exit status in verifiers.tsv. Phase counters include only the calling solver thread. Phase runs and whole-process counters were separate measurements.

The position overlay inserts the candidate implementation in g3 and GoIvy after the ordinary early prover. The phase-counters overlay records the individual operations and the costs within that prototype. The early-counters overlay attributes the existing verifier path on its own. These are three independent patches against the stated commits. To apply an overlay to disposable copies, put g3/ and goivy/ side by side and use patch -p1 from their parent. Build goivy_check from the goivy directory with xtrace_off, using a local replace to the copy of g3/pkg. Use GROUND_POLICY=canon-memo, GROUND_MODE=direct, GROUND_DOMAIN=seen, GROUND_K=3 and GROUND_CAP=4000 for the integrated comparison. In production the ordinary solver retains responsibility for the result if a fast proof is inconclusive.
