package main

import (
	"encoding/binary"
	"fmt"
	"github.com/glycerine/g3/pkg/api"
	"github.com/glycerine/g3/pkg/ast"
	"os"
	"runtime"
	"syscall"
	"unsafe"
)

var fd uintptr
var empty uint64

func counter() uint64 {
	var v [3]uint64
	n, _, e := syscall.RawSyscall(syscall.SYS_READ, fd, uintptr(unsafe.Pointer(&v[0])), unsafe.Sizeof(v))
	if e != 0 || n != unsafe.Sizeof(v) || v[1] != v[2] {
		panic("incomplete counter")
	}
	return v[0]
}
func start() {
	runtime.LockOSThread()
	var a struct {
		Type, Size                                    uint32
		Config, Period, SampleType, ReadFormat, Flags uint64
		Padding                                       [16]byte
	}
	a.Size = uint32(unsafe.Sizeof(a))
	a.Config = 1
	a.ReadFormat = 3
	a.Flags = 1<<5 | 1<<6
	var e syscall.Errno
	fd, _, e = syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN, uintptr(unsafe.Pointer(&a)), 0, ^uintptr(0), ^uintptr(0), 0, 0)
	if e != 0 {
		panic(e)
	}
	x := counter()
	empty = counter() - x
}
func check(e error) {
	if e != nil {
		panic(e)
	}
}
func main() {
	start()
	totals := map[string]uint64{}
	point := counter()
	record := func(key string) {
		n := counter() - point
		if n > empty {
			n -= empty
		}
		totals[key] = n
		point = counter()
	}
	mode := os.Args[1]
	dir := os.Args[2]
	ctx, e := api.NewSMTContext()
	check(e)
	m, e := ctx.Manager()
	check(e)
	s, e := ctx.NewSimpleSolver()
	check(e)
	record("init")
	filename := "full.smt2"
	if mode == "dag" {
		filename = "probes.smt2"
	}
	root, e := ctx.ParseSMT2File(dir+"/"+filename, api.SMT2Bindings{})
	check(e)
	h, e := m.RefGet(root)
	check(e)
	n, e := m.GetNumArgs(h)
	check(e)
	record("parse")
	var rows, owned []ast.ASTHandle
	if mode == "dag" {
		raw, e := os.ReadFile(dir + "/dag.bin")
		check(e)
		word := func() uint32 { x := binary.LittleEndian.Uint32(raw); raw = raw[4:]; return x }
		symbols, numTerms, numRows := word(), word(), word()
		if symbols != n {
			panic(fmt.Sprintf("probes %d != symbols %d", n, symbols))
		}
		decls := make([]ast.ASTHandle, symbols)
		atoms := make([]ast.ASTHandle, symbols)
		for i := range decls {
			probe, e := m.GetArg(h, uint32(i))
			check(e)
			x, e := m.GetArg(probe, 0)
			check(e)
			atoms[i] = x
			decls[i], e = m.GetDecl(x)
			check(e)
		}
		owned = make([]ast.ASTHandle, 0, numTerms)
		args := make([]ast.ASTHandle, 0, 8)
		record("prepare")
		for i := uint32(0); i < numTerms; i++ {
			d, arity := word(), word()
			x := atoms[d]
			args = args[:0]
			for j := uint32(0); j < arity; j++ {
				args = append(args, owned[word()])
			}
			if arity != 0 {
				x, e = m.MkApp(decls[d], args)
				check(e)
			}
			check(m.IncRef(x))
			owned = append(owned, x)
		}
		rows = make([]ast.ASTHandle, numRows)
		for i := range rows {
			rows[i] = owned[word()]
		}
		if len(raw) != 0 {
			panic("extra bytes")
		}
	} else {
		rows = make([]ast.ASTHandle, n)
		for i := range rows {
			rows[i], e = m.GetArg(h, uint32(i))
			check(e)
		}
	}
	record("build")
	for _, x := range rows {
		check(s.Assert(x))
	}
	record("assert")
	for i := len(owned) - 1; i >= 0; i-- {
		check(m.DecRef(owned[i]))
	}
	check(m.DelRef(&root))
	record("release")
	ans, e := s.Check()
	check(e)
	record("check")
	check(s.Close())
	check(ctx.Close())
	record("teardown")
	fmt.Print(int(ans), " ", len(rows), " ", len(owned))
	for _, k := range []string{"init", "parse", "prepare", "build", "assert", "release", "check", "teardown"} {
		fmt.Print(" ", totals[k])
	}
	fmt.Println()
}
