"""Generate a signed test input, with a known finite model or a quantified contradiction."""
import random
import sys

def make(seed):
 rng=random.Random(seed);num=3;us=[rng.randrange(3)for _ in range(3)];fs=[rng.randrange(3)for _ in range(3)];ps=[rng.randrange(2)for _ in range(3)];rel=[[rng.randrange(2)for _ in range(3)]for _ in range(3)];fresh=0
 def term(names,k):
  if k and rng.randrange(3)==0:
   a=term(names,k-1);return ('f',a)
  return rng.choice(['a','b','c',*names])
 def formula(names,k):
  nonlocal fresh
  if k==0:
   op=rng.choice(('P','R','='));a=term(names,2)
   return (op,a)if op=='P'else(op,a,term(names,2))
  op=rng.choice(('and','or','=>','=','xor','ite','not','forall','exists','forall','exists'))
  if op in ('forall','exists'):
   x='x'+str(fresh);fresh+=1
   return(op,((x,'S'),),formula([*names,x],k-1))
  n=1 if op=='not'else 3 if op=='ite'else 2
  return(op,*(formula(names,k-1)for i in range(n)))
 def ev(x,env):
  if isinstance(x,str):return us['abc'.index(x)]if x in ('a','b','c')else env[x]
  op,*a=x
  if op in ('forall','exists'):
   vals=[ev(a[1],dict(env,**{a[0][0][0]:v}))for v in range(num)];return(all if op=='forall'else any)(vals)
  v=[ev(y,env)for y in a]
  if op=='P':return bool(ps[v[0]])
  if op=='R':return bool(rel[v[0]][v[1]])
  if op=='f':return fs[v[0]]
  if op=='=':return v[0]==v[1]
  if op=='xor':return v[0]!=v[1]
  if op=='not':return not v[0]
  if op=='and':return all(v)
  if op=='or':return any(v)
  if op=='=>':return not v[0] or v[1]
  if op=='ite':return v[1]if v[0]else v[2]
  raise ValueError(op)
 def show(x):return x if isinstance(x,str)else '('+' '.join(show(t)for t in x)+')'
 h='(declare-sort S 0)\n'+''.join('(declare-fun '+s+' () S)\n' for s in 'abc')+'(declare-fun f (S) S)\n(declare-fun P (S) Bool)\n(declare-fun R (S S) Bool)\n'
 rs=[formula([],rng.randrange(2,6))for _ in range(rng.randrange(4,9))]
 rs=[x if ev(x,{})else('not',x)for x in rs];ex='sat'
 if seed%4==0:
  # Add independent universally quantified contradictory instances.
  rs.extend([('forall',(('y','S'),),('P',('f','y'))),('not',('P',('f','a')))]);ex='unsat'
 return h+''.join('(assert '+show(x)+')\n' for x in rs),ex

if __name__=="__main__":
 text, expected = make(int(sys.argv[1]))
 print(text, end="")
 print(expected, file=sys.stderr)
