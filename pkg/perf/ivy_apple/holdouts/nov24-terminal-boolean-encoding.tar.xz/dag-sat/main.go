package main

import (
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"runtime"
	"slices"
	"strconv"
	"syscall"
	"unsafe"

	"github.com/glycerine/g3/pkg/arena"
	"github.com/glycerine/g3/pkg/sat"
	"github.com/glycerine/g3/pkg/util/control"
	"github.com/glycerine/g3/pkg/util/lbool"
	"github.com/glycerine/g3/pkg/util/numeral"
	"github.com/glycerine/g3/pkg/util/params"
	"github.com/glycerine/g3/pkg/util/symbol"
)

type op struct {
	Name           string
	Bool, Declared bool
}
type node struct {
	op   uint32
	args []int32
}
type graph struct {
	ops   []op
	terms []node
	roots []int32
}

func must(e error) {
	if e != nil {
		panic(e)
	}
}
func load(dir string) graph {
	var g graph
	raw, e := os.ReadFile(dir + "/symbols.json")
	must(e)
	must(json.Unmarshal(raw, &g.ops))
	raw, e = os.ReadFile(dir + "/dag.bin")
	must(e)
	get := func() uint32 { v := binary.LittleEndian.Uint32(raw); raw = raw[4:]; return v }
	if int(get()) != len(g.ops) {
		panic("inconsistent symbols")
	}
	g.terms = make([]node, get())
	g.roots = make([]int32, get())
	words := make([]int32, len(raw)/4)
	off := 0
	for i := range g.terms {
		n := &g.terms[i]
		n.op = get()
		a := int(get())
		n.args = words[off : off+a]
		off += a
		for j := range n.args {
			n.args[j] = int32(get())
			if int(n.args[j]) >= i {
				panic("forward reference")
			}
		}
	}
	for i := range g.roots {
		g.roots[i] = int32(get())
	}
	if len(raw) > 0 {
		panic("extra words")
	}
	return g
}

type pair [2]int32

func key(a, b int32) pair {
	if a > b {
		return pair{b, a}
	}
	return pair{a, b}
}
func abs(x int32) int32 {
	if x < 0 {
		return -x
	}
	return x
}

type cnf struct {
	graph
	vars               int32
	lits               []int32
	eq, iff            map[pair]int32
	edges              []pair
	gates              map[string]int32
	rows               [][]int32
	candidates, lemmas int
}

func (c *cnf) fresh() int32 { c.vars++; return c.vars }
func (c *cnf) emit(xs ...int32) {
	out := xs[:0]
	for _, x := range xs {
		if x == 1 {
			return
		}
		if x == -1 {
			continue
		}
		same := false
		for _, y := range out {
			if y == -x {
				return
			}
			if x == y {
				same = true
			}
		}
		if !same {
			out = append(out, x)
		}
	}
	c.rows = append(c.rows, slices.Clone(out))
}
func (c *cnf) disj(xs []int32) int32 {
	slices.Sort(xs)
	xs = slices.Compact(xs)
	out := xs[:0]
	for _, x := range xs {
		if x == 1 {
			return 1
		}
		if x == -1 {
			continue
		}
		out = append(out, x)
	}
	for _, x := range out {
		if x > 0 {
			if _, ok := slices.BinarySearch(out, -x); ok {
				return 1
			}
		}
	}
	if len(out) == 0 {
		return -1
	}
	if len(out) == 1 {
		return out[0]
	}
	raw := make([]byte, len(out)*4)
	for i, x := range out {
		binary.LittleEndian.PutUint32(raw[4*i:], uint32(x))
	}
	k := string(raw)
	if r := c.gates[k]; r != 0 {
		return r
	}
	r := c.fresh()
	c.gates[k] = r
	xs = append(slices.Clone(out), -r)
	c.emit(xs...)
	for _, x := range out {
		c.emit(r, -x)
	}
	return r
}
func (c *cnf) equiv(a, b int32) int32 {
	if a == b {
		return 1
	}
	if a == -b {
		return -1
	}
	if abs(a) == 1 {
		return a * b
	}
	if abs(b) == 1 {
		return a * b
	}
	k := key(a, b)
	if v := c.iff[k]; v != 0 {
		return v
	}
	v := c.fresh()
	c.iff[k] = v
	c.emit(-v, -a, b)
	c.emit(-v, a, -b)
	c.emit(v, a, b)
	c.emit(v, -a, -b)
	return v
}
func (c *cnf) equality(a, b int32) int32 {
	if a == b {
		return 1
	}
	if c.ops[c.terms[a].op].Bool {
		return c.equiv(c.lit(a), c.lit(b))
	}
	k := key(a, b)
	if v := c.eq[k]; v != 0 {
		return v
	}
	v := c.fresh()
	c.eq[k] = v
	c.edges = append(c.edges, k)
	return v
}
func (c *cnf) lit(n int32) int32 {
	if x := c.lits[n]; x != 0 {
		return x
	}
	t := c.terms[n]
	o := c.ops[t.op]
	var x int32
	if !o.Bool {
		panic("untyped Boolean")
	}
	switch o.Name {
	case "true":
		x = 1
	case "false":
		x = -1
	case "not":
		x = -c.lit(t.args[0])
	case "and", "or", "=>":
		xs := make([]int32, len(t.args))
		for i, a := range t.args {
			xs[i] = c.lit(a)
			if o.Name == "and" || o.Name == "=>" && i == 0 {
				xs[i] = -xs[i]
			}
		}
		if o.Name == "=>" && len(xs) != 2 {
			panic("nary implication")
		}
		x = c.disj(xs)
		if o.Name == "and" {
			x = -x
		}
	case "=", "distinct", "xor":
		if len(t.args) != 2 {
			panic("nary equivalence")
		}
		x = c.equality(t.args[0], t.args[1])
		if o.Name != "=" {
			x = -x
		}
	case "ite":
		a, b, d := c.lit(t.args[0]), c.lit(t.args[1]), c.lit(t.args[2])
		x = c.fresh()
		c.emit(-a, -b, x)
		c.emit(-a, b, -x)
		c.emit(a, -d, x)
		c.emit(a, d, -x)
	default:
		x = c.fresh()
	}
	c.lits[n] = x
	return x
}
func (c *cnf) branch(n, sign int32, xs []int32) []int32 {
	t := c.terms[n]
	o := c.ops[t.op]
	if o.Name == "not" {
		return c.branch(t.args[0], -sign, xs)
	}
	if o.Name == "or" && sign == 1 || o.Name == "and" && sign == -1 {
		for _, a := range t.args {
			xs = c.branch(a, sign, xs)
		}
		return xs
	}
	return append(xs, sign*c.lit(n))
}
func (c *cnf) encode() {
	c.vars = 1
	c.lits = make([]int32, len(c.terms))
	c.eq = map[pair]int32{}
	c.iff = map[pair]int32{}
	c.gates = map[string]int32{}
	var buf []int32
	for _, r := range c.roots {
		buf = c.branch(r, 1, buf[:0])
		c.emit(buf...)
	}
	for n, t := range c.terms {
		if o := c.ops[t.op]; o.Name == "ite" && !o.Bool {
			a := c.lit(t.args[0])
			c.emit(-a, c.equality(int32(n), t.args[1]))
			c.emit(a, c.equality(int32(n), t.args[2]))
		}
	}
}
func (c *cnf) congruence(mode string) {
	if mode == "boolean" {
		return
	}
	explicit := make(map[pair]bool, len(c.eq))
	for _, e := range c.edges {
		explicit[e] = true
	}
	groups := make([][]int32, len(c.ops))
	for i, t := range c.terms {
		if o := c.ops[t.op]; o.Declared && len(t.args) > 0 && (o.Bool || mode == "one") {
			groups[t.op] = append(groups[t.op], int32(i))
		}
	}
	for _, group := range groups {
		for i, b := range group {
			bb := c.terms[b]
			for _, a := range group[:i] {
				c.candidates++
				aa := c.terms[a]
				at := -1
				for j, x := range aa.args {
					if x == bb.args[j] {
						continue
					}
					if at != -1 {
						at = -2
						break
					}
					at = j
				}
				if at < 0 {
					continue
				}
				u, v := aa.args[at], bb.args[at]
				if mode != "one" && !c.ops[c.terms[u].op].Bool && !explicit[key(u, v)] {
					continue
				}
				guard := c.equality(u, v)
				if c.ops[bb.op].Bool && mode != "predicate" {
					x, y := c.lit(a), c.lit(b)
					c.emit(-guard, -x, y)
					c.emit(-guard, x, -y)
				} else {
					c.emit(-guard, c.equality(a, b))
				}
				c.lemmas++
			}
		}
	}
	adj := make([][]int32, len(c.terms))
	for _, e := range c.edges {
		adj[e[0]] = append(adj[e[0]], e[1])
	}
	for _, e := range c.edges {
		a, b := e[0], e[1]
		ab := c.eq[e]
		for _, d := range adj[b] {
			if ad := c.eq[key(a, d)]; ad != 0 {
				bd := c.eq[key(b, d)]
				c.emit(-ab, -bd, ad)
				c.emit(-ab, bd, -ad)
				c.emit(ab, -bd, -ad)
				c.lemmas++
			}
		}
	}
}
func (c *cnf) reduce() (int, [][]int32) {
	vals := make([]int8, c.vars+1)
	occ := make([][]int32, 2*(c.vars+1))
	trail := make([]int32, 0, c.vars)
	assign := func(x int32) bool {
		v := abs(x)
		s := int8(1)
		if x < 0 {
			s = -1
		}
		if vals[v] != 0 {
			return vals[v] == s
		}
		vals[v] = s
		trail = append(trail, x)
		return true
	}
	slot := func(x int32) int32 {
		if x < 0 {
			return -2*x + 1
		}
		return 2 * x
	}
	for i, row := range c.rows {
		if len(row) == 0 || len(row) == 1 && !assign(row[0]) {
			return len(trail), [][]int32{nil}
		}
		if len(row) > 1 {
			for _, x := range row {
				s := slot(x)
				occ[s] = append(occ[s], int32(i))
			}
		}
	}
	for j := 0; j < len(trail); j++ {
		for _, idx := range occ[slot(-trail[j])] {
			free := 0
			var next int32
			done := false
			for _, x := range c.rows[idx] {
				v := vals[abs(x)]
				if v == 0 {
					free++
					next = x
				} else if (v > 0) == (x > 0) {
					done = true
					break
				}
			}
			if !done && (free == 0 || free == 1 && !assign(next)) {
				return len(trail), [][]int32{nil}
			}
		}
	}
	kept := make([][]int32, 0, len(c.rows))
	for _, row := range c.rows {
		out := row[:0]
		done := false
		for _, x := range row {
			v := vals[abs(x)]
			if v == 0 {
				out = append(out, x)
			} else if (v > 0) == (x > 0) {
				done = true
				break
			}
		}
		if !done {
			kept = append(kept, out)
		}
	}
	return len(trail), kept
}

var fd uintptr
var empty uint64

func counter() uint64 {
	var v [3]uint64
	n, _, e := syscall.RawSyscall(syscall.SYS_READ, fd, uintptr(unsafe.Pointer(&v[0])), unsafe.Sizeof(v))
	if e != 0 || n != unsafe.Sizeof(v) || v[1] != v[2] {
		panic("incomplete counter")
	}
	return v[0]
}
func start() {
	runtime.LockOSThread()
	var a struct {
		Type, Size                                    uint32
		Config, Period, SampleType, ReadFormat, Flags uint64
		Padding                                       [16]byte
	}
	a.Size = uint32(unsafe.Sizeof(a))
	a.Config = 1
	a.ReadFormat = 3
	a.Flags = 1<<5 | 1<<6
	var e syscall.Errno
	fd, _, e = syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN, uintptr(unsafe.Pointer(&a)), 0, ^uintptr(0), ^uintptr(0), 0, 0)
	if e != 0 {
		panic(e)
	}
	x := counter()
	empty = counter() - x
}
func main() {
	start()
	stages := []uint64{}
	before := counter()
	stage := func() {
		after := counter()
		n := after - before
		if n > empty {
			n -= empty
		}
		stages = append(stages, n)
		before = counter()
	}
	dir, mode := os.Args[1], os.Args[2]
	bound, e := strconv.ParseUint(os.Args[3], 10, 32)
	must(e)
	c := cnf{graph: load(dir)}
	stage()
	c.encode()
	stage()
	c.congruence(mode)
	stage()
	units, rows := c.reduce()
	stage()
	budget := arena.NewBudget(1 << 31)
	sy, e := symbol.NewManager(symbol.Config{Budget: budget})
	must(e)
	q, e := numeral.NewRationalService(numeral.RationalServiceConfig{Integers: numeral.IntegerConfig{Cells: arena.Config{Budget: budget}, Words: arena.VectorConfig{Descriptors: arena.Config{Budget: budget}}}})
	must(e)
	pc, e := params.NewParamsContext(sy, q, params.ParamsConfig{Budget: budget})
	must(e)
	catalog, e := params.NewGlobalParamsCatalog(sy, params.GlobalParamsCatalogConfig{Budget: budget})
	must(e)
	gl, e := params.NewGlobalParamsService(sy, pc, params.GlobalParamsConfig{Budget: budget, Catalog: catalog})
	must(e)
	must(gl.InitializeSource())
	p, e := gl.SourceGetModuleName("sat")
	must(e)
	rt, e := sat.NewRuntime(sat.RuntimeConfig{Budget: budget, ParamsContext: pc, Globals: gl})
	must(e)
	limit, e := control.NewReslimit(budget)
	must(e)
	s, e := sat.NewSATSolver(sat.SolverConfig{ParamsContext: pc, Params: p, RLimit: limit, Budget: budget, Runtime: rt})
	must(e)
	used := make([]bool, c.vars+1)
	for _, row := range rows {
		for _, x := range row {
			used[abs(x)] = true
		}
	}
	vars := make([]sat.BoolVar, len(used))
	for i, ok := range used {
		if ok {
			vars[i], e = s.MkVar(false, true)
			must(e)
		}
	}
	var scratch []sat.Literal
	for _, row := range rows {
		scratch = scratch[:0]
		for _, x := range row {
			scratch = append(scratch, sat.MakeLiteral(vars[abs(x)], x < 0))
		}
		must(s.MkClause(scratch))
	}
	stage()
	must(limit.Push(uint32(bound)))
	res, e := s.Check(nil)
	if errors.Is(e, sat.ErrSATSolverCanceled) && !limit.IncOffset(0) {
		res = lbool.Undef
	} else {
		must(e)
	}
	steps := limit.Count()
	limit.Pop()
	stage()
	must(s.Close())
	limit.Close()
	must(rt.Close())
	must(pc.Del(&p))
	must(gl.Close())
	must(catalog.Close())
	must(pc.Close())
	must(q.Close())
	must(sy.Close())
	stage()
	result := "unknown"
	if res == lbool.False {
		result = "unsat"
	} else if res == lbool.True {
		result = "sat"
	}
	fmt.Print(result, " ", len(c.terms), " ", len(c.roots), " ", c.candidates, " ", c.lemmas, " ", c.vars, " ", len(c.rows), " ", units, " ", len(rows), " ", steps)
	for _, x := range stages {
		fmt.Print(" ", x)
	}
	fmt.Println()
}
