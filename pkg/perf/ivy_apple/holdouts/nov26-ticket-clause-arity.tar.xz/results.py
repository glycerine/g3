import sys,csv,re,subprocess
from pathlib import Path
from collections import Counter
binary=Path(sys.argv[2]).resolve()
out = csv.writer(sys.stdout)
out.writerow(('query','kind','arity','outcome','count'))
for q,expected in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
    run = subprocess.run([binary, '-in', '-smt2'], input=(Path(sys.argv[1])/(q+'.smt2')).read_bytes(),capture_output=True,check=True)
    stats = dict(re.findall(rb':([\w-]+)\s+(\d+)\b',run.stdout))
    assert run.stdout.startswith(b'unsat\n') and tuple(int(stats[k]) for k in [b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count']) == expected
    counts = Counter()
    for row in run.stderr.decode().splitlines():
        tag, kind, arity, *outcome = row.split()
        if tag in ('compact','full'):
            counts[kind,arity,tag+'-'+outcome[0]] += 1
            continue
        assert tag in ('kept','attempt')
        counts[kind,arity,'discarded'] += 1 if tag=='attempt' else -1
        if outcome:
            counts[kind,arity,outcome[0]] += 1
    for key,n in sorted(counts.items()):
        assert n >= 0
        if n: out.writerow((q,*key,n))
