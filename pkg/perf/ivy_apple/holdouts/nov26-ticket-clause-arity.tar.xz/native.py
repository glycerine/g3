"""Count clause arities, simplification and storage during native instance assertion."""
from pathlib import Path
import re,shlex,subprocess
pkg=Path.cwd()
root=pkg.parent
build=root/'build'
out=Path(__file__).resolve().parent
flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
make=(build/'Makefile').read_text()
includes=shlex.split(re.search(r'^includes_39 = (.*)$',make,re.M)[1])
header=out/'observer.hpp'
header.write_text("#pragma once\n#include <cstdio>\nextern bool counting;\n")
def once(code,old,new):
    assert code.count(old)==1,(old,code.count(old))
    return code.replace(old,new)
objs=[]
for filename in ['qi_queue','smt_internalizer']:
    src=root/('src/smt/'+filename+'.cpp')
    s=src.read_text()
    if filename=='qi_queue':
        s+='\nbool counting;\n'
        k='m_context.internalize_instance(lemma, pr1, gen);'
        s=once(s,k,'::counting=true; '+k+' ::counting=false;')
    else:
        start=s.index('clause * context::mk_clause(unsigned')
        end=s.index('m_stats.m_num_mk_clause++;', start)
        body=s[start:end]
        k='switch (k) {'
        body=once(body,k,'unsigned arity=num_lits; if (::counting) std::fprintf(stderr,"attempt %u %u\\n",unsigned(k),arity); '+k)
        for tag,anchor in [('kept','m_stats.m_num_mk_lits += num_lits;'), ('compact','m_stats.m_num_mk_bin_clause++;')]:
            body=once(body,anchor,'if (::counting) std::fprintf(stderr,"'+tag+' %u %u %u\\n", unsigned(k),arity,num_lits); '+anchor)
        s=s[:start]+body+'if (::counting) std::fprintf(stderr,"full %u %u %u\\n",unsigned(k),arity,num_lits); '+s[end:]
    dst=out/src.name
    dst.write_text(s)
    obj=out/(filename+'.o')
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-include',header,'-o',obj,dst],cwd=build,check=True)
    objs.append(obj)
link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',make,re.M)[1]
libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
subprocess.run([flags['LINK'],'-o',out/'z3',*objs,*libs,*shlex.split(flags['LINK_EXTRA_FLAGS'])],cwd=build,check=True)
