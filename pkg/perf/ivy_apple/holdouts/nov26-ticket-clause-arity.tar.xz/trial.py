"""Test a direct simplification path for two distinct unassigned auxiliary literals."""
import json
import subprocess
from pathlib import Path

work = Path(__file__).resolve().parent
src = Path.cwd()/'smtcore/smt_internalizer.go'
code = src.read_text()
a = code.index('if ordered {', code.index('func (s *SMTInternalizerState) addClauseKindWithJustificationAndDeleteHandler('))
b = code.index('// A proof or assignment callback',a)
part = code[a:b]
m = part.index('kept := s.clauseKeptScratch[:0]')
n = part.index('for _, literal := range literals', m)
code = code[:a] + part[m:n] + '''
    if kind == SMTClauseAux && len(literals)==2 && literals[0]>SMTFalseLiteral && literals[1]>SMTFalseLiteral &&
        literals[0].Var()!=literals[1].Var() && uint(literals[0])<uint(len(s.assignment)) && uint(literals[1])<uint(len(s.assignment)) &&
        s.assignment[literals[0]]==lbool.Undef && s.assignment[literals[1]]==lbool.Undef {
        if err:=s.open(); err!=nil {return err}
        a,b:=literals[0],literals[1]
        if a>b {a,b=b,a}
        kept=append(kept,a,b)
    } else {
''' + part[:m]+part[n:]+'}\n'+code[b:]
target=work/'trial.go'
target.write_bytes(subprocess.check_output(['gofmt'],input=code.encode()))
overlay=work/'trial.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(target)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'trial','./cmd/g3'],check=True)
