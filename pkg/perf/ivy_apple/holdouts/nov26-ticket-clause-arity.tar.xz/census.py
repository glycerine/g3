"""Count attempted and simplified clause lengths during Ticket instance assertion."""
import csv
import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path

work = Path(__file__).resolve().parent
sources = {}
for name in ('smt_qi_instance.go', 'smt_internalizer.go'):
    source = Path.cwd() / 'smtcore' / name
    code = source.read_text()
    if name == 'smt_qi_instance.go':
        anchor = 'if err = internalizer.internalizeInstance(result, locals.arguments); err != nil {'
        replacement = '''qaCountArity = true
        err = internalizer.internalizeInstance(result, locals.arguments)
        qaCountArity = false
        if err != nil {'''
        code += '\nvar qaCountArity bool\n'
    else:
        anchor = 'ordered := kind == SMTClauseAux || kind == SMTClauseAuxLemma'
        replacement = '''if qaCountArity { println("attempt", int(kind), len(literals)) }
        ''' + anchor
        marker = 's.statistics.NumMkLits += uint32(len(kept))'
        assert code.count(marker) == 1
        code = code.replace(marker, 'if qaCountArity { println("kept", int(kind), len(literals), len(kept)) }\n' + marker)
        for marker, tag in [('s.binaryClauses.add(first, second, root, lemma, proof)', 'compact'), ('clause.registerDirectory(root, proof, owner)', 'full')]:
            assert code.count(marker) == 1
            code = code.replace(marker, 'if qaCountArity { println("'+tag+'", int(kind), len(literals), len(kept)) }\n' + marker)
    assert code.count(anchor) == 1
    target = work / name
    target.write_text(code.replace(anchor, replacement))
    sources[str(source)] = str(target)
overlay = work / 'overlay.json'
overlay.write_text(json.dumps({'Replace': sources}))
binary = work / 'g3'
subprocess.run(['go', 'build', '-pgo=off', '-mod=readonly', '-buildvcs=false', '-overlay', overlay, '-o', binary, './cmd/g3'], check=True)
