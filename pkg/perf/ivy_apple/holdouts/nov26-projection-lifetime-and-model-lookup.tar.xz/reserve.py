"""Estimate grounding capacity from the already parsed, bounded input DAG."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
src=Path.cwd()/'api/internal/order/quantified_goal.go'
s=src.read_text()
k='g.global = make([]uint32, len(g.input))'
assert s.count(k)==1
s=s.replace(k,'''if len(g.input) >= 16 {
        g.terms = make([]groundApplication, 1, len(g.input))
        g.applications = make(map[uint64]uint32, len(g.input))
        g.arguments = make([]uint32, 0, min(len(g.children), 2*len(g.input)))
    }
    '''+k)
dst=w/'reserve.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'reserve.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'reserve-goivy','./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
