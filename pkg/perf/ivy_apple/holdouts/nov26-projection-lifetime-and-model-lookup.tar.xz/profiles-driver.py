"""Partition retired instruction samples in matched Ticket check call stacks."""
import argparse
from collections import Counter
import csv
import os
import re
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--cpu', required=True)
p.add_argument('--perf', default='perf')
p.add_argument('--out', required=True, type=Path)
p.add_argument('--fixtures', required=True, type=Path)
p.add_argument('--reuse', action='store_true')
p.add_argument('--rounds', type=int, default=6)
p.add_argument('go')
p.add_argument('z3')
a = p.parse_args()
a.out.mkdir(exist_ok=a.reuse)
configs = {
    'g3': (a.go, 'fp,48', '(*Context).CheckSatDisplay', '(*SMTQuantifierManager).instantiate', {
        'promotion': ('(*SMTQuantifierManager).promoteUnsatEntry',),
        'checker': ('(*SMTChecker).run', '(*SMTChecker).checkCandidate', '(*SMTChecker).checkCore'),
        'substitution': ('(*SMTCachedVarSubstitution).Instantiate',),
        'theory rewrite': ('(*TheoryRewriter).Rewrite', '(*rewriterEngine).Rewrite'),
        'lemma assembly': ('(*SMTQIInstanceBuilder).finish',),
        'relevance registration': ('addAssertedOrWatches',),
        'clause insertion': ('addRootClause',),
        'other assertion': ('(*SMTInternalizerState).assertExpression',),
        'queue ownership': ('RecordInstance',),
    }),
    'z3': (a.z3, 'dwarf,8192', 'cmd_context::check_sat(', 'smt::qi_queue::instantiate(smt::qi_queue::entry&)', {
        'promotion': ('smt::checker::is_unsat',),
        'checker': ('smt::checker::is_sat',),
        'substitution': ('cached_var_subst::operator()',),
        'theory rewrite': ('th_rewriter::operator()', 'rewriter_tpl<th_rewriter_cfg>', 'th_rewriter_cfg::reduce_app'),
        'relevance registration': ('add_or_rel_watches',),
        'clause insertion': ('mk_root_clause', 'smt::context::mk_clause(', 'smt::context::simplify_aux_clause_literals'),
        'other assertion': ('smt::context::internalize_assertion',),
    }),
}
period = 1000003
writer = csv.writer(sys.stdout, lineterminator='\n')
writer.writerow(('query', 'round', 'engine', 'check', 'queue', 'phase', 'samples', 'period'))
for query in ('ticket-127', 'ticket-290'):
    source = (a.fixtures / f'{query}.smt2').read_bytes()
    reference = None
    for i in range(a.rounds):
        for label in (('g3', 'z3') if i % 2 == 0 else ('z3', 'g3')):
            binary, stack, check, queue, phases = configs[label]
            raw = a.out / f'{query}-{i+1}-{label}.data'
            if not a.reuse:
                run = subprocess.run(['taskset', '-c', a.cpu, a.perf, 'record', '-B', '-N', '-e', 'instructions:u', '-c', str(period), '--call-graph', stack, '-o', raw, '--', binary, '-in', '-smt2'],
                                     env=dict(os.environ, GOMAXPROCS='1'), input=source, capture_output=True, timeout=120, check=True)
                if not run.stdout.startswith(b'unsat\n') or b'(error' in run.stdout:
                    raise ValueError((raw, run.stdout))
                raw.with_suffix('.stdout').write_bytes(run.stdout)
                raw.with_suffix('.record').write_bytes(run.stderr)
            result = raw.with_suffix('.stdout').read_text()
            stats = dict(re.findall(r':([\w-]+)\s+(\d+)\b', result))
            observed = tuple(stats.get(key, '0') for key in ('decisions', 'conflicts', 'quant-instantiations', 'rlimit-count'))
            if reference is None:
                reference = observed
            if observed != reference or not result.startswith('unsat\n') or '(error' in result:
                raise ValueError((raw, observed, reference))
            with subprocess.Popen([a.perf, 'report', '-D', '-i', raw], stdout=subprocess.PIPE, text=True) as report:
                bad = sum('PERF_RECORD_LOST' in row or 'PERF_RECORD_THROTTLE' in row for row in report.stdout)
            if bad or report.returncode:
                raise ValueError((raw, bad, report.returncode))
            text = subprocess.check_output([a.perf, 'script', '-i', raw], text=True)
            counts = Counter()
            for sample in text.split('\n\n'):
                if len(sample.splitlines()) < 2:
                    continue
                has_check = check in sample
                has_queue = queue in sample
                phase = 'outside check' if not has_check else 'other check'
                if has_check and has_queue:
                    phase = 'other queue work'
                    for name, callers in phases.items():
                        if any(caller in sample for caller in callers):
                            phase = name
                            break
                elif has_check and phases['promotion'][0] in sample:
                    phase = 'promotion'
                counts[int(has_check), int(has_queue), phase] += 1
            for (has_check, has_queue, phase), count in sorted(counts.items()):
                writer.writerow((query, i+1, label, has_check, has_queue, phase, count, period))
            sys.stdout.flush()
