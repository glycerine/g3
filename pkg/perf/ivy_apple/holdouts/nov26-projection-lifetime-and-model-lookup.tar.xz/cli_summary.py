"""Sum all measured phases and report paired whole-process instruction changes."""
import csv,collections,statistics,sys
for filename in sys.argv[1:]:
    d=collections.defaultdict(collections.Counter)
    for r in csv.DictReader(open(filename)):d[r['query'],r['round']][r['engine']]+=int(r['instructions'])
    for q in sorted({q for q,i in d}):
        for mode in sorted(set.union(*(set(row) for row in d.values()))-{'base'}):
            changes=[100*(v[mode]/v['base']-1) for (k,i),v in d.items() if k==q and mode in v and 'base' in v]
            if changes:print(filename.split('/')[-1],q,mode,len(changes),round(statistics.median(changes),3))
