"""Record pinned complete verifier runs and require the saved reference streams."""
import json
import os
from pathlib import Path
import subprocess
import sys

perf, fixtures, examples, go, native, out = sys.argv[1:]
gold = Path(fixtures)
cases = json.loads((gold / 'cases.json').read_text())
out = Path(out).resolve()
out.mkdir(exist_ok=True)
for case in ('ticket_protocol', 'hybrid'):
    path, isolate, code = cases[case]
    ref = gold / 'reference' / case
    engines = [('g3', go, 'fp,64'), ('z3', native, 'dwarf,8192')]
    for i in range(6):
        for tag, exe, stack in engines[::1 if i%2 == 0 else -1]:
            data = out / f'{case}-{i+1}-{tag}.data'
            cmd = ['taskset','-c','11',perf,'record','-B','-N','-e','instructions:u','-c','1000003','--call-graph',stack,'-o',data,'--',Path(exe).resolve()]
            if isolate:
                cmd.append('isolate='+isolate)
            cmd.append(Path(examples)/path)
            p = subprocess.run(cmd, capture_output=True, cwd=out, env=dict(os.environ,GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1'),timeout=120)
            stderr = b''.join(l for l in p.stderr.splitlines(keepends=True) if not l.startswith(b'[ perf record:'))
            if (p.returncode,p.stdout,stderr)!=(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()):
                raise ValueError((case,tag,p.returncode,stderr[:300],len(p.stdout)))
            stats = subprocess.check_output([perf,'report','--stats','-i',data],text=True)
            assert 'SAMPLE events:' in stats and all(name+' events:' not in stats for name in ('LOST','LOST_SAMPLES','THROTTLE','UNTHROTTLE'))
