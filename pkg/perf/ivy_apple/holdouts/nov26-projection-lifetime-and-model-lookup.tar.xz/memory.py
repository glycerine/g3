"""Compare total Go allocations in complete runs with matched proof transcripts."""
from pathlib import Path
import json,subprocess,os,sys,csv
w=Path(__file__).resolve().parent;root=Path.cwd()
ivy=w/'frontend/goivy';main=ivy/'cmd/goivy_check/main.go'
s=main.read_text().replace('import (','import (\n"runtime"',1)
old='os.Exit(goivy.MainWithConfig(args, cfg))'
assert s.count(old)==1
s=s.replace(old,'''code:=goivy.MainWithConfig(args,cfg); var mem runtime.MemStats; runtime.ReadMemStats(&mem); println("ALLOCATION",mem.TotalAlloc,mem.Mallocs); os.Exit(code)''')
dst=w/'mem-main.go';dst.write_text(s)
names=sys.argv[1:]; gold=root/'build/.bool-scan/golden';examples=Path('/home/jaten/ivy/ivy-lang-examples')
for name in names:
    paths={str(main):str(dst)}
    if name=='base':
        src=root/'api/internal/order/quantified_boolean.go';old=w/'before.go'
        old.write_bytes(subprocess.check_output(['git','show','af7d977bc:pkg/api/internal/order/quantified_boolean.go']))
        paths[str(src)]=str(old)
    elif name not in ('copy','release'):
        paths.update(json.loads((w/(name+'.json')).read_text())['Replace'])
    ov=w/('mem-'+name+'.json');ov.write_text(json.dumps({'Replace':paths}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/('mem-'+name),'./cmd/goivy_check'],cwd=ivy,check=True)
out=csv.writer(sys.stdout);out.writerow(('case','round','engine','allocated_bytes','allocated_objects'))
for case,(path,iso,code) in json.loads((gold/'cases.json').read_text()).items():
    ref=gold/'reference'/case
    for i in range(5):
        for name in names[i%len(names):]+names[:i%len(names)]:
            r=subprocess.run(['taskset','-c','14',w/('mem-'+name),*(['isolate='+iso] if iso else []),examples/path],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
            lines=r.stderr.splitlines(keepends=True); stats=lines.pop().split()
            assert stats[0]==b'ALLOCATION' and (r.returncode,r.stdout,b''.join(lines))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
            out.writerow((case,i+1,name,*map(int,stats[1:])));sys.stdout.flush()
