"""Build release and bounded projection reservation with an identical frontend."""
from pathlib import Path
import subprocess,json,sys
w=Path(__file__).resolve().parent
src=Path.cwd()/'api/internal/order/quantified_goal.go'
for name in sys.argv[1:]:
    args=[]
    if name=='limited':
        s=(w/'reserve.go').read_text().replace('if len(g.input) >= 16 {','if n := min(len(g.input), g.compiler.ceiling-g.compiler.work+1, 2048); !seedGoal && n >= 16 {').replace('1, len(g.input))','1, n)').replace('make(map[uint64]uint32, len(g.input))','make(map[uint64]uint32, n)').replace('2*len(g.input)','2*n')
        dst=w/'limited.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));ov=w/'limited.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}));args=['-overlay',ov]
        subprocess.run(['go','test','-c','-pgo=off','-mod=readonly',*args,'-o',w/'project-limited','./api'],check=True)
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off',*args,'-o',w/(name+'-goivy'),'./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
