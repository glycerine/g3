"""Check the reference value, remaining work and incomplete flag for every root evaluation."""
from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;root=Path.cwd()
src=root/'smtcore/smt_model_table_check.go';orig=src.read_text()
a=orig.index('func (g *tableModel) evaluate(');b=orig.index('// A frozen sort',a)
old=orig[a:b].replace(' evaluate(', ' referenceEvaluate(').replace('g.evaluate(', 'g.referenceEvaluate(')
t=(w/'prefix.go').read_text().replace('func (g *tableModel) evaluate(', 'func (g *tableModel) evaluateRow(').replace('g.evaluate(term.args[i]', 'g.evaluateRow(term.args[i]').replace('return g.evaluate(fn.fallback','return g.evaluateRow(fn.fallback')
t += old + '''func (g *tableModel) evaluate(id int, bindings []int, depth int) int {
    start,failed:=g.work,g.incomplete
    value:=g.evaluateRow(id,bindings,depth)
    work,incomplete:=g.work,g.incomplete
    g.work,g.incomplete=start,failed
    if other:=g.referenceEvaluate(id,bindings,depth); other!=value || work!=g.work || incomplete!=g.incomplete {panic("lookup accounting mismatch")}
    g.audited++
    return value
}'''
t=t.replace('defer g.clearModel()','g.audited=0; defer func(){println("ROOTS", g.audited);g.clearModel()}()')
core=root/'smtcore/smt_model_table.go'
paths={}
for source,s in [(src,t),(core,core.read_text().replace('type tableModel struct {','type tableModel struct {\n audited int'))]:
    dst=w/('oracle-'+source.name);dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));paths[str(source)]=str(dst)
ov=w/'row-oracle.json';ov.write_text(json.dumps({'Replace':paths}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'row-oracle-goivy','./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
