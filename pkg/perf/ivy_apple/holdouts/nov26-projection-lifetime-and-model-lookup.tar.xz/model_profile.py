"""Partition instructions in model checking on complete g3 verifiers by call path."""
import csv,sys,re,subprocess
from pathlib import Path
from collections import Counter
w=Path(__file__).resolve().parent;out=csv.writer(sys.stdout);out.writerow(('case','round','stage','samples'))
for f in sorted((w/'confirmation').glob('*-g3.data')):
    name,turn,_=f.stem.rsplit('-',2);counts=Counter()
    for b in subprocess.check_output([sys.argv[1],'script','--no-inline','-i',f],text=True).split('\n\n'):
        if '(*SMTQuantifierManager).CheckModel' not in b:continue
        cat=next((s for s,look in [
            ('table compile','(*tableModel).compile'),('diagram','(*tableModel).checkDiagram'),('evaluate','(*tableModel).evaluate'),
            ('domain','(*tableModel).domain'),('other table','(*tableModel).check'),
            ('finite candidate evaluation','(*SMTModelChecker).auxiliaryCounterexamples'),
            ('candidate model generation','(*SMTKernel).buildCandidateModelGenerator'),
        ] if look in b),'other')
        counts[cat]+=1
    for k,n in counts.items():out.writerow((name,turn,k,n))
