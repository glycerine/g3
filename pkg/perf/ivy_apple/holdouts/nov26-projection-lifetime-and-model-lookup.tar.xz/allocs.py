"""Use the existing GoIvy allocation profiler with arbitrary verifier transcripts."""
from pathlib import Path
import sys,json,os,subprocess
pkg=Path.cwd()
sys.path.insert(0,str(pkg/'perf/ivy_raft/quantifier_profile'))
from profile import build
w=Path(__file__).resolve().parent
tmp=w/'heap';tmp.mkdir(exist_ok=True)
ivy,gold,examples=map(Path,sys.argv[1:])
exe=build(ivy.resolve(),tmp,65536)
for case in ('ticket_protocol','hybrid'):
    path,iso,rc=json.loads((gold/'cases.json').read_text())[case]
    for turn in range(3):
        p=tmp/f'{case}-{turn}.pb.gz'
        env=dict(os.environ,IVY_STUDY_PROFILE=str(p),GOMAXPROCS='1',XTRACE_OFF='1')
        run=subprocess.run(['taskset','-c','14',exe,*(['isolate='+iso] if iso else []),examples/path],env=env,cwd=tmp,capture_output=True)
        ref=gold/'reference'/case
        assert (run.returncode,run.stdout,run.stderr)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    with (tmp/(case+'.pb.gz')).open('wb') as f:
        subprocess.run(['go','tool','pprof','-proto',*sorted(tmp.glob(case+'-*.pb.gz'))],stdout=f,check=True)
