"""Exercise the evaluator at both ends of a function table and on fallback."""
import csv,os,re,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
out=csv.writer(sys.stdout);out.writerow(('case','round','engine','ns','bytes','allocs'));names=sys.argv[1:]
for i in range(9):
    for tag in names[i%len(names):]+names[:i%len(names)]:
        p=subprocess.run(['taskset','-c','13',w/('row-'+tag),'-test.run=^$','-test.bench=^BenchmarkModelTableFunctionLookup$','-test.benchtime=250000x'],capture_output=True,text=True,env=dict(os.environ,GOMAXPROCS='1'))
        assert p.returncode==0,p.stdout+p.stderr
        rows=re.findall(r'^BenchmarkModelTableFunctionLookup/(\S+)\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op',p.stdout,re.M)
        assert len(rows)==9,p.stdout
        for k,ns,size,n in rows:out.writerow((k,i+1,tag,ns,size,n))
        sys.stdout.flush()
