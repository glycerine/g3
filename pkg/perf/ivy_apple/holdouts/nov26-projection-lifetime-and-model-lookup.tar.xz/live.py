"""Compare reachable heap per completed quantified projection at the SAT handoff."""
import os,sys,subprocess,re,csv
from pathlib import Path
w=Path(__file__).resolve().parent
out=csv.writer(sys.stdout);out.writerow(('round','engine','live_B_per_problem'))
engines=sys.argv[1:]
for i in range(9):
    for tag in engines[i%len(engines):]+engines[:i%len(engines)]:
        run=subprocess.run(['taskset','-c','18',w/('retained-'+tag),'-test.run=^$','-test.bench=^BenchmarkAppleQuantifiedProblemLiveHeap$','-test.benchtime=1x'],cwd='api',env=dict(os.environ,GOMAXPROCS='1'),text=True,capture_output=True,check=True)
        match=re.search(r'([0-9.]+) live-B/problem',run.stdout);assert match,run.stdout
        out.writerow((i+1,tag,match[1]));sys.stdout.flush()
