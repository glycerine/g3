"""Require exact transcripts while the instrumented solver checks each finite assignment twice."""
from pathlib import Path
import json,subprocess,os,csv,sys
w=Path(__file__).resolve().parent;gold=Path(sys.argv[1]);examples=Path(sys.argv[2])
out=csv.writer(sys.stdout);out.writerow(('case','checks','root_evaluations'))
for case,(path,iso,rc) in json.loads((gold/'cases.json').read_text()).items():
    if not (gold/'reference'/case/'stdout').exists():continue
    run=subprocess.run(['taskset','-c','15',w/'row-oracle-goivy',*(['isolate='+iso] if iso else []),examples/path],cwd=w,capture_output=True,timeout=180,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
    lines=run.stderr.splitlines(keepends=True)
    counts=[int(row.split()[1]) for row in lines if row.startswith(b'ROOTS ')]
    err=b''.join(row for row in lines if not row.startswith(b'ROOTS '))
    ref=gold/'reference'/case
    assert (run.returncode,run.stdout,err)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(case,err[:400])
    out.writerow((case,len(counts),sum(counts)));sys.stdout.flush()
