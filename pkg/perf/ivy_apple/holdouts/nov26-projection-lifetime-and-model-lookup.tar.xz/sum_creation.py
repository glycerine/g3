"""Compare observed enode samples with all decoded whole-process samples."""
import csv,collections,sys
for filename in sys.argv[1:]:
    d=collections.defaultdict(collections.Counter);rounds=collections.defaultdict(set)
    for r in csv.DictReader(open(filename)):
        k=(r['query'],r['engine']);d[k][r['stage']]+=int(r['samples']);rounds[k].add(r['round'])
    for q in sorted({k for k,e in d}):
        a,b=d[q,'g3'],d[q,'z3']
        all_a,all_b=sum(a.values()),sum(b.values())
        ca,cb=all_a-a['outside'],all_b-b['outside']
        print(q,len(rounds[q,'g3']),ca,cb,all_a,all_b,round(100*(ca-cb)/(all_a-all_b),2),dict(a),dict(b))
