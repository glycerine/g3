"""Rotate compiled benchmark binaries on one CPU and collect per-operation measurements."""
import csv,sys,subprocess,re,os
from pathlib import Path
w=Path(__file__).resolve().parent;mode=sys.argv[1]; engines=sys.argv[2:]
out=csv.writer(sys.stdout);out.writerow(('benchmark','round','engine','ns','bytes','allocs'))
pattern,iterations,cpu,directory=('BenchmarkTheoryReduction/(UninterpretedEquality|Iff)/Core$',500000,13,'ast/rewriter') if mode=='bench' else ('BenchmarkAppleQuantifiedPremises',25,18,'api')
for i in range(9):
    for tag in engines[i%len(engines):]+engines[:i%len(engines)]:
        exe=w/(mode+'-'+tag)
        run=subprocess.run(['taskset','-c',str(cpu),exe,'-test.run=^$','-test.bench='+pattern,'-test.benchtime='+str(iterations)+'x'],env=dict(os.environ,GOMAXPROCS='1'),cwd=directory,text=True,capture_output=True)
        assert run.returncode==0,run.stdout+run.stderr
        rows=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op',run.stdout,re.M)
        assert len(rows)==2,run.stdout
        for name,ns,size,allocs in rows:out.writerow((name,i+1,tag,ns,size,allocs))
        sys.stdout.flush()
