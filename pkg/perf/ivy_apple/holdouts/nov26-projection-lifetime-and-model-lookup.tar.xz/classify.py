"""Classify retired instruction samples in the enode creation call tree."""
import csv
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path

writer = csv.writer(sys.stdout)
writer.writerow(['query', 'round', 'engine', 'stage', 'samples'])
for raw in sorted(Path(sys.argv[1]).glob('*.data')):
    query, turn, engine = raw.stem.rsplit('-', 2)
    go = engine == 'g3'
    anchor = '(*SMTInternalizerState).mkEnode' if go else 'smt::context::mk_enode('
    stages = [('construct', ('smtcore.newSMTEnode', 'smt::enode::mk(')),
              ('congruence', ('(*SMTCongruenceTable).Insert', 'smt::cg_table::insert(')),
              ('register', ('(*SMTCheckerContext).registerEnode',)),
              ('ownership', ('(*ASTManager).IncRef',)),
              ('trail', ('pushCoreTrail',))]
    counts = Counter()
    report = subprocess.check_output([sys.argv[2], 'script', '--no-inline', '-i', raw], text=True)
    for sample in report.split('\n\n'):
        frames = re.findall(r'^\s+[\da-fA-F]+ (.*?)\+0x',sample,re.M)
        if not frames:
            continue
        pos = next((i for i,f in enumerate(frames) if anchor in f),None)
        if pos is None:
            counts['outside'] += 1
            continue
        inside = frames[:pos]
        stage = next((s for s,names in stages if any(n in f for n in names for f in inside)),'other creation')
        counts[stage] += 1
    for stage,n in sorted(counts.items()):
        writer.writerow([query,turn,engine,stage,n])
