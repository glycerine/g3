"""Try last-binding reuse for finite model terms depending on at most two variables."""
from pathlib import Path
import subprocess,json,sys
w=Path(__file__).resolve().parent;root=Path.cwd()
a=root/'smtcore/smt_model_table.go';b=root/'smtcore/smt_model_table_check.go'
s=a.read_text().replace('type tableModel struct {','type tableModel struct {\n evalMemo []finiteMemo')
s=s.replace('g.manager = nil','g.evalMemo=nil\n g.manager = nil')
t=b.read_text()
k='func (g *tableModel) evaluate(id int, bindings []int, depth int) int {'
genuine=t[t.index(k):t.index('// A frozen sort')]
wrapper='''type finiteMemo struct {
    mask uint32
    first, second int
    a,b,depth,value,cost int
    eligible bool
}
func (g *tableModel) prepareMemo() {
    g.evalMemo=make([]finiteMemo,len(g.terms))
    for i:=range g.terms {
        row:=&g.evalMemo[i]
        term:=&g.terms[i]
        if term.op==tableVariable {
            if term.index<0 || term.index>=8 {row.mask=256} else { row.mask=1<<uint(term.index) }
            continue
        }
        for _,child:=range term.args {row.mask |= g.evalMemo[child].mask}
        if term.op==tableConstant || len(term.args)==0 || row.mask>=256 || bits.OnesCount32(row.mask)>2 {continue}
        row.first,row.second=-1,-1
        if row.mask!=0 {
            row.first=bits.TrailingZeros32(row.mask)
            if more:=row.mask&(row.mask-1); more!=0 {row.second=bits.TrailingZeros32(more)}
        }
        row.eligible=true
    }
}
func (g *tableModel) evaluate(id int, bindings []int, depth int) int {
    if g.evalMemo==nil || !g.evalMemo[id].eligible {return g.evaluateCore(id,bindings,depth)}
    row:=&g.evalMemo[id]
    if row.first>=len(bindings) || row.second>=len(bindings) {return g.evaluateCore(id,bindings,depth)}
    var a,b int
    if row.first>=0 {a=bindings[row.first]}
    if row.second>=0 {b=bindings[row.second]}
    if row.cost>0 && row.depth==depth && row.a==a && row.b==b && g.work>row.cost {
        g.work-=row.cost
        return row.value
    }
    before:=g.work
    v:=g.evaluateCore(id,bindings,depth)
    if !g.incomplete && v!=0 && g.work>0 {row.a,row.b,row.depth,row.value,row.cost=a,b,depth,v,before-g.work}
    return v
}

'''
t=t.replace('import (','import (\n"math/bits"',1).replace(k,wrapper+k.replace(' evaluate(',' evaluateCore('))
t=t.replace('g.work = 100000','if tuples>=16 {g.prepareMemo()}\n g.work = 100000')
mode=sys.argv[1]
if mode=='audit':
    t+=genuine.replace(' evaluate(',' referenceEvaluate(').replace('g.evaluate(', 'g.referenceEvaluate(')
    t=t.replace('value := g.evaluate(root, bindings, 0)','''before,was:=g.work,g.incomplete
        value := g.evaluate(root,bindings,0)
        after,incomplete:=g.work,g.incomplete
        g.work,g.incomplete=before,was
        expected:=g.referenceEvaluate(root,bindings,0)
        if expected!=value || after!=g.work || incomplete!=g.incomplete {panic("finite memo mismatch")}
        if j==0 {println("CHECKTABLE",tuples)}''')
paths={}
for src,code in [(a,s),(b,t)]:
    dst=w/(mode+'-'+src.name);dst.write_bytes(subprocess.check_output(['gofmt'],input=code.encode()));paths[str(src)]=str(dst)
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':paths}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/(mode+'-goivy'),'./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
