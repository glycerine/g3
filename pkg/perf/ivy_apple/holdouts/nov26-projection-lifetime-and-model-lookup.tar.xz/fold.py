"""Use the frame's known argument count before checking for an ITE."""
from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;root=Path.cwd()
src=root/'ast/rewriter/rewriter_engine.go'
s=src.read_text()
old='if i == 1 || i > 0 && r.modelBooleanShortCircuit {'
assert s.count(old)==1
s=s.replace(old,'if i == 1 && n == 3 || i > 0 && r.modelBooleanShortCircuit {')
dst=w/'fold.go';dst.write_text(s);ov=w/'fold.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',ov,'-o',w/'fold','./cmd/g3'],check=True)
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'fold-goivy','./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
