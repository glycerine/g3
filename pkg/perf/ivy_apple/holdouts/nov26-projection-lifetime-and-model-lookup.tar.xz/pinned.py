"""Build the release without overlays on the two previously measured frontends."""
import subprocess,sys,tarfile
from pathlib import Path
w=Path(__file__).resolve().parent
repo=Path.home()/'ivy'
if sys.argv[1]=='apple':
    tree=w/'apple-source';tree.mkdir(exist_ok=True)
    with subprocess.Popen(['git','-C',repo,'archive','07cdeec61','goivy'],stdout=subprocess.PIPE) as p:
        with tarfile.open(fileobj=p.stdout,mode='r|') as archive:archive.extractall(tree,filter='data')
    assert p.returncode==0
    src=tree/'goivy'
    library=Path('z3vendor/native_lib/libz3.a');(src/library).parent.mkdir(exist_ok=True)
    if not (src/library).exists():(src/library).symlink_to(repo/'goivy'/library)
    subprocess.run(['go','mod','edit','-replace','github.com/glycerine/g3/pkg='+str(Path.cwd())],cwd=src,check=True)
    builds=[('apple-g3','xtrace_off'),('apple-z3','xtrace_off,classic_z3')]
    mod=[]
else:
    src=w/'frontend/goivy';builds=[('release-goivy','xtrace_off')];mod=['-modfile',w/'heap/study.mod']
for name,tags in builds:
    subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-pgo=off','-tags='+tags,*mod,'-o',w/name,'./cmd/goivy_check'],cwd=src,check=True)
