"""Specialize the default pre-visit and cache predicates for the theory traversal."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;src=Path.cwd()/'ast/rewriter/rewriter_engine.go';s=src.read_text()
a=s.index('func (r *rewriterEngine) visit(');b=s.index('func (',a+5)
t=s[a:b]
start=t.index('sub, subProof, found, e :=');end=t.index('if depth == 0',start)
t=t[:start]+'''theory, known := r.cfg.(*theoryRewriterConfiguration)
    shortcut := known && !c.proofGen && !ast.ASTValidateHandles && !ast.ASTSourceDebug
    if !shortcut || theory.hasSubstitution {
    '''+t[start:end]+''' }
    '''+t[end:]
t=t.replace('if e = appendRewriterRoot(m, &c.results, t); e != nil {','if e := appendRewriterRoot(m, &c.results, t); e != nil {',1)
t=t.replace('if c.proofGen {\n\t\t\te = r.appendProof(ast.ASTHandle{})\n\t\t}\n\t\treturn true, e','if c.proofGen {return true, r.appendProof(ast.ASTHandle{})}; return true,nil',1)
t=t.replace('cache, e := r.mustCacheShape(t, kind, rc, n)\n\tif e != nil {\n\t\treturn false, e\n\t}', '''var cache bool
    if shortcut {
        cache = t != c.root && (rc>1 || theory.cacheAll) && (kind==ast.ASTQuantifier || kind==ast.ASTApp && n>0)
    } else {
        cache,e = r.mustCacheShape(t,kind,rc,n)
        if e!=nil {return false,e}
    }''')
start=t.index('allowed, e :=');end=t.index('switch kind',start)
t=t[:start]+'if !shortcut {\n'+t[start:end]+'}\n'+t[end:]
s=s[:a]+t+s[b:]
dst=w/'visit.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));ov=w/'visit.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',ov,'-o',w/'visit','./cmd/g3'],check=True)
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'visit-goivy','./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
