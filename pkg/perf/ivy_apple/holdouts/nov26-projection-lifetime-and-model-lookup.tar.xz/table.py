"""Evaluate compact short-arity scans and an index built during model validation."""
from pathlib import Path
import subprocess,sys,json
w=Path(__file__).resolve().parent;root=Path.cwd(); mode=sys.argv[1]
a=root/'smtcore/smt_model_table.go';b=root/'smtcore/smt_model_table_check.go'
s=a.read_text();t=b.read_text()
start=t.index('for _, entry := range fn.entries');end=t.index('// Model function',start)
code = '''if value, probes := fn.lookup(&args, len(term.args)); value != 0 {
            g.work -= probes
            return value
        }
        g.work -= len(fn.entries)
        '''
t=t[:start]+code+t[end:]
lookup='''func (f *tableFunction) lookup(args *[tableMaxArity]int, arity int) (int,int) {
    switch arity {
    case 1:
        for i:=range f.entries { if f.entries[i].keys[0]==args[0] {return f.entries[i].value,i+1} }
    case 2:
        for i:=range f.entries { row:=&f.entries[i]; if row.keys[0]==args[0] && row.keys[1]==args[1] {return row.value,i+1} }
    default:
        for i:=range f.entries { if f.entries[i].keys==*args {return f.entries[i].value,i+1} }
    }
    return 0,len(f.entries)
}
'''
if mode=='index':
    s=s.replace('type tableFunction struct {','type tableFunction struct {\n positions map[[tableMaxArity]int]uint8')
    s=s.replace('var seen map[[tableMaxArity]int]struct{}','var seen map[[tableMaxArity]int]uint8').replace('seen = make(map[[tableMaxArity]int]struct{}, len(fn.entries))','seen = make(map[[tableMaxArity]int]uint8, len(fn.entries)); if len(fn.entries)>=8 {fn.positions = seen}').replace('seen[row.keys] = struct{}{}','seen[row.keys] = uint8(i+1)')
    lookup=lookup.replace('switch arity {','if f.positions != nil {pos:=int(f.positions[*args]); if pos!=0 {return f.entries[pos-1].value,pos}; return 0,len(f.entries)}\n switch arity {')
t=t.replace('func tableBool(',lookup+'\nfunc tableBool(')
paths={}
for src,value in [(a,s),(b,t)]:
    dst=w/(mode+'-'+src.name);dst.write_bytes(subprocess.check_output(['gofmt'],input=value.encode()));paths[str(src)]=str(dst)
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':paths}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/(mode+'-goivy'),'./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
