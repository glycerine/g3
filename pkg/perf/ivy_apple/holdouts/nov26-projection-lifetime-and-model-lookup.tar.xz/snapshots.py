"""Count repeated interpreted function rows within one model-check invocation."""
from pathlib import Path
import subprocess,json,os,csv,sys,collections
w=Path(__file__).resolve().parent;root=Path.cwd()
core=root/'smtcore/smt_model_table.go';s=core.read_text()
anchor='id := len(g.functions)'
assert s.count(anchor)==1
s=s.replace(anchor,'''println("MROWFN",decl.Origin(),decl.Slot(),decl.Generation(),fallback.Slot(),fallback.Generation(),arity,len(fn.entries))
    for _,row:=range fn.entries {
        for j:=uint32(0);j<arity;j++ { v:=g.values[row.keys[j]]; println("MROWKEY",v.Slot(),v.Generation()) }
        v:=g.values[row.value]; println("MROWVAL",v.Slot(),v.Generation())
    }
    '''+anchor)
check=root/'smtcore/smt_model_checker.go';t=check.read_text()
anchor='func (c *SMTModelChecker) Check(model *protomodel.ProtoModel, quantifiers []ast.ASTHandle) (bool, error) {'
t=t.replace(anchor,anchor+'\n println("MODELCALL"); defer println("MODELEND")')
anchor='status, bindings, err := c.tableScratch.check(c.manager, model, flat, body, count)'
t=t.replace(anchor,anchor+'\n println("TABLESTATUS",int(status))')
paths={}
for src,code in ((core,s),(check,t)):
    dst=w/('census-'+src.name);dst.write_text(code);paths[str(src)]=str(dst)
ov=w/'snapshots.json';ov.write_text(json.dumps({'Replace':paths}))
exe=w/'snapshot-goivy'
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
out=csv.writer(sys.stdout);out.writerow(('case','candidate_calls','empty_tables','functions','rows','repeated_functions','same_local_snapshot','same_rows','false','undef','true'))
examples=Path('/home/jaten/ivy/ivy-lang-examples');gold=root/'build/.bool-scan/golden'
for case,(path,iso,rc) in json.loads((gold/'cases.json').read_text()).items():
    run=subprocess.run(['taskset','-c','17',exe,*(['isolate='+iso] if iso else []),examples/path],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
    ref=gold/'reference'/case;keep=[];stack=[];counts=collections.Counter()
    it=iter(run.stderr.splitlines(keepends=True))
    for row in it:
        parts=row.split();tag=parts[0] if parts else b''
        if tag==b'MODELCALL':stack.append({});counts['calls']+=1
        elif tag==b'MODELEND':stack.pop()
        elif tag==b'TABLESTATUS':counts[int(parts[1])]+=1
        elif tag==b'MROWFN':
            owner,slot,generation,fs,fg,arity,n=map(int,parts[1:])
            keys=[]
            for i in range(n):
                for j in range(arity):
                    k,x,y=next(it).split();assert k==b'MROWKEY';keys.extend((int(x),int(y)))
                k,x,y=next(it).split();assert k==b'MROWVAL';keys.extend((int(x),int(y)))
            key=(owner,slot,generation);snapshot=(fs,fg,arity,n,tuple(keys))
            counts['functions']+=1;counts['rows']+=n;counts['empty']+=n==0
            if key in stack[-1]:
                counts['repeats']+=1
                if stack[-1][key]==snapshot:counts['same']+=1;counts['same_rows']+=n
            stack[-1][key]=snapshot
        else:keep.append(row)
    assert not stack and (run.returncode,run.stdout,b''.join(keep))==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),case
    out.writerow((case,*[counts[x] for x in ('calls','empty','functions','rows','repeats','same','same_rows',-1,0,1)]));sys.stdout.flush()
