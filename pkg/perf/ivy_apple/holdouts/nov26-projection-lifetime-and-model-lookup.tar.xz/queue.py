"""Separate queue work from GC and general rewriting in complete g3 runs."""
from pathlib import Path
from collections import Counter
import csv,re,subprocess,sys
w=Path(__file__).resolve().parent
out=csv.writer(sys.stdout);out.writerow(('case','round','engine','category','samples'))
for f in sorted((w/'confirmation').glob('*-g3.data')):
    case,turn,engine=f.stem.rsplit('-',2)
    d=Counter()
    for b in subprocess.check_output([sys.argv[1],'script','--no-inline','-i',f],text=True).split('\n\n'):
        if not re.search(r'^\s+[\da-fA-F]+ ',b,re.M):continue
        queue='(*SMTQuantifierManager).instantiate' in b
        cat=next((key for key,labels in [
            ('GC',('runtime.gcDrain','runtime.gcAssistAlloc','runtime.wbBufFlush1')),
            ('enode creation',('(*SMTInternalizerState).mkEnode',)),
            ('projection',('/api/internal/order.','.proveAssertions')),
            ('substitution',('(*SMTCachedVarSubstitution).Instantiate',)),
            ('theory rewrite',('(*TheoryRewriter).Rewrite',)),
            ('candidate check',('(*SMTChecker).run',)),
            ('assertion',('(*SMTInternalizerState).assertExpression',)),
            ('queue other',('(*SMTQuantifierManager).instantiate',)),
            ('other search',('(*SMTKernel).search',)),
            ('other solver check',('(*SMTSolver).CheckSat',)),
            ('other solver push',('(*SMTSolver).Push',)),
        ] if any(k in b for k in labels)),'other')
        d[('queue ' if queue else '')+cat]+=1
    for key,n in d.items():out.writerow((case,turn,engine,key,n))
