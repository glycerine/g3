"""Try storing one resolved literal in padding already present in its justification."""
from pathlib import Path
import json, subprocess,sys
w=Path(__file__).resolve().parent
src=Path.cwd()/'smtcore/smt_justification.go'
s=src.read_text().replace('type SMTUnitResolutionJustification struct {\n\tSMTJustificationBase','type SMTUnitResolutionJustification struct {\n\tSMTJustificationBase\n\tsingle [1]SMTLiteral')
old='return &SMTUnitResolutionJustification{SMTJustificationBase: NewSMTJustificationBase(region), Antecedent: antecedent, Literals: append([]SMTLiteral(nil), literals...)}, nil'
assert s.count(old)==1
s=s.replace(old,'''j := &SMTUnitResolutionJustification{SMTJustificationBase: NewSMTJustificationBase(region), Antecedent: antecedent}
    if len(literals) == 1 {
        j.single[0] = literals[0]
        j.Literals = j.single[:]
    } else {
        j.Literals = append([]SMTLiteral(nil), literals...)
    }
    return j, nil''')
dst=w/'unit.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'unit.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',ov,'-o',w/'unit','./cmd/g3'],check=True)
ivy=w/'frontend/goivy'
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'unit-goivy','./cmd/goivy_check'],cwd=ivy,check=True)
