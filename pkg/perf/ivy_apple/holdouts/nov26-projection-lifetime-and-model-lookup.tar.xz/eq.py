"""Compare operand-shape and sort admission for the one-bit equality rule."""
from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/th_rewriter.go'
s=src.read_text();a=s.index('kind, err := c.owner.manager.GetKind(term)',s.index('func (c *theoryRewriterConfiguration) equalityBit'));b=s.index('if count,',a)
s=s[:a]+'''app, family, op, err := c.owner.manager.AppIdentity(term)
    if err != nil || !app || family != c.owner.manager.BasicFamilyID() || op != ast.ASTOpEq {
        return x, 0, false, err
    }
    '''+s[b:]
label=sys.argv[1]
if label=='sort':
    a=s.index('if kind == ast.ASTOpEq {',s.index('func (c *theoryRewriterConfiguration) reduceAppCore'))
    s=s[:a]+s[a:].replace('if kind == ast.ASTOpEq {','tryBitEquality := kind == ast.ASTOpIff\n        if kind == ast.ASTOpEq {',1).replace('status := RewriteFailed','tryBitEquality = sortFamily == m.BasicFamilyID()\n            status := RewriteFailed',1).replace('if kind == ast.ASTOpEq || kind == ast.ASTOpIff {','if tryBitEquality {',1)
dst=w/(label+'.go');dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',ov,'-o',w/label,'./cmd/g3'],check=True)
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/(label+'-goivy'),'./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
