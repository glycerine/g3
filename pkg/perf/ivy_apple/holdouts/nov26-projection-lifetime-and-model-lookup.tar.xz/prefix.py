from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;src=Path.cwd()/'smtcore/smt_model_table_check.go';s=src.read_text()
a=s.index('for _, entry := range fn.entries');b=s.index('// Model function',a)
s=s[:a]+'''// Both key arrays are zero-padded. The first two positions are the
        // complete key for unary and binary functions.
        for i := range fn.entries {
            row := &fn.entries[i]
            if row.keys[0] == args[0] && row.keys[1] == args[1] && (len(term.args) <= 2 || row.keys == args) {
                g.work -= i + 1
                return row.value
            }
        }
        g.work -= len(fn.entries)
        '''+s[b:]
dst=w/'prefix.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));ov=w/'prefix.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','test','-c','-pgo=off','-mod=readonly','-overlay',ov,'-o',w/'row-prefix','./smtcore'],check=True)
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-modfile',w/'heap/study.mod','-mod=readonly','-tags=xtrace_off','-overlay',ov,'-o',w/'prefix-goivy','./cmd/goivy_check'],cwd=w/'frontend/goivy',check=True)
