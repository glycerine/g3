"""Replay the first differing model bindings in the archived TLB histories."""
import os,tarfile
from pathlib import Path
out=Path(os.environ['RESULTS']);out.mkdir(parents=True,exist_ok=True)
script_dir=Path(__file__).resolve().parent
def read(archive,name):
    with tarfile.open(Path('perf/ivy_apple/holdouts')/archive) as a:return a.extractfile('study/'+name).read().decode()
history=read('nov27-tlb-witness-history.tar.xz','replay.py')
def swaps(s):
    a=s.index('  for repno in range(3):');b=s.index('     r=sp.run(',a)
    s=s[:a]+'''  for repno in range(int(os.environ.get('ROUNDS','3'))):
   n=1;golden=ref/'compat'/str(n)/'1/native'
   cases=[(k,m) for k in ['0..0','all'] for m in map(int,os.environ.get('MASKS','0,1,2,4,8,15').split(','))]
   for key,mask in cases[repno:]+cases[:repno]:
     mode='indexed'
'''+s[b:]
    go=read('nov27-unary-demand-and-fresh-symbols.tar.xz','sources/events-smt_search.go.txt')
    tree=go[go.index('func trialTree('):go.index('func witnessTrace(')]+'func witnessTree(m *ast.ASTManager,t ast.ASTHandle) string {var b strings.Builder;trialTree(m,t,&b);return b.String()}\n'
    edit="""
 k=p/'smtcore/smt_search.go';v=Path(rep[str(k)]).read_text().replace('import (','import ("strings";"strconv";"os";').replace('k.internalizer.statistics.NumDecisions++','if trialSwapOn{trialSwapD++};k.internalizer.statistics.NumDecisions++')
 put(k,v+EXTRA)
 k=p/'smtcore/smt_model_checker_instances.go';v=k.read_text().replace('return c.pinInstance(quantifier, bindings, generation)','swapTerm(c,quantifier,bindings,fromInverse,generation);return c.pinInstance(quantifier, bindings, generation)');put(k,v)
 k=p/'smtcore/smt_qi_instance.go';v=k.read_text().replace('if err = internalizer.internalizeInstance','if trialSwapOn{trialSwapQ++;if trialSwapD==595{trialSwapBurst++}};if err = internalizer.internalizeInstance');put(k,v)
 k=front/'phase_observer_trial.go';v=Path(rep[str(k)]).read_text().replace('import (','import ("strconv";').replace('func unitBegin(b,g int){','func unitBegin(b,g int){if b==60&&g==1{m,e:=strconv.Atoi(os.Getenv("SWAP_MASK"));if e!=nil{panic(e)};smtcore.BeginSwap(b,g,m,os.Getenv("TARGET")=="all")};').replace('func unitEnd(b,g int){','func unitEnd(b,g int){if b==60&&g==1{a,n,burst:=smtcore.FinishSwap();fmt.Fprintln(os.Stderr,"SWAP_DONE",a,n,burst)};');put(k,v)
"""
    if os.environ.get('TRIAL_CACHE'):
        s=s.replace("GOCACHE=str(d/'cache')","GOCACHE=os.environ['TRIAL_CACHE']")
    payload=tree+(script_dir/'swap.go.txt').read_text()
    if os.environ.get("OBSERVE"):
        pos=payload.index(" idx:=len(c.newInstances)")
        payload=payload[:pos]+''' idx:=len(c.newInstances);fmt.Fprint(os.Stderr,"SWAP_BIND ",idx," ",inv," ",gen," ",witnessTree(c.manager,quant)," ::");for _,t:=range terms{fmt.Fprint(os.Stderr," ",witnessTree(c.manager,t))};fmt.Fprintln(os.Stderr)
}
'''
    if os.environ.get("CATALOG"):
        payload=payload.replace('if trialSwapMask&','observeSwapValue(c,quant,i,terms[i],target);if trialSwapMask&')+(script_dir/'catalog.go.txt').read_text()
        edit+="""
 k=p/'smtcore/smt_model_finder_instantiation_set.go';v=k.read_text();a='for _, entry := range s.elements.Entries() {'
 i=v.index(a,v.index('func (s *smtModelFinderInstantiationSet) MakeInverse'))
 v=v[:i]+'if trialSwapOn{if swapCatalog==nil{swapCatalog=make(map[*smtModelFinderInstantiationSet][]swapChoice)};swapCatalog[s]=nil};'+v[i:]
 a='old, found, err := s.inverse.Find(value)';v=v.replace(a,'if trialSwapOn{swapCatalog[s]=append(swapCatalog[s],swapChoice{term,value,generation})};'+a);put(k,v)
"""
    edit=edit.replace('v+EXTRA','v+'+repr(payload))
    s=s.replace(" j=d/'ov.json'",edit+" j=d/'ov.json'").replace('TARGET=key,UNIT_MODE=mode','TARGET=key,UNIT_MODE=mode,SWAP_MASK=str(mask)')
    s=s.replace('stages=[];rest','info=[];done=[];stages=[];rest').replace('else:rest.extend(l)',"""elif l.startswith(b'SWAP_BIND '):info.append(l)
      elif l.startswith(b'SWAP_DONE '):done.append(tuple(map(int,a[1:])))
      else:rest.extend(l)""")
    s=s.replace('assert match,(n,mode,repno)',"""if not match: (w/'failure.log').write_bytes(rest)
     assert match and len(done)==1,(n,key,mask,repno,done)
     (w/f'{key}-{mask}.log').write_bytes(b''.join(info))
     assert done[0][0]==mask.bit_count(),(key,mask,done,info)
     with (w/'swaps.csv').open('a') as raw:csv.writer(raw).writerow([repno,key,mask,*done[0],sum(v for t,ph,v in stages if t==b'60-1' and ph==b'check'),sum(v for _,_,v in stages)])""")
    pos=s.index(" with (w/(variant+'.csv')).open")
    s=s[:pos]+" if os.environ.get('SAVE_BINARY'):\n  import shutil;shutil.copy2(exe,os.environ['SAVE_BINARY'])\n"+s[pos:]
    return s
history=history.replace('exec(compile(prefix+', 'namespace["swaps"]=swaps\nschedule+="    s=swaps(s)\\n"\nexec(compile(prefix+')
exec(history)
