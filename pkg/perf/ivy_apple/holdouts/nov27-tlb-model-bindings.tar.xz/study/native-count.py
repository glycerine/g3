"""Count native nontrivial quantified instances inside TLB 60/1."""
import csv,json,os,subprocess,tarfile,tempfile
from pathlib import Path
pkg=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();out=Path(os.environ['RESULTS']);out.mkdir(parents=True,exist_ok=True)
examples=Path(os.environ['IVY_EXAMPLES']);ref=Path(os.environ['NNF_REFERENCE']);spec=(ref/'compat.txt').read_text().splitlines()[0]
expected=int(next(row['exit'] for row in csv.DictReader((ref/'ranking.csv').open()) if row['case']==spec))
with tempfile.TemporaryDirectory() as temp,tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t:
    d=Path(temp);rep={}
    plan=json.loads(t.extractfile('study/plans/linked-z3.json').read())
    for _,name,source in plan['sources']:
        s=t.extractfile('study/sources/'+source).read().decode()
        if name=='z3bridge_solver_model.go':
            a=s.index('batch:=newStageBatch()');b=s.index('z3solver := s.newZ3Solver()',a)+len('z3solver := s.newZ3Solver()')
            s=s[:b]+';if batch==60{z3solver.SetParam("qi.profile_freq","1")}'+s[b:]
            s=s.replace('stopCheck:=startStage(batch,index+1);','if batch==60&&index==0{fmt.Fprintln(os.Stderr,"BEGIN_COUNT")};stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");if batch==60&&index==0{fmt.Fprintln(os.Stderr,"END_COUNT")}')
        f=d/name;f.write_text(s);rep[str(front/name)]=str(f)
    j=d/'overlay.json';j.write_text(json.dumps({'Replace':rep}));exe=d/'native'
    subprocess.run(['go','build','-mod=readonly','-tags','classic_z3,xtrace_off','-buildvcs=false','-pgo=off','-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-overlay',j,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=os.environ.get('TRIAL_CACHE',str(d/'cache'))),check=True)
    with (out/'counts.csv').open('w') as f:
        writer=csv.writer(f);writer.writerow(['round','started','ended','instances','profile_lines_outside_check','status'])
        for i in range(2):
            r=subprocess.run(['taskset','-c',os.environ['CPU'],exe,examples/spec],cwd=d,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),timeout=180)
            normal=[];counts=[];starts=ends=outside=0;inside=False
            for line in r.stderr.splitlines(keepends=True):
                if line.startswith(b'STAGE-COUNT '):continue
                if line.strip()==b'BEGIN_COUNT':inside=True;starts+=1;continue
                if line.strip()==b'END_COUNT':inside=False;ends+=1;continue
                if line.startswith(b'[quantifier_instances]'):
                    if inside:counts.append(line)
                    else:outside+=1
                else:normal.append(line)
            gold=ref/'compat/1/1/native'
            if (r.returncode,r.stdout,b''.join(normal))!=(expected,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()):
                (out/'failure.log').write_bytes(r.stderr);raise ValueError('native transcript mismatch')
            assert starts==ends==1 and counts
            (out/f'profile-{i}.log').write_bytes(b''.join(counts))
            writer.writerow([i,starts,ends,len(counts),outside,'match']);f.flush()
