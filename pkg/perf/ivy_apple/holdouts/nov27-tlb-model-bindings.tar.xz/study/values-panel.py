"""Compare whole verifiers built with the original and direct inverse-key enumerator."""
from pathlib import Path
import os,tarfile
w=Path(os.environ['RESULTS']);w.mkdir(parents=True,exist_ok=True)
with tarfile.open('perf/ivy_apple/holdouts/nov27-macro-expansion-walkers.tar.xz') as t:
    s=t.extractfile('study/process.py').read().decode()
a=s.index('    cases=');b=s.index('    for mode in modes:',a)
s=s[:a]+"    cases=[8,6,1];modes=['base','direct']\n"+s[b:]
a=s.index("        if mode!='base':");b=s.index("        o=d/'overlay.json'",a)
s=s[:a]+"""        if mode=='base':
            name='smtcore/smt_model_finder_instantiation_set.go'
            overlay(pkg/name,subprocess.check_output(['git','show','848b1162d:pkg/'+name],text=True))
"""+s[b:]
s=s.replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("GOCACHE=str(d/'cache')","GOCACHE=os.environ.get('TRIAL_CACHE',str(d/'cache'))")
exec(s)
