"""Measure an input-independent binding rule in the full verifier under normal GC."""
import os,tarfile
from pathlib import Path
script_dir=Path(__file__).resolve().parent
policy=os.environ.get('POLICY','equality')
results=Path(os.environ['RESULTS']);results.mkdir(parents=True,exist_ok=True)
with tarfile.open('perf/ivy_apple/holdouts/nov27-macro-expansion-walkers.tar.xz') as t:
    s=t.extractfile('study/process.py').read().decode()
a=s.index('    cases=');b=s.index('    for mode in modes:',a)
s=s[:a]+"    cases=list(map(int,os.environ.get('CASES','8,6,1,4,2,3,5,7,9,10,11,12,227').split(',')));modes=['base',policy]\n"+s[b:]
a=s.index("        if mode!='base':");b=s.index("        o=d/'overlay.json'",a)
s=s[:a]+"""        if mode!='base':
            path=pkg/'smtcore/smt_model_checker.go';source=path.read_text()
            hook='bindings[i] = term';pos=source.index(hook,source.index('func (c *SMTModelChecker) addFiniteCounterexample'))
            source=source[:pos]+'if i==1&&len(bindings)==2{term,err=c.benchRepresentative(quantifier,term,value,generation);if err!=nil{return false,err}};'+source[pos:]
            extra=(script_dir/'representative.go.txt').read_text().replace('var benchRep string','const benchRep="'+mode+'"').replace('var benchReplaced int','').replace('benchReplaced++;','')
            overlay(path,source+extra)
"""+s[b:]
s=s.replace('range(3):',"range(int(os.environ.get('ROUNDS','3'))):").replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("GOCACHE=str(d/'cache')","GOCACHE=os.environ.get('TRIAL_CACHE',str(d/'cache'))")
exec(s)
