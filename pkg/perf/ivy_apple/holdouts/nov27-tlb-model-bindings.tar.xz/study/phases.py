"""Use the archived per-instance meters inside the complete TLB check."""
from pathlib import Path
import csv,json,os,re,shlex,shutil,subprocess as sp,tarfile,tempfile
from collections import Counter
pkg=Path.cwd();out=Path(os.environ['RESULTS']);out.mkdir(parents=True,exist_ok=True)
front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES'])
case=(ref/'compat.txt').read_text().splitlines()[0]
def source(archive,name):
    with tarfile.open(pkg/'perf/ivy_apple/holdouts'/archive) as t:return t.extractfile(name).read()
def first(name):return source('nov27-first-push-queue-comparison.tar.xz',name)
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp)
 if os.environ.get('METER_LIB'):lib=Path(os.environ['METER_LIB']).resolve(strict=True)
 else:
    build=pkg.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
    inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    objs=[]
    for name in ('cached_var_subst','qi_queue'):
        cpp=d/(name+'.cpp');cpp.write_bytes(first(cpp.name));obj=d/(name+'.o')
        sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,cpp],cwd=build,check=True);objs.append(obj)
    lib=d/'meter.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);sp.run(['ar','r',lib,*objs],check=True)
 for engine in ('base','release','native'):
    native=engine=='native';mode='native' if native else 'g3';mp={}
    def put(path,data):
        target=d/(engine+'-'+path.name);target.write_bytes(data);mp[str(path)]=str(target)
    for fn in ('phase_observer_trial.go','z3bridge_solver_model.go'):
        data=first('check-'+mode+'-'+fn)
        if fn.startswith('z3bridge'):
            # Use the staged bridge matching the current study's verifier.
            if native:data=source('nov27-unary-demand-and-fresh-symbols.tar.xz','study/sources/native-z3bridge_solver_model.go.txt')
            else:data=source('nov27-terminal-conflict-replay.tar.xz','study/stage-bridge.go.txt')
            hook=b'stopCheck:=startStage(batch,index+1);';assert data.count(hook)==1
            data=data.replace(hook,b'capturePush=batch==60 && index==0;'+hook).replace(b'stopCheck("check")',b'stopCheck("check");capturePush=false')
        put(front/fn,data)
    guard=(source('nov27-unary-demand-and-fresh-symbols.tar.xz','study/sources/native-z3bridge_guarded_equalities.go.txt') if native else source('nov27-terminal-conflict-replay.tar.xz','study/guards.go.txt'))
    put(front/'z3bridge_guarded_equalities.go',guard)
    if native:put(front/'smt/quantifier.go',first('check-native-quantifier.go').replace(b'/tmp/g3-first-qi/check.a',os.fsencode(lib)))
    else:
        put(pkg/'smtcore/smt_qi_instance.go',first('check-g3-smt_qi_instance.go'))
        if engine=='base':put(pkg/'smtcore/smt_model_checker.go',sp.check_output(['git','show','38f35fd3a:pkg/smtcore/smt_model_checker.go']))
    j=d/'overlay.json';j.write_text(json.dumps({'Replace':mp}))
    sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off,classic_z3' if native else 'xtrace_off','-pgo='+('off' if native else str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',d/engine,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=os.environ.get('TRIAL_CACHE',str(d/'cache'))),check=True)
 with (out/'phases.csv').open('w') as f:
    wr=csv.writer(f);wr.writerow(['round','engine','op','flag','calls','instructions'])
    for i in range(3):
        modes=['base','release','native']
        for eng in modes[i:]+modes[:i]:
            r=sp.run(['taskset','-c',os.environ['CPU'],d/eng,ex/case],cwd=d,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),timeout=180)
            normal=[];active=False;start=end=0;counts=Counter();cost=Counter()
            for line in r.stderr.splitlines(keepends=True):
                a=line.split()
                if line.startswith(b'OPEN '):assert a[1:]==[b'60',b'1'] and not active;active=True;start+=1
                elif line.startswith(b'STAGE-COUNT '):
                    if active:assert a[1:4]==[b'60',b'1',b'check'] and a[6]==a[7];active=False;end+=1
                elif active and a and a[0] in (b'C',b'S',b'R',b'A'):
                    key=(a[0].decode(),int(a[1]));counts[key]+=1;cost[key]+=int(a[2])
                else:normal.append(line)
            golden=ref/'compat/1/1/native'
            assert (r.returncode,r.stdout,b''.join(normal))==(1,(golden/'stdout').read_bytes(),(golden/'stderr').read_bytes()),(eng,r.stderr[-500:])
            assert start==end==1 and counts['R',0]==counts['A',0] and counts['S',0]+counts['S',1]==counts['C',0]==counts['R',0]+counts['R',1]
            wr.writerows([i,eng,*k,counts[k],cost[k]] for k in sorted(counts));f.flush()
