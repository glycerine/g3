"""Price same-binary release pairs and check the complete native transcript corpus."""
import os,tarfile,tempfile,subprocess
from pathlib import Path
script_dir=Path(__file__).resolve().parent
with tarfile.open('perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t, tempfile.TemporaryDirectory() as temp:
    d=Path(temp)
    def read(name):return t.extractfile('study/'+name).read()
    sd=d/'release-sources';sd.mkdir()
    for name in ('apple.go.txt','regular.go.txt','apple-guards.go.txt','regular-guards.go.txt'):
        (sd/name).write_bytes(read('release-sources/'+name))
    helper=(script_dir/'anchor.go.txt').read_text().replace('import "github.com/glycerine/g3/pkg/ast"','import ("os";"github.com/glycerine/g3/pkg/ast")\n var benchmarkNamed = os.Getenv("USE_NAMED")=="1"')
    (sd/'helper.go').write_text(helper)
    source=subprocess.check_output(['git','show','38f35fd3a:pkg/smtcore/smt_model_checker.go'],text=True)
    pos=source.index('bindings[i] = term',source.index('func (c *SMTModelChecker) addFiniteCounterexample'))
    hook='if benchmarkNamed && i==1 && len(bindings)==2 {term,err=c.namedSecondBinding(quantifier,bindings[0],term,value,generation);if err!=nil{return false,err}};'
    (sd/'checker.go').write_text(source[:pos]+hook+source[pos:])
    s=read('final_panel.py').decode().replace('GOCACHE=str(d/"cache")','GOCACHE=os.environ.get("TRIAL_CACHE",str(d/"cache"))')
    s=s.replace('str(source/(mode+".go.txt"))','str(source/"checker.go")').replace('smt_model_checker_repeated_binding.go','smt_model_named_binding.go').replace('str(source/(mode+"-helper.go.txt"))','str(source/"helper.go")')
    s=s.replace('GOMAXPROCS="1",XTRACE_OFF','USE_NAMED=("1" if mode=="candidate" else "0"),GOMAXPROCS="1",XTRACE_OFF')
    s=s.replace('[8,6,2,3,4,5,7,9,10,11,12,1],["raft_no_assume"]','[4,8,6,1,2,3,5,7,9,10,11,12],[227]')
    if os.environ.get("REPEAT"):
        s=s.replace('range(3):','range(7):').replace('[4,8,6,1,2,3,5,7,9,10,11,12],[227],["rfn2"],["dramc_nb2"]','[4],[1],[3,6],[227]')
        s=s[:s.index('    with concurrent.futures.ThreadPoolExecutor(4) as pool,(output/"verified.csv"')]
    if os.environ.get("OBSERVE_ALL"):
        h=(sd/'helper.go').read_text().replace('import ("os";','import ("fmt";"os";')
        h=h.replace('if first == second {','fmt.Fprintln(os.Stderr,"NAMED_CALL");if first == second {').replace('evaluated := c.modelFinder','fmt.Fprintln(os.Stderr,"NAMED_SCAN");evaluated := c.modelFinder').replace('return entry.Key, nil','fmt.Fprintln(os.Stderr,"NAMED_CHANGE");return entry.Key, nil')
        (sd/'helper.go').write_text(h)
        pos=s.index('            if (r.returncode,r.stdout,r.stderr)')
        s=s[:pos]+'''            marks=[b'NAMED_CALL',b'NAMED_SCAN',b'NAMED_CHANGE']
            rows=r.stderr.splitlines(keepends=True)
            stats=[sum(line.strip()==tag for line in rows) for tag in marks]
            r.stderr=b''.join(line for line in rows if line.strip() not in marks)
'''+s[pos:]
        s=s.replace('return [case,"match"]','return [case,"match",*stats]').replace('["case","transcript"]','["case","transcript","calls","scans","changes"]')
    exec(compile(s,'anchor-release-screen','exec'),{'__file__':str(d/'run.py')})
