"""Assert complete conditions and summarize within-process instruction counters."""
from collections import defaultdict
from pathlib import Path
from statistics import median
import csv,sys
w=Path(sys.argv[1])
def check(runs,groups,reps,path,header):
    assert len(runs)==groups,(path,len(runs),groups)
    with path.open('w') as f:
        writer=csv.writer(f);writer.writerow(header)
        for key,rr in sorted(runs.items()):
            assert sorted(r[0] for r in rr)==list(range(reps)),key
            writer.writerow([*key,*map(median,zip(*(r[1:] for r in rr)))])
def matches(group,n):
    rr=list(csv.DictReader((w/group/'candidate.csv').open()))
    assert len(rr)==n and all(x['status']=='match' for x in rr),group
for g,n in [('main',36),('catalog',2),('observe',2),('general',24),('rank',32),('anchor',32)]:matches(g,n)
r=defaultdict(list)
for rep,key,mask,hits,q,burst,c,st in csv.reader((w/'main/swaps.csv').open()):
    assert int(hits)==int(mask).bit_count()
    r[key,int(mask)].append(list(map(int,(rep,q,burst,c,st))))
check(r,12,3,w/'swaps-summary.csv',['history','mask','asserted','burst_after_decision_595','check','stages'])
for g,modes,reps in [('general',3,1),('rank',4,1),('anchor',2,2)]:
    r=defaultdict(list)
    for rep,pol,c,hits,observed,cost,st in csv.reader((w/g/'fresh.csv').open()):
        assert observed=='407'
        r[int(c),pol].append(list(map(int,(rep,hits,cost,st))))
    check(r,modes*8,reps,w/(g+'-summary.csv'),['counter','policy','changes','check','stages'])
