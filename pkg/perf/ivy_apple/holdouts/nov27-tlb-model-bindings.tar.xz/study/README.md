# Model-witness replay on TLB 60/1

Use Linux with perf_event_open for retired user instructions, the benchmark GoIvy regular and Apple frontends, and this fork's native build. Run from g3/pkg. The scripts reuse the previously tracked observers and frontend overlays. For the binding replay, general-rule trials, values-panel and search-panel use revision 38f35fd3a. For phases.py use the revision containing this archive and the named second binding change. The values microbenchmark and its original implementation are available on opposite sides of 38f35fd3a; the baseline run in this study overlaid 848b1162d's instantiation-set Go source while keeping the new benchmark.

Export GOIVY_FRONTEND, GOIVY_MODFILE (absolute), IVY_EXAMPLES, and NNF_REFERENCE (the reference with compat.txt, ranking.csv and compat/<case>/1/native). For the large holdouts also set APPLE_FRONTEND, APPLE_REFERENCE, ABC and PANEL_CPUS (four comma-separated CPU IDs). CPU selects the core for standalone experiments. PERF can select an explicit Linux perf binary. Set STUDY to this extracted directory and OUT to a fresh absolute result directory. TRIAL_CACHE can point to a dedicated Go build cache to reuse compilation between runs. The benchmark processes run independently and use transcript and exit-status checks. No observer is used by the production solver.

    OBSERVE=1 MASKS=0 ROUNDS=1 RESULTS="$OUT/observe" python3 "$STUDY/replay.py"
    CATALOG=1 MASKS=0 ROUNDS=1 RESULTS="$OUT/catalog" python3 "$STUDY/replay.py"
    RESULTS="$OUT/main" python3 "$STUDY/replay.py"
    ROUNDS=1 RESULTS="$OUT/general" python3 "$STUDY/general.py"
    RANK=1 ROUNDS=1 RESULTS="$OUT/rank" python3 "$STUDY/general.py"
    ANCHOR=1 ROUNDS=2 RESULTS="$OUT/anchor" python3 "$STUDY/general.py"
    RESULTS="$OUT/panel" python3 "$STUDY/values-panel.py"
    RESULTS="$OUT/search-panel" python3 "$STUDY/search-panel.py"
    RESULTS="$OUT/anchor-panel" python3 "$STUDY/anchor-panel.py"
    REPEAT=1 RESULTS="$OUT/repeat" python3 "$STUDY/anchor-panel.py"
    OBSERVE_ALL=1 VERIFY_ONLY=1 RESULTS="$OUT/admission" python3 "$STUDY/anchor-panel.py"
    RESULTS="$OUT/native" python3 "$STUDY/native-count.py"
    RESULTS="$OUT/phases" python3 "$STUDY/phases.py"
    python3 "$STUDY/summarize.py" "$OUT"

The swap mask bits in pin order select the binary tuple's second processor (1), the two unary tuples' processor (2 and 4), or the map term (8). Both original histories and all swaps include their own diagnostic lookup cost. The paired mask-zero control verifies the terms and sorts without changing a binding. Each swaps.csv row contains rotation, history, mask, actual replacements, nontrivial lemmas, lemmas after decision 595 before decision 596, check instructions and complete stage sum. The per-slot lookup compares printed live terms, rejects ambiguity, and keeps the other binding of the binary tuple in its original history. The catalog logs term, model value, generation, and whether it is the original or designated alternate for the binder. All four alternatives are tied for minimum generation and already mapped to the original model value.

The general, rank and anchor fresh.csv files record round, policy, requested counter, replacements, initial counter, check instructions and stage sum. The equality and binary trials use the model finder's evaluator. The ranking and final rule use already cached values. They each execute the full verifier with the rule restricted to the target check. The release panels apply the rule throughout verification under normal GC and measure whole-process instructions. The five-workload repeat uses seven alternating pairs on each input. For an exact rerun of the same-binary screen, anchor-panel.py overlays both the checker from 38f35fd3a and the archived helper. The direct key enumeration panel compares separate release builds.

The native profile enables qi.profile_freq=1 for batch 60 and counts profile records strictly between entry and exit of its live first check. Profiling instructions are excluded from the timing comparison. phases.py reuses the observer sources and native objects from nov27-first-push-queue-comparison.tar.xz. By default it builds the two instrumented objects against this fork and uses a temporary copy of the benchmark frontend's static library. For the original runs METER_LIB pointed to the already built check.a from that same archive. Fields C, S, R, and A represent the existing satisfaction check, binder substitution, theory rewriting and instance internalization. The flag denotes satisfied for C, cache hit for S, reduced to true for R and zero for A. Phase counts aggregate individual measurements within each check. Print overhead lies outside the individual operation intervals.
