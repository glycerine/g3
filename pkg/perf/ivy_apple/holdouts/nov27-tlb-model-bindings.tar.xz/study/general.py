import os,tarfile
from pathlib import Path
script_dir=Path(__file__).resolve().parent
def old(name):
    with tarfile.open('perf/ivy_apple/holdouts/nov27-tlb-witness-history.tar.xz') as t:return t.extractfile('study/'+name).read().decode()
ns={};exec(old('fresh.py'),ns);fresh=ns['fresh']
def rep(s):
    s=fresh(s)
    a=s.index('   cases=[(key,c)');b=s.index("     mode='indexed'",a)
    s=s[:a]+"""   cases=[('0..0',v,p) for v in range(407,415) for p in ('base','binary','equality')]
   for key,counter,policy in cases[repno:]+cases[:repno]:
"""+s[b:];s=s.replace('range(3):',"range(int(os.environ.get('ROUNDS','2'))):").replace('FRESH_AT=str(counter)','FRESH_AT=str(counter),REP=policy')
    add="""
 k=p/'smtcore/smt_model_checker.go';v=Path(rep[str(k)]).read_text();needle='bindings[i] = term';a=v.index(needle,v.index('func (c *SMTModelChecker) addFiniteCounterexample'))
 v=v[:a]+'if benchRep!=""&&benchRep!="base"&&i==1&&len(bindings)==2{term,err=c.benchRepresentative(quantifier,term,value,generation);if err!=nil{return false,err}};'+v[a:]
 put(k,v+EXTRA+'\\nfunc BenchRepMode(p string){benchRep=p;benchReplaced=0};func BenchRepCount()int{return benchReplaced}\\n')
 k=front/'phase_observer_trial.go';v=Path(rep[str(k)]).read_text().replace('func unitBegin(b,g int){','func unitBegin(b,g int){if b==60&&g==1{smtcore.BenchRepMode(os.Getenv("REP"))};').replace('func unitEnd(b,g int){','func unitEnd(b,g int){if b==60&&g==1{fmt.Fprintln(os.Stderr,"REP",smtcore.BenchRepCount());smtcore.BenchRepMode("")};');put(k,v)
"""
    s=s.replace(" j=d/'ov.json'",add.replace("v+EXTRA","v+"+repr((script_dir/('rank.go.txt' if os.environ.get('RANK') else 'representative.go.txt')).read_text()))+" j=d/'ov.json'")
    if os.environ.get('ANCHOR'):
        original=(script_dir/'representative.go.txt').read_text()
        helper=(script_dir/'anchor.go.txt').read_text().split('import "github.com/glycerine/g3/pkg/ast"')[1]
        s=s.replace(repr(original),repr('var benchRep string;var benchReplaced int\n'+helper))
        s=s.replace('term,err=c.benchRepresentative(quantifier,term,value,generation);','before:=term;term,err=c.namedSecondBinding(quantifier,bindings[0],term,value,generation);if before!=term{benchReplaced++};')
        s=s.replace("('base','binary','equality')","('base','anchor')")
    if os.environ.get('RANK'):
        s=s.replace("('base','binary','equality')","('base','more','less','class')")
    s=s.replace('else:rest.extend(l)',"elif l.startswith(b'REP '):replaced=int(a[1])\n      else:rest.extend(l)")
    s=s.replace('writerow([repno,key,counter,fresh_entry','writerow([repno,policy,counter,replaced,fresh_entry').replace("GOCACHE=str(d/'cache')","GOCACHE=os.environ.get('TRIAL_CACHE',str(d/'cache'))")
    return s
code=old('replay.py').replace('exec(compile(prefix+', 'namespace["rep"]=rep\nschedule+="    s=rep(s)\\n"\nexec(compile(prefix+')
exec(code)
