"""Compare whole-spec costs of larger bounded macro identity probes."""
from pathlib import Path
import csv, io, json, os, subprocess, sys, time

pkg=Path.cwd().resolve()
out=Path(__file__).resolve().parent
ivy=Path.home()/'ivy/goivy'
env=dict(os.environ, GOCACHE='/tmp/g3-nov23-day/cache',GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',PWD=str(ivy))
src=pkg/'ast/macros/macro_expansion_identity.go'
variants={'baseline':32,'cap64':64,'cap128':128}
for name, cap in variants.items():
    dest=out/name
    dest.mkdir(parents=True)
    (dest/'abc').symlink_to('/tmp/g3-nov22b/spec-survey/with-abc-native/abc')
    flags=[]
    if name!='baseline':
        patched=dest/src.name
        patched.write_text(src.read_text().replace('maxMacroProbeVisits = 32', f'maxMacroProbeVisits = {cap}'))
        overlay=dest/'overlay.json'
        local=Path('/home/jaten/g3/pkg') / src.relative_to(pkg)
        overlay.write_text(json.dumps({'Replace':{str(src):str(patched),str(local):str(patched)}}))
        flags=['-overlay='+str(overlay)]
    subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-tags=xtrace_off',
                    *flags,'-o',dest/'goivy_check','./cmd/goivy_check'], cwd=ivy,env=env,check=True)

reference=Path('/tmp/g3-nov24-day/archive-verifier-stacks')
cases=json.loads((reference/'cases.json').read_text())
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (out/'runs.csv').open('w') as file:
    wr=csv.writer(file)
    wr.writerow(('case','round','variant','instructions','milliseconds'))
    for case in ('hybrid','ticket_protocol','arm_rules3'):
        spec,isolate,status=cases[case]
        assert not isolate
        gold=[(reference/'reference'/case/p).read_bytes() for p in ('stdout','stderr')]
        for turn in range(5):
            labels=list(variants)
            offset=turn%len(labels)
            for name in labels[offset:]+labels[:offset]:
                dest=out/name
                counts=dest/'perf.csv'
                start=time.monotonic()
                r=subprocess.run(['taskset','-c','16',perf,'stat','-x,','-o',counts,'-e','instructions:u','--',
                                  dest/'goivy_check',Path.home()/'ivy/ivy-lang-examples'/spec],
                                 env=env,cwd=dest,capture_output=True,timeout=90)
                elapsed=(time.monotonic()-start)*1e3
                assert r.returncode==status and r.stdout==gold[0] and r.stderr==gold[1], (name,case,r.returncode,r.stderr[-700:])
                inst,=[int(row[0]) for row in csv.reader(counts.open()) if len(row)>4 and row[2]=='instructions:u']
                wr.writerow((case,turn+1,name,inst,f'{elapsed:.3f}'))
                file.flush()
        print(case,'verified',flush=True)
