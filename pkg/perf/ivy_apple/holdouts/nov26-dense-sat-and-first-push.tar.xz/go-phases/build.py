"""Instrument reduction phases on the first physical push of each solver."""
from pathlib import Path
import json, os, subprocess

pkg = Path.cwd().resolve()
pkg_import = '/home/jaten/g3/pkg'
ivy = Path.home()/'ivy/goivy'
out = Path(__file__).resolve().parent
mapping = {}
def overlay(name, src):
    p=out/Path(name).name
    p.write_bytes(subprocess.check_output(['gofmt'],input=src.encode()))
    for root in (pkg, Path(pkg_import)):
        mapping[str(root/name)]=str(p)
    return p

pkg_file='util/firstpushcounter/count.go'
for root in (pkg, Path(pkg_import)):
    mapping[str(root/pkg_file)]=str(out/'firstpushcounter.go')
counter='import "github.com/glycerine/g3/pkg/util/firstpushcounter"'
def add_import(s):
    i=s.index('\n')
    return s[:i+1]+counter+'\n'+s[i+1:]

name='smtcore/smt_asserted_driver.go'
s=add_import((pkg/name).read_text())
needle='\tif err := assertedVerbose(10, "(smt."+pass.sourceName()+")\\n"); err != nil {'
assert s.count(needle)==1
s=s.replace(needle,'\tdefer firstpushcounter.Leave(firstpushcounter.Enter("pass."+pass.sourceName()))\n'+needle)
s=s.replace('func (k *SMTKernel) reduceAssertedPending() (bool, error) {',
    'func (k *SMTKernel) reduceAssertedPending() (bool, error) {\n'
    '\tdefer firstpushcounter.Leave(firstpushcounter.Enter("reduce-asserted"))')
overlay(name,s)

name='smtcore/smt_kernel.go'
s=add_import((pkg/name).read_text())
sig='func (k *SMTKernel) internalizePending() (resultErr error) {'
assert s.count(sig)==1
s=s.replace(sig,sig+'\n\tdefer firstpushcounter.Leave(firstpushcounter.Enter("internalize-pending"))')
start=s.index(sig)
end=s.index('func (k *SMTKernel)',start+len(sig))
code=s[start:end].replace('\tif k.assertedFormulasInconsistent() {',
    '\tdefer firstpushcounter.Leave(firstpushcounter.Enter("internalize-and-commit"))\n\tif k.assertedFormulasInconsistent() {',1)
overlay(name,s[:start]+code+s[end:])

name='ast/rewriter/rewriter_engine.go'
s=add_import((pkg/name).read_text())
start=s.index('func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32)')
end=s.index('func (r *rewriterEngine) ',start+10)
code=s[start:end]
for mark, event in [('\tif r.substituteVariables {','Visit'),('\t\th, e := c.getCached(t)','CacheLookup'),('\t\t\tif e = r.sameSort(t, h); e != nil {','CacheHit')]:
    assert code.count(mark)==1
    code=code.replace(mark, '\tfirstpushcounter.Count(firstpushcounter.'+event+')\n'+mark)
overlay(name,s[:start]+code+s[end:])

name='ast/rewriter/th_rewriter.go'
s=add_import((pkg/name).read_text())
s=s.replace('\tvar dependency ast.ASTDependency\n\tfound, err := c.owner.manager.ExprSubstitutionFindDependency',
    '\tvar dependency ast.ASTDependency\n\tfirstpushcounter.Count(firstpushcounter.SubstitutionLookup)\n\tfound, err := c.owner.manager.ExprSubstitutionFindDependency',1)
s=s.replace('\tif err != nil || !found || dependency.IsNull() {','\tif found {firstpushcounter.Count(firstpushcounter.SubstitutionHit)}\n\tif err != nil || !found || dependency.IsNull() {',1)
sig='func (c *theoryRewriterConfiguration) reduceAppCore(decl ast.ASTHandle, args ast.AppArguments, out ast.ASTRef) (RewriteStatus, error) {'
assert s.count(sig)==1
s=s.replace(sig,sig+'\n\tfirstpushcounter.Count(firstpushcounter.TheoryReducer)')
overlay(name,s)

input_file=out.parent/'z3bridge_solver_model.go'
mapping[str(ivy/input_file.name)]=str(input_file)
name='z3bridge_first_push_profile.go'
p=out/name
p.write_text('''package goivy
import "github.com/glycerine/g3/pkg/util/firstpushcounter"
var profileBatchNumber int
func nextProfileBatch() int {profileBatchNumber++;return profileBatchNumber}
func recordFirstPush(batch int) func() {return firstpushcounter.Begin(batch)}
''')
mapping[str(ivy/name)]=str(p)
ov=out/'overlay.json'
ov.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-tags=xtrace_off',
                '-overlay='+str(ov),'-o',str(out/'goivy_check'),'./cmd/goivy_check'],cwd=ivy,
                env=dict(os.environ,PWD=str(ivy),GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
