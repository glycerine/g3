package firstpushcounter

import (
	"fmt"
	"os"
	"runtime"
	"sort"
	"syscall"
	"unsafe"
)

var fd uintptr
var active bool
var empty uint64
var rows map[string]row
var events [6]uint64

type row struct {
	calls, instructions uint64
}
type Interval struct {
	name  string
	start uint64
}

const (
	Visit = iota
	CacheLookup
	CacheHit
	SubstitutionLookup
	SubstitutionHit
	TheoryReducer
)

func read() uint64 {
	var data [3]uint64
	n, _, err := syscall.RawSyscall(syscall.SYS_READ, fd, uintptr(unsafe.Pointer(&data[0])), unsafe.Sizeof(data))
	if err != 0 || n != unsafe.Sizeof(data) || data[1] != data[2] {
		panic("cannot read the unscaled solver thread counter")
	}
	return data[0]
}

func Begin(batch int) func() {
	runtime.LockOSThread()
	var attr struct {
		Type, Size                                    uint32
		Config, Period, SampleType, ReadFormat, Flags uint64
		Reserved                                      [16]byte
	}
	attr.Size = uint32(unsafe.Sizeof(attr))
	attr.Config = 1
	attr.ReadFormat = 3
	attr.Flags = 1<<5 | 1<<6
	var err syscall.Errno
	fd, _, err = syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN, uintptr(unsafe.Pointer(&attr)), 0, ^uintptr(0), ^uintptr(0), 0, 0)
	if err != 0 {
		panic(err)
	}
	rows = make(map[string]row, 24)
	clear(events[:])
	lo := read()
	empty = read() - lo
	active = true
	whole := Enter("whole")
	return func() {
		Leave(whole)
		active = false
		syscall.Close(int(fd))
		runtime.UnlockOSThread()
		var keys []string
		for name := range rows {
			keys = append(keys, name)
		}
		sort.Strings(keys)
		for _, name := range keys {
			r := rows[name]
			fmt.Fprintln(os.Stderr, "FIRST-PUSH-PHASE", batch, name, r.calls, r.instructions, empty)
		}
		fmt.Fprintln(os.Stderr, "FIRST-PUSH-COUNT", batch, events)
	}
}

func Count(event int) {
	if active {
		events[event]++
	}
}
func Enter(name string) Interval {
	if !active {
		return Interval{}
	}
	return Interval{name: name, start: read()}
}
func Leave(t Interval) {
	if t.name == "" {
		return
	}
	amount := read() - t.start
	r := rows[t.name]
	r.calls++
	if amount > empty {
		r.instructions += amount - empty
	}
	rows[t.name] = r
}
