"""Compare matched CNF search for three independent propagation changes."""
import csv, io, os, re, subprocess, sys, time
from pathlib import Path

pkg = Path.cwd()
out = Path(__file__).resolve().parent
base = out.parent
sys.path.insert(0, str(pkg/'perf/ivy_raft'))
from watch_propagation import check_output
env = dict(os.environ, GOMAXPROCS='1')
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
engines = {'baseline': base/'repair-final'/'g3', 'z3': pkg.parent/'build/z3'}
engines.update((name, out/name) for name in ('trail','finish','ternary','combined'))
inputs = [(base/'repair-adaptive'/'unseen'/(name+'.cnf'), 'sat') for name in ('w3-n330-112','w3-n330-2309','w3-n330-721')]
inputs += [(base/'repair-final'/'hidden-contradiction-8.cnf','unsat')]
with (out/'cases.csv').open('w') as stream:
    write = csv.writer(stream)
    keys = ('conflicts','decisions','propagations','ternary-propagations','binary-propagations')
    write.writerow(('case','engine','round','answer','instructions','milliseconds',*keys))
    for file, status in inputs:
        source = file.read_text().splitlines()
        n = int(source[0].split()[2])
        clauses = [[int(l) for l in line.split()[:-1]] for line in source[1:]]
        expected = None
        for turn in range(7):
            offset = turn%len(engines)
            labels = list(engines)
            for label in labels[offset:]+labels[:offset]:
                start = time.monotonic()
                run = subprocess.run(['taskset','-c','12',perf,'stat','-x,','-e','instructions:u','--',
                                      engines[label],'-st','-dimacs',file],env=env,
                                     capture_output=True,text=True,check=True,timeout=60)
                elapsed=(time.monotonic()-start)*1e3
                check_output(run.stdout, status, n, clauses)
                stats=dict(re.findall(r':([\w-]+)\s+(\d+)\b',run.stdout))
                values=tuple(stats.get(k,'0') for k in keys)
                if expected is None:
                    expected = values
                if values != expected:
                    raise RuntimeError((file,label,values,expected))
                inst, = [int(row[0]) for row in csv.reader(io.StringIO(run.stderr)) if len(row)>2 and row[2]=='instructions:u']
                write.writerow((file.stem,label,turn+1,status,inst,f'{elapsed:.3f}',*values))
                stream.flush()
        print(file.name,'verified',flush=True)
