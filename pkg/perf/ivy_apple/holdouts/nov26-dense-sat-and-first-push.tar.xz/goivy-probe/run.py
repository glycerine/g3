"""Sample the three costliest hybrid first pushes using the same GoIvy source."""
from pathlib import Path
import argparse
import json, os, subprocess

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--cpu', default='18')
p.add_argument('--rounds', type=int, default=5)
p.add_argument('--batches', default='31,32,33')
p.add_argument('--spec', default='hybrid')
p.add_argument('--label', default='profile')
p.add_argument('--period', default='1000003')
args = p.parse_args()

out = Path(__file__).resolve().parent
reference = Path('/tmp/g3-nov24-day/archive-verifier-stacks')
spec, isolate, status = json.loads((reference/'cases.json').read_text())[args.spec]
assert not isolate
spec = Path.home()/'ivy/ivy-lang-examples'/spec
gold = [(reference/'reference'/args.spec/name).read_bytes() for name in ('stdout','stderr')]
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
env = dict(os.environ, GOMAXPROCS='1', GOGC='100', XTRACE_OFF='1', G3_FIRST_PUSH_BATCHES=args.batches)
for turn in range(1, args.rounds+1):
    for engine in (('g3','native') if turn%2 else ('native','g3')):
        run = out/(args.spec+'-'+args.label)/f'{turn}-{engine}'
        run.mkdir(parents=True)
        ctl, ack = run/'ctl', run/'ack'
        os.mkfifo(ctl)
        os.mkfifo(ack)
        perf_data = run/'perf.data'
        proc = subprocess.run(['taskset','-c',args.cpu,perf,'record','-B','-N','-D','-1',
                               '--control',f'fifo:{ctl},{ack}', '-o',perf_data,
                               '-e','instructions:u','-c',args.period,'--call-graph','fp',
                               '--',out/engine/'goivy_check',spec], env=dict(env,G3_PERF_CONTROL=str(ctl),G3_PERF_ACK=str(ack)),
                              cwd=out/engine, capture_output=True, timeout=90)
        (run/'stdout').write_bytes(proc.stdout)
        (run/'stderr').write_bytes(proc.stderr)
        stages = []
        stderr = []
        for line in proc.stderr.splitlines(keepends=True):
            if line.startswith(b'PROFILE-FIRST-PUSH '):
                stages.append(line.decode().split()[-1])
            elif not line.startswith((b'[ perf record:', b'Events ')):
                stderr.append(line)
        if proc.returncode!=status or proc.stdout!=gold[0] or b''.join(stderr)!=gold[1] or ','.join(stages)!=args.batches:
            raise RuntimeError((proc.returncode, stages, b''.join(stderr)[-1000:]))
        with (run/'leaf.txt').open('w') as f:
            subprocess.run([perf,'report','--stdio','--no-children','--percent-limit','0.1',
                            '--show-nr-samples','-g','none','-i',perf_data], check=True, stdout=f)
        with (run/'inclusive.txt').open('w') as f:
            subprocess.run([perf,'report','--stdio','--children','--percent-limit','0.5',
                            '--show-nr-samples','-g','none','-i',perf_data], check=True, stdout=f)
        raw = subprocess.run([perf,'script','-D','-G','-i',perf_data],check=True,capture_output=True).stdout
        throttle = raw.count(b'PERF_RECORD_THROTTLE')
        (run/'throttle.txt').write_text(str(throttle)+'\n')
        if throttle:
            raise RuntimeError((args.batches,engine,'throttling',throttle))
        print(args.spec, turn, engine, stages, flush=True)
