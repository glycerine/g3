package goivy

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

var profileBatchNumber int

func nextProfileBatch() int {
	profileBatchNumber++
	return profileBatchNumber
}

func recordFirstPush(batch int) func() {
	if !strings.Contains(","+os.Getenv("G3_FIRST_PUSH_BATCHES")+",", ","+strconv.Itoa(batch)+",") {
		return func() {}
	}
	ctl, err := os.OpenFile(os.Getenv("G3_PERF_CONTROL"), os.O_RDWR, 0)
	if err != nil {
		panic(err)
	}
	ack, err := os.OpenFile(os.Getenv("G3_PERF_ACK"), os.O_RDWR, 0)
	if err != nil {
		panic(err)
	}
	read := bufio.NewReader(ack)
	send := func(command string) {
		if _, err := fmt.Fprintln(ctl, command); err != nil {
			panic(err)
		}
		line, err := read.ReadString('\n')
		if err != nil || strings.TrimLeft(line, "\x00") != "ack\n" {
			panic(fmt.Sprintf("perf %s: %q %v", command, line, err))
		}
	}
	send("enable")
	return func() {
		send("disable")
		ctl.Close()
		ack.Close()
		fmt.Fprintln(os.Stderr, "PROFILE-FIRST-PUSH", batch)
	}
}
