from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();o=json.loads(Path('/tmp/g3-selective/final/overlay.json').read_text());ov=o['Replace'];k=f/'z3bridge_solver_model.go';s=Path(ov[str(k)]).read_text()
i=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('if finalCond != nil',i);head,tail=s[:i],s[i:]
a='z3solver.Assert(zc)';assert a in tail;tail=tail.replace(a,'''var rank *smt.RankTrial
 if len(finalCond)==1 && os.Getenv("TRY_RANK")=="1"{rank=z3solver.TryRank(zc);zc=rank.Expr(zc)}
 '''+a,1)
tail=tail.replace('finalCheck := check','zCond=rank.Expr(zCond)\n finalCheck := check',1)
dst=w/'live-bridge.go.txt';dst.write_text(head+tail);ov[str(k)]=str(dst);ov[str(f/'smt/rank_trial.go')]=str(w/'live.go.txt');j=w/'live.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',j,'-o',w/'live','./cmd/goivy_check'],cwd=f,check=True)
