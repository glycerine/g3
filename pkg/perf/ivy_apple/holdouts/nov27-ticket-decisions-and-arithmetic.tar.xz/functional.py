from encode import parse,Terms,render,w,src,keys
from pathlib import Path
import collections,subprocess,os,csv,re
keys=keys+['8-12-8','8-14-8','8-16-1']
def function(e):
 if not isinstance(e,list) or len(e)!=3 or e[0]!='forall' or len(e[1])!=3:return
 body=e[2]
 if not isinstance(body,list) or len(body)!=3 or body[0]!='=>':return
 cond,out=body[1:]
 if not isinstance(out,list) or len(out)!=3 or out[0]!='=' or not isinstance(cond,list) or len(cond)!=3 or cond[0]!='and':return
 a,b=cond[1:]
 if not isinstance(a,list) or not isinstance(b,list) or len(a)!=3 or len(b)!=3 or a[0]!=b[0]:return
 r,x,y=a
 if not all(isinstance(z,str) for z in [r,x,y,*b]):return
 if b==[r,x,out[2]] and y==out[1] and len({x,y,out[2]})==3 and {n for n,_ in e[1]}=={x,y,out[2]}:return r
def make(txt,mode):
 forms=parse(txt);t=Terms();base=next(c[1] for c in forms if c[0]=='assert');rels={function(parse(t.render(n))[0]) for n in t.conjuncts(t.expand(base,{}))}-{None};assert rels
 decls={};out=[]
 def rec(e):
  if function(e) in rels:return 'true'
  return [rec(x) for x in e] if isinstance(e,list) else e
 for c in forms:
  if c[0]=='declare-sort' and len(c)==2:c=c+['0']
  if c[0]=='declare-fun' and c[1] in rels and mode!='base':
   _,r,ss,ret=c;x,y=ss;assert ret=='Bool'
   i=len(decls);decls[r]=i;v='study-fn-'+str(i);d='study-set-'+str(i);assert d not in txt and v not in txt
   out.extend([['declare-fun',v,[x],y],['declare-fun',d,[x] if mode=='partial' else ss,'Bool']])
   c=['define-fun',r,[['x',x],['y',y]],'Bool',['and',[d,'x'] if mode=='partial' else [d,'x','y'],['=',[v,'x'],'y']]]
  elif c[0]=='assert' and mode!='base':c=['assert',rec(c[1])]
  out.append(c)
 return '\n'.join(map(render,out))+'\n'
if __name__=='__main__':
 for shape in ['fresh','incremental']:
  d=w/('function-'+shape);d.mkdir(exist_ok=True)
  for key in keys:
   txt=(src/key.split('-')[0]/(key+'.smt2')).read_text()
   for mode in ['base','partial','guard']:
    val=make(txt,mode)
    if shape=='incremental':
     i=val.rindex('\n(assert ');val=val[:i]+'\n(push 1)'+val[i:]
    (d/(key+'-'+mode+'.smt2')).write_text(val)
  s=(w/'encode.py').read_text().split("if __name__=='__main__':")[1].replace("choices=['base','diagonal','rank']","choices=['base','partial','guard']").replace("'encoded.csv'",repr('function-'+shape+'.csv'))
  exec('if True:'+s)
