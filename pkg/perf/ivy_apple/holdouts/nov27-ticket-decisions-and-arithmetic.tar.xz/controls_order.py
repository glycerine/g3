from pathlib import Path
import itertools,csv,subprocess
from image import image
from encode import make,w
decl='(declare-sort U 0)(declare-fun r (U U) Bool)(declare-fun a () U)(declare-fun b () U)(declare-fun c () U)'
refl='(assert (forall ((x U)) (r x x)))'
trans='(assert (forall ((x U)(y U)(z U)) (=> (and (r x y)(r y z)) (r x z))))'
total='(assert (forall ((x U)(y U)) (or (r x y)(r y x))))'
anti='(assert (forall ((x U)(y U)) (=> (and (r x y)(r y x)) (= x y))))'
with (w/'order-controls.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case mode engine status'.split())
 for name,ax,goal,want in [('chain',anti,'(and (distinct a b c) (r a b) (r b c))','sat'),('cycle',anti,'(and (distinct a b c) (r a b) (r b c) (r c a))','unsat'),('equivalent','true','(and (distinct a b) (r a b) (r b a))','sat'),('no upper bound','true','(forall ((x U)) (exists ((y U)) (not (r y x))))','open')]:
  txt=decl+'(assert (and '+refl[8:-1]+' '+trans[8:-1]+' '+total[8:-1]+' '+(ax if ax=='true' else ax[8:-1])+'))\n(assert '+goal+')\n(check-sat)'
  for mode in ['base','diagonal','rank']+(['image'] if ax==anti else []):
   src=image(txt) if mode=='image' else make(txt,mode)
   for lab,exe in [('g3',w/'g3-cli'),('z3',Path.cwd().parent/'build/z3')]:
    try:
     r=subprocess.run([exe,'-in','-smt2'],input=src,text=True,timeout=0.8,capture_output=True);assert not r.returncode and not r.stderr,(r.returncode,r.stderr,r.stdout);ans=r.stdout.strip()
    except subprocess.TimeoutExpired:ans='timeout'
    assert ans==want or want=='open' and ans in ('sat','unknown','timeout'),(name,mode,ans)
    out.writerow([name,mode,lab,ans]);f.flush()
with (w/'finite-orders.csv').open('w') as f:
 out=csv.writer(f);out.writerow('size relations total_preorders total_orders'.split())
 for n in range(1,5):
  dom=range(n);pairs=list(itertools.product(dom,repeat=2));models=set(sum(1<<i for i,(x,y) in enumerate(pairs) if rank[x]<=rank[y]) for rank in itertools.product(dom,repeat=n));found=linear=0
  for m in range(1<<(n*n)):
   le=lambda x,y: bool(m & (1<<(x*n+y)))
   pre=all(le(x,y) or le(y,x) for x,y in pairs) and all(not (le(x,y) and le(y,z)) or le(x,z) for x,y,z in itertools.product(dom,repeat=3))
   assert pre==(m in models)
   if pre:found+=1;linear+=all(x==y or not(le(x,y) and le(y,x)) for x,y in pairs)
  out.writerow([n,1<<(n*n),found,linear])
