from pathlib import Path
import csv,statistics as s,collections
w=Path(__file__).resolve().parent
for name in ['policies','ground','confirm','meter']:
 f=w/(name+'.csv')
 if not f.exists():continue
 print(name);d=collections.defaultdict(dict)
 for r in csv.DictReader(f.open()):d[r.get('case',r.get('goal'))].setdefault(r['mode'],[]).append(int(r['instructions']))
 for c,ms in d.items():
  a=next(iter(ms.values()))
  print(c,[(k,len(v),round(s.median(v)/1e6,2),round(s.median((y/x-1)*100 for x,y in zip(a,v)),2)) for k,v in ms.items()])
