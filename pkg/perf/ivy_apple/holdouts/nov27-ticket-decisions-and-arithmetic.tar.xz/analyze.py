from pathlib import Path
import collections,csv,re,sys
w=Path(__file__).resolve().parent
old=Path('/tmp/g3-ticket-search')
def norm(t,names):
 t=re.sub(r'([^()\s!]+)!\d+(?=[()\s]|$)',lambda m:m[1]+'!@'+str(names.setdefault(m[0],len(names))),t)
 stack=[[]]
 for tok in re.findall(r'\(|\)|[^()\s]+',t):
  if tok=='(':stack.append([])
  elif tok==')':
   a=stack.pop()
   if a[0]=='=' and len(a)==3:a[1:]=sorted(a[1:])
   stack[-1].append('('+' '.join(a)+')')
  else:stack[-1].append(tok)
 return ' '.join(stack[0])
def read(mode):
 path=(old/'z3-search-events.csv') if mode=='native' else w/(mode+'.csv')
 ret=[];names=collections.defaultdict(dict)
 for r in csv.DictReader(path.open()):
  if mode=='native' and (r['batch'],r['goal'])!=('4','55'):continue
  k=r['event']
  if k not in ['offer','formula','split']:continue
  value=r['value']
  if k=='split':value=value.split(' ',1)[1]
  ret.append((k,norm(value,names[k]),r['value']))
 return ret
def compare(a,b):
 x=read(a);y=read(b)
 print('\n',a,b)
 for k in [None,'split','offer','formula']:
  p=[v for v in x if k is None or v[0]==k];q=[v for v in y if k is None or v[0]==k]
  pos=next((i for i,(l,r) in enumerate(zip(p,q)) if l[:2]!=r[:2]),min(len(p),len(q)))
  print('stream',k,'counts',len(p),len(q),'prefix',pos)
  if pos<min(len(p),len(q)):
   if k is None:print('preceded by',collections.Counter(z[0] for z in p[:pos]))
   for v in [p[pos],q[pos]]: print(' ',v[0],v[2][:220])
if __name__=='__main__':
 for mode in sys.argv[1:]: compare(*mode.split(':'))
