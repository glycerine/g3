from pathlib import Path
import concurrent.futures,subprocess,os,csv,statistics as st,collections
w=Path(__file__).resolve().parent;rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines()
p=w/'validation/verified'
def panel(i):
 env=dict(os.environ,STEM='native'+str(i),CPU=str(1+2*i),CASES=' '.join(str(x) for x in range(i+1,len(cases)+1,6)),ROUNDS='1',MODES='native');subprocess.run(['python3',p/'verify.py'],env=env,check=True)
with concurrent.futures.ThreadPoolExecutor(6) as pool:list(pool.map(panel,range(6)))
def read(stem):
 data={r['case']:r for f in sorted(p.glob(stem+'*.csv')) for r in csv.DictReader(f.open())}
 assert set(data)==set(cases) and all(r['status']=='match' for r in data.values())
 return data
a,b=read('panel'),read('native')
with (w/'inventory.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case g3_instructions native_instructions instruction_gap g3_ms native_ms'.split())
 for c in sorted(cases,key=lambda k:int(b[k]['instructions'])-int(a[k]['instructions'])):o.writerow([c,int(a[c]['instructions']),int(b[c]['instructions']),int(a[c]['instructions'])-int(b[c]['instructions']),a[c]['ms'],b[c]['ms']])
