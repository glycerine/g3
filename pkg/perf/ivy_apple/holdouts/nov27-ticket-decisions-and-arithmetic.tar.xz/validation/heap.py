from pathlib import Path
import csv,json,os,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();main=front/'cmd/goivy_check/main.go'
configs={'base':'base.json','delta':'delta.json','prefix':'prefix.json','views':'views-verify.json','packed':'packed-verify.json','leaves':'leaves-verify.json','rollback':'rollback.json'}
modes=sys.argv[1:] or list(configs)
with (w/(os.getenv('STEM','alloc')+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('mode case round total_bytes objects collections live'.split())
 for m in modes:
  j=w/(m+'-alloc.json');ov=json.loads((w/configs.get(m,m+'.json')).read_text());ov['Replace'][str(main)]=str(Path('/tmp/g3-selective/final/heap-main.go.txt'));j.write_text(json.dumps(ov))
  subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/(m+'-alloc'),'./cmd/goivy_check'],cwd=front,check=True)
  ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');names=(rank/'compat.txt').read_text().splitlines()
  for nr in [2,3,4,12]:
   name=names[nr-1];ref=rank/'compat'/str(nr)/'1/native'
   for i in range(3):
    r=subprocess.run(['taskset','-c','10',w/(m+'-alloc'),ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOGC='100',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,check=True)
    ls=r.stderr.splitlines(keepends=True);assert r.stdout==(ref/'stdout').read_bytes() and b''.join(l for l in ls if not l.startswith(b'HEAP-STUDY '))==(ref/'stderr').read_bytes()
    v,=[l.decode().split()[1:] for l in ls if l.startswith(b'HEAP-STUDY ')];out.writerow([m,name,i,*v]);f.flush()
