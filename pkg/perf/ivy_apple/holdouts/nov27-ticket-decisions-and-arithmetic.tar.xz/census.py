from pathlib import Path
import os,subprocess,csv
w=Path(__file__).resolve().parent;rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');names=(rank/'compat.txt').read_text().splitlines()
with (w/'census.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case mode observations'.split())
 for nr in [3,6,8,12,2,4]:
  for mode in ['constants','seen','ranked']:
   ref=rank/'compat'/str(nr)/'1/native';r=subprocess.run([w/mode,ex/names[nr-1]],cwd=w,env=dict(os.environ,GOMAXPROCS='1',TRY_RANK='1',REPORT_DIAG='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=45)
   lines=r.stderr.splitlines(keepends=True);assert (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith((b'GROUND ',b'RANK '))))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
   o.writerow([names[nr-1],mode,';'.join(l.decode().strip() for l in lines if l.startswith((b'GROUND ',b'RANK ')))]);f.flush()
