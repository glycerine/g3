from analyze import read
from pathlib import Path
from collections import Counter
import csv,re
w=Path(__file__).resolve().parent
def quant(tree):
 i=tree.find('(forall')
 if i<0:return '(unclassified)'
 n=0
 for j in range(i,len(tree)):
  n+=(tree[j]=='(')-(tree[j]==')')
  if n==0:return re.sub(r'!@\d+','!fresh',tree[i:j+1])
with (w/'families.csv').open('w') as f:
 out=csv.writer(f);out.writerow('mode event quantifier count'.split())
 for mode in ['release','forced','ordinary','native','early','siblingchoice']:
  counts=Counter((k,quant(t)) for k,t,v in read(mode) if k in ['offer','formula'])
  for (k,t),n in counts.items():out.writerow([mode,k,t,n])
rows=list(csv.DictReader((w/'families.csv').open()))
for k in ('offer','formula'):
 by=lambda mode:Counter({r['quantifier']:int(r['count']) for r in rows if r['event']==k and r['mode']==mode})
 a,b=by('release'),by('native')
 for t,n in (a-b).most_common(5):print(k,n,a[t],b[t],t[:240])
