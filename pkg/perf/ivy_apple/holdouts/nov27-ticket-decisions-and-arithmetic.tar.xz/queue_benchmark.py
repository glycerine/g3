from pathlib import Path
import csv,subprocess,re,os
w=Path(__file__).resolve().parent
with (w/'queue.csv').open('w') as f:
 o=csv.writer(f);o.writerow('round mode benchmark ns instructions'.split())
 for i in range(9):
  for width,pos in [(4,'First'),(4,'Last'),(16,'First'),(16,'Last')]:
   for mode in ['old','new'][::1 if i%2==0 else -1]:
    st=w/'queue.stat';b=f'BenchmarkSMTQuantifierCandidate/Width{width}/{pos}/Queue';r=subprocess.run(['taskset','-c','24','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-e','instructions:u','-o',st,'--',w/('queue-'+mode+'.test'),'-test.run=^$','-test.bench=^'+b.replace('/','$/^')+'$','-test.benchtime=120000x'],capture_output=True,env=dict(os.environ,GOMAXPROCS='1'),check=True);match=re.search(rb'120000\s+([\d.]+) ns/op\s+0 B/op\s+0 allocs/op',r.stdout);assert match,r.stdout[-700:]
    ins=next(int(z[0]) for z in csv.reader(st.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100)
    o.writerow([i,mode,b,float(match[1]),ins]);f.flush()
