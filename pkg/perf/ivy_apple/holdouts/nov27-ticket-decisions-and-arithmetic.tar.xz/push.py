from image import *
import subprocess,os,re
d=w/'pushed';d.mkdir(exist_ok=True)
for key in keys:
 for mode in ['base','rank','image','diagonal']:
  txt=(w/'encoded'/(key+'-'+mode+'.smt2')).read_text()
  idx=txt.rindex('\n(assert ')
  (d/(key+'-'+mode+'.smt2')).write_text(txt[:idx]+'\n(push 1)'+txt[idx:])
s=(w/'encode.py').read_text().split("if __name__=='__main__':")[1].replace("choices=['base','diagonal','rank']","choices=['base','rank','image','diagonal']").replace("'encoded.csv'","'pushed.csv'")
exec('if True:'+s)
