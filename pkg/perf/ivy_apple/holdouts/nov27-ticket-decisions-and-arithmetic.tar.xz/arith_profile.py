from pathlib import Path
import csv,os,re,subprocess,collections,sys
w=Path(__file__).resolve().parent; ex=Path('/home/jaten/ivy/ivy-lang-examples'); ref=Path('/tmp/g3-reduction-rows/compat')
names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOGC='100',GOIVY_INCLUDE=str(ex/'ivy/include'),DEBUGINFOD_URLS='')
codes={r['spec']:int(r['exit']) for f in ref.glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
engine=sys.argv[1];exe=w/'validation/final' if engine=='g3' else Path('/tmp/g3-flash-marginal/abc-control/native')
with (w/('stacks-'+engine+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow(['case','round','period','count','stack'])
 for i in range(3):
  for n in [14, 15]:
   name=names[n-1];gold=ref/str(n)/'1/native';period=1000003+100*i; data=w/('perf-'+engine+'.data')
   r=subprocess.run(['taskset','-c',sys.argv[2],perf,'record','-B','-N','-q','-e','instructions:u','-c',str(period),'--call-graph',('fp,48' if engine=='g3' else 'dwarf,8192'),'-o',data,exe,ex/name],env=env,cwd=Path('/tmp/g3-frame-child'),capture_output=True)
   assert (r.returncode,r.stdout,r.stderr)==(codes[name],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(name,r.stderr[:400])
   raw=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',data],env=env,text=True)
   tally=collections.Counter()
   for sample in raw.strip().split('\n\n'):
    lines=sample.splitlines()
    if len(lines)>1:
     tally['\n'.join(re.sub(r'^\s*[0-9a-f]+\s+','',x).strip() for x in lines[1:])]+=1
   assert sum(tally.values())>100
   for stack,count in tally.items():out.writerow((n,i,period,count,stack))
   f.flush()
