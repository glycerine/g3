from pathlib import Path
import json,os,subprocess,csv
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();o=json.loads((w/'overlay.json').read_text());ov=o['Replace']
def src(k):return Path(ov[str(k)]).read_text()
def save(k,s):dst=w/('meter-'+k.name+'.txt');dst.write_text(s);ov[str(k)]=str(dst)
k=f/'z3bridge_solver_model.go';s=src(k).replace('if batch==4 && index==54{smtcore.TrialActive=true;println("TRACE start")}','''target:=batch==4 && (index==54 || index==16)
 var end func(string);if target{end=startStage(batch,index+1)}
 smtcore.TrialActive=batch==4 && index==54''').replace('if batch==4 && index==54{smtcore.TrialActive=false;println("TRACE stop")}','smtcore.TrialActive=false;if target{end("check")}');save(k,s);ov[str(f/'phase_observer_trial.go')]='/tmp/g3-live-numeral/ticket/phase_observer_trial.go.txt'
for file in ['smt_quantifier_manager.go','smt_search.go','smt_qi_queue_schedule.go']:del ov[str(p/'smtcore'/file)]
k=p/'smtcore/smt_activity_heap_queue.go';s=src(k).replace('println("TRACE force",trialPop,v,witnessTree(q.state.manager,q.state.boolExpr[v]));','');save(k,s+'\nvar TrialActive bool\n')
j=w/'meter.json';j.write_text(json.dumps(o));subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',j,'-o',w/'meter','./cmd/goivy_check'],cwd=f,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');name=(rank/'compat.txt').read_text().splitlines()[2];ref=rank/'compat/3/1/native'
with (w/'meter.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round mode goal instructions'.split());modes=['release','early','siblingchoice','forced','ordinary']
 for i in range(7):
  for mode in modes[i%5:]+modes[:i%5]:
   r=subprocess.run(['taskset','-c','22',w/'meter',ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),MODE=mode,FORCE_VAR='142' if mode in ('early','siblingchoice') else '0',FORCE_POP={'early':'3','siblingchoice':'4'}.get(mode,'0')),capture_output=True,timeout=45);err=bytearray();seen=set()
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'STAGE-COUNT '):
     _,batch,goal,phase,n,empty,en,active,ns=l.split();assert en==active and batch==b'4';seen.add(goal);out.writerow([i,mode,goal.decode(),int(n)])
    else:err.extend(l)
   assert seen=={b'17',b'55'} and (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),err[:1500];f.flush()
