from pathlib import Path
import csv,json,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();o=json.loads(Path('/tmp/g3-selective/final/overlay.json').read_text());ov=o['Replace'];k=f/'z3bridge_solver_model.go';s=Path(ov[str(k)]).read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');h,t=s[:i],s[i:];a='s.showVCsBase(clauses)';t=t.replace(a,a+'\n batch:=newStageBatch()',1)
for key,wrap in [('if proveGoal(zCond) {','stop:=startStage(batch,index+1);proved:=proveGoal(zCond);stop("early");if proved{'),('z3solver.Push()','stop:=startStage(batch,index+1);z3solver.Push();stop("push")'),('res, err := s.decideZ3With(z3solver, finalCheck)','stopCheck:=startStage(batch,index+1);res, err := s.decideZ3With(z3solver, finalCheck);stopCheck("check")')]:assert key in t;t=t.replace(key,wrap,1)
t=t.replace('stopCheck:=startStage(batch,index+1);','finalCheck=z3solver.Check;stopCheck:=startStage(batch,index+1);',1);dst=w/'ordinary-arith-stage.go.txt';dst.write_text(h+t);ov[str(k)]=str(dst);ov[str(f/'phase_observer_trial.go')]='/tmp/g3-live-numeral/ticket/phase_observer_trial.go.txt';j=w/'ordinary-arith.json';j.write_text(json.dumps(o))
for eng in ['ordinary']:
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off'+(',classic_z3' if eng=='native' else ''),'-overlay',j,'-o',w/('arith-stage-'+eng),'./cmd/goivy_check'],cwd=f,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');names=(rank/'compat.txt').read_text().splitlines()
with (w/'ordinary-arith.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case engine round batch goal phase instructions'.split())
 for nr in [14,15]:
  ref=rank/'compat'/str(nr)/'1/native';status=int(next(r for r in csv.DictReader((rank/'ranking.csv').open()) if r['case']==names[nr-1])['exit'])
  for i in range(5):
   for eng in ['ordinary']:
    r=subprocess.run(['taskset','-c','20',w/('arith-stage-'+eng),ex/names[nr-1]],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=30);other=bytearray()
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'STAGE-COUNT '):
      _,b,g,ph,n,empty,en,active,ns=l.decode().split();assert en==active;o.writerow([names[nr-1],eng,i,b,g,ph,n])
     else:other.extend(l)
    assert (r.returncode,r.stdout,other)==(status,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(eng,other[-350:]);f.flush()
