from pathlib import Path
import os,subprocess,csv,json
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();o=json.loads((w/'live.json').read_text());ov=o['Replace'];k=f/'z3bridge_solver_model.go';s=Path(ov[str(k)]).read_text();start=s.index('func (s *Solver) GetSmallModelWithCond(');head,tail=s[:start],s[start:];a='s.showVCsBase(clauses)';tail=tail.replace(a,a+'\n batch:=newStageBatch();if len(finalCond)==1{stop:=startStage(batch,1);defer stop("whole-batch")}',1)
s=head+tail;dst=w/'liveprice-bridge.go.txt';dst.write_text(s);ov[str(k)]=str(dst);ov[str(f/'phase_observer_trial.go')]='/tmp/g3-live-numeral/ticket/phase_observer_trial.go.txt';j=w/'liveprice.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',j,'-o',w/'liveprice','./cmd/goivy_check'],cwd=f,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');names=(rank/'compat.txt').read_text().splitlines()
with (w/'liveprice.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case round mode batch quantifiers instructions'.split())
 for nr in [6,3,12]:
  ref=rank/'compat'/str(nr)/'1/native'
  for i in range(5):
   for mode in [i%2,1-i%2]:
    r=subprocess.run(['taskset','-c','24',w/'liveprice',ex/names[nr-1]],cwd=w,env=dict(os.environ,TRY_RANK=str(mode),GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',REPORT_DIAG='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=45)
    err=bytearray();q=0
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'RANK eligible '):q=int(l.split()[-1])
     elif l.startswith(b'STAGE-COUNT '):
      _,b,g,ph,ins,empty,en,active,ns=l.split();assert en==active;out.writerow([names[nr-1],i,mode,int(b),q,int(ins)]);q=0
     else:err.extend(l)
    assert (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
