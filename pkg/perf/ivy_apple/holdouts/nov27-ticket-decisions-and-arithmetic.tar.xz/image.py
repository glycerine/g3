from pathlib import Path
import itertools,csv,statistics as st
from encode import parse,Terms,render,family,w,src,keys
def image(text):
 forms=parse(text);terms=Terms();base=next(c[1] for c in forms if c[0]=='assert')
 candidates=[parse(terms.render(n))[0] for n in terms.conjuncts(terms.expand(base,{}))]
 total={a[0] for e in candidates if (a:=family(e)) and a[1]=='total'}
 rel,=[r for r in total if all(any(family(c)==(r,k) for c in candidates) for k in ('reflexive','transitive'))]
 T,=set(next(c[2] for c in forms if c[:2]==['declare-fun',rel]))
 def anti(e):
  if not isinstance(e,list) or len(e)!=3 or e[0]!='forall' or len(e[1])!=2:return False
  x,y=[v[0] for v in e[1]]
  return all(v[1]==T for v in e[1]) and e[2]==['=>',['and',[rel,x,y],[rel,y,x]],['=',x,y]]
 assert any(map(anti,candidates))
 D='study-order-domain';assert D not in text and 'Real' not in text and ':pattern' not in text
 def rec(e):
  if not isinstance(e,list):return e
  if family(e) in [(rel,k) for k in ('reflexive','total','transitive')] or anti(e):return 'true'
  if e and e[0] in ('exists','forall'):
   op,bind,body=e;body=rec(body);guards=[[D,n] for n,t in bind if t==T]
   if guards:
    cond=guards[0] if len(guards)==1 else ['and',*guards]
    body=['=>' if op=='forall' else 'and',cond,body]
   return [op,[[n,'Real' if t==T else t] for n,t in bind],body]
  if e and e[0]==rel:return ['<=',rec(e[1]),rec(e[2])]
  return [rec(z) for z in e]
 out=[['declare-fun',D,['Real'],'Bool'],['assert',['exists',[['v','Real']],[D,'v']]]]
 for c in forms:
  if c[0]=='declare-sort':
   if c[1]!=T:out.append(['declare-sort',c[1],'0'])
  elif c[0]=='declare-fun':
   _,fn,params,res=c
   if fn==rel:continue
   ps=['Real' if t==T else t for t in params];out.append(['declare-fun',fn,ps,'Real' if res==T else res])
   if res==T:
    xs=['study-input-'+str(i) for i in range(len(ps))];assert all(x not in text for x in xs)
    cons=[D,[fn,*xs] if xs else fn];out.append(['assert',['forall',list(map(list,zip(xs,ps))),cons] if xs else cons])
  elif c[0]=='assert':out.append(['assert',rec(c[1])])
  else:assert c[0] in ['check-sat','get-info'];out.append(c)
 return '\n'.join(map(render,out))+'\n'
if __name__=='__main__':
 for key in keys:
  txt=(src/key.split('-')[0]/(key+'.smt2')).read_text();(w/'encoded'/(key+'-image.smt2')).write_text(image(txt))
 s=(w/'encode.py').read_text().split("if __name__=='__main__':")[1].replace("choices=['base','diagonal','rank']","choices=['base','image']").replace("choices[i:]+choices[:i]","choices[i%2:]+choices[:i%2]").replace("'encoded.csv'","'image.csv'")
 import subprocess,os,re
 d=w/'encoded';exec('if True:'+s)
