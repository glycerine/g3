from pathlib import Path
import os,subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
o=json.loads(Path('/tmp/g3-selective/final/overlay.json').read_text())
k=p/'smtcore/smt_internalizer_state.go';s=k.read_text().replace('import (','import ("os";"path/filepath";',1)
s+='\nvar trialPriority = filepath.Base(os.Args[0])\n'
s=s.replace('if s.cachedActivity || s.caseSplitStrategy == 2 {\n\t\tif cached, found := s.activityCache[expression]', '''if trialPriority=="all" || trialPriority=="baseonly" && !s.searching || trialPriority=="searchonly" && s.searching {
 hd,e:=s.manager.NodeHeader(expression);if e==nil && hd.Kind==ast.ASTApp && hd.Family==ast.NullFamilyID && hd.NumArgs==2 {a,e:=s.manager.GetArg(expression,0);b,e2:=s.manager.GetArg(expression,1);if e==nil && e2==nil && a==b {initialActivity+=0.999}}
 }
 if s.cachedActivity || s.caseSplitStrategy == 2 {
  if cached, found := s.activityCache[expression]''')
assert 'initialActivity+=0.999' in s
dst=w/'activity.go.txt';dst.write_text(s);o['Replace'][str(k)]=str(dst);j=w/'policy.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',j,'-o',w/'off','./cmd/goivy_check'],cwd=f,check=True)
for mode in ['all','baseonly','searchonly']:(w/mode).symlink_to(w/'off') if not (w/mode).exists() else None
