from pathlib import Path
import csv,sys,re,subprocess,os,collections
sys.path.insert(0,'/tmp/g3-ticket-focus/reuse')
from analyze import Terms,parse
w=Path(__file__).resolve().parent;src=Path('/tmp/g3-ticket-focus/reuse')
def render(e):return e if isinstance(e,str) else '('+' '.join(map(render,e))+')'
def family(e):
 if not isinstance(e,list) or len(e)!=3 or e[0]!='forall':return
 vs=[v[0] for v in e[1]];sorts=[v[1] for v in e[1]]
 if not vs or len(set(sorts))!=1:return
 b=e[2]
 if len(vs)==1 and isinstance(b,list) and len(b)==3 and b[1:]==vs*2:return b[0], 'reflexive'
 if len(vs)==2 and isinstance(b,list) and len(b)==3 and b[0]=='or' and isinstance(b[1],list):
  x,y=vs;r=b[1][0]
  if b==['or',[r,x,y],[r,y,x]]:return r,'total'
 if len(vs)==3 and isinstance(b,list) and len(b)==3 and b[0]=='=>' and isinstance(b[2],list):
  x,y,z=vs;r=b[2][0]
  if b==['=>',['and',[r,x,y],[r,y,z]],[r,x,z]]:return r,'transitive'
def make(text,mode):
 forms=parse(text);t=Terms();first=next(c[1] for c in forms if c[0]=='assert')
 got=collections.defaultdict(set)
 for n in t.conjuncts(t.expand(first,{})):
  a=family(parse(t.render(n))[0])
  if a and a[0]!='=':got[a[0]].add(a[1])
 rel,=[r for r,v in got.items() if {'reflexive','total','transitive'}<=v]
 fresh='study-order-rank';assert fresh not in text
 def remove(e):
  a=family(e)
  if a and a[0]==rel and (mode=='rank' or mode=='diagonal' and a[1]=='reflexive'):return 'true'
  return [remove(x) for x in e] if isinstance(e,list) else e
 out=[]
 for c in forms:
  if c[0]=='declare-sort' and len(c)==2:c=c+['0']
  if c[:2]==['declare-fun',rel] and mode!='base':
   sort=c[2][0];assert c[2]==[sort,sort] and c[3]=='Bool'
   if mode=='rank':out.append(render(['declare-fun',fresh,[sort],'Real']));body=['<=',[fresh,'x'],[fresh,'y']]
   else:out.append(render(['declare-fun',fresh,[sort,sort],'Bool']));body=['or',['=','x','y'],[fresh,'x','y']]
   c=['define-fun',rel,[['x',sort],['y',sort]],'Bool',body]
  elif c[0]=='assert' and mode!='base':c=['assert',remove(c[1])]
  out.append(render(c))
 return '\n'.join(out)+'\n'
keys=['3-4-55','3-4-56','3-5-55','3-5-56','6-14-44','6-16-1']
d=w/'encoded';d.mkdir(exist_ok=True)
for key in keys:
 txt=(src/key.split('-')[0]/(key+'.smt2')).read_text()
 for mode in ['base','diagonal','rank']:(d/(key+'-'+mode+'.smt2')).write_text(make(txt,mode))
if __name__=='__main__':
 perf='/usr/lib/linux-tools/6.17.0-35-generic/perf';env=dict(os.environ,GOMAXPROCS='1')
 with (w/'encoded.csv').open('w') as f:
  out=csv.writer(f);out.writerow('case engine round mode answer instructions instances'.split())
  for key in keys:
   for engine,exe in [('g3',w/'g3-cli'),('z3',(Path.cwd().parent/'build/z3').resolve())]:
    choices=['base','diagonal','rank']
    for i in range(3):
     for mode in choices[i:]+choices[:i]:
      st=w/'encoded.stat';run=subprocess.run(['taskset','-c','24',perf,'stat','-x,','-e','instructions:u','-o',st,'--','timeout','4',exe,'-in','-smt2'],input=(d/(key+'-'+mode+'.smt2')).read_bytes(),capture_output=True,env=env)
      ans=run.stdout.decode().splitlines();status='timeout' if run.returncode==124 else ans[0] if ans else 'error'
      if status!='timeout':assert run.returncode==0 and status in ('unsat','unknown') and not run.stderr,(key,engine,mode,ans[:9],run.stderr[:300])
      ins=next(int(z[0]) for z in csv.reader(st.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100);m=re.search(rb':quant-instantiations\s+(\d+)',run.stdout);out.writerow([key,engine,i,mode,status,ins,int(m[1]) if m else '']);f.flush()
