import os,csv,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');name=(rank/'compat.txt').read_text().splitlines()[2];ref=rank/'compat/3/1/native'
for mode in sys.argv[1:]:
 r=subprocess.run([w/'observe',ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),MODE=mode),capture_output=True,timeout=90)
 lines=r.stderr.splitlines(keepends=True);err=b''.join(l for l in lines if not l.startswith(b'TRACE '));assert (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),err[-3000:]
 with (w/(os.getenv('LABEL',mode)+'.csv')).open('w') as f:
  out=csv.writer(f);out.writerow(['event','value'])
  for l in lines:
   if l.startswith(b'TRACE '):
    k,_,v=l[6:].decode().strip().partition(' ');out.writerow([k,v])
