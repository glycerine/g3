from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
o=json.loads(Path('/tmp/g3-selective/final/overlay.json').read_text())['Replace']
def src(k):return Path(o.get(str(k),k)).read_text()
def save(k,s):
 dst=w/(k.name+'.txt');dst.write_text(s);o[str(k)]=str(dst)
k=f/'z3bridge_solver_model.go';s=src(k).replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";',1)
a='xtracer.Trace("ivy_solver.py:1339 get_small_model() ENTER shrink=%v", shrink)';assert s.count(a)==1;s=s.replace(a,'trialBatch++;batch:=trialBatch\n'+a)
a='if proveGoal != nil {\n\t\t\t\t\tif proveGoal(zCond)';assert s.count(a)==1
s=s.replace(a,'if os.Getenv("MODE")=="ordinary"{finalCheck=z3solver.Check;proveGoal=nil;groupEqualities=false}\n'+a)
a='res, err := s.decideZ3With(z3solver, finalCheck)';assert s.count(a)==1
s=s.replace(a,'''if batch==4 && index==16 && os.Getenv("MODE")=="forced"{finalCheck=z3solver.Check}
 if batch==4 && index==54{smtcore.TrialActive=true;println("TRACE start")}
 '''+a+'''
 if batch==4 && index==54{smtcore.TrialActive=false;println("TRACE stop")}''');save(k,s+'\nvar trialBatch int\n')
k=p/'smtcore/smt_qi_queue_schedule.go';s=src(k).replace('import "github','import ("fmt";"strings";"strconv";)\nimport "github').replace('q.newEntries = append','if TrialActive { var b strings.Builder;fmt.Fprintf(&b,"%g %d %s",cost,generation,witnessTree(q.manager,fingerprint.data));for _,a:=range fingerprint.args{b.WriteString(" | ");b.WriteString(witnessTree(q.manager,a.Owner()))};println("TRACE offer",b.String()) };q.newEntries = append',1)
helper=Path('/tmp/g3-clause-confirmation/obs-g3-smt_model_checker.go').read_text().split('func trialTree(')[1].split('func witnessTrace')[0]
save(k,s+'\nvar TrialActive bool\nfunc trialTree('+helper+'\nfunc witnessTree(m *ast.ASTManager,t ast.ASTHandle) string {var b strings.Builder;trialTree(m,t,&b);return b.String()}\n')
k=p/'smtcore/smt_search.go';s=src(k).replace('k.internalizer.statistics.NumDecisions++','''k.internalizer.statistics.NumDecisions++
 if TrialActive {println("TRACE split",variable,smtDecisionLiteral(variable,phase).Sign(),witnessTree(k.manager,k.internalizer.boolExpr[variable]))}''');save(k,s)
k=p/'smtcore/smt_quantifier_manager.go';s=src(k).replace('lemma, lemmaErr := instance.Lemma()','lemma, lemmaErr := instance.Lemma(); if TrialActive && lemmaErr==nil{println("TRACE formula",witnessTree(q.state.manager,lemma))}');save(k,s)
k=p/'smtcore/smt_activity_heap_queue.go';s=src(k).replace('return q.state.popBasicActivityHeap()', '''if TrialActive {trialPop++; if trialPop==forcePop && forceVar>0{v:=int32(forceVar);value,e:=q.state.Assignment(NewSMTLiteral(v,false));if e!=nil || value!=lbool.Undef || !h.Contains(v){panic("ineligible trial")};println("TRACE force",trialPop,v,witnessTree(q.state.manager,q.state.boolExpr[v]));return v,lbool.Undef,h.Erase(v)} }
 return q.state.popBasicActivityHeap()''');save(k,s.replace('import (','import ("os";"strconv";',1)+'\nvar trialPop int\nvar forceVar,_=strconv.Atoi(os.Getenv("FORCE_VAR"))\nvar forcePop,_=strconv.Atoi(os.Getenv("FORCE_POP"))\n')
j=w/'overlay.json';j.write_text(json.dumps({'Replace':o}));subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo=off','-tags','xtrace_off','-overlay',j,'-o',w/'observe','./cmd/goivy_check'],cwd=f,check=True)
