from pathlib import Path
import csv,statistics as st,collections
w=Path(__file__).resolve().parent
def rows(p):return list(csv.DictReader(p.open()))
def bench(p,group,metric):
 d=collections.defaultdict(lambda:collections.defaultdict(list))
 for r in rows(p):d[r[group]][r['mode']].append(float(r[metric]))
 for k,ms in d.items():
  a,b=list(ms.values())[:2]
  print(k,round(st.median(a),2),round(st.median(b),2),round(100*st.median(y/x-1 for x,y in zip(a,b)),2))
for p in ['gc-off','confirm']:
 if (w/'validation'/(p+'.csv')).exists():
  print(p);bench(w/'validation'/(p+'.csv'),'case','instructions')
for engine in ['native','g3']:
 d=collections.defaultdict(collections.Counter);rd=collections.defaultdict(set)
 for r in rows(w/('stacks-'+engine+'.csv')):
  k=r['case'];rd[k].add(r['round']);s=r['stack'];n=int(r['count'])*int(r['period'])/1e6
  for label,parts in [('checks',('smt::context::check(unsigned int','SMTSolver).checkSatCore')),('prep',('smt::context::internalize_assertions()','SMTKernel).internalizePending')),('search',('smt::context::bounded_search()','SMTKernel).boundedSearch')),('cancel',('ArithRewriter).cancelMonomials',)),('rewriter',('ArithRewriter).MkAppCore',)),('comparison',('ArithRewriter).rewriteComparison',))]:
   if any(t in s for t in parts):d[k][label]+=n
 for k in d:print(engine,k,len(rd[k]),{n:round(v/len(rd[k]),2) for n,v in d[k].items()})
if (w/'arith-stages.csv').exists():
 d=collections.defaultdict(lambda:collections.defaultdict(list))
 for r in rows(w/'arith-stages.csv'):d[r['case'],r['batch'],r['goal'],r['phase']][r['engine']].append(int(r['instructions']))
 for case in dict.fromkeys(k[0] for k in d):
  z=[]
  for (c,b,g,ph),row in d.items():
   if c==case:
    a,n=[st.median(row[m]) if m in row else 0 for m in ['g3','native']];z.append((round((a-n)/1e6,2),b,g,ph,round(a/1e6,2),round(n/1e6,2)))
  print(case,sorted(z,reverse=True)[:6])
