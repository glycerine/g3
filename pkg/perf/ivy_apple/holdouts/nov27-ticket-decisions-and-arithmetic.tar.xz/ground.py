from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
o=json.loads(Path('/tmp/g3-selective/final/overlay.json').read_text())
k=p/'api/api_simple_solver_mutation.go';s=k.read_text().replace('return s.solver.Assert(formula)','if err:=s.solver.Assert(formula); err!=nil{return err}; if trialGround=="seen" || trialGround=="constants"{return trialGroundDiagonal(s,formula)};return nil')
dst=w/'ground-assert.go.txt';dst.write_text(s);o['Replace'][str(k)]=str(dst);o['Replace'][str(p/'api/diagonal_trial.go')]=str(w/'ground.go.txt');j=w/'ground.json';j.write_text(json.dumps(o))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-overlay',j,'-o',w/'control','./cmd/goivy_check'],cwd=f,check=True)
for mode in ['seen','constants']:
 if not (w/mode).exists():(w/mode).symlink_to(w/'control')
