import collections
from analyze import read
for mode in ['release','ordinary','forced','early','siblingchoice','native']:
 events=read(mode);blocks=[[]];splits=[]
 for kind,tree,value in events:
  if kind=='split':blocks.append([]);splits.append((tree,value))
  else:blocks[-1].append((kind,tree))
 if mode=='release':ref=blocks
 print(mode)
 for i,block in enumerate(blocks[:5]):
  print('after decisions',i,'offers/formulas',len([r for r in block if r[0]=='offer']),len([r for r in block if r[0]=='formula']),'extra/missing',sum((collections.Counter(block)-collections.Counter(ref[i])).values()),sum((collections.Counter(ref[i])-collections.Counter(block)).values()))
