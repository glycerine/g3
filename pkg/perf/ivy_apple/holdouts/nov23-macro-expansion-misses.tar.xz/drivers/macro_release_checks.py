from study import *
from collections import Counter
from proof_release_trace import trace
d=w/'macro-release'
def micro():
 b=d/'macros.test'
 with(w/'build.lock').open('a')as lk:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-o',b,'./ast/macros'],cwd=pkg)
 bins={'previous':w/'macro-micro/control/macros.test','g3':b}
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round mode case ns bytes allocs'.split())
  for i in range(21):
   for v in (list(bins)if i%2==0 else list(bins)[::-1]):
    p=run(['taskset','-c','15',bins[v],'-test.run','^TestMacroExpansionResourceSteps$','-test.bench','^BenchmarkMacroExpansion$','-test.cpu=1','-test.benchtime=500x','-test.benchmem'],cwd=pkg/'ast/macros',capture_output=True)
    a=re.findall(rb'BenchmarkMacroExpansion/(\w+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout);assert len(a)==5
    z.writerows([i+1,v,*[s.decode()for s in row]]for row in a);f.flush()
def bounded():
 dest=d/'supplemental.csv';q=b'(set-logic ALL)(set-option :rlimit 4294967295)(declare-fun f (Int) Int)(assert (forall ((x Int)) (! (> (f x) x) :pattern ((f x)))))(assert (= (f 0) 0))'
 dat=(w/'branch-controls/inputs/repo-datalog_soft_timeout.smt2').read_bytes()
 bs={'previous':w/'setup-limit-audit/shared/shell/g3','g3':d/'shell/g3'}
 with dest.open('w')as f:
  z=csv.writer(f);z.writerow('input engine rc stdout stderr'.split())
  for v,b in bs.items():
   for n,txt,extra,ans in [('datalog',dat,['smt.timeout=50'],'unknown|timeout'),('check',q+b'(check-sat)',[],'unsat'),('incremental',q+b'(push)(check-sat)(pop)(check-sat)',[],'unsat|unsat'),('profile',q+b'(set-option :smt.string_solver auto)(check-sat)',[],'unsat')]:
    p=run([b,*extra,'-in','-smt2'],input=txt,capture_output=True,timeout=25);out='|'.join(p.stdout.decode().strip().splitlines());z.writerow([n,v,p.returncode,out,p.stderr.decode()]);f.flush();assert out==ans and not p.stderr,(n,out,p.stderr)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:
  fs=[ex.submit(micro),ex.submit(bounded),ex.submit(trace,d)]
  for k in fs:k.result()
