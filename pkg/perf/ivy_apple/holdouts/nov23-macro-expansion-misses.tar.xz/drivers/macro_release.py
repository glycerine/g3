from study import *
import guarded_live as gl,macro_identity as mi,setup_controls as sc,ground_release_controls as gc,setup_bound_release as sb,simplifier_rebuild as sh, inspect
d=w/'macro-release';d.mkdir(exist_ok=True)
def basecontrol():return w/'setup-limit-audit/shared/shell/g3'
def budgets(s):
 import types
 fun=inspect.getsource(sb.budgets)
 fun=once(fun,"bs={'previous':old.d/'control/shell/g3','shared':au.d/'shared/shell/g3'}","bs={'previous':basecontrol(),'g3':s}")
 code=dict(sb.__dict__,d=d,basecontrol=basecontrol,s=s);exec(fun,code);code['budgets']()
def main():
 with ThreadPoolExecutor(2)as e:
  b,s=list(e.map(lambda v:build(d/v,shell=v=='shell'),['checker','shell']))
 bs={'previous':w/'plan-release/checker/goivy_check','g3':b,'native':w/'key-release/native/goivy_check'}
 js=mi.jobs();gl.d=d;gc.d=d;sc.d=d;sh.d=d/'phases';sh.d.mkdir(exist_ok=True)
 fs=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));cpus=[0,3,6,8,12,16];ss={'previous':basecontrol(),'g3':s,'native':pkg.parent/'build/z3'}
 with ThreadPoolExecutor(len(js)+len(cpus)+3)as e:
  futures=[e.submit(gl.measure_job,j,bs)for j in js]+[e.submit(sh.lane,(c,fs[i::len(cpus)],ss))for i,c in enumerate(cpus)]
  futures += [e.submit(budgets,s),e.submit(sc.shell,{'control':basecontrol(),'release':s}),e.submit(gc.corpus,b)]
  for f in futures:f.result()
if __name__=='__main__':main()
