from study import *
import macro_bounded as mb,macro_identity as mi,guarded_live as gl,setup_controls as controls
from collections import Counter
d=w/'macro-proofs';d.mkdir(exist_ok=True);m=mi.ex
def edit(v):
 if v=='control':return{}
 ed=mb.edits('small');s=ed[m]
 if 'noquant'in v:s=once(s,'case ast.ASTQuantifier:\n default:','case ast.ASTQuantifier:return 0,false\n default:')
 if 'linear'in v:
  x='for _,prev:=range seen[:*used]{if prev==h{return 0,true}}';s=once(s,x,'for _,prev:=range seen[:*used]{if prev==h{return 0,false}}')
 if 'flat'in v:
  fn=s.index('// Count the original traversal');s=s[:fn]+'''func(m *Manager)identityStepsTrial(h ast.ASTHandle,depth int,seen []ast.ASTHandle,used,budget *int)(uint32,bool){
   d,e:=m.manager.NodeHeader(h);if e!=nil{return 0,false}
   if d.Kind==ast.ASTVar{return 0,true};if d.Kind!=ast.ASTApp{return 0,false}
   if _,ok:=m.byDeclaration[d.Decl];ok{return 0,false};if d.NumArgs==0{return 0,true};if d.NumArgs>16 || depth>0 || d.Family==m.manager.BasicFamilyID() && d.DeclKind==ast.ASTOpIte{return 0,false}
   for i:=uint32(0);i<d.NumArgs;i++{a,e:=m.manager.GetArg(h,i);if e!=nil{return 0,false};if _,ok:=m.identityStepsTrial(a,depth+1,seen,used,budget);!ok{return 0,false}}
   return 1,true
  }'''
 if 'audit'in v:
  x='if !ast.ASTSourceDebug';s=once(s,x,'var expected uint32;limit:=m.manager.ResourceLimit();initial:=limit.Count();'+x)
  x='if ok && m.manager.ResourceLimit().TryIncOffset(steps){return resultDependency,m.manager.SetRef(out,term)}';s=once(s,x,'if ok && (limit.Limit==0 || (initial<=limit.Limit && uint64(steps)<=limit.Limit-initial)){expected=steps}')
  k='if done {\n\t\t\tbreak';x='''if !changed{actual:=limit.Count()-initial;if expected!=0 && (!done || !cfg.usedDependency.IsNull() || uint64(expected)!=actual){panic(fmt.Sprintf("macro no-change prediction %%v: %%d %%d %%t",term,expected,actual,done))};fmt.Fprintf(os.Stderr,"MACRO-CERT %%d %%d %%d %%t\\n",limit.Limit,expected,actual,done)}'''.replace('%%','%');s=once(s,k,x+'\n'+k);s=once(s,'import (','import (\n"fmt"\n"os"')
 ed[m]=s;return ed
def mk(v):
 od=d/v;o=overlay(od/'overlay',edit(v));return build(od/'checker',o=o),build(od/'shell',shell=True,o=o)
def main():
 vs=['control','flat','noquant','linear','full']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;bb={v:b[0]for v,b in bs.items()};js=[j for j in mi.jobs()if j[1]in ['ordinary','tlb','rfn2','hybrid_reliable_broadcast_cisa','toy-consensus','flash2','raftok','cf_live']]
 with ThreadPoolExecutor(8)as e:list(e.map(lambda j:gl.measure_job(j,bb),js))
def audit():
 b,s=mk('audit');fs=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'));jobs=[(p.name,[s,'-smt2',p],0,None)for p in fs]+[(j[1],[b,*(['isolate='+j[3]]if j[3]else[]),examples/j[2]],j[4],j[-1])for j in mi.jobs()]
 def lane(v):
  n,cmd,rc,ref=v;od=d/'audit'/n;od.mkdir(exist_ok=True);p=subprocess.run(cmd,cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1'));ls=p.stderr.splitlines(keepends=True);other=b''.join(l for l in ls if not l.startswith(b'MACRO-CERT '));assert p.returncode==rc and (ref==None or p.stdout==(ref/'stdout').read_bytes()and other==(ref/'stderr').read_bytes()),(n,p.returncode,other[-550:])
  ct=Counter(tuple(l.decode().split()[1:])for l in ls if l.startswith(b'MACRO-CERT '))
  with(od/'counts.csv').open('w')as f:z=csv.writer(f);z.writerow('cap predicted actual identity observations'.split());z.writerows([*k,v]for k,v in ct.items())
 with ThreadPoolExecutor(6)as e:list(e.map(lane,jobs))
if __name__=='__main__':
 if 'audit'in sys.argv:audit()
 else:main()
