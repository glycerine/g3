from study import *
import macro_identity as mi,guarded_live as gl,setup_controls as controls
d=w/'macro-bounded';d.mkdir(exist_ok=True);q=mi.ex;lim=pkg/'util/control/rlimit.go'
def edits(v):
 if v=='control':return{}
 old=mi.edit('probe256');base=q.read_text();source=old[q];fn=source[source.index('// Count the original traversal'):];m=mi.m
 depth=1 if v=='shallow'else 5 if v=='depth5'else 32;budget=128 if v!='small'else 32
 fn=fn.replace('depth>32','depth>'+str(depth))
 s=once(base,'oldTerm, err := m.manager.NewRef(term)','''if !ast.ASTSourceDebug && !ast.ASTValidateHandles && !diagnostic.TraceCompiled() && m.manager.TraceStream==nil && !m.manager.Budget().InjectionArmed() && !m.manager.NumeralService().RuntimeOwner().AllocationLimited(){
  proofs,e:=m.manager.ProofsEnabled();if e!=nil{return resultDependency,e};if !proofs{
    var seen [64]ast.ASTHandle;var n int;budget:='''+str(budget)+'''
    var steps uint32;var ok bool
    LOOKUP
    if !ok{steps,ok=m.identityStepsTrial(term,0,seen[:],&n,&budget);if ok{steps*=2;if steps==0{steps=1};STORE}}
    if ok && m.manager.ResourceLimit().TryIncOffset(steps){return resultDependency,m.manager.SetRef(out,term)}
  }
 }
 oldTerm,err:=m.manager.NewRef(term)''')
 s=once(s,'import (','import (\n"github.com/glycerine/g3/pkg/util/diagnostic"')
 ed={}
 if 'warm'in v:
  ed[m]=old[m];s=s.replace('LOOKUP','if m.identitiesTrial!=nil{a:=m.identitiesTrial[term.Slot()%256];if a.term==term{steps=a.steps;ok=true}}').replace('STORE','if m.identitiesTrial==nil{m.identitiesTrial=new([256]macroIdentityTrial)};m.identitiesTrial[term.Slot()%256]=macroIdentityTrial{term,steps}')
 else:s=s.replace('LOOKUP','').replace('STORE','')
 ed[q]=s+'\n'+fn
 t=lim.read_text();needle='func (r *Reslimit) Push(delta uint32) error {';t=once(t,needle,'''// TryIncOffset charges a complete block only if all its original steps can run.
 // The caller can use its usual single-step path when the block does not fit.
 func(r *Reslimit)TryIncOffset(n uint32)bool{
  r.CheckOpen()
  if !r.suspended && (r.cancellationRequested() || (r.Limit!=0 && (r.Steps>r.Limit || uint64(n)>r.Limit-r.Steps))){return false}
  r.Steps+=uint64(n);return true
 }
 '''+needle)
 ed[lim]=t
 return ed
def mk(v):
 od=d/v;o=overlay(od/'overlay',edits(v));return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def main():
 vs=['control','shallow','depth5','small','probe','warm']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;bb={v:b[0]for v,b in bs.items()};js=mi.jobs()
 with ThreadPoolExecutor(8)as e:list(e.map(lambda j:gl.measure_job(j,bb),js))
def shell():
 controls.d=d;controls.shell({z:d/z/'shell/g3'for z in ('control','probe','warm')})
if __name__=='__main__':
 if 'shell'in sys.argv:shell()
 else:main()
