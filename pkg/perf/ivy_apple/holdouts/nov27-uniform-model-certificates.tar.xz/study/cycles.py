from pathlib import Path
import os
w=Path(__file__).resolve().parent;s=(w/'whole.py').read_text().replace("'instructions:u','--'","'instructions:u,cycles:u,task-clock','--'").replace("'case round mode instructions ms'","'case round mode instructions ms cycles clock_ns'").replace("o.writerow([name,i,mode,n,round(elapsed,3)])","ct={r[2]:r[0] for r in csv.reader(stat.open()) if len(r)>4};o.writerow([name,i,mode,n,round(elapsed,3),ct['cycles:u'],ct['task-clock']])")
import sys
sys.argv=['whole.py','cycles','base','release'];os.environ.update(CPU='20',ROUNDS='11',CASES='3 6 4 2');exec(s)
