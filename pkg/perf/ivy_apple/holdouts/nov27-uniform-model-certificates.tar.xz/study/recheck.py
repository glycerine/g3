from pathlib import Path
import csv
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-or-install/final/release.py').read_text();s=s[:s.index('subprocess.run([*flags')]+s[s.index('def run'):s.index("run(12,")]
exec(s);modes={'release':w/'release'}
rerun=[r['case'] for f in sorted(w.glob('panel*.csv')) for r in csv.DictReader(f.open()) if r['status']!='match']
assert rerun;run(24,'abc-recheck',rerun,1,['release'])
