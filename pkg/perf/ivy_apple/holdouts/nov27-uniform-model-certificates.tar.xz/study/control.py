from pathlib import Path
import subprocess as sp,json,os
w=Path(__file__).resolve().parent;p=Path.cwd()
a=p/'smtcore/smt_model_table_check.go';s=a.read_text().replace('import (','import ("os";',1).replace('if !bounded {\n\t\tremaining := 96','if enableUniform && !bounded {\n\t\tremaining := 96',1)+'\nvar enableUniform=os.Getenv("MODEL_MODE")=="enabled"\n'
b=w/'switch.go';b.write_text(s);ov=json.loads((w/'release.json').read_text());ov['Replace'][str(a)]=str(b);j=w/'switch.json';j.write_text(json.dumps(ov))
for m,j in [('enabled',j),('rebuilt',w/'base.json')]:
 sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/m,'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
if not (w/'disabled').exists():(w/'disabled').symlink_to(w/'enabled')
src=(w/'cycles.py').read_text().replace("exec(s)","s=s.replace('XTRACE_OFF=', 'MODEL_MODE=mode,XTRACE_OFF=');exec(s)").replace("'cycles','base','release'","'control-cycles','enabled','disabled','rebuilt','release'").replace("ROUNDS='11'","ROUNDS='7'").replace("CASES='3 6 4 2'","CASES='3 2 4 6'")
exec(src)
