from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'uniform.py').read_text()
s=s.replace("key='domains := make([][]int, count)'","key='g.manager, g.model, g.work = m, model, 6000'").replace('g.uniformValue(root,&fuel)','uniformAST(m,model,body,&fuel)').replace('uniform.go.txt','direct.go.txt').replace("w/'uniform.go'","w/'direct.go'").replace("w/'uniform.json'","w/'direct.json'").replace("w/'uniform'","w/'direct'").replace("w/'off'","w/'direct-off'").replace("w/'uniform-counts.csv'","w/'direct-counts.csv'").replace("'uniform-whole','off','uniform'","'direct-whole','direct-off','direct'").replace('if mode=="uniform"','if mode=="direct"').replace("CPU='20'","CPU='10'")
exec(s)
