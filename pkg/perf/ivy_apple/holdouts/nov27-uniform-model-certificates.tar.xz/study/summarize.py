from pathlib import Path
import csv,collections as c
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'queries.csv').open()))
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case group queries instructions'.split())
 for case in sorted(set(r['case'] for r in rows)):
  seen=c.defaultdict(dict);tot=c.defaultdict(lambda:[0,0])
  for r in rows:
   if r['case']!=case or r['result']!='-1':continue
   def add(k):tot[k][0]+=1;tot[k][1]+=int(r['instructions'])
   add('certified')
   key=tuple(r[k] for k in ['solver','origin','slot','generation','arity'])
   for name in ['body','exact','iso']:
    k=key+(r.get(name),);candidate=int(r['candidate'])
    if k in seen[name] and seen[name][k]<candidate:add(name)
    seen[name].setdefault(k,candidate)
   for name in ['exact','iso']:
    k=key+(r.get(name),r['goal'],r['batch']);candidate=int(r['candidate'])
    if k in seen[name+'-goal'] and seen[name+'-goal'][k]<candidate:add(name+'-goal')
    seen[name+'-goal'].setdefault(k,candidate)
  for k,v in tot.items():out.writerow([case,k,*v]);print(case,k,*v)
