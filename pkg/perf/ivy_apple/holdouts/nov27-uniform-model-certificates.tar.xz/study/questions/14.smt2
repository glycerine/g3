(declare-sort hrb.node 0)
(declare-fun mbqiReplay!0 () hrb.node)
(declare-const hrb.node!val!0 hrb.node)
(declare-const hrb.node!val!1 hrb.node)
(assert (distinct hrb.node!val!0 hrb.node!val!1))
(assert (or (= mbqiReplay!0 hrb.node!val!0) (= mbqiReplay!0 hrb.node!val!1)))
(assert false)

(check-sat)
