(declare-sort hrb.node 0)
(declare-fun mbqiReplay!0 () hrb.node)
(declare-const hrb.node!val!0 hrb.node)
(assert (= mbqiReplay!0 hrb.node!val!0))
(assert false)

(check-sat)
