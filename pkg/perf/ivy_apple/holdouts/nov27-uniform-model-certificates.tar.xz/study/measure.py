from pathlib import Path
import collections as c,io,csv,os,subprocess as sp,json
p=Path.cwd();w=Path(__file__).resolve().parent;prev=Path('/tmp/g3-arm-pass')
ov=json.loads((prev/'table.json').read_text())
def edit(name,src):
 a=p/'smtcore'/name;b=w/name;b.write_text(src);ov['Replace'][str(a)]=str(b)
s=(p/'smtcore/smt_model_checker.go').read_text().replace('type SMTModelChecker struct {','var studySolver,studyRound int\ntype SMTModelChecker struct {\n studyID int')
s=s.replace('return &SMTModelChecker{','studySolver++;return &SMTModelChecker{studyID:studySolver,',1)
k='func (c *SMTModelChecker) Check(model *protomodel.ProtoModel, quantifiers []ast.ASTHandle) (bool, error) {'
s=s.replace(k,k+'\n oldRound,oldSolver:=studyActiveRound,studyActiveSolver;defer func(){studyActiveRound,studyActiveSolver=oldRound,oldSolver}();studyRound++;studyActiveRound=studyRound;studyActiveSolver=c.studyID')
edit('smt_model_checker.go',s)
s=(prev/'table-check.go').read_text().replace('import (','import ("fmt";',1)
s=s.replace('func tableBool(','''var studyActiveSolver,studyActiveRound int
var studySnapshots=map[string]int{}
func studyEncode(s string) int {id:=studySnapshots[s];if id==0{id=len(studySnapshots)+1;studySnapshots[s]=id};return id}
func tableBool(''')
s=s.replace('reason:="sort";','exact,iso:=0,0;reason:="sort";')
s=s.replace('end(reason);println("TABLE",StudyBatch,StudyGoal,reason,int(st),count)','end(reason);println("TABLE",StudyBatch,StudyGoal,reason,int(st),count,studyActiveSolver,studyActiveRound,body.Origin(),body.Slot(),body.Generation(),exact,iso)')
k='reason="small-int"'
s=s.replace(k,'''if StudyBatch!=0 {
 prog:=fmt.Sprintf("%d/%v/%v/%v/%v/%v/%v",root,g.terms,g.functions,g.sorts,g.integers,sorts,domains)
 iso=studyEncode(prog);exact=studyEncode(fmt.Sprintf("%d/%v",iso,g.values))
 }
 '''+k)
edit('smt_model_table_check.go',s)
j=w/'config.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'measure','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows')
old=list(csv.DictReader((prev/'tables.csv').open()))
with (w/'queries.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case batch goal phase result arity solver candidate origin slot generation exact iso instructions'.split())
 for nr in [2,4,3,6]:
  case=(ref/'compat.txt').read_text().splitlines()[nr-1];d=ref/'compat'/str(nr)/'1/native'
  env=dict(os.environ,GOGC='off',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1')
  r=sp.run(['taskset','-c','24',w/'measure',ex/case],env=env,cwd=prev,capture_output=True,check=True);rest=[];obs=[]
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'TABLE '):obs.append(line.decode().split()[1:])
   elif not line.startswith(b'STAGE-COUNT '):rest.append(line)
  assert (r.stdout,b''.join(rest))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes())
  clean=[k for k in old if k['case']==str(nr) and k['round']=='0'];assert len(clean)==len(obs)
  for v,z in zip(obs,clean):
   assert v[:5]==[z[k] for k in ['batch','goal','phase','result','arity']]
   o.writerow([nr,*v,z['instructions']])
  f.flush()
