from pathlib import Path
import csv,statistics as s,collections as c
w=Path(__file__).resolve().parent
for stem in ['final/complete','final/raft_no_assume/long','final/rfn2/long','final/dramc_nb2/long']:
 f=w/(stem+'.csv')
 if not f.exists():continue
 d=c.defaultdict(lambda:c.defaultdict(list))
 for r in csv.DictReader(f.open()):d[r['case']][r['mode']].append([int(r['instructions']),float(r['ms'])])
 for case,modes in d.items(): print(stem,case,[(m,len(x),round(s.median(a for a,b in x)/1e6,2),round(s.median(b for a,b in x),2)) for m,x in modes.items()])
d=c.defaultdict(list)
for l in (w/'final/paired-bench.txt').read_text().splitlines():
 f=l.split()
 if len(f)==2 and f[0].isdigit():mode=f[-1]
 if l.startswith('Benchmark'): d[mode].append([float(f[2]),int(f[4]),int(f[6])])
print('micro',[(m,[s.median(x) for x in zip(*v)]) for m,v in d.items()])
