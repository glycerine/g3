from pathlib import Path
import subprocess as sp,json
w=Path(__file__).resolve().parent;p=Path.cwd();j=w/'bench-base.json';j.write_text(json.dumps({'Replace':{str(p/'smtcore/smt_model_table_check.go'):str(w/'old-check.go')}}))
for mode in ('base','release'):
 sp.run(['go','test','-c','-o',w/(mode+'.test'),*(['-overlay',j] if mode=='base' else []),'./smtcore'],check=True)
with (w/'bench.txt').open('w') as f:
 for i in range(7):
  for mode in ('base','release')[::1 if i%2==0 else -1]:
   print(i,mode,file=f,flush=True);sp.run(['taskset','-c','22',w/(mode+'.test'),'-test.run=^$','-test.bench=^BenchmarkUniformPredicateModelCheck$','-test.benchtime=300ms'],check=True,stdout=f)
