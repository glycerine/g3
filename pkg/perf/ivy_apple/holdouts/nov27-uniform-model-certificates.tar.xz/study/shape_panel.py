from pathlib import Path
import concurrent.futures,csv,os
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-or-install/final/release.py').read_text();s=s[:s.index('subprocess.run([*flags')]+s[s.index('def run'):s.index('run(12,')];exec(s)
modes={'shape':w/'shape'}
with concurrent.futures.ThreadPoolExecutor(6) as pool:
 jobs=[pool.submit(run,1+2*i,'shape-panel'+str(i),cases[i::6],1,['shape']) for i in range(6)]
 for j in jobs:j.result()
