from pathlib import Path
import tarfile
p=Path.cwd();w=Path(__file__).resolve().parent;out=p/'perf/ivy_apple/holdouts/nov27-uniform-model-certificates.tar.xz'
with tarfile.open(out,'w:xz',preset=3) as t:
 for f in sorted(w.rglob('*')):
  if f.is_file() and not f.is_symlink() and f.suffix in ['.py','.txt','.json','.go','.csv','.smt2']:t.add(f,arcname='study/'+str(f.relative_to(w)))
 for name in ['g3-arm-pass/table-check.go','g3-arm-pass/table-bridge.go.txt','g3-arm-pass/measure-table.go','g3-arm-pass/tables.csv','g3-arm-pass/stats.py','g3-arm-pass/release.json','g3-assert-op/stage-goals.csv','g3-assert-op/stage-totals.csv','g3-interval-products/verify.py','g3-or-install/final/release.py','g3-selective/final/long.py','g3-selective/final/apple.json','g3-selective/final/apple.go.txt','g3-selective/final/heap-main.go.txt','g3-selective/final/z3bridge_solver_model.go','g3-selective/final/z3bridge_guarded_equalities.go','g3-plan-budget/long.py','g3-ticket-first/arith_stages.py','g3-arith-next/final/arith-stage.json','g3-reduction-rows/compat.txt','g3-reduction-rows/ranking.csv']:
  f=Path('/tmp')/name;t.add(f,arcname='support/'+name)
