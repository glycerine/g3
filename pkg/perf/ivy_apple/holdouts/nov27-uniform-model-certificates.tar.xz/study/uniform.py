from pathlib import Path
import subprocess as sp,json,os,csv
p=Path.cwd();w=Path(__file__).resolve().parent;prev=Path('/tmp/g3-arm-pass')
a=p/'smtcore/smt_model_table_check.go';s=a.read_text();key='domains := make([][]int, count)'
s=s.replace(key,'''if !bounded && os.Getenv("MODEL_UNIFORM")!="" {
 fuel:=96
 if g.uniformValue(root,&fuel)==tableTrue {
  if os.Getenv("MODEL_UNIFORM")=="report"{println("UNIFORM",StudyBatch,StudyGoal,body.Slot())} else{return lbool.False,nil,nil}
 }
 }
 '''+key).replace('import (','import ("os";',1)+(w/'uniform.go.txt').read_text()
# Hoist policy switches out of the query path.
s=s.replace('os.Getenv("MODEL_UNIFORM")','studyUniform')+'\nvar studyUniform=os.Getenv("MODEL_UNIFORM")\n'
b=w/'uniform.go';b.write_text(s);ov=json.loads((prev/'table.json').read_text());ov['Replace'][str(a)]=str(b);j=w/'uniform.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'uniform','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows')
with (w/'uniform-counts.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case batch goal slot'.split())
 for nr in (2,4,3,6):
  case=(ref/'compat.txt').read_text().splitlines()[nr-1];d=ref/'compat'/str(nr)/'1/native'
  r=sp.run(['taskset','-c','24',w/'uniform',ex/case],env=dict(os.environ,MODEL_UNIFORM='report',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),cwd=prev,capture_output=True,check=True)
  rest=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'UNIFORM '):o.writerow([nr,*l.decode().split()[1:]])
   else:rest.append(l)
  assert (r.stdout,b''.join(rest))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes());f.flush()
(w/'off').symlink_to(w/'uniform') if not (w/'off').exists() else None
src=(prev/'whole.py').read_text().replace('XTRACE_OFF=','MODEL_UNIFORM="yes" if mode=="uniform" else "",XTRACE_OFF=')
import sys
sys.argv=['whole.py','uniform-whole','off','uniform'];os.environ.update(CASES='2 4 3 6',ROUNDS='7',CPU='20');exec(src)
