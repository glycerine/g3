from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-arm-pass/stats.py').read_text().replace('batch==8 && g==1 || batch==6 && (g==5 || g==6 || g==26)','(batch==16 || batch==23 || batch==35) && g==1 || batch==31 && g==34 || batch==2 && (g==55 || g==56)')
s=s.replace("ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows/compat/4/1/native')","ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows')")
i=s.index('  for i in range(3):');s=s[:i]+"""  for nr in [2,3,6]:
   ref=rank/'compat'/str(nr)/'1/native';case=(rank/'compat.txt').read_text().splitlines()[nr-1]
"""+'\n'.join(' '+l for l in s[i:].splitlines())+'\n';s=s.replace("ex/'test/arm_rules3.ivy'","ex/case").replace("'engine round batch goal name before after delta'","'case engine round batch goal name before after delta'").replace('out.writerow([e,i,b,g,k','out.writerow([nr,e,i,b,g,k')
exec(s)
