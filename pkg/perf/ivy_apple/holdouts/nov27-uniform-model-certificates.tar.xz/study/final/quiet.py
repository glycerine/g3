from pathlib import Path
w=Path(__file__).resolve().parent
s=(w.parent/'cycles.py').read_text().replace("'cycles','base','release'","'quiet','base','release','native'").replace("ROUNDS='11'","ROUNDS='13'").replace("CPU='20'","CPU='23'").replace("CASES='3 6 4 2'","CASES='2'").replace('clock_ms','clock_ns')
exec(s)
