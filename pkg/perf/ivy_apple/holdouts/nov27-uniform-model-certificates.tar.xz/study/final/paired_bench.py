from pathlib import Path
import subprocess as sp
w=Path(__file__).resolve().parent
sp.run(['go','test','-c','-o',w/'release.test','./smtcore'],check=True)
s=(w.parent/'bench.py').read_text();exec(s[s.index("with (w/'bench.txt')"):].replace("w/'bench.txt'","w/'paired-bench.txt'"))
