from pathlib import Path
import subprocess as sp,os
w=Path(__file__).resolve().parent;p=Path.cwd()
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay','/tmp/g3-arm-pass/release.json','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'release','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
sp.run(['python3',w/'long.py'],check=True)
