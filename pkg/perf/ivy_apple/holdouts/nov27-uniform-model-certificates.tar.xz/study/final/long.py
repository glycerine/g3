from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/apple-source/goivy').resolve()
for mode in ['base','release']:
 ov=json.loads(Path('/tmp/g3-selective/final/apple.json').read_text())
 if mode=='base':ov['Replace'][str(p/'smtcore/smt_model_table_check.go')]=str(w/'old-check.go')
 j=w/(mode+'-apple.json');j.write_text(json.dumps(ov))
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-o',w/('apple-'+mode),'./cmd/goivy_check'],cwd=front,check=True)
s=Path('/tmp/g3-selective/final/long.py').read_text();exec(s[s.index("s=Path('/tmp/g3-plan-budget/long.py')"):])
