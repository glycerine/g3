from pathlib import Path
import struct,mmap
w=Path(__file__).resolve().parent
def text(path):
 with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as buf:
  off=struct.unpack_from('<Q',buf,40)[0];size,n,ix=struct.unpack_from('<HHH',buf,58)
  def section(i):return struct.unpack_from('<IIQQQQIIQQ',buf,off+i*size)
  sec=section(ix);names=buf[sec[4]:sec[4]+sec[5]]
  for i in range(n):
   s=section(i)
   if names[s[0]:].split(b'\0',1)[0]==b'.text':return buf[s[4]:s[4]+s[5]]
  raise ValueError('missing text')
a,b=map(text,[w.parent/'shape',w/'release']);print('release .text bytes',len(a),len(b),'equal',a==b);assert a==b
