from pathlib import Path
import json,os,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;a=p/'smtcore/smt_model_uniform.go';s=a.read_text()
i=s.index('\n',s.index('func uniformModelBool('));header=s[s.index('func uniformModelBool('):i]
s=s[:i]+'''
 probe:=uniformModelProbe{manager:m,model:model,boolean:boolean,remaining:*remaining}
 result:=probe.value(expr);*remaining=probe.remaining;return result
}
type uniformModelProbe struct{manager *ast.ASTManager;model *protomodel.ProtoModel;boolean ast.ASTHandle;remaining int}
func (p *uniformModelProbe) value(expr ast.ASTHandle) lbool.LBool {
 m:=p.manager
'''+s[i:].replace('*remaining','p.remaining').replace('return uniformModelBool(m, model, arg, boolean, remaining)','return p.value(arg)')
i=s.index('if h.Family == ast.NullFamilyID');j=s.index('\n\tif h.Family !=',i)
fn=s[i:j].split('\n',1)[1].rsplit('}',1)[0]
fn=fn.replace('sort, err := m.GetRange(h.Decl)\n\t\tif err != nil || sort != boolean {\n\t\t\treturn lbool.Undef\n\t\t}', 'var err error').replace('model.Core()','p.model.Core()')
i0=fn.index('if err == nil && m.IsTrue(value)');fn=fn[:i0]+'''if err!=nil || (!m.IsTrue(value) && !m.IsFalse(value)){return lbool.Undef}
 sort,err:=m.GetRange(h.Decl);if err!=nil || sort!=p.boolean{return lbool.Undef};return lbool.FromBool(m.IsTrue(value))
'''
s=s[:i]+'if h.Family==ast.NullFamilyID{return p.predicate(h)}'+s[j:]+'\nfunc (p *uniformModelProbe) predicate(h ast.ASTNodeHeader) lbool.LBool {\n m:=p.manager\n'+fn+'}\n'
b=w/'shape.go';b.write_text(s);sp.run(['gofmt','-w',b],check=True)
ov=json.loads((w/'release.json').read_text());ov['Replace'][str(a)]=str(b);j=w/'shape.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'shape','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
src=(w/'cycles.py').read_text().replace("'cycles','base','release'","'shape-cycles','base','release','shape'").replace("ROUNDS='11'","ROUNDS='9'").replace("CPU='20'","CPU='12'");exec(src)
