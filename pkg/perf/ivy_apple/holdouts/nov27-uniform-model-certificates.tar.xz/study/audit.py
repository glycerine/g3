from pathlib import Path
import csv,base64,json,subprocess as sp,os,sys,collections as c
p=Path.cwd();w=Path(__file__).resolve().parent;prev=Path('/tmp/g3-arm-pass');ov=json.loads((prev/'release.json').read_text())
def edit(name,s):
 a=p/'smtcore'/name;b=w/('audit-'+name);b.write_text(s);ov['Replace'][str(a)]=str(b)
a=p/'smtcore/smt_model_table_check.go';s=a.read_text().replace('if !bounded {\n\t\tremaining := 96','studyHit=false\n if !bounded {\n\t\tremaining := 96',1).replace('== lbool.True {\n\t\t\treturn lbool.False, nil, nil','== lbool.True {\n studyHit=true',1)+'\nvar studyHit bool\n'
edit(a.name,s);a=p/'smtcore/smt_model_checker.go';s=a.read_text().replace('import (','import ("encoding/base64";"bytes";',1)
k='auxiliary := c.auxiliaryContext\n\tif (auxiliary';s=s.replace(k,'studyExtra:=false\n '+k,1)
k='status, bindings, err := c.tableScratch.check';i=s.index(k);j=s.index('\n',i);s=s[:i]+'studyHit=false\n '+s[i:j]+'''
 if studyHit {println("CERTAUDIT",int(status));if status==lbool.True{panic("table witness contradicts uniform certificate")};studyExtra=status==lbool.Undef}
'''+s[j:]
k='if status == lbool.False {\n\t\treturn false, nil\n\t}';i=s.index('status, err := auxiliary.CheckSat(nil)');s=s[:i]+s[i:].replace(k,'''if studyExtra {var b bytes.Buffer;if err:=auxiliary.Display(&b,nil);err!=nil{return false,err};b.WriteString("\\n(check-sat)\\n");println("EXTRAQUERY",int(status),base64.StdEncoding.EncodeToString(b.Bytes()))}
 '''+k,1)
edit(a.name,s);j=w/'audit.json';j.write_text(json.dumps(ov));front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'audit','./cmd/goivy_check'],cwd=front,check=True)
sys.path.insert(0,str(p/'perf/ivy_apple/holdouts'));from model_tables_replay import canonical_query
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows');qdir=w/'questions';qdir.mkdir(exist_ok=True);questions={}
with (w/'audit.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case type status frequency'.split())
 for nr in (2,4,3,6):
  name=(ref/'compat.txt').read_text().splitlines()[nr-1];d=ref/'compat'/str(nr)/'1/native'
  r=sp.run(['taskset','-c','24',w/'audit',ex/name],env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),cwd=w,capture_output=True,check=True)
  rest=[];counts=c.Counter()
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'CERTAUDIT '):counts['prior_table',int(l.split()[1])]+=1
   elif l.startswith(b'EXTRAQUERY '):
    _,st,data=l.split();counts['auxiliary',int(st)]+=1
    q=canonical_query(base64.b64decode(data).decode())
    if q not in questions:
     a=qdir/(str(len(questions))+'.smt2');a.write_text(q);native=sp.run([p.parent/'build/z3','-smt2',a],capture_output=True,check=True);assert native.stdout.strip()==b'unsat' and not native.stderr;questions[q]=a
    counts['native','unsat']+=1
   else:rest.append(l)
  assert (r.stdout,b''.join(rest))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes()),rest[-2:]
  for (k,st),n in counts.items():o.writerow([nr,k,st,n])
  f.flush()
