from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'cycles.py').read_text().replace("'cycles','base','release'","'shape-confirm','rebuilt','release','shape'").replace("ROUNDS='11'","ROUNDS='9'").replace("CPU='20'","CPU='18'").replace("CASES='3 6 4 2'","CASES='2 4 6 3'")
exec(s)
