import csv,statistics as s,collections as c
from pathlib import Path
w=Path(__file__).resolve().parent
with (w/'paired.csv').open('w') as f:
 o=csv.writer(f);o.writerow('study case base trial pairs metric median_percent'.split())
 for stem,pairs in [('cycles',[('base','release')]),('control-cycles',[('disabled','enabled'),('rebuilt','release')]),('shape-cycles',[('release','shape'),('base','shape')]),('shape-confirm',[('release','shape'),('rebuilt','shape')])]:
  d=c.defaultdict(dict)
  for r in csv.DictReader((w/(stem+'.csv')).open()):d[r['case']][r['round'],r['mode']]=r
  for name,v in d.items():
   for a,b in pairs:
    rounds=[rd for rd,m in v if m==a and (rd,b) in v]
    if not rounds:continue
    for k in ['cycles','instructions','ms']:
     change=s.median(float(v[rd,b][k])/float(v[rd,a][k]) for rd in rounds)-1
     o.writerow([stem,name,a,b,len(rounds),k,round(100*change,3)])
     if k=='cycles':print(stem,name.split('/')[-1],a,b,len(rounds),round(100*change,2))
