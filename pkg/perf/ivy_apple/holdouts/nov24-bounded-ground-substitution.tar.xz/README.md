# Resource-bounded ground substitution

The previous source is g3 27b16460e. Production code and the Go benchmark are in 0d489f264. The application runs used GoIvy 832e392ef with a local g3 module replacement. Run the commands from an extracted copy of this archive.

    python3 replay.py --pkg /path/to/g3/pkg --query 2 --budget 12000000

The replay driver accepts all six saved solver histories and 6, 9 or 12 million resource steps for the last query of each history. It reads api/test_vectors/apple_enumeration_search.json.gz from the checkout and verifies the proof result and exact resource charge for every sibling. The CSVs contain both original and trial readings. To benchmark production directly:

    cd /path/to/g3/pkg
    go test -tags=xtrace_off ./smtcore -run '^$' -bench '^BenchmarkSMT(Bounded)?QuantifierInstanceStream$' -cpu=1 -benchtime=65536x

micro.csv covers seven rotating pairs of 16,384 and 65,536 operations. Subtract the low from the high process instruction count and divide by 49,152. verification contains all four process runs per complete Apple input (two orders). Compare verdicts via exit, stdout and stderr. Scheduling contention prevents a reliable wall-time estimate from those runs. The bounded directory in the adjacent nov24-boolean-operand-search archive includes six standalone queries, native comparisons and five additional three-round verification controls. The corpus CSVs record compatibility with the reference exit, stdout and stderr on all 228 cases.
