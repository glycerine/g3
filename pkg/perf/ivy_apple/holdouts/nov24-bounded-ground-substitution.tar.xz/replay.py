"""Verify every per-check proof outcome and resource increment in a captured Apple solver session."""
import argparse
import csv
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--pkg', type=Path, required=True)
p.add_argument('--query', type=int, choices=range(1,7), required=True)
p.add_argument('--budget', type=int, choices=[6000000,9000000,12000000], default=12000000)
args = p.parse_args()
pkg = args.pkg.resolve()
with (root/'steps'/f'{args.query}.csv').open() as f:
    expected = [(r['check'], r['proved'], r['steps']) for r in csv.DictReader(f)
                if r['engine']=='before' and int(r['budget'])==args.budget]
with gzip.open(pkg/'api/test_vectors/apple_enumeration_search.json.gz','rt') as f:
    fixture = json.load(f)
with tempfile.TemporaryDirectory() as td:
    tmp = Path(td)
    repl = {str(pkg/'api/enumeration_replay_study_test.go'): str(root/'enumeration_replay_study_test.go')}
    overlay = tmp/'overlay.json'
    overlay.write_text(json.dumps({'Replace':repl}))
    exe = tmp/'api.test'
    subprocess.run(['go','test','-tags=xtrace_off','-overlay='+str(overlay),'-c','-o',exe,'./api'],cwd=pkg,check=True)
    sequence=[]
    for q in fixture['Batches'][args.query-1]['History']:
        d=fixture['Declarations'][q['Declarations']]
        b=fixture['Premises'][q['Premises']]
        sequence.append({'Problem':{'Text':d+b+q['Goal'],'AssertionsStart':len(d.encode()),
                                    'LastAssertionStart':len((d+b).encode()),'DeclarationCount':d.count('\n')}})
    path = tmp/'sequence.json'
    path.write_text(json.dumps(sequence))
    r=subprocess.run([exe,'-test.run=^TestStudyEnumerationReplay$','-test.v','-test.timeout=20m'],env=dict(os.environ,GOMAXPROCS='1',ENUM_SEQUENCE=str(path),ENUM_SCOPE='warm',ENUM_REGIME='default',ENUM_STEPS=str(args.budget)),capture_output=True,text=True,check=True)
    got = re.findall(r'^STEPS (\d+) (true|false) (\d+)$', r.stdout, re.M)
    if not expected or got != expected:
        raise ValueError(f'check results differ: expected {expected}, got {got}')
    print(f'query {args.query}, budget {args.budget}: all {len(got)} verdicts and charges match')
