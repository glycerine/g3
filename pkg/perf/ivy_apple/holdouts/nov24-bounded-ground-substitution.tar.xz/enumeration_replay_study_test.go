package api

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/glycerine/g3/pkg/api/internal/order"
	"os"
	"strconv"
	"testing"
	"time"
)

type enumerationReplay struct {
	Problem order.Problem
	New     bool
	Proved  bool
	Owner   string
}

func TestStudyEnumerationReplay(t *testing.T) {
	f, e := os.Open(os.Getenv("ENUM_SEQUENCE"))
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	var qs []enumerationReplay
	if e = json.NewDecoder(f).Decode(&qs); e != nil {
		t.Fatal(e)
	}
	parent, e := NewSMTContext()
	if e != nil {
		t.Fatal(e)
	}
	defer parent.Close()
	m, e := parent.Manager()
	if e != nil {
		t.Fatal(e)
	}
	scope := os.Getenv("ENUM_SCOPE")
	regime := os.Getenv("ENUM_REGIME")
	if scope == "cold" {
		qs = qs[len(qs)-1:]
	}
	budget, _ := strconv.Atoi(os.Getenv("ENUM_STEPS"))
	var p orderProofState
	defer p.release()
	if e = p.start(m, enumerationSearch); e != nil {
		t.Fatal(e)
	}
	if regime != "default" {
		x, e := p.ctx.NewParameterSet()
		if e != nil {
			t.Fatal(e)
		}
		e = x.SetBool("smt.macro_finder", regime != "macro-off")
		if e == nil {
			rel := uint32(1)
			if regime == "rel2" {
				rel = 2
			}
			if regime == "rel0" {
				rel = 0
			}
			e = x.SetUInt("smt.relevancy", rel)
		}
		if e == nil {
			switch regime {
			case "ematch":
				e = x.SetBool("smt.mbqi", false)
			case "seed":
				e = x.SetUInt("smt.random_seed", 1)
			case "phase2":
				e = x.SetUInt("smt.phase_selection", 2)
			case "phase6":
				e = x.SetUInt("smt.phase_selection", 6)
			case "eager3":
				e = x.SetDouble("smt.qi.eager_threshold", 3)
			case "multi":
				e = x.SetUInt("smt.qi.max_multi_patterns", 2)
			}
		}
		if e == nil {
			e = p.child.SetParameters(x)
		}
		if e = errors.Join(e, x.Close()); e != nil {
			t.Fatal(e)
		}
	}
	for i, q := range qs {
		if p.needsNewDeclarations(q.Problem) {
			t.Fatal("inconsistent declarations", i)
		}
		limit := uint32(6000000)
		if i == len(qs)-1 {
			limit = uint32(budget)
		}
		cm, er := p.ctx.Manager()
		if er != nil {
			t.Fatal(er)
		}
		rl := cm.ResourceLimit()
		st := rl.Count()
		started := time.Now()
		yes, e := p.check(m, q.Problem, limit, true)
		if e != nil {
			t.Fatal(e)
		}
		fmt.Println("STEPS", i+1, yes, rl.Count()-st)
		if i == len(qs)-1 || !yes {
			fmt.Printf("REPLAY %d %d %t %d\n", i+1, len(qs), yes, time.Since(started).Nanoseconds())
			if !yes {
				break
			}
		}
	}
}
