from pathlib import Path
import os,re,csv,statistics,subprocess,collections
w=Path(__file__).resolve().parent;p=Path.cwd();fx=w.parent/'fixtures'
ops={1:'substitution',2:'app',3:'quantifier',4:'variable',5:'constant',6:'cache-find',7:'cache-insert',8:'scope-entry',9:'scope-exit',10:'push-root',11:'pop-roots',12:'uf',13:'eq',14:'or',15:'and',16:'not',17:'ite',18:'basic-other',19:'theory-other'}
expected={r['query']:r for r in csv.DictReader((fx/'census-full.csv').open())}
keys=('decisions','conflicts','quant-instantiations','rlimit-count')
with (w/'calls.csv').open('w') as out:
 wr=csv.writer(out);wr.writerow(['query','engine','round','instance','op','calls','raw','blank16'])
 for q,ref in expected.items():
  for i in range(3):
   for e in (['g3','z3'] if i%2==0 else ['z3','g3']):
    r=subprocess.run(['taskset','-c','14',w/e,'-in','-smt2'],input=(fx/(q+'.smt2')).read_bytes(),capture_output=True,check=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'))
    stats=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));assert r.stdout.startswith(b'unsat\n') and tuple(stats[k] for k in keys)==tuple(ref[k] for k in keys)
    lines=r.stderr.decode().splitlines();assert len(lines)==int(ref['calls'])
    for j,line in enumerate(lines):
     assert line.startswith('OPS [');n,v=[list(map(int,a.split())) for a in line[5:-1].split('] [')];assert n[0]==16
     for k in ops:
      if n[k]:wr.writerow([q,e,i+1,j,k,n[k],v[k],v[0]])
    out.flush()
