from pathlib import Path
import sys,json
w=Path(__file__).resolve().parent;old=w.parent.parent/'g3-unchanged-frame'
s=(w.parent/'build.py').read_text().replace("old=w.parent/'g3-unchanged-frame'","old=w.parent.parent/'g3-unchanged-frame'")
s=s.replace("n=w/'native'","n=w.parent/'native'").replace("(w/'go')","(w.parent/'go')")
if sys.argv[1]=='g3':
 anchor="k=p/'smtcore/smt_qi_instance.go'";s=s.replace(anchor,'''k=p/'ast/rewriter/rewriter_engine.go';eng=Path(files[str(k)]).read_text();i=eng.index('op:=19');j=eng.index('opStart:=opBegin()',i)
 eng=eng[:i]+"""op:=2
if rowActive{ _,fid,kind,err:=m.AppIdentity(t);if err!=nil{return err};if cfg,ok:=r.cfg.(*theoryRewriterConfiguration);ok && fid==cfg.arithmetic.family && kind>=2 && kind<=9{op=int(kind)+10}}
"""+eng[j:];dst=w/k.name;dst.write_text(eng);files[str(k)]=str(dst)
 '''+anchor)
else:
 a="k=p.parent/'src/smt/qi_queue.cpp'";s=s.replace(a,'''hdr=n/'ast/rewriter/rewriter_def.h';eng=hdr.read_text();i=eng.index('int op=19');j=eng.index('window sample(op)',i)
 eng=eng[:i]+"""int op=2;if(measured_ops.fd>=0 && f->get_family_id()==m().get_family_id("arith") && f->get_decl_kind()>=2 && f->get_decl_kind()<=9){op=10+f->get_decl_kind();}"""+eng[j:]
 dst=w/'ast/rewriter/rewriter_def.h';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(eng)
 '''+a).replace("'-I'+str(n),*includes","'-I'+str(w),'-I'+str(n),*includes")
exec(compile(s,'build.py','exec'))
