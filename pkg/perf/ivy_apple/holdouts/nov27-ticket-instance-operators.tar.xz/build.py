from pathlib import Path
import os,sys,re,shlex,subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;old=w.parent/'g3-unchanged-frame';n=w/'native';build=p.parent/'build';e=sys.argv[1]
if e=='g3':
 files={str(p/'ast/rewriter'/k.name.removesuffix('.txt')):str(k) for k in (w/'go').glob('*.go.txt')}
 k=p/'smtcore/smt_qi_instance.go';s=k.read_text()
 a='if err = rw.Rewrite(instance, simplified); err != nil {';assert s.count(a)==1
 s=s.replace(a,'rewriter.BeginObservedRow();err = rw.Rewrite(instance, simplified); rewriter.EndObservedRow(); if err != nil {')
 dst=w/k.name;dst.write_text(s);files[str(k)]=str(dst)
 k=p/'cmd/g3/main.go';s=k.read_text().replace('package main','package main\nimport "runtime"').replace('func main() {','func main() { runtime.LockOSThread(); defer runtime.UnlockOSThread()');dst=w/k.name;dst.write_text(s);files[str(k)]=str(dst)
 ov=w/'cli.json';ov.write_text(json.dumps({'Replace':files}));subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',ov,'-o',w/e,'./cmd/g3'],check=True)
else:
 flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l);mk=(build/'Makefile').read_text();inc=shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1])
 # Rebuild th_rewriter.o as well, so all instrumented sources are reproducible.
 inc12=shlex.split(re.search('^includes_12 = (.*)$',mk,re.M)[1])
 k=p.parent/'src/smt/qi_queue.cpp';s=k.read_text();a='m_context.get_rewriter()(instance, s_instance, pr);';assert s.count(a)==1
 dst=w/k.name;dst.write_text('counter measured_ops;\n'+s.replace(a,'measured_ops.begin();'+a+'measured_ops.finish();'))
 objs=[]
 for source,includes in [(dst,inc),(p.parent/'src/ast/rewriter/th_rewriter.cpp',inc12)]:
  obj=w/(source.stem+'.o');subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),'-I'+str(n),*includes,'-include',str(n/'ops.hpp'),'-o',obj,source],cwd=build,check=True);objs.append(obj)
 link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',mk,re.M)[1];libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
 subprocess.run([flags['LINK'],'-o',w/e,*objs,*libs,*shlex.split(flags['LINK_EXTRA_FLAGS'])],cwd=build,check=True)
