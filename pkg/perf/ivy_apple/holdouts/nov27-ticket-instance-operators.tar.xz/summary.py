import csv,collections,statistics
from pathlib import Path
w=Path(__file__).resolve().parent;tot=collections.Counter();counts=collections.Counter()
for r in csv.DictReader((w/'calls.csv').open()):
 q,e=r['query'],r['engine'];k,i,j,n,v,b=map(int,[r[x] for x in ['op','round','instance','calls','raw','blank16']])
 tot[q,e,k,i]+=v-n*b/16
 if i==1:counts[q,e,j,k]=n
p=['empty','subst','unused','quant','variable','constant','find','insert','scope-in','scope-out','push','pop','uf','eq','or','and','not','ite','basic','theory']
for q in sorted({q for q,e,k,i in tot}):
 print(q)
 for k in [1,3,4,5,*range(12,20)]:
  js={j for qq,e,j,kk in counts if qq==q and k==kk}
  assert all(counts[q,'g3',j,k]==counts[q,'z3',j,k] for j in js)
  n=sum(counts[q,'g3',j,k] for j in js)
  if n:
   g,z=[statistics.median(tot[q,e,k,i] for i in range(1,4)) for e in ['g3','z3']]
   print(p[k],n,round(g/1e6,3),round(z/1e6,3),round((g-z)/1e6,3))
