from pathlib import Path
import os,sys,subprocess,json
w=Path(__file__).resolve().parent;pkg=Path.cwd();src=(pkg/'build/.boolean-enode-cost/frontend/goivy').resolve();mod=(pkg/'build/.boolean-enode-cost/heap/study.mod').resolve();prev=Path('/tmp/g3-ivy-pgo')
s=(prev/'bridge.go.txt').read_text()
s=s.replace('first := true','first := true',1)
s=s.replace('finalCheck := check','''if ordinal<2 {fmt.Fprintf(os.Stderr,"GOAL %d %d %q\\n",batch,ordinal+1,zCond.String())}
                finalCheck := check''')
s=s.replace('if proved {','if ordinal<2 {fmt.Fprintf(os.Stderr,"EARLY %d %d %t\\n",batch,ordinal+1,proved)}; if proved {')
s=s.replace('res, err := s.decideZ3With(z3solver, finalCheck)','''if ordinal==1 {if e:=os.WriteFile(fmt.Sprintf("batch-%03d.smt2",batch),[]byte(z3solver.ToSMT2()),0600);e!=nil{panic(e)}}
                res, err := s.decideZ3With(z3solver, finalCheck)
                if ordinal<2{fmt.Fprintf(os.Stderr,"RESULT %d %d %t %t\\n",batch,ordinal+1,res==smt.Unsat,res==smt.Sat)}''')
(w/'bridge.go.txt').write_text(s)
stage='package goivy\nvar stageN int\nfunc newStageBatch()int{stageN++;return stageN}\nfunc startStage(a,b int)func(string){return func(string){}}\n'
(w/'stub.go.txt').write_text(stage)
ov=w/'observer.json';ov.write_text(json.dumps({'Replace':{str(src/'z3bridge_solver_model.go'):str(w/'bridge.go.txt'),str(src/'phase_observer_trial.go'):str(w/'stub.go.txt')}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',ov,'-o',w/'observer','./cmd/goivy_check'],cwd=src,check=True)
ex=Path(sys.argv[1]);spec='examples/ivy/flash2.ivy';ref=prev/'survey/5/1/native'
r=subprocess.run([w/'observer',ex/spec],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True)
lines=r.stderr.splitlines(keepends=True);markers=(b'GOAL ',b'EARLY ',b'RESULT ')
(w/'events.txt').write_bytes(b''.join(l for l in lines if l.startswith(markers)))
assert (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith(markers)))==(1,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),r.stderr[-250:]
