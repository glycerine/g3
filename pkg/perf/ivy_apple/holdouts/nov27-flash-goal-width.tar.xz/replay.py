"""Price dropping direct universal instances on standalone incremental captures of Flash goal two."""
import argparse,csv,os,subprocess,tempfile,time
from pathlib import Path
from bases import parse,expand,conjuncts

def smt(x):
    return x if isinstance(x,str) else '('+' '.join(map(smt,x))+')'

def matches(rule, goal, variables, bindings):
    if isinstance(rule,str):
        if rule in variables:
            return bindings.setdefault(rule,goal)==goal
        return rule==goal
    return (isinstance(goal,tuple) and len(rule)==len(goal)
            and all(matches(p,g,variables,bindings) for p,g in zip(rule,goal)))

def variants(text):
    base,goal=[expand(c[1],{}) for c in parse(text) if c[0]=='assert']
    assert goal[:1]==('and',) and goal[1][0]=='not' and goal[1][1][0]=='and'
    rules=[(c[2],{v for v,_ in c[1]}) for c in conjuncts(base)
           if isinstance(c,tuple) and c[0]=='forall']
    clauses=goal[1][1][1:]
    removed=[i for i,c in enumerate(clauses) if any(matches(p,c,vs,{}) for p,vs in rules)]
    prefix=text[:text.rindex('(assert')]+'(push 1)\n'
    def query(include):
        selected=[c for i,c in enumerate(clauses) if i in include]
        body=smt(('and',*selected)) if selected else 'true'
        return prefix+'(assert (and (not '+body+')))\n(check-sat)\n'
    return len(removed),query(range(len(clauses))),query(set(range(len(clauses)))-set(removed)),query(removed)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for k in ('g3','z3','captures','output','perf'):
        ap.add_argument('--'+k,type=Path,required=True)
    ap.add_argument('--cpu',required=True)
    ap.add_argument('--rounds',type=int,default=3)
    args=ap.parse_args()
    engines={'g3':args.g3.resolve(),'z3':args.z3.resolve()}
    env=dict(os.environ,GOMAXPROCS='1')
    with tempfile.TemporaryDirectory() as tmp,args.output.open('x',newline='') as f:
        out=csv.writer(f)
        out.writerow('batch removed round engine goal instructions cycles elapsed_ms'.split())
        tmp=Path(tmp)
        for src in sorted(args.captures.glob('batch-*.smt2')):
            removed,original,residual,proof=variants(src.read_text())
            for label,text in [('original',original),('residual',residual),('proof',proof)]:
                (tmp/(label+'.smt2')).write_text(text)
            # Check the implication base => removed clauses independently before timing.
            for exe in engines.values():
                r=subprocess.run([exe,tmp/'proof.smt2'],env=env,capture_output=True,timeout=30)
                assert (r.returncode,r.stdout,r.stderr)==(0,b'unsat\n',b''),(src,exe,r)
            runs=[(e,k) for e in engines for k in ('original','residual')]
            for i in range(args.rounds):
                for e,k in runs[i:]+runs[:i]:
                    start=time.monotonic()
                    r=subprocess.run(['taskset','-c',args.cpu,args.perf,'stat','-x,','-o',tmp/'stat','-e','instructions:u,cycles:u','--',engines[e],tmp/(k+'.smt2')],env=env,capture_output=True,timeout=30)
                    ms=(time.monotonic()-start)*1000
                    assert (r.returncode,r.stdout,r.stderr)==(0,b'unsat\n',b''),(src,e,k,r)
                    counters={r[2]:int(r[0]) for r in csv.reader((tmp/'stat').read_text().splitlines()) if len(r)>4 and float(r[4])==100}
                    out.writerow([src.stem,removed,i,e,k,counters['instructions:u'],counters['cycles:u'],ms])
                    f.flush()

if __name__=='__main__':
    main()
