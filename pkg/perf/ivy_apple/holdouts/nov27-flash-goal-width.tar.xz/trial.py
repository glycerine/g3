from pathlib import Path
import os,sys,subprocess,json
w=Path(__file__).resolve().parent;pkg=Path.cwd();front=Path(sys.argv[1]).resolve();mod=Path(sys.argv[2]).resolve();mode=sys.argv[3]
src=pkg/'api/internal/order/universal_premises.go';s=src.read_text()
s+='''
func (p *UniversalPremises) TrialConjuncts(m *ast.ASTManager, assertions []ast.ASTHandle) ([]ast.ASTHandle,int,error) {
 h:=assertions[len(assertions)-1]
 for i:=0;i<8;i++ {hd,e:=m.NodeHeader(h);if e!=nil{return nil,0,e};if hd.Kind!=ast.ASTApp || hd.Family!=m.BasicFamilyID() || hd.NumArgs!=1{return nil,0,nil}
 h,e=m.GetArg(h,0);if e!=nil{return nil,0,e}
 if hd.DeclKind==ast.ASTOpNot{break};if hd.DeclKind!=ast.ASTOpAnd&&hd.DeclKind!=ast.ASTOpOr || i==7{return nil,0,nil}
 }
 hd,e:=m.NodeHeader(h);if e!=nil||hd.Kind!=ast.ASTApp||hd.Family!=m.BasicFamilyID()||hd.DeclKind!=ast.ASTOpAnd||hd.NumArgs<4||hd.NumArgs>128{return nil,0,e}
 ground,e:=m.IsGround(h);if !ground||e!=nil{return nil,0,e}
 if _,e=p.Refutes(m,assertions,150000,true);e!=nil||p.manager!=m||!slices.Equal(p.base,assertions[:len(assertions)-1]){return nil,0,e}
 var keep []ast.ASTHandle; work:=100000
 for i:=uint32(0);i<hd.NumArgs;i++{a,e:=m.GetArg(h,i);if e!=nil{return nil,0,e};if !p.entails(a,true,0,&work){keep=append(keep,a)}}
 return keep,int(hd.NumArgs),nil
}
'''
f=w/(mode+'-universal.go');f.write_text(s);ov={str(src):str(f)}
src=pkg/'api/api_verification_goal.go';s=src.read_text()
code='''keep,total,e:=p.universalPremises.TrialConjuncts(m,assertions)
 if e!=nil{return false,e}
 if total>0 { DIAG
 if len(keep)==0{return !m.ResourceLimit().CancelFlag(),nil}
 if len(keep)<total{
  COPY
 }
 }
 '''
if mode=='skip':code='''_,total,e:=p.universalPremises.TrialConjuncts(m,assertions);if e!=nil{return false,e};if total>0{return false,nil}
 '''
else:
 diag='fmt.Fprintf(os.Stderr,"MATCH %d %d\\n",total,len(keep))' if mode=='count' else ''
 if diag:s=s.replace('import "github','import "fmt"\nimport "os"\nimport "github')
 op='' if mode=='count' else '''local:=append([]ast.ASTHandle(nil),assertions...)
 for _,child:=range keep{
  n,e:=m.MkNot(child);if e!=nil{return false,e};if e=m.IncRef(n);e!=nil{return false,e}
  local[len(local)-1]=n
  yes,e:=p.proveRelevantPremises(m,local)
  de:=m.DecRef(n);if e!=nil{return false,e};if de!=nil{return false,de}
  if !yes||m.ResourceLimit().CancelFlag(){return false,nil}
 }
 return true,nil'''
 code=code.replace('DIAG',diag).replace('COPY',op)
s=s.replace('goal := assertions[len(assertions)-1]',code+'goal := assertions[len(assertions)-1]',1)
f=w/(mode+'-api.go');f.write_text(s);ov[str(src)]=str(f);o=w/(mode+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
