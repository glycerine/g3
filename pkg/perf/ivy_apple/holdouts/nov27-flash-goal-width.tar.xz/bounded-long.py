"""Rotate complete verifier binaries on one CPU and verify exact proof transcripts."""
from pathlib import Path
import csv,json,os,subprocess,sys,time
w=Path(__file__).resolve().parent
ex=Path(sys.argv[1]);gold,longrefs=map(lambda s:Path(s).resolve(),sys.argv[2:4]);cpu,rounds,stem,*cases=sys.argv[4:]
specs={}; engines=['blendivy','blendbounded']
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'));env.pop('GOGC',None)
with (w/(stem+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round engine instructions cycles milliseconds maxrss_kib'.split())
 for name in cases:
  if name=='raft_no_assume':
   spec='examples/raft/raft_no_assume.ivy';iso='';code=0;ref=longrefs/'raft-holdout'/name/'1/native'
  elif name in specs:
   spec,iso,code=specs[name];ref=gold/'reference'/name
  else:
   spec='doc/examples/apple/ord_live.ivy';iso=name;code=0;ref=longrefs/'apple-holdout'/name/'1/native'
  expected=code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()
  for i in range(int(rounds)):
   offset=i%len(engines)
   for engine in engines[offset:]+engines[:offset]:
    d=w/('log-'+stem+'-'+engine);d.mkdir(exist_ok=True)
    counts=d/'counts';rss=d/'rss';cmd=['taskset','-c',cpu,perf,'stat','-x,','-o',counts,'-e','instructions:u,cycles:u','--','/usr/bin/time','-q','-o',rss,'-f','%M',w/(('apple-' if name in ('dramc_nb2','rfn2') else '')+engine)]+(['isolate='+iso] if iso else [])+[ex/spec]
    start=time.monotonic();r=subprocess.run(cmd,cwd=d,capture_output=True,env=env,timeout=240);ms=(time.monotonic()-start)*1000
    assert (r.returncode,r.stdout,r.stderr)==expected,(name,engine,r.returncode,r.stderr[-200:])
    hw={row[2]:int(row[0]) for row in csv.reader(counts.read_text().splitlines()) if len(row)>4 and float(row[4])==100.0}
    out.writerow((name,i,engine,hw['instructions:u'],hw['cycles:u'],ms,int(rss.read_text())));f.flush()
  print(name,flush=True)
