from pathlib import Path
import gzip,collections
w=Path(__file__).resolve().parent
for n in (8,4):
 d={}
 for line in gzip.open(w/f'g3-{n}.log.gz','rt'):
  t,*v=line.removeprefix('EVENT ').split()
  if t=='START':k=v[0];d[k]=[0,set(),set(),set(),set(),set()]
  else:
   x=d[k]
   if t=='Q':x[0]+=1
   if t=='CREATED':
    i=int(v[0]);assert i==x[0];x[1].add(i)
    if v[1]=='true':x[2].add(i)
   if t=='USED':
    i=int(v[0]);assert i in x[1];x[3].add(i)
    if v[1]=='true':x[4].add(i)
    if v[2]=='terminal':x[5].add(i)
 for k,x in d.items():print(n,k,x[0],*[len(v) for v in x[1:]])
