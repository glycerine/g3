from pathlib import Path
import gzip,collections
w=Path(__file__).resolve().parent
def quantifier(shape):
 a=shape.index('(forall ');depth=0
 for j in range(a,len(shape)):
  if shape[j]=='(':depth+=1
  if shape[j]==')':
   depth-=1
   if not depth:return shape[a:j+1]
 raise ValueError(shape)
def report(k):
 if not k:return
 tp=len(used&pred);print(k,len(q),len(used),len(pred),tp,len(set(q[i] for i in used)),len(set(q.values())))
for n in (8,4):
 k=''
 for line in gzip.open(w/f'g3-{n}.log.gz','rt'):
  t,_,v=line.strip().removeprefix('EVENT ').partition(' ')
  if t=='START':
   report(k);k=v;q={};seen=set();pred=set();used=set()
  elif t=='Q':
   i=len(q)+1;q[i]=quantifier(v)
   if q[i] in seen:pred.add(i)
  elif t=='USED':
   i=int(v.split()[0]);used.add(i);seen.add(q[i])
 report(k)
