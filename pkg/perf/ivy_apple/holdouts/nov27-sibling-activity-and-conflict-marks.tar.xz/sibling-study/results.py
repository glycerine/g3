from pathlib import Path
import os,json,csv,subprocess as sp,tempfile
p=Path.cwd();w=Path(__file__).resolve().parent;rank=Path(os.environ['NNF_REFERENCE']);names=(rank/'compat.txt').read_text().splitlines();ex=Path(os.environ['IVY_EXAMPLES']).resolve();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=td,GOTMPDIR=td)
 path=p/'smtcore/smt_kernel_results.go';src=path.read_text()
 for mode in ['base','capture','ceiling']:
  s=src
  if mode=='capture':
   a=s.index('\tclear(pending.held)');b=s.index('\t*pending =',a);s=s[:a]+s[b:]
   a=s.index('if !k.relevancy.IsRelevant(expression)');b=s.index('if value != lbool.True',a)
   old=s[a:b];i=old.index('item, err :=');j=old.index('\n\t\t}',i)
   s=s[:a]+'''// Both result lists require an assigned literal.
  value:=k.internalizer.assignment[NewSMTLiteral(variable,false).Index()]
  if value==lbool.Undef || !k.relevancy.IsRelevant(expression){continue}
  '''+old[i:j]+'\n\t\t'+s[b:]
  if mode=='ceiling':
   k='func (k *SMTKernel) captureLiteralResultsHeld(';a=s.index('{',s.index(k))+1;s=s[:a]+'\nif !held{return k.releasePendingResults()}\n'+s[a:]
  f=d/(mode+'.go');f.write_text(s);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt')}};ov['Replace'][str(path)]=str(f);j=d/(mode+'.json');j.write_text(json.dumps(ov))
  sp.run(['go','build','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-overlay',j,'-mod=readonly','-buildvcs=false','-o',d/mode,'./cmd/goivy_check'],cwd=front,env=env,check=True)
 with (w/'results.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case round mode instructions status'.split())
  for n in [2,4,8,3,6,7,9,12]:
   gold=rank/f'compat/{n}/1/native'
   for i in range(5):
    modes=['base','capture','ceiling']
    for m in modes[i%3:]+modes[:i%3]:
     st=d/'stat';r=sp.run(['taskset','-c',os.environ.get('CPU','18'),os.environ.get('PERF','perf'),'stat','-x,','-e','instructions:u','-o',st,'--',d/m,ex/names[n-1]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=120);status=(r.returncode,r.stdout,r.stderr)==(0,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes())
     v,=[int(x[0]) for x in csv.reader(st.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100];o.writerow([n,i,m,v,'match' if status else 'different']);f.flush()
