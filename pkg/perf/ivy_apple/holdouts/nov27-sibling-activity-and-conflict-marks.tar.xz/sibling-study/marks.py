from pathlib import Path
import os,json,subprocess as sp,tempfile
p=Path.cwd();w=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=td,GOTMPDIR=td)
 b=p/'smtcore/smt_conflict_levels_benchmark_test.go';s=b.read_text();a=s.index('func Benchmark');s=s[:a]+s[a:].replace('BenchmarkSMTBinaryConflictLevels','BenchmarkSMTLearnedConflictMarks').replace('[]int{64, 1024, 8192}','[]int{64, 1024, 8192, 65536}').replace('benchmarkMust(b, w.s.AssignLiteral(a,','benchmarkMust(b, w.s.PushScope());benchmarkMust(b, w.s.AssignLiteral(a,').replace('benchmarkMust(b, w.s.AssignLiteral(z,','benchmarkMust(b, w.s.PushScope());benchmarkMust(b, w.s.AssignLiteral(z,').replace('if err != nil || result.Resolved','if err != nil || !result.Resolved || len(result.Lemma)!=2');bench=w/'bench-marks.go.txt';bench.write_text(s)
 path=p/'smtcore/smt_conflict_resolver.go';s=path.read_text().replace('\n\t\tclear(r.marks)','');k='marks := r.resetMarks()';assert s.count(k)==1;s=s.replace(k,k+'''\n// Successful resolution clears the UIP and each remaining lemma mark.
 defer func(){if resolveErr!=nil {clear(marks)}}()
''');mod=w/'marks.go.txt';mod.write_text(s)
 for mode in ('base','trial'):
  ov={str(b):str(bench)}
  if mode=='trial':ov[str(path)]=str(mod)
  j=d/(mode+'.json');j.write_text(json.dumps({'Replace':ov}));sp.run(['go','test','-c','-overlay',j,'-o',d/mode,'./smtcore'],env=env,check=True)
 for i in range(5):
  for m in (('base','trial') if i%2==0 else ('trial','base')):
   with (w/(m+'.bench')).open('a') as f:
    sp.run(['taskset','-c',os.environ.get('CPU','24'),d/m,'-test.run','^$','-test.bench','^BenchmarkSMTLearnedConflictMarks$','-test.benchtime','40000x'],env=env,stdout=f,check=True,cwd=p/'smtcore')
