from pathlib import Path
import os,json,csv,subprocess as sp,tempfile
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();rank=Path(os.environ['NNF_REFERENCE']);names=(rank/'compat.txt').read_text().splitlines();ex=Path(os.environ['IVY_EXAMPLES']).resolve()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace'];rep[str(front/'phase_observer_trial.go')]=str(w/'row-timer.go.txt')
 path=p/'smtcore/smt_kernel_results.go';s=path.read_text().replace('import (','import ("os";"fmt";"strconv";"syscall";"unsafe";');start=(w/'restore.txt').read_text();s+='\n'+start[start.index('func stateRead()'):start.index('func intervene(')]
 for func,op in [('captureLiteralResultsHeld','capture'),('materializeLiteralResults','query')]:
  a=s.index('{',s.index('func (k *SMTKernel) '+func+'('))+1
  s=s[:a]+'''if os.Getenv("NNF_FD")!=""{a:=stateRead();defer func(){v:=stateRead()-a;fmt.Fprintln(os.Stderr,"CAPTURE","'''+op+'''",len(k.internalizer.boolExpr),len(k.internalizer.assignedLiterals),v)}()}
'''+s[a:]
 f=d/'results.go';f.write_text(s);rep[str(path)]=str(f);j=d/'obs.json';j.write_text(json.dumps(ov));exe=d/'observer'
 sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=td,GOTMPDIR=td,GOCACHE=str(d/'cache')),check=True)
 with (w/'capture-cost.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case round batch goal phase operation variables assigned instructions'.split())
  for n in (4,2,8,3):
   ref=rank/f'compat/{n}/1/native'
   for i in range(3):
    r=sp.run(['taskset','-c',os.environ.get('CPU','26'),exe,ex/names[n-1]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=90);rest=bytearray();rows=[]
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'CAPTURE '):rows.append(l.decode().split()[1:])
     elif l.startswith(b'STAGE-COUNT '):
      _,b,g,ph,_,_,en,ac,_=l.decode().split();assert en==ac
      for row in rows:o.writerow([n,i,b,g,ph,*row])
      rows=[]
     else:rest.extend(l)
    assert not rows and (r.returncode,r.stdout,rest)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
