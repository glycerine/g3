from pathlib import Path
import os,json,csv,subprocess as sp,tempfile
p=Path.cwd();w=Path(__file__).resolve().parent;rank=Path(os.environ['NNF_REFERENCE']);names=(rank/'compat.txt').read_text().splitlines();ex=Path(os.environ['IVY_EXAMPLES']).resolve();front=Path(os.environ['GOIVY_FRONTEND']).resolve();codes={x['case']:int(x['exit']) for x in csv.DictReader((rank/'ranking.csv').open())}
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=td,GOTMPDIR=td);path=p/'smtcore/smt_kernel.go';s=path.read_text().replace('import (','import ("os";z3rand "github.com/glycerine/g3/pkg/util/random";').replace('type SMTKernel struct {','type SMTKernel struct {\n studyScopes []siblingState');k='k.scopes = append(k.scopes, len(k.assertions))';assert s.count(k)==1;s=s.replace(k,'if studyPolicy!=""{k.rememberSibling()};'+k);k='k.scopes = k.scopes[:pop.level]';assert s.count(k)==1;s=s.replace(k,'if studyPolicy!=""{if e:=k.restoreSibling(pop.level);e!=nil{return e}};'+k)+(w/'policy.txt').read_text()
 f=d/'kernel.go';f.write_text(s);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt')}};ov['Replace'][str(path)]=str(f);j=d/'trial.json';j.write_text(json.dumps(ov));exe=d/'run'
 sp.run(['go','build','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-overlay',j,'-mod=readonly','-buildvcs=false','-o',exe,'./cmd/goivy_check'],cwd=front,env=env,check=True)
 with (w/'policy.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case round mode instructions status'.split())
  for n in [8,3,4,2,6,7,9,12,10,11,5,1]:
   gold=rank/f'compat/{n}/1/native'
   for i in range(3):
    modes=['','rng','activity','both']
    for m in modes[i%4:]+modes[:i%4]:
     st=d/'stat';r=sp.run(['taskset','-c',os.environ.get('CPU','22'),os.environ.get('PERF','perf'),'stat','-x,','-e','instructions:u','-o',st,'--',exe,ex/names[n-1]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',SIBLING_POLICY=m,XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=120)
     status=(r.returncode,r.stdout,r.stderr)==(codes[names[n-1]],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes())
     if not status:(w/f'error-{n}-{m}.txt').write_bytes(r.stderr[-2000:])
     v,=[int(x[0]) for x in csv.reader(st.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100];o.writerow([n,i,m or 'off',v,'match' if status else 'different']);f.flush()
