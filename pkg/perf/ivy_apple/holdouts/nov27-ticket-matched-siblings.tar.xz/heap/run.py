from pathlib import Path
import csv,subprocess,os
w=Path(__file__).resolve().parent; d=Path(os.environ['FOCUS_BIN']); ex=Path('/home/jaten/ivy/ivy-lang-examples'); names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines(); name=next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy'));ref=Path('/tmp/g3-reduction-rows/compat')/str(names.index(name)+1)/'1/native'
with (w/'heap.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round gc batch goal bytes objects collections end_heap_bytes'.split())
 for i in range(7):
  for gc in ['100','off'][::1 if i%2==0 else -1]+(['profile'] if i==6 else []):
   env=dict(os.environ,GOMAXPROCS='1',GOGC=gc if gc!='profile' else '100',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
   if gc=='profile':env['ALLOC_PROFILE']=str(w)
   r=subprocess.run(['taskset','-c','18',d/'heap',ex/name],env=env,cwd=d,capture_output=True);ls=r.stderr.splitlines(keepends=True);rows=[x.split()[1:] for x in ls if x.startswith(b'HEAP ')]
   assert (r.returncode,r.stdout,b''.join(x for x in ls if not x.startswith((b'HEAP ',b'WINDOW '))))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());assert len(rows)==4
   out.writerows([i,gc,*map(int,x)] for x in rows);f.flush()
