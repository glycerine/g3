from pathlib import Path
import os,json,subprocess
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);p=Path.cwd();front=p/'build/.boolean-enode-cost/frontend/goivy';src=(w.parent/'window.go.txt').read_text().replace('"runtime"','"runtime";"runtime/pprof";"path/filepath"')
src=src.replace('func sampleClock()', '''func init(){if os.Getenv("ALLOC_PROFILE")!=""{runtime.MemProfileRate=512}}
func recordProfile(batch,goal int,when string){runtime.GC();runtime.GC(); f,err:=os.Create(filepath.Join(os.Getenv("ALLOC_PROFILE"),fmt.Sprintf("%d-%d-%s.pb",batch,goal,when)));if err!=nil{panic(err)};if err=pprof.Lookup("allocs").WriteTo(f,0);err!=nil{panic(err)}; if err=f.Close();err!=nil{panic(err)}}
func sampleClock()''')
src=src.replace('start:=sampleClock()','''snap:=os.Getenv("ALLOC_PROFILE")!="" && batch==4 && goal==55
    if snap{recordProfile(batch,goal,"before")}
    var a,b runtime.MemStats;runtime.ReadMemStats(&a)
    start:=sampleClock()''').replace('end:=sampleClock()','''end:=sampleClock();runtime.ReadMemStats(&b)
        fmt.Fprintln(os.Stderr,"HEAP",batch,goal,b.TotalAlloc-a.TotalAlloc,b.Mallocs-a.Mallocs,b.NumGC-a.NumGC,b.HeapAlloc)
        if snap{recordProfile(batch,goal,"after")}''')
(w/'heap.go.txt').write_text(src);o=w/'overlay.json';o.write_text(json.dumps({'Replace':{str((front/'z3bridge_solver_model.go').resolve()):str(w.parent/'bridge.go.txt'),str((front/'focus_trial.go').resolve()):str(w/'heap.go.txt')}}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/'heap','./cmd/goivy_check'],cwd=front,check=True)
