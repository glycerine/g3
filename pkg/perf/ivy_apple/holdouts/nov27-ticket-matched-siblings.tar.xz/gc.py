from pathlib import Path
import os,csv,subprocess,time
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);ex=Path('/home/jaten/ivy/ivy-lang-examples');names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines();name=next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy'));gold=Path('/tmp/g3-reduction-rows/compat')/str(names.index(name)+1)/'1/native';perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'gc.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round engine gc batch goal instructions ms rss_kib'.split())
 modes=[(e,gc) for gc in ['100','200','off'] for e in ['g3','z3']]
 for i in range(9):
  for e,gc in modes[i%6:]+modes[:i%6]:
   start=time.monotonic();r=subprocess.run(['taskset','-c','22','/usr/bin/time','-o',w/'rss','-f','%M',perf,'stat','-x,','-o',w/'stat','-e','instructions:u','--',d/e,ex/name],cwd=d,env=dict(os.environ,GOGC=gc,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True);ms=1000*(time.monotonic()-start)
   lines=r.stderr.splitlines(keepends=True);assert (r.returncode,r.stdout,b''.join(x for x in lines if not x.startswith(b'STAGE-COUNT ')))==(0,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes())
   for l in lines:
    if l.startswith(b'STAGE-COUNT '):
     _,b,g,stage,num,empty,en,run,ns=l.split();assert en==run;out.writerow([i,e,gc,int(b),int(g),int(num),int(ns)/1e6,''])
   stat=next(row[0] for row in csv.reader((w/'stat').open()) if len(row)>4 and row[2]=='instructions:u' and float(row[4])==100)
   out.writerow([i,e,gc,0,0,stat,ms,(w/'rss').read_text().strip()]);f.flush()
