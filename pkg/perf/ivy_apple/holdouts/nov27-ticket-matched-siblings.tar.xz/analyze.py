from pathlib import Path
from collections import Counter,defaultdict
import csv
w=Path(__file__).resolve().parent;cnt=Counter();leaves=Counter();rounds=defaultdict(set)
for r in csv.DictReader((w/'samples.csv').open()):
 b,g,i=map(int,[r['batch'],r['goal'],r['round']]); e=r['engine']; k=(b,g,e);s=r['stack']; rounds[k].add(i);weight=int(r['period'])*int(r['count'])
 inst=any(x in s for x in ['(*SMTQuantifierManager).Propagate.func1','(*SMTQuantifierManager).instantiate\n','smt::qi_queue::instantiate(smt::qi_queue::entry&)'])
 tags=[('substitute',['(*SMTCachedVarSubstitution).Instantiate','cached_var_subst::operator()']),('rewrite',['(*TheoryRewriter).Rewrite','(*rewriterEngine).Rewrite','rewriter_tpl<th_rewriter_cfg>','th_rewriter::operator()']),('assert',['(*SMTInternalizerState).assertExpression','smt::context::internalize_assertion']),('check model of instance',['(*SMTChecker).run','smt::checker::is_sat'])] if inst else [('conflict',['(*SMTKernel).resolveSearchConflict','smt::context::resolve_conflict(']),('preprocess',['(*SMTKernel).internalizeCheckAssertions','smt::context::internalize_assertions(']),('matching',['(*smtMAMImpl).Match','smt::mam_impl::match(']),('propagate',['(*SMTInternalizerState).PropagateCore','smt::context::propagate('])]
 cat=next((key for key,terms in tags if any(t in s for t in terms)), 'other instance' if inst else 'other solver')
 cnt[k,cat]+=weight
 leaves[k,cat,s.splitlines()[0]]+=weight
with (w/'phases.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['batch','goal','category','g3_M','Z3_M','excess_M'])
 for b,g in [(4,55),(4,56),(5,55),(5,56)]:
  rows=[]
  for cat in sorted(set(q[1] for q in cnt)):
   a,z=[cnt[(b,g,e),cat]/max(1,len(rounds[b,g,e]))/1e6 for e in ['g3','z3']];rows.append((a-z,cat,a,z))
  for delta,cat,a,z in sorted(rows,reverse=True):out.writerow([b,g,cat,*map(lambda v:round(v,3),(a,z,delta))])
with (w/'leaves.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['batch','goal','engine','category','leaf','millions'])
 for (k,cat,leaf),v in leaves.most_common():out.writerow([*k,cat,leaf,round(v/len(rounds[k])/1e6,3)])
