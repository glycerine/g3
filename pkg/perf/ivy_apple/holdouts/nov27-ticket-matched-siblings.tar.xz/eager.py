from pathlib import Path
import subprocess,json,os,csv,time
p=Path.cwd();w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN'])
f=p/'smtcore/smt_qi_queue_schedule.go'
src=f.read_text().replace('import "github.com','import "os"\nimport "github.com',1)
key='type SMTQIQueueEntry struct';src=src.replace(key,'var studyEager=os.Getenv("G3_EAGER_TRIAL")\n'+key)
anchor='sinceLastCheck := 0'
src=src.replace(anchor,'''threshold:=q.eagerThreshold
    if threshold==10 {
        switch studyEager {
        case "zero":threshold=0
        case "two":threshold=2
        case "burst":if len(q.newEntries)>=16{threshold=2}
        }
    }
    '''+anchor).replace('entry.Cost <= q.eagerThreshold','entry.Cost <= threshold')
(w/'eager.go.txt').write_text(src)
front=p/'build/.boolean-enode-cost/frontend/goivy';o=w/'eager.json';o.write_text(json.dumps({'Replace':{str(f):str(w/'eager.go.txt')}}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/'eager','./cmd/goivy_check'],cwd=front,check=True)
s=Path('/tmp/g3-plan-replay/final/outliers.py').read_text()
s=s[:s.index('modes=')]+"""modes={k:d/'eager' for k in ['base','zero','two','burst']}
"""+s[s.index('def run'):s.rindex('run(12,')]
s=s.replace("dict(os.environ,GOMAXPROCS","dict(os.environ,G3_EAGER_TRIAL=m,GOMAXPROCS")
exec(s)
names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
cases2=[next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy')),'examples/liveness/ticket.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/arm_rules3.ivy','test/flash2.ivy']
run(20,'eager',cases2,5,['base','zero','two','burst'])
