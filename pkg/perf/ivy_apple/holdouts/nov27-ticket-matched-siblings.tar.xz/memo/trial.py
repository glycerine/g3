from pathlib import Path
import os,json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);front=p/'build/.boolean-enode-cost/frontend/goivy';f=p/'smtcore/smt_checker_candidate.go';src=f.read_text()
for mode in ['selective','static']:
 s=src.replace('return c.checkCandidate(p, 0, want)','if _, err := c.context.manager.GetRefCount(p.body); err != nil { return false,err };return c.checkCandidate(p, 0, want)')
 for fail in ['nil','false']:
  key='refs, err := c.context.manager.GetRefCount(n.expression)\n\tif err != nil {\n\t\treturn '+fail+', err\n\t}'
  assert s.count(key)==1
  s=s.replace(key,"refs := uint32(2)"+('''
        if n.memo!=0 {var err error; refs,err=c.context.manager.GetRefCount(n.expression); if err!=nil{return '''+fail+',err}}' if mode=='selective' else ''))
 f2=w/(mode+'.go.txt');f2.write_text(s);o=w/(mode+'.json');o.write_text(json.dumps({'Replace':{str(f):str(f2)}}))
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/('memo-'+mode),'./cmd/goivy_check'],cwd=front,check=True)
