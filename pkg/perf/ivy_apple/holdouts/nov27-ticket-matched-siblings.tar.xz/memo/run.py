from pathlib import Path
s=Path('/tmp/g3-ticket-focus/operands/run.py').read_text().replace("'reuse':d/'operands-plain'","**{m:d/('memo-'+m) for m in ['selective','static']}").replace("run(12,'operands',cases2,9,['base','reuse'])","run(22,'memo',cases2,7,['base','selective','static'])")
exec(s)
