from pathlib import Path
import os,subprocess
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']); env=dict(os.environ,TMPDIR='/wd_black1tb/home/jaten/tmp')
for mode in ['base','selective','static']:
 args=[] if mode=='base' else ['-overlay='+str(w/(mode+'.json'))]
 subprocess.run(['go','test',*args,'-c','-o',d/('memo-bench-'+mode),'./smtcore'],check=True,env=env)
with (w/'bench.txt').open('w') as f:
 for i in range(7):
  modes=['base','selective','static']
  for m in modes[i%3:]+modes[:i%3]:
   s=subprocess.check_output(['taskset','-c','10',d/('memo-bench-'+m),'-test.run=^$','-test.bench=^BenchmarkSMTQuantifierCandidate$/^Width(1|16|64)$/./(RegisteredChecker|Queue)$','-test.benchtime=15000x','-test.benchmem'],env=dict(os.environ,GOMAXPROCS='1'),text=True)
   assert 'BenchmarkSMT' in s,s;f.write(f'round {i} {m}\n{s}');f.flush()
