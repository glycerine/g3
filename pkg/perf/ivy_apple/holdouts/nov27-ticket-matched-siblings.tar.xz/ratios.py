import statistics as st,csv,collections
from pathlib import Path
w=Path(__file__).resolve().parent
for fname in ['watch','queue','eager','held','guard','long']:
 f=w/(fname+'.csv')
 if not f.exists():continue
 groups=collections.defaultdict(dict)
 for r in csv.DictReader(f.open()):
  if r['status']=='match':groups[r['case']][r['mode'],r['round']]=r
  else: print(r['case'],r['status'])
 for case,v in groups.items():
  for m in sorted({e for e,i in v}-{'base'}):
   pairs=[(r,v['base',i]) for (e,i),r in v.items() if e==m and ('base',i) in v]
   if pairs:print(fname,Path(case).stem,m,len(pairs),*[round(st.median(100*(float(x[k])/float(b[k])-1) for x,b in pairs),2) for k in ['instructions','ms']])
