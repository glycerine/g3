from pathlib import Path
w=Path(__file__).resolve().parent;d=w/'verified-panel';d.mkdir(exist_ok=True)
s=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0];s=s[s.index('import subprocess'):];s=s.replace('w=Path(__file__).resolve().parent;','');s=s[:s.index('subprocess.run([*flags')]+s[s.index('def run'):]
abc=Path('/wd_black1tb/home/jaten/tmp/g3-ticket-focus/abc')
if not abc.exists():abc.symlink_to('/tmp/g3-frame-child/abc')
modes={'reuse':Path('/wd_black1tb/home/jaten/tmp/g3-ticket-focus/operands-plain')};w=d;exec(s)
with concurrent.futures.ThreadPoolExecutor(8) as pool:
 jobs=[pool.submit(run,1+2*i,'panel'+str(i),cases[i::8],1,['reuse']) for i in range(8)]
 for job in jobs:job.result()
