from pathlib import Path
import os,json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);f=p/'smtcore/smt_qi_instance.go';s=f.read_text()
s=s.replace('registry *SMTQuantifierRegistry','registry *SMTQuantifierRegistry\n operandScratch []ast.ASTHandle',1)
s=s.replace('locals.release(b.manager)','locals.release(b)').replace('release(m *ast.ASTManager) (err error) {','release(b *SMTQIInstanceBuilder) (err error) {\n m:=b.manager\n if len(l.arguments)>0 && cap(l.arguments)<=32 {b.operandScratch=l.arguments[:0]}')
s=s.replace('args := make([]ast.ASTHandle, 1+int(head.NumArgs))','''count:=1+int(head.NumArgs)
            var args []ast.ASTHandle
            if arguments!=nil && cap(b.operandScratch)>=count {
                args=b.operandScratch[:count]; b.operandScratch=nil
            }else{args=make([]ast.ASTHandle,count)}''')
(w/'instance.go.txt').write_text(s);front=p/'build/.boolean-enode-cost/frontend/goivy'
for name,root in [('plain',{}),('direct',json.loads((w.parent/'direct/overlay.json').read_text())['Replace']),('heap',json.loads((w.parent/'heap/overlay.json').read_text())['Replace'])]:
 o=w/(name+'.json');root[str(f)]=str(w/'instance.go.txt');o.write_text(json.dumps({'Replace':root}))
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/('operands-'+name),'./cmd/goivy_check'],cwd=front,check=True)
