from pathlib import Path
import os,csv,subprocess
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN'])
s=Path('/tmp/g3-plan-replay/final/outliers.py').read_text()
s=s[:s.index('modes=')]+"""modes={'base':Path('/tmp/g3-plan-replay/final/release'),'reuse':d/'operands-plain'}
"""+s[s.index('def run'):s.rindex('run(12,')]
exec(s)
names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
cases2=[next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy')),'examples/liveness/ticket.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/arm_rules3.ivy','test/flash2.ivy']
run(12,'operands',cases2,9,['base','reuse'])
