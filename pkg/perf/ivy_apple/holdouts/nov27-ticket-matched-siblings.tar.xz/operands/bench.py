from pathlib import Path
import os,subprocess
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN'])
with (w/'benchmark.txt').open('w') as f:
 for i in range(11):
  for m in ['base','reuse'][::1 if i%2==0 else -1]:
   exe=d/('operand-base-bench' if m=='base' else 'operand-bench');s=subprocess.check_output(['taskset','-c','18',exe,'-test.run=^$','-test.bench=^BenchmarkSMTQuantifierLemmaOperands$','-test.benchtime=20000x','-test.benchmem'],text=True,env=dict(os.environ,GOMAXPROCS='1'))
   assert 'BenchmarkSMT' in s;f.write(f'round {i} {m}\n{s}');f.flush()
