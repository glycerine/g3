from pathlib import Path
import os,csv,subprocess
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);ex=Path('/home/jaten/ivy/ivy-lang-examples');names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines();name=next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy'));ref=Path('/tmp/g3-reduction-rows/compat')/str(names.index(name)+1)/'1/native'
with (w/'goal.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round mode observer batch goal instructions bytes allocations'.split())
 for i in range(7):
  for mode in ['base','reuse'][::1 if i%2==0 else -1]:
   for obs in ['heap','direct']:
    exe=d/('operands-'+obs) if mode=='reuse' else (d/'heap' if obs=='heap' else Path(str(d)+'-direct/g3'))
    r=subprocess.run(['taskset','-c','18',exe,ex/name],cwd=d,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')));ls=r.stderr.splitlines(keepends=True)
    assert (r.returncode,r.stdout,b''.join(x for x in ls if not x.startswith((b'HEAP ',b'WINDOW ',b'STAGE-COUNT '))))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    rows=0
    for l in ls:
     x=l.split()
     if l.startswith(b'HEAP '):out.writerow([i,mode,obs,int(x[1]),int(x[2]),'',int(x[3]),int(x[4])]);rows+=1
     if l.startswith(b'STAGE-COUNT '):assert x[6]==x[7];out.writerow([i,mode,obs,int(x[1]),int(x[2]),int(x[4]),'','']);rows+=1
    assert rows==4;f.flush()
