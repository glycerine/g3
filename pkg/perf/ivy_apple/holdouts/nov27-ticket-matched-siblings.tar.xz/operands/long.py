from pathlib import Path
s=Path('/tmp/g3-plan-budget/long.py').read_text()
a=s.index('for mode in');b=s.index('ex=Path',a)
s=s[:a]+"""subprocess.run([*flags,'-o',bin/'apple-operands','./cmd/goivy_check'],cwd=front,check=True)
"""+s[b:]
s=s.replace('g3-nov27-private-budget','g3-ticket-focus').replace("modes=['base','256','512']","modes=['base','reuse']").replace("for m in modes[i:]+modes[:i]:","for m in modes[i%2:]+modes[:i%2]:").replace("exe=bin/m if apple else (Path('/tmp/g3-live-frame-cost/recheck/baseline') if m=='base' else w/m/'release')","exe=(Path('/wd_black1tb/home/jaten/tmp/g3-nov27-final-model/final') if m=='base' else bin/'apple-operands') if apple else (Path('/tmp/g3-plan-replay/final/release') if m=='base' else bin/'operands-plain')")
exec(s)
