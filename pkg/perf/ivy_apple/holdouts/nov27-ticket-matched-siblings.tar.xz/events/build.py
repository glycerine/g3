from pathlib import Path
import os,shutil,shlex,subprocess,json,re
p=Path.cwd();w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);d.mkdir(exist_ok=True)
front=p/'build/.boolean-enode-cost/frontend/goivy'
windows=(w.parent/'window.go.txt').read_text().replace('tid:=syscall.Gettid()','tid:=syscall.Gettid(); os.Setenv("TICKET_WINDOW",fmt.Sprintf("%d/%d",batch,goal))').replace('end:=sampleClock()','os.Unsetenv("TICKET_WINDOW"); end:=sampleClock()')
(w/'window.go.txt').write_text(windows)
base={str((front/'z3bridge_solver_model.go').resolve()):str(w.parent/'bridge.go.txt'),str((front/'focus_trial.go').resolve()):str(w/'window.go.txt')}
for eng in (['z3'] if os.environ.get('NATIVE_ONLY') else ['g3','z3']):
 ov=base.copy()
 if eng=='g3':
  f=p/'smtcore/smt_qi_instance.go';s=f.read_text().replace('import (','import ("os";',1)
  s+='\nfunc studyEvent(kind string){if k:=os.Getenv("TICKET_WINDOW"); k!=""{println("FOCUS",k,kind)}}\n'
  for anchor,kind in [('if satisfied {','satisfied'),('if b.manager.IsTrue(simplified) {','true'),('stat.IncrementInstances()','assert')]:
   k=anchor+'studyEvent("'+kind+'");' if anchor.endswith('{') else 'studyEvent("'+kind+'");'+anchor
   assert s.count(anchor)==1,anchor;s=s.replace(anchor,k)
  f2=w/'instance.go.txt';f2.write_text(s);ov[str(f)]=str(f2)
 else:
  build=p.parent/'build';cc=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
  inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1]);lib=d/'lib-focus.a'
  shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
  f=p.parent/'src/smt/qi_queue.cpp';s='#include <cstdlib>\n#include <cstdio>\nstatic void study_event(char const* kind){if (auto w=getenv("TICKET_WINDOW")) fprintf(stderr,"FOCUS %s %s\\n",w,kind);}\n'+f.read_text()
  for anchor,kind in [('if (m_checker.is_sat(q->get_expr(), num_bindings, bindings)) {','satisfied'),('if (m_manager.is_true(s_instance)) {','true'),('stat->inc_num_instances();','assert')]:
   assert s.count(anchor)>=1,anchor;s=s.replace(anchor,anchor+'study_event("'+kind+'");',1)
  f2=w/'qi_queue.cpp';f2.write_text(s);obj=d/'qi_queue.o'
  subprocess.run([cc['CXX'],*shlex.split(cc['CXXFLAGS']),*inc,'-o',obj,f2],cwd=build,check=True)
  subprocess.run(['ar','r',lib,obj],check=True)
  f=front/'smt/quantifier.go';f2=w/'quantifier.go';f2.write_text(f.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));ov[str(f.resolve())]=str(f2)
 o=w/(eng+'.json');o.write_text(json.dumps({'Replace':ov}))
 subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off'+(',classic_z3' if eng=='z3' else ''),'-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/eng,'./cmd/goivy_check'],cwd=front,check=True)
