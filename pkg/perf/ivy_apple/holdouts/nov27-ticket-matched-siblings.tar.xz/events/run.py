from collections import Counter
from pathlib import Path
import subprocess,os,csv
w=Path(__file__).resolve().parent; d=Path(os.environ['FOCUS_BIN']); ex=Path('/home/jaten/ivy/ivy-lang-examples');names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines();name=next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy'));ref=Path('/tmp/g3-reduction-rows/compat')/str(names.index(name)+1)/'1/native'
with (w/'events.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','engine','goal','satisfied','true','assert'])
 for i in range(3):
  for m in ['g3','z3'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','14',d/m,ex/name],cwd=d,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOGC='100',GOIVY_INCLUDE=str(ex/'ivy/include')))
   keep=[];counts=Counter();windows=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'WINDOW '):windows.append(l)
    elif l.startswith(b'FOCUS '):_,goal,cat=l.decode().split();counts[goal,cat]+=1
    else:keep.append(l)
   assert (r.returncode,r.stdout,b''.join(keep))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());assert len(windows)==4
   for goal in sorted(set(k for k,_ in counts)):out.writerow([i,m,goal,*[counts[goal,cat] for cat in ['satisfied','true','assert']]])
   assert len(set(k for k,_ in counts))==4;f.flush()
