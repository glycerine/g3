# November 27 Ticket study

Production commits a656e6f29 and e977d5f08. From pkg run
`go test ./smtcore -run '^$' -bench '^BenchmarkSMTQuantifierLemma' -benchmem`.
The sibling and verifier-level studies also require the matching GoIvy frontend,
Ivy examples, native library built from this fork, and Linux perf counters.
The Python drivers retain the original machine paths, CPU affinity, and perf
binary. Adapt these paths on another machine. Overlay JSON records the mappings
used for the instrumented executables. The deps directory includes shared
drivers used across earlier studies. No executable binaries are bundled.

- direct, events, prices and aggregate contain the window and event counts.
- heap contains before/after heap profiles and allocation reports. Samples
  taken during profile emission are identified separately from solver work.
- operands and memo contain individual experiments. verified contains the final
  combined counts, full-suite results, panel checks and rotated release runs.
- reuse/3, 6 and 8 are the complete original SMT snapshots for POPL18,
  nested Ticket and L2S. reuse/hits contains independent check formulas.
  The analysis, intersection, core, weights and ceiling scripts produce the
  corresponding CSVs. regenerate the expanded intersections and selector
  formulas with intersect.py and cores.py. The native core helper is core.c.
  Compile from pkg using cc -I../src/api -c path/to/core.c -o /tmp/core.o
  and link with c++ -fopenmp /tmp/core.o /path/to/libz3.a -lpthread -ldl -o
  path/to/reuse/core. deps/g3-plan-replay/native.c is the native replay helper.
- To replay the online test build the CLI from pkg with
  `go build -o /tmp/ticket-bin/release-cli ./cmd/g3` and run
  `FOCUS_BIN=/tmp/ticket-bin python3 reuse/online.py`. It reads the bundled
  snapshots and writes per-batch counters to reuse/online.csv. Set CPU
  affinity and the perf executable in the script for the current machine.
  verify_hits.py uses the same CLI and verifies the stored earlier cores.
