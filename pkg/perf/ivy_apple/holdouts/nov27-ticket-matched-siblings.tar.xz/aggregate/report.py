from pathlib import Path
import csv,collections,statistics,json
w=Path(__file__).resolve().parent; groups=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0]))
for engine in ['g3','z3']:
 for r in csv.DictReader((w/(engine+'.csv')).open()):
  k=int(r['slot']); name={6:'or-operands',7:'root-clauses',14:'asserted-instances'}.get(k) or ['variable','enode','gate','gate-clause','congruence','term'][k%8]
  v=groups[r['input'],name,engine][r['round']];v[0]+=int(r['calls']);v[1]+=int(r['instructions'])
with (w/'totals.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case operation g3_calls z3_calls g3_M z3_M gap_M same_price_saving_M'.split())
 for case,op in sorted({(k[0],k[1]) for k in groups}):
  y=[]
  for e in ['g3','z3']:
   d=groups[case,op,e];assert len(d)==3 and len(set(v[0] for v in d.values()))==1,(case,op,e,d)
   y.append([statistics.median(x[i] for x in d.values()) for i in [0,1]])
  (n,a),(m,b)=y;out.writerow([case,op,n,m,*[round(x/1e6,3) for x in [a,b,a-b,a-(b/m)*n]]])
