(declare-sort ticket_protocol.thread)
(declare-sort ticket_protocol.ticket)
(declare-fun __m_l2s_d_c (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun l2s_d (ticket_protocol.ticket) Bool)
(declare-fun __m_l2s_d_b (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(declare-fun __l2s_d_a (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.zero () ticket_protocol.ticket)
(declare-fun __m_l2s_d_a (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.sk1 () ticket_protocol.thread)
(declare-fun l2s_d (ticket_protocol.thread) Bool)
(declare-fun __m_l2s_d (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.sk0 () ticket_protocol.thread)
(declare-fun l2s_g_5 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.scheduled (ticket_protocol.thread) Bool)
(declare-fun __m_l2s_w_0 (ticket_protocol.thread) Bool)
(declare-fun l2s_w_0 (ticket_protocol.thread) Bool)
(declare-fun __m_l2s_g_5 (ticket_protocol.thread) Bool)
(declare-fun new__old_l2s_g_5_a (ticket_protocol.thread) Bool)
(declare-fun __m_l2s_g_3 (ticket_protocol.thread) Bool)
(declare-fun new__old_l2s_g_3_a (ticket_protocol.thread) Bool)
(declare-fun __m_ticket_protocol.scheduled (ticket_protocol.thread) Bool)
(declare-fun __l2s_w_0 (ticket_protocol.thread) Bool)
(declare-fun |__fml:t| () ticket_protocol.thread)
(declare-fun __l2s_g_5 (ticket_protocol.thread) Bool)
(declare-fun __m__old_l2s_g_5 (ticket_protocol.thread) Bool)
(declare-fun __l2s_g_3 (ticket_protocol.thread) Bool)
(declare-fun __m__old_l2s_g_3 (ticket_protocol.thread) Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun __l2s_w_2 () Bool)
(declare-fun l2s_w_2 () Bool)
(declare-fun __ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun __l2s_g_7 () Bool)
(declare-fun _old_l2s_g_7 () Bool)
(declare-fun __l2s_g_1 (ticket_protocol.thread) Bool)
(declare-fun _old_l2s_g_1 (ticket_protocol.thread) Bool)
(declare-fun __ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun |__fml:y| () ticket_protocol.ticket)
(declare-fun __ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun |__new_fml:x| () ticket_protocol.ticket)
(declare-fun __ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun __l2s_d (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.le
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun l2s_g_3 (ticket_protocol.thread) Bool)
(declare-fun __ticket_protocol.scheduled (ticket_protocol.thread) Bool)
(declare-fun l2s_g_4 (ticket_protocol.thread) Bool)
(declare-fun l2s_g_1 (ticket_protocol.thread) Bool)
(declare-fun l2s_w_1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun l2s_w_3 () Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_0 (ticket_protocol.thread) Bool)
(declare-fun l2s_g_2 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.c
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun l2s_s_7 () ticket_protocol.ticket)
(declare-fun l2s_s_4 (ticket_protocol.thread) Bool)
(declare-fun l2s_s_1 (ticket_protocol.thread ticket_protocol.ticket) Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_s_3 (ticket_protocol.thread) Bool)
(declare-fun l2s_s_0 (ticket_protocol.thread ticket_protocol.ticket) Bool)
(declare-fun l2s_s_2 (ticket_protocol.thread) Bool)
(declare-fun l2s_a (ticket_protocol.ticket) Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_a (ticket_protocol.thread) Bool)
(declare-fun l2s_s_6 () ticket_protocol.ticket)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_s_9 () ticket_protocol.thread)
(declare-fun l2s_s_8 () ticket_protocol.thread)
(declare-fun l2s_s_10 () ticket_protocol.ticket)
(declare-fun l2s_s_5 (ticket_protocol.ticket ticket_protocol.ticket) Bool)
(assert (let ((a!1 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> l2s_saved
                 (= (ticket_protocol.le
                      |X:ticket_protocol.ticket|
                      |Y:ticket_protocol.ticket|)
                    (l2s_s_5 |X:ticket_protocol.ticket|
                             |Y:ticket_protocol.ticket|)))))
      (a!2 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> l2s_saved
                 (= (l2s_s_1 ticket_protocol.sk0 |K:ticket_protocol.ticket|)
                    (__ticket_protocol.m
                      ticket_protocol.sk0
                      |K:ticket_protocol.ticket|)))))
      (a!3 (or (not l2s_g_9)
               (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
                 (not (l2s_g_0 |T:ticket_protocol.thread|)))))
      (a!4 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|K2:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> (and l2s_g_6
                      l2s_saved
                      (ticket_protocol.c
                        ticket_protocol.sk1
                        |K1:ticket_protocol.ticket|)
                      (l2s_s_0 ticket_protocol.sk1 |K2:ticket_protocol.ticket|))
                 (ticket_protocol.le
                   |K1:ticket_protocol.ticket|
                   |K2:ticket_protocol.ticket|))))
      (a!5 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|K2:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> (and l2s_g_6
                      l2s_saved
                      (ticket_protocol.c
                        ticket_protocol.sk1
                        |K1:ticket_protocol.ticket|)
                      (l2s_s_0 ticket_protocol.sk1 |K2:ticket_protocol.ticket|)
                      (not (__l2s_w_0 ticket_protocol.sk1)))
                 (not (= |K1:ticket_protocol.ticket|
                         |K2:ticket_protocol.ticket|)))))
      (a!6 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
                      (__ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|)
                      (not (= |M:ticket_protocol.ticket| ticket_protocol.zero)))
                 (not (ticket_protocol.le
                        ticket_protocol.service
                        |M:ticket_protocol.ticket|)))))
      (a!7 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
             (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                          (and (__ticket_protocol.m
                                 |T:ticket_protocol.thread|
                                 |K:ticket_protocol.ticket|)
                               (not (__ticket_protocol.pc1
                                      |T:ticket_protocol.thread|))))))
               (=> (and (not (ticket_protocol.le
                               __ticket_protocol.next_ticket
                               |K:ticket_protocol.ticket|))
                        (ticket_protocol.le
                          ticket_protocol.service
                          |K:ticket_protocol.ticket|))
                   a!1))))
      (a!8 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                 (__l2s_d |T:ticket_protocol.thread|))))
      (a!9 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|K0:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> (and (ticket_protocol.c
                        ticket_protocol.sk1
                        |K0:ticket_protocol.ticket|)
                      (ticket_protocol.le
                        |K:ticket_protocol.ticket|
                        |K0:ticket_protocol.ticket|))
                 (__l2s_d_a |K:ticket_protocol.ticket|))))
      (a!10 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not l2s_waiting)
                       (__ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |K:ticket_protocol.ticket|)
                       (__ticket_protocol.m
                         ticket_protocol.sk0
                         |K0:ticket_protocol.ticket|)
                       (not (ticket_protocol.le
                              |K0:ticket_protocol.ticket|
                              |K:ticket_protocol.ticket|))
                       (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|)))
                  (l2s_a |T:ticket_protocol.thread|))))
      (a!11 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (not l2s_waiting)
                       (__ticket_protocol.m
                         ticket_protocol.sk0
                         |K0:ticket_protocol.ticket|)
                       (ticket_protocol.le
                         |K:ticket_protocol.ticket|
                         |K0:ticket_protocol.ticket|))
                  (l2s_a |K:ticket_protocol.ticket|))))
      (a!12 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (not l2s_waiting)
                       l2s_g_6
                       (ticket_protocol.c
                         ticket_protocol.sk1
                         |K0:ticket_protocol.ticket|)
                       (ticket_protocol.le
                         |K:ticket_protocol.ticket|
                         |K0:ticket_protocol.ticket|))
                  (l2s_a |K:ticket_protocol.ticket|))))
      (a!13 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and l2s_saved (__l2s_w_0 |T:ticket_protocol.thread|))
                  (= (l2s_s_2 |T:ticket_protocol.thread|)
                     (__ticket_protocol.pc1 |T:ticket_protocol.thread|)))))
      (a!14 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and l2s_saved (__l2s_w_0 |T:ticket_protocol.thread|))
                  (= (l2s_s_3 |T:ticket_protocol.thread|)
                     (__ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
      (a!15 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and l2s_saved (__l2s_w_0 |T:ticket_protocol.thread|))
                  (= (l2s_s_4 |T:ticket_protocol.thread|)
                     (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!16 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and l2s_saved (__l2s_w_0 |T:ticket_protocol.thread|))
                  (= (l2s_s_1 |T:ticket_protocol.thread|
                              |K:ticket_protocol.ticket|)
                     (__ticket_protocol.m
                       |T:ticket_protocol.thread|
                       |K:ticket_protocol.ticket|)))))
      (a!17 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and l2s_saved (__l2s_w_0 |T:ticket_protocol.thread|))
                  (= (l2s_s_0 |T:ticket_protocol.thread|
                              |K:ticket_protocol.ticket|)
                     (ticket_protocol.c
                       |T:ticket_protocol.thread|
                       |K:ticket_protocol.ticket|)))))
      (a!18 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (let ((a!1 (or (and (__ticket_protocol.pc1
                                    |T:ticket_protocol.thread|)
                                  (= |K:ticket_protocol.ticket| l2s_s_7))
                             (and (__ticket_protocol.pc2
                                    |T:ticket_protocol.thread|)
                                  (not (ticket_protocol.le
                                         |K:ticket_protocol.ticket|
                                         |K0:ticket_protocol.ticket|)))
                             (and (ticket_protocol.pc3
                                    |T:ticket_protocol.thread|)
                                  (= |K:ticket_protocol.ticket| l2s_s_7)))))
                (=> (and l2s_saved
                         (l2s_s_1 |T:ticket_protocol.thread| l2s_s_7)
                         (not (__l2s_w_0 |T:ticket_protocol.thread|))
                         (l2s_s_3 |T:ticket_protocol.thread|)
                         (__ticket_protocol.m
                           |T:ticket_protocol.thread|
                           |K:ticket_protocol.ticket|)
                         (__ticket_protocol.m
                           ticket_protocol.sk0
                           |K0:ticket_protocol.ticket|))
                    a!1))))
      (a!19 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (let ((a!1 (and (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
                              (= |K:ticket_protocol.ticket| l2s_s_7)
                              (not (ticket_protocol.le
                                     ticket_protocol.service
                                     l2s_s_7)))))
              (let ((a!2 (or (and (ticket_protocol.pc3
                                    |T:ticket_protocol.thread|)
                                  (= |K:ticket_protocol.ticket| l2s_s_7)
                                  (= |K:ticket_protocol.ticket|
                                     ticket_protocol.service))
                             a!1
                             (and (__ticket_protocol.pc2
                                    |T:ticket_protocol.thread|)
                                  (not (ticket_protocol.le
                                         |K:ticket_protocol.ticket|
                                         |K0:ticket_protocol.ticket|))))))
                (=> (and l2s_saved
                         (l2s_s_1 |T:ticket_protocol.thread| l2s_s_7)
                         (l2s_s_4 |T:ticket_protocol.thread|)
                         (__ticket_protocol.m
                           |T:ticket_protocol.thread|
                           |K:ticket_protocol.ticket|)
                         (__ticket_protocol.m
                           ticket_protocol.sk0
                           |K0:ticket_protocol.ticket|))
                    a!2)))))
      (a!20 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (let ((a!1 (and (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
                              (= |K:ticket_protocol.ticket| l2s_s_7)
                              (not (ticket_protocol.le
                                     ticket_protocol.service
                                     l2s_s_7)))))
              (let ((a!2 (or a!1
                             (and (__ticket_protocol.pc2
                                    |T:ticket_protocol.thread|)
                                  (not (ticket_protocol.le
                                         |K:ticket_protocol.ticket|
                                         |K0:ticket_protocol.ticket|))))))
                (=> (and l2s_saved
                         (l2s_s_1 |T:ticket_protocol.thread| l2s_s_7)
                         (l2s_s_4 |T:ticket_protocol.thread|)
                         (__ticket_protocol.m
                           |T:ticket_protocol.thread|
                           |K:ticket_protocol.ticket|)
                         (__ticket_protocol.m
                           ticket_protocol.sk0
                           |K0:ticket_protocol.ticket|)
                         (not (l2s_w_1 |T:ticket_protocol.thread|))
                         (not (l2s_g_0 |T:ticket_protocol.thread|)))
                    a!2)))))
      (a!21 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (ticket_protocol.pc3 |T1:ticket_protocol.thread|)
                       (ticket_protocol.pc3 |T2:ticket_protocol.thread|))
                  (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!22 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (or (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                  (not (__ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
      (a!23 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (or (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                  (not (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!24 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (or (not (__ticket_protocol.pc2 |T:ticket_protocol.thread|))
                  (not (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!25 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K2:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (__ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |K1:ticket_protocol.ticket|)
                       (__ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |K2:ticket_protocol.ticket|))
                  (= |K1:ticket_protocol.ticket| |K2:ticket_protocol.ticket|))))
      (a!26 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K2:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (ticket_protocol.c
                         |T:ticket_protocol.thread|
                         |K1:ticket_protocol.ticket|)
                       (ticket_protocol.c
                         |T:ticket_protocol.thread|
                         |K2:ticket_protocol.ticket|))
                  (= |K1:ticket_protocol.ticket| |K2:ticket_protocol.ticket|))))
      (a!27 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not (= __ticket_protocol.next_ticket
                               ticket_protocol.zero))
                       (__ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|))
                  (not (ticket_protocol.le
                         __ticket_protocol.next_ticket
                         |M:ticket_protocol.ticket|)))))
      (a!28 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (or (__ticket_protocol.pc2 |T:ticket_protocol.thread|)
                      (ticket_protocol.pc3 |T:ticket_protocol.thread|))
                  (not (= __ticket_protocol.next_ticket ticket_protocol.zero)))))
      (a!29 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (__ticket_protocol.m
                         |T1:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|)
                       (__ticket_protocol.m
                         |T2:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|)
                       (not (= |M:ticket_protocol.ticket| ticket_protocol.zero)))
                  (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!30 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (__ticket_protocol.pc2 |T:ticket_protocol.thread|)
                       (__ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|))
                  (ticket_protocol.le
                    ticket_protocol.service
                    |M:ticket_protocol.ticket|))))
      (a!31 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (not (and (not (__ticket_protocol.pc1 |T1:ticket_protocol.thread|))
                        (not (__ticket_protocol.pc1 |T2:ticket_protocol.thread|))
                        (__ticket_protocol.m
                          |T1:ticket_protocol.thread|
                          ticket_protocol.zero)
                        (__ticket_protocol.m
                          |T2:ticket_protocol.thread|
                          ticket_protocol.zero)
                        (not (= |T1:ticket_protocol.thread|
                                |T2:ticket_protocol.thread|))))))
      (a!32 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (__l2s_g_1 |V0:ticket_protocol.thread|)
                  (not (and (__ticket_protocol.pc2 |V0:ticket_protocol.thread|)
                            (l2s_g_4 |V0:ticket_protocol.thread|))))))
      (a!33 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_2 |V0:ticket_protocol.thread|)
                  (not (l2s_g_0 |V0:ticket_protocol.thread|)))))
      (a!34 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (__l2s_g_3 |V0:ticket_protocol.thread|)
                  (not (__l2s_g_5 |V0:ticket_protocol.thread|)))))
      (a!35 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_4 |V0:ticket_protocol.thread|)
                  (not (ticket_protocol.pc3 |V0:ticket_protocol.thread|)))))
      (a!36 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (__l2s_g_5 |V0:ticket_protocol.thread|)
                  (not (__ticket_protocol.scheduled |V0:ticket_protocol.thread|)))))
      (a!37 (=> __l2s_g_7
                (not (and (__ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8))))
      (a!38 (not (and (and (__ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8)
                      __l2s_w_2)))
      (a!39 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (not (and (__ticket_protocol.scheduled
                          |V0:ticket_protocol.thread|)
                        (__l2s_w_0 |V0:ticket_protocol.thread|)))))
      (a!40 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (not (and (not (ticket_protocol.pc3 |V0:ticket_protocol.thread|))
                        (l2s_w_1 |V0:ticket_protocol.thread|)))))
      (a!41 (forall ((|Z:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (not (ticket_protocol.le
                         |Z:ticket_protocol.ticket|
                         |__new_fml:x|))
                  (ticket_protocol.le |__fml:y| |Z:ticket_protocol.ticket|))))
      (a!42 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (let ((a!1 (and (not (_old_l2s_g_1 |V0:ticket_protocol.thread|))
                              (not (and (__ticket_protocol.pc2
                                          |V0:ticket_protocol.thread|)
                                        (l2s_g_4 |V0:ticket_protocol.thread|))))))
                (=> a!1 (not (l2s_g_1 |V0:ticket_protocol.thread|))))))
      (a!43 (and (not _old_l2s_g_7)
                 (not (and (__ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8))))
      (a!44 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_1 |V0:ticket_protocol.thread|)
                  (not (and (ticket_protocol.pc2 |V0:ticket_protocol.thread|)
                            (l2s_g_4 |V0:ticket_protocol.thread|))))))
      (a!45 (=> l2s_g_7
                (not (and (ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8))))
      (a!46 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not (__m__old_l2s_g_3 |V0:ticket_protocol.thread|))
                       (not (__m_l2s_g_5 |V0:ticket_protocol.thread|)))
                  (not (__m_l2s_g_3 |V0:ticket_protocol.thread|)))))
      (a!47 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not (__m__old_l2s_g_5 |V0:ticket_protocol.thread|))
                       (not (__ticket_protocol.scheduled
                              |V0:ticket_protocol.thread|)))
                  (not (__m_l2s_g_5 |V0:ticket_protocol.thread|)))))
      (a!48 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (__m_l2s_g_3 |V0:ticket_protocol.thread|)
                  (not (__m_l2s_g_5 |V0:ticket_protocol.thread|)))))
      (a!49 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (__m_l2s_g_5 |V0:ticket_protocol.thread|)
                  (not (__m_ticket_protocol.scheduled
                         |V0:ticket_protocol.thread|)))))
      (a!50 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not (new__old_l2s_g_3_a |V0:ticket_protocol.thread|))
                       (not (l2s_g_5 |V0:ticket_protocol.thread|)))
                  (not (l2s_g_3 |V0:ticket_protocol.thread|)))))
      (a!51 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not (new__old_l2s_g_5_a |V0:ticket_protocol.thread|))
                       (not (__m_ticket_protocol.scheduled
                              |V0:ticket_protocol.thread|)))
                  (not (l2s_g_5 |V0:ticket_protocol.thread|)))))
      (a!52 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_3 |V0:ticket_protocol.thread|)
                  (not (l2s_g_5 |V0:ticket_protocol.thread|)))))
      (a!53 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_5 |V0:ticket_protocol.thread|)
                  (not (ticket_protocol.scheduled |V0:ticket_protocol.thread|)))))
      (a!54 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|Y:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|Z:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (ticket_protocol.le
                         |X:ticket_protocol.ticket|
                         |Y:ticket_protocol.ticket|)
                       (ticket_protocol.le
                         |Y:ticket_protocol.ticket|
                         |Z:ticket_protocol.ticket|))
                  (ticket_protocol.le
                    |X:ticket_protocol.ticket|
                    |Z:ticket_protocol.ticket|))))
      (a!55 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (ticket_protocol.le
                         |X:ticket_protocol.ticket|
                         |Y:ticket_protocol.ticket|)
                       (ticket_protocol.le
                         |Y:ticket_protocol.ticket|
                         |X:ticket_protocol.ticket|))
                  (= |X:ticket_protocol.ticket| |Y:ticket_protocol.ticket|))))
      (a!56 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (__m_l2s_d |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      true
                      (__l2s_d |V0:ticket_protocol.thread|)))))
      (a!57 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread)
                     (|V1:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (ticket_protocol.m
                   |V0:ticket_protocol.thread|
                   |V1:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      (= |V1:ticket_protocol.ticket|
                         __ticket_protocol.next_ticket)
                      (__ticket_protocol.m
                        |V0:ticket_protocol.thread|
                        |V1:ticket_protocol.ticket|)))))
      (a!58 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.pc1 |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      false
                      (__ticket_protocol.pc1 |V0:ticket_protocol.thread|)))))
      (a!59 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.pc2 |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      true
                      (__ticket_protocol.pc2 |V0:ticket_protocol.thread|)))))
      (a!60 (and __l2s_w_2
                 (not (and (ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8))
                 (not l2s_g_7)))
      (a!61 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (__m_l2s_w_0 |V0:ticket_protocol.thread|)
                 (and (__l2s_w_0 |V0:ticket_protocol.thread|)
                      (not (__m_ticket_protocol.scheduled
                             |V0:ticket_protocol.thread|))
                      (not (__m_l2s_g_5 |V0:ticket_protocol.thread|))))))
      (a!62 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (l2s_w_0 |V0:ticket_protocol.thread|)
                 (and (__m_l2s_w_0 |V0:ticket_protocol.thread|)
                      (not (ticket_protocol.scheduled
                             |V0:ticket_protocol.thread|))
                      (not (l2s_g_5 |V0:ticket_protocol.thread|))))))
      (a!63 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (__m_l2s_d_a |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| ticket_protocol.sk0))
                      true
                      (__m_l2s_d |V0:ticket_protocol.thread|)))))
      (a!64 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (l2s_d |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| ticket_protocol.sk1))
                      true
                      (__m_l2s_d_a |V0:ticket_protocol.thread|)))))
      (a!65 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (__m_l2s_d_b |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket| ticket_protocol.zero))
                      true
                      (__l2s_d_a |V0:ticket_protocol.ticket|)))))
      (a!66 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (__m_l2s_d_c |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket|
                              ticket_protocol.service))
                      true
                      (__m_l2s_d_b |V0:ticket_protocol.ticket|)))))
      (a!67 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (l2s_d |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket|
                              ticket_protocol.next_ticket))
                      true
                      (__m_l2s_d_c |V0:ticket_protocol.ticket|))))))
  (and (or l2s_waiting l2s_frozen l2s_saved)
       (or (not l2s_waiting) (not l2s_frozen))
       (or (not l2s_waiting) (not l2s_saved))
       (or (not l2s_frozen) (not l2s_saved))
       a!1
       (=> l2s_saved (= ticket_protocol.zero l2s_s_10))
       (=> l2s_saved (= ticket_protocol.sk0 l2s_s_8))
       (=> l2s_saved (= ticket_protocol.sk1 l2s_s_9))
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (not (__ticket_protocol.scheduled |T:ticket_protocol.thread|)))
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (__l2s_g_3 |T:ticket_protocol.thread|))
       (not __l2s_g_7)
       (= (not __l2s_w_2)
          (and (__ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8))
       (=> l2s_frozen (and (__ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8))
       (=> l2s_saved (and (__ticket_protocol.pc2 ticket_protocol.sk0) l2s_g_8))
       a!2
       (=> l2s_saved (ticket_protocol.le l2s_s_7 ticket_protocol.service))
       (=> l2s_saved (ticket_protocol.le l2s_s_6 __ticket_protocol.next_ticket))
       (or (not l2s_g_9)
           (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (l2s_g_2 |T:ticket_protocol.thread|)))
       a!3
       (=> (not l2s_w_3) (or l2s_g_9 l2s_g_6))
       (=> (and (not l2s_g_9) (not l2s_waiting)) l2s_g_6)
       (exists ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.c ticket_protocol.sk1 |K:ticket_protocol.ticket|))
       (=> l2s_saved
           (exists ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
             (l2s_s_0 ticket_protocol.sk1 |K:ticket_protocol.ticket|)))
       a!4
       a!5
       a!6
       a!7
       (exists ((|M:ticket_protocol.ticket| ticket_protocol.ticket))
         (__ticket_protocol.m ticket_protocol.sk0 |M:ticket_protocol.ticket|))
       (__l2s_d ticket_protocol.sk0)
       (__l2s_d ticket_protocol.sk1)
       a!8
       (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
         (=> (ticket_protocol.le
               |K:ticket_protocol.ticket|
               __ticket_protocol.next_ticket)
             (__l2s_d_a |K:ticket_protocol.ticket|)))
       a!9
       (=> (not l2s_waiting) (l2s_a ticket_protocol.sk0))
       (=> (not l2s_waiting) (l2s_a ticket_protocol.sk1))
       a!10
       a!11
       a!12
       a!13
       a!14
       a!15
       a!16
       a!17
       a!18
       a!19
       a!20
       a!21
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (or (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
             (__ticket_protocol.pc2 |T:ticket_protocol.thread|)
             (ticket_protocol.pc3 |T:ticket_protocol.thread|)))
       a!22
       a!23
       a!24
       a!25
       a!26
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (= __ticket_protocol.next_ticket ticket_protocol.zero)
             (__ticket_protocol.m
               |T:ticket_protocol.thread|
               ticket_protocol.zero)))
       a!27
       a!28
       a!29
       a!30
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (ticket_protocol.pc3 |T:ticket_protocol.thread|)
             (__ticket_protocol.m
               |T:ticket_protocol.thread|
               ticket_protocol.service)))
       (ticket_protocol.le
         ticket_protocol.service
         __ticket_protocol.next_ticket)
       a!31
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (=> (l2s_g_0 |V0:ticket_protocol.thread|)
             (ticket_protocol.pc3 |V0:ticket_protocol.thread|)))
       a!32
       a!33
       a!34
       a!35
       a!36
       (=> l2s_g_6 (ticket_protocol.pc3 ticket_protocol.sk1))
       a!37
       (=> l2s_g_8 (not (ticket_protocol.pc3 ticket_protocol.sk0)))
       (=> l2s_g_9 (not l2s_g_6))
       a!38
       (not (and l2s_g_6 l2s_w_3))
       a!39
       a!40
       (__ticket_protocol.pc1 |__fml:t|)
       (not (ticket_protocol.le |__fml:y| |__new_fml:x|))
       a!41
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (=> (_old_l2s_g_1 |V0:ticket_protocol.thread|)
             (l2s_g_1 |V0:ticket_protocol.thread|)))
       a!42
       (=> _old_l2s_g_7 l2s_g_7)
       (=> a!43 (not l2s_g_7))
       a!44
       a!45
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (=> (__m__old_l2s_g_3 |V0:ticket_protocol.thread|)
             (__m_l2s_g_3 |V0:ticket_protocol.thread|)))
       a!46
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (=> (__m__old_l2s_g_5 |V0:ticket_protocol.thread|)
             (__m_l2s_g_5 |V0:ticket_protocol.thread|)))
       a!47
       a!48
       a!49
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (=> (new__old_l2s_g_3_a |V0:ticket_protocol.thread|)
             (l2s_g_3 |V0:ticket_protocol.thread|)))
       a!50
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (=> (new__old_l2s_g_5_a |V0:ticket_protocol.thread|)
             (l2s_g_5 |V0:ticket_protocol.thread|)))
       a!51
       a!52
       a!53
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.le
           |X:ticket_protocol.ticket|
           |X:ticket_protocol.ticket|))
       a!54
       a!55
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
         (or (ticket_protocol.le
               |X:ticket_protocol.ticket|
               |Y:ticket_protocol.ticket|)
             (ticket_protocol.le
               |Y:ticket_protocol.ticket|
               |X:ticket_protocol.ticket|)))
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.le ticket_protocol.zero |X:ticket_protocol.ticket|))
       a!56
       a!57
       (= |__new_fml:x| __ticket_protocol.next_ticket)
       (= ticket_protocol.next_ticket |__fml:y|)
       a!58
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (= (_old_l2s_g_1 |V0:ticket_protocol.thread|)
            (__l2s_g_1 |V0:ticket_protocol.thread|)))
       (= _old_l2s_g_7 __l2s_g_7)
       a!59
       (= l2s_w_2 a!60)
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (= (__m__old_l2s_g_3 |V0:ticket_protocol.thread|)
            (__l2s_g_3 |V0:ticket_protocol.thread|)))
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (= (__m__old_l2s_g_5 |V0:ticket_protocol.thread|)
            (__l2s_g_5 |V0:ticket_protocol.thread|)))
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (= (__m_ticket_protocol.scheduled |V0:ticket_protocol.thread|)
            (= |V0:ticket_protocol.thread| |__fml:t|)))
       a!61
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (= (new__old_l2s_g_3_a |V0:ticket_protocol.thread|)
            (__m_l2s_g_3 |V0:ticket_protocol.thread|)))
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (= (new__old_l2s_g_5_a |V0:ticket_protocol.thread|)
            (__m_l2s_g_5 |V0:ticket_protocol.thread|)))
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (not (ticket_protocol.scheduled |V0:ticket_protocol.thread|)))
       a!62
       a!63
       a!64
       a!65
       a!66
       a!67)))
(assert (and (not (=> (not l2s_waiting) (l2s_a ticket_protocol.sk0)))))

(check-sat)
(get-info :all-statistics)
