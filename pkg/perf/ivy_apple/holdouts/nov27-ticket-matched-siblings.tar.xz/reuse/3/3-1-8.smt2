(declare-sort ticket_protocol.ticket)
(declare-sort ticket_protocol.thread)
(declare-fun ticket_protocol.le
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.zero () ticket_protocol.ticket)
(declare-fun ticket_protocol.l2s.w_request_flag () Bool)
(declare-fun ticket_protocol.l2s.d_thread (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.w_last_scheduled (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(declare-fun ticket_protocol.l2s.d_ticket (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.t0 () ticket_protocol.thread)
(declare-fun ticket_protocol.l2s.saved () Bool)
(declare-fun ticket_protocol.l2s.frozen () Bool)
(declare-fun ticket_protocol.l2s.waiting () Bool)
(declare-fun ticket_protocol.request_flag () Bool)
(declare-fun ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun @M () ticket_protocol.ticket)
(declare-fun @T () ticket_protocol.thread)
(assert (let ((a!1 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
             (= (ticket_protocol.l2s.d_ticket |K:ticket_protocol.ticket|)
                (or (= |K:ticket_protocol.ticket| ticket_protocol.zero)
                    (= |K:ticket_protocol.ticket| ticket_protocol.service)
                    (= |K:ticket_protocol.ticket| ticket_protocol.next_ticket)))))
      (a!2 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|Y:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|Z:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> (and (ticket_protocol.le
                        |X:ticket_protocol.ticket|
                        |Y:ticket_protocol.ticket|)
                      (ticket_protocol.le
                        |Y:ticket_protocol.ticket|
                        |Z:ticket_protocol.ticket|))
                 (ticket_protocol.le
                   |X:ticket_protocol.ticket|
                   |Z:ticket_protocol.ticket|))))
      (a!3 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> (and (ticket_protocol.le
                        |X:ticket_protocol.ticket|
                        |Y:ticket_protocol.ticket|)
                      (ticket_protocol.le
                        |Y:ticket_protocol.ticket|
                        |X:ticket_protocol.ticket|))
                 (= |X:ticket_protocol.ticket| |Y:ticket_protocol.ticket|)))))
  (and (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (ticket_protocol.pc1 |T:ticket_protocol.thread|))
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (not (ticket_protocol.pc2 |T:ticket_protocol.thread|)))
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (not (ticket_protocol.pc3 |T:ticket_protocol.thread|)))
       (= ticket_protocol.service ticket_protocol.zero)
       (= ticket_protocol.next_ticket ticket_protocol.zero)
       (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                (|T:ticket_protocol.thread| ticket_protocol.thread))
         (= (ticket_protocol.m
              |T:ticket_protocol.thread|
              |K:ticket_protocol.ticket|)
            (= |K:ticket_protocol.ticket| ticket_protocol.zero)))
       (not ticket_protocol.request_flag)
       ticket_protocol.l2s.waiting
       (not ticket_protocol.l2s.frozen)
       (not ticket_protocol.l2s.saved)
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (= (ticket_protocol.l2s.d_thread |T:ticket_protocol.thread|)
            (= |T:ticket_protocol.thread| ticket_protocol.t0)))
       a!1
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (= (ticket_protocol.l2s.w_last_scheduled |T:ticket_protocol.thread|)
            (ticket_protocol.l2s.d_thread |T:ticket_protocol.thread|)))
       ticket_protocol.l2s.w_request_flag
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.le
           |X:ticket_protocol.ticket|
           |X:ticket_protocol.ticket|))
       a!2
       a!3
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
         (or (ticket_protocol.le
               |X:ticket_protocol.ticket|
               |Y:ticket_protocol.ticket|)
             (ticket_protocol.le
               |Y:ticket_protocol.ticket|
               |X:ticket_protocol.ticket|)))
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.le ticket_protocol.zero |X:ticket_protocol.ticket|)))))
(assert (let ((a!1 (=> (and (not (= ticket_protocol.next_ticket ticket_protocol.zero))
                    (ticket_protocol.m @T @M))
               (not (ticket_protocol.le ticket_protocol.next_ticket @M)))))
  (and (not a!1))))

(check-sat)
(get-info :all-statistics)
