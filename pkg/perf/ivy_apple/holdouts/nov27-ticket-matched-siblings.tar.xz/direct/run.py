from pathlib import Path
import csv,os,subprocess
w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN']);ex=Path('/home/jaten/ivy/ivy-lang-examples');names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines(); name=next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy'));gold=Path('/tmp/g3-reduction-rows/compat')/str(names.index(name)+1)/'1/native'
with (w/'counts.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['round','engine','batch','goal','instructions','ns'])
 for i in range(9):
  for mode in ['g3','z3'][::1 if i%2==0 else -1]:
   r=subprocess.run(['taskset','-c','14',d/mode,ex/name],cwd=d,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOGC='100',GOIVY_INCLUDE=str(ex/'ivy/include')))
   lines=r.stderr.splitlines(keepends=True)
   assert (r.returncode,r.stdout,b''.join(x for x in lines if not x.startswith(b'STAGE-COUNT ')))==(0,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes())
   data=[x.split() for x in lines if x.startswith(b'STAGE-COUNT ')];assert len(data)==4
   for _,b,g,phase,num,empty,en,run,ns in data:
    assert en==run;out.writerow([i,mode,*map(int,[b,g,num,ns])])
   f.flush()
