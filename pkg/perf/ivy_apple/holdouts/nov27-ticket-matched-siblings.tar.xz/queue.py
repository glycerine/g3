from pathlib import Path
import subprocess,json,os,csv,time
p=Path.cwd();w=Path(__file__).resolve().parent;d=Path(os.environ['FOCUS_BIN'])
f=p/'smtcore/smt_qi_queue_schedule.go'
src=f.read_text().replace('import "github.com','import "os"\nimport "sort"\nimport "github.com',1)
src=src.replace('type SMTQIQueueEntry struct','var studyQueueMode=os.Getenv("G3_QUEUE_TRIAL")\ntype SMTQIQueueEntry struct',1)
key='sinceLastCheck := 0'
assert src.count(key)==1
src=src.replace(key,'''if len(q.newEntries)>1 {
        switch studyQueueMode {
        case "cheap":
            for i:=1;i<len(q.newEntries);i++ { if q.newEntries[i].Cost < q.newEntries[i-1].Cost {
                sort.SliceStable(q.newEntries,func(i,j int)bool{return q.newEntries[i].Cost<q.newEntries[j].Cost});break
            }}
        case "recent":
            for i,j:=0,len(q.newEntries)-1;i<j;i,j=i+1,j-1 {q.newEntries[i],q.newEntries[j]=q.newEntries[j],q.newEntries[i]}
        }
    }
    '''+key)
(w/'queue.go.txt').write_text(src)
front=p/'build/.boolean-enode-cost/frontend/goivy';o=w/'queue.json';o.write_text(json.dumps({'Replace':{str(f):str(w/'queue.go.txt')}}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off','-overlay',o,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',d/'queue','./cmd/goivy_check'],cwd=front,check=True)
s=Path('/tmp/g3-plan-replay/final/outliers.py').read_text()
s=s[:s.index('modes=')]+"""modes={k:d/'queue' for k in ['base','cheap','recent']}
"""+s[s.index('def run'):s.rindex('run(12,')]
s=s.replace("dict(os.environ,GOMAXPROCS","dict(os.environ,G3_QUEUE_TRIAL=m,GOMAXPROCS")
exec(s)
names=Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()
cases2=[next(n for n in names if 'popl18' in n and n.endswith('/ticket_protocol.ivy')),'examples/liveness/ticket.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/arm_rules3.ivy','test/flash2.ivy']
run(16,'queue',cases2,9,['base','cheap','recent'])
