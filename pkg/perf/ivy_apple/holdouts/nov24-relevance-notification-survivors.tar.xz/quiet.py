import argparse,csv,os,re,subprocess,sys,time
from pathlib import Path
parser=argparse.ArgumentParser()
for field in ['pkg','go','native','output']:parser.add_argument('--'+field,type=Path,required=True)
args=parser.parse_args();pkg=args.pkg.resolve();env=os.environ.copy()
def run(cmd,**kw):return subprocess.run(cmd,check=True,**kw)
import resource
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
from rotating_verification import ticks,idle,thread_siblings

def secs():
 x=resource.getrusage(resource.RUSAGE_CHILDREN);return x.ru_utime+x.ru_stime
def main():
 allcpus=[c for c in sorted(os.sched_getaffinity(0)) if c==min([c,*thread_siblings(c)])];groups={c:[c,*thread_siblings(c)]for c in allcpus}; shared=set().union(*groups.values());bs={'g3':args.go.resolve(),'native':args.native.resolve()}
 vs=['g3','native'];n=400000
 with args.output.open('x',newline='')as f:
  z=csv.writer(f);z.writerow('population round attempt cpu engine iterations ns occupancy sibling_idle accepted'.split())
  for population in [0,16384]:
   done=0
   for attempt in range(1,121):
    t0=ticks(shared);time.sleep(1.5);t1=ticks(shared);rates={c:min(idle(t0,t1,k)for k in groups[c])for c in allcpus};cpu=max(rates,key=rates.get);cpus=groups[cpu]
    if rates[cpu]<.93:continue
    ok=True;rows=[]
    for v in vs if done%2 else vs[::-1]:
     before=ticks(cpus);st=time.monotonic();usage=secs()
     cmd=[bs[v],str(population),str(n)]if v=='native'else[bs[v],'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTDeepSharedAssertion$/^Unrelated'+str(population)+'$','-test.benchtime='+str(n)+'x']
     r=run(['taskset','-c',str(cpu),*cmd],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True);elapsed=time.monotonic()-st;occ=(secs()-usage)/elapsed;after=ticks(cpus)
     sib=min((idle(before,after,c)for c in cpus if c!=cpu),default=1.);ok=ok and min(sib,occ)>=.95
     if v=='native':ns=float(r.stdout.strip().split(',')[-1])
     else:ns=float(re.search(r'([0-9.]+) ns/op',r.stdout)[1])
     rows.append([population,done+1,attempt,cpu,v,n,ns,occ,sib])
    for row in rows:z.writerow([*row,int(ok)])
    f.flush()
    if ok:done+=1
    if done==7:break
   print(population,done,'accepted',flush=True)
if __name__=='__main__':main()
