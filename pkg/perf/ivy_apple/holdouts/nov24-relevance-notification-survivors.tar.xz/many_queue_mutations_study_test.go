package smtcore

import (
	"fmt"
	"github.com/glycerine/g3/pkg/ast"
	"math/rand"
	"slices"
	"testing"
)

func TestStudyManyQueueMutations(t *testing.T) {
	for seed := int64(0); seed < 1024; seed++ {
		t.Run(fmt.Sprint(seed), func(t *testing.T) {
			m := astTestManager(t)
			ctx, err := NewSMTCheckerContext(m)
			astTestMust(t, err)
			p, err := NewSMTRelevancyPropagator(ctx, true)
			astTestMust(t, err)
			var handles [12]ast.ASTHandle
			for i := range handles {
				handles[i] = smtRelevancyPinnedBool(t, m, fmt.Sprintf("pending-%d", i))
			}
			// Replay against an independent trail and filter the entire reference
			// queue after each pop, including duplicate equal-class notifications.
			rng := rand.New(rand.NewSource(seed))
			live := make(map[ast.ASTHandle]bool)
			var trail, queue []ast.ASTHandle
			var limits []int
			for step := 0; step < 12000; step++ {
				h := handles[rng.Intn(len(handles))]
				switch rng.Intn(10) {
				case 0, 1:
					if len(limits) < 8 {
						astTestMust(t, p.PushScope())
						limits = append(limits, len(trail))
					}
				case 2, 3:
					if len(limits) > 0 {
						n := 1 + rng.Intn(len(limits))
						astTestMust(t, p.PopScopes(uint32(n)))
						level := len(limits) - n
						base := limits[level]
						for _, term := range trail[base:] {
							delete(live, term)
						}
						limits, trail = limits[:level], trail[:base]
						kept := queue[:0]
						for _, term := range queue {
							if live[term] {
								kept = append(kept, term)
							}
						}
						queue = kept
					}
				case 4:
					value := rng.Intn(2) == 0
					astTestMust(t, ctx.SetRelevant(h, value))
					live[h] = value
				case 5:
					if got := p.DrainNewlyRelevant(); !slices.Equal(got, queue) {
						t.Fatalf("drain at step %d: got %v, want %v", step, got, queue)
					}
					queue = nil
				case 6:
					p.discardNewlyRelevant()
					queue = nil
				case 7:
					astTestMust(t, p.MarkRelevant(h))
					if live[h] {
						break
					}
					live[h] = true
					trail = append(trail, h)
					queue = append(queue, h)
				default:
					astTestMust(t, p.setRelevant(h))
					live[h] = true
					trail = append(trail, h)
					queue = append(queue, h)
				}
				if !slices.Equal(p.newlyRelevant, queue) {
					t.Fatalf("step %d: got %v, want %v", step, p.newlyRelevant, queue)
				}
			}
			astTestMust(t, p.release())
		})
	}
}
