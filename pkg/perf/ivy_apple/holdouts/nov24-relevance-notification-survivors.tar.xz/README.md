# Retiring distinct pending relevance notifications

The comparison uses g3 24d97d8d4, the previous implementation at 38f049ffb, and this same repository's configured C++ build. From an extracted copy of the archive:

    python3 replay.py --pkg /path/to/g3/pkg --cpu 2 --output results.csv

The driver locks the g3 benchmark to its current OS thread and opens a per-thread user-instruction counter in each engine. It enables the counter for 8,000 consecutive push/assert/pop operations and disables it before teardown. Each row includes enabled and scheduled time. thread.csv contains nine rotations per engine at each of three unrelated Boolean populations. process.csv contains seven two-size process rotations including runtime background work. Divide each thread count by 8,000.

The differential fixture instantiates the repository's independent full-queue reference model under 1,024 seeds of 12,000 interleaved operations. Random operations include marking an already marked member of an equivalence class, externally clearing or restoring marks, draining and discarding the queue, and nested scope pop. The focused tests additionally cover callback and interrupted release paths. coverage.csv counts each fast trim with a nonempty retained prefix on 14 complete Ivy verification runs. corpus includes the independent exit/stdout/stderr check for each of 228 verification inputs.

quiet.csv records all 14 paired elapsed comparisons. Both the Go and native processes had to occupy at least 95% of their assigned CPU, and its hardware sibling had to be at least 95% idle during each. The uninstrumented benchmark reported the duration of 400,000 scopes. To repeat, build the committed smtcore benchmark with go test -tags=xtrace_off -c and the native deep_shared_assertion.cpp with perf/ivy_apple/native_benchmark.py, then run quiet.py --pkg /path/to/g3/pkg --go /path/to/smtcore.test --native /path/to/deep_shared_assertion --output quiet.csv.
