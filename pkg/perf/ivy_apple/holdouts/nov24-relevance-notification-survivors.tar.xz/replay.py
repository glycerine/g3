from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,csv,os,re,sys,subprocess,json,tempfile
cli=argparse.ArgumentParser(description="Bracket repeated deep scopes with a solver-thread instruction counter")
cli.add_argument("--pkg",type=Path,required=True)
cli.add_argument("--cpu",type=int,required=True)
cli.add_argument("--rounds",type=int,default=9)
cli.add_argument("--output",type=Path,required=True)
a=cli.parse_args()
pkg=a.pkg.resolve();env=os.environ.copy()
def once(s,old,new):
 assert s.count(old)==1,old
 return s.replace(old,new)
def run(cmd,**kwargs):
 return subprocess.run(cmd,check=True,**kwargs)
def overlay(path,ed):
 path.mkdir(parents=True,exist_ok=True)
 replacements={}
 for source,txt in ed.items():
  f=path/source.name;f.write_text(txt);replacements[str(source)]=str(f)
 o=path/'overlay.json';o.write_text(json.dumps({'Replace':replacements}));return o
sys.path.insert(0,str(pkg/'perf/ivy_apple'))
from native_benchmark import build_native
tmp=tempfile.TemporaryDirectory();rd=Path(tmp.name);q=pkg/'smtcore/smt_deep_assertion_benchmark_test.go'
def binary(v):
 sd=rd/v;sd.mkdir(exist_ok=True)
 if v=='native':
  s=(pkg.parent/'src/test/perf/deep_shared_assertion.cpp').read_text()
  s=s.replace('#include <chrono>','#include "'+str(pkg.parent/'src/test/perf/thread_counter.h')+'"\n#include <chrono>')
  s=once(s,'auto begin =','open_counter();signal_counter(true);auto begin =')
  s=once(s,'VERIFY(ctx.get_num_bool_vars()','signal_counter(false);report_counter();VERIFY(ctx.get_num_bool_vars()')
  src=sd/'driver.cpp';src.write_text(s);b=sd/'bench';build_native(pkg.parent/'build',b,src);return b
 t=q.read_text();t=once(t,'b.ResetTimer()','startScopeCounter();scopePhaseActive=true;scopePhaseEvent(1,true);b.ResetTimer()');t=once(t,'b.StopTimer()','b.StopTimer();scopePhaseEvent(1,false);finishScopeCounter();scopePhaseActive=false')
 ed={q:t,pkg/'smtcore/study_scope_counter_test.go':(pkg/'perf/scope_restoration/pop_phases/thread.go.txt').read_text()}
 if v=='before':
  for f in ['smtcore/smt_relevancy.go','smtcore/smt_relevancy_retirement_test.go','smtcore/smt_expr_table.go']:ed[pkg/f]=subprocess.check_output(['git','show','38f049ffb:pkg/'+f],cwd=pkg,text=True)
 o=overlay(sd/'overlay',ed);b=sd/'smtcore.test'
 with (sd/'build.log').open('w')as log:
  run(['go','test','-tags=xtrace_off','-p','2','-overlay='+str(o),'-c','-o',b,'./smtcore'],cwd=pkg,stdout=log,stderr=log)
 return b
def main():
 vs=['before','after','native']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(binary,vs)))
 with a.output.open('x',newline='')as f:
  z=csv.writer(f);z.writerow('round engine unrelated count ns instructions enabled_ns running_ns'.split())
  for i in range(a.rounds):
   for v in vs[i%3:]+vs[:i%3]:
    for n in [0,1024,16384]:
     k=8000;cmd=[bs[v],str(n),str(k)]if v=='native'else[bs[v],'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTDeepSharedAssertion$/^Unrelated'+str(n)+'$','-test.benchtime='+str(k)+'x']
     r=run(['taskset','-c',str(a.cpu),*cmd],env=dict(env,GOMAXPROCS='1',SCOPE_PHASE='1',SCOPE_THREAD_EVENT='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
     counts=re.findall(r'SCOPE-THREAD (\d+) (\d+) (\d+)',r.stdout)[-1];assert counts[1]==counts[2]
     ns=(r.stdout.strip().split(',')[-1] if v=='native'else re.findall(r'([0-9.]+) ns/op',r.stdout)[-1])
     z.writerow([i+1,v,n,k,ns,*counts]);f.flush()
if __name__=='__main__':main()
