"""Profile each phase of the satisfiable DIMACS controls."""
from collections import Counter
import csv
import gzip
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd().resolve()
sys.path.insert(0, str(root/'perf/ivy_raft'))
sys.path.insert(0, str(root/'perf/ivy_apple'))
from watch_propagation import formulas, dimacs, check_output
from stack_costs import samples

output = root/'build/.nov26-cnf-profile'
perf = '/usr/lib/linux-tools/6.17.0-35-generic/perf'
cases = list(row for row in formulas() if row[3] == 'sat')
engines = {
    'g3': root/'build/.nov26-capacity/final-output/g3',
    'z3': root.parent/'build/z3',
}

def classify(stack, engine):
    has = lambda *checks: any(x in frame for x in checks for frame in stack)
    if has('ParseDIMACS', 'parse_dimacs', 'read_clause<'):
        if has('(*Solver).MkClause', 'sat::solver::mk_clause'):
            return 'insert_clause'
        if has('(*Solver).MkVar', 'sat::solver::mk_var'):
            return 'create_variable'
        return 'scan'
    if has('writeDIMACSModel', 'display_model', '(*DIMACSFrontend).writeResult'):
        return 'model_output'
    if has('checkSpanWithDepth', 'sat::solver::check', 'checkCoreSpan'):
        return 'solve'
    if has('(*DIMACSFrontend).Close', 'sat::solver::~solver'):
        return 'teardown'
    return 'other'

with (output/'samples.csv').open('w') as stream:
    writer = csv.writer(stream)
    writer.writerow(['case','engine','round','stage','symbol','samples'])
    for name, variables, clauses, expected in cases:
        case = output/(name+'.cnf')
        case.write_text(dimacs(variables, clauses))
        for i in range(1,4):
            for engine in list(engines)[::1 if i%2 else -1]:
                stem=output/f'{name}-{i}-{engine}'
                raw=stem.with_suffix('.data')
                dest=stem.with_suffix('.gz')
                graph='fp' if engine=='g3' else 'dwarf,8192'
                command=['taskset','-c','13',perf,'record','--no-buildid','--call-graph',graph,
                         '-m','2048','-e','instructions:u','-c','100003','-o',raw,'--',
                         engines[engine],'-dimacs',case]
                proc=subprocess.run(command,env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,check=True)
                assert b'lost' not in proc.stderr.lower() and b'throttl' not in proc.stderr.lower(),proc.stderr
                check_output(proc.stdout.decode(),expected,variables,clauses)
                trace=subprocess.run([perf,'script','--no-inline','-i',raw,'-F','event,ip,sym,dso'],capture_output=True,check=True)
                assert b'lost' not in trace.stderr.lower(),trace.stderr
                with gzip.open(dest,'wb',compresslevel=1) as text:
                    text.write(trace.stdout)
                raw.unlink()
                counts=Counter((classify(s,engine),s[0]) for s in samples(dest) if s)
                assert counts, name
                writer.writerows((name,engine,i,stage,symbol,count) for (stage,symbol),count in sorted(counts.items()))
                stream.flush()
