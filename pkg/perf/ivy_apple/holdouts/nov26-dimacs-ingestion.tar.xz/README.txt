DIMACS ingestion follow-up on Linux amd64 and Go 1.27.3.
The baseline is 442c1c1a0. The two retained changes are c8512b43d.

profile.py and the *.gz traces sample user-mode instructions from the batched
baseline and ../build/z3 on CPU 13. samples.csv classifies those stacks by
calling phase. These are sampling observations, not per-phase exact counters.

The watch_propagation.py driver independently checks each satisfying model.
combined/controls.csv rotates release, baseline and Z3 nine times on CPU 13.
The individual overlays compare the same six cases, using five rotations.
short-sort uses CPU 13. watch-push, borrow-attach and zero-activity use CPU 9.
Zero-activity uses the combined baseline. The other alternatives use the
batched baseline. Compile standalone Go binaries with -buildvcs=false.

The short-sort benchmark uses the same tests with the before-sort overlay and
the combined implementation. All ten runs use CPU 13, GOMAXPROCS=1 and
-test.benchtime=200ms. The oracle sorts the same data and compares every word.
The archive keeps the prototype sources and exact measured CSVs. Tests for
the retained changes are in the package and the ordinary/checked test logs.
