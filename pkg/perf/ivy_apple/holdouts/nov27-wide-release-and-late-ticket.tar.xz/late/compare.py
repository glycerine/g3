"""Rank phase costs and compare ordered Ticket search traces across backends."""
import collections,csv,re,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
targets=[(b,1) for b in (6,7,8)]
def rows(name):
    with (w/name).open() as f: return list(csv.DictReader(f))
def sequence(label):
    out=collections.defaultdict(list)
    for r in rows(label+'-events.csv'):
        v=r['value']
        if r['event']=='split': v=v.split(' ',1)[1]
        if r['event']=='offer': v=v.split(' ',2)[2]
        out[int(r['batch']),int(r['goal']),r['event']].append(v)
    return out
def alpha(seq):
    ids={}
    return [re.sub(r'([^()\s!]+)!\d+(?=[()\s]|$)',lambda m:m[1]+'!@'+str(ids.setdefault(m[0],len(ids))),s) for s in seq]
def prefix(x,y):
    return next((i for i,(a,b) in enumerate(zip(alpha(x),alpha(y))) if a!=b),min(len(x),len(y)))
g,z,o=map(sequence,('release','native','ordinary'))
with (w/'search-summary.csv').open('w') as f:
    table=csv.writer(f)
    table.writerow(('batch','goal','event','g3','z3','ordinary','g3_z3_prefix','ordinary_z3_prefix'))
    for b,i in targets:
        for event in ('formula','split','offer','candidate'):
            key=(b,i,event)
            x,y,raw=g[key],z[key],o[key]
            table.writerow((b,i,event,len(x),len(y),len(raw),prefix(x,y),prefix(raw,y)))
