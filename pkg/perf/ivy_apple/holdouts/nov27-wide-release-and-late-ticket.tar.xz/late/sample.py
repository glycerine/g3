"""Attribute retired instructions to stacks inside the eight target check calls."""
import collections,csv,json,os,re,subprocess,sys
from pathlib import Path
os.environ['DEBUGINFOD_URLS']=''
w=Path(__file__).resolve().parent
gold,examples,perf=map(Path,sys.argv[1:4])
rounds=int(sys.argv[4]);cpu=sys.argv[5]
ref=gold/'reference/ticket_protocol'; spec=examples/json.loads((gold/'cases.json').read_text())['ticket_protocol'][0]
env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include'))
for i in range(rounds):
 for eng,stack in ([('g3','fp,48'),('z3','dwarf,8192')][::1 if i%2==0 else -1]):
    data=w/('samples-'+eng+'.data')
    period=2000003+i*1000
    r=subprocess.run(['taskset','-c',cpu,perf,'record','--clockid','mono','-B','-N','-e','instructions:u','-c',str(period),'--call-graph',stack,'-o',data,'--',w/(eng+'-windows'),spec],cwd=w,env=env,capture_output=True,check=True)
    windows=[];clean=[]
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'WINDOW '):
            _,b,g,tid,l,h=line.split();windows.append(tuple(map(int,(b,g,tid,l,h))))
        elif not line.startswith(b'[ perf record:'): clean.append(line)
    assert len(windows)==3 and r.stdout==(ref/'stdout').read_bytes() and b''.join(clean)==(ref/'stderr').read_bytes(),(r.stderr[:400],clean)
    stats=subprocess.check_output([perf,'report','--stdio','--stats','-i',data],text=True)
    assert not re.search(r'(LOST|THROTTLE) events:',stats)
    # Restrict unwinding to the eight disjoint CLOCK_MONOTONIC intervals.
    def stamp(ns):return '%d.%09d'%divmod(ns,10**9)
    when=' '.join(stamp(l)+','+stamp(h) for _,_,_,l,h in windows)
    cmd=[perf,'script','--ns','--time',when,'-F','tid,time,event,ip,sym','-i',data]
    out=subprocess.check_output(cmd,text=True)
    groups=collections.Counter()
    for sample in out.strip().split('\n\n'):
        lines=sample.splitlines()
        if not lines:continue
        m=re.match(r'^\s*(\d+)\s+(\d+)\.(\d{9}):',lines[0])
        assert m,lines[:2]
        tid,t,n=map(int,m.groups());now=t*10**9+n
        hit=[(b,g) for b,g,thread,l,h in windows if tid==thread and l<=now<=h]
        if not hit:continue
        syms=tuple(re.sub(r'^\s*[0-9a-f]+\s+','',x).strip() for x in lines[1:] if x.strip())
        assert syms,lines[:2]
        groups[(*hit[0],syms)]+=1
    assert len(set(k[:2] for k in groups))==3
    with (w/'sample-stacks.csv').open('w' if i==0 and eng=='g3' else 'a') as dest:
        writer=csv.writer(dest)
        if i==0 and eng=='g3':writer.writerow(['round','engine','batch','goal','period','samples','stack'])
        for (b,g,syms),count in groups.items():writer.writerow((i,eng,b,g,period,count,'\n'.join(syms)))
    data.unlink()
    print(i,eng,sum(groups.values()),flush=True)
