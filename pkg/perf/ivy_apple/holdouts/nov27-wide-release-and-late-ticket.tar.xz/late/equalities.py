"""Compare signed decisions allowing only generated-name renaming and equality symmetry."""
import collections,csv,re
from pathlib import Path
w=Path(__file__).resolve().parent
def canonical(value,names):
    sign,tree=value.split(' ',2)[1:]
    trees=[]
    def term(s):
        if re.fullmatch(r'[^()!\s]+!\d+',s):
            s=s[:s.rindex('!')]+'!@'+str(names.setdefault(s,len(names)))
        return s
    for token in re.findall(r'\(|\)|[^()\s]+',tree):
        if token=='(':
            trees.append([])
        elif token==')':
            args=trees.pop()
            if args[0]=='=' and len(args)==3:args[1:]=sorted(args[1:])
            t='('+' '.join(args)+')'
            if not trees: return sign,t
            trees[-1].append(t)
        else:
            trees[-1].append(term(token))
    raise ValueError(tree)
def read(engine):
    names=collections.defaultdict(dict);splits=collections.defaultdict(list)
    for r in csv.DictReader((w/(engine+'-events.csv')).open()):
        if r['event']=='split':
            key=(r['batch'],r['goal'])
            splits[key].append(canonical(r['value'],names[key]))
    return splits
x,y=read('ordinary'),read('native')
for key,a in x.items():
    b=y[key]; print(*key,len(a),len(b),sum(l!=r for l,r in zip(a,b)))
