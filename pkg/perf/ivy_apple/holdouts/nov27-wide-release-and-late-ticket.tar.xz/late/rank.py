"""Assign every sample to one operation for comparison between the two solvers."""
import csv
from collections import Counter,defaultdict
from pathlib import Path
import sys
w=Path(__file__).resolve().parent
with (w/'sample-stacks.csv').open() as f:rows=list(csv.DictReader(f))
# First distinguish actual instantiation from other search. Within each group,
# nested operations are assigned in the listed precedence.
inside=[
    ('substitute','(*SMTCachedVarSubstitution).Instantiate',['cached_var_subst::operator()']),
    ('rewrite','(*TheoryRewriter).Rewrite',['rewriter_tpl<th_rewriter_cfg>','th_rewriter::operator()']),
    ('assert instance','(*SMTInternalizerState).assertExpression',['smt::context::internalize_assertion']),
    ('check instance','(*SMTChecker).run',['smt::checker::is_sat']),
]
outside=[
    ('conflict resolution','(*SMTKernel).resolveSearchConflict',['smt::context::resolve_conflict(']),
    ('preprocess and internalize','(*SMTKernel).internalizeCheckAssertions',['smt::context::internalize_assertions(']),
    ('E-matching','(*smtMAMImpl).Match',['smt::mam_impl::match(']),
    ('remaining propagation','(*SMTInternalizerState).PropagateCore',['smt::context::propagate(']),
]
costs=Counter();rounds=defaultdict(set)
for r in rows:
    e=r['engine'];s=r['stack'];b=int(r['batch']);g=int(r['goal'])
    rounds[e,b,g].add(r['round'])
    in_entry=('(*SMTQuantifierManager).instantiate\n' if e=='g3' else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)') in s
    ops=inside if in_entry else outside
    phase=next((name for name,go,native in ops if any(v in s for v in ([go] if e=='g3' else native))), 'other queue and lemma assembly' if in_entry else 'other search')
    costs[e,b,g,phase]+=int(r['period'])*int(r['samples'])
wr=csv.writer(sys.stdout);wr.writerow(('batch','goal','phase','g3_million','z3_million','difference_million'))
for b in [6,7,8]:
    g=1
    for phase in sorted({p for _,_,_,p in costs}):
        a,z=(costs[e,b,g,phase]/len(rounds[e,b,g])/1e6 for e in ('g3','z3'))
        wr.writerow((b,g,phase,f'{a:.3f}',f'{z:.3f}',f'{a-z:.3f}'))
