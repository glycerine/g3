"""Sum calibrated final disjunction-release instructions by check and owner."""
import csv,json,os,subprocess,sys
from collections import Counter
from pathlib import Path
w=Path(__file__).resolve().parent
gold=Path(sys.argv[1]).resolve()
examples=Path(sys.argv[2])
rel,_,code=json.loads((gold/'cases.json').read_text())['ticket_protocol']
ref=gold/'reference/ticket_protocol'
expected={(r['engine'],int(r['batch']),int(r['goal']),r['kind']):int(r['final']) for r in csv.DictReader(Path(sys.argv[3]).open())}
wr=csv.writer(sys.stdout);wr.writerow(('engine','round','batch','goal','owner','count','instructions'))
for i in range(5):
    for engine in ['base','wide'][::1 if i%2==0 else -1]:
        r=subprocess.run(['taskset','-c','16',Path(sys.argv[4 if engine=="base" else 5]),examples/rel],cwd=w,capture_output=True,check=False,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
        counts=Counter();cost=Counter();other=[];seen=set()
        for line in r.stderr.splitlines(keepends=True):
            if line.startswith(b'WATCH-COST '):
                _,k,n=line.split();counts[int(k)]+=1;cost[int(k)]+=int(n)
            elif line.startswith(b'WATCH-END '):
                _,b,g,phase=line.split();b=int(b);g=int(g)
                if phase==b'check':
                    assert (b,g) not in seen
                    seen.add((b,g))
                    for k,name in [(3,'owned-parent'),(4,'OR-mark')]:
                        assert counts[k]==expected["g3",b,g,name],(engine,b,g,counts)
                        wr.writerow((engine,i,b,g,name,counts[k],cost[k]))
                counts.clear();cost.clear()
            elif not line.startswith((b'WATCH-POP ',b'STAGE-COUNT ')):other.append(line)
        assert len(seen)==8 and not counts and (r.returncode,r.stdout,b''.join(other))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(seen,other[-5:])
        sys.stdout.flush()
