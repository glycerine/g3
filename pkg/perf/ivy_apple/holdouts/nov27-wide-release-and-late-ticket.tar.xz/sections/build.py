"""Cost the disjoint actions on every AST destroyed by the selected OR releases."""
import sys,json,re,shlex,subprocess,shutil
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent
e=sys.argv[1];front,mod,prior=(Path(x).resolve() for x in sys.argv[2:5])
files=json.loads((prior/'price'/(e+'.json')).read_text())['Replace']
def replace(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(k,s):
    d=w/(e+'-'+k.name);d.write_text(s);files[str(k)]=str(d)
if e=='g3':
    k=p/'smtcore/smt_relevancy.go';s=Path(files[str(k)]).read_text()
    s=s.replace('fd,a,b=watchStart()', 'fd,a,b=watchStart();ast.WatchFD=int(fd)').replace('fd,a,b:=watchStart()', 'fd,a,b:=watchStart();ast.WatchFD=int(fd)').replace('v:=watchRead(fd);println','ast.WatchFD=-1;v:=watchRead(fd);println')
    save(k,s)
    k=p/'ast/ast_core_delete.go';s=Path(sys.argv[5]).read_text().replace('package ast','package ast\nimport("syscall";"unsafe")',1)
    s+='''\nvar WatchFD = -1
func sectionRead()int64{var c [3]uint64;n,_,err:=syscall.RawSyscall(syscall.SYS_READ,uintptr(WatchFD),uintptr(unsafe.Pointer(&c[0])),24);if n!=24||err!=0{panic("read")};return int64(c[0])}
type section struct {arity int; a,b int64}
func (d *section) begin(){if WatchFD>=0{d.a=sectionRead();d.b=sectionRead()}}
func (d *section) end(k int){if WatchFD>=0{v:=sectionRead();println("SECTION",d.arity,k,v-2*d.b+d.a)}}
'''
    s=replace(s,'m.deletionCurrent = current','var probe section; if WatchFD>=0{probe.arity=int(m.appAt(current.slot).count)};m.deletionCurrent = current')
    s=replace(s,'if e := m.tableEraseIdentity(current);','probe.begin();if e := m.tableEraseIdentity(current);')
    s=replace(s,'if e := m.deletionAfter(current);','probe.end(0);probe.begin();if e := m.deletionAfter(current);')
    s=replace(s,'// Native deletion visits','probe.end(1);probe.begin();\n\t\t// Native deletion visits')
    s=replace(s,'if m.DebugRefCount {\n\t\t\tm.DebugFreeIndices','probe.end(2);probe.begin();if m.DebugRefCount {\n\t\t\tm.DebugFreeIndices')
    s=replace(s,'m.deletionCurrent = parent\n\t\tm.deletionHead = astNodeRef{}','probe.end(3);m.deletionCurrent = parent\n\t\tm.deletionHead = astNodeRef{}')
    save(k,s)
else:
    build=p.parent/'build'
    flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
    inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    lib=w/'lib.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
    for name in ['smt_relevancy','ast']:
        if name=='smt_relevancy':
            s=(prior/'price/smt_relevancy.cpp').read_text()
            s='extern int section_fd;\n'+replace(s,'m_relevant_exprs.set(j,nullptr);auto v','section_fd=fd;m_relevant_exprs.set(j,nullptr);section_fd=-1;auto v')
        else:
            s=(p.parent/'src/ast/ast.cpp').read_text()
            a=s.index('void ast_manager::delete_node(');b=s.index('sort * ast_manager::mk_sort',a);body=s[a:b]
            body=replace(body,'m_ast_table.erase(n);','Section probe; if(section_fd>=0)probe.arity=to_app(n)->get_num_args();probe.begin();m_ast_table.erase(n);probe.end(0);probe.begin();')
            body=replace(body,'switch (n->get_kind())','probe.end(1);probe.begin();switch (n->get_kind())')
            body=replace(body,'if (m_debug_ref_count) {','probe.end(2);probe.begin();if (m_debug_ref_count) {')
            body=replace(body,'deallocate_node(n, ::get_node_size(n));','deallocate_node(n, ::get_node_size(n));probe.end(3);')
            s='''#include <unistd.h>
#include <cstdlib>
#include <cstdio>
int section_fd=-1;
struct Section{int arity; long long a,b;
long long rd(){unsigned long long c[3];if(read(section_fd,c,24)!=24)abort();return c[0];}
void begin(){if(section_fd>=0){a=rd();b=rd();}}
void end(int k){if(section_fd>=0){auto v=rd();fprintf(stderr,"SECTION %d %d %lld\\n",arity,k,v-2*b+a);}}};
'''+s[:a]+body+s[b:]
        src=w/(name+'.cpp');obj=w/(name+'.o');src.write_text(s)
        subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,src],cwd=build,check=True)
        subprocess.run(['ar','r',lib,obj],check=True)
    k=front/'smt/quantifier.go';save(k,k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
out=w/(e+'.json');out.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',out,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
