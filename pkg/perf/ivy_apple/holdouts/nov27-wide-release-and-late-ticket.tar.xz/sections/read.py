import csv,json,os,subprocess,sys
from pathlib import Path
from collections import Counter
w=Path(__file__).resolve().parent
gold=Path(sys.argv[1]).resolve();examples=Path(sys.argv[2]);census=Path(sys.argv[3])
case='ticket_protocol'
rel,_,code=json.loads((gold/'cases.json').read_text())[case]
ref=gold/'reference'/case
expect={(r['engine'],int(r['batch']),int(r['goal']),int(r['application_arity'])):int(r['nodes_destroyed']) for r in csv.DictReader(census.open())}
wr=csv.writer(sys.stdout);wr.writerow(('engine','round','batch','goal','arity','section','calls','instructions'))
for i in range(5):
    for engine in ['g3','z3'][::1 if i%2==0 else -1]:
        r=subprocess.run(['taskset','-c','16',w/engine,examples/rel],cwd=w,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
        counts=Counter();cost=Counter();other=[];seen=set()
        for l in r.stderr.splitlines(keepends=True):
            if l.startswith(b'SECTION '):
                _,a,k,v=l.split();key=(int(a),int(k));counts[key]+=1;cost[key]+=int(v)
            elif l.startswith(b'WATCH-END '):
                _,b,g,phase=l.split();b=int(b);g=int(g)
                if phase==b'check':
                    assert (b,g) not in seen
                    seen.add((b,g))
                    expected={(arity,k):n for (e,h,j,arity),n in expect.items() if (e,h,j)==(engine,b,g) for k in range(4)}
                    assert counts==expected,(engine,b,g,counts,expected)
                    for (a,k),n in sorted(counts.items()):wr.writerow((engine,i,b,g,a,['erase','recycle','children','free'][k],n,cost[a,k]))
                counts.clear();cost.clear()
            elif not l.startswith((b'WATCH-POP ',b'STAGE-COUNT ',b'WATCH-COST ')):other.append(l)
        assert len(seen)==8 and not counts and (code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())==(r.returncode,r.stdout,b''.join(other)),(engine,seen,other[-5:])
        sys.stdout.flush()
