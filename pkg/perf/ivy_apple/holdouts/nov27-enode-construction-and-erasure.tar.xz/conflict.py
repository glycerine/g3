"""Attribute each sampled conflict stack to the immediate child of a selected frame."""
import collections
import csv
import sys

with open(sys.argv[1]) as f:
    rows = list(csv.DictReader(f))
for engine, frames in [('g3', ['(*SMTKernel).resolveSearchConflict','(*SMTInternalizerState).PopScopes','(*SMTInternalizerState).popTo','(*SMTRelevancyPropagator).PopScopes','(*SMTRelevancyPropagator).finishPop','(*SMTRelevancyPropagator).undoTrail']), ('z3', ['smt::context::resolve_conflict(', 'smt::context::pop_scope_core('])]:
    rounds = {r['round'] for r in rows if r['engine'] == engine}
    for target in frames:
        costs = collections.Counter()
        for r in rows:
            stack = r['stack'].splitlines()
            if r['engine'] != engine or not any(frames[0] in f for f in stack):
                continue
            indices = [i for i, f in enumerate(stack) if target in f]
            if indices:
                i = max(indices)
                costs[stack[i-1] if i else '(self)'] += int(r['period']) * int(r['samples'])
        print(target)
        for name, value in costs.most_common(12):
            print(f'{value/len(rounds)/1e6:.2f}', name)
