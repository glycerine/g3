"""One allocation for a short node and its pointers while preserving slice reads in all consumers."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();d={}
def save(k,s):
 dest=w/('tail-'+k.name);dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));d[str(k)]=str(dest)
k=p/'smtcore/smt_internalizer.go';s=k.read_text();i=s.index('func (s *SMTInternalizerState) existingTermChildren');j=s.index('\n}',i)
t=s[i:j].replace('([]*SMTEnode, bool, error)','([2]*SMTEnode, bool, error)').replace('return nil,','return [2]*SMTEnode{},');t=t[:t.index('\tif count == 1 {')]+'\treturn pair, true, nil';save(k,s[:i]+t+s[j:])
k=p/'smtcore/smt_enode_core.go';s=k.read_text().replace('children []*SMTEnode','children [2]*SMTEnode');i=s.index('n := &SMTEnode{');j=s.index('n.root, n.next',i)
s=s[:i]+'''var n *SMTEnode
 switch {
 case !options.SuppressArguments && header.NumArgs==1:
  data:=new(struct{node SMTEnode; child [1]*SMTEnode});n=&data.node;n.arguments=data.child[:]
 case !options.SuppressArguments && header.NumArgs==2:
  data:=new(struct{node SMTEnode; child [2]*SMTEnode});n=&data.node;n.arguments=data.child[:]
 default: n=new(SMTEnode)
 }
 n.manager=m;n.owner=owner;n.declaration=header.Decl;n.classSize=1;n.generation=options.Generation;n.functionDeclID=math.MaxUint32
 n.internalScopeLevel=options.InternalScopeLevel;n.suppressArguments=options.SuppressArguments
 n.equality=header.Family==m.BasicFamilyID() && header.DeclKind==ast.ASTOpEq
 n.commutative=commutative;n.boolean=boolean;n.mergeTruthValue=options.MergeTruthValue;n.congruenceEnabled=options.CongruenceEnabled;n.labelHash=-1
 n.theoryVariables=*NewDefaultSMTTheoryVarList();n.family=header.Family;n.declKind=header.DeclKind
 '''+s[j:]
s=s.replace('n.arguments = term.children','copy(n.arguments,term.children[:])').replace('n.arguments = make([]*SMTEnode, count)','if count>2 {n.arguments=make([]*SMTEnode,count)}');save(k,s)
k=p/'smtcore/smt_enode_aux.go';s=k.read_text().replace('n.sourceParents, n.arguments = nil, nil','if len(n.arguments)<=2 { clear(n.arguments) }; n.sourceParents, n.arguments = nil, nil');save(k,s)
(w/'tail.json').write_text(json.dumps({'Replace':d}))
