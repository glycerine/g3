"""Replace the enode child slice descriptor with two child pointers and an overflow pointer."""
from pathlib import Path
import re,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();files={}
for k in sorted((p/'smtcore').glob('*.go')):
 old=s=k.read_text()
 if k.name not in ('smt_candidate_body.go','smt_qi_instance.go','smt_relevant_expr.go'):
  s=re.sub(r'\.arguments\b(?!\()', '.args()',s)
  for who in ('g','graph'):
   s=s.replace(who+'.args()',who+'.arguments')
 if k.name=='smt_checker_candidate.go':s=s.replace('p.args()', 'p.arguments')
 if k.name=='smt_enode_core.go':
  s=s.replace('arguments              []*SMTEnode','shortArgs [2]*SMTEnode\n wideArgs *[]*SMTEnode').replace('transMark                             bool','shortCount uint8\n transMark bool')
  s=s.replace('children []*SMTEnode','children [2]*SMTEnode')
  a='''if term != nil {
			n.args() = term.children
		} else {'''
  assert a in s
  s=s.replace(a,'''args:=n.allocateArgs(header.NumArgs)
      if term!=nil {
         copy(args,term.children[:])
      } else {''')
  s=s.replace('n.args() = make([]*SMTEnode, count)','').replace('n.args()[i] = child','args[i] = child')
  i=s.index('func (n *SMTEnode) valid()')
  s=s[:i]+'''func (n *SMTEnode) args() []*SMTEnode {
    if n.wideArgs!=nil {return *n.wideArgs};return n.shortArgs[:n.shortCount]
}
func (n *SMTEnode) allocateArgs(count uint32) []*SMTEnode {
 if count<=2 { n.shortCount=uint8(count);return n.shortArgs[:count] }
 a:=make([]*SMTEnode,count);n.wideArgs=&a;return a
}
func (n *SMTEnode) setArgs(a []*SMTEnode) {
 n.shortArgs=[2]*SMTEnode{}; n.wideArgs=nil;n.shortCount=0
 if len(a)>2 {n.wideArgs=&a;return}; copy(n.shortArgs[:],a);n.shortCount=uint8(len(a))
}
'''+s[i:]
 if k.name=='smt_internalizer.go':
  i=s.index('func (s *SMTInternalizerState) existingTermChildren');j=s.index('\n}',i);t=s[i:j].replace('([]*SMTEnode, bool, error)','([2]*SMTEnode, bool, error)').replace('return nil,','return [2]*SMTEnode{},')
  t=t[:t.index('\tif count == 1 {')]+'\treturn pair, true, nil';s=s[:i]+t+s[j:]
 if k.name=='smt_enode_aux.go':
  s=s.replace('n.sourceParents, n.args() = nil, nil','n.sourceParents=nil;n.setArgs(nil)').replace('t.node.args() = append(t.node.args()[:0], args...)','''if len(args)<=2 {t.node.setArgs(args)} else if t.node.wideArgs!=nil {*t.node.wideArgs=append((*t.node.wideArgs)[:0],args...)} else {t.node.setArgs(append([]*SMTEnode(nil),args...))}''')
 if k.name=='smt_cg_table.go':
  s=s.replace('declaration: decl, arguments: args,','declaration: decl,');a=s.index('tmp := SMTEnode{');b=s.index('\n',a);s=s[:b]+'\n tmp.setArgs(args)'+s[b:]
 if s!=old:
  d=w/('inline-'+k.name);d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));files[str(k)]=str(d)
(w/'inline.json').write_text(json.dumps({'Replace':files}))
