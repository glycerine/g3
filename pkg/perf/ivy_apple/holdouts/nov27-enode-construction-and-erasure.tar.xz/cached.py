from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();d={}
def save(k,s):
 dest=w/('cached-'+k.name);dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));d[str(k)]=str(dest)
k=p/'ast/ast_core_accessors.go';s=k.read_text();a='func (m *ASTManager) GetFuncDeclFlags(h ASTHandle) (ASTFuncFlags, error) {'
s=s.replace(a,a+'\nif decl:=m.cachedFuncDecl(h);decl!=nil {return decl.identityFlags,nil}')
i=s.index('// GetFuncDeclFlags');s=s[:i]+'''func(m *ASTManager) cachedFuncDecl(h ASTHandle) *astFuncDeclRecord{
 if ASTSourceDebug || !m.fastHandle(h) || m.nodeAt(h.slot).kind!=ASTFuncDecl{return nil}
 d:=m.declAt(h.slot);if !d.identityCached{return nil};return d
}
'''+s[i:];save(k,s)
k=p/'ast/ast_rewriter_access.go';s=k.read_text()
for name,expr in [('RewriterAssociative','c.identityFlags.LeftAssociative && c.identityFlags.RightAssociative'),('RewriterCommutative','c.identityFlags.Commutative')]:
 a='func (m *ASTManager) '+name+'(d ASTHandle) (bool, error) {';s=s.replace(a,a+'\nif c:=m.cachedFuncDecl(d);c!=nil{return '+expr+',nil}')
save(k,s);(w/'cached.json').write_text(json.dumps({'Replace':d}))
