"""Test a single cached declaration lookup for flags shared by SMT and the rewriter."""
from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;files={}
def save(k,s):
 d=w/(k.name+'.txt');d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));files[str(k)]=str(d)
k=p/'ast/ast_core_accessors.go';s=k.read_text()
i=s.index('r, e := m.readKind(',s.index('func (m *ASTManager) GetFuncDeclFlags'));j=s.index('\n}',i)
s=s[:i]+'''r, e := m.readNode(h)
 if e!=nil{return ASTFuncFlags{},e}
 return m.funcFlags(r)'''+s[j:];save(k,s)
k=p/'ast/ast_rewriter_access.go';s=k.read_text()
for name in ['RewriterAssociative','RewriterCommutative']:
 i=s.index('decl, e :=',s.index('func (m *ASTManager) '+name));j=s.index('\n\treturn flags.',i)
 s=s[:i]+'flags,e:=m.GetFuncDeclFlags(d)'+s[j:]
save(k,s)
ov=w/'flags.json';ov.write_text(json.dumps({'Replace':files}))
