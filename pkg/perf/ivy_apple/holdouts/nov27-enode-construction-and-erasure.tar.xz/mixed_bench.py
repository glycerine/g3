from pathlib import Path
import csv,os,subprocess,sys,re
w=Path(__file__).resolve().parent;perf=sys.argv[1];labels=sys.argv[2:]
wr=csv.writer(sys.stdout);wr.writerow(('round','engine','operation','instructions','ns_per_op','allocs'))
for i in range(9):
 for op in ('EraseInsert','EraseMiss','EraseCommuted','Ordered','Find','Miss'):
  for e in labels[i%len(labels):]+labels[:i%len(labels)]:
   f=w/'probe.perf';r=subprocess.run(['taskset','-c','16',perf,'stat','-x,','-o',f,'-e','instructions:u','--',w/(e+'.test'),'-test.cpu=1','-test.run=^$',f'-test.bench=^BenchmarkSMTCongruenceProbes$/^{op}$','-test.benchtime=200000x'],capture_output=True,check=True,env=dict(os.environ,GOMAXPROCS='1'))
   m=re.search(rb'200000\s+([\d.]+) ns/op\s+\d+ B/op\s+(\d+) allocs/op',r.stdout);assert m,r.stdout
   hw=next(v[0] for v in csv.reader(f.read_text().splitlines()) if len(v)>4 and v[2]=='instructions:u' and float(v[4])==100)
   wr.writerow((i,e,op,hw,m[1].decode(),m[2].decode()));sys.stdout.flush()
