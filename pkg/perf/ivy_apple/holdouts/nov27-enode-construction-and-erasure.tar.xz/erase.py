"""Remove an exact representative from the short congruence table in one probe."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();d={}
def save(k,s):
 dest=w/('erase-'+k.name);dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));d[str(k)]=str(dest)
k=p/'smtcore/smt_cg_small_table.go';s=k.read_text();a=s.index('func (t *smtCgSmallTable) del(');b=s.index('func (t *smtCgSmallTable) grow',a)
piece=s[a:b].replace('if t.count == 0 {','returnPLACEHOLDER\n}\n\nfunc (t *smtCgSmallTable) remove(k0,k1,expected *SMTEnode) bool {\nif t.count == 0 {',1).replace('returnPLACEHOLDER','t.remove(k0,k1,nil)').replace('\n\t\treturn\n','\n\t\treturn false\n').replace('\n\t\t\treturn\n','\n\t\t\treturn false\n').replace('if e.k0 == k0 && e.k1 == k1 {','if e.k0 == k0 && e.k1 == k1 {\nif expected!=nil && e.node!=expected{return false}').replace('t.entries[i] = smtCgSmallEntry{}','t.entries[i] = smtCgSmallEntry{}\nreturn true')
save(k,s[:a]+piece+s[b:])
k=p/'smtcore/smt_cg_table.go';s=k.read_text()
a='candidate, _, err := t.Find(node)\n\tif err != nil || candidate == nil {'
assert s.count(a)==1
s=s.replace(a,'''if err:=t.validateNode(node);err!=nil{return false,err}
 bucket,err:=t.ensureTable(node);if err!=nil{return false,err}
 if len(node.arguments)<=2 && (!node.commutative || len(node.arguments)==2) && !node.declaration.IsNull() {
    key:=smtCongruenceSmallKey(node)
    if bucket.small.remove(key[0],key[1],node) {return true,nil}
 }
 candidate,_,err:=bucket.find(node)
 if err!=nil||candidate==nil {''').replace('t.bucketFor(node).remove(candidate)','bucket.remove(candidate)')
save(k,s);(w/'erase.json').write_text(json.dumps({'Replace':d}))
