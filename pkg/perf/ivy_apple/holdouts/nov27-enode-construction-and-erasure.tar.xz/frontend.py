from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3])
for label in sys.argv[3:]:
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags=xtrace_off','-overlay',w/(label+'.json'),'-o',w/(label+'-ivy'),'./cmd/goivy_check'],cwd=front,check=True)
