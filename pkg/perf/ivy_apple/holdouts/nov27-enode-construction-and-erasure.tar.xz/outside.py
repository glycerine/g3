"""Attribute samples outside queue entry, assigning each stack to one operation."""
import collections
import csv
import sys

groups = [
    ('conflict resolution', '(*SMTKernel).resolveSearchConflict', 'smt::context::resolve_conflict('),
    ('assertion internalization', '(*SMTKernel).internalizeCheckAssertions', 'smt::context::internalize_assertions('),
    ('E-matching', '(*smtMAMImpl).Match', 'smt::mam_impl::match('),
    ('remaining propagation', '(*SMTInternalizerState).PropagateCore', 'smt::context::propagate('),
]
counts = collections.Counter()
rounds = collections.defaultdict(set)
with open(sys.argv[1]) as file:
    for row in csv.DictReader(file):
        engine, stack = row['engine'], row['stack']
        rounds[engine].add(row['round'])
        go = engine == 'g3'
        entry = '(*SMTQuantifierManager).instantiate\n' if go else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)'
        if entry in stack:
            continue
        phase = next((name for name, g, z in groups if (g if go else z) in stack), 'remaining')
        counts[engine, phase] += int(row['period']) * int(row['samples'])
for phase in [g[0] for g in groups] + ['remaining']:
    g, z = (counts[e, phase] / len(rounds[e]) / 1e6 for e in ('g3','z3'))
    print(phase, f'{g:.2f} {z:.2f} {g-z:.2f}')
