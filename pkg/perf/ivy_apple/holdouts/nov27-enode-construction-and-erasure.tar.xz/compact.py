"""Keep the overflow slice descriptor allocation on the wide path and read arity directly."""
from pathlib import Path
import json,subprocess,re
w=Path(__file__).resolve().parent;f=json.loads((w/'inline.json').read_text())['Replace'];out={}
for k,v in f.items():
 s=Path(v).read_text()
 if k.endswith('smt_enode_core.go'):
  s=s.replace('n.wideArgs = &a\n\t\treturn','wide:=a; n.wideArgs=&wide; n.setWideCount(len(a));return')
  s=s.replace('n.wideArgs = &a\n\treturn a','n.wideArgs = &a; n.setWideCount(len(a))\n\treturn a')
  i=s.index('func (n *SMTEnode) setArgs');s=s[:i]+'''func(n *SMTEnode) setWideCount(count int){if count<255{n.shortCount=uint8(count)}else{n.shortCount=255}}
func(n *SMTEnode) arity() int {if n.shortCount!=255{return int(n.shortCount)};return len(*n.wideArgs)}
'''+s[i:]
 if k.endswith('smt_enode_aux.go'):
  s=s.replace('t.node.setArgs(nil)','t.node.setArgs(nil)').replace('n.setArgs(nil)','n.wideArgs=nil;n.shortCount=0;n.shortArgs=[2]*SMTEnode{}')
  s=s.replace('*t.node.wideArgs = append((*t.node.wideArgs)[:0], args...)','*t.node.wideArgs = append((*t.node.wideArgs)[:0], args...);t.node.setWideCount(len(args))')
 s=re.sub(r'len\(([\w.]+)\.args\(\)\)',r'\1.arity()',s)
 d=w/('compact-'+Path(k).name);d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));out[k]=str(d)
(w/'compact.json').write_text(json.dumps({'Replace':out}))
