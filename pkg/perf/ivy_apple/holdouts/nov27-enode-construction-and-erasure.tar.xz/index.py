"""Return a short congruence-table slot from the lookup and erase that slot."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();out={}
def save(k,s):
 d=w/('index-'+k.name);d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));out[str(k)]=str(d)
k=p/'smtcore/smt_cg_small_table.go';s=k.read_text();a=s.index('if t.count == 0');b=s.index('// set is',a)
old=s[a:b];s=s[:a]+'''if i:=t.indexOf(k0,k1);i>=0{return t.entries[i].node};return nil
}
func(t *smtCgSmallTable) indexOf(k0,k1 *SMTEnode) int {
'''+old.replace('return nil','return -1').replace('return e.node','return i')+s[b:]
a=s.index('if t.count == 0',s.index('func (t *smtCgSmallTable) del('));b=s.index('t.count--',a)
s=s[:a]+'''if i:=t.indexOf(k0,k1);i>=0{t.deleteAt(i)}
}
func(t *smtCgSmallTable) deleteAt(i int){
 mask:=len(t.entries)-1
 '''+s[b:];save(k,s)
k=p/'smtcore/smt_cg_table.go';s=k.read_text()
a=s.index('key := smtCongruenceSmallKey(node)',s.index('func (b *smtCongruenceBucket) find('));b=s.index('// remove deletes',a);j=s.index('func (b *smtCongruenceBucket) store(',a)
seg=s[a:j].replace('if candidate := b.small.get(key[0], key[1]); candidate != nil {','''if i:=b.small.indexOf(key[0],key[1]);i>=0{
 candidate:=b.small.entries[i].node
 if candidate==node && !node.declaration.IsNull() && (!node.commutative||len(node.arguments)==2){return i,false,nil}''').replace('if candidate := b.small.get(key[1], key[0]); candidate != nil {','if i:=b.small.indexOf(key[1],key[0]);i>=0{candidate:=b.small.entries[i].node').replace('return candidate, commuted, err','return i,commuted,err').replace('return nil, false, nil','return -1,false,nil')
s=s[:a]+'''i,commuted,err:=b.findSmall(node)
 if i<0{return nil,false,err};return b.small.entries[i].node,commuted,err
}
func(b *smtCongruenceBucket) findSmall(node *SMTEnode)(int,bool,error){
'''+seg+s[j:]
a=s.index('candidate, _, err := t.Find(node)',s.index('func (t *SMTCongruenceTable) Erase('));j=s.index('return true, nil',a)
s=s[:a]+'''if err:=t.validateNode(node);err!=nil{return false,err}
 b,err:=t.ensureTable(node);if err!=nil{return false,err}
 if len(node.arguments)<=2 {
   i,_,err:=b.findSmall(node);if err!=nil||i<0{return false,err}
   entry:=b.small.entries[i];key:=smtCongruenceSmallKey(entry.node)
   if entry.k0==key[0] && entry.k1==key[1] {b.small.deleteAt(i)} else {b.remove(entry.node)}
   return true,nil
 }
 candidate,_,err:=b.find(node)
 if err!=nil||candidate==nil{return false,err};b.remove(candidate)
 '''+s[j:];save(k,s)
(w/'index.json').write_text(json.dumps({'Replace':out}))
