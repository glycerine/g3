"""Aggregate nonoverlapping formula intervals within each of the eight actual checks."""
from collections import Counter
from pathlib import Path
import csv,json,sys,subprocess,os
w=Path(__file__).resolve().parent
gold,examples=map(Path,sys.argv[1:3]);gold=gold.resolve();ref=gold/'reference/ticket_protocol'
rel,_,code=json.loads((gold/'cases.json').read_text())['ticket_protocol']
wr=csv.writer(sys.stdout);wr.writerow(('engine','round','batch','goal','kind','calls','instructions'))
for i in range(5):
 for e in ('g3','z3')[::1 if i%2==0 else -1]:
  r=subprocess.run(['taskset','-c','16',w/('detail-'+e),examples/rel],cwd=w,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
  n=Counter();cost=Counter();seen=set();rest=[]
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'IC-PRICE '):
    _,k,c,v=line.split();n[int(k)]+=int(c);cost[int(k)]+=int(v)
   elif line.startswith(b'STAGE-COUNT '):
    if n:
     _,b,g,stage,*_=line.split();b=int(b);g=int(g)
     assert stage==b'check' and b in range(2,6) and g in (55,56)
     seen.add((b,g))
     for k in n:wr.writerow((e,i,b,g,('fresh','bound','not-fresh','not-bound')[k//8]+'-'+('setup','fields','children','parents')[k%8],n[k],cost[k]))
     n.clear();cost.clear()
   else:rest.append(line)
  assert not n and len(seen)==8 and (r.returncode,r.stdout,b''.join(rest))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(e,seen,rest[-3:])
  sys.stdout.flush()
