"""Allocate each solver-owned enode from a fresh cell in a small GC-managed block."""
from pathlib import Path
import sys,json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;n=int(sys.argv[1]);name='block'+str(n);files={}
def save(k,s):
 d=w/(name+'-'+k.name);d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));files[str(k)]=str(d)
k=p/'smtcore/smt_enode_core.go';s=k.read_text().replace('byApp, options, nil)','byApp, options, nil, nil)').replace('term *smtTermInputs) (*SMTEnode','term *smtTermInputs, storage *SMTEnode) (*SMTEnode').replace('n := &SMTEnode{','n:=storage; if n==nil {n=new(SMTEnode)};*n=SMTEnode{');save(k,s)
k=p/'smtcore/smt_internalizer_state.go';s=k.read_text().replace('enodeStack                 []*SMTEnode','nodeSpace []SMTEnode\n enodeStack []*SMTEnode')
s=s.replace('node, err := newSMTEnode(',f'''if len(s.nodeSpace)==0 {{s.nodeSpace=make([]SMTEnode,{n})}}
 cell:=&s.nodeSpace[0]
 s.nodeSpace=s.nodeSpace[1:]
 if len(s.nodeSpace)==0 {{s.nodeSpace=nil}}
 node, err := newSMTEnode(''').replace('}, term)','}, term, cell)').replace('s.closed = true','s.nodeSpace=nil; s.closed = true');save(k,s)
o=w/(name+'.json');o.write_text(json.dumps({'Replace':files}))
