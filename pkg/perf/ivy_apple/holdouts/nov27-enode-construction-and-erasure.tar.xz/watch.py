import csv
import os
from pathlib import Path
import re
import subprocess
import sys

directory = Path(__file__).resolve().parent
writer = csv.writer(sys.stdout)
writer.writerow(('round','engine','ns_per_op','watches','bytes','allocs'))
for n in range(11):
    for name in ('watch-base', 'held')[::1 if n % 2 == 0 else -1]:
        data = subprocess.check_output(['taskset','-c','16', directory/(name + '.test'),'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTRelevancyWatchPop$','-test.benchtime=1000x'],env=dict(os.environ,GOMAXPROCS='1'),text=True)
        m = re.search(r'1000\s+([\d.]+) ns/op\s+([\d.]+) watches/op\s+(\d+) B/op\s+(\d+) allocs/op',data)
        assert m, data
        writer.writerow((n,name,*m.groups()))
        sys.stdout.flush()
