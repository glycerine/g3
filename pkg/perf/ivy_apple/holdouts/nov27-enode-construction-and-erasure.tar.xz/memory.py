"""Measure the cost of holding retired nodes and the normal live/idle solver footprint."""
from pathlib import Path
import csv,os,re,subprocess,sys
w=Path(__file__).resolve().parent;wr=csv.writer(sys.stdout);wr.writerow(('round','engine','benchmark','metric','value'))
labels=sys.argv[1:]
for i in range(7):
 for e in labels[i%len(labels):]+labels[:i%len(labels)]:
  r=subprocess.run(['taskset','-c','16',w/(e+'-memory.test'),'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMT(RetiredEnodeReferences|CongruenceScopeMemory)$','-test.benchtime=3x'],capture_output=True,check=True,env=dict(os.environ,GOMAXPROCS='1'),text=True)
  n=0
  for line in r.stdout.splitlines():
   if not line.startswith('Benchmark'):continue
   data=line.split();n+=1
   for val,metric in zip(data[2::2],data[3::2]):
    if metric.endswith('B/solver'):wr.writerow((i,e,data[0],metric,val))
  assert n==4,r.stdout
  sys.stdout.flush()
