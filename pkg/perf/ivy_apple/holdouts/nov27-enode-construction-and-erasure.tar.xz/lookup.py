"""Use the solver's enode table directly where child resolution has no callbacks."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
files={}
def save(k,s):
 d=w/('direct-'+k.name);d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));files[str(k)]=str(d)
k=p/'smtcore/smt_enode_core.go';s=k.read_text().replace('byApp, options, nil)','byApp, options, nil, nil)').replace('term *smtTermInputs) (*SMTEnode','term *smtTermInputs, table *smtEnodeTable) (*SMTEnode').replace('count != 0 && byApp == nil','count != 0 && byApp == nil && table == nil').replace('child := byApp(argument)','''var child *SMTEnode
 if table!=nil {child=table.get(argument)} else {child=byApp(argument)}''')
a=s.index('for _, child := range n.arguments');b=s.index('\n\t\t}',a);s=s[:a]+'if table==nil {\n'+s[a:b]+'\n}'+s[b:];save(k,s)
k=p/'smtcore/smt_internalizer_state.go';s=k.read_text().replace('newSMTEnode(s.manager, expression, s.context.enodes.get,','newSMTEnode(s.manager, expression, nil,').replace('}, term)','}, term, &s.context.enodes)');save(k,s)
o=w/'direct.json';o.write_text(json.dumps({'Replace':files}))
