from study import *
from collections import Counter
from bisect import bisect_left
import first_push_frontier as ff,macro_identity as mi,shutil
sys.path.insert(0,str(pkg/'perf/ivy_apple'));from relevance_counts import make_value
d=w/'matched-first-passes';d.mkdir(exist_ok=True)
header='''#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
namespace {
struct pass_instruction_span {
  char const* name;
  int fd,tid;
  uint64_t start,empty,begin_ns;
  static uint64_t clock_ns() { struct timespec t; if (clock_gettime(CLOCK_MONOTONIC, &t)) abort(); return uint64_t(t.tv_sec)*1000000000+t.tv_nsec; }
  uint64_t counter() const { uint64_t data[3]; if (read(fd,data,sizeof data)!=sizeof data || data[1]!=data[2]) abort(); return data[0]; }
  explicit pass_instruction_span(char const* n):name(n),tid(syscall(SYS_gettid)){
    perf_event_attr attr{}; attr.size=sizeof attr;attr.type=PERF_TYPE_HARDWARE;attr.config=PERF_COUNT_HW_INSTRUCTIONS;attr.exclude_kernel=1;attr.exclude_hv=1;attr.read_format=PERF_FORMAT_TOTAL_TIME_ENABLED|PERF_FORMAT_TOTAL_TIME_RUNNING;
    fd=syscall(SYS_perf_event_open,&attr,0,-1,-1,0);if(fd<0) abort();
    auto a=counter(); empty=counter()-a; begin_ns=clock_ns(); start=counter();
  }
  ~pass_instruction_span(){auto end=counter();auto ns=clock_ns();close(fd);fprintf(stderr,"ASSERTED-PASS %s %d %llu %llu %llu %llu\\n",name,tid,(unsigned long long)begin_ns,(unsigned long long)ns,(unsigned long long)(end-start),(unsigned long long)empty);}
};
}
'''
def native():
 od=d/'native';od.mkdir(exist_ok=True);src=pkg.parent/'src';bd=pkg.parent/'build';lib=ivy/'z3vendor/native_lib/libz3.a';member='asserted_formulas.o';assert subprocess.check_output(['ar','p',lib,member])==(bd/'smt'/member).read_bytes()
 q=src/'smt/asserted_formulas.cpp';s=q.read_text();anchor='if (!s.should_apply()) return true;';s=once(s,anchor,anchor+'\n    pass_instruction_span span(s.id());');(od/q.name).write_text(header+s)
 mk=(bd/'Makefile').read_text();conf=(bd/'config.mk').read_text();inc=re.search(r'\$\((includes_\d+)\).*\.\./src/smt/asserted_formulas\.cpp$',mk,re.M)
 run([*make_value(conf,'CXX'),*make_value(conf,'CXXFLAGS'),*make_value(mk,inc[1]),'-o',od/member,od/q.name],cwd=bd)
 libout=od/'libz3.a';shutil.copyfile(lib,libout);run(['ar','rcs',libout,od/member]);z=ivy.resolve()/'smt/quantifier.go'
 o=overlay(od/'overlay',ff.source()|{z:once(z.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(libout))});return build(od/'checker','native',o)
def gatepath():
 # Keep the Go observer identical to the separate stack-sampling trial.
 o=overlay(d/'g3/overlay',ff.source());return build(d/'g3/checker',o=o)
def lane(j,bs):
 c,n,sp,iso,rc,_,ref=j;od=d/n;od.mkdir(exist_ok=True);vs=list(bs)
 with(od/'runs.csv').open('w')as of:
  z=csv.writer(of);z.writerow('spec round engine pushes passes matches'.split())
  for i in range(5):
   for v in vs[i%len(vs):]+vs[:i%len(vs)]:
    sd=od/f'{i+1}-{v}';sd.mkdir(exist_ok=True);r=subprocess.run(['taskset','-c',str(c),bs[v],*(['isolate='+iso]if iso else[]),examples/sp],cwd=sd,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100'));ls=r.stderr.splitlines(keepends=True);other=b''.join(l for l in ls if not l.startswith((b'W-INTERVAL ',b'ASSERTED-PASS ')))
    assert r.returncode==rc and (r.stdout,other)==tuple((ref/y).read_bytes()for y in ('stdout','stderr')),(n,v,r.returncode,other[-200:]); windows=[tuple(map(int,(x[1],x[4],x[5],x[6])))for l in ls if l.startswith(b'W-INTERVAL ') and (x:=l.split())[2]==b'first'];ends=[x[3]for x in windows];assert ends==sorted(ends)
    nr=0
    with(sd/'passes.csv').open('w')as f:
     ph=csv.writer(f);ph.writerow('push stage instructions empty'.split())
     for l in ls:
      if not l.startswith(b'ASSERTED-PASS '):continue
      _,tag,tid,begin,end,ins,empty=l.decode().split();idx=bisect_left(ends,int(begin))
      if idx<len(windows)and windows[idx][1]==int(tid) and windows[idx][2]<=int(begin)and windows[idx][3]>=int(end):
       ph.writerow([windows[idx][0],tag,ins,empty]);nr+=1
    assert nr and windows,(v,n);z.writerow([n,i+1,v,len(windows),nr,1]);of.flush();print(n,i+1,v,len(windows),nr,flush=True)
def main():
 with ThreadPoolExecutor(2)as ex:
  bn=ex.submit(native);bg=ex.submit(gatepath);bs={'previous':w/'first-push-frontier/g3/goivy_check','g3':bg.result(),'native':bn.result()}
 js=[(c,*j[1:])for c,j in zip([1,3,12,22],(j for j in mi.jobs()if j[1]in ('ordinary','tlb','flash2','hybrid_reliable_broadcast_cisa')))]
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:lane(j,bs),js))
if __name__=='__main__':main()
