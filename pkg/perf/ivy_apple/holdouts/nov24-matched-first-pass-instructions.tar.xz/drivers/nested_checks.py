from study import *
from types import SimpleNamespace
sys.path.insert(0,str(pkg/'perf/ivy_apple/incremental_cost'));import first_pass_instructions as p
import macro_identity as mi
dr=w/'nested-first-confirmed';dr.mkdir(exist_ok=True)
args=SimpleNamespace(output=dr,goivy=ivy.resolve(),cpp_build=pkg.parent/'build',abc=(prior/'spec-survey/with-abc-native/abc').resolve(),detail=True)
bs=p.prepare(args)
def lane(t):
 cpu,j=t;_,n,sp,iso,rc,_,ref=j;dest=dr/n;dest.mkdir();a=SimpleNamespace(cpu=cpu,spec=examples/sp,expect_exit=rc,isolate=iso,reference=ref)
 with (dest/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['round','engine','first_pushes'])
  for i in range(5):
   for v,b in list(bs.items())[::1 if i%2==0 else -1]:
    num=p.measure(a,b,dest/f'{i+1}-{v}');z.writerow([i+1,v,num]);f.flush();print(n,i+1,v,num,flush=True)
with ThreadPoolExecutor(4)as ex:list(ex.map(lane,zip([34,26,24,31],(j for j in mi.jobs()if j[1]in ['ordinary','tlb','flash2','hybrid_reliable_broadcast_cisa']))))
