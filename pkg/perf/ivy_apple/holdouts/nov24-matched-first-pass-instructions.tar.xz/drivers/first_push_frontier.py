from study import *
import guarded_live as gl,macro_identity as mi
from bisect import bisect_left
from decimal import Decimal
from collections import Counter
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import first_push_profile as pf
d=w/'first-push-frontier';d.mkdir(exist_ok=True)
q=ivy.resolve()/'z3bridge_solver_model.go';driver=pkg/'smtcore/smt_asserted_driver.go'
def source():
 a=q.read_text();i=a.index('func (s *Solver) GetSmallModelWithCond(');pre,a=a[:i],a[i:]
 a=once(a,'if finalCond != nil {','if finalCond!=nil {\nfirstPhysical:=true')
 a=once(a,'z3solver.Push()\n\t\t\t\t}\n\t\t\t\tz3solver.Assert(zCond)','''if firstPhysical {end:=startWindow();z3solver.Push();end("first",0);firstPhysical=false}else{z3solver.Push()}
 }\n z3solver.Assert(zCond)''')
 s=driver.read_text();s=s.replace('if err := assertedVerbose(10,','defer trialPassBegin(pass.sourceName())()\n if err := assertedVerbose(10,',1)
 helper='''package smtcore
 import("os";"fmt";"runtime";"syscall";"unsafe")
 func trialPassBegin(name string)func(){runtime.LockOSThread();tid:=syscall.Gettid()
 var attr struct{Type,Size uint32;Config,Period,SampleType,ReadFormat,Flags uint64;Pad [16]byte};attr.Size=uint32(unsafe.Sizeof(attr));attr.Config=1;attr.Flags=1<<5|1<<6;attr.ReadFormat=3
 fd,_,e:=syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN,uintptr(unsafe.Pointer(&attr)),0,^uintptr(0),^uintptr(0),0,0);if e!=0{panic(e)}
 read:=func()uint64{var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,fd,uintptr(unsafe.Pointer(&v[0])),24);if e!=0 || n!=24 || v[1]!=v[2]{panic("pass counter")};return v[0]}
 clock:=func()int64{var ts syscall.Timespec;_,_,e:=syscall.RawSyscall(syscall.SYS_CLOCK_GETTIME,1,uintptr(unsafe.Pointer(&ts)),0);if e!=0{panic(e)};return ts.Nano()}
 empty:=read();empty=read()-empty;start:=clock();a:=read();return func(){b:=read();end:=clock();syscall.Close(int(fd));runtime.UnlockOSThread();fmt.Fprintln(os.Stderr,"ASSERTED-PASS",name,tid,start,end,b-a,empty)}}
 '''
 return {q:pre+a,ivy.resolve()/'logical_window.go':(prior/'hot-windows/g3/logical_window.go').read_text(),driver:s,driver.parent/'asserted_pass_benchmark_observer.go':helper}
def lane(j,bs):
 c,n,sp,iso,rc,_,ref=j
 for i in range(3):
  for en,b in list(bs.items())[::1 if i%2==0 else -1]:
   rd=d/n/f'{i+1}-{en}';rd.mkdir(parents=True,exist_ok=True);raw=rd/'data';period=1000003
   with(rd/'stdout').open('wb')as so,(rd/'events').open('wb')as se:
    r=subprocess.run(['taskset','-c',str(c),perf,'record','--quiet','--clockid','mono','--no-buildid','-m','1024','-e','instructions:u','-c',str(period),'--call-graph',('fp'if en=='g3'else'dwarf,8192'),'-o',raw,'--',b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=rd,stdout=so,stderr=se,env=dict(env,GOMAXPROCS='1',GOGC='100'))
   events=(rd/'events').read_bytes().splitlines(keepends=True);unmarked=b''.join(l for l in events if not l.startswith((b'W-INTERVAL ',b'ASSERTED-PASS ')));assert r.returncode==rc and (rd/'stdout').read_bytes()==(ref/'stdout').read_bytes()and unmarked==(ref/'stderr').read_bytes(),(n,en,unmarked[-200:])
   spans=[tuple(map(int,(t[1],t[4],t[5],t[6]))) for line in events if line.startswith(b'W-INTERVAL ') and (t:=line.split())[2]==b'first'];ends=[s[3]for s in spans]
   passes=[];ends2=[]
   with(rd/'passes.csv').open('w')as f:
    z=csv.writer(f);z.writerow('group stage instructions empty'.split())
    for l in events:
     if not l.startswith(b'ASSERTED-PASS '):continue
     _,tag,tid,begin,end,ins,empty=l.decode().split();tid,begin,end=map(int,[tid,begin,end]);ix=bisect_left(ends,begin)
     if ix<len(spans) and spans[ix][1]==tid and spans[ix][2]<=begin and spans[ix][3]>=end:passes.append((tag,tid,begin,end));z.writerow([spans[ix][0],tag,ins,empty])
   ends2=[p[3] for p in passes];assert ends==sorted(ends) and ends2==sorted(ends2)
   with (rd/'decode.log').open('wb')as ferr,subprocess.Popen([perf,'script','--ns','--no-inline','-F','tid,time,event,ip,sym,dso','-i',raw],stdout=subprocess.PIPE,stderr=ferr,text=True)as st,(rd/'totals.csv').open('w')as f:
    obs=Counter();fs=[];group=None;stage=None
    def count():
     if group is None:return
     guessed,func=pf.classify(fs)
     for level,val in [('stage',stage or guessed),('leaf',(fs or ['?'])[0]),('caller',func)]:obs[group,stage or '?',level,val]+=1
     for x in set(fs):
      if any(t in x for t in ['github.com/glycerine/g3/pkg/','asserted_formulas','ast_manager::','rewriter_tpl','th_rewriter','quantifier','smt::context::','pattern_inference','macro_manager','var_subst']):obs[group,stage or '?','inclusive',x]+=1
    for line in st.stdout:
     hd=pf.HEADER.match(line)
     if hd:
      count();group=None;fs=[];stage=None;tid=int(hd[1]);tm=int(Decimal(hd[2])*1000000000);ix=bisect_left(ends,tm)
      if ix<len(ends)and spans[ix][1]==tid and spans[ix][2]<=tm:
       group=spans[ix][0];k=bisect_left(ends2,tm)
       if k<len(ends2) and passes[k][1]==tid and passes[k][2]<=tm:stage=passes[k][0]
     elif group is not None:
      mt=pf.FRAME.match(line)
      if mt:fs.append(mt[1])
    count();assert st.wait()==0 and obs,(n,en)
    z=csv.writer(f);z.writerow('group measured_pass category name samples period'.split());z.writerows([*k,v,period]for k,v in sorted(obs.items()))
   assert 'lost'not in(rd/'decode.log').read_text().lower();raw.unlink();print(n,en,i+1,len(spans),len(passes),flush=True)
def main():
 o=overlay(d/'overlay',source())
 with ThreadPoolExecutor(2)as e:bs=dict(zip(['g3','native'],e.map(lambda en:build(d/en,en,o),['g3','native'])))
 js=[(c,*j[1:])for c,j in zip([14,16,18,19],(j for j in mi.jobs()if j[1]in ('tlb','ordinary','hybrid_reliable_broadcast_cisa','flash2')))]
 with ThreadPoolExecutor(len(js))as e:list(e.map(lambda j:lane(j,bs),js))
if __name__=='__main__':main()
