from end_stats import *
for n in ('tlb','ordinary','hybrid_reliable_broadcast_cisa','flash2'):
 s=defaultdict(list);groups=defaultdict(list)
 for p in (w/'matched-first-passes'/n).glob('*/passes.csv'):
  a=Counter();ns=Counter()
  for r in rows(p):a[r['stage']]+=(int(r['instructions'])-int(r['empty']))/1e9;ns[r['stage']]+=1
  e=p.parent.name.split('-')[1]
  for k,v in a.items():s[k,e].append(v);groups[k,e].append(ns[k])
 print(n)
 for k in sorted(set(k for k,e in s)):print(k,[(e,len(s[k,e]),groups[k,e][0],round(median(s[k,e]),4))for e in ['previous','g3','native']if s[k,e]])
