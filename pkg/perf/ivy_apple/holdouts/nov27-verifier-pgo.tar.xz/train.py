from pathlib import Path
import subprocess,os,sys,csv
w=Path(__file__).resolve().parent;ex,tlb,raft=map(Path,sys.argv[1:4]);cpu=sys.argv[4]
with (w/'training.csv').open('w') as f:
 out=csv.writer(f);out.writerow(('case','round','bytes'))
 for i in range(2):
  for name,spec,ref,code in [('raft','examples/raft/raft_no_assume.ivy',raft,0),('tlb','examples/liveness/tlb.ivy',tlb,1)]:
   profile=w/f'{name}-{i}.pprof'
   r=subprocess.run(['taskset','-c',cpu,w/'training',ex/spec],cwd=w,capture_output=True,env=dict(os.environ,IVY_PGO_PROFILE=str(profile),GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1',GOMAXPROCS='1'),timeout=180)
   assert (r.returncode,r.stdout,r.stderr)==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,r.returncode,r.stderr[-250:])
   out.writerow((name,i,profile.stat().st_size));f.flush()
