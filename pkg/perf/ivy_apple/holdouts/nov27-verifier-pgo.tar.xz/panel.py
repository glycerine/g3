"""Run the retained DIMACS and SMT controls against three Go compiler profiles."""
from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
pkg=Path.cwd();root=pkg/'build';old=root/'.nov26-sat-arena-hot'
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
panel,cpu=sys.argv[1:3];engines=[k+'='+str(w/v) for k,v in [('base','basecli'),('pgo','cli'),('blend','blendcli')]]
if panel=='sat':
 d=root/'.nov26-clause-locality/fixtures'
 cmd=['python3',w/'measure.py','--pkg',pkg,'--perf',perf,'--cpu',cpu,'--rounds','5','--solver-arg=-v:2']
 for status,name,stdin in [('unsat','pigeon8-s0',False),('sat','random-256-3',True),('unsat','random-208-3',False),('sat','random-208-4',False)]:
  cmd+=['--case',status+':'+str(d/(name+'.cnf'))+(':stdin' if stdin else '')]
 cmd+=engines+['z3='+str(pkg.parent/'build/z3')]
else:
 cmd=['python3',w/'measure_smt.py','--cpu',cpu,'--perf',perf,'--output',w/'smt-raw','--pairs','9']
 for n in (127,290):cmd+=['--query',root/f'.bool-scan/fixtures/ticket-{n}.smt2']
 cmd+=engines
with (w/(panel+'.csv')).open('w') as f:subprocess.run(cmd,stdout=f,check=True)
