from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent; pkg=Path.cwd();front,mod=map(lambda x:Path(x).resolve(),sys.argv[1:3]);target=sys.argv[3];mode=target.removeprefix('apple-')
cmd=['go','build','-buildvcs=false','-mod=readonly','-pgo='+('off' if mode in ('training','base','basecli','native') else str(w/('blend.pprof' if mode.startswith('blend') else 'complete.pprof')))]
if mode=='training':
 src=front/'cmd/goivy_check/main.go';dst=w/'profile-main.go'
 s=src.read_text();needle='os.Exit(goivy.MainWithConfig(args, cfg))';assert s.count(needle)==1
 dst.write_text(s.replace('"os/signal"','"os/signal"\n"runtime/pprof"').replace(needle,'''f,e:=os.Create(os.Getenv("IVY_PGO_PROFILE"));if e!=nil{panic(e)};if e=pprof.StartCPUProfile(f);e!=nil{panic(e)}
 code:=goivy.MainWithConfig(args,cfg);pprof.StopCPUProfile();if e=f.Close();e!=nil{panic(e)};os.Exit(code)'''))
 ov=w/'training.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}));cmd+=['-overlay',str(ov)]
cli=mode in ('cli','basecli','blendcli')
cmd+=['-tags','xtrace_off,classic_z3' if mode=='native' else 'xtrace_off','-o',str(w/target)]
if cli:cmd+=['./cmd/g3']
else:cmd+=['-modfile',str(mod),'./cmd/goivy_check']
subprocess.run(cmd,cwd=pkg if cli else front,check=True)
