from pathlib import Path
import subprocess,os
w=Path(__file__).resolve().parent;old=(Path.cwd()/'build/.nov26-sat-arena-hot').resolve()
for dest,inputs in [('complete',sorted(w.glob('*-[01].pprof'))),('blend',[w/'complete.pprof',old/'training/combined.pprof'])]:
 with (w/(dest+'.pprof')).open('wb') as out:
  subprocess.run(['go','run','-mod=readonly','.',*inputs],cwd=old/'profile-merge',env=dict(os.environ,GOPROXY='off'),stdout=out,check=True)
