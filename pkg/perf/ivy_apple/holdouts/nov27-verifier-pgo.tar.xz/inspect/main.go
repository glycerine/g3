package main

import (
	"encoding/csv"
	"os"
	"strconv"
	"strings"

	"github.com/google/pprof/profile"
)

func main() {
	w := csv.NewWriter(os.Stdout)
	w.Write([]string{"profile", "group", "cpu_ns"})
	for _, file := range os.Args[1:] {
		f, err := os.Open(file)
		if err != nil {
			panic(err)
		}
		p, err := profile.Parse(f)
		f.Close()
		if err != nil {
			panic(err)
		}
		idx := -1
		for i, t := range p.SampleType {
			if t.Type == "cpu" && t.Unit == "nanoseconds" {
				idx = i
			}
		}
		if idx < 0 {
			panic("missing CPU samples")
		}
		sums := map[string]int64{}
		for _, s := range p.Sample {
			group := "other"
			if len(s.Location) > 0 && len(s.Location[0].Line) > 0 {
				name := s.Location[0].Line[0].Function.Name
				const pkg = "github.com/glycerine/g3/pkg/"
				if strings.HasPrefix(name, pkg) {
					part, _, _ := strings.Cut(strings.TrimPrefix(name, pkg), ".")
					group = part
				} else if strings.HasPrefix(name, "github.com/glycerine/ivy/goivy") {
					group = "goivy"
				} else if strings.HasPrefix(name, "runtime.") {
					group = "runtime"
				}
			}
			sums[group] += s.Value[idx]
		}
		for key, n := range sums {
			w.Write([]string{file, key, strconv.FormatInt(n, 10)})
		}
	}
	w.Flush()
	if err := w.Error(); err != nil {
		panic(err)
	}
}
