"""Compare retained worker heap in independent processes after one warm scope round."""
import csv,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
with (w/'workers.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round engine case idle_bytes_per_solver fixture_bytes_per_solver'.split())
 for i in range(5):
  engines=['base','ivy','blendivy'];offset=i%len(engines)
  for eng in engines[offset:]+engines[:offset]:
   r=subprocess.check_output(['taskset','-c',sys.argv[1],w/(eng+'.test'),'-test.run=^$','-test.bench=^BenchmarkSMTScopeRestorationPeakIdle$','-test.benchtime=1x','-test.cpu=1'],text=True)
   bench=[s.split() for s in r.splitlines() if s.startswith('Benchmark')];assert len(bench)==2
   for fields in bench:
    out.writerow((i,eng,fields[0].split('/')[-1],fields[fields.index('idle-B/solver')-1],fields[fields.index('fixture-B/solver')-1]));f.flush()
