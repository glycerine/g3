from pathlib import Path
import csv,os,time,subprocess,sys
w=Path(__file__).resolve().parent;os.sched_setaffinity(0,{int(sys.argv[1])})
env=dict(os.environ,GOMAXPROCS='1')
with (w/'startup.csv').open('w') as f:
 out=csv.writer(f);out.writerow(('case','round','engine','milliseconds'))
 for case,args,data in [('version',['-version'],b''),('dimacs',['-dimacs','-in'],b'p cnf 1 1\n1 0\n'),('smt',['-smt2','-in'],b'(declare-const x Int)\n(assert (> x 1))\n(check-sat)\n')]:
  expected=None;engines=['basecli','cli','blendcli']
  for i in range(61):
   off=i%len(engines)
   for name in engines[off:]+engines[:off]:
    start=time.perf_counter_ns();r=subprocess.run([w/name,*args],env=env,input=data,capture_output=True)
    ms=(time.perf_counter_ns()-start)/1e6
    result=(r.returncode,r.stdout,r.stderr)
    if expected is None:
     assert r.returncode in (0,10) and r.stdout and not r.stderr
     if case=='smt':assert r.stdout.strip()==b'sat'
     if case=='dimacs':assert r.stdout.split()==[b'sat',b'1']
     expected=result
    assert result==expected
    if i:out.writerow((case,i,name,ms))
