from pathlib import Path
import subprocess,collections,csv
w=Path(__file__).resolve().parent;perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'propagate-lines.csv').open('w') as f:
 out=csv.writer(f);out.writerow(('file','source','samples'))
 for data in sorted((w/'samples').glob('*-g3-*.data')):
  leaves=subprocess.check_output([perf,'script','-i',data,'-G','-F','ip,sym'],text=True)
  counts=collections.Counter(line.split()[0] for line in leaves.splitlines() if ').propagateCore' in line)
  pcs=list(counts);src=subprocess.check_output([w/'go-addr2line',w/'blendcli'],input='\n'.join(pcs)+'\n',text=True).splitlines()[1::2];assert len(src)==len(pcs) and pcs
  tally=collections.Counter()
  for loc,pc in zip(src,pcs):tally[loc.split('/')[-1]]+=counts[pc]
  for loc,n in tally.most_common():out.writerow((data.stem,loc,n))
