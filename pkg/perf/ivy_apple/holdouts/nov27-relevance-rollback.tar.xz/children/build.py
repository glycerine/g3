"""Count descendants actually destroyed by the matched final disjunction releases."""
from pathlib import Path
import sys,re,json,shlex,subprocess,shutil
p=Path.cwd();w=Path(__file__).resolve().parent
e=sys.argv[1];front,mod=(Path(x).resolve() for x in sys.argv[2:])
marks=w.parent/'marks'
files=json.loads((marks/(e+'.json')).read_text())['Replace']
def save(k,s):
    out=w/(e+'-'+k.name);out.write_text(s);files[str(k)]=str(out)
if e=='g3':
    k=p/'smtcore/smt_relevancy.go';s=Path(files[str(k)]).read_text()
    a='counts[entry.kind &^ smtRelevancyWatchOwnsParent][last]++'
    s=s.replace(a,a+';if entry.kind==smtRelevancyRefTrail && last==1 {ast.WatchCountDeletion=true}')
    a='consumed, err := p.context.manager.DecRefHeldConsumed(entry.expression)'
    s=s.replace(a,a+';ast.WatchCountDeletion=false')
    a='if _,e=p.context.manager.DecRefHeldConsumed(h);e!=nil{panic(e)}'
    s=s.replace(a,'ast.WatchCountDeletion=k==4 && last==1;'+a+';ast.WatchCountDeletion=false')
    save(k,s)
    k=p/'ast/ast_core_delete.go';s=k.read_text()
    a='m.traceDeletingNode(current, n)'
    s=s.replace(a,'''if WatchCountDeletion {arity:=-1;if n.kind==ASTApp {arity=int(m.appAt(current.slot).count)};println("WATCH-NODE",arity)}
            '''+a)
    save(k,s+'\nvar WatchCountDeletion bool\n')
else:
    build=p.parent/'build'
    flags=dict(line.split('=',1) for line in (build/'config.mk').read_text().splitlines() if '=' in line)
    inc=re.findall(r'^includes_\d+ = (.*)$',(build/'Makefile').read_text(),re.M)
    includes=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    lib=w/'lib.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
    for name in ['smt_relevancy','ast']:
        if name=='smt_relevancy':
            s=(marks/'smt_relevancy.cpp').read_text()
            a='m_relevant_exprs.set(j,nullptr);'
            s='extern bool g3_watch_deletion;\n'+s.replace(a,'g3_watch_deletion=get_manager().is_or(e)&&e->get_ref_count()==1;'+a+'g3_watch_deletion=false;')
        else:
            s=(p.parent/'src/ast/ast.cpp').read_text()
            i=s.index('void ast_manager::delete_node(');a=s.index('worklist.pop_back();',i)+len('worklist.pop_back();')
            s='bool g3_watch_deletion=false;\n'+s[:a]+'\nif(g3_watch_deletion)fprintf(stderr,"WATCH-NODE %d\\n",is_app(n)?(int)to_app(n)->get_num_args():-1);\n'+s[a:]
        src=w/(name+'.cpp');obj=w/(name+'.o');src.write_text(s)
        subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-o',obj,src],cwd=build,check=True)
        subprocess.run(['ar','r',lib,obj],check=True)
    k=front/'smt/quantifier.go';save(k,k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
overlay=w/(e+'.json');overlay.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',overlay,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
