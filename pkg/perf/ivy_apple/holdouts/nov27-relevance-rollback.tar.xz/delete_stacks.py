"""Rank sampled instructions under AST deletion across matched verification calls."""
import collections,csv,sys
with open(sys.argv[1]) as f:rows=list(csv.DictReader(f))
for e in ['g3','z3']:
    d=collections.Counter(); rounds={r['round'] for r in rows if r['engine']==e}
    for r in rows:
        if r['engine']!=e:continue
        s=r['stack'].splitlines()
        marker='(*ASTManager).deleteNodeWorklistBody' if e=='g3' else 'ast_manager::delete_node('
        indices=[i for i,f in enumerate(s) if marker in f]
        if indices:
            i=max(indices);d[s[i-1] if i else '(self)']+=int(r['period'])*int(r['samples'])
    print(e,'total',sum(d.values())/len(rounds)/1e6)
    for k,v in d.most_common(15):print(round(v/len(rounds)/1e6,3),k)
