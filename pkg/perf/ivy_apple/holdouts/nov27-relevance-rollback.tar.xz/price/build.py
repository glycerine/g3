"""Bracket just the final OR release, including any child destruction it triggers."""
import sys,json,subprocess,shlex,re,shutil
from pathlib import Path
w=Path(__file__).resolve().parent
p=Path.cwd()
e=sys.argv[1]
front,mod,stages=(Path(x).resolve() for x in sys.argv[2:])
mark=w.parent/'marks'
files=json.loads((mark/(e+'.json')).read_text())['Replace']
def save(k,s):
    d=w/(e+'-'+k.name);d.write_text(s);files[str(k)]=str(d)
def replace(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
k=front/'phase_observer_trial.go'
s=Path(json.loads(stages.read_text())['Replace'][str(k)]).read_text()
s=replace(s,'start := time.Now()','active:=batch>=2 && batch<=5 && (goal==55 || goal==56);if active{os.Setenv("G3_WATCH_COUNT",fmt.Sprint(fd))};start := time.Now()')
s=replace(s,'elapsed := time.Since(start)','if active{os.Unsetenv("G3_WATCH_COUNT");fmt.Fprintln(os.Stderr,"WATCH-END",batch,goal,phase)};elapsed := time.Since(start)')
save(k,s)
if e=='g3':
    k=p/'smtcore/smt_relevancy.go';s=Path(files[str(k)]).read_text().replace('"os"','"os"\n"strconv"\n"unsafe"\n"syscall"')
    s+='''
func watchRead(fd uintptr)int64{var c [3]uint64;n,_,err:=syscall.RawSyscall(syscall.SYS_READ,fd,uintptr(unsafe.Pointer(&c[0])),24);if n!=24||err!=0{panic("read")};return int64(c[0])}
func watchStart()(uintptr,int64,int64){n,err:=strconv.Atoi(os.Getenv("G3_WATCH_COUNT"));if err!=nil{panic(err)};fd:=uintptr(n);a:=watchRead(fd);b:=watchRead(fd);return fd,a,b}
'''
    needle='consumed, err := p.context.manager.DecRefHeldConsumed(entry.expression)'
    s=replace(s,'if active {\n      rc,err', 'price:=false;var fd uintptr;var a,b int64; if active {\n      rc,err')
    s=replace(s,'counts[entry.kind &^ smtRelevancyWatchOwnsParent][last]++','counts[entry.kind &^ smtRelevancyWatchOwnsParent][last]++;price=entry.kind==smtRelevancyRefTrail && last==1')
    s=replace(s,needle,'if price{fd,a,b=watchStart()};'+needle+';if price{v:=watchRead(fd);println("WATCH-COST",3,v-2*b+a)}')
    s=replace(s,'if _,e=p.context.manager.DecRefHeldConsumed(h);e!=nil{panic(e)}','if k==4 && last==1 {fd,a,b:=watchStart();_,e=p.context.manager.DecRefHeldConsumed(h);v:=watchRead(fd);println("WATCH-COST",4,v-2*b+a)}else{_,e=p.context.manager.DecRefHeldConsumed(h)};if e!=nil{panic(e)}')
    save(k,s)
else:
    build=p.parent/'build'
    flags=dict(line.split('=',1) for line in (build/'config.mk').read_text().splitlines() if '=' in line)
    includes=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    s=(mark/'smt_relevancy.cpp').read_text()
    s='#include <unistd.h>\nstatic long long watch_read(int fd){unsigned long long c[3];if(read(fd,c,24)!=24)__builtin_trap();return c[0];}\n'+s
    s=replace(s,'m_relevant_exprs.set(j,nullptr);','if(get_manager().is_or(e)&&e->get_ref_count()==1){int fd=atoi(getenv("G3_WATCH_COUNT"));auto a=watch_read(fd), b=watch_read(fd);m_relevant_exprs.set(j,nullptr);auto v=watch_read(fd);fprintf(stderr,"WATCH-COST 4 %lld\\n",v-2*b+a);}else{m_relevant_exprs.set(j,nullptr);}')
    src=w/'smt_relevancy.cpp';src.write_text(s);obj=w/'smt_relevancy.o'
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-o',obj,src],cwd=build,check=True)
    lib=w/'lib-watch.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
    k=front/'smt/quantifier.go';save(k,k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
out=w/(e+'.json');out.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-buildvcs=false','-pgo=off','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',out,'-o',w/e,'./cmd/goivy_check'],cwd=front,check=True)
