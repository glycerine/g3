"""An asserted OR already retains the parent that owns each watched argument."""
from pathlib import Path
import json
w=Path(__file__).resolve().parent
p=Path.cwd()/'smtcore/smt_relevancy.go';s=p.read_text()
s=s.replace('const smtRelevancyWatchOwnsParent smtRelevancyTrailKind = 1 << 7','''const (
    smtRelevancyWatchOwnsParent smtRelevancyTrailKind = 1 << 7
    smtRelevancyWatchBorrowsSource smtRelevancyTrailKind = 1 << 6
)''')
s=s.replace('entry.kind &^ smtRelevancyWatchOwnsParent {','entry.kind &^ (smtRelevancyWatchOwnsParent | smtRelevancyWatchBorrowsSource) {')
s=s.replace('p.trail = p.trail[:i]\n\t\tif entry.kind','p.trail = p.trail[:i]\n        if entry.kind&smtRelevancyWatchBorrowsSource != 0 {continue}\n\t\tif entry.kind')
s=s.replace('} else if err := p.context.manager.IncRef(source); err != nil {','''} else if handler.kind == smtRelevancyAssertedOr {
        // The first watch holds the parent until every later watch is unlinked.
        // Its child edges keep both a positive argument and a NOT operand live.
        kind |= smtRelevancyWatchBorrowsSource
    } else if err := p.context.manager.IncRef(source); err != nil {''')
assert s.count('kind |= smtRelevancyWatchBorrowsSource')==1
q=w/'borrow-smt_relevancy.go';q.write_text(s)
(w/'borrow.json').write_text(json.dumps({'Replace':{str(p):str(q)}}))
