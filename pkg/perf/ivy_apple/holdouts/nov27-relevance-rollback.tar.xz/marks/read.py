from pathlib import Path
from collections import Counter
import csv,json,subprocess,os,sys
w=Path(__file__).resolve().parent
gold,examples=(Path(x).resolve() if i==0 else Path(x) for i,x in enumerate(sys.argv[1:]))
rel,_,exit_code=json.loads((gold/'cases.json').read_text())['ticket_protocol']
expected=gold/'reference/ticket_protocol'
wr=csv.writer(sys.stdout);wr.writerow(('engine','batch','goal','kind','surviving','final'))
for e in ['g3','z3']:
    run=subprocess.run(['taskset','-c','16',w/e,examples/rel],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
    rows=Counter();remaining=[];seen=set()
    for line in run.stderr.splitlines(keepends=True):
        if line.startswith(b'WATCH-POP '):
            _,k,i,n=line.split();rows[int(k),int(i)]+=int(n)
        elif line.startswith(b'WATCH-END '):
            _,b,g,phase=line.split()
            if phase==b'check':
                assert (b,g) not in seen
                seen.add((b,g))
                for k,kind in enumerate(['handler','positive','negative','owned-parent','OR-mark','other-mark']):
                    wr.writerow((e,int(b),int(g),kind,rows[k,0],rows[k,1]))
            rows.clear()
        else:remaining.append(line)
    assert len(seen)==8 and not rows and (run.stdout,b''.join(remaining),run.returncode)==((expected/'stdout').read_bytes(),(expected/'stderr').read_bytes(),exit_code),(e,seen,remaining[-4:])
