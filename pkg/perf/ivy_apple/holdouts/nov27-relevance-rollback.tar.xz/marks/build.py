"""Build isolated Go and repository-native observers on the same stage frontend."""
import sys, json, re, shutil, subprocess, shlex
from pathlib import Path
w=Path(__file__).resolve().parent
p=Path.cwd()
engine=sys.argv[1]
front,mod,overlay=(Path(x).resolve() for x in sys.argv[2:])
files=json.loads(overlay.read_text())['Replace']
def save(k,s):
    dest=w/(engine+'-'+k.name)
    dest.write_text(s)
    files[str(k)]=str(dest)
k=front/'phase_observer_trial.go'
save(k,'''package goivy
import ("fmt"; "os")
var phaseBatch int
func newStageBatch() int {phaseBatch++;return phaseBatch}
func startStage(batch,goal int)func(string){
    active:=batch>=2 && batch<=5 && (goal==55 || goal==56)
    if active {os.Setenv("G3_WATCH_COUNT","1")}
    return func(phase string){if active{os.Unsetenv("G3_WATCH_COUNT");fmt.Fprintln(os.Stderr,"WATCH-END",batch,goal,phase)}}
}
''')
if engine=='g3':
    k=p/'smtcore/smt_relevancy.go'
    s=k.read_text().replace('import (','import (\n"os"')
    tag='func (p *SMTRelevancyPropagator) undoTrail(limit int) error {'
    s=s.replace(tag,tag+'''
 active:=os.Getenv("G3_WATCH_COUNT")!=""
 var counts [4][2]int
 defer func(){if active{for k,row:=range counts{for i,n:=range row{if n>0{println("WATCH-POP",k,i,n)}}}}}()
''')
    needle='consumed, err := p.context.manager.DecRefHeldConsumed(entry.expression)'
    assert s.count(needle)==1
    s=s.replace(needle,'''if active {
      rc,err:=p.context.manager.GetRefCount(entry.expression);if err!=nil||rc==0{panic("dead trail entry")}
      last:=0;if rc==1{last=1};counts[entry.kind &^ smtRelevancyWatchOwnsParent][last]++
    }
'''+needle)
    a='p.relevant, err = p.context.manager.ShrinkHeldRefs(p.relevant, scope.relevantLimit)'
    assert s.count(a)==1
    s=s.replace(a,'''if os.Getenv("G3_WATCH_COUNT")!="" {
        for _,h:=range p.relevant[scope.relevantLimit:] {
            rc,e:=p.context.manager.GetRefCount(h);if e!=nil || rc==0{panic("dead mark")}
            head,_,e:=p.context.manager.ExpressionHeader(h);if e!=nil{panic(e)}
            k:=5;if head.Family==p.context.manager.BasicFamilyID() && head.DeclKind==ast.ASTOpOr{k=4}
            last:=0;if rc==1{last=1};println("WATCH-POP",k,last,1)
            if _,e=p.context.manager.DecRefHeldConsumed(h);e!=nil{panic(e)}
        };p.relevant=p.relevant[:scope.relevantLimit]
    }else{'''+a+'}')
    save(k,s)
else:
    build=p.parent/'build'
    flags=dict(line.split('=',1) for line in (build/'config.mk').read_text().splitlines() if '=' in line)
    includes=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    s=(p.parent/'src/smt/smt_relevancy.cpp').read_text()
    a=s.index('void undo_trail(unsigned old_lim)')
    b=s.index('m_trail.shrink(old_lim);',a)
    chunk=s[a:b].replace('unsigned i =','bool active=getenv("G3_WATCH_COUNT")!=nullptr; unsigned counts[3][2]={}; unsigned i =')
    chunk=chunk.replace('m.dec_ref(n);','if (active) {unsigned k=t.get_kind()==eh_trail::HANDLER?0:t.get_kind()==eh_trail::POS_WATCH?1:2; counts[k][n->get_ref_count()==1]++;} m.dec_ref(n);')
    s=s[:a]+chunk+'if(active)for(unsigned k=0;k<3;k++)for(unsigned i=0;i<2;i++)if(counts[k][i])fprintf(stderr,"WATCH-POP %u %u %u\\n",k,i,counts[k][i]);\n'+s[b:]
    a='m_relevant_exprs.shrink(old_lim);'
    assert s.count(a)==1
    s=s.replace(a,'''if(getenv("G3_WATCH_COUNT"))for(unsigned j=old_lim;j<m_relevant_exprs.size();j++){
        expr* e=m_relevant_exprs.get(j);fprintf(stderr,"WATCH-POP %d %d 1\\n",get_manager().is_or(e)?4:5,e->get_ref_count()==1);
        m_relevant_exprs.set(j,nullptr);
    }
    '''+a)
    src=w/'smt_relevancy.cpp';src.write_text('#include <cstdlib>\n'+s)
    obj=w/'smt_relevancy.o'
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-o',obj,src],cwd=build,check=True)
    lib=w/'lib-watch.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
    subprocess.run(['ar','r',lib,obj],check=True)
    k=front/'smt/quantifier.go'
    save(k,k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
out=w/(engine+'.json');out.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-buildvcs=false','-pgo=off','-mod=readonly','-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if engine=='z3' else ''),'-overlay',out,'-o',w/engine,'./cmd/goivy_check'],cwd=front,check=True)
