from pathlib import Path
import csv,re,subprocess,sys
w=Path(__file__).resolve().parent
wr=csv.writer(sys.stdout);wr.writerow(('round','engine','operation','instructions','ns_per_op','allocations'))
for i in range(9):
    for op in ['Individual','Combined']:
        for e in ['base','checked-once'][::1 if i%2==0 else -1]:
            f=w/'bench.perf'
            out=subprocess.check_output(['taskset','-c','16',sys.argv[1],'stat','-x,','-o',f,'-e','instructions:u','--',w/(e+'.test'),'-test.cpu=1','-test.run=^$',f'-test.bench=^BenchmarkASTSharedReferenceBatch$/^{op}$','-test.benchtime=500000x'],text=True)
            m=re.search(r'500000\s+([\d.]+) ns/op\s+\d+ B/op\s+(\d+) allocs/op',out);assert m,out
            n=next(l[0] for l in csv.reader(f.read_text().splitlines()) if len(l)>4 and l[2]=='instructions:u' and float(l[4])==100)
            wr.writerow((i,e,op,n,*m.groups()));sys.stdout.flush()
