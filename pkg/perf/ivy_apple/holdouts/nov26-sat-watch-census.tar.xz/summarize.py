"""Validate the paired SAT watch census and summarize profile attribution."""

from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import re
import sys
from statistics import median

base = Path(__file__).resolve().parent
census = base / "census"
stream = csv.writer(sys.stdout, lineterminator="\n")
stream.writerow(("case", "lists", "binary", "ternary", "clause", "total_watches", "blocked",
                 "other_true", "inspected", "moves", "units", "conflicts"))
for case in ("random-208-3", "random-208-4", "pigeon8-s0"):
    marker = "WATCH-CENSUS "
    def marker_value(engine):
        lines = (census / f"{case}-{engine}.stderr").read_text().splitlines()
        value, = (line.removeprefix(marker) for line in lines if line.startswith(marker))
        return value
    go, native = marker_value("g3"), marker_value("z3")
    counts = json.loads(go)
    assert counts == {key: int(n) for key, n in re.findall(r"(\w+)=(\d+)", native)}, case
    one = (census / f"{case}-g3.stdout").read_text()
    two = (census / f"{case}-z3.stdout").read_text()
    expected = "sat" if case == "random-208-4" else "unsat"
    assert one.splitlines()[0] == two.splitlines()[0] == expected
    # Both expose this same search. Allow omissions of zero and non-search stats.
    keys = ("conflicts", "decisions", "propagations", "ternary-propagations", "binary-propagations")
    stats = lambda s: dict(re.findall(r":([\w-]+)\s+(\d+)", s))
    assert all(stats(one).get(key, "0") == stats(two).get(key, "0") for key in keys), case
    stream.writerow((case, *(counts[k] for k in ("Lists", "Binary", "Ternary", "Clauses")),
                     sum(counts[k] for k in ("Binary", "Ternary", "Clauses")),
                     *(counts[k] for k in ("Blocked", "OtherTrue", "Inspected", "Moves", "Units", "Conflicts"))))

p = base / "profile"
leaf = defaultdict(list)
for flat in sorted(p.glob("*.flat")):
    assert int(flat.with_suffix(".throttle").read_text()) == 0
    case, engine = flat.stem.rsplit("-", 2)[::2]
    for l in flat.read_text().splitlines():
        if line := re.match(r"\s*(\d+\.\d+)%.*\[\.\] (.*)", l):
            leaf[case, engine, line[2]].append(float(line[1]))
print()
stream.writerow(("case", "engine", "leaf", "median_percent"))
for (case, engine, symbol), shares in sorted(leaf.items()):
    if "propagate_core" in symbol or ".propagateCore" in symbol or "(*ClauseBytes).Borrow" in symbol:
        assert len(shares) == 3
        stream.writerow((case, engine, symbol, median(shares)))

print()
stream.writerow(("case", "leaf", "caller", "sample_count"))
for case in ("random-208-3", "random-208-4"):
    caller = Counter()
    for path in sorted(p.glob(case+"-*-g3.stacks")):
        for sample in path.read_text().split("\n\n"):
            rows = sample.splitlines()
            if len(rows) < 2 or "(*ClauseBytes).Borrow" not in rows[1]:
                continue
            names = [l.split()[1].split("+0x")[0] for l in rows[2:] if "pkg/sat." in l]
            caller[" > ".join(name.removeprefix("github.com/glycerine/g3/pkg/sat.") for name in names[:3])] += 1
    for name, count in caller.most_common():
        stream.writerow((case, "Borrow", name, count))
