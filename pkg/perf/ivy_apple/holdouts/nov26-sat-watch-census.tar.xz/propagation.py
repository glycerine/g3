"""Prototype shorter SAT propagation paths using the existing arena and watch layout."""

import argparse
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
scratch = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("variants", nargs="+")
p.add_argument("--goivy", action="store_true")
a = p.parse_args()


def build(name):
    variants = name.split("+")
    assert set(variants) <= {"pages", "words", "trail", "dense", "checkpoint", "row", "pointer", "dense-owned"}
    out = scratch / name
    out.mkdir(exist_ok=True)
    patches = {}

    def replace(path, old, new):
        src = pkg / path
        text = patches.get(src, src).read_text()
        if text.count(old) != 1:
            raise ValueError((path, old))
        dest = out / src.name
        dest.write_text(text.replace(old, new))
        patches[src] = dest

    def extend(path, code):
        src = pkg / path
        text = patches.get(src, src).read_text()
        dest = out / src.name
        dest.write_text(text + code)
        patches[src] = dest

    path = "sat/sat_solver_propagation.go"
    if "pages" in variants:
        replace(path, "\t\trecords := store.records\n",
                """        records := store.records
        var pages arena.ClausePageView
        if destinations != nil && iter.backing != nil && iter.backing.owner == s.clauses.origin && !s.clauses.closed && s.clauses.self == s.clauses {
            pages = s.clauses.storage.PhysicalView()
        }
""")
        replace(path, """\t\t\t\toff := iter.backing.offset(bits, pos)
\t\t\t\tc := StoredClauseRef(off)
\t\t\t\tclause, e := s.clauses.view(c)
\t\t\t\tif e != nil {
\t\t\t\t\treturn false, e
\t\t\t\t}""",
                """                var clause satClauseView
                var off satClauseOffset
                code := bits.val1 >> satWatchSlotBits
                if code&1 == 0 {
                    clause = pages.Borrow(bits.val1 & ((1 << satWatchSlotBits) - 1), code>>1)
                }
                if clause == nil {
                    off = iter.backing.offset(bits, pos)
                    clause, e = s.clauses.view(StoredClauseRef(off))
                    if e != nil { return false, e }
                }
                if tracing {
                    off = iter.backing.offset(bits, pos)
                }
                c := StoredClauseRef(off)""")
        replace(path, "\t\t\t\t\tif e = v.watches.pushClause(i, c0, off);",
                """                    if off.slot == 0 {
                        off = iter.backing.offset(bits, pos)
                    }
                    if e = v.watches.pushClause(i, c0, off);""")
        replace(path, "\t\t\t\tclause.setFlag(satClauseFlagUsed)\n",
                """                clause.setFlag(satClauseFlagUsed)
                if off.slot == 0 {
                    off = iter.backing.offset(bits, pos)
                    c = StoredClauseRef(off)
                }
""")
        extend("arena/clause_pages.go", """
// ClausePageView is a borrowed directory. Use it inside an operation that
// holds the arena and executes without clause allocation or callbacks.
type ClausePageView struct { pages []clausePage }

func (a *ClauseBytes) PhysicalView() ClausePageView {
    if a.compat != nil || a.closed {
        return ClausePageView{}
    }
    return ClausePageView{pages: a.pages}
}

func (v ClausePageView) Borrow(slot, generation uint32) []byte {
    n := slot - 1
    page := n >> clausePageShift
    if page >= uint32(len(v.pages)) || generation == 0 {
        return nil
    }
    p := &v.pages[page]
    index := n & (clausePageSlots - 1)
    if index >= p.taken {
        return nil
    }
    offset := index * p.stride
    end := offset + p.stride
    row := p.data[offset:end:end]
    if binary.LittleEndian.Uint32(row) != generation {
        return nil
    }
    return row[clausePageHeaderBytes:]
}
""")
    if "words" in variants:
        file = "sat/sat_clause_storage.go"
        replace(file, '"sync/atomic"', '"sync/atomic"\n"runtime"\n"unsafe"')
        replace(file, """\trest := v[satClauseLiteralsOffset+8 : satClauseLiteralsOffset+4*uint64(n)]
\tfor len(rest) >= 4 {""",
                """    rest := v[satClauseLiteralsOffset+8 : satClauseLiteralsOffset+4*uint64(n)]
    if runtime.GOARCH == "amd64" && !satStorageSourceDebug {
        words := unsafe.Slice((*uint32)(unsafe.Pointer(&rest[0])), len(rest)/4)
        for i, value := range words {
            replacement := Literal(value)
            if assignment[replacement.index()] != lbool.False {
                v.setLiteral(1, replacement)
                words[i] = uint32(falsified)
                return replacement, true
            }
        }
        return 0, false
    }
    for len(rest) >= 4 {""")
    if "trail" in variants:
        replace(path, "\ttracing := s.tracingPropagation()\n\tfor {\n\t\tsize, e := v.trail.Size(v.trailRef)\n\t\tif e != nil {\n\t\t\treturn false, e\n\t\t}",
                """    tracing := s.tracingPropagation()
    fast := !tracing && !satStorageSourceDebug && !s.extensionPresent
    var e error
    if fast {
        if _, e = v.trail.Size(v.trailRef); e != nil {
            return false, e
        }
    }
    for {
        var size uint32
        if fast {
            size = uint32(len(v.trail.values))
        } else {
            size, e = v.trail.Size(v.trailRef)
            if e != nil { return false, e }
        }""")
    if "dense" in variants:
        file = "sat/sat_solver_watch_lists.go"
        replace(file, "lists                 []satSolverWatchListRef",
                "lists                 []satSolverWatchListRef\n densePrefix uint32")
        replace(file, "\tw.lists = append(w.lists, r)", """
            if uint32(len(w.lists)) == w.densePrefix && r.slot == w.densePrefix {
                w.densePrefix++
            }
            w.lists = append(w.lists, r)""")
        replace(file, "\tfor i := range w.lists {", "\tw.densePrefix = 0\n\tfor i := range w.lists {")
        replace(file, "\told := uint32(len(w.lists))", "\tw.densePrefix = min(n, w.densePrefix)\n\told := uint32(len(w.lists))")
        amend = "dest := currentPropagationList(i, destinations, records, store.origin)"
        replace(path, amend, """
                    var dest *satSolverWatchListRecord
                    if i < denseCount && records[i].live {
                        dest = &records[i]
                    } else {
                        dest = currentPropagationList(i, destinations, records, store.origin)
                    }""")
        anchor = "        records := store.records" if "pages" in variants else "\t\trecords := store.records"
        replace(path, anchor,
                """        records := store.records
            denseCount := uint32(0)
            if destinations != nil {
                denseCount = min(uint32(len(records)), v.watches.densePrefix)
            }""")
    if "dense-owned" in variants:
        file = "sat/sat_solver_watch_store.go"
        replace(file, "closed             bool", "closed, hasFreed   bool")
        replace(file, "\tx.live = false", "\tx.live = false\n s.hasFreed = true")
        anchor = "        records := store.records" if "pages" in variants else "\t\trecords := store.records"
        replace(path, anchor,
                """        records := store.records
            var dense []satSolverWatchListRecord
            // With sequential allocation, each owner has the matching record.
            // An explicit additional list changes the lengths. A free may
            // retire or reorder the slot, even before a new allocation.
            if destinations != nil && !store.hasFreed && len(records) == len(destinations) {
                dense = records
            }""")
        replace(path, "dest := currentPropagationList(i, destinations, records, store.origin)",
                """
                    var dest *satSolverWatchListRecord
                    if i < uint32(len(dense)) {
                        dest = &dense[i]
                    } else {
                        dest = currentPropagationList(i, destinations, records, store.origin)
                    }""")
    if "checkpoint" in variants:
        file = "sat/sat_solver_propagation_control.go"
        replace(file, "cfg, e := s.config.State()\n\tif e != nil {",
                "if e := s.config.open(); e != nil {")
        replace(file, "if n > cfg.MaxMemory {", "if n > s.config.state.MaxMemory {")
    if "row" in variants or "pointer" in variants:
        file = "arena/clause_pages.go"
        replace(file, "if r == (SmallBytesRef{}) {", "if r.Slot == 0 && r.Generation == 0 {")
        old = """\tstart := index * p.stride
\tend := start + p.stride
\trow := p.data[start:end:end]
\tif binary.LittleEndian.Uint32(row) != uint32(r.Generation) {
\t\treturn nil, ErrInvalidSlot
\t}
\treturn row[clausePageHeaderBytes:], nil"""
        if "pointer" in variants:
            replace(file, '"reflect"', '"reflect"\n"unsafe"')
            new = """    start := index * p.stride
                end := start + p.stride
                // The page constructor supplies a word-aligned stride and
                // at least a generation word in every allocated row.
                if uint64(end) > uint64(len(p.data)) {
                    return nil, ErrInvalidSlot
                }
                row := unsafe.Add(unsafe.Pointer(unsafe.SliceData(p.data)), uintptr(start))
                encoded := unsafe.Slice((*byte)(row), clausePageHeaderBytes)
                if binary.LittleEndian.Uint32(encoded) != uint32(r.Generation) {
                    return nil, ErrInvalidSlot
                }
                payload := (*byte)(unsafe.Add(row, clausePageHeaderBytes))
                return unsafe.Slice(payload, p.stride-clausePageHeaderBytes), nil"""
        else:
            new = """    start := index * p.stride
                data := p.data
                end := start + p.stride
                if binary.LittleEndian.Uint32(data[start:]) != uint32(r.Generation) {
                    return nil, ErrInvalidSlot
                }
                return data[start+clausePageHeaderBytes:end:end], nil"""
        replace(file, old, new)
    for dest in patches.values():
        subprocess.run(["gofmt", "-w", dest], check=True)
    cwd, name, args = pkg, "g3", ("./cmd/g3",)
    if a.goivy:
        for src, dest in list(patches.items()):
            patches[Path.home() / "g3/pkg" / src.relative_to(pkg)] = dest
        cwd, name, args = Path.home() / "ivy/goivy", "goivy_check", ("-tags=xtrace_off", "./cmd/goivy_check")
    overlay = out / (name + ".json")
    overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k,v in patches.items()}}))
    subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay",
                    overlay, "-o", out/name, *args], cwd=cwd, check=True)


for name in a.variants:
    build(name)
