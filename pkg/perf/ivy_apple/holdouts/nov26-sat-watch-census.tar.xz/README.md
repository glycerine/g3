# Measure identical SAT propagation work

The first SAT panels use the solver code at `16f6a80e0`. The final paired comparison starts at `53f0e3730`, which also contains the SMT operand change. Go builds used Go 1.27.3 with PGO disabled on an AMD Ryzen Threadripper 3960X. The linked GoIvy proof controls used the same frontend and examples checkout `07cdeec61` and ABC installation, with one Go processor and normal GC.

Run the builders from the Go package root. `census.py go` creates an observational overlay. `census.py native` compiles the in-tree SAT solver source with counters and relinks one diagnostic shell executable using the existing Z3 build objects. It uses the existing Makefile and configuration flags, but writes new files only in the extracted archive directory. The two observers are for single-worker runs. Their timings are excluded.

The cases come from `nov26-physical-clause-arena.tar.xz`. Run each census program with `-v:2 -st -dimacs path/to/input.cnf` with one worker. The census counts only visits in the propagation loop, so its units and conflicts are a subset of the shell's totals. `summarize.py` compares counters and outcomes and regenerates `census-summary.csv`.

The instruction profiles use ordinary uninstrumented builds, CPU 13, frame-pointer unwinding and one sample per 1,500,007 user instructions. The profiler checked three repetitions on each hard input and engine. All twelve accounted for zero loss and throttle records. The Go stacks support grouping the arena borrow by immediate and enclosing callers. The native comparison uses function leaf samples, so it does not depend on native stack completeness.

`propagation.py` generates the tested ordinary row lookup, typed literal scan, borrowed physical directory, lighter checkpoint and direct destination variants. Both the original dense-prefix and more conservative fresh-store variants are reproducible. The old dense-prefix version fails `TestSATPropagationMoveToRecycledList`. `specialized_loop.py` makes a separate copy of the source loop with the ordinary mode fixed at build time.

The timing driver `measure.py` pins each process to CPU 10, rotates binaries, verifies the result and SAT model, and compares decisions, conflicts and all three propagation counts. The hard inputs ran from files. Planted controls ran through stdin. The ordinary pigeon control added `--solver-arg=-v:2`. The complete verifier check on CPU 11 used `verify.py` and the transcripts and case descriptions in `nov24-verifier-instruction-stacks.tar.xz`.

The final Go version uses the committed destination lookup. Its focused checked-handle and ordinary arena, SAT and CLI tests are recorded with the instrumented SAT and arena suites and vet.
