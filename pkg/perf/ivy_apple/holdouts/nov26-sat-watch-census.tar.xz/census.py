"""Build paired, untimed watch-visit observers using this fork's sources."""

import argparse
import json
from pathlib import Path
import re
import shlex
import subprocess

pkg = Path.cwd()
out = Path(__file__).resolve().parent / "census"
out.mkdir(exist_ok=True)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("engine", choices=("go", "native"))
args = parser.parse_args()
labels = ("Lists", "Binary", "Ternary", "Clauses", "Blocked", "Missing", "OtherTrue", "Inspected", "Moves", "Units", "Conflicts")


def replace(text, edits):
    for old, new in edits:
        if text.count(old) != 1:
            raise ValueError((old, text.count(old)))
        text = text.replace(old, new)
    return text


def mark(text, locations, native):
    for where, label in locations:
        at = text.index(where)
        assert text.find(where, at+1) < 0, where
        end = text.index("\n", at)
        row = ("++watchCensus." if native else "watchCensus.") + label + (";" if native else "++")
        text = text[:end+1] + "        " + row + "\n" + text[end+1:]
    return text


if args.engine == "go":
    paths = {}
    original = pkg / "sat/sat_solver_propagation.go"
    text = original.read_text()
    first = text.index("func (s *satSolverPropagationState) propagateCore")
    last = text.index("// Source set_end", first)
    body = text[first:last]
    body = mark(body, [
        ("count := uint32(len(record.values()))", "Lists"),
        ("case 0:", "Binary"), ("case 1:", "Ternary"), ("case 2:", "Clauses"),
        ("if assignment[blocked.index()] == lbool.True {", "Blocked"),
        ("if clause.flag(satClauseFlagRemoved) || c1 != not {", "Missing"),
        ("if assignment[c0.index()] == lbool.True {", "OtherTrue"),
        ("if moved {", "Moves"),
        ("if value == lbool.False {", "Conflicts"),
        ("s.clausePropagations++", "Units"),
    ], False)
    path = out / original.name
    path.write_text(text[:first] + body + text[last:])
    paths[original] = path
    original = pkg / "sat/sat_clause_storage.go"
    path = out / original.name
    text = original.read_text()
    path.write_text(replace(text, [
        ("for len(rest) >= 4 {", "for len(rest) >= 4 {\n watchCensus.Inspected++"),
    ]))
    paths[original] = path
    original = pkg / "cmd/g3/main.go"
    path = out / original.name
    text = original.read_text()
    reference = '"github.com/glycerine/g3/pkg/sat"'
    if reference not in text:
        text = text.replace("package main", "package main\n import "+reference)
    text = replace(text, [("func main() {", "func main() {\n defer sat.PrintWatchCensus()")])
    path.write_text(text)
    paths[original] = path
    census = out / "watch_census.go"
    census.write_text("""package sat
import ("encoding/json"; "os"; "fmt")
var watchCensus struct { """ + ", ".join(labels) + """ uint64 }
func PrintWatchCensus() {
    b,_ := json.Marshal(watchCensus)
    fmt.Fprintln(os.Stderr, "WATCH-CENSUS "+string(b))
}
""")
    paths[pkg / "sat/watch_census.go"] = census
    for path in paths.values():
        subprocess.run(["gofmt", "-w", path], check=True)
    overlay = out / "observer.json"
    overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k, v in paths.items()}}))
    subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", overlay,
                    "-o", out / "g3", "./cmd/g3"], cwd=pkg, check=True)
else:
    root = pkg.parent
    build = root / "build"
    source = root / "src/sat/sat_solver.cpp"
    text = source.read_text()
    first = text.index("    bool solver::propagate_core(bool update)")
    last = text.index("    bool solver::propagate(bool update)", first)
    body = mark(text[first:last], [
        ("watch_list & wlist = m_watches[l.index()];", "Lists"),
        ("case watched::BINARY:", "Binary"), ("case watched::TERNARY:", "Ternary"),
        ("case watched::CLAUSE: {", "Clauses"),
        ("if (value(it->get_blocked_literal()) == l_true) {", "Blocked"),
        ("if (c.was_removed() || c[1] != not_l) {", "Missing"),
        ("if (value(c[0]) == l_true) {", "OtherTrue"),
        ("for (; l_it != l_end; ++l_it) {", "Inspected"),
        ("if (value(*l_it) != l_false) {", "Moves"),
        ("if (value(c[0]) == l_false) {", "Conflicts"),
        ("m_stats.m_propagate++;", "Units"),
    ], True)
    emit = "\n".join(f'        std::cerr << "{label}=" << {label} << " ";' for label in labels)
    header = '#include <iostream>\nnamespace {\nstruct WatchCensus {\n'
    header += "".join(f"    unsigned long long {label} = 0;\n" for label in labels)
    header += '''    ~WatchCensus() {\n        std::cerr << "WATCH-CENSUS ";\n''' + emit
    header += '''\n        std::cerr << std::endl;\n    }\n};\nWatchCensus watchCensus;\n}\n'''
    path = out / source.name
    path.write_text(header + text[:first] + body + text[last:])
    make = (build / "Makefile").read_text()
    config = dict(row.split("=", 1) for row in (build / "config.mk").read_text().splitlines() if "=" in row)
    config.update(dict(re.findall(r"(?m)^(includes_\d+) = (.*)$", make)))
    cpp = next(line.removeprefix("\t@") for line in make.splitlines()
               if line.startswith("\t@$(CXX) ") and line.endswith("../src/sat/sat_solver.cpp"))
    cpp = cpp.replace("sat/sat_solver$(OBJ_EXT)", str(out / "sat_solver.o")).replace("../src/sat/sat_solver.cpp", str(path))
    link = next(line.strip() for line in make.splitlines() if line.startswith("\t$(LINK) ") and "$(LINK_OUT_FLAG)z3" in line)
    link = link.replace("$(LINK_OUT_FLAG)z3$(EXE_EXT)", "$(LINK_OUT_FLAG)" + str(out / "z3"))
    link = link.replace("sat/sat$(LIB_EXT)", str(out / "sat_solver.o") + " sat/sat$(LIB_EXT)")

    def run(command):
        command = re.sub(r"\$\(([^)]+)\)", lambda match: config[match[1]], command)
        subprocess.run(shlex.split(command), cwd=build, check=True)

    run(cpp)
    run(link)
