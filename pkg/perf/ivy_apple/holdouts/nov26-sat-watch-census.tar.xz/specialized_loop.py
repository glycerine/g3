"""Measure a propagation loop specialized for the ordinary solver path."""

import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
out = Path(__file__).resolve().parent / "ordinary-loop"
out.mkdir(exist_ok=True)
src = pkg / "sat/sat_solver_propagation.go"
text = src.read_text()
first = text.index("func (s *satSolverPropagationState) propagateCore")
last = text.index("// Source set_end", first)
ordinary = text[first:last].replace("propagateCore", "propagateOrdinary", 1)
ordinary = ordinary.replace("tracing := s.tracingPropagation()", "const tracing = false")
ordinary = ordinary.replace("var destinations []satSolverWatchListRef\n\t\tif !tracing && !satStorageSourceDebug && !s.extensionPresent {\n\t\t\tdestinations = v.watches.lists\n\t\t}",
                            "destinations := v.watches.lists")
prior = "\t\tfor pos := uint32(0); pos < iter.end; pos++ {\n"
begin = ordinary.index(prior)
end = ordinary.index("\n\t\t\t// A trace or extension", begin)
ordinary = ordinary[:begin] + """        wide := iter.backing
        for index, bits := range data[:iter.end] {
            pos := uint32(index)""" + ordinary[end:]
ordinary = ordinary.replace("iter.backing.wide", "wide.wide")
# An extension cannot be present on this path. Keep the original diagnostic
# when a handcrafted watch would otherwise leave an invalid backing live.
begin = ordinary.index("\t\t\tcase 3:")
end = ordinary.index("\t\t\tdefault:", begin)
ordinary = ordinary[:begin] + ordinary[end:]
entry = "func (s *satSolverPropagationState) propagateCore(update bool) (bool, error) {"
wrapper = entry + """
    if s != nil && !satStorageSourceDebug && !s.extensionPresent && !s.tracingPropagation() &&
        !s.budget.InjectionArmed() {
        return s.propagateOrdinary(update)
    }"""
assert text.count(entry) == 1
text = text.replace(entry, wrapper, 1)
text += "\n" + ordinary
path = out / src.name
path.write_bytes(subprocess.check_output(["gofmt"], input=text.encode()))
overlay = out / "g3.json"
overlay.write_text(json.dumps({"Replace": {str(src): str(path)}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", overlay,
                "-o", out / "g3", "./cmd/g3"], cwd=pkg, check=True)
