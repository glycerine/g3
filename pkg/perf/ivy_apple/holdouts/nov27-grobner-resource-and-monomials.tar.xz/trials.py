from pathlib import Path
import subprocess,json,os
w=Path(__file__).resolve().parent;p=Path.cwd();k=p/'math/grobner/basis.go'
base=subprocess.check_output(['git','show','HEAD:pkg/math/grobner/basis.go'],text=True)
fixed=k.read_text()
fast=fixed.replace('i, j := 0, 0','''if len(a.vars) == len(b.vars) {
        return sameBody(a,b), nil,nil
    }
    if len(a.vars) == 1 {
        for i,v := range b.vars {
            if v != a.vars[0] {continue}
            if i == 0 {return true,b.vars[1:],nil}
            if i == len(b.vars)-1 {return true,b.vars[:i],nil}
            rest := make([]ast.ASTHandle,0,len(b.vars)-1)
            rest = append(rest,b.vars[:i]...)
            return true,append(rest,b.vars[i+1:]...),nil
        }
        return false,nil,nil
    }
    i, j := 0, 0''',1)
for mode,s in [('base',base),('fixed',fixed),('subset',fast)]:
 g=w/(mode+'.go');g.write_text(s);j=w/(mode+'.json');j.write_text(json.dumps({'Replace':{str(k):str(g)}}))
 subprocess.run(['go','test','-c','-overlay',j,'-o',w/(mode+'.test'),'./math/grobner'],check=True)
for i in range(5):
 for mode in ['base','fixed','subset'][i%3:]+['base','fixed','subset'][:i%3]:
  with (w/('bench-'+mode)).open('a') as out:subprocess.run(['taskset','-c','20',w/(mode+'.test'),'-test.run=^$','-test.bench=^BenchmarkUnmatchedGrobnerRule$','-test.benchtime=200ms'],env=dict(os.environ,GOMAXPROCS='1'),stdout=out,check=True)
