from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd()
s=p/'util/control/rlimit.go';o=w/'rlimit.go';t=s.read_text().replace('r.Steps += uint64(offset)','if offset != 0 { studyCharge(r,offset) }; r.Steps += uint64(offset)');o.write_text(t)
g=p/'util/control/study_charge.go';src=w/'study.go';src.write_text('''package control
import ("fmt";"os";"runtime";"strings")
func studyCharge(r *Reslimit, n uint32){
 var pcs [20]uintptr; k:=runtime.Callers(2,pcs[:]); fr:=runtime.CallersFrames(pcs[:k]); var names []string
 for {f,more:=fr.Next(); names=append(names,f.Function);if !more{break}}
 fmt.Fprintf(os.Stderr,"CHARGE %p %d %s\\n",r,n,strings.Join(names,"|"))
}
''')
j=w/'obs.json';j.write_text(json.dumps({'Replace':{str(s):str(o),str(g):str(src)}}))
for n in [22,36,37,39]:
 s=Path(f'/tmp/g3-arith-next/arith-inputs/14-2-{n}.smt2').read_text().split('\n(assert ')
 (w/f'{n}.smt2').write_text(s[0]+'\n(assert '+s[1]+'\n(push 1)\n(assert '+s[2])
subprocess.run(['go','build','-overlay',j,'-o',w/'g3','./cmd/g3'],check=True)
for n in [22,36,37,39]:
 with (w/f'go-{n}.log').open('w') as f:subprocess.run([w/'g3',w/f'{n}.smt2'],stderr=f,stdout=(w/f'go-{n}.stats').open('w'),check=True)
