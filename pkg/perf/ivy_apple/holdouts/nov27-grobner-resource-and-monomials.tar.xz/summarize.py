import csv,collections,re
from pathlib import Path
w=Path(__file__).resolve().parent
groups=collections.defaultdict(collections.Counter);inside=collections.defaultdict(collections.Counter)
for r in csv.DictReader((w/'profiles.csv').open()):
 n=int(r['samples'])*int(r['period'])/int(r['repeats'])/1e6;s=r['stack'];c=groups[r['goal'],r['engine']];c['all']+=n
 expressions={'finalCheck':r'SMTInternalizerState\).FinalCheckTheories|context::final_check\(','nonlinear':r'SMTTheoryArith\).processNonLinear|::process_non_linear\(','grobner':r'SMTTheoryArith\).computeGrobner|::compute_grobner\(','rewrite':r'TheoryRewriter\).Rewrite|rewriter_tpl<th_rewriter_cfg>::operator','pending':r'SMTKernel\).internalizePending|context::internalize_assertions\(','macro':r'SMTKernel\).findPendingMacros|asserted_formulas::find_macros','propagate':r'SMTTheoryArith\).propagateCore|theory_arith<[^\n]*>::propagate_core\(','maxMin':r'SMTTheoryArith\).maxMinNlVars|::max_min_nl_vars\('}
 for k,expr in expressions.items():
  if re.search(expr,s):c[k]+=n
 if re.search(expressions['finalCheck'],s):
  for frame in set(s.splitlines()):
   if 'SMTTheoryArith).' in frame or 'theory_arith<' in frame:inside[r['goal'],r['engine']][frame]+=n
for key,c in groups.items():print(key,{k:round(v,2) for k,v in c.items()},[(k.split('SMTTheoryArith).')[-1].split('mi_ext>::')[-1][:48],round(v,2)) for k,v in inside[key].most_common(8)])
