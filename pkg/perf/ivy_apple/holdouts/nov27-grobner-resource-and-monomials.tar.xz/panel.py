from pathlib import Path
import subprocess,os,json,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();old=Path('/tmp/g3-arith-next/final')
for name,target in [('abc',old/'abc'),('before',old/'release'),('native',old/'native')]:
 if not (w/name).exists():(w/name).symlink_to(target)
shutil.copyfile(old/'whole.py',w/'whole.py')
for name in ['fixed','subset']:
 j=w/(name+'-verifier.json');j.write_text(json.dumps({'Replace':{**json.loads((w/(name+'.json')).read_text())['Replace'],**json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())['Replace']}}))
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/(name+'-verifier'),'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
subprocess.run(['python3',w/'whole.py','whole','before','fixed-verifier','subset-verifier','native'],env=dict(os.environ,CPU='22',ROUNDS='11',CASES='14 15'),check=True)
