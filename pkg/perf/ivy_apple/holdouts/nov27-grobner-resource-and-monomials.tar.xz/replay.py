from pathlib import Path
import subprocess,csv,os,re
w=Path(__file__).resolve().parent
subprocess.run(['go','build','-overlay',w/'subset.json','-o',w/'candidate','./cmd/g3'],check=True)
engines=[('before','/tmp/g3-arith-next/cli'),('candidate',w/'candidate'),('native',Path.cwd().parent/'build/z3')]
with (w/'limits.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['query','push','limit','engine','answer','steps','decisions','conflicts','instances'])
 for src in sorted(Path('/tmp/g3-arith-next/arith-inputs').glob('*.smt2')):
  parts=src.read_text().split('\n(assert ');assert len(parts)==3
  for push in [0,1]:
   source=(parts[0]+'\n(assert '+parts[1]+('\n(push 1)' if push else '')+'\n(assert '+parts[2])
   def run(limit,engine,exe):
    text=f'(set-option :rlimit {limit})\n'+source
    r=subprocess.run([exe,'-in','-smt2'],input=text,text=True,capture_output=True,timeout=15,env=dict(os.environ,GOMAXPROCS='1'),check=True)
    assert not r.stderr and '(error' not in r.stdout
    answer=r.stdout.splitlines()[0];d=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout))
    steps=int(d['rlimit-count']);out.writerow([src.stem,push,limit,engine,answer,steps,*[d.get(k,0) for k in ['decisions','conflicts','quant-instantiations']]]);return steps
   n=run(0,*engines[-1]);run(0,*engines[0]);run(0,*engines[1])
   for limit in [n//2,n-1,n,n+1,n+100]:
    for engine,exe in engines:run(limit,engine,exe)
