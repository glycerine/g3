from pathlib import Path
import json,subprocess,os,csv
w=Path(__file__).resolve().parent;p=Path.cwd();old=Path('/tmp/g3-arith-next/final')
for mode in ['fixed','subset']:
 j=w/(mode+'-stage.json');j.write_text(json.dumps({'Replace':{**json.loads((w/(mode+'.json')).read_text())['Replace'],**json.loads((old/'arith-stage.json').read_text())['Replace']}}))
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/('arith-stage-'+mode),'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
for mode,target in [('before',old/'arith-stage-g3'),('native',Path('/tmp/g3-ticket-first/arith-stage-native'))]:
 d=w/('arith-stage-'+mode)
 if not d.exists():d.symlink_to(target)
src=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();src=src[src.index("rank=Path"):].replace("'g3','native'","'before','fixed','subset','native'").replace("'20'","'24'");exec(src)
