package control
import ("fmt";"os";"runtime";"strings")
func studyCharge(r *Reslimit, n uint32){
 var pcs [20]uintptr; k:=runtime.Callers(2,pcs[:]); fr:=runtime.CallersFrames(pcs[:k]); var names []string
 for {f,more:=fr.Next(); names=append(names,f.Function);if !more{break}}
 fmt.Fprintf(os.Stderr,"CHARGE %p %d %s\n",r,n,strings.Join(names,"|"))
}
