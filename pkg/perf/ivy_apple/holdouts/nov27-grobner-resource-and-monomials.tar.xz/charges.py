from pathlib import Path
from collections import Counter
import csv,json,re
w=Path(__file__).resolve().parent
with (w/'charges.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['goal','engine','all_steps','grobner_reduce','other_grobner','other_steps'])
 for goal in [22,36,37,39]:
  for engine in ['go','native']:
   vals=Counter()
   if engine=='go':
    for line in (w/f'go-{goal}.log').open():
     _,owner,n,stack=line.split(' ',3)
     vals[next((x.split('.')[-1] for x in stack.strip().split('|') if '/grobner.' in x),'other')]+=int(n)
    stats=(w/f'go-{goal}.stats').read_text();reduce=vals['reduce']
   else:
    for stack,n in json.loads((w/f'native-{goal}.json').read_text()):
     vals[next((x.split('(')[0].split('::')[-1] for x in stack if x.startswith('grobner::')),'other')]+=n
    stats=(w/f'native-{goal}.log').read_text();reduce=vals['simplify']
   total=sum(vals.values());assert total==int(re.search(r':rlimit-count\s+(\d+)',stats)[1])
   out.writerow([goal,engine,total,reduce,total-vals['other']-reduce,vals['other']])
