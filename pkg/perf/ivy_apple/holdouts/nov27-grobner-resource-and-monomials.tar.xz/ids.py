from pathlib import Path
import subprocess,csv,json,os
w=Path(__file__).resolve().parent;p=Path.cwd()
k=p/'math/grobner/grobner.go';s=k.read_text();s=s.replace('\n\tids          map[ast.ASTHandle]uint32','').replace(', ids: make(map[ast.ASTHandle]uint32)','').replace('\n\ts.ids = nil','').replace('s.astID(','s.manager.GetASTID(');i=s.index('func (s *Solver) astID(');s=s[:i]+s[s.index('func (s *Solver) varLess(',i):];g=w/'ids.go';g.write_text(s)
for mode,overlay in [('ids','/tmp/g3-ticket-first/validation/final.json'),('arith-stage-ids','/tmp/g3-arith-next/final/arith-stage.json')]:
 j=w/(mode+'.json');j.write_text(json.dumps({'Replace':{**json.loads(Path(overlay).read_text())['Replace'],str(k):str(g)}}))
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/mode,'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
subprocess.run(['python3',w/'whole.py','ids-whole','subset-verifier','ids'],env=dict(os.environ,CPU='24',ROUNDS='9',CASES='14 15'),check=True)
src=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();src=src[src.index("rank=Path"):].replace("'g3','native'","'subset','ids'").replace("'20'","'24'").replace("'arith-stages.csv'","'ids-stages.csv'");exec(src)
