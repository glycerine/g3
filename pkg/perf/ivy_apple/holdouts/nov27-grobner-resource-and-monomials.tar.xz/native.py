import gdb,os,collections,json
n=os.environ['ARITH_GOAL'];w='/tmp/g3-arith-ops'
tally=collections.Counter()
class Count(gdb.Breakpoint):
 def stop(self):
  f=gdb.newest_frame()
  amount=int(f.read_register('esi')) if self.location.endswith('unsigned int)') else 1
  if amount:
   names=[]
   while f and len(names)<14:
    names.append(f.name() or '?');f=f.older()
   tally[tuple(names)]+=amount
  return False
for sig in ['reslimit::inc()','reslimit::inc(unsigned int)']:Count(sig)
gdb.execute('run '+w+'/'+n+'.smt2')
with open(w+'/native-'+n+'.json','w') as f:json.dump(list(tally.items()),f)
