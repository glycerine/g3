from pathlib import Path
import subprocess,os,csv,re
w=Path(__file__).resolve().parent; perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'strategies.csv').open('w') as f:
 out=csv.writer(f);out.writerow('goal engine strategy round answer instructions steps decisions conflicts gb'.split())
 for goal in [22,36,37,39]:
  source=Path(f'/tmp/g3-arith-ops/{goal}.smt2').read_text()
  for i in range(3):
   for engine,exe in [('g3',Path('/tmp/g3-arith-ops/candidate')),('native',Path.cwd().parent/'build/z3')][::1 if i%2==0 else -1]:
    for switch in ['default','smt.arith.nl.gb','smt.arith.nl.branching']:
     txt=(f'(set-option :{switch} false)\n' if switch!='default' else '')+source
     stat=w/'scratch.stat'
     try:r=subprocess.run(['taskset','-c','24',perf,'stat','-e','instructions:u','-x,','-o',stat,'--',exe,'-in','-smt2'],input=txt.encode(),env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,timeout=4)
     except subprocess.TimeoutExpired:out.writerow([goal,engine,switch,i,'timeout','','','','','']);continue
     output=r.stdout.decode();assert r.returncode==0 and '(error' not in output and not r.stderr,(output,r.stderr)
     steps=dict(re.findall(r':([\w-]+)\s+(\d+)\b',output))
     ins=next(int(z[0]) for z in csv.reader(stat.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100)
     out.writerow([goal,engine,switch,i,output.splitlines()[0],ins,*[steps.get(k,0) for k in ('rlimit-count','decisions','conflicts','arith-grobner')]]);f.flush()
