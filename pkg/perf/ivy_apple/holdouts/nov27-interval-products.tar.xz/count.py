import os,collections,gdb,json
w='/tmp/g3-interval-products';en=os.environ['IV_ENGINE'];goal=os.environ['IV_GOAL']
targets={'g3':['github.com/glycerine/g3/pkg/smtcore.(*SMTTheoryArith).mkIntervalForMonomial','github.com/glycerine/g3/pkg/smtcore.(*SMTTheoryArith).mulBoundOf','github.com/glycerine/g3/pkg/smtcore.(*smtOldInterval).mul'],'native':['smt::theory_arith<smt::mi_ext>::mk_interval_for(grobner::monomial const*)','smt::theory_arith<smt::mi_ext>::mul_bound_of(expr*, unsigned int, old_interval&)','old_interval::operator*=(old_interval const&)']}
c=collections.Counter()
class Count(gdb.Breakpoint):
 def stop(self):
  f=gdb.newest_frame();chain=[]
  while f and len(chain)<14:
   chain.append(f.name() or '?');f=f.older()
  c[self.location,any(name==targets[en][0] for name in chain)]+=1
  return False
for sig in targets[en]:Count(sig)
gdb.execute('run /tmp/g3-arith-ops/'+goal+'.smt2')
with open(w+'/'+en+'-'+goal+'.json','w') as f:json.dump(list(c.items()),f)
