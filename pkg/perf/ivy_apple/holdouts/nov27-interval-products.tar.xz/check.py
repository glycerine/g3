from pathlib import Path
import subprocess,csv,os,json,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();v=Path('/tmp/g3-arith-ops/validation')
for n,t in [('abc',v/'abc'),('base',v/'release'),('arith-stage-before',Path('/tmp/g3-arith-ops/arith-stage-subset'))]:
 if not (w/n).exists():(w/n).symlink_to(t)
for n,ov in [('trial','/tmp/g3-ticket-first/validation/final.json'),('arith-stage-trial','/tmp/g3-arith-next/final/arith-stage.json')]:
 j=w/(n+'-verifier.json');j.write_text(json.dumps({'Replace':{**json.loads(Path(ov).read_text())['Replace'],**json.loads((w/'overlay.json').read_text())['Replace']}}))
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/n,'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
src=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();src=src[src.index("rank=Path"):].replace("'g3','native'","'before','trial'").replace("'20'","'26'");exec(src)
shutil.copyfile(v/'whole.py',w/'whole.py')
subprocess.run(['python3',w/'whole.py','whole','base','trial'],env=dict(os.environ,CASES='14 15',ROUNDS='9',CPU='20'),check=True)
