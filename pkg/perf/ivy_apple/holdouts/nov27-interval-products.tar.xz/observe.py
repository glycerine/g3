from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'smtcore/smt_theory_arith_nl.go';b=p/'smtcore/old_interval.go';s=a.read_text()
for key,code in [('func (t *SMTTheoryArith) isInconsistentEq','println("IV-EQ")'),('func (t *SMTTheoryArith) isInconsistent2','println("IV-SQUARE")'),('func (t *SMTTheoryArith) mkIntervalForMonomial','println("IV-MON",m,m.Degree());defer println("IV-END")'),('func (t *SMTTheoryArith) mulBoundOf','println("IV-BOUND", power)')]:
 i=s.index(' {',s.index(key))+2;s=s[:i]+'\n'+code+s[i:]
s1=w/'observer-nl.go';s1.write_text(s);s2=w/'observer-mul.go';s2.write_text(b.read_text().replace('if i.zero() {','if i.zero() {',1).replace('func (i *smtOldInterval) mul(other *smtOldInterval) (err error) {','func (i *smtOldInterval) mul(other *smtOldInterval) (err error) {\nprintln("IV-MUL")'))
j=w/'observer.json';j.write_text(json.dumps({'Replace':{str(a):str(s1),str(b):str(s2)}}));subprocess.run(['go','build','-overlay',j,'-o',w/'observer','./cmd/g3'],check=True)
for g in [22,39]:
 r=subprocess.run([w/'observer',f'/tmp/g3-arith-ops/{g}.smt2'],capture_output=True,check=True)
 assert r.stdout.startswith(b'unsat\n') and all(l.startswith(b'IV-') for l in r.stderr.splitlines())
 (w/f'calls-{g}.txt').write_bytes(r.stderr);(w/f'stats-{g}.txt').write_bytes(r.stdout)
