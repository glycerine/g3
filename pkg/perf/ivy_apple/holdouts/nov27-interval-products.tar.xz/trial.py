from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd();k=p/'smtcore/old_interval.go';s=k.read_text().replace('var temps []*smtExtendedRational','// Multiplying two mixed intervals needs all four endpoint products.\n var temps [4]smtExtendedRational\n used := 0').replace('for _, t := range temps {\n\t\t\terr = errors.Join(err, t.del(q))','for j := 0; j < used; j++ {\n err = errors.Join(err, temps[j].del(q))').replace('r, e := smtExtendedProduct(q, x, y)\n\t\ttemps = append(temps, &r)\n\t\treturn &r, e','r := &temps[used]\n used++\n var e error\n *r, e = smtExtendedProduct(q, x, y)\n return r, e');g=w/'old_interval.go';g.write_text(s);subprocess.run(['gofmt','-w',g],check=True)
j=w/'overlay.json';j.write_text(json.dumps({'Replace':{str(k):str(g)}}))
subprocess.run(['go','test','-overlay',j,'-c','-o',w/'trial.test','./smtcore'],check=True)
for i in range(5):
 for mode in ['base','trial'][::1 if i%2==0 else -1]:
  with (w/(mode+'.txt')).open('a') as out:subprocess.run(['taskset','-c','20',w/(mode+'.test'),'-test.run=^$','-test.bench=^BenchmarkIntervalEndpointProducts$','-test.benchtime=200ms'],stdout=out,check=True)
