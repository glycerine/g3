from pathlib import Path
s=Path('/tmp/g3-plan-budget/broad.py').read_text();s=s[:s.index('with concurrent.futures.ThreadPoolExecutor')]
exec(s)
names=['doc/examples/leader_election_ring.ivy','examples/pldi16/learning_switch.ivy','examples/pldi16/leader_election_ring.ivy','doc/examples/cav2024/examp1.ivy','test/field1.ivy','doc/examples/networking/ip_spec1.ivy','examples/ivy/card2.ivy','test/SCP_problem_simplified_2.ivy','ivy/ivy2/ast.ivy','test/proving9a.ivy']
run(10,'confirm',names,9,list(modes))
