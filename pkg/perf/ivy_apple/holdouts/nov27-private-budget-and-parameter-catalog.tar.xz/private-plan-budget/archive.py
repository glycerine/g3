from pathlib import Path
import tarfile
w=Path(__file__).resolve().parent
old=Path('/tmp/g3-live-frame-cost/private')
out=Path.cwd()/'perf/ivy_apple/holdouts/nov27-private-budget-and-parameter-catalog.tar.xz'
with tarfile.open(out,'w:xz',preset=4) as tar:
 def add(f,n):tar.add(f,'private-plan-budget/'+str(n),recursive=False)
 for f in sorted(w.rglob('*')):
  if f.is_file() and not f.is_symlink() and f.suffix in ('.py','.csv','.json','.txt','.md'):add(f,f.relative_to(w))
 deps=[old/'obs.json',old/'study.py',old/'init/setup.json',old/'init/labels.json',Path('/tmp/g3-early-cost/detail/run.py'),Path('/tmp/g3-or-install/final/release.py'),Path('/tmp/g3-reduction-rows/compat.txt'),Path('/tmp/g3-reduction-rows/ranking.csv')]
 import json
 for f in [old/'obs.json',old/'init/setup.json']:deps += [Path(v) for v in json.loads(f.read_text())['Replace'].values()]
 for f in sorted(set(deps)):add(f,Path('dependencies')/f.relative_to('/tmp'))
