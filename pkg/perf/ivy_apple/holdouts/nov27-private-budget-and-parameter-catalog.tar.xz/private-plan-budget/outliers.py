from pathlib import Path
import sys
w=Path(__file__).resolve().parent;mode=sys.argv[1];d=w/'outlier'/mode;d.mkdir(exist_ok=True,parents=True)
s=(w/'profile.py').read_text().replace('w=Path(__file__).resolve().parent;','')
s=s.replace("o=w/'profile.json';","""if mode!='base':ov.update(json.loads((w.parent.parent/mode/'trial.json').read_text())['Replace'])
ov.update(json.loads((w.parent.parent/'original.json').read_text())['Replace'])
o=w/'profile.json';""")
a=s.index("for spec in ['examples/");b=s.index(']:',a)+2
s=s[:a]+"""for spec in ['doc/examples/cav2024/examp1.ivy','test/proving9a.ivy','examples/pldi16/learning_switch.ivy']:"""+s[b:]
s=s.replace("w/'g3'","Path('/wd_black1tb/home/jaten/tmp/g3-nov27-private-budget')/('meter-'+mode)")
w=d;exec(s)
