from pathlib import Path
import csv
from statistics import median
for f in Path(__file__).resolve().parent.glob('*.csv'):
 rows=list(csv.DictReader(f.open()))
 if len(set(r['round'] for r in rows))!=3:continue
 cols=list(rows[0]);cols=cols[cols.index('initializeQueueHeuristics')+1:]
 print(f.stem,sorted([(round(median(sum(int(r[k]) for r in rows if r['proved']=='false' and r['round']==str(i)) for i in range(3))/1e6,3),k) for k in cols],reverse=True))
