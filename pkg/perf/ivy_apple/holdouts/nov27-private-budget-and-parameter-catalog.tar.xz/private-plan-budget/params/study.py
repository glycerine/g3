from pathlib import Path
import json,re,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();old=Path('/tmp/g3-live-frame-cost/private');ov=json.loads((old/'init/setup.json').read_text())['Replace'];labels=json.loads((old/'init/labels.json').read_text())
def source(key):
 f=p/key;return Path(ov.get(str(f),f)).read_text()
def save(key,s):
 f=p/key;d=w/(f.name+'.txt');d.write_text(s);ov[str(f)]=str(d)
k='api/internal/order/early_cost_trial.go';save(k,source(k).replace('[50]','[96]'))
k='api/api_simple_solver_object.go';s=source(k);pat='e40:=order.PriceSection(40);';s=s.replace('package api','package api\nimport study "github.com/glycerine/g3/pkg/smtcore"',1).replace(pat,pat+'study.FactoryProbe=order.PriceSection;').replace('s.create(s.logic);e40()','s.create(s.logic);study.FactoryProbe=nil;e40()');save(k,s)
probes=['NewSMTKernel','newSMTInternalizerState','NewSMTCheckerContext','NewSMTRelevancyPropagator','smtInstallRetainedSetup','configurePreprocessingParamsCore','NewSMTParams','Update','initContextEnodes','initializeQueueHeuristics']
files=list((p/'smtcore').glob('*.go'))
for name in probes:
 pat=re.compile(r'(?m)^func '+(r'\(\w+ \*SMTParams\) ' if name=='Update' else r'(?:\([^\n]+?\) )?')+name+r'\([^\n]*?\) [^\n]*?\{')
 matches=[f for f in files if not f.name.endswith('_test.go') and pat.search(f.read_text())];assert len(matches)==1,(name,matches);k=str(matches[0].relative_to(p));s=source(k);m=pat.search(s);idx=len(labels);labels.append([k,name]);s=s[:m.end()]+f'\n if FactoryProbe!=nil {{defer FactoryProbe({idx})()}}\n'+s[m.end():];save(k,s)
for f in sorted((p/'smtcore').glob('util_smt_*params.go')):
 k=str(f.relative_to(p));s=source(k)
 for m in reversed(list(re.finditer(r'(?m)^func \(s \*(\w+)\) (constructSource|updateLocal)\([^\n]*?\) [^\n]*?\{',s))):
  idx=len(labels);labels.append([k,m[1]+'.'+m[2]]);s=s[:m.end()]+f'\n if FactoryProbe!=nil {{defer FactoryProbe({idx})()}}\n'+s[m.end():]
 if 'SourceGetValueName("auto_config")' in s:
  z='value, e := s.Globals.SourceGetValueName("auto_config")';idx=len(labels);labels.append([k,'global auto_config']);s=s.replace(z,'var finish func();if FactoryProbe!=nil {finish=FactoryProbe('+str(idx)+')};'+z+';if finish!=nil{finish()}')
 save(k,s)
k='smtcore/smt_kernel.go';save(k,source(k)+'\nvar FactoryProbe func(int)func()\n')
(w/'labels.json').write_text(json.dumps(labels));o=w/'obs.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',o,'-o',w/'g3','./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
import csv
src=Path('/tmp/g3-early-cost/detail');s=(old/'study.py').read_text();exec(s[s.index('ex=Path'):])
