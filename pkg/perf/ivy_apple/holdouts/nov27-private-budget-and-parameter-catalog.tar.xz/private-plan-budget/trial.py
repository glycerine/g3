from pathlib import Path
import subprocess,sys,json
p=Path.cwd();w=Path(__file__).resolve().parent;steps=int(sys.argv[1]);w=w/str(steps);w.mkdir(exist_ok=True)
src=p/'api/api_verification_goal.go';s=src.read_text();k='check(narrow, 6000)';assert s.count(k)==1
d=w/'goal.go.txt';d.write_text(s.replace(k,'check(narrow, '+str(steps)+')'))
o=w/'trial.json';o.write_text(json.dumps({'Replace':{str(src):str(d)}}))
s=Path('/tmp/g3-or-install/final/release.py').read_text().replace('w=Path(__file__).resolve().parent;','').replace('/tmp/g3-card-install/volume-release','/tmp/g3-live-frame-cost/recheck/baseline').replace("'-o',w/'release'","'-overlay',o,'-o',w/'release'")
s=s[:s.index('run(12,')]+"""run(12 if steps==256 else 14,'whole',['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','doc/examples/cav2024/examp2.ivy','examples/liveness/alternating_bit_protocol.ivy'],7,['base','release'])"""
exec(s)
