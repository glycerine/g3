from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();k=p/'util/params/util_param_descrs.go';s=k.read_text()
a=s.index('info := paramDescrInfo{',s.index('func (d *ParamDescrs) insert('));s=s[:a]+'''return d.insertNew(k,kind,descr,def,module)
}

func (d *ParamDescrs) insertInterned(k usymbol.Symbol, kind ParamKind, descr, def, module *string) error {
 if udiag.DebugBuild { return d.insert(k,kind,descr,def,module) }
 if _,found:=d.entries.Get2(k);found {return nil}
 return d.insertNew(k,kind,descr,def,module)
}
func (d *ParamDescrs) insertNew(k usymbol.Symbol, kind ParamKind, descr, def, module *string) error {
 '''+s[a:]
a=s.index('if !udiag.DebugBuild {',s.index('func (d *ParamDescrs) InsertName'));b=s.index('\n}',a);s=s[:a]+'return d.insertInterned(k,kind,descr,def,module)'+s[b:]
ov={}
for k,s in [(k,s),(p/'util/params/util_param_descrs_group.go',(p/'util/params/util_param_descrs_group.go').read_text().replace('d.insert(k,','d.insertInterned(k,'))]:
 d=w/(k.name+'.txt');d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));ov[str(k)]=str(d)
(w/'trial.json').write_text(json.dumps({'Replace':ov}))
s=(w.parent/'hash/bench.py').read_text()
exec(s)
