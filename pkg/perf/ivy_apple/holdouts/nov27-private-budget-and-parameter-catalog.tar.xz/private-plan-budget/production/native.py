from pathlib import Path
s=(Path(__file__).parent/'screen.py').read_text().split("abc=w/")[0];exec(s)
modes['base']=Path('/tmp/g3-live-frame-cost/recheck/baseline')
run(12,'head-native',['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy','doc/examples/cav2024/examp1.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','examples/liveness/alternating_bit_protocol.ivy'],5,['base','release','native'])
