from pathlib import Path
import csv,collections
w=Path(__file__).resolve().parent
d=collections.defaultdict(dict)
for f in (w/'panel').glob('panel[0-7].csv'):
 for r in csv.DictReader(f.open()):d[r['case']][r['mode']]=r
for m in ['256','512']:
 vals=[(100*(int(x[m]['instructions'])/int(x['base']['instructions'])-1),k) for k,x in d.items() if m in x and 'base' in x and x[m]['status']==x['base']['status']=='match']
 print(m,len(vals),sorted(vals,reverse=True)[:6],sorted(vals)[:4]);print('different',[(k,x[m]['status']) for k,x in d.items() if m in x and x[m]['status']!='match'])
