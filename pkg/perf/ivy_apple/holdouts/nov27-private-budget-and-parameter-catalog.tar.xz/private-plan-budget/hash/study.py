from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();ov={}
def save(key,fn):
 f=p/key;d=w/(f.name+'.txt');d.write_text(fn(f.read_text()));ov[str(f)]=str(d)
key='util/params/util_param_descrs.go';f=p/key
def change(s):
 a=s.index('words := k.SymbolWords()');b=s.index('\n\t}, int(c.InitialCapacity)',a)
 return s[:a]+'return insdict.Mix64(uint64(k.Tag)<<32 | uint64(k.Value))'+s[b:]
save(key,change)
o=w/'trial.json';o.write_text(json.dumps({'Replace':ov}))
s=Path('/tmp/g3-or-install/final/release.py').read_text().replace('w=Path(__file__).resolve().parent;','').replace('/tmp/g3-card-install/volume-release','/tmp/g3-live-frame-cost/recheck/baseline').replace("'-o',w/'release'","'-overlay',o,'-o',w/'release'")
s=s[:s.index('run(12,')]+"""run(12,'whole',['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy','doc/examples/cav2024/examp1.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','examples/liveness/alternating_bit_protocol.ivy'],7,['base','release'])"""
exec(s)
