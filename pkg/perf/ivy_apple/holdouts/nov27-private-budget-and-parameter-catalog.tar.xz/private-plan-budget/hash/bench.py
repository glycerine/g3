from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for m,extra in [('base',[]),('hash',['-overlay',w/'trial.json'])]:
 subprocess.run(['go','test',*extra,'-c','-o',w/(m+'.test'),'./util/params'],check=True)
for i in range(9):
 for m in ['base','hash'][::1 if i%2==0 else -1]:
  with (w/(m+'.txt')).open('w' if not i else 'a') as f:
   for name,n in [('ParamDescriptionLookup',500000),('FirstGlobalParameterLookup',60)]:
    subprocess.run(['taskset','-c','20',w/(m+'.test'),'-test.run','^$','-test.bench','^Benchmark'+name+'$','-test.benchtime='+str(n)+'x','-test.cpu','1'],stdout=f,check=True)
