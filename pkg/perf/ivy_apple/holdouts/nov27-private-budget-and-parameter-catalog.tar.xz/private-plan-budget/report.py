from pathlib import Path
import csv,collections
from statistics import median
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'plans.csv').open()));d=collections.defaultdict(list);seq=collections.defaultdict(list)
for r in rows:
 q=tuple(r[k] for k in ['plan','allowance','answer','begin','end','limit','attempt','reason','proved']);i=int(r['round']);key=r['input'];seq[key,i].append(q)
 assert int(r['end'])<=int(r['limit'])
 d[key,i,r['answer']].append(int(r['instructions']))
for key in sorted({r['input'] for r in rows}):
 assert seq[key,0]==seq[key,1]==seq[key,2];print(Path(key).stem,[(val,len(d[key,0,val]),round(median(sum(d[key,i,val]) for i in range(3))/1e6,2)) for val in ('1','0','-1')])
for f in [*w.glob('*/whole.csv'),*w.glob('*/long.csv')]:
 rows=list(csv.DictReader(f.open()))
 for c in dict.fromkeys(x['case'] for x in rows):
  d={(r['mode'],r['round']):r for r in rows if r['case']==c}
  for m in sorted({k[0] for k in d}-{'base'}):
   pairs=[(r,d['base',i]) for (v,i),r in d.items() if v==m and ('base',i) in d]
   if not pairs:continue
   assert all(x['status']==y['status']=='match' for x,y in pairs)
   print(f.parent.name,Path(c).stem,m,len(pairs),*[round(median(100*(float(x[k])/float(y[k])-1) for x,y in pairs),2) for k in ['instructions','ms']])
