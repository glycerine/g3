from pathlib import Path
import csv,collections,re
from statistics import median
w=Path(__file__).resolve().parent
for f in [w/'production/head-native.csv',*w.glob('production/*/long.csv'),w/'panel/confirm.csv']:
 rows=list(csv.DictReader(f.open()))
 for spec in dict.fromkeys(r['case'] for r in rows):
  d={(r['mode'],r['round']):r for r in rows if r['case']==spec}
  for mode in sorted({k[0] for k in d}-{'base'}):
   pairs=[(r,d['base',i]) for (m,i),r in d.items() if m==mode and ('base',i) in d]
   if not pairs:continue
   assert all(a['status']==b['status']=='match' for a,b in pairs)
   print(f.parent.name,Path(spec).stem,mode,len(pairs),*[round(median(100*(float(a[k])/float(b[k])-1) for a,b in pairs),2) for k in ('instructions','ms')],round(median(float(a['ms']) for a,b in pairs),1))
for d in ['hash','insert']:
 for m in ['base','hash']:
  rows=re.findall(r'(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op',(w/d/(m+'.txt')).read_text())
  print(d,m,[(k,median(float(n) for key,n in rows if key==k)) for k in dict.fromkeys(x[0] for x in rows)])
rows=[r for f in (w/'production').glob('verify*.csv') for r in csv.DictReader(f.open())]
assert len(rows)==len({r['case'] for r in rows})==228 and all(r['status']=='match' for r in rows)
