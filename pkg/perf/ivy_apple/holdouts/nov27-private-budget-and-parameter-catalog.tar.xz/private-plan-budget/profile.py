from pathlib import Path
import json,csv,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd();old=Path('/tmp/g3-live-frame-cost/private');ov=json.loads((old/'obs.json').read_text())['Replace']
def change(key,name,fn):
 f=p/key;source=Path(ov.get(str(f),f));d=w/name;d.write_text(fn(source.read_text()));ov[str(f)]=str(d)
change('api/internal/order/early_cost_trial.go','meter.go.txt',lambda s:s+'\nfunc StudyCost(i int)(int64,bool){return priceCosts[i],priceActive}\n')
def plans(s):
 key='end:=order.PriceSection(34);answer, err := aux.child.Check();end()';assert key in s
 return s.replace('import (','import ("fmt";"os";',1).replace(key,'''before,active:=order.StudyCost(34);steps:=limit.Steps;
 '''+key+'''
 if active {
 after,_:=order.StudyCost(34);reason:="";if answer==lbool.Undef && err==nil {reason,_=aux.child.ReasonUnknown()}
 fmt.Fprintf(os.Stderr,"PLANDETAIL %T %d %d %d %d %d %d %d %q\\n",plan,maxSteps,answer,steps,limit.Steps,limit.Limit,after-before,studyID,reason)
 }
 ''')
change('api/api_goal_instances_check.go','plan.go.txt',plans)
change('api/api_order_abstraction.go','batch.go.txt',lambda s:s.replace('order.PriceBegin();','studyID++;order.PriceBegin();')+'\nvar studyID int\n')
o=w/'profile.json';o.write_text(json.dumps({'Replace':ov}))
front=p/'build/.boolean-enode-cost/frontend/goivy'
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-mod=readonly','-buildvcs=false','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-tags','xtrace_off','-overlay',o,'-o',w/'g3','./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
import shlex
with (w/'plans.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['input','round','plan','allowance','answer','begin','end','limit','instructions','attempt','reason','proved'])
 for spec in ['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy']:
  ref=rank/'compat'/str(cases.index(spec)+1)/'1/native'
  for i in range(3):
   r=subprocess.run(['taskset','-c','18',w/'g3',ex/spec],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
   keep=[];pending=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'PLANDETAIL '):pending.append(shlex.split(l.decode())[1:])
    elif l.startswith(b'EARLY-COST '):
     for row in pending:out.writerow([spec,i,*row,l.split()[1].decode()])
     pending=[]
    else:keep.append(l)
   assert not pending and (r.returncode,r.stdout,b''.join(keep))==(codes[spec],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
   f.flush()
