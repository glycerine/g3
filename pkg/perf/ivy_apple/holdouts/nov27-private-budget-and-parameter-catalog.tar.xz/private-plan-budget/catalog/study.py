from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();ov={}
def save(key,fn):
 f=p/key;d=w/(f.name+'.txt');d.write_text(fn(f.read_text()));ov[str(f)]=str(d)
# Counterfactual: isolated private command contexts only. Skip catalog lookup for
# absent private auto_config. This is an upper-bound experiment with changed
# resource-failure behavior; the release uses the full public lookup.
save('util/params/util_gparams.go',lambda s:s.replace('type GlobalParams struct {','type GlobalParams struct {\n StudyPrivate bool'))
save('util/params/util_gparams_service_ops.go',lambda s:s.replace('func (s *GlobalParamsService) SourceGetValueName','func (s *GlobalParamsService) StudyPrivateDefault() error {g,e:=s.namespaceImpAt(574);if e==nil{g.StudyPrivate=true};return e}\nfunc (s *GlobalParamsService) SourceGetValueName',1))
save('util/params/util_gparams_values.go',lambda s:s.replace('return g.getDefault(g.GlobalDescriptors, k, module)','return g.getDefault(g.GlobalDescriptors, k, module)').replace('if e = g.ensureRegistered(); e != nil {\n\t\t\treturn "", e','if g.StudyPrivate && !g.modulesRegistered && g.catalog!=nil {name,err:=g.SymbolsField.String(k);if err==nil && name=="auto_config" {return "true",nil}}\n\t\tif e = g.ensureRegistered(); e != nil {\n\t\t\treturn "", e',1))
save('api/api_order_abstraction.go',lambda s:s.replace('command.UseAPISolverInitialization()','g,e:=command.GlobalParameters();if e!=nil{return e};if e=g.StudyPrivateDefault();e!=nil{return e};command.UseAPISolverInitialization()',1))
o=w/'trial.json';o.write_text(json.dumps({'Replace':ov}))
s=Path('/tmp/g3-or-install/final/release.py').read_text().replace('w=Path(__file__).resolve().parent;','').replace('/tmp/g3-card-install/volume-release','/tmp/g3-live-frame-cost/recheck/baseline').replace("'-o',w/'release'","'-overlay',o,'-o',w/'release'")
s=s[:s.index('run(12,')]+"""run(12,'whole',['examples/liveness/hybrid_reliable_broadcast_cisa.ivy','test/flash2.ivy','doc/examples/cav2024/examp5.ivy','doc/examples/cav2024/examp1.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','examples/liveness/alternating_bit_protocol.ivy'],7,['base','release'])"""
exec(s)
