import csv
from pathlib import Path
from statistics import median
for f in Path(__file__).resolve().parent.glob('*.csv'):
 rows=list(csv.DictReader(f.open()))
 if not rows:continue
 for success in ['true','false']:
  cols=['factory',*list(rows[0])[-10:]]
  vals=[median(sum(int(r[k]) for r in rows if r['proved']==success and r['round']==str(i)) for i in range(3)) for k in cols]
  print(f.stem,success,[(k,round(v/1e6,2)) for k,v in zip(cols,vals)])
