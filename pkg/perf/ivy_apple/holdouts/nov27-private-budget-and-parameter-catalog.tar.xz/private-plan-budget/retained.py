from pathlib import Path
import subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent
f=w/'production';f.mkdir(exist_ok=True)
s=(w/'long.py').read_text().replace("w=Path(__file__).resolve().parent;","").replace("g3-nov27-private-budget'","g3-nov27-private-catalog'")
s=s.replace("['base','256','512']","['base','production','catalog']").replace("args=[] if mode=='base' else","args=[] if mode in ['base','production'] else")
s=s.replace("subprocess.run([*flags,*args,",'''if mode=='base':
  # Use the original hash in the Apple baseline after the production edit.
  args=['-overlay',w/'original.json']
 if mode=='catalog':
  import json
  ov=json.loads((w/'catalog/trial.json').read_text())['Replace'];ov.update(json.loads((w/'original.json').read_text())['Replace'])
  o=w/'catalog/apple.json';o.write_text(json.dumps({'Replace':ov}));args=['-overlay',o]
 subprocess.run([*flags,*args,''').replace("d=w/name;","d=w/'production'/name;")
import json
key=p/'util/params/util_param_descrs.go';original=w/'original.go.txt';original.write_bytes(subprocess.check_output(['git','show','4b0d068c2:pkg/util/params/util_param_descrs.go']))
(w/'original.json').write_text(json.dumps({'Replace':{str(key):str(original)}}))
build=Path('/tmp/g3-or-install/final/release.py').read_text().split('modes=')[0].replace('w=Path(__file__).resolve().parent;','').replace("w/'release'","w/'production/release'")
exec(build)
exec(s)
