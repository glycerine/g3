"""Count exact short-arity application inputs within each compiled ground plan."""
import json,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/ground_instance.go'
s=src.read_text()
s=s.replace('type groundInstancePlan struct {','''type observeKey struct { op uint16; args [8]ast.ASTHandle }
type groundInstancePlan struct {
    prior map[observeKey]ast.ASTHandle
    last map[uint16]observeKey''')
s=s.replace('plan := c.plan(m, body)','println("GREQUEST")\n plan := c.plan(m, body)')
s=s.replace('for i, op := range p.apps {','''var covered, repeats, live, lastLive int
    if p.prior==nil { p.prior=make(map[observeKey]ast.ASTHandle);p.last=make(map[uint16]observeKey) }
    for i, op := range p.apps {''')
k='result, err := m.RewriterMakeApp'
s=s.replace(k,'''var key observeKey
        var observed ast.ASTHandle
        if len(args)<=len(key.args) {
            covered++
            key.op=op.dest
            copy(key.args[:],args)
            if old,ok:=p.prior[key];ok {
                repeats++
                if m.IsLiveHandle(old) { live++;observed=old;if p.last[op.dest]==key {lastLive++} }
            }
        }
        '''+k)
s=s.replace('if err := m.IncRefHeld(result);','''if len(args)<=len(key.args) {
            if !observed.IsNull() && observed!=result {panic("live observed handle differs")}
            p.prior[key]=result;p.last[op.dest]=key
        }
        if err := m.IncRefHeld(result);''')
s=s.replace('return m.SetRef(out, p.values[0])','println("GPLAN",len(p.apps),covered,repeats,live,lastLive)\n return m.SetRef(out, p.values[0])')
dest=w/'observer.go';dest.write_text(s)
overlay=w/'obs.json';overlay.write_text(json.dumps({'Replace':{str(src):str(dest)}}))
subprocess.run(['go','build','-mod=readonly','-pgo=off','-buildvcs=false','-overlay',overlay,'-o',w/'obs','./cmd/g3'],check=True)
