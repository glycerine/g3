from pathlib import Path
import os,csv,subprocess,sys,json
from collections import Counter
w=Path(__file__).resolve().parent;ref,ex=map(Path,sys.argv[1:]); out=csv.writer(sys.stdout);out.writerow(('case','app','family','kind','depth','previous_steps','now_steps','count'))
for case,(p,iso,rc) in json.loads((ref/'cases.json').read_text()).items():
    r=subprocess.run([w/'flip-goivy',*(['isolate='+iso] if iso else []),ex/p],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True,timeout=120)
    counts=Counter();stderr=[]
    for l in r.stderr.splitlines(keepends=True):
        if l.startswith(b'FLIP '):counts[tuple(l.decode().split()[1:])]+=1
        elif not l.startswith(b'RWFRAME '):stderr.append(l)
    g=ref/'reference'/case
    assert (r.stdout,b''.join(stderr),r.returncode)==((g/'stdout').read_bytes(),(g/'stderr').read_bytes(),rc)
    for k,n in counts.items():out.writerow((case,*k,n))
