"""Measure accounted plan-array capacities after each eligible lookup."""
from pathlib import Path
import json,csv,statistics,os,subprocess,sys
w=Path(__file__).resolve().parent;gold,examples=map(Path,sys.argv[1:]);out=csv.writer(sys.stdout)
out.writerow(('case','threshold','requests','median_bytes','mean_bytes','max_bytes'))
for case,(path,isol,rc) in json.loads((gold/'cases.json').read_text()).items():
    for n in (4,2):
        r=subprocess.run([w/('space'+str(n)+'-goivy'),*(['isolate='+isol] if isol else []),examples/path],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'))
        vals=[];stderr=[]
        for line in r.stderr.splitlines(keepends=True):
            if line.startswith(b'PLANSPACE '):vals.append(int(line.split()[1]))
            else:stderr.append(line)
        ref=gold/'reference'/case
        assert (r.stdout,b''.join(stderr),r.returncode)==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes(),rc)
        out.writerow((case,n,len(vals),statistics.median(vals),round(statistics.mean(vals)),max(vals)))
