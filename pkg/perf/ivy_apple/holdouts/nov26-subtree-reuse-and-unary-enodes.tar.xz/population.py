"""Census all enodes successfully registered through the internalizer."""
from pathlib import Path
import json
w=Path(__file__).resolve().parent;src=Path.cwd()/'smtcore/smt_internalizer_state.go'
s=src.read_text();k='s.statistics.NumMkEnode++'
assert s.count(k)==1
s=s.replace(k,k+'\n println("NEWNODE",count, int32(node.family),node.boolean,suppressArguments,term!=nil,congruenceEnabled)')
dst=w/'population.go';dst.write_text(s);(w/'population.json').write_text(json.dumps({'Replace':{str(src):str(dst)}}))
