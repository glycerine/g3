"""Validate instrumented CLI and verifier transcripts and aggregate per-query events."""
import sys,csv,json,re,os,subprocess
from collections import Counter
from pathlib import Path
w=Path(__file__).resolve().parent
mode=sys.argv[1];fixtures,gold,examples=map(Path,sys.argv[2:])
out=csv.writer(sys.stdout)
if mode=='frames':out.writerow(('case','rewrites','steps','under_root','under_child','predicted_finishes','changed_result','changed_steps'))
else:out.writerow(('case','status','calls','applications'))
def events(case,stderr):
    keep=[];counts=Counter();apps=Counter();tot=[0]*6;n=0
    for line in stderr.splitlines(keepends=True):
        if mode=='frames' and line.startswith(b'RWFRAME '):
            vals=list(map(int,line.split()[1:]));assert len(vals)==6
            tot=[x+y for x,y in zip(vals,tot)];n+=1
        elif mode=='why' and line.startswith(b'FALL '):
            _,tag,value=line.split(); tag=tag.decode();v=int(value)
            label=tag+str(v) if tag=='no-plan' else tag
            counts[label]+=1
            if tag!='no-plan':apps[label]+=v
        else:keep.append(line)
    if mode=='frames':out.writerow([case,n,*tot])
    else:
        for k in sorted(counts):out.writerow((case,k,counts[k],apps[k]))
    return b''.join(keep)
for name,expected in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
    r=subprocess.run([w/mode,'-in','-smt2'],input=(fixtures/(name+'.smt2')).read_bytes(),capture_output=True,check=True)
    stats=dict(re.findall(rb':([\w-]+)\s+(\d+)\b',r.stdout))
    assert not events(name,r.stderr) and r.stdout.startswith(b'unsat\n') and tuple(int(stats[k]) for k in (b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count'))==expected
for name,(path,isolate,code) in json.loads((gold/'cases.json').read_text()).items():
    r=subprocess.run([w/(mode+'-goivy'),*(['isolate='+isolate] if isolate else []),examples/path],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'))
    ref=gold/'reference'/name
    assert (events(name,r.stderr),r.stdout,r.returncode)==((ref/'stderr').read_bytes(),(ref/'stdout').read_bytes(),code)
