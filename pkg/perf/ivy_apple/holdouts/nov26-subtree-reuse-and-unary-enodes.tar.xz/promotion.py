from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/ground_instance.go'
mode=sys.argv[1]; s=src.read_text()
if mode=='why':
    a=s.index('plan := c.plan(m, body)')
    b=s.index('if err := s.Reset()',a)
    s=s[:a]+s[a:b].replace('if plan == nil || !plan.bind(m, bindings) {','''if plan==nil {println("FALL", "no-plan", int(c.bodies[body].uses));return s.Substitute(body,bindings,out)}
        if !plan.bind(m, bindings) {
            println("FALL","binding",len(plan.apps))''').replace('return s.Substitute(body, bindings, out)\n\t}\n\t','return s.Substitute(body, bindings, out)\n\t}\n\t',1).replace('if err != nil || !previous.IsNull() {','if err != nil || !previous.IsNull() {\n println("FALL", "previous", len(plan.apps))')+s[b:]
    s=s.replace('return c.apply(r, plan, out)','println("FALL", "apply",len(plan.apps))\n return c.apply(r, plan, out)')
else:
    assert mode in ('1','2')
    s=s.replace('entry.uses == 4','entry.uses == '+mode)
dst=w/(mode+'.go');dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',ov,'-o',w/mode,'./cmd/g3'],check=True)
