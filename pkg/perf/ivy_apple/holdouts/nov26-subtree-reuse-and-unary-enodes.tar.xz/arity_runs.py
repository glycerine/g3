"""Validate full runs and count ordinary terms by number of already eligible operands."""
import os,csv,json,sys,subprocess
from pathlib import Path
from collections import Counter
w=Path(__file__).resolve().parent;gold,ex=map(Path,sys.argv[1:]);out=csv.writer(sys.stdout)
out.writerow(('case','arity','visited','all_ready'))
for case,(p,iso,rc) in json.loads((gold/'cases.json').read_text()).items():
    r=subprocess.run([w/'arity-goivy',*(['isolate='+iso] if iso else []),ex/p],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True,timeout=120)
    all_=Counter();ready=Counter();stderr=[]
    for l in r.stderr.splitlines(keepends=True):
        if l.startswith(b'NODEWIDTH '):
            _,width,eligible=l.split();width=int(width);all_[width]+=1
            if eligible==b'true':ready[width]+=1
        else:stderr.append(l)
    g=gold/'reference'/case
    assert (r.stdout,b''.join(stderr),r.returncode)==((g/'stdout').read_bytes(),(g/'stderr').read_bytes(),rc)
    for n in sorted(all_):out.writerow((case,n,all_[n],ready[n]))
