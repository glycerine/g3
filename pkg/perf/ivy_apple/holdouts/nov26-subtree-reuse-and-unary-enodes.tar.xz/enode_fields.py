from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;src=Path.cwd()/'smtcore/smt_enode_core.go'
s=(w/src.name).read_text()
a=s.index('*n = SMTEnode{');b=s.index('n.root, n.next = n, n',a)
s=s[:a]+'''n.manager, n.owner, n.declaration = m,owner,header.Decl
    n.classSize, n.generation, n.functionDeclID = 1, options.Generation, math.MaxUint32
    n.internalScopeLevel, n.suppressArguments = options.InternalScopeLevel, options.SuppressArguments
    n.family,n.declKind=header.Family,header.DeclKind
    n.equality=header.Family==m.BasicFamilyID() && header.DeclKind==ast.ASTOpEq
    n.boolean,n.mergeTruthValue=boolean,options.MergeTruthValue
    n.congruenceEnabled,n.labelHash=options.CongruenceEnabled,-1
    n.theoryVariables.theory, n.theoryVariables.variable = SMTNullTheoryID,SMTNullTheoryVar
    '''+s[b:]
dst=w/'fields.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'fields.json';mapping=json.loads((w/'enode.json').read_text());mapping['Replace'][str(src)]=str(dst);ov.write_text(json.dumps(mapping))
subprocess.run(['go','test','-pgo=off','-mod=readonly','-overlay',ov,'-c','-o',w/'fields.test','./smtcore'],check=True)
