"""Extend ordinary operand reuse to unary applications and retain exact slice width."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
mapping=json.loads((w/'candidate.json').read_text())['Replace']
for src,path in list(mapping.items()):
    src=Path(src);s=Path(path).read_text()
    if src.name=='smt_enode_core.go':
        s=s.replace('header.NumArgs == 2','header.NumArgs != 0').replace('record.children[:]','record.children[:header.NumArgs:header.NumArgs]')
    else:
        a=s.index('func (s *SMTInternalizerState) existingTermChildren(')
        b=s.index('func (',a+1)
        t=s[a:b].replace('if count != 2','if count > 2').replace('for i := range pair','for i := uint32(0); i<count; i++').replace('s.manager.GetArg(expression, uint32(i))','s.manager.GetArg(expression, i)')
        s=s[:a]+t+s[b:]
    dest=w/('unary-'+src.name);dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));mapping[str(src)]=str(dest)
ov=w/'unary.json';ov.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',ov,'-o',w/'unary','./cmd/g3'],check=True)
