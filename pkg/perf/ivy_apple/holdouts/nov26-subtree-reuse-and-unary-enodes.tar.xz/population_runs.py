"""Validate full runs and count ordinary terms by number of already eligible operands."""
import os,csv,json,sys,subprocess
from pathlib import Path
from collections import Counter
w=Path(__file__).resolve().parent;gold,ex=map(Path,sys.argv[1:]);out=csv.writer(sys.stdout)
out.writerow(('case','args','family','boolean','suppressed','known_inputs','congruence','count'))
for case,(p,iso,rc) in json.loads((gold/'cases.json').read_text()).items():
    r=subprocess.run([w/'population-goivy',*(['isolate='+iso] if iso else []),ex/p],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True,timeout=120)
    all_=Counter();ready=Counter();stderr=[]
    for l in r.stderr.splitlines(keepends=True):
        if l.startswith(b'NEWNODE '):all_[tuple(l.decode().split()[1:])]+=1
        else:stderr.append(l)
    g=gold/'reference'/case
    assert (r.stdout,b''.join(stderr),r.returncode)==((g/'stdout').read_bytes(),(g/'stderr').read_bytes(),rc)
    for k,n in sorted(all_.items()):out.writerow((case,*k,n))
