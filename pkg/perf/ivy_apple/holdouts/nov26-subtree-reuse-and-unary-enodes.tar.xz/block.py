"""Allocate binary records from fresh solver-local blocks; never recycle published addresses."""
from pathlib import Path
import subprocess,json,sys
w=Path(__file__).resolve().parent;mode=sys.argv[1];n=int(mode.removeprefix('block'));assert 2<=n<=128
mapping=json.loads((w/'fields.json').read_text())['Replace']
src=Path.cwd()/'smtcore/smt_enode_core.go'
s=(w/'fields.go').read_text().replace('type smtTermInputs struct {','type smtBinaryEnode struct {node SMTEnode; children [2]*SMTEnode}\ntype smtTermInputs struct {\n slot *smtBinaryEnode')
a=s.index('storage := new(struct {');b=s.index('storage.children =',a)
s=s[:a]+'storage:=term.slot\n'+s[b:]
dst=w/(mode+'-core.go');dst.write_text(s);mapping[str(src)]=str(dst)
src=src.with_name('smt_internalizer_state.go')
s=src.read_text().replace('type SMTInternalizerState struct {','type SMTInternalizerState struct {\n freshEnodes []smtBinaryEnode')
k='node, err := newSMTEnode(s.manager, expression'
s=s.replace(k,'''if term!=nil && term.header.NumArgs==2 {
        if len(s.freshEnodes)==0 {s.freshEnodes=make([]smtBinaryEnode, N)}
        term.slot=&s.freshEnodes[0]
        s.freshEnodes=s.freshEnodes[1:]
        if len(s.freshEnodes)==0 {s.freshEnodes=nil}
    }
    '''.replace('N)',str(n)+')')+k)
dst=w/(mode+'-state.go');dst.write_text(s);mapping[str(src)]=str(dst)
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','test','-pgo=off','-mod=readonly','-overlay',ov,'-c','-o',w/(mode+'.test'),'./smtcore'],check=True)
