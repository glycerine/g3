"""Group scoped fixture samples by phase and by GC/allocator or primary operation."""
import csv,sys,subprocess,re
from pathlib import Path
from collections import Counter
w=Path(__file__).resolve().parent;perf=sys.argv[1]
d=Counter();data=w/'enodes.data'
dump=subprocess.check_output([perf,'report','-D','-i',data],text=True)
assert not any(k in dump for k in ('PERF_RECORD_LOST','PERF_RECORD_THROTTLE'))
for b in subprocess.check_output([perf,'script','-i',data],text=True).split('\n\n'):
    frames=re.findall(r'^\s+[\da-fA-F]+ (.*?)\+0x',b,re.M)
    if not frames:continue
    phase=next((name for name,s in [('pop','.PopScopes'),('insert','.Internalize'),('push','.PushScope')] if s in b),'other')
    stage=next((name for name,terms in [('write barrier',('wbBufFlush','gcWriteBarrier')),('allocator',('runtime.mallocgc','runtime.newobject')),('GC',('runtime.gc','runtime.scanobject')),('parent removal',('.detachParentsForDeletion',)),('congruence',('SMTCongruenceTable)',)),('construct',('smtcore.newSMTEnode',)),('register',('.registerEnode',))] if any(t in b for t in terms)),'other')
    d[phase,stage,frames[0].split('/pkg/')[-1]]+=1
out=csv.writer(sys.stdout);out.writerow(('phase','stage','leaf','samples'))
for k,n in d.items():out.writerow((*k,n))
