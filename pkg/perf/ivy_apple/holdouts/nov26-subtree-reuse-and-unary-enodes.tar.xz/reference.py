"""Collect references with the pinned release frontend and compare proof verdicts to old captures."""
from pathlib import Path
import json,subprocess,sys,os,re
w=Path(__file__).resolve().parent;src,examples,binary,native=map(Path,sys.argv[1:])
out=w/'current';out.mkdir(exist_ok=True)
cases=json.loads((src/'cases.json').read_text())
(out/'cases.json').write_text(json.dumps(cases))
for case in ('test_liveness2','tlb'):
    path,isol,exitcode=cases[case]
    env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1')
    r=subprocess.run([binary.resolve(),*(['isolate='+isol] if isol else []),examples/path],env=env,cwd=w,capture_output=True,timeout=120)
    old=src/'reference'/case; target=out/'reference'/case;target.mkdir(parents=True,exist_ok=True)
    def verdicts(s):return re.findall(rb'(?m)^(?:PASS|FAIL|UNKNOWN)\b[^\n]*',s)
    oracle=subprocess.run([native.resolve(),*(['isolate='+isol] if isol else []),examples/path],env=env,cwd=w,capture_output=True,timeout=120)
    verdict=verdicts(r.stdout)
    assert verdict and verdict==verdicts(oracle.stdout) and r.returncode==oracle.returncode==exitcode, (case,len(verdict),len(verdicts(oracle.stdout)),r.returncode,oracle.returncode)
    print(case,"same_frontend_native",r.stdout==oracle.stdout,r.stderr==oracle.stderr,"old_verdicts_match",verdict==verdicts((old/'stdout').read_bytes()))
    (target/'stdout').write_bytes(r.stdout);(target/'stderr').write_bytes(r.stderr)
    print(case,len(verdict),r.returncode,flush=True)
