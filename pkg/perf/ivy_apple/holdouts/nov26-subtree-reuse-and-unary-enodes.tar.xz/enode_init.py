from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent
src=Path.cwd()/'smtcore/smt_enode_core.go'
s=(w/src.name).read_text()
a=s.index('var n *SMTEnode');b=s.index('*n = SMTEnode{',a);c=s.index('n.root, n.next = n, n',b)
s=s[:a]+s[b:c].replace('*n = SMTEnode{','initial := SMTEnode{')+'''var n *SMTEnode
    if term!=nil && header.NumArgs==2 {
        storage:=&struct {node SMTEnode; children [2]*SMTEnode}{node:initial, children:term.children}
        n=&storage.node
        n.arguments=storage.children[:]
    } else {
        n=&initial
    }
    '''+s[c:]
s=s.replace('if term != nil {\n\t\t\tn.arguments = pair\n\t\t} else {','if term == nil {')
dst=w/'init.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'init.json';mapping=json.loads((w/'enode.json').read_text());mapping['Replace'][str(src)]=str(dst);ov.write_text(json.dumps(mapping))
subprocess.run(['go','test','-pgo=off','-mod=readonly','-overlay',ov,'-c','-o',w/'init.test','./smtcore'],check=True)
