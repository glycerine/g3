"""Profile application work inside proofless instance rewriting on complete verifiers."""
import csv,sys,os,re,subprocess,json
from pathlib import Path
from collections import Counter
w=Path(__file__).resolve().parent
perf=sys.argv[1];gold,ex,release=map(lambda v:Path(v).resolve(),sys.argv[2:5]); ex=Path(sys.argv[3]); cases=json.loads((gold/'cases.json').read_text())
out=csv.writer(sys.stdout);out.writerow(('case','round','engine','component','samples'))
for case in ('ticket_protocol','hybrid'):
    path,isol,rc=cases[case]
    ref=gold/'reference'/case
    for turn in range(8):
        for label,exe in ([('obs',w/'frames-goivy'),('base',release)] if turn%2==0 else [('base',release),('obs',w/'frames-goivy')]):
            data=w/'frames.data'
            cmd=['taskset','-c','14',perf,'record','-B','-N','-e','instructions:u','-c','1000003','--call-graph','fp,64','-o',data,'--',exe,*(['isolate='+isol] if isol else []),ex/path]
            r=subprocess.run(cmd,cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1'))
            # perf writes a two-line recording summary on stderr. Require all remaining lines to match.
            stderr=b''.join(l for l in r.stderr.splitlines(keepends=True) if not l.startswith((b'[ perf record:',b'RWFRAME ')))
            if r.stdout!=(ref/"stdout").read_bytes(): (w/"mismatch.out").write_bytes(r.stdout)
            assert (r.returncode,r.stdout,stderr)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(case,label,r.returncode,len(r.stdout),len((ref/"stdout").read_bytes()),stderr[:1000])
            dump=subprocess.check_output([perf,'report','-D','-i',data],text=True)
            assert not any(k in dump for k in ('PERF_RECORD_LOST','PERF_RECORD_THROTTLE'))
            d=Counter()
            for b in subprocess.check_output([perf,'script','-i',data],text=True).split('\n\n'):
                if not b.strip():continue
                if '(*SMTQIInstanceBuilder).materialize' not in b or '(*rewriterEngine).processApp' not in b:continue
                # Use only the actual theory rewrite, excluding later lemma creation.
                if '(*TheoryRewriter).Rewrite' not in b:continue
                if any(n in b for n in ('.auditFinish','.auditStep')):continue
                bucket=next((s for n,s in [('auditChildApp','child'),('auditRootApp','root'),('auditNewApp','other')] if n in b),'unmarked')
                d[bucket]+=1
            for k,n in d.items():out.writerow((case,turn+1,label,k,n))
            sys.stdout.flush()
