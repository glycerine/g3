from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent
src=Path.cwd()/'smtcore/smt_enode_core.go'
s=(w/'fields.go').read_text()
a=s.index('var n *SMTEnode');b=s.index('n.manager, n.owner',a)
s=s[:a]+'''var n *SMTEnode
    if term != nil && !options.SuppressArguments && header.NumArgs == 2 {
        record := new(struct {
            node SMTEnode
            children [2]*SMTEnode
        })
        record.children = term.children
        n = &record.node
        n.arguments = record.children[:]
    } else {
        n = new(SMTEnode)
    }
    '''+s[b:]
s=s.replace('if term != nil {\n\t\t\tn.arguments = pair\n\t\t} else {','if term == nil {')
s=s.replace('n.theoryVariables.theory, n.theoryVariables.variable = SMTNullTheoryID, SMTNullTheoryVar','n.theoryVariables = *NewDefaultSMTTheoryVarList()')
dst=w/'release.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
mapping=json.loads((w/'fields.json').read_text());mapping['Replace'][str(src)]=str(dst)
ov=w/'candidate.json';ov.write_text(json.dumps(mapping))
for cmd in [['go','test','-c','-o',w/'candidate.test','./smtcore'],['go','build','-buildvcs=false','-o',w/'candidate','./cmd/g3']]:
    cmd[2:2]=['-pgo=off','-mod=readonly','-overlay',ov]
    subprocess.run(cmd,check=True)
