"""Read-only counter of immediately reusable children before ordinary term recursion."""
from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;src=Path.cwd()/'smtcore/smt_internalizer.go';s=src.read_text()
k='children, ok, err := s.existingTermChildren(expression, count)'
assert s.count(k)==1
s=s.replace(k,'''eligible:=true
        for i:=uint32(0);i<count;i++ {
            h,e:=s.manager.GetArg(expression,i);if e!=nil{panic(e)}
            child:=s.context.enodes.get(h)
            if child==nil || child.root==nil || child.boolean || s.theories[child.family]!=nil {eligible=false;break}
        }
        println("NODEWIDTH",count,eligible)
        '''+k)
dst=w/'arity.go';dst.write_text(s);(w/'arity.json').write_text(json.dumps({'Replace':{str(src):str(dst)}}))
