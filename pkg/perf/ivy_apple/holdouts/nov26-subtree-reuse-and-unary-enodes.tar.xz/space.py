from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;src=Path.cwd()/'ast/rewriter/ground_instance.go';mode=sys.argv[1];n=int(mode[-1])
s=src.read_text().replace('entry.uses == 4','entry.uses == '+str(n))
k='plan := c.plan(m, body)';s=s.replace(k,k+'\n println("PLANSPACE", c.size)')
dst=w/(mode+'.go');dst.write_text(s);ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
