"""Only reuse the live unary operand. Preserve separate allocations and binary layout."""
import json,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent;src=Path.cwd()/'smtcore/smt_internalizer.go';s=src.read_text()
a=s.index('func (s *SMTInternalizerState) existingTermChildren(');b=s.index('func (',a+1)
t=s[a:b].replace('if count != 2','if count > 2').replace('for i := range pair','for i := uint32(0); i<count; i++').replace('s.manager.GetArg(expression, uint32(i))','s.manager.GetArg(expression, i)').replace('return []*SMTEnode{pair[0], pair[1]},','if count==1 {return []*SMTEnode{pair[0]},true,nil}\n return []*SMTEnode{pair[0], pair[1]},')
dst=w/'reuse.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=(s[:a]+t+s[b:]).encode()))
ov=w/'reuse.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
for cmd in [['go','test','-c','-o',w/'reuse.test','./smtcore'],['go','build','-o',w/'reuse','./cmd/g3']]:
    cmd[2:2]=['-pgo=off','-mod=readonly','-buildvcs=false','-overlay',ov]
    subprocess.run(cmd,check=True)
