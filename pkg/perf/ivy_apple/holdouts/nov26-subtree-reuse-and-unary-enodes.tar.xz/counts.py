"""Aggregate completed plans and verify remaining output exactly."""
import sys,os,csv,json,re,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
fixtures,gold,examples=map(Path,sys.argv[1:])
out=csv.writer(sys.stdout);out.writerow(('case','eligible_requests','applied','applications','covered','repeat','live','consecutive_live'))
def collect(name,r):
    total=[0]*5; requests=plans=0;err=[]
    for line in r.stderr.splitlines(keepends=True):
        if line==b'GREQUEST\n':requests+=1
        elif line.startswith(b'GPLAN '):
            n=list(map(int,line.split()[1:]));assert len(n)==5
            total=[x+y for x,y in zip(n,total)];plans+=1
        else:err.append(line)
    out.writerow([name,requests,plans,*total])
    return b''.join(err)
for name,expected in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
    r=subprocess.run([w/'obs','-in','-smt2'],input=(fixtures/(name+'.smt2')).read_bytes(),capture_output=True,check=True)
    assert not collect(name,r) and r.stdout.startswith(b'unsat\n')
    stats=dict(re.findall(rb':([\w-]+)\s+(\d+)\b',r.stdout))
    assert tuple(int(stats[k]) for k in (b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count'))==expected
for name,(path,isolate,code) in json.loads((gold/'cases.json').read_text()).items():
    r=subprocess.run([w/'obs-goivy',*(['isolate='+isolate] if isolate else []),examples/path],cwd=w,capture_output=True,timeout=120,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'))
    ref=gold/'reference'/name
    assert (collect(name,r),r.stdout,r.returncode)==((ref/'stderr').read_bytes(),(ref/'stdout').read_bytes(),code)
