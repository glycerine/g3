"""Skip construction for unchanged inputs only while the previous result generation lives."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/ground_instance.go'
s=src.read_text().replace('type groundInstancePlan struct {','type groundInstancePlan struct {\n ready bool')
s=s.replace('if plan == nil || !plan.bind(m, bindings) {','''var changed [maxGroundInstanceNodes]bool
    if plan == nil {return s.Substitute(body,bindings,out)}
    ready:=plan.ready
    plan.ready=false
    if !plan.bind(m, bindings, &changed) {''')
s=s.replace('return c.apply(r, plan, out)','''err = c.apply(r, plan, out, ready, &changed)
    plan.ready=err==nil
    return err''')
s=s.replace('bind(m *ast.ASTManager, bindings []ast.ASTHandle)', 'bind(m *ast.ASTManager, bindings []ast.ASTHandle,changed *[maxGroundInstanceNodes]bool)')
s=s.replace('p.values[v.dest] = h','changed[v.dest]=p.values[v.dest]!=h\n p.values[v.dest] = h')
s=s.replace('apply(r *rewriterEngine, p *groundInstancePlan, out ast.ASTRef)', 'apply(r *rewriterEngine, p *groundInstancePlan, out ast.ASTRef,ready bool, changed *[maxGroundInstanceNodes]bool)')
a=s.index('args := c.args[:op.arity]');b=s.index('if err := m.IncRefHeld',a)
s=s[:a]+'''children:=p.edges[int(op.first):int(op.first)+int(op.arity)]
        prev:=p.values[op.dest]
        same:=ready
        if same {
            for _,child:=range children { if changed[child] {same=false;break} }
        }
        result:=prev
        if !same || !m.IsLiveHandle(prev) {
            args:=c.args[:op.arity]
            for j,child:=range children {args[j]=p.values[child]}
            var err error
            result,err=m.RewriterMakeApp(op.decl,ast.SliceArguments(args))
            if err!=nil{return err}
        }
        changed[op.dest]=prev!=result
        '''+s[b:]
dest=w/'trial.go';dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/'trial.json';overlay.write_text(json.dumps({'Replace':{str(src):str(dest)}}))
subprocess.run(['go','build','-mod=readonly','-pgo=off','-buildvcs=false','-overlay',overlay,'-o',w/'trial','./cmd/g3'],check=True)
