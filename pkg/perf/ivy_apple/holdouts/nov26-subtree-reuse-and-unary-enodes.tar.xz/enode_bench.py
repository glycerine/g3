"""Alternate the scoped fixture at three widths and record whole-process counters."""
from pathlib import Path
import csv,os,re,sys,subprocess
w=Path(__file__).resolve().parent;perf=sys.argv[1]
out=csv.writer(sys.stdout);out.writerow(('width','round','engine','instructions','cycles','ns','bytes','allocs'))
engines = [(k,v) for k,v in (arg.split('=',1) for arg in sys.argv[2:])] or [('base','enodes.test'),('trial','new.test')]
for width,iterations in [(32,4000),(256,500),(2048,100)]:
    for i in range(9):
        for name,bin in engines[i%len(engines):]+engines[:i%len(engines)]:
            f=w/'bench.stat';r=subprocess.run(['taskset','-c','16',perf,'stat','-x,','-o',f,'-e','instructions:u,cycles:u','--',w/bin,'-test.run=^$','-test.bench=^'+os.environ.get('BENCH','BenchmarkSMTEnodeScopeBatch')+'$/^'+str(width)+'$','-test.benchtime='+str(iterations)+'x'],env=dict(os.environ,GOMAXPROCS='1',GOGC='100'),capture_output=True,text=True,check=True)
            hw={v[2]:int(v[0]) for v in csv.reader(f.read_text().splitlines()) if len(v)>4 and v[2].endswith(':u') and float(v[4])==100}
            row=next(l for l in r.stdout.splitlines() if l.startswith('Benchmark'))
            ns,bytes_,allocs=[re.search(r'([\d.]+) '+unit,row)[1] for unit in ['ns/op','B/op','allocs/op']]
            out.writerow((width,i+1,name,hw['instructions:u'],hw['cycles:u'],ns,bytes_,allocs));sys.stdout.flush()
