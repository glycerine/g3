"""Price canonical construction on repeated tuples with identical map work on both sides."""
from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent
src=Path.cwd()/'ast/rewriter/ground_instance.go'
for mode in ('price','skip'):
    s=src.read_text().replace('type groundInstancePlan struct {','''type subtreeKey struct {op uint16; args [8]ast.ASTHandle}
type groundInstancePlan struct {\n prior map[subtreeKey]ast.ASTHandle''')
    a=s.index('result, err := m.RewriterMakeApp'); b=s.index('if err := m.IncRefHeld(result)',a)
    s=s[:a]+'''var result ast.ASTHandle
        var key subtreeKey
        if len(args)<=len(key.args) {
            key.op=op.dest
            copy(key.args[:],args)
            if previous,ok:=p.prior[key];ok && m.IsLiveHandle(previous) {result=previous}
        }
        if result.IsNull() || FORCE {
            built,e:=m.RewriterMakeApp(op.decl,ast.SliceArguments(args))
            if e!=nil{return e}
            if !result.IsNull() && built!=result {panic("observed hit mismatch")}
            result=built
        }
        if len(args)<=len(key.args) {
            if p.prior==nil {p.prior=make(map[subtreeKey]ast.ASTHandle)}
            p.prior[key]=result
        }
        '''.replace('FORCE','true' if mode=='price' else 'false')+s[b:]
    dst=w/(mode+'.go');dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',ov,'-o',w/mode,'./cmd/g3'],check=True)
