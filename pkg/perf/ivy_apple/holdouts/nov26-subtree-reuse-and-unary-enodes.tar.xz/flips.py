from pathlib import Path
import json
w=Path(__file__).resolve().parent;mp=json.loads((w/'frames.json').read_text())
src=Path.cwd()/'ast/rewriter/rewriter_engine.go';s=Path(mp['Replace'][str(src)]).read_text()
k='if !v.same{a.changed++}'
assert s.count(k)==1
s=s.replace(k,'''if !v.same {
    a.changed++
    app,fam,op,e:=r.core.manager.AppIdentity(f.curr)
    if e!=nil {panic(e)}
    println("FLIP",app,int32(fam),op,len(r.core.frames),a.history[k].steps,v.steps)
}''')
dst=w/'flip.go';dst.write_text(s)
mp['Replace'][str(src)]=str(dst);(w/'flip.json').write_text(json.dumps(mp))
