"""Coallocate the binary ordinary term and its already validated children."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent; mapping={}
for name in ('smt_internalizer.go','smt_enode_core.go'):
    src=Path.cwd()/'smtcore'/name;s=src.read_text()
    if name=='smt_internalizer.go':
        a=s.index('func (s *SMTInternalizerState) existingTermChildren(')
        b=s.index('func (',a+1)
        part=s[a:b].replace('([]*SMTEnode, bool, error)', '([2]*SMTEnode, bool, error)').replace('if count == 0', 'var pair [2]*SMTEnode\n if count == 0',1).replace('\n\tvar pair [2]*SMTEnode\n\tfor', '\n\tfor').replace('return nil,', 'return pair,').replace('return []*SMTEnode{pair[0], pair[1]}','return pair')
        s=s[:a]+part+s[b:]
    else:
        s=s.replace('children []*SMTEnode\n}', 'children [2]*SMTEnode\n}',1)
        k='n := &SMTEnode{'
        assert s.count(k)==1
        s=s.replace(k,'''var n *SMTEnode
        var pair []*SMTEnode
        if term != nil && header.NumArgs == 2 {
            storage := new(struct {node SMTEnode; children [2]*SMTEnode})
            storage.children = term.children
            n, pair = &storage.node, storage.children[:]
        } else {n=new(SMTEnode)}
        *n = SMTEnode{''').replace('n.arguments = term.children','n.arguments = pair')
    dst=w/name;dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    mapping[str(src)]=str(dst)
ov=w/'enode.json';ov.write_text(json.dumps({'Replace':mapping}))
for cmd in [['go','test','-c','-o',w/'new.test', './smtcore'],['go','build','-o',w/'enode','./cmd/g3']]:
    cmd[2:2]=['-pgo=off','-mod=readonly','-overlay',ov]
    subprocess.run(cmd,check=True)
