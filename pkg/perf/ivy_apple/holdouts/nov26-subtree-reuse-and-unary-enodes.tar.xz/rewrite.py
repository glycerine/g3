"""Observe unchanged quantified rewrite frames across separate instance materializations."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent; pkg=Path.cwd()
repl={}
def save(filename,code):
    src=pkg/filename;dst=w/src.name
    dst.write_text(code); repl[str(src)]=str(dst)
def read(filename):return (pkg/filename).read_text()
name='smtcore/smt_qi_instance.go'
s=read(name);k='rw.Rewrite(instance, simplified)';assert s.count(k)==1
save(name,s.replace(k,'rw.ObserveInstance(prepared.quantifier, instance, simplified)'))
name='ast/rewriter/rewriter_core.go';s=read(name)
save(name,s.replace('type rewriterFrame struct {','type rewriterFrame struct {\n auditStart uint64; auditPrior bool'))
name='ast/rewriter/rewriter_engine.go';s=read(name)
s=s.replace('type rewriterEngine struct {','type rewriterEngine struct {\n audit auditFrames')
k='r.numSteps++\n\t\tif !r.substituteVariables'
assert s.count(k)==1
s=s.replace(k,'''r.numSteps++
        if r.audit.active {r.auditStep()}
        if !r.substituteVariables''')
k='e = r.processApp()';assert s.count(k)==1
s=s.replace(k, '''if r.audit.active {
            if r.audit.underChild {e=r.auditChildApp()} else if r.audit.underRoot {e=r.auditRootApp()} else {e=r.auditNewApp()}
        } else {e=r.processApp()}''')
for method in ['finish(fr','rewritten(fr']:
    a=s.index('func (r *rewriterEngine) '+method)
    b=s.index('if e = ',s.index('if e != nil',a))
    s=s[:b]+'if r.audit.active {r.auditFinish(fr,h)}\n '+s[b:]
s+='''
type auditKey struct {q,term ast.ASTHandle; depth uint32}
type auditValue struct {same bool; steps uint64}
type auditFrames struct {
    active,underRoot,underChild bool
    q ast.ASTHandle
    history,pending map[auditKey]auditValue
    steps,rootSteps,childSteps,hits,changed,costChanged uint64
}
func (r *rewriterEngine) auditStep() {
    a:=&r.audit
    a.steps++
    frames:=r.core.frames
    f:=&frames[len(frames)-1]
    if f.auditStart==0 {
        f.auditStart=a.steps
        f.auditPrior=a.history[auditKey{a.q,f.curr,f.maxDepth()}].same
    }
    a.underRoot=frames[0].auditPrior
    a.underChild=false
    for i:=1;i<len(frames);i++ {if frames[i].auditPrior {a.underChild=true;break}}
    if a.underRoot {a.rootSteps++}
    if a.underChild {a.childSteps++}
}
func (r *rewriterEngine) auditFinish(f rewriterFrame,h ast.ASTHandle) {
    a:=&r.audit
    if f.auditStart==0{return}
    k:=auditKey{a.q,f.curr,f.maxDepth()}
    v:=auditValue{f.curr==h,a.steps-f.auditStart+1}
    if f.auditPrior {a.hits++; if !v.same{a.changed++};if v.steps!=a.history[k].steps{a.costChanged++}}
    a.pending[k]=v
}
//go:noinline
func (r *rewriterEngine) auditChildApp() error {return r.processApp()}
//go:noinline
func (r *rewriterEngine) auditRootApp() error {return r.processApp()}
//go:noinline
func (r *rewriterEngine) auditNewApp() error {return r.processApp()}
func (r *TheoryRewriter) ObserveInstance(q,h ast.ASTHandle,out ast.ASTRef) error {
    a:=&r.traversal.engine.audit
    if a.history==nil {a.history=make(map[auditKey]auditValue);a.pending=make(map[auditKey]auditValue)}
    a.active=true;a.q=q;a.steps=0;a.childSteps=0;a.rootSteps=0;a.hits=0;a.changed=0;a.costChanged=0
    e:=r.Rewrite(h,out)
    a.active=false
    if e==nil {for k,v:=range a.pending {a.history[k]=v}}
    clear(a.pending)
    println("RWFRAME",a.steps,a.rootSteps,a.childSteps,a.hits,a.changed,a.costChanged)
    return e
}
'''
save(name,s)
ov=w/'frames.json';ov.write_text(json.dumps({'Replace':repl}))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-pgo=off','-overlay',ov,'-o',w/'frames','./cmd/g3'],check=True)
