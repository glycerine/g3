import csv,statistics,sys,collections
from statistics import median
for f in sys.argv[1:]:
    d=collections.defaultdict(dict)
    for r in csv.DictReader(open(f)):d[r['width'],r['round']][r['engine']]=r
    for width in (32,256,2048):
        for mode in sorted({m for (w,_),p in d.items() if w==str(width) for m in p}-{'base'}):
            pairs=[p for (w,_),p in d.items() if w==str(width) and 'base' in p and mode in p]
            if not pairs:continue
            print(width,mode,len(pairs),*[round(median([(float(p[mode][c])/float(p['base'][c])-1)*100 for p in pairs]),2) for c in ['instructions','cycles','ns']],*[round(median([float(p[m][c]) for p in pairs])) for c in ['bytes','allocs'] for m in ('base',mode)])
