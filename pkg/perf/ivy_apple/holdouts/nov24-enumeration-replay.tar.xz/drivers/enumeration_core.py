from common import *
import enum_premise_slices as sl,shlex
rd=d/'enumeration-cores';rd.mkdir(exist_ok=True)
z3=pkg.parent/'build/z3';exe=d/'enumeration-replay/api.test'
def native(root,p,c,timeout,tag):
 stats=root/(tag+'.perf');r=subprocess.run(['taskset','-c',str(c),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',stats,'--',z3,'-t:'+str(timeout),p],env=env,capture_output=True,text=True,timeout=timeout//1000+150)
 (root/(tag+'.stdout')).write_text(r.stdout);(root/(tag+'.stderr')).write_text(r.stderr);assert r.stdout.splitlines() and r.stdout.splitlines()[0]in('unsat','sat','unknown'),(tag,r.returncode,r.stdout[:300]);cs=[int(l.split(',')[0])for l in stats.read_text().splitlines()if ':u'in l];return r.stdout.splitlines()[0],r.stdout,cs
def job(name,c):
 root=rd/name;root.mkdir();q=json.loads((sl.rd/name/'original.json').read_text())[0];p=q['Problem'];forms,g=sl.terms(p);ds=p['Text'][:p['AssertionsStart']]
 src=root/'tracked.smt2';src.write_text('(set-option :produce-unsat-cores true)\n'+ds+''.join('(assert (! '+v+' :named premise'+str(i)+'))\n'for i,v in enumerate(forms))+g+'(check-sat)\n(get-unsat-core)\n')
 res,txt,cnt=native(root,src,c,180000,'tracked')
 with(root/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('query engine stage premises budget answer instructions cycles'.split());wr.writerow([name,'native','tracked',len(forms),180000,res,*cnt]);f.flush()
  if res!='unsat':print(name,'tracked',res,flush=True);return
  ix=sorted(set(int(n) for n in re.findall(r'premise(\d+)',txt)));pre=''.join('(assert '+forms[i]+')\n'for i in ix);nf=root/'core.smt2';nf.write_text(ds+pre+g+'(check-sat)\n');(root/'indices.txt').write_text(' '.join(map(str,ix))+'\n');v,_,ct=native(root,nf,c,90000,'verify')
  wr.writerow([name,'native','core',len(ix),90000,v,*ct]);assert v=='unsat',(name,v);f.flush()
  x={**p,'Text':ds+pre+g,'LastAssertionStart':len(ds)+len(pre)};inp=root/'core.json';inp.write_text(json.dumps([{**q,'Problem':x}]))
  for budget in (100000,1000000,6000000):
   pf=root/('go'+str(budget)+'.perf');r=run(['taskset','-c',str(c),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',pf,'--',exe,'-test.run=^TestStudyEnumerationReplay$','-test.v'],env=dict(env,GOMAXPROCS='1',ENUM_SCOPE='cold',ENUM_REGIME='default',ENUM_STEPS=str(budget),ENUM_SEQUENCE=str(inp)),capture_output=True,text=True);ans=re.search(r'^REPLAY 1 1 (true|false)',r.stdout,re.M).group(1)
   ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];wr.writerow([name,'g3','core',len(ix),budget,ans,*ct]);f.flush()
   if ans=='true':break
  print(name,'assertions',len(forms),'core',len(ix),'g3',ans,budget,flush=True)
def lane(i,c):
 for name in ('miss'+str(i),'control'+str(i)):job(name,c)
with ThreadPoolExecutor(6)as ex:list(ex.map(lambda x:lane(*x),enumerate([5,22,37,26,11,42],1)))
