from common import *
import collections,math
rd=d/'enum-premise-slices';rd.mkdir(exist_ok=True);record=d/'enumeration-replay/complete.jsonl';exe=d/'enumeration-replay/api.test';sym=re.compile(r'\bef\d+_\d+\b')
def tree(s):
 stack=[];v=None
 for t in re.findall(r'\(|\)|[^()\s]+',s):
  if t=='(':stack.append([])
  elif t==')':
   n=stack.pop()
   if stack:stack[-1].append(n)
   else:v=n
  else:stack[-1].append(t)
 assert not stack and v is not None;return v
def render(x):return x if isinstance(x,str)else '('+' '.join(map(render,x))+')'
def split(n):
 if isinstance(n,list)and n and n[0]=='and':
  for ch in n[1:]:yield from split(ch)
 else:yield render(n)
def terms(p):
 pre,g=p['Text'][p['AssertionsStart']:p['LastAssertionStart']],p['Text'][p['LastAssertionStart']:]
 pre=[e for l in pre.splitlines()for e in split(tree(l)[1])];return pre,g
def pick(forms,g,mode,k):
 vs=[set(sym.findall(l))for l in forms];gset=set(sym.findall(g))
 freq=collections.Counter(it for row in vs for it in row);seed=set(gset);rank=[];remain=set(range(len(forms)))
 for depth in range(4):
  scores=[]
  for i in remain:
   share=vs[i]&seed
   if not share:continue
   scores.append((sum((1/freq[s])**.7 for s in share)/max(1,len(vs[i]))**.4,i))
  if not scores:break
  scores.sort(key=lambda x:(-x[0],x[1]))
  step=min(len(scores), k-len(rank), k//(2**(depth+1)) if depth<3 else k);step=max(1,step)
  add=[i for _,i in scores[:step]];rank+=add;remain.difference_update(add);seed.update(*(vs[i]for i in add))
  if len(rank)>=k:break
 if mode=='rank':return sorted(set(rank).union(i for i,l in enumerate(forms)if not vs[i]))
 if mode=='direct':return [i for i,l in enumerate(forms)if not vs[i]or vs[i]&gset]
 if mode=='tail':return sorted({i for i in range(len(forms))if i>=len(forms)-k or not vs[i]})
 return list(range(len(forms)))
def cases():
 misses=[];prev=None
 with record.open()as sf:
  for line in sf:
   try:q=json.loads(line)
   except ValueError:break
   if not q['Proved']:
    misses.extend([(f'miss{len(misses)//2+1}',q),(f'control{len(misses)//2+1}',prev)])
    if len(misses)==12:break
   prev=q
 assert len(misses)==12
 for name,q in misses:
  p=q['Problem'];forms,g=terms(p);decls=p['Text'][:p['AssertionsStart']];root=rd/name;root.mkdir(exist_ok=True)
  for v,k in [('original',0),('flat',0),('rank',32),('rank',64),('rank',128),('rank',256),('direct',0),('tail',64)]:
   pre=p['Text'][p['AssertionsStart']:p['LastAssertionStart']]if v=='original'else ''.join('(assert '+forms[i]+')\n'for i in pick(forms,g,v,k))
   pv={**p,'Text':decls+pre+g,'LastAssertionStart':len(decls)+len(pre)};tag=v+(str(k)if k else'')
   (root/(tag+'.json')).write_text(json.dumps([{**q,'Problem':pv}]))
   (root/(tag+'.smt2')).write_text(decls+pre+g+'(check-sat)\n')
 return [n for n,_ in misses]
def measure(name,c,role):
 base=rd/name;variants=['original','flat','rank32','rank64','rank128','rank256','direct','tail64']
 with(base/(role+'.csv')).open('w')as out:
  wr=csv.writer(out);wr.writerow('query selection engine budget proof instructions cycles rows'.split())
  for v in variants:
   p=base/(v+'.smt2');n=p.read_text().count('(assert');stats=base/(role+'.perf')
   if role=='g3':
    en=dict(env,GOMAXPROCS='1',ENUM_SCOPE='cold',ENUM_REGIME='default',ENUM_STEPS='1000000',ENUM_SEQUENCE=str(base/(v+'.json')));cmd=[exe,'-test.run=^TestStudyEnumerationReplay$','-test.v'];t=1000000
   else:en=env;cmd=[pkg.parent/'build/z3','-t:30000',p];t=30000
   r=subprocess.run(['taskset','-c',str(c),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',stats,'--',*cmd],env=en,capture_output=True,text=True,timeout=95);assert r.returncode==0,(role,name,v,r.stdout[-350:],r.stderr[-350:])
   if role=='g3':ans=re.search(r'^REPLAY 1 1 (true|false)',r.stdout,re.M).group(1)
   else:ans=r.stdout.strip();assert ans in ('sat','unsat','unknown'),r.stdout[:300]
   ct=[int(l.split(',')[0])for l in stats.read_text().splitlines()if ':u'in l];wr.writerow([name,v,role,t,ans,*ct,n]);out.flush()
  print(name,role,'done',flush=True)
if __name__=='__main__':
 ns=cases()
 def lane(k,c,role):
  for n in ns[k::4]:measure(n,c,role)
 with ThreadPoolExecutor(8)as ex:
  fs=[ex.submit(lane,k,c,role)for role,cs in [('g3',[0,13,35,46]),('native',[2,28,44,27])]for k,c in enumerate(cs)]
  for f in fs:f.result()
