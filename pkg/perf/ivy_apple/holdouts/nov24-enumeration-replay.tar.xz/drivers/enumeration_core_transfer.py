from common import *
import enum_premise_slices as sl,itertools
rd=d/'enumeration-core-transfer';rd.mkdir(exist_ok=True)
oracle=d/'enumeration-cores';exe=d/'enumeration-replay/api.test'
def load():
 rs={}
 for kind,i in itertools.product(('miss','control'),range(1,7)):
  n=kind+str(i);q=json.loads((sl.rd/n/'original.json').read_text())[0];p=q['Problem'];forms,g=sl.terms(p)
  own=oracle/n/'indices.txt'
  if not own.is_file():continue
  core={forms[int(x)] for x in own.read_text().split()};rs[n]=(q,forms,g,core)
 return rs
def compare(rs,n,c):
 q,forms,g,core=rs[n];p=q['Problem'];terms=set(forms);out=rd/n;out.mkdir(exist_ok=True)
 with(out/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('target source base shared_core own_overlap selected steps answer instructions cycles'.split())
  for source in [s for s in rs if s!=n]+['all-other-misses','all-controls','past-only']:
   if source=='all-controls':ss=[i for i in rs if i.startswith('control')]
   elif source=='all-other-misses':ss=[i for i in rs if i.startswith('miss')and i!=n]
   elif source=='past-only':ss=[i for i in rs if i.startswith('miss')and int(i[4:])<int(n[4:])]+['control'+n[4:]]
   else:ss=[source]
   pick=set().union(*(rs[s][-1] for s in ss))&terms
   pres=''.join('(assert '+v+')\n'for v in forms if v in pick);nf=out/(source+'.json');decls=p['Text'][:p['AssertionsStart']]
   nf.write_text(json.dumps([{**q,'Problem':{**p,'Text':decls+pres+g,'LastAssertionStart':len(decls)+len(pres)}}]))
   for limit in (1000000,6000000):
    pf=out/(source+'.perf');r=run(['taskset','-c',str(c),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',pf,'--',exe,'-test.run=^TestStudyEnumerationReplay$','-test.v'],env=dict(env,GOMAXPROCS='1',ENUM_SCOPE='cold',ENUM_REGIME='default',ENUM_STEPS=str(limit),ENUM_SEQUENCE=str(nf)),capture_output=True,text=True)
    ans=re.search(r'^REPLAY 1 1 (true|false)',r.stdout,re.M).group(1);ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];z.writerow([n,source,len(forms),len(pick),len(pick&core),pres.count('(assert'),limit,ans,*ct]);f.flush()
    if ans=='true':print(n,source,len(pick),ans,limit,flush=True);break
 print(n,'finished',flush=True)
rs=load();assert len(rs)==12,rs.keys()
with ThreadPoolExecutor(6)as ex:list(ex.map(lambda x:compare(rs,*x),zip(['miss'+str(i)for i in range(1,7)],[3,17,33,26,15,23])))
