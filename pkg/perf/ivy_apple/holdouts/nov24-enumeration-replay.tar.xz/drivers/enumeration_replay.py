from common import *
import holdouts as ho
rd=d/'enumeration-replay';rd.mkdir(exist_ok=True)
driver=r'''package api
import("os";"encoding/json";"testing";"strconv";"fmt";"time";"errors";"github.com/glycerine/g3/pkg/api/internal/order")
type enumerationReplay struct{Problem order.Problem; New bool; Proved bool; Owner string}
func TestStudyEnumerationReplay(t *testing.T){
 f,e:=os.Open(os.Getenv("ENUM_SEQUENCE"));if e!=nil{t.Fatal(e)};defer f.Close()
 var qs []enumerationReplay;if e=json.NewDecoder(f).Decode(&qs);e!=nil{t.Fatal(e)}
 parent,e:=NewSMTContext();if e!=nil{t.Fatal(e)};defer parent.Close();m,e:=parent.Manager();if e!=nil{t.Fatal(e)}
 scope:=os.Getenv("ENUM_SCOPE");regime:=os.Getenv("ENUM_REGIME");if scope=="cold"{qs=qs[len(qs)-1:]}
 budget,_:=strconv.Atoi(os.Getenv("ENUM_STEPS"))
 var p orderProofState;defer p.release()
 if e=p.start(m,enumerationSearch);e!=nil{t.Fatal(e)}
 if regime!="default"{x,e:=p.ctx.NewParameterSet();if e!=nil{t.Fatal(e)};e=x.SetBool("smt.macro_finder",regime!="macro-off")
 if e==nil{rel:=uint32(1);if regime=="rel2"{rel=2};if regime=="rel0"{rel=0};e=x.SetUInt("smt.relevancy",rel)}
 if e==nil{switch regime{case "ematch":e=x.SetBool("smt.mbqi",false);case "seed":e=x.SetUInt("smt.random_seed",1);case "phase2":e=x.SetUInt("smt.phase_selection",2);case "phase6":e=x.SetUInt("smt.phase_selection",6);case "eager3":e=x.SetDouble("smt.qi.eager_threshold",3);case "multi":e=x.SetUInt("smt.qi.max_multi_patterns",2)}}
 if e==nil{e=p.child.SetParameters(x)};if e=errors.Join(e,x.Close());e!=nil{t.Fatal(e)}}
 for i,q:=range qs {if p.needsNewDeclarations(q.Problem){t.Fatal("inconsistent declarations",i)}
 limit:=uint32(6000000);if i==len(qs)-1{limit=uint32(budget)}
 started:=time.Now();yes,e:=p.check(m,q.Problem,limit,true);if e!=nil{t.Fatal(e)}
 if i==len(qs)-1||!yes{fmt.Printf("REPLAY %d %d %t %d\n",i+1,len(qs),yes,time.Since(started).Nanoseconds());if !yes{break}}
 }
}'''
def binaries():
 p=pkg/'api/api_enumeration_refutation.go';s=once(p.read_text(),'"errors"','"errors"\n"os"\n"fmt"\n"encoding/json"')
 s=once(s,'if p.kernel == nil {','fresh:=p.kernel==nil; if p.kernel == nil {')
 x='proved, err := p.kernel.check(m, *problem, 6_000_000, true)'
 s=once(s,x,x+'''
 if name:=os.Getenv("ENUM_CAPTURE");name!=""{f,e:=os.OpenFile(name,os.O_APPEND|os.O_CREATE|os.O_WRONLY,0600);if e!=nil{panic(e)};e=json.NewEncoder(f).Encode(struct {Problem *order.Problem; New,Proved bool; Owner string}{problem,fresh,proved,fmt.Sprintf("%p",p)});if f.Close()!=nil||e!=nil{panic("capture failed")}}
 ''')
 ot=overlay(rd/'test',{pkg/'api/enumeration_replay_study_test.go':driver})
 def testbin():
  with(w/'build.lock').open('a')as lk,(rd/'testbuild.log').open('w')as log:
   fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-tags=xtrace_off','-overlay='+str(ot),'-c','-o',rd/'api.test','./api'],cwd=pkg,stdout=log,stderr=log)
 with ThreadPoolExecutor(2)as ex:
  f=ex.submit(testbin);b=build(rd/'checker',o=overlay(rd/'overlay',{p:s}));f.result()
 return b
def capture(b):
 _,_,sp,_,rc,ref=ho.jobs()[0];src=rd/'complete.jsonl';r=subprocess.run(['taskset','-c','17',b,examples/sp],cwd=rd,capture_output=True,env=dict(env,GOMAXPROCS='1',ENUM_CAPTURE=str(src)))
 assert(r.returncode,r.stdout,r.stderr)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
 active={};n=ok=checks=0
 with src.open()as f:
  for l in f:
   x=json.loads(l);owner=x['Owner']
   if x['New']:active[owner]=[]
   active[owner].append(x);checks+=1
   if x['Proved']:ok+=1;continue
   n+=1;qs=active.pop(owner);out=rd/('q'+str(n)+'.json');out.write_text(json.dumps(qs));print('miss',n,'history',len(qs),'length',len(x['Problem']['Text']),flush=True)
 print('capture',checks,ok,n,flush=True);assert n==6
def lane(q,c):
 src=rd/('q'+str(q)+'.json');out=rd/('replay-'+str(q)+'.csv')
 with out.open('w')as f:
  z=csv.writer(f);z.writerow('query regime scope budget reached total proved ns instructions cycles'.split())
  for budget,scopes,names in [(6000000,['warm','cold'],['default','ematch','rel2','rel0','seed','phase2','eager3','multi','macro-off']),(12000000,['cold','warm'],['default','rel2','ematch']),(24000000,['warm'],['default'])]:
   for s in scopes:
    for v in names:
     pf=rd/(str(q)+'.perf');r=run(['taskset','-c',str(c),perf,'stat','-e','cycles:u,instructions:u','-x,','-o',pf,'--',rd/'api.test','-test.run=^TestStudyEnumerationReplay$','-test.timeout=3m','-test.v'],env=dict(env,GOMAXPROCS='1',ENUM_SEQUENCE=str(src),ENUM_SCOPE=s,ENUM_REGIME=v,ENUM_STEPS=str(budget)),capture_output=True,text=True)
     hit=re.findall(r'^REPLAY (\d+) (\d+) (true|false) (\d+)$',r.stdout,re.M);assert len(hit)==1,(v,s,q,r.stdout[-600:]);ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];z.writerow([q,v,s,budget,*hit[0],ct[1],ct[0]]);f.flush()
     if v=='default' or hit[0][2]=='true':print(q,v,s,budget,hit[0][:3],flush=True)
if __name__=='__main__':
 b=binaries();capture(b)
 with ThreadPoolExecutor(6)as ex:list(ex.map(lambda x:lane(*x),enumerate([7,18,24,30,12,41],1)))
