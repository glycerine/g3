"""Run from pkg after extracting this file. The optional argv[1] specifies z3."""
import gzip
import json
import subprocess
import sys
with gzip.open("api/test_vectors/apple_enumeration_search.json.gz", "rt") as f:
    fixture = json.load(f)
for i, batch in enumerate(fixture["Batches"], 1):
    for form, query in [("full", batch["History"][-1]), ("core", batch["Core"])]:
        declarations = fixture["Declarations"][query["Declarations"]]
        premises = fixture["Premises"][query["Premises"]]
        problem = declarations + premises + query["Goal"] + "(check-sat)\n"
        run = subprocess.run([sys.argv[1] if len(sys.argv) > 1 else "../build/z3", "-in"],
                             input=problem, capture_output=True, text=True, check=True)
        print(i, form, run.stdout.strip(), flush=True)
        assert run.stdout.strip() == "unsat"
