"""Separate clause filtering from publication and assignment."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;pkg=Path.cwd();base=w.parent/'.boolean-enode-cost'
f=pkg/'smtcore/smt_internalizer.go';s=f.read_text()
mark='\t// mk_clause: j = unit_resolution_justification'
assert s.count(mark)==1
s=s.replace(mark, """    return s.storeSimplifiedClause(kept, removedFalse, root, kind, proof, justification, deleteHandler)
}

func (s *SMTInternalizerState) storeSimplifiedClause(kept, removedFalse []SMTLiteral, root bool, kind SMTClauseKind, proof ast.ASTHandle, justification SMTJustification, deleteHandler SMTClauseDeleteHandler) error {
"""+mark)
dst=w/'split.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'split.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'split','./cmd/goivy_check'],cwd=base/'frontend/goivy',env=env,check=True)
