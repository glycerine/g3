import collections,csv,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
for engine in ('g3','gates-only-z3','detail-g3','detail-z3','early-g3','clause-z3'):
    totals=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0]))
    for r in csv.DictReader((w/(engine+'.csv')).open()):
        v=totals[int(r['stage'])][r['round']]
        v[0]+=int(r['calls']);v[1]+=int(r['instructions'])
    for stage,rounds in sorted(totals.items()):
        assert len(rounds)==5
        counts={r[0] for r in rounds.values()}
        assert len(counts)==1
        print(engine,stage,counts.pop(),statistics.median(r[1] for r in rounds.values()))
