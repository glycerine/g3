"""Verify and measure the 203 matched assertions with each production trial."""
import collections,csv,json,os,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
pkg=Path.cwd()
prev=w.parent/'.lemma-pairs'
base=w.parent/'.boolean-enode-cost'
front=base/'frontend/goivy'
examples=Path('/home/jaten/ivy/ivy-lang-examples')
ref=w.parent/'.bool-scan/golden/reference/hybrid'
basefiles=json.loads((prev/'g3.json').read_text())['Replace']
engines=sys.argv[1:]
for label in engines:
    files=basefiles.copy()
    if label not in ('flags','release'):
        files.update(json.loads((w/(label+'.json')).read_text())['Replace'])
    overlay=w/('target-'+label+'.json')
    overlay.write_text(json.dumps({'Replace':files}))
    exe=w/('target-'+label)
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',overlay,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
out=csv.writer(sys.stdout);out.writerow(['round','engine','ordinal','operation','instructions'])
with (prev/'gc-off.csv').open() as source:
    expected=[(r['operation'],int(r['ast_hash'])) for r in csv.DictReader(source) if r['round']=='1' and r['candidate']=='0']
for i in range(5):
    for label in engines[i%len(engines):]+engines[:i%len(engines)]:
        r=subprocess.run(['taskset','-c','14',w/('target-'+label),examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
        rows,keep,c=[],[],0
        for line in r.stderr.splitlines(keepends=True):
            if line.startswith(b'PREFIX '):c+=1
            elif line.startswith(b'LEM '):
                if c==0:
                    _,kind,h,empty,raw=line.decode().split()
                    rows.append((kind,int(h),int(raw)-int(empty)))
            elif line.startswith(b'STAGE-COUNT '):
                if line.startswith(b'STAGE-COUNT 35 1 check '):
                    assert [(k,h) for k,h,_ in rows]==expected and len(rows)==406
                    out.writerows([i+1,label,n//2+1,k,v] for n,(k,h,v) in enumerate(rows))
                rows,c=[],0
            else:keep.append(line)
        assert r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
        sys.stdout.flush()
