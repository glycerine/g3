import csv,collections,statistics
from pathlib import Path
rows=collections.defaultdict(dict)
for row in csv.DictReader((Path(__file__).resolve().parent/'bench.csv').open()):
    rows[row['build'],row['arity'],row['round']][int(row['n'])]=row
for a in ['0','1','2','3','8']:
    for label in ['before','flags']:
        p=[vals for (b,k,_),vals in rows.items() if a==k and b==label]
        assert len(p)==7
        print(a,label,round(statistics.median((int(v[100000]['instructions'])-int(v[10000]['instructions']))/90000 for v in p),1),statistics.median(float(v[100000]['ns']) for v in p))
