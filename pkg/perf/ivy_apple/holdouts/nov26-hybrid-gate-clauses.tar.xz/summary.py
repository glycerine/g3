"""Summarize the short-clause trials and compare retired instructions by prefix."""
from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
bench=collections.defaultdict(dict)
for r in csv.DictReader((w/'compact-bench.csv').open()):
    bench[r['width'],r['kind'],r['round']][r['engine']]=float(r['ns_per_op'])
for width,kind in sorted({(a,b) for a,b,i in bench},key=lambda pair:tuple(map(int,pair))):
    vals=[d for (a,b,_),d in bench.items() if a==width and b==kind]
    assert len(vals)==9 and all(len(d)==2 for d in vals)
    print(width,kind,statistics.median(v['flags'] for v in vals),statistics.median(v['compact'] for v in vals))
data=collections.defaultdict(lambda:collections.Counter())
for r in csv.DictReader((w/'target.csv').open()):
    data[r['engine'],r['operation']][r['round']]+=int(r['instructions'])
for key,rounds in data.items():
    print(key,len(rounds),statistics.median(rounds.values()))
