"""Build a private variant that filters the sorted literal copy in place."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent
pkg=Path.cwd();base=w.parent/'.boolean-enode-cost'
f=pkg/'smtcore/smt_internalizer.go'
s=f.read_text()
s=s.replace('ordered := kind == SMTClauseAux', 'kept := s.clauseKeptScratch[:0]\n\tordered := kind == SMTClauseAux',1)
s=s.replace('s.clauseSortScratch = append(s.clauseSortScratch[:0], literals...)\n\t\tliterals = s.clauseSortScratch','literals = append(kept, literals...)\n\t\tkept = literals[:0]')
s=s.replace('// Collect the simplified literals in solver-local storage.\n\tkept := s.clauseKeptScratch[:0]','// Filter into the owned backing array. Every kept position is at or before its input.')
assert s.count('kept := s.clauseKeptScratch')==1 and 'clauseSortScratch' not in s
dst=w/'compact.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'compact.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
subprocess.run(['go','test','-c','-pgo=off','-overlay',ov,'-o',w/'compact-bench','./smtcore'],env=env,check=True)
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'compact','./cmd/goivy_check'],cwd=base/'frontend/goivy',env=env,check=True)
