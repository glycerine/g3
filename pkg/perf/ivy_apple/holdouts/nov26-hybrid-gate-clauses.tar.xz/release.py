"""Build the verifier and compare total scratch capacity across the clause change."""
import json,os,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
pkg=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-o',w/'release','./cmd/goivy_check'],cwd=front,env=env,check=True)
maps={}
for name in ('smt_internalizer.go','smt_internalizer_state.go'):
    dst=w/('old-'+name)
    dst.write_bytes(subprocess.check_output(['git','show','52ea5fd9d:pkg/smtcore/'+name]))
    maps[str(pkg/'smtcore'/name)]=str(dst)
test=pkg/'smtcore/smt_clause_simplify_benchmark_test.go'
dst=w/'old-benchmark.go'
dst.write_text(test.read_text().replace('cap(s.clauseKeptScratch)+','cap(s.clauseSortScratch)+cap(s.clauseKeptScratch)+'))
maps[str(test)]=str(dst)
ov=w/'old-mem.json'
ov.write_text(json.dumps({'Replace':maps}))
for label,opts in [('release',[]),('old',['-overlay',ov])]:
    with (w/(label+'-capacity.txt')).open('w') as out:
        subprocess.run(['go','test',*opts,'-run=^$','-bench=^BenchmarkSMTAuxiliaryClauseSimplification$','-benchtime=1000x','-cpu=1','./smtcore'],stdout=out,env=env,check=True)
