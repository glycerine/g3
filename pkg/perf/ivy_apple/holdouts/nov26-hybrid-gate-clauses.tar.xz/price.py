"""Count and price internalization calls on hybrid's matched instance operands."""
from pathlib import Path
import csv,json,os,re,shlex,shutil,subprocess,sys

work=Path(__file__).resolve().parent
clause='clause' in sys.argv[2:]
detail=clause or 'detail' in sys.argv[2:]
if detail:
    work=work/('clause' if clause else 'gate')
    work.mkdir(exist_ok=True)
pkg=Path.cwd()
prev=pkg/'build'/'.lemma-pairs'
base=pkg/'build'/'.boolean-enode-cost'
front=base/'frontend/goivy'
engine=sys.argv[1]
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')

def one(src,old,new):
    assert src.count(old)==1,old
    return src.replace(old,new)

if engine=='g3':
    files=json.loads((prev/'op.json').read_text())['Replace']
    groups={'smt_internalizer_state.go':[('mkBoolVar',0),('mkEnode',1)],
            'smt_internalizer.go':[('addGateConstraints',2),('internalizeQuantifier',3)],
            'smt_enode_core.go':[('newSMTEnode',4)], 'smt_checker.go':[('registerEnode',5)],
            'smt_cg_table.go':[('Insert',6)]}
    if detail:
        groups={'smt_internalizer.go':[('addGateClause',0),('argumentLiterals',2)],
                'smt_relevancy.go':[('AddAndWatches',1),('AddOrWatches',1),('AddITEWatches',1)]}
    if clause:
        groups={'smt_internalizer.go':[('gateClauseProof',0)], 'smt_clause.go':[('newSMTClause',1)],
                'watch_list.go':[('InsertClause',2)], 'smt_boolean_propagation.go':[('makeClauseWithJustificationAndDeleteHandler',3)]}
    for filename,hooks in groups.items():
        f=pkg/'smtcore'/filename
        src=Path(files.get(str(f),f)).read_text()
        for name,i in hooks:
            src,n=re.subn(r'(^func (?:\([^\n]+?\) )?'+name+r'\([^\n]+? \{)$',
                lambda m:m[0]+f'\n if priceFD>=0 {{ a:=lemmaRead(priceFD); b:=lemmaRead(priceFD); defer func(){{c:=lemmaRead(priceFD); priceN[{i}]++;priceCost[{i}]+=int64(c-b)-int64(b-a)}}() }}',src,flags=re.M)
            assert n==1,(filename,name,n)
        if clause:
            src=src.replace('if priceFD>=0 { a:=lemmaRead(priceFD);','if gateFD>=0 { a:=lemmaRead(priceFD);')
        if filename=='smt_internalizer.go':
            if clause:
                signature='func (s *SMTInternalizerState) addGateClause(literals []SMTLiteral) error {'
                src=one(src,signature,signature+'if priceFD>=0 {gateFD=priceFD;defer func(){gateFD=-1}()}\n')
                src+='\nvar gateFD = -1\n'
                src=one(src,'ordered := kind == SMTClauseAux', 'fd:=gateFD; a:=lemmaRead(fd);b:=lemmaRead(fd);if fd>=0 {defer func(){if fd>=0 {c:=lemmaRead(fd);priceN[6]++;priceCost[6]+=int64(c-b)-int64(b-a)}}()};ordered := kind == SMTClauseAux')
                src=one(src,'// mk_clause: j = unit_resolution_justification', 'if fd>=0 {c:=lemmaRead(fd);priceN[4]++;priceCost[4]+=int64(c-b)-int64(b-a);fd=-1}\n // mk_clause: j = unit_resolution_justification')
            src=one(src,'probe:=lemmaRead(fd); if err = s.Internalize','priceFD=fd;probe:=lemmaRead(fd); if err = s.Internalize')
            src=one(src,'internal:=lemmaRead(fd); literals','priceFD=-1;if fd>=0 { for i,n:=range priceN {if n>0 {println("PRICE",i,n,priceCost[i])}};clear(priceN[:]);clear(priceCost[:]) };internal:=lemmaRead(fd); literals')
            src+='\nvar priceFD = -1\nvar priceN [7]int\nvar priceCost [7]int64\n'
        dst=work/filename
        dst.write_text(src)
        files[str(f)]=str(dst)
else:
    files=json.loads((prev/'seg-z3.json').read_text())['Replace']
    build=pkg.parent/'build'
    src=(prev/'native-operand/smt_internalizer.cpp').read_text()
    hdr='''
static int price_fd=-1, counts[7]{};
static long long cost[7]{};
struct Interval {
    int fd,i; uint64_t a,b;
    Interval(int k):fd(price_fd),i(k),a(rd(fd)),b(rd(fd)){}
    ~Interval(){if(fd>=0){auto c=rd(fd);counts[i]++;cost[i]+=(long long)(c-b)-(long long)(b-a);}}
};
'''
    src=one(src,'extern int seg_fd;',hdr+'extern int seg_fd;')
    src=one(src,'uint64_t a=rd(fd),b=rd(fd);','price_fd=fd;uint64_t a=rd(fd),b=rd(fd);')
    src=one(src,'uint64_t c=rd(fd);\n                    lits','price_fd=-1; if(fd>=0){for(int i=0;i<7;i++){if(counts[i])fprintf(stderr,"PRICE %d %d %lld\\n",i,counts[i],cost[i]);counts[i]=0;cost[i]=0;}} uint64_t c=rd(fd);\n                    lits')
    if clause:
        src=one(src,'void context::mk_gate_clause(unsigned num_lits, literal * lits) {','void context::mk_gate_clause(unsigned num_lits, literal * lits) { struct Gate {int old; Gate():old(gate_fd){gate_fd=price_fd;} ~Gate(){gate_fd=old;}} gate;')
        src=one(src,'static int price_fd=-1,','static int gate_fd=-1,price_fd=-1,')
        src=one(src,'bool context::simplify_aux_clause_literals(unsigned & num_lits, literal * lits, literal_buffer & simp_lits) {','bool context::simplify_aux_clause_literals(unsigned & num_lits, literal * lits, literal_buffer & simp_lits) {Interval guard(4);')
        src=one(src,'Interval(int k):fd(price_fd)','Interval(int k):fd(gate_fd)')
        src=one(src,'clause * cls = clause::mk(', 'clause * cls; {Interval guard(1);cls = clause::mk(')
        src=one(src,'m_bool_var2expr.c_ptr());\n            if (lemma)', 'm_bool_var2expr.c_ptr());}\n            if (lemma)')
        src=one(src,'m_aux_clauses.push_back(cls);\n                add_watch_literal(cls, 0);\n                add_watch_literal(cls, 1);','m_aux_clauses.push_back(cls);\n                {Interval guard(2);add_watch_literal(cls, 0);} {Interval guard(2);add_watch_literal(cls, 1);}')
    elif detail:
        for part in ['mk_gate_clause(unsigned num_lits, literal * lits)', 'add_and_rel_watches(app * n)', 'add_or_rel_watches(app * n)', 'add_ite_rel_watches(app * n)']:
            signature='void context::'+part+' {'
            src=one(src,signature,signature+'Interval guard('+str(int('watches' in part))+');')
    else:
        for name,i in [('mk_bool_var',0),('mk_enode',1),('internalize_quantifier',3)]:
            src,n=re.subn(r'(context::'+name+r'\([^\n]+? \{)',r'\1 Interval guard('+str(i)+');',src)
            assert n==1,name
        start=src.index('if (is_new_var && n->get_family_id()')
        end=src.index('case OP_TRUE:',start)
        switch=src[start:end]
        switch,n=re.subn(r'(case OP_(?:AND|OR|ITE|NOT|IFF):)(.*?break;)',r'\1 {Interval guard(2);\2}',switch,flags=re.S)
        assert n==5
        src=src[:start]+switch+src[end:]
        src=one(src,'enode * e           = enode::mk','enode * e;{Interval guard(4);e = enode::mk')
        src=one(src,'m_scope_lvl, cgc_enabled, true);','m_scope_lvl, cgc_enabled, true);}')
        src=one(src,'enode_bool_pair pair = m_cg_table.insert(e);','enode_bool_pair pair;{Interval guard(6);pair = m_cg_table.insert(e);}')
    f=work/'smt_internalizer.cpp';f.write_text(src)
    flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
    inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    obj=f.with_suffix('.o')
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,f],cwd=build,check=True)
    lib=work/('lib.a' if detail else 'lib-explicit-gates.a')
    shutil.copyfile(prev/'seg/libseg.a',lib)
    subprocess.run(['ar','r',lib,obj],check=True)
    q=front/'smt/quantifier.go';dst=work/'quantifier.go'
    dst.write_text(Path(files[str(q)]).read_text().replace(str(prev/'seg/libseg.a'),str(lib)))
    files[str(q)]=str(dst)
overlay=work/(engine+'.json');overlay.write_text(json.dumps({'Replace':files}))
exe=work/engine
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if engine=='z3' else 'xtrace_off','-overlay',overlay,'-o',exe,'./cmd/goivy_check'],cwd=front,env=env,check=True)
examples=Path('/home/jaten/ivy/ivy-lang-examples')
ref=pkg/'build'/'.bool-scan/golden/reference/hybrid'
out=csv.writer(sys.stdout);out.writerow(['round','operand','stage','calls','instructions'])
with (prev/'operand.csv').open() as inp:
    kinds=[r['kind'] for r in csv.DictReader(inp) if r['round']=='1']
for i in range(5):
    r=subprocess.run(['taskset','-c','14',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=work,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
    keep,rows,c,k,segments=[],[],0,0,0
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'PREFIX '): c+=1
        elif line.startswith(b'PRICE '):
            if c==0 and kinds[k]=='full': rows.append([i+1,k+1,*line.decode().split()[1:]])
        elif line.startswith((b'OPER ',b'NATIVEOP ')): k+=c==0
        elif line.startswith(b'SEG '): segments+=c==0
        elif line.startswith(b'STAGE-COUNT '):
            if line.startswith(b'STAGE-COUNT 35 1 check '):
                assert k==639 and segments==203 and rows
                out.writerows(rows)
            rows,c,k,segments=[],0,0,0
        elif not line.startswith(b'LEM '):keep.append(line)
    assert r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
