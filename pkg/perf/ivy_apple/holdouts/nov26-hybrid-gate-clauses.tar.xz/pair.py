"""Order two-literal inputs directly in the simplifier's private buffer."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;pkg=Path.cwd();base=w.parent/'.boolean-enode-cost'
f=pkg/'smtcore/smt_internalizer.go';s=f.read_text()
old='literals = append(kept, literals...)\n\t\tkept = literals[:0]\n\t\tslices.Sort(literals)'
assert s.count(old)==1
s=s.replace(old,'''if len(literals)==2 {
        a,b:=literals[0],literals[1]
        if a>b {a,b=b,a}
        literals=append(kept,a,b)
    } else {
        literals=append(kept,literals...)
        slices.Sort(literals)
    }
    kept=literals[:0]''')
dst=w/'pair.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'pair.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'pair','./cmd/goivy_check'],cwd=base/'frontend/goivy',env=env,check=True)
