"""Build the short-circuited commutative enode constructor and its controls."""
import json,os,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
pkg=Path.cwd()
base=w.parent/'.boolean-enode-cost'
src=pkg/'smtcore/smt_enode_core.go'
s=src.read_text()
old='flags, err := m.GetFuncDeclFlags(header.Decl)\n\tif err != nil {\n\t\treturn nil, err\n\t}'
assert s.count(old)==1
s=s.replace(old,'''commutative := false
    if !options.SuppressArguments && header.NumArgs == 2 {
        flags, err := m.GetFuncDeclFlags(header.Decl)
        if err != nil {return nil, err}
        commutative = flags.Commutative
    }''').replace('boolean:  boolean, mergeTruthValue:', 'commutative: commutative, boolean: boolean, mergeTruthValue:').replace('\n\tn.commutative = len(n.arguments) == 2 && flags.Commutative','')
dst=w/'flags.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=w/'flags.json';overlay.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
for label,opts in [('before',[]),('flags',['-overlay',overlay])]:
    subprocess.run(['go','test','-c','-pgo=off',*opts,'-o',w/(label+'-bench'),'./smtcore'],env=env,check=True)
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',overlay,'-o',w/'flags','./cmd/goivy_check'],cwd=base/'frontend/goivy',env=env,check=True)
