"""Try recognizing satisfied binary gate clauses before sorting the literals."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent
pkg=Path.cwd();base=w.parent/'.boolean-enode-cost'
f=pkg/'smtcore/smt_internalizer.go';s=f.read_text()
old='return s.addWrappedProofClause(literals, false, proof)'
assert s.count(old)==1
s=s.replace(old,'''if proof.IsNull() && len(literals)==2 {
        a,b:=literals[0].Index(),literals[1].Index()
        if uint(a)<uint(len(s.assignment)) && uint(b)<uint(len(s.assignment)) &&
            (s.assignment[a]==lbool.True || s.assignment[b]==lbool.True) && s.open()==nil {return nil}
    }
    '''+old)
dst=w/'satisfied.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/'satisfied.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'satisfied','./cmd/goivy_check'],cwd=base/'frontend/goivy',env=env,check=True)
