"""Measure constructor instructions with two trip counts to subtract setup."""
from pathlib import Path
import csv,os,re,subprocess,sys
w=Path(__file__).resolve().parent
out=csv.writer(sys.stdout)
out.writerow(['round','arity','build','n','instructions','ns','bytes','allocs'])
for i in range(7):
    for a in [0,1,2,3,8]:
        for label in (['before','flags'] if i%2==0 else ['flags','before']):
            for n in [10000,100000]:
                p=subprocess.run(['taskset','-c','16','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-e','instructions:u','--',w/(label+'-bench'),'-test.run=^$','-test.bench=^BenchmarkSMTEnodeCreation$/^'+str(a)+'$','-test.benchtime='+str(n)+'x'],env=dict(os.environ,GOMAXPROCS='1',GOGC='off'),text=True,capture_output=True,check=True)
                hw=next(row for row in csv.reader(p.stderr.splitlines()) if len(row)>4 and row[2]=='instructions:u')
                assert float(hw[4])==100
                m=re.search(r'^BenchmarkSMTEnodeCreation/\d+\s+\d+\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M)
                out.writerow([i+1,a,label,n,hw[0],*m.groups()])
                sys.stdout.flush()
