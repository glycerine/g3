(set-info :status unknown)
(declare-datatypes ((op_type 0)) ((op_type (nop) (write) (read) (rrsp) (wr_cmp))))
 (declare-sort tar_cf_clock)
 (declare-sort tar_clock)
 (declare-datatypes ((loc_type 0)) ((loc_type (init_l) (cf_mem_l) (cf_pio_l) (cf_cmp_l) (if_l) (memc_l) (dramc_l) (arm_l))))
 (declare-datatypes ((mem_loc_type 0)) ((mem_loc_type (mem_loc_init) (mem_memc) (pio_memc))))
 (declare-sort mem_type)
 (declare-sort addr_type)
 (declare-sort proc)
 (declare-datatypes ((ph_type 0)) ((ph_type (nop_ph) (wr_ph) (rd_ph) (cpl_ph))))
 (declare-sort lclock)
 (declare-fun ref.lt () lclock)
(declare-fun cfabric.t_rd_min () lclock)
(declare-fun __memc_lt_min () lclock)
(declare-fun __memc_blocking () lclock)
(declare-fun dramc_lt_min () lclock)
(declare-fun _T () lclock)
(declare-fun ref.lt_tar_cf () tar_cf_clock)
(declare-fun cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun ref.evs.cmp (lclock) op_type)
(declare-fun ref.evs.req (lclock) op_type)
(declare-fun |0:lclock| () lclock)
(declare-fun |0:tar_cf_clock| () tar_cf_clock)
(declare-fun __ref.evs.l_req (lclock) loc_type)
(declare-fun __ref.evs.l_cmp (lclock) loc_type)
(declare-fun |0:tar_clock| () tar_clock)
(declare-fun ref.evs.lt_arr (lclock) tar_clock)
(declare-fun ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun ref.evs.a (lclock) addr_type)
(declare-fun ref.evs.m (lclock) mem_type)
(declare-fun ref.evs.p (lclock) proc)
(declare-fun _P () proc)
(declare-fun |__loc:tt| () lclock)
(declare-fun |__loc:aa| () addr_type)
(declare-fun |__loc:mm| () mem_type)
(declare-fun |__fml:p| () proc)
(declare-fun |__loc:t4| () lclock)
(declare-fun |__loc:aa_a| () addr_type)
(declare-fun |__loc:mm_a| () mem_type)
(declare-fun |__loc:pp| () proc)
(declare-fun ref.evs.l_req (lclock) loc_type)
(declare-fun |__loc:t5| () lclock)
(declare-fun |__loc:aa_a_a| () addr_type)
(declare-fun |__new_loc:mz| () mem_type)
(declare-fun |__loc:pp_a| () proc)
(declare-fun |__loc:t6| () lclock)
(declare-fun memc_lt_min () lclock)
(declare-fun ref.evs.l_cmp (lclock) loc_type)
(declare-fun |__loc:t| () lclock)
(declare-fun |__fml:lt| () lclock)
(declare-fun |__new_loc:t| () lclock)
(declare-fun |__fml:ph| () ph_type)
(declare-fun memc_blocking () lclock)
(declare-fun @T () lclock)
(declare-fun cfabric.cpl_fair () Bool)
(declare-fun cfabric.rd_fair () Bool)
(declare-fun cfabric.wr_fair () Bool)
(declare-fun cfabric.rd_pio_fair () Bool)
(declare-fun cfabric.wr_pio_fair () Bool)
(declare-fun __l2s_d (lclock) Bool)
(declare-fun |work_created[1a]| (lclock) Bool)
(declare-fun l2s_g_17 () Bool)
(declare-fun |work_invar[0a]| () Bool)
(declare-fun __l2s_d_a (tar_cf_clock) Bool)
(declare-fun l2s_g_19 () Bool)
(declare-fun l2s_init_9 () Bool)
(declare-fun l2s_g_20 () Bool)
(declare-fun l2s_init_10 () Bool)
(declare-fun l2s_g_21 () Bool)
(declare-fun l2s_init_11 () Bool)
(declare-fun l2s_g_23 () Bool)
(declare-fun l2s_init_13 () Bool)
(declare-fun l2s_g_22 () Bool)
(declare-fun l2s_init_12 () Bool)
(declare-fun l2s_g_24 () Bool)
(declare-fun l2s_init_14 () Bool)
(declare-fun l2s_init_8 () Bool)
(declare-fun ref.evs.serialized (lclock) Bool)
(declare-fun |<:lclock:lclock| (lclock lclock) Bool)
(declare-fun __sys_live.cf_pio_req (lclock) Bool)
(declare-fun sys_live.is_io (lclock) Bool)
(declare-fun sys_live.pending (lclock) Bool)
(declare-fun |__work_needed[1a]| (lclock) Bool)
(declare-fun l2s_g_16 () Bool)
(declare-fun arm.cpl_fair (proc) Bool)
(declare-fun l2s_g_18 () Bool)
(declare-fun l2s_g_25 () Bool)
(declare-fun l2s_g_26 () Bool)
(declare-fun l2s_g_27 () Bool)
(declare-fun l2s_g_28 () Bool)
(declare-fun l2s_g_29 () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0__ts0_b () Bool)
(declare-fun __ts0__ts0_c_a () Bool)
(declare-fun isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun __ts0_b_a () Bool)
(declare-fun __ts0_b_b () Bool)
(declare-fun __ts0_a_b () Bool)
(declare-fun __ts0_b_a_a () Bool)
(declare-fun __ts0_a_a_a () Bool)
(declare-fun __ts0_b_a_a_a () Bool)
(declare-fun __ts0_a_a_a_a () Bool)
(declare-fun |work_invar[0b]| () Bool)
(declare-fun |work_invar[1a]| () Bool)
(declare-fun |work_invar[1b]| () Bool)
(declare-fun |work_invar[4a]| () Bool)
(declare-fun |work_invar[4b]| () Bool)
(declare-fun |work_invar[5a]| () Bool)
(declare-fun |work_invar[5b]| () Bool)
(declare-fun |work_invar[6a]| () Bool)
(declare-fun |work_invar[6b]| () Bool)
(declare-fun |work_invar[7]| () Bool)
(declare-fun |work_invar[7a]| () Bool)
(declare-fun |work_invar[8]| () Bool)
(declare-fun |work_invar[9]| () Bool)
(declare-fun l2s_w_9 () Bool)
(declare-fun l2s_w_11 () Bool)
(declare-fun l2s_w_13 () Bool)
(declare-fun l2s_w_12 () Bool)
(declare-fun l2s_w_14 () Bool)
(declare-fun l2s_w_10 () Bool)
(declare-fun l2s_w_8 () Bool)
(declare-fun |__m_loc:wr| () Bool)
(declare-fun |__m_loc:rd| () Bool)
(declare-fun |__m_loc:cmp| () Bool)
(declare-fun |__new_loc:rd| () Bool)
(declare-fun __ts0__ts0__ts0__ts0_a_a_a () Bool)
(declare-fun __ts0__ts0__ts0_b_a_a () Bool)
(declare-fun |__new_loc:wr| () Bool)
(declare-fun |__new_loc:cmp| () Bool)
(declare-fun |__new_loc:ordpip1| () Bool)
(declare-fun |__new_loc:ordpip0| () Bool)
(declare-fun |__new_loc:ordpip| () Bool)
(assert
 (not cfabric.cpl_fair))
(assert
 (not cfabric.rd_fair))
(assert
 (not cfabric.wr_fair))
(assert
 (not cfabric.rd_pio_fair))
(assert
 (not cfabric.wr_pio_fair))
(assert
 (forall ((|T:lclock| lclock) )(let (($x2488 (__l2s_d |T:lclock|)))
 (let (($x2890 (and $x2488)))
 (=> (|work_created[1a]| |T:lclock|) $x2890))))
 )
(assert
 (let (($x2576 (not l2s_g_17)))
 (=> (not |work_invar[0a]|) $x2576)))
(assert
 (__l2s_d ref.lt))
(assert
 (__l2s_d cfabric.t_rd_min))
(assert
 (__l2s_d __memc_lt_min))
(assert
 (__l2s_d __memc_blocking))
(assert
 (__l2s_d dramc_lt_min))
(assert
 (__l2s_d _T))
(assert
 (__l2s_d_a ref.lt_tar_cf))
(assert
 (__l2s_d_a cfabric.t_rd_arr_min))
(assert
 (=> l2s_init_9 l2s_g_19))
(assert
 (=> l2s_init_10 l2s_g_20))
(assert
 (=> l2s_init_11 l2s_g_21))
(assert
 (=> l2s_init_13 l2s_g_23))
(assert
 (=> l2s_init_12 l2s_g_22))
(assert
 (=> l2s_init_14 l2s_g_24))
(assert
 (=> l2s_init_8 l2s_g_17))
(assert
 (forall ((|T:lclock| lclock) )(=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|))) (not (and (= (ref.evs.req |T:lclock|) nop) (= (ref.evs.cmp |T:lclock|) nop)))))
 )
(assert
 (let (($x2331 (= ref.lt_tar_cf |0:tar_cf_clock|)))
 (let (($x2324 (= ref.lt |0:lclock|)))
 (=> $x2324 $x2331))))
(assert
 (= (ref.evs.req |0:lclock|) nop))
(assert
 (= (__ref.evs.l_req |0:lclock|) init_l))
(assert
 (= (ref.evs.cmp |0:lclock|) nop))
(assert
 (= (__ref.evs.l_cmp |0:lclock|) init_l))
(assert
 (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|))
(assert
 (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|))
(assert
 (forall ((|T:lclock| lclock) )(let (($x274 (ref.evs.serialized |T:lclock|)))
 (let ((?x357 (ref.evs.cmp |T:lclock|)))
 (let (($x2338 (= ?x357 nop)))
 (let ((?x521 (ref.evs.req |T:lclock|)))
 (let (($x2334 (= ?x521 nop)))
 (let (($x3059 (= |T:lclock| |0:lclock|)))
 (let (($x3792 (or $x3059 (|<:lclock:lclock| ref.lt |T:lclock|))))
 (=> $x3792 (and $x2334 $x2338 $x274))))))))))
 )
(assert
 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock) )(let ((?x2098 (__ref.evs.l_req |T1:lclock|)))
 (let (($x2299 (= ?x2098 cf_pio_l)))
 (let (($x2261 (= ?x2098 if_l)))
 (let (($x2285 (= ?x2098 memc_l)))
 (let ((?x7590 (__ref.evs.l_req |T0:lclock|)))
 (let (($x7787 (= ?x7590 memc_l)))
 (let (($x7882 (or (and (= ?x7590 cf_pio_l) $x2299) (and (= ?x7590 if_l) (or $x2261 $x2299)) (and $x7787 (or $x2285 $x2261 $x2299)))))
 (let (($x259 (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
 (let ((?x353 (ref.evs.mem_loc |T1:lclock|)))
 (let (($x578 (= ?x353 pio_memc)))
 (let ((?x355 (ref.evs.mem_loc |T0:lclock|)))
 (let (($x3551 (= ?x355 pio_memc)))
 (let ((?x276 (ref.evs.a |T1:lclock|)))
 (let (($x258 (= (ref.evs.a |T0:lclock|) ?x276)))
 (let ((?x253 (ref.evs.m |T1:lclock|)))
 (let ((?x332 (ref.evs.m |T0:lclock|)))
 (let (($x333 (= ?x332 ?x253)))
 (let ((?x335 (ref.evs.p |T1:lclock|)))
 (let (($x337 (= (ref.evs.p |T0:lclock|) ?x335)))
 (let (($x3505 (or (and (= (ref.evs.req |T0:lclock|) write) (= (ref.evs.req |T1:lclock|) write)) (and (= (ref.evs.req |T0:lclock|) read) (= (ref.evs.req |T1:lclock|) read)))))
 (=> (and $x3505 $x337 $x333 $x258 $x3551 $x578 $x259) $x7882))))))))))))))))))))))
 )
(assert
 (forall ((|T:lclock| lclock) )(let (($x821 (__sys_live.cf_pio_req |T:lclock|)))
 (let (($x579 (sys_live.is_io |T:lclock|)))
 (let (($x474 (sys_live.pending |T:lclock|)))
 (let (($x783 (or (= |T:lclock| _T) (|<:lclock:lclock| |T:lclock| _T))))
 (let (($x1251 (and $x783 $x474)))
 (let (($x1878 (and $x1251 $x579)))
 (let (($x824 (|__work_needed[1a]| |T:lclock|)))
 (= $x824 (and $x1878 $x821))))))))))
 )
(assert
 (let (($x1696 (sys_live.pending _T)))
 (=> l2s_g_16 $x1696)))
(assert
 (let (($x1700 (not l2s_g_16)))
 (let (($x1701 (=> (and (= (ref.evs.p _T) _P) (sys_live.pending _T)) $x1700)))
 (=> (and l2s_g_17 (and (= (ref.evs.p _T) _P) (sys_live.pending _T))) $x1700))))
(assert
 (let (($x1705 (not (arm.cpl_fair _P))))
 (=> l2s_g_18 $x1705)))
(assert
 (let (($x1708 (not l2s_g_18)))
 (=> l2s_g_19 $x1708)))
(assert
 (let (($x1712 (not l2s_g_25)))
 (=> l2s_g_20 $x1712)))
(assert
 (let (($x1716 (not l2s_g_26)))
 (=> l2s_g_21 $x1716)))
(assert
 (let (($x1720 (not l2s_g_27)))
 (=> l2s_g_22 $x1720)))
(assert
 (let (($x1724 (not l2s_g_28)))
 (=> l2s_g_23 $x1724)))
(assert
 (let (($x1728 (not l2s_g_29)))
 (=> l2s_g_24 $x1728)))
(assert
 (let (($x1731 (not cfabric.cpl_fair)))
 (=> l2s_g_25 $x1731)))
(assert
 (let (($x1734 (not cfabric.rd_fair)))
 (=> l2s_g_26 $x1734)))
(assert
 (let (($x1737 (not cfabric.rd_pio_fair)))
 (=> l2s_g_27 $x1737)))
(assert
 (let (($x1740 (not cfabric.wr_fair)))
 (=> l2s_g_28 $x1740)))
(assert
 (let (($x1743 (not cfabric.wr_pio_fair)))
 (=> l2s_g_29 $x1743)))
(assert
 (let (($x8233 (or __ts0_a __ts0_b)))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x8233))))
(assert
 (let (($x3989 (not __ts0_d)))
 (or $x3989 (or (not __ts0_a) (isd.rd |__fml:p| |__loc:mm| |__loc:aa| |__loc:tt|)))))
(assert
 (let ((?x3988 (ref.evs.req |__loc:tt|)))
 (let (($x3987 (= ?x3988 read)))
 (let (($x5341 (not __ts0_a)))
 (let (($x8243 (or $x5341 $x3987)))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x8243)))))))
(assert
 (let (($x5341 (not __ts0_a)))
 (let (($x89650 (or $x5341 (= (__ref.evs.l_req |__loc:tt|) if_l))))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x89650)))))
(assert
 (or __ts0_d (or (not __ts0__ts0_c_a) (or __ts0_a __ts0__ts0_b))))
(assert
 (let (($x4793 (not __ts0__ts0_c_a)))
 (let (($x100580 (or $x4793 (or (not __ts0_a) (isd.wr |__fml:p| |__loc:mm| |__loc:aa| |__loc:tt|)))))
 (or __ts0_d $x100580))))
(assert
 (let ((?x3988 (ref.evs.req |__loc:tt|)))
 (let (($x3986 (= ?x3988 write)))
 (let (($x5341 (not __ts0_a)))
 (let (($x8349 (or $x5341 $x3986)))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 $x8349))))))))
(assert
 (let (($x5341 (not __ts0_a)))
 (let (($x89650 (or $x5341 (= (__ref.evs.l_req |__loc:tt|) if_l))))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 $x89650))))))
(assert
 (let (($x8473 (not __ts0_b_a)))
 (or $x8473 (or __ts0_a_a false))))
(assert
 (or __ts0_a_b __ts0_b_b))
(assert
 (let ((?x8720 (ref.evs.req |__loc:t4|)))
 (let (($x8724 (= ?x8720 read)))
 (let (($x8721 (= ?x8720 write)))
 (let (($x13835 (or (and (isd.wr |__loc:pp| |__loc:mm_a| |__loc:aa_a| |__loc:t4|) $x8721) (and (isd.rd |__loc:pp| |__loc:mm_a| |__loc:aa_a| |__loc:t4|) $x8724))))
 (let (($x8714 (not __ts0_a_b)))
 (or $x8714 $x13835)))))))
(assert
 (let (($x8714 (not __ts0_a_b)))
 (or $x8714 (= (ref.evs.l_req |__loc:t4|) memc_l))))
(assert
 (or __ts0_a_a_a __ts0_b_a_a))
(assert
 (let ((?x8785 (ref.evs.req |__loc:t5|)))
 (let (($x8789 (= ?x8785 read)))
 (let (($x8786 (= ?x8785 write)))
 (let (($x14508 (or (and (isd.wr |__loc:pp_a| |__new_loc:mz| |__loc:aa_a_a| |__loc:t5|) $x8786) (and (isd.rd |__loc:pp_a| |__new_loc:mz| |__loc:aa_a_a| |__loc:t5|) $x8789))))
 (let (($x8779 (not __ts0_a_a_a)))
 (or $x8779 $x14508)))))))
(assert
 (let (($x8779 (not __ts0_a_a_a)))
 (or $x8779 (= (ref.evs.l_req |__loc:t5|) dramc_l))))
(assert
 (or __ts0_a_a_a_a __ts0_b_a_a_a))
(assert
 (let (($x8839 (or (= (ref.evs.req |__loc:t6|) write) (= (ref.evs.req |__loc:t6|) read))))
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 $x8839))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.l_req |__loc:t6|) dramc_l))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.m |__loc:t6|) (ref.evs.m memc_lt_min)))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.a |__loc:t6|) (ref.evs.a memc_lt_min)))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.req |__loc:t6|) (ref.evs.req memc_lt_min)))))
(assert
 (= (ref.evs.l_req |0:lclock|) init_l))
(assert
 (= (ref.evs.l_cmp |0:lclock|) init_l))
(assert
 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock) )(let ((?x302 (ref.evs.l_req |T1:lclock|)))
 (let (($x569 (= ?x302 cf_pio_l)))
 (let (($x520 (= ?x302 if_l)))
 (let (($x551 (= ?x302 memc_l)))
 (let ((?x2983 (ref.evs.l_req |T0:lclock|)))
 (let (($x3312 (= ?x2983 memc_l)))
 (let (($x3550 (or (and (= ?x2983 cf_pio_l) $x569) (and (= ?x2983 if_l) (or $x520 $x569)) (and $x3312 (or $x551 $x520 $x569)))))
 (let (($x259 (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
 (let ((?x353 (ref.evs.mem_loc |T1:lclock|)))
 (let (($x578 (= ?x353 pio_memc)))
 (let ((?x355 (ref.evs.mem_loc |T0:lclock|)))
 (let (($x3551 (= ?x355 pio_memc)))
 (let ((?x276 (ref.evs.a |T1:lclock|)))
 (let (($x258 (= (ref.evs.a |T0:lclock|) ?x276)))
 (let ((?x253 (ref.evs.m |T1:lclock|)))
 (let ((?x332 (ref.evs.m |T0:lclock|)))
 (let (($x333 (= ?x332 ?x253)))
 (let ((?x335 (ref.evs.p |T1:lclock|)))
 (let (($x337 (= (ref.evs.p |T0:lclock|) ?x335)))
 (let (($x3505 (or (and (= (ref.evs.req |T0:lclock|) write) (= (ref.evs.req |T1:lclock|) write)) (and (= (ref.evs.req |T0:lclock|) read) (= (ref.evs.req |T1:lclock|) read)))))
 (=> (and $x3505 $x337 $x333 $x258 $x3551 $x578 $x259) $x3550))))))))))))))))))))))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) (|V:lclock| lclock) )(=> (and (|<:lclock:lclock| |T:lclock| |U:lclock|) (|<:lclock:lclock| |U:lclock| |V:lclock|)) (|<:lclock:lclock| |T:lclock| |V:lclock|)))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) )(not (and (|<:lclock:lclock| |T:lclock| |U:lclock|) (|<:lclock:lclock| |U:lclock| |T:lclock|))))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) )(let (($x298 (|<:lclock:lclock| |U:lclock| |T:lclock|)))
 (let (($x641 (= |T:lclock| |U:lclock|)))
 (let (($x259 (|<:lclock:lclock| |T:lclock| |U:lclock|)))
 (or $x259 $x641 $x298)))))
 )
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[0a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[0b]| $x1855)))
(assert
 (forall ((|T:lclock| lclock) )(let (($x1837 (= |T:lclock| ref.lt)))
 (let (($x1838 (or $x1837 (|<:lclock:lclock| |T:lclock| ref.lt))))
 (= (|work_created[1a]| |T:lclock|) $x1838))))
 )
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[1a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[1b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[4a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[4b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[5a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[5b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[6a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[6b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[7]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[7a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[8]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[9]| $x1855)))
(assert
 (forall ((|T:lclock| lclock) )(let ((?x2098 (__ref.evs.l_req |T:lclock|)))
 (let (($x2299 (= ?x2098 cf_pio_l)))
 (let ((?x521 (ref.evs.req |T:lclock|)))
 (let (($x522 (= ?x521 write)))
 (let (($x523 (= ?x521 read)))
 (let (($x524 (or $x523 $x522)))
 (let (($x821 (__sys_live.cf_pio_req |T:lclock|)))
 (= $x821 (and $x524 $x2299))))))))))
 )
(assert
 (let (($x2576 (not l2s_g_17)))
 (let (($x1700 (not l2s_g_16)))
 (let (($x1701 (=> (and (= (ref.evs.p _T) _P) (sys_live.pending _T)) $x1700)))
 (let (($x2575 (not (not $x1701))))
 (= l2s_w_9 (and $x2575 $x2576)))))))
(assert
 (= l2s_w_11 (and (not cfabric.rd_fair) (not l2s_g_26))))
(assert
 (= l2s_w_13 (and (not cfabric.wr_fair) (not l2s_g_28))))
(assert
 (= l2s_w_12 (and (not cfabric.rd_pio_fair) (not l2s_g_27))))
(assert
 (= l2s_w_14 (and (not cfabric.wr_pio_fair) (not l2s_g_29))))
(assert
 (= l2s_w_10 (and (not cfabric.cpl_fair) (not l2s_g_25))))
(assert
 (= l2s_w_8 (and (not (arm.cpl_fair _P)) (not l2s_g_18))))
(assert
 (not |__m_loc:wr|))
(assert
 (not |__m_loc:rd|))
(assert
 (not |__m_loc:cmp|))
(assert
 (= |__new_loc:rd| (ite __ts0_d (ite __ts0_b |__m_loc:rd| true) |__m_loc:rd|)))
(assert
 (let ((?x14625 (ite __ts0__ts0__ts0_b_a_a (ite __ts0__ts0__ts0__ts0_a_a_a |__fml:lt| |__loc:t|) |__loc:t|)))
 (let ((?x9010 (ite __ts0_b |__loc:t| |__loc:tt|)))
 (let ((?x87988 (ite __ts0_d ?x9010 (ite __ts0__ts0_c_a (ite __ts0__ts0_b |__loc:t| |__loc:tt|) ?x14625))))
 (= |__new_loc:t| ?x87988)))))
(assert
 (let (($x11832 (ite __ts0__ts0_c_a (ite __ts0__ts0_b |__m_loc:wr| true) |__m_loc:wr|)))
 (= |__new_loc:wr| (ite __ts0_d |__m_loc:wr| $x11832))))
(assert
 (let (($x11897 (ite __ts0__ts0__ts0_b_a_a (or __ts0__ts0__ts0__ts0_a_a_a |__m_loc:cmp|) |__m_loc:cmp|)))
 (= |__new_loc:cmp| (ite __ts0_d |__m_loc:cmp| (ite __ts0__ts0_c_a |__m_loc:cmp| $x11897)))))
(assert
 (= __ts0__ts0__ts0__ts0_a_a_a (= (__ref.evs.l_cmp |__fml:lt|) if_l)))
(assert
 (let (($x6720 (= |__fml:ph| cpl_ph)))
 (= __ts0__ts0__ts0_b_a_a $x6720)))
(assert
 (let (($x4749 (= |__fml:ph| wr_ph)))
 (= __ts0__ts0_c_a $x4749)))
(assert
 (let (($x4747 (= |__fml:ph| rd_ph)))
 (= __ts0_d $x4747)))
(assert
 (= |__new_loc:ordpip| (or |__new_loc:ordpip0| |__new_loc:ordpip1|)))
(assert
 (let ((?x8476 (ref.evs.mem_loc |__new_loc:t|)))
 (let (($x8477 (= ?x8476 pio_memc)))
 (let (($x9057 (= ?x8476 mem_memc)))
 (= __ts0_a_a (ite __ts0_b_a (or $x9057 $x8477) |__new_loc:cmp|))))))
(assert
 (= __ts0_b_a (and (or |__new_loc:rd| |__new_loc:wr|) (not |__new_loc:ordpip|))))
(assert
 (= memc_lt_min (ite __ts0_b_b __memc_lt_min |__loc:t4|)))
(assert
 (let ((?x3294 (ref.evs.m memc_lt_min)))
 (= |__new_loc:mz| ?x3294)))
(assert
 (= memc_blocking (ite __ts0_b_a_a_a __memc_blocking |__loc:t6|)))
(assert
 (forall ((|T:lclock| lclock) )(let (($x473 (or (isd.rd (ref.evs.p |T:lclock|) (ref.evs.m |T:lclock|) (ref.evs.a |T:lclock|) |T:lclock|) (isd.wr (ref.evs.p |T:lclock|) (ref.evs.m |T:lclock|) (ref.evs.a |T:lclock|) |T:lclock|))))
 (let (($x474 (sys_live.pending |T:lclock|)))
 (= $x474 $x473))))
 )
(assert
 (forall ((|T:lclock| lclock) )(let ((?x353 (ref.evs.mem_loc |T:lclock|)))
 (let (($x578 (= ?x353 pio_memc)))
 (let (($x579 (sys_live.is_io |T:lclock|)))
 (= $x579 $x578)))))
 )
(assert
 (let (($x2713 (|work_created[1a]| @T)))
 (and (not (=> (and |work_invar[1a]| (|__work_needed[1a]| @T)) $x2713)))))
(check-sat)
