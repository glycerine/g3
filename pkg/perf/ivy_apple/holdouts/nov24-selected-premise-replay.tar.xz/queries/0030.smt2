(set-info :status unknown)
(declare-datatypes ((op_type 0)) ((op_type (nop) (write) (read) (rrsp) (wr_cmp))))
 (declare-sort tar_cf_clock)
 (declare-sort tar_clock)
 (declare-datatypes ((loc_type 0)) ((loc_type (init_l) (cf_mem_l) (cf_pio_l) (cf_cmp_l) (if_l) (memc_l) (dramc_l) (arm_l))))
 (declare-datatypes ((mem_loc_type 0)) ((mem_loc_type (mem_loc_init) (mem_memc) (pio_memc))))
 (declare-sort mem_type)
 (declare-sort addr_type)
 (declare-sort proc)
 (declare-datatypes ((ph_type 0)) ((ph_type (nop_ph) (wr_ph) (rd_ph) (cpl_ph))))
 (declare-sort lclock)
 (declare-fun ref.lt () lclock)
(declare-fun cfabric.t_rd_min () lclock)
(declare-fun __memc_lt_min () lclock)
(declare-fun __memc_blocking () lclock)
(declare-fun __dramc_lt_min () lclock)
(declare-fun _T () lclock)
(declare-fun ref.lt_tar_cf () tar_cf_clock)
(declare-fun cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun __ref.evs.cmp (lclock) op_type)
(declare-fun __ref.evs.req (lclock) op_type)
(declare-fun |0:lclock| () lclock)
(declare-fun |0:tar_cf_clock| () tar_cf_clock)
(declare-fun __ref.evs.l_req (lclock) loc_type)
(declare-fun __ref.evs.l_cmp (lclock) loc_type)
(declare-fun |0:tar_clock| () tar_clock)
(declare-fun __ref.evs.lt_arr (lclock) tar_clock)
(declare-fun ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun _P () proc)
(declare-fun ref.evs.p (lclock) proc)
(declare-fun |__loc:t| () lclock)
(declare-fun |__fml:a| () addr_type)
(declare-fun |__fml:m| () mem_type)
(declare-fun |__loc:pp| () proc)
(declare-fun |__fml:y| () tar_clock)
(declare-fun |__ts0__ts0__ts0__new_fml:x_a| () tar_clock)
(declare-fun |__ts0__ts0__new_fml:lt_b| () lclock)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_a| () tar_clock)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| () tar_clock)
(declare-fun |__ts0__ts0__ts0__ts0__new_fml:x_a| () tar_clock)
(declare-fun |__ts0__ts0__ts0__new_fml:lt_b| () lclock)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_b| () tar_clock)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| () tar_clock)
(declare-fun ref.evs.req (lclock) op_type)
(declare-fun |__loc:t3| () lclock)
(declare-fun |__loc:aa| () addr_type)
(declare-fun |__loc:pp_a| () proc)
(declare-fun ref.evs.l_req (lclock) loc_type)
(declare-fun |__loc:t4| () lclock)
(declare-fun |__loc:aa_a| () addr_type)
(declare-fun |__loc:mm| () mem_type)
(declare-fun |__loc:pp_b| () proc)
(declare-fun |__loc:t5| () lclock)
(declare-fun |__loc:aa_a_a| () addr_type)
(declare-fun |__new_loc:mz| () mem_type)
(declare-fun |__loc:pp_a_a| () proc)
(declare-fun |__loc:t4_a| () lclock)
(declare-fun |__loc:aa_b| () addr_type)
(declare-fun |__loc:mm_a| () mem_type)
(declare-fun |__loc:pp_c| () proc)
(declare-fun |__loc:t5_a| () lclock)
(declare-fun |__loc:aa_a_b| () addr_type)
(declare-fun |__new_loc:mz_a| () mem_type)
(declare-fun |__loc:pp_a_b| () proc)
(declare-fun |__loc:t6| () lclock)
(declare-fun ref.evs.m (lclock) mem_type)
(declare-fun memc_lt_min () lclock)
(declare-fun ref.evs.a (lclock) addr_type)
(declare-fun ref.evs.cmp (lclock) op_type)
(declare-fun ref.evs.l_cmp (lclock) loc_type)
(declare-fun ref.evs.lt_arr (lclock) tar_clock)
(declare-fun ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun |__ts0__m_loc:tt_a| () lclock)
(declare-fun |__loc:tt| () lclock)
(declare-fun |__ts0__ts0__m_loc:tt_a| () lclock)
(declare-fun |__new_loc:tt| () lclock)
(declare-fun |__ts0__ts0__new_fml:lt_a_a| () lclock)
(declare-fun __ref.lt_tar (mem_type) tar_clock)
(declare-fun |__ts0__ts0__ts0__new_loc:a_a_a| () addr_type)
(declare-fun |__ts0__ts0__ts0__new_loc:m_a_a| () mem_type)
(declare-fun |__ts0__ts0__ts0__new_fml:lt_a_a| () lclock)
(declare-fun |__ts0__ts0__ts0__ts0__new_loc:a_a_a| () addr_type)
(declare-fun |__ts0__ts0__ts0__ts0__new_loc:m_a_a| () mem_type)
(declare-fun |__fml:lt| () lclock)
(declare-fun |__ts0__ts0__ts0__new_loc:t_a_a| () lclock)
(declare-fun |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a| () lclock)
(declare-fun |__fml:p| () proc)
(declare-fun |__fml:ph| () ph_type)
(declare-fun dramc_lt_min () lclock)
(declare-fun memc_blocking () lclock)
(declare-fun @T () lclock)
(declare-fun cfabric.cpl_fair () Bool)
(declare-fun cfabric.rd_fair () Bool)
(declare-fun cfabric.wr_fair () Bool)
(declare-fun cfabric.rd_pio_fair () Bool)
(declare-fun cfabric.wr_pio_fair () Bool)
(declare-fun __l2s_d (lclock) Bool)
(declare-fun |work_created[1b]| (lclock) Bool)
(declare-fun l2s_g_17 () Bool)
(declare-fun |work_invar[0a]| () Bool)
(declare-fun __l2s_d_a (tar_cf_clock) Bool)
(declare-fun l2s_g_19 () Bool)
(declare-fun l2s_init_9 () Bool)
(declare-fun l2s_g_20 () Bool)
(declare-fun l2s_init_10 () Bool)
(declare-fun l2s_g_21 () Bool)
(declare-fun l2s_init_11 () Bool)
(declare-fun l2s_g_23 () Bool)
(declare-fun l2s_init_13 () Bool)
(declare-fun l2s_g_22 () Bool)
(declare-fun l2s_init_12 () Bool)
(declare-fun l2s_g_24 () Bool)
(declare-fun l2s_init_14 () Bool)
(declare-fun l2s_init_8 () Bool)
(declare-fun __ref.evs.serialized (lclock) Bool)
(declare-fun |<:lclock:lclock| (lclock lclock) Bool)
(declare-fun __sys_live.cf_pio_req (lclock) Bool)
(declare-fun sys_live.is_io (lclock) Bool)
(declare-fun sys_live.pending (lclock) Bool)
(declare-fun |__work_needed[1b]| (lclock) Bool)
(declare-fun l2s_g_16 () Bool)
(declare-fun arm.cpl_fair (proc) Bool)
(declare-fun l2s_g_18 () Bool)
(declare-fun l2s_g_25 () Bool)
(declare-fun l2s_g_26 () Bool)
(declare-fun l2s_g_27 () Bool)
(declare-fun l2s_g_28 () Bool)
(declare-fun l2s_g_29 () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun isd.rd (proc mem_type addr_type lclock) Bool)
(declare-fun |<:tar_clock:tar_clock| (tar_clock tar_clock) Bool)
(declare-fun __ts0__ts0_a_a_a () Bool)
(declare-fun __ts0__ts0_b_a_a () Bool)
(declare-fun tar_clock.succ (tar_clock tar_clock) Bool)
(declare-fun __ts0__ts0__ts0__ts0_b_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0_a_a_a_a () Bool)
(declare-fun __ts0__ts0_b () Bool)
(declare-fun __ts0__ts0_c_a () Bool)
(declare-fun isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun __ts0__ts0__ts0_a_a_b () Bool)
(declare-fun __ts0__ts0__ts0_b_a_b () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0_b_a_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a () Bool)
(declare-fun __ts0_b_a () Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun __ts0_b_b () Bool)
(declare-fun __ts0_a_b () Bool)
(declare-fun __ts0_b_a_a () Bool)
(declare-fun __ts0_a_a_a () Bool)
(declare-fun __ts0_b_c () Bool)
(declare-fun __ts0_a_c () Bool)
(declare-fun __ts0_b_a_b () Bool)
(declare-fun __ts0_a_a_b () Bool)
(declare-fun __ts0_b_a_a_a () Bool)
(declare-fun __ts0_a_a_a_a () Bool)
(declare-fun ref.evs.serialized (lclock) Bool)
(declare-fun |work_invar[0b]| () Bool)
(declare-fun |work_invar[1a]| () Bool)
(declare-fun |work_invar[1b]| () Bool)
(declare-fun |work_invar[4a]| () Bool)
(declare-fun |work_invar[4b]| () Bool)
(declare-fun |work_invar[5a]| () Bool)
(declare-fun |work_invar[5b]| () Bool)
(declare-fun |work_invar[6a]| () Bool)
(declare-fun |work_invar[6b]| () Bool)
(declare-fun |work_invar[7]| () Bool)
(declare-fun |work_invar[7a]| () Bool)
(declare-fun |work_invar[8]| () Bool)
(declare-fun |work_invar[9]| () Bool)
(declare-fun l2s_w_9 () Bool)
(declare-fun l2s_w_11 () Bool)
(declare-fun l2s_w_13 () Bool)
(declare-fun l2s_w_12 () Bool)
(declare-fun l2s_w_14 () Bool)
(declare-fun l2s_w_10 () Bool)
(declare-fun l2s_w_8 () Bool)
(declare-fun |__ts0__m_loc:ordpip_a| () Bool)
(declare-fun |__loc:ordpip| () Bool)
(declare-fun |__ts0__ts0__m_loc:ordpip_a| () Bool)
(declare-fun |__new_loc:ordpip| () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0__ts0_a_a_b_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0__ts0_b_b_a () Bool)
(declare-fun __ts0__ts0__ts0__ts0_a_a_b () Bool)
(assert
 (not cfabric.cpl_fair))
(assert
 (not cfabric.rd_fair))
(assert
 (not cfabric.wr_fair))
(assert
 (not cfabric.rd_pio_fair))
(assert
 (not cfabric.wr_pio_fair))
(assert
 (forall ((|T:lclock| lclock) )(let (($x2488 (__l2s_d |T:lclock|)))
 (let (($x2890 (and $x2488)))
 (=> (|work_created[1b]| |T:lclock|) $x2890))))
 )
(assert
 (let (($x2576 (not l2s_g_17)))
 (=> (not |work_invar[0a]|) $x2576)))
(assert
 (__l2s_d ref.lt))
(assert
 (__l2s_d cfabric.t_rd_min))
(assert
 (__l2s_d __memc_lt_min))
(assert
 (__l2s_d __memc_blocking))
(assert
 (__l2s_d __dramc_lt_min))
(assert
 (__l2s_d _T))
(assert
 (__l2s_d_a ref.lt_tar_cf))
(assert
 (__l2s_d_a cfabric.t_rd_arr_min))
(assert
 (=> l2s_init_9 l2s_g_19))
(assert
 (=> l2s_init_10 l2s_g_20))
(assert
 (=> l2s_init_11 l2s_g_21))
(assert
 (=> l2s_init_13 l2s_g_23))
(assert
 (=> l2s_init_12 l2s_g_22))
(assert
 (=> l2s_init_14 l2s_g_24))
(assert
 (=> l2s_init_8 l2s_g_17))
(assert
 (forall ((|T:lclock| lclock) )(let ((?x2138 (__ref.evs.cmp |T:lclock|)))
 (let (($x9650 (= ?x2138 nop)))
 (let ((?x963 (__ref.evs.req |T:lclock|)))
 (let (($x9651 (= ?x963 nop)))
 (let (($x9652 (and $x9651 $x9650)))
 (=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|))) (not $x9652))))))))
 )
(assert
 (let (($x2331 (= ref.lt_tar_cf |0:tar_cf_clock|)))
 (let (($x2324 (= ref.lt |0:lclock|)))
 (=> $x2324 $x2331))))
(assert
 (= (__ref.evs.req |0:lclock|) nop))
(assert
 (= (__ref.evs.l_req |0:lclock|) init_l))
(assert
 (= (__ref.evs.cmp |0:lclock|) nop))
(assert
 (= (__ref.evs.l_cmp |0:lclock|) init_l))
(assert
 (= (__ref.evs.lt_arr |0:lclock|) |0:tar_clock|))
(assert
 (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|))
(assert
 (forall ((|T:lclock| lclock) )(let (($x2108 (__ref.evs.serialized |T:lclock|)))
 (let ((?x2138 (__ref.evs.cmp |T:lclock|)))
 (let (($x9650 (= ?x2138 nop)))
 (let ((?x963 (__ref.evs.req |T:lclock|)))
 (let (($x9651 (= ?x963 nop)))
 (let (($x3059 (= |T:lclock| |0:lclock|)))
 (let (($x3792 (or $x3059 (|<:lclock:lclock| ref.lt |T:lclock|))))
 (=> $x3792 (and $x9651 $x9650 $x2108))))))))))
 )
(assert
 (forall ((|T:lclock| lclock) )(let (($x821 (__sys_live.cf_pio_req |T:lclock|)))
 (let (($x579 (sys_live.is_io |T:lclock|)))
 (let (($x474 (sys_live.pending |T:lclock|)))
 (let (($x783 (or (= |T:lclock| _T) (|<:lclock:lclock| |T:lclock| _T))))
 (let (($x1251 (and $x783 $x474)))
 (let (($x1878 (and $x1251 $x579)))
 (let (($x836 (|__work_needed[1b]| |T:lclock|)))
 (= $x836 (and $x1878 $x821))))))))))
 )
(assert
 (let (($x1696 (sys_live.pending _T)))
 (=> l2s_g_16 $x1696)))
(assert
 (let (($x1700 (not l2s_g_16)))
 (let (($x1701 (=> (and (= (ref.evs.p _T) _P) (sys_live.pending _T)) $x1700)))
 (=> (and l2s_g_17 (and (= (ref.evs.p _T) _P) (sys_live.pending _T))) $x1700))))
(assert
 (let (($x1705 (not (arm.cpl_fair _P))))
 (=> l2s_g_18 $x1705)))
(assert
 (let (($x1708 (not l2s_g_18)))
 (=> l2s_g_19 $x1708)))
(assert
 (let (($x1712 (not l2s_g_25)))
 (=> l2s_g_20 $x1712)))
(assert
 (let (($x1716 (not l2s_g_26)))
 (=> l2s_g_21 $x1716)))
(assert
 (let (($x1720 (not l2s_g_27)))
 (=> l2s_g_22 $x1720)))
(assert
 (let (($x1724 (not l2s_g_28)))
 (=> l2s_g_23 $x1724)))
(assert
 (let (($x1728 (not l2s_g_29)))
 (=> l2s_g_24 $x1728)))
(assert
 (let (($x1731 (not cfabric.cpl_fair)))
 (=> l2s_g_25 $x1731)))
(assert
 (let (($x1734 (not cfabric.rd_fair)))
 (=> l2s_g_26 $x1734)))
(assert
 (let (($x1737 (not cfabric.rd_pio_fair)))
 (=> l2s_g_27 $x1737)))
(assert
 (let (($x1740 (not cfabric.wr_fair)))
 (=> l2s_g_28 $x1740)))
(assert
 (let (($x1743 (not cfabric.wr_pio_fair)))
 (=> l2s_g_29 $x1743)))
(assert
 (let (($x8233 (or __ts0_a __ts0_b)))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x8233))))
(assert
 (let (($x3989 (not __ts0_d)))
 (or $x3989 (or (not __ts0_a) (isd.rd |__loc:pp| |__fml:m| |__fml:a| |__loc:t|)))))
(assert
 (let (($x3989 (not __ts0_d)))
 (or $x3989 (or (not __ts0_a) (= (__ref.evs.req |__loc:t|) read)))))
(assert
 (let (($x5341 (not __ts0_a)))
 (let (($x101371 (or $x5341 (= (__ref.evs.l_req |__loc:t|) memc_l))))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x101371)))))
(assert
 (let (($x14441 (not __ts0__ts0_a_a_a)))
 (let (($x26218 (not __ts0__ts0_b_a_a)))
 (let (($x18454 (or $x26218 (or $x14441 (|<:tar_clock:tar_clock| |__ts0__ts0__ts0__new_fml:x_a| |__fml:y|)))))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x18454))))))
(assert
 (let (($x14441 (not __ts0__ts0_a_a_a)))
 (let (($x26218 (not __ts0__ts0_b_a_a)))
 (let (($x90486 (or $x26218 (or $x14441 (tar_clock.succ |__ts0__ts0__ts0__new_fml:x_a| |__fml:y|)))))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x90486))))))
(assert
 (let (($x14441 (not __ts0__ts0_a_a_a)))
 (let (($x12445 (or __ts0__ts0_b_a_a (or $x14441 (not (__ref.evs.serialized |__ts0__ts0__new_fml:lt_b|))))))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x12445)))))
(assert
 (let (($x14417 (not __ts0__ts0__ts0__ts0_b_a_a)))
 (let (($x13245 (or $x14417 (|<:tar_clock:tar_clock| |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_a| |__fml:y|))))
 (let (($x14441 (not __ts0__ts0_a_a_a)))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 (or __ts0__ts0_b_a_a (or $x14441 $x13245))))))))
(assert
 (let (($x14417 (not __ts0__ts0__ts0__ts0_b_a_a)))
 (let (($x14584 (or $x14417 (tar_clock.succ |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_a| |__fml:y|))))
 (let (($x14441 (not __ts0__ts0_a_a_a)))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 (or __ts0__ts0_b_a_a (or $x14441 $x14584))))))))
(assert
 (let (($x14965 (|<:tar_clock:tar_clock| |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| |__fml:y|)))
 (let (($x13912 (not __ts0__ts0__ts0__ts0__ts0_a_a_a_a)))
 (let (($x14441 (not __ts0__ts0_a_a_a)))
 (let (($x14076 (or __ts0__ts0_b_a_a (or $x14441 (or __ts0__ts0__ts0__ts0_b_a_a (or $x13912 $x14965))))))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 $x14076)))))))
(assert
 (let (($x13912 (not __ts0__ts0__ts0__ts0__ts0_a_a_a_a)))
 (let (($x99460 (or $x13912 (tar_clock.succ |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| |__fml:y|))))
 (let (($x14441 (not __ts0__ts0_a_a_a)))
 (let (($x3989 (not __ts0_d)))
 (or $x3989 (or __ts0__ts0_b_a_a (or $x14441 (or __ts0__ts0__ts0__ts0_b_a_a $x99460)))))))))
(assert
 (or __ts0_d (or (not __ts0__ts0_c_a) (or __ts0_a __ts0__ts0_b))))
(assert
 (let (($x4793 (not __ts0__ts0_c_a)))
 (let (($x85316 (or $x4793 (or (not __ts0_a) (isd.wr |__loc:pp| |__fml:m| |__fml:a| |__loc:t|)))))
 (or __ts0_d $x85316))))
(assert
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 (or (not __ts0_a) (= (__ref.evs.req |__loc:t|) write))))))
(assert
 (let (($x5341 (not __ts0_a)))
 (let (($x101371 (or $x5341 (= (__ref.evs.l_req |__loc:t|) memc_l))))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 $x101371))))))
(assert
 (let (($x10691 (|<:tar_clock:tar_clock| |__ts0__ts0__ts0__ts0__new_fml:x_a| |__fml:y|)))
 (let (($x15077 (not __ts0__ts0__ts0_a_a_b)))
 (let (($x81729 (not __ts0__ts0__ts0_b_a_b)))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 (or $x81729 (or $x15077 $x10691)))))))))
(assert
 (let (($x10709 (tar_clock.succ |__ts0__ts0__ts0__ts0__new_fml:x_a| |__fml:y|)))
 (let (($x15077 (not __ts0__ts0__ts0_a_a_b)))
 (let (($x81729 (not __ts0__ts0__ts0_b_a_b)))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 (or $x81729 (or $x15077 $x10709)))))))))
(assert
 (let (($x15077 (not __ts0__ts0__ts0_a_a_b)))
 (let (($x13083 (or __ts0__ts0__ts0_b_a_b (or $x15077 (not (__ref.evs.serialized |__ts0__ts0__ts0__new_fml:lt_b|))))))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 $x13083))))))
(assert
 (let (($x13186 (|<:tar_clock:tar_clock| |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_b| |__fml:y|)))
 (let (($x14777 (not __ts0__ts0__ts0__ts0__ts0_b_a_a)))
 (let (($x15077 (not __ts0__ts0__ts0_a_a_b)))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 (or __ts0__ts0__ts0_b_a_b (or $x15077 (or $x14777 $x13186))))))))))
(assert
 (let (($x14777 (not __ts0__ts0__ts0__ts0__ts0_b_a_a)))
 (let (($x13141 (or $x14777 (tar_clock.succ |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_b| |__fml:y|))))
 (let (($x15077 (not __ts0__ts0__ts0_a_a_b)))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 (or __ts0__ts0__ts0_b_a_b (or $x15077 $x13141)))))))))
(assert
 (let (($x15147 (|<:tar_clock:tar_clock| |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| |__fml:y|)))
 (let (($x90533 (not __ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a)))
 (let (($x15077 (not __ts0__ts0__ts0_a_a_b)))
 (let (($x12224 (or __ts0__ts0__ts0_b_a_b (or $x15077 (or __ts0__ts0__ts0__ts0__ts0_b_a_a (or $x90533 $x15147))))))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 $x12224))))))))
(assert
 (let (($x90533 (not __ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a)))
 (let (($x14135 (or $x90533 (tar_clock.succ |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| |__fml:y|))))
 (let (($x15077 (not __ts0__ts0__ts0_a_a_b)))
 (let (($x14000 (or __ts0__ts0__ts0_b_a_b (or $x15077 (or __ts0__ts0__ts0__ts0__ts0_b_a_a $x14135)))))
 (let (($x4793 (not __ts0__ts0_c_a)))
 (or __ts0_d (or $x4793 $x14000))))))))
(assert
 (or __ts0_a_a __ts0_b_a))
(assert
 (let (($x107019 (and (isd.rd |__loc:pp_a| |__fml:m| |__loc:aa| |__loc:t3|) (= (ref.evs.req |__loc:t3|) read))))
 (let (($x137570 (and (isd.wr |__loc:pp_a| |__fml:m| |__loc:aa| |__loc:t3|) (= (ref.evs.req |__loc:t3|) write))))
 (let (($x11041 (not __ts0_a_a)))
 (or $x11041 (or $x137570 $x107019))))))
(assert
 (let (($x11041 (not __ts0_a_a)))
 (or $x11041 (= (ref.evs.l_req |__loc:t3|) dramc_l))))
(assert
 (or __ts0_a_b __ts0_b_b))
(assert
 (let ((?x8720 (ref.evs.req |__loc:t4|)))
 (let (($x8724 (= ?x8720 read)))
 (let (($x8721 (= ?x8720 write)))
 (let (($x107212 (or (and (isd.wr |__loc:pp_b| |__loc:mm| |__loc:aa_a| |__loc:t4|) $x8721) (and (isd.rd |__loc:pp_b| |__loc:mm| |__loc:aa_a| |__loc:t4|) $x8724))))
 (let (($x8714 (not __ts0_a_b)))
 (or $x8714 $x107212)))))))
(assert
 (let ((?x8728 (ref.evs.l_req |__loc:t4|)))
 (let (($x11048 (= ?x8728 dramc_l)))
 (let (($x8714 (not __ts0_a_b)))
 (or $x8714 $x11048)))))
(assert
 (or __ts0_a_a_a __ts0_b_a_a))
(assert
 (let ((?x8785 (ref.evs.req |__loc:t5|)))
 (let (($x8789 (= ?x8785 read)))
 (let (($x11069 (and (isd.rd |__loc:pp_a_a| |__new_loc:mz| |__loc:aa_a_a| |__loc:t5|) $x8789)))
 (let (($x8786 (= ?x8785 write)))
 (let (($x11067 (and (isd.wr |__loc:pp_a_a| |__new_loc:mz| |__loc:aa_a_a| |__loc:t5|) $x8786)))
 (let (($x8779 (not __ts0_a_a_a)))
 (or $x8779 (or $x11067 $x11069)))))))))
(assert
 (let (($x8779 (not __ts0_a_a_a)))
 (or $x8779 (= (ref.evs.l_req |__loc:t5|) dramc_l))))
(assert
 (or __ts0_a_c __ts0_b_c))
(assert
 (let ((?x11077 (ref.evs.req |__loc:t4_a|)))
 (let (($x11081 (= ?x11077 read)))
 (let (($x11078 (= ?x11077 write)))
 (let (($x107153 (or (and (isd.wr |__loc:pp_c| |__loc:mm_a| |__loc:aa_b| |__loc:t4_a|) $x11078) (and (isd.rd |__loc:pp_c| |__loc:mm_a| |__loc:aa_b| |__loc:t4_a|) $x11081))))
 (let (($x107169 (not __ts0_a_c)))
 (or $x107169 $x107153)))))))
(assert
 (let (($x11086 (= (ref.evs.l_req |__loc:t4_a|) memc_l)))
 (let (($x107169 (not __ts0_a_c)))
 (or $x107169 $x11086))))
(assert
 (or __ts0_a_a_b __ts0_b_a_b))
(assert
 (let (($x11126 (and (isd.rd |__loc:pp_a_b| |__new_loc:mz_a| |__loc:aa_a_b| |__loc:t5_a|) (= (ref.evs.req |__loc:t5_a|) read))))
 (let (($x11123 (and (isd.wr |__loc:pp_a_b| |__new_loc:mz_a| |__loc:aa_a_b| |__loc:t5_a|) (= (ref.evs.req |__loc:t5_a|) write))))
 (let (($x11117 (not __ts0_a_a_b)))
 (or $x11117 (or $x11123 $x11126))))))
(assert
 (let (($x11117 (not __ts0_a_a_b)))
 (or $x11117 (= (ref.evs.l_req |__loc:t5_a|) dramc_l))))
(assert
 (or __ts0_a_a_a_a __ts0_b_a_a_a))
(assert
 (let (($x8839 (or (= (ref.evs.req |__loc:t6|) write) (= (ref.evs.req |__loc:t6|) read))))
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 $x8839))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.l_req |__loc:t6|) dramc_l))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.m |__loc:t6|) (ref.evs.m memc_lt_min)))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.a |__loc:t6|) (ref.evs.a memc_lt_min)))))
(assert
 (let (($x8834 (not __ts0_a_a_a_a)))
 (or $x8834 (= (ref.evs.req |__loc:t6|) (ref.evs.req memc_lt_min)))))
(assert
 (forall ((|T:lclock| lclock) )(=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|))) (not (and (= (ref.evs.req |T:lclock|) nop) (= (ref.evs.cmp |T:lclock|) nop)))))
 )
(assert
 (= (ref.evs.req |0:lclock|) nop))
(assert
 (= (ref.evs.l_req |0:lclock|) init_l))
(assert
 (= (ref.evs.cmp |0:lclock|) nop))
(assert
 (= (ref.evs.l_cmp |0:lclock|) init_l))
(assert
 (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|))
(assert
 (forall ((|T:lclock| lclock) )(let (($x274 (ref.evs.serialized |T:lclock|)))
 (let ((?x357 (ref.evs.cmp |T:lclock|)))
 (let (($x2338 (= ?x357 nop)))
 (let ((?x521 (ref.evs.req |T:lclock|)))
 (let (($x2334 (= ?x521 nop)))
 (let (($x3059 (= |T:lclock| |0:lclock|)))
 (let (($x3792 (or $x3059 (|<:lclock:lclock| ref.lt |T:lclock|))))
 (=> $x3792 (and $x2334 $x2338 $x274))))))))))
 )
(assert
 (forall ((|T0:lclock| lclock) (|T1:lclock| lclock) )(let ((?x302 (ref.evs.l_req |T1:lclock|)))
 (let (($x569 (= ?x302 cf_pio_l)))
 (let (($x520 (= ?x302 if_l)))
 (let (($x551 (= ?x302 memc_l)))
 (let ((?x2983 (ref.evs.l_req |T0:lclock|)))
 (let (($x3312 (= ?x2983 memc_l)))
 (let (($x3550 (or (and (= ?x2983 cf_pio_l) $x569) (and (= ?x2983 if_l) (or $x520 $x569)) (and $x3312 (or $x551 $x520 $x569)))))
 (let (($x259 (|<:lclock:lclock| |T0:lclock| |T1:lclock|)))
 (let ((?x353 (ref.evs.mem_loc |T1:lclock|)))
 (let (($x578 (= ?x353 pio_memc)))
 (let ((?x355 (ref.evs.mem_loc |T0:lclock|)))
 (let (($x3551 (= ?x355 pio_memc)))
 (let ((?x276 (ref.evs.a |T1:lclock|)))
 (let (($x258 (= (ref.evs.a |T0:lclock|) ?x276)))
 (let ((?x253 (ref.evs.m |T1:lclock|)))
 (let ((?x332 (ref.evs.m |T0:lclock|)))
 (let (($x333 (= ?x332 ?x253)))
 (let ((?x335 (ref.evs.p |T1:lclock|)))
 (let (($x337 (= (ref.evs.p |T0:lclock|) ?x335)))
 (let (($x3505 (or (and (= (ref.evs.req |T0:lclock|) write) (= (ref.evs.req |T1:lclock|) write)) (and (= (ref.evs.req |T0:lclock|) read) (= (ref.evs.req |T1:lclock|) read)))))
 (=> (and $x3505 $x337 $x333 $x258 $x3551 $x578 $x259) $x3550))))))))))))))))))))))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) (|V:lclock| lclock) )(=> (and (|<:lclock:lclock| |T:lclock| |U:lclock|) (|<:lclock:lclock| |U:lclock| |V:lclock|)) (|<:lclock:lclock| |T:lclock| |V:lclock|)))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) )(not (and (|<:lclock:lclock| |T:lclock| |U:lclock|) (|<:lclock:lclock| |U:lclock| |T:lclock|))))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) )(let (($x298 (|<:lclock:lclock| |U:lclock| |T:lclock|)))
 (let (($x641 (= |T:lclock| |U:lclock|)))
 (let (($x259 (|<:lclock:lclock| |T:lclock| |U:lclock|)))
 (or $x259 $x641 $x298)))))
 )
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[0a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[0b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[1a]| $x1855)))
(assert
 (forall ((|T:lclock| lclock) )(let (($x1837 (= |T:lclock| ref.lt)))
 (let (($x1838 (or $x1837 (|<:lclock:lclock| |T:lclock| ref.lt))))
 (= (|work_created[1b]| |T:lclock|) $x1838))))
 )
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[1b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[4a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[4b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[5a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[5b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[6a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[6b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[7]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[7a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[8]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[9]| $x1855)))
(assert
 (forall ((|T:lclock| lclock) )(let ((?x2098 (__ref.evs.l_req |T:lclock|)))
 (let (($x2299 (= ?x2098 cf_pio_l)))
 (let ((?x963 (__ref.evs.req |T:lclock|)))
 (let (($x2262 (= ?x963 write)))
 (let (($x2263 (= ?x963 read)))
 (let (($x2264 (or $x2263 $x2262)))
 (let (($x821 (__sys_live.cf_pio_req |T:lclock|)))
 (= $x821 (and $x2264 $x2299))))))))))
 )
(assert
 (let (($x2576 (not l2s_g_17)))
 (let (($x1700 (not l2s_g_16)))
 (let (($x1701 (=> (and (= (ref.evs.p _T) _P) (sys_live.pending _T)) $x1700)))
 (let (($x2575 (not (not $x1701))))
 (= l2s_w_9 (and $x2575 $x2576)))))))
(assert
 (= l2s_w_11 (and (not cfabric.rd_fair) (not l2s_g_26))))
(assert
 (= l2s_w_13 (and (not cfabric.wr_fair) (not l2s_g_28))))
(assert
 (= l2s_w_12 (and (not cfabric.rd_pio_fair) (not l2s_g_27))))
(assert
 (= l2s_w_14 (and (not cfabric.wr_pio_fair) (not l2s_g_29))))
(assert
 (= l2s_w_10 (and (not cfabric.cpl_fair) (not l2s_g_25))))
(assert
 (= l2s_w_8 (and (not (arm.cpl_fair _P)) (not l2s_g_18))))
(assert
 |__ts0__m_loc:ordpip_a|)
(assert
 (= |__ts0__m_loc:tt_a| |0:lclock|))
(assert
 (let ((?x106782 (ite __ts0__ts0_c_a (ite __ts0__ts0_b |__ts0__ts0__m_loc:tt_a| |__loc:t|) |__loc:tt|)))
 (= |__new_loc:tt| (ite __ts0_d (ite __ts0_b |__ts0__m_loc:tt_a| |__loc:t|) ?x106782))))
(assert
 (let (($x132434 (ite __ts0__ts0_c_a (ite __ts0__ts0_b |__ts0__ts0__m_loc:ordpip_a| false) |__loc:ordpip|)))
 (= |__new_loc:ordpip| (ite __ts0_d (ite __ts0_b |__ts0__m_loc:ordpip_a| false) $x132434))))
(assert
 (= |__ts0__ts0__new_fml:lt_a_a| |__new_loc:tt|))
(assert
 (let ((?x131265 (ref.evs.m |__new_loc:tt|)))
 (let ((?x129613 (__ref.lt_tar ?x131265)))
 (= |__ts0__ts0__ts0__new_fml:x_a| ?x129613))))
(assert
 (= |__ts0__ts0__new_fml:lt_b| |__new_loc:tt|))
(assert
 (= |__ts0__ts0__ts0__new_loc:a_a_a| (ref.evs.a |__ts0__ts0__new_fml:lt_b|)))
(assert
 (let ((?x104289 (ref.evs.m |__ts0__ts0__new_fml:lt_b|)))
 (= |__ts0__ts0__ts0__new_loc:m_a_a| ?x104289)))
(assert
 (let ((?x104289 (ref.evs.m |__ts0__ts0__new_fml:lt_b|)))
 (let ((?x137931 (__ref.lt_tar ?x104289)))
 (= |__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_a| ?x137931))))
(assert
 (let ((?x104289 (ref.evs.m |__ts0__ts0__new_fml:lt_b|)))
 (let ((?x137931 (__ref.lt_tar ?x104289)))
 (= |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| ?x137931))))
(assert
 (= __ts0__ts0__ts0__ts0__ts0_a_a_a_a (= (__ref.evs.req |__ts0__ts0__new_fml:lt_b|) write)))
(assert
 (= __ts0__ts0__ts0__ts0_b_a_a (= (__ref.evs.req |__ts0__ts0__new_fml:lt_b|) read)))
(assert
 (let (($x137732 (not (= |__new_loc:tt| |0:lclock|))))
 (let (($x9122 (not |__new_loc:ordpip|)))
 (let (($x106554 (and $x9122 $x137732 (= (ref.evs.mem_loc |__new_loc:tt|) mem_memc))))
 (= __ts0__ts0_b_a_a $x106554)))))
(assert
 |__ts0__ts0__m_loc:ordpip_a|)
(assert
 (= |__ts0__ts0__m_loc:tt_a| |0:lclock|))
(assert
 (= |__ts0__ts0__ts0__new_fml:lt_a_a| |__new_loc:tt|))
(assert
 (let ((?x131265 (ref.evs.m |__new_loc:tt|)))
 (let ((?x129613 (__ref.lt_tar ?x131265)))
 (= |__ts0__ts0__ts0__ts0__new_fml:x_a| ?x129613))))
(assert
 (= |__ts0__ts0__ts0__new_fml:lt_b| |__new_loc:tt|))
(assert
 (= |__ts0__ts0__ts0__ts0__new_loc:a_a_a| (ref.evs.a |__ts0__ts0__ts0__new_fml:lt_b|)))
(assert
 (let ((?x105598 (ref.evs.m |__ts0__ts0__ts0__new_fml:lt_b|)))
 (= |__ts0__ts0__ts0__ts0__new_loc:m_a_a| ?x105598)))
(assert
 (let ((?x105598 (ref.evs.m |__ts0__ts0__ts0__new_fml:lt_b|)))
 (let ((?x106547 (__ref.lt_tar ?x105598)))
 (= |__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a_b| ?x106547))))
(assert
 (let ((?x105598 (ref.evs.m |__ts0__ts0__ts0__new_fml:lt_b|)))
 (let ((?x106547 (__ref.lt_tar ?x105598)))
 (= |__ts0__ts0__ts0__ts0__ts0__ts0__new_fml:x_a_a_a| ?x106547))))
(assert
 (= __ts0__ts0__ts0__ts0__ts0__ts0_a_a_a_a (= (__ref.evs.req |__ts0__ts0__ts0__new_fml:lt_b|) write)))
(assert
 (= __ts0__ts0__ts0__ts0__ts0_b_a_a (= (__ref.evs.req |__ts0__ts0__ts0__new_fml:lt_b|) read)))
(assert
 (let (($x137732 (not (= |__new_loc:tt| |0:lclock|))))
 (let (($x9122 (not |__new_loc:ordpip|)))
 (let (($x106554 (and $x9122 $x137732 (= (ref.evs.mem_loc |__new_loc:tt|) mem_memc))))
 (= __ts0__ts0__ts0_b_a_b $x106554)))))
(assert
 (= |__ts0__ts0__ts0__new_loc:t_a_a| |__fml:lt|))
(assert
 (= |__ts0__ts0__ts0__ts0__ts0__new_fml:lt_a_a| |__ts0__ts0__ts0__new_loc:t_a_a|))
(assert
 (= __ts0__ts0__ts0__ts0__ts0__ts0_a_a_b_a (= (ref.evs.mem_loc |__ts0__ts0__ts0__new_loc:t_a_a|) pio_memc)))
(assert
 (= __ts0__ts0__ts0__ts0__ts0_b_b_a (= (ref.evs.mem_loc |__ts0__ts0__ts0__new_loc:t_a_a|) mem_memc)))
(assert
 (let (($x54778 (and (isd.wr |__fml:p| |__fml:m| |__fml:a| |__ts0__ts0__ts0__new_loc:t_a_a|) (= (__ref.evs.cmp |__ts0__ts0__ts0__new_loc:t_a_a|) wr_cmp))))
 (let (($x55904 (and (isd.rd |__fml:p| |__fml:m| |__fml:a| |__ts0__ts0__ts0__new_loc:t_a_a|) (= (__ref.evs.cmp |__ts0__ts0__ts0__new_loc:t_a_a|) rrsp))))
 (let (($x76636 (and (or $x55904 $x54778) (= (__ref.evs.l_cmp |__ts0__ts0__ts0__new_loc:t_a_a|) memc_l) (= (ref.evs.m |__ts0__ts0__ts0__new_loc:t_a_a|) |__fml:m|))))
 (= __ts0__ts0__ts0__ts0_a_a_b $x76636)))))
(assert
 (let (($x4749 (= |__fml:ph| wr_ph)))
 (= __ts0__ts0_c_a $x4749)))
(assert
 (let (($x4747 (= |__fml:ph| rd_ph)))
 (= __ts0_d $x4747)))
(assert
 (= dramc_lt_min (ite __ts0_b_b __dramc_lt_min |__loc:t4|)))
(assert
 (let ((?x3260 (ref.evs.m dramc_lt_min)))
 (= |__new_loc:mz| ?x3260)))
(assert
 (= memc_lt_min (ite __ts0_b_c __memc_lt_min |__loc:t4_a|)))
(assert
 (let ((?x3294 (ref.evs.m memc_lt_min)))
 (= |__new_loc:mz_a| ?x3294)))
(assert
 (= memc_blocking (ite __ts0_b_a_a_a __memc_blocking |__loc:t6|)))
(assert
 (forall ((|T:lclock| lclock) )(let (($x473 (or (isd.rd (ref.evs.p |T:lclock|) (ref.evs.m |T:lclock|) (ref.evs.a |T:lclock|) |T:lclock|) (isd.wr (ref.evs.p |T:lclock|) (ref.evs.m |T:lclock|) (ref.evs.a |T:lclock|) |T:lclock|))))
 (let (($x474 (sys_live.pending |T:lclock|)))
 (= $x474 $x473))))
 )
(assert
 (forall ((|T:lclock| lclock) )(let ((?x353 (ref.evs.mem_loc |T:lclock|)))
 (let (($x578 (= ?x353 pio_memc)))
 (let (($x579 (sys_live.is_io |T:lclock|)))
 (= $x579 $x578)))))
 )
(assert
 (let (($x2717 (|work_created[1b]| @T)))
 (and (not (=> (and |work_invar[1b]| (|__work_needed[1b]| @T)) $x2717)))))
(check-sat)
