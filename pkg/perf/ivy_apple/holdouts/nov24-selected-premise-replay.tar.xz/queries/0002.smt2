(set-info :status unknown)
(declare-datatypes ((op_type 0)) ((op_type (nop) (write) (read) (rrsp) (wr_cmp))))
 (declare-sort tar_cf_clock)
 (declare-sort tar_clock)
 (declare-datatypes ((loc_type 0)) ((loc_type (init_l) (cf_mem_l) (cf_pio_l) (cf_cmp_l) (if_l) (memc_l) (dramc_l) (arm_l))))
 (declare-datatypes ((mem_loc_type 0)) ((mem_loc_type (mem_loc_init) (mem_memc) (pio_memc))))
 (declare-sort mem_type)
 (declare-sort addr_type)
 (declare-sort proc)
 (declare-sort lclock)
 (declare-fun ref.lt () lclock)
(declare-fun cfabric.t_rd_min () lclock)
(declare-fun memc_lt_min () lclock)
(declare-fun memc_blocking () lclock)
(declare-fun dramc_lt_min () lclock)
(declare-fun _T () lclock)
(declare-fun ref.lt_tar_cf () tar_cf_clock)
(declare-fun cfabric.t_rd_arr_min () tar_cf_clock)
(declare-fun ref.evs.cmp (lclock) op_type)
(declare-fun ref.evs.req (lclock) op_type)
(declare-fun |0:lclock| () lclock)
(declare-fun |0:tar_cf_clock| () tar_cf_clock)
(declare-fun ref.evs.l_req (lclock) loc_type)
(declare-fun ref.evs.l_cmp (lclock) loc_type)
(declare-fun |0:tar_clock| () tar_clock)
(declare-fun ref.evs.lt_arr (lclock) tar_clock)
(declare-fun ref.evs.lt_arr_cf (lclock) tar_cf_clock)
(declare-fun _P () proc)
(declare-fun ref.evs.p (lclock) proc)
(declare-fun ref.evs.a (lclock) addr_type)
(declare-fun ref.evs.m (lclock) mem_type)
(declare-fun ref.evs.mem_loc (lclock) mem_loc_type)
(declare-fun @T () lclock)
(declare-fun cfabric.cpl_fair () Bool)
(declare-fun cfabric.rd_fair () Bool)
(declare-fun cfabric.wr_fair () Bool)
(declare-fun cfabric.rd_pio_fair () Bool)
(declare-fun cfabric.wr_pio_fair () Bool)
(declare-fun __l2s_d (lclock) Bool)
(declare-fun |work_created[0b]| (lclock) Bool)
(declare-fun l2s_g_17 () Bool)
(declare-fun |work_invar[0a]| () Bool)
(declare-fun __l2s_d_a (tar_cf_clock) Bool)
(declare-fun l2s_g_19 () Bool)
(declare-fun l2s_init_9 () Bool)
(declare-fun l2s_g_20 () Bool)
(declare-fun l2s_init_10 () Bool)
(declare-fun l2s_g_21 () Bool)
(declare-fun l2s_init_11 () Bool)
(declare-fun l2s_g_23 () Bool)
(declare-fun l2s_init_13 () Bool)
(declare-fun l2s_g_22 () Bool)
(declare-fun l2s_init_12 () Bool)
(declare-fun l2s_g_24 () Bool)
(declare-fun l2s_init_14 () Bool)
(declare-fun l2s_init_8 () Bool)
(declare-fun ref.evs.serialized (lclock) Bool)
(declare-fun |<:lclock:lclock| (lclock lclock) Bool)
(declare-fun sys_live.pending (lclock) Bool)
(declare-fun l2s_g_16 () Bool)
(declare-fun arm.cpl_fair (proc) Bool)
(declare-fun l2s_g_18 () Bool)
(declare-fun l2s_g_25 () Bool)
(declare-fun l2s_g_26 () Bool)
(declare-fun l2s_g_27 () Bool)
(declare-fun l2s_g_28 () Bool)
(declare-fun l2s_g_29 () Bool)
(declare-fun sys_live.cf_mem_req (lclock) Bool)
(declare-fun sys_live.is_io (lclock) Bool)
(declare-fun |work_needed[0b]| (lclock) Bool)
(declare-fun |work_invar[0b]| () Bool)
(declare-fun |work_invar[1a]| () Bool)
(declare-fun |work_invar[1b]| () Bool)
(declare-fun |work_invar[4a]| () Bool)
(declare-fun |work_invar[4b]| () Bool)
(declare-fun |work_invar[5a]| () Bool)
(declare-fun |work_invar[5b]| () Bool)
(declare-fun |work_invar[6a]| () Bool)
(declare-fun |work_invar[6b]| () Bool)
(declare-fun |work_invar[7]| () Bool)
(declare-fun |work_invar[7a]| () Bool)
(declare-fun |work_invar[8]| () Bool)
(declare-fun |work_invar[9]| () Bool)
(declare-fun l2s_w_9 () Bool)
(declare-fun l2s_w_11 () Bool)
(declare-fun l2s_w_13 () Bool)
(declare-fun l2s_w_12 () Bool)
(declare-fun l2s_w_14 () Bool)
(declare-fun l2s_w_10 () Bool)
(declare-fun l2s_w_8 () Bool)
(declare-fun isd.wr (proc mem_type addr_type lclock) Bool)
(declare-fun isd.rd (proc mem_type addr_type lclock) Bool)
(assert
 (not cfabric.cpl_fair))
(assert
 (not cfabric.rd_fair))
(assert
 (not cfabric.wr_fair))
(assert
 (not cfabric.rd_pio_fair))
(assert
 (not cfabric.wr_pio_fair))
(assert
 (forall ((|T:lclock| lclock) )(let (($x2488 (__l2s_d |T:lclock|)))
 (let (($x2890 (and $x2488)))
 (=> (|work_created[0b]| |T:lclock|) $x2890))))
 )
(assert
 (let (($x2576 (not l2s_g_17)))
 (=> (not |work_invar[0a]|) $x2576)))
(assert
 (__l2s_d ref.lt))
(assert
 (__l2s_d cfabric.t_rd_min))
(assert
 (__l2s_d memc_lt_min))
(assert
 (__l2s_d memc_blocking))
(assert
 (__l2s_d dramc_lt_min))
(assert
 (__l2s_d _T))
(assert
 (__l2s_d_a ref.lt_tar_cf))
(assert
 (__l2s_d_a cfabric.t_rd_arr_min))
(assert
 (=> l2s_init_9 l2s_g_19))
(assert
 (=> l2s_init_10 l2s_g_20))
(assert
 (=> l2s_init_11 l2s_g_21))
(assert
 (=> l2s_init_13 l2s_g_23))
(assert
 (=> l2s_init_12 l2s_g_22))
(assert
 (=> l2s_init_14 l2s_g_24))
(assert
 (=> l2s_init_8 l2s_g_17))
(assert
 (forall ((|T:lclock| lclock) )(=> (and (= ref.lt |T:lclock|) (not (= |T:lclock| |0:lclock|))) (not (and (= (ref.evs.req |T:lclock|) nop) (= (ref.evs.cmp |T:lclock|) nop)))))
 )
(assert
 (let (($x2331 (= ref.lt_tar_cf |0:tar_cf_clock|)))
 (let (($x2324 (= ref.lt |0:lclock|)))
 (=> $x2324 $x2331))))
(assert
 (= (ref.evs.req |0:lclock|) nop))
(assert
 (= (ref.evs.l_req |0:lclock|) init_l))
(assert
 (= (ref.evs.cmp |0:lclock|) nop))
(assert
 (= (ref.evs.l_cmp |0:lclock|) init_l))
(assert
 (= (ref.evs.lt_arr |0:lclock|) |0:tar_clock|))
(assert
 (= (ref.evs.lt_arr_cf |0:lclock|) |0:tar_cf_clock|))
(assert
 (forall ((|T:lclock| lclock) )(let (($x274 (ref.evs.serialized |T:lclock|)))
 (let ((?x357 (ref.evs.cmp |T:lclock|)))
 (let (($x2338 (= ?x357 nop)))
 (let ((?x521 (ref.evs.req |T:lclock|)))
 (let (($x2334 (= ?x521 nop)))
 (=> (or (= |T:lclock| |0:lclock|) (|<:lclock:lclock| ref.lt |T:lclock|)) (and $x2334 $x2338 $x274))))))))
 )
(assert
 (let (($x1696 (sys_live.pending _T)))
 (=> l2s_g_16 $x1696)))
(assert
 (let (($x1701 (=> (and (= (ref.evs.p _T) _P) (sys_live.pending _T)) (not l2s_g_16))))
 (=> (and l2s_g_17 (and (= (ref.evs.p _T) _P) (sys_live.pending _T))) (not l2s_g_16))))
(assert
 (let (($x1705 (not (arm.cpl_fair _P))))
 (=> l2s_g_18 $x1705)))
(assert
 (let (($x1708 (not l2s_g_18)))
 (=> l2s_g_19 $x1708)))
(assert
 (let (($x1712 (not l2s_g_25)))
 (=> l2s_g_20 $x1712)))
(assert
 (let (($x1716 (not l2s_g_26)))
 (=> l2s_g_21 $x1716)))
(assert
 (let (($x1720 (not l2s_g_27)))
 (=> l2s_g_22 $x1720)))
(assert
 (let (($x1724 (not l2s_g_28)))
 (=> l2s_g_23 $x1724)))
(assert
 (let (($x1728 (not l2s_g_29)))
 (=> l2s_g_24 $x1728)))
(assert
 (let (($x1731 (not cfabric.cpl_fair)))
 (=> l2s_g_25 $x1731)))
(assert
 (let (($x1734 (not cfabric.rd_fair)))
 (=> l2s_g_26 $x1734)))
(assert
 (let (($x1737 (not cfabric.rd_pio_fair)))
 (=> l2s_g_27 $x1737)))
(assert
 (let (($x1740 (not cfabric.wr_fair)))
 (=> l2s_g_28 $x1740)))
(assert
 (let (($x1743 (not cfabric.wr_pio_fair)))
 (=> l2s_g_29 $x1743)))
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) (|V:lclock| lclock) )(=> (and (|<:lclock:lclock| |T:lclock| |U:lclock|) (|<:lclock:lclock| |U:lclock| |V:lclock|)) (|<:lclock:lclock| |T:lclock| |V:lclock|)))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) )(not (and (|<:lclock:lclock| |T:lclock| |U:lclock|) (|<:lclock:lclock| |U:lclock| |T:lclock|))))
 )
(assert
 (forall ((|T:lclock| lclock) (|U:lclock| lclock) )(let (($x298 (|<:lclock:lclock| |U:lclock| |T:lclock|)))
 (let (($x641 (= |T:lclock| |U:lclock|)))
 (let (($x259 (|<:lclock:lclock| |T:lclock| |U:lclock|)))
 (or $x259 $x641 $x298)))))
 )
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[0a]| $x1855)))
(assert
 (forall ((|T:lclock| lclock) )(let (($x1837 (= |T:lclock| ref.lt)))
 (let (($x1838 (or $x1837 (|<:lclock:lclock| |T:lclock| ref.lt))))
 (= (|work_created[0b]| |T:lclock|) $x1838))))
 )
(assert
 (forall ((|T:lclock| lclock) )(let (($x562 (sys_live.cf_mem_req |T:lclock|)))
 (let (($x474 (sys_live.pending |T:lclock|)))
 (let (($x783 (or (= |T:lclock| _T) (|<:lclock:lclock| |T:lclock| _T))))
 (let (($x1251 (and $x783 $x474)))
 (= (|work_needed[0b]| |T:lclock|) (and (and $x1251 (not (sys_live.is_io |T:lclock|))) $x562)))))))
 )
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[0b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[1a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[1b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[4a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[4b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[5a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[5b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[6a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[6b]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[7]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[7a]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[8]| $x1855)))
(assert
 (let (($x1855 (and (and (sys_live.pending _T) (= (ref.evs.p _T) _P)) l2s_g_16)))
 (= |work_invar[9]| $x1855)))
(assert
 (let (($x2576 (not l2s_g_17)))
 (let (($x1701 (=> (and (= (ref.evs.p _T) _P) (sys_live.pending _T)) (not l2s_g_16))))
 (= l2s_w_9 (and (not (not $x1701)) $x2576)))))
(assert
 (= l2s_w_11 (and (not cfabric.rd_fair) (not l2s_g_26))))
(assert
 (= l2s_w_13 (and (not cfabric.wr_fair) (not l2s_g_28))))
(assert
 (= l2s_w_12 (and (not cfabric.rd_pio_fair) (not l2s_g_27))))
(assert
 (= l2s_w_14 (and (not cfabric.wr_pio_fair) (not l2s_g_29))))
(assert
 (= l2s_w_10 (and (not cfabric.cpl_fair) (not l2s_g_25))))
(assert
 (= l2s_w_8 (and (not (arm.cpl_fair _P)) (not l2s_g_18))))
(assert
 (forall ((|T:lclock| lclock) )(let (($x473 (or (isd.rd (ref.evs.p |T:lclock|) (ref.evs.m |T:lclock|) (ref.evs.a |T:lclock|) |T:lclock|) (isd.wr (ref.evs.p |T:lclock|) (ref.evs.m |T:lclock|) (ref.evs.a |T:lclock|) |T:lclock|))))
 (let (($x474 (sys_live.pending |T:lclock|)))
 (= $x474 $x473))))
 )
(assert
 (forall ((|T:lclock| lclock) )(let ((?x302 (ref.evs.l_req |T:lclock|)))
 (let (($x560 (= ?x302 cf_mem_l)))
 (let ((?x521 (ref.evs.req |T:lclock|)))
 (let (($x522 (= ?x521 write)))
 (let (($x523 (= ?x521 read)))
 (let (($x524 (or $x523 $x522)))
 (let (($x562 (sys_live.cf_mem_req |T:lclock|)))
 (= $x562 (and $x524 $x560))))))))))
 )
(assert
 (forall ((|T:lclock| lclock) )(let ((?x353 (ref.evs.mem_loc |T:lclock|)))
 (let (($x578 (= ?x353 pio_memc)))
 (let (($x579 (sys_live.is_io |T:lclock|)))
 (= $x579 $x578)))))
 )
(assert
 (let (($x2709 (|work_created[0b]| @T)))
 (and (not (=> (and |work_invar[0b]| (|work_needed[0b]| @T)) $x2709)))))
(check-sat)
