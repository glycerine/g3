from common import *
import selective_premise_release as release,holdouts as ho,stage_frontier as sf,shlex
rd=d/'selective-budget-trials';rd.mkdir(exist_ok=True)
def make():
 f=pkg/'api/api_verification_goal.go'
 s=release.sources()[f];s=once(s,'import "github.com/glycerine/g3/pkg/ast"','import("github.com/glycerine/g3/pkg/ast";"os";"strconv")')
 s=once(s,'steps = 20000','steps=trialSelectiveLimit')
 s=once(s,'selected: input}, steps)','selected: input,trialExtra:steps==trialSelectiveLimit && len(subset)>maxNarrowPremises}, steps)')
 # Use a dedicated flag; ordinary wide scans can share the 100000 budget.
 s=once(s,'check := func','checkingExtra:=false; check := func')
 s=once(s,'trialExtra:steps==trialSelectiveLimit && len(subset)>maxNarrowPremises','trialExtra:checkingExtra')
 s=once(s,'steps=trialSelectiveLimit','checkingExtra=true;steps=trialSelectiveLimit')
 s=once(s,'var subset []ast.ASTHandle','checkingExtra=false;var subset []ast.ASTHandle')
 s+='\nvar trialSelectiveLimit=func()uint32{x,e:=strconv.Atoi(os.Getenv("G3_SELECTIVE_LIMIT"));if e!=nil{return 20000};return uint32(x)}()\n'
 sp=pkg/'api/api_short_premises.go';sy=once(sp.read_text(),'type shortPremisePlan struct {','type shortPremisePlan struct {\ntrialExtra bool')
 g=pkg/'api/api_goal_instances_check.go';t=once(g.read_text(),'import (','import ("os";"fmt";')
 t=once(t,'complete, err := plan.assertIn(parent, m, aux.child)','''audit:=false
 if sp,ok:=plan.(*shortPremisePlan);ok{audit=sp.trialExtra && studyMeter}
 start:=limit.Count(); translated:=uint64(0);complete, err := plan.assertIn(parent, m, aux.child)
 if audit{translated=limit.Count()-start}
 verdict:=int(9)
 if audit{defer func(){fmt.Fprintln(os.Stderr,"PLANBUDGET",maxSteps,limit.Count()-start,translated,complete,verdict,limit.CancelFlag(),proved)}()}''')
 t=once(t,'answer, err := aux.child.Check()','answer, err := aux.child.Check();if audit{verdict=int(answer)}')
 t+='\nvar studyMeter=os.Getenv("G3_SELECTED_METER")=="1"\n'
 o=overlay(rd/'overlay',{f:s,sp:sy,g:t});b=build(rd/'checker',o=o);bs={}
 for limit in (20000,50000,100000,250000):
  q=rd/(str(limit)+'.sh');q.write_text('#!/bin/sh\nG3_SELECTIVE_LIMIT='+str(limit)+' exec '+shlex.quote(str(b))+' "$@"\n');q.chmod(0o700);bs[str(limit)]=q
 return b,bs
def audited(j,b,limit):
 c,n,sp,iso,rc,ref=j;sd=rd/('audit-'+n+'-'+str(limit));sd.mkdir();p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=sd,capture_output=True,env=dict(env,GOMAXPROCS='1',G3_SELECTIVE_LIMIT=str(limit),G3_SELECTED_METER='1'))
 rest=bytearray();rows=[]
 for l in p.stderr.splitlines(keepends=True):
  if l.startswith(b'PLANBUDGET '):rows.append(l.decode().split()[1:])
  else:rest.extend(l)
 assert(p.returncode,p.stdout,rest)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(n,limit,rest[-500:])
 with(sd/'plans.csv').open('w')as f:z=csv.writer(f);z.writerow('limit used translation complete answer cancelled proved'.split());z.writerows(rows)
 print(n,limit,Counter(tuple(r[-3:])for r in rows),flush=True)
def main():
 b,bs=make();ho.root=rd;js=[(5,*ho.jobs()[0][1:]),(19,*ho.jobs()[1][1:]),(29,'sys_live','doc/examples/apple/ord_live2.ivy','sys_live',0,w/'long-alternatives/ord2-sys/reference')]
 with ThreadPoolExecutor(8)as ex:
  fs=[ex.submit(ho.measure_spec,j,bs,3)for j in js]
  fs += [ex.submit(audited,(c,*js[0][1:]),b,limit) for c,limit in zip([2,15,27,47],(20000,50000,100000,250000))]
  for f in fs:f.result()
if __name__=='__main__':main()
