from common import *
import holdouts as ho,stage_frontier as sf,macro_identity as mi,ground_release_controls as gc
rd=d/'selective-premise-release';rd.mkdir(exist_ok=True)
def sources():
 p=pkg/'api/api_verification_goal.go'
 s=once(p.read_text(),'if p.plans.reusable(m) {','afterNarrow := false\n\tif p.plans.reusable(m) {')
 s=once(s,'''// After the definition search has already paid for a solver check,
		// try additional constraints only if they still fit a small plan.
		if len(narrow) != 0 {
			wideLimit = min(wideLimit, maxNarrowPremises)
		}''','''if len(narrow) != 0 {
			// With more goal relations, the second selection is less
			// selective. Require it to retain a smaller share of the base.
			afterNarrow = true
			wideLimit = min(wideLimit, max(maxNarrowPremises, len(base.rows)/(2*len(relations))))
		}''')
 s=once(s,'if yes, err := check(defs.selectRows(m, symbols, true, wideLimit), 100000);','''wide := defs.selectRows(m, symbols, true, wideLimit)
	steps := uint32(100000)
	if afterNarrow && len(wide) > maxNarrowPremises {
		// Bound the additional search before returning to the full solver.
		steps = 20000
	}
	if yes, err := check(wide, steps);''')
 q=pkg/'api/api_verification_goal_test.go';t=q.read_text();i=t.index('	for _, size :=',t.index('func TestVerificationWideSearchAfterDefinitions'));j=t.index('\n}',i)
 t=t[:i]+'''	for _, tc := range []struct {
		name string
		size, padding, relations int
		fact, selected bool
	}{
		{"small", 32, 220, 4, true, true},
		{"one relation", 33, 220, 1, true, true},
		{"four relations below cutoff", 33, 230, 4, true, false},
		{"four relations at cutoff", 33, 231, 4, true, true},
		{"insufficient savings", 33, 219, 1, true, false},
		{"satisfiable selection", 33, 220, 1, false, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var facts strings.Builder
			if tc.fact {
				facts.WriteString("(gamma k)")
			} else {
				facts.WriteString("(unrelated k)")
			}
			// The two definitions and the ground rows make up the wide plan.
			for i := 0; i < tc.size-3; i++ {
				fmt.Fprintf(&facts, " (pad%d k)", i)
			}
			input := relevantPremiseExample(facts.String(), tc.padding)
			var decls, goal strings.Builder
			decls.WriteString("(declare-fun unrelated (U) Bool)")
			goal.WriteString("(and (not (alpha k))")
			for i:=1; i<tc.relations; i++ {
				fmt.Fprintf(&decls, "(declare-fun side%d (U) Bool)", i)
				fmt.Fprintf(&goal, " (side%d k)", i)
			}
			goal.WriteByte(')')
			input = strings.Replace(input, "(declare-const k U)", decls.String()+"(declare-const k U)", 1)
			input = strings.Replace(input, "(assert (not (alpha k)))", "(assert "+goal.String()+")", 1)
			ctx, s := orderSolver(t, input)
			m, err := ctx.Manager()
			astTestMust(t, err)
			roots, err := solver.Assertions(s.solver)
			astTestMust(t, err)
			batch := s.BeginOrderProofBatch()
			t.Cleanup(func() { astTestMust(t, batch.Close()) })
			want := tc.selected || tc.fact && !batch.state.plans.reusable(m)
			got, err := batch.state.proveRelevantPremises(m, roots)
			if err != nil || got != want {
				t.Fatalf("selected proof %t, want %t, error %v", got, want, err)
			}
			result, err := s.Check()
			if err != nil || result == lbool.Undef || (result == lbool.False) != tc.fact {
				t.Fatalf("full solver result %v, want unsat=%t, error %v", result, tc.fact, err)
			}
		})
	}'''+t[j:]
 return {p:s,q:t}
def tests(o):
 with(w/'build.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_SH)
  for n,tags in [('fast',['-tags=xtrace_off']),('default',[])]:
   with(rd/('test-'+n+'.log')).open('w')as f:
    run(['go','test','-p','3','-count=1','-overlay='+str(o),*tags,'./api','./api/internal/order'],cwd=pkg,stdout=f,stderr=f)
def main():
 o=overlay(rd/'overlay',sources())
 with ThreadPoolExecutor(2)as ex:
  ft=ex.submit(tests,o);b=build(rd/'checker',o=o);(rd/'info.txt').write_text(linked(b))
  ho.root=rd;gc.d=rd
  bs={'before':d/'release-arena-generation/checker/goivy_check','after':b,'native':native}
  jobs=[(c,*j[1:])for c,j in zip([3,8,15],ho.jobs()[:3])]
  jobs += [(25,'sys_live','doc/examples/apple/ord_live2.ivy','sys_live',0,w/'long-alternatives/ord2-sys/reference'),(32,'issue73','jea/issue73/ord.ivy','',0,w/'extended-phases/long/3/1/native')]
  jobs += [(c,*j[1:])for c,j in zip([2,12,21,33,38,44,46],(j for j in sf.jobs()if j[1]in('tlb','hybrid','hermes_rmw_o3','ticket_protocol','arm_rules3','flash_example','alternate_bit')))]
  jobs += [(c,*j[1:5],j[-1])for c,j in zip([4,13,22,40,45],(j for j in mi.jobs()if j[1]in('rfn2','dramc_nb2','cf_live','raft_no_assume_test','toy_consensus')))]
  assert len({j[1]for j in jobs})==len(jobs)
  (rd/'cases.csv').write_text('\n'.join(','.join(map(str,j)) for j in jobs)+'\n')
  with ThreadPoolExecutor(len(jobs)+1)as pool:
   fs=[pool.submit(gc.corpus,b)]+[pool.submit(ho.measure_spec,j,bs,3) for j in jobs]
   for f in fs:f.result()
  ft.result()
if __name__=='__main__':main()
