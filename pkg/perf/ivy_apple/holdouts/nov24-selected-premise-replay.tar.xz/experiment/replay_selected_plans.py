from common import *
import enum_matched_profiles as mp
rd=d/'replay-selected-plans';rd.mkdir(exist_ok=True)
root=d/'selected-phase-evidence/apple2/after-capture'
def lane(v,cpu,qs):
 b={'g3':d/'release-arena-generation/g3','native':pkg.parent/'build/z3'}[v]
 dest=rd/f'{v}-{cpu}.csv'
 with dest.open('w')as f:
  z=csv.writer(f);z.writerow('ordinal solver mode limit oracle answer decisions conflicts instances rlimit instructions cycles wall'.split())
  for qi,ref in qs:
   src=next(root.glob(f'{qi:04d}-*.smt2.gz'))
   raw=gzip.decompress(src.read_bytes())
   for mode,macro,mbqi in [('match','true','false'),('macro','true','true'),('default','false','true')]:
    for limit in (20000,50000,100000,250000,1000000):
     params=f'(set-option :smt.macro_finder {macro})(set-option :smt.mbqi {mbqi})(set-option :rlimit {limit})\n'.encode()
     # Parse options before the assertions; the shell charges work differently from the live private manager.
     inp=params+raw;pf=rd/f'{v}-{cpu}.perf';start=time.monotonic()
     p=run(['taskset','-c',str(cpu),perf,'stat','-x,','-e','instructions:u,cycles:u','-o',pf,'--',b,'-in','-smt2','-st'],input=inp,capture_output=True,env=dict(env,GOMAXPROCS='1'));wall=time.monotonic()-start
     lines=p.stdout.decode().splitlines();assert p.stderr==b'' and lines[0]in ('sat','unknown','unsat')and not any('(error' in l for l in lines),(qi,v,mode,limit,lines[:3],p.stderr[-130:]);ans=lines[0];assert ans==ref or ans=='unknown',(qi,v,mode,limit,ans,ref)
     st=dict(mp.pars.findall(p.stdout.decode()));ins=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l]
     z.writerow([qi,v,mode,limit,ref,ans,*[st.get(k,0)for k in ('decisions','conflicts','quant-instantiations','rlimit-count')],*ins,round(wall,6)]);f.flush()
def main():
 rows=readcsv(root/'independent.csv');qs=[(int(x['query'][:4]),x['native_answer'])for x in rows];assert len(qs)==33
 with ThreadPoolExecutor(8)as e:
  fs=[e.submit(lane,v,c,qs[i::4])for v,cs in [('g3',[0,6,12,22]),('native',[4,11,17,31])]for i,c in enumerate(cs)]
  for f in fs:f.result()
if __name__=='__main__':main()
