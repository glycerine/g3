from common import *
import selective_premise_release as rel,live_checks as lc,holdouts as ho,stage_frontier as sf,macro_identity as mi
rd=d/'selected-phase-evidence';rd.mkdir(exist_ok=True)
def edits(candidate):
 br=lc.bridge;s=br.read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('\n\tif overallResult == smt.Unsat',i);p=s[i:j]
 p=once(p,'z3solver := s.newZ3Solver()','trialBatchSeq++;b:=trialBatchSeq;fmt.Fprintln(os.Stderr,"COST-OPEN",b);defer fmt.Fprintln(os.Stderr,"COST-CLOSE",b);z3solver := s.newZ3Solver()')
 p=once(p,'for _, fc := range finalCond {','for j,fc:=range finalCond{fmt.Fprintln(os.Stderr,"COST-GOAL",b,j+1)')
 p=once(p,'if proveGoal(zCond) {','stop:=trialPassBegin("early");yes:=proveGoal(zCond);stop();if yes {')
 p=once(p,'z3solver.Push()','stop:=trialPassBegin("push");z3solver.Push();stop()')
 p=p.replace('z3solver.Pop()','stop:=trialPassBegin("pop");z3solver.Pop();stop()')
 p=once(p,'res, err := s.decideZ3With(z3solver, finalCheck)','stopCheck:=trialPassBegin("check");res, err := s.decideZ3With(z3solver, finalCheck);stopCheck()')
 s=s[:i]+p+s[j:]+'\nvar trialBatchSeq int\n'
 if '"os"'not in s:s=once(s,'import (','import ("os";')
 ed={br:s,br.parent/'selected_phase_benchmark_observer.go':lc.helper.replace('package smt','package goivy')}
 if candidate:
  f=pkg/'api/api_verification_goal.go';s=rel.sources()[f]
  s=once(s,'import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast";"fmt";"os";"compress/gzip")')
  s=once(s,'if yes, err := check(wide, steps); yes || err != nil || m.ResourceLimit().CancelFlag() {','''yes, err := check(wide, steps)
  if steps==20000 {
    trialOrdinal++
    fmt.Fprintln(os.Stderr,"SELECT",trialOrdinal,len(base.rows),len(relations),len(narrow),len(wide),yes)
    if os.Getenv("G3_SAVE_PREMISE")=="1" {
      ctx:=SMTContext{smtContextState:p.source.owner}
      data,e:=ctx.BenchmarkSMT2(goal,APIBenchmarkConfig{Assumptions:wide});if e!=nil{panic(e)}
      f,e:=os.Create(fmt.Sprintf("%04d-%t.smt2.gz",trialOrdinal,yes));if e!=nil{panic(e)};z:=gzip.NewWriter(f)
      if _,e=z.Write([]byte(data));e!=nil{panic(e)};if e=z.Close();e!=nil{panic(e)};if e=f.Close();e!=nil{panic(e)}
    }
  }
  if yes || err!=nil || m.ResourceLimit().CancelFlag(){''')+'\nvar trialOrdinal int\n'
  ed[f]=s
 return ed
def make(mode):
 sd=rd/mode;return build(sd/'checker',o=overlay(sd/'overlay',edits(mode=='after')))
def runone(j,mode,b,capture):
 c,n,sp,iso,rc,ref=j;sd=rd/n/(mode+('-capture'if capture else''));sd.mkdir(parents=True);scope=[];groups=defaultdict(Counter);rest=bytearray();obs=[]
 with(sd/'stdout').open('wb')as out,subprocess.Popen(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],env=dict(env,GOMAXPROCS='1',GOGC='100',G3_SAVE_PREMISE='1'if capture else'0'),cwd=sd,stdout=out,stderr=subprocess.PIPE)as p:
  for line in p.stderr:
   if line.startswith(b'COST-OPEN '):scope.append([int(line.split()[1]),0])
   elif line.startswith(b'COST-CLOSE '):assert scope.pop()[0]==int(line.split()[1])
   elif line.startswith(b'COST-GOAL '):
    _,bat,goal=line.split();assert int(bat)==scope[-1][0];scope[-1][1]=int(goal)
   elif line.startswith(b'INNER-CHECK '):
    _,name,tid,lo,hi,cost,empty=line.split();x=groups[tuple(scope[-1])if scope else(0,0)];x[name.decode()]+=int(cost)-int(empty);x[name.decode()+'_count']+=1
   elif line.startswith(b'SELECT '):obs.append([*(scope[-1]if scope else(0,0)),*line.decode().split()[1:]])
   else:rest.extend(line)
  code=p.wait()
 assert not scope and(code,(sd/'stdout').read_bytes(),rest)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(n,mode,code,rest[-500:])
 ks='early push check pop'.split();ks+= [x+'_count'for x in ks]
 with gzip.open(sd/'checks.csv.gz','wt')as f:
  z=csv.writer(f);z.writerow(['batch','goal',*ks]);z.writerows([*k,*[v[x]for x in ks]]for k,v in sorted(groups.items()))
 with(sd/'selected.csv').open('w')as f:
  z=csv.writer(f);z.writerow('batch goal ordinal source relations narrow wide proved'.split());z.writerows(obs)
 (sd/'validation').write_text('matched exit and both complete output streams\n')
 if capture:
  with(sd/'independent.csv').open('w')as f:
   z=csv.writer(f);z.writerow('query g3_proved native_answer'.split())
   for src in sorted(sd.glob('*.smt2.gz')):
    payload=gzip.decompress(src.read_bytes());assert b'(check-sat)'in payload
    res=run(['taskset','-c',str(c),pkg.parent/'build/z3','-T:15','-in','-smt2'],input=payload,capture_output=True)
    verdict=res.stdout.strip();assert res.stderr==b'' and verdict in (b'unsat',b'sat',b'unknown',b'timeout'),(src,res.stdout[-500:],res.stderr[-500:]);proved=src.name.endswith('-true.smt2.gz');assert not proved or verdict==b'unsat',(src,verdict);z.writerow([src.name,int(proved),verdict.decode()]);f.flush()
 print(n,mode,capture,len(obs),sum(x[-1]=='true'for x in obs),flush=True)
def main():
 with ThreadPoolExecutor(2)as e:bs=dict(zip(['before','after'],e.map(make,['before','after'])))
 js=ho.jobs()[:2]+[(20,'sys_live','doc/examples/apple/ord_live2.ivy','sys_live',0,w/'long-alternatives/ord2-sys/reference')]+[j for j in sf.jobs()if j[1]=='tlb']
 with ThreadPoolExecutor(12)as e:
  fs=[e.submit(runone,(cpu,*j[1:]),mode,bs[mode],cap)for cs,j in zip([(1,17,34),(6,18,31),(0,14,36),(9,26,41)],js)for cpu,(mode,cap)in zip(cs,[('before',False),('after',False),('after',True)])]
  for f in fs:f.result()
if __name__=='__main__':main()
