from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();a=p/'math/grobner/basis.go';s=a.read_text()
i=s.index('c := numeral.NewRational()',s.index('func (s *Solver) mulAppend'));j=s.index('\n}',i)
s=s[:i]+'''for _, m := range source.monomials[start:] {
		n := &Monomial{coeff: numeral.NewRational(), owner:s, live:true}
		if err := s.q.Mul(&m.coeff, coeff, &n.coeff); err != nil {
			return errors.Join(err,s.delMonomial(n))
		}
		n.vars = make([]ast.ASTHandle,0,len(m.vars)+len(vars))
		n.vars = append(n.vars,m.vars...)
		n.vars = append(n.vars,vars...)
		for i,v := range n.vars {
			if err := s.manager.IncRef(v); err != nil {
				n.vars = n.vars[:i]
				return errors.Join(err,s.delMonomial(n))
			}
		}
		if err := s.sortVars(n.vars); err != nil {return errors.Join(err,s.delMonomial(n))}
		*out = append(*out,n)
	}
	return nil'''+s[j:]
g=w/'basis.go';g.write_text(s);subprocess.run(['gofmt','-w',g],check=True)
for tag,extra in [('base',{}),('trial',{str(a):str(g)})]:
 d=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());d['Replace'].update(extra)
 ov=w/(tag+'.json');ov.write_text(json.dumps(d))
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',ov,'-o',w/tag,'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
