from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
a=p/'smtcore/smt_model_table.go';b=p/'smtcore/smt_model_table_check.go';c=p/'smtcore/smt_model_checker.go'
s=a.read_text().replace('import (','import (\n"os"').replace('type tableModel struct {','var studyPolicy=os.Getenv("CARD_MODE")\n type tableModel struct {\nstudyArithmetic bool')
s=s.replace('if h.DeclKind == smtArithOpNum {','if studyPolicy!="base" && h.DeclKind == smtArithOpNum {').replace('id := g.integerID(number, sort)','g.studyArithmetic=true;id := g.integerID(number, sort)').replace('if !tableIntegerOperator','if studyPolicy=="base" || !tableIntegerOperator')
t=b.read_text();k='if model.Core().Manager() != m';t=t.replace(k,'g.studyArithmetic=false\n '+k).replace('defer g.clearModel()','defer func(){used:=g.studyArithmetic;g.clearModel();g.studyArithmetic=used}()')
u=c.read_text();k='if err != nil || status == lbool.False {'
u=u.replace(k,'''if c.tableScratch.studyArithmetic && status!=lbool.Undef {
 if studyPolicy=="observe"{println("NUMERIC",count,status,len(bindings),c.modelFinder!=nil,auxiliary.config.CertifyBoundedModelTables)}
 if studyPolicy=="valid" && status==lbool.True || studyPolicy=="witness" && status==lbool.False || studyPolicy=="unary" && count!=1 || studyPolicy=="multi" && count==1 || studyPolicy=="bounded" && !auxiliary.config.CertifyBoundedModelTables || studyPolicy=="open" && auxiliary.config.CertifyBoundedModelTables {status=lbool.Undef}
 };'''+k)
ov=w/'policy.json';files={}
for f,x in [(a,s),(b,t),(c,u)]:
 dst=w/('policy-'+f.name+'.txt');dst.write_text(x);files[str(f)]=str(dst)
ov.write_text(json.dumps({'Replace':files}))
src=(w/'complete.py').read_text();i=src.index('src=f.read_text()');j=src.index('subprocess.run',i)
src=src[:i]+"ov=w/'policy.json'\n"+src[j:];src=src.replace("['base','bv','lift','both','short','off']","['base','all','valid','witness','unary','multi','bounded','open']").replace("w/'verifier'","w/'policy-verifier'").replace("'complete-'","'policy-'").replace("('full-'","('policyfull-'").replace('range(5)','range(3)')
exec(compile(src,__file__,'exec'))
