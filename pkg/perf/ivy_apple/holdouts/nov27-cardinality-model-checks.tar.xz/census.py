from pathlib import Path
import csv,subprocess,collections,re,os
w=Path(__file__).resolve().parent; f=Path('/tmp/g3-frame-child/held-fixtures/card3-3-9.smt2')
keys=['decisions','conflicts','quant-instantiations','rlimit-count']
for m in ['g3','z3']:
 r=subprocess.run([w/m,'-in','-smt2'],input=f.read_bytes(),capture_output=True,check=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'))
 vals=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));assert r.stdout.startswith(b'unsat\n') and [int(vals[k]) for k in keys]==[616,27,665,154316]
 (w/(m+'.trace')).write_bytes(r.stderr)
 on=False;calls=0;pending=0;groups=[]
 for l in r.stderr.decode().splitlines():
  if l=='CQ begin':assert not on;on=True;calls+=1
  elif l=='CQ end':assert on;on=False
  elif l.startswith('CQ pending '):
   if on:groups.append([calls,int(l.split()[-1]),[]])
  elif l.startswith('CQ row '):
   if on:groups[-1][-1].append(l[7:])
  else:raise ValueError(l)
 assert not on
 with (w/(m+'-batches.csv')).open('w') as o:
  out=csv.writer(o);out.writerow(['check','pending','installed','rows']);out.writerows((i,n,len(rs),' '.join(rs)) for i,n,rs in groups)
 print(m,calls,len(groups),sum(g[1] for g in groups),sum(len(g[2]) for g in groups))
