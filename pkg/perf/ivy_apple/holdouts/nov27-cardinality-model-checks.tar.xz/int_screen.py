from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent;h=Path('/tmp/g3-frame-child')
s=(h/'compare.py').read_text().replace('ACTION_SCOPE=m','ACTION_SCOPE=m,CARD_MODE=m').replace('exe=w/m',"exe=w/'integer-verifier'").replace('cwd=w,capture_output','cwd=Path("/tmp/g3-frame-child"),capture_output');driver=w/'int_driver.py';driver.write_text(s)
cases=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines()
jobs=[subprocess.Popen([sys.executable,driver,f'arithmetic{i}_base_calc',str(cpu),'3',*cases[i::4]]) for i,cpu in enumerate([2,4,14,20])]
assert [j.wait() for j in jobs]==[0]*len(jobs)
