(declare-fun @Z () (_ BitVec 64))
(declare-fun @X () (_ BitVec 64))
(declare-fun @Y () (_ BitVec 64))
(assert true)
(assert (let ((a!1 (not (=> (and (bvult @X @Y) (bvult @Y @Z)) (bvult @X @Z)))))
  (and a!1)))

(check-sat)
(get-info :all-statistics)
