(declare-fun @X () (_ BitVec 64))
(declare-fun @Y () (_ BitVec 64))
(assert true)
(assert (and (bvult @X @Y) (bvult @Y @X)))

(check-sat)
(get-info :all-statistics)
