(declare-fun @X () (_ BitVec 64))
(declare-fun @Y () (_ BitVec 64))
(assert true)
(assert (and (not (or (bvult @X @Y) (= @X @Y) (bvult @Y @X)))))

(check-sat)
(get-info :all-statistics)
