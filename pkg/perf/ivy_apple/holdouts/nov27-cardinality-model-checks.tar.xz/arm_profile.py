from pathlib import Path
import collections,csv,re,os,subprocess
w=Path(__file__).resolve().parent;h=Path('/tmp/g3-frame-child');p=Path.cwd();perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
keys=['decisions','conflicts','quant-instantiations','rlimit-count'];gold={r['fixture']:r for r in csv.DictReader((h/'held-replay.csv').open()) if r['engine']=='z3'}
env=dict(os.environ,GOMAXPROCS='1',GOGC='off',DEBUGINFOD_URLS='')
with (w/'arm-children.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['fixture','engine','round','period','parent','child','samples'])
 for name in ['arm_rules3-6-5','arm_rules3-6-6']:
  for i in range(3):
   for engine in ['g3','native'][::1 if i%2==0 else -1]:
    period=200003+i*100;g=engine=='g3';data=w/'arm.data'
    r=subprocess.run(['taskset','-c','20',perf,'record','-B','-N','-q','-e','instructions:u','-c',str(period),'--call-graph','fp,48' if g else 'dwarf,8192','-o',data,h/'cli' if g else p.parent/'build/z3','-in','-smt2'],input=(h/'held-fixtures'/(name+'.smt2')).read_bytes(),env=env,capture_output=True,check=True);v=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));assert r.stdout.startswith(b'unsat\n') and not r.stderr and all(int(v.get(k,0))==int(gold[name][k]) for k in keys)
    raw=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',data],env=env,text=True);counts=collections.Counter()
    for sample in raw.strip().split('\n\n'):
     if ('MaterializeAndInternalize' if g else 'qi_queue::instantiate(smt::qi_queue::entry&)') not in sample:continue
     stack=[l.strip().partition(' ')[2].split('+0x')[0] for l in sample.splitlines()[1:]]
     marks=['(*SMTInternalizerState).assertExpression','(*SMTInternalizerState).Internalize','(*SMTInternalizerState).internalizeTerm','(*SMTInternalizerState).addRootClause'] if g else ['smt::context::internalize_assertion(','smt::context::internalize(','smt::context::internalize_term(','smt::context::mk_root_clause(']
     if not any(marks[0] in fn for fn in stack):continue
     for mark in marks:
      for j in range(len(stack)-1,-1,-1):
       if mark in stack[j]:
        counts[mark,stack[max(0,j-1)]]+=1;break
    for (par,child),n in counts.items():out.writerow([name,engine,i,period,par,child,n])
    f.flush()
