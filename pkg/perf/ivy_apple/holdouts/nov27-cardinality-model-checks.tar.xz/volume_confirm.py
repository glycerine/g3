from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'volume_release.py').read_text().split('cpus=[',1)[0]
exec(compile(s,__file__,'exec'))
jobs=[(14,'volume_quiet',['examples/ivy/card2.ivy','examples/ivy/card3.ivy','examples/ivy/indexset_test.ivy','examples/ivy/toy_consensus2.ivy'],25,['base','integer','native']),(2,'volume_outliers',['test/mc3.ivy','test/ordered_set.ivy','test/decreases1.ivy','test/mc4.ivy','test/vsync_paxos_temp.ivy','test/toma8.ivy','test/client_server_mc3.ivy','test/proving9.ivy','test/whilesome1.ivy','test/auto1.ivy','doc/examples/leader_election_ring_udp.ivy'],9,['mixed','integer'])]
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 fut=[pool.submit(run,*j) for j in jobs]
 for f in fut:f.result()
