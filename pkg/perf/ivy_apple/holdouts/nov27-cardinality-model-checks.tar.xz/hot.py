from pathlib import Path
import csv,subprocess,collections
w=Path(__file__).resolve().parent
with (w/'hot.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','inclusive','samples','function'])
 for eng,suffix in [('g3','.old'),('z3','')]:
  txt=subprocess.check_output(['/usr/lib/linux-tools/6.17.0-35-generic/perf','script','--no-inline','-F','tid,event,ip,sym','-i','/tmp/g3-frame-child/held.data'+suffix],text=True)
  a=collections.Counter();b=collections.Counter()
  for sample in txt.strip().split('\n\n'):
   if not ('(*SMTModelChecker).auxiliaryCounterexamples' in sample and '(*SMTKernel).reduceAssertedPending' in sample or 'smt::model_checker::check(quantifier*)' in sample and 'asserted_formulas::reduce()' in sample):continue
   frames=[l.strip().partition(' ')[2].split('+0x')[0] for l in sample.splitlines()[1:]]
   a[frames[0]]+=1;b.update(set(frames))
  for i,c in enumerate([a,b]):
   for fn,n in c.most_common():out.writerow([eng,i,n,fn])
