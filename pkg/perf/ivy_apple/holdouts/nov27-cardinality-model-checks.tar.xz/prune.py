from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'complete.py').read_text();i=s.index("src=f.read_text()");j=s.index('subprocess.run',i)
s=s[:i]+'''f=p/'smtcore/smt_asserted_ite.go'
s=f.read_text().replace('import (','import (\\n"os"')
key='if err := proc.Rewrite(assertion.Formula, out, proof); err != nil {'
assert s.count(key)==2
s=s.replace(key,\'''skip:=false
  if cardStudyPrune!="" && cardStudyPrune!="base" {
    if nonground && (cardStudyPrune=="ground" || cardStudyPrune=="both") {skip,err=k.manager.IsGround(assertion.Formula)}
    if !skip && err==nil && (cardStudyPrune=="noite" || cardStudyPrune=="both"){var has bool;has,err=k.manager.HasQuantifiersOrITE(assertion.Formula);skip=!has}
  }
  if err==nil {if skip {err=k.manager.SetRef(out,assertion.Formula)} else {err=proc.Rewrite(assertion.Formula,out,proof)}}
  if err!=nil {\''',1)+'\\nvar cardStudyPrune=os.Getenv("CARD_MODE")\\n'
dst=w/'prune.go.txt';dst.write_text(s);ov=w/'prune.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
'''+s[j:];s=s.replace("['base','bv','lift','both','short','off']","['base','noite','ground','both']").replace("w/'verifier'","w/'prune-verifier'").replace("'complete-'","'prune-'").replace('modes[i:]+modes[:i]','modes[i%len(modes):]+modes[:i%len(modes)]').replace("('full-'","('prunefull-'")
exec(compile(s,__file__,'exec'))
