from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'release.py').read_text().split('cpus=[',1)[0]
exec(compile(s,__file__,'exec'))
run(22,'quiet',['examples/ivy/card3.ivy','examples/ivy/toy_consensus2.ivy','examples/ivy/card2.ivy'],25,['base','release','native'])
