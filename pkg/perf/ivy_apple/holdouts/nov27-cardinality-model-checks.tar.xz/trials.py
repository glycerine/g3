from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent; mode=sys.argv[1]
f=p/'smtcore/smt_model_checker.go';s=f.read_text();key='c.auxiliaryContext = next'
code={'base':'','bv':'next.kernel.preprocessState.MaxBVSharing=false','lift':'next.kernel.preprocessState.LiftITE=smtLiftITENone;next.kernel.preprocessState.NonGroundLiftITE=smtLiftITENone','both':'next.kernel.preprocessState.MaxBVSharing=false;next.kernel.preprocessState.LiftITE=smtLiftITENone;next.kernel.preprocessState.NonGroundLiftITE=smtLiftITENone','off':'next.kernel.preprocess=false','short':'next.kernel.skipRepeatedPreprocessing=true;next.kernel.reduceIfSharingChanged=true'}[mode]
dst=w/(mode+'.go.txt');dst.write_text(s.replace(key,code+'\n'+key));ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-pgo=off','-overlay',ov,'-o',w/('cli-'+mode),'./cmd/g3'],check=True)
