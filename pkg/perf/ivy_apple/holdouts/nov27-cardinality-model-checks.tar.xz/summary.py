import csv,collections,sys
from pathlib import Path
from statistics import median
w=Path(__file__).resolve().parent
for pattern in sys.argv[1:]:
 d=collections.defaultdict(lambda:collections.defaultdict(list));bad=[]
 for f in w.glob(pattern):
  for x in csv.DictReader(f.open()):
   if x.get('status',x.get('answer')) not in ('match','unsat'):bad.append((x.get('case',x.get('fixture')),x['mode']));continue
   d[x.get('case',x.get('fixture'))][x['mode']].append(int(x['instructions']))
 for n,g in d.items():
  if 'base' in g:print(n,*(f'{m}:{100*(median(v)/median(g["base"])-1):+.2f}%' for m,v in g.items() if m!='base'))
 print('differences',set(bad))
