from pathlib import Path
import json,subprocess,re,shlex,sys
p=Path.cwd();w=Path(__file__).resolve().parent;b=p.parent/'build'
def edit(f,changes):
 s=f.read_text()
 for a,z in changes:
  assert s.count(a)==1,(f,a,s.count(a));s=s.replace(a,z)
 dst=w/(f.name+'.txt' if f.suffix=='.go' else f.name);dst.write_text(s);return dst
if sys.argv[1]=='g3':
 ov={}
 def go(name,changes):
  f=p/'smtcore'/name;ov[str(f)]=str(edit(f,changes))
 key='auxiliary := c.auxiliaryContext'
 go('smt_model_checker.go',[(key,key+'\n println("CQ begin"); defer println("CQ end")')])
 key='ready, err := k.reduceAssertedPending()'
 go('smt_kernel.go',[(key,'println("CQ pending",len(k.assertions)-k.assertedHead); '+key),('head, err = k.internalizePendingRow(head)','studyRow(k.manager,k.assertions[head].Formula); head, err = k.internalizePendingRow(head)')])
 z=w/'study.go.txt';z.write_text('''package smtcore
import ("strings";"github.com/glycerine/g3/pkg/ast")
func studyRow(m *ast.ASTManager, h ast.ASTHandle) {
 var b strings.Builder
 var walk func(ast.ASTHandle)
 walk=func(t ast.ASTHandle){
 hd,e:=m.NodeHeader(t);if e!=nil{panic(e)};b.WriteByte('(')
 if hd.Kind==ast.ASTApp {n,e:=m.GetASTName(hd.Decl);if e!=nil{panic(e)};v,e:=m.Symbols.String(n);if e!=nil{panic(e)};b.WriteString(v); if hd.NumArgs==0 && v=="Int"{num,_,ok,e:=m.ArithmeticNumeralText(t);if e!=nil{panic(e)};if ok{b.WriteString(num)}}
 for i:=uint32(0);i<hd.NumArgs;i++{x,e:=m.GetArg(t,i);if e!=nil{panic(e)};walk(x)}
 }else{b.WriteString("?")};b.WriteByte(')')};walk(h);println("CQ row",b.String())
}
''');ov[str(p/'smtcore/zz_card_install.go')]=str(z);o=w/'study.json';o.write_text(json.dumps({'Replace':ov}))
 subprocess.run(['go','build','-buildvcs=false','-pgo=off','-overlay',o,'-o',w/'g3','./cmd/g3'],check=True)
else:
 src=p.parent/'src/smt';s=src/'smt_context.cpp';k='void context::internalize_assertions() {';a='expr * f   = m_asserted_formulas.get_formula(qhead);'
 helper='''static void cq_row(std::ostream& o,expr* t){o<<"(";if(is_app(t)){auto* a=to_app(t);o<<a->get_decl()->get_name();if(a->get_num_args()==0 && a->get_decl()->get_name()==symbol("Int") && a->get_decl()->get_num_parameters() && a->get_decl()->get_parameter(0).is_rational())o<<a->get_decl()->get_parameter(0).get_rational();for(auto* x:*a)cq_row(o,x);}else{o<<"?";}o<<")";}\n    '''
 c=edit(s,[(k,helper+k+'\n std::cerr<<"CQ pending "<<(m_asserted_formulas.get_num_formulas()-m_asserted_formulas.get_qhead())<<"\\n";'),(a,a+'\n std::cerr<<"CQ row ";cq_row(std::cerr,f);std::cerr<<"\\n";')])
 k='bool model_checker::check(quantifier * q) {';m=edit(src/'smt_model_checker.cpp',[(k,k+'\n std::cerr<<"CQ begin\\n"; struct cq_end {~cq_end(){std::cerr<<"CQ end\\n";}} cq;')])
 mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l)
 objs=[]
 for f in [c,m]:
  o=w/(f.stem+'.o');subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',o,f],cwd=b,check=True);objs.append(o)
 link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',mk,re.M)[1];libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
 subprocess.run([conf['LINK'],'-o',w/'z3',*objs,*libs,*shlex.split(conf['LINK_EXTRA_FLAGS'])],cwd=b,check=True)
