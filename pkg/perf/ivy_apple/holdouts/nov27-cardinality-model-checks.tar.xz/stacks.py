from pathlib import Path
import csv,subprocess,collections
w=Path(__file__).resolve().parent
with (w/'stacks.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','parent','nearest_child','samples'])
 for eng,suffix in [('g3','.old'),('z3','')]:
  perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
  txt=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i','/tmp/g3-frame-child/held.data'+suffix],text=True)
  markers=['(*SMTKernel).internalizePending','(*SMTKernel).reduceAssertedPending','(*SMTKernel).invokeAssertedPass','(*SMTKernel).internalizePendingRow','smt::context::internalize_assertions','smt::context::reduce_assertions','smt::asserted_formulas::reduce()']
  c=collections.Counter()
  for row in txt.strip().split('\n\n'):
   if '(*SMTModelChecker).auxiliaryCounterexamples' not in row and 'smt::model_checker::check(quantifier*)' not in row:continue
   s=[l.strip().partition(' ')[2].split('+0x')[0] for l in row.splitlines()[1:]]
   for m in markers:
    for i,fr in enumerate(s):
     if fr.endswith(m) or fr.endswith(m+'()'):
      c[m,s[max(0,i-1)]]+=1;break
  for (m,s),v in c.most_common():out.writerow([eng,m,s,v])
