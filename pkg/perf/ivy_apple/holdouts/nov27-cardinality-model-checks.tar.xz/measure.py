from pathlib import Path
import csv,os,re,subprocess,time,sys
w=Path(__file__).resolve().parent;perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
names=sys.argv[2:]; modes=sys.argv[1].split(','); env=dict(os.environ,GOMAXPROCS='1',GOGC='off')
with (w/('trial-'+sys.argv[1]+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow(['fixture','round','mode','answer','instructions','ms','decisions','conflicts','instantiations','rlimit'])
 for n in names:
  src=Path('/tmp/g3-frame-child/held-fixtures')/(n+'.smt2')
  for i in range(5):
   for m in modes[i%len(modes):]+modes[:i%len(modes)]:
    t=time.monotonic();stat=w/'trial.stat'
    r=subprocess.run(['taskset','-c','14',perf,'stat','-x,','-o',stat,'-e','instructions:u','--',w/('cli-'+m),'-in','-smt2'],input=src.read_bytes(),capture_output=True,env=env,timeout=90)
    if r.returncode or not r.stdout.startswith(b'unsat\n') or r.stderr:
     out.writerow([n,i,m,'different','','','','','','']);(w/(n+'-'+m+'.err')).write_bytes(r.stderr);f.flush();continue
    vals=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([n,i,m,'unsat',ins,round(1000*(time.monotonic()-t),2),*[vals.get(k,0) for k in ['decisions','conflicts','quant-instantiations','rlimit-count']]]);f.flush()
