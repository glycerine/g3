from pathlib import Path
import subprocess,sys,os,csv,time,statistics,re,json
w=Path(__file__).resolve().parent;p=Path.cwd();frontend=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();f=p/'smtcore/smt_model_checker.go'
src=f.read_text().replace('import (','import (\n"os"')
key='c.auxiliaryContext = next';src=src.replace(key,'''switch os.Getenv("CARD_MODE") {
 case "off":next.kernel.preprocess=false
 case "bv":next.kernel.preprocessState.MaxBVSharing=false
 case "lift":next.kernel.preprocessState.LiftITE=smtLiftITENone;next.kernel.preprocessState.NonGroundLiftITE=smtLiftITENone
 case "both":next.kernel.preprocessState.MaxBVSharing=false;next.kernel.preprocessState.LiftITE=smtLiftITENone;next.kernel.preprocessState.NonGroundLiftITE=smtLiftITENone
 case "short":next.kernel.skipRepeatedPreprocessing=true;next.kernel.reduceIfSharingChanged=true
 };'''+key);dst=w/'runtime.go.txt';dst.write_text(src);ov=w/'runtime.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',ov,'-o',w/'verifier','./cmd/goivy_check'],cwd=frontend,check=True)
h=Path('/tmp/g3-frame-child');ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');names=(rank/'compat.txt').read_text().splitlines()
codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
def run(item):
 idx,case=item;cpu=[2,4,6,8,16,18][idx];modes=['base','bv','lift','both','short','off'];ref=rank/'compat'/str(names.index(case)+1)/'1/native';expected=(codes[case],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
 with (w/('complete-'+str(idx)+'.csv')).open('w') as f:
  out=csv.writer(f);out.writerow(['case','round','mode','status','instructions','ms']);failed=set()
  for i in range(5):
   for m in modes[i:]+modes[:i]:
    if m in failed:continue
    stat=w/('full-'+str(idx)+'.stat');t=time.monotonic()
    try:r=subprocess.run(['taskset','-c',str(cpu),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/'verifier',ex/case],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',CARD_MODE=m,GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=h,capture_output=True,timeout=30)
    except subprocess.TimeoutExpired:out.writerow([case,i,m,'timeout','',30000]);failed.add(m);continue
    ok=(r.returncode,r.stdout,r.stderr)==expected
    if not ok:failed.add(m)
    ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([case,i,m,'match' if ok else 'different',ins,round(1000*(time.monotonic()-t),2)]);f.flush()
from concurrent.futures import ThreadPoolExecutor
with ThreadPoolExecutor(6) as pool:list(pool.map(run,enumerate(sys.argv[1:])))
