from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'release.py').read_text().split('cpus=[',1)[0]
exec(compile(s,__file__,'exec'))
groups=[['test/ordered_set.ivy','test/derpar1.ivy','test/crashpong1.ivy','test/parameter2.ivy','doc/examples/leader_election_ring.ivy','doc/examples/networking/ip_spec1.ivy'],['jea/hermes_rmw_o3.ivy','examples/raft/raftok.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy'],['test/toy_consensus_mc.ivy','doc/examples/toy_consensus.ivy']]
with concurrent.futures.ThreadPoolExecutor(3) as pool:
 jobs=[pool.submit(run,cpu,'confirm'+str(j),names,7,['base','release']) for j,(cpu,names) in enumerate(zip([4,6,8],groups))]
 for job in jobs:job.result()
