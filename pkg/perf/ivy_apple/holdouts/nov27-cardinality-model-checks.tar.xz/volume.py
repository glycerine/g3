from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
a=p/'smtcore/smt_model_table.go';b=p/'smtcore/smt_model_table_check.go';c=p/'smtcore/smt_model_checker.go'
s=a.read_text().replace('import (','import (\n"os"').replace('type tableModel struct {','var studyPolicy=os.Getenv("CARD_MODE")\n type tableModel struct {\nstudyArithmetic bool;studyTuples int')
s=s.replace('if h.DeclKind == smtArithOpNum {','if studyPolicy!="base" && h.DeclKind == smtArithOpNum {').replace('id := g.integerID(number, sort)','g.studyArithmetic=true;id := g.integerID(number, sort)').replace('if !tableIntegerOperator','if studyPolicy=="base" || !tableIntegerOperator')
t=b.read_text();k='if model.Core().Manager() != m';t=t.replace(k,'g.studyArithmetic=false;g.studyTuples=0\n '+k).replace('defer g.clearModel()','defer func(){used,tuples:=g.studyArithmetic,g.studyTuples;g.clearModel();g.studyArithmetic=used;g.studyTuples=tuples}()')
t=t.replace('if tuples > tableMaxTuples {','g.studyTuples=tuples; if tuples > tableMaxTuples {',1)
u=c.read_text();k='if err != nil || status == lbool.False {'
u=u.replace(k,'''if c.tableScratch.studyArithmetic && status!=lbool.Undef {
 if studyPolicy=="observe"{println("NUMERIC",count,status,c.tableScratch.studyTuples,c.modelFinder!=nil,auxiliary.config.CertifyBoundedModelTables)}
 tuples:=c.tableScratch.studyTuples
 if studyPolicy=="three" && count<3 || studyPolicy=="four" && count<4 || studyPolicy=="eight" && tuples<8 || studyPolicy=="sixteen" && tuples<16 || studyPolicy=="thirtytwo" && tuples<32 || studyPolicy=="sixtyfour" && tuples<64 || studyPolicy=="valid" && status==lbool.True || studyPolicy=="witness" && status==lbool.False || studyPolicy=="unary" && count!=1 || studyPolicy=="multi" && count==1 || studyPolicy=="bounded" && !auxiliary.config.CertifyBoundedModelTables || studyPolicy=="open" && auxiliary.config.CertifyBoundedModelTables {status=lbool.Undef}
 };'''+k)
ov=w/'volume.json';files={}
for f,x in [(a,s),(b,t),(c,u)]:
 dst=w/('volume-'+f.name+'.txt');dst.write_text(x);files[str(f)]=str(dst)
ov.write_text(json.dumps({'Replace':files}))
src=(w/'complete.py').read_text();i=src.index('src=f.read_text()');j=src.index('subprocess.run',i)
src=src[:i]+"ov=w/'volume.json'\n"+src[j:];src=src.replace("['base','bv','lift','both','short','off']","['base','three','four','eight','sixteen','thirtytwo','sixtyfour']").replace("w/'verifier'","w/'volume-verifier'").replace("'complete-'","'volume-'").replace("('full-'","('policyfull-'").replace('range(5)','range(3)')
exec(compile(src,__file__,'exec'))
