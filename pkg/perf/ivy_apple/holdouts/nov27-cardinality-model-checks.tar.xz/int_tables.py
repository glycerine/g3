from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd()
a=p/'smtcore/smt_model_table.go';b=p/'smtcore/smt_model_table_check.go'
s=a.read_text().replace('import (','import (\n"os"\n"strconv"')
s=s.replace('type tableModel struct {','''var intMode=os.Getenv("CARD_MODE")
type tableModel struct {
 ints map[int]int64
 numbers map[int64]int''')
k='modelValue, err := g.manager.IsModelValue(value)'
s=s.replace(k,'''if intMode!="base"{
 h,e:=g.manager.NodeHeader(value);if e!=nil{return 0,e}
 if h.Kind==ast.ASTApp&&h.NumArgs==0&&h.DeclKind==0{
 txt,integer,ok,e:=g.manager.ArithmeticNumeralText(value);if e!=nil{return 0,e}
 if integer&&ok {v,e:=strconv.ParseInt(txt,10,32);if e==nil{sort,e:=g.manager.GetSort(value);if e!=nil{return 0,e};id:=g.intID(v,sort);g.values[id]=value;g.valueIDs[value]=id;return id,nil}}
 }}\n'''+k)
s=s.replace('clear(g.valueIDs)','clear(g.ints);clear(g.numbers);clear(g.valueIDs)')
s+='''\nfunc(g *tableModel) intID(v int64,sort ast.ASTHandle)int{
 if id:=g.numbers[v];id!=0{return id};if g.numbers==nil{g.numbers=make(map[int64]int);g.ints=make(map[int]int64)}
 id:=len(g.values);g.numbers[v]=id;g.ints[id]=v;g.values=append(g.values,ast.ASTHandle{});g.sorts=append(g.sorts,sort);return id
}\n'''
key='n.op = tableApplication\n\t\tdefault:'
assert s.count(key)==1
s=s.replace(key,key+'''
   if intMode=="compare" || intMode=="calc" {
    fid,e:=g.manager.ArithmeticFamilyID();if e!=nil{return 0,e}
    kind:=header.DeclKind
    if header.Family==fid && (kind>=2&&kind<=5&&header.NumArgs==2 || intMode=="calc"&&(kind==6||kind==7||kind==9)&&header.NumArgs>=2 || intMode=="calc"&&kind==8&&header.NumArgs==1) {
     n.op=-100-kind;break
    }
   }''');t=b.read_text();key='case tableApplication:'
t=t.replace(key,'''case -102,-103,-104,-105,-106,-107,-108,-109:
   id:=eval(0);x,ok:=g.ints[id];if !ok {g.incomplete=true;return 0}
   if term.op==-108{x=-x}
   for i:=1;i<len(term.args);i++{y,ok:=g.ints[eval(i)];if !ok{g.incomplete=true;return 0}
    switch term.op{case -102:return tableBool(x<=y);case -103:return tableBool(x>=y);case -104:return tableBool(x<y);case -105:return tableBool(x>y);case -106:x+=y;case -107:x-=y;case -109:x*=y}
    if x< -2147483648||x>2147483647{g.incomplete=true;return 0}
   };if x< -2147483648||x>2147483647{g.incomplete=true;return 0};return g.intID(x,g.sorts[id])
 '''+key)
ov=w/'integers.json';files={}
for file,src in [(a,s),(b,t)]:
 dst=w/('experiment-'+file.name+'.txt');dst.write_text(src);files[str(file)]=str(dst)
ov.write_text(json.dumps({'Replace':files}))
s=(w/'complete.py').read_text();i=s.index('src=f.read_text()');j=s.index('subprocess.run',i)
s=s[:i]+"ov=w/'integers.json'\n"+s[j:];s=s.replace("['base','bv','lift','both','short','off']","['base','eq','compare','calc']").replace("w/'verifier'","w/'integer-verifier'").replace("'complete-'","'integer-'").replace('modes[i:]+modes[:i]','modes[i%len(modes):]+modes[:i%len(modes)]').replace("('full-'","('intfull-'")
exec(compile(s,__file__,'exec'))
