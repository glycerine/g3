from pathlib import Path
import os,subprocess,csv
w=Path(__file__).resolve().parent;h=Path('/tmp/g3-frame-child');ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
import sys
with (w/'numeric-hits.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','arity','status','bindings','finder','bounded'])
 for name in sys.argv[1:]:
  r=subprocess.run([w/'policy-verifier',ex/name],cwd=h,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',CARD_MODE='observe',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True);lines=[]
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'NUMERIC '):out.writerow([name,*line.decode().split()[1:]])
   else:lines.append(line)
  ref=rank/'compat'/str(cases.index(name)+1)/'1/native'
  assert (r.returncode,r.stdout,b''.join(lines))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
