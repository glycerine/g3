from pathlib import Path
import sys,csv,json,time,concurrent.futures,subprocess,os
w=Path(__file__).resolve().parent;p=Path.cwd();scratch=(p/'build/.boolean-enode-cost').resolve();f=scratch/'apple-source/goivy'
flags=['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')]
subprocess.run([*flags,'-overlay',w/'integers.json','-o',w/'int-apple','./cmd/goivy_check'],cwd=f,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
def run(job):
 name,cpu=job;apple=name!='raft_no_assume';ref=(scratch/'apple-final' if apple else Path('/tmp/g3-nov22b/end-panel-final/large-a'))/name/'1/native'
 spec=ex/('doc/examples/apple/ord_live.ivy' if apple else 'examples/raft/raft_no_assume.ivy');exe=w/('shape-apple' if apple else 'shape')
 with (w/('int-long-'+name+'.csv')).open('w') as f:
  out=csv.writer(f);out.writerow(['case','round','mode','status','instructions','ms']);cap=180
  for i in range(3):
   for mode in ('base','calc')[::1 if not i%2 else -1]:
    exe=(w/'int-apple') if apple else w/'integer-verifier'
    stat=w/('int-long-'+name+'.stat');cmd=['taskset','-c',str(cpu),perf,'stat','-x,','-o',stat,'-e','instructions:u','--',exe,*(['isolate='+name] if apple else []),spec]
    start=time.monotonic()
    try:r=subprocess.run(cmd,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',ACTION_SCOPE=mode,CARD_MODE=mode,GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=Path("/tmp/g3-frame-child"),timeout=cap)
    except subprocess.TimeoutExpired:out.writerow([name,i,mode,'timeout','',round((time.monotonic()-start)*1000)]);return
    ms=round((time.monotonic()-start)*1000);good=(r.returncode,r.stdout,r.stderr)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    ins=next(v[0] for v in csv.reader(stat.open()) if len(v)>4 and v[2]=='instructions:u' and float(v[4])==100)
    out.writerow([name,i,mode,'match' if good else 'different',ins,ms]);f.flush()
    if not good:(w/('int-long-'+name+'.stderr')).write_bytes(r.stderr);return
    if mode=='base':cap=min(180,max(15,3*ms/1000))
with concurrent.futures.ThreadPoolExecutor(3) as pool:list(pool.map(run,[('raft_no_assume',26),('rfn2',28),('dramc_nb2',30)]))
