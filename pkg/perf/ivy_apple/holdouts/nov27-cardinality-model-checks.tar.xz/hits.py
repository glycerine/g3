from pathlib import Path
import csv,os,subprocess,json,sys
p=Path.cwd();w=Path(__file__).resolve().parent;h=Path('/tmp/g3-frame-child');rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');f=p/'smtcore/smt_model_checker.go';k='if err != nil || status == lbool.False {'
s=f.read_text().replace(k,'''for _, th:=range c.state.theories {if a,ok:=th.(*SMTTheoryArith); ok && (len(a.atoms)>0||len(a.varPos)>0){println("MIXED",count,status,len(c.tableScratch.terms),auxiliary.config.CertifyBoundedModelTables);break}}
  '''+k);dst=w/'hits.go.txt';dst.write_text(s);ov=w/'hits.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
subprocess.run(['go','build','-buildvcs=false','-pgo=off','-tags','xtrace_off','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-overlay',ov,'-o',w/'hits','./cmd/goivy_check'],cwd=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(),check=True)
cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
with (w/'hits.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','arity','status','terms_after_return','bounded'])
 for name in sys.argv[1:]:
  r=subprocess.run([w/'hits',ex/name],cwd=h,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True)
  lines=[]
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'MIXED '):out.writerow([name,*line.decode().split()[1:]])
   else:lines.append(line)
  ref=rank/'compat'/str(cases.index(name)+1)/'1/native'
  assert (r.returncode,r.stdout,b''.join(lines))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
