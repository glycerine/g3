Release and run identification

  6ed5d6e09 is the release measured in attach-production/controls.csv.
  The paired control is c8512b43d. The Python watch propagation driver ran
  all six satisfiable cases, nine rotations, CPU 13, Go 1.27.3 and GOMAXPROCS=1.
  propagation-lookup is the independent five-rotation observer on CPU 9.
  All checked models satisfied the complete CNF.

  The full Apple ord_live2 run uses the pair manifested in .nov26-later/pair/.
  The accepted rows meet .95 for before-idle, sibling-idle and measured
  user + system CPU fraction. One transcript is provided. Every attempt
  matched that transcript and was charged to the recorded backend.

  verification-pair/build.json identifies the c8512b43d g3 builds and the
  GoIvy local replacement. Ticket direct uses CPU 4, hybrid uses CPU 18.
  verification/ticket_protocol/ contains the preliminary PMU attempt which
  matched stdout/stderr but did not meet its .91 CPU-fraction threshold.
  The equality comparisons use the same pair and ABC binary and record
  .88 minimum core and sibling idle fractions across nine rotations.
