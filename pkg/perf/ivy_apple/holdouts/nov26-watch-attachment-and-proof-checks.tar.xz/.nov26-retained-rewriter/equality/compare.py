"""Compare individual quantifier changes with frozen g3 and linked Z3."""
from concurrent.futures import ThreadPoolExecutor
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd().resolve()
sys.path.insert(0, str(root/'perf/ivy_apple'))
from compare import EVENTS, measure
from holdouts.rotating_verification import idle, thread_siblings, ticks
from argparse import Namespace
import time

path = root / 'build/.nov26-retained-rewriter/equality'
reference = Path('/tmp/g3-nov24-day/archive-verifier-stacks')
cases = json.loads((reference/'cases.json').read_text())
engines = {
    'g3': root/'build/.nov26-cnf-profile/verification-pair/g3/goivy_check',
    'candidate': path/'goivy_check',
    'native': root/'build/.nov26-cnf-profile/verification-pair/native/goivy_check',
}

def run(name, cpu):
    spec, isolate, status = cases[name]
    out = path / 'confirmation' / name
    out.mkdir(parents=True)
    spec = Path('/home/jaten/ivy/ivy-lang-examples') / spec
    args = Namespace(cpu=cpu, spec=str(spec), isolate=isolate,
                     perf='/usr/lib/linux-tools/6.17.0-35-generic/perf')
    ref = [(reference/'reference'/name/s).read_bytes() for s in ('stdout','stderr')]
    siblings = thread_siblings(cpu)
    cpus = [cpu, *siblings]
    with (out/'runs.csv').open('x') as f:
        writer = csv.writer(f)
        writer.writerow(['round','engine','attempt','idle_before','sibling_idle','exit','match','wall','user','system','rss',*EVENTS])
        order = list(engines)
        for i, offset in enumerate([0,2,1,2,0,1,2,0,1],1):
            for engine in order[offset:]+order[:offset]:
                for attempt in range(1,13):
                    first = ticks(cpus)
                    time.sleep(1)
                    before = ticks(cpus)
                    rc, timing, counters = measure(str(engines[engine]), args, out/f'{i}-{engine}-{attempt}', status, 100)
                    after = ticks(cpus)
                    result = [(out/f'{i}-{engine}-{attempt}'/s).read_bytes() for s in ('stdout','stderr')]
                    inter = min(idle(before,after,c) for c in siblings)
                    ready = min(idle(first,before,c) for c in cpus)
                    writer.writerow([i,engine,attempt,ready,inter,rc,int(ref==result),*timing,*counters])
                    f.flush()
                    if rc != status or ref != result:
                        raise RuntimeError((name,engine,rc))
                    if min(ready,inter) >= .88:
                        break
                else:
                    raise RuntimeError(f'CPU {cpu} was busy for {name} {engine} round {i}')
    print(name, 'compared', flush=True)

with ThreadPoolExecutor(2) as pool:
    list(pool.map(run, ['ticket_protocol','hybrid'], [2,18]))
