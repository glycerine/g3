"""Build a theory rewriter that reads the fixed equality shape once."""
import json
import os
from pathlib import Path
import subprocess

pkg=Path.cwd().resolve()
ivy=Path.home()/'ivy/goivy'
out=pkg/'build/.nov26-retained-rewriter/equality'
module=json.loads(subprocess.check_output(['go','list','-mod=readonly','-m','-json','github.com/glycerine/g3/pkg'],
                                         cwd=ivy))
local=Path(module['Dir'])
assert local.samefile(pkg)
manager=Path('ast/ast_rewriter_access.go')
rewriter=Path('ast/rewriter/th_rewriter.go')
source=manager.read_text()+'''
// RewriterEqualityArguments returns the two arguments of a basic equality.
func (m *ASTManager) RewriterEqualityArguments(h ASTHandle) (left, right ASTHandle, matched bool, err error) {
	r, err := m.readNode(h)
	if err != nil || m.nodeAt(r.slot).kind != ASTApp {
		return left,right,false,err
	}
	app := m.appAt(r.slot)
	family, operation, err := m.appIdentity(app)
	if err != nil || family != m.BasicFamilyID() || operation != ASTOpEq || app.count != 2 {
		return left,right,false,err
	}
	a, err := m.appArg(app,0)
	if err != nil {
		return left,right,false,err
	}
	b, err := m.appArg(app,1)
	return m.external(a),m.external(b),err==nil,err
}
'''
s=rewriter.read_text()
start=s.index('kind, err :=',s.index('func (c *theoryRewriterConfiguration) equalityBit'))
end=s.index('\n\tisBV, err :=',start)
s=s[:start]+'''left, right, matched, err := c.owner.manager.RewriterEqualityArguments(term)
	if err != nil || !matched {
		return x, 0, false, err
	}'''+s[end:]
start=s.index('\n\tright, err := c.owner.manager.GetArg(term, 1)',start)
end=s.index('\n\tif v, yes, e := c.bitNumeral(left)',start)
s=s[:start]+s[end:]
m={}
for path,value in [(manager,source),(rewriter,s)]:
    obj=out/path.name
    obj.write_bytes(subprocess.check_output(['gofmt'],input=value.encode()))
    m[str(pkg/path)]=str(obj)
    m[str(local/path)]=str(obj)
path=out/'overlay.json'
path.write_text(json.dumps({"Replace":m}))
flags=['-p','6','-overlay='+str(path)]
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
with (out/'tests.log').open('w') as log:
    subprocess.run(['go','test','-count=1',*flags,'./ast','./ast/rewriter'], env=env, stdout=log,stderr=log,check=True)
subprocess.run(['go','build',*flags,'-mod=readonly','-pgo=off','-buildvcs=false','-tags=xtrace_off',
                '-o',out/'goivy_check','./cmd/goivy_check'],cwd=ivy,env=env,check=True)
abc=(pkg/'build/.nov26-cnf-profile/verification-pair/g3/abc').resolve()
(out/'abc').symlink_to(abc)
