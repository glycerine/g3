(set-info :status unknown)
(declare-sort hermes_protocol.version 0)
 (declare-datatypes ((hermes_protocol.hstate 0)) (((hermes_protocol.hs_valid) (hermes_protocol.hs_invalid) (hermes_protocol.hs_invalid_write) (hermes_protocol.hs_write) (hermes_protocol.hs_replay))))
 (declare-datatypes ((ltask 0)) (((ready_finish) (o3_finish))))
 (declare-sort hermes_protocol.value 0)
 (declare-sort hermes_protocol.epoch 0)
 (declare-sort hermes_protocol.node 0)
 (declare-sort hermes_protocol.ts 0)
 (declare-fun hermes_protocol.init_epoch () hermes_protocol.epoch)
(declare-fun hermes_protocol.init_ts () hermes_protocol.ts)
(declare-fun hermes_protocol.init_value () hermes_protocol.value)
(declare-fun __hermes_protocol.cur_ts (hermes_protocol.node) hermes_protocol.ts)
(declare-fun __hermes_protocol.cur_value (hermes_protocol.node) hermes_protocol.value)
(declare-fun __hermes_protocol.pending_ts (hermes_protocol.node) hermes_protocol.ts)
(declare-fun __hermes_protocol.state (hermes_protocol.node) hermes_protocol.hstate)
(declare-fun __hermes_protocol.ready_epoch (hermes_protocol.node) hermes_protocol.epoch)
(declare-fun hermes_protocol.ready_task () ltask)
(declare-fun hermes_protocol.o3_task () ltask)
(declare-fun |__loc:c| () hermes_protocol.node)
(declare-fun |__loc:w| () hermes_protocol.node)
(declare-fun |__loc:a| () hermes_protocol.node)
(declare-fun |__loc:b| () hermes_protocol.node)
(declare-fun |__loc:t1| () hermes_protocol.ts)
(declare-fun |__loc:t2| () hermes_protocol.ts)
(declare-fun |__loc:e| () hermes_protocol.epoch)
(declare-fun |__new_fml:n| () hermes_protocol.node)
(declare-fun |__new_fml:t| () hermes_protocol.ts)
(declare-fun |__loc:base_ver| () hermes_protocol.version)
(declare-fun |__fml:y| () hermes_protocol.version)
(declare-fun |__new_fml:x| () hermes_protocol.version)
(declare-fun |__fml:y_a| () hermes_protocol.version)
(declare-fun |__new_fml:x_a| () hermes_protocol.version)
(declare-fun |__fml:y_a_a| () hermes_protocol.version)
(declare-fun |__new_fml:x_a_a| () hermes_protocol.version)
(declare-fun |__new_fml:n_a| () hermes_protocol.node)
(declare-fun __m_hermes_protocol.state (hermes_protocol.node) hermes_protocol.hstate)
(declare-fun |__new_fml:t_a| () hermes_protocol.ts)
(declare-fun __m_hermes_protocol.cur_ts (hermes_protocol.node) hermes_protocol.ts)
(declare-fun |__loc:base_ver_a| () hermes_protocol.version)
(declare-fun |__fml:y_b| () hermes_protocol.version)
(declare-fun |__new_fml:x_b| () hermes_protocol.version)
(declare-fun |__fml:y_a_b| () hermes_protocol.version)
(declare-fun |__new_fml:x_a_b| () hermes_protocol.version)
(declare-fun |__fml:y_a_a_a| () hermes_protocol.version)
(declare-fun |__new_fml:x_a_a_a| () hermes_protocol.version)
(declare-fun |__new_fml:n_b| () hermes_protocol.node)
(declare-fun |__new_fml:s| () hermes_protocol.node)
(declare-fun |__new_fml:v_b| () hermes_protocol.value)
(declare-fun |__new_fml:t_b| () hermes_protocol.ts)
(declare-fun |__new_fml:n_c| () hermes_protocol.node)
(declare-fun |__new_fml:s_a| () hermes_protocol.node)
(declare-fun |__new_fml:v_c| () hermes_protocol.value)
(declare-fun |__new_fml:t_c| () hermes_protocol.ts)
(declare-fun |__new_fml:n_d| () hermes_protocol.node)
(declare-fun |__new_fml:s_b| () hermes_protocol.node)
(declare-fun |__new_fml:v_d| () hermes_protocol.value)
(declare-fun |__new_fml:t_d| () hermes_protocol.ts)
(declare-fun |__new_fml:n_e| () hermes_protocol.node)
(declare-fun |__new_fml:s_c| () hermes_protocol.node)
(declare-fun |__new_fml:v_e| () hermes_protocol.value)
(declare-fun |__new_fml:t_e| () hermes_protocol.ts)
(declare-fun |__new_fml:n_f| () hermes_protocol.node)
(declare-fun |__new_fml:t_f| () hermes_protocol.ts)
(declare-fun hermes_protocol.pending_ts (hermes_protocol.node) hermes_protocol.ts)
(declare-fun |__new_fml:a| () hermes_protocol.node)
(declare-fun |__ts0__ts0__new_fml:n_g_a| () hermes_protocol.node)
(declare-fun |__ts0__new_fml:n_g_b| () hermes_protocol.node)
(declare-fun |__ts0__new_fml:t_g_b| () hermes_protocol.ts)
(declare-fun |__ts0__new_fml:a_a_b| () hermes_protocol.node)
(declare-fun |__ts0__new_fml:n_h_a| () hermes_protocol.node)
(declare-fun |0:hermes_protocol.version| () hermes_protocol.version)
(declare-fun |__loc:v1| () hermes_protocol.value)
(declare-fun |__new_fml:v| () hermes_protocol.value)
(declare-fun |__new_loc:0_b| () hermes_protocol.version)
(declare-fun |__new_loc:mid_ver| () hermes_protocol.version)
(declare-fun |__new_loc:0_a| () hermes_protocol.version)
(declare-fun |__new_loc:new_ver| () hermes_protocol.version)
(declare-fun |__new_loc:0| () hermes_protocol.version)
(declare-fun |__new_loc:after_ver| () hermes_protocol.version)
(declare-fun |__loc:v2| () hermes_protocol.value)
(declare-fun |__new_fml:v_a| () hermes_protocol.value)
(declare-fun |__new_loc:0_b_a| () hermes_protocol.version)
(declare-fun |__new_loc:mid_ver_a| () hermes_protocol.version)
(declare-fun |__new_loc:0_a_a| () hermes_protocol.version)
(declare-fun |__new_loc:new_ver_a| () hermes_protocol.version)
(declare-fun |__new_loc:0_c| () hermes_protocol.version)
(declare-fun |__new_loc:after_ver_a| () hermes_protocol.version)
(declare-fun __m_hermes_protocol.cur_ts_a (hermes_protocol.node) hermes_protocol.ts)
(declare-fun __m_hermes_protocol.cur_ts_b (hermes_protocol.node) hermes_protocol.ts)
(declare-fun __m_hermes_protocol.cur_ts_c (hermes_protocol.node) hermes_protocol.ts)
(declare-fun __m_hermes_protocol.cur_ts_d (hermes_protocol.node) hermes_protocol.ts)
(declare-fun |__ts0__ts0__new_fml:a_a_a| () hermes_protocol.node)
(declare-fun |__ts0__ts0__new_fml:t_g_a| () hermes_protocol.ts)
(declare-fun |__ts0__new_fml:a_b_a| () hermes_protocol.node)
(declare-fun |__ts0__new_fml:t_h_a| () hermes_protocol.ts)
(declare-fun hermes_protocol.ready_epoch (hermes_protocol.node) hermes_protocol.epoch)
(declare-fun hermes_protocol.cur_ts (hermes_protocol.node) hermes_protocol.ts)
(declare-fun __hermes_protocol.seen_epoch (hermes_protocol.epoch) Bool)
(declare-fun __hermes_protocol.seen_ts (hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.completed (hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.ts_value (hermes_protocol.ts hermes_protocol.value) Bool)
(declare-fun __hermes_protocol.ts_rmw (hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.parent (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun hermes_protocol.lt (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.same_parent (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.ts_version (hermes_protocol.ts hermes_protocol.version) Bool)
(declare-fun __hermes_protocol.same_version (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.next_version (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun |<:hermes_protocol.version:hermes_protocol.version| (hermes_protocol.version hermes_protocol.version) Bool)
(declare-fun __hermes_protocol.rmw_conflict (hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.write_conflict (hermes_protocol.ts) Bool)
(declare-fun hermes_protocol.live (hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.inv_write (hermes_protocol.node hermes_protocol.ts hermes_protocol.value) Bool)
(declare-fun hermes_protocol.inv_rmw (hermes_protocol.node hermes_protocol.ts hermes_protocol.value) Bool)
(declare-fun __hermes_protocol.ack_msg (hermes_protocol.node hermes_protocol.node hermes_protocol.ts) Bool)
(declare-fun hermes_protocol.le (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun hermes_protocol.val_msg (hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.o3_quorum (hermes_protocol.node hermes_protocol.node hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.cur_rmw (hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.pending (hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.acked (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.pending_rmw (hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.ready (hermes_protocol.node) Bool)
(declare-fun hermes_protocol.client_write_pending (hermes_protocol.node) Bool)
(declare-fun hermes_protocol.client_rmw_pending (hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.ready_epoch_active (hermes_protocol.epoch) Bool)
(declare-fun __hermes_protocol.epoch_done (hermes_protocol.epoch) Bool)
(declare-fun hermes_protocol.complete_try (hermes_protocol.node) Bool)
(declare-fun hermes_protocol.o3_try (hermes_protocol.node hermes_protocol.node hermes_protocol.ts) Bool)
(declare-fun __hermes_protocol.write_then_write_order_ok (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __ts0_f () Bool)
(declare-fun __ts0_e () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun hermes_protocol.version.succ (hermes_protocol.version hermes_protocol.version) Bool)
(declare-fun __m_hermes_protocol.pending (hermes_protocol.node) Bool)
(declare-fun __m_hermes_protocol.seen_ts (hermes_protocol.ts) Bool)
(declare-fun __m_hermes_protocol.ts_version (hermes_protocol.ts hermes_protocol.version) Bool)
(declare-fun hermes_protocol.inv_write (hermes_protocol.node hermes_protocol.ts hermes_protocol.value) Bool)
(declare-fun hermes_protocol.pending (hermes_protocol.node) Bool)
(declare-fun hermes_protocol.ack_msg (hermes_protocol.node hermes_protocol.node hermes_protocol.ts) Bool)
(declare-fun __m_hermes_protocol.acked_e (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __ts0__m_hermes_protocol.acked_f_b (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.rmw_then_write_order_ok (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __hermes_protocol.rmw_then_rmw_order_ok (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __m_hermes_protocol.pending_a (hermes_protocol.node) Bool)
(declare-fun __m_hermes_protocol.ready_a (hermes_protocol.node) Bool)
(declare-fun __ts0__ts0_b () Bool)
(declare-fun __ts0__ts0_a () Bool)
(declare-fun __m_hermes_protocol.pending_rmw_a (hermes_protocol.node) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __m_hermes_protocol.pending_b (hermes_protocol.node) Bool)
(declare-fun __m_hermes_protocol.ready_b (hermes_protocol.node) Bool)
(declare-fun __ts0__ts0_b_a () Bool)
(declare-fun __ts0__ts0_a_a () Bool)
(declare-fun __m_hermes_protocol.pending_rmw_b (hermes_protocol.node) Bool)
(declare-fun __ts0_c_a () Bool)
(declare-fun __m_hermes_protocol.pending_c (hermes_protocol.node) Bool)
(declare-fun __m_hermes_protocol.ready_c (hermes_protocol.node) Bool)
(declare-fun __ts0__ts0_b_b () Bool)
(declare-fun __ts0__ts0_a_b () Bool)
(declare-fun __m_hermes_protocol.pending_rmw_c (hermes_protocol.node) Bool)
(declare-fun __ts0_c_b () Bool)
(declare-fun __m_hermes_protocol.pending_d (hermes_protocol.node) Bool)
(declare-fun __m_hermes_protocol.ready_d (hermes_protocol.node) Bool)
(declare-fun __ts0__ts0_b_c () Bool)
(declare-fun __ts0__ts0_a_c () Bool)
(declare-fun __m_hermes_protocol.pending_rmw_d (hermes_protocol.node) Bool)
(declare-fun __ts0_c_c () Bool)
(declare-fun __m_hermes_protocol.epoch_done_c (hermes_protocol.epoch) Bool)
(declare-fun __ts0__ts0__m_hermes_protocol.epoch_done_d_a (hermes_protocol.epoch) Bool)
(declare-fun __ts0__m_hermes_protocol.epoch_done_e_a (hermes_protocol.epoch) Bool)
(declare-fun hermes_protocol.epoch_done (hermes_protocol.epoch) Bool)
(declare-fun __ts0__ts0__m_hermes_protocol.acked_f_a (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __ts0__m_hermes_protocol.acked_g_a (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun hermes_protocol.acked (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun __m_hermes_protocol.ready_e (hermes_protocol.node) Bool)
(declare-fun __ts0__ts0__m_hermes_protocol.ready_f_a (hermes_protocol.node) Bool)
(declare-fun __ts0__m_hermes_protocol.ready_g_a (hermes_protocol.node) Bool)
(declare-fun hermes_protocol.ready (hermes_protocol.node) Bool)
(declare-fun __ts0__ts0__ts0_a_e () Bool)
(declare-fun __ts0__ts0_a_f () Bool)
(declare-fun __ts0__m_hermes_protocol.epoch_done_d_b (hermes_protocol.epoch) Bool)
(declare-fun __ts0__m_hermes_protocol.ready_f_b (hermes_protocol.node) Bool)
(declare-fun __ts0__ts0_a_a_b () Bool)
(declare-fun hermes_protocol.seen_epoch (hermes_protocol.epoch) Bool)
(declare-fun hermes_protocol.ready_epoch_active (hermes_protocol.epoch) Bool)
(declare-fun hermes_protocol.completed (hermes_protocol.ts) Bool)
(declare-fun hermes_protocol.same_version (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun hermes_protocol.write_then_write_order_ok (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun hermes_protocol.next_version (hermes_protocol.ts hermes_protocol.ts) Bool)
(declare-fun hermes_protocol.rmw_then_write_order_ok (hermes_protocol.node hermes_protocol.node) Bool)
(declare-fun hermes_protocol.rmw_then_rmw_order_ok (hermes_protocol.node hermes_protocol.node) Bool)
(assert
 (__hermes_protocol.seen_epoch hermes_protocol.init_epoch))
(assert
 (__hermes_protocol.seen_ts hermes_protocol.init_ts))
(assert
 (__hermes_protocol.completed hermes_protocol.init_ts))
(assert
 (__hermes_protocol.ts_value hermes_protocol.init_ts hermes_protocol.init_value))
(assert
 (not (__hermes_protocol.ts_rmw hermes_protocol.init_ts)))
(assert
 (forall ((|B:hermes_protocol.ts| hermes_protocol.ts) )(not (__hermes_protocol.parent hermes_protocol.init_ts |B:hermes_protocol.ts|)))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|V1:hermes_protocol.value| hermes_protocol.value) (|V2:hermes_protocol.value| hermes_protocol.value) )(let (($x2723 (and (__hermes_protocol.ts_value |T:hermes_protocol.ts| |V1:hermes_protocol.value|) (__hermes_protocol.ts_value |T:hermes_protocol.ts| |V2:hermes_protocol.value|))))
 (=> $x2723 (= |V1:hermes_protocol.value| |V2:hermes_protocol.value|))))
 )
(assert
 (forall ((|B1:hermes_protocol.ts| hermes_protocol.ts) (|B2:hermes_protocol.ts| hermes_protocol.ts) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3773 (__hermes_protocol.parent |T:hermes_protocol.ts| |B1:hermes_protocol.ts|)))
 (=> (and $x3773 (__hermes_protocol.parent |T:hermes_protocol.ts| |B2:hermes_protocol.ts|)) (= |B1:hermes_protocol.ts| |B2:hermes_protocol.ts|))))
 )
(assert
 (forall ((|B:hermes_protocol.ts| hermes_protocol.ts) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x48 (hermes_protocol.lt |B:hermes_protocol.ts| |T:hermes_protocol.ts|)))
 (let (($x3141 (__hermes_protocol.seen_ts |B:hermes_protocol.ts|)))
 (let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (=> (__hermes_protocol.parent |T:hermes_protocol.ts| |B:hermes_protocol.ts|) (and $x257 $x3141 $x48))))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |U:hermes_protocol.ts|)))
 (let (($x3141 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x4213 (and $x3141 $x257)))
 (let (($x2749 (__hermes_protocol.same_parent |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> $x2749 $x4213))))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x1197 (and (not (= |T:hermes_protocol.ts| hermes_protocol.init_ts)) (not (= |U:hermes_protocol.ts| hermes_protocol.init_ts)))))
 (let (($x2749 (__hermes_protocol.same_parent |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> $x2749 $x1197))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x2749 (__hermes_protocol.same_parent |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> $x2749 (__hermes_protocol.same_parent |U:hermes_protocol.ts| |T:hermes_protocol.ts|))))
 )
(assert
 (forall ((|B1:hermes_protocol.ts| hermes_protocol.ts) (|B2:hermes_protocol.ts| hermes_protocol.ts) (|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3773 (__hermes_protocol.parent |U:hermes_protocol.ts| |B2:hermes_protocol.ts|)))
 (let (($x2749 (__hermes_protocol.same_parent |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> (and $x2749 (__hermes_protocol.parent |T:hermes_protocol.ts| |B1:hermes_protocol.ts|) $x3773) (= |B1:hermes_protocol.ts| |B2:hermes_protocol.ts|)))))
 )
(assert
 (forall ((|B:hermes_protocol.ts| hermes_protocol.ts) (|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3773 (__hermes_protocol.parent |U:hermes_protocol.ts| |B:hermes_protocol.ts|)))
 (let (($x2095 (__hermes_protocol.parent |T:hermes_protocol.ts| |B:hermes_protocol.ts|)))
 (let (($x2749 (__hermes_protocol.same_parent |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> (and $x2749 $x2095) $x3773)))))
 )
(assert
 (forall ((|B:hermes_protocol.ts| hermes_protocol.ts) (|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x2095 (__hermes_protocol.parent |T:hermes_protocol.ts| |B:hermes_protocol.ts|)))
 (let (($x3773 (__hermes_protocol.parent |U:hermes_protocol.ts| |B:hermes_protocol.ts|)))
 (let (($x2749 (__hermes_protocol.same_parent |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> (and $x2749 $x3773) $x2095)))))
 )
(assert
 (forall ((|B:hermes_protocol.ts| hermes_protocol.ts) (|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x2749 (__hermes_protocol.same_parent |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (let (($x29 (= |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (let (($x46 (not $x29)))
 (let (($x3773 (__hermes_protocol.parent |U:hermes_protocol.ts| |B:hermes_protocol.ts|)))
 (let (($x2095 (__hermes_protocol.parent |T:hermes_protocol.ts| |B:hermes_protocol.ts|)))
 (=> (and $x2095 $x3773 $x46) $x2749)))))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|V1:hermes_protocol.version| hermes_protocol.version) (|V2:hermes_protocol.version| hermes_protocol.version) )(let (($x205 (= |V1:hermes_protocol.version| |V2:hermes_protocol.version|)))
 (let (($x3634 (__hermes_protocol.ts_version |T:hermes_protocol.ts| |V2:hermes_protocol.version|)))
 (=> (and (__hermes_protocol.ts_version |T:hermes_protocol.ts| |V1:hermes_protocol.version|) $x3634) $x205))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|V:hermes_protocol.version| hermes_protocol.version) )(let (($x3141 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x4313 (__hermes_protocol.ts_version |T:hermes_protocol.ts| |V:hermes_protocol.version|)))
 (=> $x4313 $x3141))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (=> $x257 (__hermes_protocol.same_version |T:hermes_protocol.ts| |T:hermes_protocol.ts|))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |U:hermes_protocol.ts|)))
 (let (($x3141 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x4213 (and $x3141 $x257)))
 (let (($x3775 (__hermes_protocol.same_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> $x3775 $x4213))))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3775 (__hermes_protocol.same_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> $x3775 (__hermes_protocol.same_version |U:hermes_protocol.ts| |T:hermes_protocol.ts|))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) (|V:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3775 (__hermes_protocol.same_version |U:hermes_protocol.ts| |V:hermes_protocol.ts|)))
 (let (($x3640 (__hermes_protocol.same_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> (and $x3640 $x3775) (__hermes_protocol.same_version |T:hermes_protocol.ts| |V:hermes_protocol.ts|)))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) (|V:hermes_protocol.version| hermes_protocol.version) )(let (($x4313 (__hermes_protocol.ts_version |U:hermes_protocol.ts| |V:hermes_protocol.version|)))
 (let (($x3634 (__hermes_protocol.ts_version |T:hermes_protocol.ts| |V:hermes_protocol.version|)))
 (let (($x3640 (__hermes_protocol.same_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> (and $x3640 $x3634) $x4313)))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) (|V:hermes_protocol.version| hermes_protocol.version) )(let (($x3640 (__hermes_protocol.same_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (let (($x4313 (__hermes_protocol.ts_version |U:hermes_protocol.ts| |V:hermes_protocol.version|)))
 (let (($x3634 (__hermes_protocol.ts_version |T:hermes_protocol.ts| |V:hermes_protocol.version|)))
 (=> (and $x3634 $x4313) $x3640)))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |U:hermes_protocol.ts|)))
 (let (($x3141 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x4213 (and $x3141 $x257)))
 (let (($x3591 (__hermes_protocol.next_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> $x3591 $x4213))))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|U:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3591 (__hermes_protocol.next_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))
 (=> $x3591 (not (__hermes_protocol.same_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|TV:hermes_protocol.version| hermes_protocol.version) (|U:hermes_protocol.ts| hermes_protocol.ts) (|UV:hermes_protocol.version| hermes_protocol.version) )(let (($x4313 (__hermes_protocol.ts_version |U:hermes_protocol.ts| |UV:hermes_protocol.version|)))
 (let (($x3682 (and (__hermes_protocol.next_version |T:hermes_protocol.ts| |U:hermes_protocol.ts|) (__hermes_protocol.ts_version |T:hermes_protocol.ts| |TV:hermes_protocol.version|) $x4313)))
 (=> $x3682 (|<:hermes_protocol.version:hermes_protocol.version| |UV:hermes_protocol.version| |TV:hermes_protocol.version|)))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|TV:hermes_protocol.version| hermes_protocol.version) (|U:hermes_protocol.ts| hermes_protocol.ts) (|UV:hermes_protocol.version| hermes_protocol.version) )(let (($x178 (|<:hermes_protocol.version:hermes_protocol.version| |TV:hermes_protocol.version| |UV:hermes_protocol.version|)))
 (let (($x4313 (__hermes_protocol.ts_version |U:hermes_protocol.ts| |UV:hermes_protocol.version|)))
 (=> (and (__hermes_protocol.ts_version |T:hermes_protocol.ts| |TV:hermes_protocol.version|) $x4313 $x178) (hermes_protocol.lt |T:hermes_protocol.ts| |U:hermes_protocol.ts|)))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) (|V:hermes_protocol.value| hermes_protocol.value) )(let (($x3141 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x3666 (__hermes_protocol.ts_value |T:hermes_protocol.ts| |V:hermes_protocol.value|)))
 (=> $x3666 $x3141))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x3946 (__hermes_protocol.ts_rmw |T:hermes_protocol.ts|)))
 (=> $x3946 $x257))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x2301 (__hermes_protocol.rmw_conflict |T:hermes_protocol.ts|)))
 (=> $x2301 $x257))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3946 (__hermes_protocol.ts_rmw |T:hermes_protocol.ts|)))
 (let (($x2301 (__hermes_protocol.rmw_conflict |T:hermes_protocol.ts|)))
 (=> $x2301 $x3946))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x2626 (__hermes_protocol.write_conflict |T:hermes_protocol.ts|)))
 (=> $x2626 $x257))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x3946 (__hermes_protocol.ts_rmw |T:hermes_protocol.ts|)))
 (let (($x3744 (not $x3946)))
 (let (($x2626 (__hermes_protocol.write_conflict |T:hermes_protocol.ts|)))
 (=> $x2626 $x3744)))))
 )
(assert
 (forall ((|S:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) (|V:hermes_protocol.value| hermes_protocol.value) )(let (($x3666 (__hermes_protocol.ts_value |T:hermes_protocol.ts| |V:hermes_protocol.value|)))
 (let (($x3141 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x1344 (hermes_protocol.live |S:hermes_protocol.node|)))
 (let (($x2981 (__hermes_protocol.inv_write |S:hermes_protocol.node| |T:hermes_protocol.ts| |V:hermes_protocol.value|)))
 (=> $x2981 (and $x1344 $x3141 $x3666 (not (__hermes_protocol.ts_rmw |T:hermes_protocol.ts|)))))))))
 )
(assert
 (forall ((|S:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) (|V:hermes_protocol.value| hermes_protocol.value) )(let (($x3717 (__hermes_protocol.ts_rmw |T:hermes_protocol.ts|)))
 (let (($x3666 (__hermes_protocol.ts_value |T:hermes_protocol.ts| |V:hermes_protocol.value|)))
 (let (($x3141 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x1344 (hermes_protocol.live |S:hermes_protocol.node|)))
 (let (($x612 (hermes_protocol.inv_rmw |S:hermes_protocol.node| |T:hermes_protocol.ts| |V:hermes_protocol.value|)))
 (=> $x612 (and $x1344 $x3141 $x3666 $x3717))))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(not (__hermes_protocol.ack_msg |N:hermes_protocol.node| |N:hermes_protocol.node| |T:hermes_protocol.ts|)))
 )
(assert
 (forall ((|A:hermes_protocol.node| hermes_protocol.node) (|C:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x1367 (__hermes_protocol.ack_msg |A:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 (=> $x1367 (and (hermes_protocol.live |A:hermes_protocol.node|) (hermes_protocol.live |C:hermes_protocol.node|)))))
 )
(assert
 (forall ((|A:hermes_protocol.node| hermes_protocol.node) (|C:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x1367 (__hermes_protocol.ack_msg |A:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 (=> $x1367 $x257))))
 )
(assert
 (forall ((|A:hermes_protocol.node| hermes_protocol.node) (|C:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x1377 (hermes_protocol.le |T:hermes_protocol.ts| (__hermes_protocol.cur_ts |A:hermes_protocol.node|))))
 (let (($x1367 (__hermes_protocol.ack_msg |A:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 (=> $x1367 $x1377))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x2307 (__hermes_protocol.completed |T:hermes_protocol.ts|)))
 (let (($x623 (hermes_protocol.val_msg |T:hermes_protocol.ts|)))
 (=> $x623 $x2307))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x2307 (__hermes_protocol.completed |T:hermes_protocol.ts|)))
 (=> $x2307 $x257))))
 )
(assert
 (forall ((|C:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x1344 (hermes_protocol.live |C:hermes_protocol.node|)))
 (let (($x1390 (__hermes_protocol.o3_quorum |N:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 (=> $x1390 $x1344))))
 )
(assert
 (forall ((|A:hermes_protocol.node| hermes_protocol.node) (|C:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x1400 (not (= |A:hermes_protocol.node| |C:hermes_protocol.node|))))
 (let (($x1390 (__hermes_protocol.o3_quorum |N:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 (=> (and $x1390 (hermes_protocol.live |A:hermes_protocol.node|) $x1400) (__hermes_protocol.ack_msg |A:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))))
 )
(assert
 (forall ((|C:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x1377 (hermes_protocol.le |T:hermes_protocol.ts| (__hermes_protocol.cur_ts |C:hermes_protocol.node|))))
 (let (($x1344 (hermes_protocol.live |C:hermes_protocol.node|)))
 (let (($x1390 (__hermes_protocol.o3_quorum |N:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 (=> (and $x1390 $x1344) $x1377)))))
 )
(assert
 (forall ((|C:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x257 (__hermes_protocol.seen_ts |T:hermes_protocol.ts|)))
 (let (($x1390 (__hermes_protocol.o3_quorum |N:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 (=> $x1390 $x257))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (__hermes_protocol.seen_ts ?x227)))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x1420 (__hermes_protocol.cur_value |N:hermes_protocol.node|)))
 (let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (__hermes_protocol.ts_value ?x227 ?x1420))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x1427 (__hermes_protocol.cur_rmw |N:hermes_protocol.node|)))
 (=> $x1427 (__hermes_protocol.ts_rmw (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(=> (not (__hermes_protocol.cur_rmw |N:hermes_protocol.node|)) (not (__hermes_protocol.ts_rmw (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x72 (hermes_protocol.live |N:hermes_protocol.node|)))
 (let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (=> $x153 $x72))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (=> $x153 (__hermes_protocol.seen_ts (__hermes_protocol.pending_ts |N:hermes_protocol.node|)))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (=> $x153 (__hermes_protocol.acked |N:hermes_protocol.node| |N:hermes_protocol.node|))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let ((?x3622 (__hermes_protocol.pending_ts |N:hermes_protocol.node|)))
 (let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (=> $x153 (hermes_protocol.le ?x3622 ?x227))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x1461 (__hermes_protocol.pending_rmw |N:hermes_protocol.node|)))
 (let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1462 (and $x153 $x1461)))
 (=> $x1462 (__hermes_protocol.ts_rmw (__hermes_protocol.pending_ts |N:hermes_protocol.node|)))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1471 (and $x153 (not (__hermes_protocol.pending_rmw |N:hermes_protocol.node|)))))
 (=> $x1471 (not (__hermes_protocol.ts_rmw (__hermes_protocol.pending_ts |N:hermes_protocol.node|)))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let ((?x3622 (__hermes_protocol.pending_ts |N:hermes_protocol.node|)))
 (let (($x3895 (= ?x3622 ?x227)))
 (let (($x1461 (__hermes_protocol.pending_rmw |N:hermes_protocol.node|)))
 (let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1462 (and $x153 $x1461)))
 (=> $x1462 $x3895))))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x1427 (__hermes_protocol.cur_rmw |N:hermes_protocol.node|)))
 (let (($x1461 (__hermes_protocol.pending_rmw |N:hermes_protocol.node|)))
 (let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1462 (and $x153 $x1461)))
 (=> $x1462 $x1427))))))
 )
(assert
 (forall ((|A:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x226 (__hermes_protocol.cur_ts |A:hermes_protocol.node|)))
 (let ((?x3622 (__hermes_protocol.pending_ts |N:hermes_protocol.node|)))
 (let (($x1487 (__hermes_protocol.acked |N:hermes_protocol.node| |A:hermes_protocol.node|)))
 (let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1488 (and $x153 $x1487)))
 (=> $x1488 (hermes_protocol.le ?x3622 ?x226))))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1493 (__hermes_protocol.ready |N:hermes_protocol.node|)))
 (=> $x1493 $x153))))
 )
(assert
 (forall ((|A:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let (($x1487 (__hermes_protocol.acked |N:hermes_protocol.node| |A:hermes_protocol.node|)))
 (=> (and (__hermes_protocol.ready |N:hermes_protocol.node|) (hermes_protocol.live |A:hermes_protocol.node|)) $x1487)))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let ((?x3622 (__hermes_protocol.pending_ts |N:hermes_protocol.node|)))
 (let (($x3834 (hermes_protocol.lt ?x3622 ?x227)))
 (let (($x3895 (= ?x3622 ?x227)))
 (let (($x1493 (__hermes_protocol.ready |N:hermes_protocol.node|)))
 (=> $x1493 (or $x3895 $x3834))))))))
 )
(assert
 (forall ((|A:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1541 (not $x153)))
 (=> $x1541 (not (__hermes_protocol.acked |N:hermes_protocol.node| |A:hermes_protocol.node|))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1541 (not $x153)))
 (=> $x1541 (not (__hermes_protocol.pending_rmw |N:hermes_protocol.node|))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x153 (__hermes_protocol.pending |N:hermes_protocol.node|)))
 (let (($x1541 (not $x153)))
 (=> $x1541 (not (__hermes_protocol.ready |N:hermes_protocol.node|))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x72 (hermes_protocol.live |N:hermes_protocol.node|)))
 (let (($x426 (hermes_protocol.client_write_pending |N:hermes_protocol.node|)))
 (=> $x426 $x72))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x72 (hermes_protocol.live |N:hermes_protocol.node|)))
 (let (($x443 (hermes_protocol.client_rmw_pending |N:hermes_protocol.node|)))
 (=> $x443 $x72))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let ((?x226 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let (($x1561 (hermes_protocol.le |T:hermes_protocol.ts| ?x226)))
 (=> (and (__hermes_protocol.completed |T:hermes_protocol.ts|) (hermes_protocol.live |N:hermes_protocol.node|)) $x1561))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x152 (__hermes_protocol.state |N:hermes_protocol.node|)))
 (let (($x148 (= ?x152 hermes_protocol.hs_valid)))
 (=> $x148 (__hermes_protocol.completed (__hermes_protocol.cur_ts |N:hermes_protocol.node|))))))
 )
(assert
 (forall ((|R:hermes_protocol.ts| hermes_protocol.ts) (|T:hermes_protocol.ts| hermes_protocol.ts) )(let (($x2301 (__hermes_protocol.rmw_conflict |T:hermes_protocol.ts|)))
 (let (($x29 (= |R:hermes_protocol.ts| |T:hermes_protocol.ts|)))
 (let (($x46 (not $x29)))
 (let (($x3775 (__hermes_protocol.same_version |R:hermes_protocol.ts| |T:hermes_protocol.ts|)))
 (let (($x3946 (__hermes_protocol.ts_rmw |T:hermes_protocol.ts|)))
 (let (($x3717 (__hermes_protocol.ts_rmw |R:hermes_protocol.ts|)))
 (let (($x3013 (__hermes_protocol.completed |R:hermes_protocol.ts|)))
 (=> (and $x3013 $x3717 $x3946 $x3775 $x46) $x2301)))))))))
 )
(assert
 (forall ((|R1:hermes_protocol.ts| hermes_protocol.ts) (|R2:hermes_protocol.ts| hermes_protocol.ts) )(let (($x29 (= |R1:hermes_protocol.ts| |R2:hermes_protocol.ts|)))
 (let (($x3775 (__hermes_protocol.same_version |R1:hermes_protocol.ts| |R2:hermes_protocol.ts|)))
 (let (($x3946 (__hermes_protocol.ts_rmw |R2:hermes_protocol.ts|)))
 (let (($x3717 (__hermes_protocol.ts_rmw |R1:hermes_protocol.ts|)))
 (let (($x2307 (__hermes_protocol.completed |R2:hermes_protocol.ts|)))
 (let (($x3013 (__hermes_protocol.completed |R1:hermes_protocol.ts|)))
 (=> (and $x3013 $x2307 $x3717 $x3946 $x3775) $x29))))))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x72 (hermes_protocol.live |N:hermes_protocol.node|)))
 (let (($x1493 (__hermes_protocol.ready |N:hermes_protocol.node|)))
 (=> $x1493 $x72))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x1493 (__hermes_protocol.ready |N:hermes_protocol.node|)))
 (=> $x1493 (__hermes_protocol.seen_epoch (__hermes_protocol.ready_epoch |N:hermes_protocol.node|)))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x1493 (__hermes_protocol.ready |N:hermes_protocol.node|)))
 (=> $x1493 (not (= (__hermes_protocol.ready_epoch |N:hermes_protocol.node|) hermes_protocol.init_epoch)))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(let (($x1493 (__hermes_protocol.ready |N:hermes_protocol.node|)))
 (=> $x1493 (__hermes_protocol.ready_epoch_active (__hermes_protocol.ready_epoch |N:hermes_protocol.node|)))))
 )
(assert
 (forall ((|E:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x5034 (__hermes_protocol.seen_epoch |E:hermes_protocol.epoch|)))
 (let (($x1727 (__hermes_protocol.epoch_done |E:hermes_protocol.epoch|)))
 (=> $x1727 $x5034))))
 )
(assert
 (forall ((|E:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x5034 (__hermes_protocol.seen_epoch |E:hermes_protocol.epoch|)))
 (let (($x5905 (__hermes_protocol.ready_epoch_active |E:hermes_protocol.epoch|)))
 (=> $x5905 $x5034))))
 )
(assert
 (forall ((|N:hermes_protocol.node| hermes_protocol.node) )(not (hermes_protocol.complete_try |N:hermes_protocol.node|)))
 )
(assert
 (forall ((|C:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) (|T:hermes_protocol.ts| hermes_protocol.ts) )(not (hermes_protocol.o3_try |N:hermes_protocol.node| |C:hermes_protocol.node| |T:hermes_protocol.ts|)))
 )
(assert
 (= hermes_protocol.ready_task ready_finish))
(assert
 (= hermes_protocol.o3_task o3_finish))
(assert
 (hermes_protocol.live |__loc:c|))
(assert
 (hermes_protocol.live |__loc:w|))
(assert
 (hermes_protocol.live |__loc:a|))
(assert
 (hermes_protocol.live |__loc:b|))
(assert
 (not (= |__loc:c| |__loc:w|)))
(assert
 (not (= |__loc:c| |__loc:a|)))
(assert
 (not (= |__loc:c| |__loc:b|)))
(assert
 (not (= |__loc:w| |__loc:a|)))
(assert
 (not (= |__loc:w| |__loc:b|)))
(assert
 (not (= |__loc:a| |__loc:b|)))
(assert
 (not (__hermes_protocol.pending |__loc:c|)))
(assert
 (not (__hermes_protocol.pending |__loc:w|)))
(assert
 (let ((?x5883 (__hermes_protocol.state |__loc:c|)))
 (let (($x5952 (= ?x5883 hermes_protocol.hs_valid)))
 (or $x5952 (= ?x5883 hermes_protocol.hs_invalid)))))
(assert
 (let ((?x7446 (__hermes_protocol.state |__loc:w|)))
 (let (($x7482 (= ?x7446 hermes_protocol.hs_valid)))
 (or $x7482 (= ?x7446 hermes_protocol.hs_invalid)))))
(assert
 (let ((?x4405 (__hermes_protocol.cur_ts |__loc:c|)))
 (hermes_protocol.lt ?x4405 |__loc:t1|)))
(assert
 (let ((?x7750 (__hermes_protocol.cur_ts |__loc:w|)))
 (hermes_protocol.lt ?x7750 |__loc:t2|)))
(assert
 (hermes_protocol.lt |__loc:t1| |__loc:t2|))
(assert
 (__hermes_protocol.write_then_write_order_ok |__loc:c| |__loc:w|))
(assert
 (not (__hermes_protocol.seen_ts |__loc:t1|)))
(assert
 (not (__hermes_protocol.seen_ts |__loc:t2|)))
(assert
 (not (__hermes_protocol.seen_epoch |__loc:e|)))
(assert
 (or __ts0_e __ts0_f))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or __ts0_b __ts0_d))))
(assert
 (let (($x13898 (hermes_protocol.live |__new_fml:n|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x12723 (or $x2198 $x13898)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12723))))))
(assert
 (let (($x11304 (__hermes_protocol.pending |__new_fml:n|)))
 (let (($x12016 (not $x11304)))
 (let (($x2198 (not __ts0_b)))
 (let (($x14380 (or $x2198 $x12016)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x14380)))))))
(assert
 (let ((?x13970 (__hermes_protocol.state |__new_fml:n|)))
 (let (($x12981 (= ?x13970 hermes_protocol.hs_valid)))
 (let (($x14029 (or $x12981 (= ?x13970 hermes_protocol.hs_invalid))))
 (let (($x2198 (not __ts0_b)))
 (let (($x10779 (or $x2198 $x14029)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x10779))))))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x9506 (hermes_protocol.lt ?x5690 |__new_fml:t|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x12857 (or $x2198 $x9506)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12857)))))))
(assert
 (let (($x13257 (__hermes_protocol.seen_ts |__new_fml:t|)))
 (let (($x13204 (not $x13257)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11503 (or $x2198 $x13204)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x11503)))))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x14333 (__hermes_protocol.seen_ts ?x5690)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11667 (or $x2198 $x14333)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x11667)))))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x4558 (__hermes_protocol.ts_version ?x5690 |__loc:base_ver|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x9184 (or $x2198 $x4558)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x9184)))))))
(assert
 (let (($x5976 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x| |__fml:y|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x14319 (or $x2198 $x5976)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x14319))))))
(assert
 (let (($x5729 (hermes_protocol.version.succ |__new_fml:x| |__fml:y|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x7966 (or $x2198 $x5729)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x7966))))))
(assert
 (let (($x5463 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a| |__fml:y_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11750 (or $x2198 $x5463)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x11750))))))
(assert
 (let (($x5734 (hermes_protocol.version.succ |__new_fml:x_a| |__fml:y_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x14119 (or $x2198 $x5734)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x14119))))))
(assert
 (let (($x5426 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a| |__fml:y_a_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11829 (or $x2198 $x5426)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x11829))))))
(assert
 (let (($x5055 (hermes_protocol.version.succ |__new_fml:x_a_a| |__fml:y_a_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x12884 (or $x2198 $x5055)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12884))))))
(assert
 (let (($x11634 (hermes_protocol.live |__new_fml:n_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x13871 (or $x2198 $x11634)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x13871))))))
(assert
 (let (($x6164 (__m_hermes_protocol.pending |__new_fml:n_a|)))
 (let (($x13278 (not $x6164)))
 (let (($x2198 (not __ts0_b)))
 (let (($x12806 (or $x2198 $x13278)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12806)))))))
(assert
 (let ((?x12279 (__m_hermes_protocol.state |__new_fml:n_a|)))
 (let (($x14206 (= ?x12279 hermes_protocol.hs_valid)))
 (let (($x12675 (or $x14206 (= ?x12279 hermes_protocol.hs_invalid))))
 (let (($x2198 (not __ts0_b)))
 (let (($x12282 (or $x2198 $x12675)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12282))))))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x6116 (hermes_protocol.lt ?x6159 |__new_fml:t_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x13922 (or $x2198 $x6116)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x13922)))))))
(assert
 (let (($x12156 (__m_hermes_protocol.seen_ts |__new_fml:t_a|)))
 (let (($x12727 (not $x12156)))
 (let (($x2198 (not __ts0_b)))
 (let (($x12389 (or $x2198 $x12727)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12389)))))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x12898 (__m_hermes_protocol.seen_ts ?x6159)))
 (let (($x2198 (not __ts0_b)))
 (let (($x13272 (or $x2198 $x12898)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x13272)))))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x8595 (__m_hermes_protocol.ts_version ?x6159 |__loc:base_ver_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x7790 (or $x2198 $x8595)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x7790)))))))
(assert
 (let (($x8715 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_b| |__fml:y_b|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x13299 (or $x2198 $x8715)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x13299))))))
(assert
 (let (($x7492 (hermes_protocol.version.succ |__new_fml:x_b| |__fml:y_b|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11327 (or $x2198 $x7492)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x11327))))))
(assert
 (let (($x7744 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_b| |__fml:y_a_b|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x12444 (or $x2198 $x7744)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12444))))))
(assert
 (let (($x7289 (hermes_protocol.version.succ |__new_fml:x_a_b| |__fml:y_a_b|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x10133 (or $x2198 $x7289)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x10133))))))
(assert
 (let (($x8861 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a_a| |__fml:y_a_a_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x12821 (or $x2198 $x8861)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x12821))))))
(assert
 (let (($x7960 (hermes_protocol.version.succ |__new_fml:x_a_a_a| |__fml:y_a_a_a|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x13954 (or $x2198 $x7960)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x13954))))))
(assert
 (let (($x13534 (hermes_protocol.live |__new_fml:n_b|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x19047 (or $x2198 $x13534)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x19047))))))
(assert
 (let (($x14325 (= |__new_fml:n_b| |__new_fml:s|)))
 (let (($x9208 (not $x14325)))
 (let (($x2198 (not __ts0_b)))
 (let (($x14293 (or $x2198 $x9208)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x14293)))))))
(assert
 (let (($x9559 (hermes_protocol.inv_write |__new_fml:s| |__new_fml:t_b| |__new_fml:v_b|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x13668 (or $x2198 $x9559)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 $x13668))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_b) (hermes_protocol.live |__new_fml:n_c|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_b) (not (= |__new_fml:n_c| |__new_fml:s_a|))))))
(assert
 (let (($x23258 (hermes_protocol.inv_write |__new_fml:s_a| |__new_fml:t_c| |__new_fml:v_c|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x2198 $x23258))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_b) (hermes_protocol.live |__new_fml:n_d|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_b) (not (= |__new_fml:n_d| |__new_fml:s_b|))))))
(assert
 (let (($x23264 (hermes_protocol.inv_write |__new_fml:s_b| |__new_fml:t_d| |__new_fml:v_d|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x2198 $x23264))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_b) (hermes_protocol.live |__new_fml:n_e|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_b) (not (= |__new_fml:n_e| |__new_fml:s_c|))))))
(assert
 (let (($x23271 (hermes_protocol.inv_write |__new_fml:s_c| |__new_fml:t_e| |__new_fml:v_e|)))
 (let (($x2198 (not __ts0_b)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x2198 $x23271))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_b) (not (hermes_protocol.live |__new_fml:n_f|))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (hermes_protocol.live |__new_fml:n|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (__hermes_protocol.pending |__new_fml:n|))))))
(assert
 (let ((?x13970 (__hermes_protocol.state |__new_fml:n|)))
 (let (($x12981 (= ?x13970 hermes_protocol.hs_valid)))
 (let (($x14029 (or $x12981 (= ?x13970 hermes_protocol.hs_invalid))))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x14029))))))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x9506 (hermes_protocol.lt ?x5690 |__new_fml:t|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x9506)))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (__hermes_protocol.seen_ts |__new_fml:t|))))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x14333 (__hermes_protocol.seen_ts ?x5690)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x14333)))))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x4558 (__hermes_protocol.ts_version ?x5690 |__loc:base_ver|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x4558)))))))
(assert
 (let (($x5976 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x| |__fml:y|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x5976))))))
(assert
 (let (($x5729 (hermes_protocol.version.succ |__new_fml:x| |__fml:y|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x5729))))))
(assert
 (let (($x5463 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a| |__fml:y_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x5463))))))
(assert
 (let (($x5734 (hermes_protocol.version.succ |__new_fml:x_a| |__fml:y_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x5734))))))
(assert
 (let (($x5426 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a| |__fml:y_a_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x5426))))))
(assert
 (let (($x5055 (hermes_protocol.version.succ |__new_fml:x_a_a| |__fml:y_a_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x5055))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (hermes_protocol.live |__new_fml:n_a|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (__m_hermes_protocol.pending |__new_fml:n_a|))))))
(assert
 (let ((?x12279 (__m_hermes_protocol.state |__new_fml:n_a|)))
 (let (($x14206 (= ?x12279 hermes_protocol.hs_valid)))
 (let (($x12675 (or $x14206 (= ?x12279 hermes_protocol.hs_invalid))))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x12675))))))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x6116 (hermes_protocol.lt ?x6159 |__new_fml:t_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x6116)))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (__m_hermes_protocol.seen_ts |__new_fml:t_a|))))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x12898 (__m_hermes_protocol.seen_ts ?x6159)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x12898)))))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x8595 (__m_hermes_protocol.ts_version ?x6159 |__loc:base_ver_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x8595)))))))
(assert
 (let (($x8715 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_b| |__fml:y_b|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x8715))))))
(assert
 (let (($x7492 (hermes_protocol.version.succ |__new_fml:x_b| |__fml:y_b|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x7492))))))
(assert
 (let (($x7744 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_b| |__fml:y_a_b|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x7744))))))
(assert
 (let (($x7289 (hermes_protocol.version.succ |__new_fml:x_a_b| |__fml:y_a_b|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x7289))))))
(assert
 (let (($x8861 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a_a| |__fml:y_a_a_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x8861))))))
(assert
 (let (($x7960 (hermes_protocol.version.succ |__new_fml:x_a_a_a| |__fml:y_a_a_a|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x7960))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (hermes_protocol.live |__new_fml:n_b|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (= |__new_fml:n_b| |__new_fml:s|))))))
(assert
 (let (($x9559 (hermes_protocol.inv_write |__new_fml:s| |__new_fml:t_b| |__new_fml:v_b|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x9559))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (hermes_protocol.live |__new_fml:n_c|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (= |__new_fml:n_c| |__new_fml:s_a|))))))
(assert
 (let (($x23258 (hermes_protocol.inv_write |__new_fml:s_a| |__new_fml:t_c| |__new_fml:v_c|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x23258))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (hermes_protocol.live |__new_fml:n_d|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (= |__new_fml:n_d| |__new_fml:s_b|))))))
(assert
 (let (($x23264 (hermes_protocol.inv_write |__new_fml:s_b| |__new_fml:t_d| |__new_fml:v_d|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x23264))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (hermes_protocol.live |__new_fml:n_e|)))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (not (= |__new_fml:n_e| |__new_fml:s_c|))))))
(assert
 (let (($x23271 (hermes_protocol.inv_write |__new_fml:s_c| |__new_fml:t_e| |__new_fml:v_e|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x23271))))))
(assert
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or (not __ts0_d) (hermes_protocol.pending |__new_fml:n_f|)))))
(assert
 (let (($x21603 (= (hermes_protocol.pending_ts |__new_fml:n_f|) |__new_fml:t_f|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x21603))))))
(assert
 (let (($x21870 (hermes_protocol.ack_msg |__new_fml:a| |__new_fml:n_f| |__new_fml:t_f|)))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x21870))))))
(assert
 (let (($x22920 (not (__m_hermes_protocol.acked_e |__new_fml:n_f| |__new_fml:a|))))
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 $x22920))))))
(assert
 (let (($x13943 (not __ts0_d)))
 (let (($x11748 (not __ts0_e)))
 (or $x11748 (or $x13943 (not (hermes_protocol.live |__ts0__ts0__new_fml:n_g_a|)))))))
(assert
 (let (($x13898 (hermes_protocol.live |__new_fml:n|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x13898))))
(assert
 (let (($x11304 (__hermes_protocol.pending |__new_fml:n|)))
 (let (($x12016 (not $x11304)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x12016)))))
(assert
 (let ((?x13970 (__hermes_protocol.state |__new_fml:n|)))
 (let (($x12981 (= ?x13970 hermes_protocol.hs_valid)))
 (let (($x14029 (or $x12981 (= ?x13970 hermes_protocol.hs_invalid))))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x14029))))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x9506 (hermes_protocol.lt ?x5690 |__new_fml:t|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x9506)))))
(assert
 (let (($x13257 (__hermes_protocol.seen_ts |__new_fml:t|)))
 (let (($x13204 (not $x13257)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x13204)))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x14333 (__hermes_protocol.seen_ts ?x5690)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x14333)))))
(assert
 (let ((?x5690 (__hermes_protocol.cur_ts |__new_fml:n|)))
 (let (($x4558 (__hermes_protocol.ts_version ?x5690 |__loc:base_ver|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x4558)))))
(assert
 (let (($x5976 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x| |__fml:y|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5976))))
(assert
 (forall ((|Y:hermes_protocol.version| hermes_protocol.version) )(let (($x3047 (or (= |__fml:y| |Y:hermes_protocol.version|) (|<:hermes_protocol.version:hermes_protocol.version| |__fml:y| |Y:hermes_protocol.version|))))
 (let (($x5186 (=> (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x| |Y:hermes_protocol.version|) $x3047)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5186)))))
 )
(assert
 (let (($x5729 (hermes_protocol.version.succ |__new_fml:x| |__fml:y|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5729))))
(assert
 (let (($x5463 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a| |__fml:y_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5463))))
(assert
 (forall ((|Y:hermes_protocol.version| hermes_protocol.version) )(let (($x4173 (or (= |__fml:y_a| |Y:hermes_protocol.version|) (|<:hermes_protocol.version:hermes_protocol.version| |__fml:y_a| |Y:hermes_protocol.version|))))
 (let (($x3484 (=> (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a| |Y:hermes_protocol.version|) $x4173)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x3484)))))
 )
(assert
 (let (($x5734 (hermes_protocol.version.succ |__new_fml:x_a| |__fml:y_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5734))))
(assert
 (let (($x5426 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a| |__fml:y_a_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5426))))
(assert
 (forall ((|Y:hermes_protocol.version| hermes_protocol.version) )(let (($x3488 (or (= |__fml:y_a_a| |Y:hermes_protocol.version|) (|<:hermes_protocol.version:hermes_protocol.version| |__fml:y_a_a| |Y:hermes_protocol.version|))))
 (let (($x5825 (=> (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a| |Y:hermes_protocol.version|) $x3488)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5825)))))
 )
(assert
 (let (($x5055 (hermes_protocol.version.succ |__new_fml:x_a_a| |__fml:y_a_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x5055))))
(assert
 (let (($x11634 (hermes_protocol.live |__new_fml:n_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x11634))))
(assert
 (let (($x6164 (__m_hermes_protocol.pending |__new_fml:n_a|)))
 (let (($x13278 (not $x6164)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x13278)))))
(assert
 (let ((?x12279 (__m_hermes_protocol.state |__new_fml:n_a|)))
 (let (($x14206 (= ?x12279 hermes_protocol.hs_valid)))
 (let (($x12675 (or $x14206 (= ?x12279 hermes_protocol.hs_invalid))))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x12675))))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x6116 (hermes_protocol.lt ?x6159 |__new_fml:t_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x6116)))))
(assert
 (let (($x12156 (__m_hermes_protocol.seen_ts |__new_fml:t_a|)))
 (let (($x12727 (not $x12156)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x12727)))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x12898 (__m_hermes_protocol.seen_ts ?x6159)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x12898)))))
(assert
 (let ((?x6159 (__m_hermes_protocol.cur_ts |__new_fml:n_a|)))
 (let (($x8595 (__m_hermes_protocol.ts_version ?x6159 |__loc:base_ver_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x8595)))))
(assert
 (let (($x8715 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_b| |__fml:y_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x8715))))
(assert
 (forall ((|Y:hermes_protocol.version| hermes_protocol.version) )(let (($x7428 (or (= |__fml:y_b| |Y:hermes_protocol.version|) (|<:hermes_protocol.version:hermes_protocol.version| |__fml:y_b| |Y:hermes_protocol.version|))))
 (let (($x7382 (=> (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_b| |Y:hermes_protocol.version|) $x7428)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x7382)))))
 )
(assert
 (let (($x7492 (hermes_protocol.version.succ |__new_fml:x_b| |__fml:y_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x7492))))
(assert
 (let (($x7744 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_b| |__fml:y_a_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x7744))))
(assert
 (forall ((|Y:hermes_protocol.version| hermes_protocol.version) )(let (($x7726 (or (= |__fml:y_a_b| |Y:hermes_protocol.version|) (|<:hermes_protocol.version:hermes_protocol.version| |__fml:y_a_b| |Y:hermes_protocol.version|))))
 (let (($x7713 (=> (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_b| |Y:hermes_protocol.version|) $x7726)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x7713)))))
 )
(assert
 (let (($x7289 (hermes_protocol.version.succ |__new_fml:x_a_b| |__fml:y_a_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x7289))))
(assert
 (let (($x8861 (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a_a| |__fml:y_a_a_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x8861))))
(assert
 (forall ((|Y:hermes_protocol.version| hermes_protocol.version) )(let (($x8808 (or (= |__fml:y_a_a_a| |Y:hermes_protocol.version|) (|<:hermes_protocol.version:hermes_protocol.version| |__fml:y_a_a_a| |Y:hermes_protocol.version|))))
 (let (($x7316 (=> (|<:hermes_protocol.version:hermes_protocol.version| |__new_fml:x_a_a_a| |Y:hermes_protocol.version|) $x8808)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x7316)))))
 )
(assert
 (let (($x7960 (hermes_protocol.version.succ |__new_fml:x_a_a_a| |__fml:y_a_a_a|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x7960))))
(assert
 (let (($x13534 (hermes_protocol.live |__new_fml:n_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x13534))))
(assert
 (let (($x14325 (= |__new_fml:n_b| |__new_fml:s|)))
 (let (($x9208 (not $x14325)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x9208)))))
(assert
 (let (($x9559 (hermes_protocol.inv_write |__new_fml:s| |__new_fml:t_b| |__new_fml:v_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x9559))))
(assert
 (let (($x21260 (hermes_protocol.live |__new_fml:n_c|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x21260))))
(assert
 (let (($x23118 (not (= |__new_fml:n_c| |__new_fml:s_a|))))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x23118))))
(assert
 (let (($x23258 (hermes_protocol.inv_write |__new_fml:s_a| |__new_fml:t_c| |__new_fml:v_c|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x23258))))
(assert
 (let (($x21559 (hermes_protocol.live |__new_fml:n_d|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x21559))))
(assert
 (let (($x23261 (not (= |__new_fml:n_d| |__new_fml:s_b|))))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x23261))))
(assert
 (let (($x23264 (hermes_protocol.inv_write |__new_fml:s_b| |__new_fml:t_d| |__new_fml:v_d|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x23264))))
(assert
 (let (($x21494 (hermes_protocol.live |__new_fml:n_e|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x21494))))
(assert
 (let (($x23268 (not (= |__new_fml:n_e| |__new_fml:s_c|))))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x23268))))
(assert
 (let (($x23271 (hermes_protocol.inv_write |__new_fml:s_c| |__new_fml:t_e| |__new_fml:v_e|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x23271))))
(assert
 (let (($x23451 (hermes_protocol.pending |__new_fml:n_f|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x23451))))
(assert
 (let (($x21603 (= (hermes_protocol.pending_ts |__new_fml:n_f|) |__new_fml:t_f|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x21603))))
(assert
 (let (($x21870 (hermes_protocol.ack_msg |__new_fml:a| |__new_fml:n_f| |__new_fml:t_f|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x21870))))
(assert
 (let (($x22920 (not (__m_hermes_protocol.acked_e |__new_fml:n_f| |__new_fml:a|))))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x22920))))
(assert
 (let (($x11407 (not __ts0_f)))
 (or $x11407 (hermes_protocol.pending |__ts0__new_fml:n_g_b|))))
(assert
 (let (($x22176 (= (hermes_protocol.pending_ts |__ts0__new_fml:n_g_b|) |__ts0__new_fml:t_g_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x22176))))
(assert
 (let (($x19920 (hermes_protocol.ack_msg |__ts0__new_fml:a_a_b| |__ts0__new_fml:n_g_b| |__ts0__new_fml:t_g_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 $x19920))))
(assert
 (let (($x23180 (__ts0__m_hermes_protocol.acked_f_b |__ts0__new_fml:n_g_b| |__ts0__new_fml:a_a_b|)))
 (let (($x11407 (not __ts0_f)))
 (or $x11407 (not $x23180)))))
(assert
 (let (($x11407 (not __ts0_f)))
 (or $x11407 (not (hermes_protocol.live |__ts0__new_fml:n_h_a|)))))
(assert
 (forall ((|X:hermes_protocol.ts| hermes_protocol.ts) )(hermes_protocol.le |X:hermes_protocol.ts| |X:hermes_protocol.ts|))
 )
(assert
 (forall ((|X:hermes_protocol.ts| hermes_protocol.ts) (|Y:hermes_protocol.ts| hermes_protocol.ts) (|Z:hermes_protocol.ts| hermes_protocol.ts) )(=> (and (hermes_protocol.le |X:hermes_protocol.ts| |Y:hermes_protocol.ts|) (hermes_protocol.le |Y:hermes_protocol.ts| |Z:hermes_protocol.ts|)) (hermes_protocol.le |X:hermes_protocol.ts| |Z:hermes_protocol.ts|)))
 )
(assert
 (forall ((|X:hermes_protocol.ts| hermes_protocol.ts) (|Y:hermes_protocol.ts| hermes_protocol.ts) )(let (($x29 (= |X:hermes_protocol.ts| |Y:hermes_protocol.ts|)))
 (=> (and (hermes_protocol.le |X:hermes_protocol.ts| |Y:hermes_protocol.ts|) (hermes_protocol.le |Y:hermes_protocol.ts| |X:hermes_protocol.ts|)) $x29)))
 )
(assert
 (forall ((|X:hermes_protocol.ts| hermes_protocol.ts) (|Y:hermes_protocol.ts| hermes_protocol.ts) )(let (($x20 (hermes_protocol.le |X:hermes_protocol.ts| |Y:hermes_protocol.ts|)))
 (or $x20 (hermes_protocol.le |Y:hermes_protocol.ts| |X:hermes_protocol.ts|))))
 )
(assert
 (forall ((|T:hermes_protocol.ts| hermes_protocol.ts) )(hermes_protocol.le hermes_protocol.init_ts |T:hermes_protocol.ts|))
 )
(assert
 (forall ((|X:hermes_protocol.version| hermes_protocol.version) (|Y:hermes_protocol.version| hermes_protocol.version) (|Z:hermes_protocol.version| hermes_protocol.version) )(let (($x174 (|<:hermes_protocol.version:hermes_protocol.version| |Y:hermes_protocol.version| |Z:hermes_protocol.version|)))
 (let (($x177 (not (and (|<:hermes_protocol.version:hermes_protocol.version| |X:hermes_protocol.version| |Y:hermes_protocol.version|) $x174))))
 (let (($x178 (|<:hermes_protocol.version:hermes_protocol.version| |X:hermes_protocol.version| |Z:hermes_protocol.version|)))
 (=> (hermes_protocol.version.succ |X:hermes_protocol.version| |Z:hermes_protocol.version|) (and $x178 $x177))))))
 )
(assert
 (forall ((|T:hermes_protocol.version| hermes_protocol.version) (|U:hermes_protocol.version| hermes_protocol.version) (|V:hermes_protocol.version| hermes_protocol.version) )(let (($x178 (|<:hermes_protocol.version:hermes_protocol.version| |T:hermes_protocol.version| |V:hermes_protocol.version|)))
 (let (($x174 (|<:hermes_protocol.version:hermes_protocol.version| |U:hermes_protocol.version| |V:hermes_protocol.version|)))
 (=> (and (|<:hermes_protocol.version:hermes_protocol.version| |T:hermes_protocol.version| |U:hermes_protocol.version|) $x174) $x178))))
 )
(assert
 (forall ((|T:hermes_protocol.version| hermes_protocol.version) (|U:hermes_protocol.version| hermes_protocol.version) )(let (($x174 (|<:hermes_protocol.version:hermes_protocol.version| |T:hermes_protocol.version| |U:hermes_protocol.version|)))
 (not (and $x174 (|<:hermes_protocol.version:hermes_protocol.version| |U:hermes_protocol.version| |T:hermes_protocol.version|)))))
 )
(assert
 (forall ((|T:hermes_protocol.version| hermes_protocol.version) (|U:hermes_protocol.version| hermes_protocol.version) )(let (($x205 (= |T:hermes_protocol.version| |U:hermes_protocol.version|)))
 (let (($x174 (|<:hermes_protocol.version:hermes_protocol.version| |T:hermes_protocol.version| |U:hermes_protocol.version|)))
 (or $x174 $x205 (|<:hermes_protocol.version:hermes_protocol.version| |U:hermes_protocol.version| |T:hermes_protocol.version|)))))
 )
(assert
 (forall ((|X:hermes_protocol.version| hermes_protocol.version) )(let (($x213 (|<:hermes_protocol.version:hermes_protocol.version| |0:hermes_protocol.version| |X:hermes_protocol.version|)))
 (or (= |0:hermes_protocol.version| |X:hermes_protocol.version|) $x213)))
 )
(assert
 (forall ((|M:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x226 (__hermes_protocol.cur_ts |M:hermes_protocol.node|)))
 (let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let (($x228 (hermes_protocol.lt ?x227 ?x226)))
 (= (__hermes_protocol.write_then_write_order_ok |N:hermes_protocol.node| |M:hermes_protocol.node|) (or (__hermes_protocol.same_version ?x227 ?x226) $x228))))))
 )
(assert
 (forall ((|M:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x226 (__hermes_protocol.cur_ts |M:hermes_protocol.node|)))
 (let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let (($x238 (__hermes_protocol.next_version ?x227 ?x226)))
 (let (($x228 (hermes_protocol.lt ?x227 ?x226)))
 (= (__hermes_protocol.rmw_then_write_order_ok |N:hermes_protocol.node| |M:hermes_protocol.node|) (or (__hermes_protocol.same_version ?x227 ?x226) $x228 $x238)))))))
 )
(assert
 (forall ((|M:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x226 (__hermes_protocol.cur_ts |M:hermes_protocol.node|)))
 (let ((?x227 (__hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let (($x228 (hermes_protocol.lt ?x227 ?x226)))
 (= (__hermes_protocol.rmw_then_rmw_order_ok |N:hermes_protocol.node| |M:hermes_protocol.node|) (or (__hermes_protocol.same_version ?x227 ?x226) $x228))))))
 )
(assert
 (let ((?x17143 (ite __ts0_f |__loc:c| (ite __ts0_d |__loc:c| |__loc:c|))))
 (= |__new_fml:n| ?x17143)))
(assert
 (let ((?x19297 (ite __ts0_f |__loc:t1| (ite __ts0_d |__loc:t1| |__loc:t1|))))
 (= |__new_fml:t| ?x19297)))
(assert
 (let ((?x20006 (ite __ts0_f |__loc:v1| (ite __ts0_d |__loc:v1| |__loc:v1|))))
 (= |__new_fml:v| ?x20006)))
(assert
 (let ((?x17152 (ite __ts0_f |__loc:base_ver| (ite __ts0_d |__loc:base_ver| |__loc:base_ver|))))
 (= |__new_fml:x| ?x17152)))
(assert
 (let ((?x17155 (ite __ts0_f |__fml:y| (ite __ts0_d |__fml:y| |__fml:y|))))
 (= |__new_loc:0_b| ?x17155)))
(assert
 (let ((?x17158 (ite __ts0_f |__new_loc:0_b| (ite __ts0_d |__new_loc:0_b| |__new_loc:0_b|))))
 (= |__new_loc:mid_ver| ?x17158)))
(assert
 (let ((?x17161 (ite __ts0_f |__new_loc:mid_ver| (ite __ts0_d |__new_loc:mid_ver| |__new_loc:mid_ver|))))
 (= |__new_fml:x_a| ?x17161)))
(assert
 (let ((?x17164 (ite __ts0_f |__fml:y_a| (ite __ts0_d |__fml:y_a| |__fml:y_a|))))
 (= |__new_loc:0_a| ?x17164)))
(assert
 (let ((?x17167 (ite __ts0_f |__new_loc:0_a| (ite __ts0_d |__new_loc:0_a| |__new_loc:0_a|))))
 (= |__new_loc:new_ver| ?x17167)))
(assert
 (let ((?x17170 (ite __ts0_f |__new_loc:new_ver| (ite __ts0_d |__new_loc:new_ver| |__new_loc:new_ver|))))
 (= |__new_fml:x_a_a| ?x17170)))
(assert
 (let ((?x17173 (ite __ts0_f |__fml:y_a_a| (ite __ts0_d |__fml:y_a_a| |__fml:y_a_a|))))
 (= |__new_loc:0| ?x17173)))
(assert
 (let ((?x17176 (ite __ts0_f |__new_loc:0| (ite __ts0_d |__new_loc:0| |__new_loc:0|))))
 (= |__new_loc:after_ver| ?x17176)))
(assert
 (let ((?x19357 (ite __ts0_f |__loc:w| (ite __ts0_d |__loc:w| |__loc:w|))))
 (= |__new_fml:n_a| ?x19357)))
(assert
 (let ((?x20981 (ite __ts0_f |__loc:t2| (ite __ts0_d |__loc:t2| |__loc:t2|))))
 (= |__new_fml:t_a| ?x20981)))
(assert
 (let ((?x20160 (ite __ts0_f |__loc:v2| (ite __ts0_d |__loc:v2| |__loc:v2|))))
 (= |__new_fml:v_a| ?x20160)))
(assert
 (let ((?x19312 (ite __ts0_f |__loc:base_ver_a| (ite __ts0_d |__loc:base_ver_a| |__loc:base_ver_a|))))
 (= |__new_fml:x_b| ?x19312)))
(assert
 (let ((?x20644 (ite __ts0_f |__fml:y_b| (ite __ts0_d |__fml:y_b| |__fml:y_b|))))
 (= |__new_loc:0_b_a| ?x20644)))
(assert
 (let ((?x23144 (ite __ts0_f |__new_loc:0_b_a| (ite __ts0_d |__new_loc:0_b_a| |__new_loc:0_b_a|))))
 (= |__new_loc:mid_ver_a| ?x23144)))
(assert
 (let ((?x22650 (ite __ts0_f |__new_loc:mid_ver_a| (ite __ts0_d |__new_loc:mid_ver_a| |__new_loc:mid_ver_a|))))
 (= |__new_fml:x_a_b| ?x22650)))
(assert
 (= |__new_loc:0_a_a| (ite __ts0_f |__fml:y_a_b| (ite __ts0_d |__fml:y_a_b| |__fml:y_a_b|))))
(assert
 (let ((?x19386 (ite __ts0_f |__new_loc:0_a_a| (ite __ts0_d |__new_loc:0_a_a| |__new_loc:0_a_a|))))
 (= |__new_loc:new_ver_a| ?x19386)))
(assert
 (let ((?x18825 (ite __ts0_f |__new_loc:new_ver_a| (ite __ts0_d |__new_loc:new_ver_a| |__new_loc:new_ver_a|))))
 (= |__new_fml:x_a_a_a| ?x18825)))
(assert
 (let ((?x22412 (ite __ts0_f |__fml:y_a_a_a| (ite __ts0_d |__fml:y_a_a_a| |__fml:y_a_a_a|))))
 (= |__new_loc:0_c| ?x22412)))
(assert
 (let ((?x22936 (ite __ts0_f |__new_loc:0_c| (ite __ts0_d |__new_loc:0_c| |__new_loc:0_c|))))
 (= |__new_loc:after_ver_a| ?x22936)))
(assert
 (let ((?x17143 (ite __ts0_f |__loc:c| (ite __ts0_d |__loc:c| |__loc:c|))))
 (= |__new_fml:n_b| ?x17143)))
(assert
 (let ((?x19357 (ite __ts0_f |__loc:w| (ite __ts0_d |__loc:w| |__loc:w|))))
 (= |__new_fml:s| ?x19357)))
(assert
 (let ((?x20981 (ite __ts0_f |__loc:t2| (ite __ts0_d |__loc:t2| |__loc:t2|))))
 (= |__new_fml:t_b| ?x20981)))
(assert
 (let ((?x20160 (ite __ts0_f |__loc:v2| (ite __ts0_d |__loc:v2| |__loc:v2|))))
 (= |__new_fml:v_b| ?x20160)))
(assert
 (let (($x5985 (__m_hermes_protocol.pending_a |__new_fml:n_b|)))
 (let (($x5604 (__m_hermes_protocol.ready_a |__new_fml:n_b|)))
 (let (($x7622 (ite __ts0__ts0_b $x5604 $x5985)))
 (= __ts0__ts0_a (ite __ts0_f $x7622 (ite __ts0_d $x7622 $x7622)))))))
(assert
 (let (($x5985 (__m_hermes_protocol.pending_a |__new_fml:n_b|)))
 (let (($x5310 (and $x5985 (__m_hermes_protocol.pending_rmw_a |__new_fml:n_b|))))
 (let (($x23025 (ite __ts0_f $x5310 (ite __ts0_d $x5310 $x5310))))
 (= __ts0__ts0_b $x23025)))))
(assert
 (let ((?x6421 (__m_hermes_protocol.cur_ts_a |__new_fml:n_b|)))
 (let (($x6148 (hermes_protocol.lt ?x6421 |__new_fml:t_b|)))
 (let (($x18627 (ite __ts0_f $x6148 (ite __ts0_d $x6148 $x6148))))
 (= __ts0_c $x18627)))))
(assert
 (let ((?x19357 (ite __ts0_f |__loc:w| (ite __ts0_d |__loc:w| |__loc:w|))))
 (= |__new_fml:n_c| ?x19357)))
(assert
 (let ((?x17143 (ite __ts0_f |__loc:c| (ite __ts0_d |__loc:c| |__loc:c|))))
 (= |__new_fml:s_a| ?x17143)))
(assert
 (let ((?x19297 (ite __ts0_f |__loc:t1| (ite __ts0_d |__loc:t1| |__loc:t1|))))
 (= |__new_fml:t_c| ?x19297)))
(assert
 (let ((?x20006 (ite __ts0_f |__loc:v1| (ite __ts0_d |__loc:v1| |__loc:v1|))))
 (= |__new_fml:v_c| ?x20006)))
(assert
 (let (($x6483 (__m_hermes_protocol.pending_b |__new_fml:n_c|)))
 (let (($x6482 (__m_hermes_protocol.ready_b |__new_fml:n_c|)))
 (let (($x8455 (ite __ts0__ts0_b_a $x6482 $x6483)))
 (= __ts0__ts0_a_a (ite __ts0_f $x8455 (ite __ts0_d $x8455 $x8455)))))))
(assert
 (let (($x6483 (__m_hermes_protocol.pending_b |__new_fml:n_c|)))
 (let (($x6582 (and $x6483 (__m_hermes_protocol.pending_rmw_b |__new_fml:n_c|))))
 (let (($x21957 (ite __ts0_f $x6582 (ite __ts0_d $x6582 $x6582))))
 (= __ts0__ts0_b_a $x21957)))))
(assert
 (let ((?x6641 (__m_hermes_protocol.cur_ts_b |__new_fml:n_c|)))
 (let (($x6642 (hermes_protocol.lt ?x6641 |__new_fml:t_c|)))
 (let (($x23453 (ite __ts0_f $x6642 (ite __ts0_d $x6642 $x6642))))
 (= __ts0_c_a $x23453)))))
(assert
 (let ((?x17460 (ite __ts0_f |__loc:a| (ite __ts0_d |__loc:a| |__loc:a|))))
 (= |__new_fml:n_d| ?x17460)))
(assert
 (let ((?x17143 (ite __ts0_f |__loc:c| (ite __ts0_d |__loc:c| |__loc:c|))))
 (= |__new_fml:s_b| ?x17143)))
(assert
 (let ((?x19297 (ite __ts0_f |__loc:t1| (ite __ts0_d |__loc:t1| |__loc:t1|))))
 (= |__new_fml:t_d| ?x19297)))
(assert
 (let ((?x20006 (ite __ts0_f |__loc:v1| (ite __ts0_d |__loc:v1| |__loc:v1|))))
 (= |__new_fml:v_d| ?x20006)))
(assert
 (let (($x8424 (__m_hermes_protocol.pending_c |__new_fml:n_d|)))
 (let (($x8423 (__m_hermes_protocol.ready_c |__new_fml:n_d|)))
 (let (($x8571 (ite __ts0__ts0_b_b $x8423 $x8424)))
 (= __ts0__ts0_a_b (ite __ts0_f $x8571 (ite __ts0_d $x8571 $x8571)))))))
(assert
 (let (($x8424 (__m_hermes_protocol.pending_c |__new_fml:n_d|)))
 (let (($x8581 (and $x8424 (__m_hermes_protocol.pending_rmw_c |__new_fml:n_d|))))
 (= __ts0__ts0_b_b (ite __ts0_f $x8581 (ite __ts0_d $x8581 $x8581))))))
(assert
 (let ((?x8644 (__m_hermes_protocol.cur_ts_c |__new_fml:n_d|)))
 (let (($x8636 (hermes_protocol.lt ?x8644 |__new_fml:t_d|)))
 (= __ts0_c_b (ite __ts0_f $x8636 (ite __ts0_d $x8636 $x8636))))))
(assert
 (let ((?x21580 (ite __ts0_f |__loc:b| (ite __ts0_d |__loc:b| |__loc:b|))))
 (= |__new_fml:n_e| ?x21580)))
(assert
 (let ((?x17143 (ite __ts0_f |__loc:c| (ite __ts0_d |__loc:c| |__loc:c|))))
 (= |__new_fml:s_c| ?x17143)))
(assert
 (let ((?x19297 (ite __ts0_f |__loc:t1| (ite __ts0_d |__loc:t1| |__loc:t1|))))
 (= |__new_fml:t_e| ?x19297)))
(assert
 (let ((?x20006 (ite __ts0_f |__loc:v1| (ite __ts0_d |__loc:v1| |__loc:v1|))))
 (= |__new_fml:v_e| ?x20006)))
(assert
 (let (($x8444 (__m_hermes_protocol.pending_d |__new_fml:n_e|)))
 (let (($x8521 (__m_hermes_protocol.ready_d |__new_fml:n_e|)))
 (let (($x8445 (ite __ts0__ts0_b_c $x8521 $x8444)))
 (= __ts0__ts0_a_c (ite __ts0_f $x8445 (ite __ts0_d $x8445 $x8445)))))))
(assert
 (let (($x8444 (__m_hermes_protocol.pending_d |__new_fml:n_e|)))
 (let (($x8365 (and $x8444 (__m_hermes_protocol.pending_rmw_d |__new_fml:n_e|))))
 (= __ts0__ts0_b_c (ite __ts0_f $x8365 (ite __ts0_d $x8365 $x8365))))))
(assert
 (let ((?x8274 (__m_hermes_protocol.cur_ts_d |__new_fml:n_e|)))
 (let (($x8275 (hermes_protocol.lt ?x8274 |__new_fml:t_e|)))
 (= __ts0_c_c (ite __ts0_f $x8275 (ite __ts0_d $x8275 $x8275))))))
(assert
 (let ((?x17143 (ite __ts0_f |__loc:c| (ite __ts0_d |__loc:c| |__loc:c|))))
 (= |__new_fml:n_f| ?x17143)))
(assert
 (let ((?x19357 (ite __ts0_f |__loc:w| (ite __ts0_d |__loc:w| |__loc:w|))))
 (= |__new_fml:a| ?x19357)))
(assert
 (let ((?x19297 (ite __ts0_f |__loc:t1| (ite __ts0_d |__loc:t1| |__loc:t1|))))
 (= |__new_fml:t_f| ?x19297)))
(assert
 (forall ((|V0:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x6811 (__m_hermes_protocol.epoch_done_c |V0:hermes_protocol.epoch|)))
 (let (($x23400 (__ts0__ts0__m_hermes_protocol.epoch_done_d_a |V0:hermes_protocol.epoch|)))
 (let (($x23341 (__ts0__m_hermes_protocol.epoch_done_e_a |V0:hermes_protocol.epoch|)))
 (let (($x416 (hermes_protocol.epoch_done |V0:hermes_protocol.epoch|)))
 (= $x416 (ite __ts0_f $x23341 (ite __ts0_d $x23400 $x6811))))))))
 )
(assert
 (forall ((|V0:hermes_protocol.node| hermes_protocol.node) (|V1:hermes_protocol.node| hermes_protocol.node) )(let (($x6962 (__m_hermes_protocol.acked_e |V0:hermes_protocol.node| |V1:hermes_protocol.node|)))
 (let (($x19529 (ite __ts0_f (__ts0__m_hermes_protocol.acked_g_a |V0:hermes_protocol.node| |V1:hermes_protocol.node|) (ite __ts0_d (__ts0__ts0__m_hermes_protocol.acked_f_a |V0:hermes_protocol.node| |V1:hermes_protocol.node|) $x6962))))
 (let (($x391 (hermes_protocol.acked |V0:hermes_protocol.node| |V1:hermes_protocol.node|)))
 (= $x391 $x19529)))))
 )
(assert
 (forall ((|V0:hermes_protocol.node| hermes_protocol.node) )(let (($x6972 (__m_hermes_protocol.ready_e |V0:hermes_protocol.node|)))
 (let (($x21310 (ite __ts0_f (__ts0__m_hermes_protocol.ready_g_a |V0:hermes_protocol.node|) (ite __ts0_d (__ts0__ts0__m_hermes_protocol.ready_f_a |V0:hermes_protocol.node|) $x6972))))
 (let (($x396 (hermes_protocol.ready |V0:hermes_protocol.node|)))
 (= $x396 $x21310)))))
 )
(assert
 (forall ((|V0:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x6811 (__m_hermes_protocol.epoch_done_c |V0:hermes_protocol.epoch|)))
 (let (($x6945 (or $x6811 (= |V0:hermes_protocol.epoch| (__hermes_protocol.ready_epoch |__new_fml:n_f|)))))
 (let (($x23400 (__ts0__ts0__m_hermes_protocol.epoch_done_d_a |V0:hermes_protocol.epoch|)))
 (= $x23400 (ite __ts0__ts0__ts0_a_e $x6945 $x6811))))))
 )
(assert
 (let (($x8224 (__m_hermes_protocol.ready_e |__new_fml:n_f|)))
 (= __ts0__ts0__ts0_a_e $x8224)))
(assert
 (forall ((|V0:hermes_protocol.node| hermes_protocol.node) )(let (($x6972 (__m_hermes_protocol.ready_e |V0:hermes_protocol.node|)))
 (let (($x6970 (and (= |V0:hermes_protocol.node| |__new_fml:n_f|))))
 (let (($x8193 (ite $x6970 false $x6972)))
 (= (__ts0__ts0__m_hermes_protocol.ready_f_a |V0:hermes_protocol.node|) $x8193)))))
 )
(assert
 (= |__ts0__ts0__new_fml:n_g_a| |__loc:c|))
(assert
 (= |__ts0__ts0__new_fml:a_a_a| |__loc:a|))
(assert
 (= |__ts0__ts0__new_fml:t_g_a| |__loc:t1|))
(assert
 (forall ((|V0:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x6811 (__m_hermes_protocol.epoch_done_c |V0:hermes_protocol.epoch|)))
 (let (($x6945 (or $x6811 (= |V0:hermes_protocol.epoch| (__hermes_protocol.ready_epoch |__new_fml:n_f|)))))
 (let (($x23355 (__ts0__m_hermes_protocol.epoch_done_d_b |V0:hermes_protocol.epoch|)))
 (= $x23355 (ite __ts0__ts0_a_f $x6945 $x6811))))))
 )
(assert
 (let (($x8224 (__m_hermes_protocol.ready_e |__new_fml:n_f|)))
 (= __ts0__ts0_a_f $x8224)))
(assert
 (forall ((|V0:hermes_protocol.node| hermes_protocol.node) )(let (($x6972 (__m_hermes_protocol.ready_e |V0:hermes_protocol.node|)))
 (let (($x6970 (and (= |V0:hermes_protocol.node| |__new_fml:n_f|))))
 (let (($x8193 (ite $x6970 false $x6972)))
 (= (__ts0__m_hermes_protocol.ready_f_b |V0:hermes_protocol.node|) $x8193)))))
 )
(assert
 (= |__ts0__new_fml:n_g_b| |__loc:c|))
(assert
 (= |__ts0__new_fml:a_a_b| |__loc:a|))
(assert
 (= |__ts0__new_fml:t_g_b| |__loc:t1|))
(assert
 (forall ((|V0:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x23355 (__ts0__m_hermes_protocol.epoch_done_d_b |V0:hermes_protocol.epoch|)))
 (let (($x18953 (ite __ts0__ts0_a_a_b (or $x23355 (= |V0:hermes_protocol.epoch| (__hermes_protocol.ready_epoch |__ts0__new_fml:n_g_b|))) $x23355)))
 (let (($x23341 (__ts0__m_hermes_protocol.epoch_done_e_a |V0:hermes_protocol.epoch|)))
 (= $x23341 $x18953)))))
 )
(assert
 (= __ts0__ts0_a_a_b (__ts0__m_hermes_protocol.ready_f_b |__ts0__new_fml:n_g_b|)))
(assert
 (forall ((|V0:hermes_protocol.node| hermes_protocol.node) )(let (($x21837 (ite (and (= |V0:hermes_protocol.node| |__ts0__new_fml:n_g_b|)) false (__ts0__m_hermes_protocol.ready_f_b |V0:hermes_protocol.node|))))
 (= (__ts0__m_hermes_protocol.ready_g_a |V0:hermes_protocol.node|) $x21837)))
 )
(assert
 (= |__ts0__new_fml:n_h_a| |__loc:c|))
(assert
 (= |__ts0__new_fml:a_b_a| |__loc:b|))
(assert
 (= |__ts0__new_fml:t_h_a| |__loc:t1|))
(assert
 (forall ((|V0:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x5034 (__hermes_protocol.seen_epoch |V0:hermes_protocol.epoch|)))
 (let (($x411 (hermes_protocol.seen_epoch |V0:hermes_protocol.epoch|)))
 (= $x411 $x5034))))
 )
(assert
 (forall ((|V0:hermes_protocol.epoch| hermes_protocol.epoch) )(let (($x5905 (__hermes_protocol.ready_epoch_active |V0:hermes_protocol.epoch|)))
 (let (($x421 (hermes_protocol.ready_epoch_active |V0:hermes_protocol.epoch|)))
 (= $x421 $x5905))))
 )
(assert
 (forall ((|V0:hermes_protocol.node| hermes_protocol.node) )(let ((?x5162 (__hermes_protocol.ready_epoch |V0:hermes_protocol.node|)))
 (let ((?x402 (hermes_protocol.ready_epoch |V0:hermes_protocol.node|)))
 (= ?x402 ?x5162))))
 )
(assert
 (forall ((|V0:hermes_protocol.ts| hermes_protocol.ts) )(let (($x2307 (__hermes_protocol.completed |V0:hermes_protocol.ts|)))
 (let (($x643 (hermes_protocol.completed |V0:hermes_protocol.ts|)))
 (= $x643 $x2307))))
 )
(assert
 (forall ((|X:hermes_protocol.ts| hermes_protocol.ts) (|Y:hermes_protocol.ts| hermes_protocol.ts) )(let (($x48 (hermes_protocol.lt |X:hermes_protocol.ts| |Y:hermes_protocol.ts|)))
 (= $x48 (and (hermes_protocol.le |X:hermes_protocol.ts| |Y:hermes_protocol.ts|) (not (= |X:hermes_protocol.ts| |Y:hermes_protocol.ts|))))))
 )
(assert
 (forall ((|M:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x86 (hermes_protocol.cur_ts |M:hermes_protocol.node|)))
 (let ((?x87 (hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let (($x88 (hermes_protocol.lt ?x87 ?x86)))
 (let (($x89 (hermes_protocol.same_version ?x87 ?x86)))
 (= (hermes_protocol.write_then_write_order_ok |N:hermes_protocol.node| |M:hermes_protocol.node|) (or $x89 $x88)))))))
 )
(assert
 (forall ((|M:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x86 (hermes_protocol.cur_ts |M:hermes_protocol.node|)))
 (let ((?x87 (hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let (($x88 (hermes_protocol.lt ?x87 ?x86)))
 (let (($x89 (hermes_protocol.same_version ?x87 ?x86)))
 (= (hermes_protocol.rmw_then_write_order_ok |N:hermes_protocol.node| |M:hermes_protocol.node|) (or $x89 $x88 (hermes_protocol.next_version ?x87 ?x86))))))))
 )
(assert
 (forall ((|M:hermes_protocol.node| hermes_protocol.node) (|N:hermes_protocol.node| hermes_protocol.node) )(let ((?x86 (hermes_protocol.cur_ts |M:hermes_protocol.node|)))
 (let ((?x87 (hermes_protocol.cur_ts |N:hermes_protocol.node|)))
 (let (($x88 (hermes_protocol.lt ?x87 ?x86)))
 (let (($x89 (hermes_protocol.same_version ?x87 ?x86)))
 (= (hermes_protocol.rmw_then_rmw_order_ok |N:hermes_protocol.node| |M:hermes_protocol.node|) (or $x89 $x88)))))))
 )
(check-sat)
