"""Count work in SAT watched-literal propagation in both engines."""
import csv
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import traceback

pkg=Path.cwd().resolve()
root=pkg/'build/.nov26-propagation'
native=pkg.parent/'build'
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache',GOMAXPROCS='1')
active=('trail','binary','ternary','clause','blocked','removed','first_true','scanned','moved',
        'conflict','unit')

def once(src,old,new):
    if src.count(old)!=1:
        raise ValueError(old)
    return src.replace(old,new)

def go():
    prop='sat/sat_solver_propagation.go'
    storage='sat/sat_clause_storage.go'
    main='cmd/g3/main.go'
    s=(pkg/prop).read_text()
    ident='propagationObservation'
    for raw,field in [('\n\t\tv.qhead++','trail'),('case 0:\n\t\t\t\tl1 := Literal(w.val1)','binary'),
        ('case 1:\n\t\t\t\tl1, e := w.Literal1()','ternary'),
        ('case 2:\n\t\t\t\tblocked, e := w.BlockedLiteral()','clause'),
        ('if assignment[blocked.index()] == lbool.True {\n\t\t\t\t\tif tracing','blocked'),
        ('if clause.flag(satClauseFlagRemoved) || c1 != not {','removed'),
        ('if assignment[c0.index()] == lbool.True {','first_true'),
        ('if moved {\n\t\t\t\t\ti := replacement','moved'),
        ('if value == lbool.False {\n\t\t\t\t\tif e =','conflict'),
        ('s.clausePropagations++','unit')]:
        if field in ('trail','unit'):
            s=once(s,raw,raw+'\n'+ident+'.'+field+'++\n')
        else:
            j=s.index(raw)
            end=s.index('\n',j) if '\n' not in raw else j+raw.index('\n')
            s=s[:end]+f'\n{ident}.{field}++'+s[end:]
    s=s.replace('import (','import (\n"fmt"\n"os"',1)
    s+='\nvar '+ident+' struct { '+', '.join(active)+' uint64 }\n'
    data=', '.join(ident+'.'+k for k in active)
    s+='\nfunc PrintPropagationObservations(){ fmt.Fprintln(os.Stderr,"PROPAGATION-COUNTS",'+data+') }\n'
    t=(pkg/storage).read_text()
    t=once(t,'for len(rest) >= 4 {','for len(rest) >= 4 {\npropagationObservation.scanned++')
    m=(pkg/main).read_text()
    if '"github.com/glycerine/g3/pkg/sat"' not in m:
        m=m.replace('import (','import (\n"github.com/glycerine/g3/pkg/sat"',1)
    # main uses os.Exit, so defer within the returning argument parser.
    match=re.search(r'(?m)^func (runArgumentsWithDiagnostics\([^\n]+) \{\n',m)
    assert match
    m=m[:match.end()]+'defer sat.PrintPropagationObservations()\n'+m[match.end():]
    replacements={}
    for rel,src in [(prop,s),(storage,t),(main,m)]:
        f=root/Path(rel).name
        f.write_bytes(subprocess.check_output(['gofmt'],input=src.encode()))
        replacements[str(pkg/rel)]=str(f)
    p=root/'overlay.json'
    p.write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
    bin=root/'g3'
    subprocess.run(['go','build','-p','5','-overlay='+str(p),'-buildvcs=false','-pgo=off','-o',bin,'./cmd/g3'],
                   env=env,check=True)
    return bin

def cpp():
    original=pkg.parent/'src/sat/sat_solver.cpp'
    text=original.read_text()
    start=text.index('bool solver::propagate_core(bool update)')
    end=text.index('SASSERT(m_qhead == m_trail.size());',start)
    s=text[start:end]
    for boundary,field in [
        ('m_qhead++;','trail'),('case watched::BINARY:','binary'),('case watched::TERNARY:','ternary'),
        ('case watched::CLAUSE: {','clause'),('if (value(it->get_blocked_literal()) == l_true) {','blocked'),
        ('if (c.was_removed() || c[1] != not_l) {','removed'),
        ('if (value(c[0]) == l_true) {','first_true'),('for (; l_it != l_end; ++l_it) {','scanned'),
        ('if (value(*l_it) != l_false) {','moved'),('if (value(c[0]) == l_false) {','conflict'),
        ('m_stats.m_propagate++;','unit')]:
        s=once(s,boundary,boundary+f'\n++propagation_counts.{field};\n')
    decl='struct PropagationObservations { unsigned long long '+', '.join(active)+';\n'
    decl+='~PropagationObservations(){ std::fprintf(stderr,"PROPAGATION-COUNTS '+(' %llu'*len(active)).lstrip()+'\\n",'+', '.join(active)+'); } };\n'
    text='#include <cstdio>\nnamespace { '+decl+'static PropagationObservations propagation_counts{}; }\n'+text[:start]+s+text[end:]
    file=root/'sat_solver.cpp'
    file.write_text(text)
    def words(name,data):
        t=re.search(r'^'+name+r'\s*=\s*(.*?)\s*$',data,re.M)
        return shlex.split(t[1])
    config=(native/'config.mk').read_text()
    make=(native/'Makefile').read_text()
    includes=re.search(r'\$\((includes_\d+)\).*\.\./src/sat/sat_solver.cpp$',make,re.M)[1]
    obj=root/'sat_solver.o'
    subprocess.run([*words('CXX',config),*words('CXXFLAGS',config),*words(includes,make),'-o',obj,file],
                   cwd=native,check=True)
    cmds=[shlex.split(ln) for ln in subprocess.check_output(['make','-n','-W','shell/main.o','z3'],cwd=native,text=True).splitlines()
          if 'shell/main.o' in ln and ' -o z3 ' in ln]
    assert len(cmds)==1
    args=cmds[0]
    bin=root/'z3'
    args[args.index('-o')+1]=str(bin)
    args.insert(args.index('shell/main.o'),str(obj))
    subprocess.run(args,cwd=native,check=True)
    return bin

def main():
    from concurrent.futures import ThreadPoolExecutor
    from watch_propagation import formulas,dimacs,check_output
    with ThreadPoolExecutor(2) as pool:
        g,n=pool.submit(go),pool.submit(cpp)
        binaries={'g3':g.result(),'z3':n.result()}
    with (root/'runs.csv').open('w') as f:
        rows=csv.writer(f)
        rows.writerow(['case','name','answer','decisions','conflicts',*active])
        for name,n,clauses,expected in formulas(3):
            if name not in ('pigeon8','pigeon8-s0','pigeon8-s1','pigeon8-s2','propagate3','propagate6'):
                continue
            path=root/(name+'.cnf')
            path.write_text(dimacs(n,clauses))
            stats=None
            for engine,binary in binaries.items():
                p=subprocess.run(['taskset','-c','11',binary,'-st','-dimacs',path],env=env,capture_output=True,text=True)
                assert p.returncode in (0,10 if expected=='sat' else 20),p.stderr
                ours=check_output(p.stdout,expected,n,clauses)
                assert stats is None or expected=='sat' or stats==ours,(name,stats,ours)
                stats=ours
                line=next(ln for ln in p.stderr.splitlines() if ln.startswith('PROPAGATION-COUNTS'))
                counts=list(map(int,line.split()[1:]))
                assert len(counts)==len(active)
                rows.writerow([name,engine,expected,ours.get('decisions',0),ours.get('conflicts',0),*counts])
                f.flush()

if __name__=='__main__':
    main()
