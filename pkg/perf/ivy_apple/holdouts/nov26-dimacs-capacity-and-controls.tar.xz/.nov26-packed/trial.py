"""Compare 16-byte arena descriptors with directly borrowed pooled payloads."""
import json
import os
from pathlib import Path
import subprocess
import sys

pkg = Path.cwd().resolve()
root = pkg / 'build/.nov26-packed'

def once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

def layout_slab(src):
    src = once(src, 'records []vectorDescriptor', 'records []vectorDescriptor\n\tblocks []smallByteRecord')
    src = once(src, 'pageShift                                      uint8', 'pageShift uint8\n\tbyteBlocks bool')
    src = once(src, 'func (s *descriptorSlab) location', '''func (p *descriptorSlabPage) hasRecords() bool {
        return p.records != nil || p.blocks != nil
    }

    func (s *descriptorSlab) allocateRecords(p *descriptorSlabPage) {
        if s.byteBlocks {
            p.blocks = make([]smallByteRecord, s.config.PageSize)
        } else {
            p.records = make([]vectorDescriptor, s.config.PageSize)
        }
    }

    func (s *descriptorSlab) location''')
    src = once(src, 's.pages = append(s.pages, descriptorSlabPage{records: make([]vectorDescriptor, s.config.PageSize), meta: make([]descriptorState, s.config.PageSize)})\n\t} else if s.pages[p].records == nil {',
        '''page := descriptorSlabPage{meta:make([]descriptorState,s.config.PageSize)}
        s.allocateRecords(&page)
        s.pages = append(s.pages, page)
    } else if !s.pages[p].hasRecords() {''')
    src = once(src, 's.pages[p].records = make([]vectorDescriptor, s.config.PageSize)', 's.allocateRecords(&s.pages[p])')
    src = once(src, 'page.records[i] = vectorDescriptor{}', '''if s.byteBlocks {
        page.blocks[i] = smallByteRecord{}
    } else {
        page.records[i] = vectorDescriptor{}
    }''')
    src = once(src, 'if p.live == 0 && p.records != nil {\n\t\t\tp.records = nil',
              'if p.live == 0 && p.hasRecords() {\n\t\t\tp.records = nil\n\t\t\tp.blocks = nil')
    return once(src, 'if s.pages[i].records != nil {', 'if s.pages[i].hasRecords() {')

block_query = '''
// The byte-only descriptor mode keeps the typed payload pointer and its
// compact location in the original descriptor's 16 bytes on amd64.
// Pooled offsets are multiples of four and do not exceed 8 KiB.
// The allocation ledger retains the complete generation even if this
// record omits it. A nil pointer denotes a direct allocation or empty slot.
type smallByteRecord struct {
    payload *byte
    location uint64
}

const smallByteGenerationShift = 51

func (a *SmallBytes) writeBlock(slot Slot, page, offset, size uint32, gen Generation) {
    if !a.fastBlocks {
        a.descriptors.Write(slot,smallByteDescriptor(page,offset,size,gen))
        return
    }
    p,i := a.descriptors.location(slot)
    d := &a.descriptors.pages[p].blocks[i]
    if a.chunks[page].class==0 {
        *d=smallByteRecord{location:uint64(size)<<32|uint64(page)}
        return
    }
    packedGen:=uint64(gen)
    if packedGen >= 1<<(64-smallByteGenerationShift) {
        packedGen=0
    }
    *d=smallByteRecord{payload:&a.chunks[page].data[offset],
        location:uint64(page)|uint64(offset/4)<<32|uint64(size)<<43|packedGen<<smallByteGenerationShift}
}

func (d smallByteRecord) size() uint32 {
    if d.payload==nil { return uint32(d.location>>32) }
    return uint32(d.location>>43)&255
}

func (a *SmallBytes) descriptorBlock(r SmallBytesRef) (vectorDescriptor,bool) {
    if !a.descriptors.IsLive(r.Slot,r.Generation) { return vectorDescriptor{},false }
    p,i:=a.descriptors.location(r.Slot)
    d:=a.descriptors.pages[p].blocks[i]
    result:=vectorDescriptor{page:uint32(d.location),length:d.size(),capacity:uint32(r.Generation)}
    if d.payload!=nil { result.offset=(uint32(d.location>>32)&2047)*4 }
    return result,true
}

func (a *SmallBytes) borrowBlock(r SmallBytesRef) (smallByteRecord,error) {
    s:=a.descriptors
    slot:=uint32(r.Slot)-1
    if slot>=s.slots || r.Generation==0 {
        return smallByteRecord{},ErrInvalidSlot
    }
    page,index:=s.location(r.Slot)
    p:=&s.pages[page]
    if index>=uint32(len(p.blocks)) {
        return smallByteRecord{},ErrInvalidSlot
    }
    d:=p.blocks[index]
    if d.payload!=nil {
        gen:=Generation(d.location>>smallByteGenerationShift)
        if gen!=0 {
            if gen!=r.Generation { return smallByteRecord{},ErrInvalidSlot }
            return d,nil
        }
    }
    m:=p.meta[index]
    if m.next!=r.Slot || m.generation!=r.Generation {
        return smallByteRecord{},ErrInvalidSlot
    }
    return d,nil
}

func (a *SmallBytes) blockData(d smallByteRecord) []byte {
    if d.payload!=nil { return unsafe.Slice(d.payload,int(uint32(d.location>>43)&255)) }
    return a.chunks[uint32(d.location)].data
}

func (a *SmallBytes) readBlockUint32(r SmallBytesRef, offset uint32) (uint32,error) {
    if a.closed { return 0,ErrClosed }
    if r==(SmallBytesRef{}) { return 0,ErrBounds }
    d,err:=a.borrowBlock(r)
    if err!=nil { return 0,err }
    if n:=d.size(); offset>n || n-offset<4 { return 0,ErrBounds }
    if d.payload!=nil {
        return binary.LittleEndian.Uint32(unsafe.Slice((*byte)(unsafe.Add(unsafe.Pointer(d.payload),offset)),4)),nil
    }
    return binary.LittleEndian.Uint32(a.chunks[uint32(d.location)].data[offset:]),nil
}
'''

def layout_storage(src, enabled):
    src = once(src, '"reflect"', '"reflect"\n"unsafe"')
    src = once(src, 'closed                    bool', 'closed, fastBlocks        bool')
    src = once(src, 'return &SmallBytes{descriptors: d, config: c}, nil',
               '''compact := '''+enabled+''' && c.ChunkSize<=8192 && unsafe.Sizeof(smallByteRecord{})==unsafe.Sizeof(vectorDescriptor{})
    d.byteBlocks=compact
    return &SmallBytes{descriptors:d,config:c,fastBlocks:compact},nil''')
    src = once(src, 'd, live := a.descriptors.readLive(r.Slot, r.Generation)', '''var d vectorDescriptor
    var live bool
    if a.fastBlocks {
        d,live=a.descriptorBlock(r)
    }else{
        d,live=a.descriptors.readLive(r.Slot,r.Generation)
    }''')
    src = once(src, 'func (a *SmallBytes) ReadUint32LE(r SmallBytesRef, offset uint32) (uint32, error) {',
              '''func (a *SmallBytes) ReadUint32LE(r SmallBytesRef, offset uint32) (uint32, error) {
    if a.fastBlocks { return a.readBlockUint32(r,offset) }''')
    src = once(src, 's := a.descriptors\n\tif uint32(r.Slot)-1', '''if a.fastBlocks {
        b,err:=a.borrowBlock(r)
        if err!=nil {return nil,err}
        return a.blockData(b),nil
    }
    s := a.descriptors
    if uint32(r.Slot)-1''')
    src = once(src, 'a.descriptors.Write(slot, smallByteDescriptor(page, 0, size, g))', 'a.writeBlock(slot,page,0,size,g)')
    src = once(src, 'a.descriptors.Write(slot, smallByteDescriptor(page, offset, size, g))', 'a.writeBlock(slot,page,offset,size,g)')
    return src + block_query

def hoist_hot_routes(src):
    old='''if a.fastBlocks {
        b,err:=a.borrowBlock(r)
        if err!=nil {return nil,err}
        return a.blockData(b),nil
    }'''
    src=once(src,old,'if a.fastBlocks { return a.fastBorrowBlock(r) }')
    src=once(src,'if a.fastBlocks { return a.readBlockUint32(r,offset) }',
        'if a.fastBlocks { return a.fastReadBlock(r,offset) }')
    return src+'''
func (a *SmallBytes) fastBorrowBlock(r SmallBytesRef) ([]byte,error) {
    s:=a.descriptors
    n:=uint32(r.Slot)-1
    if n>=s.slots || r.Generation==0 { return nil,ErrInvalidSlot }
    rows:=s.pages[n>>s.pageShift].blocks
    index:=n&(s.config.PageSize-1)
    if index>=uint32(len(rows)) {return nil,ErrInvalidSlot}
    row:= &rows[index]
    if row.location>>smallByteGenerationShift==uint64(r.Generation) && row.payload!=nil {
        return unsafe.Slice(row.payload,int(uint32(row.location>>43)&255)),nil
    }
    d,err:=a.borrowBlock(r)
    if err!=nil { return nil,err }
    return a.blockData(d),nil
}
func (a *SmallBytes) fastReadBlock(r SmallBytesRef,offset uint32) (uint32,error) {
    s:=a.descriptors
    n:=uint32(r.Slot)-1
    if !a.closed && n<s.slots && r.Generation!=0 {
        rows:=s.pages[n>>s.pageShift].blocks
        index:=n&(s.config.PageSize-1)
        if index<uint32(len(rows)) {
            row:=&rows[index]
            if row.location>>smallByteGenerationShift==uint64(r.Generation) && row.payload!=nil {
                length:=uint32(row.location>>43)&255
                if offset>length || length-offset<4 {return 0,ErrBounds}
                return binary.LittleEndian.Uint32(unsafe.Slice((*byte)(unsafe.Add(unsafe.Pointer(row.payload),offset)),4)),nil
            }
        }
    }
    return a.readBlockUint32(r,offset)
}
'''

def build(variant):
    out = root / variant
    out.mkdir(exist_ok=True)
    enable = {'packed':'!c.DirectOnly','hot':'!c.DirectOnly','old-layout':'false'}[variant]
    patches = {
        'arena/descriptor_slab.go': layout_slab((pkg/'arena/descriptor_slab.go').read_text()),
        'arena/small_bytes.go': layout_storage((pkg/'arena/small_bytes.go').read_text(),enable),
    }
    if variant == 'hot':
        patches['arena/small_bytes.go']=hoist_hot_routes(patches['arena/small_bytes.go'])
    mapping = {}
    for name, code in patches.items():
        file=out/Path(name).name
        file.write_bytes(subprocess.check_output(['gofmt'],input=code.encode()))
        mapping[str(pkg/name)]=str(file)
    overlay = out/'overlay.json'
    overlay.write_text(json.dumps({'Replace':mapping},indent=2)+'\n')
    env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
    with (out/'tests.log').open('w') as log:
        for flags in ([],['-tags=g3checked,g3debug,g3trace'],
                      ['-gcflags=github.com/glycerine/g3/pkg/arena=-d=checkptr=2','-run=SmallBytes|Clause|Propagation|Subsumption']):
            subprocess.run(['go','test','-p','5','-overlay='+str(overlay),'-count=1',*flags,'./arena','./sat'],env=env,stdout=log,stderr=log,check=True)
    subprocess.run(['go','build','-p','5','-overlay='+str(overlay),'-buildvcs=false','-pgo=off','-o',str(out/'g3'),'./cmd/g3'], env=env,check=True)
    subprocess.run(['go','test','-p','5','-overlay='+str(overlay),'-c','-pgo=off','-o',str(out/'sat.test'),'./sat'],env=env,check=True)

if __name__=='__main__':
    build(sys.argv[1] if len(sys.argv)>1 else 'packed')
