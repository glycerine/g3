"""Time endpoint-preserving alternatives to the inner clause-literal scan."""
import json
import os
from pathlib import Path
import subprocess
import sys
pkg = Path.cwd().resolve()
root = pkg/'build/.nov26-watch-scan'
name = 'sat/sat_clause_storage.go'
src=(pkg/name).read_text()
variant=sys.argv[1]
out=root/variant
out.mkdir()
start=src.index('\trest := v[satClauseLiteralsOffset+8')
end=src.index('\n\treturn 0, false',start)
old=src[start:end]
assert 'v.setLiteral(1, replacement)' in old
index_scan='''
    rest := v[satClauseLiteralsOffset+8 : satClauseLiteralsOffset+4*uint64(n)]
    for i:=0;i<len(rest);i+=4{
        replacement:=Literal(binary.LittleEndian.Uint32(rest[i:]))
        if assignment[replacement.index()] != lbool.False {
            v.setLiteral(1,replacement)
            binary.LittleEndian.PutUint32(rest[i:],uint32(falsified))
            return replacement,true
        }
    }'''.strip('\n')
pointer_scan='''
    rest := v[satClauseLiteralsOffset+8 : satClauseLiteralsOffset+4*uint64(n)]
    // The bit pattern below is the little-endian host representation.
    // Other hosts take the portable path.
    if *(*byte)(unsafe.Pointer(&satLittleEndianProbe)) == 1 {
        words:=unsafe.Slice((*uint32)(unsafe.Pointer(unsafe.SliceData(rest))),len(rest)/4)
        for i,word:= range words {
            replacement:=Literal(word)
            if assignment[replacement.index()] != lbool.False {
                v.setLiteral(1,replacement)
                words[i]=uint32(falsified)
                return replacement,true
            }
        }
        return 0,false
    }
'''.strip('\n')
if variant=='index':
    src=src[:start]+index_scan+src[end:]
elif variant=='words':
    src=src[:start]+pointer_scan+'\n'+old[old.index(chr(10))+1:]+src[end:]
    src=src.replace('"sync/atomic"','"sync/atomic"\n"unsafe"',1)
    src+='\nvar satLittleEndianProbe = uint32(1)\n'
else:
    raise ValueError(variant)
patch=out/Path(name).name
patch.write_bytes(subprocess.check_output(['gofmt'],input=src.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(pkg/name):str(patch)}})+'\n')
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
with (out/'tests.log').open('w') as log:
    for flags in ([],['-tags=g3checked,g3debug,g3trace'],['-gcflags=github.com/glycerine/g3/pkg/sat=-d=checkptr=2','-run=Clause|Propagation|Subsumption']):
        subprocess.run(['go','test','-p','4','-count=1','-overlay='+str(overlay),*flags,'./sat'],env=env,stdout=log,stderr=log,check=True)
subprocess.run(['go','build','-p','4','-pgo=off','-buildvcs=false','-overlay='+str(overlay),'-o',str(out/'g3'),'./cmd/g3'],env=env,check=True)
