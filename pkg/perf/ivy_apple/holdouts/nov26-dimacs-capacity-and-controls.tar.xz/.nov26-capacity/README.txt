Hosts and tools
  Threadripper 3960X, Linux amd64, Go 1.27.3.
  GOMAXPROCS=1 for standalone DIMACS. Linux perf user-mode instructions and
  cycles in each solver command. Baseline g3 code at 47792d65b. Z3 is this
  checkout's ../build/z3. Final capacity and model-output revisions are
  35c6ff567 and 442c1c1a0. Tests and sources for them are in git.

Files and commands, from pkg/
  final/pigeon.csv and final/controls.csv are the release comparison, with
  watch_propagation.py --compare-heuristics --permutations 3 for pigeon and
  five rotations of the six satisfiable controls. CPU 12 for pigeon and CPU
  13 for controls. The plain prototype and release each have separate CSVs.
  final-output/controls.csv compares capacity, final batched model output,
  and Z3. Batched-output/controls.csv is the earlier seven-rotation trial.
  final-output/model-bytes.log compares whole stdout against the previous g3,
  and the driver independently verifies every assignment against the input.
  .nov26-propagation/measure.py builds in-tree Go and C++ observers. This is
  the source of the matched propagation counters, independent of timing.
  .nov26-packed/ and .nov26-watch-scan/ retain overlay generators and results
  for the descriptor and replacement scan alternatives. Both descriptor
  comparisons used CPU 12, the scan comparison CPU 13. The raw warm
  benchmark rows report bytes per clause and time per 49,152 checked views.
  .nov26-candidate/ retains the overlays and complete proof results. GoIvy
  07cdeec61 with its local module replacement and the same ABC binary as
  the earlier published pair. The nine accepted observations per engine
  require at least .88 idle fraction before and on the sibling during the
  run. All attempted matches, including busy-core rejections, are recorded.
  .nov26-later/quiet-apple2/runs.csv is an interim snapshot of the separate
  full Apple timing job. This is not the final three-rotation comparison.
