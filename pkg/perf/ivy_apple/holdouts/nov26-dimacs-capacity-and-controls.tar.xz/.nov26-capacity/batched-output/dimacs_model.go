package shell

// Source: src/shell/dimacs_frontend.cpp:49-59,126-137.
import (
	"github.com/glycerine/g3/pkg/sat"
	"github.com/glycerine/g3/pkg/util/lbool"
	"io"
	"strconv"
)

func (f *DIMACSFrontend) writeResult(s *sat.Solver, status lbool.LBool, tracking [][]sat.Literal) error {
	switch status {
	case lbool.True:
		if _, err := io.WriteString(f.output, "sat\n"); err != nil {
			return err
		}
		model, err := s.AppendModel(nil)
		if err != nil {
			return err
		}
		var buffer [4096]byte
		chunk := buffer[:0]
		for i := 1; i < len(model); i++ {
			var variable int
			switch model[i] {
			case lbool.True:
				variable = i
			case lbool.False:
				variable = -i
			default:
				continue
			}
			if len(chunk) > len(buffer)-21 {
				if n, err := f.output.Write(chunk); err != nil {
					return err
				} else if n != len(chunk) {
					return io.ErrShortWrite
				}
				chunk = buffer[:0]
			}
			chunk = strconv.AppendInt(chunk, int64(variable), 10)
			chunk = append(chunk, ' ')
		}
		chunk = append(chunk, '\n')
		n, err := f.output.Write(chunk)
		if err == nil && n != len(chunk) {
			return io.ErrShortWrite
		}
		return err
	case lbool.False:
		if _, err := io.WriteString(f.output, "unsat\n"); err != nil {
			return err
		}
		if tracking != nil {
			return f.writeCore(s, tracking)
		}
		return nil
	default:
		_, err := io.WriteString(f.output, "unknown\n")
		return err
	}
}
