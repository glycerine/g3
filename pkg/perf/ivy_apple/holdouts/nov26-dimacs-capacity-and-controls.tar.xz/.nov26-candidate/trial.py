"""Evaluate compiled quantifier candidates with syntax-local memoization."""
import json
import os
from pathlib import Path
import subprocess
import sys
pkg=Path.cwd().resolve()
ivy=Path('/home/jaten/ivy/goivy')
root=pkg/'build/.nov26-candidate'
variant=sys.argv[1]
out=root/variant
out.mkdir()
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
name='smtcore/smt_checker_candidate.go'
source=(pkg/name).read_text()
if variant in ('memo','fewer-reads'):
    if variant=='memo':
        source=source.replace('''refs, err := c.context.manager.GetRefCount(n.expression)
	if err != nil {
		return nil, err
	}
	return c.candidateEnodeWithRefs(p, n, refs)''','return c.candidateEnodeCore(p, n)',1)
        source=source.replace('candidateEnodeWithRefs(p *smtCandidateBody, n *smtCandidateNode, refs uint32)',
                              'candidateEnodeCore(p *smtCandidateBody, n *smtCandidateNode)',1)
        source=source.replace('''refs, err := c.context.manager.GetRefCount(n.expression)
	if err != nil {
		return false, err
	}
	''','',1)
        source=source.replace('refs > 1 && n.memo != 0','n.memo != 0')
        source=source.replace('checkCandidateCore(p, n, refs, want)','checkCandidateCore(p, n, want)')
        source=source.replace('checkCandidateCore(p *smtCandidateBody, n *smtCandidateNode, refs uint32, want bool)',
                              'checkCandidateCore(p *smtCandidateBody, n *smtCandidateNode, want bool)')
        source=source.replace('c.candidateEnodeWithRefs(p, n, refs)','c.candidateEnodeCore(p, n)')
    else:
        for fail in ('nil','false'):
            old=f'refs, err := c.context.manager.GetRefCount(n.expression)\n\tif err != nil {{\n\t\treturn {fail}, err\n\t}}'
            assert source.count(old)==1
            source=source.replace(old,f'''var refs uint32
                if n.memo != 0 {{
                    var err error
                    if refs,err=c.context.manager.GetRefCount(n.expression); err!=nil {{return {fail},err}}
                }}''')
    # Candidate evaluation borrows the registered quantifier body. Establish
    # manager validity once before the pure reads from the prepared plan.
    signature='func (c *SMTChecker) runCandidate(p *smtCandidateBody, want bool) (bool, error) {'
    source=source.replace(signature,signature+'''
        if err:=c.context.manager.ValidateHandle(p.body); err!=nil {return false,err}
    ''',1)
elif variant!='base':
    raise ValueError(variant)
extra=out/'smt_checker_candidate.go'
extra.write_bytes(subprocess.check_output(['gofmt'],input=source.encode()))
mapping={str(pkg/name):str(extra),str(Path('/home/jaten/g3/pkg')/name):str(extra)}
path=out/'overlay.json'
path.write_text(json.dumps({'Replace':mapping},indent=2)+'\n')
flags=['-p','4','-overlay='+str(path)]
with (out/'tests.log').open('w') as log:
    subprocess.run(['go','test',*flags,'-run=SMTChecker|QuantifierCandidate|QIInstance','./smtcore'],
                   env=env,stdout=log,stderr=log,check=True)
subprocess.run(['go','test',*flags,'-c','-pgo=off','-o',str(out/'smt.test'),'./smtcore'],env=env,check=True)
subprocess.run(['go','build',*flags,'-mod=readonly','-pgo=off','-buildvcs=false','-tags=xtrace_off',
                '-o',str(out/'goivy_check'),'./cmd/goivy_check'],cwd=ivy,env=env,check=True)
(out/'abc').symlink_to('/tmp/g3-nov22b/spec-survey/with-abc-native/abc')
