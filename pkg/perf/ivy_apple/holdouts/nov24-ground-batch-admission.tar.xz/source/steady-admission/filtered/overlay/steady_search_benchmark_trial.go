package api

import (
	"errors"
	"fmt"
	"github.com/glycerine/g3/pkg/api/internal/order"
	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/sat"
	"github.com/glycerine/g3/pkg/util/control"
	"github.com/glycerine/g3/pkg/util/lbool"
	"os"
	"strconv"
)

// The experiment retains only definitional clauses and certified consequences
// of the permanent source premises. SAT and UNKNOWN both defer to the source.
type studySteadySearch struct {
	sync          int
	projectionIDs []uint32
	db            order.StudyGroundDB
	version       uint64
	sat           orderBooleanSolver
	rows          int
	validated     bool
}

func (s *studySteadySearch) close() error {
	s.rows = 0
	s.sync = 0
	s.projectionIDs = nil
	s.validated = false
	return s.sat.close()
}
func (s *studySteadySearch) prove(src *APISimpleSolver, m *ast.ASTManager, roots []ast.ASTHandle) (proved bool, err error) {
	p, e := s.db.Project(m, roots, steadyRepeat, steadyMin, steadyCong)
	if e != nil || p == nil {
		return false, e
	}
	b := &s.sat
	l := m.ResourceLimit()
	if s.version != p.Version {
		if e = s.close(); e != nil {
			return false, e
		}
		s.version = p.Version
	}
	if b.limit == nil {
		b.limit, e = control.NewReslimit(m.Budget())
		if e != nil {
			return false, e
		}
	}
	limit := b.limit
	limit.RunSignals = l.RunSignals
	defer func() { limit.RunSignals = nil }()
	if e = limit.Push(2000000); e != nil {
		return false, e
	}
	defer limit.Pop()
	if e = l.PushChild(limit); e != nil {
		return false, e
	}
	defer l.PopChild()
	if l.CancelFlag() || !limit.IncOffset(uint32(p.Work)) {
		return false, nil
	}
	added := len(p.Clauses) - s.rows
	start := limit.Count()
	var result lbool.LBool
	defer func() {
		if proved && err == nil && !s.validated {
			s.validated, err = validProofInput(m, roots[:len(roots)-1], limit)
			proved = s.validated
		}
		if proved && err == nil {
			proved, err = validProofInput(m, roots[len(roots)-1:], limit)
		}
		if l.CancelFlag() || !limit.IncOffset(0) {
			proved = false
		}
		if steadyAudit {
			fmt.Fprintln(os.Stderr, "STEADY", s.version, p.Variables, len(p.Clauses), added, p.Work, limit.Count()-start, result, proved, err == nil)
		}
	}()
	if steadyFilter != "" {
		yes, done := p.BCP(m, 0)
		if yes && done {
			return true, nil
		}
		if !p.Indexed() {
			return false, nil
		}
		newVars := p.Variables + 1 - len(s.projectionIDs)
		if newVars > 0 {
			s.projectionIDs = append(s.projectionIDs, make([]uint32, newVars)...)
		}
		if b.solver == nil {
			if e = b.start(src, m); e != nil {
				return false, errors.Join(e, s.close())
			}
		}
		good := false
		defer func() {
			if !good {
				err = errors.Join(err, s.close())
			}
		}()
		literal := func(x int32) (sat.Literal, error) {
			n := x
			if n < 0 {
				n = -n
			}
			id := s.projectionIDs[n]
			if id == 0 {
				v, e := b.solver.MkVar(true, true)
				if e != nil {
					return sat.DefaultLiteral(), e
				}
				id = uint32(v) + 1
				s.projectionIDs[n] = id
			}
			return sat.MakeLiteral(sat.BoolVar(id-1), x < 0), nil
		}
		trail := p.Permanent()
		if s.sync > len(trail) {
			return false, nil
		}
		for _, v := range trail[s.sync:] {
			n := v
			if n < 0 {
				n = -n
			}
			id := s.projectionIDs[n]
			if id != 0 {
				if e = b.solver.MkClause([]sat.Literal{sat.MakeLiteral(sat.BoolVar(id-1), v < 0)}); e != nil {
					return false, e
				}
			}
		}
		s.sync = len(trail)
		var cut [3]int32
		var cnf [3]sat.Literal
		for j, row := range p.Clauses[s.rows:] {
			if j%256 == 0 && !limit.IncOffset(uint32(min(256, len(p.Clauses)-s.rows-j))) {
				return false, nil
			}
			used := 0
			ok := false
			for _, x := range row {
				if x == 0 {
					break
				}
				val := p.Value(x)
				if val > 0 {
					ok = true
					break
				}
				if val == 0 {
					cut[used] = x
					used++
				}
			}
			if ok {
				continue
			}
			for j, x := range cut[:used] {
				cnf[j], e = literal(x)
				if e != nil {
					return false, e
				}
			}
			if e = b.solver.MkClause(cnf[:used]); e != nil {
				return false, e
			}
		}
		s.rows = len(p.Clauses)
		switch p.Value(p.Goal) {
		case -1:
			good = true
			return true, nil
		case 1:
			result, e = b.solver.Check(nil)
		default:
			lit, e := literal(p.Goal)
			if e != nil {
				return false, e
			}
			result, e = b.solver.Check([]sat.Literal{lit})
			if e != nil {
				return false, e
			}
		}
		if e != nil {
			return false, e
		}
		if e = b.solver.PopToBaseLevel(); e != nil {
			return false, e
		}
		good = !l.CancelFlag() && limit.IncOffset(0)
		return good && result == lbool.False, nil
	}
	if steadyBackend != "sat" {
		yes, complete := p.BCP(m, steadyDecisions)
		if yes && complete {
			return true, nil
		}
		if steadyBackend == "units" || l.CancelFlag() {
			return false, nil
		}
	}
	if b.solver == nil {
		if e = b.start(src, m); e != nil {
			return false, errors.Join(e, s.close())
		}
	}
	good := false
	defer func() {
		if !good {
			err = errors.Join(err, s.close())
		}
	}()
	for len(b.vars) <= p.Variables {
		v, e := b.solver.MkVar(true, true)
		if e != nil {
			return false, e
		}
		b.vars = append(b.vars, v)
	}
	ok, e := b.add(p.Clauses[s.rows:], sat.DefaultLiteral())
	if e != nil || !ok {
		return false, e
	}
	s.rows = len(p.Clauses)
	goal := p.Goal
	if goal == 0 {
		return false, ast.ErrASTDomain
	}
	id := goal
	if id < 0 {
		id = -id
	}
	lit := sat.MakeLiteral(b.vars[id], goal < 0)
	result, e = b.solver.Check([]sat.Literal{lit})
	if e != nil {
		return false, e
	}
	if e = b.solver.PopToBaseLevel(); e != nil {
		return false, e
	}
	good = !l.CancelFlag() && limit.IncOffset(0)
	return good && result == lbool.False, nil
}

var steadyBackend = os.Getenv("G3_STEADY_ENGINE")
var steadyAudit = os.Getenv("G3_STEADY_AUDIT") != ""
var steadyMin = func() int { v, _ := strconv.Atoi(os.Getenv("G3_STEADY_MIN")); return v }()
var steadyRepeat = func() int { v, _ := strconv.Atoi(os.Getenv("G3_STEADY_REPEAT")); return v }()
var steadyCong = func() int { v, _ := strconv.Atoi(os.Getenv("G3_STEADY_CONGRUENCE")); return v }()
var steadyDecisions = func() int { v, _ := strconv.Atoi(os.Getenv("G3_STEADY_DECISIONS")); return v }()

var steadyPlacement = os.Getenv("G3_STEADY_WHEN")

var steadyFilter = os.Getenv("G3_STEADY_FILTER")

var steadyHint = func() int { v, _ := strconv.Atoi(os.Getenv("G3_STEADY_HINT")); return v }()
var steadyDelay = func() int { v, _ := strconv.Atoi(os.Getenv("G3_STEADY_DELAY")); return v }()
