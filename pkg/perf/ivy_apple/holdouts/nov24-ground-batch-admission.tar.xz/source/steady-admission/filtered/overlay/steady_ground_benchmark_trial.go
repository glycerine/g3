package order

import (
	"github.com/glycerine/g3/pkg/ast"
	"math/bits"
	"slices"
	"sort"
)

// Experimental incremental ground projection. Only facts and positive
// top-level universal instances are permanent. The goal is a SAT assumption.
type StudyGroundPacket struct {
	Version   uint64
	Base      *StudyGroundDB
	Variables int
	Clauses   []BooleanClause
	Goal      int32
	Work      int
}
type studyQuantRule struct {
	body  ast.ASTHandle
	sorts [4]ast.ASTHandle
	n     int
}
type studyInstantiation struct {
	id   int
	args [4]uint32
}
type steadyCode struct {
	start int32
	width int
}
type StudyGroundDB struct {
	defs                    []steadyGateDef
	version                 uint64
	units                   steadyUnits
	m                       *ast.ASTManager
	base                    []ast.ASTHandle
	rules                   []studyQuantRule
	facts                   []ast.ASTHandle
	indexed, loaded, failed bool
	g                       groundProjection
	counts                  map[[8]ast.ASTHandle]int
	installed               map[[8]ast.ASTHandle]bool
	terms                   map[studyInstantiation]bool
	result                  []int32
	codes                   []steadyCode
	labels                  map[ast.ASTHandle]int
	group                   map[uint32][]uint32
	sorts                   map[uint32]ast.ASTHandle
	dataITE                 map[uint32]bool
	nextInput               int
	equal                   map[[2]uint32]int32
	gates                   map[[3]int32]int32
	vars                    int32
	cnf                     []BooleanClause
	congruence              int
}

func (z *StudyGroundDB) reset(m *ast.ASTManager, base []ast.ASTHandle) {
	*z = StudyGroundDB{version: z.version + 1, m: m, base: slices.Clone(base), counts: map[[8]ast.ASTHandle]int{}, installed: map[[8]ast.ASTHandle]bool{}, terms: map[studyInstantiation]bool{},
		g: newGroundProjection(m, 500000), result: []int32{0}, codes: []steadyCode{{}}, labels: map[ast.ASTHandle]int{}, group: map[uint32][]uint32{}, sorts: map[uint32]ast.ASTHandle{}, dataITE: map[uint32]bool{}, equal: map[[2]uint32]int32{}, gates: map[[3]int32]int32{}, vars: 1, cnf: []BooleanClause{{1}}, nextInput: 1}
}
func (z *StudyGroundDB) index() error {
	m := z.m
	todo := slices.Clone(z.base)
	seen := map[ast.ASTHandle]bool{}
	for len(todo) > 0 {
		if len(todo) > 8192 || len(seen) > 8192 || m.ResourceLimit().CancelFlag() {
			return errBitLimit
		}
		i := len(todo) - 1
		h := todo[i]
		todo = todo[:i]
		if seen[h] {
			continue
		}
		seen[h] = true
		hd, e := m.NodeHeader(h)
		if e != nil {
			return e
		}
		if hd.Kind == ast.ASTApp && hd.Family == m.BasicFamilyID() && hd.DeclKind == ast.ASTOpAnd {
			for j := hd.NumArgs; j > 0; j-- {
				v, e := m.GetArg(h, j-1)
				if e != nil {
					return e
				}
				todo = append(todo, v)
			}
			continue
		}
		if hd.Kind != ast.ASTQuantifier {
			ok, e := m.IsGround(h)
			if e != nil {
				return e
			}
			if ok {
				z.facts = append(z.facts, h)
			}
			continue
		}
		all, e := m.IsForall(h)
		if e != nil {
			return e
		}
		if !all {
			continue
		}
		n, e := m.GetNumDeclarations(h)
		if e != nil {
			return e
		}
		if n == 0 || n > 4 {
			continue
		}
		body, e := m.GetQuantifierBody(h)
		if e != nil {
			return e
		}
		nested, e := m.HasQuantifiers(body)
		if e != nil {
			return e
		}
		if nested {
			continue
		}
		rule := studyQuantRule{n: int(n), body: body}
		for j := uint32(0); j < n; j++ {
			rule.sorts[j], e = m.GetDeclarationSort(h, j)
			if e != nil {
				return e
			}
		}
		z.rules = append(z.rules, rule)
	}
	z.indexed = true
	return nil
}
func (z *StudyGroundDB) key(q ast.ASTHandle) (k [8]ast.ASTHandle, n int, err error) {
	m := z.m
	ground, e := m.IsGround(q)
	if e != nil || !ground {
		return k, 0, e
	}
	todo := []ast.ASTHandle{q}
	seen := map[ast.ASTHandle]bool{}
	for len(todo) != 0 {
		if len(seen) > 256 || len(todo) > 512 || m.ResourceLimit().CancelFlag() {
			return k, 0, nil
		}
		i := len(todo) - 1
		h := todo[i]
		todo = todo[:i]
		if seen[h] {
			continue
		}
		seen[h] = true
		hd, e := m.NodeHeader(h)
		if e != nil || hd.Kind != ast.ASTApp || hd.NumArgs > 256 {
			return k, 0, e
		}
		if hd.NumArgs == 0 && hd.Family == ast.NullFamilyID {
			st, e := m.GetSort(h)
			if e != nil {
				return k, 0, e
			}
			ok, e := m.IsUninterpretedSort(st)
			if e != nil {
				return k, 0, e
			}
			if ok {
				if n == len(k) {
					return k, 0, nil
				}
				k[n] = h
				n++
			}
		}
		for j := uint32(0); j < hd.NumArgs; j++ {
			v, e := m.GetArg(h, j)
			if e != nil {
				return k, 0, e
			}
			todo = append(todo, v)
		}
	}
	sort.Slice(k[:n], func(i, j int) bool { return k[i].Slot() < k[j].Slot() })
	return k, n, nil
}
func (z *StudyGroundDB) source(h ast.ASTHandle) (uint32, error) {
	g := &z.g
	v, e := g.read(h, 0)
	if e != nil {
		return 0, e
	}
	if d := len(g.input) - len(g.global); d > 0 {
		g.global = append(g.global, make([]uint32, d)...)
		g.local = append(g.local, make([]uint32, d)...)
		g.version = append(g.version, make([]uint32, d)...)
	}
	for ; z.nextInput < len(g.input); z.nextInput++ {
		n := &g.input[z.nextInput]
		if n.kind != ast.ASTApp || n.boolean {
			continue
		}
		if _, ok := z.sorts[n.symbol]; ok {
			continue
		}
		st, e := z.m.GetSort(n.expr)
		if e != nil {
			return 0, e
		}
		z.sorts[n.symbol] = st
		hd, e := z.m.NodeHeader(n.expr)
		if e != nil {
			return 0, e
		}
		z.dataITE[n.symbol] = hd.Family == z.m.BasicFamilyID() && hd.DeclKind == ast.ASTOpIte && hd.NumArgs == 3
	}
	return v, nil
}
func (z *StudyGroundDB) newVar() int32 { z.vars++; return z.vars }
func (z *StudyGroundDB) and(a, b int32) int32 {
	if a == 1 || a == b {
		return b
	}
	if b == 1 {
		return a
	}
	if a == -1 || b == -1 || a == -b {
		return -1
	}
	if a > b {
		a, b = b, a
	}
	key := [3]int32{a, b, 0}
	if v := z.gates[key]; v != 0 {
		return v
	}
	v := z.newVar()
	z.gates[key] = v
	z.rememberGate(v, a, b, 0)
	return v
}
func (z *StudyGroundDB) ite(c, a, b int32) int32 {
	if c == 1 || a == b {
		return a
	}
	if c == -1 {
		return b
	}
	if a == 1 {
		return -z.and(-c, -b)
	}
	if a == -1 {
		return z.and(-c, b)
	}
	if b == 1 {
		return -z.and(c, -a)
	}
	if b == -1 {
		return z.and(c, a)
	}
	if c < 0 {
		c, a, b = -c, b, a
	}
	sg := int32(1)
	if a < 0 {
		a, b, sg = -a, -b, -1
	}
	key := [3]int32{c, a, b}
	if v := z.gates[key]; v != 0 {
		return sg * v
	}
	v := z.newVar()
	z.gates[key] = v
	z.rememberGate(v, c, a, b)
	return sg * v
}
func (z *StudyGroundDB) eq(a, b uint32) int32 {
	if a == b {
		return 1
	}
	if a > b {
		a, b = b, a
	}
	key := [2]uint32{a, b}
	if v := z.equal[key]; v != 0 {
		return v
	}
	v := int32(1)
	if z.g.terms[a].boolean {
		v = z.ite(z.result[a], z.result[b], -z.result[b])
	} else {
		x, y := z.codes[a], z.codes[b]
		for j := 0; j < max(x.width, y.width); j++ {
			u, w := int32(-1), int32(-1)
			if j < x.width {
				u = x.start + int32(j)
			}
			if j < y.width {
				w = y.start + int32(j)
			}
			v = z.and(v, z.ite(u, w, -w))
		}
	}
	z.equal[key] = v
	return v
}
func (z *StudyGroundDB) assert(v int32) {
	if v != 1 {
		z.need(v)
		z.cnf = append(z.cnf, BooleanClause{v})
	}
}
func (z *StudyGroundDB) compile() error {
	g := &z.g
	for i := uint32(len(z.result)); i < uint32(len(g.terms)); i++ {
		if z.vars > 150000 || len(z.cnf) > 450000 {
			return errBitLimit
		}
		t := &g.terms[i]
		a := g.arguments[t.start : t.start+t.count]
		if e := g.compiler.charge(1 + len(a)); e != nil {
			return e
		}
		vs := z.result
		v := int32(0)
		var code steadyCode
		if !t.boolean {
			st, ok := z.sorts[t.symbol]
			if !ok {
				return inapplicable
			}
			n := bits.Len(uint(z.labels[st]))
			z.labels[st]++
			code = steadyCode{z.vars + 1, n}
			z.vars += int32(n)
		} else {
			switch t.operation {
			case opaqueOperation:
				v = z.newVar()
			case ast.ASTOpTrue:
				v = 1
			case ast.ASTOpFalse:
				v = -1
			case ast.ASTOpNot:
				v = -vs[a[0]]
			case ast.ASTOpAnd, ast.ASTOpOr:
				sign := int32(1)
				if t.operation == ast.ASTOpOr {
					sign = -1
				}
				v = 1
				for _, j := range a {
					v = z.and(v, sign*vs[j])
				}
				v *= sign
			case ast.ASTOpImplies:
				v = -z.and(vs[a[0]], -vs[a[1]])
			case ast.ASTOpIte:
				v = z.ite(vs[a[0]], vs[a[1]], vs[a[2]])
			case ast.ASTOpIff, ast.ASTOpEq:
				v = z.eq(a[0], a[1])
			case ast.ASTOpXor:
				v = -z.eq(a[0], a[1])
			default:
				return inapplicable
			}
		}
		z.result = append(z.result, v)
		z.codes = append(z.codes, code)
		if z.dataITE[t.symbol] {
			z.guardEqual(vs[a[0]], i, a[1])
			z.guardEqual(-vs[a[0]], i, a[2])
		}
		if t.count == 0 || t.count > 8 || t.operation != opaqueOperation {
			continue
		}
		list := z.group[t.symbol]
		if len(list) >= z.congruence {
			continue
		}
		for _, o := range list {
			ot := g.terms[o]
			if ot.count != t.count {
				return inapplicable
			}
			other := g.arguments[ot.start : ot.start+ot.count]
			if e := g.compiler.charge(1 + len(a)); e != nil {
				return e
			}
			same := int32(1)
			for j, x := range a {
				same = z.and(same, z.eq(x, other[j]))
			}
			z.guardEqual(same, i, o)
		}
		z.group[t.symbol] = append(list, i)
	}
	return nil
}
func (z *StudyGroundDB) root(h ast.ASTHandle) (uint32, error) {
	id, e := z.source(h)
	if e != nil {
		return 0, e
	}
	return z.g.ground(id, 0)
}
func (z *StudyGroundDB) join(k [8]ast.ASTHandle, n int) error {
	g := &z.g
	if !z.loaded {
		for _, h := range z.facts {
			v, e := z.root(h)
			if e != nil {
				return e
			}
			g.roots = append(g.roots, v)
		}
		z.loaded = true
	}
	if !z.installed[k] {
		by := map[ast.ASTHandle][]uint32{}
		for _, h := range k[:n] {
			id, e := z.source(h)
			if e != nil {
				return e
			}
			st := g.input[id].sort
			if st.IsNull() {
				return inapplicable
			}
			if len(by[st]) < 3 {
				by[st] = append(by[st], id)
			}
		}
		for id, r := range z.rules {
			var sets [4][]uint32
			comb := 1
			for j := 0; j < r.n; j++ {
				sets[j] = by[r.sorts[j]]
				comb *= len(sets[j])
			}
			if comb == 0 {
				continue
			}
			if e := g.compiler.charge(1); e != nil {
				return e
			}
			var root uint32
			for j := 0; j < min(comb, 32); j++ {
				key := studyInstantiation{id: id}
				off := j
				for x := r.n - 1; x >= 0; x-- {
					key.args[x] = sets[x][off%len(sets[x])]
					off /= len(sets[x])
				}
				if z.terms[key] {
					continue
				}
				if len(z.terms) > 9000 {
					return errBitLimit
				}
				if root == 0 {
					var e error
					root, e = z.source(r.body)
					if e != nil {
						return e
					}
				}
				g.bindings = key.args[:r.n]
				g.epoch++
				v, e := g.ground(root, 0)
				g.bindings = nil
				if e != nil {
					return e
				}
				g.roots = append(g.roots, v)
				z.terms[key] = true
			}
		}
		z.installed[k] = true
	}
	if e := z.compile(); e != nil {
		return e
	}
	for _, v := range g.roots {
		z.assert(z.result[v])
	}
	g.roots = g.roots[:0]
	return nil
}
func (z *StudyGroundDB) Project(m *ast.ASTManager, xs []ast.ASTHandle, repeat, minRules, congruence int) (p *StudyGroundPacket, err error) {
	if len(xs) < 2 || len(xs) > 8192 {
		return nil, nil
	}
	base, goal := xs[:len(xs)-1], xs[len(xs)-1]
	if z.m != m || !slices.Equal(z.base, base) {
		z.reset(m, base)
	}
	if z.failed {
		return nil, nil
	}
	key, n, e := z.key(goal)
	if e != nil || n == 0 {
		return nil, e
	}
	z.counts[key]++
	if z.counts[key] < repeat {
		return nil, nil
	}
	defer func() {
		if err != nil {
			z.failed = true
			if err == inapplicable || err == errBitLimit {
				err = nil
				p = nil
			}
		}
	}()
	if !z.indexed {
		if e = z.index(); e != nil {
			return nil, e
		}
	}
	if len(z.rules) < minRules {
		z.failed = true
		return nil, nil
	}
	z.g.compiler.work = 0
	z.g.compiler.nextPoll = 0
	z.congruence = congruence
	if e = z.join(key, n); e != nil {
		return nil, e
	}
	v, e := z.root(goal)
	if e != nil {
		return nil, e
	}
	if e = z.compile(); e != nil {
		return nil, e
	}
	z.need(z.result[v])
	return &StudyGroundPacket{z.version, z, int(z.vars), z.cnf, z.result[v], z.g.compiler.work}, nil
}

// The partial assignments before mark follow from the permanent clauses.
// The assumption and all branch assignments are undone after each query.
type steadyUnits struct {
	values   []int8
	links    [][]int32
	trail    []int32
	indexed  int
	conflict bool
}

func (u *steadyUnits) value(v int32) int8 {
	if v < 0 {
		return -u.values[-v]
	}
	return u.values[v]
}
func (u *steadyUnits) set(v int32) bool {
	x := v
	sign := int8(1)
	if x < 0 {
		x = -x
		sign = -1
	}
	old := u.values[x]
	if old != 0 {
		return old == sign
	}
	u.values[x] = sign
	u.trail = append(u.trail, v)
	return true
}
func (u *steadyUnits) undo(n int) {
	for _, v := range u.trail[n:] {
		if v < 0 {
			v = -v
		}
		u.values[v] = 0
	}
	u.trail = u.trail[:n]
}
func (u *steadyUnits) row(r BooleanClause) (unit int32, active bool) {
	for _, v := range r {
		if v == 0 {
			break
		}
		x := u.value(v)
		if x > 0 {
			return 0, false
		}
		if x == 0 {
			if unit != 0 {
				return 0, false
			}
			unit = v
		}
	}
	return unit, true
}
func (u *steadyUnits) prop(m *ast.ASTManager, cl []BooleanClause, head int, work *int) (bool, bool) {
	for ; head < len(u.trail); head++ {
		if *work < 0 || m.ResourceLimit().CancelFlag() {
			return false, false
		}
		for _, j := range u.links[literalSlot(-u.trail[head])] {
			*work--
			if v, ok := u.row(cl[j]); ok && (v == 0 || !u.set(v)) {
				return true, true
			}
		}
	}
	return false, true
}
func (u *steadyUnits) search(m *ast.ASTManager, cl []BooleanClause, head int, work, left *int) (bool, bool) {
	if yes, done := u.prop(m, cl, head, work); yes || !done {
		return yes, done
	}
	if *left <= 0 {
		return false, false
	}
	var pivot int32
	for _, row := range cl {
		*work--
		if *work <= 0 {
			return false, false
		}
		sat := false
		v := int32(0)
		for _, lit := range row {
			if lit == 0 {
				break
			}
			x := u.value(lit)
			if x > 0 {
				sat = true
				break
			}
			if x == 0 && v == 0 {
				v = lit
			}
		}
		if !sat && v != 0 {
			pivot = v
			break
		}
	}
	if pivot == 0 {
		return false, true
	}
	*left--
	mark := len(u.trail)
	for _, v := range [2]int32{pivot, -pivot} {
		u.set(v)
		yes, done := u.search(m, cl, mark, work, left)
		u.undo(mark)
		if !yes || !done {
			return false, done
		}
	}
	return true, true
}
func (p *StudyGroundPacket) BCP(m *ast.ASTManager, decisions int) (bool, bool) {
	u := &p.Base.units
	if u.conflict {
		return true, true
	}
	if n := p.Variables + 1 - len(u.values); n > 0 {
		u.values = append(u.values, make([]int8, n)...)
	}
	n := 2*len(u.values) + 1 - len(u.links)
	if n > 0 {
		u.links = append(u.links, make([][]int32, n)...)
	}
	head := len(u.trail)
	work := 2500000
	for i := u.indexed; i < len(p.Clauses); i++ {
		if i%256 == 0 && m.ResourceLimit().CancelFlag() {
			*u = steadyUnits{}
			return false, false
		}
		r := p.Clauses[i]
		for _, v := range r {
			if v == 0 {
				break
			}
			k := literalSlot(v)
			u.links[k] = append(u.links[k], int32(i))
		}
		if v, ok := u.row(r); ok && (v == 0 || !u.set(v)) {
			u.conflict = true
			return true, true
		}
	}
	u.indexed = len(p.Clauses)
	if yes, done := u.prop(m, p.Clauses, head, &work); !done || yes {
		if !done {
			*u = steadyUnits{}
		} else {
			u.conflict = true
		}
		return yes, done
	}
	mark := len(u.trail)
	if !u.set(p.Goal) {
		return true, true
	}
	defer u.undo(mark)
	return u.search(m, p.Clauses, mark, &work, &decisions)
}

type steadyGateDef struct {
	inputs [3]int32
	flags  uint8
}

func (z *StudyGroundDB) rememberGate(v, a, b, c int32) {
	if len(z.defs) <= int(v) {
		z.defs = append(z.defs, make([]steadyGateDef, int(v)+1-len(z.defs))...)
	}
	z.defs[v].inputs = [3]int32{a, b, c}
}
func (z *StudyGroundDB) need(l int32) {
	v, sign := l, uint8(1)
	if l < 0 {
		v = -l
		sign = 2
	}
	if int(v) >= len(z.defs) {
		return
	}
	g := &z.defs[v]
	args := g.inputs
	if args[0] == 0 || g.flags&sign != 0 {
		return
	}
	g.flags |= sign
	a, b, c := args[0], args[1], args[2]
	if c == 0 {
		if sign == 1 {
			z.need(a)
			z.need(b)
			z.cnf = append(z.cnf, BooleanClause{-v, a}, BooleanClause{-v, b})
		} else {
			z.need(-a)
			z.need(-b)
			z.cnf = append(z.cnf, BooleanClause{v, -a, -b})
		}
	} else {
		z.need(a)
		z.need(-a)
		if sign == 1 {
			z.need(b)
			z.need(c)
			z.cnf = append(z.cnf, BooleanClause{-a, -v, b}, BooleanClause{a, -v, c})
		} else {
			z.need(-b)
			z.need(-c)
			z.cnf = append(z.cnf, BooleanClause{-a, v, -b}, BooleanClause{a, v, -c})
		}
	}
}
func (z *StudyGroundDB) clause(a, b, c int32) {
	if a == 1 || b == 1 || c == 1 || a != 0 && (a == -b || a == -c) || b != 0 && b == -c {
		return
	}
	var row BooleanClause
	n := 0
	for _, x := range [3]int32{a, b, c} {
		if x == 0 || x == -1 || n > 0 && row[0] == x || n > 1 && row[1] == x {
			continue
		}
		z.need(x)
		row[n] = x
		n++
	}
	z.cnf = append(z.cnf, row)
}
func (z *StudyGroundDB) guardEqual(guard int32, a, b uint32) {
	if a == b || guard == -1 {
		return
	}
	require := func(x, y int32) { z.clause(-guard, -x, y); z.clause(-guard, x, -y) }
	if z.g.terms[a].boolean {
		require(z.result[a], z.result[b])
		return
	}
	x, y := z.codes[a], z.codes[b]
	for j := 0; j < max(x.width, y.width); j++ {
		u, w := int32(-1), int32(-1)
		if j < x.width {
			u = x.start + int32(j)
		}
		if j < y.width {
			w = y.start + int32(j)
		}
		require(u, w)
	}
}

func (p *StudyGroundPacket) Indexed() bool      { return p.Base.units.indexed == len(p.Clauses) }
func (p *StudyGroundPacket) Permanent() []int32 { return p.Base.units.trail }
func (p *StudyGroundPacket) Value(l int32) int8 { return p.Base.units.value(l) }
