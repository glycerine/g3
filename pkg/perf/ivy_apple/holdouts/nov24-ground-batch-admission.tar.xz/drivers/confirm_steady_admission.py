from common import *
import stage_frontier as sf,macro_identity as mi,holdouts as ho
rd=d/'confirm-steady-admission';rd.mkdir(exist_ok=True);ho.root=rd;q=d/'steady-admission'
bs={'before':d/'release-repeat-plans/checker/goivy_check','observed12':q/'filtered-h0-d12.sh','expected48':q/'filtered-h48-d1.sh','expected64':q/'filtered-h64-d1.sh','native':native}
js=[(33,*j[1:])for j in sf.jobs()if j[1]=='tlb']+[(c,*j[1:5],j[-1])for c,j in zip([26,28,30],(j for j in mi.jobs()if j[1]in('cf_live','dramc_nb2','rfn2')))]
with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:ho.measure_spec(j,bs,5),js))
