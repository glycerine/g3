from common import *
import stage_frontier as sf,macro_identity as mi,initial_pass_schedules as ips,shlex
rd=d/'steady-equalities';rd.mkdir(exist_ok=True)
def make(v):
 src=d/'steady-admission/filtered/overlay';files=json.loads((src/'overlay.json').read_text())['Replace'];ed={Path(k):Path(val).read_text()for k,val in files.items()if Path(k).is_relative_to(pkg)or Path(k).is_relative_to(ivy.resolve())};a=pkg/'api/internal/order/steady_ground_benchmark_trial.go';s=ed[a]
 s=once(s,'type StudyGroundDB struct {','type StudyGroundDB struct {\nlinks map[uint32][]uint32\nsortTerms map[ast.ASTHandle][]uint32')
 x='z.g.compiler.work = 0';s=once(s,x,'if z.links==nil{z.links=map[uint32][]uint32{};z.sortTerms=map[ast.ASTHandle][]uint32{}}\n'+x)
 i=s.index('func (z *StudyGroundDB) eq(');j=s.index('\n}',i)+2;t=s[i:j];i1=t.index('x, y := z.codes[a], z.codes[b]');j1=t.index('\n\t}',i1)
 trans='''v=z.newVar()
 z.equal[key]=v
 small,other:=a,b;if len(z.links[small])>len(z.links[other]){small,other=other,small}
 for _,c:=range z.links[small]{x,y:=small,other;k1:=[2]uint32{min(x,c),max(x,c)};k2:=[2]uint32{min(y,c),max(y,c)}
 u,w:=z.equal[k1],z.equal[k2];if w==0{continue}
 z.clause(-u,-w,v);z.clause(-u,-v,w);z.clause(-w,-v,u)
 }
 z.links[a]=append(z.links[a],b);z.links[b]=append(z.links[b],a)'''
 if v=='sparse-only':trans='v=z.newVar()'
 t=t[:i1]+trans+t[j1:];s=s[:i]+t+s[j:]
 x='n := bits.Len(uint(z.labels[st]))';i=s.index(x);j=s.index('\n\t\t} else {',i);s=s[:i]+'_=st;'+s[j:];s=s.replace('"math/bits"','')
 i=s.index('x, y := z.codes[a], z.codes[b]',s.index('func (z *StudyGroundDB) guardEqual'));j=s.index('\n}',i);s=s[:i]+'z.clause(-guard,z.eq(a,b),0)'+s[j:]
 if v.startswith('complete'):
  c=v.removeprefix('complete');x='z.codes = append(z.codes, code)';s=once(s,x,x+'\nif !t.boolean{st:=z.sorts[t.symbol];prev:=z.sortTerms[st];if len(prev)<'+c+'{for _,o:=range prev{z.eq(o,i)};z.sortTerms[st]=append(prev,i)}}')
 ed[a]=s;sd=rd/v;b=build(sd/'checker',o=overlay(sd/'overlay',ed));(sd/'build-info.txt').write_text(linked(b));return b
def main():
 versions=['sparse','complete8','complete16','complete32','sparse-only']
 with ThreadPoolExecutor(2)as e:built=dict(zip(versions,e.map(make,versions)))
 vs={'before':d/'release-repeat-plans/checker/goivy_check','bits':d/'steady-admission/filtered-h64-d1.sh','native':native}
 for v,b in built.items():
  for cg in [4,16,32]:
   n=f'{v}-c{cg}';f=rd/(n+'.sh');f.write_text('#!/bin/sh\nG3_STEADY_ENGINE=sat G3_STEADY_FILTER=residual G3_STEADY_HINT=48 G3_STEADY_WHEN=middle G3_STEADY_MIN=192 G3_STEADY_REPEAT=1 G3_STEADY_CONGRUENCE='+str(cg)+' exec '+shlex.quote(str(b))+' "$@"\n');f.chmod(0o700);vs[n]=f
 ips.root=rd;js=[j for j in sf.jobs()if j[1]in('tlb','arm_rules3','hermes_rmw_o3','ticket_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([4,6],(j for j in mi.jobs()if j[1]in('cf_live','rfn2')))];js=[(29,*j[1:])if j[1]=='tlb'else j for j in js]
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:ips.lane(j,vs,2),js))
if __name__=='__main__':main()
