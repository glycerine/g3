from common import *
import timed_policy as tp,stage_frontier as sf
tp.root=d/'quiet-sparse-projections';tp.root.mkdir(exist_ok=True);tp.bins={'independent':d/'steady-equalities/sparse-only-c16.sh','ordinal':d/'steady-admission/filtered-h48-d1.sh','native':native}
j=next(j for j in sf.jobs()if j[1]=='tlb');tp.lane(j[1:])
