from common import *
import steady_ground_search as ss,initial_verified_schedule as iv,stage_frontier as sf,macro_identity as mi,initial_pass_schedules as ips,holdouts as ho,shlex
rd=d/'steady-placement';rd.mkdir(exist_ok=True)
def make(initial):
 sd=rd/initial;od=ss.rd/'overlay';a=pkg/'api/api_order_abstraction.go';gs=pkg/'api/internal/order/steady_ground_benchmark_trial.go';api=pkg/'api/steady_search_benchmark_trial.go'
 ed={q:(od/q.name).read_text()for q in [a,gs,api]}
 s=ed[a];x='if !proved && err == nil && steadyBackend != "" && goal.IsNull() && p.plans.reusable(parent) && !limit.CancelFlag() {'
 s=once(s,x,'''if !proved&&err==nil&&steadyBackend!=""&&(steadyPlacement=="last"||steadyPlacement=="late"&&goal.IsNull())&&p.plans.reusable(parent)&&!limit.CancelFlag(){''')
 x='if consistent && original {';s=once(s,x,'''if steadyBackend!=""&&reuse&&consistent&&original&&p.plans.reusable(parent)&&(steadyPlacement=="middle"||steadyPlacement=="middle-after"&&!combined.CanDeferFirstPush()){
 if yes,e:=p.steadySearch.prove(s,parent,assertions);e!=nil||yes||limit.CancelFlag(){return yes,e}
 }
 '''+x)
 x='proved, err = p.proveAssertions(parent, assertions, maxSteps, reuse)';s=once(s,x,'''if steadyPlacement=="ready"&&steadyBackend!=""&&reuse&&p.steadySearch.sat.solver!=nil&&p.plans.reusable(parent){
 if yes,e:=p.steadySearch.prove(s,parent,assertions);e!=nil||yes||limit.CancelFlag(){return yes,e}}
 '''+x);x='if consistent && original {';s=once(s,x,'''if steadyPlacement=="ready"&&steadyBackend!=""&&reuse&&p.steadySearch.sat.solver==nil&&original&&consistent&&p.plans.reusable(parent){
 if yes,e:=p.steadySearch.prove(s,parent,assertions);e!=nil||yes||limit.CancelFlag(){return yes,e}}
 '''+x)
 ed[a]=s;ed[api]+='\nvar steadyPlacement=os.Getenv("G3_STEADY_WHEN")\n'
 if initial!='ordinary':ed.update(iv.changes(initial))
 b=build(sd/'checker',o=overlay(sd/'overlay',ed));(sd/'build-info.txt').write_text(linked(b));return b
def main():
 with ThreadPoolExecutor(2)as ex:bsrc=dict(zip(['ordinary','raw+n0'],ex.map(make,['ordinary','raw+n0'])))
 vs={'before':d/'release-repeat-plans/checker/goivy_check','native':native}
 for v in ['ordinary','raw+n0']:
  for p,rep,cg,mn in [('late',2,16,192),('last',1,16,64),('middle',1,16,64),('middle-after',2,16,192),('ready',1,16,192),('middle',1,48,32),('middle',2,4,192),('middle',1,16,192),('middle',1,16,384)]:
   if v=='raw+n0'and (p,cg,mn)not in[('middle',16,64),('last',16,64),('late',16,192),('middle',16,192)]:continue
   n=f'{v}-{p}-{rep}-{cg}-{mn}';f=rd/(n+'.sh');f.write_text('#!/bin/sh\nG3_STEADY_ENGINE=sat G3_STEADY_REPEAT='+str(rep)+' G3_STEADY_MIN='+str(mn)+' G3_STEADY_CONGRUENCE='+str(cg)+' G3_STEADY_WHEN='+p+' exec '+shlex.quote(str(bsrc[v]))+' "$@"\n');f.chmod(0o700);vs[n]=f
 ips.root=rd
 js=[j for j in sf.jobs()if j[1]in('tlb','arm_rules3','hybrid','flash2','ticket_protocol','hermes_rmw_o3','alternating_bit_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([4,6,8,10,12],(j for j in mi.jobs()if j[1]in('cf_live','rfn2','dramc_nb2','toy-consensus','raftok')))]
 js=[(35,*j[1:])if j[1]=='tlb'else j for j in js]
 with ThreadPoolExecutor(6)as ex:list(ex.map(lambda j:ips.lane(j,vs,2),js))
if __name__=='__main__':main()
