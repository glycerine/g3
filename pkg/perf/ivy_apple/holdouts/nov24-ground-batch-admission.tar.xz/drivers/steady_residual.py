from common import *
import stage_frontier as sf,macro_identity as mi,initial_pass_schedules as ips,initial_verified_schedule as iv,shlex
rd=d/'steady-residual';rd.mkdir(exist_ok=True)
def make(v):
 init='raw'in v;direct='direct'in v;lazy='lazy'in v
 sd=rd/v;a=pkg/'api/api_order_abstraction.go';q=pkg/'api/internal/order/steady_ground_benchmark_trial.go';b=pkg/'api/steady_search_benchmark_trial.go'
 where=d/('steady-sparse-ground/'+('lazy-direct'if direct and lazy else'direct'if direct else'lazy')if direct or lazy else'steady-placement/ordinary')/'overlay'
 ed={p:(where/p.name).read_text()for p in [a,q,b]};s=ed[b];s+='\nvar steadyFilter=os.Getenv("G3_STEADY_FILTER")\n'
 s=once(s,'type studySteadySearch struct {','type studySteadySearch struct {\nsync int\nprojectionIDs []uint32')
 s=once(s,'s.rows = 0','s.rows=0;s.sync=0;s.projectionIDs=nil');x='if steadyBackend != "sat" {';s=once(s,x,(d/'steady_residual.tpl').read_text()+x)
 ed[b]=s;ed[q]+='''\nfunc(p *StudyGroundPacket)Indexed()bool{return p.Base.units.indexed==len(p.Clauses)}
func(p *StudyGroundPacket)Permanent()[]int32{return p.Base.units.trail}
func(p *StudyGroundPacket)Value(l int32)int8{return p.Base.units.value(l)}\n'''
 if init:ed.update(iv.changes('raw+n0'))
 bb=build(sd/'checker',o=overlay(sd/'overlay',ed));(sd/'build-info.txt').write_text(linked(bb));return bb
def main():
 vs=['dense','direct','lazy-direct','raw-lazy-direct','raw-dense']
 with ThreadPoolExecutor(3)as e:bsrc=dict(zip(vs,e.map(make,vs)))
 bs={'before':d/'release-repeat-plans/checker/goivy_check','native':native}
 for v,b in bsrc.items():
  for loc,rep,cg,mn in [('late',2,16,192),('middle-after',1,16,192),('middle',1,16,192),('middle',2,32,192)]:
   n=f'{v}-{loc}-{rep}-{cg}';f=rd/(n+'.sh');f.write_text('#!/bin/sh\nG3_STEADY_ENGINE=sat G3_STEADY_FILTER=residual G3_STEADY_REPEAT='+str(rep)+' G3_STEADY_CONGRUENCE='+str(cg)+' G3_STEADY_MIN='+str(mn)+' G3_STEADY_WHEN='+loc+' exec '+shlex.quote(str(b))+' "$@"\n');f.chmod(0o700);bs[n]=f
 ips.root=rd;js=[j for j in sf.jobs()if j[1]in('tlb','arm_rules3','hybrid','ticket_protocol','hermes_rmw_o3')]+[(c,*j[1:5],j[-1])for c,j in zip([4,6,8,10],(j for j in mi.jobs()if j[1]in('cf_live','rfn2','dramc_nb2','raftok')))];js=[(39,*j[1:])if j[1]=='tlb'else j for j in js]
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:ips.lane(j,bs,2),js))
if __name__=='__main__':main()
