from common import *
import timed_policy as tp, stage_frontier as sf
tp.root=d/'quiet-guarded-projections';tp.root.mkdir(exist_ok=True);tp.bins={'before':d/'release-repeat-plans/checker/goivy_check','complete8':d/'steady-equalities/complete8-c16.sh','ordinal':d/'steady-admission/filtered-h48-d1.sh','native':native}
j=next(j for j in sf.jobs()if j[1]=='tlb');tp.lane(j[1:])
