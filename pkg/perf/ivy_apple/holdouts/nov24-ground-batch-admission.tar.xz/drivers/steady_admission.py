from common import *
import stage_frontier as sf,macro_identity as mi,initial_pass_schedules as ips,shlex
rd=d/'steady-admission';rd.mkdir(exist_ok=True)
def make(v,filtering):
 sd=rd/v;a=pkg/'api/api_order_abstraction.go';q=pkg/'api/internal/order/steady_ground_benchmark_trial.go';b=pkg/'api/steady_search_benchmark_trial.go';smt=ivy.resolve()/'smt/g3_solver.go';bridge=ivy.resolve()/'z3bridge_solver_model.go'
 src=d/('steady-residual/lazy-direct'if filtering else'steady-sparse-ground/lazy-direct')/'overlay'
 ed={p:(src/p.name).read_text()for p in [a,q,b]};s=ed[a];s=once(s,'previousGoalProved bool','steadyExpected,steadyObserved int\npreviousGoalProved bool') if 'previousGoalProved bool' in s else re.sub(r'(previousGoalProved\s+bool)',r'steadyExpected,steadyObserved int\n\1',s,count=1)
 x='func (p *orderProofState) proveWithGoal(';i=s.index('{',s.index(x))+1;s=s[:i]+'''\np.steadyObserved++
'''+s[i:]
 x='p.plans.reusable(parent)';s=s.replace(x,'p.plans.reusable(parent) && p.studyAmortized()')
 s+='''\nfunc(b *OrderProofBatch)StudyExpectedGoals(n int){b.state.steadyExpected=n}
func(p *orderProofState)studyAmortized()bool{return p.steadyExpected>=steadyHint && p.steadyObserved>=steadyDelay}\n'''
 ed[a]=s;ed[b]+='''\nvar steadyHint=func()int{v,_:=strconv.Atoi(os.Getenv("G3_STEADY_HINT"));return v}()
var steadyDelay=func()int{v,_:=strconv.Atoi(os.Getenv("G3_STEADY_DELAY"));return v}()\n'''
 u=smt.read_text();x='func (s *Z3Solver) BeginVerificationGoalChecks()';u=once(u,x,'func (s *Z3Solver) BeginVerificationGoalChecks(steadyGoalCount ...int)');i=u.index('batch := s.c.BeginOrderProofBatch()',u.index('func (s *Z3Solver) BeginVerificationGoalChecks'));j=u.index('\n',i);u=u[:j]+'\nif len(steadyGoalCount)>0{batch.StudyExpectedGoals(steadyGoalCount[0])}'+u[j:];ed[smt]=u
 ed[bridge]=once(bridge.read_text(),'z3solver.BeginVerificationGoalChecks()','z3solver.BeginVerificationGoalChecks(len(finalCond))')
 bb=build(sd/'checker',o=overlay(sd/'overlay',ed));(sd/'build-info.txt').write_text(linked(bb));return bb
def main():
 with ThreadPoolExecutor(2)as ex:bsrc=dict(zip(['direct','filtered'],ex.map(lambda v:make(v,v=='filtered'),['direct','filtered'])))
 vs={'before':d/'release-repeat-plans/checker/goivy_check','native':native}
 for variant,b in bsrc.items():
  for hint,delay in [(0,4),(0,12),(0,32),(0,48),(32,1),(48,1),(64,1),(96,1),(128,1),(64,4)]:
   n=f'{variant}-h{hint}-d{delay}';f=rd/(n+'.sh');f.write_text('#!/bin/sh\nG3_STEADY_ENGINE=sat G3_STEADY_WHEN=middle G3_STEADY_MIN=192 G3_STEADY_REPEAT=1 G3_STEADY_CONGRUENCE=16 G3_STEADY_FILTER='+('residual'if variant=='filtered'else'')+' G3_STEADY_HINT='+str(hint)+' G3_STEADY_DELAY='+str(delay)+' exec '+shlex.quote(str(b))+' "$@"\n');f.chmod(0o700);vs[n]=f
 ips.root=rd;js=[j for j in sf.jobs()if j[1]in('tlb','arm_rules3','hybrid','alternating_bit_protocol','hermes_rmw_o3','ticket_protocol')]+[(c,*j[1:5],j[-1])for c,j in zip([2,4,6,8,10],(j for j in mi.jobs()if j[1]in('cf_live','rfn2','dramc_nb2','toy-consensus','raftok')))];js=[(36,*j[1:])if j[1]=='tlb'else j for j in js]
 with ThreadPoolExecutor(4)as ex:list(ex.map(lambda j:ips.lane(j,vs,2),js))
if __name__=='__main__':main()
