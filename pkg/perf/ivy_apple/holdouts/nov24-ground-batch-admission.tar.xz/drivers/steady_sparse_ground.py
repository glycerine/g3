from common import *
import stage_frontier as sf,macro_identity as mi,initial_pass_schedules as ips,shlex
rd=d/'steady-sparse-ground';rd.mkdir(exist_ok=True)
def make(v):
 sd=rd/v;a=pkg/'api/api_order_abstraction.go';q=pkg/'api/internal/order/steady_ground_benchmark_trial.go';b=pkg/'api/steady_search_benchmark_trial.go'
 where=d/'steady-placement/ordinary/overlay';ed={p:(where/p.name).read_text()for p in [a,q,b]};s=ed[q]
 x='type StudyGroundDB struct {';s=once(s,x,x+'\ndefs []steadyGateDef')
 s+=(d/'steady_lazy_gates.go.txt').read_text()
 if 'lazy'in v:
  x='z.cnf = append(z.cnf, BooleanClause{-v, a}, BooleanClause{-v, b}, BooleanClause{v, -a, -b})';s=once(s,x,'z.rememberGate(v,a,b,0)')
  x='z.cnf = append(z.cnf, BooleanClause{-c, -v, a}, BooleanClause{-c, v, -a}, BooleanClause{c, -v, b}, BooleanClause{c, v, -b})';s=once(s,x,'z.rememberGate(v,c,a,b)')
  x='z.cnf = append(z.cnf, BooleanClause{v})';s=once(s,x,'z.need(v);'+x)
  x='return &StudyGroundPacket{';s=once(s,x,'z.need(z.result[v]);'+x)
 if 'direct'in v:
  s=once(s,'z.assert(-z.and(vs[a[0]], -z.eq(i, a[1])))','z.guardEqual(vs[a[0]],i,a[1])')
  s=once(s,'z.assert(-z.and(-vs[a[0]], -z.eq(i, a[2])))','z.guardEqual(-vs[a[0]],i,a[2])')
  s=once(s,'z.assert(-z.and(same, -z.eq(i, o)))','z.guardEqual(same,i,o)')
 ed[q]=s;bb=build(sd/'checker',o=overlay(sd/'overlay',ed));(sd/'build-info.txt').write_text(linked(bb));return bb
def main():
 vs=['direct','lazy','lazy-direct']
 with ThreadPoolExecutor(3)as e:bsrc=dict(zip(vs,e.map(make,vs)))
 ps=d/'steady-placement';bs={'before':d/'release-repeat-plans/checker/goivy_check','dense':ps/'ordinary-late-2-16-192.sh','native':native}
 for v,b in bsrc.items():
  for loc,rep,cg,mn in [('late',2,16,192),('middle',1,16,192),('middle',1,48,64),('middle',1,4,64)]:
   n=f'{v}-{loc}-{rep}-{cg}-{mn}';f=rd/(n+'.sh');f.write_text('#!/bin/sh\nG3_STEADY_ENGINE=sat G3_STEADY_REPEAT='+str(rep)+' G3_STEADY_CONGRUENCE='+str(cg)+' G3_STEADY_MIN='+str(mn)+' G3_STEADY_WHEN='+loc+' exec '+shlex.quote(str(b))+' "$@"\n');f.chmod(0o700);bs[n]=f
 ips.root=rd;js=[j for j in sf.jobs()if j[1]in('tlb','arm_rules3','hybrid','ticket_protocol','hermes_rmw_o3')]+[(c,*j[1:5],j[-1])for c,j in zip([4,6,8],(j for j in mi.jobs()if j[1]in('cf_live','rfn2','raftok')))];js=[(37,*j[1:])if j[1]=='tlb'else j for j in js]
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:ips.lane(j,bs,2),js))
if __name__=='__main__':main()
