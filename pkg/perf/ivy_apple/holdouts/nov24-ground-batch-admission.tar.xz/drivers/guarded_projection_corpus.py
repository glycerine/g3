from common import *
import ground_release_controls as gr
gr.d=d/'guarded-projection-corpus';gr.d.mkdir(exist_ok=True);gr.corpus(d/'steady-admission/filtered-h48-d1.sh')
