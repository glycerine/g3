from common import *
import filecmp
rd=d/'large-batch-census';rd.mkdir(exist_ok=True)
def main():
 bridge=ivy.resolve()/'z3bridge_solver_model.go';s=bridge.read_text();a=s.index('func (s *Solver) GetSmallModelWithCond(');b=s.index('// No final conditions:',a);part=s[a:b]
 x='if finalCond != nil {';part=once(part,x,x+'\nfmt.Fprintln(os.Stderr,"EXPECTED-GOALS",len(finalCond))');s=s[:a]+part+s[b:];s=once(s,'import (','import("os";')if '"os"'not in s else s
 binary=build(rd/'checker',o=overlay(rd/'overlay',{bridge:s}));(rd/'build-info.txt').write_text(linked(binary));ref=w/'relation-selection-release/corpus'
 rows=sorted((r for f in ref.glob('cpu-*.csv')for r in readcsv(f)if r['engine']=='reference'),key=lambda r:int(r['index']));assert len(rows)==228
 def one(j):
  c,ls=j
  with(rd/f'cpu-{c}.csv').open('w')as f:
   z=csv.writer(f);z.writerow('case spec exit stdout stderr batch_lengths'.split())
   for r in ls:
    i=int(r['index']);sp=r['spec'];od=rd/str(i);od.mkdir();rf=ref/str(i)/'g3'
    p=subprocess.run(['taskset','-c',str(c),binary,examples/sp],cwd=od,env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True,timeout=1200);e=bytearray();batches=[]
    for l in p.stderr.splitlines(keepends=True):
     if l.startswith(b'EXPECTED-GOALS '):batches.append(int(l.split()[1]))
     else:e.extend(l)
    ok1=p.stdout==(rf/'stdout').read_bytes();ok2=e==(rf/'stderr').read_bytes();z.writerow([i,sp,p.returncode,int(ok1),int(ok2),' '.join(map(str,batches))]);f.flush();assert p.returncode==int(r['exit'])and ok1 and ok2,(sp,p.returncode,e[-150:])
 with ThreadPoolExecutor(4)as e:list(e.map(one,[(c,rows[k::4])for k,c in enumerate([0,14,18,30])]))
if __name__=='__main__':main()
