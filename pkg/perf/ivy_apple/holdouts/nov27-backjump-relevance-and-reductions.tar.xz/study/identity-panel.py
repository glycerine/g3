"""Compare combined family/kind lookup on complete reference workloads."""
from pathlib import Path
import tarfile
p=Path(__file__).resolve().parent
src=(p/'identity.py').read_text()
src=src[:src.rindex('exec(compile')]
exec(compile(src,'identity-source','exec'))
patch=s[s.index("        for name in ['ast/"):s.index("        j=d/'overlay.json'")]
patch=patch.replace('        for name in','    for fname in',1).replace('            p=pkg/name','        p=pkg/fname').replace("'e26261bce:pkg/'+name","'e26261bce:pkg/'+fname").replace('mode==\'identity\'','name==\'trial\'').replace('name.endswith','fname.endswith')
patch='\n'.join(line[4:] if len(line)-len(line.lstrip())>=12 else line for line in patch.splitlines())
patch=patch.replace('put(p,src)',"path=d/(name+p.name);path.write_text(src);mp[str(p)]=str(path)")
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as arc:
    driver=arc.extractfile('study/panel.py').read().decode()
a=driver.index("    if name=='trial':");b=driver.index("    j=d/",a)
driver=driver[:a]+patch+'\n'+driver[b:]
exec(compile(driver,'identity-panel','exec'))
