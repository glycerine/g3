"""Separate final and surviving reference decrements during watch undo."""
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'phase.py').read_text()
anchor='            put(p,s)'
extra='''            anchor='consumed, err := p.context.manager.DecRefHeldConsumed(entry.expression)'
            addition="""fd:=popCounter();phase:=3
            if fd>=0{
                if entry.kind==smtRelevancyRefTrail {phase+=2}
                count,err:=p.context.manager.GetRefCount(entry.expression);if err!=nil{panic(err)}
                if count==1 {phase++}
            }
            a:=popRead(fd);b:=popRead(fd)
            """
            s=edit(s,anchor,addition+anchor+';popTotal(fd,phase,1,a,b)')
'''
s=s.replace(anchor,extra+anchor)
anchor='            src=d/p.name;src.write_text(s)'
s=s.replace(anchor,'''            anchor='                m.dec_ref(n);'
            pos=s.index('void undo_trail(unsigned old_lim)')
            end=s.index('void set_relevant(',pos)
            block=s[pos:end]
            block=edit(block,anchor,'int fd=counter();auto phase=n->get_ref_count()==1?4:3;auto a=snap(fd),b=snap(fd);'+anchor+'if(fd>=0){auto v=snap(fd);fprintf(stderr,"POP-PHASE %d 1 %lld\\\\n",phase,v-2*b+a);}')
            s=s[:pos]+block+s[end:]
'''+anchor)
s=s.replace('len(totals)==12','len(totals)>=16').replace("'phase.csv'","'owners.csv'")
exec(compile(s,'owners','exec'))
