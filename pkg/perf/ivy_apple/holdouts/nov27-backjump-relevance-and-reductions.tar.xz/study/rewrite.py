"""Partition sampled instance rewriting by the closest operation on its stack."""
import csv,collections
from pathlib import Path
d=Path(__file__).resolve().parent
rounds=collections.defaultdict(set)
groups=collections.Counter()
for x in csv.DictReader((d/'stacks.csv').open()):
    key=x['batch'],x['goal'],x['engine']
    rounds[key].add(x['round'])
    frames=x['stack'].splitlines()
    if x['engine']=='g3':
        if not any('SMTQIInstanceBuilder).materialize' in f for f in frames):continue
        rewrite='rewriterEngine).rewrite'
        phases=[('reduceAppCore','theory reduction'),('constantFold','constant fold'),('getCached','cache lookup'),('ActivityCache).Insert','cache insertion'),('processApp','process application'),('rewriterEngine).visit','visit')]
    else:
        if not any('qi_queue::instantiate(smt::qi_queue::entry&)' in f for f in frames):continue
        rewrite='rewriter_tpl<th_rewriter_cfg>'
        phases=[('th_rewriter_cfg::reduce_app','theory reduction'),('>::constant_fold','constant fold'),('act_cache::find','cache lookup'),('act_cache::insert','cache insertion'),('>::process_app','process application'),('>::visit','visit')]
    if not any(rewrite in f for f in frames):continue
    op=next((label for f in frames for pat,label in phases if pat in f),'other')
    groups[key,op]+=int(x['period'])*int(x['samples'])
with (d/'rewrite.csv').open('w') as out:
    w=csv.writer(out);w.writerow(['batch','goal','engine','closest_frame','mean_sampled_instructions'])
    for (key,phase),total in sorted(groups.items()):
        w.writerow([*key,phase,round(total/len(rounds[key]))])
