"""Compare a freelist, LIFO pages, and a LIFO slice for relevance registrations."""
from pathlib import Path
import tarfile
def variant(s,mode):
    if mode=='base':return s
    a=s.index('\tindex := t.free');b=s.index('\tif !t.dense(h)',a)
    if mode=='pages':
        s=s.replace('count, free uint32','count uint32')
        a=s.index('\tindex := t.free');b=s.index('\tif !t.dense(h)',a)
        add='''	if int(t.count/smtRelevancyPageSize)==len(t.pages) {
            t.pages=append(t.pages,new([smtRelevancyPageSize]smtRelevancyLink))
        }
        t.count++
        index:=t.count
        *t.link(index)=smtRelevancyLink{handler:handler, previous:previous, generation:h.Generation()}
'''
        pop='cell:=t.link(t.count); t.count--'
    else:
        add='''	t.links=append(t.links,smtRelevancyLink{handler:handler,previous:previous,generation:h.Generation()})
        index:=uint32(len(t.links))
'''
        pop='i:=len(t.links)-1; cell:= &t.links[i]; t.links=t.links[:i]'
    s=s[:a]+add+s[b:]
    a=s.index('\tindex := t.head(h)',s.index('func (t *smtRelevancyTable) pop('));b=s.index('\n\thandler :=',a)
    s=s[:a]+'\t'+pop+s[b:]
    s=s.replace('\t*cell = smtRelevancyLink{previous: t.free}\n\tt.free = index\n','')
    if mode=='slice':
        a=s.index('\tpages ');b=s.index('\n}',a)
        s=s[:a]+'\tlinks []smtRelevancyLink'+s[b:]
        s=s.replace('i := index - 1\n\treturn &t.pages[i/smtRelevancyPageSize][i%smtRelevancyPageSize]','return &t.links[index-1]')
    return s
if __name__=='__main__':
    with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as arc:
        s=arc.extractfile('study/notify-trials.py').read().decode()
    a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
    s=s[:a]+"""    modes=['base','pages','slice']
    for mode in modes:
        p=pkg/'smtcore/smt_relevancy_table.go'
        put(p,variant(sp.check_output(['git','show','e26261bce:pkg/smtcore/smt_relevancy_table.go']).decode(),mode))
"""+s[b:]
    s=s.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'notification.csv'","'links.csv'")
    exec(compile(s,'links','exec'))
