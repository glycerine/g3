"""Price three disjoint relevance-pop intervals in complete automatic Ticket history."""
import csv, json, os, re, shlex, shutil, statistics, subprocess as sp, tarfile, tempfile
from collections import defaultdict
from pathlib import Path

pkg=Path.cwd()
here=Path(__file__).resolve().parent
front=Path(os.environ['GOIVY_FRONTEND']).resolve()
ref=Path(os.environ['NNF_REFERENCE'])
ex=Path(os.environ['IVY_EXAMPLES'])
def archived(file,member):
    with tarfile.open(pkg/'perf/ivy_apple/holdouts'/file) as archive:
        return archive.extractfile(member).read().decode()
def edit(s, match, replacement):
    assert s.count(match)==1,match
    return s.replace(match,replacement)

with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp)
    for eng in ['g3','z3']:
        native=eng=='z3'
        overlay={}
        def put(k,s):
            path=d/(eng+k.name)
            path.write_text(s)
            overlay[str(k)]=str(path)
        for name,member in [('z3bridge_solver_model.go','stage-bridge.go.txt'),('z3bridge_guarded_equalities.go','guards.go.txt')]:
            body=archived('nov27-unary-demand-and-fresh-symbols.tar.xz','study/sources/native-'+name+'.txt') if native else archived('nov27-terminal-conflict-replay.tar.xz','study/'+member)
            if name.startswith('z3bridge_solver'):
                body=edit(body,'stopCheck:=startStage(batch,index+1);','capturePush=((batch==12||batch==13||batch==14)&&index==7)||(batch==16&&index==0);stopCheck:=startStage(batch,index+1);')
                body=edit(body,'stopCheck("check")','stopCheck("check");capturePush=false')
            put(front/name,body)
        timer=archived('nov27-first-push-queue-comparison.tar.xz','check-g3-phase_observer_trial.go')
        timer=edit(timer,'runtime.LockOSThread()','if !capturePush{return func(string){}};runtime.LockOSThread()')
        put(front/'phase_observer_trial.go',timer)
        if not native:
            p=pkg/'smtcore/smt_relevancy.go'
            s=edit(p.read_text(),'import (','import (\n"os"\n"strconv"\n"unsafe"\n"syscall"')
            s+='''
func popCounter()int{n,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));if e!=nil{return -1};return n}
func popRead(fd int)int64{if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if e!=0||n!=24{panic("counter")};return int64(c[0])}
func popTotal(fd,phase,count int,a,b int64){if fd>=0{v:=popRead(fd);println("POP-PHASE",phase,count,v-2*b+a)}}
'''
            anchor='for i := len(p.relevant); i > p.scopes[level].relevantLimit; i-- {'
            s=edit(s,anchor,'fd:=popCounter();a:=popRead(fd);b:=popRead(fd);'+anchor)
            s=edit(s,'p.traceUnmark(h)\n\t\t\t}', 'p.traceUnmark(h)\n\t\t\t};popTotal(fd,0,len(p.relevant)-p.scopes[level].relevantLimit,a,b)')
            anchor='p.relevant, err = p.context.manager.ShrinkHeldRefs(p.relevant, scope.relevantLimit)'
            s=edit(s,anchor,'fd:=popCounter();cnt:=len(p.relevant)-scope.relevantLimit;a:=popRead(fd);b:=popRead(fd);'+anchor+';popTotal(fd,1,cnt,a,b)')
            anchor='if err := p.undoTrail(scope.trailLimit); err != nil {'
            s=edit(s,anchor,'cnt=len(p.trail)-scope.trailLimit;a=popRead(fd);b=popRead(fd);err=p.undoTrail(scope.trailLimit);popTotal(fd,2,cnt,a,b);if err != nil {')
            put(p,s)
        else:
            build=pkg.parent/'build'
            flags=dict(line.split('=',1) for line in (build/'config.mk').read_text().splitlines() if '=' in line)
            includes=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
            p=pkg.parent/'src/smt/smt_relevancy.cpp'
            s='#include <cstdlib>\n#include <unistd.h>\nstatic long long snap(int fd){if(fd<0)return 0;unsigned long long c[3];if(read(fd,c,24)!=24)__builtin_trap();return c[0];}\nstatic int counter(){auto s=getenv("QI_COUNTER_FD");return s?atoi(s):-1;}\n'+p.read_text()
            anchor='unsigned i = m_relevant_exprs.size();'
            pos=s.index('void unmark_relevant_exprs(unsigned old_lim)')
            s=s[:pos]+s[pos:].replace(anchor,anchor+'int fd=counter();auto count=i-old_lim;auto a=snap(fd),b=snap(fd);',1)
            anchor='m_relevant_exprs.shrink(old_lim);'
            s=edit(s,anchor,'if(fd>=0){auto v=snap(fd);fprintf(stderr,"POP-PHASE 0 %u %lld\\n",count,v-2*b+a);}a=snap(fd);b=snap(fd);'+anchor+'if(fd>=0){auto v=snap(fd);fprintf(stderr,"POP-PHASE 1 %u %lld\\n",count,v-2*b+a);}')
            anchor='undo_trail(s.m_trail_lim);'
            s=edit(s,anchor,'int fd=counter();auto count=m_trail.size()-s.m_trail_lim;auto a=snap(fd),b=snap(fd);'+anchor+'if(fd>=0){auto v=snap(fd);fprintf(stderr,"POP-PHASE 2 %u %lld\\n",count,v-2*b+a);}')
            src=d/p.name;src.write_text(s)
            obj=d/'smt_relevancy.o'
            sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-o',obj,src],cwd=build,check=True)
            lib=d/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);sp.run(['ar','r',lib,obj],check=True)
            k=front/'smt/quantifier.go';put(k,edit(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
        ov=d/(eng+'.json');ov.write_text(json.dumps({'Replace':overlay}))
        sp.run(['go','build','-buildvcs=false','-pgo='+('off' if native else str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-mod=readonly','-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-tags','xtrace_off,classic_z3' if native else 'xtrace_off','-overlay',ov,'-o',d/eng,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=os.environ['TRIAL_CACHE']),check=True)
    spec=(ref/'compat.txt').read_text().splitlines()[7]
    gold=ref/'compat/8/1/native'
    expected=next(int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open()) if r['case']==spec)
    with (here/'phase.csv').open('w') as f:
        wr=csv.writer(f);wr.writerow('round engine batch goal phase calls entries instructions'.split())
        for i in range(5):
            for eng in ['g3','z3'][::1 if i%2==0 else -1]:
                result=sp.run(['taskset','-c',os.environ['CPU'],d/eng,ex/spec],cwd=d,capture_output=True,timeout=120,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
                ordinary=[];key=None;seen=set();totals=defaultdict(lambda:[0,0,0])
                for ln in result.stderr.splitlines(keepends=True):
                    words=ln.split()
                    if ln.startswith(b'OPEN '):
                        assert key is None
                        key=tuple(map(int,words[1:3]));seen.add(key)
                    elif ln.startswith(b'POP-PHASE '):
                        assert key is not None
                        phase,n,v=map(int,words[1:]);a=totals[key+(phase,)];a[0]+=1;a[1]+=n;a[2]+=v
                    elif ln.startswith(b'STAGE-COUNT '):
                        assert tuple(map(int,words[1:3]))==key and words[6]==words[7];key=None
                    else:ordinary.append(ln)
                assert seen=={(12,8),(13,8),(14,8),(16,1)} and len(totals)==12,(eng,seen,totals)
                assert (result.returncode,result.stdout,b''.join(ordinary))==(expected,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(eng,result.stderr[-1000:])
                for k,v in sorted(totals.items()):wr.writerow([i,eng,*k,*v])
                f.flush()
