"""Compare cost and outcome per operator in the queue's ordinary instance rewriter."""
from pathlib import Path
here=Path(__file__).resolve().parent
s=(here/'phase.py').read_text()
a=s.index('        if not native:');b=s.index("        ov=d/",a)
s=s[:a]+'''        if not native:
            k=pkg/'smtcore/smt_qi_instance.go'
            src=edit(k.read_text(),'import (','import (\\n"os"')
            needle='if err = rw.Rewrite(instance, simplified); err != nil {'
            src=edit(src,needle,'rewriter.StudyActive=os.Getenv("QI_COUNTER_FD")!="";err=rw.Rewrite(instance,simplified);rewriter.StudyActive=false;if err!=nil{')
            put(k,src)
            k=pkg/'ast/rewriter/th_rewriter.go'
            src=edit(k.read_text(),'import (','import (\\n"os"\\n"syscall"\\n"unsafe"\\n"strconv"')
            src+="""
var StudyActive bool
func reduceStudyRead(fd uintptr) int64{var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,fd,uintptr(unsafe.Pointer(&v)),24);if e!=0||n!=24{panic("counter")};return int64(v[0])}
"""
            needle='status, err := c.reduceAppCore(decl, args, out)'
            src=edit(src,needle,"""var fd uintptr;var a,b int64
            if StudyActive{n,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));if e!=nil{panic(e)};fd=uintptr(n);a=reduceStudyRead(fd);b=reduceStudyRead(fd)}
            """+needle+"""
            if StudyActive{v:=reduceStudyRead(fd);family,e:=c.owner.manager.GetFamilyID(decl);if e!=nil{panic(e)};kind,e:=c.owner.manager.GetDeclKind(decl);if e!=nil{panic(e)};println("REDUCE",int32(family),int32(kind),args.Count(),int(status),v-2*b+a)}
""")
            put(k,src)
        else:
            build=pkg.parent/'build'
            flags=dict(line.split('=',1) for line in (build/'config.mk').read_text().splitlines() if '=' in line)
            make=(build/'Makefile').read_text()
            lib=d/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
            for rel,inc in [('smt/qi_queue.cpp',39),('ast/rewriter/th_rewriter.cpp',12)]:
                k=pkg.parent/'src'/rel
                src=k.read_text()
                if inc==39:
                    src='#include <cstdlib>\\nthread_local int study_reduce_fd=-1;\\n'+src
                    needle='m_context.get_rewriter()(instance, s_instance, pr);'
                    src=edit(src,needle,'auto fdstr=getenv("QI_COUNTER_FD");study_reduce_fd=fdstr?atoi(fdstr):-1;'+needle+'study_reduce_fd=-1;')
                else:
                    src='#include <unistd.h>\\nextern thread_local int study_reduce_fd;\\nstatic long long snap(int fd){unsigned long long c[3];if(read(fd,c,24)!=24)__builtin_trap();return c[0];}\\n'+src
                    needle='br_status st = reduce_app_core(f, num, args, result);'
                    src=edit(src,needle,'long long a=0,b=0;int fd=study_reduce_fd;if(fd>=0){a=snap(fd);b=snap(fd);}'+needle+'if(fd>=0){auto v=snap(fd);fprintf(stderr,"REDUCE %d %d %u %d %lld\\\\n",(int)f->get_family_id(),(int)f->get_decl_kind(),num,(int)st,v-2*b+a);}')
                srcfile=d/k.name;srcfile.write_text(src);obj=d/(k.stem+'.o')
                includes=shlex.split(re.search('^includes_'+str(inc)+' = (.*)$',make,re.M)[1])
                sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*includes,'-o',obj,srcfile],cwd=build,check=True)
                sp.run(['ar','r',lib,obj],check=True)
            k=front/'smt/quantifier.go';put(k,edit(k.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
'''+s[b:]
s=s.replace("'phase.csv'","'reductions.csv'").replace('phase calls entries instructions','family kind arity status calls instructions').replace('lambda:[0,0,0]','lambda:[0,0]').replace("b'POP-PHASE '","b'REDUCE '").replace("phase,n,v=map(int,words[1:]);a=totals[key+(phase,)];a[0]+=1;a[1]+=n;a[2]+=v","*op,v=map(int,words[1:]);a=totals[key+tuple(op)];a[0]+=1;a[1]+=v").replace('len(totals)==12','all(any(k[:2]==goal for k in totals) for goal in seen)').replace('range(5)','range(3)')
exec(compile(s,'reductions','exec'))
