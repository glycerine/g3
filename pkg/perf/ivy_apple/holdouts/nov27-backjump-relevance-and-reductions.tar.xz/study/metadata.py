"""Skip declaration-only metadata lookups in the application deletion path."""
from pathlib import Path
import tarfile
here=Path(__file__).resolve().parent
def variant(source):
    a='slot, generation := m.infoForNode(current)'
    assert source.count(a)==2
    return source.replace(a,'var slot, generation uint32\n\t\tif n.kind == ASTSort || n.kind == ASTFuncDecl {\n\t\t\tslot, generation = m.infoForNode(current)\n\t\t}')
if __name__=='__main__':
    with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as arc:
        s=arc.extractfile('study/notify-trials.py').read().decode()
    a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
    s=s[:a]+"""    modes=['base','metadata']
    for mode in modes:
        p=pkg/'ast/ast_core_delete.go'
        source=p.read_text()
        put(p,variant(source) if mode=='metadata' else source)
"""+s[b:]
    s=s.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("'notification.csv'","'metadata.csv'")
    exec(compile(s,'metadata','exec'))
