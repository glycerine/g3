"""Compare the linked-page or slice trial to the committed freelist on complete verifiers."""
from links import variant
from pathlib import Path
import os, subprocess as sp,tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    s=t.extractfile('study/panel.py').read().decode()
a=s.index("    if name=='trial':");b=s.index("    j=d/",a)
s=s[:a]+"""    path=pkg/'smtcore/smt_relevancy_table.go'
    original=sp.check_output(['git','show','e26261bce:pkg/smtcore/smt_relevancy_table.go']).decode()
    alt=d/(name+'-links.go')
    alt.write_text(variant(original,os.environ['LINKS_MODE'] if name=='trial' else 'base'))
    mp[str(path)]=str(alt)
"""+s[b:]
s=s.replace('range(5):','range('+os.environ.get('PAIRS','5')+'):')
exec(compile(s,'panel','exec'))
