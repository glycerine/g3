from collections import Counter,defaultdict
import csv,statistics
from pathlib import Path
here=Path(__file__).resolve().parent
for name in ['phase','metadata','links','identity']:
    p=here/(name+'.csv')
    if not p.exists():continue
    groups=defaultdict(Counter)
    for r in csv.DictReader(p.open()):
        k=(r['engine'],r['phase']) if name=='phase' else (r['case'],r['mode'])
        for col in ['instructions','calls','entries']:
            if col in r:groups[k,col][r['round']]+=int(r[col])
    for k,c in sorted(groups.items()):print(name,*k,len(c),statistics.median(c.values()))
