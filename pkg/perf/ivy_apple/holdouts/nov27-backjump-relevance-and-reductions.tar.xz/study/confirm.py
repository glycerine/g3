"""Rotate all three layouts on the same core for each target with normal GC."""
from pathlib import Path
p=Path(__file__).with_name('panel.py')
s=p.read_text().split("exec(compile(s,'panel','exec'))")[0]
exec(compile(s,'prepare-panel','exec'))
s=s.replace("for name in ('base','trial'):","for name in ('base','pages','slice'):").replace("os.environ['LINKS_MODE'] if name=='trial' else 'base'","name")
s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","modes=['base','pages','slice'];modes=modes[i%3:]+modes[:i%3]")
s=s.replace('((1,3),(4,8),(6,227))','((4,),(8,),(6,))')
exec(compile(s,'confirm','exec'))
