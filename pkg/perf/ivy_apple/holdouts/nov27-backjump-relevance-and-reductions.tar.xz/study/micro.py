from pathlib import Path
from links import variant
import csv,json,os,subprocess as sp,tempfile
here=Path(__file__).resolve().parent
p=Path('smtcore/smt_relevancy_table.go').resolve()
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp);modes=['base','pages','slice']
    for mode in modes:
        path=d/(mode+'.go');path.write_text(variant(sp.check_output(['git','show','e26261bce:pkg/smtcore/smt_relevancy_table.go']).decode(),mode))
        overlay=d/'overlay.json';overlay.write_text(json.dumps({'Replace':{str(p):str(path)}}))
        sp.run(['go','test','-c','-overlay',overlay,'-o',d/mode,'./smtcore'],check=True)
        sp.run([d/mode,'-test.run=Relevancy','-test.count=1'],check=True)
    with (here/'watch.bench').open('w') as out:
        for i in range(9):
            for mode in modes[i%3:]+modes[:i%3]:
                print('variant:',mode,file=out,flush=True)
                sp.run(['taskset','-c',os.environ['CPU'],d/mode,'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSMTRelevancyWatchPop$','-test.benchtime=3000x'],check=True,stdout=out)
