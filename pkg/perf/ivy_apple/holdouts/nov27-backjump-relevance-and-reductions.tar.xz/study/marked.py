"""Price final mark-vector decrements at the native and Go deletion sites."""
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'phase.py').read_text()
anchor='            put(p,s)'
s=s.replace(anchor,'''            needle='p.relevant, err = p.context.manager.ShrinkHeldRefs(p.relevant, scope.relevantLimit)'
            body="""if fd>=0 {
                for pos:=scope.relevantLimit;pos<len(p.relevant);pos++{
                    h:=p.relevant[pos];rc,e:=p.context.manager.GetRefCount(h);if e!=nil{panic(e)}
                    phase:=7;if rc==1{phase=8}
                    a:=popRead(fd);b:=popRead(fd);_,e=p.context.manager.ShrinkHeldRefs(p.relevant[pos:pos+1],0);popTotal(fd,phase,1,a,b)
                    if e!=nil{panic(e)}
                }
                p.relevant=p.relevant[:scope.relevantLimit]
            }else{"""+needle+"}"
            s=edit(s,needle,body)
'''+anchor)
anchor='            src=d/p.name;src.write_text(s)'
s=s.replace(anchor,'''            needle='m_relevant_exprs.shrink(old_lim);'
            body='if(fd>=0){for(unsigned j=old_lim;j<m_relevant_exprs.size();j++){auto phase=m_relevant_exprs.get(j)->get_ref_count()==1?8:7;auto a=snap(fd),b=snap(fd);m_relevant_exprs.set(j,nullptr);auto v=snap(fd);fprintf(stderr,"POP-PHASE %d 1 %lld\\\\n",phase,v-2*b+a);}}'
            s=edit(s,needle,body+needle)
'''+anchor)
s=s.replace('len(totals)==12','len(totals)==20').replace("'phase.csv'","'marked.csv'")
exec(compile(s,'marked','exec'))
