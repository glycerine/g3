"""Price a single declaration-identity read in theory rewriting."""
from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as arc:
    s=arc.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+'''    modes=['base','identity']
    for mode in modes:
        for name in ['ast/ast_core_accessors.go','ast/rewriter/th_rewriter.go','smtcore/smt_relevancy_table.go']:
            p=pkg/name
            src=sp.check_output(['git','show','e26261bce:pkg/'+name]).decode()
            if mode=='identity' and name.endswith('ast_core_accessors.go'):
                a=src.index('func (m *ASTManager) GetFamilyID(')
                b=src.index('func (m *ASTManager) GetDeclKind(',a)
                body=src[a:b].replace(' GetFamilyID(', ' RewriterDeclIdentity(').replace('(FamilyID, error)', '(FamilyID, int32, error)').replace('return -1, e','return -1,-1,e').replace('return a.declFamily, nil','return a.declFamily,a.declKind,nil').replace('fid, _, e := m.declIdentity(r)\\n\\treturn fid, e','return m.declIdentity(r)')
                src=src[:a]+body+src[a:]
            if mode=='identity' and name.endswith('th_rewriter.go'):
                a=src.index('func (c *theoryRewriterConfiguration) reduceAppCore(')
                src=src[:a]+src[a:].replace('family, err := m.GetFamilyID(decl)','family,kind,err := m.RewriterDeclIdentity(decl)',1).replace('kind, err := m.GetDeclKind(decl)\\n\\t\\tif err != nil {\\n\\t\\t\\treturn RewriteFailed, err\\n\\t\\t}', '',1)
            put(p,src)
'''+s[b:]
s=s.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("'notification.csv'","'identity.csv'")
exec(compile(s,'identity','exec'))
