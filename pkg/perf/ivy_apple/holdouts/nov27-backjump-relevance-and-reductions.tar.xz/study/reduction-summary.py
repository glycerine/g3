"""Decompose the reduction gap into volume and per-call cost within matching strata."""
import csv,statistics as st,collections
from pathlib import Path
d=Path(__file__).resolve().parent
rows=collections.defaultdict(lambda:collections.defaultdict(dict))
for r in csv.DictReader((d/'reductions.csv').open()):
    key=tuple(int(r[k]) for k in ['batch','goal','family','kind','arity','status'])
    rows[key][r['engine']][int(r['round'])]=int(r['calls']),int(r['instructions'])
out=collections.defaultdict(lambda:[0]*6)
for key,engines in rows.items():
    pair=[]
    for eng in ['g3','z3']:
        repeats=list(engines[eng].values())
        assert not repeats or len(repeats)==3 and len({n for n,v in repeats})==1
        pair.append((repeats[0][0],st.median(v for n,v in repeats)) if repeats else (0,0))
    (g,x),(z,y)=pair
    unit=min(g,z)*(x/g-y/z) if g and z else 0
    for k in [(key[2],key[3],key[5]),('all','all','all')]:
        a=out[k]
        for i,v in enumerate([g,z,x,y,unit,x-y-unit]):a[i]+=v
with (d/'reduction-summary.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['family','kind','status','g3_calls','z3_calls','g3_instr','z3_instr','common_call_excess','unpaired_volume_excess'])
    for key,a in sorted(out.items(),key=lambda kv:kv[1][2]-kv[1][3],reverse=True):w.writerow([*key,*[round(v) for v in a]])
