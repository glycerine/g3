"""Resample the four ordinary Ticket checks at a shorter hardware period."""
from pathlib import Path
import tarfile
d=Path(__file__).resolve().parent
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:
    driver=t.extractfile('study/stacks.py').read().decode()
    (d/'profile.go.txt').write_bytes(t.extractfile('study/profile.go.txt').read())
driver=driver.replace('[(4,6,4),(4,6,5),(4,6,6),(8,12,8)', '[(8,12,8)').replace('1500007+i*200','900001+i*202')
driver=driver.replace('range(3):','range(6):')
exec(compile(driver,'sample-pop','exec'))
