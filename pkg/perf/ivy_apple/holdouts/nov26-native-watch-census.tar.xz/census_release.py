"""Count the exact long-watch branch, size and replacement distributions."""
from pathlib import Path
import json
import subprocess

root=Path.cwd()
out=Path(__file__).resolve().parent/'release-observer'
out.mkdir(exist_ok=True)
changes={}

def patch(name, old, new):
    src=root/name
    content=changes.get(src,src).read_text()
    assert content.count(old)==1, (name,old,content.count(old))
    target=out/src.name
    target.write_text(content.replace(old,new))
    changes[src]=target

path='sat/sat_solver_propagation.go'
patch(path,'bits := data[pos]', 'bits := data[pos]\nif bits.val2&3==2 {propagationCensus.Long++}')
patch(path,'if !tracing && bits.val2&3 == 2 && assignment[bits.val2>>2] == lbool.True {','if !tracing && bits.val2&3 == 2 && assignment[bits.val2>>2] == lbool.True {\npropagationCensus.Blocked++')
patch(path,'if assignment[blocked.index()] == lbool.True {','if assignment[blocked.index()] == lbool.True {\npropagationCensus.Blocked++')
patch(path,'if tracing {\n\t\t\t\t\ts.traceProcessingClause(c)','propagationCensus.Width[min(64,clause.size())]++\nif off.storageKind!=0 {propagationCensus.Direct++}\nif tracing {\n\t\t\t\t\ts.traceProcessingClause(c)')
patch(path,'if clause.flag(satClauseFlagRemoved) || c1 != not {', 'if clause.flag(satClauseFlagRemoved) || c1 != not {\n                    propagationCensus.Obsolete++')
patch(path,'if assignment[c0.index()] == lbool.True {','if assignment[c0.index()] == lbool.True {\n                    propagationCensus.Companion++')
patch(path,'if moved {\n\t\t\t\t\ti := replacement.Negated()', 'if moved {\n                    propagationCensus.Moves++\n\t\t\t\t\ti := replacement.Negated()')
patch(path,'\t\t\t\t\tif dest != nil && dest.appendEncoded(satWatchWords{bits.val1, 2 + uint32(c0)<<2}, iter.backing.owner) {', '\t\t\t\t\tif dest != nil && dest.appendEncoded(satWatchWords{bits.val1, 2 + uint32(c0)<<2}, iter.backing.owner) {\n                        propagationCensus.FastDest++')
path='sat/sat_clause_storage.go'
patch(path,'for len(rest) >= 16 {','pos := 0\n\tfor len(rest) >= 16 {')
for i,name in enumerate(('first','second','third','fourth','replacement')):
    condition=f'if assignment[{name}.index()] != lbool.False {{'
    patch(path,condition,'propagationCensus.Inspected++\n\t\t'+condition+f'\n\t\t\tpropagationCensus.Replacement[min(64,pos+{i%4})]++')
for step in (16,4):
    anchor=f'rest = rest[{step}:]'
    patch(path,anchor,f'pos += {step//4}\n\t\t'+anchor)
path=root/'sat/sat_hot_trial_census.go'
changes[path]=out/path.name
changes[path].write_text('''package sat
import("encoding/json"; "fmt"; "os")
var propagationCensus struct {
    Long, Blocked, Companion, Obsolete, Direct, Moves, FastDest, Inspected uint64
    Width,Replacement [65]uint64
}
func PrintPropagationCensus() {
    raw,_:=json.Marshal(propagationCensus)
    fmt.Fprintf(os.Stderr,"CLAUSE-HOT %s\\n",raw)
}
''')
patch('cmd/g3/main.go','\tstopProfile()\n','\tstopProfile()\n\tsat.PrintPropagationCensus()\n')
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(path):str(data) for path,data in changes.items()}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
