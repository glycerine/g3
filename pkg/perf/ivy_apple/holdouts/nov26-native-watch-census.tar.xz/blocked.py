"""Test an early exit for a satisfied blocking literal in the watch loop."""
import argparse, json, subprocess
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('variant',choices=('copy','skip','plain','release'))
args=parser.parse_args()
root=Path.cwd()
out=Path(__file__).resolve().parent/args.variant
out.mkdir(exist_ok=True)
source=root/'sat/sat_solver_propagation.go'
s=source.read_text()
anchor='\t\t\tbits := data[pos]\n'
assert s.count(anchor)==1
insert='''
            if !tracing && bits.val2&3 == 2 && assignment[bits.val2>>2] == lbool.True {
                COPY
                out++
                continue
            }
'''
copy='''data[out] = bits
                if extra := iter.backing.wide; extra != nil {
                    extra.values[out] = extra.values[pos]
                }'''
if args.variant in ('skip','release'):
    copy='if out != pos {\n'+copy+'\n}'
if args.variant=='plain':
    insert=insert.replace('!tracing &&','!tracing && iter.backing.wide == nil &&')
    copy='data[out] = bits'
s=s.replace(anchor,anchor+insert.replace('COPY',copy))
if args.variant=='release':
    s=s.replace('if !tracing && bits.val2&3 == 2', '''// A satisfied blocking literal retains the original encoded watch.
            // Only copy it if an earlier move opened a gap in this list.
            if !tracing && bits.val2&3 == 2''')
    start=s.index('blocked, e := w.BlockedLiteral()')
    end=s.index('off := iter.backing.offset',start)
    s=s[:start]+'''if tracing {
                    blocked,e:=w.BlockedLiteral()
                    if e!=nil { return false,e }
                    if assignment[blocked.index()] == lbool.True {
                        s.traceBlockedClause(blocked,iter.backing.read(pos))
                        break
                    }
                }
                '''+s[end:]
target=out/source.name
target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(source):str(target)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
