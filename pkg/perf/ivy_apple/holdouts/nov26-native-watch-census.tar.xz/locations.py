"""Map retired-instruction samples in three Go hot functions to compiler source lines."""
import argparse,collections,csv,re,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--perf',default='perf')
p.add_argument('binary',type=Path)
p.add_argument('profiles',type=Path)
a=p.parse_args()
pattern=r'sat\.\(\*satSolverPropagationState\)\.propagateCore$|arena\.\(\*ClauseBytes\)\.Borrow$|sat\.satClauseView\.moveWatch$'
assembly=subprocess.check_output(['go','tool','objdump','-s',pattern,str(a.binary)],text=True)
locations={}
for line in assembly.splitlines():
    if line.startswith('TEXT '):
        function=line.split()[1].removeprefix('github.com/glycerine/g3/pkg/').removesuffix('(SB)')
    else:
        m=re.match(r'\s*(\S+:\d+)\s+0x([a-f0-9]+)\s+',line)
        if m: locations[int(m[2],16)]=function,m[1]
writer=csv.writer(sys.stdout)
writer.writerow(('case','round','function','source','samples'))
for file in sorted(a.profiles.glob('*-g3-*.data')):
    case,round=file.stem.rsplit('-g3-',1)
    output=subprocess.check_output([a.perf,'script','-G','-F','ip,sym,dso','-i',file],text=True)
    counts=collections.Counter()
    for line in output.splitlines():
        fields=line.split()
        if fields and fields[-1]=='('+str(a.binary.resolve())+')':
            location=locations.get(int(fields[0],16))
            if location: counts[location]+=1
    if not counts: raise ValueError(file)
    for loc,n in counts.most_common():writer.writerow((case,round,*loc,n))
