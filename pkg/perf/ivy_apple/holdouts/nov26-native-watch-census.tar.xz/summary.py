"""Report ratios of medians against the base engine, per case."""
import csv,sys,statistics as st
from collections import defaultdict
rows=defaultdict(list)
for r in csv.DictReader(open(sys.argv[1])):
    rows[r['case'],r['engine']].append(r)
for (case,engine), rs in rows.items():
    if engine=='base':continue
    ref=rows[case,'base']
    print(case,engine,len(rs),*[f'{100*(st.median(float(r[key]) for r in rs)/st.median(float(r[key]) for r in ref)-1):+.2f}%' for key in ('instructions','cycles','milliseconds')])
