"""Try validating the watch list's common physical arena once per list."""
from pathlib import Path
import subprocess,json
root=Path.cwd()
base=Path(__file__).resolve().parent
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--eager',action='store_true')
args=parser.parse_args()
out=base/('eager' if args.eager else 'combined')
out.mkdir(exist_ok=True)
src=root/'sat/sat_solver_propagation.go'
s=(base/'release'/src.name).read_text()
anchor='\t\tfor pos := uint32(0); pos < iter.end; pos++ {'
s=s.replace(anchor,'''        var common *arena.ClauseBytes
        a:=s.clauses
        if destinations != nil && iter.backing != nil && a != nil && !a.closed && a.self == a && iter.backing.owner == a.origin {
            common = a.storage
        }
'''+anchor)
a=s.index('off := iter.backing.offset(bits, pos)')
b=s.index('if e != nil {',a)
s=s[:a]+'''// A compact pooled watch inherits this list's verified owner.
                // Direct and full-width watches resolve their original offset.
                var off satClauseOffset
                var clause satClauseView
                slot := bits.val1 & ((1 << satWatchSlotBits) - 1)
                pooled := common != nil && bits.val1 & (1 << satWatchSlotBits) == 0 && slot != 0
                if pooled {
                    generation:=bits.val1>>(satWatchSlotBits+1)
                    clause,e=common.Borrow(arena.SmallBytesRef{Slot:arena.Slot(slot),Generation:arena.Generation(generation)})
                } else {
                    off=iter.backing.offset(bits,pos)
                    clause,e=s.clauses.view(StoredClauseRef(off))
                }
                '''+s[b:]
s=s.replace('s.traceProcessingClause(c)','c:=StoredClauseRef(off)\n                    s.traceProcessingClause(c)').replace('s.traceClauseMismatch(l, c,','c:=StoredClauseRef(off)\n                    s.traceClauseMismatch(l, c,')
s=s.replace('if e = v.watches.pushClause','if pooled {off=iter.backing.offset(bits,pos)}\n                    if e = v.watches.pushClause')
s=s.replace('value := assignment[c0.index()]','if pooled {off=iter.backing.offset(bits,pos)}\n                c:=StoredClauseRef(off)\n                value := assignment[c0.index()]')
if args.eager:
    a=s.index('var off satClauseOffset')
    b=s.index('if e != nil {',a)
    s=s[:a]+"""off:=iter.backing.offset(bits,pos)
                c:=StoredClauseRef(off)
                var clause satClauseView
                if common != nil && bits.val1 >> satWatchSlotBits != satWatchWide && off.storageKind == 0 && off.slot != 0 {
                    clause,e=common.Borrow(arena.SmallBytesRef{Slot:arena.Slot(off.slot),Generation:arena.Generation(off.generation)})
                } else {
                    clause,e=s.clauses.view(c)
                }
                """+s[b:]
    s=s.replace('c:=StoredClauseRef(off)\n                    s.trace','s.trace')
    s=s.replace('if pooled {off=iter.backing.offset(bits,pos)}\n                    ', '')
    s=s.replace('if pooled {off=iter.backing.offset(bits,pos)}\n                c:=StoredClauseRef(off)\n                ', '')
target=out/src.name
target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(target)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
