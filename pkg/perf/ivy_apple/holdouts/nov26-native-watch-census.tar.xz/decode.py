"""Decode compact watched clauses directly against their verified arena owner."""
import json, subprocess
from pathlib import Path
root=Path.cwd()
out=Path(__file__).resolve().parent/'decode'
out.mkdir(exist_ok=True)
file=root/'sat/sat_solver_propagation.go'
s=file.read_text()
anchor='\t\tfor pos := uint32(0); pos < iter.end; pos++ {'
assert s.count(anchor)==1
s=s.replace(anchor,'''        var storage *arena.ClauseBytes
        a:=s.clauses
        if !tracing && !s.extensionPresent && iter.backing!=nil && a!=nil && !a.closed && a.self==a && iter.backing.owner==a.origin {
            storage=a.storage
        }
'''+anchor)
a=s.index('off := iter.backing.offset(bits, pos)')
b=s.index('if e != nil {',a)
s=s[:a]+'''var clause satClauseView
                slot:=bits.val1 & ((1<<satWatchSlotBits)-1)
                if storage!=nil && bits.val1 & (1<<satWatchSlotBits)==0 && slot!=0 {
                    clause,e=storage.Borrow(arena.SmallBytesRef{Slot:arena.Slot(slot),Generation:arena.Generation(bits.val1>>(satWatchSlotBits+1))})
                } else {
                    clause,e=s.clauses.view(StoredClauseRef(iter.backing.offset(bits,pos)))
                }
                '''+s[b:]
s=s.replace('s.traceProcessingClause(c)','c:=StoredClauseRef(iter.backing.offset(bits,pos))\n                    s.traceProcessingClause(c)').replace('s.traceClauseMismatch(l, c,','c:=StoredClauseRef(iter.backing.offset(bits,pos))\n                    s.traceClauseMismatch(l, c,')
s=s.replace('watches.pushClause(i, c0, off)','watches.pushClause(i, c0, iter.backing.offset(bits,pos))')
s=s.replace('value := assignment[c0.index()]','off:=iter.backing.offset(bits,pos)\n                c:=StoredClauseRef(off)\n                value := assignment[c0.index()]')
target=out/file.name
target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(file):str(target)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
