"""Build an untimed watch observer using the in-tree native build's own recipes."""
import argparse
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('out', type=Path)
args = parser.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
repo = Path.cwd().parent
build = repo/'build'
src = (repo/'src/sat/sat_solver.cpp').read_text()
start = src.index('bool solver::propagate_core(bool update)')
end = src.index('bool solver::propagate(bool update)', start)
loop = src[start:end]
for anchor, counter in [
    ('case watched::CLAUSE: {', '++counts.long_visits;'),
    ('if (value(it->get_blocked_literal()) == l_true) {', '++counts.blocked;'),
    ('if (c[0] == not_l)', '++counts.width[std::min(64u,c.size())];'),
    ('if (c.was_removed() || c[1] != not_l) {', '++counts.obsolete;'),
    ('if (value(c[0]) == l_true) {', '++counts.companion;'),
    ('for (; l_it != l_end; ++l_it) {', '++counts.inspected;'),
    ('if (value(*l_it) != l_false) {', '++counts.moves; ++counts.replacement[std::min(64u,unsigned(l_it-c.begin()-2))];'),
]:
    assert loop.count(anchor) == 1, anchor
    pos = loop.index(anchor) + (0 if anchor == 'if (c[0] == not_l)' else len(anchor))
    loop = loop[:pos]+'\n                    '+counter+'\n                    '+loop[pos:]
observer = r'''
namespace {
struct watch_census {
    unsigned long long long_visits{}, blocked{}, obsolete{}, companion{}, inspected{}, moves{};
    unsigned long long width[65]{}, replacement[65]{};
    ~watch_census() {
        std::fprintf(stderr,"CLAUSE-HOT {\"Long\":%llu,\"Blocked\":%llu,\"Obsolete\":%llu,\"Companion\":%llu,\"Inspected\":%llu,\"Moves\":%llu",
                     long_visits, blocked, obsolete, companion, inspected, moves);
        array("Width", width);
        array("Replacement", replacement);
        std::fprintf(stderr,"}\n");
    }
    void array(const char* key, const unsigned long long* bins) {
        std::fprintf(stderr,",\"%s\":[", key);
        for(unsigned i=0;i<65;++i) std::fprintf(stderr,"%s%llu",i?",":"",bins[i]);
        std::fputc(']',stderr);
    }
} counts;
}
'''
(out/'sat_solver.cpp').write_text('#include <cstdio>\n'+src[:start]+observer+loop+src[end:])
makefile = (build/'Makefile').read_text().splitlines()
compile = next(line.strip() for line in makefile if '$(CXX_OUT_FLAG)sat/sat_solver$(OBJ_EXT)' in line)
link = next(line.strip() for line in makefile if '$(LINK_OUT_FLAG)z3$(EXE_EXT)' in line)
compile = compile.replace('sat/sat_solver$(OBJ_EXT)',str(out/'observer.o')).replace('../src/sat/sat_solver.cpp',str(out/'sat_solver.cpp'))
link = link.replace('$(LINK_OUT_FLAG)z3$(EXE_EXT)','$(LINK_OUT_FLAG)'+str(out/'z3')).replace(' sat/sat$(LIB_EXT) ',' '+str(out/'observer.o')+' sat/sat$(LIB_EXT) ')
subprocess.run(['make','-s','-f','Makefile','-f','-','census-target'],cwd=build,input='census-target:\n\t'+compile+'\n\t'+link+'\n',text=True,check=True)
