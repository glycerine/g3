# Matched native and Go SAT watch visits

Start in pkg/ of this fork with the built native executable and libraries in ../build/. Go was 1.27.3 on a Ryzen Threadripper 3960X. The original ordinary solver was 0bbb4751a. The benchmark baseline for finalists includes the trace-only fix in 8f412aa7a. Each process used one pinned core and the Go processes used GOMAXPROCS=1. All timings used ordinary builds with PGO off. The observers were used only to count visits.

Put the scripts in a writable scratch directory. From pkg/ run native.py SCRATCH/native. It copies and instruments this repository's src/sat/sat_solver.cpp, compiles it using the in-tree compiler flags and links its object with the existing release archives. It leaves the built z3 intact. census.py builds an overlay observer on 0bbb4751a and census_release.py does so on the release containing the blocked-watch optimization. Both instrument each of the four unrolled comparisons and the scalar tail. The 65th bin aggregates widths or positions of 64 or more. observe.py checks expected verdicts, every SAT model, all five search counters and equality of eight native/Go census fields including the two full histograms.

    python3 SCRATCH/native.py SCRATCH/native
    python3 SCRATCH/census_release.py
    python3 SCRATCH/observe.py INPUTS native-observer=SCRATCH/native/z3 \
      go-observer=SCRATCH/release-observer/g3 base=PATH_TO_RELEASE > counts.jsonl

Extract the files under fixtures/ in nov26-clause-locality.tar.xz for INPUTS. The second pigeonhole ordering is in nov26-sat-arena-hot.tar.xz. Complete GoIvy transcripts are in nov24-verifier-instruction-stacks.tar.xz. GoIvy was 07cdeec61 with the local g3 module replacement. Build its cmd/goivy_check with -tags=xtrace_off. Build each Go executable with -buildvcs=false -pgo=off -mod=readonly.

On the baseline source, blocked.py copy and skip are the first candidates. The skip variant elides an in-place copy. blocked.py release also removes the duplicate blocking-literal lookup on untraced builds. decode.py is an ordinary-build experiment that defers resolving a compact handle. It was superseded by the callback-aware candidates. combined.py uses the blocked.py release output and can either defer decoding or capture the original handle with --eager. owner.py uses the eager output and checks the owner per watch. Run these from pkg/ and keep their output subdirectories adjacent to the scripts. Measurements use these drivers:

    python3 SCRATCH/measure.py --cpu CPU --rounds 7 --solver-arg=-v:2 \
      --case unsat:INPUTS/random-208-3.cnf --case sat:INPUTS/random-208-4.cnf \
      --case unsat:INPUTS/pigeon8-s0.cnf --case sat:INPUTS/random-256-3.cnf:stdin \
      base=BASE final=FINAL z3=../build/z3 > final.csv
    python3 SCRATCH/summary.py final.csv

final.csv, second.csv and solo.csv cover the release candidate and native controls. planted.csv and planted-off.csv repeat the zero-conflict control with default GC and GOGC=off. The initial and intermediate experiments are recorded separately. verifier-final.csv checks exact transcripts and exit status against the reference set for four complete GoIvy workloads. Its base is the preceding GoIvy release with the reason-scan optimization. Some measurement series ran on separate cores concurrently. Inspect the cycle counts and independent repeat for the second pigeonhole ordering when interpreting elapsed time.

profile.py --cpu CPU --rounds 3 --out DIRECTORY accepts a --fixture option per DIMACS input followed by the ordinary Go and native executables. It checks search counters and rejects lost or throttled events. final-profile.csv records exclusive categories and leaf symbols at a period of 2,000,003 user instructions. With the same Go binary that produced the profiles, locations.py BINARY DIRECTORY maps leaf sample IPs to compiler lines for propagateCore, moveWatch and ClauseBytes.Borrow. These are sampled instruction locations, subject to sample skid, and cannot establish exact per-source-line execution counts. Both scripts accept --perf PATH.
