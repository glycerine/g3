"""Resolve exceptional and compact offsets before a shared owner check."""
from pathlib import Path
import subprocess,json
root=Path.cwd()
base=Path(__file__).resolve().parent
out=base/'owner'
out.mkdir(exist_ok=True)
src=root/'sat/sat_solver_propagation.go'
s=(base/'eager'/src.name).read_text()
s=s.replace('destinations != nil && iter.backing != nil && a != nil && !a.closed && a.self == a && iter.backing.owner == a.origin','destinations != nil && a != nil && !a.closed && a.self == a')
s=s.replace('bits.val1>>satWatchSlotBits != satWatchWide && off.storageKind','off.owner == a.origin && off.storageKind')
s=s.replace("// A compact pooled watch inherits this list's verified owner.\n\t\t\t\t// Direct and full-width watches resolve their original offset.","// The arena checks the physical slot and generation. Direct clauses\n                // and handles from a different owner use the allocator lookup.")
target=out/src.name
target.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(src):str(target)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
