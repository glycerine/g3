import csv,statistics as st,collections
from pathlib import Path
d=Path(__file__).resolve().parent
for group in ['panel','defer','interleave','transitive','adaptive']:
 for f in sorted((d/group).glob('time-*.csv')):
    rows=list(csv.DictReader(f.open()))
    if not rows:continue
    r={k:[int(x['instructions']) for x in rows if x['engine']==k] for k in set(x['engine'] for x in rows)}
    print(group,f.stem,len(rows),{k:round(100*(st.median(v)/st.median(r['base'])-1),2) for k,v in r.items() if k!='base'})
for f in sorted((d/'profile').glob('*.events')):
 bins=collections.defaultdict(list)
 for row in f.open():
    op,*v=row.split()
    if op=='ROWGOAL':states={}
    elif op=='ROWMETA':meta=v
    elif op=='ROWARG':
        mgr,origin,slot,gen,lit,work=v;h=origin,slot,gen;live,popped=states.setdefault(mgr,({},set()))
        if h in popped and meta[:4]==['0','0','6','2'] and meta[-1]=='true':bins[int(meta[4])].append(int(work))
        live[h]=int(lit)//2;popped.discard(h)
    elif op=='ROWOP':
        mgr,level,lim=v;live,popped=states.setdefault(mgr,({},set()))
        for h,i in list(live.items()):
            if i>=int(lim):del live[h];popped.add(h)
 print(f.name,[(k,len(v),round(sum(v)/1e6,3)) for k,v in sorted(bins.items())])
