from pathlib import Path
from trial import panel
import tarfile
def patch(pkg,name):
    p=pkg/'smtcore/smt_quantifier_manager.go';s=p.read_text()
    a='return q.instantiate([]SMTQIQueueEntry{entry})\n\t}, q.state.resourceLimitsExceeded)';assert s.count(a)==1
    s=s.replace(a,'''if StudyGoal {quant:=entry.Fingerprint.data
        if !studySeen[quant]{studySeen[quant]=true;body,e:=q.state.manager.GetQuantifierBody(quant);if e!=nil{panic(e)};n,_:=q.state.manager.GetNumDeclarations(quant);p,_:=q.state.manager.GetNumPatterns(quant);println("ROWBEGIN",quant.Slot(),quant.Generation(),n,p,studyTerm(q.state.manager,body,0))}
    }else{clear(studySeen)}
    '''+a)
    yield p,s+'''
var StudyGoal bool
var studySeen=map[ast.ASTHandle]bool{}
func studyTerm(m *ast.ASTManager,h ast.ASTHandle,depth int)string{
    if depth>40{return "..."};hd,e:=m.NodeHeader(h);if e!=nil{panic(e)}
    switch hd.Kind{
    case ast.ASTVar:i,_:=m.GetVarIndex(h);return fmt.Sprint("#",i)
    case ast.ASTQuantifier:b,_:=m.GetQuantifierBody(h);return "(Q "+studyTerm(m,b,depth+1)+")"
    }
    name,_:=m.GetASTName(hd.Decl);label,_:=m.Symbols.String(name)
    if hd.NumArgs==0{return label};var b strings.Builder;b.WriteString("(");b.WriteString(label)
    for i:=uint32(0);i<hd.NumArgs;i++{x,_:=m.GetArg(h,i);b.WriteString(" ");b.WriteString(studyTerm(m,x,depth+1))}
    b.WriteString(")");return b.String()
}
'''
def run(s):
    with tarfile.open('perf/ivy_apple/holdouts/nov27-ticket-cost-and-root-lifetimes.tar.xz') as t:src=t.extractfile('./templates.py').read().decode()
    c={};exec(src[:src.rindex("panel(['probe'],patch,run)")],c)
    return c['run'](s).replace('"github.com/glycerine/g3/pkg/ast/rewriter"','"github.com/glycerine/g3/pkg/smtcore"')
panel(['probe'],patch,run)
