from pathlib import Path
from collections import Counter
f=Path(__file__).resolve().parent/'lifetime/events'
stats=Counter()
for row in f.open():
 op,*v=row.split()
 if op=='ROWGOAL':states={};children=None
 elif op=='ROWKIDS':children=(v[0],max(int(x)//2 for x in v[1:]))
 elif op=='ROWARG':
    mgr,origin,slot,gen,lit,cost=v
    if children:
        assert children[0]==mgr
        records=states.setdefault(mgr,{})
        key=(origin,slot,gen)
        if key in records and records[key][2]:
            stats['repeated']+=1;stats['instructions']+=int(cost)
            if records[key][1]<records[key][3]:
                stats['survivors']+=1;stats['survivor instructions']+=int(cost)
        records[key]=[int(lit)//2,children[1],False,2**32];children=None
 elif op=='ROWOP':
    mgr,_,limit=v
    for r in states.get(mgr,{}).values():
        if r[0]>=int(limit):r[2]=True
        r[3]=min(r[3],int(limit))
print(dict(stats))
