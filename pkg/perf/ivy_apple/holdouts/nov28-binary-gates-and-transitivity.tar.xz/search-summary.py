import statistics as st,csv,collections
from pathlib import Path
d=Path(__file__).resolve().parent
def rows(p):return list(csv.DictReader(p.open()))
def checks(p):
    return {(int(r['batch']),int(r['goal'])):int(r['value']) for r in rows(p) if r['reason']=='decide'}
for case in [4,8]:
    groups={}
    for mode in ['base','q4','q16','delay']:
        pairs=[checks(p) for p in sorted((d/'checks').glob(f'{case}-{mode}-*.csv'))]
        if pairs:groups[mode]={k:st.median([v.get(k,0) for v in pairs]) for k in set.union(*(set(v) for v in pairs))}
    if 'base' not in groups:continue
    base=groups['base'];print('case',case)
    for mode,vals in groups.items():
        ks=set(vals)|set(base);delta={k:(vals.get(k,0)-base.get(k,0))/1e6 for k in ks}
        print(mode,round(sum(delta.values()),2),[(k,round(v,2)) for k,v in sorted(delta.items(),key=lambda kv:-abs(kv[1]))[:5]])
def observe(p):
    return {(int(r['batch']),int(r['goal'])):int(r['value']) for r in rows(p) if r['reason']=='decide'}
q=d/'quantifiers'
if not (q/'0-0-0-0-0.csv').exists():quit()
base=observe(q/'0-0-0-0-0.csv');scores=collections.defaultdict(list)
for f in sorted(q.glob('*.csv')):
    b,g,slot,gen,rep=map(int,f.stem.split('-'))
    if b==0:continue
    diag=[r for r in rows(f) if r['reason']=='defer'];v=observe(f);k=b,g
    if not diag or k not in v:continue
    diff=(v[k]-base[k])/1e6;total=(sum(v.values())-sum(base.values()))/1e6
    scores[(b,g,slot,gen)].append((diff,total,int(diag[0]['width']),int(diag[0]['work'])))
for k,vals in sorted(scores.items(),key=lambda kv:st.mean(v[1] for v in kv[1])):
    print('quantifier',k,len(vals),*[round(st.mean(c),2) for c in zip(*vals)])
