from pathlib import Path
import tarfile,tempfile
from trial import panel
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp)
    with tarfile.open('perf/ivy_apple/holdouts/nov27-ticket-cost-and-root-lifetimes.tar.xz') as t:
        for f in ('children','operands','survivors','templates'):
            (d/(f+'.py')).write_bytes(t.extractfile('./'+f+'.py').read())
    p=d/'children.py';ns={'__file__':str(p)};exec(p.read_text().rsplit("panel(['probe'],patch,run)",1)[0],ns)
    def patch(pkg,name):
        for p,s in ns['patch'](pkg,name):
            if p.name=='smt_internalizer.go':
                a='work:=counter.finish();println("ROWARG"';assert s.count(a)==1
                s=s.replace(a,'''work:=counter.finish()
                _,child,_:=s.manager.IsNot(argument)
                if !child.IsNull(){hd,e:=s.manager.NodeHeader(child);if e==nil && hd.Kind==ast.ASTApp && hd.Family==s.manager.BasicFamilyID() && hd.DeclKind==ast.ASTOpOr && hd.NumArgs==2{
                    a,e:=s.manager.GetArg(child,0);if e!=nil{panic(e)}
                    b,e:=s.manager.GetArg(child,1);if e!=nil{panic(e)}
                    l,e:=s.Literal(a);if e!=nil{panic(e)};r,e:=s.Literal(b);if e!=nil{panic(e)}
                    println("ROWKIDS",s,l.Index(),r.Index())
                }};println("ROWARG"''')
            yield p,s
    def run(s):return ns['run'](s).replace("b'ROWMETA ')","b'ROWMETA ',b'ROWKIDS ')")
    panel(['probe'],patch,run)
