from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:exec(t.extractfile('driver.py').read())
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_internalizer.go';s=p.read_text();a='for index := uint32(0); index < count; index++ {'
    i=s.index(a,s.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp'))
    extra='''
    if basic && op==ast.ASTOpOr && count==2 && gateContext && !ast.ASTValidateHandles && !ast.ASTSourceDebug && !s.manager.Budget().InjectionArmed() && s.manager.TraceStream==nil {
        var children [2]ast.ASTHandle
        READ
        for _,child:=range children{
            if _,ok:=s.boundInstanceLiteral(child);ok{continue}
            if e:=s.Internalize(child,true);e!=nil{return e}
        }
        if _,ok:=s.boolVar.lookup(expression);ok{return nil}
        v,e:=s.mkBoolVar(expression,&header,false);if e!=nil{return e}
        args:=make([]SMTLiteral,2)
        for i,child:=range children{
            lit,ok:=s.boundInstanceLiteral(child);if !ok{lit,e=s.Literal(child);if e!=nil{return e}}
            args[i]=lit
        }
        if gate:=s.boolGate(v);gate!=nil{gate.literals=args}
        parent:=NewSMTLiteral(v,false)
        for _,lit:=range args{if e:=s.addGateClause([]SMTLiteral{parent,lit.Negated()});e!=nil{return e}}
        if e:=s.addGateClause([]SMTLiteral{parent.Negated(),args[0],args[1]});e!=nil{return e}
        if s.relevancy!=nil{
            handler:=smtRelevancyHandler{kind:smtRelevancyOr,target:expression}
            for _,child:=range children{if e:=s.relevancy.addLiteralWatch(child,true,&handler);e!=nil{return e}}
        }
        return nil
    }
'''
    read='for i:=range children{children[i],err=s.manager.GetArg(expression,uint32(i));if err!=nil{return err}}'
    if name=='cached':
        read='if s.orSyntax==nil{s.orSyntax=make([][3]ast.ASTHandle,64)};record:=&s.orSyntax[expression.Slot()%64];if record[0]==expression{copy(children[:],record[1:])}else{'+read+';*record=[3]ast.ASTHandle{expression,children[0],children[1]}}'
        q=pkg/'smtcore/smt_internalizer_state.go';yield q,q.read_text().replace('type SMTInternalizerState struct {','type SMTInternalizerState struct {\norSyntax [][3]ast.ASTHandle')
    yield p,s[:i]+extra.replace('READ',read)+s[i:]
def run(s):
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%3:]+modes[:i%3]").replace('for mode in modes:w.writerow','for mode in order:w.writerow')
    return s.replace('range(5):','range(6):').replace('((1,3),(4,8),(6,227))','((4,3),(8,5),(6,2))')
if __name__=='__main__':panel(['base','local','cached'],patch,run)
