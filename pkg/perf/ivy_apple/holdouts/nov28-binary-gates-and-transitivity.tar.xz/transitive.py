from pathlib import Path
from trial import panel
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_quantifier_stat.go';s=p.read_text().replace('candidateChecks ','studyTransitive bool\n\tcandidateChecks ',1)
    s=s.replace('result.caseSplitFactor = caseSplit.Value()','result.studyTransitive=isStudyTransitivity(g.manager,quantifier,body);result.caseSplitFactor = caseSplit.Value()')
    yield p,s+Path(__file__).with_name('transitive.go.txt').read_text()
    p=pkg/'smtcore/smt_quantifier_manager.go';s=p.read_text();a='return q.instantiate([]SMTQIQueueEntry{entry})\n\t}, q.state.resourceLimitsExceeded)';assert s.count(a)==1
    yield p,s.replace(a,'''stat:=q.registry.statistics[entry.Fingerprint.data]
        if stat.studyTransitive && stat.numInstancesCurrentBranch >= '''+str(int(name[1:]))+''' && entry.Cost<=q.registry.schedule.lazyThreshold{
            promote,e:=q.promoteUnsatEntry(entry);if e!=nil{return e};if !promote{
                entry.Instantiated=false;q.registry.schedule.delayedEntries=append(q.registry.schedule.delayedEntries,entry);return nil
            }
        }
        '''+a)
def run(s):
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%4:]+modes[:i%4]").replace('for mode in modes:w.writerow','for mode in order:w.writerow')
    return s.replace('range(5):','range(4):').replace('((1,3),(4,8),(6,227))','((4,3,1),(8,5),(6,2,227))')
if __name__=='__main__':panel(['base','t0','t4','t16'],patch,run)
