from trial import panel
def patch(pkg,name):
    if name=='base':return
    burst=int(name[1:])
    p=pkg/'smtcore/smt_qi_queue_schedule.go';s=p.read_text()
    a='type SMTQIQueueSchedule struct {';s=s.replace(a,a+'\n studyState *SMTInternalizerState')
    a='check := sinceLastCheck > 100'
    s=s.replace(a,'''if (i+1)%'''+str(burst)+'''==0 && len(q.newEntries)-(i+1)>='''+str(burst)+''' && q.studyState!=nil && !q.studyState.inconsistent && q.studyState.propagationHead<len(q.studyState.assignedLiterals){
            n:=copy(q.newEntries,q.newEntries[i+1:])
            clear(q.newEntries[n:]);q.newEntries=q.newEntries[:n]
            return nil
        }
        '''+a)
    yield p,s
    p=pkg/'smtcore/smt_quantifier_manager.go';s=p.read_text();a='return q.registry.schedule.instantiateNew(q.promoteUnsatEntry';assert s.count(a)==1
    yield p,s.replace(a,'q.registry.schedule.studyState=q.state;'+a)
def run(s):
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%4:]+modes[:i%4]").replace('for mode in modes:w.writerow','for mode in order:w.writerow')
    return s.replace('range(5):','range(4):').replace('((1,3),(4,8),(6,227))','((4,3),(8,5),(6,2))')
panel(['base','q4','q16','q64'],patch,run)
