from transitive import patch as trans
from trial import panel
def patch(pkg,name):
    if name=='base':return
    for p,s in trans(pkg,'t0'):
        if p.name=='smt_quantifier_stat.go':
            s=s.replace('studyTransitive bool','studyTransitive bool\n studyEdges *smtStudyEdges')
            s=s.replace('func isStudyTransitivity(m *ast.ASTManager, q, body ast.ASTHandle) bool','type smtStudyEdges struct{decl ast.ASTHandle; left,mid,right uint32; comm bool}\nfunc isStudyTransitivity(m *ast.ASTManager, q, body ast.ASTHandle) *smtStudyEdges')
            i=s.index('func isStudyTransitivity');s=s[:i]+s[i:].replace('return false','return nil')
            a=s.index('return a[0]==c[0]');b=s.index('\n',a)
            s=s[:a]+'if !('+s[a+7:b]+'){return nil};flags,e:=m.GetFuncDeclFlags(decl);if e!=nil{return nil};return &smtStudyEdges{decl,2-a[0],2-a[1],2-b[1],flags.Commutative}'+s[b:]
            s=s.replace('result.studyTransitive=isStudyTransitivity(g.manager,quantifier,body);','result.studyEdges=isStudyTransitivity(g.manager,quantifier,body);result.studyTransitive=result.studyEdges!=nil;')
        else:
            cond={'s8':'stat.numInstancesCurrentSearch>=8','s32':'stat.numInstancesCurrentSearch>=32','unit':'true'}[name]
            s=s.replace('stat.numInstancesCurrentBranch >= 0',cond)
            if name=='unit':
                a='promote,e:=q.promoteUnsatEntry(entry);if e!=nil{return e};if !promote{'
                assert a in s
                s=s.replace(a,'''t:=stat.studyEdges;v:=entry.Fingerprint.args;falsified:=0
                pairs:=[3][2]*SMTEnode{{v[t.left],v[t.mid]},{v[t.mid],v[t.right]},{v[t.left],v[t.right]}}
                for i,pair:=range pairs{
                    x,e:=q.checker.congruentEnodeWithFlags(t.decl,t.comm,pair[:]);if e!=nil{return e}
                    if x!=nil{a:=q.state.context.getAssignment(x.owner);if i==2 && a==lbool.False || i<2 && a==lbool.True{falsified++}}
                };if falsified<2{''')
        yield p,s
def run(s):
    s=s.replace("modes=['base','trial'];modes=modes[::1 if i%2==0 else -1]","order=modes[i%4:]+modes[:i%4]").replace('for mode in modes:w.writerow','for mode in order:w.writerow')
    return s.replace('range(5):','range(4):').replace('((1,3),(4,8),(6,227))','((4,3,1),(8,5),(6,2,227))')
if __name__=='__main__':panel(['base','s8','s32','unit'],patch,run)
