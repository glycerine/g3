from trial import panel
import tarfile
from pathlib import Path
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:
    ns={};exec(t.extractfile('observe.py').read().decode().replace('from driver import panel','').rsplit("if __name__==",1)[0],ns)
    src=next(ns['patch'](Path.cwd(),'probe'))[1];src=src[src.index('type StudySample struct'):src.index('func(r StudySample)End')]
    src+='func (r StudySample) finish()uint64{end:=r.read();syscall.Close(int(r.fd));runtime.UnlockOSThread(); if end-r.b<r.b-r.a{return 0};return end-r.b-(r.b-r.a)}'
def patch(pkg,name):
    p=pkg/'smtcore/smt_quantifier_manager.go';s=p.read_text().replace('import (','import ("runtime";"syscall";"unsafe";"os";',1)
    a='return q.instantiate([]SMTQIQueueEntry{entry})\n\t}, q.state.resourceLimitsExceeded)';assert s.count(a)==1
    s=s.replace(a,'''if StudyGoal {
            bad:=q.state.Inconsistent();sample:=StudyStart()
            e:=q.instantiate([]SMTQIQueueEntry{entry})
            work:=sample.finish();println("ROWBEGIN",bad,q.state.Inconsistent(),work)
            return e
        }
        '''+a)
    yield p,s+'\nvar StudyGoal bool\n'+src
def run(s):
    with tarfile.open('perf/ivy_apple/holdouts/nov27-ticket-cost-and-root-lifetimes.tar.xz') as t:src=t.extractfile('./templates.py').read().decode()
    ctx={};exec(src[:src.rindex("panel(['probe'],patch,run)")],ctx)
    return ctx['run'](s).replace('"github.com/glycerine/g3/pkg/ast/rewriter"','"github.com/glycerine/g3/pkg/smtcore"')
panel(['probe'],patch,run)
