from pathlib import Path
import tarfile,tempfile,difflib,subprocess as sp
import trial
from trial import panel
archive=Path('perf/ivy_apple/holdouts/nov27-ticket-cost-and-root-lifetimes.tar.xz')
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp)
    with tarfile.open(archive) as t:
        for f in ('children','operands','survivors','templates'):
            (d/(f+'.py')).write_bytes(t.extractfile('./'+f+'.py').read())
    p=d/'children.py';ns={'__file__':str(p)};exec(p.read_text().rsplit("panel(['probe'],patch,run)",1)[0],ns)
    def patch(pkg,name):
        obs=dict(ns['patch'](pkg,name))
        for p,v in trial.patch(pkg,name):
            diff=''.join(difflib.unified_diff(p.read_text().splitlines(True),v.splitlines(True),'a','b'))
            f=d/'merged';f.write_text(obs[p]);sp.run(['patch','--quiet',f],input=diff,text=True,check=True);obs[p]=f.read_text()
        return obs.items()
    def run(s):
        s=ns['run'](s).replace("out/'events'","out/(mode+str(rep)+'.events')").replace(' run(8,"probe",cpus[0],False)',' for rep in range(3):\n    for mode in modes[rep:]+modes[:rep]:run(8,mode,cpus[0],False)')
        return s
    panel(['base','local','cached'],patch,run)
