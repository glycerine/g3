from trial import panel
def patch(pkg,name):
    if name=='base':return
    p=pkg/'smtcore/smt_quantifier_manager.go';s=p.read_text()
    a='return q.instantiate([]SMTQIQueueEntry{entry})\n\t}, q.state.resourceLimitsExceeded)'
    assert s.count(a)==1
    yield p,s.replace(a,'''if q.state.Inconsistent() && entry.Cost<=q.registry.schedule.lazyThreshold {
            entry.Instantiated=false
            q.registry.schedule.delayedEntries=append(q.registry.schedule.delayedEntries,entry)
            return nil
        }
        '''+a)
def run(s):return s.replace('((1,3),(4,8),(6,227))','((4,3),(8,5),(6,2))')
if __name__=='__main__':panel(['base','trial'],patch,run)
