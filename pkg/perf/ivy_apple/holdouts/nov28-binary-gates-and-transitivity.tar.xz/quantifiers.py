import csv,collections,tarfile
from pathlib import Path
from trial import panel
with tarfile.open('perf/ivy_apple/holdouts/nov27-ticket-cost-and-root-lifetimes.tar.xz') as t:events=t.extractfile('./templates/events').read().decode().splitlines()
freq=collections.defaultdict(collections.Counter)
for r in events:
    a=r.split()
    if a[0]=='ROWGOAL':goal=tuple(map(int,a[1:]))
    elif a[0]=='ROWBEGIN':freq[goal][tuple(map(int,a[1:3]))]+=1
targets=[(0,0,0,0)]+[(*g,*q) for g,v in freq.items() for q,_ in v.most_common(8)]
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:
    c={};exec(t.extractfile('observe.py').read().decode().replace('from driver import panel','').split('if __name__==')[0],c)
    s=t.extractfile('paired.py').read().decode();c={'observe_patch':c['patch'],'census':c['run'],'Path':Path};exec(s[s.index('def run('):s.index('if __name__==')],c)
def patch(pkg,name):
    p=pkg/'smtcore/smt_quantifier_manager.go';s=p.read_text()
    a='return q.instantiate([]SMTQIQueueEntry{entry})\n\t}, q.state.resourceLimitsExceeded)'
    assert s.count(a)==1
    yield p,s.replace(a,'''if StudyDefer && entry.Fingerprint.data.Slot()==StudySlot && entry.Fingerprint.data.Generation()==StudyGeneration && entry.Cost<=q.registry.schedule.lazyThreshold{
            StudySeen++
            promote,e:=q.promoteUnsatEntry(entry);if e!=nil{return e}
            if !promote{StudyDelayed++;entry.Instantiated=false;q.registry.schedule.delayedEntries=append(q.registry.schedule.delayedEntries,entry);return nil}
        }
        '''+a)+'\nvar StudyDefer bool\nvar StudySlot,StudyGeneration,StudySeen,StudyDelayed uint32\n'
def run(s):
    s=c['run'](s)
    a=s.index('    for p,src in patch')
    s=s[:a]+"""    v=dst.read_text().replace('import (','import (study "github.com/glycerine/g3/pkg/smtcore";',1)
    v+='\\nvar studyBatch,studyIndex int\\nfunc init(){fmt.Sscanf(os.Getenv("DEFER_Q"),"%d/%d/%d/%d",&studyBatch,&studyIndex,&study.StudySlot,&study.StudyGeneration)}\\n'
    needle='counter:=StudyStart();res, err := s.decideZ3With(z3solver, finalCheck)';assert v.count(needle)==1
    v=v.replace(needle,'study.StudyDefer=batch==studyBatch && index+1==studyIndex;'+needle)
    needle='counter.End("frontend","decide",res==smt.Unsat,0,0)';v=v.replace(needle,needle+';if study.StudyDefer{println("GROUND","diagnostic","defer",true,study.StudySeen,study.StudyDelayed,0)};study.StudyDefer=false');dst.write_text(v)
"""+s[a:]
    i=s.index(' for case in [4,8,3,6]:')
    return s[:i]+''' for rep in range(2):
    for target in TARGETS[::1 if rep==0 else -1]:
        key='/'.join(map(str,target));os.environ.update(GROUND_UNIT='instructions',GROUND_SCOPE='outer',DEFER_Q=key,GROUND_OUT=str(out/(key.replace('/','-')+'-'+str(rep)+'.csv')))
        run(8,'probe',cpus[0],False)
'''.replace('TARGETS',repr(targets))
panel(['probe'],patch,run)
