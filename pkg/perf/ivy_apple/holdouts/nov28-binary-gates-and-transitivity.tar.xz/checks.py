from pathlib import Path
from trial import panel
import tarfile
import defer
source=Path(__file__).with_name('interleave.py').read_text();ns={};exec(source[:source.rindex("panel(['base'")],ns)
def patch(pkg,name):
    if name=='delay':return defer.patch(pkg,'trial')
    return ns['patch'](pkg,name)
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:
    ctx={}
    exec(t.extractfile('observe.py').read().decode().replace('from driver import panel','').split('if __name__==')[0],ctx)
    obs,census=ctx['patch'],ctx['run']
    s=t.extractfile('paired.py').read().decode()
    ctx={'observe_patch':obs,'census':census,'Path':Path};exec(s[s.index('def run('):s.index('if __name__==')],ctx)
def run(s):
    return ctx['run'](s).replace("['base','native']","modes").replace('for case in [4,8,3,6]:','for case in [4,8]:')
panel(['base','q4','q16','delay'],patch,run)
