from pathlib import Path
from trial import panel
s=Path(__file__).with_name('interleave.py').read_text();c={};exec(s[:s.rindex("panel(['base'")],c)
def run(s):
    i=s.index(' def measure(');s=s[:i]+' run(5,"q4",cpus[0],False)\n'
    return s.replace('assert (r.returncode,r.stdout,r.stderr)==',"(out/'stderr.txt').write_bytes(r.stderr);(out/'stdout.txt').write_bytes(r.stdout);assert (r.returncode,r.stdout,r.stderr)==")
panel(['q4'],c['patch'],run)
