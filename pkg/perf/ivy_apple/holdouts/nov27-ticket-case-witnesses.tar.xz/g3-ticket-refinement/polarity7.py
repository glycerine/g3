from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'witness7.py').read_text();exec(s[:s.index('with (w/')])
def audit(t,env):
 if isinstance(t,str):return env.get(t,False)
 op,*args=t
 if op=='let':
  bindings,body=args;return audit(body,dict(env,**{n:audit(v,env) for n,v in bindings}))
 if op=='!':return audit(args[0],env)
 if op=='forall':
  assert all(n not in env for n,sort in args[0]);audit(args[1],env);return True
 assert op!='exists'
 children=[audit(a,env) for a in args]
 if any(children):assert op in ('and','or'),op
 return any(children)
count=sum(audit(r,{}) for r in rules)
print(len(rules),'normalized rows;',count,'contain positive universal binders')
