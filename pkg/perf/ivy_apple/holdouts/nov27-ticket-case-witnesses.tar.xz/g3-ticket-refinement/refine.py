"""Measure model-guided congruence refinement on captured ground Ticket inputs."""
import argparse
import csv
from collections import defaultdict
from itertools import combinations
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path.cwd() / "perf/ivy_apple/goal_instances/finite_models"))
from syntax import fresh_names, parse, smt


def project(forms):
    output = []
    apps = {}
    names = fresh_names(forms, "refine!")
    sorts = {f[1]: f[-1] for f in forms if f[0] == "declare-fun" and f[2]}

    def visit(expr):
        if isinstance(expr, str):
            return expr
        op, *args = expr
        args = tuple(map(visit, args))
        if op not in sorts:
            return (op, *args)
        key = (op, args)
        if key not in apps:
            atom = next(names)
            apps[key] = atom
            output.append(("declare-const", atom, sorts[op]))
        return apps[key]

    for f in forms:
        if f[0] == "assert":
            output.append(("assert", visit(f[1])))
        elif f[0].startswith("declare-"):
            output.append(f)
        else:
            assert f[0] == "check-sat", f
    return output, apps


def lemma(a, b):
    args, res = a
    other, other_res = b
    eqs = [("=", x, y) for x, y in zip(args, other, strict=True) if x != y]
    return ("assert", ("=>", eqs[0] if len(eqs) == 1 else ("and", *eqs), ("=", res, other_res)))


def command(exe, forms):
    run = subprocess.run([exe, "-in"], input="\n".join(map(smt, forms))+"\n",
                         text=True, capture_output=True, timeout=60)
    if run.returncode or run.stderr:
        raise RuntimeError((run.returncode, run.stdout[-500:], run.stderr))
    return parse(run.stdout)


def trial(source, exe, control, mode, output):
    original = parse(source.read_text())
    expected, = command(control, original)
    base, apps = project(original)
    groups = defaultdict(list)
    terms = {}
    for (op, args), res in apps.items():
        groups[op].append((args, res))
        for t in (*args, res):
            terms[t] = None
    pairs = [(a,b) for g in groups.values() for a,b in combinations(g,2)]
    selected = set()
    if mode == "eager":
        selected.update(pairs)
    if mode == "sparse":
        selected.update((a,b) for a,b in pairs if sum(x!=y for x,y in zip(a[0],b[0]))==1)
    def equalities(expr):
        if isinstance(expr, tuple):
            if expr[0] == "=" and len(expr) == 3:
                yield frozenset(expr[1:])
            for child in expr[1:]:
                yield from equalities(child)
    if mode in ("mentioned","goal"):
        statements = base if mode=="mentioned" else base[-1:]
        relevant = {eq for f in statements if f[0]=="assert" for eq in equalities(f[1])}
        selected.update((a,b) for a,b in pairs if all(x==y or frozenset((x,y)) in relevant for x,y in zip(a[0],b[0],strict=True)))
    start = len(selected)
    for r in range(64):
        query = [*base, *(lemma(a,b) for a,b in pairs if (a,b) in selected), ("check-sat",)]
        answer, = command(exe, query)
        if answer == "unsat":
            break
        assert answer == "sat"
        # Replaying identical queries with this solver's default seed is deterministic.
        tag, values = command(exe, [*query, ("get-value",tuple(terms))])
        assert tag == "sat"
        values = dict(values)
        new = []
        for g in groups.values():
            seen = defaultdict(list)
            for app in g:
                args, res = app
                key = tuple(values[t] for t in args)
                for prev in seen[key]:
                    if values[prev[1]] != values[res]:
                        new.append((prev,app))
                seen[key].append(app)
        if not new:
            break
        assert selected.isdisjoint(new)
        selected.update(new)
    else:
        raise RuntimeError("refinement round limit")
    assert answer == expected and command(control,query) == [answer], (source, mode)
    if output:
        d = output / mode
        d.mkdir(exist_ok=True,parents=True)
        (d/source.name).write_text("\n".join(map(smt,query))+"\n")
    return [source.stem,mode,answer,len(apps),len(pairs),start,r,len(selected)]


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("inputs",type=Path)
    p.add_argument("solver")
    p.add_argument("control")
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    w = csv.writer(sys.stdout)
    w.writerow("query mode answer applications possible_pairs initial_pairs retries final_pairs".split())
    for source in sorted(args.inputs.glob("*-goal.smt2")):
        for mode in ("lazy","sparse","eager","mentioned","goal"):
            w.writerow(trial(source,args.solver,args.control,mode,args.output))
            sys.stdout.flush()
