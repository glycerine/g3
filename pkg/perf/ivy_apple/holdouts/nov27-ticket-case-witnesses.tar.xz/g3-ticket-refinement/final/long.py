from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd()
s=Path('/tmp/g3-selective/final/long.py').read_text();exec(s[s.index("s=Path('/tmp/g3-plan-budget/long.py')"):])
