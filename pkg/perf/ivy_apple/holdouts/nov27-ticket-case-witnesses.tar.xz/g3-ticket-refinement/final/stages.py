from pathlib import Path
import subprocess,os,csv
w=Path(__file__).resolve().parent;p=Path.cwd()
for eng,tags in [('g3','xtrace_off'),('native','xtrace_off,classic_z3')]:
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags',tags,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay','/tmp/g3-arith-next/final/arith-stage.json','-o',w/('arith-stage-'+eng),'./cmd/goivy_check'],cwd=p/'build/.boolean-enode-cost/frontend/goivy',check=True)
s=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();s=s[s.index('rank=Path'):].replace('for nr in [14,15]','for nr in [6,3]').replace('range(5)','range(3)');exec(s)
