from pathlib import Path
import os,sys,csv,subprocess,time
w=Path(__file__).resolve().parent;p=Path.cwd()
rank=Path('/tmp/g3-reduction-rows');names=(rank/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
stem=sys.argv[1];modes=sys.argv[2:];cpu=os.getenv('CPU','20')
with (w/(stem+'.csv')).open('w') as f:
 o=csv.writer(f);o.writerow('case round mode instructions ms'.split())
 for nr in map(int,os.getenv('CASES','2 3 4 12').split()):
  name=names[nr-1];ref=rank/'compat'/str(nr)/'1/native'
  for i in range(int(os.getenv('ROUNDS','7'))):
   for mode in modes[i%len(modes):]+modes[:i%len(modes)]:
    stat=w/(stem+'.stat');start=time.monotonic()
    r=subprocess.run(['taskset','-c',cpu,'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/mode,ex/name],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,timeout=100)
    elapsed=(time.monotonic()-start)*1000
    assert (r.returncode,r.stdout,r.stderr)==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,mode,r.stderr[-250:])
    n,=[int(z[0]) for z in csv.reader(stat.open()) if len(z)>4 and z[2]=='instructions:u' and float(z[4])==100]
    o.writerow([name,i,mode,n,round(elapsed,3)]);f.flush()
