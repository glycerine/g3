from pathlib import Path
import subprocess as sp,sys
w=Path(__file__).resolve().parent;p=Path.cwd();older=Path('/tmp/g3-ticket-splits/final');mode=sys.argv[1]
if mode=='regular':
 front=p/'build/.boolean-enode-cost/frontend/goivy';j=Path('/tmp/g3-ticket-first/validation/final.json');ex='release';args=['-modfile',p/'build/.boolean-enode-cost/heap/study.mod']
else:
 front=p/'build/.boolean-enode-cost/apple-source/goivy';j=older/'release-apple.json';ex='apple-release';args=[]
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,*args,'-o',w/ex,'./cmd/goivy_check'],cwd=front,check=True)
