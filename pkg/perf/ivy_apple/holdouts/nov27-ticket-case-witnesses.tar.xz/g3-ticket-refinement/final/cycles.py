from pathlib import Path
import sys
w=Path(__file__).resolve().parent;s=(w/'whole.py').read_text().replace("'instructions:u','--'","'instructions:u,cycles:u','--'").replace("'case round mode instructions ms'","'case round mode instructions ms cycles'").replace('o.writerow([name,i,mode,n,round(elapsed,3)])',"ct={r[2]:r[0] for r in csv.reader(stat.open()) if len(r)>4 and float(r[4])==100};o.writerow([name,i,mode,n,round(elapsed,3),ct['cycles:u']])");exec(s)
