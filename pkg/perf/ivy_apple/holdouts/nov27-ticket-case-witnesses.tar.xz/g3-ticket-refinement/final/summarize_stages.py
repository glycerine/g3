from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
totals=collections.defaultdict(int);goals=collections.defaultdict(list);first=set()
for r in csv.DictReader((w/'arith-stages.csv').open()):
 case=r['case'];eng=r['engine'];rd=r['round'];b=r['batch'];g=r['goal'];phase=r['phase'];n=int(r['instructions'])
 if phase=='push':
  key=case,eng,rd,b
  phase='later push' if key in first else 'first push';first.add(key)
 totals[case,phase,eng,rd]+=n;goals[case,phase,b,g,eng].append(n)
with (w/'stage-totals.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','phase','g3','linked','difference'])
 for k in sorted(set((case,ph) for case,ph,_,_ in totals)):
  v=[statistics.median(totals[k+(en,str(i))] for i in range(3)) for en in ('g3','native')]
  out.writerow([*k,*v,v[0]-v[1]])
with (w/'stage-goals.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','phase','batch','goal','g3','linked','difference'])
 for k in sorted(set(key[:-1] for key in goals)):
  v=[statistics.median(goals[k+(en,)]) if goals[k+(en,)] else 0 for en in ('g3','native')]
  out.writerow([*k,*v,v[0]-v[1]])
