from pathlib import Path
import os,sys,subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd()
exec(Path('/tmp/g3-interval-products/verify.py').read_text())
