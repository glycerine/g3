from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'reuse.py').read_text();k='save(path,s)\nj=w/'
s=s.replace(k,'''s=s.replace('trialMode=="warm" || trialMode=="reuse" && mode==trialSearch || trialMode=="agree" && mode==predicateAgreementSearch','trialMode!=""')
save(path,s)
path=p/'api/internal/order/ground_instance_pool.go';s=Path(ov['Replace'][str(path)]).read_text().replace('import (','import ("os";',1).replace('len(by[st]) < 3 || p.trialWide','len(by[st]) < 3 || p.trialWide && caps!="narrow" && caps!="congruence"').replace('if p.trialWide{return 256}', 'if p.trialWide && caps!="narrow" && caps!="congruence"{return 256}')
save(path,s+'\\nvar caps=os.Getenv("SHARED_BIND")\\n')
path=p/'api/internal/order/ground_instance_encoding.go';s=Path(ov['Replace'][str(path)]).read_text().replace('(!p.trialWide || len(list)>=128)','(!p.trialWide || caps=="narrow" || caps=="tuple" || len(list)>=128)').replace('if p.trialWide && len(a)>1','if p.trialWide && caps!="narrow" && caps!="tuple" && len(a)>1')
save(path,s)
j=w/''')
s=s.replace("'reuse-stage.json'","'caps-stage.json'").replace("'reuse.json'","'caps.json'").replace("'reuse-stage'","'caps-stage'").replace("else 'reuse')","else 'caps')").replace("'reuse-stage.csv'","'caps-stage.csv'").replace("['off','eq','reuse','warm','agree']","['off','narrow','tuple','congruence','warm']").replace("('reuse-'+path.name)","('caps-'+path.name)")
exec(s.replace("reuse-stage.csv","caps-stage.csv"))
