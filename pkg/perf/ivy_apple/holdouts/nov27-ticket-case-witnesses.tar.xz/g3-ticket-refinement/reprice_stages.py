from pathlib import Path
import os,sys,csv,subprocess as sp
w=Path(__file__).resolve().parent;exe=sys.argv[1];modes=sys.argv[2:]
s=(w/'stage.py').read_text();s=s[s.index('rank=Path'):].replace("w/'stage.csv'","w/(exe+'-final.csv')").replace("w/'stage'","w/exe").replace("['off','eq','lazy','deep','deep-eager']","modes");exec(s)
