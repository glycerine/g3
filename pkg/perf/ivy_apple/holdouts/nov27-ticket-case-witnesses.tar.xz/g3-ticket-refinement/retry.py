from pathlib import Path
import os,json,subprocess as sp,csv
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();stage=os.getenv('METER')=='1'
ov=json.loads((w/'facts.json').read_text());ov['Replace'].update(json.loads(Path('/tmp/g3-arith-next/final/arith-stage.json').read_text())['Replace'] if stage else {})
def save(path,s):
 f=w/('retry-'+path.name);f.write_text(s);ov['Replace'][str(path)]=str(f)
path=p/'api/internal/order/ground_instance_pool.go';s=Path(ov['Replace'][str(path)]).read_text().replace('trialWide bool','trialExtra bool\n trialWide bool').replace('factMode=="facts"){key','factMode=="facts" || p.trialExtra){key')
save(path,s+'\nfunc(p *GroundInstancePool) SetTrialExtra(x bool){p.trialExtra=x}\n')
path=p/'api/api_predicate_agreement.go';s=Path(ov['Replace'][str(path)]).read_text().replace('trialMode=="warm" || trialMode!="" && mode==trialSearch || trialMode=="agree" && mode==predicateAgreementSearch','trialMode!=""')
k='proved, err := private.proveInstances';s=s.replace(k,'if private.pool!=nil{private.pool.SetTrialExtra(false)};'+k)
k='if private==&local';s=s.replace(k,'''if !proved && err==nil && mode==trialSearch && (trialMode=="retry" || trialMode=="retry-sat") && !m.ResourceLimit().CancelFlag() && private.pool!=nil && !private.pool.Disabled() && (trialMode!="retry-sat" || private.sat.solver!=nil){private.pool.SetTrialExtra(true);proved,err=private.proveInstances(src,m,assertions,min(steps,2_000_000),1,mode)}
 '''+k)
save(path,s)
j=w/('retry-stage.json' if stage else 'retry.json');j.write_text(json.dumps(ov));out=w/('retry-stage' if stage else 'retry')
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',out,'./cmd/goivy_check'],cwd=front,check=True)
if stage:
 s=(w/'stage.py').read_text();s=s[s.index('rank=Path'):].replace("w/'stage.csv'","w/'retry-stage.csv'").replace("w/'stage'","out").replace("['off','eq','lazy','deep','deep-eager']","['off','warm','facts','retry','retry-sat']");exec(s)
