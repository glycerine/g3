from pathlib import Path
import csv,collections,sys,itertools,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent
sys.path.insert(0,str(p.parent/'build/python'));import z3
sys.path.insert(0,str(p/'perf/ivy_apple/goal_instances/finite_models'));from syntax import parse,smt
src=Path('/tmp/g3-ticket-heap/obligations/3-7-1.smt2');source=parse(src.read_text());old={f[1] for f in source if f[0]=='declare-fun'}
goal=z3.Then('simplify',z3.With(z3.Tactic('nnf'),mode='full'))(z3.parse_smt2_file(str(src)))[0];solver=z3.Solver();solver.add(*list(goal));forms=parse(solver.sexpr())
decl=[f for f in forms if f[0].startswith('declare')];rules=[f[1] for f in forms if f[0]=='assert']
sig={f[1]:(f[2],f[3]) for f in decl if f[0]=='declare-fun'}
def instantiate(x,env,pool):
 if isinstance(x,str):return env.get(x,x)
 op,*args=x
 if op=='forall':
  bind,body=args;rows=[instantiate(body,dict(env,**dict(zip([n for n,_ in bind],v))),pool) for v in itertools.product(*(pool.get(st,()) for n,st in bind))]
  return ('and',*rows) if rows else 'true'
 if op=='let':
  bindings,body=args;return instantiate(body,dict(env,**{n:instantiate(v,env,pool) for n,v in bindings}),pool)
 if op=='!':return instantiate(args[0],env,pool)
 assert op!='exists'
 return (op,*(instantiate(y,env,pool) for y in args))
def apps(t,pool):
 if isinstance(t,str):return
 if t[0] in sig and t[0] not in old and sig[t[0]][1]!='Bool':pool[sig[t[0]][1]].add(t)
 for a in t[1:]:apps(a,pool)
def run(pool):
 rows=[instantiate(x,{},pool) for x in rules];text='\n'.join(map(smt,[*decl,*[('assert',r) for r in rows],('check-sat',)]))+'\n'
 answers=[sp.run([e,'-in'],input=text,text=True,capture_output=True,timeout=90,check=True).stdout.strip() for e in (p.parent/'build/z3',Path('/tmp/g3-ticket-heap/g3-cli'))];assert answers[0]==answers[1] and answers[0] in ('sat','unsat')
 return rows,text,answers[0]
with (w/'witness7.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['seed','round','terms','bytes','answer'])
 for mode in ('facts','original','all'):
  pool=collections.defaultdict(set)
  for n,(domain,st) in sig.items():
   if domain or st=='Bool':continue
   if mode=='all' or mode=='original' and (n in old or '!' in n and n.startswith('|')) or mode=='facts' and '!' in n and n.startswith('|'):pool[st].add(n)
  if mode=='facts':
   for r in rules:
    atom=r[1] if isinstance(r,tuple) and r[0]=='not' else r
    if isinstance(atom,tuple) and sig.get(atom[0],(None,None))[1]=='Bool':
     for x in atom[1:]:
      if x in sig and sig[x][0]==() and sig[x][1]!='Bool':pool[sig[x][1]].add(x)
  for i in range(2):
   rows,text,a=run({k:sorted(v,key=repr) for k,v in pool.items()});out.writerow([mode,i,sum(map(len,pool.values())),len(text),a]);f.flush()
   if a=='unsat':break
   for r in rows:apps(r,pool)
