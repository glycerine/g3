from pathlib import Path
import os,csv,subprocess as sp,time,sys
w=Path(__file__).resolve().parent;rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');names=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
modes=os.getenv('MODES','off prefix either initial').split()
with (w/(os.getenv('STEM','policy')+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round policy status instructions ms'.split())
 for nr in map(int,os.getenv('CASES','6 2 3 4 8 5 12 7').split()):
  case=names[nr-1];d=rank/'compat'/str(nr)/'1/native';expect=(codes[case],(d/'stdout').read_bytes(),(d/'stderr').read_bytes())
  for i in range(int(os.getenv('ROUNDS','3'))):
   for mode in modes[i%len(modes):]+modes[:i%len(modes)]:
    stat=w/(os.getenv('STEM','policy')+'.stat');start=time.monotonic()
    r=sp.run(['taskset','-c',os.getenv('CPU','16'),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/os.getenv('EXE','shared'),ex/case],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1',SHARED_BIND='' if mode=='off' else mode),capture_output=True,timeout=120)
    n,=[int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100]
    out.writerow([nr,i,mode,'match' if (r.returncode,r.stdout,r.stderr)==expect else 'different',n,round(1000*(time.monotonic()-start),2)]);f.flush()
