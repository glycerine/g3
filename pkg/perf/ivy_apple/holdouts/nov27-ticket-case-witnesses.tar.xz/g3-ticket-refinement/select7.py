from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'witness7.py').read_text()
s=s.replace("for mode in ('facts','original','all'):","for mode in ('facts',):").replace("w/'witness7.csv'","w/'select7.csv'")
a=s.index('  for i in range(2):')
s=s[:a]+'''  base={k:sorted(v,key=repr) for k,v in pool.items()}
  rows,_,_=run(base);extra=collections.defaultdict(set)
  for r in rows:apps(r,extra)
  for sort,candidates in extra.items():
   for term in sorted(candidates,key=repr):
    q={k:list(v) for k,v in base.items()};q[sort].append(term)
    _,text,ans=run(q)
    out.writerow([smt(term),0,sum(map(len,q.values())),len(text),ans]);f.flush()
'''
exec(s)
