from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'witness7.py').read_text().replace("for mode in ('facts','original','all'):","for mode in ('facts',):").replace("w/'witness7.csv'","w/'min7.csv'")
s=s.replace("if a=='unsat':break",'''if a=='unsat':
    for st,v in pool.items():
     for term in sorted(v,key=repr):
      v.remove(term);rr,tx,ans=run({k:sorted(z,key=repr) for k,z in pool.items()})
      if ans!='unsat':v.add(term)
    rr,tx,ans=run({k:sorted(z,key=repr) for k,z in pool.items()});assert ans=='unsat'
    out.writerow(['minimal',i,sum(map(len,pool.values())),len(tx),ans])
    (w/'minimal7.smt2').write_text(tx)
    (w/'minimal7.txt').write_text(repr(pool))
    break''')
exec(s)
