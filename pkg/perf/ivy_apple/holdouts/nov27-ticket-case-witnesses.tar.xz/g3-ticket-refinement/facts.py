from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'reuse.py').read_text()
s=s.replace("if trialMode==\"\" || trialMode==\"agree\" ||","if trialMode==\"\" || trialMode==\"agree\" ||")
s=s.replace("save(path,s)\nj=w/",'''s=s.replace('trialMode=="reuse" && mode==trialSearch','trialMode!="" && mode==trialSearch')
save(path,s)
path=p/'api/internal/order/ground_instance_pool.go';s=Path(ov['Replace'][str(path)]).read_text().replace('import (','import ("os";',1)
k='if err := p.join(key, n); err != nil {'
s=s.replace(k,'if p.trialWide && (factMode=="positive" || factMode=="negative" || factMode=="facts"){key,n=p.trialWitnesses(key,n,limit)};'+k)
save(path,s+'\\nvar factMode=os.Getenv("SHARED_BIND")\\n'+(w/'facts.go.txt').read_text())
j=w/''')
s=s.replace("'reuse-stage.json'","'facts-stage.json'").replace("'reuse.json'","'facts.json'").replace("'reuse-stage'","'facts-stage'").replace("else 'reuse')","else 'facts')").replace("'reuse-stage.csv'","'facts-stage.csv'").replace("['off','eq','reuse','warm','agree']","['off','reuse','negative','positive','facts']").replace("('reuse-'+path.name)","('facts-'+path.name)")
exec(s.replace("reuse-stage.csv","facts-stage.csv"))
