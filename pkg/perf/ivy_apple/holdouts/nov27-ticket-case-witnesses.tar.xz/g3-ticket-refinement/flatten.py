from pathlib import Path
w=Path(__file__).resolve().parent
base=(w/'stage.py').read_text()
a=base.index("dest=w/out;")
base=base[:a]+'''if path.name=='api_predicate_agreement.go':
  start=s.index('eq:=false'); end=s.index('return trialMode==',start)
  s=s[:start]+(w/'flatten.go.txt').read_text()+s[end:]
 '''+base[a:]
for a,b in [('stage-search','flat-search'),('stage-predicate','flat-predicate'),('stage.json','flat.json'),('stage.csv','flat.csv'),("w/'stage'","w/'flat'")]:base=base.replace(a,b)
exec(base.replace('arith-flat.json','arith-stage.json'))
