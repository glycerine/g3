from pathlib import Path
import csv,subprocess as sp,os
w=Path(__file__).resolve().parent;p=Path.cwd()
files=[Path('/tmp/g3-ticket-heap/obligations/3-7-1.smt2'),w/'core7.smt2',w/'minimal7.smt2']
with (w/'price7.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['engine','case','round','instructions_per_check','answer'])
 for i in range(5):
  for path in files[i%3:]+files[:i%3]:
   txt=path.read_text().split('(check-sat)')[0]+'(check-sat)\n'
   for e,exe in [('go',Path('/tmp/g3-ticket-heap/g3-cli')),('native',p.parent/'build/z3')][::1 if i%2==0 else -1]:
    stat=w/'price7.stat';r=sp.run(['taskset','-c','30','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,'smt.macro_finder=true','-in'],input=('(reset)\n'.join([txt]*5)),text=True,capture_output=True,check=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
    assert r.stdout.split()==['unsat']*5 and not r.stderr
    n,=[int(row[0]) for row in csv.reader(stat.open()) if len(row)>4 and row[2]=='instructions:u' and float(row[4])==100];o.writerow([e,path.stem,i,n/5,'unsat']);f.flush()
