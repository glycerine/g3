"""Price additional witnesses from the submitted signature using independent replay."""
from pathlib import Path
import csv,subprocess as sp,sys,itertools
w=Path(__file__).resolve().parent;previous=Path('/tmp/g3-ticket-heap');src=(previous/'ground.py').read_text()
s=src[src.index('  t=Terms();'):src.index("   dest=w/'ground-inputs'")]
s=s.replace("  for mode in ('ground','goal','one-extra'):",'''  candidates=[t.node(a) for a,st in sig.items() if t.node(a) not in cs.get(st,[])]
  def build(extras):
   mode='goal' ''')
a=s.index("   if mode=='one-extra':");b=s.index('   keep=[]',a);s=s[:a]+"   for node in extras:pools.setdefault(sig[t.terms[node]],[]).append(node)\n"+s[b:]
s+='''   return text,ni
  def solve(extras):
   text,ni=build(extras);res=sp.run([native,'-in'],input=text,text=True,capture_output=True,check=True,timeout=45);answer=res.stdout.strip();assert answer in ('sat','unsat') and not res.stderr
   return answer,ni,text
  def record(method,extras,answer,ni,text):
   if method=='all' or answer=='unsat':
    ctl=sp.run([previous/'g3-cli','-in'],input=text,text=True,capture_output=True,check=True,timeout=45)
    assert ctl.stdout.strip()==answer and not ctl.stderr
   o.writerow([f.stem,method,' '.join(t.terms[x] for x in extras),ni,answer]);out.flush()
  a,n,text=solve(candidates);record('all',candidates,a,n,text)
  if a!='unsat':continue
  small=candidates[:]
  for x in candidates:
   trial=[j for j in small if x!=j];a,n,text=solve(trial)
   if a=='unsat':small=trial
  a,n,text=solve(small);record('minimal',small,a,n,text)
  if len(small)>2:continue
  for x in itertools.combinations(candidates,1):
   a,n,text=solve(x);record('single',x,a,n,text)
'''
d='''import functools,collections,itertools,csv,sys,subprocess,os
sys.path.insert(0,'/tmp/g3-ticket-focus/reuse');from analyze import Terms,parse
native=Path.cwd().parent/'build/z3'
with (w/'extras.csv').open('w') as out:
 o=csv.writer(out);o.writerow(['query','method','extras','instances','answer'])
 for f in sorted((previous/'obligations').glob('*.smt2')):
  if f.stem not in ('3-3-55','3-4-55','3-4-56','3-5-56','3-7-1'):continue
'''
exec(d+s)
