from pathlib import Path
import csv,json,subprocess as sp,os
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'model.json').read_text());ov['Replace'].update(json.loads(Path('/tmp/g3-arith-next/final/arith-stage.json').read_text())['Replace'])
for path,out in [(p/'api/api_ground_instances.go','stage-search.go'),(p/'api/api_predicate_agreement.go','stage-predicate.go')]:
 s=Path(ov['Replace'][str(path)]).read_text()
 if 'ground_instances' in path.name:
  s=s.replace('type groundInstanceSolver struct {','type groundInstanceSolver struct {\n isTrial bool').replace('if mode==trialSearch{s.pool','if mode==trialSearch{s.isTrial=true;s.pool')
  s=s.replace('const maxDecisionLevel = 256','maxDecisionLevel:=uint32(256);if s.isTrial && (trialMode=="deep" || trialMode=="deep-eager"){maxDecisionLevel=4096}')
  s=s.replace('trialMode=="lazy-log"', 'trialMode=="deep"').replace('if attempt<6 && result==','if s.isTrial && attempt<6 && result==')
  k='if err := s.sat.solver.PopToBaseLevel(); err != nil {';at=s.index(k,s.index('for attempt:=0'));s=s[:at]+'if s.isTrial {println("TRIAL-SAT",attempt,int(result),q.Variables,len(q.Clauses))};'+s[at:]
 else:
  s=s.replace('mode==trialSearch && (trialMode=="log" || trialMode=="lazy-log")','mode==trialSearch')
 dest=w/out;dest.write_text(s);ov['Replace'][str(path)]=str(dest)
j=w/'stage.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'stage','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');name=(rank/'compat.txt').read_text().splitlines()[2];ref=rank/'compat/3/1/native';expect=int(next(x['exit'] for x in csv.DictReader((rank/'ranking.csv').open()) if x['case']==name))
with (w/'stage.csv').open('w') as f:
 o=csv.writer(f);o.writerow('mode round batch goal phase instructions trials'.split())
 for i in range(3):
  for mode in ['off','eq','lazy','deep','deep-eager'][i:]+['off','eq','lazy','deep','deep-eager'][:i]:
   r=sp.run(['taskset','-c','30',w/'stage',ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1',SHARED_BIND='' if mode=='off' else mode),capture_output=True)
   rest=bytearray();trials=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'STAGE-COUNT '):
     _,b,g,ph,n,empty,en,active,ns=l.decode().split();assert en==active;o.writerow([mode,i,b,g,ph,n,';'.join(trials)]);trials=[]
    elif l.startswith(b'TRIAL'):trials.append(l.decode().strip())
    else:rest.extend(l)
   assert (r.returncode,r.stdout,rest)==(expect,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),rest[-500:]
   f.flush()
