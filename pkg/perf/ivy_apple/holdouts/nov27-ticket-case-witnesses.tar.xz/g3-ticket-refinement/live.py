from pathlib import Path
import json,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-arm-pass/release.json').read_text())
def save(path,s):
 b=w/('live-'+path.name);b.write_text(s);ov['Replace'][str(path)]=str(b)
path=p/'api/internal/order/ground_instance_pool.go';s=path.read_text().replace('installed                 map','trialWide bool\n installed                 map').replace('if len(by[st]) < 3 {','if len(by[st]) < 3 || p.trialWide {').replace('min(comb, 32)','min(comb, p.capTrialTuples())')
save(path,s+'\nfunc(p *GroundInstancePool) EnableWideTrial(){p.trialWide=true}\nfunc(p *GroundInstancePool)capTrialTuples()int{if p.trialWide{return 256};return 32}\n')
path=p/'api/internal/order/ground_instance_encoding.go';s=path.read_text().replace('if len(list) >= 16 {','if len(list)>=16 && (!p.trialWide || len(list)>=128){')
k='other := g.arguments[ot.start : ot.start+ot.count]';assert s.count(k)==1;s=s.replace(k,k+'\n if p.trialWide && len(a)>1 {different:=0;for j,x:=range a{if x!=other[j]{different++}};if different>1{continue}}')
save(path,s)
path=p/'api/api_ground_instances.go';s=path.read_text().replace('predicateAgreementSearch\n','predicateAgreementSearch\n trialSearch\n',1)
k='observed := mode';s=s.replace(k,'if mode==trialSearch{s.pool.EnableWideTrial()}\n '+k);save(path,s)
path=p/'api/api_predicate_agreement.go';s=path.read_text().replace('import (','import ("os";',1)
k='if !guardedPredicateAgreement(m, assertions[len(assertions)-1]) {\n\t\treturn false, nil\n\t}'
assert k in s
s=s.replace(k,'''mode:=predicateAgreementSearch
 if !guardedPredicateAgreement(m, assertions[len(assertions)-1]) {
 if trialMode=="" || !trialCases(m,assertions[len(assertions)-1]){return false,nil}
 mode=trialSearch
 }''').replace('1, predicateAgreementSearch)','1, mode)').replace('err = errors.Join(err, private.close())','if mode==trialSearch && trialMode=="log"{println("TRIAL",proved)};err = errors.Join(err, private.close())')
s+='''
var trialMode=os.Getenv("SHARED_BIND")
func trialCases(m *ast.ASTManager, goal ast.ASTHandle)bool{
 limit:=4; root,h,ok:=(signedRefutationGoal{term:goal}).unwrap(m,&limit)
 if !ok || !root.negated || h.Family!=m.BasicFamilyID() || h.DeclKind!=ast.ASTOpImplies || h.NumArgs!=2{return false}
 a,_:=m.GetArg(root.term,0); b,_:=m.GetArg(root.term,1); ah,_:=m.NodeHeader(a);bh,_:=m.NodeHeader(b)
 if ah.Family!=m.BasicFamilyID() || ah.DeclKind!=ast.ASTOpAnd || bh.Family!=m.BasicFamilyID() || bh.DeclKind!=ast.ASTOpOr || bh.NumArgs>8{return false}
 eq:=false
 for i:=range bh.NumArgs{v,_:=m.GetArg(b,i);hdr,_:=m.NodeHeader(v);if hdr.Family!=m.BasicFamilyID() || hdr.DeclKind!=ast.ASTOpAnd || hdr.NumArgs>8{return false}
 for j:=range hdr.NumArgs{x,_:=m.GetArg(v,j);xh,_:=m.NodeHeader(x);if xh.Family==m.BasicFamilyID() && xh.DeclKind==ast.ASTOpEq{eq=true}}
 }
 return trialMode!="eq" || eq
}
'''
save(path,s);j=w/'live.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'live','./cmd/goivy_check'],cwd=front,check=True)
