from pathlib import Path
import csv,json,concurrent.futures,os,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());path=p/'api/api_predicate_agreement.go';s=path.read_text();k='return p.guardedCases.proveInstances(p.source, m, assertions, steps, 1, guardedCaseSearch)';assert s.count(k)==1
s=s.replace(k,'yes,e:='+k[len('return '):]+';println("CASE-RESULT",yes);return yes,e');dest=w/'hits-predicate.go';dest.write_text(s);ov['Replace'][str(path)]=str(dest);j=w/'hits.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'hits','./cmd/goivy_check'],cwd=front,check=True)
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
def run(n):
 case=cases[n-1];ref=rank/'compat'/str(n)/'1/native'
 r=sp.run([w/'hits',ex/case],cwd=w/'final',env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
 y=r.stderr.count(b'CASE-RESULT true\n');no=r.stderr.count(b'CASE-RESULT false\n');err=r.stderr.replace(b'CASE-RESULT true\n',b'').replace(b'CASE-RESULT false\n',b'')
 assert (r.returncode,r.stdout,err)==(codes[case],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(case,r.returncode,err[-250:])
 return [n,case,y,no]
with concurrent.futures.ThreadPoolExecutor(6) as pool,(w/'hits.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['n','case','proved','inconclusive'])
 for row in pool.map(run,range(1,len(cases)+1)):o.writerow(row);f.flush()
