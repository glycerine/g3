from pathlib import Path
import json,subprocess as sp,os
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
stage=os.getenv('METER')=='1'
ov=json.loads((w/'live.json').read_text())
if stage:ov['Replace'].update(json.loads(Path('/tmp/g3-arith-next/final/arith-stage.json').read_text())['Replace'])
def save(path,s):
 dest=w/('reuse-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
path=p/'api/api_order_abstraction.go';s=path.read_text().replace('instances          *groundInstanceSolver','instances          *groundInstanceSolver\n casePool *groundInstanceSolver')
i=s.index('if b.state.instances != nil {');j=s.index('\n\t}',i)+3;s=s[:j]+'\n'+s[i:j].replace('state.instances','state.casePool')+s[j:]
s=s.replace('return provePredicateAgreement(s, parent, assertions, maxSteps)','return trialAgreement(p,s, parent, assertions, maxSteps)')
save(path,s)
path=p/'api/api_predicate_agreement.go';s=(w/'flat-predicate.go').read_text()
s=s.replace('func provePredicateAgreement(src','func trialAgreement(state *orderProofState,src',1).replace('if trialMode=="" ||','if trialMode=="" || trialMode=="agree" ||',1)
k='var private groundInstanceSolver';s=s.replace(k,'''var local groundInstanceSolver
 private:=&local
 if trialMode=="warm" || trialMode=="reuse" && mode==trialSearch || trialMode=="agree" && mode==predicateAgreementSearch{
 if state.casePool==nil{state.casePool=new(groundInstanceSolver)};private=state.casePool}
 ''').replace('if mode==trialSearch{println("TRIAL",proved)};err = errors.Join(err, private.close())','if private==&local{err=errors.Join(err,private.close())}')
save(path,s)
j=w/('reuse-stage.json' if stage else 'reuse.json');j.write_text(json.dumps(ov));out=w/('reuse-stage' if stage else 'reuse')
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',out,'./cmd/goivy_check'],cwd=front,check=True)
if stage:
 s=(w/'stage.py').read_text();s=s[s.index('rank=Path'):].replace('w/\'stage.csv\'','w/\'reuse-stage.csv\'').replace("w/'stage'","out").replace("['off','eq','lazy','deep','deep-eager']","['off','eq','reuse','warm','agree']");import csv;exec(s)
