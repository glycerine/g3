from pathlib import Path
import sys,re,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'perf/ivy_apple/goal_instances/finite_models'));from syntax import parse,smt
forms=parse((w/'minimal7.smt2').read_text());decl=[f for f in forms if f[0].startswith('declare')]
def conjuncts(t):
 if isinstance(t,tuple) and t[0]=='and':
  for child in t[1:]:yield from conjuncts(child)
 else:yield t
rows=list(dict.fromkeys(c for f in forms if f[0]=='assert' for c in conjuncts(f[1])))
text='\n'.join(map(smt,[('set-option',':produce-unsat-cores','true'),*decl,*[('assert',('!',row,':named','proof!'+str(i))) for i,row in enumerate(rows)],('check-sat',),('get-unsat-core',)]))
native=p.parent/'build/z3';r=sp.run([native,'smt.core.minimize=true','-in'],input=text,text=True,capture_output=True,check=True);assert r.stdout.startswith('unsat\n');ids=sorted(map(int,re.findall(r'proof!(\d+)',r.stdout)))
core='\n'.join(map(smt,[*decl,*[('assert',rows[i]) for i in ids],('check-sat',)]))
for solver in (native,'/tmp/g3-ticket-heap/g3-cli'):
 assert sp.run([solver,'-in'],input=core,text=True,capture_output=True,check=True).stdout.strip()=='unsat'
(w/'core-ground7.smt2').write_text(core);(w/'core-ground7.txt').write_text(f'{len(rows)} unique conjuncts; {len(ids)} core conjuncts; {len(core)} bytes\n')
