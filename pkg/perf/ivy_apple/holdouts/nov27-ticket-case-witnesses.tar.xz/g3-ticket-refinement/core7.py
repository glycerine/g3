from pathlib import Path
import re,csv,sys,subprocess as sp
w=Path(__file__).resolve().parent
sys.path.insert(0,'/tmp/g3-ticket-focus/reuse');from analyze import parse,Terms
t=Terms();file=Path('/tmp/g3-ticket-heap/obligations/3-7-1.smt2');src=parse(file.read_text());decl=[t.render(t.expand(x,{})) for x in src if x[0].startswith('declare-')]
rows=[i for r in src if r[0]=='assert' for i in t.conjuncts(t.expand(r[1],{}))];terms=[t.render(i) for i in rows]
tracked='\n'.join(['(set-option :produce-unsat-cores true)',*decl,*['(assert (! '+x+' :named r'+str(i)+'))' for i,x in enumerate(terms)],'(check-sat)','(get-unsat-core)'])
r=sp.run([Path.cwd().parent/'build/z3','smt.core.minimize=true','-in'],input=tracked,text=True,capture_output=True,timeout=120,check=True);assert r.stdout.startswith('unsat\n')
ids=sorted(map(int,re.findall(r'\br([0-9]+)\b',r.stdout)));assert ids
text='\n'.join([*decl,*['(assert '+terms[i]+')' for i in ids],'(check-sat)'])+'\n';(w/'core7.smt2').write_text(text)
for exe in [Path.cwd().parent/'build/z3',Path('/tmp/g3-ticket-heap/g3-cli')]:
 assert sp.run([exe,'-in'],input=text,text=True,capture_output=True,timeout=120,check=True).stdout.strip()=='unsat'
with (w/'core7.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['index','universals','existentials','assertion'])
 for i in ids:out.writerow([i,terms[i].count('(forall '),terms[i].count('(exists '),terms[i]])
