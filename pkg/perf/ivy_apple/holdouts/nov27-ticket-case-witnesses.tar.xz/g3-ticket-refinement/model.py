from pathlib import Path
import subprocess as sp,json
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'live.json').read_text())
def patch(path,fn):
 f=p/path;s=Path(ov['Replace'][str(f)]).read_text();out=w/('model-'+f.name);out.write_text(fn(s));ov['Replace'][str(f)]=str(out)
patch('api/internal/order/ground_instance_pool.go',lambda s:s.replace('trialWide bool','trialWide bool\n trialLazy bool').replace('EnableWideTrial(){p.trialWide=true}','EnableWideTrial(lazy bool){p.trialWide=true;p.trialLazy=lazy}'))
def encoding(s):
 k='list := p.group[t.symbol]';s=s.replace(k,'if p.trialLazy {continue}\n '+k)
 return s+'''
// Model-guided experiment: add a valid congruence lemma only when two
// applications coincide in this assignment and have disagreeing outputs.
func(p *GroundInstancePool) RefineTrial(q *GroundInstanceQuery, value func(int32)bool)bool{
 if !p.trialLazy{return false}
 g:=&p.g
 type key struct{sym uint32;args [8]uint32}
 observed:=map[key]uint32{}
 label:=func(id uint32)uint32{if g.terms[id].boolean{if value(p.result[id]){return 1};return 0}; c:=p.codes[id];var n uint32;for j:=0;j<c.width;j++{if value(c.bit(j)){n|=1<<j}};return n}
 before:=len(g.compiler.Clauses)
 for id:=uint32(1);id<uint32(len(g.terms));id++{
 t:=g.terms[id];if t.count==0 || t.count>8 || t.operation!=opaqueOperation{continue}
 args:=g.arguments[t.start:t.start+t.count];k:=key{sym:t.symbol};for j,arg:=range args{k.args[j]=label(arg)}
 other,ok:=observed[k];if !ok{observed[k]=id;continue};if label(other)==label(id){continue}
 ot:=g.terms[other];rhs:=g.arguments[ot.start:ot.start+ot.count];same:=int32(1)
 for j,v:=range args{same=g.compiler.and(same,p.eq(v,rhs[j]))};p.guardEqual(same,id,other)
 if g.compiler.work>g.compiler.ceiling || len(g.compiler.Clauses)>120000{return false}
 }
 q.Variables=g.compiler.Vars;q.Clauses=g.compiler.Clauses
 return len(q.Clauses)>before
}
'''
patch('api/internal/order/ground_instance_encoding.go',encoding)
def search(s):
 s=s.replace('EnableWideTrial()','EnableWideTrial(trialMode=="lazy" || trialMode=="lazy-log")')
 k='result, err := s.sat.solver.CheckWithDecisionDepth(assumptions, maxDecisionLevel)'
 s=s.replace(k,'for attempt:=0;;attempt++{\n'+k)
 k='if err := s.sat.solver.PopToBaseLevel(); err != nil {'
 a=s.index(k,s.index('for attempt:=0'));s=s[:a]+'''var model sat.Model
 if attempt<6 && result==lbool.True && (trialMode=="lazy" || trialMode=="lazy-log"){model,err=s.sat.solver.AppendModel(nil);if err!=nil{return false,err}}
 '''+s[a:]
 k='keep = s.sat.limit.IncOffset(0)';s=s.replace(k,'''if len(model)>0{
 val:=func(x int32)bool{if x==1{return true};if x==-1{return false};if v:=q.Value(x);v!=0{return v>0};n:=x;if n<0{n=-n};id:=s.variableIDs[n];v:=id!=0 && int(id)<=len(model) && model[id-1]==lbool.True;return v==(x>0)}
 if s.pool.RefineTrial(q,val){if !s.sat.limit.IncOffset(uint32(q.Variables)){return false,nil};conflict,ok:=q.Reduce(s.sat.limit,false);if !ok{return false,nil};if conflict{return true,nil};if ok,e:=s.install(q);!ok || e!=nil{return false,e};continue}
 }
 '''+k)
 return s.replace('return keep && result == lbool.False, nil','return keep && result == lbool.False, nil\n }')
patch('api/api_ground_instances.go',search)
patch('api/api_predicate_agreement.go',lambda s:s.replace('trialMode=="log"','(trialMode=="log" || trialMode=="lazy-log")').replace('return trialMode!="eq" || eq','return trialMode=="on" || eq'))
j=w/'model.json';j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-overlay',j,'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'model','./cmd/goivy_check'],cwd=front,check=True)
