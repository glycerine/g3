from common import *
import enum_matched_profiles as mp
rd=d/'qi-rewrite-census';rd.mkdir(exist_ok=True)
def binaries():
 p=pkg/'smtcore/smt_qi_instance.go';u=pkg/'smtcore/smt_quantifier_manager.go';s=once(p.read_text(),'import (','import ("os";')
 i=s.index('type SMTQIInstanceBuilder struct {');s=s[:i]+'''type qiStudyRow struct{checked,skipped,rewrites,unchanged,toTrue,rawHits,sameResult,work,sameWork,repeatedWork uint64}
 '''+s[i:];s=once(s,'type SMTQIInstanceBuilder struct {','type SMTQIInstanceBuilder struct {\n studyRows map[ast.ASTHandle]*qiStudyRow\n studyInputs map[ast.ASTHandle]ast.ASTHandle')
 i=s.index('if satisfied {',s.index('func (b *SMTQIInstanceBuilder) prepare'));s=s[:i]+'''if b.studyRows==nil{b.studyRows=make(map[ast.ASTHandle]*qiStudyRow);b.studyInputs=make(map[ast.ASTHandle]ast.ASTHandle)};r:=b.studyRows[quantifier];if r==nil{r=&qiStudyRow{};b.studyRows[quantifier]=r};r.checked++;if satisfied{r.skipped++}
 '''+s[i:];k='return b.Finish(prepared, rewritten, stat, scope)'
 s=once(s,k,'''r:=b.studyRows[prepared.quantifier];if r!=nil{
  n,_:=rw.NumSteps();r.rewrites++;r.work+=uint64(n);if instance==rewritten{r.unchanged++;r.sameWork+=uint64(n)};if b.manager.IsTrue(rewritten){r.toTrue++}
  if old,ok:=b.studyInputs[instance];ok{r.rawHits++;r.repeatedWork+=uint64(n);if old==rewritten{r.sameResult++}};b.studyInputs[instance]=rewritten
 };'''+k)
 s+='''\nfunc(b *SMTQIInstanceBuilder)dumpStudy(){if b==nil||b.studyRows==nil{return};for q,r:=range b.studyRows{fmt.Fprintf(os.Stderr,"QISTUDY %d %d %d %d %d %d %d %d %d %d %d %d\\n",q.Slot(),q.Generation(),r.checked,r.skipped,r.rewrites,r.unchanged,r.toTrue,r.rawHits,r.sameResult,r.work,r.sameWork,r.repeatedWork)};b.studyRows=nil;b.studyInputs=nil}\n'''
 z=once(u.read_text(),'func (q *SMTQuantifierManager) Close() error {','func (q *SMTQuantifierManager) Close() error {\n if q!=nil{q.builder.dumpStudy()}')
 o=overlay(rd/'overlay',{p:s,u:z});b=rd/'g3'
 with(w/'build.lock').open('a')as lk,(rd/'build.log').open('w')as l:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','3','-tags=xtrace_off','-buildvcs=false','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
 return b
def lane(tag,c,b):
 src=mp.rd/tag/'input.smt2';ref=(mp.rd/tag/'1-g3/stdout').read_text();q=run(['taskset','-c',str(c),b,'-st','-smt2',src],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
 clean=lambda output:{k:v for k,v in mp.pars.findall(output)if all(z not in k for z in ['memory','alloc','time'])}
 assert clean(ref)==clean(q.stdout)and q.stdout.startswith('unknown\n');lines=q.stderr.splitlines();assert lines and all(l.startswith('QISTUDY ')for l in lines),q.stderr[-250:]
 with(rd/f'{tag}.csv').open('w')as f:
  z=csv.writer(f);z.writerow('slot generation checked skipped rewrites unchanged true repeated result_match work same_work repeat_work'.split());z.writerows(l.split()[1:]for l in lines)
if __name__=='__main__':
 b=binaries()
 with ThreadPoolExecutor(3)as ex:
  for f in [ex.submit(lane,t,c,b)for t,c in zip(['miss1','miss3','miss6'],[4,10,18])]:f.result()
