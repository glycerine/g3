import csv
import gzip
import statistics
import sys
from pathlib import Path

def aggregate(root):
    for path in sorted(root.glob('miss*/*-*/stacks.csv.gz')):
        case, trial = path.parent.parent.name, path.parent.name
        repeat, engine = trial.split('-')
        counts = {}
        with gzip.open(path, 'rt') as stream:
            for row in csv.DictReader(stream):
                stack = row['leaf-to-root']
                if engine == 'g3':
                    queue = 'smtcore.(*SMTQuantifierManager).instantiate|' in stack
                    check = 'smtcore.(*SMTChecker).run|' in stack
                    subst = 'smtcore.(*SMTCachedVarSubstitution).Instantiate|' in stack
                    rewrite = 'ast/rewriter.(*TheoryRewriter).Rewrite|' in stack
                    internal = 'smtcore.(*SMTInternalizerState).InternalizeInstance|' in stack
                    counterexample = 'smtcore.(*SMTModelChecker).auxiliaryCounterexamples|' in stack
                else:
                    queue = 'smt::qi_queue::instantiate(smt::qi_queue::entry&)' in stack
                    check = 'smt::checker::is_sat(' in stack
                    subst = 'cached_var_subst::operator()' in stack
                    rewrite = 'rewriter_tpl<th_rewriter_cfg>' in stack
                    internal = 'smt::context::internalize_assertion(' in stack
                    counterexample = 'smt::model_checker::check(quantifier*)' in stack
                active = dict(total=True, queue=queue, satisfaction=queue and check,
                              substitution=queue and subst, rewrite=queue and rewrite and not internal and not check and not subst,
                              internalize=queue and internal, counterexample=counterexample)
                for key, value in active.items():
                    counts[key] = counts.get(key, 0) + int(row['samples']) * int(row['period']) * value
        yield dict(case=case, round=repeat, engine=engine, **counts)

if __name__ == '__main__':
    rows = list(aggregate(Path(sys.argv[1])))
    writer = csv.DictWriter(sys.stdout, fieldnames=rows[0])
    writer.writeheader()
    writer.writerows(rows)
