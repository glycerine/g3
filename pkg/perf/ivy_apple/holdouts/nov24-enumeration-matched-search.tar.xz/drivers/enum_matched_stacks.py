from common import *
import enum_matched_profiles as mp,gzip
rd=d/'enum-matched-stacks';rd.mkdir(exist_ok=True)
def trial(c,tag):
 src=mp.rd/tag/'input.smt2';out=rd/tag;out.mkdir(exist_ok=True)
 expect=None
 with(out/'totals.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine answer qi conflicts reslimit samples mean_stack'.split())
  for i in range(3):
   for en in list(mp.binaries)[::1 if i%2==0 else -1]:
    q=out/(str(i+1)+'-'+en);q.mkdir(exist_ok=True);period=7500019
    p=run(['taskset','-c',str(c),perf,'record','-q','--no-buildid','-e','instructions:u','-c',str(period),'--call-graph','fp' if en=='g3'else 'dwarf,4096','-o',q/'samples','--',mp.binaries[en],'-st','-smt2',src],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True);stats=dict(mp.pars.findall(p.stdout))
    key=tuple(stats[k]for k in ('quant-instantiations','conflicts','rlimit-count'));assert p.stdout.startswith('unknown\n')and(expect is None or key==expect);expect=key
    counts=Counter();st=[]
    with(q/'decode.log').open('w')as l,subprocess.Popen([perf,'script','--no-inline','-F','event,ip,sym,dso','-i',q/'samples'],stdout=subprocess.PIPE,stderr=l,text=True,errors='replace')as proc:
     for line in proc.stdout:
      if line.strip().endswith('instructions:u:')or line.strip()=='': 
       if st:counts[tuple(st)]+=1;st=[]
       continue
      m=re.match(r'^\s*([\da-f]+)\s+(.*?)\s+\((.*)\)\s*$',line)
      if m:st.append(re.sub(r'\+0x[0-9a-f]+$','',m[2]).removeprefix('github.com/glycerine/g3/pkg/'))
     if st:counts[tuple(st)]+=1
     assert proc.wait()==0 and 'lost'not in(q/'decode.log').read_text().lower()
    n=sum(counts.values());depth=sum(len(k)*v for k,v in counts.items())/max(n,1)
    assert n>450 and depth>2,(tag,en,n,depth)
    with gzip.open(q/'stacks.csv.gz','wt')as l:
     wr=csv.writer(l);wr.writerow(['samples','period','leaf-to-root']);wr.writerows([v,period,'|'.join(k)]for k,v in counts.most_common())
    z.writerow([i+1,en,'unknown',*key,n,depth]);f.flush()
    print(tag,en,i+1,n,round(depth,1),flush=True);(q/'samples').unlink()
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:
  for f in [ex.submit(trial,c,tag)for c,tag in zip([8,16,24],['miss1','miss3','miss6'])]:f.result()
