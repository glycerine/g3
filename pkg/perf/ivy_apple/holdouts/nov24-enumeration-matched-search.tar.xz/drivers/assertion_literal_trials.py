from common import *
import enum_matched_profiles as mp
rd=d/'assertion-literal-trials';rd.mkdir(exist_ok=True);p=pkg/'smtcore/smt_internalizer.go'
def edit(mode):
 s=p.read_text()
 if 'args' in mode:
  i=s.index('op, basic, err := s.basicOperation(expression)',s.index('func (s *SMTInternalizerState) Assert('))
  end=s.index('switch op {',i)
  s=s[:i]+'''header,err:=s.manager.NodeHeader(expression)
  if err!=nil{return err}
  op,basic:=s.smtHeaderBasicOperation(&header)
  if basic && smtInternalizerGateOperation(op){
  var local [8]ast.ASTHandle
  arguments:=local[:]
  if header.NumArgs>uint32(len(local)){arguments=make([]ast.ASTHandle,header.NumArgs)} else {arguments=arguments[:header.NumArgs]}
  for i:=range arguments{arguments[i],err=s.manager.GetArg(expression,uint32(i));if err!=nil{return err}}
  '''+s[end:]
  i=s.index('literals := make([]SMTLiteral, len(arguments))',i);s=s[:i]+s[i:].replace('literals := make([]SMTLiteral, len(arguments))','var localLits [8]SMTLiteral;literals:=localLits[:];if len(arguments)>len(localLits){literals=make([]SMTLiteral,len(arguments))}else{literals=literals[:len(arguments)]}',1)
 if 'known' in mode or 'fused' in mode:
  i=s.index('if err = s.Internalize(argument, true);',s.index('case ast.ASTOpOr:',s.index('func (s *SMTInternalizerState) Assert(')));j=s.index('if err != nil',s.index('literals[index], err =',i))
  s=s[:i]+'literals[index], err=s.assertedLiteral(argument)\n'+s[j:]
  fk='''func(s *SMTInternalizerState)assertedLiteral(expression ast.ASTHandle)(SMTLiteral,error){
    m:=s.manager
    atom:=expression;neg:=false
    if m.IsTrue(atom){return SMTTrueLiteral,nil};if m.IsFalse(atom){return SMTFalseLiteral,nil}
    h,err:=m.NodeHeader(atom);if err!=nil{return SMTNullLiteral,err}
    if op,basic:=s.smtHeaderBasicOperation(&h);basic&&op==ast.ASTOpNot{
       atom,err=m.GetArg(atom,0);if err!=nil{return SMTNullLiteral,err};neg=true
       if m.IsTrue(atom){return SMTFalseLiteral,nil};if m.IsFalse(atom){return SMTTrueLiteral,nil}
       h,err=m.NodeHeader(atom);if err!=nil{return SMTNullLiteral,err}
       if inner,b:=s.smtHeaderBasicOperation(&h);b&&inner==ast.ASTOpNot{
         if err=s.Internalize(expression,true);err!=nil{return SMTNullLiteral,err};return s.Literal(expression)
       }
    }
    if v,ok:=s.boolVar.lookup(atom);ok{return NewSMTLiteral(v,neg),nil}
    SLOW
   }
   '''
  if 'fused' in mode:
   slow='''boolean,err:=s.isBoolean(atom);if err!=nil{return SMTNullLiteral,err};if h.Kind==ast.ASTVar||!boolean{return SMTNullLiteral,ast.ErrASTDomain}
     if err=s.internalizeFormula(atom,true,&h);err!=nil{return SMTNullLiteral,err}
     if v,ok:=s.boolVar.lookup(atom);ok{return NewSMTLiteral(v,neg),nil};return SMTNullLiteral,ast.ErrASTDomain'''
  else:slow='if err=s.Internalize(expression,true);err!=nil{return SMTNullLiteral,err};return s.Literal(expression)'
  s+='\n'+fk.replace('SLOW',slow)
 return {p:s}
def go(mode):
 dr=rd/mode;dr.mkdir(exist_ok=True);o=overlay(dr/'overlay',edit(mode));b=dr/'g3'
 with(w/'build.lock').open('a')as lk,(dr/'build.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH)
  run(['go','test','-p','4','-count=1','-overlay='+str(o),'-run','Internaliz|Quantifier|Assert|Clause','./smtcore'],cwd=pkg,stdout=log,stderr=log)
  run(['go','build','-p','4','-tags=xtrace_off','-buildvcs=false','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=log,stderr=log)
 return b
def probe(tag,c,bs):
 sd=rd/tag;sd.mkdir(exist_ok=True)
 if tag.startswith('miss'):src=mp.rd/tag/'input.smt2'
 else:
  q=json.loads((d/'enum-premise-slices'/tag/'original.json').read_text())[0]['Problem'];src=sd/'query.smt2';src.write_text('(set-option :rlimit 6000000)\n'+q['Text']+'(check-sat)\n')
 ref=None
 with(sd/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine answer qi conflicts steps instructions cycles'.split())
  for i in range(3):
   seq=list(bs)
   for label in seq[i:]+seq[:i]:
    pf=sd/'perf';q=run(['taskset','-c',str(c),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',pf,'--',bs[label],'-smt2','-st',src],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
    st={k:int(v)for k,v in mp.pars.findall(q.stdout)if 'memory'not in k and 'alloc'not in k and 'time'not in k}
    ans=q.stdout.splitlines()[0];key=ans,st;assert ref is None or key==ref,(tag,label,[(k,v,ref[1].get(k))for k,v in st.items()if v!=ref[1].get(k)]);ref=key
    ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];z.writerow([i+1,label,ans,st.get('quant-instantiations',0),st.get('conflicts',0),st.get('rlimit-count',0),*ct]);f.flush()
if __name__=='__main__':
 modes=['args','known','fused','args-fused']
 with ThreadPoolExecutor(2)as ex:bs={'before':d/'release-arena-generation/g3',**dict(zip(modes,ex.map(go,modes)))}
 with ThreadPoolExecutor(6)as ex:
  for f in [ex.submit(probe,t,c,bs)for t,c in zip(['miss1','miss3','miss6','control1','control3','control6'],[2,6,10,16,30,34])]:f.result()
