from common import *
rd=d/'enum-native-budget';rd.mkdir(exist_ok=True)
def lane(c,items):
 with(rd/f'cpu-{c}.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('case regime engine budget answer instructions cycles qi conflicts resource'.split())
  for tag,filename in items:
   src=json.loads(filename.read_text())[0]['Problem']
   for mode in ['scoped','batch','using-smt','defaults']:
    setup=''if mode=='defaults'else '(set-option :smt.macro_finder true)\n(set-option :smt.relevancy 1)\n'
    a=src['LastAssertionStart'];data=src['Text'][:a]+('(push 1)\n' if mode=='scoped'else'')+src['Text'][a:]+('(check-sat-using smt)\n'if mode=='using-smt'else'(check-sat)\n')
    for eng,bin in [('native',pkg.parent/'build/z3'),('g3',d/'release-arena-generation/g3')]:
     for budget in (1000000,6000000):
      pf=rd/f'{c}.perf';s=(setup+f'(set-option :rlimit {budget})\n'+data).encode()
      t=subprocess.run(['taskset','-c',str(c),perf,'stat','-x,','-e','instructions:u,cycles:u','-o',pf,'--',bin,'-smt2','-in','-st'],input=s,env=dict(env,GOMAXPROCS='1'),capture_output=True,timeout=160)
      out=t.stdout.decode();err=t.stderr.decode()
      (rd/f'{tag}-{mode}-{eng}-{budget}.out').write_text(out+err)
      if t.returncode not in (0,1)or not out.splitlines():raise ValueError((eng,tag,mode,t.returncode,err[-300:]))
      ans=out.splitlines()[0];stats={k:int(v)for k,v in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])',out)}
      if 'error'in out:ans='unsupported'
      assert ans in ('sat','unknown','unsat','unsupported'),(tag,mode,eng,out[:300],err)
      if tag.startswith('sat'):assert ans!='unsat',(tag,mode,eng)
      elif ans=='sat':raise ValueError(('independently UNSAT query reported SAT',tag,mode,eng))
      ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];wr.writerow([tag,mode,eng,budget,ans,*ct,stats.get('quant-instantiations',''),stats.get('conflicts',''),stats.get('rlimit-count','')]);f.flush()
      if ans!='unknown':break
if __name__=='__main__':
 jobs=[(kind+str(i),d/'enum-premise-slices'/(('control'if kind=='control'else'miss')+str(i))/('rank64.json'if kind=='sat'else 'original.json'))for kind in ['miss','control','sat']for i in range(1,7)]
 cpus=[1,7,19,27,37,45]
 with ThreadPoolExecutor(len(cpus))as ex:
  for f in [ex.submit(lane,c,jobs[k::len(cpus)])for k,c in enumerate(cpus)]:f.result()
