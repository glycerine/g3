from common import *
import gzip
rd=d/'enum-matched-profiles';rd.mkdir(exist_ok=True)
binaries={'g3':d/'release-arena-generation/g3','native':pkg.parent/'build/z3'}
pars=re.compile(r':([\w-]+)\s+(\d+)(?=[\s)])')
def case(n):
 p=json.loads((d/'enum-premise-slices'/n/'original.json').read_text())[0]['Problem'];k=p['LastAssertionStart']
 return '(set-option :smt.macro_finder true)\n(set-option :smt.relevancy 1)\n(set-option :rlimit 6000000)\n'+p['Text'][:k]+'(push 1)\n'+p['Text'][k:]+'(check-sat)\n'
def one(tag,c):
 base=rd/tag;base.mkdir(exist_ok=True);src=base/'input.smt2';src.write_text(case(tag));reference=None
 expected={'rlimit-count','quant-instantiations','conflicts'}
 with(base/'totals.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine answer qi conflicts steps sampled instructions cycles'.split())
  for i in range(3):
   for en in (('g3','native')if i%2==0 else('native','g3')):
    b=binaries[en];p=base/(str(i+1)+'-'+en);p.mkdir(exist_ok=True)
    cmd=['taskset','-c',str(c),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',p/'totals','--',perf,'record','-q','--no-buildid','-e','instructions:u','-c','310009','-o',p/'samples','--',b,'-st','-smt2',src]
    r=run(cmd,env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True);ref=r.stdout.splitlines()[0];stats=dict(pars.findall(r.stdout));assert ref=='unknown'and expected<=set(stats)
    k=tuple(stats[s] for s in sorted(expected));assert reference is None or reference==k,(tag,en,k,reference);reference=k
    (p/'stdout').write_text(r.stdout);(p/'stderr').write_text(r.stderr)
    counts=Counter();sampled=0
    pr=run([perf,'script','--no-inline','-F','ip,sym,dso','-i',p/'samples'],capture_output=True,text=True)
    for line in pr.stdout.splitlines():
     m=re.match(r'^\s*([\da-f]+)\s+(.*?)\s+\(([^()]*)\)\s*$',line)
     if m:
      s=re.sub(r'\+0x[0-9a-f]+$','',m[2]);counts[s,m[3]]+=1;sampled+=1
    assert sampled>1000,(sampled,pr.stdout[:200]);cnt=[int(l.split(',')[0])for l in (p/'totals').read_text().splitlines()if ':u'in l]
    with gzip.open(p/'leaf.csv.gz','wt')as out:
     wr=csv.writer(out);wr.writerow(['symbol','image','samples','period'])
     for (s,img),v in counts.most_common():wr.writerow([s,img,v,310009])
    z.writerow([i+1,en,ref,stats['quant-instantiations'],stats['conflicts'],stats['rlimit-count'],sampled,*cnt]);f.flush()
    # Keep the IPs for line-level attribution; none of these records include user stacks.
    print(tag,i+1,en,sampled,flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:
  for f in [ex.submit(one,t,c)for t,c in zip(['miss1','miss3','miss6'],[7,15,27])]:f.result()
