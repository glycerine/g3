from common import *
import enum_matched_profiles as mp
rd=d/'qi-repeat-audit';rd.mkdir(exist_ok=True)
def make():
    p=pkg/'smtcore/smt_qi_instance.go';u=pkg/'smtcore/smt_quantifier_manager.go'
    s=once(p.read_text(),'import (','import ("os";')
    s=once(s,'type SMTQIInstanceBuilder struct {','''type repeatSample struct {input,output ast.ASTHandle; index uint64}
    type repeatStats struct {raw,already,identity,nowChanged,prevOutputLive,exactLive,mismatchLive,stepsOnIdentity,stepsAll uint64}
    type SMTQIInstanceBuilder struct {
    studyAll map[ast.ASTHandle]repeatSample
    studyTiny []repeatSample
    studyStats [3]repeatStats
    studyIndex uint64''')
    i=s.index('return b.Finish(prepared, rewritten, stat, scope)')
    s=s[:i]+'''b.studyObserve(instance,rewritten,rw)
    '''+s[i:]
    s+='''
    func(b *SMTQIInstanceBuilder)studyObserve(in,out ast.ASTHandle,rw *rewriter.TheoryRewriter){
        if b.studyAll==nil{b.studyAll=make(map[ast.ASTHandle]repeatSample);b.studyTiny=make([]repeatSample,256+4096)}
        n,_:=rw.NumSteps();b.studyIndex++
        a:=int(in.Slot()&255);z:=256+int(in.Slot()&4095)
        old:=[3]repeatSample{b.studyAll[in],b.studyTiny[a],b.studyTiny[z]}
        for j,prev:=range old{
            r:=&b.studyStats[j];r.raw++;r.stepsAll+=uint64(n)
            if prev.input!=in{continue};r.already++
            if prev.output==in{r.identity++;if out!=in{r.nowChanged++}else{r.stepsOnIdentity+=uint64(n)}}
            if b.manager.IsLiveHandle(prev.output){r.prevOutputLive++;if prev.output==out{r.exactLive++}else{r.mismatchLive++}}
        }
        v:=repeatSample{in,out,b.studyIndex};b.studyAll[in]=v;b.studyTiny[a]=v;b.studyTiny[z]=v
    }
    func(b *SMTQIInstanceBuilder)dumpRepeatStudy(){if b==nil||b.studyAll==nil{return};for i,s:=range b.studyStats{fmt.Fprintf(os.Stderr,"REPEAT %d %d %d %d %d %d %d %d %d %d\\n",i,s.raw,s.already,s.identity,s.nowChanged,s.prevOutputLive,s.exactLive,s.mismatchLive,s.stepsOnIdentity,s.stepsAll)};b.studyAll=nil;b.studyTiny=nil}
    '''
    z=once(u.read_text(),'func (q *SMTQuantifierManager) Close() error {','func (q *SMTQuantifierManager) Close() error {\n if q!=nil{q.builder.dumpRepeatStudy()}')
    o=overlay(rd/'overlay',{p:s,u:z});b=rd/'g3'
    with(w/'build.lock').open('a')as lk,(rd/'build.log').open('w')as l:
        fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','3','-tags=xtrace_off','-buildvcs=false','-pgo=off','-overlay='+str(o),'-o',b,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
    return b
def probe(job,b):
    tag,c=job;src=mp.rd/tag/'input.smt2';ref=(mp.rd/tag/'1-g3/stdout').read_text()
    p=run(['taskset','-c',str(c),b,'-st','-smt2',src],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
    stats=lambda s:{k:v for k,v in mp.pars.findall(s)if not any(w in k for w in ('memory','alloc','time'))}
    assert stats(ref)==stats(p.stdout) and p.stdout.startswith('unknown\n')
    lines=p.stderr.splitlines();assert lines and all(l.startswith('REPEAT ') for l in lines)
    with(rd/(tag+'.csv')).open('w')as f:
        z=csv.writer(f);z.writerow('cache rewrites repeated previous_identity now_changed previous_live matched_live changed_live identity_steps all_steps'.split());z.writerows(l.split()[1:]for l in lines)
if __name__=='__main__':
    b=make()
    with ThreadPoolExecutor(3)as ex:list(ex.map(lambda j:probe(j,b),zip(['miss1','miss3','miss6'],[3,17,25])))
