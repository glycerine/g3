"""Time the four conditional gate clauses by ordinal and disposition."""
from pathlib import Path
body = Path(__file__).with_name('gates.py').read_text()
exec(body[:body.rindex("exec(compile(s,")])
a = g.index('case ast.ASTOpIte:', g.index('func (s *SMTInternalizerState) addGateConstraints('))
b = g.index('if s.relevancy != nil',a)
v = edit(g[a:b],'for _, clause :=','for ordinal, clause :=')
anchor = 'if err = s.addGateClause(clause); err != nil {\n\t\t\t\treturn err\n\t\t\t}'
v = edit(v,anchor,'''var ck uint64;var regular,binary uint32;var assigned int;var conflict bool
            if track{regular=s.statistics.NumMkClause;binary=s.statistics.NumMkBinClause;assigned=len(s.assignedLiterals);conflict=s.inconsistent;ck=studyRd(installMeter)}
            '''+anchor+'''
            if track{cost:=studyRd(installMeter)-ck; key:=10*ordinal
            if regular!=s.statistics.NumMkClause{key++}else if binary!=s.statistics.NumMkBinClause{key+=2}else if !conflict && s.inconsistent{key+=3}else if assigned!=len(s.assignedLiterals){key+=4}
            fmt.Fprintln(os.Stderr,"P",key,cost)}''')
g = g[:a]+v+g[b:]
a=c.index('void context::mk_ite_cnstr(')
b=c.index('\n    }',a)
v=c[a:b]
for ordinal,line in enumerate(('mk_gate_clause(~l, ~l1,  l2);','mk_gate_clause(~l,  l1,  l3);','mk_gate_clause(l,  ~l1, ~l2);','mk_gate_clause(l,   l1, ~l3);')):
    v=edit(v,line,'''{auto regular=m_stats.m_num_mk_clause,binary=m_stats.m_num_mk_bin_clause;auto assigned=m_assigned_literals.size();bool conflict=inconsistent();auto ck=track?operand_rd(install_meter):0;
      '''+line+'''
      if(track){auto cost=operand_rd(install_meter)-ck;int key='''+str(10*ordinal)+''';if(regular!=m_stats.m_num_mk_clause)key++;else if(binary!=m_stats.m_num_mk_bin_clause)key+=2;else if(!conflict && inconsistent())key+=3;else if(assigned!=m_assigned_literals.size())key+=4;fprintf(stderr,"P %d %lld\\n",key,cost);}}''')
c=c[:a]+v+c[b:]
s=edit(s,"b'B',b'Z'","b'B',b'Z',b'P'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
