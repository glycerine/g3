"""Check release verdicts, both output streams and exit codes against the native corpus."""
from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    s=t.extractfile('study/release.py').read().decode().replace("('base','trial','apple')","('trial','apple')")
s=s[:s.index(' def measure(')]+s[s.index(' with ThreadPoolExecutor(4)'):]
exec(compile(s,'verify','exec'))
