"""Coallocate short unit-resolution reasons and their retained literal slice."""
from pathlib import Path
import tempfile,tarfile
pkg=Path.cwd()
with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel=t.extractfile('study/panel.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    p=pkg/'smtcore/smt_justification.go'
    src=p.read_text()
    anchor='return &SMTUnitResolutionJustification{SMTJustificationBase: NewSMTJustificationBase(region), Antecedent: antecedent, Literals: append([]SMTLiteral(nil), literals...)}, nil'
    assert src.count(anchor)==1
    src=src.replace(anchor,'''if len(literals) <= 2 {
        entry := new(struct {
            reason SMTUnitResolutionJustification
            literals [2]SMTLiteral
        })
        copy(entry.literals[:],literals)
        entry.reason = SMTUnitResolutionJustification{SMTJustificationBase: NewSMTJustificationBase(region), Antecedent:antecedent, Literals:entry.literals[:len(literals):len(literals)]}
        return &entry.reason,nil
    }
    '''+anchor)
    trial=Path(tmp)/p.name
    trial.write_text(src)
    panel=panel.replace("mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp[str(pkg/'smtcore/smt_justification.go')]=str(trial)")
    exec(compile(panel,'panel','exec'),{'trial':trial,'__file__':__file__})
