"""Measure Boolean ITE relevance registration using the condition's existing SAT literal."""
import os
import tarfile
import tempfile
from pathlib import Path

pkg = Path.cwd()
with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as archive:
    panel = archive.extractfile('study/panel.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    p = pkg/'smtcore/smt_internalizer.go'
    f = Path(tmp)/p.name
    s = p.read_text()
    anchor = 'return s.relevancy.AddITEWatches(expression)'
    assert s.count(anchor)==1
    s = s.replace(anchor,'''condition := arguments[0]
            if condition.Var() != SMTTrueLiteral.Var() {
                atom := s.boolExpr[condition.Var()]
                handler := smtRelevancyHandler{kind:smtRelevancyITE,target:expression}
                if err := s.relevancy.addWatch(atom,!condition.Sign(),&handler); err != nil {
                    return err
                }
                return s.relevancy.addWatch(atom,condition.Sign(),&handler)
            }
            '''+anchor)
    f.write_text(s)
    anchor = "mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())"
    assert panel.count(anchor)==1
    panel = panel.replace(anchor,"mp[str(pkg/'smtcore/smt_internalizer.go')]=str(trial)")
    exec(compile(panel,'panel','exec'),{'trial':f,'__file__':__file__})
