"""Attribute fresh Boolean ITE gate installation to literal lookup, clauses and relevance."""
from pathlib import Path
body = Path(__file__).with_name('bool-parts.py').read_text()
exec(body[:body.rindex('exec(compile(s,')])
g += '\nvar observedGate ast.ASTHandle\n'
g = edit(g, 'if err = s.addGateConstraints(expression, op);',
         'if ite{observedGate=expression};if err = s.addGateConstraints(expression, op);')
a = g.index('func (s *SMTInternalizerState) addGateConstraints(')
b = g.index('func (s *SMTInternalizerState) internalizeTerm(',a)
v = g[a:b]
v = edit(v,'variable := s.boolVar.get(expression)','track:=expression==observedGate;var start uint64;if track{observedGate=ast.ASTHandle{};start=studyRd(installMeter)};variable := s.boolVar.get(expression)')
a2 = v.index('case ast.ASTOpIte:')
v = v[:a2] + edit(v[a2:],'for _, clause :=','if track{fmt.Fprintln(os.Stderr,"Z",0,studyRd(installMeter)-start); start=studyRd(installMeter)};for _, clause :=')
v = edit(v,'return s.relevancy.AddITEWatches(expression)','if track{fmt.Fprintln(os.Stderr,"Z",1,studyRd(installMeter)-start);start=studyRd(installMeter)};err:=s.relevancy.AddITEWatches(expression);if track{fmt.Fprintln(os.Stderr,"Z",2,studyRd(installMeter)-start)};return err')
g = g[:a]+v+g[b:]
c = edit(c,'*observed_bool_ite=nullptr;', '*observed_bool_ite=nullptr,*observed_gate=nullptr;')
c = edit(c,'mk_ite_cnstr(to_app(n));\n                add_ite_rel_watches(to_app(n));','if(ite)observed_gate=n;mk_ite_cnstr(to_app(n));if(ite)t=operand_rd(install_meter);add_ite_rel_watches(to_app(n));if(ite)fprintf(stderr,"Z 2 %lld\\n",operand_rd(install_meter)-t);')
a = c.index('void context::mk_ite_cnstr(')
b = c.index('\n    }',a)
v = edit(c[a:b], 'literal l  =', 'bool track=n==observed_gate;long long start=0;if(track){observed_gate=nullptr;start=operand_rd(install_meter);}literal l  =')
v = edit(v,'mk_gate_clause(~l, ~l1,  l2);','if(track){fprintf(stderr,"Z 0 %lld\\n",operand_rd(install_meter)-start);start=operand_rd(install_meter);}mk_gate_clause(~l, ~l1,  l2);')
v += '\n if(track)fprintf(stderr,"Z 1 %lld\\n",operand_rd(install_meter)-start);'
c = c[:a]+v+c[b:]
s = edit(s,"b'J',b'B'","b'J',b'B',b'Z'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
