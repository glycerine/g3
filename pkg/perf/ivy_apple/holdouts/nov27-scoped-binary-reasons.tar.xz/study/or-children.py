"""Classify direct children of the two-input ORs underneath fresh negations."""
from pathlib import Path
body=Path(__file__).with_name('negated-or.py').read_text()
exec(body[:body.rindex('exec(compile(s,')])
a=g.index('func (s *SMTInternalizerState) internalizeFormulaCoreOp(');b=g.index('func (s *SMTInternalizerState) argumentLiterals',a)
v=edit(g[a:b],'if err = s.Internalize(argument, isGate);','''var ct uint64; tag:=0;if track && count==2 {
     child:=argument;neg,h,e:=s.manager.IsNot(child);if e!=nil{panic(e)};if neg{tag+=1000;child=h}
     if _,bound:=s.boolVar.lookup(child);bound{tag+=100}
     h2,e:=s.manager.NodeHeader(child);if e!=nil{panic(e)}
     if h2.Kind!=ast.ASTApp{tag+=90}else if h2.Family==s.manager.BasicFamilyID(){tag+=int(h2.DeclKind)}else if h2.Family==ast.NullFamilyID{tag+=80;if h2.NumArgs==0{tag++}}else{tag+=89};ct=studyRd(installMeter)}
     if err = s.Internalize(argument, isGate);''')
v=edit(v,'return fmt.Errorf("internalize formula child %d: %w", index, err)\n\t\t}','return fmt.Errorf("internalize formula child %d: %w", index, err)\n\t\t};if track && count==2{fmt.Fprintln(os.Stderr,"Y",tag,studyRd(installMeter)-ct)}')
g=g[:a]+v+g[b:]
a=c.index('void context::internalize_formula_core');b=c.index('bool is_new_var',a)
v=c[a:b]; anchor='internalize(arg, _is_gate);'
if anchor not in v:
    print(v)
    raise RuntimeError('native recursion anchor')
v=edit(v,anchor,'''long long ct=0;int tag=0;if(track && n->get_num_args()==2){
    expr* child=arg;if(m_manager.is_not(arg,child))tag+=1000;if(b_internalized(child))tag+=100;
    if(!is_app(child))tag+=90;else{auto* app=to_app(child);if(app->get_family_id()==m_manager.get_basic_family_id())tag+=app->get_decl_kind();else if(app->get_family_id()==null_family_id)tag+=app->get_num_args()?80:81;else tag+=89;}
    ct=operand_rd(install_meter);}'''+anchor+'''if(track && n->get_num_args()==2)fprintf(stderr,"Y %d %lld\\n",tag,operand_rd(install_meter)-ct);''')
c=c[:a]+v+c[b:]
s=edit(s,"b'Q',b'X'","b'Q',b'X',b'Y'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
