"""Time newly internalized negated disjunction operands of quantified lemmas by arity."""
from pathlib import Path
body=Path(__file__).with_name('parts.py').read_text()
exec(body[:body.rindex("exec(compile(s,")])
g=edit(g,'if code==2{observedEquality=argument}', 'if code==106{_,child,e:=s.manager.IsNot(argument);if e!=nil{panic(e)};observedEquality=child}')
a=g.index('if track{observedEquality=ast.ASTHandle{};')
b=g.index(';t=studyRd(installMeter)}',a)
g=g[:a]+'if track{observedEquality=ast.ASTHandle{};missing=int(count)'+g[b:]
g+='\nvar observedOrGate ast.ASTHandle\n'
g=edit(g,'if err = s.addGateConstraints(expression, op);','if track{observedOrGate=expression};if err = s.addGateConstraints(expression, op);')
a=g.index('func (s *SMTInternalizerState) addGateConstraints(');b=g.index('func (s *SMTInternalizerState) internalizeTerm(',a)
v=g[a:b];v=edit(v,'variable := s.boolVar.get(expression)','track:=observedOrGate==expression;var start uint64;if track{observedOrGate=ast.ASTHandle{};start=studyRd(installMeter)};variable := s.boolVar.get(expression)')
v=edit(v,'case ast.ASTOpOr:\n\t\tfor _, argument','case ast.ASTOpOr:\n if track{fmt.Fprintln(os.Stderr,"X",len(arguments)*10,studyRd(installMeter)-start);start=studyRd(installMeter)};for _, argument')
v=edit(v,'return s.relevancy.AddOrWatches(expression)','if track{fmt.Fprintln(os.Stderr,"X",len(arguments)*10+1,studyRd(installMeter)-start);start=studyRd(installMeter)};err:=s.relevancy.AddOrWatches(expression);if track{fmt.Fprintln(os.Stderr,"X",len(arguments)*10+2,studyRd(installMeter)-start)};return err')
g=g[:a]+v+g[b:]
c=edit(c,'if(code==2)observed_eq=arg;','if(code==106)observed_eq=atom;')
c=edit(c,'for(expr* x:*n)if(!e_internalized(x))missing++;','missing=n->get_num_args();')
c=edit(c,'*observed_eq=nullptr;', '*observed_eq=nullptr,*observed_or_gate=nullptr;')
c=edit(c,'mk_or_cnstr(to_app(n));\n                add_or_rel_watches(to_app(n));','if(track)observed_or_gate=n;mk_or_cnstr(to_app(n));if(track)t=operand_rd(install_meter);add_or_rel_watches(to_app(n));if(track)fprintf(stderr,"X %d %lld\\n",missing*10+2,operand_rd(install_meter)-t);')
a=c.index('void context::mk_or_cnstr(');b=c.index('\n    }',a)
v=c[a:b]
# Native obtains each literal during clause construction; measure those together.
v=v.replace('{','{ bool track=n==observed_or_gate;long long start=0;if(track){observed_or_gate=nullptr;start=operand_rd(install_meter);}',1)
v+='\n if(track)fprintf(stderr,"X %d %lld\\n",n->get_num_args()*10+1,operand_rd(install_meter)-start);'
c=c[:a]+v+c[b:]
s=edit(s,"b'E',b'Q'","b'E',b'Q',b'X'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
