"""Compare allocation traffic and solver-thread instructions on TLB 60/1 with normal GC."""
from pathlib import Path
body=Path(__file__).with_name('check.py').read_text()
body=body.replace("path = d / name","""if name == 'phase_observer_trial.go':
            src = src.replace('start := time.Now()', 'var before,after runtime.MemStats;runtime.ReadMemStats(&before);start := time.Now()')
            src = src.replace('runtime.UnlockOSThread()', 'runtime.ReadMemStats(&after);fmt.Fprintln(os.Stderr,"ALLOC",after.TotalAlloc-before.TotalAlloc,after.Mallocs-before.Mallocs);runtime.UnlockOSThread()')
        path = d / name""")
body=body.replace("('base','fixed')","('base','reason','attach','packed')",1)
a=body.index("        if mode == 'base':");b=body.index('        mapping =',a)
body=body[:a]+"""        if mode != 'base':
            driver=Path(__file__).with_name(mode+'.py').read_text()
            idx=driver.index('    panel=panel.replace')
            runner=driver[:idx]
            if mode=='packed':
                runner+='    selected.update({key:Path(value).read_bytes() for key,value in overlays.items()})'
            else:
                runner+='    selected[str(p)]=trial.read_bytes()'
            selected={}
            exec(runner,{'__file__':__file__,'selected':selected})
            for key,data in selected.items():
                path=d/(mode+Path(key).name)
                path.write_bytes(data)
                overlay[key]=str(path)
"""+body[b:]
body=body.replace("'elapsed_ns']","'elapsed_ns','bytes','allocations']")
body=body.replace('for i in range(7):','modes=["base","reason","attach","packed"];\n        for i in range(4):')
body=body.replace("for mode in (('fixed','base') if i%2 else ('base','fixed')):","for mode in modes[i:]+modes[:i]:")
body=body.replace("GOGC='off'","GOGC='100'").replace('normal, counts = [], []','normal, counts, alloc = [], [], []').replace("elif line.startswith(b'STAGE-COUNT '):","elif line.startswith(b'ALLOC '):\n                        alloc.append(tuple(map(int,cols[1:])))\n                    elif line.startswith(b'STAGE-COUNT '):")
body=body.replace("assert len(counts)==1","assert len(counts)==len(alloc)==1").replace('*counts[0]]','*counts[0],*alloc[0]]')
exec(compile(body,'memory-check','exec'))
