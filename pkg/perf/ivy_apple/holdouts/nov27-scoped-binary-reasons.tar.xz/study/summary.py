"""Print medians from case-paired comparisons and focal check/constructor measurements."""
import csv
import statistics as st
import sys
from pathlib import Path
p=Path(sys.argv[1])
for d in ('watch','literal-panel','store','block','reason','packed','attach','joined','final-panel'):
    row=[]
    for n in (1,3,4,6,8,227):
        f=p/d/f'time-{n}.csv'
        r=list(csv.DictReader(f.open()))
        assert len(r)==10
        pairs=[]
        for i in range(5):
            pair={x['engine']:int(x['instructions']) for x in r if int(x['round'])==i}
            pairs.append(100*(pair['trial']/pair['base']-1))
        row.append(round(st.median(pairs),3))
    print(d,*row)
for d in ('.','literal','final-cost','memory','joined-memory'):
    r=list(csv.DictReader((p/d/'check.csv').open()))
    for mode in sorted({x['engine'] for x in r}):
        xs=[x for x in r if x['engine']==mode]
        print(d,mode,len(xs),{k:st.median(int(x[k]) for x in xs) for k in ('instructions','bytes','allocations') if k in xs[0]})
for f in sorted(p.glob('*.bench')):
    out={}
    for line in f.read_text().splitlines():
        if not line.startswith('Benchmark'):continue
        a=line.split();out.setdefault(a[0],[]).append(float(a[2]))
    print(f.name,{k:st.median(v) for k,v in out.items()})
