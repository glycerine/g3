"""Time simplification, resolution reasons, and storage of the conditional's retained clauses."""
from pathlib import Path
body=Path(__file__).with_name('gates.py').read_text()
exec(body[:body.rindex('exec(compile(s,')])
g+='\nvar pricingGateClause bool\n'
a=g.index('case ast.ASTOpIte:',g.index('func (s *SMTInternalizerState) addGateConstraints('))
b=g.index('if s.relevancy != nil',a)
v=edit(g[a:b],'if err = s.addGateClause(clause);','pricingGateClause=track;err=s.addGateClause(clause);pricingGateClause=false;if err2:=err;')
# Preserve error semantics and do not introduce an unused local.
v=v.replace('if err2:=err; err != nil','if err != nil')
g=g[:a]+v+g[b:]
g=edit(g,'kept := s.clauseKeptScratch[:0]','track:=pricingGateClause;var started uint64;if track{started=studyRd(installMeter)};kept := s.clauseKeptScratch[:0]')
g=edit(g,'return s.storeSimplifiedClause(kept,','if track{fmt.Fprintln(os.Stderr,"U",len(kept)*10,studyRd(installMeter)-started)};return s.storeSimplifiedClause(kept,')
g=edit(g,'// mk_clause: j = unit_resolution_justification(j, simp_lits) whenever','track:=pricingGateClause;var started uint64;if track{started=studyRd(installMeter)};\n // mk_clause: j = unit_resolution_justification(j, simp_lits) whenever')
g=edit(g,'s.statistics.NumMkLits += uint32(len(kept))','if track{fmt.Fprintln(os.Stderr,"U",len(kept)*10+1,studyRd(installMeter)-started)};s.statistics.NumMkLits += uint32(len(kept))')
g=edit(g,'clause, owner, err := s.makeClauseWithJustificationAndDeleteHandler(kept,','if track{started=studyRd(installMeter)};clause, owner, err := s.makeClauseWithJustificationAndDeleteHandler(kept,')
g=edit(g,'if clause.ReinternalizeAtoms() {\n\t\t// C++ saves','if track{fmt.Fprintln(os.Stderr,"U",len(kept)*10+2,studyRd(installMeter)-started);started=studyRd(installMeter)};if clause.ReinternalizeAtoms() {\n\t\t// C++ saves')
g=edit(g,'\n\treturn nil\n}\n\nfunc (s *SMTInternalizerState) selectLearnedWatchLiteral','\n if track{fmt.Fprintln(os.Stderr,"U",len(kept)*10+3,studyRd(installMeter)-started)};return nil\n}\n\nfunc (s *SMTInternalizerState) selectLearnedWatchLiteral')
c=edit(c,'*observed_gate=nullptr;', '*observed_gate=nullptr;static thread_local bool pricing_gate_clause=false;')
a=c.index('void context::mk_ite_cnstr('); b=c.index('\n    }',a)
v=edit(c[a:b],'mk_gate_clause(~l, ~l1,  l2);','pricing_gate_clause=track;mk_gate_clause(~l, ~l1,  l2);')
v=edit(v,'mk_gate_clause(l,   l1, ~l3);','mk_gate_clause(l,   l1, ~l3);pricing_gate_clause=false;')
c=c[:a]+v+c[b:]
a=c.index('clause * context::mk_clause(unsigned'); b=c.index('void context::add_lit_occs',a)
v=c[a:b]
v=edit(v,'switch (k) {','bool track=pricing_gate_clause;long long started=track?operand_rd(install_meter):0;switch (k) {')
v=edit(v,'if (!simp_lits.empty()) {','if(track){fprintf(stderr,"U %d %lld\\n",num_lits*10,operand_rd(install_meter)-started);started=operand_rd(install_meter);}if (!simp_lits.empty()) {')
v=edit(v,'unsigned activity = 0;','if(track)fprintf(stderr,"U %d %lld\\n",num_lits*10+1,operand_rd(install_meter)-started);unsigned activity = 0;')
v=edit(v,'clause * cls = clause::mk','if(track)started=operand_rd(install_meter);clause * cls = clause::mk')
idx=v.index('m_aux_clauses.push_back(cls);')
v=v[:idx]+edit(v[idx:],'add_watch_literal(cls, 1);','add_watch_literal(cls, 1);if(track){fprintf(stderr,"U %d %lld\\n",num_lits*10+2,operand_rd(install_meter)-started);started=operand_rd(install_meter);}')
v=edit(v,'return cls;', 'if(track)fprintf(stderr,"U %d %lld\\n",num_lits*10+3,operand_rd(install_meter)-started);return cls;')
c=c[:a]+v+c[b:]
s=edit(s,"b'B',b'Z'","b'B',b'Z',b'U'")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
