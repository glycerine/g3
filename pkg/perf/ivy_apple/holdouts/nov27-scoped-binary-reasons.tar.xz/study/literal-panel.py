"""Check the bound literal lookup from literal.py on six complete workloads."""
from pathlib import Path
import tarfile,tempfile
pkg = Path.cwd()
src = Path(__file__).with_name('literal.py').read_text()
a = src.index("            file = pkg/'smtcore/smt_internalizer_state.go'")
b = src.index('            overlay[str(file)]',a)
with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel = t.extractfile('study/panel.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    state={'pkg':pkg,'d':Path(tmp),'mode':'bound'}
    # Keep multiline Go string indentation intact.
    exec('if True:\n'+src[a:b],state)
    anchor = "mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())"
    assert panel.count(anchor)==1
    panel=panel.replace(anchor,"mp[str(pkg/'smtcore/smt_internalizer_state.go')]=str(trial)")
    exec(compile(panel,'panel','exec'),{'trial':state['path'],'__file__':__file__})
