"""Meter instructions, allocations and bytes for current sources against the corrected parent."""
from pathlib import Path
body=Path(__file__).with_name('check.py').read_text()
body=body.replace("('smt_internalizer_state.go','smt_enode_core.go')","('smt_clause.go','smt_internalizer.go','smt_boolean_propagation.go')").replace('cd0b1a5f0:pkg/','658c3136c:pkg/')
body=body.replace("path = d / name","""if name == 'phase_observer_trial.go':
            src = src.replace('start := time.Now()', 'var before,after runtime.MemStats;runtime.ReadMemStats(&before);start := time.Now()')
            src = src.replace('runtime.UnlockOSThread()', 'runtime.ReadMemStats(&after);fmt.Fprintln(os.Stderr,"ALLOC",after.TotalAlloc-before.TotalAlloc,after.Mallocs-before.Mallocs);runtime.UnlockOSThread()')
        path = d / name""",1)
body=body.replace("'elapsed_ns']","'elapsed_ns','bytes','allocations']")
body=body.replace('normal, counts = [], []','normal, counts, alloc = [], [], []').replace("elif line.startswith(b'STAGE-COUNT '):","elif line.startswith(b'ALLOC '):\n                        alloc.append(tuple(map(int,cols[1:])))\n                    elif line.startswith(b'STAGE-COUNT '):")
body=body.replace("assert len(counts)==1","assert len(counts)==len(alloc)==1").replace('*counts[0]]','*counts[0],*alloc[0]]')
exec(compile(body,'cost','exec'))
