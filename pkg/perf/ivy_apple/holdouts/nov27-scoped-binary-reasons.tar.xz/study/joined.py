"""Single object for an ordinary scoped binary auxiliary clause simplified by one literal."""
from pathlib import Path
import tempfile,tarfile
pkg=Path.cwd()
with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel=t.extractfile('study/panel.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    p=pkg/'smtcore/smt_internalizer.go'
    src=p.read_text()
    anchor='// mk_clause: j = unit_resolution_justification(j, simp_lits) whenever'
    assert src.count(anchor)==1
    src=src.replace(anchor,'''if kind==SMTClauseAux && s.scopeLevel!=0 && len(kept)==2 && len(removedFalse)==1 && proof.IsNull() && justification==nil && deleteHandler==nil {
        // Both retained literals were undefined during simplification. There
        // has been no callback since then, and scope excludes binary watches.
        if err:=s.open();err!=nil{return err}
        entry:=new(struct{
            storage smtClauseStorage4
            attachment smtClauseAttachments
            reason SMTUnitResolutionJustification
            resolved [1]SMTLiteral
        })
        c:=&entry.storage.clause
        c.self,c.manager,c.kind=c,s.manager,kind
        c.literals=entry.storage.lits[:2:2]
        copy(c.literals,kept)
        entry.resolved[0]=removedFalse[0]
        entry.reason.Literals=entry.resolved[:]
        entry.attachment.proof=&entry.reason
        c.attachments=&entry.attachment
        for _,lit:=range kept {w:=&s.watches[lit.Negated().Index()];w.clauses=append(w.clauses,c)}
        s.ownedJustifications=append(s.ownedJustifications,&entry.reason)
        c.registerDirectory(root,proof,nil)
        s.auxClauses=append(s.auxClauses,c)
        s.statistics.NumMkLits+=2
        s.statistics.NumMkClause++
        return nil
    }
    '''+anchor)
    trial=Path(tmp)/p.name;trial.write_text(src)
    panel=panel.replace("mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp[str(pkg/'smtcore/smt_internalizer.go')]=str(trial)")
    exec(compile(panel,'panel','exec'),{'trial':trial,'__file__':__file__})
