"""Compare TLB batch 60 check 1 with and without the owner-arity correction."""
import csv
import json
import os
import subprocess as sp
import tarfile
import tempfile
from pathlib import Path

pkg = Path.cwd()
front = Path(os.environ['GOIVY_FRONTEND']).resolve()
ref = Path(os.environ['NNF_REFERENCE'])
examples = Path(os.environ['IVY_EXAMPLES'])
gold = ref / 'compat/1/1/native'
holdouts = pkg / 'perf/ivy_apple/holdouts'
out = Path(os.environ['RESULTS'])
out.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory() as tmp:
    d = Path(tmp)
    files = {}
    for name, archive, member in [
        ('z3bridge_solver_model.go','nov27-terminal-conflict-replay.tar.xz','study/stage-bridge.go.txt'),
        ('z3bridge_guarded_equalities.go','nov27-terminal-conflict-replay.tar.xz','study/guards.go.txt'),
        ('phase_observer_trial.go','nov27-first-push-queue-comparison.tar.xz','check-g3-phase_observer_trial.go')]:
        with tarfile.open(holdouts / archive) as t:
            src = t.extractfile(member).read().decode()
        if name == 'z3bridge_solver_model.go':
            src = src.replace('stopCheck:=startStage(batch,index+1);','capturePush=batch==60 && index==0;stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");capturePush=false')
        if name == 'phase_observer_trial.go':
            src = src.replace('runtime.LockOSThread()','if !capturePush{return func(string){}};runtime.LockOSThread()')
        path = d / name
        path.write_text(src)
        files[str(front / name)] = str(path)
    for mode in ('base','shape','bound'):
        overlay = files.copy()
        if mode != 'base':
            file = pkg/'smtcore/smt_internalizer_state.go'
            src = file.read_text()
            a = src.index('header, err := s.manager.NodeHeader(expression)',src.index('func (s *SMTInternalizerState) Literal('))
            b = src.index('// Reserved truth literals',a)
            src = src[:a]+"""negated, child, err := s.manager.IsNot(expression)
	if err != nil { return SMTNullLiteral, err }
	if negated {
        """+src[b:]
            if mode == 'bound':
                a = src.index('if s.manager.IsTrue(expression)',src.index('func (s *SMTInternalizerState) Literal('))
                src = src[:a]+"""if v, found := s.boolVar.lookup(expression); found && s.notChild(v).IsNull() {
                    return NewSMTLiteral(v,false), nil
                }
                """+src[a:]
            path = d/(mode+'.go')
            path.write_text(src)
            overlay[str(file)] = str(path)
        mapping = d / 'overlay.json'
        mapping.write_text(json.dumps({'Replace':overlay}))
        sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',str(Path(os.environ['GOIVY_MODFILE']).resolve()),'-overlay',mapping,'-o',d/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=os.environ['TRIAL_CACHE']),check=True)
    with (out/'check.csv').open('w') as f:
        w = csv.writer(f)
        w.writerow(['round','engine','instructions','elapsed_ns'])
        for i in range(6):
            for mode in (('base','shape','bound'), ('shape','bound','base'), ('bound','base','shape'), ('bound','shape','base'), ('shape','base','bound'), ('base','bound','shape'))[i]:
                r = sp.run(['taskset','-c',os.environ['CPU'],d/mode,examples/(ref/'compat.txt').read_text().splitlines()[0]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,timeout=180)
                normal, counts = [], []
                for line in r.stderr.splitlines(keepends=True):
                    cols = line.split()
                    if line.startswith(b'OPEN '):
                        assert cols[1:]==[b'60',b'1']
                    elif line.startswith(b'STAGE-COUNT '):
                        assert cols[1:4]==[b'60',b'1',b'check'] and cols[6]==cols[7]
                        counts.append((int(cols[4]),int(cols[8])))
                    else:
                        normal.append(line)
                assert (r.returncode,r.stdout,b''.join(normal))==(1,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()), r.stderr[-1000:]
                assert len(counts)==1
                w.writerow([i,mode,*counts[0]])
                f.flush()
