"""Try direct construction of short auxiliary clauses, with optional solver-local blocks."""
from pathlib import Path
import tempfile, tarfile, os
pkg=Path.cwd()
with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel=t.extractfile('study/panel.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    p=pkg/'smtcore/smt_boolean_propagation.go'
    src=p.read_text()
    a=src.index('func (s *SMTInternalizerState) makeClauseWithJustificationAndDeleteHandler')
    idx=src.index('owner := justification',a)
    text='''if !proofs && kind==SMTClauseAux && proof.IsNull() && len(literals)>=2 && len(literals)<=4 {
        entry := new(smtClauseStorage4)
        c:=&entry.clause
        c.self,c.manager=c,s.manager
        c.kind=kind
        c.literals=entry.lits[:len(literals):len(literals)]
        copy(c.literals,literals)
        c.setAttachments(justification,deleteHandler)
        for _,lit:=range literals[:2] {
            w:=&s.watches[lit.Negated().Index()]
            w.clauses=append(w.clauses,c)
        }
        return c,justification,nil
    }
    '''
    overlays={}
    if os.environ.get('BLOCK')=='1':
        q=pkg/'smtcore/smt_internalizer_state.go'
        src2=q.read_text().replace('type SMTInternalizerState struct {','type SMTInternalizerState struct {\n smallAux []smtClauseStorage4')
        assert src2!=q.read_text()
        other=Path(tmp)/q.name;other.write_text(src2);overlays[str(q)]=str(other)
        text=text.replace('entry := new(smtClauseStorage4)','''var entry *smtClauseStorage4
            if len(s.auxClauses)<64 {entry=new(smtClauseStorage4)} else {
                if len(s.smallAux)==0 {s.smallAux=make([]smtClauseStorage4,16)}
                entry=&s.smallAux[0]
                s.smallAux=s.smallAux[1:]
                if len(s.smallAux)==0{s.smallAux=nil}
            }''')
    trial=Path(tmp)/p.name
    trial.write_text(src[:idx]+text+src[idx:]);overlays[str(p)]=str(trial)
    panel=panel.replace("mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp.update(extras)")
    exec(compile(panel,'panel','exec'),{'extras':overlays,'__file__':__file__})
