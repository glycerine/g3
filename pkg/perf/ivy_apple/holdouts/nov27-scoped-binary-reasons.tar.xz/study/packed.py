"""Give each short auxiliary reason a distinct, never reused span of literal storage."""
import tarfile,tempfile
from pathlib import Path
pkg=Path.cwd()
with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel=t.extractfile('study/panel.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    overlays={}
    for file in ('smt_internalizer_state.go','smt_internalizer.go'):
        p=pkg/'smtcore'/file
        src=p.read_text()
        if file.endswith('_state.go'):
            anchor='type SMTInternalizerState struct {'
            change=anchor+'\n reasonLiterals []SMTLiteral'
        else:
            anchor='updated, err := NewSMTUnitResolutionJustification(region, justification, removedFalse)'
            change='''var updated *SMTUnitResolutionJustification
                var err error
                if justification==nil && len(s.auxClauses)>=64 && len(removedFalse)<=4 {
                    n:=len(removedFalse)
                    if len(s.reasonLiterals)<n {s.reasonLiterals=make([]SMTLiteral,64)}
                    lits:=s.reasonLiterals[:n:n]
                    copy(lits,removedFalse)
                    s.reasonLiterals=s.reasonLiterals[n:]
                    updated=&SMTUnitResolutionJustification{SMTJustificationBase:NewSMTJustificationBase(true),Literals:lits}
                }else{
                    updated,err=NewSMTUnitResolutionJustification(region,justification,removedFalse)
                }'''
        assert src.count(anchor)==1
        f=Path(tmp)/file;f.write_text(src.replace(anchor,change));overlays[str(p)]=str(f)
    panel=panel.replace("mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp.update(extras)")
    exec(compile(panel,'panel','exec'),{'extras':overlays,'__file__':__file__})
