"""Compare the ordinary shared clause publication path with and without coallocation."""
import tarfile, subprocess as sp
from pathlib import Path
files=('smt_clause.go','smt_internalizer.go','smt_boolean_propagation.go')
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel=t.extractfile('study/panel.py').read().decode()
a=panel.index("    if name=='trial':");b=panel.index("    j=d/",a)
panel=panel[:a]+"""    if name=='base':
        for filename in files:
            f=d/filename
            f.write_bytes(sp.check_output(['git','show','658c3136c:pkg/smtcore/'+filename]))
            mp[str(pkg/'smtcore'/filename)]=str(f)
"""+panel[b:]
exec(compile(panel,'panel','exec'))
