"""Coallocate the attachment and clause, keeping record sizes unchanged for plain clauses."""
from pathlib import Path
import tarfile, tempfile
pkg=Path.cwd()
with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
    panel=t.extractfile('study/panel.py').read().decode()
with tempfile.TemporaryDirectory() as tmp:
    p=pkg/'smtcore/smt_clause.go'
    src=p.read_text()
    anchor='clause := smtNewClauseStorage(literals, kind != SMTClauseAux || saveAtoms, needsDirectory)'
    assert src.count(anchor)==1
    src=src.replace(anchor,'''var clause *SMTClause
    if kind==SMTClauseAux && !saveAtoms && !needsDirectory && len(literals)<=4 && (justification!=nil || deleteHandler!=nil) {
        entry:=new(struct{
            storage smtClauseStorage4
            attachments smtClauseAttachments
        })
        clause=&entry.storage.clause
        clause.literals=entry.storage.lits[:len(literals):len(literals)]
        copy(clause.literals,literals)
        entry.attachments=smtClauseAttachments{proof:justification,handler:deleteHandler}
        clause.attachments=&entry.attachments
    }else{
        clause=smtNewClauseStorage(literals,kind!=SMTClauseAux || saveAtoms,needsDirectory)
        clause.setAttachments(justification,deleteHandler)
    }''')
    src=src.replace('clause.reinternalizeAtoms = saveAtoms\n\tclause.setAttachments(justification, deleteHandler)','clause.reinternalizeAtoms = saveAtoms')
    trial=Path(tmp)/p.name;trial.write_text(src)
    panel=panel.replace("mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp[str(pkg/'smtcore/smt_clause.go')]=str(trial)")
    exec(compile(panel,'panel','exec'),{'trial':trial,'__file__':__file__})
