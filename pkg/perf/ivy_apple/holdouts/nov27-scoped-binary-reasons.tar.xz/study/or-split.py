"""Compare four complete expansions of negated binary disjunctions in ground lemmas."""
from pathlib import Path
s=Path(__file__).with_name('split.py').read_text().replace("here/'split.go.txt'","here/'or-split.go.txt'")
exec(compile(s,'or-split','exec'))
