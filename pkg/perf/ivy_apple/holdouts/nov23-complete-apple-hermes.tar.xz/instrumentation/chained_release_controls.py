from ground_release_controls import *
import inspect
d=w/'chained-release-controls';d.mkdir(exist_ok=True)
last=w/'observed-release-controls/checker/goivy_check'
scope=dict(globals());exec(inspect.getsource(panel).replace("paired/'g3/goivy_check'","last"),scope);panel=scope['panel']
scope=dict(globals());exec(inspect.getsource(corpus),scope);corpus=scope['corpus']
def main2():
 b=build(d/'checker')
 def whole(cpu,quiet):
  arg=['--min-idle','.95' if quiet else '0','--rounds','3'if quiet else'1']
  run([sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',b,'--previous',last,'--native',paired/'native/goivy_check','--cpu',str(cpu),*arg,'--max-attempts','12','--spec',examples/'jea/hermes_rmw_o3_testing.ivy','--reference',w/'extended-phases/long/1/1/native','--perf',perf,'--output',d/f'whole-{cpu}'],stdout=subprocess.DEVNULL)
  print('whole',cpu,flush=True)
 with ThreadPoolExecutor(12)as e:
  fs=[e.submit(whole,15,True),e.submit(whole,2,False),e.submit(whole,7,False),e.submit(corpus,b)]
  for c,n in [(1,'rfn2'),(3,'cf_live'),(6,'dramc_nb2'),(12,'raft_no_assume_test')]:
   sp,iso,*_=CASES[n];fs.append(e.submit(panel,(c,n,sp,iso,next((prior/'end-panel-final').glob('*/'+n+'/1/g3')),0,b)))
  for c,i in [(8,0),(9,1),(13,2),(18,3)]:
   sp=vf.cases[i];ref=vf.reference(sp);fs.append(e.submit(panel,(c,Path(sp).stem,sp,'',ref,int(b'FAIL'in(ref/'stdout').read_bytes()),b)))
  for f in fs:f.result()
if __name__=='__main__':main2()
