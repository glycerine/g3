package goivy

import (
	"bufio"
	"fmt"
	"os"
	"runtime"
	"syscall"
	"unsafe"
)

type vcObs struct {
	fd          uintptr
	batch, goal int
	empty       uint64
	w           *bufio.Writer
}

var vcBatch int

func newVerificationObserver() *vcObs {
	vcBatch++
	o := &vcObs{batch: vcBatch, w: bufio.NewWriterSize(os.Stderr, 65536)}
	runtime.LockOSThread()
	var attr struct {
		Type, Size                                    uint32
		Config, Period, SampleType, ReadFormat, Flags uint64
		Padding                                       [16]byte
	}
	attr.Size = uint32(unsafe.Sizeof(attr))
	attr.Config = 1          // PERF_COUNT_HW_INSTRUCTIONS
	attr.Flags = 1<<5 | 1<<6 // exclude kernel and hypervisor
	attr.ReadFormat = 3
	var err syscall.Errno
	o.fd, _, err = syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN, uintptr(unsafe.Pointer(&attr)), 0, ^uintptr(0), ^uintptr(0), 0, 0)
	if err != 0 {
		panic(err)
	}

	a := o.read()
	o.empty = o.read() - a
	return o
}
func (o *vcObs) close() {
	if err := o.w.Flush(); err != nil {
		panic(err)
	}
	syscall.Close(int(o.fd))
	runtime.UnlockOSThread()
}
func (o *vcObs) put(begin uint64, stage string, result int) {
	n := o.read() - begin
	if n > o.empty {
		n -= o.empty
	} else {
		n = 0
	}
	fmt.Fprintln(o.w, "VC-PHASE", o.batch, o.goal, stage, result, n)
}
func (o *vcObs) read() uint64 {
	var values [3]uint64
	n, _, err := syscall.RawSyscall(syscall.SYS_READ, o.fd, uintptr(unsafe.Pointer(&values[0])), unsafe.Sizeof(values))
	if err != 0 || n != unsafe.Sizeof(values) || values[1] != values[2] {
		panic("incomplete replay instruction counter")
	}
	return values[0]
}
