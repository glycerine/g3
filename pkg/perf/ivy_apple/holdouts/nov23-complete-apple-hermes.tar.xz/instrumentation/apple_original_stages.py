from study import *
import corpus_phases as cp, tempfile
d=w/'apple-original-stages';d.mkdir(exist_ok=True);cp.root=d
o=cp.instrumentation()
with ThreadPoolExecutor(2)as ex:bs=dict(zip(('g3','native'),ex.map(lambda n:build(d/n,n,o),('g3','native'))))
def measure(v):
 c,iso,n=v;q=d/iso/n;q.mkdir(parents=True);sp=examples/'doc/examples/apple/ord_live.ivy'
 t=time.monotonic()
 with(q/'stdout').open('wb')as so,(q/'stderr').open('wb')as se,gzip.open(q/'phases.csv.gz','wt')as dest,subprocess.Popen(['taskset','-c',str(c),perf,'stat','-e','instructions:u','-x',',','-o',q/'perf.csv','--','timeout','-k','5','5400',bs[n],'isolate='+iso,sp],cwd=q,env=dict(env,GOGC='100',GOMAXPROCS='1'),stdout=so,stderr=subprocess.PIPE)as p:
  wr=csv.writer(dest);wr.writerow('batch condition stage result instructions'.split());count=0
  for l in p.stderr:
   if l.startswith(b'VC-PHASE '):
    parts=l.decode().split();wr.writerow(parts[1:]);count+=1
    if count%256==0:dest.flush();so.flush()
   else:se.write(l)
  code=p.wait()
 (q/'status').write_text(f'{code} {time.monotonic()-t:.3f} {count}\n');print(iso,n,code,count,flush=True)
def lane(j):
 i,iso=j
 for n in [('g3','native'),('native','g3')][i%2]:measure(([6,8,11,17][i],iso,n))
 a=d/iso/'g3';b=d/iso/'native';import filecmp
 sta=(a/'status').read_text().split()[0];stb=(b/'status').read_text().split()[0]
 if sta in ('0','1')and stb in ('0','1'):assert sta==stb and all(filecmp.cmp(a/x,b/x,shallow=False)for x in ['stdout','stderr']),iso
with ThreadPoolExecutor(4)as e:list(e.map(lane,enumerate(['rfn','e2e','tprops','sys_live'])))
