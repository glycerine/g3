from study import *
from collections import Counter
import shutil
d=w/'current-verifier-stacks';d.mkdir(exist_ok=True)
bs={'g3':w/'chained-release-controls/checker/goivy_check','native':w/'frontend-controls/paired-build/native/goivy_check'}
ivykey='github.com/glycerine/ivy/goivy.'
gkey='github.com/glycerine/g3/pkg/'
def summarize(sd):
 counters={k:Counter()for k in ['leaf','frontend','g3','native','solver-caller','frontend-inclusive','g3-inclusive','solver-leaf','native-inclusive']}
 def count(fr):
  if not fr:return
  counters['leaf'][fr[0]]+=1
  frontend=[f[len(ivykey):]for f in fr if f.startswith(ivykey)]
  go=[f[len(gkey):]for f in fr if f.startswith(gkey)]
  cpp=[f for f in fr if f.startswith(('smt::','rewriter_tpl<','ast_manager::','combined_solver::','th_rewriter::','solver::','solver_na2as::','context_simplifier::','strategic_solver::','Z3_'))]
  for key,items in [('frontend',frontend),('g3',go),('native',cpp)]:
   counters[key][items[0]if items else'<none>']+=1
   counters[key+'-inclusive'].update(set(items)) if key in ('g3','native','frontend') else None
  if go or cpp:
   counters['solver-caller'][frontend[0]if frontend else'<none>']+=1
   counters['solver-leaf'][fr[0]]+=1
 with gzip.open(sd/'stacks.gz','rt')as gz:
  fr=[]
  for line in gz:
   if not line.strip():count(fr);fr=[];continue
   m=re.match(r'^\s+[\da-f]+ (.*?) \(',line); 
   if m:fr.append(m[1])
  count(fr)
 with(sd/'counts.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('group frame samples'.split())
  for key,ct in counters.items():
   for n,z in ct.most_common():wr.writerow([key,n,z])
def lane(j):
 name,sp,iso,ref,expected,c,en,period=j;sd=d/f'{name}-{en}';sd.mkdir();raw=sd/'perf.data'
 cmd=['taskset','-c',str(c),perf,'record','--quiet','--no-buildid','-m','1024','-e','instructions:u','-c',str(period),'--call-graph','fp','-o',raw,'--',bs[en],*(['isolate='+iso]if iso else[]),examples/sp]
 with(sd/'stdout').open('wb')as out,(sd/'stderr').open('wb')as err:
  p=subprocess.run(cmd,cwd=sd,env=dict(env,GOMAXPROCS='1',GOGC='100'),stdout=out,stderr=err,timeout=2400)
 assert p.returncode==expected and all((sd/k).read_bytes()==(ref/k).read_bytes()for k in('stdout','stderr')),(name,en,p.returncode)
 with(sd/'decode.txt').open('wb')as err,subprocess.Popen([perf,'script','--no-inline','-i',raw,'-F','event,ip,sym,dso'],stdout=subprocess.PIPE,stderr=err)as proc,gzip.open(sd/'stacks.gz','wb',compresslevel=1)as dst:
  shutil.copyfileobj(proc.stdout,dst);assert proc.wait()==0
 assert 'lost' not in(sd/'decode.txt').read_text().lower()
 summarize(sd);print(sd,flush=True)
if __name__=='__main__':
 from panel import CASES
 jobs=[]
 for n,cs in [('tlb',[18,19]),('hermes',[10,22])]:
  if n=='hermes':sp,iso,ref,ex,period='jea/hermes_rmw_o3_testing.ivy','',w/'extended-phases/long/1/1/native',0,8000009
  else:sp,iso,_,f,u=CASES[n];ex=int(bool(f or u));ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'));period=1500007
  jobs.extend((n,sp,iso,ref,ex,c,k,period)for c,k in zip(cs,bs))
 with ThreadPoolExecutor(4)as e:list(e.map(lane,jobs))
