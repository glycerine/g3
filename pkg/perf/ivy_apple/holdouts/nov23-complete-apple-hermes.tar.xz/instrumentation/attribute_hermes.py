from study import *
from collections import Counter
for e in ('g3','native'):
 fr=[];ct=Counter();root=w/'current-verifier-stacks'/('hermes-'+e)
 def sample(fr):
  for target in ['renameASTRec','symbolsIluAstRec','clausesFromConjuncts','NewConst','RenameDistinctClauses','RenameClauses','ComposeUpdates','CheckFcsInStateWithAG']:
   if target not in fr:continue
   h=fr[fr.index(target)+1:];h=[s for s in h if s!=target]
   ct[target,' / '.join(h[:4])]+=1
 for l in gzip.open(root/'stacks.gz','rt'):
  if not l.strip():sample(fr);fr=[];continue
  m=re.match(r'^\s+[\da-f]+ github.com/glycerine/ivy/goivy\.(.*?) \(',l)
  if m:fr.append(m[1])
 sample(fr)
 with(root/'paths.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('site callers samples'.split())
  for (site,path),cnt in ct.most_common():wr.writerow([site,path,cnt])
 for tgt in ('renameASTRec','symbolsIluAstRec','ComposeUpdates'):
  print(e,tgt,[(k[1],round(v*.008,1))for k,v in ct.most_common()if k[0]==tgt][:7],flush=True)
