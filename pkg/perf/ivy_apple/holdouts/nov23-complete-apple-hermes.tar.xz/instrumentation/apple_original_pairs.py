from study import *
from panel import EVENTS
import filecmp
d=w/'apple-original-pairs';d.mkdir(exist_ok=True)
spec=examples/'doc/examples/apple/ord_live.ivy'
bins={'g3':w/'chained-release-controls/checker/goivy_check','native':w/'frontend-controls/paired-build/native/goivy_check'}
def one(c,n):
 p=d/f'{c}-{n}';p.mkdir();started=time.monotonic()
 cmd=['taskset','-c',str(c),perf,'stat','-e',','.join(EVENTS),'-x',',','-o',p/'perf.csv','--','/usr/bin/time','-f','%U %S %M','-o',p/'resources','timeout','-k','5','14400',bins[n],spec]
 with (p/'stdout').open('wb')as out,(p/'stderr').open('wb')as err,(p/'milestones.csv').open('w')as milestones,subprocess.Popen(cmd,cwd=p,env=dict(env,GOMAXPROCS='1',GOGC='100'),stdout=subprocess.PIPE,stderr=err)as proc:
  wr=csv.writer(milestones);wr.writerow('elapsed isolate passes failures'.split());isolate='';passed=failed=0
  for line in proc.stdout:
   out.write(line);s=line.strip()
   if s.startswith(b'Isolate ') or s==b'OK':
    wr.writerow([round(time.monotonic()-started,4),isolate,passed,failed]);milestones.flush();out.flush();isolate=s.decode()[8:].rstrip(':')if s!=b'OK'else'';passed=failed=0
   elif s==b'PASS':passed+=1
   elif b'FAIL'in s:failed+=1
  rc=proc.wait();wr.writerow([round(time.monotonic()-started,4),isolate,passed,failed])
 ins=next(int(r[0])for r in csv.reader((p/'perf.csv').open())if len(r)>2 and r[2]=='instructions:u')
 return rc,round(time.monotonic()-started,3),ins
def lane(j):
 c,order=j
 with(d/f'{c}.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('cpu engine exit wall instructions'.split())
  for n in order:
   r=one(c,n);wr.writerow([c,n,*r]);f.flush();print(c,n,r,flush=True)
with ThreadPoolExecutor(2)as e:list(e.map(lane,[(10,['g3','native']),(14,['native','g3'])]))
ref=d/'14-native'
for n in ('10-g3','10-native','14-g3'):
 for key in ('stdout','stderr'):assert filecmp.cmp(ref/key,d/n/key,shallow=False),(n,key)
print('original Apple transcripts match',flush=True)
