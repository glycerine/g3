from study import *
import verification_frontier as vf
import verified_cpu_pairs as vr
from panel import measure,EVENTS,CASES
from types import SimpleNamespace
import filecmp
fd=w/'frontend-controls';pair=fd/'paired-build'
while not(pair/'build.json').exists():
 if (w/'frontend-build.log').stat().st_size:print((w/'frontend-build.log').read_text(),flush=True)
 time.sleep(2)
g3=pair/'g3/goivy_check';native=pair/'native/goivy_check';previous=w/'quiet-enum-release/after/goivy_check';cub=w/'predicate-quiet-pairs/current/goivy_check';flash=w/'flash-selection-release/current/goivy_check';abc=prior/'spec-survey/with-abc-native/abc'
for b in (native,g3):
 if not(b.parent/'abc').exists():(b.parent/'abc').symlink_to(abc)
vr.d=fd/'quiet';vr.d.mkdir(exist_ok=True)
def apple(j):
 n,cpu,sp,iso,ref=j;vr.lane(j,{'native':native,'g3':g3,'previous':previous})
def short():
 for name,i,refb in [('flash-cubicle',0,cub),('test-flash2',1,flash)]:
  for field in ['timing','counters']:
   sd=fd/'flash'/name/field;run([sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',g3,'--previous',refb,'--native',native,'--cpu','20','--rounds','7'if field=='timing'else'9','--max-attempts','30','--spec',examples/vf.cases[i],'--reference',vf.reference(vf.cases[i]),'--output',sd,*(['--perf',perf,'--min-idle','0']if field=='counters'else [])],stdout=subprocess.DEVNULL)
   print(name,field,flush=True)
def hermes():
 cfg=SimpleNamespace(cpu=14,perf=perf,spec=examples/'jea/hermes_rmw_o3_testing.ivy',isolate='');ref=w/'extended-phases/long/1/1/native';rd=fd/'hermes';rd.mkdir()
 with(rd/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow(['round','engine','match','wall','user','sys','rss',*EVENTS])
  for i in range(3):
   for n,b in ([('native',native),('g3',g3)]if i%2==0 else[('g3',g3),('native',native)]):
    p=rd/f'{i+1}-{n}';code,t,c=measure(b,cfg,p,0,100);ok=not code and all((p/k).read_bytes()==(ref/k).read_bytes()for k in ['stdout','stderr']);wr.writerow([i+1,n,int(ok),*t,*c]);f.flush();assert ok;print('hermes',i+1,n,round(c[0]/1e9,3),flush=True)
def corpus():
 import spec_survey
 cfg=SimpleNamespace(perf=perf,seconds=360,gogc=100);old=w/'relation-selection-release/corpus';specs=(old/'specs.txt').read_text().splitlines();codes={int(r['index']):int(r['exit'])for f in old.glob('cpu-*.csv')for r in csv.DictReader(f.open())};rd=fd/'corpus';rd.mkdir()
 def lane(j):
  cpu,rows=j
  with(rd/f'cpu-{cpu}.csv').open('w')as f:
   wr=csv.writer(f);wr.writerow('index spec engine exit timeout wall user sys rss instructions pass fail ok matches_output matches_errors'.split())
   for i,sp in rows:
    p=rd/str(i);res=spec_survey.measure(cfg,examples/sp,native,p,cpu);match=[int(filecmp.cmp(p/k,old/str(i)/'g3'/k,shallow=False))for k in ('stdout','stderr')];wr.writerow([i,sp,'native',*res,*match]);f.flush();assert res[0]==codes[i]and res[1]==0 and match==[1,1],(i,sp,res,match)
 with ThreadPoolExecutor(3)as ex:list(ex.map(lane,[(c,list(enumerate(specs))[i::3])for i,c in enumerate([7,11,22])]))
 print('corpus',len(specs),flush=True)
def others():
 ns=['cf_live','cf_pio_live','cmpl_live','dramc_nb2','rfn2','raft_no_assume_test','hermes']
 rd=fd/'short';rd.mkdir();cfg=SimpleNamespace(cpu=16,perf=perf)
 with(rd/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('case round engine match wall user sys rss'.split()+list(EVENTS))
  for i in range(3):
   for n in ns:
    if n in ('cf_pio_live','cmpl_live'):sp='doc/examples/apple/ord_live.ivy';iso=n;ref=w/('flash-witness-shape/reference-'+n)
    elif n=='hermes':sp=vf.cases[3];iso='';ref=vf.reference(sp)
    else:sp,iso,*_=CASES[n];ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))
    cfg.spec=examples/sp;cfg.isolate=iso
    for en,b in ([('native',native),('g3',g3)]if i%2==0 else[('g3',g3),('native',native)]):
     p=rd/f'{n}-{i+1}-{en}';rc,t,c=measure(b,cfg,p,0,100);ok=not rc and all((p/k).read_bytes()==(ref/k).read_bytes()for k in ('stdout','stderr'));wr.writerow([n,i+1,en,int(ok),*t,*c]);f.flush();assert ok
if __name__=='__main__':
 jobs=[('ord-live2',4,'doc/examples/apple/ord_live2.ivy','',w/'extended-phases/long/2/1/native'),('sys-live',5,'doc/examples/apple/ord_live2.ivy','sys_live',w/'long-alternatives/ord2-sys/reference'),('issue73',15,'jea/issue73/ord.ivy','',w/'extended-phases/long/3/1/native')]
 with ThreadPoolExecutor(7)as e:
  futures=[e.submit(apple,j)for j in jobs]+[e.submit(f)for f in (short,hermes,corpus,others)]
  for f in futures:f.result()
