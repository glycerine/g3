from common import *
import timed_policy as tp,stage_frontier as sf,proof_measure_release as pm
from types import SimpleNamespace
root=d/'wide-wall-controls';root.mkdir(exist_ok=True);tp.root=root;tp.bins={'previous':d/'production-plans/checker/goivy_check','current':d/'production-wide/checker/goivy_check','native':native}
def trace():
 rd=root/'trace';rd.mkdir();sd=rd/'checker';sd.mkdir();b=sd/'goivy_check'
 with(w/'build.lock').open('a')as f,(sd/'build.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-mod=readonly','-modfile='+str(w/'local-checkout.mod'),'-o',b,'./cmd/goivy_check'],cwd=ivy,stdout=log,stderr=log)
 (sd/'build-info.txt').write_text(linked(b));(sd/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc');pm.binder.root=rd;pm.binder.trace({'before-trace':d/'proof-measure-release/trace/checker/goivy_check','after-trace':b});print('trace matched',flush=True)
def walls():
 for n in ('hermes_rmw_o3','hybrid','ticket_protocol'):
  j=next(j for j in sf.jobs()if j[1]==n);tp.lane(j[1:])
with ThreadPoolExecutor(2)as ex:
 fs=[ex.submit(trace),ex.submit(walls)]
 for f in fs:f.result()
