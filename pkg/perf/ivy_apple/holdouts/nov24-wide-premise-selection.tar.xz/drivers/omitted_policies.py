from common import *
import stage_frontier as sf,holdouts as ho,macro_identity as mi
root=d/'omitted-policies';root.mkdir(exist_ok=True);q=pkg/'api/api_verification_goal.go'
vs=['control','omit128','omit220','omit256','omit384','quarter-or220','quarter-or320','omit220-thirds','ge256-twofifths','omit128_twofifths']
def src(v):
 s=q.read_text();x='if yes, err := check(defs.selectRows(m, symbols, true), 100000); yes || err != nil || m.ResourceLimit().CancelFlag() {\n\t\treturn yes, err\n\t}'
 if v in ['omit128','omit220','omit256','omit384']:guard='len(base.rows)-len(wide)>='+v[4:];early='len(base.rows)>='+v[4:]
 elif v.startswith('quarter'):guard='len(wide)*4<len(base.rows)||len(base.rows)-len(wide)>='+v[10:];early='true'
 elif v=='omit220-thirds':guard='len(base.rows)-len(wide)>=220 && len(wide)*3<=len(base.rows)+len(wide)/4';early='len(base.rows)>=220'
 elif v=='ge256-twofifths':guard='len(wide)*5<=len(base.rows)*2';early='len(base.rows)>=256'
 else:guard='len(base.rows)-len(wide)>=128 && len(wide)*5<=len(base.rows)*2';early='len(base.rows)>=128'
 y='''if EARLY{wide:=defs.selectRows(m,symbols,true)
 if len(wide)!=0 && (GUARD){if yes,err:=check(wide,100000);yes||err!=nil||m.ResourceLimit().CancelFlag(){return yes,err}}
 if m.ResourceLimit().CancelFlag(){return false,nil}
 }'''.replace('EARLY',early).replace('GUARD',guard)
 return {q:once(s,x,y)}
def mk(v):
 if v=='control':return d/'production-plans/checker/goivy_check'
 od=root/v;return build(od/'checker',o=overlay(od/'overlay',src(v)))
def main():
 with ThreadPoolExecutor(4)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 for v,b in bs.items():
  (root/(v+'-info.txt')).write_text(linked(b))
 ho.root=root;js=[j for j in sf.jobs()if j[1]in ('hermes_rmw_o3','tlb','ticket_protocol','arm_rules3','hybrid','flash2','alternating_bit_protocol','test_liveness2')]+[(c,*j[1:5],j[-1])for c,j in zip([2,4,6,8,10],(j for j in mi.jobs()if j[1]in ('rfn2','cf_live','dramc_nb2','raftok','toy-consensus')))]
 with ThreadPoolExecutor(10)as ex:
  fs=[ex.submit(ho.measure_spec,j,bs,2)for j in js];ls=['control','omit220','quarter-or220','ge256-twofifths','omit128_twofifths']
  for i,j in enumerate(ho.jobs()[:3]):fs.append(ex.submit(ho.measure_spec,([6,10,22][i],*j[1:]),{k:bs[k]for k in ls[i:]+ls[:i]},2))
  for f in fs:f.result()
if __name__=='__main__':main()
