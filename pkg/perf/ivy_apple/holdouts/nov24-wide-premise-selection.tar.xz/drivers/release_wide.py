from common import *
import stage_frontier as sf,holdouts as ho,macro_identity as mi,ground_release_controls as gc
root=d/'production-wide';root.mkdir(exist_ok=True)
before=d/'production-plans/checker/goivy_check'
def tests(tag):
 with(w/'build.lock').open('a')as f,(root/('focused-'+(tag or 'release')+'.log')).open('w')as out:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-count=1','-p','3',*(['-tags='+tag]if tag else[]),'./api','-run','Test(Verification|OrderProofTemporaryGoal|TicketPrivatePlans|ShortPremises|Witness|Enumeration)'],cwd=pkg,stdout=out,stderr=out)
 print('focused',tag,flush=True)
def bench():
 q=pkg/'api/api_verification_goal.go';v=pkg/'api/api_verification_definitions.go'
 es={p:subprocess.check_output(['git','show','575c52898:pkg/api/'+p.name],cwd=pkg,text=True)for p in [q,v]}
 es[q]+='\nconst maxWidePremises=220\n';o=overlay(root/'prior-overlay',es)
 for v,ol in [('before',o),('after',None)]:
  with(w/'build.lock').open('a')as f,(root/(v+'-build.log')).open('w')as out:
   fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-c','-p','3','-o',root/(v+'.test'),*(['-overlay='+str(ol)]if ol else[]),'./api'],cwd=pkg,stdout=out,stderr=out)
 for i in range(7):
  for v in (['before','after'] if i%2==0 else ['after','before']):
   with(root/(v+'.bench')).open('a')as out:run(['taskset','-c','39',root/(v+'.test'),'-test.run=^$','-test.bench=^BenchmarkVerificationPremiseSearch$','-test.benchtime=10x','-test.count=1'],cwd=pkg/'api',stdout=out,stderr=out,env=dict(env,GOMAXPROCS='1'))
 print('bench done',flush=True)
def main():
 with ThreadPoolExecutor(5)as ex:
  fs=[ex.submit(tests,t)for t in ['', 'g3debug','g3checked']]+[ex.submit(bench),ex.submit(build,root/'checker')];b=fs[-1].result();(root/'build-info.txt').write_text(linked(b))
  with ThreadPoolExecutor(13)as per:
   ho.root=root;gc.d=root;bins={'before':before,'after':b,'native':native}
   js=ho.jobs()[:3]+[j for j in sf.jobs()if j[1]in ('hermes_rmw_o3','arm_rules3','ticket_protocol','tlb','hybrid','flash2','alternating_bit_protocol','test_liveness2')]+[(c,*j[1:5],j[-1])for c,j in zip([4,6,8,10,12],(j for j in mi.jobs()if j[1]in ('cf_live','rfn2','dramc_nb2','raftok','toy-consensus')))]
   fs.extend(per.submit(ho.measure_spec,j,bins,3)for j in js);fs.append(per.submit(gc.corpus,b))
   for f in fs:f.result()
if __name__=='__main__':main()
