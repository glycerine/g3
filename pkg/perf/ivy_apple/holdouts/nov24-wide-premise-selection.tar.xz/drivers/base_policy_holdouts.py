from common import *
import holdouts as ho,base_cost_policies as bp
root=d/'base-policy-holdouts';root.mkdir(exist_ok=True)
vs=['control','base256','base96','narrow1of4','base512'];bins={v:bp.mk(v) if v=='control' else bp.root/v/'checker/goivy_check'for v in vs}
ho.root=root
with ThreadPoolExecutor(3) as ex:
 tasks=[ex.submit(ho.measure_spec,(c,*j[1:]),dict(list(bins.items())[i:]+list(bins.items())[:i]),2)for i,(c,j) in enumerate(zip([4,12,22],ho.jobs()[:3]))]
 for f in tasks:f.result()
