from common import *
import plan_inputs as pi,holdouts as ho
root=d/'private-families';root.mkdir(exist_ok=True)
def mk():
 q=pkg/'api/api_goal_instances_check.go';v=pkg/'api/api_verification_goal.go';h=pkg/'api/api_short_premises.go';bridge=ivy.resolve()/'z3bridge_solver_model.go'
 es={bridge:(d/'stage-frontier/private/overlay/z3bridge_solver_model.go').read_text()}
 s=v.read_text();src='&shortPremisePlan{source: assertions, selected: input}';es[v]=once(s,src,'&shortPremisePlan{source:assertions,selected:input,studyBaseSize:len(base.rows),studySteps:steps,studyRelations:len(relations)}');es[h]=once(h.read_text(),'type shortPremisePlan struct {','type shortPremisePlan struct {\n studyBaseSize,studyRelations int; studySteps uint32')
 s=q.read_text();i=s.index('reuse := p.plans.enabled');s=s[:i]+'''runtime.LockOSThread();st:=trialPlanStart();defer func(){end:=trialPlanRead();trialPlanClose();runtime.UnlockOSThread()
 if sp,ok:=plan.(*shortPremisePlan);ok{fmt.Fprintf(os.Stderr,"FAMILY %d %d %d %d %t %d",sp.studyBaseSize,sp.studyRelations,sp.studySteps,maxSteps,proved,end-st)
 for _,h:=range sp.selected{fmt.Fprintf(os.Stderr," %d.%d",h.Slot(),h.Generation())};fmt.Fprintln(os.Stderr)}else{fmt.Fprintln(os.Stderr,"FAMILY-OTHER")}}()
 '''+s[i:];es[q]=once(s,'import (','import (\n"os";"fmt";"runtime"')
 es[pkg/'api/plan_meter.go']=(d/'plan-inputs/control/overlay/plan_meter.go').read_text()
 b=build(root/'checker',o=overlay(root/'overlay',es));(root/'build-info.txt').write_text(linked(b));return b
def lane(j,b):
 c,n,sp,iso,rc,ref=j;rd=root/n;rd.mkdir()
 for i in range(2):
  ord=0;tag=(0,0,'other');wdir=rd/str(i+1);wdir.mkdir();eout=bytearray()
  with gzip.open(wdir/'plans.csv.gz','wt')as f,(wdir/'stdout').open('wb')as so:
   z=csv.writer(f);z.writerow('ordinal batch goal phase plan base_rows relations steps allowance proved cost selected'.split())
   p=subprocess.Popen(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=wdir,env=dict(env,GOMAXPROCS='1',GOGC='100'),stdout=so,stderr=subprocess.PIPE)
   for line in p.stderr:
    if line.startswith(b'QUERY '):_,ba,g,ph=line.decode().split();tag=(ba,g,ph)
    elif line.startswith(b'FAMILY '):
     _,base,rels,steps,limit,ok,cost,*terms=line.decode().split();ord+=1;z.writerow([ord,*tag,'short',base,rels,steps,limit,ok,cost,' '.join(terms)])
    elif line.startswith(b'FAMILY-OTHER'):ord+=1;z.writerow([ord,*tag,'other',0,0,0,0,0,0,''])
    else:eout.extend(line)
   status=p.wait()
  assert status==rc and bytes(eout)==(ref/'stderr').read_bytes()and(wdir/'stdout').read_bytes()==(ref/'stdout').read_bytes(),(n,status,eout[-400:]);print(n,i+1,ord,flush=True)
def main():
 b=mk();js=pi.jobs()+ho.jobs()[:3]
 with ThreadPoolExecutor(8)as ex:list(ex.map(lambda j:lane(j,b),js))
if __name__=='__main__':main()
