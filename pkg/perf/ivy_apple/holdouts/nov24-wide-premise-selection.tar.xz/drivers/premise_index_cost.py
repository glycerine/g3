from common import *
import plan_inputs as pi,holdouts as ho
root=d/'premise-index-cost';root.mkdir(exist_ok=True)
def instrument():
 q=pkg/'api/api_witness_premises.go';v=pkg/'api/api_verification_definitions.go';s=q.read_text();s=once(s,'import ','import ("fmt";"os";"runtime")\nimport ')
 pos=s.index('index, err = indexWitnessPremises')
 s=s[:pos]+'''prev:=p.witnessPremises
 runtime.LockOSThread();a:=trialPlanStart()
 '''+s[pos:]
 s=once(s,'p.witnessPremises = index','''end:=trialPlanRead();trialPlanClose();runtime.UnlockOSThread()
 if index!=nil{seen:=make(map[ast.ASTHandle]bool);if prev!=nil{for _,r:=range prev.rows{seen[r.root]=true}};overlap:=0;for _,r:=range index.rows{if seen[r.root]{overlap++}};fmt.Fprintln(os.Stderr,"INDEX witness",len(index.base),len(index.rows),overlap,index.trialVisits,end-a)};p.witnessPremises=index''')
 s=once(s,'type witnessPremises struct {','type witnessPremises struct {\n trialVisits int')
 s=once(s,'index.base =','index.trialVisits=walk.visits;index.base=')
 t=v.read_text();t=once(t,'import ','import ("fmt";"os";"runtime")\nimport ')
 t=once(t,'d := &premiseDefinitions{','''prev:=p.definitions
 runtime.LockOSThread();counter:=trialPlanStart()
 defer func(){end:=trialPlanRead();trialPlanClose();runtime.UnlockOSThread()
 if curr:=p.definitions;curr!=nil&&curr.base==base{seen:=make(map[ast.ASTHandle]bool);if prev!=nil{for _,r:=range prev.base.rows{seen[r.root]=true}};overlap:=0;for _,r:=range base.rows{if seen[r.root]{overlap++}};fmt.Fprintln(os.Stderr,"INDEX definitions",len(base.base),len(base.rows),overlap,curr.trialVisits,end-counter)}}()
 d := &premiseDefinitions{''')
 t=once(t,'type premiseDefinitions struct {','type premiseDefinitions struct {\n trialVisits int');t=once(t,'p.definitions = d','d.trialVisits=walk.visits;p.definitions=d')
 b=build(root/'checker',o=overlay(root/'overlay',{q:s,v:t,pkg/'api/plan_meter.go':(d/'plan-inputs/control/overlay/plan_meter.go').read_text()}));(root/'build-info.txt').write_text(linked(b));return b
def lane(j,b):
 c,n,sp,iso,rc,ref=j
 for i in range(2):
  rd=root/n/str(i+1);rd.mkdir(parents=True);p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=rd,env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True);rest=bytearray()
  with gzip.open(rd/'indices.csv.gz','wt')as f:
   z=csv.writer(f);z.writerow('kind assertions rows previous_rows visits instructions'.split())
   for x in p.stderr.splitlines(keepends=True):
    if x.startswith(b'INDEX '):z.writerow(x.decode().split()[1:])
    else:rest.extend(x)
  assert (p.returncode,p.stdout,rest)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(n,p.returncode,rest[-300:])
  (rd/'validated').write_text('match\n');print(n,i+1,flush=True)
if __name__=='__main__':
 b=instrument()
 with ThreadPoolExecutor(8)as ex:list(ex.map(lambda j:lane(j,b),pi.jobs()+ho.jobs()[:3]))
