from common import *
import holdouts as ho,stage_frontier as sf,macro_identity as mi
root=d/'base-cost-policies';root.mkdir(exist_ok=True)
q=pkg/'api/api_verification_goal.go'
vs=['control','no-wide','base96','base256','base512','base1024','budget','narrow1of4','budget-quarter']
def edits(v):
 if v=='control':return {}
 s=q.read_text()
 a=s.index('if yes, err := check(defs.selectRows(m, symbols, true)');b=s.index('var subset',a);old=s[a:b]
 if v=='no-wide':ss=''
 elif v.startswith('base'):
  n=int(v[4:]);ss='if len(base.rows)>='+str(n)+'{'+old+'}\n'
 else:
  ss='wide:=defs.selectRows(m,symbols,true)\n';cap='min(100000,uint32(len(base.rows))*48)' if v in ('budget','budget-quarter') else '100000'
  src=old.replace('defs.selectRows(m, symbols, true), 100000','wide, '+cap)
  ss+=('if len(wide)*4<len(base.rows){'+src+'}\n'if v in ('budget-quarter','narrow1of4')else src)
 return {q:s[:a]+ss+s[b:]}
def mk(v):
 if v=='control':return d/'production-plans/checker/goivy_check'
 b=root/v;o=overlay(b/'overlay',edits(v));a=build(b/'checker',o=o);(b/'build-info.txt').write_text(linked(a));return a
def main():
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 ns={'tlb','ticket_protocol','arm_rules3','hybrid','hermes_rmw_o3','flash2','alternating_bit_protocol','test_liveness2'}
 js=[j for j in sf.jobs()if j[1]in ns]+[(c,*j[1:5],j[-1])for c,j in zip([2,6,8,10],(j for j in mi.jobs()if j[1]in ('rfn2','cf_live','dramc_nb2','raftok')))]
 ho.root=root
 with ThreadPoolExecutor(9)as ex:list(ex.map(lambda j:ho.measure_spec(j,bs,2),js))
if __name__=='__main__':main()
