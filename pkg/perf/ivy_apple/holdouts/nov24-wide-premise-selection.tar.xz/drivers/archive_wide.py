"""Collect completed rounds and validate the wide-premise selection release."""
from common import *
import io, tarfile
rd=d/'production-wide'
wall=d/'wide-wall-controls'
od=d/'wide-report'
od.mkdir(exist_ok=True)
versions=['before','after','native']
def csvout(name, fields, rows):
 with (od/name).open('w')as f:
  wr=csv.writer(f);wr.writerow(fields);wr.writerows(rows)
def summary():
 ref={r['spec']:r for p in(w/'relation-selection-release/corpus').glob('cpu-*.csv') for r in readcsv(p)if r['engine']=='reference'}
 corpus=sorted((r for p in(rd/'corpus').glob('*.csv')for r in readcsv(p)),key=lambda r:int(r['index']))
 assert len(ref)==len(corpus)==len({r['case']for r in corpus})==228
 assert all(r['stdout']==r['stderr']=='1'and r['timeout']=='0'and r['exit']==ref[r['case']]['exit']for r in corpus)
 csvout('corpus.csv',[*corpus[0],'reference_exit'],[[*r.values(),ref[r['case']]['exit']]for r in corpus])
 prod=[]
 for p in sorted(rd.glob('*/runs.csv')):
  rs=readcsv(p);assert all(r['match']=='1'for r in rs)
  groups=defaultdict(list)
  for r in rs:groups[r['round']].append(r)
  eligible=[ls for ls in groups.values()if sorted(r['engine']for r in ls)==sorted(versions)]
  if eligible:prod.append([p.parent.name,len(eligible),*[round(median(int(r['instructions:u'])for ls in eligible for r in ls if r['engine']==v))for v in versions]])
 csvout('production.csv',['spec','complete_rounds',*versions],prod)
 results=[]
 for p in sorted(wall.glob('*/runs.csv')):
  by=defaultdict(list)
  for r in readcsv(p):by[r['round'],r['attempt']].append(r)
  vs=['previous','current','native']
  good=[rs for rs in by.values()if sorted(r['engine']for r in rs)==sorted(vs)and all(min(float(r[k])for k in ['before','sibling','occupancy'])>=.95 and r['match']=='1'for r in rs)]
  assert len(good)==len({rs[0]['round']for rs in good})==7
  results.append([p.parent.name,len(good),len(by),*[median(float(r['wall'])for rs in good for r in rs if r['engine']==v)for v in vs]])
 csvout('elapsed.csv',['spec','accepted','attempts',*vs],results)
 bench=[]
 for v in versions[:2]:
  by=defaultdict(list)
  for line in(rd/(v+'.bench')).read_text().splitlines():
   if line.startswith('Benchmark'):
    g=line.split();assert g[1]=='10';by[g[0].split('/')[-1]].append([float(g[j])for j in(2,4,6,8)])
  assert all(len(ls)==7 for ls in by.values())
  for n,ls in by.items():bench.append([n,v,*map(median,zip(*ls))])
 csvout('benchmark.csv','fixture build ns_per_op refutations_per_op bytes_per_op allocations_per_op'.split(),bench)
 for n in ['elapsed.csv','production.csv','benchmark.csv']:print((od/n).read_text())
def archive():
 dst=pkg/'perf/ivy_apple/holdouts/nov24-wide-premise-selection.tar.xz'
 with tarfile.open(dst,'w:xz',preset=3)as ar:
  def put(n,b):
   h=tarfile.TarInfo(n);h.size=len(b);ar.addfile(h,io.BytesIO(b))
  def tree(path,pats,prefix):
   for p in sorted({p for pat in pats for p in path.glob(pat)if p.is_file()}):put(prefix+'/'+str(p.relative_to(path)),p.read_bytes())
  put('README.txt',b'''Wide premise selection. Both checkers use GoIvy 3d552b46c. Previous g3 b7caff4fa and current g3 37a8cf71d use the same locally replaced module; logging is compiled out of performance runs. The native checker links the in-tree Z3 fork. Go uses one logical processor and GOGC=100 for whole-verifier measurements. Summary medians for retired instructions use only complete three-engine rotations, and report their number. Production directories contain every finished individual observation at publication time, including incomplete rotations for long workloads. The time-only summary requires seven complete same-core rotating triplets with 95% process occupancy and 95% sibling idle time; raw timing results include rejected attempts. The compatibility corpus checks expected exit and byte-for-byte stdout and stderr. Scores in ok are verifier proof success; 91 unsuccessful verifications are expected. The benchmark alternated seven samples of ten iterations per case. Family observations, policy variants and index measurements are separate instrumented or prototype runs. Driver scripts preserve experimental details; original machine paths depend on this checkout. Use the checked-in Go benchmark and rotating_verification.py to repeat the production comparisons.\n''')
  tree(od,['*.csv'],'summary');tree(rd,['*/runs.csv','*.bench','focused-*.log','build-info.txt'],'production')
  tree(wall,['*/runs.csv','trace/trace.csv','trace/paxos.txt'],'wall')
  for n in ['omitted-policies','base-cost-policies','base-policy-holdouts']:tree(d/n,['*/runs.csv','*-info.txt'],n)
  tree(d/'private-families',['*/*/plans.csv.gz'],'private-families')
  tree(d/'premise-index-cost',['*/*/*.csv.gz'],'premise-index')
  tree(d,['release_wide.py','omitted_policies.py','base_cost_policies.py','base_policy_holdouts.py','private_families.py','premise_index_cost.py','timed_policy.py','wide_wall_controls.py','archive_wide.py'],'drivers')
 print(dst,dst.stat().st_size)
if __name__=='__main__':
 summary()
 if '--write'in sys.argv:archive()
