from pathlib import Path
import json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=(p/'build/.boolean-enode-cost').resolve()
k=p/'ast/ast_ref.go';s=k.read_text()
a=s.index('	// Recycling');z=s.index('	if e := m.lock()',a);s=s[:a]+s[z:]
a=s.index('	ref, e := m.allocateReference()',s.index('func (m *ASTManager) newRef('));s=s[:a]+'''	if !astValidateHandles && !ASTSourceDebug && m.freeReference != 0 {
		slot := m.freeReference
		r := m.referenceAt(slot)
		if r.generation != math.MaxUint32 {
			if node.slot != 0 { m.nodeAt(node.slot).rc++ }
			return m.reuseReference(slot,r,node), nil
		}
	}
'''+s[a:]
a=s.index('	if !astValidateHandles',s.index('func (m *ASTManager) DelRef('));z=s.index('	if e := m.lock()',a);s=s[:a]+s[z:]
a=s.index('	var failure error',s.index('func (m *ASTManager) delRef('));s=s[:a]+'''	if !astValidateHandles && !ASTSourceDebug && len(r.pending)==0 && m.releaseSurvivingReference(r) {
		m.releaseReferenceRecord(*ref)
		*ref=ASTRef{}
		return nil
	}
'''+s[a:]
dst=w/'simple-ast_ref.go';dst.write_text(s);ov=w/'simple.json';ov.write_text(json.dumps({'Replace':{str(k):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'simple','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
