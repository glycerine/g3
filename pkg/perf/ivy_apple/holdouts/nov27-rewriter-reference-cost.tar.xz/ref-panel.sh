set -eu
export GOIVY_INCLUDE=/home/jaten/ivy/ivy-lang-examples/ivy/include
w=/tmp/g3-unchanged-frame
python3 "$w/verify.py" --reference build/.bool-scan/golden --examples /home/jaten/ivy/ivy-lang-examples --perf /usr/lib/linux-tools/6.17.0-35-generic/perf --cpu 21 --rounds 7 --gc "$1" --case hybrid --case ticket_protocol --case arm_rules3 --case fba base="$w/base" refs="$w/refs" > "$w/refs-$1.csv"
