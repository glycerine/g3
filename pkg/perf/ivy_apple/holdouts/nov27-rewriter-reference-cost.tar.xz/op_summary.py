from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent; p=Path.cwd()
events=list(csv.DictReader((p/'build/.sweep-census/g3.csv').open())); groups={(int(r['batch']),int(r['row'])): (int(r['substitution_hits'])==0 and int(r['visit_hits'])==0 and int(r['reductions'])==int(r['reduction_misses'])) for r in events}
ops=['empty','substitution','application reducer','quantifier reducer','bound variable','constant','cache lookup','cache insertion','scope entry','scope exit','root append','root shrink']
tot=collections.defaultdict(lambda:[0,0]); seen=collections.Counter()
for r in csv.DictReader((w/'operations.csv').open()):
 i,b,row,k,n,raw,blank=(int(r[s]) for s in ['round','batch','row','op','calls','raw','blank_total'])
 seen[i]+=1
 for subset in (['all','no hits or nonconstant reduction'] if groups[b,row] else ['all']):
  a=tot[subset,k,i];a[0]+=n;a[1]+=raw-blank/16*n
assert len(seen)==3 and set(seen.values())=={5116*11}
for g in ['all','no hits or nonconstant reduction']:
 print(g)
 summary=[]
 for k in range(1,12):
  calls,costs=zip(*(tot[g,k,i] for i in range(1,4)));assert len(set(calls))==1
  summary.append((statistics.median(costs),ops[k],calls[0]))
 for ins,op,calls in sorted(summary,reverse=True):print(op,calls,round(ins/1e6,3),'M')
 print('total',round(sum(x[0] for x in summary)/1e6,3),'M')
