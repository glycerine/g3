from pathlib import Path
import json,os,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent;b=(p/'build/.boolean-enode-cost').resolve()
s=(p/'build/.push-gap/core.py').read_text().split('files=json.loads')[1].split("ov=w/")[0]
src=p/'build/.push-gap'
files=json.loads((src/'detail-g3.json').read_text())['Replace']
exec(s[s.index("k=p/"):])
for k,v in list(files.items()):files[str(Path(k).resolve())]=str(Path(v).resolve())
for label in sys.argv[1:]:
 ov=w/('core-'+label+'.json');ov.write_text(json.dumps({'Replace':files|json.loads((w/(label+'.json')).read_text())['Replace']}))
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/('core-'+label),'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
