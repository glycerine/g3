set -eu
w=/tmp/g3-unchanged-frame
front=$(realpath build/.boolean-enode-cost/apple-source/goivy)
export GOCACHE=/tmp/g3-nov23-day/cache
for label in old release; do
 go -C "$front" build -buildvcs=false -mod=readonly -pgo=off -tags=xtrace_off -overlay "$w/$label.json" -o "$w/apple-$label" ./cmd/goivy_check
done
sed 's@base="\$w/base" release="\$w/release"@base="$w/apple-old" release="$w/apple-release"@' "$w/apple.sh" > "$w/apple-pinned.sh"
bash "$w/apple-pinned.sh"
