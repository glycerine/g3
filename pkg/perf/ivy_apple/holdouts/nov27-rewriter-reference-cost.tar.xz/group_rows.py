"""Join historical row event counts to the same batch and ordinal counters."""
from pathlib import Path
import csv,statistics
from collections import defaultdict
p=Path.cwd();w=p/'build/.sweep-census';prev=p/'build/.push-gap'
def costs(path,engine,phase):
 groups=defaultdict(list)
 for r in csv.DictReader(path.open()):
  if r['engine']==engine and r['phase']==phase:
   groups[int(r['round']),int(r['batch'])].append(int(r['instructions']))
 out=defaultdict(list)
 for (_,b),values in groups.items():
  for i,v in enumerate(values):out[b,i].append(v)
 assert len(out)==5116 and all(len(x)==7 for x in out.values())
 return {k:statistics.median(v) for k,v in out.items()}
g=costs(prev/'core.csv','g3','core');z=costs(prev/'detail.csv','z3','rewrite')
groups=defaultdict(list)
for r in csv.DictReader((w/'g3.csv').open()):
 k=int(r['batch']),int(r['row'])
 flags=(int(r['substitution_hits'])>0,int(r['visit_hits'])>0,int(r['reductions'])>int(r['reduction_misses']))
 groups[any(flags)].append(k)
for flag,keys in sorted(groups.items()):
 print('hit or nonconstant reduction',flag,'rows',len(keys),'g3',sum(g[k] for k in keys),'native',sum(z[k] for k in keys))
