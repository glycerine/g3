from pathlib import Path
import json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=(p/'build/.boolean-enode-cost').resolve()
k=p/'ast/ast_ref.go';s=k.read_text()
a='func (m *ASTManager) NewRef(h ASTHandle) (ASTRef, error) {';s=s.replace(a,a+'''
 if !astValidateHandles && !ASTSourceDebug && m!=nil && m.freeReference!=0 && m.lockFree(){
  slot:=m.freeReference
  r:=m.referenceAt(slot)
  if r.generation!=math.MaxUint32 {
   var node astNodeRef
   if !h.IsNull(){
    var err error
    node,err=m.internal(h)
    if err!=nil{return ASTRef{},err}
    m.nodeAt(node.slot).rc++
   }
   m.freeReference=r.nextFree
   *r=astRefRecord{generation:r.generation+1,live:true,node:node,owned:node.slot!=0}
   m.liveReferences++
   return ASTRef{m.origin,slot,r.generation},nil
  }
 }
''')
a='func (m *ASTManager) DelRef(ref *ASTRef) error {';s=s.replace(a,a+'''
 if !astValidateHandles && !ASTSourceDebug && ref!=nil && m!=nil && m.lockFree() {
  r,err:=m.reference(*ref)
  if err!=nil{return err}
  if len(r.pending)==0 && (r.node.slot==0 || r.owned && m.nodeAt(r.node.slot).rc>1){
   if r.owned{m.nodeAt(r.node.slot).rc--}
   m.releaseReferenceRecord(*ref)
   *ref=ASTRef{}
   return nil
  }
 }
''')
a=w/'refs-ast_ref.go';a.write_text(s);ov=w/'refs.json';ov.write_text(json.dumps({'Replace':{str(k):str(a)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'refs','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
