import csv,collections,statistics,sys
from pathlib import Path
w=Path(__file__).resolve().parent
for filename in sys.argv[1:]:
 rows=list(csv.DictReader((w/filename).open()));d=collections.defaultdict(dict)
 if not rows:continue
 print(filename)
 if 'phase' in rows[0]:
  t=collections.Counter();counts=collections.Counter()
  for r in rows:
   key=r['phase'],r['engine'],int(r['round']);t[key]+=int(r['instructions']);counts[key]+=1
  for key,n in t.items():
   ph,e,i=key
   if counts[key]=={'core':5116,'whole':34}[ph]:d[ph,e][i]=n
  for k,v in sorted(d.items()):print(*k,len(v),round(statistics.median(v.values())/1e6,3))
 else:
  for r in rows:d[r['case'],r['engine']][r['round']]=r
  for (c,e),v in sorted(d.items()):
   if e=='base':continue
   a=d[c,'base'];ks=v.keys()&a.keys()
   if ks:print(c,e,len(ks),*[round(100*statistics.median(float(v[i][m])/float(a[i][m])-1 for i in ks),2) for m in ['instructions','cycles','milliseconds']])
