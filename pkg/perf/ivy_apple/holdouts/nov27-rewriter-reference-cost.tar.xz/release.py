from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();b=(p/'build/.boolean-enode-cost').resolve()
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
a=w/'old-ast_ref.go';a.write_bytes(subprocess.check_output(['git','show','fab0d9cf6:pkg/ast/ast_ref.go']))
for label,files in [('old',{str(p/'ast/ast_ref.go'):str(a)}),('release',{})]:
 ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':files}));subprocess.run(['go','test','-overlay',ov,'-c','-o',w/(label+'.test'),'./ast'],env=env,check=True)
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-o',w/'release','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=env,check=True)
