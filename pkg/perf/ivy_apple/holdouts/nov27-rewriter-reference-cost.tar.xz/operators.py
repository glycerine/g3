from pathlib import Path
import sys
w=Path(__file__).resolve().parent
e=sys.argv[1];name='breakdown.py' if e=='g3' else 'native-ops.py'
s=(w/name).read_text()
if e=='g3':
 s=s.replace('[12]uint64','[20]uint64')
 a="save(k,s)\nfor file,defs";assert s.count(a)==1
 s=s.replace(a,'''a="opStart:=opBegin();st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2);opEnd(2,opStart)"
assert s.count(a)==1
s=s.replace(a,"""op:=19
if rowActive{
 _,fid,kind,err:=m.AppIdentity(t);if err!=nil{return err}
 if fid==ast.NullFamilyID {op=12} else if fid==m.BasicFamilyID(){switch kind{
 case ast.ASTOpEq,ast.ASTOpIff:op=13
 case ast.ASTOpOr:op=14
 case ast.ASTOpAnd:op=15
 case ast.ASTOpNot:op=16
 case ast.ASTOpIte:op=17
 default:op=18}}
}
opStart:=opBegin();st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2);opEnd(op,opStart)""")
save(k,s)
for file,defs''')
else:
 s=s.replace("n=w/'cpp'","n=w/'cpp-operators'").replace('[12]','[20]').replace('i<12','i<20')
 a='(d/k.name).write_text(s)';assert s.count(a)==1
 s=s.replace(a,'''a="window sample(2);return m_cfg.reduce_app"
assert s.count(a)==1
s=s.replace(a,"""int op=19;if(measured_ops.fd>=0){auto fid=f->get_family_id();if(fid==null_family_id)op=12;else if(fid==m().get_basic_family_id())switch(f->get_decl_kind()){
case OP_EQ:case OP_IFF:op=13;break;case OP_OR:op=14;break;case OP_AND:op=15;break;case OP_NOT:op=16;break;case OP_ITE:op=17;break;default:op=18;break;}}
window sample(op);return m_cfg.reduce_app""")
(d/k.name).write_text(s)''')
 # The shared CSV parser lives in breakdown.py and originally exports ops 1..11.
 s=s.replace("exec('ex=ex'+code)","exec('ex=ex'+code.replace('range(1,12)','range(12,20)'))")
s=s.replace('range(1,12):wr.writerow','range(12,20):wr.writerow')
if e=='g3':
 s=s.replace("w/'operations.csv'","w/'operators-g3.csv'").replace("w/'operations'","w/'operators-g3'").replace("'operations-'","'operator-kind-'").replace("'operations.json'","'operator-kind.json'")
else:s=s.replace("w/'native-operations.csv'","w/'operators-z3.csv'")
exec(compile(s,name,'exec'))
