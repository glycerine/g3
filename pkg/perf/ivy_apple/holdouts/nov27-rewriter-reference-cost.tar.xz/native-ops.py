from pathlib import Path
import json,os,subprocess,sys,re,shlex,shutil,csv
w=Path(__file__).resolve().parent;p=Path.cwd();root=p.parent;b=(p/'build/.boolean-enode-cost').resolve();f=b/'frontend/goivy';src=root/'src';n=w/'cpp';n.mkdir(exist_ok=True);d=n/'ast/rewriter';d.mkdir(parents=True,exist_ok=True)
hdr=r'''#pragma once
#include <unistd.h>
#include <sys/syscall.h>
#include <linux/perf_event.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
struct counter { int fd=-1;bool busy=false;unsigned long long costs[12]{},counts[12]{};
 unsigned long long rd(){unsigned long long v[3]{};if(read(fd,v,24)!=24||v[1]!=v[2]||!v[1])abort();return v[0];}
 unsigned long long start(){if(fd<0||busy)return 0;busy=true;return rd();}
 void end(int k,unsigned long long t){if(!t)return;costs[k]+=rd()-t;counts[k]++;busy=false;}
 void begin(){perf_event_attr a{};a.size=sizeof(a);a.type=PERF_TYPE_HARDWARE;a.config=PERF_COUNT_HW_INSTRUCTIONS;a.read_format=3;a.exclude_kernel=a.exclude_hv=1;fd=syscall(SYS_perf_event_open,&a,0,-1,-1,0);if(fd<0)abort();memset(costs,0,sizeof(costs));memset(counts,0,sizeof(counts));for(int i=0;i<16;i++){auto t=start();end(0,t);}}
 void finish(){if(busy||close(fd))abort();fd=-1;fprintf(stderr,"OPS [");for(int i=0;i<12;i++)fprintf(stderr,"%s%llu",i?" ":"",counts[i]);fprintf(stderr,"] [");for(int i=0;i<12;i++)fprintf(stderr,"%s%llu",i?" ":"",costs[i]);fprintf(stderr,"]\n");}
};extern counter measured_ops;
struct window {int k;unsigned long long t;window(int k):k(k),t(measured_ops.start()){}~window(){measured_ops.end(k,t);}};
'''
(n/'ops.hpp').write_text(hdr)
k=src/'ast/rewriter/rewriter_def.h';s=k.read_text()
for op,call in [(1,'m_cfg.get_subst(t, new_t, new_t_pr)'),(2,'m_cfg.reduce_app(f, new_num_args, new_args, m_r, m_pr2)'),(3,'m_cfg.reduce_quantifier(q, new_body, new_pats.c_ptr(), new_no_pats.c_ptr(), m_r, m_pr)')]:
 assert s.count(call)==1;s=s.replace(call,'([&]{window sample('+str(op)+');return '+call+';}())')
for op,sig in [(4,'::process_var(var * v) {'),(5,'::process_const(app * t) {')]:
 assert s.count(sig)==1;s=s.replace(sig,sig+' window sample('+str(op)+');')
(d/k.name).write_text(s)
k=src/'smt/asserted_formulas.cpp';s=k.read_text();start=s.index('unsigned asserted_formulas::propagate_values(unsigned i)');end=s.index('void asserted_formulas::update_substitution',start)
a='m_rewriter(n, new_n, new_pr);';assert s[start:end].count(a)==1;s=s[:start]+s[start:end].replace(a,'if(getenv("G3_PUSH_PHASES")){measured_ops.begin();'+a+'measured_ops.finish();}else{'+a+'}')+s[end:]
dst=n/k.name;dst.write_text('counter measured_ops;\n'+s)
build=root/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l);mk=(build/'Makefile').read_text();lib=n/'lib.a';shutil.copyfile(f/'z3vendor/native_lib/libz3.a',lib)
for unit,includes in [(dst,39),(src/'ast/rewriter/th_rewriter.cpp',12)]:
 inc=shlex.split(re.search('^includes_'+str(includes)+' = (.*)$',mk,re.M)[1]);obj=n/(unit.stem+'.o');subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),'-I'+str(n),*inc,'-include',str(n/'ops.hpp'),'-o',obj,unit],cwd=build,check=True);subprocess.run(['ar','r',lib,obj],check=True)
files=json.loads((p/'build/.sweep-census/z3.json').read_text())['Replace'];k=f/'smt/quantifier.go';dst=n/k.name;dst.write_text(k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
for original,v in list(files.items()):
 files[original]=files[str(Path(original).resolve())]=str(dst if Path(original).resolve()==k else Path(v).resolve())
ov=n/'overlay.json';ov.write_text(json.dumps({'Replace':files}));exe=n/'native'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off,classic_z3','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
code=(w/'breakdown.py').read_text().split("ex=Path('/home/jaten/ivy/ivy-lang-examples')",1)[1].replace("w/'operations.csv'","w/'native-operations.csv'")
ex=Path('/home/jaten/ivy/ivy-lang-examples');exec('ex=ex'+code)
