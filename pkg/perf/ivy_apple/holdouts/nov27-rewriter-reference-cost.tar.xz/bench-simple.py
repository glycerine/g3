from pathlib import Path
import subprocess,csv,re,sys
w=Path(__file__).resolve().parent;writer=csv.writer(sys.stdout);writer.writerow(['round','engine','case','ns/op','B/op','allocs/op'])
for i in range(9):
 for e in (['old','simple'] if i%2==0 else ['simple','old']):
  a=subprocess.check_output(['taskset','-c','14',w/(e+'.test'),'-test.run=^$','-test.bench=^BenchmarkASTRecycledReference$','-test.benchtime=1000000x'],text=True)
  matches=re.findall(r'BenchmarkASTRecycledReference/(\w+)(?:-\d+)?\s+1000000\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',a);assert len(matches)==2,a
  for m in matches:writer.writerow([i+1,e,*m])
