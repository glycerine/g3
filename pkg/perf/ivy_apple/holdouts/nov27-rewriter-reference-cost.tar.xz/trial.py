from pathlib import Path
import sys,json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=(p/'build/.boolean-enode-cost').resolve()
k=p/'ast/ast_core_accessors.go';s=k.read_text()+'''
// TryCollapseHeldChildren exchanges one or two owned, shared child references
// for one reference to parent. The caller holds all handles in this manager.
// A pending register release or a child destructor requires the ordinary path.
func (m *ASTManager) TryCollapseHeldChildren(register ASTRef, children []ASTHandle, parent ASTHandle) bool {
 if astValidateHandles || len(children)==0 || len(children)>2 || !m.lockFree() ||
  register.slot==0 || m.referenceAt(register.slot).node.slot!=0 {return false}
 first:=m.nodeAt(children[0].slot)
 if first.rc<=1{return false}
 if len(children)==2 {
  second:=m.nodeAt(children[1].slot)
  if second.rc<=1 || first==second && first.rc<=2 {return false}
  second.rc--
  children[1]=ASTHandle{}
 }
 first.rc--
 m.nodeAt(parent.slot).rc++
 children[0]=parent
 return true
}
'''
a=w/'ast_core_accessors.go';a.write_text(s);files={str(k):str(a)}
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text()
anchor='''} else {
			h := t
			if fr.newChild()'''
assert s.count(anchor)==1
s=s.replace(anchor,'''} else {
            if !fr.newChild() && !fr.cacheResult() && m.TryCollapseHeldChildren(r.r,c.results[fr.spos:],t) {
                c.results=c.results[:fr.spos+1]
                c.frames=c.frames[:fi]
                return nil
            }
			h := t
			if fr.newChild()''')
a=w/'rewriter_engine.go';a.write_text(s);files[str(k)]=str(a)
for label,extra in [('base',{}),('trial',files)]:
 ov=w/(label+'.json');ov.write_text(json.dumps({'Replace':extra}))
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/label,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
