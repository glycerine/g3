"""Count outermost rewrite operations on matched first-push rows."""
from pathlib import Path
import csv,json,os,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();b=(p/'build/.boolean-enode-cost').resolve()
files=json.loads((w/'core-release.json').read_text())['Replace']
def save(k,s):
 dst=w/('operations-'+k.name);dst.write_text(s);files[str(k)]=str(dst)
src=(p/'build/.push-gap/detail-phase-zz_first_push_sample.go').read_text()
src=src[:src.index('func samplePushPass')].replace('package smtcore','package rewriter').replace('"runtime"','').replace('"time"','')
src+='''
var operationFD uintptr
var rowActive,inside bool
var costs,counts [12]uint64
func BeginObservedRow() {
 var a struct{Type,Size uint32; Config,Period,Sample,Format,Flags uint64; Tail [16]byte}
 a.Size=uint32(unsafe.Sizeof(a));a.Config=1;a.Format=3;a.Flags=1<<5|1<<6
 var e syscall.Errno
 operationFD,_,e=syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN,uintptr(unsafe.Pointer(&a)),0,^uintptr(0),^uintptr(0),0,0)
 if e!=0{panic(e)};rowActive=true; costs=[12]uint64{}; counts=[12]uint64{}
 for i:=0;i<16;i++{t:=opBegin();opEnd(0,t)}
}
func opRead() uint64{v:=ivyThreadRead(operationFD);if v[1]!=v[2] || v[1]==0{panic("multiplexed")};return v[0]}
func opBegin() uint64{if !rowActive||inside{return 0};inside=true;return opRead()}
func opEnd(k int,start uint64){if start==0{return};n:=opRead()-start;costs[k]+=n;counts[k]++;inside=false}
func EndObservedRow(){if inside{panic("unbalanced")};rowActive=false;if syscall.Close(int(operationFD))!=nil{panic("close")};fmt.Fprintln(os.Stderr,"OPS",counts,costs)}
'''
save(p/'ast/rewriter/zz_opstudy.go',src)
k=p/'smtcore/smt_asserted_formulas.go';s=Path(files[str(k)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/ast/rewriter";')
s=s.replace('endCore=samplePushPass()', 'rewriter.BeginObservedRow();endCore=samplePushPass()').replace('endCore("core")','endCore("core");rewriter.EndObservedRow()');save(k,s)
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text()
for op,line in [(1,'sub, subProof, found, e := r.cfg.GetSubst(t)'),(2,'st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)'),(3,'done, e := r.cfg.ReduceQuantifier(q, newBody, pa, na, r.r, r.pr)')]:
 assert s.count(line)==1;s=s.replace(line,'opStart:=opBegin();'+line+';opEnd('+str(op)+',opStart)')
for op,signature in [(4,'processVar(t ast.ASTHandle)'),(5,'processConst(t ast.ASTHandle)')]:
 i=s.index('{',s.index('func (r *rewriterEngine) '+signature));s=s[:i+1]+f'\n defer opEnd({op},opBegin())\n'+s[i+1:]
save(k,s)
for file,defs in [('rewriter_core.go',[(6,'(c *rewriterCore) getCached('),(7,'(c *rewriterCore) cacheResult('),(8,'(c *rewriterCore) beginScope('),(9,'(c *rewriterCore) endScope(')]),('rewriter_roots.go',[(10,'appendRewriterRoot('),(11,'shrinkRewriterRoots(')])]:
 k=p/'ast/rewriter'/file;s=k.read_text()
 for op,signature in defs:
  i=s.index('{',s.index('func '+signature));s=s[:i+1]+f'\n defer opEnd({op},opBegin())\n'+s[i+1:]
 save(k,s)
ov=w/'operations.json';ov.write_text(json.dumps({'Replace':files}));exe=w/'operations'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=p/'build/.bool-scan/golden/reference/hybrid'
with (w/'operations.csv').open('w') as f:
 wr=csv.writer(f);wr.writerow(['round','batch','row','op','calls','raw','blank_total'])
 for rnd in range(3):
  r=subprocess.run(['taskset','-c','12',exe,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,capture_output=True,check=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
  keep=[];pending=[];count=0
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'OPS '):
    counts,costs=line.decode().strip()[5:-1].split('] [');pending.append((list(map(int,counts.split())),list(map(int,costs.split()))))
   elif line.startswith(b'STAGE-COUNT '):
    _,bt,g,ph,*_=line.split()
    if ph==b'first':
     for idx,(counts,costs) in enumerate(pending):
      assert counts[0]==16
      for op in range(1,12):wr.writerow([rnd+1,int(bt),idx,op,counts[op],costs[op],costs[0]])
     count+=len(pending);pending=[]
    assert not pending
   elif not line.startswith(b'PASS-COUNT '):keep.append(line)
  assert count==5116 and r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
