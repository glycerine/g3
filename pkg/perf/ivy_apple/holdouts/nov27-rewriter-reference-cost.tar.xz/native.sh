set -eu
w=/tmp/g3-unchanged-frame
b=$(realpath build/.boolean-enode-cost)
export GOCACHE=/tmp/g3-nov23-day/cache
export GOIVY_INCLUDE=/home/jaten/ivy/ivy-lang-examples/ivy/include
go -C "$b/frontend/goivy" build -pgo=off -buildvcs=false -mod=readonly -modfile "$b/heap/study.mod" -tags=xtrace_off,classic_z3 -o "$w/native" ./cmd/goivy_check
python3 "$w/verify.py" --reference build/.bool-scan/golden --examples /home/jaten/ivy/ivy-lang-examples --perf /usr/lib/linux-tools/6.17.0-35-generic/perf --cpu 21 --rounds 7 --case hybrid --case ticket_protocol --case arm_rules3 --case fba release="$w/release" native="$w/native" >"$w/native.csv"
