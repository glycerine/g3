from collections import defaultdict,Counter
from pathlib import Path
import csv,statistics
w=Path(__file__).resolve().parent
ops=['','Substitution lookup','Nonconstant application reducer','Quantifier reducer','Variable processing','Constant processing']
counts={};sums=defaultdict(float)
for engine,path in [('g3','operations.csv'),('z3','native-operations.csv')]:
 for r in csv.DictReader((w/path).open()):
  rnd,b,row,k,n,raw,blank=map(int,[r[f] for f in ['round','batch','row','op','calls','raw','blank_total']])
  if 1<=k<=5:
   if rnd==1:counts[engine,b,row,k]=n
   else:assert counts[engine,b,row,k]==n
   sums[engine,k,rnd]+=raw-n*blank/16
for k in range(1,6):
 coords=[(b,i) for e,b,i,o in counts if e=='g3' and k==o];assert len(coords)==5116
 different=sum(counts['g3',b,i,k]!=counts['z3',b,i,k] for b,i in coords)
 a,b=[statistics.median(sums[e,k,r] for r in range(1,4))/1e6 for e in ['g3','z3']]
 print(ops[k],sum(counts['g3',bt,i,k] for bt,i in coords),sum(counts['z3',bt,i,k] for bt,i in coords),'different rows',different,'millions',round(a,3),round(b,3),round(a-b,3))
