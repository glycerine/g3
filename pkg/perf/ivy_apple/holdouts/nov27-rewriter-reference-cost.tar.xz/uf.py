from pathlib import Path
import json,os,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;b=(p/'build/.boolean-enode-cost').resolve()
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text()
a='''		// f->is_associative()''';i=s.index(a);i=s.rindex('\n		d, e := m.GetDecl(t)',0,i);s=s[:i]+'''
        if !fr.newChild() && !ast.ASTValidateHandles && !ast.ASTSourceDebug {
            if cfg,ok:=r.cfg.(*theoryRewriterConfiguration); ok && (!cfg.pullCheapITE || n!=2) {
                _,family,_,err:=m.AppIdentity(t)
                if err!=nil{return err}
                if family==ast.NullFamilyID{
                    if err=m.ResetRefHeld(r.pr2);err!=nil{return err}
                    if err=m.SetRefHeld(r.r,t);err!=nil{return err}
                    return r.finish(fr,false,true)
                }
            }
        }'''+s[i:]
files={str(k):str(w/'uf-rewriter_engine.go')};(w/'uf-rewriter_engine.go').write_text(s)
ov=w/'uf.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'uf','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
