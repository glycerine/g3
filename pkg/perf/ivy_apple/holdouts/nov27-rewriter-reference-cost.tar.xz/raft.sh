set -eu
export GOIVY_INCLUDE=/home/jaten/ivy/ivy-lang-examples/ivy/include
w=/tmp/g3-unchanged-frame
run() {
 python3 "$w/verify.py" --reference "$1" --examples /home/jaten/ivy/ivy-lang-examples --perf /usr/lib/linux-tools/6.17.0-35-generic/perf --cpu 16 --rounds 3 --case "$2" base="$w/base" release="$w/release" >"$w/clean-$2.csv"
}
run build/.witness-origin/proofs raft
