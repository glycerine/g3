package pattern

import (
	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/util/symbol"
	"math/rand"
	"reflect"
	"testing"
)

func (c *patternCandidates) collectEveryOccurrence(body ast.ASTHandle) (err error) {
	if c == nil || c.closed {
		return ast.ErrASTHandle
	}
	if len(c.candidates) != 0 || len(c.collectRefs) != 0 {
		return ast.ErrASTDomain
	}
	arith, err := c.manager.ArithmeticFamilyID()
	if err != nil {
		return err
	}
	defer func() {
		if e := c.releaseCollectRefs(); err == nil {
			err = e
		}
	}()
	cache := make(map[collectKey]*collectedInfo)
	stack := []collectKey{{node: body}}
	for len(stack) != 0 {
		key := stack[len(stack)-1]
		if err = c.traceCollectVisit(key); err != nil {
			return err
		}
		if err = c.traceCollectInfo(key); err != nil {
			return err
		}
		kind, e := c.manager.GetKind(key.node)
		if e != nil {
			return e
		}
		visited := true
		switch kind {
		case ast.ASTApp:
			count, e := c.manager.GetNumArgs(key.node)
			if e != nil {
				return e
			}
			for i := count; i != 0; i-- {
				child, e := c.manager.GetArg(key.node, i-1)
				if e != nil {
					return e
				}
				childKey := collectKey{node: child, delta: key.delta}
				if _, done := cache[childKey]; !done {
					stack = append(stack, childKey)
					visited = false
				}
			}
		case ast.ASTQuantifier:
			count, e := c.manager.GetNumDeclarations(key.node)
			if e != nil {
				return e
			}
			child, e := c.manager.GetQuantifierBody(key.node)
			if e != nil {
				return e
			}
			childKey := collectKey{node: child, delta: key.delta + count}
			if _, done := cache[childKey]; !done {
				stack = append(stack, childKey)
				visited = false
			}
		}
		if visited {
			stack = stack[:len(stack)-1]
			if err = c.collectNode(cache, key, arith); err != nil {
				return err
			}
		}
	}
	return nil
}
func TestStudySharedPatternReference(t *testing.T) {
	m := patternManager(t)
	pin := func(h ast.ASTHandle, e error) ast.ASTHandle {
		patternMust(t, e)
		patternMust(t, m.IncRef(h))
		t.Cleanup(func() { patternMust(t, m.DecRef(h)) })
		return h
	}
	b := pin(m.MkBoolSort())
	pool := []ast.ASTHandle{}
	for i := uint32(0); i < 7; i++ {
		pool = append(pool, pin(m.MkVar(i, b)))
	}
	gd := pin(m.MkFuncDecl(symbol.Numerical(650), nil, b, ast.ASTFuncDeclInfo{}))
	pool = append(pool, pin(m.MkApp(gd, nil)))
	decls := map[int]ast.ASTHandle{}
	for _, w := range []int{1, 2, 4, 8, 16, 32} {
		domain := make([]ast.ASTHandle, w)
		for i := range domain {
			domain[i] = b
		}
		decls[w] = pin(m.MkFuncDecl(symbol.Numerical(uint32(700+w)), domain, b, ast.ASTFuncDeclInfo{}))
	}
	random := rand.New(rand.NewSource(241124))
	pick := func() ast.ASTHandle { return pool[random.Intn(len(pool))] }
	for i := 0; i < 150; i++ {
		w := []int{1, 2, 4, 8, 16, 32}[random.Intn(6)]
		n := random.Intn(5)
		args := make([]ast.ASTHandle, w)
		a, z := pick(), pick()
		for j := range args {
			if random.Intn(4) == 0 {
				args[j] = z
			} else {
				args[j] = a
			}
		}
		var h ast.ASTHandle
		switch n {
		case 0:
			h = pin(m.MkQuantifier(ast.ASTQuantifierSpec{Forall: true, Sorts: []ast.ASTHandle{b}, Names: []symbol.Symbol{symbol.Numerical(1)}, Body: a}))
		case 1:
			h = pin(m.MkFamilyApp(m.BasicFamilyID(), ast.ASTOpAnd, nil, args))
		default:
			h = pin(m.MkApp(decls[w], args))
		}
		pool = append(pool, h)
	}
	for i := 0; i < 10000; i++ {
		n := 1 + random.Intn(7)
		a, z := pick(), pick()
		args := make([]ast.ASTHandle, 8+random.Intn(20))
		for j := range args {
			switch j % 4 {
			case 0:
				args[j] = z
			case 2:
				args[j] = pick()
			default:
				args[j] = a
			}
		}
		root, e := m.MkFamilyApp(m.BasicFamilyID(), ast.ASTOpAnd, nil, args)
		patternMust(t, e)
		patternMust(t, m.IncRef(root))
		var excluded []ast.ASTHandle
		if i%3 == 0 {
			excluded = []ast.ASTHandle{a}
		}
		x, e := newPatternCandidates(m, uint32(n), excluded, false)
		patternMust(t, e)
		y, e := newPatternCandidates(m, uint32(n), excluded, false)
		patternMust(t, e)
		patternMust(t, x.collectEveryOccurrence(root))
		patternMust(t, y.collect(root))
		if !reflect.DeepEqual(x.candidates, y.candidates) || !reflect.DeepEqual(x.info, y.info) {
			t.Fatalf("mismatched candidate order or metadata on query %d", i)
		}
		patternMust(t, y.close())
		patternMust(t, x.close())
		patternMust(t, m.DecRef(root))
	}
}
