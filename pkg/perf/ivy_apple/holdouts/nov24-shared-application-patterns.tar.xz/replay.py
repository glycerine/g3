"""Run the shared-application pattern benchmark with both g3 versions and in-tree Z3."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pkg', required=True, type=Path)
parser.add_argument('--cpu', required=True, type=int)
parser.add_argument('--rounds', type=int, default=7)
parser.add_argument('--width', type=int, choices=(4, 16, 128, 512), action='append')
parser.add_argument('--perf', default='perf')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
pkg = args.pkg.resolve()
sys.path.insert(0, str(pkg / 'perf/ivy_apple'))
from native_benchmark import build_native

short = {4: 1500, 16: 700, 128: 70, 512: 10}
env = dict(os.environ, GOMAXPROCS='1')
with tempfile.TemporaryDirectory() as scratch, args.output.open('x', newline='') as out:
    tmp = Path(scratch)
    src = tmp / 'collect.go'
    src.write_bytes(subprocess.check_output(['git', 'show', 'b4faa2855:pkg/ast/pattern/collect.go'], cwd=pkg))
    ov = tmp / 'overlay.json'
    ov.write_text(json.dumps({'Replace': {str(pkg / 'ast/pattern/collect.go'): str(src)}}))
    for name, flags in [('before', ['-overlay=' + str(ov)]), ('after', [])]:
        subprocess.run(['go', 'test', '-pgo=off', '-tags=xtrace_off', *flags, '-c', '-o', tmp / name, './ast/pattern'], cwd=pkg, check=True)
    build_native(pkg.parent / 'build', tmp / 'native', pkg.parent / 'src/test/perf/pattern_shared_applications.cpp')
    z = csv.writer(out)
    z.writerow('round engine width count ns bytes allocs instructions cycles'.split())
    engines = ['before', 'after', 'native']
    for i in range(args.rounds):
        pivot = i % len(engines)
        for engine in engines[pivot:] + engines[:pivot]:
            for width in args.width or short:
                for count in [short[width], 3 * short[width]]:
                    cmd = [tmp / engine, str(width), str(count)]
                    if engine != 'native':
                        cmd = [tmp / engine, '-test.cpu=1', '-test.run=^$',
                               f'-test.bench=^BenchmarkPatternSharedApplications$/^Width{width}$',
                               f'-test.benchtime={count}x']
                    log = tmp / 'perf.txt'
                    run = subprocess.run(['taskset', '-c', str(args.cpu), args.perf, 'stat', '-x,',
                                          '-e', 'instructions:u,cycles:u', '-o', log, '--', *cmd],
                                         env=env, check=True, text=True, capture_output=True)
                    if engine == 'native':
                        metrics = [run.stdout.strip().split(',')[-1], '', '']
                    else:
                        metrics = re.search(r'([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op', run.stdout).groups()
                    counts = [int(line.split(',')[0]) for line in log.read_text().splitlines() if ':u' in line]
                    if len(counts) != 2:
                        raise RuntimeError(f'missing hardware counters in {log.read_text()}')
                    z.writerow([i + 1, engine, width, count, *metrics, *counts])
                    out.flush()
