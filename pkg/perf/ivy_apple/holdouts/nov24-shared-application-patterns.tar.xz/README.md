# Shared applications during quantifier pattern inference

The two committed benchmarks build the same universally quantified Boolean DAG. Two applications of arity N alternate in an N-argument conjunction. Each application alternates the same two bound variables. Both engines verify the inferred pattern count and ordered term identities. The timed loop infers and then releases the new quantifier. The parent and original body remain live.

    python3 replay.py --pkg /path/to/g3/pkg --cpu 4 --output results.csv
    python3 replay.py --pkg /path/to/g3/pkg --cpu 4 --rounds 1 --width 16 --output smoke.csv

Use a configured in-tree native build with libz3.a. Take each engine's difference in process counters between the long and short run at the same width and rotation, then divide by the difference in iteration counts. Seven such slopes determine each median. The bytes and allocation columns come from the Go harness. The native harness does not count allocations.

quiet.csv compares the uninstrumented elapsed time on a physical core. Each member of an accepted rotating triple had to occupy at least 95% of its assigned CPU while its hardware sibling was at least 95% idle. quiet.py repeats the timing experiment given prebuilt Go test binaries and the in-tree native benchmark binary.

The coverage observer counted completed cache hits and arities in the original collector across seventeen complete Ivy runs. Counts include only binder depth zero. The arity_min column is the lower bound of a bucket with the next boundary exclusive. No wide application qualified for the new shortcut on those runs.

threshold-micro.csv compares lookup thresholds 2, 8 and 32 with the unmodified collector and native Z3. The threshold prototypes explicitly retained each original temporary reference. The final production version also uses the same existing saveCollectInfo helper as original visits. The two verifier panels preserve process counters. The five tagged-package logs, broader solver and API tests and all compatibility corpus comparisons belong to the production implementation.

The oracle test includes the original unoptimized collector from b4faa2855 under a separate name. It compares candidate identity, discovery order, free variable sets and expression sizes on 10,000 generated DAG queries with nested quantifiers and repeated terms. To repeat it, point a Go test overlay from ast/pattern/shared_walk_oracle_test.go in the pkg module to oracle/shared_walk_oracle_test.go and run go test -tags=xtrace_off -overlay=overlay.json -run TestStudySharedPatternReference ./ast/pattern.
