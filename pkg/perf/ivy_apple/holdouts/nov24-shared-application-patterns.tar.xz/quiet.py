import argparse,csv,os,re,sys,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser()
for name in ['pkg','before','after','native','output']:p.add_argument('--'+name,required=True,type=Path)
args=p.parse_args();pkg=args.pkg.resolve();env=os.environ.copy()
def run(cmd,**kw):return subprocess.run(cmd,check=True,**kw)
import resource
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
from rotating_verification import ticks,idle,thread_siblings

def usage():
 u=resource.getrusage(resource.RUSAGE_CHILDREN);return u.ru_utime+u.ru_stime
def main():
 cpus=[c for c in sorted(os.sched_getaffinity(0)) if c==min([c,*thread_siblings(c)])];peers={c:[c,*thread_siblings(c)]for c in cpus};allcpu=set().union(*peers.values())
 bs={'before':args.before.resolve(),'after':args.after.resolve(),'native':args.native.resolve()};vs=list(bs)
 with args.output.open('x')as f:
  z=csv.writer(f);z.writerow('width round attempt engine cpu count ns occupancy sibling_idle accepted'.split())
  for width,counts in [(16,[12000,25000,60000]),(128,[450,6000,3000]),(512,[22,1700,220])]:
   done=0
   for a in range(1,121):
    t0=ticks(allcpu);time.sleep(1);t1=ticks(allcpu);rates={c:min(idle(t0,t1,k)for k in peers[c])for c in cpus};cpu=max(rates,key=rates.get)
    if rates[cpu]<.93:continue
    ok=True;rows=[]
    for v in vs[done%3:]+vs[:done%3]:
     n=counts[vs.index(v)];ts=ticks(peers[cpu]);t=time.monotonic();u=usage()
     cmd=[bs[v],str(width),str(n)]if v=='native'else[bs[v],'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkPatternSharedApplications$/^Width'+str(width)+'$','-test.benchtime='+str(n)+'x']
     r=run(['taskset','-c',str(cpu),*cmd],env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True);occ=(usage()-u)/(time.monotonic()-t);te=ticks(peers[cpu]);sib=min((idle(ts,te,k)for k in peers[cpu]if k!=cpu),default=1.);ok=ok and min(occ,sib)>=.95
     ns=float(r.stdout.strip().split(',')[-1])if v=='native'else float(re.search(r'([\d.]+) ns/op',r.stdout)[1]);rows.append([width,done+1,a,v,cpu,n,ns,occ,sib])
    for row in rows:z.writerow([*row,int(ok)])
    f.flush()
    if ok:done+=1
    if done==7:break
   print(width,done,'quiet triples',flush=True)
if __name__=='__main__':main()
