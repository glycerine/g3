from pathlib import Path
import os
w=Path(__file__).resolve().parent;os.environ.update(EXE='select',CASES='13 228',MODES='off half',ROUNDS='5',CPU='30',STEM='select-full')
exec(Path('/tmp/g3-witness-match/panel.py').read_text().replace('SHARED_BIND=','WIDTH_TRIAL='))
