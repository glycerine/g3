from pathlib import Path
import csv,subprocess as sp,os,re
w=Path(__file__).resolve().parent;p=Path.cwd()
with (w/'query-results.csv').open('w') as f:
 o=csv.writer(f);o.writerow('query engine result instances decisions conflicts'.split())
 for path in sorted((w/'queries').glob('*.smt2')):
  answers=[]
  for tag,exe in [('g3',Path(os.getenv('G3_CLI','/tmp/g3-witness-match/g3'))),('z3',p.parent/'build/z3')]:
   r=sp.run([exe,'smt.macro_finder=true',path],capture_output=True,text=True,timeout=30,check=True);answer=r.stdout.splitlines()[0];assert not r.stderr and answer in ('sat','unsat')
   answers.append(answer);stats=dict(re.findall(r':([\w-]+)\s+(\d+)',r.stdout));o.writerow([path.name,tag,answer,*[stats.get(k,0) for k in ('quant-instantiations','decisions','conflicts')]])
  assert answers[0]==answers[1];f.flush()
