from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'run.py').read_text().replace("w/mode,ex/name","w/('arrival-'+mode),ex/name").replace("b'R',b'A'","b'R',b'A',b'Q',b'D'").replace("w/'instances.csv'","w/'arrival-events.csv'").replace("w/'pushes.csv'","w/'arrival-pushes.csv'").replace('range(3)','range(1)')
exec(s)
