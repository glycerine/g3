from pathlib import Path
import sys
w=Path(__file__).resolve().parent
s=(w/'build.py').read_text()
k="  f=w/(name+'.cpp')";s=s.replace(k,"""  if name=='qi_queue':
   for op,label in [('m_new_entries.push_back(entry(f, cost, generation));','Q'),('m_delayed_entries.push_back(curr);','D')]:
    assert s.count(op)==1;s=s.replace(op,op+'if(getenv("QI_COUNTER_FD"))fprintf(stderr,"'+label+' 0 0\\\\n");')
"""+k)
k="j=w/(mode+'.json')";s=s.replace(k,"""if not native:
 path=p/'smtcore/smt_qi_queue_schedule.go';s=path.read_text().replace('import "github.com','import ("os";"fmt");import "github.com',1)
 for op,label in [('q.newEntries = append(q.newEntries, SMTQIQueueEntry{Fingerprint: fingerprint, Cost: cost, Generation: generation})','Q'),('q.delayedEntries = append(q.delayedEntries, entry)','D')]:
  assert s.count(op)==1;s=s.replace(op,op+';if os.Getenv("QI_COUNTER_FD")!=""{fmt.Fprintln(os.Stderr,"'+label+' 0 0")}')
 put(path,s)
"""+k)
s=s.replace("w/(name+'.cpp')","w/('arrival-'+name+'.cpp')").replace("w/'study.a'","w/'arrivals.a'").replace("d=w/(mode+'-'","d=w/('arrival-'+mode+'-'").replace("j=w/(mode+'.json')","j=w/('arrival-'+mode+'.json')").replace("'-o',w/mode","'-o',w/('arrival-'+mode)")
exec(s)
