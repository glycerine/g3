from pathlib import Path
from collections import Counter
import csv,os,subprocess as sp
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');names=(ref/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())};ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'instances.csv').open('w') as f,(w/'pushes.csv').open('w') as g:
 out=csv.writer(f);out.writerow('case round engine batch goal event flag instructions'.split());push=csv.writer(g);push.writerow('case round engine batch goal candidates'.split())
 for case in (3,6,12,10,2,4):
  name=names[case-1];d=ref/'compat'/str(case)/'1/native';expect=(codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes())
  for i in range(3):
   for mode in (['g3','native'] if i%2==0 else ['native','g3']):
    r=sp.run(['taskset','-c','18',w/mode,ex/name],cwd=w,capture_output=True,timeout=90,env=dict(os.environ,GOGC='off',XTRACE_OFF='1',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
    stay=bytearray();active=None;counts=Counter()
    for line in r.stderr.splitlines(keepends=True):
     a=line.split()
     if line.startswith(b'OPEN '):assert active is None;active=tuple(map(int,a[1:]));counts.clear()
     elif line.startswith(b'STAGE-COUNT '):
      if a[3]==b'first':
       assert tuple(map(int,a[1:3]))==active and a[6]==a[7];assert counts['C',0]==counts['S',0]+counts['S',1]==counts['R',0]+counts['R',1] and counts['R',0]==counts['A',0];push.writerow([case,i,mode,*active,counts['C',0]+counts['C',1]]);active=None
     elif a and a[0] in (b'C',b'S',b'R',b'A'):
      assert active and len(a)==3;op=a[0].decode();flag,n=map(int,a[1:]);counts[op,flag]+=1;out.writerow([case,i,mode,*active,op,flag,n])
     else:stay.extend(line)
    assert active is None and (r.returncode,r.stdout,stay)==expect,(case,i,mode,r.returncode,stay[-800:]);f.flush();g.flush()
