"""Prototype reuse of a plan instruction when all operands match the last tuple."""
from pathlib import Path
import json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());rep=ov['Replace']
def put(path,s):
 f=w/('partial-'+path.name);f.write_text(s);rep[str(path)]=str(f)
path=p/'ast/ast_rewriter_access.go';s=path.read_text()+'''
func(m *ASTManager) TrialRepeatApp(h ASTHandle)bool{
 if m.freeNode==0 || !m.IsLiveHandle(h){return false};n:=m.nodeAt(m.freeNode);if n.generation==^uint32(0){return false};n.generation++;return true
}
''';put(path,s)
path=p/'ast/rewriter/ground_instance.go';s=path.read_text().replace('"errors"','"errors";"os";"fmt"')
s=s.replace('type groundInstancePlan struct {','''var partialTrial=os.Getenv("PARTIAL_TRIAL")
var partialHits,partialOps int
type groundInstancePlan struct {
 dirty []bool
 complete bool''')
s=s.replace('if plan == nil || !plan.bind(m, bindings) {','if plan == nil || !plan.bind(m, bindings) {if plan!=nil{plan.complete=false};').replace('if err != nil || !previous.IsNull() {','if err != nil || !previous.IsNull() {plan.complete=false;').replace('if err := s.Reset(); err != nil {','if err := s.Reset(); err != nil {plan.complete=false;')
s=s.replace('p.values[v.dest] = h','if len(p.dirty)>0{p.dirty[v.dest]=p.values[v.dest]!=h};p.values[v.dest] = h')
s=s.replace('if _, ok := visit(root, 0);','if _, ok := visit(root, 0);')
k='return p\n}';assert s.count(k)==1;s=s.replace(k,'if partialTrial!=""{p.dirty=make([]bool,len(p.values))};'+k)
k='for i, op := range p.apps {';s=s.replace(k,'old:=p.complete;p.complete=false;'+k)
k='result, err := m.RewriterMakeApp(op.decl, ast.SliceArguments(args))';s=s.replace(k,'''result:=p.values[op.dest];reuse:=old && len(p.dirty)>0 && (!ast.ASTValidateHandles && !ast.ASTSourceDebug) && (partialTrial!="unary" || op.arity==1)
 if reuse{for _,id:=range p.edges[int(op.first):int(op.first)+int(op.arity)]{if p.dirty[id]{reuse=false;break}};reuse=reuse && m.TrialRepeatApp(result)}
 if partialTrial=="count"{partialOps++;if reuse{partialHits++}}
 var err error
 if !reuse{result,err=m.RewriterMakeApp(op.decl,ast.SliceArguments(args))}
 if len(p.dirty)>0{p.dirty[op.dest]=p.values[op.dest]!=result}
 ''')
s=s.replace('return m.SetRef(out, p.values[0])','err=m.SetRef(out,p.values[0]);p.complete=err==nil;return err')
s+='\nfunc TrialPartialReport(){fmt.Fprintln(os.Stderr,"REUSE",partialHits,partialOps)}\n';put(path,s)
path=front/'z3bridge_solver_model.go';s=Path(rep[str(path)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/ast/rewriter";',1);s=s.replace('s.showVCsBase(clauses)','if os.Getenv("PARTIAL_TRIAL")=="count"{defer rewriter.TrialPartialReport()};s.showVCsBase(clauses)');put(path,s)
j=w/'partial.json';j.write_text(json.dumps(ov));sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'partial','./cmd/goivy_check'],cwd=front,check=True)
