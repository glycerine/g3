from pathlib import Path
import os
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-witness-match/panel.py').read_text().replace('SHARED_BIND=', 'PARTIAL_TRIAL=')
os.environ.update(EXE='partial',CASES='3 6 2 4 8 12 10 5',MODES='off all unary',ROUNDS='5',CPU='26',STEM='partial-full')
exec(s)
