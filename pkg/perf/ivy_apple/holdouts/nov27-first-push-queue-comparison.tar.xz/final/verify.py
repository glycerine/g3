from pathlib import Path
import os
w=Path(__file__).resolve().parent;old=Path('/tmp/g3-ticket-refinement/final')
for name in ('base','apple-base'):
 f=w/name
 if not f.exists():f.symlink_to(old/('release' if name=='base' else 'apple-release'))
s=Path('/tmp/g3-arith-next/final/verify.py').read_text()
exec(s)
