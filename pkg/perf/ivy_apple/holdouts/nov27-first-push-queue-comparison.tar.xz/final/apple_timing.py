from pathlib import Path
import csv,os,time,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;ex=Path('/home/jaten/ivy/ivy-lang-examples');d=p/'build/.boolean-enode-cost/apple-final/dramc_nb2/1/native'
with (w/'apple-timing.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['round','mode','cpu','instructions','cycles','task_clock_ns','elapsed_ms'])
 for i in range(5):
  for m in [('release','base'),('base','release')][i%2]:
   stat=w/'apple-timing.stat';start=time.monotonic();cpu=[18,24][i%2]
   r=sp.run(['taskset','-c',str(cpu),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u,cycles:u,task-clock','--',w/('apple-'+m),'isolate=dramc_nb2',ex/'doc/examples/apple/ord_live.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=150);ms=1000*(time.monotonic()-start)
   assert (r.returncode,r.stdout,r.stderr)==(0,(d/'stdout').read_bytes(),(d/'stderr').read_bytes())
   hw={a[2]:a[0] for a in csv.reader(stat.open()) if len(a)>4 and float(a[4])==100}
   o.writerow([i,m,cpu,hw['instructions:u'],hw['cycles:u'],hw['task-clock'],round(ms,3)]);f.flush()
