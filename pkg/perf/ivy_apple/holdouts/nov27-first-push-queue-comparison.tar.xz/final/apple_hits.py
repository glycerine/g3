from pathlib import Path
import subprocess as sp,os,csv,json,tempfile
p=Path.cwd();w=Path(__file__).resolve().parent;f=p/'api/api_goal_instances_check.go';s=f.read_text().replace('if wideSingleRound && p.expectedGoals > 1 {','if wideSingleRound && p.expectedGoals > 1 {println("ELIGIBLE");').replace('if 4*(base-selected) < base {','if 4*(base-selected) < base {println("FALLBACK");')
j=w/'apple-observer.json';ov=json.loads(Path('/tmp/g3-ticket-splits/final/release-apple.json').read_text());src=w/'apple-witness.go.txt';src.write_text(s);ov['Replace'][str(f)]=str(src);j.write_text(json.dumps(ov))
with tempfile.TemporaryDirectory(prefix='g3-qi-apple-obs-',dir=Path.home()/'tmp') as d:
 exe=Path(d)/'checker';front=p/'build/.boolean-enode-cost/apple-source/goivy'
 sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=d,GOTMPDIR=d),check=True)
 ex=Path('/home/jaten/ivy/ivy-lang-examples');out=w/'apple-hits.csv'
 with out.open('w') as f:
  o=csv.writer(f);o.writerow(['case','eligible','fallback'])
  for n in ('rfn2','dramc_nb2'):
   ref=p/'build/.boolean-enode-cost/apple-final'/n/'1/native';r=sp.run(['taskset','-c','26',exe,'isolate='+n,ex/'doc/examples/apple/ord_live.ivy'],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=90);lines=r.stderr.splitlines(keepends=True);other=b''.join(x for x in lines if x not in (b'ELIGIBLE\n',b'FALLBACK\n'))
   assert (r.returncode,r.stdout,other)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());o.writerow([n,lines.count(b'ELIGIBLE\n'),lines.count(b'FALLBACK\n')]);f.flush()
