from pathlib import Path
import subprocess as sp,os,csv
w=Path(__file__).resolve().parent;d=w/'queries';d.mkdir(exist_ok=True);ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows')
for n,targets in [(8,'12/8,14/8,16/1'),(13,'11/14,10/6,11/6')]:
 name=(rank/'compat.txt').read_text().splitlines()[n-1];ref=rank/'compat'/str(n)/'1/native'
 r=sp.run(['/tmp/g3-ticket-stages/dump-native',ex/name],cwd=w,env=dict(os.environ,XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TICKET_CASE=str(n),TICKET_DIR=str(d),TICKET_TARGETS=','+targets+','),capture_output=True)
 assert (r.returncode,r.stdout,r.stderr)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),r.stderr[:400]
 assert all((d/(str(n)+'-'+t.replace('/','-')+'.smt2')).exists() for t in targets.split(','))
