from pathlib import Path
import csv
from statistics import median
from collections import defaultdict,Counter
w=Path(__file__).resolve().parent
d=defaultdict(Counter)
for r in csv.DictReader((w/'check-events.csv').open()):
 c=r['event'];f=int(r['flag']);v=int(r['instructions']);k=r['batch'],r['engine'],int(r['round']);entry=d[k]
 if c=='C': hit=None
 if c=='S':hit=f
 entry[c]+=1;entry[c+'+']+=f;entry[c+'i']+=v
 if c in ('S','A','R'):
  assert hit in (0,1);entry[c+str(hit)+'i']+=v
with (w/'check-summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch engine op calls positive instructions hit_instructions miss_instructions'.split())
 for b in ('12','14','16'):
  for e in ('g3','native'):
   for c in 'CSRA':
    def med(k):return int(median([d[b,e,i][k] for i in range(3)]))
    out.writerow([b,e,c,med(c),med(c+'+'),med(c+'i'),med(c+'1i'),med(c+'0i')])
