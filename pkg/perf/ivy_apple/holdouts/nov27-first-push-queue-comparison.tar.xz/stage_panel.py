from pathlib import Path
import csv,json,subprocess,os,concurrent.futures,tempfile
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
def build(eng):
 with tempfile.TemporaryDirectory(prefix='g3-qi-stage-',dir=Path.home()/'tmp') as d:
  subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off'+(',classic_z3' if eng=='native' else ''),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay','/tmp/g3-arith-next/final/arith-stage.json','-o',w/('arith-stage-'+eng),'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=d,GOTMPDIR=d),check=True)
with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(build,['g3','native']))
s=Path('/tmp/g3-ticket-first/arith_stages.py').read_text();s=s[s.index('rank=Path'):].replace('for nr in [14,15]','for nr in [8,7,5,11,13,9]').replace('range(5)','range(3)');exec(s)
exec(Path('/tmp/g3-ticket-refinement/final/summarize_stages.py').read_text())
