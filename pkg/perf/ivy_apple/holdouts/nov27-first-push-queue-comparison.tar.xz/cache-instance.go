package smtcore

// Source: src/smt/qi_queue.cpp:202-288, excluding proof construction and the
// final context::internalize_instance call.

import (
	"errors"
	"fmt"
	"strconv";"os";"syscall";"unsafe"

	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/ast/rewriter"
	"github.com/glycerine/g3/pkg/util/diagnostic"
)

type SMTQIPreparedInstance struct {
	manager          *ast.ASTManager
	entry            SMTQIQueueEntry
	quantifier       ast.ASTHandle
	instance         ast.ASTRef
	alreadySatisfied bool
	closed           bool
}

func (p *SMTQIPreparedInstance) AlreadySatisfied() bool {
	return p != nil && p.alreadySatisfied
}

func (p *SMTQIPreparedInstance) Instance() (ast.ASTHandle, error) {
	if p == nil || p.manager == nil || p.closed || p.alreadySatisfied {
		return ast.ASTHandle{}, ast.ErrASTHandle
	}
	return p.manager.RefGet(p.instance)
}

func (p *SMTQIPreparedInstance) Close() error {
	if p == nil || p.manager == nil {
		return ast.ErrASTHandle
	}
	if p.closed {
		return nil
	}
	var err error
	if !p.alreadySatisfied {
		err = p.manager.DelRef(&p.instance)
	}
	p.closed = err == nil
	return err
}

type SMTQIInstance struct {
	manager     *ast.ASTManager
	fingerprint *SMTFingerprint
	quantifier  ast.ASTHandle
	lemma       ast.ASTRef
	proof       ast.ASTRef
	generation  uint32
	// proofID is the quant-inst proof's id, shown by display_instance_profile.
	proofID     uint32
	reducedTrue bool
	hasProof    bool
	closed      bool
}

func (i *SMTQIInstance) Fingerprint() *SMTFingerprint {
	if i == nil {
		return nil
	}
	return i.fingerprint
}

func (i *SMTQIInstance) Quantifier() ast.ASTHandle {
	if i == nil {
		return ast.ASTHandle{}
	}
	return i.quantifier
}

func (i *SMTQIInstance) ReducedTrue() bool { return i != nil && i.reducedTrue }
func (i *SMTQIInstance) Generation() uint32 {
	if i == nil {
		return 0
	}
	return i.generation
}

func (i *SMTQIInstance) Lemma() (ast.ASTHandle, error) {
	if i == nil || i.manager == nil || i.closed || i.reducedTrue {
		return ast.ASTHandle{}, ast.ErrASTHandle
	}
	return i.manager.RefGet(i.lemma)
}

func (i *SMTQIInstance) Proof() (ast.ASTHandle, error) {
	if i == nil || i.manager == nil || i.closed {
		return ast.ASTHandle{}, ast.ErrASTHandle
	}
	if !i.hasProof {
		return ast.ASTHandle{}, nil
	}
	return i.manager.RefGet(i.proof)
}

func (i *SMTQIInstance) Close() error {
	if i == nil || i.manager == nil {
		return ast.ErrASTHandle
	}
	if i.closed {
		return nil
	}
	var err error
	if i.hasProof {
		err = errors.Join(err, i.manager.DelRef(&i.proof))
	}
	if !i.reducedTrue {
		err = errors.Join(err, i.manager.DelRef(&i.lemma))
	}
	i.closed = err == nil
	return err
}

type SMTQIInstanceBuilder struct {
	manager      *ast.ASTManager
	checker      *SMTChecker
	substitution *SMTCachedVarSubstitution
	costs        *SMTQICostModel
	// registry receives the qi.profile_freq report after each counted
	// instance; nil in stand-alone builders.
	registry *SMTQuantifierRegistry
	// Borrowed only until the current lemma has been asserted.
	operandScratch []ast.ASTHandle
}

func NewSMTQIInstanceBuilder(manager *ast.ASTManager, checker *SMTChecker, substitution *SMTCachedVarSubstitution, costs *SMTQICostModel) (*SMTQIInstanceBuilder, error) {
	if manager == nil || checker == nil || substitution == nil || costs == nil {
		return nil, ast.ErrASTHandle
	}
	if checker.context == nil || checker.context.manager != manager || substitution.manager != manager || costs.manager != manager {
		return nil, ast.ErrASTDomain
	}
	return &SMTQIInstanceBuilder{manager: manager, checker: checker, substitution: substitution, costs: costs}, nil
}

func (b *SMTQIInstanceBuilder) Prepare(entry SMTQIQueueEntry) (*SMTQIPreparedInstance, error) {
	var prepared SMTQIPreparedInstance
	if err := b.prepare(entry, &prepared); err != nil {
		return nil, err
	}
	return &prepared, nil
}

// During queue processing the prepared instance lives only until the current
// candidate is materialized. The public Prepare result has its own lifetime.
func (b *SMTQIInstanceBuilder) prepare(entry SMTQIQueueEntry, prepared *SMTQIPreparedInstance) error {
	if b == nil || b.manager == nil || b.checker == nil || b.substitution == nil {
		return ast.ErrASTHandle
	}
	if entry.Fingerprint == nil || entry.Fingerprint.data.IsNull() {
		return ast.ErrASTDomain
	}
	quantifier := entry.Fingerprint.data
	body, err := b.manager.GetQuantifierBody(quantifier)
	if err != nil {
		return err
	}
	bindings := entry.Fingerprint.args
	var stat *SMTQuantifierStat
	if b.registry != nil {
		stat = b.registry.statistics[quantifier]
	}
	fd:=studyFD();a:=studyRd(fd);satisfied, err := b.checker.run(body, true, bindings, stat);studyLog(fd,a,"C",satisfied)
	if err != nil {
		return err
	}
	*prepared = SMTQIPreparedInstance{manager: b.manager, entry: entry, quantifier: quantifier, alreadySatisfied: satisfied}
	if satisfied {
		return nil
	}
	prepared.instance, err = b.manager.NewRef(ast.ASTHandle{})
	if err != nil {
		return err
	}
	b.substitution.study=fd>=0;a=studyRd(fd);hit,e:=b.substitution.Instantiate(quantifier,bindings,prepared.instance);b.substitution.study=false;studyLog(fd,a,"S",hit);if err=e; err!=nil{
		return errors.Join(err, prepared.Close())
	}
	return nil
}

// Materialize invokes the context theory rewriter and completes the source
// instance lemma. A nil result means the current context already satisfies the
// substituted body.
func (b *SMTQIInstanceBuilder) Materialize(prepared *SMTQIPreparedInstance, rw *rewriter.TheoryRewriter, stat *SMTQuantifierStat, scope uint32) (result *SMTQIInstance, err error) {
	var locals smtQIInstanceLocals
	defer func() { err = errors.Join(err, locals.release(b)) }()
	return b.materialize(prepared, rw, stat, scope, &locals)
}

// smtQIInstanceLocals are qi_queue::instantiate's expr_ref s_instance and
// proof_ref pr: they die when instantiate returns, after [end-of-instance].
type smtQIInstanceLocals struct {
	simplified, rewriteProof ast.ASTRef
	// The completed lemma owns these operands through assertion.
	arguments []ast.ASTHandle
}

// release destroys the locals in reverse declaration order: pr, then
// s_instance.
func (l *smtQIInstanceLocals) release(b *SMTQIInstanceBuilder) (err error) {
	m := b.manager
	// Keep storage for common clause widths. Handles contain only integers.
	if len(l.arguments) > 0 && cap(l.arguments) <= 32 {
		b.operandScratch = l.arguments[:0]
	}
	if l.rewriteProof != (ast.ASTRef{}) {
		err = m.DelRef(&l.rewriteProof)
	}
	if l.simplified != (ast.ASTRef{}) {
		err = errors.Join(err, m.DelRef(&l.simplified))
	}
	return err
}

func (b *SMTQIInstanceBuilder) materialize(prepared *SMTQIPreparedInstance, rw *rewriter.TheoryRewriter, stat *SMTQuantifierStat, scope uint32, locals *smtQIInstanceLocals) (result *SMTQIInstance, err error) {
	if b == nil || b.manager == nil || prepared == nil || prepared.manager != b.manager || prepared.closed || rw == nil || rw.Manager() != b.manager || stat == nil {
		return nil, ast.ErrASTDomain
	}
	if prepared.alreadySatisfied {
		return nil, nil
	}
	instance, err := prepared.Instance()
	if err != nil {
		return nil, err
	}
	locals.simplified, err = b.manager.NewRef(ast.ASTHandle{})
	if err != nil {
		return nil, err
	}
	simplified := locals.simplified
	proofs, err := b.manager.ProofsEnabled()
	if err != nil {
		return nil, err
	}
	if !proofs {
		fd:=studyFD();a:=studyRd(fd);if err = rw.Rewrite(instance, simplified); err != nil {
			return nil, err
		}
		rewritten, err := b.manager.RefGet(simplified);studyLog(fd,a,"R",b.manager.IsTrue(rewritten))
		if err != nil {
			return nil, err
		}
		var arguments *[]ast.ASTHandle
		if !ast.ASTValidateHandles && !ast.ASTSourceDebug && !smtcoreSourceDebug &&
			!diagnostic.TraceCompiled() && b.manager.TraceStream == nil && !b.manager.Budget().InjectionArmed() {
			arguments = &locals.arguments
		}
		return b.finishWithoutProof(prepared, rewritten, stat, scope, arguments)
	}
	locals.rewriteProof, err = b.manager.NewRef(ast.ASTHandle{})
	if err != nil {
		return nil, err
	}
	rewriteProof := locals.rewriteProof
	if err = rw.RewriteWithProof(instance, simplified, rewriteProof); err != nil {
		return nil, err
	}
	rewritten, err := b.manager.RefGet(simplified)
	if err != nil {
		return nil, err
	}
	proof, err := b.manager.RefGet(rewriteProof)
	if err != nil {
		return nil, err
	}
	return b.FinishWithProof(prepared, rewritten, proof, stat, scope)
}

// MaterializeAndInternalize completes qi_queue::instantiate through the
// concrete SMT internalizer. The returned object retains the source queue's
// lemma/proof ownership until its caller closes or scopes it.
func (b *SMTQIInstanceBuilder) MaterializeAndInternalize(prepared *SMTQIPreparedInstance, rw *rewriter.TheoryRewriter, stat *SMTQuantifierStat, scope uint32, internalizer *SMTInternalizerState) (_ *SMTQIInstance, resultErr error) {
	if internalizer == nil || internalizer.manager != b.manager {
		return nil, ast.ErrASTDomain
	}
	var locals smtQIInstanceLocals
	defer func() { resultErr = errors.Join(resultErr, locals.release(b)) }()
	result, err := b.materialize(prepared, rw, stat, scope, &locals)
	if err != nil {
		return result, fmt.Errorf("rewrite and finish instance: %w", err)
	}
	if result == nil {
		return nil, nil
	}
	out := b.manager.TraceStream
	if result.ReducedTrue() {
		if out != nil {
			traceStreamWriter(out)("[end-of-instance]\n")
		}
		return result, nil
	}
	// display_instance_profile, internalize_instance, then [end-of-instance].
	if out != nil {
		w := traceStreamWriter(out)
		w(fmt.Sprintf("[instance] %p", result.fingerprint))
		if result.hasProof {
			w(" #" + strconv.FormatUint(uint64(result.proofID), 10))
		}
		w(" ; " + strconv.FormatUint(uint64(result.generation), 10) + "\n")
	}
	fd:=studyFD();a:=studyRd(fd);err=internalizer.internalizeInstance(result, locals.arguments);studyLog(fd,a,"A",false);if err!=nil{
		return nil, errors.Join(fmt.Errorf("internalize instance lemma: %w", err), result.Close())
	}
	if out != nil {
		traceStreamWriter(out)("[end-of-instance]\n")
	}
	return result, nil
}

func (b *SMTQIInstanceBuilder) Finish(prepared *SMTQIPreparedInstance, simplified ast.ASTHandle, stat *SMTQuantifierStat, scope uint32) (*SMTQIInstance, error) {
	return b.finishWithoutProof(prepared, simplified, stat, scope, nil)
}

func (b *SMTQIInstanceBuilder) finishWithoutProof(prepared *SMTQIPreparedInstance, simplified ast.ASTHandle, stat *SMTQuantifierStat, scope uint32, arguments *[]ast.ASTHandle) (*SMTQIInstance, error) {
	if b == nil || b.manager == nil {
		return nil, ast.ErrASTHandle
	}
	proofs, err := b.manager.ProofsEnabled()
	if err != nil {
		return nil, err
	}
	if proofs {
		return nil, ast.ErrASTDomain
	}
	return b.finishLemma(prepared, simplified, stat, scope, arguments)
}

func (b *SMTQIInstanceBuilder) finishLemma(prepared *SMTQIPreparedInstance, simplified ast.ASTHandle, stat *SMTQuantifierStat, scope uint32, arguments *[]ast.ASTHandle) (*SMTQIInstance, error) {
	if b == nil || b.manager == nil || prepared == nil || prepared.manager != b.manager || prepared.closed || prepared.alreadySatisfied || stat == nil {
		return nil, ast.ErrASTDomain
	}
	boolean, err := b.manager.HasBoolSort(simplified)
	if err != nil {
		return nil, err
	}
	if !boolean {
		return nil, ast.ErrASTDomain
	}
	result := &SMTQIInstance{manager: b.manager, fingerprint: prepared.entry.Fingerprint, quantifier: prepared.quantifier}
	if b.manager.IsTrue(simplified) {
		result.reducedTrue = true
		return result, nil
	}
	stat.IncrementInstances()
	if err = b.registry.profileInstance(prepared.quantifier, stat); err != nil {
		return nil, err
	}
	negatedQuantifier, err := b.manager.MkNot(prepared.quantifier)
	if err != nil {
		return nil, err
	}
	lemma := negatedQuantifier
	if !b.manager.IsFalse(simplified) {
		head, err := b.manager.NodeHeader(simplified)
		if err != nil {
			return nil, err
		}
		if head.Kind == ast.ASTApp && head.Family == b.manager.BasicFamilyID() && head.DeclKind == ast.ASTOpOr {
			count := 1 + int(head.NumArgs)
			var args []ast.ASTHandle
			if arguments != nil && cap(b.operandScratch) >= count {
				// Recursive assertions must have independent operand storage.
				args = b.operandScratch[:count]
				b.operandScratch = nil
			} else {
				args = make([]ast.ASTHandle, count)
			}
			args[0] = negatedQuantifier
			for index := uint32(0); index < head.NumArgs; index++ {
				args[1+int(index)], err = b.manager.GetArg(simplified, index)
				if err != nil {
					return nil, err
				}
			}
			lemma, err = b.manager.MkOrArgs(args)
			if arguments != nil && err == nil {
				*arguments = args
			}
		} else {
			lemma, err = b.manager.MkOr(negatedQuantifier, simplified)
		}
		if err != nil {
			return nil, err
		}
	}
	result.generation, err = b.costs.NewGeneration(prepared.quantifier, stat, prepared.entry.Generation, scope, prepared.entry.Cost)
	if err != nil {
		return nil, err
	}
	result.lemma, err = b.manager.NewRef(lemma)
	if err != nil {
		return nil, err
	}
	return result, nil
}

// FinishWithProof constructs the source quantifier-instantiation proof after
// the enclosing context has rewritten the prepared instance. rewriteProof is
// the context rewriter's proof that Instance() equals simplified.
func (b *SMTQIInstanceBuilder) FinishWithProof(prepared *SMTQIPreparedInstance, simplified, rewriteProof ast.ASTHandle, stat *SMTQuantifierStat, scope uint32) (*SMTQIInstance, error) {
	if b == nil || b.manager == nil {
		return nil, ast.ErrASTHandle
	}
	proofs, err := b.manager.ProofsEnabled()
	if err != nil {
		return nil, err
	}
	if !proofs {
		return b.finishLemma(prepared, simplified, stat, scope, nil)
	}
	result, err := b.finishLemma(prepared, simplified, stat, scope, nil)
	if err != nil || result.reducedTrue {
		return result, err
	}
	instance, err := prepared.Instance()
	if err != nil {
		_ = result.Close()
		return nil, err
	}
	lemma, err := result.Lemma()
	if err != nil {
		_ = result.Close()
		return nil, err
	}
	negatedQuantifier, err := b.manager.MkNot(prepared.quantifier)
	if err != nil {
		_ = result.Close()
		return nil, err
	}
	bareLemma, err := b.manager.MkOr(negatedQuantifier, instance)
	if err != nil {
		_ = result.Close()
		return nil, err
	}
	bindings := make([]ast.ASTHandle, len(prepared.entry.Fingerprint.args))
	for index, binding := range prepared.entry.Fingerprint.args {
		if binding == nil || binding.owner.IsNull() {
			_ = result.Close()
			return nil, ast.ErrASTDomain
		}
		bindings[index] = binding.owner
	}
	proof, err := b.manager.MkProofQuantInstantiation(bareLemma, bindings)
	if err != nil {
		_ = result.Close()
		return nil, err
	}
	if result.proofID, err = b.manager.GetASTID(proof); err != nil {
		_ = result.Close()
		return nil, err
	}
	if bareLemma != lemma {
		if instance == simplified {
			rewrite, err := b.manager.MkProofRewrite(bareLemma, lemma)
			if err != nil {
				_ = result.Close()
				return nil, err
			}
			proof, err = b.manager.MkProofModusPonens(proof, rewrite)
			if err != nil {
				_ = result.Close()
				return nil, err
			}
		} else {
			if rewriteProof.IsNull() {
				_ = result.Close()
				return nil, ast.ErrASTDomain
			}
			bareSimplifiedLemma, err := b.manager.MkOr(negatedQuantifier, simplified)
			if err != nil {
				_ = result.Close()
				return nil, err
			}
			congruence, err := b.manager.MkProofCongruence(bareLemma, bareSimplifiedLemma, []ast.ASTHandle{rewriteProof})
			if err != nil {
				_ = result.Close()
				return nil, err
			}
			rewrite, err := b.manager.MkProofRewrite(bareSimplifiedLemma, lemma)
			if err != nil {
				_ = result.Close()
				return nil, err
			}
			transitivity, err := b.manager.MkProofTransitivity(congruence, rewrite)
			if err != nil {
				_ = result.Close()
				return nil, err
			}
			proof, err = b.manager.MkProofModusPonens(proof, transitivity)
			if err != nil {
				_ = result.Close()
				return nil, err
			}
		}
	}
	result.proof, err = b.manager.NewRef(proof)
	if err != nil {
		_ = result.Close()
		return nil, err
	}
	result.hasProof = true
	return result, nil
}

func studyFD()int{v,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));if e!=nil{return -1};return v}
func studyRd(fd int)uint64{if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if n!=24||e!=0||c[1]!=c[2]{panic("counter")};return c[0]}
func studyLog(fd int,a uint64,op string,flag bool){if fd>=0{n:=studyRd(fd)-a;v:=0;if flag{v=1};fmt.Fprintln(os.Stderr,op,v,n)}}
