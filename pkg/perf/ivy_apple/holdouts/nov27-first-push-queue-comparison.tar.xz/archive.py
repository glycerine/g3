import tarfile,csv
from pathlib import Path
w=Path(__file__).resolve().parent
def read(path):
 with path.open() as f:return list(csv.DictReader(f))
rows=[r for p in (w/'final').glob('panel?.csv') for r in read(p)]
assert len(rows)==len({r['case'] for r in rows})==228 and all(r['status']=='match' for r in rows)
for stem,count in [('partial-full',120),('width',200),('select-full',20),('final/confirmed',42),('final/split-confirm',33)]:
 data=read(w/(stem+'.csv'));assert len(data)==count and all(r['status']=='match' for r in data)
for n in ('dramc_nb2','rfn2','raft_no_assume'):
 rows=read(w/'final'/n/'long.csv');assert len(rows)==6 and all(r['status']=='match' for r in rows)
assert len(read(w/'final/apple-timing.csv'))==10 and len(read(w/'final/apple-hits.csv'))==2
rows=[r for f in w.glob('admission?.csv') for r in read(f)];assert len(rows)==228 and all(r['exact']=='True' for r in rows)
paths=sorted({f for glob in ('*.py','*.cpp','*.go','*.go.txt','*.csv','README.md','*.json','queries/*.smt2','support/*','*/long.csv','final/*.go.txt','final/*.csv','final/*.py','final/bench.txt','final/*/long.csv') for f in w.glob(glob) if f.is_file()})
dest=Path('perf/ivy_apple/holdouts/nov27-first-push-queue-comparison.tar.xz')
with tarfile.open(dest,'w:xz') as t:
 for f in paths:t.add(f,arcname=str(f.relative_to(w)))
with tarfile.open(dest) as t:
 for f in paths:assert t.extractfile(str(f.relative_to(w))).read()==f.read_bytes()
print(len(paths),'verified files',dest.stat().st_size,'bytes')
