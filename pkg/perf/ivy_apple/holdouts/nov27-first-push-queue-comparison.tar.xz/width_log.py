from pathlib import Path
import os,csv,subprocess as sp
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');names=(ref/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
with (w/'width-log.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['case','kind','parameters','proved'])
 for n in [13,8,3,6,2,4,7,9,10,12]:
  name=names[n-1];d=ref/'compat'/str(n)/'1/native';r=sp.run(['taskset','-c','31',w/'width',ex/name],cwd=w,env=dict(os.environ,XTRACE_OFF='1',WIDTH_TRIAL='log',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=60);rest=bytearray()
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith((b'WITNESS ',b'SHORT ',b'DIRECT ')):
    a=l.decode().split();o.writerow([n,a[0],' '.join(a[1:-1]),a[-1]])
   else:rest.extend(l)
  assert (r.returncode,r.stdout,rest)==(codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes());f.flush()
