import json,subprocess as sp,os,tempfile
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
path=p/'api/api_goal_instances_check.go';s=path.read_text().replace('import (','import ("os";"fmt";',1)
s+='\nvar widthTrial=os.Getenv("WIDTH_TRIAL")\n'
k='reuse := p.plans.reusable(parent)';s=s.replace(k,'''if widthTrial!=""{
 switch q:=plan.(type){case *witnessInstancePlan:
 if widthTrial=="log"{defer func(){fmt.Fprintln(os.Stderr,"WITNESS",len(q.sorts),q.width,q.rounds,q.selectedOnly,len(q.source),len(q.assertions),proved)}()}
 if len(q.sorts)==1 && (widthTrial=="one" || widthTrial=="two" || widthTrial=="omit"){if widthTrial=="omit"{return false,nil};v:=*q;width:=1;if widthTrial=="two"{width=2};v.width=min(v.width,width);plan=&v}
 case *goalInstancePlan:if widthTrial=="log"{defer func(){fmt.Fprintln(os.Stderr,"DIRECT",len(q.ground),len(q.rules),proved)}()}
 case *shortPremisePlan:if widthTrial=="log"{defer func(){fmt.Fprintln(os.Stderr,"SHORT",len(q.selected),proved)}()}
 }}
 '''+k)
f=w/'width-api_goal_instances_check.go';f.write_text(s);ov['Replace'][str(path)]=str(f)
j=w/'width.json';j.write_text(json.dumps(ov))
with tempfile.TemporaryDirectory(prefix='g3-qi-width-',dir=Path.home()/'tmp') as d:
 sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'width','./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOTMPDIR=d,TMPDIR=d),check=True)
