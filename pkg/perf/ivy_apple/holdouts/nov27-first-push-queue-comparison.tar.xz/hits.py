from pathlib import Path
import csv,subprocess as sp,os
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');names=(ref/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())};ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'partial-hits.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case hits calls'.split())
 for case in [3,6,2,4,8,12,10,5]:
  d=ref/'compat'/str(case)/'1/native';name=names[case-1];r=sp.run(['taskset','-c','24',w/'partial',ex/name],env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),PARTIAL_TRIAL='count'),cwd=w,capture_output=True,timeout=60)
  rest=bytearray();hits=calls=0
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'REUSE '):hits,calls=map(int,line.split()[1:])
   else:rest.extend(line)
  assert (r.returncode,r.stdout,rest)==(codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes())
  out.writerow([case,hits,calls]);f.flush()
