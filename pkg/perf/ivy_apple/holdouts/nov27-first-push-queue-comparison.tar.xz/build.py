"""Instrument the first physical Push in each verifier batch."""
from pathlib import Path
import json,subprocess as sp,sys,re,shlex,shutil
p=Path.cwd(); w=Path(__file__).resolve().parent; front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(); mode=sys.argv[1]; native=mode=='native'
orig=Path('/tmp/g3-ticket-first/validation/final.json');ov=json.loads(orig.read_text())['Replace']
def put(path,s):
 d=w/(mode+'-'+path.name);d.write_text(s);ov[str(path)]=str(d)
path=front/'z3bridge_solver_model.go'
s=Path(ov[str(path)]).read_text()
if native:s=Path('/tmp/g3-live-numeral/ticket/z3bridge_solver_model.go').read_text()
if native:
 k='end := startStage(batch, ordinal+1)\n\t\t\t\t\tz3solver.Push()'
 assert s.count(k)==1;s=s.replace(k,'capturePush=first;'+k+';capturePush=false')
else:
 s=s.replace('s.showVCsBase(clauses)','s.showVCsBase(clauses);batch:=newStageBatch();first:=true')
 i=s.index('func (s *Solver) GetSmallModelWithCond(');h,t=s[:i],s[i:];s=h+t.replace('z3solver.Push()','if first{capturePush=true;end:=startStage(batch,index+1);z3solver.Push();end("first");capturePush=false;first=false}else{z3solver.Push()}',1)
put(path,s)
path=front/'phase_observer_trial.go';s=Path('/tmp/g3-ticket-instance-cost/stage-native.go.txt').read_text().replace('if batch == 7 && goal == 1','if capturePush').replace('os.Setenv("QI_COUNTER_FD",fmt.Sprint(fd))','os.Setenv("QI_COUNTER_FD",fmt.Sprint(fd));fmt.Fprintln(os.Stderr,"OPEN",batch,goal)')
put(path,s+'\nvar capturePush bool\n')
if native:
 build=p.parent/'build';src=p.parent/'src/smt';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1]);objs=[]
 for name in ['cached_var_subst','qi_queue']:
  s=(src/(name+'.cpp')).read_text()
  if name=='cached_var_subst':
   s='thread_local bool study_cache_hit;\n'+s.replace('if (entry->get_data().m_key != new_key)', 'study_cache_hit=entry->get_data().m_key != new_key; if (study_cache_hit)')
  else:
   s='#include <unistd.h>\n#include <cstdio>\n#include <cstdlib>\nextern thread_local bool study_cache_hit;\nstatic long long rd(int fd){uint64_t c[3];if(read(fd,c,sizeof(c))!=sizeof(c)||c[1]!=c[2])std::abort();return c[0];}\n'.replace('uint64_t c','unsigned long long c')+s
   k='if (m_checker.is_sat(q->get_expr(), num_bindings, bindings))';s=s.replace(k,'''const char *v=getenv("QI_COUNTER_FD");int fd=v?atoi(v):-1;long long a=fd<0?0:rd(fd);bool sat=m_checker.is_sat(q->get_expr(),num_bindings,bindings);if(fd>=0)fprintf(stderr,"C %d %lld\\n",int(sat),rd(fd)-a);if(sat)''')
   for k,key,condition in [('m_subst(q, num_bindings, bindings, instance);','S','int(study_cache_hit)'),('m_context.get_rewriter()(instance, s_instance, pr);','R','int(m_manager.is_true(s_instance))'),('m_context.internalize_instance(lemma, pr1, gen);','A','0')]:
    assert s.count(k)==1;s=s.replace(k,'if(fd>=0)a=rd(fd);'+k+'if(fd>=0)fprintf(stderr,"'+key+' %d %lld\\n",'+condition+',rd(fd)-a);')
  f=w/(name+'.cpp');f.write_text(s);obj=w/(name+'.o');sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,f],cwd=build,check=True);objs.append(obj)
 lib=w/'study.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);sp.run(['ar','r',lib,*objs],check=True)
 path=front/'smt/quantifier.go';put(path,path.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
else:
 path=p/'smtcore/smt_qi_instance.go';s=path.read_text().replace('"strconv"','"strconv";"os";"syscall";"unsafe"');s+='''
func studyFD()int{v,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));if e!=nil{return -1};return v}
func studyRd(fd int)uint64{if fd<0{return 0};var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if n!=24||e!=0||c[1]!=c[2]{panic("counter")};return c[0]}
func studyLog(fd int,a uint64,op string,flag bool){if fd>=0{n:=studyRd(fd)-a;v:=0;if flag{v=1};fmt.Fprintln(os.Stderr,op,v,n)}}
'''
 k='satisfied, err := b.checker.run(body, true, bindings, stat)';s=s.replace(k,'fd:=studyFD();a:=studyRd(fd);'+k+';studyLog(fd,a,"C",satisfied)')
 k='if _, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance); err != nil {';s=s.replace(k,'a=studyRd(fd);hit,e:=b.substitution.Instantiate(quantifier,bindings,prepared.instance);studyLog(fd,a,"S",hit);if err=e; err!=nil{')
 k='if err = rw.Rewrite(instance, simplified);';s=s.replace(k,'fd:=studyFD();a:=studyRd(fd);'+k);k='rewritten, err := b.manager.RefGet(simplified)';s=s.replace(k,k+';studyLog(fd,a,"R",b.manager.IsTrue(rewritten))',1)
 k='if err = internalizer.internalizeInstance(result, locals.arguments); err != nil {';s=s.replace(k,'fd:=studyFD();a:=studyRd(fd);err=internalizer.internalizeInstance(result, locals.arguments);studyLog(fd,a,"A",false);if err!=nil{')
 put(path,s)
j=w/(mode+'.json');j.write_text(json.dumps({'Replace':ov}));sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off'+(',classic_z3' if native else ''),'-pgo='+('off' if native else str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-overlay',j,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
