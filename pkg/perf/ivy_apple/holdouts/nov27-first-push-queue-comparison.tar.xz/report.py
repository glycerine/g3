from pathlib import Path
from statistics import median
from collections import defaultdict
import csv
w=Path(__file__).resolve().parent
for path in [w/'final/confirmed.csv',*sorted((w/'final').glob('*/long.csv')),w/'select-full.csv',w/'affected.csv']:
 rows=list(csv.DictReader(path.open()))
 d=defaultdict(list)
 for r in rows:
  assert r['status']=='match'
  d[r['case'].split('/')[-1],r.get('mode',r.get('policy'))].append((int(r['instructions'])/1e6,float(r['ms'])))
 for k,v in d.items():print(path.parent.name,path.name,*k,len(v),round(median(x for x,_ in v),2),round(median(y for _,y in v),2))
