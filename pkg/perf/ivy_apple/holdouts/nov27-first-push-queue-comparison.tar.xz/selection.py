from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'witness.py').read_text()
i=s.index("path=p/'api/");j=s.index("j=w/'width.json'")
s=s[:i]+"""path=p/'api/api_witness_premises.go';s=sp.check_output(['git','show','HEAD:pkg/api/api_witness_premises.go'],text=True).replace('import \"github.com','import (\"os\";\"fmt\");import \"github.com',1);k='if full.selectedOnly && selectedNonGround > len(index.rows)-len(selected) {'
s=s.replace(k,'''if len(full.sorts)==1 && full.rounds==1 && full.width>3 {
 omitted:=len(index.rows)-len(selected)
 if selectTrial=="log"{fmt.Fprintln(os.Stderr,"SLICE",len(index.rows),len(selected),selectedNonGround,omitted,p.expectedGoals)}
 if selectTrial=="half" && selectedNonGround>omitted || selectTrial=="quarter" && selectedNonGround>3*omitted {return nil,nil}
 }
 '''+k)
s+='\\nvar selectTrial=os.Getenv("WIDTH_TRIAL")\\n';f=w/'select-premises.go';f.write_text(s);ov['Replace'][str(path)]=str(f)
# When the selective pass declines, leave this family to the incremental solver.
path=p/'api/api_goal_instances_check.go';s=path.read_text();k='if small != nil {';s=s.replace(k,'if small==nil && witness.rounds==1 && witness.width>3 && (selectTrial=="half" || selectTrial=="quarter"){return false,nil};'+k);f=w/'select-check.go';f.write_text(s);ov['Replace'][str(path)]=str(f)
"""+s[j:]
s=s.replace("'width.json'","'select.json'").replace("w/'width'","w/'select'")
exec(s)
