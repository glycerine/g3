from pathlib import Path
s=(Path(__file__).resolve().parent/'run.py').read_text()
s=s.replace("'instances.csv'", "'trial-events.csv'").replace("'pushes.csv'","'trial-pushes.csv'").replace('for case in (3,6,12,10,2,4):','for case in (3,6,2,12,10,4):').replace('for i in range(3):','for i in range(5):').replace("for mode in (['g3','native'] if i%2==0 else ['native','g3']):","for mode in (['normal','batch','omit']*2)[i%3:i%3+3]:").replace('w/mode,ex/name',"w/'cache',ex/name").replace("GOGC='off'","FIRST_CACHE=mode,GOGC='off'").replace('goal candidates\'.split()', "goal candidates instructions'.split()").replace("counts['C',0]+counts['C',1]]","counts['C',0]+counts['C',1],int(a[4])]")
exec(s)
