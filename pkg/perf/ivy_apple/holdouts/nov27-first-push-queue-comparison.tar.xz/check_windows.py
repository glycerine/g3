"""Use the same per-instance observers on the largest remaining automatic Ticket checks."""
from pathlib import Path
import os,subprocess as sp,tempfile,concurrent.futures,sys
w=Path(__file__).resolve().parent
if len(sys.argv)>1:
 s=(w/'build.py').read_text()
 i=s.index('if native:\n k=');j=s.index('put(path,s)',i)
 s=s[:i]+'''s=Path('/tmp/g3-arith-next/final/arith-stage-bridge.go.txt').read_text()
k='stopCheck:=startStage(batch,index+1);';assert s.count(k)==1;s=s.replace(k,'capturePush=(batch==12 && index==7 || batch==14 && index==7 || batch==16 && index==0);'+k).replace('stopCheck("check")','stopCheck("check");capturePush=false')
'''+s[j:]
 s=s.replace("d=w/(mode+'-'","d=w/('check-'+mode+'-'").replace("j=w/(mode+'.json')","j=w/('check-'+mode+'.json')").replace("w/'study.a'","w/'check.a'").replace("'-o',w/mode","'-o',w/('check-'+mode)")
 exec(s)
else:
 def build(mode):
  with tempfile.TemporaryDirectory(prefix='g3-check-windows-',dir=Path.home()/'tmp') as d:sp.run(['python3',__file__,mode],check=True,env=dict(os.environ,TMPDIR=d,GOTMPDIR=d))
 with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(build,['native','g3']))
 s=(w/'run.py').read_text().replace("w/'pushes.csv'","w/'check-windows.csv'").replace("w/'instances.csv'","w/'check-events.csv'").replace("for case in (3,6,12,10,2,4):","for case in (8,):").replace("w/mode,ex/name","w/('check-'+mode),ex/name").replace("if a[3]==b'first':","if active and a[3]==b'check':")
 exec(s)
