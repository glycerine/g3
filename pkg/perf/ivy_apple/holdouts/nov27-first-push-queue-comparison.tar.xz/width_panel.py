import os
from pathlib import Path
w=Path(__file__).resolve().parent;os.environ.update(EXE='width',CASES='13 8 3 6 2 4 7 9 10 12',MODES='off one two omit',ROUNDS='5',CPU='26',STEM='width')
exec(Path('/tmp/g3-witness-match/panel.py').read_text().replace('SHARED_BIND=','WIDTH_TRIAL='))
