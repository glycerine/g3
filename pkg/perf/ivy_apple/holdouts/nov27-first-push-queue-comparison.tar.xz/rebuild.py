from pathlib import Path
import os,tempfile,subprocess as sp,concurrent.futures
w=Path(__file__).resolve().parent
def run(task):
 with tempfile.TemporaryDirectory(prefix='g3-push-compile-',dir=Path.home()/'tmp') as d:sp.run(['python3',w/(task[0]+'.py'),*task[1:]],check=True,env=dict(os.environ,GOTMPDIR=d,TMPDIR=d))
with concurrent.futures.ThreadPoolExecutor(3) as pool:list(pool.map(run,[('partial',),('arrivals','g3'),('arrivals','native')]))
