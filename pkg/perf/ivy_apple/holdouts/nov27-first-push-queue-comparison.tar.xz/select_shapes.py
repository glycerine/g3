from pathlib import Path
import os,csv,subprocess as sp
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');names=(ref/'compat.txt').read_text().splitlines()
with (w/'selection-shapes.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case base selected quantified omitted goals'.split())
 for n in (13,228):
  d=ref/'compat'/str(n)/'1/native';r=sp.run(['taskset','-c','24',w/'select',ex/names[n-1]],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',WIDTH_TRIAL='log',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True);rest=bytearray()
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'SLICE '):o.writerow([n,*map(int,l.split()[1:])])
   else:rest.extend(l)
  assert (r.returncode,r.stdout,rest)==(0,(d/'stdout').read_bytes(),(d/'stderr').read_bytes());f.flush()
