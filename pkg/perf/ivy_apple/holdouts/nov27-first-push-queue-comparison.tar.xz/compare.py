from pathlib import Path
import csv
from collections import defaultdict,Counter
from statistics import median
w=Path(__file__).resolve().parent
def load(stem):
 with (w/(stem+'.csv')).open() as f:return list(csv.DictReader(f))
pushes=load('pushes');events=load('instances')
shapes=defaultdict(dict)
for r in pushes:
 shapes[int(r['case']),int(r['round']),r['engine']][int(r['batch'])]=int(r['goal'])
rows=defaultdict(Counter)
for r in events:
 c,i,b=int(r['case']),int(r['round']),int(r['batch']);op=r['event'];f=int(r['flag'])
 if b not in shapes[c,i,'g3'] or b not in shapes[c,i,'native']:continue
 d=rows[c,i,r['engine']];d[op]+=1;d[op+'+']+=f;d[op+'i']+=int(r['instructions']);d[op+'i'+str(b)]+=int(r['instructions'])
for c in sorted({k[0] for k in shapes}):
 for m in ('g3','native'):
  d=rows[c,0,m];a=shapes[c,0,'g3'];b=shapes[c,0,'native'];common=a.keys()&b.keys()
  print(c,m,'pushes',len(shapes[c,0,m]),'common',len(common),'samegoal',sum(a[k]==b[k] for k in common),'counts',[(k,d[k],d[k+'+']) for k in 'CSRA'],'cost M',[round(median([rows[c,i,m][k+'i'] for i in range(3) if (c,i,m) in rows])/1e6,2) for k in 'CSRA'])
