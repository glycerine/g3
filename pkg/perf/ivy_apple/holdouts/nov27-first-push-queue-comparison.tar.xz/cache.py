from pathlib import Path
import json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
ov=json.loads((w/'g3.json').read_text());replace=ov['Replace']
path=p/'smtcore/smt_qi_instance.go';s=Path(replace[str(path)]).read_text();s=s.replace('a=studyRd(fd);hit,e:=','b.substitution.study=fd>=0;a=studyRd(fd);hit,e:=').replace('studyLog(fd,a,"S",hit);','b.substitution.study=false;studyLog(fd,a,"S",hit);')
f=w/'cache-instance.go';f.write_text(s);replace[str(path)]=str(f)
path=p/'smtcore/cached_var_subst.go';s=path.read_text().replace('import (','import ("os";',1).replace('self         *SMTCachedVarSubstitution','study bool\n self *SMTCachedVarSubstitution');s+='\nvar firstPushCacheMode=os.Getenv("FIRST_CACHE")\n'
k='hash := smtSubstitutionKeyHash(quantifier, owners)';s=s.replace(k,'''if c.study && firstPushCacheMode=="omit"{
 body,err:=c.manager.GetQuantifierBody(quantifier);if err!=nil{return false,err};return false,c.plans.Substitute(c.substitution,body,owners,out)
 }
 '''+k)
k='for i, h := range c.refs[start:] {';s=s.replace(k,'''if c.study && firstPushCacheMode=="batch" {
 n,_,e:=c.manager.IncRefThenDecRef(c.refs[start:],nil);if e!=nil{for k:=start+n-1;k>=start;k--{e=errors.Join(e,c.manager.DecRef(c.refs[k]))};c.refs=c.refs[:start];return false,e}
 }else{'''+k).replace('if c.entries == nil {','};if c.entries == nil {',1)
f=w/'cache-substitution.go';f.write_text(s);replace[str(path)]=str(f)
j=w/'cache.json';j.write_text(json.dumps(ov));sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'cache','./cmd/goivy_check'],cwd=front,check=True)
