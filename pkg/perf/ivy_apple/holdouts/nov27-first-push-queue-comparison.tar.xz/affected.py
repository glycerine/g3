from pathlib import Path
import os
w=Path(__file__).resolve().parent;os.environ.update(EXE='admit',CASES='228 13',MODES='off one-round',ROUNDS='5',CPU='28',STEM='affected')
exec(Path('/tmp/g3-witness-match/panel.py').read_text().replace('SHARED_BIND=','WIDTH_TRIAL='))
