from pathlib import Path
import os
w=Path(__file__).resolve().parent;os.environ.update(EXE='width',CASES='228',MODES='off one two',ROUNDS='5',CPU='28',STEM='hermes-width')
exec(Path('/tmp/g3-witness-match/panel.py').read_text().replace('SHARED_BIND=','WIDTH_TRIAL='))
