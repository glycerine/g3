from pathlib import Path
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-arm-pass/stats.py').read_text()
s=s.replace("marked:=batch==8 && g==1 || batch==6 && (g==5 || g==6 || g==26)","marked:=true")
a=s.index("  ex=Path");k=s.index('  for i in range(3):',a);s=s[:a]+"""  ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows')
  for nr in (8,13):
   ref=rank/'compat'/str(nr)/'1/native';name=(rank/'compat.txt').read_text().splitlines()[nr-1]
"""+'\n'.join(' '+l if l else l for l in s[k:].split('\n'))
s=s.replace("'engine round batch", "'case engine round batch").replace('[e,i,b,g,k,v.get', '[nr,e,i,b,g,k,v.get').replace('range(3)','range(1)').replace("ex/'test/arm_rules3.ivy'",'ex/name')
exec(s)
