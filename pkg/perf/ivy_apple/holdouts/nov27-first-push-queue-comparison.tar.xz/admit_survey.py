import os,subprocess as sp,csv,concurrent.futures
from pathlib import Path
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');names=(ref/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())};ex=Path('/home/jaten/ivy/ivy-lang-examples')
def run(lane):
 with (w/('admission'+str(lane)+'.csv')).open('w') as f:
  o=csv.writer(f);o.writerow('case spec exact one_round wider'.split())
  for i in range(lane,len(names),6):
   name=names[i];d=ref/'compat'/str(i+1)/'1/native';r=sp.run(['taskset','-c',str(1+2*lane),w/'admit',ex/name],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',WIDTH_TRIAL='log',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd='/tmp/g3-frame-child',capture_output=True,timeout=90);rest=bytearray();one=wide=0
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'FULL '):
     _,width,rounds,*_=l.split();wide+=int(width)>3;one+=int(width)>3 and int(rounds)==1
    else:rest.extend(l)
   ok=(r.returncode,r.stdout,rest)==(codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes());o.writerow([i+1,name,ok,one,wide]);f.flush()
with concurrent.futures.ThreadPoolExecutor(6) as pool:list(pool.map(run,range(6)))
