from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'witness.py').read_text()
i=s.index("k='reuse :=");j=s.index("f=w/'width",i)
s=s[:i]+'''k='if len(witness.sorts) == 1 {'
s=s.replace(k,k+\'''\n if widthTrial=="log"{fmt.Fprintln(os.Stderr,"FULL",witness.width,witness.rounds,witness.selectedOnly,len(witness.assertions))}
 if witness.width>3 && (widthTrial=="one-round" && witness.rounds==1 || widthTrial=="wide"){return false,nil}
\''',1)
'''+s[j:]
s=s.replace("'width-api","'admit-api").replace("'width.json'","'admit.json'").replace("w/'width'","w/'admit'")
exec(s)
