from collections import defaultdict,Counter
from pathlib import Path
import csv,statistics
w=Path(__file__).resolve().parent
cases=[2,3,4,6,10,12]
def rows(name):return list(csv.DictReader((w/(name+'.csv')).open()))
ev=rows('instances');pu=rows('pushes')
seq=defaultdict(list)
for r in ev:seq[r['case'],r['round'],r['engine'],r['batch']].append((r['event'],r['flag']))
calls=matches=0
for nr in cases:
 for i in range(3):
  ps=[{r['batch'] for r in pu if (r['case'],r['round'],r['engine'])==(str(nr),str(i),m)} for m in ('g3','native')]
  for b in set.intersection(*ps):
   calls+=1; x,y=[seq[str(nr),str(i),m,b] for m in ('g3','native')];matches+=(x==y)
print('matching flag sequences',matches,calls)
for name in ('trial-pushes','trial-events'):
 d=defaultdict(Counter)
 for r in rows(name):
  if r.get('event','S')=='S':d[int(r['case']),r['engine']][int(r['round'])]+=int(r['instructions'])
 for c in cases:
  print(name,c,*[round(statistics.median(d[c,m].values())/1e6,3) for m in ('normal','batch','omit')])
