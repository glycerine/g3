from study import *
import io
from pathlib import Path
d=w/'substitution-native';d.mkdir(exist_ok=True)
def main():
 q=pkg/'smtcore/cached_var_subst.go';test=pkg/'smtcore/smt_quantifier_substitution_benchmark_test.go'
 native=w/'substitution-release/native-batches';bs={}
 for v in ['previous','g3']:
  od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',{q:subprocess.check_output(['git','show','c6c84b31e:pkg/smtcore/cached_var_subst.go'],cwd=pkg,text=True)if v=='previous'else q.read_text(),test:test.read_text()});b=od/'cache.test'
  with(w/'build.lock').open('a')as f:
   fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-c','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg)
  bs[v]=b
 bs['native']=native
 with(d/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round cpu engine batch iterations ns bytes allocs'.split())
  for i in range(21):
   vs=list(bs);vs=vs[i%3:]+vs[:i%3]
   for v in vs:
    cmd=['taskset','-c','45',bs[v]]
    if v!='native':cmd+=['-test.run=^$','-test.bench=^BenchmarkSMTQuantifierInstanceBatches$','-test.benchtime=65536x','-test.cpu=1','-test.benchmem']
    r=run(cmd,cwd=pkg/'smtcore',text=True,capture_output=True)
    vals=[[x['batch'],x['iterations'],x['ns_per_op'],'','']for x in csv.DictReader(io.StringIO(r.stdout))]if v=='native'else re.findall(r'BenchmarkSMTQuantifierInstanceBatches/(\d+)\s+(65536)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout)
    assert len(vals)==4 and all(x[1]=='65536' for x in vals),(v,r.stdout)
    z.writerows([[i+1,45,v,*x]for x in vals]);f.flush()
if __name__=='__main__':main()
