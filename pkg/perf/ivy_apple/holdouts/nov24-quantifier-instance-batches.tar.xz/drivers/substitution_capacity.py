from study import *
import guarded_live as gl,macro_identity as mi,substitution_resets as sr,theory_traversal_steps as th
from collections import Counter
d=w/'substitution-capacity';d.mkdir(exist_ok=True)
q=sr.q;bst=pkg/'smtcore/smt_quantifier_substitution_benchmark_test.go'
def edit(v):
 ed=sr.edits('bounded') if v not in ('audit','control','lazy','adaptive')else {}
 s=ed.get(q,q.read_text())
 if v=='audit':
  s=once(s,'import (','import (\n"os";"fmt"')
  for method,n in [('Reset','reset'),('Close','close')]:
   start=s.index('func (c *SMTCachedVarSubstitution) '+method+'()');i=s.index('return c.clearEntries()'if method=='Reset'else'if err := c.clearEntries();',start)
   s=s[:i]+'''fmt.Fprintln(os.Stderr,"SUB-CAP","'''+n+'''",len(c.list),cap(c.list),len(c.refs),cap(c.refs))
   '''+s[i:]
 if v=='lazy':
  s=once(s,'{manager: m, entries: make(map[uint64]uint32)}','{manager:m}');s=once(s,'c.entries = make(map[uint64]uint32)','c.entries=nil')
  s=once(s,'c.list = append(c.list, smtCachedSubstitutionEntry','if c.entries==nil{c.entries=make(map[uint64]uint32)}\n c.list = append(c.list, smtCachedSubstitutionEntry')
 if v=='adaptive':
  s=sr.edits('bounded')[q]
  a=s.index('large:=cap(c.list)>2048');b=s.index('var releaseErr error',a)
  s=s[:a]+'''large:=cap(c.list)>2048 || cap(c.list)>64 && len(c.list)<cap(c.list)/8
  if large{c.list=nil;c.entries=nil}else{c.list=c.list[:0];clear(c.entries)}
  discardRefs:=cap(c.refs)>8192 || cap(c.refs)>256 && len(c.refs)<cap(c.refs)/8
  '''+s[b:];s=s.replace('if cap(c.refs)>8192','if discardRefs')
  s=once(s,'{manager: m, entries: make(map[uint64]uint32)}','{manager:m}');s=once(s,'c.list = append(c.list, smtCachedSubstitutionEntry','if c.entries==nil{c.entries=make(map[uint64]uint32)}\n c.list = append(c.list,smtCachedSubstitutionEntry')
 if v.startswith('cap'):
  k=int(v[3:]);s=s.replace('cap(c.list)>2048','cap(c.list)>'+str(k)).replace('cap(c.refs)>8192','cap(c.refs)>'+str(4*k))
 b=bst.read_text();i=b.index('func BenchmarkSMTQuantifierInstanceStream');body=b[i:];body=once(body,'b *testing.B) {','b *testing.B) {for _,w:=range []int{4,8,16,32}{b.Run(strconv.Itoa(w*w),func(b *testing.B){')
 body=once(body,'var atoms [32]*SMTEnode','atoms:=make([]*SMTEnode,w)')
 body=body.rstrip()[:-1]+'})}}\n';ed[q]=s;ed[bst]=b[:i]+body;return ed
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edit(v));b=od/'smt.test'
 with(w/'build.lock').open('a')as f,(od/'focused.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-c','-pgo=off','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=log,stderr=log)
  run([b,'-test.run','CachedVarSubstitution|QIInstance','-test.count=1'],cwd=pkg/'smtcore',stdout=log,stderr=log)
 return b,build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def census(j,b):
 cpu,n,sp,iso,rc,_,ref=j;od=d/'audit'/n;od.mkdir(exist_ok=True);ct=Counter()
 with (od/'stdout').open('wb')as so,(od/'stderr').open('wb')as se,subprocess.Popen(['taskset','-c',str(cpu),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=od,env=dict(env,GOMAXPROCS='1'),stdout=so,stderr=subprocess.PIPE)as p:
  for l in p.stderr:
   if l.startswith(b'SUB-CAP '):ct[tuple(l.decode().split()[1:])]+=1
   else:se.write(l)
  code=p.wait()
 assert code==rc and all((od/k).read_bytes()==(ref/k).read_bytes()for k in ('stdout','stderr')),(n,code)
 with(od/'sizes.csv').open('w')as f:
  z=csv.writer(f);z.writerow('action entries entry_capacity refs ref_capacity calls'.split());z.writerows([*k,v]for k,v in ct.items())
 print('audit',n,sum(ct.values()),flush=True)
def micro(bs):
 with(d/'batches.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round variant batch calls ns bytes allocs'.split())
  for i in range(15):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in vs:
    r=run(['taskset','-c','42',bs[v],'-test.run=^$','-test.bench=^BenchmarkSMTQuantifierInstanceStream$','-test.benchmem','-test.cpu=1','-test.benchtime=16384x'],cwd=pkg/'smtcore',capture_output=True,text=True)
    vals=re.findall(r'BenchmarkSMTQuantifierInstanceStream/(\d+)\s+(16384)\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert len(vals)==4,r.stdout;z.writerows([[i+1,v,*r]for r in vals]);f.flush()
def main():
 vs=['control','lazy','cap64','cap256','cap512','cap2048','adaptive','audit']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 _,a,_=bs.pop('audit');gl.d=d;th.d=d
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([26,27,29,31,32,33],(j for j in mi.jobs()if j[1]in ('tlb','rfn2','flash2','cf_live','ordinary','hybrid_reliable_broadcast_cisa')))]
 audits=mi.jobs()+[(5,'testing','jea/hermes_rmw_o3_testing.ivy','',0,1,w/'extended-phases/long/1/1/native'),(7,'apple','doc/examples/apple/ord_live.ivy','',0,1,w/'apple-original-pairs/14-native')]
 for p in (d/'audit',):p.mkdir(exist_ok=True)
 with ThreadPoolExecutor(20)as e:
  future=[e.submit(census,j,a)for j in audits]+[e.submit(gl.measure_job,j,{v:b[1]for v,b in bs.items()})for j in js]+[e.submit(micro,{v:b[0]for v,b in bs.items()})]
  for job in future:job.result()
if __name__=='__main__':main()
