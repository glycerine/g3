from study import *
import guarded_live as gl,macro_identity as mi,theory_traversal_steps as th
d=w/'substitution-resets';d.mkdir(exist_ok=True)
q=pkg/'smtcore/cached_var_subst.go';a=pkg/'ast/ast_core_accessors.go';p=pkg/'ast/rewriter/ground_instance.go'
def edits(v):
 if v=='control':return {}
 s=q.read_text();es={}
 if v in ('drop','both','bounded','plans','all'):
  i=s.index('for len(c.refs) != 0 {');j=s.index('c.refs = nil',i)
  s=s[:i]+'''var releaseErr error
  c.refs,releaseErr=c.manager.ShrinkHeldRefs(c.refs,0);if releaseErr!=nil{return releaseErr}
  '''+s[j:]
 if v in ('acquire','both','all'):
  atext=a.read_text();i=atext.index('if h.IsNull()',atext.index('func (m *ASTManager) IncRef(h'));j=atext.index('func (m *ASTManager) DecRef(',i)
  body=atext[i:j]
  atext=atext[:i]+'''return m.trialIncLocked(h)}
  func(m *ASTManager)TrialIncRefs(hs []ASTHandle)(int,error){
   if err:=m.lock();err!=nil{return 0,err};defer m.mu.Unlock()
   for i,h:=range hs{if err:=m.trialIncLocked(h);err!=nil{return i,err}}
   return len(hs),nil
  }
  func(m *ASTManager)trialIncLocked(h ASTHandle)error{'''+body+atext[j:];es[a]=atext
  s=once(s,'for i, h := range c.refs[start:] {\n\t\tif err := c.manager.IncRef(h); err != nil {','{\n if i,err:=c.manager.TrialIncRefs(c.refs[start:]);err!=nil{')
 if v in ('bounded','all'):
  s=once(s,'c.list = nil\n\tc.entries = make(map[uint64]uint32)','''large:=cap(c.list)>2048
   if large{c.list=nil;c.entries=make(map[uint64]uint32)}else{c.list=c.list[:0];clear(c.entries)}''')
  s=once(s,'c.refs = nil','if cap(c.refs)>8192 {c.refs=nil}')
  s=once(s,'c.closed = true','c.refs=nil;c.entries=nil;c.list=nil;c.scratch=nil;c.closed = true')
 if v in ('plans','all'):
  t=p.read_text()+'\nfunc(c *GroundInstancePlans)TrialResetOwnedRoots()error{return c.release()}\n';es[p]=t
  s=once(s,'if err := c.plans.Clear(); err != nil {','if err := c.plans.TrialResetOwnedRoots(); err != nil {')
  s=once(s,'c.closed = true','if err:=c.plans.Clear();err!=nil{return err};c.closed=true')
 es[q]=s;return es
def buildv(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v));b=od/'smt.test'
 with (w/'build.lock').open('a')as f,(od/'focused.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-pgo=off','-c','-overlay='+str(o),'-o',b,'./smtcore'],cwd=pkg,stdout=log,stderr=log)
  run([b,'-test.run','CachedVarSubstitution|GroundInstance|Substitution|QIInstance|Fingerprint','-test.count=1'],cwd=pkg/'smtcore',stdout=log,stderr=log)
 return b,build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def micro(bs):
 with(d/'micro.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round variant iterations ns bytes allocs'.split())
  for i in range(21):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for v in vs:
    r=run(['taskset','-c','38',bs[v],'-test.run=^$','-test.bench=^BenchmarkSMTQuantifierInstanceStream$','-test.benchmem','-test.cpu=1','-test.benchtime=65536x'],cwd=pkg/'smtcore',capture_output=True,text=True)
    sample=re.search(r'BenchmarkSMTQuantifierInstanceStream\s+(65536)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert sample,r.stdout;z.writerow([i+1,v,*sample.groups()]);f.flush()
def main():
 vs=['control','drop','acquire','both','bounded','plans','all']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(buildv,vs)))
 gl.d=d;th.d=d;bb={v:b[1]for v,b in bs.items()};ss={v:b[2]for v,b in bs.items()}|{'native':pkg.parent/'build/z3'}
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([26,27,28,29,30,32,34,35,36],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(16)as e:
  fs=[e.submit(gl.measure_job,j,bb)for j in js]+[e.submit(th.replay,(c,n,ss))for c,n in [(11,'toy-consensus-18'),(12,'ticket-127'),(13,'ticket-290'),(17,'aux-012725')]]+[e.submit(micro,{v:b[0]for v,b in bs.items()})]
  for f in fs:f.result()
if __name__=='__main__':main()
