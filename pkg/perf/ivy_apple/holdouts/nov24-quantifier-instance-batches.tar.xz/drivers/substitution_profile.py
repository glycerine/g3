from study import *
from nlsat_final import perfstat
from types import SimpleNamespace
import io
d=w/'substitution-profile';d.mkdir(exist_ok=True);bins={v:w/'substitution-native'/v/'cache.test'for v in ['previous','g3']}|{'native':w/'substitution-release/native-batches'}
def cmd(v):
 return [bins[v]]+([]if v=='native'else['-test.run=^$','-test.bench=^BenchmarkSMTQuantifierInstanceBatches$','-test.benchtime=65536x','-test.cpu=1','-test.benchmem'])
def lane():
 with(d/'instructions.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine total_instructions iterations'.split())
  for i in range(11):
   vs=list(bins);vs=vs[i%3:]+vs[:i%3]
   for v in vs:
    res,n,t=perfstat(41,d/(v+'.perf'),cmd(v));assert not res.returncode and ('65536' in res.stdout.decode());z.writerow([i+1,v,n,4*65536]);f.flush()
def profiles():
 for i in range(3):
  for v in bins:
   rd=d/f'{i+1}-{v}';rd.mkdir(exist_ok=True);p=run(['taskset','-c','45',perf,'record','-q','-e','instructions:u','-c','55003','--no-buildid','--call-graph','dwarf,8192' if v=='native'else'fp','-o',rd/'data','--',*cmd(v)],cwd=pkg/'smtcore',env=dict(env,GOMAXPROCS='1'),capture_output=True);assert p.stdout.count(b'65536')==4,p.stdout[-500:]
   for n,fl in [('leaf','--no-children'),('inclusive','--children')]:
    with(rd/(n+'.txt')).open('wb')as f:run([perf,'report',fl,'--stdio','--no-demangle','--percent-limit','.15','--stdio-color=never','--no-call-graph','-i',rd/'data'],stdout=f)
   (rd/'data').unlink()
if __name__=='__main__':
 with ThreadPoolExecutor(2)as e:
  a=e.submit(lane);b=e.submit(profiles);a.result();b.result()
