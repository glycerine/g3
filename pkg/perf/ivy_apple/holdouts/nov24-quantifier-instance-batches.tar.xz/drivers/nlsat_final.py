from study import *
root=w/'nlsat-final';root.mkdir(exist_ok=True)
f=pkg/'nlsat/assignment.go';t=f.with_name('assignment_growth_test.go');r=f.with_name('assignment_test.go')
def compile_(v):
 d=root/v;s=t.read_text();old=subprocess.check_output(['git','show','63a45d7c5:pkg/nlsat/assignment.go'],cwd=pkg).decode()
 ed={t:s,r:r.read_text(),f:f.read_text()}
 if v=='before':
  s=s[:s.index('func TestAssignmentGrowth')]+s[s.index('func BenchmarkNLSAT'):];s=s.replace('"errors"','').replace('"github.com/glycerine/g3/pkg/arena"','');ed[t]=s;ed[f]=old
 o=overlay(d/'overlay',ed)
 with (w/'build.lock').open('a')as lk,(d/'tests').open('w')as out:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-c','-overlay='+str(o),'-o',d/'assignment.test','./nlsat'],cwd=pkg,stdout=out,stderr=out);run([d/'assignment.test','-test.run','^TestAssignment'],stdout=out,stderr=out,env=dict(env,G3_CPP_REFERENCE=str(pkg.parent/'build/z3')))
 return build(d,o=o,shell=True)
def perfstat(cpu,pf,argv):
 t0=time.monotonic();p=subprocess.run(['taskset','-c',str(cpu),perf,'stat','-x,','-e','instructions:u','-o',pf,'--',*argv],env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True,timeout=330);ct=next(int(z[0])for z in csv.reader(pf.read_text().splitlines())if len(z)>4 and z[2]=='instructions:u'and float(z[4])==100);return p,ct,round(time.monotonic()-t0,4)
def mic(bs):
 with(root/'micro.csv').open('w')as out:
  wr=csv.writer(out);wr.writerow('pair variant width iterations instructions ns bytes objects'.split())
  for j in range(1,9):
   for k,n in [(128,60),(1024,8),(8192,1)]:
    for x in ['before','after'][::1 if j%2 else -1]:
     for count in [n,n*3][::1 if j%2 else -1]:
      d=root/x;p,c,_=perfstat(45,d/'bench.perf',[d/'assignment.test','-test.run','^$','-test.cpu','1','-test.bench','^BenchmarkNLSATAssignmentGrowth$/^'+str(k)+'$','-test.benchmem','-test.benchtime='+str(count)+'x']);assert p.returncode==0;m=re.search(rb'^Benchmark\S+\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert m and int(m[1])==count;wr.writerow([j,x,k,count,c,*[b.decode() for b in m.groups()[1:]]]);out.flush()
def lane(job):
 cpu,key,bs=job;d=root/key;d.mkdir();q=w/'nra-checks'/key/'input.smt2';real=not q.exists()
 if real:q=pkg/'cmd/g3/test_vectors'/(key+'.smt2')
 ref=None;stref=None;ansref=None
 with(d/'runs.csv').open('w')as o:
  wr=csv.writer(o);wr.writerow('pair variant instructions seconds exit equal_go_output equal_verdicts answers propagations stages rlimit'.split())
  for j in range(1,4):
   for v,b in list(bs.items())[::1 if j%2 else -1]:
    p,c,dt=perfstat(cpu,d/f'{j}-{v}.perf',[b,*([]if real else['-st']),'-smt2',q]);txt=p.stdout.decode();(d/f'{j}-{v}.out').write_bytes(p.stdout+p.stderr);ans=','.join(re.findall(r'^(sat|unsat|unknown)$',txt,re.M));st=dict(re.findall(r':([\w-]+)\s+(\d+)\b',txt));stats=[int(st.get(a,0))for a in ('nlsat-propagations','nlsat-stages','rlimit-count')];raw=(txt if real else ans,p.stderr,p.returncode)
    if ref is None and v=='before':ref=raw;ansref=ans;stref=stats
    assert p.returncode==0 and ans,(key,v,p.returncode,txt[:200])
    if v!='native':assert raw==ref,(key,v,ans,ansref)
    if not real:assert ans=='sat'and stats==stref,(key,v,stats,stref)
    wr.writerow([j,v,c,dt,p.returncode,''if v=='native'else int(raw==ref),int(ans==ansref),ans,*stats]);o.flush()
 print(key,flush=True)
if __name__=='__main__':
 bs={v:compile_(v)for v in ('before','after')};bs['native']=pkg.parent/'build/z3'
 synth=['independent-8192-default','independent-2048-default','independent-8192-cnf','ordered-512-default','coupled-512-default','independent-512-default','independent-128-default','coupled-128-cnf','ordered-32-cnf'];names=synth+[p.stem for p in sorted((pkg/'cmd/g3/test_vectors').glob('*.smt2'))if any(s in p.name for s in ('nonlinear','rational_square','qfnra_nlsat','nested_rational','nlsat_shuffle'))]
 with ThreadPoolExecutor(3)as x:
  f0=x.submit(mic,bs);rs=list(x.map(lane,[(cpu,k,bs)for cpu,k in zip(([37,38]*50),names)]));f0.result()
