"""Sum each run before taking the median across complete runs."""
from collections import Counter, defaultdict
import csv, statistics, sys
runs = defaultdict(Counter)
for row in csv.DictReader(open(sys.argv[1])):
    runs[row['engine'], row['round']][row['phase']] += int(row['instructions'])
for counts in runs.values():
    if 'kernel' in counts:
        counts['outside kernel'] = counts['whole'] - counts['kernel']
        counts['other kernel'] = counts['kernel'] - counts['internalize']
        counts['commit after reduction'] = counts['internalize'] - counts['reduce']
    elif 'propagate-values' in counts:
        counts['outside named passes'] = counts['whole'] - sum(n for p,n in counts.items() if p != 'whole')
for phase in sorted({phase for counts in runs.values() for phase in counts}):
    print(phase, {engine: round(statistics.median(v[phase] for (e,i),v in runs.items() if e == engine)/1e6,2)
                  for engine in sorted({e for e,i in runs})})
