from collections import Counter,defaultdict
from pathlib import Path
import csv,statistics
w=Path(__file__).resolve().parent
d=defaultdict(Counter)
for r in csv.DictReader((w/'samples.csv').open()):
 e=r['engine'];fs=r['stack'].split('\t')
 if ('Z3_solver_push' not in fs if e=='z3' else not any(f.endswith('goivy/smt.(*Z3Solver).Push') for f in fs)):continue
 ctr=d[e,int(r['round'])];ctr['all']+=1
 def hit(a):return any(a in f for f in fs)
 phases=[('pattern inference','inferPendingPatterns','pattern_inference_fn::simplify'),('macro finder','findPendingMacros','find_macros_core()'),('value propagation','propagatePendingAssertions','asserted_formulas::propagate_values('),('BV sharing','maximizePendingBVSharing','max_bv_sharing_fn::simplify'),('NNF','normalizePendingAssertions','asserted_formulas::nnf_cnf()')]
 for label,a,b in phases:
    if hit(a if e=='g3' else b):ctr[label]+=1;break
 for a,b in [('(*rewriterEngine).processQuantifier','process_quantifier('),('(*theoryRewriterConfiguration).ReduceQuantifier','th_rewriter_cfg::reduce_quantifier('),('(*patternCandidates).inferPatternBody','pattern_inference_cfg::mk_patterns(')]:
    if hit(a if e=='g3' else b):ctr[a]+=1
 if hit('(*SMTKernel).internalizePending') and not hit('(*SMTKernel).reduceAssertedPending'):ctr['install']+=1
for e in ['g3','z3']:
 print(e)
 for name in sorted(set().union(*(set(c) for (ee,i),c in d.items() if ee==e))):
    print(name,round(statistics.mean(c[name] for (ee,i),c in d.items() if ee==e)*1.500007,1))
