"""Bracket each invoked pass during external first pushes in the same frontend."""
from pathlib import Path
import subprocess,os,json,re,shlex,shutil
p=Path.cwd();w=p/'build/.push-gap';b=w.parent/'.boolean-enode-cost';f=b/'frontend/goivy';old=w.parent/'.hybrid-obligations'
files=json.loads((old/'observer.json').read_text())['Replace']
def patch(k,s):
 v=w/('detail-phase-'+k.name);v.write_text(s);files[str(k)]=str(v)
k=f/'z3bridge_solver_model.go';s=Path(files[str(k)]).read_text()
a='z3solver.Push()\n\t\t\t\t\tif first';assert s.count(a)==1
if '"os"' not in s:s=s.replace('import (','import (\n"os"')
patch(k,s.replace(a,'if first {os.Setenv("G3_PUSH_PHASES","1")}\n z3solver.Push()\n if first {os.Unsetenv("G3_PUSH_PHASES")}\n if first'))
shared=files.copy()
for e in ['g3','z3']:
 files=shared.copy()
 if e=='g3':
    s=(old/'phase-counters/phase_observer_trial.go').read_text().replace('package goivy','package smtcore').replace('func startStage(batch, goal int)','func samplePushPass()')
    s=s.replace('runtime.LockOSThread()','if os.Getenv("G3_PUSH_PHASES")!="1" {return func(string){}};runtime.LockOSThread()').replace('"STAGE-COUNT", batch, goal, phase','"PASS-COUNT", phase')
    patch(p/'smtcore/zz_first_push_sample.go',s)
    k=p/'smtcore/smt_asserted_propagate.go';s=k.read_text()
    for call,label in [('one, result = k.rewritePendingAssertion(i)','rewrite'),('result = k.addAssertionSubstitution(k.assertions[i], depth)','substitute')]:
        assert s.count(call)==1
        s=s.replace(call,'{end:=samplePushPass();'+call+';end("'+label+'")}')
    call='if changed {\n\t\treturn k.reducePendingAssertions()'
    assert s.count(call)==1;s=s.replace(call,'if changed {\n defer samplePushPass()("followup");return k.reducePendingAssertions()')
    patch(k,s)

 else:
    build=p.parent/'build';k=p.parent/'src/smt/asserted_formulas.cpp';s=k.read_text();a='if (!s.should_apply()) return true;';assert s.count(a)==1
    hdr='''#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
struct measure_push_pass {
  const char* name; int fd=-1; unsigned long long before[3]{},empty[3]{};
  void read3(unsigned long long* a){if(read(fd,a,24)!=24 || a[1]!=a[2]) abort();}
  explicit measure_push_pass(const char* n):name(n) {
    if(!getenv("G3_PUSH_PHASES")) return;
    perf_event_attr a{};a.size=sizeof(a);a.config=PERF_COUNT_HW_INSTRUCTIONS;a.type=PERF_TYPE_HARDWARE;
    a.exclude_kernel=a.exclude_hv=1;a.read_format=PERF_FORMAT_TOTAL_TIME_ENABLED|PERF_FORMAT_TOTAL_TIME_RUNNING;
    fd=syscall(SYS_perf_event_open,&a,0,-1,-1,0);if(fd<0)abort();read3(empty);read3(before);
  }
  ~measure_push_pass(){if(fd<0)return;unsigned long long after[3];read3(after);close(fd);
    fprintf(stderr,"PASS-COUNT %s %llu %llu %llu %llu 0\\n",name,after[0]-before[0]-(before[0]-empty[0]),before[0]-empty[0],after[1]-before[1],after[2]-before[2]);}
};
'''
    for call,label in [('m_rewriter(n, new_n, new_pr);','rewrite'),('update_substitution(new_n, new_pr);','substitute')]:
        sig='unsigned asserted_formulas::propagate_values(unsigned i)';i=s.index(sig);j=s.index('void asserted_formulas::update_substitution',i)
        part=s[i:j];assert part.count(call)==1
        s=s[:i]+part.replace(call,'{measure_push_pass measured("'+label+'");'+call+'}')+s[j:]
    a='if (num_prop > 0)\n        m_reduce_asserted_formulas();';assert s.count(a)==1
    s=s.replace(a,'if (num_prop > 0) { measure_push_pass measured("followup"); m_reduce_asserted_formulas(); }')
    dst=w/('detail-'+k.name);dst.write_text(hdr+s)
    flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
    inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
    obj=w/'asserted_formulas.o';lib=w/'libdetail.a';shutil.copyfile(f/'z3vendor/native_lib/libz3.a',lib)
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dst],cwd=build,check=True)
    subprocess.run(['ar','r',lib,obj],check=True)
    k=f/'smt/quantifier.go';patch(k,k.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
 ov=w/('detail-'+e+'.json');ov.write_text(json.dumps({'Replace':files}))
 subprocess.run(['go','build','-mod=readonly','-pgo=off','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',ov,'-o',w/('detail-'+e),'./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
