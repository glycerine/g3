"""Check complete transcripts and count whole first pushes or disjoint top-level passes."""
import csv,os,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;ex=Path('/home/jaten/ivy/ivy-lang-examples');gold=w.parent/'.bool-scan/golden/reference/hybrid'
wr=csv.writer(sys.stdout);wr.writerow(('engine','round','batch','phase','instructions'))
bins=[(s.split('=')[0],Path(s.split('=')[1]).resolve()) for s in sys.argv[1:]]
for i in range(7):
 for label,exe in bins[i%len(bins):]+bins[:i%len(bins)]:
    r=subprocess.run(['taskset','-c','12',exe,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),check=True)
    stages=[];pending=[];first=0
    for l in r.stderr.splitlines(keepends=True):
        if l.startswith(b'PASS-COUNT '):
            _,ph,n,empty,en,run,ns=l.decode().split();assert en==run and int(en)>0
            pending.append((ph,int(n)))
        elif l.startswith(b'STAGE-COUNT '):
            _,b,g,ph,n,empty,en,run,ns=l.decode().split()
            if ph=='first':
                assert en==run and int(en)>0
                for phase,amount in pending+[('whole',int(n))]:wr.writerow((label,i+1,b,phase,amount))
                pending=[];first+=1
            assert not pending
        else:stages.append(l)
    assert first==34 and r.stdout==(gold/'stdout').read_bytes() and b''.join(stages)==(gold/'stderr').read_bytes()
    sys.stdout.flush()
