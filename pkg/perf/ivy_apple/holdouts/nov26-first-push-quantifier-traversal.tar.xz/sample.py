"""Collect complete hybrid process samples and retain stacks rooted in a solver push."""
import csv,os,re,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
exe={'g3':w.parent/'.witness-origin/release','z3':w.parent/'.operand-cost/linked-z3'}
gold=w.parent/'.bool-scan/golden/reference/hybrid';ex=Path('/home/jaten/ivy/ivy-lang-examples')
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
out=csv.writer(sys.stdout);out.writerow(['engine','round','stack'])
for i in range(6):
 for e in list(exe)[::(-1 if i%2 else 1)]:
    raw=w/(e+'.data')
    r=subprocess.run(['taskset','-c','14',perf,'record','-q','-B','-N','-m','2048','-e','instructions:u','-c','1500007','--call-graph','fp,96' if e=='g3' else 'dwarf,8192','-o',raw,'--',exe[e],ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,check=True)
    assert (r.stdout,r.stderr)==tuple((gold/n).read_bytes() for n in ['stdout','stderr']),r.stderr
    stat=subprocess.check_output([perf,'script','--show-lost-events','--no-inline','-i',raw],text=True)
    assert 'PERF_RECORD_LOST' not in stat
    for block in stat.split('\n\n'):
        frames=re.findall(r'^\s+[\da-fA-F]+ (.*?)\+0x',block,re.M)
        if frames and any(('PushCore' in f or 'SolverPush' in f or 'Z3_solver_push' in f or '::push()' in f or ').Push' in f) for f in frames):
            out.writerow([e,i+1,'\t'.join(frames)])
    sys.stdout.flush()
