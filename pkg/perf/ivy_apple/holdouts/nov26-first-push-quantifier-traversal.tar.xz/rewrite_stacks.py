"""Print hottest sampled leaves below a first-push value-sweep rewriter."""
import csv
from collections import Counter
from pathlib import Path
counts = {'g3': Counter(), 'z3': Counter()}
for r in csv.DictReader((Path(__file__).resolve().parent/'samples.csv').open()):
    frames = r['stack'].split('\t')
    labels = ('goivy/smt.(*Z3Solver).Push', '(*SMTKernel).rewritePendingAssertion', '(*TheoryRewriter).Rewrite') if r['engine']=='g3' else ('Z3_solver_push','asserted_formulas::propagate_values(', 'rewriter_tpl<th_rewriter_cfg>')
    if all(any(label in f for f in frames) for label in labels):
        counts[r['engine']][frames[0]] += 1
for engine, c in counts.items():
    print(engine, sum(c.values()))
    for name, n in c.most_common(12):
        print(n, name)
