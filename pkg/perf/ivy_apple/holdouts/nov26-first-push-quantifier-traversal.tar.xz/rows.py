from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();b=w.parent/'.boolean-enode-cost';f=b/'frontend/goivy'
files=json.loads((w/'final-pass-g3.json').read_text())['Replace'];del files[str(p/'smtcore/smt_asserted_driver.go')]
k=p/'smtcore/smt_asserted_propagate.go';s=k.read_text().replace('import (','import (\n"fmt"\n"os"')
a='var one bool\n';assert s.count(a)==1
s=s.replace(a,'''var end func(string)
 label:=""
 if os.Getenv("G3_PUSH_PHASES")=="1" {label=fmt.Sprintf("row/%t/%d",reverse,i-k.assertedHead);end=samplePushPass()}
 '''+a)
a='result = k.addAssertionSubstitution(k.assertions[i], depth)\n\t\t\t\t}';assert s.count(a)==1
s=s.replace(a,a+'\nif end!=nil {end(label)}')
dst=w/'rows-propagate.go';dst.write_text(s);files[str(k)]=str(dst);ov=w/'rows.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'rows','./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
