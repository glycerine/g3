import json,os,subprocess,sys
from pathlib import Path
p=Path.cwd();w=p/'build/.push-gap';b=w.parent/'.boolean-enode-cost'
for mode in sys.argv[1:]:
 f=p/'ast/rewriter/th_rewriter.go';s=f.read_text()
 anchor='uniquePatterns, e := theoryUniqueArguments(patterns)'
 if mode=='small':
    i=s.index(anchor);j=s.index('\n\t}',i)
    s=s[:i]+'''if patterns.Count() <= 1 && noPatterns.Count() <= 1 {
      updated, err = m.UpdateQuantifierArguments(old, body, patterns, noPatterns)
    } else {'''+s[i:j]+'}'+s[j:]
 else:
    a='var updated ast.ASTHandle';assert s.count(a)==1
    s=s.replace(a,'''if bodyKind != ast.ASTQuantifier && oldPatterns==0 && oldNoPatterns==0 && patterns.Count()==0 && noPatterns.Count()==0 && !ast.ASTValidateHandles && !ast.ASTSourceDebug && m.TraceStream==nil && !m.Budget().InjectionArmed() {
      original,e:=m.GetQuantifierBody(old); if e!=nil{return false,e}
      if body==original {
        may,e:=m.QuantifierMayHaveUnusedVars(old);if e!=nil{return false,e}
        if !may {ground,e:=m.IsGround(body);if e!=nil{return false,e}
          off,e:=m.ProofsDisabled();if e!=nil{return false,e}
          if off && !ground{return true,m.SetRef(out,old)}
        }
      }
    }
    '''+a)
 dst=w/(mode+'.go');dst.write_text(s)
 for cost in [False,True]:
    files=json.loads((w.parent/'.hybrid-obligations/observer.json').read_text())['Replace'] if cost else {}
    name=mode+('-cost' if cost else '');files[str(f)]=str(dst);ov=w/(name+'.json');ov.write_text(json.dumps({'Replace':files}))
    subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/name,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
