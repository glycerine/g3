"""Count equality of actual ordered formula/proof handles, qualified by AST owner and generation."""
import csv,collections,statistics,itertools,re
from pathlib import Path
w=Path(__file__).resolve().parent
d=collections.defaultdict(list)
for r in csv.DictReader((w/'inputs.csv').open()):
    rows=re.findall(r'\{[^}]+\}/\{[^}]+\}',r['ordered_rows'])
    assert ' '.join(rows)==r['ordered_rows']
    d[r['pass']].append((r['batch'],rows))
for ph,batches in d.items():
    previous=[];n=prefix=identical=repeat=0;prior=set();origins=set()
    for b,rows in batches:
        p=max((sum(1 for _ in itertools.takewhile(lambda ab:ab[0]==ab[1],zip(rows,old))) for old in previous),default=0)
        prefix+=p;identical+=any(rows==old for old in previous);repeat+=sum(v in prior for v in rows);n+=len(rows);prior.update(rows);previous.append(rows)
        origins.update(v.split()[0] for v in rows)
    print(ph,len(batches),n,'earlier rows',repeat,'best prior ordered prefix rows',prefix,'full repeats',identical,'origins',len(origins))
