from pathlib import Path
from collections import defaultdict,Counter
import csv,re,statistics,itertools
w=Path(__file__).resolve().parent
labels={};history=[];seen=set()
for r in csv.DictReader((w/'inputs.csv').open()):
 if r['pass']!='propagate-values':continue
 seq=re.findall(r'\{[^}]+\}/\{[^}]+\}',r['ordered_rows'])
 prefix=max((sum(1 for _ in itertools.takewhile(lambda t:t[0]==t[1],zip(seq,prior))) for prior in history),default=0)
 for j,row in enumerate(seq):
    labels[int(r['batch']),j]='prefix' if j<prefix else 'other prior batch row' if row in seen else 'new to batch history'
 seen.update(seq);history.append(seq)
runs=defaultdict(Counter);rowcost=defaultdict(list)
for r in csv.DictReader((w/'rows.csv').open()):
 if r['phase']=='whole':continue
 _,rev,idx=r['phase'].split('/');key=int(r['batch']),int(idx);assert key in labels
 runs[r['round']][labels[key],rev]+=int(r['instructions'])
 rowcost[key,rev].append(int(r['instructions']))
assert len(rowcost)==2*len(labels) and all(len(x)==7 for x in rowcost.values())
for k in next(iter(runs.values())):
 print(k,round(statistics.median(x[k] for x in runs.values())/1e6,3))
tops=sorted(((statistics.median(v)+statistics.median(rowcost[key,'true']),key) for (key,rev),v in rowcost.items() if rev=='false'),reverse=True)
print('top ten rows',[(k,round(n/1e6,2)) for n,k in tops[:10]])
print('top ten fraction',sum(n for n,k in tops[:10])/sum(n for n,k in tops))
