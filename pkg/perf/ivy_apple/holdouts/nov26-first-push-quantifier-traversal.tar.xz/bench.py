from pathlib import Path
import subprocess,json,csv,re,sys,os
p=Path.cwd();w=p/'build/.push-gap';d=p/'ast/pattern';files={}
for n in ['candidate_selection','candidates','candidates_test','collect','collect_test','connected_multi_pattern','multi_pattern','preferred_pattern']:
 f=d/(n+'.go');dst=w/('baseline-'+f.name);dst.write_bytes(subprocess.check_output(['git','show','0f3389d37:pkg/ast/pattern/'+f.name]));files[str(f)]=str(dst)
dst=w/'empty.go';dst.write_text('package pattern\n');files[str(d/'free_vars.go')]=str(dst)
if (d/'free_vars_test.go').exists():files[str(d/'free_vars_test.go')]=str(dst)
ov=w/'baseline.json';ov.write_text(json.dumps({'Replace':files}))
for e,overlay in [('base',['-overlay',ov]),('packed',[])]:
 subprocess.run(['go','test','-c',*overlay,'-o',w/(e+'.test'),'./ast/pattern'],env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
out=csv.writer(sys.stdout);out.writerow(['engine','round','width','ns','bytes','allocs'])
for i in range(7):
 for e in ['base','packed'][::(-1 if i%2 else 1)]:
    r=subprocess.check_output(['taskset','-c','16',w/(e+'.test'),'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkPatternSharedApplications$','-test.benchtime=300x','-test.benchmem'],text=True)
    rows=re.findall(r'^BenchmarkPatternSharedApplications/Width(\d+)\s+300\s+([.\d]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r,re.M);assert len(rows)==4,r
    out.writerows([e,i+1,*row] for row in rows);sys.stdout.flush()
