import os,subprocess
from pathlib import Path
p=Path.cwd();w=p/'build/.push-gap';b=w.parent/'.boolean-enode-cost'
for name,ov in [('shape',[]),('shape-cost',['-overlay',w.parent/'.hybrid-obligations/observer.json'])]:
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off',*ov,'-o',w/name,'./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
