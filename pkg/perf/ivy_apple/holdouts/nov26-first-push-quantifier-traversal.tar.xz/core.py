"""Measure the preprocessor call alone during each value-propagation row."""
import json, os, subprocess
from pathlib import Path
p=Path.cwd(); w=p/'build/.push-gap'; b=w.parent/'.boolean-enode-cost'
files=json.loads((w/'detail-g3.json').read_text())['Replace']
k=p/'smtcore/smt_asserted_propagate.go'; s=k.read_text()
a='one, result = k.rewritePendingAssertion(i)'
assert s.count(a)==1
s=s.replace(a,'track := os.Getenv("G3_PUSH_PHASES")=="1"; if track {os.Setenv("G3_ROW_CORE","1")}; '+a+'; if track {os.Unsetenv("G3_ROW_CORE")}')
if '"os"' not in s:s=s.replace('import (','import (\n"os"')
dst=w/'core-propagate.go'; dst.write_text(s); files[str(k)]=str(dst)
k=p/'smtcore/smt_asserted_formulas.go'; s=k.read_text()
a='proofGen := k.preprocessor.ProofGen()'; x=s.index(a); y=s.index('if err != nil {',x)
s=s[:x]+'var endCore func(string); if os.Getenv("G3_ROW_CORE")=="1" {endCore=samplePushPass()}\n'+s[x:y]+'if endCore!=nil {endCore("core")}\n'+s[y:]
if '"os"' not in s:s=s.replace('import (','import (\n"os"')
dst=w/'core-formulas.go'; dst.write_text(s); files[str(k)]=str(dst)
ov=w/'core.json'; ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'core-g3','./cmd/goivy_check'],cwd=b/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
