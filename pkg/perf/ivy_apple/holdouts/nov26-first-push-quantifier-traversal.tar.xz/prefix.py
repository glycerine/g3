"""Observe ordered input handle identities at the first reduction of each fresh solver."""
from pathlib import Path
import json,subprocess,os,csv
w=Path(__file__).resolve().parent;p=Path.cwd();b=w.parent/'.boolean-enode-cost';f=b/'frontend/goivy';old=w.parent/'.hybrid-obligations'
files=json.loads((old/'observer.json').read_text())['Replace'];k=f/'z3bridge_solver_model.go'
s=Path(files[str(k)]).read_text();a='z3solver.Push()\n\t\t\t\t\tif first';assert s.count(a)==1
s=s.replace(a,'if first {os.Setenv("FIRST_INPUT","1")}\n z3solver.Push()\n if first {os.Unsetenv("FIRST_INPUT")}\n if first')
if '"os"' not in s:s=s.replace('import (','import (\n"os"')
dst=w/'input-front.go';dst.write_text(s);files[str(k)]=str(dst)
k=p/'smtcore/smt_asserted_driver.go';s=k.read_text().replace('import "fmt"','import ("fmt";"os")');a='if err := assertedVerbose(10, "(smt."+pass';assert s.count(a)==1
s=s.replace(a,'''if os.Getenv("FIRST_INPUT")=="1" {
 fmt.Fprint(os.Stderr,"INPUT ",pass.sourceName())
 for _, row:=range k.assertions[k.assertedHead:] {fmt.Fprintf(os.Stderr," %v/%v",row.Formula,row.Proof)}
 fmt.Fprintln(os.Stderr)
 }
 '''+a)
dst=w/'input-driver.go';dst.write_text(s);files[str(k)]=str(dst);ov=w/'input.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',w/'input','./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');gold=w.parent/'.bool-scan/golden/reference/hybrid'
r=subprocess.run([w/'input',ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,check=True)
pending=[];keep=[];seen=set()
with (w/'inputs.csv').open('w') as dest:
 wr=csv.writer(dest);wr.writerow(['batch','pass','ordered_rows'])
 for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'INPUT '):pending.append(l.rstrip().decode().split(' ',2))
    elif l.startswith(b'STAGE-COUNT '):
        _,n,g,ph,*_=l.split()
        if ph==b'first':
            seen.add(n);wr.writerows([int(n),row[1],row[2] if len(row)>2 else ''] for row in pending);pending=[]
        assert not pending
    else:keep.append(l)
assert len(seen)==34 and r.stdout==(gold/'stdout').read_bytes() and b''.join(keep)==(gold/'stderr').read_bytes()
