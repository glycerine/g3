from trial import panel
from guards import patch as guard
from adaptive import run

def patch(pkg,name):
    if name=='base':return
    for p,s in guard(pkg,'false'):
        if p.name.endswith('stat.go'):
            yield p,s
            continue
        a='return q.registry.schedule.instantiateNew(q.promoteUnsatEntry'
        s=p.read_text()
        assert s.count(a)==1
        cond={'first':'fired','last':'!fired','short':'fired && stat.size<=12'}[name]
        part='''entries:=q.registry.schedule.newEntries
        if len(entries)>1{
            var pending []SMTQIQueueEntry
            n:=0
            split:=false
            for i,e:=range entries{
                stat:=q.registry.statistics[e.Fingerprint.data]
                guard:=stat.studyGuard
                fired:=!guard.IsNull() && q.state.context.getAssignment(guard)==lbool.False
                if COND{
                    if !split{continue}
                    if pending==nil{pending=append(pending,entries[n:i]...)}
                    entries[n]=e;n++
                }else if !split{n=i;split=true}else if pending!=nil{pending=append(pending,e)}
            }
            if pending!=nil{copy(entries[n:],pending)}
        }
        '''
        yield p,s.replace(a,part.replace('COND',cond)+a)
if __name__=='__main__':panel(['base','first','last','short'],patch,run)
