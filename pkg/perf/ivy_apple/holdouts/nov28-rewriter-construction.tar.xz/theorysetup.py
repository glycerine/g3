from pathlib import Path
import macroprice,re
from trial import panel
def patch(pkg,name):
    p=pkg/'ast/rewriter/th_rewriter.go';s=p.read_text()
    imports=';'.join('"'+k+'"' for k in ['os','syscall','runtime','unsafe'] if '"'+k+'"' not in s[s.index('import ('):s.index(')',s.index('import ('))])
    s=s.replace('import (','import ('+imports+';',1)
    i=s.index('func (r *TheoryRewriter) constructConfiguration')
    j=s.index('func (r *TheoryRewriter) updateFloatingParams',i)
    t=s[i:j]
    t=t.replace('c := &r.configuration','var start StudySample\n c := &r.configuration')
    t=re.sub(r'(\tif (?:c\.(\w+), |)err = (?:New\w+|r\.updateFloatingParams)\([^\n]+\); err != nil \{\n\t\treturn err\n\t\})',lambda m:'\tstart=StudyStart()\n'+m[1]+'\n println("MACROTIME","'+str(m[2] or 'fpParams')+'",start.finish())',t)
    assert t.count('start.finish()')>=8
    t=t.replace('return r.readLocalParams()', 'start=StudyStart();err=r.readLocalParams();println("MACROTIME","local",start.finish());return err')
    yield p,s[:i]+t+s[j:]+'\n'+macroprice.ns['src']
if __name__=='__main__':panel(['probe'],patch,macroprice.run)
