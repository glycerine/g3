from pathlib import Path
import csv,statistics as st,collections
d=Path(__file__).resolve().parent
for name in ['construct-release','construct']:
    v=collections.defaultdict(dict)
    for row in csv.DictReader((d/name/'runs.csv').open()):
        v[row['config'],row['engine'],row['round']][int(row['n'])]=int(row['instructions'])
    for k in sorted({k[:2] for k in v}):
        pairs=[(n[1005]-n[5])/1000 for key,n in v.items() if key[:2]==k and len(n)==2]
        print(name,k,len(pairs),st.median(pairs))
for p in sorted((d/'polyprice').glob('*')):
    v=[[int(l.split()[2]) for l in (d/f/p.name).read_text().splitlines() if ' bitVector ' in l] for f in ['theorysetup','polyprice']]
    print(p.name,[len(x) for x in v],[round(st.median(x)) for x in v],[round(sum(x)/1e6,2) for x in v])
for name in ['release','polyparams','prioritize','modelclean']:
 for f in sorted((d/name).glob('time-*.csv')):
    rows=list(csv.DictReader(f.open()))
    v={k:[int(r['instructions']) for r in rows if r['engine']==k] for k in set(r['engine'] for r in rows)}
    if 'base' in v:print(name,f.stem,len(rows),{k:round(100*(st.median(x)/st.median(v['base'])-1),2) for k,x in v.items() if k!='base'})
