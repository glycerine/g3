from pathlib import Path
import csv,statistics as st
d=Path(__file__).resolve().parent
for name in ['confirmparams-off','confirmparams-100']:
 for f in sorted((d/name).glob('*.csv')):
    r=list(csv.DictReader(f.open()))
    for metric in ['instructions','wall_ms']:
        pairs={}
        for x in r:pairs.setdefault(x['round'],{})[x['engine']]=float(x[metric])
        both=[(v['base'],v['trial']) for v in pairs.values() if len(v)==2]
        if both:print(name,f.stem,metric,len(both),round(st.median([100*(y/x-1) for x,y in both]),3))
