import polyparams,theorysetup,macroprice
from trial import panel
def patch(pkg,name):
    yield from theorysetup.patch(pkg,name)
    yield from polyparams.patch(pkg,'trial')
panel(['probe'],patch,macroprice.run)
