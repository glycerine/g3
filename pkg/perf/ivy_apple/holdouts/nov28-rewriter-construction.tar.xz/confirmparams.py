from pathlib import Path
import os,subprocess,tarfile
from trial import panel
def patch(pkg,name):
    if name=='base':
        p=pkg/'ast/rewriter/bv_polynomial_config.go'
        yield p,subprocess.check_output(['git','show','bfc6ef339:pkg/ast/rewriter/bv_polynomial_config.go']).decode()
def run(s):return s.replace('range(5):','range(17):').replace('((1,3),(4,8),(6,227))','((8,),(2,),(6,))').replace("GOGC='100'","GOGC='"+os.environ['STUDY_GC']+"'")
panel(['base','trial'],patch,run)
