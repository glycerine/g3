from pathlib import Path
s=Path(__file__).with_name('construct.py').read_text()
i=s.index('    for p,s in polyparams.patch');j=s.index("    j=t/'overlay.json'",i)
s=s[:i]+'''    if mode=='base':
        p=pkg/'ast/rewriter/bv_polynomial_config.go'
        dest=t/p.name
        dest.write_bytes(sp.check_output(['git','show','bfc6ef339:pkg/ast/rewriter/bv_polynomial_config.go']))
        mp[str(p)]=str(dest)
'''+s[j:]
exec(compile(s,'constructor','exec'))
