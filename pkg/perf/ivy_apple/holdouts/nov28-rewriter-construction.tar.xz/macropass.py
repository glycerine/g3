from trial import panel
from bindings import run
def patch(pkg,name):
    if name=='base':return
    p=pkg/'ast/macros/macro_expander.go'
    s=p.read_text()
    a='func (m *Manager) ExpandMacros(term, proof ast.ASTHandle, dependency ast.ASTDependency, out, outProof ast.ASTRef) (resultDependency ast.ASTDependency, result error) {'
    assert s.count(a)==1
    s=s.replace(a,a+'''
        return m.expandWith(nil,term,proof,dependency,out,outProof)
    }
    '''+a.replace('ExpandMacros(term','expandWith(batch **macroTheoryNormalizer, term'))
    a='normalizer, err := newMacroTheoryNormalizer(m.manager, m.paramsContext, m.globals)'
    b='defer func() { result = errors.Join(result, normalizer.close()) }()'
    assert a in s and b in s
    s=s[:s.index(a)]+'''var normalizer *macroTheoryNormalizer
    if batch!=nil{normalizer=*batch}
    if normalizer==nil{
        normalizer,err=newMacroTheoryNormalizer(m.manager,m.paramsContext,m.globals)
        if err!=nil{return resultDependency,err}
    }
    if batch!=nil {
        *batch=normalizer
        defer func(){result=errors.Join(result,normalizer.rewrite.Reset())}()
    } else {'''+b+'}'+s[s.index(b)+len(b):]
    yield p,s
    p=pkg/'ast/macros/macro_finder.go'
    s=p.read_text()
    i=s.index('func (f *Finder) pass(')
    s=s[:i]+s[i:].replace('for _, row := range input.rows {','var normalizer *macroTheoryNormalizer\n defer func(){result=errors.Join(result,normalizer.close())}()\n for _, row := range input.rows {',1).replace('f.macros.ExpandMacros(row.Expression','f.macros.expandWith(&normalizer,row.Expression',1)
    yield p,s
if __name__=='__main__':panel(['base','trial'],patch,run)
