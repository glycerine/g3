from pathlib import Path
import csv,statistics as st
d=Path(__file__).resolve().parent
for f in sorted((d/'macroprice').glob('*')):
    active=False; first=False; calls=repeat=passes=setup=close=saved=0
    for l in f.read_text().splitlines():
        a=l.split()
        if a[0]=='MACROPASS':assert not active;active=True;first=True;passes+=1
        elif a[0]=='MACROEND':active=False
        else:
            x,y=map(int,a[1:]);setup+=x;close+=y;calls+=1
            if active and not first:repeat+=1;saved+=x+y
            first=False
    print(f.name,passes,calls,repeat,round(setup/1e6,2),round(close/1e6,2),round(saved/1e6,2))
for f in sorted((d/'macropass').glob('*.csv')):
    rows=list(csv.DictReader(f.open()))
    if len(rows)<2:continue
    x,y=[[int(r['instructions']) for r in rows if r['engine']==k] for k in ('base','trial')]
    print(f.stem,len(rows),round(100*(st.median(y)/st.median(x)-1),2))
