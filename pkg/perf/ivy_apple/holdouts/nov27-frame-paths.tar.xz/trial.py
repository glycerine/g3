"""Build alternate associative-flatten guard orders and count eligible frames."""
from pathlib import Path
import json, subprocess, sys
p=Path.cwd();w=Path(__file__).resolve().parent
mode=sys.argv[1];src=p/'ast/rewriter/rewriter_engine.go';s=src.read_text()
a=s.index('\t\t// f->is_associative()',s.index('func (r *rewriterEngine) processApp()'))
b=s.index('\t\tsize :=',a)
old=s[a:b]
# Compare immutable parent kind and declaration before reading child reference
# count or associative flags. Root and quantifier parent cannot flatten.
s=s[:a]+'''        if fi > 0 {
            prev := c.frames[fi-1]
            if prev.kind == ast.ASTApp && prev.state()==0 {
                pd, e := m.GetDecl(prev.curr)
                if e!=nil {return e}
                if pd==d {
                    rc,e:=m.GetRefCount(t)
                    if e!=nil {return e}
                    if rc<=1 {
                        assoc,e:=m.RewriterAssociative(d)
                        if e!=nil {return e}
                        if assoc {
                            flat,e:=r.cfg.FlatAssoc(d)
                            if e!=nil {return e}
                            if flat {c.frames=c.frames[:fi];return r.setNewChild(t)}
                        }
                    }
                }
            }
        }
'''+s[b:]
if mode=='counts':
 s=s[:a]+'''        println("FRAME-PARENT",fi>0,fr.numArgs)
'''+s[a:]
 key='if pd==d {'
 s=s.replace(key,'println("FRAME-MATCH",pd==d);'+key,1)
elif mode=='root':
 s=src.read_text()
 k=old.index('\t\trc, e :=')
 s=s[:a]+old[:k]+'\t\tif fi > 0 && c.frames[fi-1].kind == ast.ASTApp && c.frames[fi-1].state()==0 {\n'+old[k:]+ '\n}\n'+s[b:]
elif mode!='parent':raise ValueError(mode)
dest=w/(mode+'.go.txt');dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':{str(src):str(dest)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',ov,'-o',w/mode,'./cmd/g3'],check=True)
