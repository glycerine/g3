"""Use the existing bound-operand assertion path for binary QI disjunctions."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();k=p/'smtcore/smt_qi_instance.go';s=k.read_text()
a='lemma, err = b.manager.MkOr(negatedQuantifier, simplified)';assert s.count(a)==1
s=s.replace(a,a+'''
            if arguments != nil && err == nil {
                *arguments = []ast.ASTHandle{negatedQuantifier,simplified}
            }''')
d=w/'binary.go.txt';d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));o=w/'binary.json';o.write_text(json.dumps({'Replace':{str(k):str(d)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',w/'binary','./cmd/g3'],check=True)
