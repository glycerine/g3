"""Specialize application visits for the concrete, proof-free theory rewriter."""
import json,subprocess,sys
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent;src=p/'ast/rewriter/rewriter_engine.go';s=src.read_text()
k='func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32) (bool, error) {'
a=s.index(k)+len(k)
s=s[:a]+'''
    if cfg,ok:=r.cfg.(*theoryRewriterConfiguration);ok && r.skipResumeCacheProbe {
        return r.visitTheory(cfg,t,depth)
    }
'''+s[a:]
s+='''
func (r *rewriterEngine) visitTheory(cfg *theoryRewriterConfiguration,t ast.ASTHandle,depth uint32)(bool,error){
    c:=&r.core
    if cfg.hasSubstitution {
        v,_,found,err:=cfg.GetSubst(t)
        if err!=nil {return false,err}
        if found {
            if err=appendRewriterRoot(c.manager,&c.results,v);err!=nil{return false,err}
            return true,r.setNewChildIfDifferent(t,v)
        }
    }
    if depth==0 {return true,appendRewriterRoot(c.manager,&c.results,t)}
    kind,rc,n,err:=c.manager.NodeShape(t)
    if err!=nil{return false,err}
    cache:=t!=c.root && (cfg.cacheAll || rc>1) && (kind==ast.ASTQuantifier || kind==ast.ASTApp && n>0)
    if cache {
        v,err:=c.getCached(t)
        if err!=nil{return false,err}
        if !v.IsNull(){
            if err=appendRewriterRoot(c.manager,&c.results,v);err!=nil{return false,err}
            return true,r.setNewChildIfDifferent(t,v)
        }
    }
    switch kind {
    case ast.ASTVar:return true,r.processVar(t)
    case ast.ASTApp:if n==0{return true,r.processConst(t)}
    case ast.ASTQuantifier:
    default:return false,ast.ErrASTDomain
    }
    if depth!=3 {depth--}
    return false,c.pushFrameCore(t,cache,0,depth,kind,n)
}
'''
dest=w/'specialize.go.txt';dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
o=w/'specialize.json';o.write_text(json.dumps({'Replace':{str(src):str(dest)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',w/'specialize','./cmd/g3'],check=True)
