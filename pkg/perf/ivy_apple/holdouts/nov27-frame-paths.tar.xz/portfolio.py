"""Measure the most a bounded history could cover if it knew which path to choose."""
import collections,csv,gzip,itertools,sys
from pathlib import Path
w=Path(__file__).resolve().parent
def load(p):
    for line in gzip.open(p,'rb'):
        s=line.rstrip()
        if s.startswith(b'BEGIN-PATH'):
            row=s.split()
            q=tuple(row[1:3]);root=tuple(row[3:]);seq=[]
        elif s==b'END-PATH':yield q,root,tuple(seq)
        else:seq.append(s)
def count(seq):
    return sum(x.startswith(b'VISIT ') or x in (b'EVENT SUB',b'EVENT DEPTH') for x in seq)
wr=csv.writer(sys.stdout);wr.writerow(('fixture','entries_per_quantifier','instance_count','visits','best_common_prefix_visits','matched_instance_visits','matched_instances'))
for p in sorted(w.glob('*.paths.gz')):
    for size in (1,4,16,64):
        previous=collections.defaultdict(collections.OrderedDict);instances=visits=possible=exact=matches=0
        for q,root,seq in load(p):
            instances+=1;n=count(seq);visits+=n
            history=previous[q];longest=0
            for path,roots in history.items():
                # A path already seen on a different root is available.
                if len(roots)==1 and root in roots:continue
                if path==seq:
                    exact+=n;matches+=1;longest=len(seq);break
                end=next((i for i,(x,y) in enumerate(zip(seq,path)) if x!=y),min(len(seq),len(path)))
                longest=max(longest,end)
            possible+=count(seq[:longest]);roots=history.pop(seq, set())
            if len(roots)<2:roots.add(root)
            history[seq]=roots
            if len(history)>size:history.popitem(last=False)
        wr.writerow((p.name,size,instances,visits,possible,exact,matches))
