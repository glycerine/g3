"""Screen emitted instance clauses for syntactic reuse within each Ticket check."""
import collections,csv,re,sys
from pathlib import Path
w=Path(sys.argv[1]);wr=csv.writer(sys.stdout)
wr.writerow(('engine','batch','goal','formulas','exact_repeats','literal_set_repeats','strict_subsumed','complementary','unit'))
def parse(s):
    stack=[];root=None
    for t in re.findall(r'\(|\)|[^()\s]+',s):
        if t=='(':stack.append([])
        elif t==')':
            v=tuple(stack.pop())
            if stack:stack[-1].append(v)
            else: root=v
        else:stack[-1].append(t)
    assert root and not stack
    return root
def lit(t):return (False,t[1]) if len(t)==2 and t[0]=='not' else (True,t)
for engine in ('g3','ordinary','z3'):
    prior={}
    for r in csv.DictReader((w/(engine+'-search-events.csv')).open()):
        if r['event']!='formula':continue
        k=(r['batch'],r['goal']);s=r['value'];t=parse(s)
        raw,clauses,index,c=prior.setdefault(k,(set(),set(),collections.defaultdict(set),collections.Counter()))
        ls=frozenset(lit(x) for x in (t[1:] if t[0]=='or' else (t,)))
        c['n']+=1;c['exact']+=s in raw;c['set']+=ls in clauses;c['unit']+=len(ls)==1
        c['complementary']+=any((not sign,term) in ls for sign,term in ls)
        c['sub']+=any(v<ls for x in ls for v in index[x])
        if ls not in clauses:
            # Index once on any literal in the clause (ties do not affect membership).
            index[min(ls,key=lambda x:len(index[x]))].add(ls)
        raw.add(s);clauses.add(ls)
    for k,(_,_,_,c) in prior.items():
        wr.writerow((engine,*k,*[c[x] for x in ('n','exact','set','sub','complementary','unit')]))
