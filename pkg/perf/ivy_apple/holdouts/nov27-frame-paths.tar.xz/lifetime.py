"""Observe physical clause-directory membership at repeated instance assertion."""
from pathlib import Path
import json,subprocess,sys
p=Path.cwd();w=Path(__file__).resolve().parent
f,mod,stage,printer=map(lambda x:Path(x).resolve(),sys.argv[1:5])
files=json.loads(stage.read_text())['Replace']
def save(k,s):
    d=w/('life-'+k.name);d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));files[str(k)]=str(d)
k=f/'phase_observer_trial.go';s=Path(files[str(k)]).read_text()
a='start := time.Now()';assert s.count(a)==1
s=s.replace(a,'''window:=batch>=2 && batch<=5 && (goal==55 || goal==56)
    if window {os.Setenv("G3_CLAUSE_WINDOW",fmt.Sprintf("%d/%d",batch,goal))}
    '''+a)
k2='elapsed := time.Since(start)';assert s.count(k2)==1
s=s.replace(k2,k2+'; if window {os.Unsetenv("G3_CLAUSE_WINDOW")}')
save(k,s)
k=p/'smtcore/smt_internalizer_state.go';s=k.read_text().replace('type SMTInternalizerState struct {','''type SMTInternalizerState struct {
    trialKey string
    trialHistory map[string][]trialPriorClause
    trialSerial uint64
    trialLevels []uint64
    trialInstance bool
''')
a='s.scopeLevel++';assert s.count(a)==1
s=s.replace(a,'s.trialSerial++;s.trialLevels=append(s.trialLevels[:s.scopeLevel],s.trialSerial);'+a)
save(k,s)
k=p/'smtcore/smt_internalizer.go';s=k.read_text().replace('"errors"','"errors"\n"os"\n"strings"\n"strconv"')
a='if err = s.addRootClause(literals, proof); err != nil {';assert s.count(a)==1
s=s.replace(a,'''if s.trialInstance {
                err=s.trialRootClause(expression,literals,proof)
            } else {err=s.addRootClause(literals,proof)}
            if err!=nil {''')
a='return s.assertExpression(lemma, proof, instance.Generation(), arguments)'
assert s.count(a)==1
s=s.replace(a,'''window:=os.Getenv("G3_CLAUSE_WINDOW")
    if window!="" {
        if window!=s.trialKey {s.trialKey=window;s.trialHistory=make(map[string][]trialPriorClause)}
        s.trialInstance=true
        defer func(){s.trialInstance=false}()
    }
    '''+a)
tree=printer.read_text();s+='\n'+tree.replace('func witnessTree','func lifeTree')
s+='''
type trialPriorClause struct { handle ast.ASTHandle; depth uint32; stamp uint64; clause *SMTClause }
func(s *SMTInternalizerState) trialRootClause(h ast.ASTHandle,lits []SMTLiteral,proof ast.ASTHandle) error {
    k:=lifeTree(s.manager,h)
    prior:=s.trialHistory[k]
    same,scope,live:=false,false,false
    for _,p:=range prior {
        same= same || p.handle==h
        scope= scope || p.depth==0 || (p.depth<=s.scopeLevel && s.trialLevels[p.depth-1]==p.stamp)
        live= live || p.clause!=nil && !p.clause.closed && !p.clause.Deleted() && slices.Contains(s.auxClauses,p.clause)
    }
    n:=len(s.auxClauses);err:=s.addRootClause(lits,proof);if err!=nil{return err}
    row:=trialPriorClause{handle:h,depth:s.scopeLevel}
    if row.depth!=0 {row.stamp=s.trialLevels[row.depth-1]}
    if len(s.auxClauses)>n {
        if len(s.auxClauses)!=n+1 {panic("unexpected root insertion count")}
        row.clause=s.auxClauses[n]
    }
    s.trialHistory[k]=append(prior,row)
    println("LIFETIME",s.trialKey,len(prior)>0,same,scope,live,row.clause!=nil)
    return nil
}
'''
save(k,s)
o=w/'lifetime.json';o.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-modfile',mod,'-buildvcs=false','-tags=xtrace_off','-overlay',o,'-o',w/'lifetime','./cmd/goivy_check'],cwd=f,check=True)
