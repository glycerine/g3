"""Bypass frame and cache configuration calls for nullary theory applications."""
from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;src=p/'ast/rewriter/rewriter_engine.go';s=src.read_text()
key='\tcache, e := r.mustCacheShape(t, kind, rc, n)'
pos=s.index(key,s.index('func (r *rewriterEngine) visit('))
s=s[:pos]+'''    // Both cache policies exclude constants, and the theory configuration
    // inherits the unconditional default PreVisit.
    if kind == ast.ASTApp && n == 0 {
        if _, theory := r.cfg.(*theoryRewriterConfiguration); theory {
            return true,r.processConst(t)
        }
    }
'''+s[pos:]
dst=w/'leaves.go.txt';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
o=w/'leaves.json';o.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',w/'leaves','./cmd/g3'],check=True)
