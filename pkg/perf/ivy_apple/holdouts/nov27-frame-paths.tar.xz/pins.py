"""Vary the lifetime of canonical lemma ASTs while preserving scheduled clause insertion."""
from pathlib import Path
import subprocess,json
p=Path.cwd();w=Path(__file__).resolve().parent;k=p/'smtcore/smt_quantifier_manager.go';s=k.read_text().replace('"fmt"','"fmt"\n"os"\n"strconv"')
s=s.replace('type SMTQuantifierManager struct {','''type SMTQuantifierManager struct {
    trialPins []ast.ASTRef
    trialPos int
    trialSize int
''')
a='q.lazyMatchingIndex = 0';assert s.count(a)==1
s=s.replace(a,'''if err:=q.trialRelease();err!=nil{return err}
    q.trialSize,_=strconv.Atoi(os.Getenv("G3_TRIAL_PINS"))
    '''+a)
s=s.replace('lemmaErr = q.registry.schedule.RecordInstance(lemma)','''lemmaErr = q.registry.schedule.RecordInstance(lemma)
                if lemmaErr==nil && q.trialSize>0 {lemmaErr=q.trialHold(lemma)}''')
a='if q.flushed {';assert s.count(a)==1
s=s.replace(a,'if err:=q.trialRelease();err!=nil{return err};'+a)
s+='''
func(q *SMTQuantifierManager) trialRelease() error {
    for len(q.trialPins)>0 {
        n:=len(q.trialPins)-1
        if err:=q.state.manager.DelRef(&q.trialPins[n]);err!=nil{return err}
        q.trialPins=q.trialPins[:n]
    }
    q.trialPos=0
    return nil
}
func(q *SMTQuantifierManager) trialHold(h ast.ASTHandle) error {
    if len(q.trialPins)<q.trialSize {
        ref,e:=q.state.manager.NewRef(h);if e!=nil{return e}
        q.trialPins=append(q.trialPins,ref);return nil
    }
    err:=q.state.manager.SetRef(q.trialPins[q.trialPos],h)
    q.trialPos++;if q.trialPos==len(q.trialPins){q.trialPos=0}
    return err
}
'''
d=w/'pins.go.txt';d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()));o=w/'pins.json';o.write_text(json.dumps({'Replace':{str(k):str(d)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',w/'pins','./cmd/g3'],check=True)
