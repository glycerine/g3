"""Observe theory rewriter visits and reducer returns for one quantified instance at a time."""
import json,subprocess
from pathlib import Path
p=Path.cwd();w=Path(__file__).resolve().parent;files={}
def save(k,s):
    d=w/(k.name+'.txt');d.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    files[str(k)]=str(d)
k=p/'ast/rewriter/th_rewriter.go';s=k.read_text().replace('type TheoryRewriter struct {','type TheoryRewriter struct {\n diagnosticInstance bool')
s+='''
func (r *TheoryRewriter) ObserveTrialInstance(active bool) { r.diagnosticInstance=active }
'''
save(k,s)
k=p/'smtcore/smt_qi_instance.go';s=k.read_text()
a='if err = rw.Rewrite(instance, simplified); err != nil {'
assert s.count(a)==1
s=s.replace(a,'''println("BEGIN-PATH",prepared.quantifier.Slot(),prepared.quantifier.Generation(),instance.Slot(),instance.Generation())
        rw.ObserveTrialInstance(true)
        err=rw.Rewrite(instance,simplified)
        rw.ObserveTrialInstance(false)
        println("END-PATH")
        if err!=nil {''')
save(k,s)
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text()
s+='''
func (r *rewriterEngine) measuringInstance() bool {
    cfg,ok:=r.cfg.(*theoryRewriterConfiguration)
    return ok && cfg.owner.diagnosticInstance
}
'''
a=s.index('func (r *rewriterEngine) visit(');b=s.index('func (r *rewriterEngine) processVar(',a);chunk=s[a:b]
for key,event in [('if found {','SUB'),('if depth == 0 {','DEPTH'),('if !h.IsNull() {','HIT'),('if !allowed {','SKIP')]:
 assert chunk.count(key)==1;chunk=chunk.replace(key,key+'\n if r.measuringInstance(){println("EVENT","'+event+'")}')
chunk=chunk.replace('if cache {','if r.measuringInstance(){println("VISIT",uint32(kind),n,depth,cache)}\n if cache {')
s=s[:a]+chunk+s[b:]
a=s.index('func (r *rewriterEngine) processApp()');b=s.index('func (r *rewriterEngine) processAppMacroEnd',a);chunk=s[a:b]
key='st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)';assert chunk.count(key)==1
chunk=chunk.replace(key,key+'\n if r.measuringInstance(){println("REDUCE",d.Slot(),d.Generation(),args.Count(),fr.newChild(),fr.cacheResult(),uint32(st))}')
s=s[:a]+chunk+s[b:];save(k,s)
ov=w/'paths.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',ov,'-o',w/'paths','./cmd/g3'],check=True)
