"""Compare a parent-first flatten guard on ordinary rewriter frames."""
from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;k=p/'ast/rewriter/rewriter_engine.go'
s=k.read_text();a=s.index('\t\t// f->is_associative()');b=s.index('\t\tsize :=',a)
s=s[:a]+'''        if fi > 0 {
            flat, e := r.flattenIntoParent(&c.frames[fi-1], t, d)
            if e != nil { return e }
            if flat {
                c.frames = c.frames[:fi]
                return r.setNewChild(t)
            }
        }
'''+s[b:]
i=s.index('func (r *rewriterEngine) processApp()')
s=s[:i]+'''// Flattening can join two frames only when both applications use the
// same declaration. Most child frames have a different operator.
func (r *rewriterEngine) flattenIntoParent(parent *rewriterFrame, child, decl ast.ASTHandle) (bool, error) {
    if parent.kind != ast.ASTApp || parent.state() != 0 {return false,nil}
    m:=r.core.manager
    pd, err:=m.GetDecl(parent.curr)
    if err!=nil || pd!=decl {return false,err}
    rc, err:=m.GetRefCount(child)
    if err!=nil || rc>1 {return false,err}
    assoc,err:=m.RewriterAssociative(decl)
    if err!=nil || !assoc {return false,err}
    return r.cfg.FlatAssoc(decl)
}

'''+s[i:]
dest=w/'flat.go.txt';dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
o=w/'flat.json';o.write_text(json.dumps({'Replace':{str(k):str(dest)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',w/'flat','./cmd/g3'],check=True)
