"""Rebuild the ordinary Ticket frontend and keep rewrite events for eight concrete checks."""
import argparse,collections,csv,gzip,json,os,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for a in ['frontend','mod','stage','reference','examples']:p.add_argument(a,type=Path)
p.add_argument('--build',action='store_true')
a=p.parse_args();w=Path(__file__).resolve().parent
if a.build:
 files=json.loads(a.stage.read_text())['Replace']
 files.update(json.loads((w/'paths.json').read_text())['Replace'])
 o=w/'scoped.json';o.write_text(json.dumps({'Replace':files}))
 subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',a.mod.resolve(),'-tags=xtrace_off','-overlay',o,'-o',w/'scoped','./cmd/goivy_check'],cwd=a.frontend,check=True)
name='ticket_protocol'
ref=a.reference/'reference'/name
rel,_,code=json.loads((a.reference/'cases.json').read_text())[name]
r=subprocess.run(['taskset','-c','16',w/'scoped',a.examples/rel],cwd=w,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(a.examples/'ivy/include')),capture_output=True)
keep=[];pending=[];seen=set()
for line in r.stderr.splitlines(keepends=True):
 if line.startswith((b'BEGIN-PATH ',b'END-PATH',b'REDUCE ',b'VISIT ',b'EVENT ')):pending.append(line)
 elif line.startswith(b'STAGE-COUNT '):
    _,b,g,phase,*_=line.split();key=int(b),int(g)
    if phase==b'check' and key[0] in (2,3,4,5) and key[1] in (55,56):
        assert key not in seen and pending
        seen.add(key)
        with gzip.open(w/('scope-%d-%d.paths.gz'%key),'wb') as f:f.writelines(pending)
    pending.clear()
 else:keep.append(line)
assert len(seen)==8 and (r.returncode,r.stdout,b''.join(keep))==(code,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
