from pathlib import Path
import collections,csv,json,os,subprocess,sys
w=Path(__file__).resolve().parent;gold=Path(sys.argv[1]);ex=Path(sys.argv[2]);ref=gold/'reference/ticket_protocol'
rel,_,rc=json.loads((gold/'cases.json').read_text())['ticket_protocol']
r=subprocess.run(['taskset','-c','16',w/'lifetime',ex/rel],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True)
out=[];pending=[];wr=csv.writer(sys.stdout);wr.writerow(('batch','goal','repeat','same_handle','ancestor_scope','live_clause','stored'))
for l in r.stderr.splitlines(keepends=True):
 if l.startswith(b'LIFETIME '):
    _,key,*v=l.decode().split()
    pending.append((key,v))
 elif l.startswith(b'STAGE-COUNT '):
    _,b,g,phase,*_=l.decode().split()
    for key,v in pending:
        assert key==b+'/'+g and phase=='check' and len(v)==5 and set(v)<={'false','true'}
        wr.writerow((b,g,*[int(x=='true') for x in v]))
    pending.clear()
 else:out.append(l)
assert not pending and (r.returncode,r.stdout,b''.join(out))==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
