"""Evaluate reusing the previous traversal on a different instance, in arrival order."""
from pathlib import Path
from collections import OrderedDict
import csv,gzip,itertools,sys
w=Path(__file__).resolve().parent
def visits(seq):
    return sum(s.startswith(b'VISIT ') or s in (b'EVENT SUB',b'EVENT DEPTH') for s in seq)
def paths(p):
    q=root=None
    for line in gzip.open(p,'rb'):
        s=line.rstrip()
        if s.startswith(b'BEGIN-PATH'):
            a=s.split()
            q=tuple(a[1:3]);root=tuple(a[3:]);seq=[]
        elif s==b'END-PATH':yield q,root,tuple(seq)
        else: seq.append(s)
wr=csv.writer(sys.stdout);wr.writerow(('fixture','prefix_events','capacity','visits','attempts_distinct_root','complete_paths','predicted_visits_after_prefix','wholly_matched_suffix_visits'))
for p in sorted(w.glob('*.paths.gz')):
    data=list(paths(p))
    for n in (0,2,4,8):
        for cap in (8,32,128):
            tab=OrderedDict();total=attempts=matched=predicted=suffix=0
            for q,root,seq in data:
                total+=visits(seq)
                if len(seq)<=n:continue
                k=q,seq[:n]
                last=tab.pop(k,None)
                if last and last[0]!=root:
                    attempts+=1
                    a,b=seq[n:],last[1]
                    common=tuple(x for x,y in itertools.takewhile(lambda t:t[0]==t[1],zip(a,b)))
                    predicted+=visits(common)
                    if a==b:
                        suffix+=visits(a);matched+=1
                tab[k]=(root,seq[n:])
                if len(tab)>cap:tab.popitem(last=False)
            wr.writerow((p.name,n,cap,total,attempts,matched,predicted,suffix))
