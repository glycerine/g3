"""Count repeated theory rewrite paths on different ground instances of the same quantifier."""
import collections,csv,gzip,os,re,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
fields=('decisions','conflicts','quant-instantiations','rlimit-count')
wr=csv.writer(sys.stdout);wr.writerow(('fixture','instances','nonempty','visits','reductions','repeated_instance_path','repeated_visits','previous_path','previous_visits','distinct_ground_root_repeats','distinct_root_repeated_visits','same_parent_decl','candidate_parents','all_frames'))
for query in sorted(Path(sys.argv[1]).glob('*.smt2')):
    def run(name):return subprocess.run([name,'-in','-smt2'],input=query.read_bytes(),capture_output=True,check=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'))
    base=run(sys.argv[2]); refs=dict(re.findall(rb':([\w-]+)\s+(\d+)',base.stdout))
    assert not base.stderr and base.stdout.startswith(b'unsat\n')
    for name in ('paths','counts'):
        r=run(w/name);results=dict(re.findall(rb':([\w-]+)\s+(\d+)',r.stdout))
        assert r.stdout.startswith(b'unsat\n') and [results.get(k.encode()) for k in fields]==[refs.get(k.encode()) for k in fields]
        if name=='counts':
            hist=collections.Counter(line.split()[:2][0]+b' '+line.split()[1] for line in r.stderr.splitlines())
            assert all(k.startswith((b'FRAME-MATCH ',b'FRAME-PARENT ')) for k in hist)
            same=hist[b'FRAME-MATCH true'];parents=same+hist[b'FRAME-MATCH false']; frames=hist[b'FRAME-PARENT true']+hist[b'FRAME-PARENT false']
            continue
        with gzip.open(w/(query.stem+'.paths.gz'),'wb') as f:f.write(r.stderr)
        seen={};last={};sq=None;v=collections.Counter()
        for line in r.stderr.splitlines():
            x=line.split()
            if x[0]==b'BEGIN-PATH':
                assert sq is None
                sq=tuple(x[1:3]); root=tuple(x[3:5]); seq=[];visits=0
            elif x[0]==b'END-PATH':
                assert sq is not None
                key=tuple(seq);v['instances']+=1;v['nonempty']+=bool(seq);v['visits']+=visits
                if visits:
                    pair=(sq,key)
                    if pair in seen:
                        v['repeated']+=1;v['repeated_visits']+=visits
                        if seen[pair]!=root:
                            v['distinct']+=1;v['distinct_visits']+=visits
                    if last.get(sq)==key:v['previous']+=1;v['previous_visits']+=visits
                    seen.setdefault(pair,root)
                last[sq]=key;sq=None
            else:
                assert sq is not None and x[0] in (b'VISIT',b'EVENT',b'REDUCE')
                visits+=x[0]==b'VISIT' or line in (b'EVENT SUB',b'EVENT DEPTH')
                v['reductions']+=x[0]==b'REDUCE';seq.append(line)
        assert sq is None
    wr.writerow((query.stem,*[v[k] for k in ('instances','nonempty','visits','reductions','repeated','repeated_visits','previous','previous_visits','distinct','distinct_visits')],same,parents,frames))
