"""Record proof outcomes, search counters and cost even when term lifetime changes search."""
from pathlib import Path
import csv,os,re,subprocess,sys
w=Path(__file__).resolve().parent
fixtures,perf,base=map(Path,sys.argv[1:4]);labels=('stock','0','8','64','512')
wr=csv.writer(sys.stdout);keys=('decisions','conflicts','quant-instantiations','rlimit-count')
wr.writerow(('query','round','pins','verdict','instructions','cycles',*keys))
for q in sorted(fixtures.glob('*.smt2')):
    for i in range(5):
        for n in labels[i:]+labels[:i]:
            dest=w/'pin-perf.csv';env=dict(os.environ,GOGC='off',GOMAXPROCS='1',G3_TRIAL_PINS=n)
            r=subprocess.run(['taskset','-c','18',perf,'stat','-x,','-e','instructions:u,cycles:u','-o',dest,'--',base if n=='stock' else w/'pins','-smt2','-in'],env=env,input=q.read_bytes(),capture_output=True,timeout=30)
            assert r.returncode==0 and not r.stderr and r.stdout.startswith(b'unsat\n') and b'(error' not in r.stdout,(q,n,r.stdout[:120],r.stderr)
            stats=dict(re.findall(rb':([\w-]+)\s+(\d+)',r.stdout))
            hw={x[2]:int(x[0]) for x in csv.reader(dest.read_text().splitlines()) if len(x)>4 and x[2].endswith(':u') and float(x[4])==100}
            wr.writerow((q.stem,i,n,'unsat',hw['instructions:u'],hw['cycles:u'],*[int(stats.get(k.encode(),b'0')) for k in keys]))
            sys.stdout.flush()
