"""Rotate fixed-iteration frame benchmarks on one pinned core."""
from pathlib import Path
import csv,os,subprocess,sys,re
w=Path(__file__).resolve().parent;wr=csv.writer(sys.stdout)
wr.writerow(('round','engine','case','iterations','ns_per_op','bytes_per_op','allocs_per_op'))
labels=sys.argv[1:]
for i in range(7):
    for e in labels[i%len(labels):]+labels[:i%len(labels)]:
        r=subprocess.run(['taskset','-c','16',w/(e+'.test'),'-test.run=^$','-test.bench=^BenchmarkTheoryUnaryFrames$','-test.benchtime=5000x','-test.cpu=1'],env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,check=True,text=True)
        rows=re.findall(r'BenchmarkTheoryUnaryFrames/(\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout)
        assert len(rows)==2,r.stdout
        for row in rows:wr.writerow((i,e,*row))
        sys.stdout.flush()
