"""Gather allocation stacks for one push of each standalone replay."""
from pathlib import Path
import json,os,re,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;src=p/'cmd/g3/main.go'
s=src.read_text().replace('package main','package main\nimport "runtime/pprof"',1)
if '"runtime"' not in s:s=s.replace('package main','package main\nimport "runtime"',1)
k='func main() {';assert s.count(k)==1
s=s.replace(k,k+'\nruntime.MemProfileRate=1')
k='stopProfile()\n';assert s.count(k)==1
s=s.replace(k,k+'''runtime.GC()
    runtime.GC()
    f,e:=os.Create(os.Getenv("BOUNDARY_ALLOCATIONS"))
    if e!=nil{panic(e)}
    if e=pprof.Lookup("allocs").WriteTo(f,0);e!=nil{panic(e)}
    if e=f.Close();e!=nil{panic(e)}
''')
dst=w/'main.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
f=w/'heap.json';f.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
exe=w/'heap-g3'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',f,'-o',exe,'./cmd/g3'],check=True)
for q,expected in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
    prof=w/(q+'.pb.gz')
    r=subprocess.run([exe,'-in','-smt2'],input=(w/'fixtures'/(q+'.smt2')).read_bytes(),env=dict(os.environ,GOMAXPROCS='1',BOUNDARY_ALLOCATIONS=str(prof)),capture_output=True,timeout=90,check=True)
    st=dict(re.findall(rb':([\w-]+)\s+(\d+)\b',r.stdout))
    assert r.stdout.startswith(b'unsat\n') and not r.stderr and tuple(int(st[k]) for k in [b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count'])==expected
    for sample in ['alloc_objects','alloc_space']:
        for phase,pattern in [('push','cmd_context.*Context.*\\.Push$'),('check','cmd_context.*CheckSatDisplay'),('setup','cmd_context.*DeclareSortConstructor')]:
            a=subprocess.check_output(['go','tool','pprof','-top','-nodecount=18','-unit='+('bytes' if sample=='alloc_space' else 'count'),'-sample_index='+sample,'-focus='+pattern,exe,prof],stderr=subprocess.STDOUT)
            (w/(q+'-'+phase+'-'+sample+'.txt')).write_bytes(a)
