# Ticket command costs

Use pkg at 1a65666db on Linux amd64 with permission to count retired user instructions. Build the ordinary Go CLI with go build -pgo=off -o /tmp/ticket-g3 ./cmd/g3 and build the native CLI from the same repository. From pkg, with W pointing to this extracted directory, run

    python3 "$W/measure.py" --cpu 10 --gc 400 --fixtures "$W/fixtures" g3=/tmp/ticket-g3 z3=../build/z3 > /tmp/cli.csv
    python3 "$W/summarize.py" /tmp/cli.csv

Each trial builder (batch.py, bv.py, annotations.py) creates a Go overlay and builds an executable in its own directory. Repeat the command with the trial executable as the second engine. cli.csv uses GOGC=400, current.csv and bv.csv use 100, annotations.csv and batch.csv use 400. heap.py records cumulative allocation profiles with full-rate sampling and writes text summaries for three caller subtrees. Run it separately from the instruction measurements. stacks.py and setup.py take a directory of perf data from the earlier Ticket quantifier study and a perf executable. Inclusive sample counts overlap. The instruction table in PERF_STUDY.md uses current release binaries, independently of those earlier stack samples.
