"""Group out-of-check samples under first-sort manager initialization by plugin."""
from collections import Counter
from pathlib import Path
import re,sys,subprocess,csv
p=Path(sys.argv[1]);perf=sys.argv[2];out=csv.writer(sys.stdout);out.writerow(('query','round','engine','component','samples'))
for f in sorted(p.glob('ticket-*-g3.data')):
    q,round_,engine=f.stem.rsplit('-',2);c=Counter()
    for s in subprocess.check_output([perf,'script','-i',f],text=True).split('\n\n'):
        if '(*Context).DeclareSortConstructor' not in s:continue
        if x:=re.search(r'\(\*ASTManager\)\.(Register\w+Plugin)\+',s):k=x[1]
        else:k='other'
        c[k]+=1
    for k,n in sorted(c.items()):out.writerow([q,round_,engine,k,n])
