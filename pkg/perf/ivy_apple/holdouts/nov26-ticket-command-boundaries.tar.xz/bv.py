"""Measure the startup cost of numeral acquisition for small BV sort sizes."""
from pathlib import Path
import subprocess,json,sys
pkg=Path.cwd();w=Path(__file__).resolve().parent
src=pkg/'ast/ast_bv_plugin.go';s=src.read_text()
i=s.index('power, e := m.numerals.PowerOfTwo(bits)');j=s.index('p.powerActive = false',i)+len('p.powerActive = false')
s=s[:i]+'size = FiniteSortSize(uint64(1) << bits)'+s[j:]
dst=w/'bv.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
f=w/'bv.json';f.write_text(json.dumps({'Replace':{str(src):str(dst),str(Path.home()/'g3/pkg/ast'/src.name):str(dst)}}))
ivy='--ivy' in sys.argv
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',f,'-o',w/('bv-goivy' if ivy else 'bv-g3'),*(['-tags=xtrace_off','./cmd/goivy_check'] if ivy else ['./cmd/g3'])],cwd=Path.home()/'ivy/goivy' if ivy else pkg,check=True)
