"""Measure Linux user instructions between SMT-LIB commands in a live solver."""
import argparse, csv, ctypes, os, re, signal, struct, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--fixtures',required=True,type=Path);p.add_argument('--rounds',type=int,default=9)
p.add_argument('--gc',default='100');p.add_argument('--cpu',type=int,required=True);p.add_argument('engines',nargs='+')
a=p.parse_args()
lib=ctypes.CDLL(None,use_errno=True)
def counter(pid):
    # perf_event_attr v0, PERF_COUNT_HW_INSTRUCTIONS, inherit, exclude kernel/hv, enable on exec.
    attr=struct.pack('IIQQQQQQQ',0,64,1,0,0,3,(1<<0)|(1<<1)|(1<<5)|(1<<6)|(1<<12),0,0)
    fd=lib.syscall(298,ctypes.c_char_p(attr),pid,-1,-1,0)
    if fd<0: raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
    return fd
def count(fd):
    v,enabled,running=struct.unpack('QQQ',os.read(fd,24))
    if enabled!=running:raise RuntimeError(('multiplexed',enabled,running))
    return v
def segments(s):
    parts=re.split(rb'(?m)^(?=\(assert |\(push 1\)|\(check-sat\)|\(get-info )',s)
    assert len(parts)==6
    first=parts[0].splitlines(keepends=True)
    assert first[0].startswith(b'(set-option ') and first[1].startswith(b'(declare-sort ')
    return [('option',first[0]),('first-sort',first[1]),('declarations',b''.join(first[2:]))]+list(zip(['assert1','push','assert2','check','stats'],parts[1:]))
def one(binary,s):
    cmd=[sys.executable,'-c','import os,signal,sys;os.kill(os.getpid(),signal.SIGSTOP);os.execv(sys.argv[1],sys.argv[1:])',str(binary),'-in','-smt2']
    child=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,GOMAXPROCS='1',GOGC=a.gc,XTRACE_OFF='1'))
    fd=None
    try:
        _,status=os.waitpid(child.pid,os.WUNTRACED);assert os.WIFSTOPPED(status)
        os.sched_setaffinity(child.pid,{a.cpu})
        fd=counter(child.pid);os.kill(child.pid,signal.SIGCONT)
        marks=[];last=0;stats=b''
        for label,part in [('startup',b''),('empty',b''),*segments(s)]:
            child.stdin.write(part+b'\n(echo "boundary")\n');child.stdin.flush()
            body=[]
            while True:
                line=child.stdout.readline()
                if line==b'boundary\n':break
                if not line:raise RuntimeError((label,body,child.stderr.read()))
                body.append(line)
            if label=='check':assert body==[b'unsat\n'],body
            elif label=='stats':stats=b''.join(body)
            else:assert not body,body
            n=count(fd);marks.append((label,n-last));last=n
        stdout,stderr=child.communicate(timeout=15)
        assert child.returncode==0 and not stdout and not stderr,(stdout,stderr)
        marks.append(('exit',count(fd)-last))
        all_stats=dict(re.findall(rb':([\w-]+)\s+(\d+)\b',stats))
        return marks,tuple(all_stats.get(k,b'0') for k in [b'decisions',b'conflicts',b'quant-instantiations',b'rlimit-count'])
    finally:
        if child.poll() is None:child.kill();child.wait()
        if fd is not None:os.close(fd)
out=csv.writer(sys.stdout);out.writerow(('query','round','engine','phase','instructions'))
engines=[(name,Path(path).resolve()) for name,path in [arg.split('=',1) for arg in a.engines]]
for q,reference in [('ticket-127',(708,50,1389,62021)),('ticket-290',(310,37,1241,62398))]:
    s=(a.fixtures/(q+'.smt2')).read_bytes()
    for i in range(a.rounds):
        for name,exe in engines[i%len(engines):]+engines[:i%len(engines)]:
            marks,stats=one(exe,s);assert tuple(map(int,stats))==reference,(q,name,stats)
            for phase,n in marks:out.writerow((q,i+1,name,phase,n))
            sys.stdout.flush()
