"""Trial a borrowed annotation view for quantifiers with at most one annotation of each kind."""
from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;src=p/'ast/rewriter/th_rewriter.go';s=src.read_text()
k='if updated.IsNull() {\n\t\tuniquePatterns'
assert s.count(k)==1
s=s.replace(k,'''if updated.IsNull() && patterns.Count()<=1 && noPatterns.Count()<=1 {
        updated,err=m.UpdateQuantifierArguments(old,body,patterns,noPatterns)
    } else if updated.IsNull() {
        uniquePatterns''')
dst=w/'th_rewriter.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
f=w/'annotations.json';f.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',f,'-o',w/'annotations-g3','./cmd/g3'],check=True)
