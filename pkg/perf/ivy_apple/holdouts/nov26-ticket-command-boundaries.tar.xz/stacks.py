"""Inclusive call sites within first push, and manager startup within declaration."""
from pathlib import Path
from collections import Counter
import re,sys,subprocess,csv
p=Path(sys.argv[1]);perf=sys.argv[2];out=csv.writer(sys.stdout)
out.writerow(('query','engine','phase','symbol','samples'))
for q in ['ticket-127','ticket-290']:
 for e in ['g3','z3']:
  c=Counter()
  for f in p.glob(q+'-*-'+e+'.data'):
   for s in subprocess.check_output([perf,'script','-i',f],text=True).split('\n\n'):
    frames=re.findall(r'\s+[a-fA-F0-9]+ (.*?)\+0x',s)
    for label,needle in [('push','cmd_context.(*Context).Push' if e=='g3' else 'cmd_context::push('),('declare','cmd_context.(*Context).DeclareSortConstructor' if e=='g3' else 'cmd_context::insert(')]:
     for i,fr in enumerate(frames):
      if needle in fr:
       c[label,'(all)']+=1
       for k in set(frames[:i]):c[label,k.split('/pkg/')[-1]]+=1
       break
  for (label,k),n in c.most_common():out.writerow((q,e,label,k,n))
