"""Trial reserving formula rows once per pending assertion pass."""
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
work = Path(__file__).resolve().parent
overlays = {}

def save(src, code):
    dst = work / src.name
    dst.write_text(code)
    overlays[str(src)] = str(dst)

src = pkg / 'ast/macros/macro_finder.go'
code = src.read_text()
key = 'func (b *FormulaBatch) open()'
assert code.count(key) == 1
code = code.replace(key, '''func NewSizedFormulaBatch(m *ast.ASTManager, count int) (*FormulaBatch, error) {
    b, err := NewFormulaBatch(m)
    if err == nil && count > 0 {
        b.rows = make([]Formula, 0, count)
    }
    return b, err
}

''' + key)
code = code.replace('output, err := NewFormulaBatch(f.manager)', 'output, err := NewSizedFormulaBatch(f.manager, input.Len())')
code = code.replace('current, err := NewFormulaBatch(f.manager)', 'current, err := NewSizedFormulaBatch(f.manager, len(inputs))')
save(src, code)
for src in sorted((pkg / 'smtcore').glob('smt_asserted_*.go')):
    if src.name.endswith('_test.go'):
        continue
    code = src.read_text()
    key = 'macros.NewFormulaBatch(k.manager)'
    if key in code:
        save(src, code.replace(key, 'macros.NewSizedFormulaBatch(k.manager, len(k.assertions)-k.assertedHead)'))
overlay = work / 'batch.json'
overlay.write_text(json.dumps({'Replace': overlays}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',overlay,'-o',work/'batch-g3','./cmd/g3'], check=True)
