"""Report median phase counts and paired deltas in millions of instructions."""
import csv, statistics as st, sys
for f in sys.argv[1:]:
    rows=list(csv.DictReader(open(f)))
    for q in dict.fromkeys(x['query'] for x in rows):
        r=[x for x in rows if x['query']==q]
        engines=list(dict.fromkeys(x['engine'] for x in r))
        for phase in list(dict.fromkeys(x['phase'] for x in r))+['total']:
            vs=[]
            for e in engines:
                values={}
                for x in r:
                    if x['engine']==e and (phase=='total' or x['phase']==phase):
                        values[x['round']]=values.get(x['round'],0)+int(x['instructions'])/1e6
                vs.append(values)
            x,y=vs
            print(f,q,phase,*[round(st.median(a.values()),3) for a in vs],round(st.median(y[k]-x[k] for k in x),3))
