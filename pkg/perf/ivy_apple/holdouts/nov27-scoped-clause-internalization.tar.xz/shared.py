"""Compare fresh, scoped and shared-prefix replays of the 28 ordered Flash obligations."""
import argparse,collections,csv,os,statistics,subprocess,tempfile,time
from pathlib import Path
from bases import parse,expand,conjuncts

def smt(term):return term if isinstance(term,str) else '('+' '.join(map(smt,term))+')'

def inputs(captures):
    prelude={};signatures={};bases=[];goals=[]
    for src in sorted(captures.glob('batch-*.smt2')):
        cmds=parse(src.read_text())
        for cmd in cmds:
            if cmd[0].startswith('declare'):
                if cmd[0]=='declare-fun':
                    assert signatures.setdefault(cmd[1],cmd)==cmd
                prelude[cmd]=True
        base,goal=[expand(cmd[1],{}) for cmd in cmds if cmd[0]=='assert']
        bases.append(set(map(smt,conjuncts(base))));goals.append(smt(goal))
    declarations='\n'.join(map(smt,sorted(prelude,key=lambda c:(c[0]=='declare-fun',smt(c)))))+'\n'
    freq=collections.Counter(c for base in bases for c in base)
    bases=[sorted(b,key=lambda c:(-freq[c],c)) for b in bases]
    return declarations,bases,goals

def script(declarations,bases,goals,mode):
    lines=[];counts=collections.Counter()
    def emit(row):lines.append(row)
    def push():emit('(push 1)');counts['pushes']+=1
    def pop():emit('(pop 1)')
    def premises(rows):
        if rows:
            emit('(assert (and '+' '.join(rows)+'))')
            counts['premises']+=len(rows)
    def query(i):
        push();emit('(assert '+goals[i]+')');emit('(check-sat)');pop()
    def group(start,end,depth):
        # Consecutive bases with the same next conjunct can share their
        # longest common prefix. Keep the observed batch order.
        i=start
        while i<end:
            j=i+1
            while j<end and depth<len(bases[i]) and depth<len(bases[j]) and bases[j][depth]==bases[i][depth]:j+=1
            stop=depth
            while all(stop<len(bases[n]) and bases[n][stop]==bases[i][stop] for n in range(i,j)):stop+=1
            push();premises(bases[i][depth:stop])
            if j==i+1:query(i)
            else:group(i,j,stop)
            pop();i=j
    if mode.startswith('tree'):
        ordered=[[] for _ in bases]
        def visit(start,end,inherited):
            shared=set.intersection(*(set(b) for b in bases[start:end]))
            prefix=[x for x in bases[start] if x in shared and x not in inherited]
            for i in range(start,end):ordered[i].extend(prefix)
            if prefix and mode=='tree':push();premises(prefix)
            if end==start+1:
                if mode=='tree':query(start)
            else:
                mid=(end+start)//2
                visit(start,mid,shared);visit(mid,end,shared)
            if prefix and mode=='tree':pop()
        emit(declarations);visit(0,len(bases),set())
        if mode=='tree-flat':
            return script(declarations,ordered,goals,'scoped')
    elif mode=='shared':
        emit(declarations);group(0,len(bases),0)
    else:
        if mode=='scoped':emit(declarations)
        for i,b in enumerate(bases):
            if mode=='fresh':
                if i:emit('(reset)')
                emit(declarations)
            else:push()
            premises(b);query(i)
            if mode=='scoped':pop()
    return '\n'.join(lines)+'\n',counts

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for key in ('captures','g3','z3','perf','output'):ap.add_argument('--'+key,type=Path,required=True)
    ap.add_argument('--cpu',required=True);ap.add_argument('--rounds',type=int,default=5)
    a=ap.parse_args();args=inputs(a.captures);expected=b'unsat\n'*len(args[1])
    with tempfile.TemporaryDirectory() as t,a.output.open('x',newline='') as out:
        w=Path(t);writer=csv.writer(out);writer.writerow('round engine mode premises pushes instructions cycles milliseconds'.split());jobs=[]
        for mode in ('fresh','scoped','shared','tree-flat','tree'):
            text,counts=script(*args,mode);file=w/(mode+'.smt2');file.write_text(text)
            jobs+=[(e,exe,file,counts) for e,exe in [('g3',a.g3),('z3',a.z3)]]
        for i in range(a.rounds):
            for e,exe,file,counts in jobs[i%len(jobs):]+jobs[:i%len(jobs)]:
                cmd=['taskset','-c',a.cpu,a.perf,'stat','-x,','-o',w/'counts','-e','instructions:u,cycles:u','--',exe.resolve(),file]
                start=time.monotonic();r=subprocess.run(cmd,env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,timeout=120)
                ms=(time.monotonic()-start)*1000
                assert (r.returncode,r.stdout,r.stderr)==(0,expected,b''),(e,file,r.stdout[:150],r.stderr[:150])
                hardware={r[2]:int(r[0]) for r in csv.reader((w/'counts').read_text().splitlines()) if len(r)>4 and float(r[4])==100}
                writer.writerow((i,e,file.stem,counts['premises'],counts['pushes'],hardware['instructions:u'],hardware['cycles:u'],ms));out.flush()
if __name__=='__main__':main()
