"""Compile an internal reduction at combined Assert or inside SMT kernel preprocessing."""
import json,sys,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(sys.argv[1]).resolve();mod=Path(sys.argv[2]).resolve();mode=sys.argv[3];out=sys.argv[4] if len(sys.argv)>4 else mode
combined=mode in ('combined','guarded','indexed')
folder='solver' if combined else 'smtcore'
u=(w/'parts-universal.go').read_text().replace('package order','package '+folder,1)
u+='''
func trialNarrow(m *ast.ASTManager,base []ast.ASTHandle,h ast.ASTHandle)(ast.ASTHandle,error){
 var u UniversalPremises
 keep,n,e:=u.TrialConjuncts(m,append(base,h));if e!=nil||n==len(keep){return ast.ASTHandle{},e}
 body,e:=m.MkAndArray(keep);if e!=nil{return ast.ASTHandle{},e}
 return m.MkNotSimplified(body)
}
'''
src=p/folder/('combined_solver.go' if combined else 'smt_kernel.go');s=src.read_text()
if combined:
 at=s.index('if err := c.first.Assert(h);')
 s=s[:at]+'''second:=h
 if c.secondStarted && c.HasOriginalAssertions(){
  m:=c.manager
  hd,e:=m.NodeHeader(h);if e!=nil{return e}
  if hd.Kind==ast.ASTApp && hd.Family==m.BasicFamilyID() && hd.NumArgs==1{
    base,e:=Assertions(c.first);if e!=nil{return e}
    r,e:=trialNarrow(m,base,h);if e!=nil{return e}
    if !r.IsNull(){if e=m.IncRef(r);e!=nil{return e};defer m.DecRef(r);second=r}
  }
 }
 '''+s[at:]
 s=s.replace('c.mutationResult(c.second.Assert(h))','c.mutationResult(c.second.Assert(second))')
else:
 at=s.index('k.assertedHasQuantifiers = k.assertedHasQuantifiers || hasQuantifiers') if mode=='after' else s.index('hasQuantifiers, err := k.manager.HasQuantifiers(formula)',s.index('func (k *SMTKernel) assertFormulaCore'))
 s=s[:at]+'''if k.assertedHead>0 && proof.IsNull() {
  m:=k.manager;hd,e:=m.NodeHeader(formula);if e!=nil{return e}
  if hd.Kind==ast.ASTApp && hd.Family==m.BasicFamilyID() && hd.NumArgs==1{
   base:=make([]ast.ASTHandle,0,k.assertedHead+1)
   for _,a:=range k.assertions[:k.assertedHead]{base=append(base,a.Formula)}
   r,e:=trialNarrow(m,base,formula);if e!=nil{return e}
   if !r.IsNull(){if e=m.IncRef(r);e!=nil{return e};defer m.DecRef(r);formula=r}
  }
 }
 '''+s[at:]
if mode=='guarded':
 s=s.replace('if c.secondStarted && c.HasOriginalAssertions(){','if t,ok:=c.first.(*TacticSolver);c.secondStarted && ok && !t.produceProofs && !t.produceCores && c.HasOriginalAssertions(){')
ov={}
for file,content in [(src,s),(p/folder/'universal_trial.go',u)]:
 dest=w/(out+'-'+file.name);dest.write_text(content);ov[str(file)]=str(dest)
o=w/(out+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/out,'./cmd/goivy_check'],cwd=front,check=True)
