"""Try universal entailment at the point a scoped, preprocessed row enters the SMT kernel."""
from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(sys.argv[1]).resolve();mod=Path(sys.argv[2]).resolve();mode=sys.argv[3]
src=p/'smtcore/smt_kernel.go';s=src.read_text();needle='if err := k.internalizer.Assert(assertion.Formula, assertion.Proof, 0); err != nil {'
u=(w/'parts-universal.go').read_text().replace('package order','package smtcore',1)
s=s.replace(needle,'if err := k.trialInternalize(assertion, head); err != nil {')
s+='''
func(k *SMTKernel) trialInternalize(a SMTKernelAssertion,head int)error{
 m:=k.manager;h:=a.Formula
 if k.assertedHead>0 && len(k.scopes)>0 && a.Proof.IsNull(){
  hd,e:=m.NodeHeader(h);if e!=nil{return e}
  if hd.Kind==ast.ASTApp && hd.Family==m.BasicFamilyID() && (hd.NumArgs==1 || hd.DeclKind==ast.ASTOpOr && hd.NumArgs>=4 && hd.NumArgs<=128){
   base:=make([]ast.ASTHandle,0,k.assertedHead+1)
   for _,x:=range k.assertions[:k.assertedHead]{base=append(base,x.Formula)}
   var u UniversalPremises; inputs:=append(base,h)
   var keep []ast.ASTHandle;wide:=int(hd.NumArgs)
   if hd.NumArgs==1{
    keep,wide,e=u.TrialConjuncts(m,inputs)
    if e==nil && len(keep)<wide {h,e=m.MkAndArray(keep);if e==nil{h,e=m.MkNotSimplified(h)}}
   }else{
    ground,e:=m.IsGround(h);if e!=nil{return e}
    if ground{
     if _,e=u.Refutes(m,inputs,150000,true);e!=nil{return e}
     if u.manager==m{work:=100000;for i:=uint32(0);i<hd.NumArgs;i++{c,e:=m.GetArg(h,i);if e!=nil{return e};if !u.entails(c,false,0,&work){keep=append(keep,c)}}
      if len(keep)<wide{h,e=m.MkOrArray(keep);if e!=nil{return e}}
     }
    }
   }
   if e!=nil{return e}
   if h!=a.Formula{if e=m.IncRef(h);e!=nil{return e};defer m.DecRef(h)}
  }
 }
 return k.internalizer.Assert(h,a.Proof,0)
}
'''
if mode=='observe':
 s=s.replace('if h!=a.Formula{','if h!=a.Formula{println("REMOVED",int(hd.NumArgs),wide,len(keep));')
ov={}
for name,code in [(src,s),(p/'smtcore/universal_trial.go',u)]:
 dst=w/(mode+'-'+name.name);dst.write_text(code);ov[str(name)]=str(dst)
o=w/(mode+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
