from pathlib import Path
import sys,subprocess
w=Path(__file__).resolve().parent
cases=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines()
jobs=[subprocess.Popen([sys.executable,str(w/'run.py'),'scope-broad-'+str(i),str(2*i+4),'2','bounded,scope',*cases[i::4]]) for i in range(4)]
sys.exit(max(x.wait() for x in jobs))
