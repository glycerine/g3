"""Sample retired instructions inside exact first-push intervals on the calling OS thread."""
import collections,csv,os,re,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;ex=Path(sys.argv[1]);ref=Path(sys.argv[2]);perf=Path(sys.argv[3]);cpu=sys.argv[4];rounds=int(sys.argv[5])
env=dict(os.environ,DEBUGINFOD_URLS='',GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
with (w/'push-samples.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow('engine round batch period count stack'.split())
 for i in range(rounds):
  engines=[('g3','fp,56'),('native','dwarf,8192')]
  for eng,stack in engines[::1 if i%2==0 else -1]:
   data=w/'push.data';period=2500009+2*i
   r=subprocess.run(['taskset','-c',cpu,perf,'record','--clockid','mono','-B','-N','-e','instructions:u','-c',str(period),'--call-graph',stack,'-o',data,'--',w/(eng+'-windows'),ex/'examples/ivy/flash2.ivy'],env=env,cwd=w,capture_output=True,timeout=90)
   windows=[];rest=bytearray()
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'FLASH-PUSH '):windows.append(tuple(map(int,line.split()[1:])))
    elif not line.startswith(b'[ perf record:'):rest.extend(line)
   assert r.returncode==1 and len(windows)==28 and rest==(ref/'stderr').read_bytes() and r.stdout==(ref/'stdout').read_bytes(),(eng,len(windows),rest[:300])
   stats=subprocess.check_output([perf,'report','--stdio','--stats','-i',data],text=True)
   assert not re.search(r'(LOST|THROTTLE) events:',stats),stats
   def stamp(ns):return '%d.%09d'%divmod(ns,10**9)
   when=' '.join(stamp(l)+','+stamp(h) for _,l,h in windows)
   out=subprocess.check_output([perf,'script','--ns','--time',when,'-F','tid,time,event,ip,sym','-i',data],text=True,env=env)
   hits=collections.Counter()
   for sample in out.strip().split('\n\n'):
    lines=sample.splitlines()
    if not lines:continue
    m=re.match(r'^\s*(\d+)\s+(\d+)\.(\d{9}):',lines[0]);assert m,lines[:1]
    tid,t,n=map(int,m.groups());now=t*10**9+n
    for batch,(thread,l,h) in enumerate(windows,1):
     if thread==tid and l<=now<=h:
      syms=tuple(re.sub(r'^\s*[0-9a-f]+\s+','',x).strip() for x in lines[1:] if x.strip())
      assert syms
      hits[batch,'\n'.join(syms)]+=1;break
   for (b,st),n in hits.items():writer.writerow((eng,i,b,period,n,st))
   f.flush()
   print(eng,i,sum(hits.values()),flush=True)
   data.unlink()
