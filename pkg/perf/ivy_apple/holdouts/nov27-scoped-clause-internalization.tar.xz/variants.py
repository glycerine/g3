"""Build a trial that proves only the missing conjuncts, privately or at the first concrete push."""
import json,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(sys.argv[1]).resolve();mod=Path(sys.argv[2]).resolve();mode=sys.argv[3]
src=p/'api/internal/order/universal_premises.go';ov={str(src):str(w/(mode+'-universal.go'))}
u=(w/'parts-universal.go').read_text()
if mode.startswith('all'):
 u=u.replace('hd.NumArgs<4','hd.NumArgs<'+('2' if mode=='all2' else '4'))
(w/(mode+'-universal.go')).write_text(u)
a=p/'api/api_order_abstraction.go';s=a.read_text()
s+='''
func trialResidual(m *ast.ASTManager, u *order.UniversalPremises, assertions []ast.ASTHandle)(ast.ASTHandle,error){
 keep,total,e:=u.TrialConjuncts(m,assertions);if e!=nil||total==0||len(keep)==total{return ast.ASTHandle{},e}
 body,e:=m.MkAndArray(keep);if e!=nil{return ast.ASTHandle{},e}
 return m.MkNotSimplified(body)
}
'''
if mode in ('residual','private'):
 key='proved, err = p.proveAssertions(parent, assertions, maxSteps, reuse)'
 alt='''if !goal.IsNull() && p.previousGoalProved{
  residual,e:=trialResidual(parent,&p.universalPremises,assertions);if e!=nil{return false,e}
  if !residual.IsNull(){
   if e=parent.IncRef(residual);e!=nil{return false,e}
   defer func(){err=errors.Join(err,parent.DecRef(residual))}()
   assertions=append([]ast.ASTHandle(nil),assertions...);assertions[len(assertions)-1]=residual
  }
 }
 '''
 if mode=='private':
  alt=alt.replace('assertions[len(assertions)-1]=residual','assertions[len(assertions)-1]=residual;return p.proveRelevantPremises(parent,assertions)')
 s=s.replace(key,alt+key)
else:
 s+='''
func(s *APISimpleSolver) TrialReduceGoal(h ast.ASTHandle)(ast.ASTRef,error){
 m,e:=s.solver.Manager();if e!=nil{return ast.ASTRef{},e}
 comb,ok:=s.solver.(*solver.CombinedSolver);if !ok||!comb.CanDeferFirstPush(){return m.NewRef(h)}
 inputs,e:=solver.Assertions(s.solver);if e!=nil{return ast.ASTRef{},e}
 var u order.UniversalPremises
 r,e:=trialResidual(m,&u,append(inputs,h));if e!=nil{return ast.ASTRef{},e}
 if r.IsNull(){r=h};return m.NewRef(r)
}
'''
 if mode.startswith('all'):
  s=s.replace('!comb.CanDeferFirstPush()','!comb.HasOriginalAssertions()')
 if mode in ('all4','all2','first'):
  s=s.replace('inputs,e:=solver.Assertions(s.solver);',"""head,e:=m.NodeHeader(h);if e!=nil{return ast.ASTRef{},e}
 if head.Kind!=ast.ASTApp || head.Family!=m.BasicFamilyID() || head.NumArgs!=1{return m.NewRef(h)}
 inputs,e:=solver.Assertions(s.solver);""")
 k=front/'smt/g3_solver.go';ss=k.read_text();key='func (s *Z3Solver) SimplifyVerificationCondition(e Z3Expr) Z3Expr {'
 ss=ss.replace(key,key+'\n e=s.ctx.refExpr(s.c.TrialReduceGoal(e.c))')
 dst=w/(mode+'-bridge.go');dst.write_text(ss);ov[str(k)]=str(dst)
dst=w/(mode+'-solver.go');dst.write_text(s);ov[str(a)]=str(dst);o=w/(mode+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
