"""Print per-case median paired changes for CSV files produced by the verifier drivers."""
import csv,statistics as s,sys,collections as c
d=c.defaultdict(lambda:c.defaultdict(dict))
for name in sys.argv[1:]:
    for row in csv.DictReader(open(name)):
        d[row['case']][row['engine']][row['round']]=row
for case,eng in d.items():
    a,b=eng.values()
    rounds=a.keys() & b.keys()
    if not rounds: continue
    print(case,len(rounds),*[round(s.median(100*(float(b[i][k])/float(a[i][k])-1) for i in rounds),2)
                             for k in ('instructions','cycles','milliseconds')],
          *[round(s.median(float(x[i]['instructions']) for i in rounds)/1e9,4) for x in (a,b)])
