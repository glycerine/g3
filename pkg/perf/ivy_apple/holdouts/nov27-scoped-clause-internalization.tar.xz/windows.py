"""Build the Flash verifier with windows only around the first physical push."""
import sys,json,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();prior=Path('/tmp/g3-ivy-pgo')
front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);e=sys.argv[3]
src=front/'z3bridge_solver_model.go';s=src.read_text()
at=s.index('finalCheck := check');offset=s.rindex('for _, fc := range finalCond {',0,at)
s=s[:offset]+'firstPush := true\n\t\t'+s[offset:]
at=s.index('z3solver.Push()',s.index('finalCheck := check'))
s=s[:at]+s[at:].replace('z3solver.Push()','''if firstPush { 
 start:=flashStart(); z3solver.Push(); flashStop(start); firstPush=false
 }else{z3solver.Push()}''',1)
stub='''package goivy
import("os";"fmt";"syscall";"unsafe";"runtime")
func flashNow()int64{var t syscall.Timespec;_,_,e:=syscall.RawSyscall(syscall.SYS_CLOCK_GETTIME,1,uintptr(unsafe.Pointer(&t)),0);if e!=0{panic(e)};return t.Nano()}
func flashStart()int64{runtime.LockOSThread();return flashNow()}
func flashStop(start int64){stop:=flashNow();tid:=syscall.Gettid();runtime.UnlockOSThread();fmt.Fprintln(os.Stderr,"FLASH-PUSH",tid,start,stop)}
'''
ov={}
for f,content in [(src,s),(front/'flash_push_intervals.go',stub)]:
 o=w/(e+'-'+f.name);o.write_text(content);ov[str(f)]=str(o)
o=w/(e+'-windows.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-pgo='+('off' if e=='native' else str(prior/'blend.pprof')),'-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if e=='native' else ''),'-overlay',o,'-o',w/(e+'-windows'),'./cmd/goivy_check'],cwd=front,check=True)
