"""Compare physical stages of the release verification strategy on Flash."""
from pathlib import Path
import csv,subprocess,json,sys,os
w=Path(__file__).resolve().parent;front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3])
eng=sys.argv[3];ex=Path(sys.argv[4]);cpu=sys.argv[5]
ov=w/('stage-'+eng+'.json');ov.write_text(json.dumps({'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'bridge.go.txt'),str(front/'phase_observer_trial.go'):str(w/'stage.go.txt')}}))
exe=w/('probe-'+eng)
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-pgo='+('off' if eng=='native' else str(w/'blend.pprof')),'-modfile',mod,'-tags','xtrace_off'+(',classic_z3' if eng=='native' else ''),'-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
codes={r['spec']:int(r['exit']) for path in (w/'survey').glob('cpu-*.csv') for r in csv.DictReader(path.open()) if r['engine']=='native'}
with (w/('stages-'+eng+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round batch goal stage instructions'.split())
 for name in ['examples/ivy/flash2.ivy','test/flash2.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy']:
  index=(w/'prior-gaps.txt').read_text().splitlines().index(name)+1;ref=w/'survey'/str(index)/'1'/'native'
  for i in range(3):
   r=subprocess.run(['taskset','-c',cpu,exe,ex/name],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=120)
   err=bytearray()
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'STAGE-COUNT '):
     _,b,g,stage,num,empty,en,active,ns=line.decode().split();assert en==active
     out.writerow((name,i,b,g,stage,num))
    else:err.extend(line)
   assert (r.returncode,r.stdout,err)==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,eng,r.returncode,err[:120]);f.flush()
