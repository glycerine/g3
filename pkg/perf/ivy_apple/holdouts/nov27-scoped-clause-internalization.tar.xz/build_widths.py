from pathlib import Path
import json,sys,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;front=Path(sys.argv[1]).resolve();mod=Path(sys.argv[2]).resolve();mode=sys.argv[3];name=sys.argv[4] if len(sys.argv)>4 else mode
src=p/'smtcore/smt_scoped_clause.go';s=src.read_text()
# Accept the final named width or the literal in the intermediate source.
width=mode[3:] if mode.startswith('min') else '4'
s=s.replace('const minScopedClauseWidth = 16','const minScopedClauseWidth = '+width)
s=s.replace('hd.NumArgs < 4','hd.NumArgs < '+width)
if mode=='census':
 s=s.replace('if len(index.rules) == 0 {','println("WIDTH",hd.NumArgs,k.assertedHead);if len(index.rules) == 0 {').replace('return remaining, len(remaining)', 'if len(remaining)<int(hd.NumArgs){println("KEPT",hd.NumArgs,len(remaining))};return remaining, len(remaining)')
dst=w/(name+'-width.go');dst.write_text(s);o=w/(name+'.json');o.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/name,'./cmd/goivy_check'],cwd=front,check=True)
