from pathlib import Path
import subprocess,os,csv,collections
w=Path(__file__).resolve().parent;p=Path('/tmp/g3-ivy-pgo');ex=Path('/home/jaten/ivy/ivy-lang-examples')
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
codes={r['spec']:int(r['exit']) for f in (p/'survey').glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
with (w/'census.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case width trials committed_rows matches removed'.split())
 for idx,name in enumerate((p/'prior-gaps.txt').read_text().splitlines(),1):
  r=subprocess.run(['taskset','-c','20',p/'scoped-clause-census',ex/name],cwd=w,env=env,capture_output=True,timeout=120)
  ref=p/'survey'/str(idx)/'1'/'native';err=bytearray();data=collections.defaultdict(lambda:[0,0,0,0])
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith((b'WIDTH ',b'KEPT ')):
    kind,a,b=line.split();width,value=int(a),int(b)
    if kind==b'WIDTH':data[width][0]+=1;data[width][1]+=value
    else:data[width][2]+=1;data[width][3]+=width-value
   else:err.extend(line)
  assert (r.returncode,r.stdout,err)==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),name
  for width,stats in sorted(data.items()):out.writerow([name,width,*stats])
  f.flush()
