"""Estimate instructions under selected first-push frames from matched stack samples."""
import csv,collections,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
prefix={'g3':('scope','(*SMTKernel).'),'native':('native','asserted_formulas::')}
keys={
    'all preprocessing':('(*SMTKernel).reduceAssertedPending','asserted_formulas::reduce()'),
    'value propagation':('(*SMTKernel).propagatePendingAssertions','asserted_formulas::propagate_values'),
    'pattern inference':('(*SMTKernel).inferPendingPatterns','asserted_formulas::pattern_inference_fn::simplify'),
    'macro discovery':('(*SMTKernel).findPendingMacros','asserted_formulas::find_macros_core'),
    'NNF':('(*SMTKernel).normalizePendingAssertions','asserted_formulas::nnf_cnf'),
    'internalizing assertions':('(*SMTKernel).internalizePendingRow','smt::context::internalize_assertion('),
    'installing base in incremental backend':('(*CombinedSolver).initSecond','combined_solver::init_solver2_assertions'),
}
rows=list(csv.DictReader((w/'push-samples.csv').open()))
for engine,(name,_) in prefix.items():
    per_round=collections.Counter()
    for r in csv.DictReader((w/('stages-'+name+'.csv')).open()):
        if r['case']=='examples/ivy/flash2.ivy' and r['stage']=='first':per_round[r['round']]+=int(r['instructions'])
    total=statistics.median(per_round.values())
    samples=[r for r in rows if r['engine']==engine]
    weight=sum(int(r['count'])*int(r['period']) for r in samples)
    for label,symbols in keys.items():
        n=sum(int(r['count'])*int(r['period']) for r in samples if symbols[engine=='native'] in r['stack'])
        print(engine,label,round(total*n/weight/1e6,1),'M')
