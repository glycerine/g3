"""Count structural conjuncts in the captured Flash SMT-LIB queries after expanding lets."""
from pathlib import Path
import csv,re,sys

def parse(text):
    stack = [[]]
    for tok in re.findall(r';[^\n]*|\|[^|]*\||\(|\)|[^\s()]+', text):
        if tok.startswith(';'):
            continue
        if tok == '(':
            stack.append([])
        elif tok == ')':
            expr = tuple(stack.pop())
            stack[-1].append(expr)
        else:
            stack[-1].append(tok)
    assert len(stack) == 1
    return stack[0]

def expand(term, env):
    if isinstance(term,str):
        return env.get(term,term)
    if term[0] == 'let':
        more = {k:expand(v,env) for k,v in term[1]}
        return expand(term[2],env | more)
    return tuple(expand(c,env) for c in term)

def conjuncts(term):
    if isinstance(term,tuple) and term[0] == 'and':
        for child in term[1:]:
            yield from conjuncts(child)
    else:
        yield term

if __name__=='__main__':
    w=Path(__file__).parent
    bases=[]
    goals=set()
    for path in sorted(w.glob('batch-*.smt2')):
        base,goal=[expand(cmd[1],{}) for cmd in parse(path.read_text()) if cmd[0]=='assert']
        bases.append(set(conjuncts(base)))
        goals.add(goal)
    print('distinct goals',len(goals),'distinct premise sets',len(set(map(frozenset,bases))))
    shared=set.intersection(*bases)
    print('common to all',len(shared),'premise range',min(map(len,bases)),max(map(len,bases)))
    for i,base in enumerate(bases,1):
        print(i,len(base),sum(isinstance(x,tuple) and x[0]=='forall' for x in base))
