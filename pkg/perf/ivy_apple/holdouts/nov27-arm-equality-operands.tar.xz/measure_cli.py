"""Alternate pinned CLI builds on the two SMT-LIB obligations."""
import argparse
from pathlib import Path
import csv, os, subprocess, sys, tempfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('fixtures',type=Path)
p.add_argument('base',type=Path)
p.add_argument('candidate',type=Path)
p.add_argument('--cpu',required=True)
p.add_argument('--perf',default='perf')
a=p.parse_args()
out=csv.writer(sys.stdout)
out.writerow(['fixture','round','mode','instructions'])
with tempfile.TemporaryDirectory() as tmp:
 stat=Path(tmp)/'stat.csv'
 for f in sorted(a.fixtures.glob('arm_rules3-6-[56].smt2')):
  for i in range(9):
   for mode,exe in [('base',a.base),('candidate',a.candidate)][::1 if i%2==0 else -1]:
    result=subprocess.run(['taskset','-c',a.cpu,a.perf,'stat','-o',stat,'-x,','-e','instructions:u','--',exe,'-in','-smt2'],input=f.read_bytes(),capture_output=True,check=True,timeout=60,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
    assert result.stdout.startswith(b'unsat\n'),result.stdout
    with stat.open() as h:count=next(r[0] for r in csv.reader(h) if len(r)>4 and r[2]=='instructions:u' and float(r[4])==100)
    out.writerow([f.stem,i,mode,count])
