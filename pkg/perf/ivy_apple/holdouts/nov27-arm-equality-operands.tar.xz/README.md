# ARM equality operand study

Production source at e4c16049c. Extract outside the checkout. Run commands with pkg as the working directory. The observers use the repository's configured ../build for the C++ link. Observed binaries are for counting only.

    python3 "$study/bindings/build.py" g3
    python3 "$study/bindings/build.py" z3
    python3 "$study/replay.py" "$study/bindings/g3" "$study/bindings/z3"

The ordered records in bindings/operands.csv include both engines. census.py in that directory gives the observer protocol and original local layout. The fixtures directory supplies both complete inputs. replay.csv gives expected search counters. paths.csv and theory.csv are inclusive call-stack counts from the earlier 6/6 sampling pair.

experiment.py and iff/experiment.py contain the precise source substitutions and original local release runner invocation. release-original.py records the original build flags and reference checks. To build the prototype elsewhere, create a Go overlay with a Replace mapping from the absolute production file to its archived replacement, then pass -overlay to go build for the solver or GoIvy frontend. For the first prototype map smtcore/smt_internalizer.go to existing.go.txt. For the second map ast/rewriter/rewriter_configuration.go to iff/rewrite.go.txt. Build the baseline with identical flags, GoIvy source, module replaces and PGO profile.

    python3 "$study/measure_cli.py" --cpu 12 "$study/fixtures" "$baseline_cli" "$iff_cli"
    python3 "$study/paired.py" --cpu 14 --include "$ivy/ivy/include" "$baseline" "$prototype" "$native" "$ivy/test/arm_rules3.ivy" "$ivy/examples/liveness/hybrid_reliable_broadcast_cisa.ivy" "$ivy/examples/ivy/card3.ivy"

Use --perf to select the installed Linux perf executable. The portable paired driver refreshes the native reference locally. The original rotated runs used saved references from the same frontend. Whole verifier runs use normal GC with GOMAXPROCS=1. CLI pairs disable GC. Each whole.csv contains a separate set of controls. Compare within panels.
