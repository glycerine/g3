"""Compare answers and search counters for the archived SMT-LIB goals."""
import argparse
import csv
import os
from pathlib import Path
import re
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("engines", nargs="+", type=Path)
parser.add_argument("--fixtures", type=Path, default=Path(__file__).resolve().parent / "fixtures")
args = parser.parse_args()
out = csv.writer(sys.stdout)
keys = ["decisions", "conflicts", "quant-instantiations", "rlimit-count"]
out.writerow(["fixture", "engine", "answer", *keys])
for fixture in sorted(args.fixtures.glob("arm_rules3-6-[56].smt2")):
    for engine in args.engines:
        result = subprocess.run([engine.resolve(), "-in", "-smt2"], input=fixture.read_bytes(),
                                capture_output=True, check=True, timeout=60,
                                env=dict(os.environ, GOMAXPROCS="1", GOGC="off"))
        lines = result.stdout.decode()
        if lines.splitlines()[0] != "unsat":
            raise ValueError((fixture, engine, lines[:200]))
        values = dict(re.findall(r":([\w-]+)\s+(\d+)\b", lines))
        out.writerow([fixture.stem, engine, "unsat", *(values[key] for key in keys)])
