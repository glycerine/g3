from pathlib import Path
import json,subprocess,sys,re,shlex
w=Path(__file__).resolve().parent;p=Path.cwd();b=p.parent/'build'
def change(f,k,z):
 s=f.read_text();assert s.count(k)==1,(f,k);dst=w/(f.name+('.txt' if f.suffix=='.go' else ''));dst.write_text(s.replace(k,z));return dst
if sys.argv[1]=='g3':
 a=p/'smtcore/smt_qi_instance.go';k='if err = internalizer.internalizeInstance(result, locals.arguments);';v=change(a,k,'println("AE begin"); defer println("AE end"); '+k)
 f=p/'smtcore/smt_internalizer.go';k='if err = s.Internalize(argument, isGate);'
 z=change(f,k,'''if basic && op==ast.ASTOpEq { ah,bo,e:=s.manager.ExpressionHeader(argument);if e!=nil{panic(e)};present:=s.context.enodes.get(argument)!=nil;family:=int32(ah.Family); if ah.Family==ast.NullFamilyID{family= -1};_,bound:=s.boolVar.lookup(argument); println("AE arg",index,present,bo,family,ah.NumArgs,bound) };'''+k)
 o=w/'go.json';o.write_text(json.dumps({'Replace':{str(a):str(v),str(f):str(z)}}));subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',o,'-o',w/'g3','./cmd/g3'],check=True)
else:
 src=p.parent/'src/smt';k='m_context.internalize_instance(lemma, pr1, gen);';a=change(src/'qi_queue.cpp',k,'std::cerr<<"AE begin\\n";'+k+'std::cerr<<"AE end\\n";')
 k='internalize(arg, _is_gate);';f=change(src/'smt_internalizer.cpp',k,'''if (m_manager.is_eq(n)){std::cerr<<"AE arg "<<i<<" "<<(e_internalized(arg)?"true":"false")<<" "<<(m_manager.is_bool(arg)?"true":"false")<<" "<<(is_app(arg)?(int)to_app(arg)->get_family_id():-1)<<" "<<(is_app(arg)?to_app(arg)->get_num_args():0)<<" "<<(m_manager.is_bool(arg)&&b_internalized(arg)?"true":"false")<<"\\n";}'''+k)
 mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l);objs=[]
 for q in [a,f]:
  o=w/(q.stem+'.o');subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',o,q],cwd=b,check=True);objs.append(o)
 link=re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$',mk,re.M)[1];libs=shlex.split(link.split('$(LINK_FLAGS)',1)[1].split('$(LINK_EXTRA_FLAGS)',1)[0].replace('$(OBJ_EXT)','.o').replace('$(LIB_EXT)','.a'))
 subprocess.run([conf['LINK'],'-o',w/'z3',*objs,*libs,*shlex.split(conf['LINK_EXTRA_FLAGS'])],cwd=b,check=True)
