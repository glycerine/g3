from pathlib import Path
import subprocess,collections,csv,re,os
w=Path(__file__).resolve().parent;h=Path('/tmp/g3-frame-child')
gold={r['fixture']:r for r in csv.DictReader((h/'held-replay.csv').open()) if r['engine']=='z3'}
with (w/'operands.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['fixture','engine','instance','operand','present','boolean','family','arity','bound'])
 for n in ['arm_rules3-6-5','arm_rules3-6-6']:
  prior=None
  for eng in ['g3','z3']:
   r=subprocess.run([w/eng,'-in','-smt2'],input=(h/'held-fixtures'/(n+'.smt2')).read_bytes(),capture_output=True,check=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off'));v=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()))
   assert r.stdout.startswith(b'unsat\n') and all(int(v[k])==int(gold[n][k]) for k in ['decisions','conflicts','quant-instantiations','rlimit-count'])
   rows=[];active=False;i=0
   for line in r.stderr.decode().splitlines():
    if line=='AE begin':assert not active;active=True;i+=1
    elif line=='AE end':assert active;active=False
    elif line.startswith('AE arg '):
     if active:rows.append([i,*line.split()[2:]])
    else:raise ValueError(line)
   assert not active
   for row in rows:out.writerow([n,eng,*row])
   print(n,eng,i,len(rows),collections.Counter((z[2],z[4]) for z in rows).most_common(10),'matches prior',rows==prior)
   if prior is not None:print('first mismatch',next(((a,b) for a,b in zip(rows,prior) if a!=b),None))
   prior=rows
