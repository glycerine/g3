from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go';s=f.read_text();k='if err = s.Internalize(argument, isGate);';assert s.count(k)==1
s=s.replace(k,'''if basic && op == ast.ASTOpEq {
 node := s.context.enodes.get(argument)
 if node != nil && node.root != nil && !node.boolean && s.theories[node.family] == nil {continue}
 };'''+k);dst=w/'existing.go.txt';dst.write_text(s);ov=w/'existing.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0]
orig=orig.replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','release'])
