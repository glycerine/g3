"""Measure two verifier builds against a native verifier on the same Ivy input."""
import argparse
import csv
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--cpu", type=int, required=True)
p.add_argument("--perf", default="perf")
p.add_argument("--rounds", type=int, default=9)
p.add_argument("--include", required=True)
p.add_argument("base", type=Path)
p.add_argument("candidate", type=Path)
p.add_argument("native", type=Path)
p.add_argument("cases", nargs="+", type=Path)
a = p.parse_args()
env = dict(os.environ, GOMAXPROCS="1", XTRACE_OFF="1", GOIVY_INCLUDE=a.include)
out = csv.writer(sys.stdout)
out.writerow(["case", "round", "mode", "status", "instructions", "ms"])
with tempfile.TemporaryDirectory() as tmp:
    stat = Path(tmp) / "perf.csv"
    for case in a.cases:
        case = case.resolve()
        ref = subprocess.run([a.native.resolve(), case], cwd=tmp, capture_output=True, env=env, timeout=120)
        variants = [("base", a.base.resolve()), ("release", a.candidate.resolve())]
        for i in range(a.rounds):
            for mode, exe in variants[::1 if i % 2 == 0 else -1]:
                start = time.monotonic()
                proc = subprocess.run(["taskset", "-c", str(a.cpu), a.perf, "stat", "-x,", "-o", stat,
                                       "-e", "instructions:u", "--", exe, case],
                                      cwd=tmp, capture_output=True, env=env, timeout=120)
                ms = (time.monotonic()-start)*1000
                if (proc.returncode, proc.stdout, proc.stderr) != (ref.returncode, ref.stdout, ref.stderr):
                    raise ValueError((case, mode, proc.returncode, proc.stdout, proc.stderr))
                with stat.open() as f:
                    count = next(row[0] for row in csv.reader(f)
                                 if len(row)>4 and row[2]=="instructions:u" and float(row[4])==100)
                out.writerow([case, i, mode, "match", count, round(ms, 3)])
                sys.stdout.flush()
