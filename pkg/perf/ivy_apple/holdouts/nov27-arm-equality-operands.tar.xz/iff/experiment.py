from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd()
f=p/'ast/rewriter/rewriter_configuration.go';s=f.read_text();k='return rw.mkEqCore(scalar[0], scalar[1], out)';assert s.count(k)==1
s=s.replace(k,'''status, err := rw.mkEqCore(scalar[0], scalar[1], out)
        if status == brFailed && err == nil && op == ast.ASTOpEq {
            boolean, err := rw.isBool(scalar[0])
            if err != nil {return brFailed, err}
            if boolean {
                gate, err := rw.manager.MkIff(scalar[0],scalar[1])
                if err != nil {return brFailed,err}
                return brDone,rw.manager.SetRef(out,gate)
            }
        }
        return status,err''')
dst=w/'rewrite.go.txt';dst.write_text(s);ov=w/'rewrite.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-overlay',ov,'-o',w/'g3','./cmd/g3'],check=True)
orig=Path('/tmp/g3-card-install/release.py').read_text().split('cpus=[',1)[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("h/'wide'","Path('/tmp/g3-card-install/volume-release')")
exec(compile(orig,__file__,'exec'))
run(14,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','release'])
