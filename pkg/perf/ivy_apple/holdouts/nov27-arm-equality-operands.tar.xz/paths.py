from pathlib import Path
import csv,collections,subprocess
w=Path(__file__).resolve().parent
with (w/'paths.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['engine','frame','child','samples'])
 for eng,suffix in [('g3','.old'),('z3','')]:
  s=subprocess.check_output(['/usr/lib/linux-tools/6.17.0-35-generic/perf','script','--no-inline','-F','tid,event,ip,sym','-i','/tmp/g3-card-install/arm.data'+suffix],text=True);t=collections.Counter()
  for block in s.strip().split('\n\n'):
   if ('MaterializeAndInternalize' if eng=='g3' else 'qi_queue::instantiate(smt::qi_queue::entry&)') not in block:continue
   if ('assertExpression' if eng=='g3' else 'smt::context::internalize_assertion(') not in block:continue
   stack=[l.strip().partition(' ')[2].split('+0x')[0] for l in block.splitlines()[1:]]
   for m in ['internalizeFormulaCoreOp','internalizeFormula','attachBooleanEnode','mkEnode','InternalizeTerm','internalizeTerm','internalize_eq','internalize_formula_core','mk_enode']:
    for i in reversed(range(len(stack))):
     fn=stack[i]
     if fn.endswith('.'+m) or '::'+m+'(' in fn:
      t[m,stack[max(0,i-1)]]+=1;break
  for (k,n),v in t.most_common():out.writerow([eng,k,n,v])
