from pathlib import Path
import os,csv,gzip,json,subprocess as sp,tempfile
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();rank=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).resolve();case=(rank/'compat.txt').read_text().splitlines()[7];ref=rank/'compat/8/1/native'
ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as temp:
 d=Path(temp)
 def put(path,s):f=d/path.name;f.write_text(s);rep[str(path)]=str(f)
 path=front/'z3bridge_solver_model.go';s=Path(rep[str(path)]).read_text().replace('stopCheck:=startStage(batch,index+1);','forceBegin(batch,index+1);stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");forceEnd()');put(path,s)
 path=front/'phase_observer_trial.go';s=Path(rep[str(path)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";')
 put(path,s+'''\nfunc forceBegin(batch,goal int){smtcore.StudySeen=0;smtcore.StudyGoal=0
 if batch!=12{return};smtcore.StudyGoal=goal
 mode:=os.Getenv("FORCE");if goal==8 && (mode=="force"||mode=="restoreAll"||mode=="restore16"){smtcore.StudyN,smtcore.StudyVar=10,31}
}
func forceEnd(){smtcore.StudyGoal=0;if smtcore.StudyN!=0{panic("missed decision")};smtcore.StudyN=0}\n''')
 path=p/'smtcore/smt_activity_heap_queue.go';s=path.read_text();k='return q.state.popBasicActivityHeap()';assert s.count(k)==1
 s=s.replace(k,'''if StudyN!=0 && StudySeen+1==StudyN{v:=StudyVar;StudyN=0;val,e:=q.state.Assignment(NewSMTLiteral(v,false));if e!=nil||val!=lbool.Undef||!h.Contains(v){println("FORCED unavailable",v);'''+k+'''};println("FORCED",v,witnessTree(q.state.manager,q.state.boolExpr[v]));return v,lbool.Undef,h.Erase(v)}
 '''+k)+'\nvar StudySeen,StudyN,StudyVar int32\n';put(path,s)
 path=p/'smtcore/smt_search.go';s=path.read_text();k='k.internalizer.traceDecide(variable, phase == lbool.True)';s=s.replace(k,'if StudyN!=0{StudySeen++};'+k);src=(w/'tree.go.txt').read_text();s=s.replace('import (','import ("os";"strings";"strconv";')+src[src.index('func trialTree('):src.index('var trialOwner')];put(path,s)
 path=p/'util/random/generator.go';put(path,path.read_text()+'\nfunc(g *Generator) StudySeed()uint32{return g.state}\n')
 path=p/'smtcore/smt_search.go';ss=Path(rep[str(path)]).read_text();k='func (k *SMTKernel) boundedSearch(session *smtSearchSession) (lbool.LBool, bool, error) {';assert ss.count(k)==1;put(path,ss.replace(k,k+"""if StudyGoal!=0 {g:=StudyGoal;StudyGoal=0;val:=k.internalizer.random.StudySeed();mode:=os.Getenv("FORCE");if (mode=="restoreAll" && g>8)||(mode=="restore16"||mode=="inject16") && g==16 {v,e:=strconv.ParseUint(os.Getenv(fmt.Sprintf("SEED_%d",g)),10,32);if e!=nil{panic(e)};k.internalizer.random.SetSeed(uint32(v))};println("SEED",g,val,k.internalizer.random.StudySeed())}
""")+'\nvar StudyGoal int\n')
 exe=d/'trial';j=d/'overlay.json';j.write_text(json.dumps(ov));sp.run(['go','build','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-mod=readonly','-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=temp,GOTMPDIR=temp),check=True)
 with (w/'rng.csv').open('w') as f,(w/'rng-events.txt').open('w') as log:
  o=csv.writer(f);o.writerow('round mode batch goal phase instructions'.split());modes=['off','force','restoreAll','restore16','inject16'];seeds={'off':{},'force':{}}
  for i in range(5):
   for mode in modes[i%5:]+modes[:i%5]:
    rest=bytearray();r=sp.run(['taskset','-c',os.environ.get('CPU','22'),exe,ex/case],cwd=d,env=dict(os.environ,**seeds['force' if mode=='inject16' else 'off'],FORCE=mode,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=90)
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'SEED '):
      _,g,v,_=l.decode().split();log.write(mode+' '+l.decode());
      if mode in seeds:seeds[mode]['SEED_'+g]=v
     elif l.startswith(b'FORCED '):log.write(f'{mode} '+l.decode());log.flush()
     elif l.startswith(b'STAGE-COUNT '):
      _,b,g,phase,c,_,en,ac,_=l.decode().split();assert en==ac;o.writerow([i,mode,b,g,phase,c])
     else:rest.extend(l)
    assert (r.returncode,r.stdout,rest)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),rest[:500];f.flush()
