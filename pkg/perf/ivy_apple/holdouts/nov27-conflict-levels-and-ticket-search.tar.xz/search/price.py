from pathlib import Path
import os,re,csv,json,subprocess as sp,tempfile
p=Path.cwd();w=Path(__file__).resolve().parent;front=Path(os.environ['GOIVY_FRONTEND']).resolve();rank=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).resolve();names=(rank/'compat.txt').read_text().splitlines()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as temp:
 d=Path(temp);os.environ["GOCACHE"]=str(d/"cache")
 for mode in ['base','release']:
  ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
  def put(path,s):
   f=d/(mode+'-'+path.name);f.write_text(s);rep[str(path)]=str(f)
  path=front/'phase_observer_trial.go';put(path,(w/'row-timer.go.txt').read_text())
  if mode=='base':
   for name in ('smt_conflict_levels.go','smt_context_trace.go','smt_conflict_resolver.go'):
    path=p/'smtcore'/name;put(path,sp.check_output(['git','show','6b8a61a3d:pkg/smtcore/'+name],text=True))
  path=p/'smtcore/smt_search.go';s=path.read_text().replace('import (','import ("os";"strconv";"syscall";"unsafe";');s+='''
func conflictRead(fd int)uint64 {var c [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c)),24);if e!=0||n!=24||c[1]!=c[2]{panic("counter")};return c[0]}
'''
  k='resolution, err := resolver.resolve(conflict, conflictLiteral, baseLevel, userBaseLevel)';assert s.count(k)==1;s=s.replace(k,'fd,fe:=strconv.Atoi(os.Getenv("NNF_FD"));var start uint64;if fe==nil{start=conflictRead(fd)};'+k+';if fe==nil{cost:=conflictRead(fd)-start;fmt.Fprintln(os.Stderr,"PRICE",len(k.internalizer.booleanData),cost)}');put(path,s)
  j=d/(mode+'.json');j.write_text(json.dumps(ov));sp.run(['go','build','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-mod=readonly','-o',d/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=temp,GOTMPDIR=temp),check=True)
 with (w/'prices.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case round mode batch goal phase calls live_variables resolver_instructions'.split())
  for n in [4,8,2,3]:
   gold=rank/f'compat/{n}/1/native'
   for i in range(3):
    for mode in (('base','release') if i%2==0 else ('release','base')):
     r=sp.run(['taskset','-c',os.environ.get('CPU','22'),d/mode,ex/names[n-1]],cwd=d,capture_output=True,timeout=90,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
     rest=bytearray();calls=vs=ins=0
     for line in r.stderr.splitlines(keepends=True):
      if line.startswith(b'PRICE '):
       _,v,c=line.split();calls+=1;vs+=int(v);ins+=int(c)
      elif line.startswith(b'STAGE-COUNT '):
       _,b,g,phase,_,_,en,ac,_=line.decode().split();assert en==ac;o.writerow([n,i,mode,b,g,phase,calls,vs,ins]);calls=vs=ins=0
      else:rest.extend(line)
     assert calls==0 and (r.returncode,r.stdout,rest)==(0,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),rest[:400];f.flush()
