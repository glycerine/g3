from pathlib import Path
import gzip,collections,re
w=Path(__file__).resolve().parent
def load(m,n):
 d={}
 for l in gzip.open(w/f'{m}-{n}.log.gz','rt'):
  tag,_,v=l.rstrip().removeprefix('EVENT ').partition(' ')
  if tag=='START':case=v;d[case]=[]
  else:d[case].append((tag,v))
 return d
def sig(tag,v):
 if tag in ('D','Q'):
  i,term=v.split(' ',1);return ('-' if int(i)%2 else '+',term) if tag=='D' else (int(i),term)
 return tuple(map(int,v.split()))
def prefix(x,y):return next((i for i,(a,b) in enumerate(zip(x,y)) if a!=b),min(len(x),len(y)))
for n in (8,4):
 a,b=load('g3',n),load('native',n)
 for k in a:
  print(k)
  for tag in ('D','Q','C'):
   xs,ys=[[sig(t,v) for t,v in z[k] if t==tag] for z in (a,b)];i=prefix(xs,ys);print(tag,len(xs),len(ys),'prefix',i,'overlap',sum((collections.Counter(xs)&collections.Counter(ys)).values()))
   if tag=='D' and i<min(len(xs),len(ys)):print('first',str(xs[i])[:150],str(ys[i])[:150])
