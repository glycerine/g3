from pathlib import Path
import collections,re
exec((Path(__file__).parent/'compare.py').read_text().split('for n in (8,4):')[0])
def convert(events):
 names={};cnt=collections.Counter();out=[];memo={}
 def canon(term):
  toks=iter(re.findall(r'\(|\)|[^()\s]+',term));end=object()
  def read(t):
   if t=='(':
    xs=[]
    for t in toks:
     if t==')':break
     xs.append(read(t))
    if xs[0] in ('=','iff') and len(xs)==3:xs[1:]=sorted(xs[1:])
    return '('+' '.join(xs)+')'
   m=re.fullmatch(r'(.+)!([0-9]+)',t)
   if m and t not in names:
    pref=m[1];names[t]=pref+'!@'+str(cnt[pref]);cnt[pref]+=1
   return names.get(t,t)
  s=read(next(toks));assert next(toks,end) is end;return s
 for t,v in events:
  if t in ('D','Q'):
   num,term=v.split(' ',1)
   if term not in memo:memo[term]=canon(term)
   out.append((t,int(num),memo[term]))
  elif t=='C':
   sc,back,*lits=map(int,v.split());out.append((t,sc,back,tuple(sorted(lits))))
  else:out.append((t,))
 return out
for n in (8,4):
 g,z=load('g3',n),load('native',n)
 for k in g:
  a,b=[convert(x[k]) for x in (g,z)]
  print(k,'full prefix',prefix(a,b),'lens',len(a),len(b))
  for t in ('D','Q','C'):
   xs,ys=[[e for e in s if e[0]==t] for s in (a,b)];i=prefix(xs,ys);print(t,i,'of',len(xs),len(ys))
   if t=='D' and i<min(len(xs),len(ys)):print('at mismatch',xs[i][1],ys[i][1],xs[i][2][:155],ys[i][2][:155])
