from pathlib import Path
import json

root = Path.cwd()
out = root / 'build/.nov26-qi-path'
watch = root / 'smtcore/smt_relevancy_asserted_or.go'
manager = root / 'smtcore/smt_quantifier_manager.go'

def replace(path, old, new):
    source = path.read_text()
    assert source.count(old) == 1, (path, old)
    return source.replace(old, new)

watch_source = replace(watch, '''	for _, child := range args {
		if err := p.addLiteralWatch(child, true, &handler); err != nil {''', '''	for i, literal := range literals {
		source := args[i]
		if literal.Sign() {
			source = p.internalizer.boolExpr[literal.Var()]
		}
		if err := p.addWatch(source, !literal.Sign(), &handler); err != nil {''')
promote_source = replace(manager, 'return q.checker.IsUnsatisfiable(body, entry.Fingerprint.args)',
    'return q.checker.run(body, false, entry.Fingerprint.args, q.registry.statistics[entry.Fingerprint.data])')
for name, variants in [('watch', {watch: watch_source}), ('promote', {manager: promote_source})]:
    overlay = {}
    for path, source in variants.items():
        target = out / (name + '-' + path.name)
        target.write_text(source)
        overlay[str(path)] = str(target)
    (out / (name + '.json')).write_text(json.dumps({'Replace': overlay}))
