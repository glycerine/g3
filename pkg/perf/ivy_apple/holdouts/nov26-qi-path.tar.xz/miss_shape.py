"""Prototype sharing a validated arena read between substitution and rewriter traversal."""
from pathlib import Path
import json

root = Path.cwd()
out = root / 'build/.nov26-qi-path'
substitution = root / 'ast/ast_expr_substitution_ops.go'
engine = root / 'ast/rewriter/rewriter_engine.go'
helper = '''
// ExprSubstitutionMissShape returns a node shape when the current substitution
// is known to miss. The ordinary lookup still owns every uncertain case.
func (m *ASTManager) ExprSubstitutionMissShape(s ASTExprSubstitution, key ASTHandle) (kind ASTKind, rc, count uint32, miss bool) {
    state := m.lastExprSubstitution
    if astValidateHandles || !m.lockFree() || key.origin != m.origin || s.origin != m.origin || state == nil || state.record != s.record {
        return
    }
    _, record, err := m.substKey(astNodeRef{key.slot, key.generation})
    if err != nil || record.hasFlag(astWasSubstitutionKey) {
        return
    }
    if record.kind == ASTApp {
        count = m.appAt(key.slot).count
    }
    return record.kind, record.rc, count, true
}
'''
text = engine.read_text()
start = text.index('func (r *rewriterEngine) visit(t ast.ASTHandle')
end = text.index('\nfunc (r *rewriterEngine) processVar(', start)
body = text[start:end]
body = body.replace('sub, subProof, found, e := r.cfg.GetSubst(t)', '''var kind ast.ASTKind
    var rc, n uint32
    miss := false
    if cfg, ok := r.cfg.(*theoryRewriterConfiguration); ok && cfg.hasSubstitution {
        kind, rc, n, miss = m.ExprSubstitutionMissShape(cfg.substitution, t)
    }
    var sub, subProof ast.ASTHandle
    var found bool
    var e error
    if !miss {
        sub, subProof, found, e = r.cfg.GetSubst(t)
    }''')
body = body.replace('''kind, rc, n, e := m.NodeShape(t)
	if e != nil {
		return false, e
	}''', '''if !miss {
        kind, rc, n, e = m.NodeShape(t)
        if e != nil {
            return false, e
        }
    }''')
assert 'ExprSubstitutionMissShape' in body and 'kind, rc, n, e = m.NodeShape(t)' in body
mapping = {}
for path, changed in ((substitution, substitution.read_text()+helper), (engine, text[:start]+body+text[end:])):
    dst = out / ('miss-' + path.name)
    dst.write_text(changed)
    mapping[str(path)] = str(dst)
(out / 'miss.json').write_text(json.dumps({'Replace': mapping}))
