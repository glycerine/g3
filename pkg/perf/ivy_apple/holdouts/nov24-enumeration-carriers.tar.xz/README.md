# Finite carriers for Apple enumeration proofs

The six positive fixtures contain every original premise of a hard Apple goal. Six satisfiable projections contain 64 ranked premises. Each has six independently replayable representations. All standalone runs set smt.macro_finder, smt.relevancy=1 and a six-million resource limit. The two shell binaries agreed on verdict, decisions, conflicts, instances and reported resources for every file.

The original encoding uses distinct named constants and a quantified coverage axiom for each enumeration. The open encoding removes coverage. This only supports proving UNSAT. The power-of-two encoding replaces eligible finite sorts with bit vectors. The all-bit-vector encoding also bounds non-power-of-two quantified variables and function ranges. The mixed datatype encoding uses bit vectors for power-of-two sizes and nullary-constructor datatypes otherwise. The all-datatype encoding uses native enumeration datatypes throughout.

Run from the extracted archive. Use the local g3 checkout and the Z3 binary built from its src tree.

```sh
python3 replay.py shell --binary /path/to/g3 --case 'miss5-full/(bv-all|uf-open)'
python3 replay.py shell --binary /path/to/g3/build/z3 --case 'miss5-full/(bv-all|uf-open)'
python3 replay.py controls --binary /path/to/g3
python3 replay.py history --pkg /path/to/g3/pkg --case 'histories/5-uf-open'
```

Omit the filter to replay a full group. A history starts with a fresh private API solver, retains its preceding siblings in order and stops on the first failed refutation. Earlier checks receive six million resource units. The two terminal budgets are six and twelve million. The shell fixture is a fresh standalone query. Private API settings, history and generated symbol declarations can all affect the search. Each resource allowance is a maximum. Use the raw counts to compare work among completed proofs.

The small controls have 2, 3, 4, 5 and 8 named elements and exercise existential and universal binders, constants and function result ranges. Truth and status in controls.csv refer to the original and transformed formula respectively. An open sort can have an additional unnamed element.
