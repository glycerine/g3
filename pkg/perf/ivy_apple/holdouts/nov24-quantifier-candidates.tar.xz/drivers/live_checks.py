from common import *
from types import SimpleNamespace
import macro_identity as mi,conditional_datatypes as cd
sys.path.insert(0,str(pkg/'perf/ivy_apple'))
import search_counters as sc
root=d/'live-checks';root.mkdir(exist_ok=True)
bridge=ivy.resolve()/'z3bridge_solver_model.go';core=ivy.resolve()/'smt/g3_solver.go'
observer=gzip.decompress((pkg/'perf/ivy_apple/incremental_cost/nov24-first-pass-observers.patch.gz').read_bytes()).decode()
helper=(w/'portable-pass-final/build/g3/pkg/smtcore/asserted_pass_benchmark_observer.go').read_text().replace('package smtcore','package smt').replace('ASSERTED-PASS','INNER-CHECK')
def make(v,collect):
 od=root/(v+('-stats'if collect else'-time'));od.mkdir(exist_ok=True)
 ed={} if v in ('control','native')else cd.ed(v);s=ed.get(bridge,bridge.read_text())
 a=s.index('func (s *Solver) GetSmallModelWithCond(');b=s.index('\n}',a);h=s[a:b]
 h=once(h,'if finalCond != nil {','if finalCond != nil {\ntrialBatchSeq++; batch:=trialBatchSeq')
 h=once(h,'for _, fc := range finalCond {','for j, fc := range finalCond {')
 x='res, err := s.decideZ3With(z3solver, finalCheck)'
 h=once(h,x,'fmt.Fprintln(os.Stderr,"LIVE-BEGIN",batch,j+1)\n'+x+'\nfmt.Fprintln(os.Stderr,"LIVE-END",batch,j+1,int(res))')
 ed[bridge]=s[:a]+h+s[b:]+'\nvar trialBatchSeq int\n'
 if '"os"' not in ed[bridge]:ed[bridge]=once(ed[bridge],'import (','import (\n"os"')
 flags=[]
 if v!='native':
  s=ed.get(core,core.read_text());a=s.index(sc.GO_METHOD);b=s.index('\n}',a);t=s[a:b]
  x='if proved, err := prove(); err == nil && proved {'
  t=once(t,x,'endProof:=trialPassBegin("proof");proved,trialErr:=prove();endProof();if trialErr==nil && proved{')
  x='r, err := s.c.Check()'
  if collect:
   y='''before:=ivyCounterStats(s);endCheck:=trialPassBegin("solver");r,err:=s.c.Check();endCheck();ivyCounterSequence++;fmt.Fprintln(os.Stderr,"IVY-STATS",ivyCounterSequence,strconv.Quote(before),strconv.Quote(ivyCounterStats(s)))'''
   s=s[:a]+once(t,x,y)+s[b:]+sc.GO_HELPER
   s=once(s,'import (','import ("os";"fmt"')
  else:s=s[:a]+once(t,x,'endCheck:=trialPassBegin("solver");r,err:=s.c.Check();endCheck()')+s[b:]
  ed[core]=s;ed[core.parent/'inner_trial_observer.go']=helper
 else:
  if collect:
   obj=od/'stats.o';lib=ivy.resolve()/'z3vendor/native_lib/libz3.a';run(['c++','-O2','-fPIC','-c','-I',pkg.parent/'src/api',pkg.parent/'src/test/perf/ivy_solver_statistics.cpp','-o',obj])
   flags=['-ldflags',f"-linkmode=external '-extldflags=-Wl,--wrap=Z3_solver_check {obj} {lib} -lstdc++ -lm -lgomp'"]
 o=overlay(od/'overlay',ed);b=od/'goivy_check';args=['go','build','-p','4','-pgo=off','-buildvcs=false','-mod=readonly','-modfile='+str(w/'local-checkout.mod'),'-tags=xtrace_off'+(',classic_z3'if v=='native'else''),'-overlay='+str(o),*flags,'-o',b,'./cmd/goivy_check']
 with(w/'build.lock').open('a')as lk,(od/'build.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(args,cwd=ivy,stdout=f,stderr=f)
 if not (od/'abc').exists():(od/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
 if v!='native':(od/'build-info.txt').write_text(linked(b))
 return b
def parse(out,od,v):
 scope=None;rows=[];extra=bytearray();nativebefore=None;decoder=json.JSONDecoder()
 vals=lambda s:{k:int(n)for k,n in re.findall(r':([\w-]+)\s+(\d+)(?=[)\s])',s)}
 counter=lambda b:[(k.replace(' ','-'),int(n))for k,n in(b.rsplit('=',1)for b in b)]
 for line in out.splitlines(keepends=True):
  if line.startswith(b'LIVE-BEGIN '):
   assert scope is None;_,batch,goal=line.split();scope=(int(batch),int(goal));ins=Counter();delta=Counter();statsn=0;res=0
  elif line.startswith(b'LIVE-END '):
   _,batch,goal,r=line.split();assert scope==(int(batch),int(goal));rows.append([*scope,int(r),ins['proof'],ins['solver'],statsn,*[delta[c] for c in sc.COUNTERS]]);scope=None
  elif line.startswith(b'INNER-CHECK '):
   if scope is None:continue
   _,phase,tid,start,end,n,empty=line.decode().split();ins[phase]+=int(n)-int(empty)
  elif line.startswith(b'IVY-STATS '):
   if scope is None:continue
   _,num,strings=line.decode().split(' ',2);first,mid=decoder.raw_decode(strings);last=decoder.decode(strings[mid:].strip());before,after=vals(first),vals(last);delta.update({k:after.get(k,0)-before.get(k,0) for k in sc.COUNTERS});statsn+=1
  elif line.startswith(b'NATIVE-STATS '):
   if scope is None:continue
   head,*rest=line.decode().strip().split('|');_,num,side=head.split();s=dict(counter(rest))
   if side=='before':assert nativebefore is None;nativebefore=(num,s)
   else:
    assert nativebefore[0]==num;before=nativebefore[1];delta.update({k:s.get(k,0)-before.get(k,0)for k in sc.COUNTERS});statsn+=1;nativebefore=None
  else:extra.extend(line)
 assert scope is None and nativebefore is None
 with gzip.open(od/'checks.csv.gz','wt')as f:z=csv.writer(f);z.writerow(['batch','goal','result','proof','solver','observed_checks',*sc.COUNTERS]);z.writerows(rows)
 return extra
def lane(j,bs,rounds):
 cpu,n,sp,iso,rc,_,ref=j;out=root/n;out.mkdir(exist_ok=True);vs=list(bs)
 for i in range(rounds):
  for v in vs[i%len(vs):]+vs[:i%len(vs)]:
   od=out/f'{i+1}-{v}';od.mkdir(exist_ok=True)
   p=subprocess.run(['taskset','-c',str(cpu),bs[v],*(['isolate='+iso]if iso else []),examples/sp],cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100'),timeout=4500)
   ext=parse(p.stderr,od,v);assert p.returncode==rc and (p.stdout,ext)==tuple((ref/k).read_bytes()for k in ('stdout','stderr')),(n,v,p.returncode,ext[-500:])
   (od/'validated').write_text('matched exit and both streams\n');print(n,i+1,v,flush=True)
if __name__=='__main__':
 vs=['control','data256','native']
 with ThreadPoolExecutor(3)as ex:
  keys=[(v,a)for v in vs for a in ([True]if v=='native'else[True,False])]
  bs=dict(zip([v+('-stats'if a else'-time')for v,a in keys],ex.map(lambda k:make(*k),keys)))
 js=[(c,*j[1:])for c,j in zip([0,3,5,7,10,13],(j for j in mi.jobs()if j[1]in ['ordinary','tlb','hybrid_reliable_broadcast_cisa','flash2','toy-consensus','raftok']))]
 with ThreadPoolExecutor(8)as ex:list(ex.map(lambda j:lane(j,bs,3),js))
