from study import *
import conditional_shared as base,conditional_pass as cp,macro_identity as mi,guarded_live as gl
from panel import CASES
d=w/'conditional-datatypes';d.mkdir(exist_ok=True)
kernel=pkg/'smtcore/smt_kernel.go'
walk='''
func(k *SMTKernel)trialBaseHasDatatype()bool{
 if k.factorBasePolicy!=0{return k.factorBasePolicy==2}
 k.factorBasePolicy=1
 m:=k.manager;dt,e:=m.DatatypeFamilyID();if e!=nil{return false};var todo []ast.ASTHandle
 seen:=map[ast.ASTHandle]struct{}{};for _,row:=range k.assertions{todo=append(todo,row.Formula)}
 for len(todo)>0 && len(seen)<LIMIT{last:=len(todo)-1;h:=todo[last];todo=todo[:last];if _,ok:=seen[h];ok{continue};seen[h]=struct{}{};hd,e:=m.NodeHeader(h);if e!=nil{continue}
  if hd.Kind==ast.ASTApp{
   MATCH
   for i:=uint32(0);i<hd.NumArgs && i<128;i++{a,e:=m.GetArg(h,i);if e!=nil{continue};todo=append(todo,a)}
  }else if hd.Kind==ast.ASTQuantifier{b,e:=m.GetQuantifierBody(h);if e==nil{todo=append(todo,b)}}
 };return false
}
'''
def ed(v):
 if v=='control':return {}
 es=base.ed('compound')
 if v=='always':return es
 es[kernel]=once(es[kernel],'type SMTKernel struct {','type SMTKernel struct {\nfactorBasePolicy uint8')
 stmt='if hd.Family==dt{k.factorBasePolicy=2;return true}'
 if 'ite'in v:stmt='''if hd.Family==m.BasicFamilyID() && hd.DeclKind==ast.ASTOpIte{s,e:=m.GetSort(h);if e==nil{family,e:=m.GetFamilyID(s);if e==nil && family==dt{k.factorBasePolicy=2;return true}}}'''
 if 'enum'in v:stmt='''if hd.Family==dt{s,e:=m.GetSort(h);if e==nil{size,e:=m.GetSortSize(s);if e==nil && size.Tag==ast.ASTFiniteSortSize{k.factorBasePolicy=2;return true}}}''';stmt=stmt.replace('size.Tag','size.Kind').replace('ast.ASTFiniteSortSize','ast.ASTSortFinite')
 out=es[cp.reduce];x='if k.factorScopedConditionals &&';es[cp.reduce]=once(out,x,x+' k.trialBaseHasDatatype() &&')+walk.replace('LIMIT','256'if '256'in v else'2048').replace('MATCH',stmt);return es
def mk(v):
 od=d/v;o=overlay(od/'overlay',ed(v));b=build(od/'checker',o=o);info=run(['go','version','-m',b],capture_output=True,text=True).stdout;assert '=>\t/home/jaten/g3/pkg\t(devel)'in info;(od/'build-info.txt').write_text(info);return b
def main():
 vs=['control','always','data256','data2048','ite256','ite2048']
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 gl.d=d;js=[(c,*j[1:5],4,j[-1])for c,j in zip([1,3,5,7,9,11,13,15,17],(j for j in mi.jobs()if j[1]!='dramc_nb2'))];n='raft_no_assume';sp,iso,_,f,u=CASES[n];js.append((19,n,sp,iso,int(bool(f or u)),5,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(10)as e:list(e.map(lambda j:gl.measure_job(j,bs),js))
if __name__=='__main__':main()
