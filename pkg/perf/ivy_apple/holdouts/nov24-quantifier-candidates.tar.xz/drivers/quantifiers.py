from common import *
from types import SimpleNamespace
import conditional_datatypes as cd,macro_identity as mi
sys.path.insert(0,str(pkg/'perf/ivy_apple/incremental_cost'))
import first_push_rewrite_rows as first
root=d/'quantifiers';root.mkdir(exist_ok=True)
bridge=ivy.resolve()/'z3bridge_solver_model.go'
unit=pkg.parent/'src/smt/qi_queue.cpp'
gohelper=r'''
package smtcore
import ("fmt";"os";"strconv";"github.com/glycerine/g3/pkg/ast")
var trialNames map[ast.ASTHandle]string
var trialLast string
func trialName(m *ast.ASTManager,h ast.ASTHandle)string {
 hd,e:=m.NodeHeader(h);if e!=nil{panic(e)}
 name:=func(h ast.ASTHandle)string{s,e:=m.GetASTName(h);if e!=nil{panic(e)};v,e:=m.Symbols.String(s);if e!=nil{panic(e)};return v}
 switch hd.Kind {
 case ast.ASTApp:
  text:=name(hd.Decl);if hd.NumArgs==0{return text};text="("+text
  for i:=uint32(0);i<hd.NumArgs;i++ {a,e:=m.GetArg(h,i);if e!=nil{panic(e)};text+=" "+trialName(m,a)};return text+")"
 case ast.ASTVar:
  v,e:=m.GetVarIndex(h);if e!=nil{panic(e)};return "$"+strconv.Itoa(int(v))
 case ast.ASTQuantifier:
  text:="(exists";all,e:=m.IsForall(h);if e!=nil{panic(e)};if all{text="(forall"};n,e:=m.GetNumDeclarations(h);if e!=nil{panic(e)}
  for i:=uint32(0);i<n;i++ {s,e:=m.GetDeclarationSort(h,i);if e!=nil{panic(e)};text+=" "+name(s)}
  body,e:=m.GetQuantifierBody(h);if e!=nil{panic(e)};text+=" "+trialName(m,body)
  n,e=m.GetNumPatterns(h);if e!=nil{panic(e)};for i:=uint32(0);i<n;i++ {p,e:=m.GetPattern(h,i);if e!=nil{panic(e)};text+=" "+trialName(m,p)}
  return text+")"
 };panic("unexpected expression")
}
func trialObserve(m *ast.ASTManager,h ast.ASTHandle,status string,gen uint32){
 b,e:=os.ReadFile("watch-quantifiers");if os.IsNotExist(e){return};if e!=nil{panic(e)}
 k:=string(b);if k!=trialLast{trialLast=k;trialNames=make(map[ast.ASTHandle]string)}
 id,e:=m.GetASTID(h);if e!=nil{panic(e)};if _,ok:=trialNames[h];!ok{text:=trialName(m,h);trialNames[h]=text;fmt.Fprintln(os.Stderr,"QUANT-NAME",k,id,text)}
 fmt.Fprintln(os.Stderr,"QUANT-COUNT",k,id,status,gen)
}
'''
cpphelper=r'''
#include <fstream>
#include <sstream>
#include <unordered_set>
static void trial_name(std::ostream& o, expr* e) {
 if (is_var(e)) {o << "$" << to_var(e)->get_idx();return;}
 if (is_app(e)) {app* a=to_app(e);unsigned n=a->get_num_args();if(n)o<<"(";o<<a->get_decl()->get_name();for(unsigned i=0;i<n;i++){o<<" ";trial_name(o,a->get_arg(i));}if(n)o<<")";return;}
 quantifier* q=to_quantifier(e);o<<(q->is_forall()?"(forall":"(exists");
 for(unsigned i=0;i<q->get_num_decls();i++)o<<" "<<q->get_decl_sort(i)->get_name();
 o<<" ";trial_name(o,q->get_expr());
 for(unsigned i=0;i<q->get_num_patterns();i++){o<<" ";trial_name(o,q->get_pattern(i));}
 o<<")";
}
static void trial_observe(quantifier* q,const char* stage,unsigned gen) {
 std::ifstream infile("watch-quantifiers");if(!infile)return;
 std::string key;std::getline(infile,key);static std::string last;static std::unordered_set<quantifier*> seen;
 if(key!=last){last=key;seen.clear();}
 if(seen.insert(q).second){std::ostringstream s;trial_name(s,q);std::fprintf(stderr,"QUANT-NAME %s %u %s\n",key.c_str(),q->get_id(),s.str().c_str());}
 std::fprintf(stderr,"QUANT-COUNT %s %u %s %u\n",key.c_str(),q->get_id(),stage,gen);
}
'''
def build_obs(v):
 od=root/v;od.mkdir(exist_ok=True);ed=cd.ed(v)if v=='data256'else{}
 s=ed.get(bridge,bridge.read_text());a=s.index('func (s *Solver) GetSmallModelWithCond(');b=s.index('\n}',a);t=s[a:b]
 t=once(t,'if finalCond != nil {','if finalCond != nil {\ntrialBatch++; batch:=trialBatch')
 t=once(t,'for _, fc := range finalCond {','for j,fc:=range finalCond {')
 x='res, err := s.decideZ3With(z3solver, finalCheck)'
 t=once(t,x,'''selected:=(batch==10 && j+1==70)||(batch==14 && j+1==69)||(batch==5 && j+1==69)
 if selected{if e:=os.WriteFile("watch-quantifiers",[]byte(fmt.Sprintf("%d-%d",batch,j+1)),0600);e!=nil{panic(e)}}
 '''+x+'''
 if selected{if e:=os.Remove("watch-quantifiers");e!=nil{panic(e)}}
 ''')
 ed[bridge]=s[:a]+t+s[b:]+'\nvar trialBatch int\n'
 if '"os"'not in ed[bridge]:ed[bridge]=once(ed[bridge],'import (','import (\n"os"')
 if v=='native':
  s=once(unit.read_text(),'namespace smt {',cpphelper+'\nnamespace smt {')
  s=once(s,'if (m_checker.is_sat(q->get_expr(), num_bindings, bindings)) {','trial_observe(q,"candidate",generation);\n        if (m_checker.is_sat(q->get_expr(), num_bindings, bindings)) {\n            trial_observe(q,"satisfied",generation);')
  s=once(s,'        if (m_manager.is_true(s_instance)) {','        if (m_manager.is_true(s_instance)) {\n            trial_observe(q,"true",generation);')
  s=once(s,'stat->inc_num_instances();','trial_observe(q,"instance",generation);\n        stat->inc_num_instances();')
  source=od/unit.name;source.write_text(s);sources={unit:source}
  first.native_library(SimpleNamespace(cpp_build=pkg.parent/'build',goivy=ivy.resolve()),od,sources,'qi_queue',None)
  adapter=ivy.resolve()/'smt/quantifier.go';ed[adapter]=sources[adapter].read_text()
 else:
  sf=pkg/'smtcore/smt_qi_instance.go';s=sf.read_text()
  s=once(s,'satisfied, err := b.checker.run(body, true, bindings, stat)','trialObserve(b.manager,quantifier,"candidate",entry.Generation);\n satisfied, err := b.checker.run(body, true, bindings, stat)')
  s=once(s,'if satisfied {','if satisfied {\n trialObserve(b.manager,quantifier,"satisfied",entry.Generation)')
  s=once(s,'result.reducedTrue = true','trialObserve(b.manager,prepared.quantifier,"true",prepared.entry.Generation);\n result.reducedTrue = true')
  s=once(s,'stat.IncrementInstances()','trialObserve(b.manager,prepared.quantifier,"instance",prepared.entry.Generation);\n stat.IncrementInstances()')
  ed[sf]=s;ed[sf.parent/'trial_quantifier_histogram.go']=gohelper
 o=overlay(od/'overlay',ed);binary=build(od/'checker','native'if v=='native'else'g3',o);(od/'build-info').write_text(linked(binary)if v!='native'else subprocess.check_output(['go','version','-m',binary],text=True));return binary
def measure(v,bb,idx):
 od=root/v/str(idx);od.mkdir(exist_ok=True);j=mi.jobs()[0]
 p=subprocess.run(['taskset','-c',str({'control':4,'data256':6,'native':8}[v]),bb,examples/j[2]],cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100'))
 names={};counts=Counter();etc=bytearray()
 for line in p.stderr.splitlines(keepends=True):
  if line.startswith(b'QUANT-NAME '):
   _,scope,num,q=line.decode().rstrip().split(' ',3);names[(scope,num)]=q
  elif line.startswith(b'QUANT-COUNT '):
   _,scope,num,what,gen=line.decode().split();counts[(scope,names[(scope,num)],what,int(gen))]+=1
  else:etc.extend(line)
 assert p.returncode==0 and p.stdout==(j[-1]/'stdout').read_bytes() and etc==(j[-1]/'stderr').read_bytes(),(v,p.returncode,etc[-500:])
 with gzip.open(od/'observations.csv.gz','wt')as f:z=csv.writer(f);z.writerow(['goal','quantifier','stage','generation','count']);z.writerows([*k,n]for k,n in sorted(counts.items()))
 for goal in ['5-69','10-70','14-69']:
  sub=Counter();sub.update({st:sum(n for (g,q,s,gen),n in counts.items()if g==goal and s==st)for st in ['candidate','instance','true','satisfied']});assert sub['candidate']==sub['instance']+sub['true']+sub['satisfied'] and sub['instance']>0;print(v,goal,sub,flush=True)
if __name__=='__main__':
 vs=['control','data256','native']
 def lane(v):
  b=build_obs(v)
  for i in (1,2):measure(v,b,i)
 with ThreadPoolExecutor(3)as e:list(e.map(lane,vs))
