from pathlib import Path
import tempfile,json,os,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();base=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
def put(path,s):
 f=w/('subsumed-'+path.name);f.write_text(s);base['Replace'][str(path)]=str(f)
path=p/'api/api_short_premises.go';s=path.read_text().replace('type shortPremisePlan struct {','type shortPremisePlan struct {\n trialSat bool');put(path,s)
path=p/'api/api_goal_instances_check.go';s=path.read_text().replace('&& hasPrivatePremiseModel(parent, short.selected) {','&& hasPrivatePremiseModel(parent, short.selected) {\n short.trialSat=true').replace('return err == nil && answer == lbool.False, err','if short,ok:=plan.(*shortPremisePlan);ok{short.trialSat=err==nil && answer==lbool.True};return err == nil && answer == lbool.False, err',1);put(path,s)
path=p/'api/api_verification_goal.go';s=path.read_text().replace('import ','import ("os";"fmt")\nimport ',1).replace('func (p *orderProofState) proveRelevantPremises(','var subTrial=os.Getenv("SUBSET_PRICE")\nfunc (p *orderProofState) proveRelevantPremises(')
s=s.replace('check := func(subset','var earlier []ast.ASTHandle;knownSat:=false\n check := func(subset')
k='return p.checkProofPlan(m, &shortPremisePlan{source: assertions, selected: input}, steps)';assert s.count(k)==1
s=s.replace(k,'''subsetOf:=len(earlier)>0 && len(subset)<=len(earlier)
 if subsetOf{for _,a:=range subset{if !containsDeclaration(earlier,a){subsetOf=false;break}}}
 if subsetOf && (subTrial=="any" || subTrial=="sat" && knownSat){return false,nil}
 plan:=&shortPremisePlan{source:assertions,selected:input}
 yes,e:=p.checkProofPlan(m,plan,steps)
 if subTrial=="observe"{fmt.Fprintln(os.Stderr,"COVER",steps,len(base.rows),len(subset),subsetOf,knownSat,plan.trialSat,yes)}
 earlier=subset;knownSat=plan.trialSat;return yes,e''');put(path,s)
j=w/'subsumed.json';j.write_text(json.dumps(base))
with tempfile.TemporaryDirectory(dir=Path.home()/'tmp') as t:
 sp.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'subsumed','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=t,GOTMPDIR=t),check=True)
