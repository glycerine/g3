from pathlib import Path
import csv,os,subprocess as sp,time,concurrent.futures
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');names=(ref/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');codes={x['case']:int(x['exit']) for x in csv.DictReader((ref/'ranking.csv').open())}
def lane(i):
 cases=list(map(int,os.environ['CASES'].split())) if 'CASES' in os.environ else list(range(1,229))
 with (w/(os.environ.get('STEM','coverage-panel')+str(i)+'.csv')).open('w') as f:
  out=csv.writer(f);out.writerow('case round mode status instructions ms'.split())
  for k in cases[i::4]:
   name=names[k-1];gold=ref/'compat'/str(k)/'1/native';work=w/'release-work'/str(k);work.mkdir(exist_ok=True,parents=True)
   if not (work/'abc').exists():(work/'abc').symlink_to('/home/jaten/go/bin/abc')
   for j in range(int(os.getenv('ROUNDS','1'))):
    for m in (['base','release'] if (k+j)%2 else ['release','base']):
     exe=(Path('/tmp/g3-first-qi') if m=='base' else w)/'release';stat=work/(os.environ.get('STEM','coverage-panel')+'.stat');start=time.monotonic()
     rr=sp.run(['taskset','-c',str(int(os.getenv('CPU','32'))+2*i),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,ex/name],cwd=work,capture_output=True,timeout=180,env=dict(os.environ,GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'))
     assert (rr.returncode,rr.stdout,rr.stderr)==(codes[name],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(k,m,rr.stderr[-120:])
     ins=next(int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
     out.writerow([k,j,m,'match',ins,round(1000*(time.monotonic()-start),2)]);f.flush()
with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(lane,range(4)))
