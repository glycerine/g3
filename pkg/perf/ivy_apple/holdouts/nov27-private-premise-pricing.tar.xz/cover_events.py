from pathlib import Path
import os
w=Path(__file__).resolve().parent
s=(w/'inventory.py').read_text().replace("w/'subset_trial'","w/'subsumed'").replace("w/'inventory-work'","w/'subsumed-work'").replace("w/'inventory.csv'","w/'subsumed_events.csv'").replace("b'SUBSET '","b'COVER '").replace("_,a,b,c,yes,ok=l.decode().strip().split();assert ok=='true';events.append([a,b,c,yes])","events.append(l.decode().split()[1:])").replace("selector base selected proved","budget base selected subset prior_sat sat proved").replace("['none',0,0,'false']","['none',0,0,'false','false','false','false']")
exec(s)
