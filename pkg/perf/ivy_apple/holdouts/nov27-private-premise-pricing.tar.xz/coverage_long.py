from pathlib import Path
import csv,os,subprocess as sp,time,concurrent.futures
p=Path.cwd();w=Path(__file__).resolve().parent;ex=Path('/home/jaten/ivy/ivy-lang-examples')
def test(pair):
 name,cpu=pair;apple=name!='raft_no_assume';ref=(p/'build/.boolean-enode-cost/apple-final' if apple else Path('/tmp/g3-nov22b/end-panel-final/large-a'))/name/'1/native';spec=ex/('doc/examples/apple/ord_live.ivy' if apple else 'examples/raft/raft_no_assume.ivy')
 with (w/('coverage-'+name+'.csv')).open('w') as f:
  out=csv.writer(f);out.writerow('case round engine status instructions ms'.split())
  for i in range(3):
   for m in (['base','release'] if i%2==0 else ['release','base']):
    exe=(Path('/tmp/g3-first-qi') if m=='base' else w)/('apple-release' if apple else 'release');stat=w/('holdout-'+name+'.stat');start=time.monotonic()
    rr=sp.run(['taskset','-c',str(cpu),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-e','instructions:u','-o',stat,'--',exe,*(['isolate='+name] if apple else []),spec],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
    assert (rr.returncode,rr.stdout,rr.stderr)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,rr.stderr[-200:]);ins=next(int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([name,i,m,'match',ins,round(1000*(time.monotonic()-start),2)]);f.flush()
with concurrent.futures.ThreadPoolExecutor(3) as pool:list(pool.map(test,[('rfn2',18),('dramc_nb2',20),('raft_no_assume',22)]))
