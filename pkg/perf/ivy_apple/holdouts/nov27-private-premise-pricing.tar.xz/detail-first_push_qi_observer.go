package api
import("fmt";"os";"strconv";"syscall";"unsafe")
var priceInRelevant bool
func studyPrivate(op string)func(){if op=="proveRelevantPremises"{priceInRelevant=true}else if !priceInRelevant{return func(){}};fd,e:=strconv.Atoi(os.Getenv("PST_FD"));if e!=nil{return func(){}}; rd:=func()uint64{var a [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&a)),24);if n!=24||e!=0||a[1]!=a[2]{panic("counter")};return a[0]};start:=rd();return func(){if op=="proveRelevantPremises"{priceInRelevant=false};n:=rd()-start;fmt.Fprintln(os.Stderr,"PRIVATE",op,n)}}
