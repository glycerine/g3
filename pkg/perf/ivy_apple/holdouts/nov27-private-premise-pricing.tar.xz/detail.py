from pathlib import Path
import subprocess as sp,os,csv,json,tempfile
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads(Path('/tmp/g3-arith-next/final/arith-stage.json').read_text());rep=ov['Replace']
def put(path,s):
 f=w/('detail-'+path.name);f.write_text(s);rep[str(path)]=str(f)
path=front/'phase_observer_trial.go';s=Path(rep[str(path)]).read_text().replace('start := time.Now()','os.Setenv("PST_FD",fmt.Sprint(fd));start := time.Now()').replace('elapsed := time.Since(start)','os.Unsetenv("PST_FD");elapsed := time.Since(start)');put(path,s)
funcs=['proveRelevantPremises','checkProofPlan','selectRows','indexedPremises','indexDefinitions','collect']
import re
for path in sorted((p/'api').glob('*.go')):
 if path.name.endswith('_test.go'):continue
 s=path.read_text();orig=s
 for m in reversed(list(re.finditer(r'^func \(\w+ \*\w+\) ('+'|'.join(funcs)+r')\([^\n]+\{\s*$',s,re.M))):
  if m[1]=='collect' and '*witnessSymbolWalk' not in m[0]:continue
  i=s.index('{',m.start(),m.end())+1;s=s[:i]+'\n defer studyPrivate("'+m[1]+'")()\n'+s[i:]
 if s!=orig:put(path,s)
put(p/'api/first_push_qi_observer.go','''package api
import("fmt";"os";"strconv";"syscall";"unsafe")
var priceInRelevant bool
func studyPrivate(op string)func(){if op=="proveRelevantPremises"{priceInRelevant=true}else if !priceInRelevant{return func(){}};fd,e:=strconv.Atoi(os.Getenv("PST_FD"));if e!=nil{return func(){}}; rd:=func()uint64{var a [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&a)),24);if n!=24||e!=0||a[1]!=a[2]{panic("counter")};return a[0]};start:=rd();return func(){if op=="proveRelevantPremises"{priceInRelevant=false};n:=rd()-start;fmt.Fprintln(os.Stderr,"PRIVATE",op,n)}}
''')
j=w/'detail.json';j.write_text(json.dumps(ov))
with tempfile.TemporaryDirectory(prefix='g3-qi-private-',dir=Path.home()/'tmp') as d:
 sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'detail','./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOTMPDIR=d,TMPDIR=d),check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows')
with (w/'detail.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case round batch goal phase op instructions'.split())
 for n in (7,9,6,2):
  name=(rank/'compat.txt').read_text().splitlines()[n-1];ref=rank/'compat'/str(n)/'1/native';rc=int(next(r['exit'] for r in csv.DictReader((rank/'ranking.csv').open()) if r['case']==name))
  for i in range(3):
   r=sp.run(['taskset','-c','14',w/'detail',ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=60);rest=bytearray();ops=[]
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'PRIVATE '):_,op,count=l.decode().split();ops.append((op,count))
    elif l.startswith(b'STAGE-COUNT '):
     _,b,g,phase,count,_,en,ac,_=l.decode().split();assert en==ac
     for op,v in ops+[('TOTAL',count)]:o.writerow([n,i,b,g,phase,op,v])
     ops=[]
    else:rest.extend(l)
   assert not ops and (r.returncode,r.stdout,rest)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),rest[-320:];f.flush()
