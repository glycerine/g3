from pathlib import Path
import concurrent.futures,csv,os,subprocess as sp
w=Path(__file__).resolve().parent;root=Path('/tmp/g3-reduction-rows');cases=(root/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');codes={r['case']:int(r['exit']) for r in csv.DictReader((root/'ranking.csv').open())}
def run(pair):
 i,name=pair;d=root/'compat'/str(i)/'1/native'
 work=w/'inventory-work'/str(i);work.mkdir(parents=True,exist_ok=True)
 if not (work/'abc').exists():(work/'abc').symlink_to('/home/jaten/go/bin/abc')
 rr=sp.run([w/'subset_trial',ex/name],cwd=work,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',SUBSET_PRICE='observe',GOIVY_INCLUDE=str(ex/'ivy/include')),timeout=150)
 events=[];rest=bytearray()
 for l in rr.stderr.splitlines(keepends=True):
  if l.startswith(b'SUBSET '):
   _,a,b,c,yes,ok=l.decode().strip().split();assert ok=='true';events.append([a,b,c,yes])
  else:rest.extend(l)
 assert (rr.returncode,rr.stdout,rest)==(codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes()),(i,name)
 return i,name,events
with (w/'inventory.csv').open('w') as f, concurrent.futures.ThreadPoolExecutor(4) as pool:
 out=csv.writer(f);out.writerow('case name selector base selected proved'.split())
 for i,name,events in pool.map(run,enumerate(cases,1)):
  for event in events or [['none',0,0,'false']]:out.writerow([i,name,*event])
  f.flush()
