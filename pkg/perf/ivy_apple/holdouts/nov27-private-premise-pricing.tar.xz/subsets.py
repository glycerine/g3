from pathlib import Path
import tempfile,json,os,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();base=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
path=p/'api/api_verification_goal.go';s=path.read_text()
if 'import (' in s:s=s.replace('import (','import ("os";"fmt";',1)
else:s=s.replace('import ','import ("os";"fmt")\nimport ',1)
s=s.replace('func (p *orderProofState) proveRelevantPremises(','var subsetPolicy=os.Getenv("SUBSET_PRICE")\nfunc (p *orderProofState) proveRelevantPremises(')
k='if len(assertions) < 2 {';s=s.replace(k,'if subsetPolicy=="skip-all"{return false,nil};'+k,1)
k='input := append(subset, goal)';s=s.replace(k,'''label:="rare";if steps==6000{label="narrow"}else if steps==100000{label="wide"}
 if subsetPolicy=="skip-"+label{return false,nil}
 '''+k)
k='return p.checkProofPlan(m, &shortPremisePlan{source: assertions, selected: input}, steps)';s=s.replace(k,'''yes,e:=p.checkProofPlan(m,&shortPremisePlan{source:assertions,selected:input},steps)
 if subsetPolicy=="observe"{fmt.Fprintln(os.Stderr,"SUBSET",label,len(base.rows),len(subset),yes,e==nil)}
 return yes,e''');f=w/'subset_verification_goal.go';f.write_text(s);base['Replace'][str(path)]=str(f)
j=w/'subsets.json';j.write_text(json.dumps(base))
with tempfile.TemporaryDirectory(dir=Path.home()/'tmp') as t:
 sp.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'subset_trial','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=t,GOTMPDIR=t),check=True)
