import os,sys
from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'subset_run.py').read_text().replace("case=names[nr-1];","work=w/'confirmed-work'/str(nr);work.mkdir(parents=True,exist_ok=True)\n  if not (work/'abc').exists():(work/'abc').symlink_to('/home/jaten/go/bin/abc')\n  case=names[nr-1];").replace('cwd=w,env=','cwd=work,env=')
os.environ.update(EXE='subset_trial',CASES=sys.argv[1],MODES=sys.argv[2],ROUNDS=sys.argv[3],CPU=sys.argv[4],STEM=sys.argv[5]);exec(s)
