from pathlib import Path
import subprocess as sp,tempfile,concurrent.futures,os
w=Path(__file__).resolve().parent;p=Path.cwd()
def build(kind):
 regular=kind=='release';front=p/('build/.boolean-enode-cost/frontend/goivy' if regular else 'build/.boolean-enode-cost/apple-source/goivy');j=Path('/tmp/g3-ticket-first/validation/final.json' if regular else '/tmp/g3-ticket-splits/final/release-apple.json');extra=['-modfile',p/'build/.boolean-enode-cost/heap/study.mod'] if regular else []
 with tempfile.TemporaryDirectory(prefix='g3-qi-release-',dir=Path.home()/'tmp') as d:
  sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,*extra,'-o',w/kind,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOTMPDIR=d,TMPDIR=d),check=True)
with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(build,['release','apple-release']))
