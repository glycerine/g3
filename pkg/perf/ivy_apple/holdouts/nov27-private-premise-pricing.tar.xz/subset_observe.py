from pathlib import Path
import csv,os,subprocess as sp
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');cases=(ref/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
with (w/'subset_events.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case selector base selected proved'.split())
 for n in [9,7,6,2,3,8,4,10,5]:
  name=cases[n-1];d=ref/'compat'/str(n)/'1/native'
  r=sp.run([w/'subset_trial',ex/name],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',SUBSET_PRICE='observe',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),timeout=120)
  rest=bytearray()
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'SUBSET '):
    _,s,b,k,yes,ok=l.decode().split();assert ok=='true';out.writerow([n,s,b,k,yes])
   else:rest.extend(l)
  assert (r.returncode,r.stdout,rest)==(codes[name],(d/'stdout').read_bytes(),(d/'stderr').read_bytes())
  f.flush()
