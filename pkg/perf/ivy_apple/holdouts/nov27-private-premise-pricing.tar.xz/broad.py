"""Compare complete verifiers on distinct pinned CPUs with local reference checks."""
from pathlib import Path
import csv,os,subprocess as sp,concurrent.futures
w=Path(__file__).resolve().parent
def lane(i):
 env=dict(os.environ,EXE='subset_trial',CASES=' '.join(str(n) for n in range(i+1,229,4)),MODES='off skip-all' if i%2==0 else 'skip-all off',ROUNDS='1',CPU=str(32+2*i),STEM=f'broad-{i}')
 sp.run(['python3',w/'subset_run.py'],env=env,check=True)
with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(lane,range(4)))
