package api

import ("os";"fmt")
import "github.com/glycerine/g3/pkg/ast"

const (
	maxPrivateGoalWidth = 5
	maxNarrowPremises   = 32
	maxWidePremises     = 220
)

// A first push preprocesses the entire base. After proving a sibling goal,
// try a small set of original conjuncts in a separate bounded SMT context.
// A satisfiable or unknown subset leaves the full query undecided.
var subTrial=os.Getenv("SUBSET_PRICE")
func (p *orderProofState) proveRelevantPremises(m *ast.ASTManager, assertions []ast.ASTHandle) (bool, error) {
	if len(assertions) < 2 {
		return false, nil
	}
	goal := assertions[len(assertions)-1]
	hd, err := m.NodeHeader(goal)
	if err != nil || hd.Kind != ast.ASTApp || hd.NumArgs == 0 || hd.NumArgs > maxPrivateGoalWidth {
		return false, err
	}
	// A unary Boolean wrapper can hide a wide goal. Use the wrapped
	// connective's width before building indices for a private solver.
	if hd.Family == m.BasicFamilyID() && hd.NumArgs == 1 {
		remaining := 32
		_, inner, ok := (signedRefutationGoal{term: goal}).unwrap(m, &remaining)
		if ok && inner.Kind == ast.ASTApp && inner.Family == m.BasicFamilyID() &&
			(inner.DeclKind == ast.ASTOpAnd || inner.DeclKind == ast.ASTOpOr) && inner.NumArgs > maxPrivateGoalWidth {
			return false, nil
		}
	}
	ground, err := m.IsGround(goal)
	if err != nil || !ground {
		return false, err
	}
	var walk witnessSymbolWalk
	relations, ok, err := walk.collect(m, goal)
	if err != nil || !ok || len(relations) == 0 || len(relations) > 10 {
		return false, err
	}
	base, err := p.indexedPremises(m, assertions[:len(assertions)-1])
	if err != nil || base == nil {
		return false, err
	}
	defs, err := p.indexDefinitions(m, base)
	if err != nil || defs == nil {
		return false, err
	}
	walk.includeConstants = true
	symbols, ok, err := walk.collect(m, goal)
	if err != nil || !ok {
		return false, err
	}
	var earlier []ast.ASTHandle;knownSat:=false
 check := func(subset []ast.ASTHandle, steps uint32) (bool, error) {
		if len(subset) == 0 {
			return false, nil
		}
		input := append(subset, goal)
		subsetOf:=len(earlier)>0 && len(subset)<=len(earlier)
 if subsetOf{for _,a:=range subset{if !containsDeclaration(earlier,a){subsetOf=false;break}}}
 if subsetOf && (subTrial=="any" || subTrial=="sat" && knownSat){return false,nil}
 plan:=&shortPremisePlan{source:assertions,selected:input}
 yes,e:=p.checkProofPlan(m,plan,steps)
 if subTrial=="observe"{fmt.Fprintln(os.Stderr,"COVER",steps,len(base.rows),len(subset),subsetOf,knownSat,plan.trialSat,yes)}
 earlier=subset;knownSat=plan.trialSat;return yes,e
	}
	narrow := defs.selectRows(m, symbols, false, maxNarrowPremises)
	if yes, err := check(narrow, 6000); yes || err != nil || m.ResourceLimit().CancelFlag() {
		return yes, err
	}
	wideLimit := maxWidePremises
	if p.plans.reusable(m) {
		// An inconclusive search pays for both the private solver and the
		// source's first push. Require it to save a full batch of premises.
		wideLimit = min(wideLimit, len(base.rows)-maxWidePremises)
		// After the definition search has already paid for a solver check,
		// try additional constraints only if they still fit a small plan.
		if len(narrow) != 0 {
			wideLimit = min(wideLimit, maxNarrowPremises)
		}
	}
	if yes, err := check(defs.selectRows(m, symbols, true, wideLimit), 100000); yes || err != nil || m.ResourceLimit().CancelFlag() {
		return yes, err
	}
	var subset []ast.ASTHandle
	for i, row := range base.rows {
		if i%128 == 0 && m.ResourceLimit().CancelFlag() {
			return false, nil
		}
		for _, h := range row.symbols {
			// The witness index stores twice the least frequency in each row.
			if 2*base.frequency[h] <= row.threshold && containsDeclaration(relations, h) {
				subset = append(subset, row.root)
				break
			}
		}
		if len(subset) > maxNarrowPremises {
			return false, nil
		}
	}
	if len(subset)*3 > len(base.rows) {
		return false, nil
	}
	return check(subset, 5000)
}
