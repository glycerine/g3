from pathlib import Path
import tarfile,json,sys
w=Path(__file__).resolve().parent
subprefix=('abp','detail','private','subset','coverage','inventory','broad','confirm','subsumed','cover_events')
is_sub=sys.argv[1]=='premises'
dest=Path('perf/ivy_apple/holdouts')/('nov27-private-premise-pricing.tar.xz' if is_sub else 'nov27-ticket-ground-discovery.tar.xz')
paths=[f for f in sorted(w.iterdir()) if f.is_file() and not f.is_symlink() and f.suffix in ('.py','.go','.md','.csv','.json','.smt2') and (f.name.startswith(subprefix)==is_sub or f.name in ('README.md','archive.py'))]
with tarfile.open(dest,'w:xz') as tar:
 external=set()
 for f in paths:
  if f.suffix=='.json':
   for v in json.loads(f.read_text()).get('Replace',{}).values():
    p=Path(v)
    if p.parent!=w:external.add(p)
  tar.add(f,arcname=f.name)
 for f in sorted(external):tar.add(f,arcname='overlay-dependencies/'+str(f.relative_to('/tmp')))
