"""Calibrate separate unchanged-frame operations, preserving the native action order."""
from pathlib import Path
d=Path(__file__).resolve().parent
exec(compile((d/'frames.py').read_text().split("exec(compile(s,'frames','exec'))")[0],'frame-driver','exec'))
anchor='            put(k,src)\n        else:'
go=r'''
            anchor='if clk.fd!=0{defer clk.stop(0)}'
            src=edit(src,anchor,'if clk.fd!=0 && flag==0 {framePieces=true;defer func(){framePieces=false}()}')
            src=edit(src,'if e = m.SetRefHeld(r.r, h); e != nil {\n\t\t\t\treturn e\n\t\t\t}\n\t\t}\n\t\treturn r.finish(fr, false, true)','e=m.SetRefHeld(r.r,h);if framePieces{clk.op=2;clk.stop(0)};if e!=nil{return e}\n}\nreturn r.finish(fr,false,true)')
            a=src.index('func (r *rewriterEngine) finish(');b=src.index('func (r *rewriterEngine) rewritten(',a)
            f=src[a:b]
            f=edit(f,'h, e := m.RefGetHeld(r.r)','var clk frameClock;if framePieces{clk=frameStart(m,fr.curr,3,0)};h,e:=m.RefGetHeld(r.r)')
            for n,call in [(3,'shrinkRewriterRoots(m, &c.results, fr.spos)'),(4,'appendRewriterRoot(m, &c.results, h)'),(5,'r.cache(fr, h)')]:
                f=edit(f,'if e = '+call+'; e != nil {','e='+call+';if framePieces{clk.stop(0);clk=frameStart(m,fr.curr,'+str(n+1)+',0)};if e!=nil{')
            f=edit(f,'return m.ResetRefHeld(r.r)','e=m.ResetRefHeld(r.r);if framePieces{clk.stop(0)};return e')
            src=src[:a]+f+src[b:]+'\nvar framePieces bool\n'
'''
s=s.replace(anchor,go+anchor)
anchor="                    q=d/'frames.h';q.write_text(h)"
cpp=r'''
                    a=h.index('void rewriter_tpl<Config>::process_app');b=h.index('case REWRITE_BUILTIN:',a)
                    block=h[a:b]
                    block=edit(block,'finish.start(t,1,fr.m_new_child?1:0);','if(!fr.m_new_child)finish.start(t,2,0);')
                    a2=block.index('if(!fr.m_new_child)finish.start');prefix=block[:a2];part=block[a2:]
                    for n,call in [(3,'result_stack().shrink(fr.m_spos);'),(4,'result_stack().push_back(m_r);'),(5,'cache_result<ProofGen>(t, m_r, m_pr, fr.m_cache_result);'),(6,'if (ProofGen) {')]:
                        part=edit(part,call,'if(finish.fd>=0){finish.stop(0);finish.start(t,'+str(n)+',0);}'+call)
                    h=h[:a]+prefix+part+h[b:]
'''
s=s.replace(anchor,cpp+anchor)
s=s.replace("'frames.csv'","'pieces.csv'")
exec(compile(s,'pieces','exec'))
