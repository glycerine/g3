"""Measure child visits and failed no-macro completions while rewriting a queued instance."""
from pathlib import Path
import tarfile
d=Path(__file__).resolve().parent
with tarfile.open('perf/ivy_apple/holdouts/nov27-backjump-relevance-and-reductions.tar.xz') as t:
    for name in ('phase.py','reductions.py'):
        (d/name).write_bytes(t.extractfile('study/'+name).read())
driver=(d/'reductions.py').read_text().split("exec(compile(s,'reductions','exec'))")[0]
exec(compile(driver,'prepare','exec'))
a=s.index("            needle='status, err := c.reduceAppCore");b=s.index('            put(k,src)',a)
s=s[:a]+'''            src+="""
var frameHit bool
type frameClock struct{ fd uintptr; a,b int64; op,fam,kind,arity,flag int }
func frameStart(m *ast.ASTManager,t ast.ASTHandle,op,flag int)frameClock{
    if !StudyActive{return frameClock{}}
    n,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));if e!=nil{panic(e)}
    h,e:=m.NodeHeader(t);if e!=nil{panic(e)}
    c:=frameClock{fd:uintptr(n),op:op,fam:int(h.Family),kind:int(h.DeclKind),arity:int(h.NumArgs),flag:flag}
    c.a=reduceStudyRead(c.fd);c.b=reduceStudyRead(c.fd);return c
}
func(c frameClock)stop(status int){if c.fd!=0{v:=reduceStudyRead(c.fd);println("REDUCE",c.op,c.fam,c.kind,c.arity,c.flag,status,v-2*c.b+c.a)}}
"""
            put(k,src)
            k=pkg/'ast/rewriter/rewriter_engine.go'
            src=k.read_text()
            a=src.index('func (r *rewriterEngine) visit(')
            b=src.index('func (r *rewriterEngine) processVar(',a)
            sect=edit(src[a:b],'if !h.IsNull() {','if !h.IsNull() {if StudyActive{frameHit=true}')
            src=src[:a]+sect+src[b:]
            anchor='done, e := r.visit(arg, fr.maxDepth())'
            a=src.index('func (r *rewriterEngine) processApp()');src=src[:a]+src[a:].replace(anchor,'clk:=frameStart(m,t,0,0);frameHit=false;'+anchor+';status:=0;if done{status=1};if frameHit{status=2};clk.stop(status)',1)
            a=src.index('func (r *rewriterEngine) processApp()');b=src.index('func (r *rewriterEngine) processAppMacroEnd',a)
            part=src[a:b]
            anchor='} else {\\n\\t\\t\\th := t\\n\\t\\t\\tif fr.newChild()'
            part=edit(part,anchor,'} else {\\nflag:=0;if fr.newChild(){flag=1};clk:=frameStart(m,t,1,flag);if clk.fd!=0{defer clk.stop(0)}\\n h:=t\\n if fr.newChild()')
            src=src[:a]+part+src[b:]
'''+s[b:]
a=s.index("                    needle='br_status st = reduce_app_core");b=s.index("                srcfile=d/k.name",a)
s=s[:a]+'''                    hp=pkg.parent/'src/ast/rewriter/rewriter_def.h'
                    h=hp.read_text()
                    h=edit(h,'bool rewriter_tpl<Config>::visit(expr * t, unsigned max_depth) {','bool rewriter_tpl<Config>::visit(expr * t, unsigned max_depth) {')
                    h=edit(h,'expr * r = get_cached(t);\\n        if (r) {','expr * r = get_cached(t);\\n        if (r) { if(study_reduce_fd>=0)frame_hit=true;')
                    anchor='if (!visit<ProofGen>(arg, fr.m_max_depth))'
                    h=edit(h,anchor,'frame_clock clk(t,0,0);frame_hit=false;bool done=visit<ProofGen>(arg, fr.m_max_depth);clk.stop(frame_hit?2:(done?1:0));if (!done)')
                    anchor='app * new_t;'
                    a=h.index('void rewriter_tpl<Config>::process_app');b=h.index('case REWRITE_BUILTIN:',a)
                    block=h[a:b]
                    block=edit(block,anchor,'frame_clock finish;'+anchor)
                    block=edit(block,'if (fr.m_new_child) {','finish.start(t,1,fr.m_new_child?1:0);if (fr.m_new_child) {')
                    block=edit(block,'set_new_child_flag(t, m_r);\\n        m_r = nullptr;','set_new_child_flag(t, m_r);\\n        m_r = nullptr;finish.stop(0);')
                    h=h[:a]+block+h[b:]
                    q=d/'frames.h';q.write_text(h)
                    src=edit(src,'#include "ast/rewriter/rewriter_def.h"','\n'.join([]) if False else """static thread_local bool frame_hit;
struct frame_clock {
 int fd=-1,op=0,fam=0,kind=0,arity=0,flag=0;long long a=0,b=0;
 frame_clock()=default;frame_clock(app*t,int o,int f){start(t,o,f);}
 void start(app*t,int o,int f){fd=study_reduce_fd;if(fd<0)return;op=o;flag=f;fam=t->get_family_id();kind=t->get_decl_kind();arity=t->get_num_args();a=snap(fd);b=snap(fd);}
 void stop(int status){if(fd<0)return;auto v=snap(fd);fprintf(stderr,"REDUCE %d %d %d %d %d %d %lld\\\\n",op,fam,kind,arity,flag,status,v-2*b+a);}
};
"""+'#include "'+str(q)+'"')
'''.replace("'\n'.join([]) if False else ",'')+s[b:]
s=s.replace("'reductions.csv'","'frames.csv'").replace('family kind arity status calls','operation family kind arity changed status calls')
exec(compile(s,'frames','exec'))
