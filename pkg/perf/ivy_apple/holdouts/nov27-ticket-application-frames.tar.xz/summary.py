from pathlib import Path
from collections import defaultdict,Counter
from statistics import median
import csv
d=Path(__file__).resolve().parent
rows=defaultdict(lambda:defaultdict(dict))
for r in csv.DictReader((d/'frames.csv').open()):
    key=tuple(int(r[col]) for col in ('batch','goal','operation','family','kind','arity','changed','status'))
    rows[key][r['engine']][r['round']]=int(r['calls']),int(r['instructions'])
groups=defaultdict(Counter)
for key,eng in rows.items():
    values=[]
    for name in ['g3','z3']:
        samples=list(eng[name].values())
        assert not samples or len(samples)==3 and len({n for n,v in samples})==1
        values.append((samples[0][0],median(v for n,v in samples)) if samples else (0,0))
    (g,x),(z,y)=values
    mix=min(g,z)*(x/g-y/z) if g and z else 0
    for group in [(key[2],key[-2],key[-1]),(key[2],'all','all')]:
        for k,v in zip(('g3_calls','z3_calls','g3_instructions','z3_instructions','common_cost','unpaired_cost'),(g,z,x,y,mix,x-y-mix)):
            groups[group][k]+=v
with (d/'summary.csv').open('w') as out:
    w=csv.writer(out);w.writerow(['operation','changed','status',*next(iter(groups.values()))])
    for key,c in groups.items():w.writerow([*key,*[round(v) for v in c.values()]])
