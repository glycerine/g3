"""Reuse the validated node shape when the current theory substitution cannot match."""
from pathlib import Path
import tarfile
def patches(pkg):
    p=pkg/'ast/ast_expr_substitution_ops.go'
    accessor=p.read_text()+"""
// RewriterUnmappedShape reads the shape only when a live substitution
// provably has no mapping for this expression. Otherwise the caller uses
// its normal substitution lookup, including error and dependency handling.
func (m *ASTManager) RewriterUnmappedShape(s ASTExprSubstitution, h ASTHandle) (ASTKind,uint32,uint32,bool) {
    if astValidateHandles || m==nil || !m.lockFree() || h.origin!=m.origin || s.origin!=m.origin || m.lastExprSubstitution==nil || m.lastExprSubstitution.record!=s.record || h.slot==0 || h.slot>=m.nextNode {
        return 0,0,0,false
    }
    slot:=m.nodeSlotAt(h.slot)
    n:= &slot.node
    if !n.live || n.generation!=h.generation || n.kind>ASTQuantifier || n.hasFlag(astWasSubstitutionKey) {return 0,0,0,false}
    if n.kind==ASTApp{return n.kind,n.rc,slot.app.count,true}
    return n.kind,n.rc,0,true
}
"""
    q=pkg/'ast/rewriter/rewriter_engine.go'
    s=q.read_text();a=s.index('func (r *rewriterEngine) visit(');b=s.index('func (r *rewriterEngine) processVar',a)
    part=s[a:b];a0=part.index('sub, subProof');b0=part.index('cache, e :=')
    front=part[a0:b0].replace('kind, rc, n, e := m.NodeShape(t)','kind, rc, n, e = m.NodeShape(t)')
    part=part[:a0]+'''var kind ast.ASTKind
    var rc,n uint32
    var unmapped bool
    if cfg,ok:=r.cfg.(*theoryRewriterConfiguration); ok && cfg.hasSubstitution && depth!=0 {
        kind,rc,n,unmapped=m.RewriterUnmappedShape(cfg.substitution,t)
    }
    if !unmapped {
    '''+front+'}\n\t'+part[b0:]
    return [(p,accessor),(q,s[:a]+part+s[b:])]
if __name__=='__main__':
    with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:src=t.extractfile('study/notify-trials.py').read().decode()
    a=src.index('    modes=');b=src.index("        j=d/'overlay.json'",a)
    src=src[:a]+"""    modes=['base','shape']
    for mode in modes:
        for p,source in patches(pkg):
            put(p,source if mode=='shape' else p.read_text())
"""+src[b:]
    src=src.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%2:]+modes[:i%2]').replace("'notification.csv'","'shape.csv'")
    exec(compile(src,'shape','exec'))
