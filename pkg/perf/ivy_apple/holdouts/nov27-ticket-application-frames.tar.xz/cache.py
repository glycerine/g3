from pathlib import Path
import tarfile,subprocess as sp
def source(name,mode):
    s=sp.check_output(['git','show','42170d520:pkg/ast/'+name]).decode()
    if 'table' in mode and name=='ast_activity_chashtable.go':
        s=s.replace('\tusedSlots int32\n','').replace('\tt.usedSlots = 0\n','').replace('\t\t\tt.usedSlots = used\n','').replace('\t\t\t\t\tt.usedSlots--\n','')
        s=s.replace('if head.next == activityChashFree {\n\t\tt.usedSlots++\n\t} else {','if head.next != activityChashFree {')
        s=s.replace('targetSlots int32) (int32, int32)', 'targetSlots int32) int32').replace('\tused := int32(0)\n','').replace('\t\t\t\tused++\n','').replace('return -1, 0','return -1').replace('return cellar, used','return cellar').replace('next, used := t.copyTable','next := t.copyTable')
        s=s.replace('alloc(n int32)','alloc(slots, cellar int32)').replace('if s := t.spare;', 'n:=slots+cellar\n if s := t.spare;').replace('clear(cells)','clear(cells[:slots])').replace('t.alloc(slots + cellar)','t.alloc(slots,cellar)').replace('t.alloc(newSlots + newCellar)','t.alloc(newSlots,newCellar)')
    if 'same' in mode and name=='ast_activity_cache.go':
        s=s.replace('if !v.IsNull() {\n\t\t\tvalueNode = m.activityOperand(v)','if k==v {valueNode=keyNode} else if !v.IsNull() {\n\t\t\tvalueNode = m.activityOperand(v)')
    return s
if __name__=='__main__':
    with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
    a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
    s=s[:a]+"""    modes=['base','table','same','table-same']
    for mode in modes:
        for name in ['ast_activity_chashtable.go','ast_activity_cache.go']:
            put(pkg/'ast'/name,source(name,mode))
"""+s[b:]
    exec(compile(s.replace("'notification.csv'","'cache.csv'"),'cache','exec'))
