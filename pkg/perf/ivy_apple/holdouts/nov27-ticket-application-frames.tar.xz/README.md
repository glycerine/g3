Ticket application-frame profiles and release experiments on 42170d520

Extract the archive into a scratch directory. Run its Python drivers from the repository pkg directory. Use the same GoIvy frontend, modfile, reference outputs, examples and CPU environment as the seven-check study and the November 27 backjump study. phase.py and reductions.py are automatically extracted by frames.py from the latter archive. The native build uses this repository's C++ tree.

Run frames.py then summary.py for the child-entry and failed-reduction table. Run pieces.py for unchanged-completion operations 2 through 6. To summarize pieces.csv with summary.py, substitute pieces.csv and pieces-summary.csv for its input and output filenames. Run shape.py and cache.py for the uninstrumented alternating trials. Case 4 selects ARM and case 8 selects automatic Ticket. Sum each round's goal instructions within case and mode, then take the median. Raw counters and both summaries are included.
