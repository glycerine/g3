"""Estimate disjoint call-path costs in the ordinary solver's eight Ticket checks."""
from pathlib import Path
import collections,csv,statistics
w=Path(__file__).resolve().parent
counts=collections.defaultdict(collections.Counter)
for r in csv.DictReader((w/'sample-stacks.csv').open()):
    e=r['engine']; stack=r['stack']
    go=e=='g3';p=int(r['period'])*int(r['samples'])
    in_entry=('(*SMTQuantifierManager).instantiate\n' if go else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)') in stack
    tests=([
        ('substitution','(*SMTCachedVarSubstitution).Instantiate'),
        ('theory rewrite','(*TheoryRewriter).Rewrite'),
        ('assertion','(*SMTInternalizerState).assertExpression'),
        ('checker','(*SMTChecker).run'),
        ('lemma assembly','(*SMTQIInstanceBuilder).finish'),
    ] if go else [
        ('substitution','cached_var_subst::operator()'),
        ('theory rewrite','rewriter_tpl<th_rewriter_cfg>'),
        ('theory rewrite','th_rewriter::operator()'),
        ('assertion','smt::context::internalize_assertion'),
        ('checker','smt::checker::is_sat'),
    ])
    phase='outside queue entry'
    if in_entry:
        phase=next((name for name,s in tests if s in stack),'other queue entry')
    counts[e,int(r['round'])][phase]+=p
rounds=len(set(i for e,i in counts))
for phase in sorted({k for c in counts.values() for k in c}):
    vals=[sum(counts[e,i][phase] for i in range(rounds))/rounds/1e6 for e in ['g3','z3']]
    print(phase,*[round(n,2) for n in [*vals,vals[0]-vals[1]]])
for e in ['g3','z3']:
    print(e,'total',sum(sum(counts[e,i].values()) for i in range(rounds))/rounds/1e6)
