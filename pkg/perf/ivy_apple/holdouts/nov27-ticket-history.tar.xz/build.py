from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent
p=Path.cwd()
base=Path(sys.argv[1]).resolve()
frontend=Path(sys.argv[2]).resolve()
mod=Path(sys.argv[3]).resolve()
observers=Path(sys.argv[4]).resolve()
for name in sys.argv[5:] or ('observed', 'concrete', 'concrete-observed', 'ordinary', 'ordinary-observed'):
    files=json.loads((base/'overlay.json').read_text())['Replace']
    if 'observed' in name:
        original=json.loads((observers/'all-g3.json').read_text())['Replace']
        files.update({k:v for k,v in original.items() if Path(k).parent==p/'smtcore'})
        assert len(files)==7
    if name != 'observed':
        src=base/'z3bridge_solver_model.go'
        key='batchCheck, proveGoal, release = z3solver.BeginVerificationGoalBatch(len(finalCond))'
        s=src.read_text()
        assert s.count(key)==1
        dest=w/(name+'.go.txt')
        if 'ordinary' in name:
            assert s.count('finalCheck := check')==1
            s=s.replace('finalCheck := check','finalCheck := check; finalCheck = z3solver.Check')
        if 'raw' in name:
            assert s.count('zCond = z3solver.SimplifyVerificationCondition(zCond)')==1
            s=s.replace('zCond = z3solver.SimplifyVerificationCondition(zCond)','// Trial: submit original goal')
        if 'ordinary' in name or 'concrete' in name:
            s=s.replace(key,key+'\n                proveGoal = nil')
        dest.write_text(s)
        files[str(frontend/src.name)]=str(dest)
    out=w/(name+'.json')
    out.write_text(json.dumps({'Replace':files}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',out,'-o',w/name,'./cmd/goivy_check'],cwd=frontend,check=True)
