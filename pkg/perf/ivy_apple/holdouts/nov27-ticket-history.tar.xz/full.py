"""Build full verifiers with independent pre-push and post-push proof controls."""
from pathlib import Path
import sys,json,subprocess
w=Path(__file__).resolve().parent
f=Path(sys.argv[1]).resolve();mod=Path(sys.argv[2]).resolve()
k=f/'z3bridge_solver_model.go'
for name in sys.argv[3:] or ('early-only','post-only','ordinary-full'):
    s=k.read_text()
    if not name.endswith('post-only'):
        key='finalCheck := check'
        assert s.count(key)==1
        s=s.replace(key,key+'; finalCheck = z3solver.Check')
    if not name.endswith('early-only'):
        key='batchCheck, proveGoal, release = z3solver.BeginVerificationGoalBatch(len(finalCond))'
        assert s.count(key)==1
        s=s.replace(key,key+'; proveGoal = nil')
    d=w/(name+'.go.txt'); d.write_text(s)
    o=w/(name+'.json'); o.write_text(json.dumps({'Replace':{str(k):str(d)}}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/name,'./cmd/goivy_check'],cwd=f,check=True)
