"""Rank phase costs and compare ordered Ticket search traces across backends."""
import collections,csv,re,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
targets=[(b,g) for b in range(2,6) for g in (55,56)]
def rows(name):
    with (w/name).open() as f: return list(csv.DictReader(f))
for name in ('stock','z3','concrete','ordinary','raw','ordinary-raw'):
    rounds=collections.defaultdict(collections.Counter)
    for r in rows(name+'-counts.csv'):
        b,g=int(r['batch']),int(r['goal'])
        n=int(r['instructions'])
        c=rounds[int(r['round'])]
        c['all']+=n
        if r['phase']=='check':
            c['checks']+=1
            c['check']+=n
            if (b,g) in targets: c['eight']+=n;c[b,g]+=n
    # Every complete run ends with the same set of bracketed phases.
    totals=collections.Counter(int(r['round']) for r in rows(name+'-counts.csv'))
    assert len(set(totals.values()))==1
    print(name,len(rounds),*[round(statistics.median(c[k] for c in rounds.values())/(1 if k=='checks' else 1e6),2) for k in ['checks','all','check','eight',*targets]])
def sequence(label):
    out=collections.defaultdict(list)
    for r in rows(label+'-search-events.csv'):
        v=r['value']
        if r['event']=='split': v=v.split(' ',1)[1]
        if r['event']=='offer': v=v.split(' ',2)[2]
        out[int(r['batch']),int(r['goal']),r['event']].append(v)
    return out
def alpha(seq):
    ids={}
    return [re.sub(r'([^()\s!]+)!\d+(?=[()\s]|$)',lambda m:m[1]+'!@'+str(ids.setdefault(m[0],len(ids))),s) for s in seq]
def prefix(x,y):
    return next((i for i,(a,b) in enumerate(zip(alpha(x),alpha(y))) if a!=b),min(len(x),len(y)))
g,z,o=map(sequence,('g3','z3','ordinary'))
with (w/'search-summary.csv').open('w') as f:
    table=csv.writer(f)
    table.writerow(('batch','goal','event','g3','z3','ordinary','g3_z3_prefix','ordinary_z3_prefix'))
    for b,i in targets:
        for event in ('formula','split','offer','candidate'):
            key=(b,i,event)
            x,y,raw=g[key],z[key],o[key]
            table.writerow((b,i,event,len(x),len(y),len(raw),prefix(x,y),prefix(raw,y)))
