"""Try reusing the cached application sort for general GetSort and slice registration."""
import json,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd()
front,mod=map(lambda a:Path(a).resolve(),sys.argv[1:3])
files={}
for name in ('sort','operands'):
    if name=='sort':
        src=p/'ast/ast_core_accessors.go'
        key='func (m *ASTManager) GetSort(h ASTHandle) (ASTHandle, error) {'
        s=src.read_text();assert s.count(key)==1
        s=s.replace(key,key+'''
    if !ASTSourceDebug && m.fastHandle(h) {
        slot := m.nodeSlotAt(h.slot)
        if slot.node.kind == ASTApp && slot.app.rangeSort.slot != 0 {
            return m.external(slot.app.rangeSort), nil
        }
    }''')
    else:
        src=p/'ast/ast_app_slice.go'
        s=src.read_text();assert s.count('appSliceSortsMatch(domain, associative, input)')==2
        s=s.replace('appSliceSortsMatch(domain, associative, input)','appSliceSortsMatch(domain, associative, input, operands[:len(input)])')
        key='appSliceSortsMatch(decl *astFuncDeclRecord, associative bool, input []ASTHandle)'
        assert s.count(key)==1
        s=s.replace(key,key[:-1]+', operands []*astNodeSlot)').replace('switch m.nodeAt(h.slot).kind {','switch operands[i].node.kind {').replace('sort = m.appAt(h.slot).rangeSort','sort = operands[i].app.rangeSort')
    dest=w/(name+'.go.txt');dest.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    files[str(src)]=str(dest)
    o=w/(name+'.json');o.write_text(json.dumps({'Replace':files}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',o,'-o',w/(name+'-cli'),'./cmd/g3'],check=True)
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/(name+'-ivy'),'./cmd/goivy_check'],cwd=front,check=True)
