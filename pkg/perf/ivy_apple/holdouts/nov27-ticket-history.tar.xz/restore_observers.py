"""Recreate the search observer overlays from this fork and a pinned GoIvy build."""
import json,re,shlex,shutil,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
p=Path.cwd()
f,mod,base=map(lambda s:Path(s).resolve(),sys.argv[1:4])
def patched(source,patch):
    target=w/('wt-'+source.name)
    target.write_bytes(source.read_bytes())
    subprocess.run(['patch','--fuzz=0',target],input=patch.read_bytes(),check=True)
    return target
files={}
for patch in sorted((w/'patches').glob('*.go.patch')):
    src=p/'smtcore'/patch.name.removesuffix('.patch')
    files[str(src)]=str(patched(src,patch))
(w/'all-g3.json').write_text(json.dumps({'Replace':files}))
build=p.parent/'build'
flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
lib=w/'lib-ticket-observer.a';shutil.copyfile(f/'z3vendor/native_lib/libz3.a',lib)
for patch in sorted((w/'patches').glob('*.cpp.patch')):
    src=p.parent/'src/smt'/patch.name.removesuffix('.patch')
    dest=patched(src,patch);obj=w/(src.stem+'.o')
    subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dest],cwd=build,check=True)
    subprocess.run(['ar','r',lib,obj],check=True)
k=f/'smt/quantifier.go';dest=w/'native-quantifier.go';key='${SRCDIR}/../z3vendor/native_lib/libz3.a'
s=k.read_text();assert key in s;dest.write_text(s.replace(key,str(lib)))
files=json.loads((base/'overlay.json').read_text())['Replace'];files[str(k)]=str(dest)
ov=w/'native-observed.json';ov.write_text(json.dumps({'Replace':files}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off,classic_z3','-overlay',ov,'-o',w/'native-observed','./cmd/goivy_check'],cwd=f,check=True)
