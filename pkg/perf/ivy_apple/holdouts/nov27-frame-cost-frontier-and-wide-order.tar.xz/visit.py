"""Build a concrete proof-free theory visitor, preserving scoped cache and substitution behavior."""
from pathlib import Path
import sys,json,csv,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();src=p/'ast/rewriter/rewriter_engine.go';s=src.read_text().replace('import (','import (\n"os"',1)
s=s.replace('skipResumeCacheProbe     bool','skipResumeCacheProbe     bool\n studyTheory *theoryRewriterConfiguration')
s=s.replace('_, theory := cfg.(*theoryRewriterConfiguration)','concrete,theory := cfg.(*theoryRewriterConfiguration); if studyVisit && !proofGen && !ast.ASTValidateHandles && !ast.ASTSourceDebug {r.studyTheory=concrete}')
key='if r.substituteVariables {\n\t\treturn r.visitSubstitution(t, depth)';assert s.count(key)==1
s=s.replace(key,'if r.studyTheory!=nil{return r.studyTheoryVisit(t,depth)}\n '+key)
s+='''
var studyVisit=os.Getenv("ACTION_SCOPE")=="special"
func (r *rewriterEngine) studyTheoryVisit(t ast.ASTHandle, depth uint32)(bool,error){
 c:=&r.core;m:=c.manager;cfg:=r.studyTheory
 if cfg.hasSubstitution {
  sub,_,found,e:=cfg.GetSubst(t);if e!=nil{return false,e}
  if found {if e=appendRewriterRoot(m,&c.results,sub);e!=nil{return false,e};return true,r.setNewChildIfDifferent(t,sub)}
 }
 if depth==0{return true,appendRewriterRoot(m,&c.results,t)}
 kind,rc,arity,err:=m.NodeShape(t);if err!=nil{return false,err}
 cache:=(cfg.cacheAll || rc>1) && t!=c.root && (kind==ast.ASTQuantifier || kind==ast.ASTApp && arity>0)
 if cache {
   h,e:=c.getCached(t);if e!=nil{return false,e};if !h.IsNull(){
    if e=appendRewriterRoot(m,&c.results,h);e!=nil{return false,e};return true,r.setNewChildIfDifferent(t,h)
   }
 }
 switch kind{
 case ast.ASTVar:
  if len(r.bindings)==0{return true,appendRewriterRoot(m,&c.results,t)}
  idx,e:=m.GetVarIndex(t);if e!=nil{return false,e};return true,r.processBoundVariable(t,idx)
 case ast.ASTApp: if arity==0{return true,r.processConst(t)}
 case ast.ASTQuantifier:
 default:return false,ast.ErrASTDomain
 }
 if depth!=3{depth--};return false,c.pushFrameCore(t,cache,0,depth,kind,arity)
}
'''
dst=w/'visit.go.txt';dst.write_text(s);o=w/'visit.json';o.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
exe=w/'visit'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
d=w/'visit_compare.py';d.write_text((w/'compare.py').read_text().replace('exe=w/m',"exe=w/'visit'"))
names=list(dict.fromkeys(r['case'] for r in csv.DictReader(Path('/tmp/g3-ticket-operand-price/seed0_base_draw1.csv').open())))
subprocess.run([sys.executable,d,'visit_base_special','14','7',*names],check=True)
