"""Extract complete goals from the native frontend and compare actual solver search statistics."""
from pathlib import Path
import csv,subprocess,os,re,time
w=Path(__file__).resolve().parent;p=Path.cwd();ex=Path('/home/jaten/ivy/ivy-lang-examples');survey=Path('/tmp/g3-reduction-rows');h=Path('/tmp/g3-ticket-stages')
cases=(survey/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((survey/'ranking.csv').open())}
samples={'test/arm_rules3.ivy':['6/5','6/6','8/1'],'examples/ivy/indexset_test.ivy':['3/9','3/10'],'examples/ivy/card2.ivy':['3/9'],'examples/ivy/card3.ivy':['3/9'],'doc/examples/leader_election_ring.ivy':['3/3'],'doc/examples/leader_election_ring_btw.ivy':['3/3']}
fx=w/'held-fixtures';fx.mkdir(exist_ok=True)
for name,goals in samples.items():
 ref=survey/'compat'/str(cases.index(name)+1)/'1/native'
 r=subprocess.run(['taskset','-c','20',h/'dump-native',ex/name],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TICKET_DIR=str(fx),TICKET_TARGETS=','+','.join(goals)+',',TICKET_CASE=Path(name).stem))
 assert (r.returncode,r.stdout,r.stderr)==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),name
fixtures = sorted(fx/(Path(name).stem+'-'+goal.replace('/', '-')+'.smt2') for name, goals in samples.items() for goal in goals)
assert len(fixtures)==9 and all(f.is_file() for f in fixtures)
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf';keys=['decisions','conflicts','quant-instantiations','rlimit-count']
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-o',w/'cli','./cmd/g3'],check=True)
with (w/'held-replay.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['fixture','round','engine','answer','instructions','ms',*keys])
 for i in range(5):
  for src in fixtures:
   for e in ['g3','z3'][::1 if not i%2 else -1]:
    stat=w/'held.stat';exe=w/'cli' if e=='g3' else p.parent/'build/z3';t=time.monotonic()
    r=subprocess.run(['taskset','-c','20',perf,'stat','-x,','-o',stat,'-e','instructions:u','--',exe,'-in','-smt2'],input=src.read_bytes(),env=dict(os.environ,GOMAXPROCS='1',GOGC='off'),capture_output=True,timeout=90,check=True)
    ms=1000*(time.monotonic()-t);answer=r.stdout.splitlines()[0].decode();assert answer in ('sat','unsat','unknown') and not r.stderr
    vals=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()));ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([src.stem,i,e,answer,ins,round(ms,2),*[int(vals.get(k,0)) for k in keys]]);f.flush()
