"""Test source-independent admission learned only from this solver's preceding attempts."""
from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();k=p/'api/api_order_abstraction.go';s=k.read_text().replace('import (','import (\n"os"',1)
s=s.replace('type orderProofState struct {','type orderProofState struct {\n studyWins map[uint64]uint8\n studyMiss map[uint64]uint8\n studyEarlyWins uint32')
key='proved, err = p.proveAssertions(parent, assertions, maxSteps, reuse)'
assert s.count(key)==1;s=s.replace(key,'''if reuse && len(assertions)>0 && studyMode!="base" && studyMode!=""{
 h:=studyShape(parent,assertions[len(assertions)-1],2)
 if h!=0 {
  if !goal.IsNull(){
   if (studyMode=="early"||studyMode=="both") && p.studyEarlyWins>=2 && p.studyWins[h]==0{return false,nil}
   defer func(){if proved && err==nil{if p.studyWins==nil{p.studyWins=make(map[uint64]uint8)};p.studyWins[h]=1;p.studyEarlyWins++}}()
  }else if studyMode=="post"||studyMode=="both" {
   if p.studyMiss==nil{p.studyMiss=make(map[uint64]uint8)}
   if v:=p.studyMiss[h];v>=2 && v<6 {p.studyMiss[h]++;return false,nil}
   defer func(){if err==nil{if proved{p.studyMiss[h]=0}else if p.studyMiss[h]>=6{p.studyMiss[h]=2}else{p.studyMiss[h]++}}}()
  }
 }
 }
 '''+key)
s+='''
var studyMode=os.Getenv("ACTION_SCOPE")
func studyShape(m *ast.ASTManager,t ast.ASTHandle,depth int) uint64 {
 hd,err:=m.NodeHeader(t);if err!=nil{return 0}
 h:=uint64(hd.Kind)+31*(uint64(uint32(hd.Family))+37*uint64(uint32(hd.DeclKind)))+43*uint64(hd.NumArgs)+1
 if depth==0{return h};if hd.Kind==ast.ASTQuantifier{v,e:=m.GetQuantifierBody(t);if e!=nil{return 0};return h*16777619+studyShape(m,v,depth-1)}
 for i:=uint32(0);i<min(hd.NumArgs,3);i++{v,e:=m.GetArg(t,i);if e!=nil{return 0};h=h*16777619+studyShape(m,v,depth-1)}
 return h
}
'''
dst=w/'shape.go.txt';dst.write_text(s);o=w/'shape.json';o.write_text(json.dumps({'Replace':{str(k):str(dst)}}))
exe=w/'shape';subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
import csv
names=list(dict.fromkeys(r['case'] for r in csv.DictReader(Path('/tmp/g3-ticket-operand-price/seed0_base_draw1.csv').open())))
names+=['test/arm_rules3.ivy','test/flash2.ivy','examples/liveness/split_queue_2_new.ivy']
d=w/'shape_compare.py';d.write_text((w/'compare.py').read_text().replace('exe=w/m',"exe=w/'shape'"))
procs=[subprocess.Popen([sys.executable,d,f'shape{i}_base_early_post_both',str(cpu),'5',*names[i::2]]) for i,cpu in enumerate([2,16])]
assert [j.wait() for j in procs]==[0,0]
