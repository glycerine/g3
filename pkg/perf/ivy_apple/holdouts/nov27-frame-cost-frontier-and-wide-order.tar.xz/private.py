"""Disaggregate unsuccessful post-push certificates from ordinary SMT checks."""
from pathlib import Path
import json,csv,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();h=Path('/tmp/g3-ticket-stages')
ov=json.loads((h/'translated.json').read_text())
k=f/'smt/g3_solver.go';s=k.read_text();key='if proved, err := prove(); err == nil && proved {'
assert s.count(key)==1;s=s.replace(key,'''end:=func(bool){};if StudyBegin!=nil{end=StudyBegin()};proved,err:=prove();end(proved && err==nil);if err==nil && proved {''')+'\nvar StudyBegin func()func(bool)\n'
def emit(k,s):
 dst=w/('private-'+k.name+'.txt');dst.write_text(s);ov['Replace'][str(k)]=str(dst)
emit(k,s)
k=f/'z3bridge_solver_model.go';s=(h/'translated.go.txt').read_text()
key='res, err := s.decideZ3With(z3solver, finalCheck)'
assert s.count(key)==1;s=s.replace(key,'''smt.StudyBegin=func()func(bool){finish:=startStage(batch,ordinal+1);return func(ok bool){if ok{finish("post-success")}else{finish("post-miss")}}}
 '''+key+'''
 smt.StudyBegin=nil''')
emit(k,s);o=w/'private.json';o.write_text(json.dumps(ov));exe=w/'private'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
src=(w/'frontier.py').read_text();a=src.index("src=Path('/tmp/g3-reduction-rows')");src='from pathlib import Path\nimport csv,subprocess,concurrent.futures,os\nw=Path(__file__).resolve().parent\n'+src[a:]
src=src.replace("['g3','native']","['g3']").replace("('g3','native')[::1 if (i+ix)%2==0 else -1]","['g3']").replace("w/'stage-g3' if e=='g3' else h/'translated-native'","w/'private'").replace("f'frontier","f'cert").replace('[2,4,14,20]','[3,5,15,21]')
d=w/'private_run.py';d.write_text(src);subprocess.run([sys.executable,d],check=True)
