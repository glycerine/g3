from pathlib import Path
import csv,collections,statistics as s
w=Path(__file__).resolve().parent
data=collections.defaultdict(lambda: [0,0])
counts=collections.defaultdict(dict)
for r in csv.DictReader((w/'meter/calls.csv').open()):
 q,e,i,k=r['query'],r['engine'],r['round'],int(r['op'])
 key=q,e,i,k
 n=int(r['calls']);data[key][0]+=n;data[key][1]+=int(r['raw'])-n*int(r['blank16'])/16
 counts[q,i,k,int(r['instance'])][e]=n
with (w/'prices.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['fixture','op','g3_calls','native_calls','g3_instructions','native_instructions','mismatched_instance_rounds'])
 for q in sorted({k[0] for k in data}):
  for k in range(1,7):
   a=[data[q,'g3',i,k] for i in ['1','2','3']];b=[data[q,'z3',i,k] for i in ['1','2','3']]
   diff=sum(v.get('z3',0)!=v.get('g3',0) for (query,_,op,_),v in counts.items() if query==q and k==op)
   row=[q,k,a[0][0],b[0][0],round(s.median(v[1] for v in a)),round(s.median(v[1] for v in b)),diff];out.writerow(row);print(*row)
