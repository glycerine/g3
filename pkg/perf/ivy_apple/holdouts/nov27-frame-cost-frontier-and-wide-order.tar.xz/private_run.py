from pathlib import Path
import csv,subprocess,concurrent.futures,os
w=Path(__file__).resolve().parent
src=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
cases=(src/'compat.txt').read_text().splitlines()
names=[r for r in csv.DictReader((src/'ranking.csv').open()) if r['exact']=='True' and r['proof']=='True' and (float(r['excess_instructions'])>0 or float(r['excess_seconds'])>0)]
def group(item):
 ix,cpu=item
 with (w/f'cert{ix}.csv').open('w') as fo,(w/f'cert-status{ix}.csv').open('w') as fs:
  out=csv.writer(fo);out.writerow(['case','engine','round','batch','goal','stage','instructions'])
  status=csv.writer(fs);status.writerow(['case','engine','round','status','stage_count'])
  for row in names[ix::4]:
   name=row['case'];ref=src/'compat'/str(cases.index(name)+1)/'1/native'
   for i in range(3):
    for e in ['g3']:
     exe=w/'private'
     r=subprocess.run(['taskset','-c',str(cpu),exe,ex/name],cwd=w,capture_output=True,timeout=180,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
     raw=[];vals=[]
     for line in r.stderr.splitlines(keepends=True):
      if line.startswith(b'STAGE-COUNT '):
       _,b,g,s,n,empty,en,active,ns=line.decode().split();assert en==active;vals.append([name,e,i,b,g,s,n])
      else:raw.append(line)
     exact=(r.returncode,r.stdout,b''.join(raw))==(int(row['exit']),(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
     status.writerow([name,e,i,'match' if exact else 'different',len(vals)]);fs.flush()
     if exact:out.writerows(vals);fo.flush()
     else:(w/f'cert{ix}-{e}.stderr').write_bytes(b''.join(raw))
with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(group,enumerate([3,5,15,21])))
