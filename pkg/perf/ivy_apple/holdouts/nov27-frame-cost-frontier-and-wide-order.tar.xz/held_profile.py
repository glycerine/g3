"""Sample independent matched-search obligations and the complete verifiers that produced them."""
from pathlib import Path
import csv,collections,os,re,subprocess,statistics
w=Path(__file__).resolve().parent;p=Path.cwd();ex=Path('/home/jaten/ivy/ivy-lang-examples');survey=Path('/tmp/g3-reduction-rows')
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf';env=dict(os.environ,GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),DEBUGINFOD_URLS='')
specs=['test/arm_rules3.ivy','examples/ivy/card3.ivy'];fixtures=['arm_rules3-6-5','arm_rules3-6-6','card3-3-9']
cases=(survey/'compat.txt').read_text().splitlines()
keys=['decisions','conflicts','quant-instantiations','rlimit-count'];stats={r['fixture']:r for r in csv.DictReader((w/'held-replay.csv').open()) if r['engine']=='z3'}
def group(s,g):
 if ('(*SMTModelChecker).checkQuantifier' if g else 'smt::model_checker::check(quantifier*)') in s:return 'MBQI quantifier check'
 if (any(n in s for n in ['(*SMTQuantifierManager).instantiate','(*SMTQuantifierManager).Propagate.func1','(*SMTQIInstanceBuilder).MaterializeAndInternalize']) if g else 'smt::qi_queue::instantiate(smt::qi_queue::entry&)' in s):
  for name,ng,nn in [('instance substitution','(*SMTCachedVarSubstitution).Instantiate','cached_var_subst::operator()'),('instance assertion','(*SMTInternalizerState).assertExpression','smt::context::internalize_assertion'),('instance rewrite','(*rewriterEngine).Rewrite','rewriter_tpl<th_rewriter_cfg>'),('instance checker','(*SMTChecker).run','smt::checker::is_sat')]:
   if (ng if g else nn) in s:return name
  return 'other instance work'
 if ('(*SMTKernel).internalizePending' if g else 'smt::context::internalize_assertions') in s:return 'assertion installation'
 if ('(*SMTKernel).boundedSearch' if g else 'smt::context::bounded_search') in s:return 'other SMT search'
 return 'other'
with (w/'held-profile.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','round','engine','category','samples','instructions'])
 for i in range(3):
  for name in [*specs,*fixtures]:
   cli=name not in specs
   for e in ('g3','native')[::1 if not i%2 else -1]:
    g=e=='g3'
    exe=(w/'cli' if g else p.parent/'build/z3') if cli else (w/'base' if g else Path('/tmp/g3-flash-marginal/abc-control/native'))
    args=['-in','-smt2'] if cli else [ex/name];data=w/'held.data';period=500003+100*i
    r=subprocess.run(['taskset','-c','22',perf,'record','-B','-N','-q','-e','instructions:u','-c',str(period),'--call-graph',('fp,48' if g else 'dwarf,8192'),'-o',data,exe,*args],cwd=w,env=env,input=(w/'held-fixtures'/(name+'.smt2')).read_bytes() if cli else None,capture_output=True)
    if cli:
     vals=dict(re.findall(r':([\w-]+)\s+(\d+)\b',r.stdout.decode()))
     assert r.returncode==0 and r.stdout.startswith(b'unsat\n') and not r.stderr and all(int(vals.get(k,0))==int(stats[name][k]) for k in keys)
    else:
     ref=survey/'compat'/str(cases.index(name)+1)/'1/native'
     assert (r.returncode,r.stdout,r.stderr)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
    raw=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',data],env=env,text=True)
    tally=collections.Counter()
    for sample in raw.strip().split('\n\n'):
     if len(sample.splitlines())>1:tally[group(sample,g)]+=1
    for label,n in tally.items():out.writerow([name,i,e,label,n,n*period]);f.flush()
