"""Build release and compare the two complete ring verifiers plus independent controls."""
from pathlib import Path
import csv,subprocess,sys,json
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
build=['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')]
subprocess.run([*build,'-o',w/'cycle','./cmd/goivy_check'],cwd=f,check=True)
d=w/'cycle_driver.py';s=(w/'compare.py').read_text().replace('exe=w/m',"exe=(Path('/tmp/g3-flash-marginal/abc-control/native') if m=='native' else w/m)");d.write_text(s)
cases=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines();names=[n for n in cases if 'leader_election_ring' in n]
jobs=[subprocess.Popen([sys.executable,d,'ring_base_cycle_native','4','11',*names])]
for i,cpu in enumerate([2,14,16,20]):
 jobs.append(subprocess.Popen([sys.executable,d,f'cycle{i}_base_cycle',str(cpu),'3',*cases[i::4]]))
assert [j.wait() for j in jobs]==[0]*len(jobs)
