from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
s=(w/'shape_long.py').read_text();a=s.index("subprocess.run(['go','build'");b=s.index("ex=Path(",a)
s=s[:a]+'''flags=['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')]
subprocess.run([*flags,'-o',w/'cycle-apple','./cmd/goivy_check'],cwd=f,check=True)
'''+s[b:]
s=s.replace("('long-'+name","('verified-'+name").replace("('base','early')","('base','cycle')").replace("stat=w/('verified-'+name+'.stat');cmd=",'''exe=(Path('/tmp/g3-reduction-rows/apple') if mode=='base' else w/'cycle-apple') if apple else w/mode
    stat=w/('verified-'+name+'.stat');cmd=''')
d=w/'cycle_long_run.py';d.write_text(s);subprocess.run([sys.executable,d],check=True)
