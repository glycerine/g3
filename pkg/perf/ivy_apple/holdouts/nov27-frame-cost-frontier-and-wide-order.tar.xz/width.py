from pathlib import Path
import subprocess,csv,os,time
w=Path(__file__).resolve().parent;p=Path.cwd();ex=Path('/home/jaten/ivy/ivy-lang-examples');src=ex/'doc/examples/leader_election_ring.ivy'
base=src.read_text();assert base.count('bv[64]')==1
tmp=w/'widths';tmp.mkdir(exist_ok=True);perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'width-sweep.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['width','round','engine','status','instructions','ms'])
 for width in [2,4,8,16,32,64,128]:
  dest=tmp/f'ring{width}.ivy';dest.write_text(base.replace('bv[64]',f'bv[{width}]'))
  gold=None
  for i in range(5):
   modes=['native','base','cycle'];modes=modes[i%3:]+modes[:i%3]
   for mode in modes:
    exe=Path('/tmp/g3-flash-marginal/abc-control/native') if mode=='native' else w/mode
    stat=w/'width.stat';t=time.monotonic()
    r=subprocess.run(['taskset','-c','18',perf,'stat','-x,','-o',stat,'-e','instructions:u','--',exe,dest],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=120)
    ms=1000*(time.monotonic()-t);actual=(r.returncode,r.stdout,r.stderr)
    if gold is None:
     assert r.returncode==1 and b'PASS' in r.stdout and b'failed checks: 1' in r.stderr,r.stderr[:500]
     gold=actual
    assert gold==actual,(width,mode);ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([width,i,mode,'match',ins,round(ms,2)]);f.flush()
