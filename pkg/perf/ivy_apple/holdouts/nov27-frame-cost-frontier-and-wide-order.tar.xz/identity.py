"""Recognize ordinary non-ITE parents using cached AST identity; retain exact checked fallback."""
from pathlib import Path
import subprocess,json,sys,csv,os
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov={}
def put(k,s):
 d=w/('identity-'+k.name+'.txt');d.write_text(s);ov[str(k)]=str(d)
k=p/'ast/ast_rewriter_access.go';s=k.read_text()+'''
// RewriterMayBeITE returns false only for an already classified application
// whose declaration cannot select an ITE branch.
func (m *ASTManager) RewriterMayBeITE(t ASTHandle) bool {
 if ASTSourceDebug || !m.fastHandle(t){return true}
 a:=m.appAt(t.slot)
 return !a.declCached || a.declFamily==m.BasicFamilyID() && a.declKind==ASTOpIte
}
''';put(k,s)
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text().replace('import (','import (\n"os"',1);key='if i == 1 || i > 0 && r.modelBooleanShortCircuit {'
assert s.count(key)==1;s=s.replace(key,'if i == 1 && (!studyIdentity || m.RewriterMayBeITE(t)) || i > 0 && r.modelBooleanShortCircuit {')+'\nvar studyIdentity=os.Getenv("ACTION_SCOPE")=="identity"\n';put(k,s)
o=w/'identity.json';o.write_text(json.dumps({'Replace':ov}));exe=w/'identity'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
d=w/'identity_compare.py';d.write_text((w/'compare.py').read_text().replace('exe=w/m',"exe=w/'identity'"))
names=list(dict.fromkeys(r['case'] for r in csv.DictReader(Path('/tmp/g3-ticket-operand-price/seed0_base_draw1.csv').open())))
subprocess.run([sys.executable,d,'identity_base_identity','16','7',*names],check=True)
