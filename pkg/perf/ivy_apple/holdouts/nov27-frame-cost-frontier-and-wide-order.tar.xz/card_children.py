"""Attribute card3 3/9 samples to frames immediately below the quantifier checker."""
import collections,csv,os,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent; perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'card-children.csv').open('w') as f:
 out=csv.writer(f);out.writerow(('record','child','samples'))
 for name in ['held.data','held.data.old']:
  s=subprocess.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',w/name],env=dict(os.environ,DEBUGINFOD_URLS=''),text=True)
  tally=collections.Counter()
  for sample in s.strip().split('\n\n'):
   frames=sample.splitlines()[1:]
   for i,frame in enumerate(frames):
    if 'smt::model_checker::check(quantifier*)' in frame or '(*SMTModelChecker).auxiliaryCounterexamples' in frame and '.func' not in frame:
     tally[(frames[i-1] if i else frame).strip().split(' ',1)[-1].split('+0x')[0]]+=1
     sub=frames[:i]
     if any('(*SMTSolver).CheckSat' in t or 'smt::context::check(unsigned int' in t for t in sub):
      category='other'
      for label,go,native in [('install','(*SMTKernel).internalizePending','smt::context::internalize_assertions'),('search','(*SMTKernel).boundedSearch','smt::context::bounded_search'),('prepare','(*SMTKernel).setup','smt::context::setup'),('model','(*SMTKernel).','smt::context::mk_model')]:
       if label=='model':go='(*SMTKernel).buildModel'
       if any(go in t or native in t for t in sub):
        category=label;break
      tally['check / '+category]+=1
     break
  for child,n in tally.most_common():out.writerow([name,child,n])
