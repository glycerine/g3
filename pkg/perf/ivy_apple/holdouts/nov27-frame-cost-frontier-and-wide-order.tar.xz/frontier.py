"""Measure verifier stages on the union of the elapsed and instruction deficits in the 228-input screen."""
from pathlib import Path
import csv,subprocess,concurrent.futures,os,sys
w=Path(__file__).resolve().parent;p=Path.cwd();h=Path('/tmp/g3-ticket-stages');f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',h/'translated.json','-o',w/'stage-g3','./cmd/goivy_check'],cwd=f,check=True)
src=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
cases=(src/'compat.txt').read_text().splitlines()
names=[r for r in csv.DictReader((src/'ranking.csv').open()) if r['exact']=='True' and r['proof']=='True' and (float(r['excess_instructions'])>0 or float(r['excess_seconds'])>0)]
def group(item):
 ix,cpu=item
 with (w/f'frontier{ix}.csv').open('w') as fo,(w/f'frontier-status{ix}.csv').open('w') as fs:
  out=csv.writer(fo);out.writerow(['case','engine','round','batch','goal','stage','instructions'])
  status=csv.writer(fs);status.writerow(['case','engine','round','status','stage_count'])
  for row in names[ix::4]:
   name=row['case'];ref=src/'compat'/str(cases.index(name)+1)/'1/native'
   for i in range(3):
    for e in ('g3','native')[::1 if (i+ix)%2==0 else -1]:
     exe=w/'stage-g3' if e=='g3' else h/'translated-native'
     r=subprocess.run(['taskset','-c',str(cpu),exe,ex/name],cwd=w,capture_output=True,timeout=180,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
     raw=[];vals=[]
     for line in r.stderr.splitlines(keepends=True):
      if line.startswith(b'STAGE-COUNT '):
       _,b,g,s,n,empty,en,active,ns=line.decode().split();assert en==active;vals.append([name,e,i,b,g,s,n])
      else:raw.append(line)
     exact=(r.returncode,r.stdout,b''.join(raw))==(int(row['exit']),(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
     status.writerow([name,e,i,'match' if exact else 'different',len(vals)]);fs.flush()
     if exact:out.writerows(vals);fo.flush()
     else:(w/f'frontier{ix}-{e}.stderr').write_bytes(b''.join(raw))
with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(group,enumerate([2,4,14,20])))
