"""Test publishing a held unchanged parent directly on ordinary unsuccessful reduction."""
from pathlib import Path
import json,sys,subprocess,csv
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text();a=s.index('func (r *rewriterEngine) processApp()');b=s.index('// processAppMacroEnd',a);pre,s,post=s[:a],s[a:b],s[b:]
key='} else {\n\t\t\th := t\n\t\t\tif fr.newChild()'
assert s.count(key)==1
s=s.replace(key,'''} else {
   if !fr.newChild() && studyFinish && !ast.ASTValidateHandles && !ast.ASTSourceDebug {
     old,err:=m.RefGetHeld(r.r);if err!=nil{return err}
     if old.IsNull(){
       if err:=shrinkRewriterRoots(m,&c.results,fr.spos);err!=nil{return err}
       if err:=appendRewriterRoot(m,&c.results,t);err!=nil{return err}
       if err:=r.cache(fr,t);err!=nil{return err}
       c.frames=c.frames[:fi];return nil
     }
   }
   h := t
   if fr.newChild()''')
s=(pre+s+post).replace('import (','import (\n"os"',1)+'\nvar studyFinish=os.Getenv("ACTION_SCOPE")=="direct"\n'
dst=w/'finish.go.txt';dst.write_text(s);o=w/'finish.json';o.write_text(json.dumps({'Replace':{str(k):str(dst)}}))
exe=w/'finish'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
d=w/'finish_compare.py';d.write_text((w/'compare.py').read_text().replace('exe=w/m',"exe=w/'finish'"))
src=Path('/tmp/g3-ticket-operand-price')
names=list(dict.fromkeys(r['case'] for r in csv.DictReader((src/'seed0_base_draw1.csv').open())))
subprocess.run([sys.executable,d,'finish_base_direct','16','7',*names],check=True)
