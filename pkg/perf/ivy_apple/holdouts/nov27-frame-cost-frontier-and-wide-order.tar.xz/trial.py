"""Build the current checkout with each of two independent frame-loop changes."""
from pathlib import Path
import subprocess,json,sys
w=Path(__file__).resolve().parent;p=Path.cwd()
f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
mode=sys.argv[1];ov={}
def put(path,s):
 k=p/path;d=w/(mode+'-'+k.name+'.txt');d.write_text(s);ov[str(k)]=str(d)
k='ast/rewriter/rewriter_engine.go';s=(p/k).read_text()
a=s.index('func (r *rewriterEngine) processApp()');pre,s=s[:a],s[a:]
if mode in ('arity','both'):
 key='if i == 1 || i > 0 && r.modelBooleanShortCircuit {'
 assert s.count(key)==1;s=s.replace(key,'if n == 3 && i == 1 || i > 0 && r.modelBooleanShortCircuit {')
if mode in ('inline','both'):
 key='arg, e := m.GetArg(t, i)'
 assert key in s;s=s.replace(key,'var arg ast.ASTHandle; var e error; if n<=2 && !ast.ASTSourceDebug && !ast.ASTValidateHandles {arg=m.RewriterSmallArgument(t,i)}else{arg,e=m.GetArg(t,i)}',1)
 k2='ast/ast_rewriter_access.go';put(k2,(p/k2).read_text()+'\nfunc (m *ASTManager) RewriterSmallArgument(t ASTHandle,i uint32) ASTHandle {return m.external(m.appAt(t.slot).inlineArgs[i])}\n')
put(k,pre+s);o=w/(mode+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',w/mode,'./cmd/goivy_check'],cwd=f,check=True)
