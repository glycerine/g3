from pathlib import Path
import csv,sys,subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
k=p/'ast/rewriter/rewriter_engine.go';s=k.read_text().replace('import (','import (\n"os"',1);key='if i == 1 || i > 0 && r.modelBooleanShortCircuit {'
assert s.count(key)==1;s=s.replace(key,'if i == 1 && (!studyArity || n==3) || i > 0 && r.modelBooleanShortCircuit {')+'\nvar studyArity=os.Getenv("ACTION_SCOPE")=="arity"\n';dst=w/'confirm.go.txt';dst.write_text(s)
o=w/'confirm.json';o.write_text(json.dumps({'Replace':{str(k):str(dst)}}));exe=w/'confirm'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
d=w/'confirm_compare.py';d.write_text((w/'compare.py').read_text().replace('exe=w/m',"exe=w/'confirm'"))
names=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines()
procs=[subprocess.Popen([sys.executable,d,f'confirm{i}_base_arity',str(c),'3',*names[i::4]]) for i,c in enumerate([2,4,20,22])]
assert [j.wait() for j in procs]==[0]*4
