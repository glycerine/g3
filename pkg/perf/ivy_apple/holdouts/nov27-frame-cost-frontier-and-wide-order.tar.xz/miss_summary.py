from pathlib import Path
import csv,collections as c,statistics as st
w=Path(__file__).resolve().parent
d=c.Counter();detailed=c.defaultdict(dict);ok=c.defaultdict(set)
for f in w.glob('cert-status*.csv'):
 for r in csv.DictReader(f.open()):
  if r['status']=='match':ok[r['case']].add(int(r['round']))
for f in w.glob('cert[0-9].csv'):
 for r in csv.DictReader(f.open()):
  if len(ok[r['case']])!=3:continue
  n,i,b,g,k=r['case'],int(r['round']),int(r['batch']),int(r['goal']),r['stage']
  if k in ('check','post-miss','post-success','early'):detailed[n,i,b,g][k]=int(r['instructions'])
with (w/'cert-goals.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','batch','goal','attempt','instructions'])
 for (n,i,b,g),obs in detailed.items():
  for k in ['post-miss','post-success','early']:
   if k not in obs:continue
   label=('early-miss' if 'check' in obs else 'early-success') if k=='early' else k
   d[n,i,label]+=obs[k]
   if i==0:
    assert all(k in detailed[n,j,b,g] and ('check' in detailed[n,j,b,g])==('check' in obs) for j in (1,2))
    out.writerow([n,b,g,label,int(st.median(detailed[n,j,b,g][k] for j in range(3)))])
with (w/'cert-totals.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','early-miss','post-miss','early-success','post-success'])
 for n in sorted(n for n in ok if len(ok[n])==3):
  out.writerow([n,*[st.median(d[n,i,k] for i in range(3)) for k in ['early-miss','post-miss','early-success','post-success']]])
rows=list(csv.DictReader((w/'cert-totals.csv').open()));print('cases',len(rows))
for k in ['early-miss','post-miss','early-success','post-success']:print(k,round(sum(int(r[k]) for r in rows)/1e6))
for r in sorted(rows,key=lambda r:-int(r['post-miss']))[:10]:print(r['case'],r['early-miss'],r['post-miss'])
