"""Rotate complete verifier runs and retain failures as evidence."""
from pathlib import Path
import subprocess,os,sys,csv,time
w=Path(__file__).resolve().parent;p=Path('/tmp/g3-ivy-pgo');ex=Path('/home/jaten/ivy/ivy-lang-examples')
stem,cpu,rounds,*names=sys.argv[1:]
codes={r['spec']:int(r['exit']) for f in (p/'survey').glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
with (w/(stem+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round mode status instructions cycles ms'.split())
 for name in names:
  idx=(p/'prior-gaps.txt').read_text().splitlines().index(name)+1;ref=p/'survey'/str(idx)/'1/native';expected=codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()
  abc=Path('/tmp/g3-flash-marginal/abc-control')
  if idx==35:expected=1,(abc/'native.out').read_bytes(),(abc/'native.err').read_bytes()
  modes=sys.argv[1].split('_')[1:];assert modes[0]=='base';failed=set()
  for i in range(int(rounds)):
   for m in modes[i%len(modes):]+modes[:i%len(modes)]:
    if m in failed:continue
    env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),ACTION_SCOPE=m)
    exe=w/'conflict'
    stat=w/(stem+'.stat');cmd=['taskset','-c',cpu,'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u,cycles:u','--',exe,ex/name]
    t=time.monotonic()
    try:
     r=subprocess.run(cmd,cwd=w,capture_output=True,timeout=75,env=env)
     ok=(r.returncode,r.stdout,r.stderr)==expected
     if not ok:
      (w/(stem+'-'+m+'.stdout')).write_bytes(r.stdout);(w/(stem+'-'+m+'.stderr')).write_bytes(r.stderr);failed.add(m)
     hw={x[2]:int(x[0]) for x in csv.reader(stat.read_text().splitlines()) if len(x)>4 and float(x[4])==100}
     out.writerow([name,i,m,'match' if ok else 'different',hw.get('instructions:u'),hw.get('cycles:u'),1000*(time.monotonic()-t)])
    except subprocess.TimeoutExpired:
     out.writerow([name,i,m,'timeout','','',75000]);failed.add(m)
    f.flush()
