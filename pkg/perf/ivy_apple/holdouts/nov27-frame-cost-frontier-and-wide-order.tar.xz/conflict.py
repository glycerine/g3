"""Check whether already-inconsistent concrete assertions explain repeated private work."""
from pathlib import Path
import sys,csv,json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();k=p/'api/api_order_abstraction.go';s=k.read_text().replace('import (','import (\n"os"',1)
a=s.index('func (p *orderProofState) proveWithGoal');pre,s=s[:a],s[a:];key='assertions, err := solver.Assertions(s.solver)';assert s.count(key)==1
s=s.replace(key,'''if reuse && goal.IsNull(){if c,ok:=s.solver.(*solver.CombinedSolver);ok && c.HasInconsistentAssertions(){switch studyConflict{case "concrete":return false,nil;case "known":return true,nil;case "count":println("ALREADY-FALSE")}}}
 '''+key);dst=w/'conflict.go.txt';dst.write_text(pre+s+'\nvar studyConflict=os.Getenv("ACTION_SCOPE")\n')
o=w/'conflict.json';o.write_text(json.dumps({'Replace':{str(k):str(dst)}}));exe=w/'conflict'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
import os
d=w/'conflict_compare.py';d.write_text((w/'compare.py').read_text().replace('exe=w/m',"exe=w/'conflict'"));survey=Path('/tmp/g3-reduction-rows');cases=(survey/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples')
codes={r['case']:int(r['exit']) for r in csv.DictReader((survey/'ranking.csv').open())}
names=list(dict.fromkeys(r['case'] for r in csv.DictReader((w/'cert-totals.csv').open())))
with (w/'conflicts.csv').open('w') as fo:
 out=csv.writer(fo);out.writerow(['case','count'])
 for name in names:
  if name.endswith('/ticket_mc.ivy'):continue
  ref=survey/'compat'/str(cases.index(name)+1)/'1/native';r=subprocess.run([exe,ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',ACTION_SCOPE='count',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),capture_output=True,timeout=120)
  assert (r.returncode,r.stdout,r.stderr.replace(b'ALREADY-FALSE\n',b''))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),name
  out.writerow([name,r.stderr.count(b'ALREADY-FALSE\n')]);fo.flush()
eligible=Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines()
rows=sorted(csv.DictReader((w/'conflicts.csv').open()),key=lambda r:-int(r['count']));names=[r['case'] for r in rows if int(r['count']) and r['case'] in eligible][:6]
if names:subprocess.run([sys.executable,d,'conflict_base_concrete_known','18','5',*names],check=True)
