from pathlib import Path
import csv,subprocess,sys
w=Path(__file__).resolve().parent;src=Path('/tmp/g3-ticket-operand-price')
d=w/'compare.py';d.write_text((src/'compare.py').read_text().replace("Path('/tmp/g3-reduction-rows/release') if m=='base' else w/m","w/m"))
for mode in ['base','arity','inline','both']:subprocess.run([sys.executable,w/'trial.py',mode],check=True)
names=list(dict.fromkeys(r['case'] for r in csv.DictReader((src/'seed0_base_draw1.csv').open())))
subprocess.run([sys.executable,d,'frames_base_arity_inline_both','14','5',*names],check=True)
