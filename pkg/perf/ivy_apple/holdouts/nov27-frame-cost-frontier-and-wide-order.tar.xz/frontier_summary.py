from pathlib import Path
import csv,statistics as st,collections as c
w=Path(__file__).resolve().parent
ok=c.defaultdict(set);d=c.Counter();goals=c.Counter()
for f in w.glob('frontier-status*.csv'):
 for r in csv.DictReader(f.open()):
  if r['status']=='match':ok[r['case'],r['engine']].add(int(r['round']))
for f in w.glob('frontier[0-9].csv'):
 for r in csv.DictReader(f.open()):
  name,e,i,b,g,k,n=r['case'],r['engine'],int(r['round']),int(r['batch']),int(r['goal']),r['stage'],int(r['instructions'])
  d[name,e,i,k]+=n;goals[name,e,i,b,g,k]+=n
names=sorted({n for n,e in ok if ok[n,'native']==ok[n,'g3']=={0,1,2}})
with (w/'frontier-phases.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','stage','g3','native','difference'])
 for name in names:
  for k in sorted({row[-1] for row in d if row[0]==name}):
   a,b=[st.median(d[name,e,i,k] for i in range(3)) for e in ('g3','native')]
   out.writerow([name,k,a,b,a-b])
with (w/'frontier-goals.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['case','batch','goal','stage','g3','native','difference'])
 for name,b,g,k in sorted({(n,b,g,k) for n,e,i,b,g,k in goals if n in names}):
  a,z=[st.median(goals[name,e,i,b,g,k] for i in range(3)) for e in ('g3','native')]
  out.writerow([name,b,g,k,a,z,a-z])
print('compared',len(names), 'inputs')
tot=c.Counter()
for r in csv.DictReader((w/'frontier-phases.csv').open()):tot[r['stage']]+=int(r['difference'])
print(tot.most_common())
for r in sorted(csv.DictReader((w/'frontier-goals.csv').open()),key=lambda r:-int(r['difference']))[:16]:print(r['case'].split('/')[-1],r['batch'],r['goal'],r['stage'],round(int(r['difference'])/1e6,2))
