"""Measure the counterfactual value of perfect foreknowledge of inconclusive certificates."""
from pathlib import Path
import csv,subprocess,json,sys
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov={}
def emit(k,s):
 dst=w/('oracle-'+k.name+'.txt');dst.write_text(s);ov[str(k)]=str(dst)
k=f/'smt/g3_solver.go';s=k.read_text();key='if proved, err := prove(); err == nil && proved {'
assert s.count(key)==1
s=s.replace(key,'''if !s.StudySkipPost {if proved, err := prove(); err == nil && proved {''').replace('r, err := s.c.Check()\n\t\tfail(err)','}\n r, err := s.c.Check()\n\t\tfail(err)',1)
s=s.replace('type Z3Solver struct {','type Z3Solver struct {\n StudySkipPost bool');emit(k,s)
k=f/'z3bridge_solver_model.go';s=k.read_text()
i=s.index('func (s *Solver) GetSmallModelWithCond(');pre,s=s[:i],s[i:];s=s.replace('z3solver := s.newZ3Solver()','studyOrdinal++; batch:=studyOrdinal;z3solver := s.newZ3Solver()',1).replace('for _, fc := range finalCond {','for ordinal, fc := range finalCond {',1)
key='finalCheck := check';s=s.replace(key,key+'''
 tag:=fmt.Sprintf(",%d/%d,",batch,ordinal+1)
 mode:=os.Getenv("ACTION_SCOPE")
 early:=strings.Contains(os.Getenv("STUDY_EARLY"),tag);post:=strings.Contains(os.Getenv("STUDY_POST"),tag)
 z3solver.StudySkipPost=post && (mode=="post" || mode=="both")
''',1)
assert s.count('if proveGoal(zCond) {')==1
s=s.replace('if proveGoal(zCond) {','if !(early && (mode=="early"||mode=="both")) && proveGoal(zCond) {',1)
s=pre+'var studyOrdinal int\n'+s
for name in ['strings','os']:
 if '"'+name+'"' not in s:s=s.replace('import (','import (\n"'+name+'"',1)
emit(k,s)
o=w/'oracle.json';o.write_text(json.dumps({'Replace':ov}));exe=w/'oracle'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
ss=(w/'compare.py').read_text();key="exe=w/m";assert key in ss;ss=ss.replace(key,'''for pos in ['early','post']:
     env['STUDY_'+pos.upper()]=','+','.join(positions.get((name,pos),[]))+','
    exe=w/'oracle' ''')
ss=ss.replace('stem,cpu,rounds,*names=sys.argv[1:]','''positions={}
for rr in csv.DictReader((w/'cert-goals.csv').open()):
 if rr['attempt'].endswith('-miss'):positions.setdefault((rr['case'],rr['attempt'].split('-')[0]),[]).append(rr['batch']+'/'+rr['goal'])
stem,cpu,rounds,*names=sys.argv[1:]''')
d=w/'oracle_compare.py';d.write_text(ss)
rows=list(csv.DictReader((w/'cert-totals.csv').open()));pool=set(Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines());rows=[r for r in rows if r['case'] in pool]
names=[r['case'] for r in sorted(rows,key=lambda r:-int(r['post-miss'])-int(r['early-miss']))[:12]]
children=[subprocess.Popen([sys.executable,d,f'oracle{i}_base_early_post_both',str(cpu),'5',*names[i::3]]) for i,cpu in enumerate([4,14,20])]
assert [x.wait() for x in children]==[0,0,0]
