from pathlib import Path
import csv,json,subprocess,os,sys
w=Path(__file__).resolve().parent;p=Path.cwd();f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();h=Path('/tmp/g3-ticket-stages')
k=p/'api/api_order_abstraction.go';s=k.read_text();key='order.RefutesComparisonCycle(parent, assertions[len(assertions)-1], 32) {'
assert s.count(key)==1;s=s.replace(key,key+'\n println("WORD-CYCLE",p.expectedGoals,p.openingAttempts,!goal.IsNull(),len(assertions));')
dst=w/'wide-meter.go.txt';dst.write_text(s);ov=json.loads((h/'translated.json').read_text());ov['Replace'][str(k)]=str(dst);o=w/'wide-meter.json';o.write_text(json.dumps(ov))
exe=w/'wide-stage'
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off','-pgo=off','-overlay',o,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');src=Path('/tmp/g3-reduction-rows');codes={r['case']:int(r['exit']) for r in csv.DictReader((src/'ranking.csv').open())};cases=(src/'compat.txt').read_text().splitlines()
with (w/'wide-stages.csv').open('w') as fo,(w/'wide-proofs.csv').open('w') as fp:
 out=csv.writer(fo);out.writerow(['case','round','batch','goal','stage','instructions']);proofs=csv.writer(fp);proofs.writerow(['case','round','batch','goal','stage','expected','opening','temporary','assertions'])
 for name in ['test/arm_rules3.ivy','doc/examples/leader_election_ring.ivy','doc/examples/leader_election_ring_btw.ivy']:
  ref=src/'compat'/str(cases.index(name)+1)/'1/native'
  for i in range(3):
   r=subprocess.run(['taskset','-c','22',exe,ex/name],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True);raw=[];hit=[]
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'STAGE-COUNT '):
     _,b,g,k,n,empty,en,active,ns=line.decode().split();assert en==active;out.writerow([name,i,b,g,k,n])
     for v in hit:proofs.writerow([name,i,b,g,k,*v])
     hit=[]
    elif line.startswith(b'WORD-CYCLE '):hit.append(line.decode().split()[1:])
    else:raw.append(line)
   assert not hit and (r.returncode,r.stdout,b''.join(raw))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
   fo.flush();fp.flush()
