from pathlib import Path
import csv,json,subprocess,re,os
w=Path(__file__).resolve().parent;p=Path.cwd();o=w/'confirm.json';ov=json.loads(o.read_text());ov['Replace'][str(p/'ast/rewriter/theory_binary_frame_benchmark_test.go')]=str(w/'binary_benchmark.go.txt');o=w/'bench.json';o.write_text(json.dumps(ov))
subprocess.run(['go','test','-c','-vet=off','-overlay',o,'-o',w/'bench','./ast/rewriter'],check=True)
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'bench.csv').open('w') as f:
 out=csv.writer(f);out.writerow('round mode ns bytes allocs instructions cycles'.split())
 for i in range(11):
  for mode in ['base','arity'][::1 if not i%2 else -1]:
   stat=w/'bench.stat'
   r=subprocess.run(['taskset','-c','18',perf,'stat','-x,','-o',stat,'-e','instructions:u,cycles:u','--',w/'bench','-test.run=^$','-test.bench=^BenchmarkTheoryBinaryFrames$','-test.benchtime=30000x'],env=dict(os.environ,GOMAXPROCS='1',ACTION_SCOPE=mode),capture_output=True,check=True)
   m=re.search(rb'30000\s+([0-9.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert m,r.stdout
   hw={v[2]:v[0] for v in csv.reader(stat.open()) if len(v)>4 and float(v[4])==100}
   out.writerow([i,mode,*[v.decode() for v in m.groups()],hw['instructions:u'],hw['cycles:u']]);f.flush()
