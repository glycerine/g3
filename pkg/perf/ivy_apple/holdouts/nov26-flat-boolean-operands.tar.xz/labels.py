"""Report assumed formulas which directly expose the symbol in the diagnostic."""
from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent
ivy=Path.home()/'ivy/goivy'
src=ivy/'isolate.go';s=src.read_text()
k='for _, lfSlice := range [][]*LabeledFormula{\n\t\tmod.LabeledAxioms, mod.LabeledProps, mod.LabeledInits, mod.LabeledConjs, mod.Definitions, mod.AssumedInvs,'
assert s.count(k)==1;s=s.replace(k,k.replace('for _,','for idx,'))
k='collectSymbolsInto(as2, lf.Formula.(Expr), allSyms2)'
assert s.count(k)==2
s=s.replace(k,'''if idx==5 {
    symbols:=NewInsMap[NodeKey,Expr]()
    collectSymbolsInto(as2,lf.Formula.(Expr),symbols)
    if allSymsNameSet(symbols)["rfn.abs.lastq"]{fmt.Fprintf(os.Stderr,"ASSUMPTION %s %s\\n",lfLabelName(lf),PrettyFmla(lf.Formula.(Expr)))}
}
'''+k,1).replace('import (','import (\n "os"',1)
d=w/'labels';d.mkdir(exist_ok=True)
dst=d/'isolate.go';dst.write_text(s)
f=d/'overlay.json';f.write_text(json.dumps({'Replace':{str(src):str(dst),str(src.resolve()):str(dst)}}))
exe=d/'goivy'
subprocess.run(['go','build','-mod=readonly','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay',f,'-o',exe,'./cmd/goivy_check'],cwd=ivy,check=True)
for case in ('rfn2','dramc_nb2'):
 r=subprocess.run([exe,'isolate='+case,Path.home()/'ivy/ivy-lang-examples/doc/examples/apple/ord_live.ivy'],cwd=d,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True)
 (d/(case+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==1 and b'may have visible effect' in r.stderr,r.stderr
