"""Build a Go observer covering the same queue interval as native.py."""
from pathlib import Path
import json
import subprocess

pkg = Path.cwd()
out = Path(__file__).resolve().parent / 'go-observer'
out.mkdir(exist_ok=True)
fields = ('calls','reduce','binary','operand','identity','negation','marked','new_marks','misses')
paths = {}

def replace(name, old, new, expected=1):
    path = pkg / name
    source = paths.get(path, path).read_text()
    if source.count(old) != expected:
        raise ValueError((name, old, source.count(old)))
    emit(name, source.replace(old, new, 1))

def emit(name, source):
    path = pkg/name
    dst = out / path.name
    dst.write_bytes(subprocess.check_output(['gofmt'], input=source.encode()))
    paths[path] = dst

emit('ast/rewriter/qi_frame_observation.go', '''package rewriter
import (
    "fmt"
    "os"
    "github.com/glycerine/g3/pkg/ast"
)
var qiFrameObserver struct {
    active bool
    results *[]ast.ASTHandle
''' + ''.join(f'    {name} uint64\n' for name in fields) + '''}
func (r *TheoryRewriter) ObserveQuantifierFrameRewrite(term ast.ASTHandle, out ast.ASTRef) error {
    obs := &qiFrameObserver
    prior, results := obs.active, obs.results
    obs.active = true
    obs.results = &r.traversal.engine.core.results
    obs.calls++
    defer func() { obs.active, obs.results = prior, results }()
    return r.Rewrite(term, out)
}
func PrintQuantifierFrameObservation() {
    fmt.Fprint(os.Stderr, "QI-FRAMES")
''' + ''.join(f'    fmt.Fprintf(os.Stderr, " {field}=%d", qiFrameObserver.{field})\n' for field in fields) + '''
    fmt.Fprintln(os.Stderr)
}
''')
name='ast/rewriter/bool_rewriter.go'
def count(field): return 'if qiFrameObserver.active {qiFrameObserver.'+field+'++}\n'
replace(name,'base := len(rw.nflatBuffer)',count('reduce')+'if args.Count()==2 {'+count('binary')+'}\n base := len(rw.nflatBuffer)')
replace(name,'return rw.mkNFlatBody(args, out, disjunction, base)','status,err=rw.mkNFlatBody(args,out,disjunction,base)\n if status==brFailed && err==nil {'+count('misses')+'}\nreturn')
replace(name,'if arg == unit {',count('operand')+'if arg == unit {')
replace(name,'negative, atom, e := m.IsNot(arg)',count('identity')+'negative, atom, e := m.IsNot(arg)')
replace(name,'if negative {','if negative {\n'+count('negation'))
for bit in ['negBit','posBit']:
    replace(name,'set(key, '+bit+')',count('new_marks')+'set(key, '+bit+')')
replace(name,'nested, e := rw.isOperator(arg, op)',count('marked')+'nested, e := rw.isOperator(arg, op)',2)
# The second flatten test runs only after a nested connective was detected.
src=paths[pkg/name].read_text()
at=src.rindex('nested, e := rw.isOperator(arg, op)')
emit(name,src[:at]+count('marked')+src[at:])
replace('smtcore/smt_qi_instance.go', 'if err = rw.Rewrite(instance, simplified); err != nil {',
                                   'if err = rw.ObserveQuantifierFrameRewrite(instance, simplified); err != nil {')
replace('cmd/g3/main.go', 'package main', 'package main\nimport "github.com/glycerine/g3/pkg/ast/rewriter"')
replace('cmd/g3/main.go', 'func main() {', 'func main() {\n defer rewriter.PrintQuantifierFrameObservation()')
overlay = out/'overlay.json'
overlay.write_text(json.dumps({'Replace': {str(path):str(dst) for path,dst in paths.items()}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'], cwd=pkg, check=True)
