"""Validate instrumented Ticket replays before comparing their event counts."""
from pathlib import Path
import argparse
import csv
import os
import re
import subprocess
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--fixtures', required=True, type=Path)
p.add_argument('--raw', required=True, type=Path)
p.add_argument('engines', nargs='+')
a = p.parse_args()
a.raw.mkdir(exist_ok=True)
writer = csv.writer(sys.stdout)
fields = None
search = ('decisions', 'conflicts', 'quant-instantiations', 'rlimit-count')
for q in ('ticket-127','ticket-290','toy-consensus-18'):
    source = (a.fixtures/(q+'.smt2')).read_bytes()
    ref = None
    for option in a.engines:
        label, path = option.split('=',1)
        run = subprocess.run([path,'-in','-smt2'], input=source, capture_output=True, check=True, timeout=60,
                             env=dict(os.environ,GOMAXPROCS='1'))
        if not run.stdout.startswith(b'unsat\n') or b'(error' in run.stdout:
            raise ValueError((q,label,run.stdout,run.stderr))
        for name,data in (('stdout',run.stdout),('stderr',run.stderr)):
            (a.raw/(q+'-'+label+'.'+name)).write_bytes(data)
        all_stats = dict(re.findall(r':([\w-]+)\s+(\d+)\b',run.stdout.decode()))
        seen = tuple(all_stats.get(k,'0') for k in search)
        if ref is None:
            ref = seen
        if ref != seen:
            raise ValueError((q,label,ref,seen))
        line = run.stderr.decode().strip()
        if not line:
            continue
        if not line.startswith('QI-FRAMES ') or '\n' in line:
            raise ValueError((q,label,line))
        stats = dict(entry.split('=',1) for entry in line.split()[1:])
        if fields is None:
            fields = tuple(stats)
            writer.writerow(('query','engine',*fields,*search))
        writer.writerow((q,label,*(stats[k] for k in fields),*seen))
