"""Recognize already normalized small Boolean connectives on slice-backed inputs."""
from pathlib import Path
import json,subprocess,sys
pkg=Path.cwd();work=Path(__file__).resolve().parent/'flat32';work.mkdir(exist_ok=True)
files={}
def save(src,s):
    dst=work/src.name
    dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    files[str(src)]=files[str(Path.home()/'g3/pkg'/src.relative_to(pkg))]=str(dst)
src=pkg/'ast/ast_core_boolean_factories.go'
save(src,src.read_text()+'''
// DistinctFlatBooleanOperands recognizes an AND or OR that needs neither
// flattening nor constant, duplicate, or complement simplification.
func (m *ASTManager) DistinctFlatBooleanOperands(args AppArguments, op int32) bool {
    var atoms [32]astNodeRef
    n:=args.count
    if astValidateHandles || n<2 || n>uint32(len(atoms)) || args.appOwner!=nil || args.raw ||
        uint64(args.argumentOffset)+uint64(n)>uint64(len(args.slice)) || m==nil || !m.lockFree(){return false}
    for i,h:=range args.slice[args.argumentOffset:args.argumentOffset+n]{
        r,e:=m.internal(h)
        if e!=nil || r==m.trueApp || r==m.falseApp{return false}
        if m.nodeAt(r.slot).kind==ASTApp {
            a:=m.appAt(r.slot)
            family,kind,e:=m.appIdentity(a)
            if e!=nil {return false}
            if family==0{
                if kind==op{return false}
                if kind==ASTOpNot {
                    r,e=m.appArg(a,0)
                    if e!=nil {return false}
                }
            }
        }
        for _,seen:=range atoms[:i]{if seen==r{return false}}
        atoms[i]=r
    }
    return true
}
''')
src=pkg/'ast/rewriter/bool_rewriter.go';s=src.read_text();k='i := uint32(0)\n\tfor ; i < args.Count(); i++'
assert s.count(k)==1
save(src,s.replace(k,'''if (!disjunction || !rw.localContext || rw.localContextCost>rw.localContextLimit) && rw.manager.DistinctFlatBooleanOperands(args,op) {return brFailed,nil}
    '''+k))
f=work/'overlay.json';f.write_text(json.dumps({'Replace':files}))
ivy='--ivy' in sys.argv
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-overlay',f,'-o',work/('goivy' if ivy else 'g3'),*(['-tags=xtrace_off','./cmd/goivy_check'] if ivy else ['./cmd/g3'])],cwd=Path.home()/'ivy/goivy' if ivy else pkg,check=True)
