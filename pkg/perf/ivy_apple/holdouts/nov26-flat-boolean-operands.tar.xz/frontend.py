"""Locate a frontend-only Apple rejection with historical source exports."""
import csv,os,subprocess,sys,tarfile,tempfile
from pathlib import Path
work=Path(__file__).resolve().parent
repo=Path.home()/'ivy'
pkg=Path.cwd()
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(repo/'ivy-lang-examples/ivy/include'))
def probe(ref):
    rev=subprocess.check_output(['git','-C',repo,'rev-parse','--short=9',ref],text=True).strip()
    with tempfile.TemporaryDirectory(dir=work) as tmp:
        with subprocess.Popen(['git','-C',repo,'archive',ref,'goivy'],stdout=subprocess.PIPE) as p:
            with tarfile.open(fileobj=p.stdout,mode='r|') as t:t.extractall(tmp)
        assert p.returncode==0
        cwd=Path(tmp)/'goivy'
        subprocess.run(['go','mod','edit','-replace','github.com/glycerine/g3/pkg='+str(pkg)],cwd=cwd,check=True)
        exe=cwd/'check'
        subprocess.run(['go','build','-mod=readonly','-pgo=off','-tags=xtrace_off','-buildvcs=false','-o',exe,'./cmd/goivy_check'],cwd=cwd,check=True)
        r=subprocess.run([exe,'isolate=rfn2',repo/'ivy-lang-examples/doc/examples/apple/ord_live.ivy'],capture_output=True,env=env,cwd=tmp,timeout=60)
        passes=sum(x.strip()==b'PASS' for x in r.stdout.splitlines())
        error=r.stderr.decode().strip()
        if (r.returncode,passes)!=(0,26) and not (r.returncode==1 and passes==0 and 'may have visible effect on rfn.abs.lastq' in error):raise ValueError((ref,passes,error))
        return rev,r.returncode,passes,error
out=csv.writer(sys.stdout)
out.writerow(['revision','exit','passes','stderr'])
for ref in sys.argv[1:]:
    out.writerow(probe(ref));sys.stdout.flush()
