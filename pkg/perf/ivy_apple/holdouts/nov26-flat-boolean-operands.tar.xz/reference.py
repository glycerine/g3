"""Capture the updated linked-native transcripts and compare proof outcome lists."""
from pathlib import Path
import json,os,re,subprocess,sys
work=Path(__file__).resolve().parent
old,examples,exe=map(Path,sys.argv[1:]);exe=exe.resolve()
gold=work/'golden';gold.mkdir(exist_ok=True)
cases={k:v for k,v in json.loads((old/'cases.json').read_text()).items() if k in ['ticket_protocol','hybrid','arm_rules3','fba']}
(gold/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
for k,(src,isolate,code) in cases.items():
    d=gold/'reference'/k;d.mkdir(parents=True,exist_ok=True)
    r=subprocess.run([exe,*(['isolate='+isolate] if isolate else []),examples/src],cwd=d,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),timeout=90)
    assert r.returncode==code,(k,r.returncode,r.stderr[-500:])
    old_bytes=(old/'reference'/k/'stdout').read_bytes()
    def results(data):
        return re.findall(rb'^(?:PASS|FAIL|UNKNOWN)\b.*$',data,re.M)
    assert results(r.stdout)==results(old_bytes) and r.stderr==(old/'reference'/k/'stderr').read_bytes(),k
    (d/'stdout').write_bytes(r.stdout);(d/'stderr').write_bytes(r.stderr)
    print(k,len(results(r.stdout)),r.stdout==old_bytes,flush=True)
