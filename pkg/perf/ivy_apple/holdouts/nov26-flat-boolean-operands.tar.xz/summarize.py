"""Print median per-round percentage changes from the matched release."""
import csv, sys
from statistics import median
for file in sys.argv[1:]:
    with open(file) as stream:
        rows=list(csv.DictReader(stream))
    key='case' if 'case' in rows[0] else 'query'
    for case in dict.fromkeys(x[key] for x in rows):
        sample=[x for x in rows if x[key]==case]
        by_round={(x['round'],x['engine']):x for x in sample}
        for variant in sorted({x['engine'] for x in sample}-{'base'}):
            pairs=[(x,by_round[x['round'],'base']) for x in sample if x['engine']==variant and (x['round'],'base') in by_round]
            if pairs:
                print(file,case,variant,len(pairs),*[round(median(100*(float(a[k])/float(b[k])-1) for a,b in pairs),2) for k in ('instructions','cycles','milliseconds')])
