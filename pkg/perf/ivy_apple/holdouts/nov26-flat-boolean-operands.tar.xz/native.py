"""Build a fork-native Ticket rewrite census using three replacement objects."""
from pathlib import Path
import re
import shlex
import subprocess

pkg = Path.cwd()
root = pkg.parent
build = root / 'build'
out = Path(__file__).resolve().parent / 'native'
out.mkdir(exist_ok=True)
flags = dict(row.split('=', 1) for row in (build / 'config.mk').read_text().splitlines() if '=' in row)
makefile = (build / 'Makefile').read_text()
fields = ('calls','reduce','binary','operand','identity','negation','marked','new_marks','misses')
observer = out / 'observe.hpp'
observer.write_text('''#pragma once
#include <cstdio>
struct qi_observation {
    bool active = false;
''' + ''.join('    unsigned long long %s = 0;\n' % field for field in fields) + '''    ~qi_observation() {
        std::fprintf(stderr, "QI-FRAMES");
''' + ''.join('        std::fprintf(stderr, " %s=%%llu", %s);\n' % (f, f) for f in fields) + '''        std::fprintf(stderr, "\\n");
    }
};
extern qi_observation qi_observed;
struct qi_observation_scope {
    bool previous;
    qi_observation_scope(): previous(qi_observed.active) { qi_observed.active = true; ++qi_observed.calls; }
    ~qi_observation_scope() { qi_observed.active = previous; }
};
#define QI_OBSERVE(field) do { if (qi_observed.active) ++qi_observed.field; } while (false)
#define QI_SHRINK(n) do { if (qi_observed.active) qi_observed.result_releases += result_stack().size() - (n); } while (false)
''')

def once(s, old, new):
    if s.count(old) != 1:
        raise ValueError((old, s.count(old)))
    return s.replace(old, new)

name='ast/rewriter/bool_rewriter.cpp'
source=(root/'src'/name).read_text()
for op in ('and','or'):
    start=source.index('br_status bool_rewriter::mk_nflat_'+op+'_core')
    end=source.index('br_status bool_rewriter::mk_flat_'+op+'_core',start)
    seg=source[start:end].replace('bool s = false;', 'QI_OBSERVE(reduce); if(num_args==2) QI_OBSERVE(binary); bool s=false;')
    seg=seg.replace('expr * arg  = args[i];','QI_OBSERVE(operand); expr * arg  = args[i];')
    seg=seg.replace('if (m().is_not(arg)) {','QI_OBSERVE(identity); if (m().is_not(arg)) { QI_OBSERVE(negation);')
    for st in ('neg_lits.mark(atom);','pos_lits.mark(arg);'):
        seg=seg.replace(st,'QI_OBSERVE(new_marks); '+st)
    seg=seg.replace('return BR_FAILED;', 'QI_OBSERVE(misses); return BR_FAILED;')
    source=source[:start]+seg+source[end:]
    start=source.index('br_status bool_rewriter::mk_flat_'+op+'_core')
    end=source.index('\n}',start)+2
    seg=source[start:end]
    for arg in ('args[i]','arg'):
        st=f'if (m().is_{op}({arg}))'
        seg=once(seg,st,'QI_OBSERVE(marked); '+st)
    source=source[:start]+seg+source[end:]
core_out=out/'bool_rewriter.cpp'
core_out.write_text(source)
queue_path = root / 'src/smt/qi_queue.cpp'
queue = once(queue_path.read_text(), 'namespace smt {', 'qi_observation qi_observed;\n\nnamespace smt {')
queue = once(queue, '        m_context.get_rewriter()(instance, s_instance, pr);',
             '        { qi_observation_scope observe; m_context.get_rewriter()(instance, s_instance, pr); }')
queue_out = out / queue_path.name
queue_out.write_text(queue)
objects = []
for includes, source in (('includes_39', queue_out), ('includes_12', core_out)):
    includes = re.search(r'^'+includes+r' = (.*)$', makefile, re.M)[1]
    dest = out / (source.stem + '.o')
    command = [flags['CXX'], *shlex.split(flags['CXXFLAGS']), '-I'+str(out), *shlex.split(includes),
               '-include', str(observer), '-o', str(dest), str(source)]
    subprocess.run(command, cwd=build, check=True)
    objects.append(str(dest))
link = re.search(r'^z3\$\(EXE_EXT\):.*\n\t(.*)$', makefile, re.M)[1]
objects_and_libs = shlex.split(link.split('$(LINK_FLAGS)', 1)[1].split('$(LINK_EXTRA_FLAGS)', 1)[0]
                             .replace('$(OBJ_EXT)', '.o').replace('$(LIB_EXT)', '.a'))
subprocess.run([flags['LINK'], '-o', str(out/'z3'), *objects, *objects_and_libs, *shlex.split(flags['LINK_EXTRA_FLAGS'])],
               cwd=build, check=True)
