"""Test how collecting assumed-invariant symbols affects frontend interference."""
from pathlib import Path
import csv,json,os,subprocess,sys
w=Path(__file__).resolve().parent
ivy=Path.home()/'ivy/goivy'
src=ivy/'isolate.go'
out=csv.writer(sys.stdout);out.writerow(('phase','isolate','exit','passes','stderr'))
for phase in sys.argv[1:]:
    d=w/phase;d.mkdir(exist_ok=True)
    s=src.read_text()
    entries={'first':'mod.LabeledConjs, mod.AssumedInvs,','second':'mod.Definitions, mod.AssumedInvs,'}
    for k,old in entries.items():
        if phase==k or phase=='both-phases':
            assert s.count(old)==1
            s=s.replace(old,old.replace(' mod.AssumedInvs,',''))
    dst=d/'isolate.go.txt';dst.write_text(s)
    f=d/'overlay.json';f.write_text(json.dumps({'Replace':{str(src):str(dst),str(src.resolve()):str(dst)}}))
    exe=d/'goivy'
    subprocess.run(['go','build','-mod=readonly','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay',f,'-o',exe,'./cmd/goivy_check'],cwd=ivy,check=True)
    for case in ('rfn2','dramc_nb2'):
        r=subprocess.run([exe,'isolate='+case,Path.home()/'ivy/ivy-lang-examples/doc/examples/apple/ord_live.ivy'],cwd=d,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True,timeout=120)
        for k in ('stdout','stderr'):(d/(case+'.'+k)).write_bytes(getattr(r,k))
        out.writerow((phase,case,r.returncode,r.stdout.splitlines().count(b'PASS'),r.stderr.decode().strip()));sys.stdout.flush()
