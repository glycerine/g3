"""Build individual Boolean reduction experiments from the release."""
from pathlib import Path
import argparse,json,subprocess
p=argparse.ArgumentParser()
p.add_argument('name',choices=['marks','bools','binary','both'])
p.add_argument('--ivy',action='store_true')
a=p.parse_args()
root=Path.cwd();work=Path(__file__).resolve().parent
out=work/a.name;out.mkdir(exist_ok=True);files={}
def save(src,s):
    dst=out/src.name
    dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    files[str(src)]=files[str(Path.home()/'g3/pkg'/src.relative_to(root))]=str(dst)
if a.name in ('marks','both'):
    src=root/'ast/rewriter/bool_rewriter.go'
    s=src.read_text()
    lo=s.index('\t\t\tfor i := range rw.nflatSmall',s.index('set :='))
    hi=s.index('\t\t\trw.nflatSmall = append',lo)
    s=s[:lo]+s[hi:]
    s=s.replace('rw.nflatMarks[key] |= bit','rw.nflatMarks[key] = bit')
    save(src,s)
if a.name in ('bools','both'):
    src=root/'ast/ast_core_boolean_factories.go';s=src.read_text()
    for n in ['true','false']:
        start='func (m *ASTManager) Mk'+n.title()+'() (ASTHandle, error) {'
        s=s.replace(start,start+'\nif m!=nil && m.lockFree(){ return m.external(m.'+n+'App),nil }')
    save(src,s)
if a.name=='binary':
    src=root/'ast/rewriter/bool_rewriter.go';s=src.read_text()
    k='base := len(rw.nflatBuffer)'
    s=s.replace(k,'''if args.Count()==2 && (!disjunction || !rw.localContext || rw.localContextCost>rw.localContextLimit) {
        return rw.binaryConnective(args,out,disjunction)
    }
    '''+k)
    s+='''
// Handle two operands in evaluation order. The first absorbing constant
// finishes the reduction before the second operand is accessed.
func (rw *boolRewriter) binaryConnective(args ast.AppArguments,out ast.ASTRef,or bool)(brStatus,error){
    m:=rw.manager
    unit,err:=m.MkBoolVal(!or)
    if err!=nil{return brFailed,err}
    absorb,err:=m.MkBoolVal(or)
    if err!=nil{return brFailed,err}
    first,err:=args.At(0)
    if err!=nil{return brFailed,err}
    if first==absorb{return brDone,m.SetRef(out,absorb)}
    var firstNeg bool
    var firstAtom ast.ASTHandle
    if first!=unit{
        firstNeg,firstAtom,err=m.IsNot(first)
        if err!=nil{return brFailed,err}
        if !firstNeg{firstAtom=first}
    }
    second,err:=args.At(1)
    if err!=nil{return brFailed,err}
    if second==absorb{return brDone,m.SetRef(out,absorb)}
    if second==unit{return brDone,m.SetRef(out,first)}
    secondNeg,secondAtom,err:=m.IsNot(second)
    if err!=nil{return brFailed,err}
    if first==unit{return brDone,m.SetRef(out,second)}
    if !secondNeg{secondAtom=second}
    if firstAtom!=secondAtom{return brFailed,nil}
    if firstNeg!=secondNeg{return brDone,m.SetRef(out,absorb)}
    return brDone,m.SetRef(out,first)
}
'''
    save(src,s)
f=out/'overlay.json';f.write_text(json.dumps({'Replace':files}))
exe='goivy' if a.ivy else 'g3'
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-pgo=off','-overlay',f,'-o',out/exe,*(['-tags=xtrace_off','./cmd/goivy_check'] if a.ivy else ['./cmd/g3'])],cwd=Path.home()/'ivy/goivy' if a.ivy else root,check=True)
