"""Test the old mixin membership predicate in an isolated current-frontend build."""
from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent
ivy=Path.home()/'ivy/goivy'
src=ivy/'isolate.go'
s=src.read_text()
a='useMixin := func(name string) bool {\n\t\treturn StartsWithEqSome(name, present, mod, implementationMap)'
assert s.count(a)==1
dst=w/'isolate.go';dst.write_text(s.replace(a,a.replace('StartsWithEqSome','StartsWithSome')))
f=w/'mixin.json';f.write_text(json.dumps({'Replace':{str(src):str(dst),str(src.resolve()):str(dst)}}))
subprocess.run(['go','build','-mod=readonly','-tags=xtrace_off','-pgo=off','-buildvcs=false','-overlay',f,'-o',w/'mixin-goivy','./cmd/goivy_check'],cwd=ivy,check=True)
