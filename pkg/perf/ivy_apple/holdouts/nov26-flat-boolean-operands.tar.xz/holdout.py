"""Compare every integer search statistic on the six prior general rewrite queries."""
import csv,json,os,re,subprocess,sys,time
from pathlib import Path
w=Path(__file__).resolve().parent
perf,cpu=sys.argv[1:3]
engines=[(a,Path(b).resolve()) for a,b in (x.split('=',1) for x in sys.argv[3:])]
out=csv.writer(sys.stdout);out.writerow(('query','round','engine','instructions','cycles','milliseconds','answer','stats'))
for q in sorted((w/'queries').glob(os.environ.get('QUERY_PATTERN','*.smt2'))):
    ref=None
    for i in range(int(os.environ.get('ROUNDS','3'))):
        for engine,exe in engines[i%2:]+engines[:i%2]:
            f=w/(q.stem+'-'+str(os.getpid())+'-'+engine+'.stat')
            start=time.monotonic()
            r=subprocess.run(['taskset','-c',cpu,perf,'stat','-x,','-o',f,'-e','instructions:u,cycles:u','--',exe,'-st','-smt2',q],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1'),capture_output=True,text=True,timeout=100,check=True)
            ms=(time.monotonic()-start)*1000
            ans=r.stdout.splitlines()[0]
            stats={k:int(v) for k,v in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])',r.stdout) if not any(t in k for t in ['alloc','memory','time'])}
            assert ans==('unknown' if q.stem.startswith('miss') else 'unsat') and 'rlimit-count' in stats and not r.stderr,(q,r)
            if ref is None:ref=stats
            assert stats==ref,(q,stats,ref)
            hw={r[2]:int(r[0]) for r in csv.reader(f.read_text().splitlines()) if len(r)>4 and r[2].endswith(':u') and float(r[4])==100}
            out.writerow([q.stem,i+1,engine,hw['instructions:u'],hw['cycles:u'],round(ms,2),ans,json.dumps(stats,sort_keys=True)]);sys.stdout.flush()
