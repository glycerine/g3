"""Measure batch-level reuse of a binary witness for a group of unary counterexamples."""
from pathlib import Path
body=Path(__file__).with_name('order.py').read_text()
exec(body[:body.index('s=s[:a]+')])
s=s[:a]+''' p=pkg/'smtcore/smt_model_checker.go';v=p.read_text()
 v=edit(v,'type SMTModelChecker struct {','type SMTModelChecker struct {\\n trialChoice trialWitnessChoice')
 anchor='term, err = c.namedSecondBinding(quantifier, bindings[0], term, value, generation)'
 v=edit(v,anchor,'original:=term;'+anchor+';if TrialOrderMode!=0 && err==nil && term!=original {c.trialChoice=trialWitnessChoice{len(c.newInstances),quantifier,original,bindings[0],term}}')
 anchor='failures, err := c.checkQuantifiers(model, quantifiers, false)'
 v=edit(v,anchor,'c.trialChoice=trialWitnessChoice{};'+anchor+';if err==nil && TrialOrderMode!=0 && !c.exhausted {err=c.trialGroup(model,c.trialChoice,TrialOrderMode)}')
 put(p,v)
 p=pkg/'smtcore/smt_model_checker_repeated_binding.go';v=p.read_text().replace('import (','import ("os";"strconv";')
 fn=v[v.index('func (c *SMTModelChecker) falsifiesRepeatedBinding'):]
 fn=fn.replace('falsifiesRepeatedBinding','trialFalsified').replace('quantifier, value ast.ASTHandle','quantifier ast.ASTHandle, values []ast.ASTHandle').replace('[]ast.ASTHandle{value, value}','values')
 put(p,v+fn+(here/'group.go.txt').read_text())
'''+s[b:]
s=s.replace('github.com/glycerine/g3/pkg/ast/rewriter','github.com/glycerine/g3/pkg/smtcore').replace('rewriter.TrialEqualityChanges','smtcore.TrialOrderChanges')
s=s.replace('if !capturePush{return func(string){}};runtime.LockOSThread()', 'if !capturePush{return func(string){}};smtcore.StartGroupTrial();runtime.LockOSThread()').replace('runtime.UnlockOSThread();fmt.Fprintln','runtime.UnlockOSThread();smtcore.TrialOrderMode=0;fmt.Fprintln')
exec(compile(s,'group','exec'))
