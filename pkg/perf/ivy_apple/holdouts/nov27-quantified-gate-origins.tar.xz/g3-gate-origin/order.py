"""Test stable scheduling of repeated versus first-seen fingerprint tuples."""
import tarfile
from pathlib import Path
with tarfile.open('perf/ivy_apple/holdouts/nov27-fresh-equality-conditionals.tar.xz') as t:s=t.extractfile('study/rewrite.py').read().decode()
a=s.index(' boolsrc=');b=s.index(' for f,archive',a)
s=s[:a]+''' p=pkg/'smtcore/smt_qi_queue_schedule.go'
 v=p.read_text().replace('import "github.com/glycerine/g3/pkg/ast"','import ("github.com/glycerine/g3/pkg/ast";"os";"strconv")')
 v=edit(v,'manager           *ast.ASTManager','history map[[5]ast.ASTHandle]bool; orderScratch []SMTQIQueueEntry; manager *ast.ASTManager')
 v=edit(v,'sinceLastCheck := 0','if TrialOrderMode!=0 {q.trialOrder(TrialOrderMode)};sinceLastCheck := 0')
 v+=(here/'order.go.txt').read_text()
 put(p,v)
'''+s[b:]
s=s.replace('github.com/glycerine/g3/pkg/ast/rewriter','github.com/glycerine/g3/pkg/smtcore').replace('rewriter.TrialEqualityChanges','smtcore.TrialOrderChanges')
s=s.replace('if !capturePush{return func(string){}};runtime.LockOSThread()', 'if !capturePush{return func(string){}};smtcore.StartOrderTrial();runtime.LockOSThread()').replace('runtime.UnlockOSThread();fmt.Fprintln','runtime.UnlockOSThread();smtcore.TrialOrderMode=0;fmt.Fprintln')
exec(compile(s,'order','exec'))
