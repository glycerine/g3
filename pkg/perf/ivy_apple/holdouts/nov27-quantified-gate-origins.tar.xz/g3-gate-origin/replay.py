"""Replay the four differing native choices in the first MBQI burst on TLB 60/1."""
from pathlib import Path
body=Path(__file__).with_name('order.py').read_text()
exec(body[:body.index("s=s[:a]+")])
s=s[:a]+''' p=pkg/'smtcore/smt_model_checker.go';v=p.read_text()
 anchor='term, err = c.namedSecondBinding(quantifier, bindings[0], term, value, generation)'
 v=edit(v,anchor,'original:=term;'+anchor+';if err==nil && replayOn && replayCount==1415 && len(c.newInstances)==1 && term!=original && replayMask&1!=0 {term=original;TrialOrderChanges++}')
 put(p,v)
 p=pkg/'smtcore/smt_model_checker_instances.go';v=p.read_text()
 v=edit(v,'if c.pinsBusy {','if c.pinsBusy {') if False else v
 pos=v.index('if c.pinsBusy {',v.index('func (c *SMTModelChecker) pinInstance'))
 v=v[:pos]+"if replayOn && replayCount==1415 && len(c.newInstances)>=5 && len(c.newInstances)<=7 {c.trialUnary(quantifier, bindings, &generation)};"+v[pos:]
 put(p,v)
 p=pkg/'smtcore/smt_model_checker_repeated_binding.go';v=p.read_text().replace('import (','import ("os";"fmt";"strconv";')
 fn=v[v.index('func (c *SMTModelChecker) falsifiesRepeatedBinding'):]
 fn=fn.replace('falsifiesRepeatedBinding','trialFalsified').replace('quantifier, value ast.ASTHandle','quantifier ast.ASTHandle, values []ast.ASTHandle').replace('[]ast.ASTHandle{value, value}','values')
 put(p,v+fn+(here/'replay.go.txt').read_text())
 p=pkg/'smtcore/smt_qi_instance.go';v=p.read_text()
 v=edit(v,'if err = internalizer.internalizeInstance','if replayOn {replayCount++};if err = internalizer.internalizeInstance')
 put(p,v)
'''+s[b:]
s=s.replace('github.com/glycerine/g3/pkg/ast/rewriter','github.com/glycerine/g3/pkg/smtcore').replace('rewriter.TrialEqualityChanges','smtcore.TrialOrderChanges')
s=s.replace('if !capturePush{return func(string){}};runtime.LockOSThread()', 'if !capturePush{return func(string){}};smtcore.StartReplayTrial();runtime.LockOSThread()').replace('runtime.UnlockOSThread();fmt.Fprintln','runtime.UnlockOSThread();smtcore.EndReplayTrial();fmt.Fprintln')
s=s.replace('modes=[0,1,2,3,4]','modes=[0,1,2,4,8,14,15]')
s=s.replace("elif l.startswith(b'CHANGES '):","elif l.startswith(b'REPLAY '):\n                    with (res/'details.log').open('ab') as out:out.write(str((i,mode)).encode()+b' '+l)\n                elif l.startswith(b'CHANGES '):")
exec(compile(s,'replay','exec'))
