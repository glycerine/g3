"""Decompose fresh OR counts by the other solver's queue and checker observations."""
import csv
from pathlib import Path
from collections import defaultdict,Counter
import sys
p=Path(sys.argv[1])
records=[]
for engine in ('release','native'):
    rows=defaultdict(lambda:defaultdict(Counter))
    counts=Counter()
    src=(p/'arrivals'/(engine+'-0.tsv')).read_bytes()
    original=b''.join(l for l in src.splitlines(keepends=True) if l.startswith((b'ORIGIN\t',b'OPERAND\t')))
    assert original==(p/'data'/(engine+'-0.tsv')).read_bytes()
    for line in src.decode().splitlines():
        tag,*parts=line.split('\t')
        if tag in ('ARRIVE','CHECK'):
            flag,*k=parts
            rows[tuple(k)][tag][flag]+=1;counts[tag,flag]+=1
        elif tag=='ORIGIN':
            current=tuple(parts)
            rows[current][tag]['installs']+=1;counts[tag,'installs']+=1
        elif tag=='OPERAND':
            rows[current][tag]['all']+=1
            rows[current][tag]['fresh']+=int(parts[0])
    print(engine,counts)
    records.append(rows)
for engine,own,other in [('g3',*records),('native',*reversed(records))]:
    split=Counter();sources=Counter()
    for k,r in own.items():
        n=r['OPERAND']['fresh']
        if not n:continue
        t=other.get(k,{})
        if 'ORIGIN' in t:stage='installed'
        elif 'CHECK' in t:stage='checked, never installed' if t['CHECK'].get('false',0) else 'always satisfied'
        elif 'ARRIVE' in t:stage='queued, never checked'
        else:stage='absent'
        split[stage]+=n
        if stage=='absent':
            sources[tuple(sorted(r['ARRIVE']))]+=n
    print(engine,'gate occurrences by furthest other stage',dict(split),'sources for absent keys',dict(sources))
