"""Run a general witness rule through complete verifiers and check both output streams."""
from pathlib import Path
import tarfile,tempfile,os
body=Path(__file__).with_name('group.py').read_text()
exec(body[:body.rindex("exec(compile(s,")])
gen=s[s.index(" p=pkg/'smtcore/smt_model_checker.go'"):s.index(" for f,archive")]
from textwrap import dedent
here=Path(__file__).resolve().parent
pkg=Path.cwd()
def edit(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
with tempfile.TemporaryDirectory() as temp:
    d0=Path(temp);extra={}
    def put(p,v):
        if p.name=='smt_model_checker_repeated_binding.go':
            v=v.replace('var TrialOrderChanges,TrialOrderMode int','var TrialOrderChanges int;var TrialOrderMode='+os.environ.get('MODE','2'))
            if os.environ.get('CENSUS'):
                v=v.replace('import ("os";','import ("fmt";"os";')
                v=v.replace('TrialOrderChanges+=end-start+1','fmt.Fprintln(os.Stderr,"GROUP",end-start+1);TrialOrderChanges+=end-start+1')
        f=d0/p.name;f.write_text(v);extra[str(p)]=str(f)
    exec(dedent(gen))
    with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:
        if os.environ.get('CENSUS'):
            driver=t.extractfile('study/release.py').read().decode().replace("('base','trial','apple')","('trial','apple')")
            a=driver.index("    if name=='base':");b=driver.index("    j=d/",a);driver=driver[:a]+"    mp.update(extra)\n"+driver[b:]
            driver=driver[:driver.index(' def measure(')]+driver[driver.index(' with ThreadPoolExecutor(4)'):]
            driver=driver.replace('assert (r.returncode,r.stdout,r.stderr)==',"""lines=r.stderr.splitlines(keepends=True);hits=[int(line.split()[1]) for line in lines if line.startswith(b'GROUP ')]
        assert (r.returncode,r.stdout,b''.join(line for line in lines if not line.startswith(b'GROUP ')))==""")
            driver=driver.replace("return [case,'match']","return [case,'match',len(hits),sum(hits)]").replace("['case','transcript']","['case','transcript','batches','bindings']")
        else:
            driver=t.extractfile('study/panel.py').read().decode()
            driver=edit(driver,"mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())",'mp.update(extra)')
    exec(compile(driver,'run','exec'))
