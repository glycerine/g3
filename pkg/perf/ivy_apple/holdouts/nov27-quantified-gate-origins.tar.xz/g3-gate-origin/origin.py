"""Record every installed tuple and its root-level negated OR operands on TLB 60/1."""
from pathlib import Path
import tarfile,tempfile
here=Path(__file__).resolve().parent
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t,tempfile.TemporaryDirectory() as tmp:
    p=Path(tmp)
    for name in ('components.py','operand-kinds.py'):
        (p/name).write_bytes(t.extractfile('study/'+name).read())
    source=(p/'operand-kinds.py').read_text()
    d={'__file__':str(p/'operand-kinds.py')}
    exec(source[:source.rindex('exec(compile(s,')],d)
g,c,s,qgo,qcpp,edit=(d[k] for k in ('g','c','s','qgo','qcpp','edit'))
qgo+='\n'+(here/'shape.go.txt').read_text()
qgo=edit(qgo,'installMeter=fd;err=internalizer.internalizeInstance','''installMeter=fd;if fd>=0{line:="ORIGIN\\t"+studyShape(b.manager,result.quantifier);for _,arg:=range result.fingerprint.args {line+="\\t"+studyShape(b.manager,arg.owner)};fmt.Fprintln(os.Stderr,line)};err=internalizer.internalizeInstance''')
qcpp=(here/'shape.cpp.txt').read_text()+'\n'+qcpp
qcpp=edit(qcpp,'install_meter=fd;m_context.internalize_instance','''install_meter=fd;if(fd>=0){std::string line="ORIGIN\\t"+gate_study_shape(q);for(unsigned i=0;i<num_bindings;i++)line+="\\t"+gate_study_shape(bindings[i]->get_owner());fprintf(stderr,"%s\\n",line.c_str());}m_context.internalize_instance''')
g=edit(g,'if _,bound:=s.boolVar.lookup(term);!bound', '''if negative!=0{h,e:=s.manager.NodeHeader(term);if e!=nil{panic(e)};if h.Kind==ast.ASTApp && h.Family==s.manager.BasicFamilyID() && h.DeclKind==ast.ASTOpOr {_,known:=s.boolVar.lookup(term);fmt.Fprintf(os.Stderr,"OPERAND\\t%d\\t%s\\n",map[bool]int{false:1,true:0}[known],studyShape(s.manager,term))}};if _,bound:=s.boolVar.lookup(term);!bound''')
c='#include <string>\nstruct expr;extern std::string gate_study_shape(expr*);\n'+c
c=edit(c,'if(fd>=0 && !lit_internalized(arg)){','''if(fd>=0){expr*x=arg;if(m_manager.is_not(arg,x)&&m_manager.is_or(x))fprintf(stderr,"OPERAND\\t%d\\t%s\\n",int(!lit_internalized(arg)),gate_study_shape(x).c_str());}if(fd>=0 && !lit_internalized(arg)){''')
s=edit(s,'for line in r.stderr.splitlines(keepends=True):','rows=[]\n            for line in r.stderr.splitlines(keepends=True):')
s=edit(s,'elif active and a and a[0]',"""elif active and line.startswith((b'ORIGIN\\t',b'OPERAND\\t')):rows.append(line)
                elif active and a and a[0]""")
s=edit(s,"assert start==end==1","(out/(eng+'-'+str(i)+'.tsv')).write_bytes(b''.join(rows))\n            assert start==end==1")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
