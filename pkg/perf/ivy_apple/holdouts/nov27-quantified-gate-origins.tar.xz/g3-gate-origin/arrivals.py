"""Track each admitted tuple before the candidate checker and actual installation."""
from pathlib import Path
body=Path(__file__).with_name('origin.py').read_text()
exec(body[:body.rindex('exec(compile(s,')])
registry=Path('smtcore/smt_quantifier_registry.go').read_text()
registry=edit(registry,'import (','import (\n"os"')
registry=edit(registry,'if err = r.schedule.Insert(fingerprint, cost, maxGeneration);','''if studyFD()>=0{source:="pattern";if pattern.IsNull(){source="no-pattern"};studyTuple("ARRIVE",source,r.manager,quantifier,fingerprint.args);studyTuple("BEFORE",source,r.manager,quantifier,bindings)};if err = r.schedule.Insert(fingerprint, cost, maxGeneration);''')
qgo+='''
func studyTuple(tag,flag string,m *ast.ASTManager,q ast.ASTHandle,args []*SMTEnode){line:=tag+"\\t"+flag+"\\t"+studyShape(m,q);for _,arg:=range args{line+="\\t"+studyShape(m,arg.owner)};fmt.Fprintln(os.Stderr,line)}
'''
registry=registry.replace('import (\n"os"','import (')
qgo=edit(qgo,'studyLog(fd,a,"C",satisfied)','studyLog(fd,a,"C",satisfied);if fd>=0{studyTuple("CHECK",strconv.FormatBool(satisfied),b.manager,quantifier,bindings)}')
qcpp=edit(qcpp,'m_new_entries.push_back(entry(f, cost, generation));','''if(getenv("QI_COUNTER_FD")){std::string line=std::string("ARRIVE\\t")+(pat?"pattern":"no-pattern")+"\\t"+gate_study_shape(q);for(unsigned i=0;i<f->get_num_args();i++)line+="\\t"+gate_study_shape(f->get_arg(i)->get_owner());fprintf(stderr,"%s\\n",line.c_str());}m_new_entries.push_back(entry(f, cost, generation));''')
qcpp=edit(qcpp,'if(sat) {','''if(fd>=0){std::string line=std::string("CHECK\\t")+(sat?"true":"false")+"\\t"+gate_study_shape(q);for(unsigned i=0;i<num_bindings;i++)line+="\\t"+gate_study_shape(bindings[i]->get_owner());fprintf(stderr,"%s\\n",line.c_str());}if(sat) {''')
s=edit(s,"put(pkg/'smtcore/smt_internalizer.go'","put(pkg/'smtcore/smt_quantifier_registry.go',overlays['registry']);put(pkg/'smtcore/smt_internalizer.go'")
s=edit(s,"(b'ORIGIN\\t',b'OPERAND\\t')","(b'ORIGIN\\t',b'OPERAND\\t',b'ARRIVE\\t',b'CHECK\\t',b'BEFORE\\t')")
s=edit(s,"for i in range(2):","for i in range(1):")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('registry',registry),('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
