"""Cross the candidate rule with eight fresh-name histories in the same binary."""
from pathlib import Path
body=Path(__file__).with_name('group.py').read_text();exec(body[:body.rindex("exec(compile(s,")])
a=s.index(' for f,archive')
s=s[:a]+''' p=pkg/'ast/ast_core_fresh_factories.go';v=p.read_text().replace('import (','import ("fmt";"os";')
 v=edit(v,'if m.freshInfoActive ||','if ObserveHistoryCounter {ObserveHistoryCounter=false;if m.freshID!=407 || SetHistoryCounter<m.freshID {panic("fresh history")};fmt.Fprintln(os.Stderr,"FRESH",m.freshID,SetHistoryCounter);m.freshID=SetHistoryCounter};if m.freshInfoActive ||')
 put(p,v+'\\nvar ObserveHistoryCounter bool\\nvar SetHistoryCounter uint32\\n')
'''+s[a:]
s=s.replace('put(front/f,src)',"""if f.startswith('phase_'):
        src=src.replace('import (','import ("strconv";"github.com/glycerine/g3/pkg/ast";')
        src=edit(src,'phaseBatch++; return','phaseBatch++;if phaseBatch==60 {n,e:=strconv.Atoi(os.Getenv("FRESH_AT"));if e!=nil{panic(e)};ast.SetHistoryCounter=uint32(n);ast.ObserveHistoryCounter=true}; return')
    put(front/f,src)""")
s=s.replace('for i in range(3):','for i in range(2):')
s=s.replace('modes=[0,1,2,3,4];modes=modes[i:]+modes[:i]','modes=[(n,m) for n in range(407,415) for m in ([0,3] if i==0 else [3,0])]')
s=s.replace('for mode in modes:', 'for counter,mode in modes:').replace('ENCODING=str(mode)','FRESH_AT=str(counter),ENCODING=str(mode)')
s=s.replace("elif l.startswith(b'CHANGES '):","elif l.startswith(b'FRESH '):assert list(map(int,a[1:]))==[407,counter]\n                elif l.startswith(b'CHANGES '):")
s=s.replace("'policy','replacements'","'counter','policy','replacements'").replace('w.writerow([i,mode,*changes','w.writerow([i,counter,mode,*changes')
exec(compile(s,'history','exec'))
