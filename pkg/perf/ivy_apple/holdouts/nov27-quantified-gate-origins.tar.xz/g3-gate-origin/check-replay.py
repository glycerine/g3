"""Compare the entire resulting installation stream with native after the four choices."""
from pathlib import Path
import textwrap,os
here=Path(__file__).resolve().parent
r=here.joinpath('replay.py').read_text();exec(r[:r.rindex("exec(compile(s,")])
gen=s[s.index(" p=pkg/'smtcore/smt_model_checker.go'"):s.index(" for f,archive")]
r=here.joinpath('origin.py').read_text();exec(r[:r.rindex("exec(compile(s,")])
pkg=Path.cwd();more={}
def put(p,v):
    if p.name=='smt_qi_instance.go':return
    more[str(p)]=v.encode()
exec(textwrap.dedent(gen))
qgo=edit(qgo,'installMeter=fd;if fd>=0{line:','installMeter=fd;if fd>=0{replayOn=true;replayMask=15;replayCount++;line:')
s=edit(s,"put(pkg/'smtcore/smt_internalizer.go'","exec('for path,v in more.items():put(Path(path),v)');put(pkg/'smtcore/smt_internalizer.go'")
s=edit(s,"(b'ORIGIN\\t',b'OPERAND\\t')","(b'ORIGIN\\t',b'OPERAND\\t')") if False else s
s=edit(s,"elif active and line.startswith((b'ORIGIN","elif active and line.startswith(b'REPLAY '):pass\n                elif active and line.startswith((b'ORIGIN")
s=s.replace("('release','native')","('release',)").replace("['release','native']","['release']").replace("for i in range(2):","for i in range(1):")
os.environ['METER_LIB']=os.environ['NATIVE_LIBRARY']
exec(compile(s,'phase-driver','exec'),{'more':more,'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
