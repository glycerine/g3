"""Price verifier phases on the matched native search without expression printing."""
from pathlib import Path
import textwrap
here=Path(__file__).resolve().parent
body=here.joinpath('group.py').read_text()
exec(body[:body.rindex('exec(compile(s,')])
gen=s[s.index(" p=pkg/'smtcore/smt_model_checker.go'"):s.index(" for f,archive")]
r=here.joinpath('origin.py').read_text();exec(r[:r.index("qgo+=")])
more={};pkg=Path.cwd()
def put(p,v):
    if p.name=='smt_model_checker_repeated_binding.go':v=v.replace('var TrialOrderChanges,TrialOrderMode int','var TrialOrderChanges int;var TrialOrderMode int')
    more[str(p)]=v.encode()
exec(textwrap.dedent(gen))
# Enable the candidate only within the selected check.
s=edit(s,"if fn.startswith('z3bridge'):", """if fn.startswith('phase_observer') and not native:
            data=data.replace(b'import (',b'import ("github.com/glycerine/g3/pkg/smtcore";')
            data=data.replace(b'runtime.LockOSThread()',b'if capturePush{smtcore.TrialOrderMode=3};runtime.LockOSThread()').replace(b'runtime.UnlockOSThread()',b'smtcore.TrialOrderMode=0;runtime.UnlockOSThread()')
        if fn.startswith('z3bridge'):""")
s=edit(s,"put(pkg/'smtcore/smt_internalizer.go'","exec('for path,v in more.items():put(Path(path),v)');put(pkg/'smtcore/smt_internalizer.go'")
exec(compile(s,'phase-driver','exec'),{'more':more,'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
