"""Identify processor witnesses by the quantifier and binder that created them."""
from pathlib import Path
body=Path(__file__).with_name('origin.py').read_text()
exec(body[:body.rindex('exec(compile(s,')])
src=Path('ast/normal_forms/skolemizer.go').read_text()
src=edit(src,'import (','import (\n "os";"fmt";"strings"')
src=edit(src,'if x = hold(decl); x != nil {','''declName:=studyName(m,decl)
        if strings.HasPrefix(declName,"P:tlb.processor!") || strings.HasPrefix(declName,"C:tlb.processor!") {fmt.Fprintf(os.Stderr,"SKOLEM\\t%s\\t%d\\t%s\\n",declName,i,studyShape(m,q))}
        if x = hold(decl); x != nil {''')+'\n'+(here/'shape.go.txt').read_text()
cpp=Path('../src/ast/normal_forms/nnf.cpp').read_text()
cpp='#include <sstream>\n#include <cstdio>\nclass expr;extern std::string gate_study_shape(expr*);\n'+cpp
cpp=edit(cpp,'app * sk            = m().mk_app(sk_decl, args.size(), args.c_ptr());','''std::ostringstream ss;ss<<sk_decl->get_name();auto name=ss.str();if(name.find("P:tlb.processor!")==0 || name.find("C:tlb.processor!")==0)fprintf(stderr,"SKOLEM\\t%s\\t%u\\t%s\\n",name.c_str(),i,gate_study_shape(q).c_str());app * sk = m().mk_app(sk_decl, args.size(), args.c_ptr());''')
s=edit(s,"'qi_queue','smt_internalizer')","'qi_queue','smt_internalizer','nnf')")
s=edit(s,"put(pkg/'smtcore/smt_internalizer.go'","put(pkg/'ast/normal_forms/skolemizer.go',overlays['skolem-go']);put(pkg/'smtcore/smt_internalizer.go'")
s=edit(s,"elif active and line.startswith((b'ORIGIN","elif line.startswith(b'SKOLEM\\t'):rows.append((b'IN\\t' if active else b'OUT\\t')+line)\n                elif active and line.startswith((b'ORIGIN")
s=edit(s,"for i in range(2):","for i in range(1):")
exec(compile(s,'phase-driver','exec'),{'overlays':{k:v.encode() for k,v in [('skolem-go',src),('nnf.cpp',cpp),('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
