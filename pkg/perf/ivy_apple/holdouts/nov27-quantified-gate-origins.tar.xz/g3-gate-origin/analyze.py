"""Match installed quantifiers, ordered bindings and negated ORs at first use."""
import csv
import sys
from pathlib import Path
from collections import Counter,defaultdict
p=Path(sys.argv[1])
def load(engine):
    src=(p/(engine+'-0.tsv')).read_bytes()
    assert src==(p/(engine+'-1.tsv')).read_bytes()
    rows=defaultdict(list)
    for line in src.decode().splitlines():
        tag,*v=line.split('\t')
        if tag=='ORIGIN':
            key=tuple(v)
            entry=[]
            rows[key].append(entry)
        else:
            assert tag=='OPERAND' and len(v)==2
            entry.append((v[1],int(v[0])))
    return rows
a,b=load('release'),load('native')
out=defaultdict(lambda:[0,0,0,0,0])
def add(key, idx, row):
    v=out[key];v[idx]+=sum(k for _,k in row);v[idx+2]+=len(row)
totals=Counter()
with (p/'tuples.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['quantifier','bindings','g3_installs','native_installs','g3_fresh','native_fresh','g3_occurrences','native_occurrences'])
    for key in sorted(a.keys()|b.keys()):
        aa,bb=a.get(key,[]),b.get(key,[])
        n=min(len(aa),len(bb))
        totals['matched']+=n;totals['duplicate_keys']+=max(len(aa),len(bb))>1
        for i,xs in enumerate((aa,bb)):
            for row in xs[n:]:add('unmatched install',i,row)
        for ra,rb in zip(aa,bb):
            left,right=defaultdict(list),defaultdict(list)
            for expr,v in ra:left[expr].append(v)
            for expr,v in rb:right[expr].append(v)
            for expr in left.keys()|right.keys():
                la,lb=left[expr],right[expr]
                k=min(len(la),len(lb))
                for i,vs in enumerate((la,lb)):
                    add('different operand',i,[(expr,v) for v in vs[k:]])
                    add('same operand',i,[(expr,v) for v in vs[:k]])
                totals['pairs fresh only in g3']+=sum(x>y for x,y in zip(la,lb))
                totals['pairs fresh only in native']+=sum(x<y for x,y in zip(la,lb))
        w.writerow([key[0],repr(key[1:]),len(aa),len(bb),sum(v for r in aa for _,v in r),sum(v for r in bb for _,v in r),sum(map(len,aa)),sum(map(len,bb))])
print('instances',*(sum(map(len,x.values())) for x in (a,b)),'distinct tuples',len(a),len(b),'shared keys',len(a.keys() & b.keys()),'quantifiers',len({k[0] for k in a}),len({k[0] for k in b}))
print(totals);print('fresh g3/native, total operands g3/native')
for k,v in out.items():print(k,*v[:4])
assert tuple(sum(v[i] for v in out.values()) for i in (0,1))==(731,518)
qsets=[{k[0] for k in x} for x in (a,b)]
print('shared quantified bodies',len(qsets[0]&qsets[1]))
for eng,own,other,otherq in [('g3',a,b,qsets[1]),('native',b,a,qsets[0])]:
    counts=Counter()
    for k,rows in own.items():
        vals=Counter(expr for row in rows for expr,fresh in row if fresh)
        if k not in other:
            counts['unshared tuple for shared quantifier' if k[0] in otherq else 'unshared quantifier']+=sum(vals.values());continue
        matches=other[k]
        seen={expr for row in matches for expr,_ in row}
        fresh=Counter(expr for row in matches for expr,f in row if f)
        for expr,n in vals.items():
            counts['matched fresh occurrences']+=min(n,fresh[expr])
            counts['operand present, excess fresh occurrences' if expr in seen else 'operand absent']+=max(0,n-fresh[expr])
    print(eng,'order-independent fresh occurrence counts',dict(counts))
