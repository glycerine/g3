"""Translate the native witness names to the g3 namespace using the supplied correspondence."""
import re,sys,subprocess as sp
from pathlib import Path
p=Path(sys.argv[1]);out=p/'aligned'
pat=re.compile(rb'\((([PC]):tlb\.processor!)(\d+):tlb\.processor\)')
def translate(b):
    def sub(m):
        n=int(m[3])
        assert 13212<=n<=13221
        return b'('+m[1]+str(n-12805).encode()+b':tlb.processor)'
    return pat.sub(sub,b)
origins=[]
for engine in ('release','native'):
    raw=(p/'skolems'/(engine+'-0.tsv')).read_bytes()
    ordinary=b''.join(l for l in raw.splitlines(keepends=True) if l.startswith((b'ORIGIN\t',b'OPERAND\t')))
    assert ordinary==(p/'data'/(engine+'-0.tsv')).read_bytes()
    decls=[line.split(b'\t')[2:] for line in raw.splitlines() if b'\tSKOLEM\t' in line][-10:]
    assert len(decls)==10
    origins.append(decls)
    with (p/(engine+'-skolems.tsv')).open('wb') as out_decl:
        for x in decls:out_decl.write(b'\t'.join(x)+b'\n')
for i,(g,n) in enumerate(zip(*origins)):
    assert g[1:]==n[1:] and g[0].split(b'!')[0]==n[0].split(b'!')[0]
    assert int(g[0].split(b'!')[-1])==407+i and int(n[0].split(b'!')[-1])==13212+i
for d in ('data','canonical'):
    (out/d).mkdir(parents=True,exist_ok=True)
    for f in (p/d).glob('*.tsv'):
        b=f.read_bytes()
        (out/d/f.name).write_bytes(translate(b) if f.name.startswith('native') else b)
sp.run([sys.executable,p/'analyze.py',out/'data'],check=True)
if (out/'canonical/native-0.tsv').exists():
    (out/'arrivals').symlink_to('canonical',target_is_directory=True) if not (out/'arrivals').exists() else None
    sp.run([sys.executable,p/'queues.py',out],check=True)
