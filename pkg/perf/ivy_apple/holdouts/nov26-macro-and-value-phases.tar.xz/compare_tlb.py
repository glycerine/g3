"""Rotate independent macro and value-propagation builds on complete verifications."""
from pathlib import Path
import argparse
import csv
import json
import os
import subprocess
import time

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('trial', choices=('value-trials','macro-trials'))
p.add_argument('variants', nargs='+')
p.add_argument('--cpu', type=int, required=True)
p.add_argument('--rounds', type=int, default=5)
p.add_argument('--gc', default='100')
p.add_argument('--label', default='runs')
p.add_argument('--case', action='append')
args=p.parse_args()
base=Path(__file__).resolve().parent
trial=base/args.trial
env=dict(os.environ,GOMAXPROCS='1',GOGC=args.gc,XTRACE_OFF='1')
repo=Path.cwd()
ref=Path('/tmp/g3-nov24-day/archive-verifier-stacks')
cases={'tlb':('examples/liveness/tlb.ivy','',1)}
baseline=base/'value-trials/baseline'
engines={'baseline':baseline,'z3':repo/'build/.nov26-later/pair/native'}
engines.update((name,trial/name) for name in args.variants)
assert all((dir/'goivy_check').is_file() for dir in engines.values())
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (trial/(args.label+'.csv')).open('w') as stream:
    w=csv.writer(stream)
    w.writerow(('case','round','engine','gc','milliseconds','instructions','cycles'))
    for name in (args.case or ('hybrid','ticket_protocol','arm_rules3')):
        spec,isolate,exit=cases[name]
        assert not isolate
        gold=[(Path('/tmp/g3-nov24-day/holdout-streams')/name/p).read_bytes() for p in ('stdout','stderr')]
        for turn in range(args.rounds):
            labels=list(engines)
            offset=turn%len(labels)
            for label in labels[offset:]+labels[:offset]:
                d=engines[label]
                counts=d/(args.label+'.perf')
                cmd=['taskset','-c',str(args.cpu),perf,'stat','-x,','-o',counts,
                     '-e','instructions:u,cycles:u','--',d/'goivy_check',
                     Path.home()/'ivy/ivy-lang-examples'/spec]
                start=time.monotonic()
                r=subprocess.run(cmd,cwd=d,env=env,capture_output=True,timeout=120)
                ms=(time.monotonic()-start)*1e3
                if r.returncode!=exit or r.stdout!=gold[0] or r.stderr!=gold[1]:
                    (d/f'{name}-failure.stdout').write_bytes(r.stdout)
                    (d/f'{name}-failure.stderr').write_bytes(r.stderr)
                    raise RuntimeError((label,name,r.returncode,r.stderr[-150:]))
                hw={r[2]:int(r[0]) for r in csv.reader(counts.open()) if len(r)>4 and r[2].endswith(':u') and float(r[4])==100}
                w.writerow((name,turn+1,label,args.gc,f'{ms:.3f}',hw['instructions:u'],hw['cycles:u']))
                stream.flush()
        print(name,'verified',flush=True)
