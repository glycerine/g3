"""Read the solver-thread first-push counters and verify the complete transcript."""
from pathlib import Path
import csv
import json
import os
import subprocess

reference = Path('/tmp/g3-nov24-day/archive-verifier-stacks')
cases = json.loads((reference/'cases.json').read_text())
out = Path(__file__).resolve().parent
env = dict(os.environ, GOMAXPROCS='1', GOGC='100', XTRACE_OFF='1')
for name in ('ticket_protocol','hybrid'):
    spec, isolate, status=cases[name]
    assert not isolate
    gold=[(reference/'reference'/name/f).read_bytes() for f in ('stdout','stderr')]
    with (out/(name+'-events.csv')).open('w') as counters, (out/(name+'-phases.csv')).open('w') as phases:
        ec,pw=csv.writer(counters),csv.writer(phases)
        ec.writerow(('round','batch','visits','cache_lookups','cache_hits','substitution_lookups','substitution_hits','theory_reductions','expand','emptydefinitions','identity','unchanged','changed','macrolookup','macromatch','fixpoint','valuerow','valuechange'))
        pw.writerow(('round','batch','phase','calls','instructions','empty'))
        for turn in range(1,6):
            proof=subprocess.run(['taskset','-c','15',out/'goivy_check',Path.home()/'ivy/ivy-lang-examples'/spec],
                                 cwd=out,env=env,capture_output=True,timeout=60)
            stderr=[]
            for line in proof.stderr.splitlines(keepends=True):
                if line.startswith(b'FIRST-PUSH-PHASE '):
                    pw.writerow([turn,*line.decode().split()[1:]])
                elif line.startswith(b'FIRST-PUSH-COUNT '):
                    ec.writerow([turn,*line.decode().replace('[','').replace(']','').split()[1:]])
                else:
                    stderr.append(line)
            assert proof.returncode==status and proof.stdout==gold[0] and b''.join(stderr)==gold[1], (proof.returncode,stderr[-5:])
    print(name,'five matching transcripts', flush=True)
