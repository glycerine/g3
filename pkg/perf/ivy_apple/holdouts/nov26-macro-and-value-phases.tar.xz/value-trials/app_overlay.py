"""Build variants that send known application metadata directly into theory reducers."""
import json
import os
from pathlib import Path
import subprocess

pkg = Path.cwd().resolve()
ivy = Path.home()/'ivy/goivy'
out = Path(__file__).resolve().parent
env = dict(os.environ, PWD=str(ivy), GOCACHE='/tmp/g3-nov23-day/cache')
th='ast/rewriter/th_rewriter.go'
engine='ast/rewriter/rewriter_engine.go'
def sub(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)

def build(skip_uninterpreted):
    s=(pkg/th).read_text()
    sig='func (c *theoryRewriterConfiguration) reduceAppCore(decl ast.ASTHandle, args ast.AppArguments, out ast.ASTRef) (RewriteStatus, error) {'
    start=s.index(sig)
    end=s.index('func (c *theoryRewriterConfiguration) iteView',start)
    block=s[start:end]
    old='''	if family == m.BasicFamilyID() {
		kind, err := m.GetDeclKind(decl)
		if err != nil {
			return RewriteFailed, err
		}
		if kind == ast.ASTOpEq {'''
    block=sub(block, old,'''    var kind int32
    if family == m.BasicFamilyID() {
        kind, err = m.GetDeclKind(decl)
        if err != nil { return RewriteFailed,err }
    }
    return c.reduceKnownApp(decl,family,kind,args,out)
}
func (c *theoryRewriterConfiguration) reduceKnownApp(decl ast.ASTHandle, family ast.FamilyID, kind int32, args ast.AppArguments, out ast.ASTRef) (RewriteStatus,error) {
    m := c.owner.manager
    if family == m.BasicFamilyID() {
        if kind == ast.ASTOpEq {''')
    s=s[:start]+block+s[end:]
    mark='''	status, err := c.reduceAppCore(decl, args, out)
	if err != nil || status != RewriteDone && status != RewriteFailed {'''
    s=sub(s,mark,'''    status, err := c.reduceAppCore(decl, args, out)
    return c.finishAppReduction(decl,args,out,status,err)
}
func (c *theoryRewriterConfiguration) reduceAppFromHeader(header ast.ASTNodeHeader, args ast.AppArguments, out, proof ast.ASTRef) (RewriteStatus, error) {
    if err := c.owner.manager.SetRef(proof, ast.ASTHandle{}); err != nil { return RewriteFailed,err }
    status,err := c.reduceKnownApp(header.Decl,header.Family,header.DeclKind,args,out)
    return c.finishAppReduction(header.Decl,args,out,status,err)
}
func (c *theoryRewriterConfiguration) finishAppReduction(decl ast.ASTHandle, args ast.AppArguments, out ast.ASTRef, status RewriteStatus, err error) (RewriteStatus, error) {
    if err != nil || status != RewriteDone && status != RewriteFailed {''')
    x=(pkg/engine).read_text()
    start=x.index('func (r *rewriterEngine) processApp(')
    end=x.index('// processAppMacroEnd',start)
    block=x[start:end]
    old='''		d, e := m.GetDecl(t)
		if e != nil {
			return e
		}
		// f->is_associative() && t->get_ref_count() <= 1 &&
		// frame_stack().size() > 1: pure reads, the declaration's flags
		// read only when the cheaper tests pass.
		rc, e := m.GetRefCount(t)
		if e != nil {
			return e
		}'''
    block=sub(block,old,'''        var header ast.ASTNodeHeader
        var d ast.ASTHandle
        var rc uint32
        var e error
        theory, concrete := r.cfg.(*theoryRewriterConfiguration)
        if concrete && !ast.ASTValidateHandles {
            header,e=m.NodeHeader(t)
            if e != nil { return e }
            d,rc=header.Decl,header.RefCount
        } else {
            d,e=m.GetDecl(t)
            if e != nil { return e }
            rc,e=m.GetRefCount(t)
            if e != nil { return e }
        }''')
    mark='\t\tst, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)'
    block=sub(block,mark,'''        var st brStatus
        if concrete && !ast.ASTValidateHandles {
            st,e=theory.reduceAppFromHeader(header,args,r.r,r.pr2)
        } else {
            st,e=r.cfg.ReduceApp(d,args,r.r,r.pr2)
        }''')
    if skip_uninterpreted:
        mark='''        if concrete && !ast.ASTValidateHandles {
            st,e=theory.reduceAppFromHeader(header,args,r.r,r.pr2)'''
        block=sub(block, mark, '''        if concrete && !ast.ASTValidateHandles && header.Family==ast.NullFamilyID &&
            (!theory.pullCheapITE || args.Count()!=2) {
            st=RewriteFailed
        } else if concrete && !ast.ASTValidateHandles {
            st,e=theory.reduceAppFromHeader(header,args,r.r,r.pr2)''')
    return {th:s,engine:x[:start]+block+x[end:]}

for name, skip in [('known-uninterpreted',True)]:
    d=out/name
    d.mkdir(parents=True,exist_ok=True)
    if not (d/'abc').exists():
        (d/'abc').symlink_to('/tmp/g3-nov22b/spec-survey/with-abc-native/abc')
    overlay={}
    for file, s in build(skip).items():
        leaf=d/Path(file).name
        leaf.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
        for namespace in (pkg,Path('/home/jaten/g3/pkg')):
            overlay[str(namespace/file)]=str(leaf)
    ov=d/'overlay.json'
    ov.write_text(json.dumps({'Replace':overlay}))
    subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-tags=xtrace_off',
                    '-overlay='+str(ov),'-o',d/'goivy_check','./cmd/goivy_check'],
                    cwd=ivy,env=env,check=True)
    print(name,'built',flush=True)
