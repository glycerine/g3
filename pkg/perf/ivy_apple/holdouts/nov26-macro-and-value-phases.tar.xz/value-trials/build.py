"""Build independent first-push traversal and scoped-substitution alternatives."""
import json
import os
from pathlib import Path
import subprocess
import sys

pkg = Path.cwd().resolve()
ivy = Path.home()/'ivy/goivy'
out = Path(__file__).resolve().parent
env = dict(os.environ, PWD=str(ivy), GOCACHE='/tmp/g3-nov23-day/cache')

def read(name):
    return (pkg/name).read_text()

def sub(src, old, new):
    assert src.count(old)==1, old
    return src.replace(old,new)

def scoped_header():
    name='ast/ast_expr_substitution_scope.go'
    s=sub(read(name), '\tif size, e := m.allocator.Size(s.record); e != nil || size != astScopedExprSubstBytes {',
        '\tif !astValidateHandles { return a, nil }\n\tif size, e := m.allocator.Size(s.record); e != nil || size != astScopedExprSubstBytes {')
    return {name:s}

def asserted_refs():
    name='smtcore/smt_asserted_formulas.go'
    s=read(name).replace('import (','import (\n\t"github.com/glycerine/g3/pkg/util/diagnostic"',1)
    start=s.index('func (k *SMTKernel) preprocessAssertionMode(')
    end=s.index('func (k *SMTKernel) preprocessAssertionWith(',start)
    code=s[start:end]
    old='\tproofRef, err := k.manager.NewRef(ast.ASTHandle{})'
    new='''    if !ast.ASTValidateHandles && !diagnostic.TraceCompiled() && k.manager.TraceStream == nil &&
          !k.preprocessor.ProofGen() && !k.manager.Budget().InjectionArmed() &&
          !k.manager.NumeralService().RuntimeOwner().AllocationLimited() {
        disabled, err := k.manager.ProofsDisabled()
        if err != nil { return ast.ASTHandle{}, ast.ASTHandle{}, err }
        if disabled {
            if err := k.preprocessor.Rewrite(formula, resultRef); err != nil {
                return ast.ASTHandle{}, ast.ASTHandle{}, errors.Join(err,k.flushAssertedCache())
            }
            out, err := k.manager.StealRef(resultRef)
            if err != nil { return ast.ASTHandle{}, ast.ASTHandle{}, err }
            if !proof.IsNull() {
                if err := k.manager.IncRef(proof); err != nil {
                    return ast.ASTHandle{}, ast.ASTHandle{}, errors.Join(err,k.manager.DecRef(out))
                }
            }
            return out, proof, nil
        }
    }
'''+old
    return {name:s[:start]+sub(code,old,new)+s[end:]}

def fused():
    name='ast/ast_core_accessors.go'
    s=read(name)
    sig=s[s.index('func (m *ASTManager) NodeShape('):s.index('// AppIdentity')]
    extra=sig.replace('NodeShape(', 'SubstitutionNodeShape(').replace('numArgs uint32, err','numArgs uint32, knownMiss bool, err')
    extra=extra.replace('return 0, 0, 0, e','return 0, 0, 0, false, e')
    extra=extra.replace('if n.kind == ASTApp {', '''knownMiss = !astValidateHandles && m.lockFree() && h.origin == m.origin &&
        h.slot < m.nextNode && h.generation == n.generation && n.live && n.kind <= ASTQuantifier &&
        !n.hasFlag(astWasSubstitutionKey)
    if n.kind == ASTApp {''')
    extra=extra.replace('count, nil','count, knownMiss, nil').replace('n.rc, 0, nil','n.rc, 0, knownMiss, nil')
    result={name:s+'\n'+extra}
    name='ast/rewriter/rewriter_engine.go'
    s=read(name)
    start=s.index('func (r *rewriterEngine) visit(')
    end=s.index('func (r *rewriterEngine) processVar',start)
    code=s[start:end]
    code=sub(code,'\tsub, subProof, found, e := r.cfg.GetSubst(t)', '''var kind ast.ASTKind
    var rc, n uint32
    var e error
    var found, knownMiss bool
    var sub, subProof ast.ASTHandle
    _, tryShape := r.cfg.(*theoryRewriterConfiguration)
    tryShape = tryShape && !ast.ASTValidateHandles && depth != 0 && !t.IsNull()
    if tryShape {
        kind, rc, n, knownMiss, e = m.SubstitutionNodeShape(t)
        if e != nil { return false, e }
    }
    if !knownMiss {
        sub, subProof, found, e = r.cfg.GetSubst(t)
    }''')
    code=sub(code,'''	kind, rc, n, e := m.NodeShape(t)
	if e != nil {
		return false, e
	}''','''if !tryShape {
        kind, rc, n, e = m.NodeShape(t)
        if e != nil { return false, e }
    }''')
    result[name]=s[:start]+code+s[end:]
    return result

variants = {
    'baseline': {},
    'scoped-header': scoped_header(),
    'asserted-refs': asserted_refs(),
    'fused': fused(),
    'joint': scoped_header() | asserted_refs() | fused(),
}
for name in (sys.argv[1:] or list(variants)):
    d=out/name
    d.mkdir(parents=True,exist_ok=True)
    if not (d/'abc').exists():
        (d/'abc').symlink_to('/tmp/g3-nov22b/spec-survey/with-abc-native/abc')
    overlay={}
    for file,s in variants[name].items():
        destination=d/Path(file).name
        destination.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
        for namespace in (pkg,Path('/home/jaten/g3/pkg')):
            overlay[str(namespace/file)]=str(destination)
    ov=d/'overlay.json'
    ov.write_text(json.dumps({'Replace':overlay}))
    subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-tags=xtrace_off',
                    '-overlay='+str(ov),'-o',d/'goivy_check','./cmd/goivy_check'],cwd=ivy,env=env,check=True)
    print(name,'built',flush=True)
