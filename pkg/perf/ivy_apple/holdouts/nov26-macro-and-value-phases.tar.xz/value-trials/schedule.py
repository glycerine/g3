"""Measure the upper bound of omitting one direction of first-push value propagation."""
import json
import os
from pathlib import Path
import subprocess

pkg=Path.cwd().resolve()
ivy=Path.home()/'ivy/goivy'
out=Path(__file__).resolve().parent
env=dict(os.environ,PWD=str(ivy),GOCACHE='/tmp/g3-nov23-day/cache')
file='smtcore/smt_asserted_propagate.go'
source=(pkg/file).read_text()
configs={
    'forward-first': 'reverse',
    'reverse-first': '!reverse',
    'forward-stable': 'reverse && !changed',
}
for label,condition in configs.items():
    mark='\tfor _, reverse := range []bool{false, true} {'
    assert source.count(mark)==1
    text=source.replace(mark,mark+f'\n\t\tif k.skipRepeatedPreprocessing && {condition} {{continue}}')
    d=out/label
    d.mkdir(parents=True,exist_ok=True)
    if not (d/'abc').exists():
        (d/'abc').symlink_to('/tmp/g3-nov22b/spec-survey/with-abc-native/abc')
    patched=d/Path(file).name
    patched.write_bytes(subprocess.check_output(['gofmt'],input=text.encode()))
    ov=d/'overlay.json'
    ov.write_text(json.dumps({'Replace':{str(pkg/file):str(patched),
        str(Path('/home/jaten/g3/pkg')/file):str(patched)}}))
    subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-tags=xtrace_off',
                    '-overlay='+str(ov),'-o',d/'goivy_check','./cmd/goivy_check'],cwd=ivy,env=env,check=True)
    print(label,'built',flush=True)
