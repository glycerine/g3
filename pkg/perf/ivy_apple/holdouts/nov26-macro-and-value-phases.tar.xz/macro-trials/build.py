"""Test lexical, proof-free macro scratch reuse with the same refutation workload."""
import json
import os
from pathlib import Path
import subprocess
import sys

pkg = Path.cwd().resolve()
ivy = Path.home()/'ivy/goivy'
out = Path(__file__).resolve().parent
env = dict(os.environ, PWD=str(ivy), GOCACHE='/tmp/g3-nov23-day/cache')

def read(name):
    return (pkg/name).read_text()

def sub(src, old, new):
    assert src.count(old)==1, old
    return src.replace(old,new)

def scratch(traverse, normalize, refs):
    finder='ast/macros/macro_finder.go'
    src=read(finder)
    new_import='\n\t"github.com/glycerine/g3/pkg/util/diagnostic"'
    src=sub(src,'\n\t"errors"','\n\t"errors"'+new_import)
    sig='\tfor _, row := range input.rows {'
    prefix='''    useScratch := !proofs && !ast.ASTValidateHandles && !diagnostic.TraceCompiled() &&
        f.manager.TraceStream == nil && !f.manager.Budget().InjectionArmed() &&
        !f.manager.NumeralService().RuntimeOwner().AllocationLimited()
    var temp *macroExpansionScratch
    if useScratch && len(input.rows) != 0 {
        temp = &macroExpansionScratch{}
        defer func() {
            result = errors.Join(result,temp.close())
        }()
    }
'''
    old_refs='''		out, e := f.manager.NewRef(ast.ASTHandle{})
		if e != nil {
			return fail(e)
		}
		outProof, e := f.manager.NewRef(ast.ASTHandle{})
		if e != nil {
			_ = f.manager.DelRef(&out)
			return fail(e)
		}
'''
    if refs:
        prefix+='''    var reusableOut, reusableProof ast.ASTRef
    if temp != nil {
        reusableOut, err = f.manager.NewRef(ast.ASTHandle{})
        if err != nil { return fail(err) }
        defer func(){ result=errors.Join(result,f.manager.DelRef(&reusableOut)) }()
        reusableProof, err = f.manager.NewRef(ast.ASTHandle{})
        if err != nil { return fail(err) }
        defer func(){ result=errors.Join(result,f.manager.DelRef(&reusableProof)) }()
    }
'''
        body=src[src.index('func (f *Finder) pass('):]
        body=sub(body,old_refs,'''        out, outProof := reusableOut, reusableProof
        var e error
        if temp == nil {
            out, e = f.manager.NewRef(ast.ASTHandle{})
            if e != nil {return fail(e)}
            outProof, e = f.manager.NewRef(ast.ASTHandle{})
            if e != nil { _=f.manager.DelRef(&out); return fail(e) }
        }
        release := func() error {
            if temp != nil {
                return errors.Join(f.manager.ResetRefHeld(outProof), f.manager.ResetRefHeld(out))
            }
            return errors.Join(f.manager.DelRef(&outProof), f.manager.DelRef(&out))
        }
''')
        start=body.index('		proof := row.Proof')
        body=body[:start]+body[start:].replace('f.manager.DelRef(&outProof), f.manager.DelRef(&out)','release()')
        src=src[:src.index('func (f *Finder) pass(')]+body
    src=sub(src,sig,prefix+sig)
    src=sub(src,'f.macros.ExpandMacros(row.Expression, proof, row.Dependency, out, outProof)',
                'f.macros.expandMacros(row.Expression, proof, row.Dependency, out, outProof,temp)')
    expander='ast/macros/macro_expander.go'
    s=read(expander)
    exact='func (m *Manager) ExpandMacros(term, proof ast.ASTHandle, dependency ast.ASTDependency, out, outProof ast.ASTRef) (resultDependency ast.ASTDependency, result error) {'
    s=sub(s,exact,'''type macroExpansionScratch struct {
    norm *macroTheoryNormalizer
    expansion *rewriter.Traversal
    configuration macroExpanderConfig
}

func (s *macroExpansionScratch) close() error {
    var result error
    if s.expansion != nil { result=s.expansion.Close() }
    return errors.Join(result, s.norm.close())
}

'''+exact+'''
    return m.expandMacros(term, proof, dependency, out, outProof, nil)
}

func (m *Manager) expandMacros(term, proof ast.ASTHandle, dependency ast.ASTDependency, out, outProof ast.ASTRef, scratch *macroExpansionScratch) (resultDependency ast.ASTDependency, result error) {''')
    if traverse:
        original='''		if proofs {
			traversal, err = rewriter.NewProofTraversal(m.manager, cfg)
		} else {
			traversal, err = rewriter.NewTraversal(m.manager, cfg)
		}'''
        s=sub(s,original,'''        if scratch != nil {
            cfg=&scratch.configuration
            cfg.owner=m
            traversal=scratch.expansion
            if traversal==nil {
                traversal,err=rewriter.NewTraversal(m.manager,cfg)
                scratch.expansion=traversal
            }
        } else if proofs {
            traversal, err = rewriter.NewProofTraversal(m.manager, cfg)
        } else {
            traversal, err = rewriter.NewTraversal(m.manager, cfg)
        }''')
        s=sub(s,'\t\tif e = errors.Join(e, cfg.close(), traversal.Close()); e != nil {','''        e = errors.Join(e, cfg.close())
        if scratch == nil {
            e = errors.Join(e,traversal.Close())
        } else if e == nil {
            e = traversal.Reset()
        }
        if e != nil {''')
    if normalize:
        old='''	normalizer, err := newMacroTheoryNormalizer(m.manager, m.paramsContext, m.globals)
	if err != nil {
		return resultDependency, err
	}
	defer func() { result = errors.Join(result, normalizer.close()) }()'''
        s=sub(s,old,'''    var normalizer *macroTheoryNormalizer
    if scratch != nil { normalizer=scratch.norm }
    if normalizer==nil {
        normalizer,err=newMacroTheoryNormalizer(m.manager,m.paramsContext,m.globals)
        if err != nil {return resultDependency, err}
        if scratch != nil {
            scratch.norm=normalizer
        } else {
            defer func(){result=errors.Join(result,normalizer.close())}()
        }
    }
    if scratch != nil {
        defer func(){result=errors.Join(result,normalizer.rewrite.Reset())}()
    }''')
    return {finder:src,expander:s}

variants={
 'normalizer': (False,True,False),
 'traversal': (True,False,False),
 'refs': (False,False,True),
 'combined': (True,True,True),
}

for name in (sys.argv[1:] or list(variants)):
    d=out/name
    d.mkdir(parents=True,exist_ok=True)
    if not (d/'abc').exists():
        (d/'abc').symlink_to('/tmp/g3-nov22b/spec-survey/with-abc-native/abc')
    overlay={}
    for file,s in scratch(*variants[name]).items():
        destination=d/Path(file).name
        destination.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
        for namespace in (pkg,Path('/home/jaten/g3/pkg')):
            overlay[str(namespace/file)]=str(destination)
    ov=d/'overlay.json'
    ov.write_text(json.dumps({'Replace':overlay}))
    subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-tags=xtrace_off',
                    '-overlay='+str(ov),'-o',d/'goivy_check','./cmd/goivy_check'],cwd=ivy,env=env,check=True)
    print(name,'built',flush=True)
