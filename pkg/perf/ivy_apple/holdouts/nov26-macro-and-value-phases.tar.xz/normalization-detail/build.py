"""Instrument reduction phases on the first physical push of each solver."""
from pathlib import Path
import json, os, subprocess

pkg = Path.cwd().resolve()
pkg_import = '/home/jaten/g3/pkg'
ivy = Path.home()/'ivy/goivy'
out = Path(__file__).resolve().parent
mapping = {}
def overlay(name, src):
    p=out/Path(name).name
    p.write_bytes(subprocess.check_output(['gofmt'],input=src.encode()))
    for root in (pkg, Path(pkg_import)):
        mapping[str(root/name)]=str(p)
    return p

pkg_file='util/firstpushcounter/count.go'
for root in (pkg, Path(pkg_import)):
    mapping[str(root/pkg_file)]=str(out/'firstpushcounter.go')
counter='import "github.com/glycerine/g3/pkg/util/firstpushcounter"'
def add_import(s):
    i=s.index('\n')
    return s[:i+1]+counter+'\n'+s[i+1:]

name='smtcore/smt_asserted_driver.go'
s=add_import((pkg/name).read_text())
needle='\tif err := assertedVerbose(10, "(smt."+pass.sourceName()+")\\n"); err != nil {'
assert s.count(needle)==1
s=s.replace(needle,'\tdefer firstpushcounter.Leave(firstpushcounter.Enter("pass."+pass.sourceName()))\n'+needle)
s=s.replace('func (k *SMTKernel) reduceAssertedPending() (bool, error) {',
    'func (k *SMTKernel) reduceAssertedPending() (bool, error) {\n'
    '\tdefer firstpushcounter.Leave(firstpushcounter.Enter("reduce-asserted"))')
overlay(name,s)

name='smtcore/smt_kernel.go'
s=add_import((pkg/name).read_text())
sig='func (k *SMTKernel) internalizePending() (resultErr error) {'
assert s.count(sig)==1
s=s.replace(sig,sig+'\n\tdefer firstpushcounter.Leave(firstpushcounter.Enter("internalize-pending"))')
start=s.index(sig)
end=s.index('func (k *SMTKernel)',start+len(sig))
code=s[start:end].replace('\tif k.assertedFormulasInconsistent() {',
    '\tdefer firstpushcounter.Leave(firstpushcounter.Enter("internalize-and-commit"))\n\tif k.assertedFormulasInconsistent() {',1)
overlay(name,s[:start]+code+s[end:])

name='ast/rewriter/rewriter_engine.go'
s=add_import((pkg/name).read_text())
start=s.index('func (r *rewriterEngine) visit(t ast.ASTHandle, depth uint32)')
end=s.index('func (r *rewriterEngine) ',start+10)
code=s[start:end]
for mark, event in [('\tif r.substituteVariables {','Visit'),('\t\th, e := c.getCached(t)','CacheLookup'),('\t\t\tif e = r.sameSort(t, h); e != nil {','CacheHit')]:
    assert code.count(mark)==1
    code=code.replace(mark, '\tfirstpushcounter.Count(firstpushcounter.'+event+')\n'+mark)
overlay(name,s[:start]+code+s[end:])

name='ast/rewriter/th_rewriter.go'
s=add_import((pkg/name).read_text())
s=s.replace('\tvar dependency ast.ASTDependency\n\tfound, err := c.owner.manager.ExprSubstitutionFindDependency',
    '\tvar dependency ast.ASTDependency\n\tfirstpushcounter.Count(firstpushcounter.SubstitutionLookup)\n\tfound, err := c.owner.manager.ExprSubstitutionFindDependency',1)
s=s.replace('\tif err != nil || !found || dependency.IsNull() {','\tif found {firstpushcounter.Count(firstpushcounter.SubstitutionHit)}\n\tif err != nil || !found || dependency.IsNull() {',1)
sig='func (c *theoryRewriterConfiguration) reduceAppCore(decl ast.ASTHandle, args ast.AppArguments, out ast.ASTRef) (RewriteStatus, error) {'
assert s.count(sig)==1
s=s.replace(sig,sig+'\n\tfirstpushcounter.Count(firstpushcounter.TheoryReducer)')
overlay(name,s)

def annotate(file, markers):
    src=add_import((pkg/file).read_text())
    for old, hook in markers:
        assert src.count(old)==1, (file,old)
        src=src.replace(old,hook)
    overlay(file,src)

def span(sig, tag):
    return sig, sig + '\n\tdefer firstpushcounter.Leave(firstpushcounter.Enter("'+tag+'"))'

def count(mark, event):
    return mark, mark+'\n\tfirstpushcounter.Count(firstpushcounter.'+event+')'

annotate('ast/macros/macro_expander.go', [
    span('func (m *Manager) ExpandMacros(term, proof ast.ASTHandle, dependency ast.ASTDependency, out, outProof ast.ASTRef) (resultDependency ast.ASTDependency, result error) {', 'macro.expand'),
    count('if !m.HasMacros() {', 'EmptyDefinitions'),
    count('if m.chargeUnchangedExpansion(term) {', 'Identity'),
    count('if !changed {', 'Unchanged'),
    count('changed = true', 'Changed'),
    span('func (m *Manager) expandMacrosStep(cfg *macroExpanderConfig, traversal *rewriter.Traversal, proofs bool, oldTerm, oldProof, out, outProof ast.ASTRef, resultDependency *ast.ASTDependency) (bool, error) {', 'macro.traverse'),
    count('current, err := m.manager.RefGet(out)', 'Fixpoint'),
    count('func (c *macroExpanderConfig) GetSubst(term ast.ASTHandle) (ast.ASTHandle, ast.ASTHandle, bool, error) {', 'MacroLookup'),
    span('func (c *macroExpanderConfig) expand(substitution *rewriter.VarSubstitution, term, declaration ast.ASTHandle, entry managerEntry) (ast.ASTHandle, ast.ASTHandle, bool, error) {', 'macro.actual-replacement'),
    count('result, proof, ok, err := c.expand(substitution, term, declaration, c.owner.entries[i])', 'MacroMatch'),
    ('\tif !m.HasMacros() {', '\tfirstpushcounter.Count(firstpushcounter.Expand)\n\tif !m.HasMacros() {'),
    ('\tnormalizer, err := newMacroTheoryNormalizer(m.manager, m.paramsContext, m.globals)', '\tdefer firstpushcounter.Leave(firstpushcounter.Enter("macro.normalize"))\n\tconstructor := firstpushcounter.Enter("macro.normalizer-construction")\n\tnormalizer, err := newMacroTheoryNormalizer(m.manager, m.paramsContext, m.globals)\n\tfirstpushcounter.Leave(constructor)'),
    ('\tdefer func() { result = errors.Join(result, normalizer.close()) }()', '\tdefer func() {\n\t defer firstpushcounter.Leave(firstpushcounter.Enter("macro.normalizer-close"))\n\t result = errors.Join(result, normalizer.close())\n\t}()'),
    ('\tbefore, err := m.manager.RefGet(out)', '\tdefer firstpushcounter.Leave(firstpushcounter.Enter("macro.normalizer-rewrite"))\n\tbefore, err := m.manager.RefGet(out)'),
    ('\t\tif proofs {\n\t\t\ttraversal, err = rewriter.NewProofTraversal(m.manager, cfg)', '\t\ttiming := firstpushcounter.Enter("macro.traversal-new")\n\t\tif proofs {\n\t\t\ttraversal, err = rewriter.NewProofTraversal(m.manager, cfg)'),
    ('\t\tdone, e := m.expandMacrosStep', '\t\tfirstpushcounter.Leave(timing)\n\t\tdone, e := m.expandMacrosStep'),
    ('\t\tif e = errors.Join(e, cfg.close(), traversal.Close()); e != nil {', '\t\ttiming = firstpushcounter.Enter("macro.traversal-close")\n\t\te = errors.Join(e, cfg.close(), traversal.Close())\n\t\tfirstpushcounter.Leave(timing)\n\t\tif e != nil {'),
])
annotate('ast/macros/macro_expansion_identity.go', [
    span('func (m *Manager) chargeUnchangedExpansion(term ast.ASTHandle) bool {','macro.identity'),
])
annotate('ast/macros/macro_finder.go', [
    span('func (f *Finder) pass(input *FormulaBatch) (output *FormulaBatch, found bool, result error) {','macro.finder-pass'),
])
annotate('smtcore/smt_asserted_macros.go', [
    span('func (k *SMTKernel) replacePendingMacroBatch(batch *macros.FormulaBatch) error {','macro.publish-and-reduce'),
])
annotate('smtcore/smt_asserted_propagate.go', [
    span('func (k *SMTKernel) addAssertionSubstitution(assertion SMTKernelAssertion, depth map[ast.ASTHandle]uint32) error {','values.insert'),
    span('func (k *SMTKernel) rewritePendingAssertion(index int) (bool, error) {','values.rewrite-row'),
    count('old := k.assertions[index]', 'ValueRow'),
    ('\tchanged := formula != old.Formula', '\tchanged := formula != old.Formula\n\tif changed {firstpushcounter.Count(firstpushcounter.ValueChange)}'),
])
input_file=out.parent/'z3bridge_solver_model.go'
mapping[str(ivy/input_file.name)]=str(input_file)
name='z3bridge_first_push_profile.go'
p=out/name
p.write_text('''package goivy
import "github.com/glycerine/g3/pkg/util/firstpushcounter"
var profileBatchNumber int
func nextProfileBatch() int {profileBatchNumber++;return profileBatchNumber}
func recordFirstPush(batch int) func() {return firstpushcounter.Begin(batch)}
''')
mapping[str(ivy/name)]=str(p)
ov=out/'overlay.json'
ov.write_text(json.dumps({'Replace':mapping}))
subprocess.run(['go','build','-p','3','-pgo=off','-buildvcs=false','-mod=readonly','-tags=xtrace_off',
                '-overlay='+str(ov),'-o',str(out/'goivy_check'),'./cmd/goivy_check'],cwd=ivy,
                env=dict(os.environ,PWD=str(ivy),GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
