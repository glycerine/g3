"""Count native macro expansion subphases at the same physical first pushes."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

pkg=Path.cwd().resolve()
sys.path.insert(0,str(pkg/'perf/ivy_apple/incremental_cost'))
from first_pass_instructions import measure
from first_push_rewrite_rows import build_checker, make_value

out=Path(__file__).resolve().parent
ivy=(Path.home()/'ivy/goivy').resolve()
probe=pkg/'build/.nov26-first-push-profile/matched-hybrid/build/ivy/goivy'
src=pkg.parent/'src'
native=pkg.parent/'build'
original=ivy/'z3vendor/native_lib/libz3.a'
archive=out/'libz3.a'
shutil.copyfile(original,archive)
sources={ivy/name:probe/name for name in ('z3bridge_solver_model.go','logical_window.go')}
config=(native/'config.mk').read_text()
makefile=(native/'Makefile').read_text()
for unit in ('macro_manager','macro_finder'):
    name=unit+'.cpp'
    member=unit+'.o'
    item=src/'ast/macros'/name
    assert subprocess.check_output(['ar','p',original,member])==(native/'ast/macros'/member).read_bytes()
    s=item.read_text()
    def add(mark,text):
        global s
        assert s.count(mark)==1, (unit,mark)
        s=s.replace(mark,mark+text)
    if unit=='macro_manager':
        sig='void macro_manager::expand_macros(expr * n, proof * pr, expr_dependency * dep, expr_ref & r, proof_ref & new_pr, expr_dependency_ref & new_dep) {'
        add(sig, '\n    pass_instruction_span observed("macro.expand");')
        add('        for (;;) {\n            macro_expander_rw proc(m, *this);',
            '\n            pass_instruction_span traversal("macro.iteration");')
        add('        if (change) {\n            th_rewriter rw(m);',
            '\n            pass_instruction_span normalization("macro.normalize-rewrite");')
    else:
        sig='bool macro_finder::expand_macros(unsigned num, justified_expr const * fmls, vector<justified_expr>& new_fmls) {'
        add(sig,'\n    pass_instruction_span observed("macro.finder-pass");')
    patched=out/name
    patched.write_text('#include "test/perf/asserted_pass_interval.h"\n'+s)
    rule=re.search(r"\$\((includes_\d+)\).*"+ re.escape("../src/ast/macros/"+name)+r"$",makefile,re.M)
    assert rule
    subprocess.run([*make_value(config,'CXX'),*make_value(config,'CXXFLAGS'),
                    *make_value(makefile,rule[1]),'-o',out/member,patched],cwd=native,check=True)
    subprocess.run(['ar','rcs',archive,out/member],check=True)
adapter=ivy/'smt/quantifier.go'
patched=out/'quantifier.go'
patched.write_text(adapter.read_text().replace("${SRCDIR}/../z3vendor/native_lib/libz3.a",str(archive)))
sources[adapter]=patched
binary=build_checker(ivy,out,sources,Path('/tmp/g3-nov22b/spec-survey/with-abc-native/abc'),True)
ref=Path('/tmp/g3-nov24-day/archive-verifier-stacks')
cases=json.loads((ref/'cases.json').read_text())
for case in ('hybrid','ticket_protocol'):
    spec,isolate,status=cases[case]
    args=argparse.Namespace(spec=Path.home()/'ivy/ivy-lang-examples'/spec,isolate=isolate,
                            expect_exit=status, cpu=16, reference=ref/'reference'/case)
    for r in range(1,4):
        dest=out/f'{case}-{r}'
        print(case,r,measure(args,binary,dest),flush=True)
