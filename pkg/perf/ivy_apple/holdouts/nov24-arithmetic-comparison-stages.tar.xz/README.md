# Arithmetic comparison and polynomial cancellation on matched search histories

The baseline is g3 28a3f0ce6, GoIvy 832e392ef, Go 1.27.3 and the native binary built in the same g3 repository. Run on Linux with user-mode instruction counters enabled. Use a fresh output directory for each configuration.

    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/cancel --cpu 2 --stage cancel --query toy-consensus-18
    python3 replay.py --pkg /path/to/g3/pkg --output /tmp/arithmetic-bounds --cpu 2 --variant identity+bound+power+normal

stages/ contains raw solver-thread instruction counts after empty-bracket calibration, across five alternating rounds, four inputs, two repetition counts and two engines. Use the median of (instructions at 32 minus instructions at 4) divided by 28. Each engine's verdict and five cumulative search counters were compared at every repetition. Stage brackets are inclusive, span different callers, and overlap across builds. The power row brackets Go's reduction helper and the C++ target predicate, which execute different numbers of times.

warm/ gives five uninstrumented whole-process instruction pairs for every query and variant. One suspended Toy Consensus observation was repeated with the same binary, input and CPU and the uninterrupted instruction count is used. Search files give one 32-check run per binary. Use perf/ivy_apple/holdouts/warm_queries.py for whole-shell reproduction against built binaries. Simplifications has all 7,408 source commands and the exact original g3 output. The comparisons include equality, strict and non-strict order, large and negative integers, real fractions, casts and quantified inputs under four option profiles. The native shell parsed and simplified the entire input independently. Exact g3 comparison is against the original g3 output.

verifiers/ contains three rotations per g3 variant on ARM, Ticket, Hermes, hybrid broadcast and Apple rfn2. Complete outputs including expected verification errors were compared with each workload's ordinary reference. Each CPU-pinned verifier includes startup, diagnostics and solver code. See perf/ivy_apple/holdouts and the public specifications named in PERF_STUDY.md.
