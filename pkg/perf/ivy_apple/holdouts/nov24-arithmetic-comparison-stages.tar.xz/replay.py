"""Replay the arithmetic stage counters or an uninstrumented simplification variant on Linux."""
import argparse
import csv
import gzip
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pkg', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--cpu', type=int, required=True)
parser.add_argument('--stage', choices=['comparison','cancel','bound','factor-gcd','to-real','negative-poly','power'])
parser.add_argument('--variant', default='control')
parser.add_argument('--query', default='toy-consensus-18')
parser.add_argument('--pairs', type=int, default=5)
parser.add_argument('--iterations', type=int, nargs='+', default=[4,32])
args = parser.parse_args()
pkg = args.pkg.resolve()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(pkg/'perf/ivy_apple/holdouts'))
import query_operations as qo
import warm_queries as warm
env = dict(os.environ, GOMAXPROCS='1', SCOPE_THREAD_EVENT='1')
manifest = json.loads((here/'manifest.json').read_text())
if args.pairs<1 or min(args.iterations)<1 or args.variant not in manifest['variants']:
    parser.error('supply a recorded variant and positive repetition counts')
def apply_patch(paths, patch, root, target):
    target.mkdir(parents=True,exist_ok=True)
    for name in paths:
        f=target/name
        f.parent.mkdir(parents=True,exist_ok=True)
        f.write_bytes((root/name).read_bytes())
    if paths:
        subprocess.run(['patch','-p1','-i',patch],cwd=target,check=True)
    return {str(root/name):str(target/name) for name in paths}

mapping=apply_patch(manifest['variants'][args.variant],here/'overlays'/(args.variant+'.patch'),pkg,out/'sources')
overlay=out/'variant.json'
overlay.write_text(json.dumps({'Replace':mapping}))
if args.stage:
    methods=manifest['stages'][args.stage]
    g=qo.build_go(out,methods['go_file'],methods['methods'],overlay)
    path='ast/rewriter/arith_rewriter.cpp'
    source=pkg.parent/'src'
    build=pkg.parent/'build'
    sources=apply_patch([path],here/'instrumentation'/(args.stage+'.patch'),source,out/'native-source')
    cfg=(build/'config.mk').read_text()
    rules=(build/'Makefile').read_text()
    inc=re.search(r'\$\((includes_\d+)\).*\.\./src/'+re.escape(path)+r'$',rules,re.M)[1]
    obj=out/'arithmetic.o'
    subprocess.run([*qo.make_words(build,'CXX',cfg),*qo.make_words(build,'CXXFLAGS',cfg),*qo.make_words(build,inc,rules),'-o',obj,sources[str(source/path)]],cwd=build,check=True)
    lines=subprocess.check_output(['make','-n','-W','shell/main.o','z3'],cwd=build,text=True).splitlines()
    links=[shlex.split(line)for line in lines if 'shell/main.o'in line and ' -o z3 'in line]
    if len(links)!=1:raise ValueError('unrecognized native link command')
    link=links[0];native=out/'z3';link[link.index('-o')+1]=str(native);link.insert(link.index('shell/main.o'),str(obj))
    subprocess.run(link,cwd=build,check=True)
    with (out/'runs.csv').open('w') as dest:
        writer=csv.writer(dest);writer.writerow(['round','query','iterations','engine','calls','instructions'])
        for i in range(args.pairs):
            for n in args.iterations[::1 if i%2==0 else -1]:
                reference=None
                for name,binary in ([('g3',g),('native',native)][::1 if i%2==0 else -1]):
                    r=subprocess.run(['taskset','-c',str(args.cpu),binary,'-in','-smt2'],input=warm.script(args.query,n,True),env=env,text=True,capture_output=True,check=True)
                    blocks=re.split(r'(?m)^(sat|unsat|unknown)$',r.stdout)
                    if blocks[1::2]!=[warm.NUMERIC_ANSWERS.get(args.query,'unsat')]*n:raise ValueError('unexpected verdict')
                    rows=[tuple(dict(re.findall(r':([\w-]+)\s+(\d+)\b',z)).get(k,'0')for k in ('decisions','added-eqs','conflicts','rlimit-count','quant-instantiations'))for z in blocks[2::2]]
                    if reference is not None and rows!=reference:raise ValueError('search diverged')
                    reference=rows
                    samples=re.findall(r'^REPLAY-OP (\d+) (\d+)$',r.stderr,re.M)
                    if len(samples)!=1:raise ValueError(r.stderr)
                    writer.writerow([i+1,args.query,n,name,*samples[0]]);dest.flush()
else:
    binary=out/'g3'
    subprocess.run(['go','build','-mod=readonly','-pgo=off','-buildvcs=false','-overlay='+str(overlay),'-o',binary,'./cmd/g3'],cwd=pkg,check=True)
    data=gzip.decompress((here/'simplifications/formulas.smt2.gz').read_bytes())
    r=subprocess.run([binary,'-in','-smt2'],input=data,capture_output=True,check=True,env=env)
    if r.stdout!=gzip.decompress((here/'simplifications/control.gz').read_bytes())or r.stderr:raise ValueError('simplification differed')
    print('Matched all retained simplifications.')
