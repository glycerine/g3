"""Report medians of within-round ratios and independent medians of absolute values."""
from pathlib import Path
import csv,sys,statistics as st
w=Path(__file__).resolve().parent
for name in sys.argv[1:]:
 rows=list(csv.DictReader((w/(name+'.csv')).open()))
 for case in sorted({r.get('case',r.get('query')) for r in rows}):
  d={(int(r['round']),r['engine']):r for r in rows if r.get('case',r.get('query'))==case}
  for eng in sorted({e for i,e in d}):
   pair=sorted(i for i,e in d if e==eng and (i,'base') in d)
   if not pair:continue
   print(case,eng,len(pair),*[round(100*(st.median(float(d[i,eng][k])/float(d[i,'base'][k]) for i in pair)-1),2) for k in ('instructions','cycles','milliseconds')],*[round(st.median(float(d[i,eng][k]) for i in pair),1) for k in ('milliseconds','maxrss_kib') if k in rows[0]])
