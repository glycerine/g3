"""Try coalescing consecutive satisfied blocking watches without changing visit order."""
from pathlib import Path
import subprocess,json,sys
w=Path(__file__).resolve().parent;p=Path.cwd();src=p/'sat/sat_solver_propagation.go';s=src.read_text()
start=s.index('if out != pos {',s.index('// A satisfied blocking literal'))
end=s.index('continue',start)
trial=sys.argv[1]
if trial=='runs':
 code='''start:=pos
 for pos+1<iter.end {
  next:=data[pos+1]
  if next.val2&3!=2 || assignment[next.val2>>2]!=lbool.True{break}
  pos++
 }
 count:=pos-start+1
 if out!=start{
 copy(data[out:out+count],data[start:pos+1])
 if extra:=iter.backing.wide;extra!=nil{copy(extra.values[out:out+count],extra.values[start:pos+1])}
 }
 out+=count
 '''
else:
 code='''if out != pos {
 data[out]=bits
 if extra:=iter.backing.wide;extra!=nil{extra.values[out]=extra.values[pos]}
 }
 out++
 if pos+1<iter.end{
 next:=data[pos+1]
 if next.val2&3==2 && assignment[next.val2>>2]==lbool.True {
 pos++
 if out!=pos {data[out]=next;if extra:=iter.backing.wide;extra!=nil{extra.values[out]=extra.values[pos]}}
 out++
 }}
 '''
dst=w/(trial+'.go');dst.write_text(s[:start]+code+s[end:]);ov=w/(trial+'.json');ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo='+str(w/'blend.pprof'),'-overlay',ov,'-tags=xtrace_off','-buildvcs=false','-o',w/trial,'./cmd/g3'],check=True)
