from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
src=p/'sat/sat_solver_conflict_resolution.go';s=src.read_text();start=s.index('\t\tfor {\n\t\t\tlit, e := v.trailRead(idx)');end=s.index('\t\tid := uint32(consequent.variable())',start)
s=s[:start]+'''		consequent, e = v.trailRead(idx)
		if e != nil {
			return false, e
		}
		// The first read validates the live trail after processConsequent.
		// Looking up a mark cannot resize it. All remaining indices decrease.
		for {
			marked, e := a.marked(uint32(consequent.variable()))
			if e != nil {
				return false, e
			}
			if marked {
				break
			}
			if idx == 0 {
				if satStorageSourceDebug {
					return false, ErrSATAssertion
				}
				return false, arena.ErrBounds
			}
			idx--
			consequent = v.trail.values[idx]
		}
'''+s[end:]
start=s.index('\t\tconsequent, e = v.trailRead(idx)')
end=s.index('\t\tid := uint32(consequent.variable())',start)
s=s[:start]+'''		consequent, idx, e = a.lastMarkedTrailLiteral(idx)
		if e != nil {
			return false, e
		}
'''+s[end:]
s+='''
// lastMarkedTrailLiteral scans the current trail backwards after an antecedent
// callback. The first read validates the owner and the highest index. Reading
// marks cannot resize the trail while this solver owns it.
func (a *satSolverConflictAnalysis) lastMarkedTrailLiteral(idx uint32) (Literal, uint32, error) {
	v := a.propagation.variables
	lit, err := v.trailRead(idx)
	if err != nil {
		return 0, idx, err
	}
	for {
		marked, err := a.marked(uint32(lit.variable()))
		if err != nil || marked {
			return lit, idx, err
		}
		if idx == 0 {
			if satStorageSourceDebug {
				return 0, idx, ErrSATAssertion
			}
			return 0, idx, arena.ErrBounds
		}
		idx--
		lit = v.trail.values[idx]
	}
}
'''
dst=w/'scan.go';dst.write_text(s);ov=w/'scan.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
for eng,profile in [('scan','off'),('scan-blend',str(w/'blend.pprof'))]:
 subprocess.run(['go','build','-pgo='+profile,'-overlay',ov,'-tags=xtrace_off','-buildvcs=false','-o',w/eng,'./cmd/g3'],check=True)
