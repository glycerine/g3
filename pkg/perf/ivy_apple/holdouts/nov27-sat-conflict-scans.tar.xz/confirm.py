"""Validate each variant on file and stdin controls with independent benchmark order."""
from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent;pkg=Path.cwd();d=pkg/'build/.nov26-clause-locality/fixtures'
stem,cpu,n,base,trial=sys.argv[1:]
cmd=['python3',w/'measure.py','--pkg',pkg,'--perf','/usr/lib/linux-tools/6.17.0-35-generic/perf','--cpu',cpu,'--rounds',n,'--solver-arg=-v:2']
for status,file,stdin in [('unsat',d/'random-208-3.cnf',False),('sat',d/'random-208-4.cnf',False),('sat',d/'random-256-3.cnf',True),('unsat',pkg/'build/.nov26-sat-arena-hot/archive/fixtures/pigeon8-s2.cnf',False)]:
 cmd+=['--case',status+':'+str(file)+(':stdin' if stdin else '')]
with (w/(stem+'.csv')).open('w') as out:
 subprocess.run(cmd+['base='+str(w/base),'trial='+str(w/trial)],stdout=out,check=True)
