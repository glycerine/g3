from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd()
src=p/'sat/sat_solver_conflict_resolution.go';s=src.read_text();start=s.index('\t\tfor {\n\t\t\tlit, e := v.trailRead(idx)');end=s.index('\t\tid := uint32(consequent.variable())',start)
s=s[:start]+'''		consequent, e = v.trailRead(idx)
		if e != nil {
			return false, e
		}
		// The first read validates the live trail after processConsequent.
		// Looking up a mark cannot resize it. All remaining indices decrease.
		for {
			marked, e := a.marked(uint32(consequent.variable()))
			if e != nil {
				return false, e
			}
			if marked {
				break
			}
			if idx == 0 {
				if satStorageSourceDebug {
					return false, ErrSATAssertion
				}
				return false, arena.ErrBounds
			}
			idx--
			consequent = v.trail.values[idx]
		}
'''+s[end:]
dst=w/'conflict.go';dst.write_text(s);ov=w/'conflict.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
for eng,profile in [('conflict','off'),('conflict-blend',str(w/'blend.pprof'))]:
 subprocess.run(['go','build','-pgo='+profile,'-overlay',ov,'-tags=xtrace_off','-buildvcs=false','-o',w/eng,'./cmd/g3'],check=True)
