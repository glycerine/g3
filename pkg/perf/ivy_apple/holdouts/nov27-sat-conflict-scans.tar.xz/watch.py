from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent;pkg=Path.cwd();d=pkg/'build/.nov26-clause-locality/fixtures'
with (w/'watch.csv').open('w') as out:
 cmd=['python3',w/'measure.py','--pkg',pkg,'--perf','/usr/lib/linux-tools/6.17.0-35-generic/perf','--cpu',sys.argv[1],'--rounds','5','--solver-arg=-v:2']
 for verdict,name in [('unsat','random-208-3'),('sat','random-208-4'),('unsat','pigeon8-s0')]:
  cmd+=['--case',verdict+':'+str(d/(name+'.cnf'))]
 subprocess.run(cmd+['base='+str(w/'blendcli'),'runs='+str(w/'runs'),'pairs='+str(w/'pairs')],stdout=out,check=True)
