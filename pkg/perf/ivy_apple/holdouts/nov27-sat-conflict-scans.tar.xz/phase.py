from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();src=p/'sat/sat_solver_conflict_helpers.go';s=src.read_text()
start=s.index('for i := head; i < n; i++',s.index('func (s *satSolverConflictResolution) forgetPhaseOfVars'))
s=s[:start]+'''// Without a trace writer this loop has no callbacks. Size checked the
	// live trail above. Validate the variable owner once before the first write.
	if head < n && !s.analysis.propagation.tracingPropagation() {
		if e := v.open(); e != nil {
			return e
		}
		for _, lit := range v.trail.values[head:n] {
			id := lit.variable()
			if uint64(id) >= uint64(len(v.phase)) {
				return v.setPhase(id, 2)
			}
			v.phase[id] = 2
		}
		return nil
	}
	'''+s[start:]
dst=w/'phase.go';dst.write_text(s);ov=w/'phase.json';ov.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
for eng,profile in [('phase','off'),('phase-blend',str(w/'blend.pprof'))]:
 subprocess.run(['go','build','-pgo='+profile,'-overlay',ov,'-tags=xtrace_off','-buildvcs=false','-o',w/eng,'./cmd/g3'],check=True)
