#!/usr/bin/env python3
"""Repeat the six fixed-search comparisons from a g3 checkout on Linux."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
STATS = re.compile(r':([\w-]+)\s+(\d+)(?=[\s)])')

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--pkg', required=True, type=Path)
    ap.add_argument('--output', required=True, type=Path)
    ap.add_argument('--cpu', required=True, type=int)
    ap.add_argument('--native', type=Path, help='in-tree Z3 executable')
    ap.add_argument('--perf', help='Linux perf executable to collect counters')
    ap.add_argument('--rounds', type=int, default=3)
    modes = sorted(d.name for d in (ROOT/'overlays').iterdir() if d.is_dir())
    ap.add_argument('--modes', nargs='+', choices=modes, default=['ref+eq+cg','tag+probe','frame+gate+watch+sort+table'])
    queries = sorted(p.stem for p in (ROOT/'queries').glob('*.smt2'))
    ap.add_argument('--queries', nargs='+', choices=queries, default=queries)
    a = ap.parse_args()
    if a.rounds < 1:
        ap.error('rounds must be positive')
    out, pkg = a.output.resolve(), a.pkg.resolve(strict=True)
    out.mkdir(parents=True, exist_ok=False)
    binaries = {}
    for mode in ['before', *dict.fromkeys(a.modes)]:
        flags = []
        if mode != 'before':
            base = ROOT/'overlays'/mode
            paths = {str(pkg/p.relative_to(base)): str(p) for p in base.rglob('*.go')}
            overlay = out/(mode+'.json')
            overlay.write_text(json.dumps({'Replace':paths}))
            flags = ['-overlay='+str(overlay)]
        binary = out/(mode+'.g3')
        subprocess.run(['go','build','-tags=xtrace_off','-pgo=off','-buildvcs=false',*flags,'-o',binary,'./cmd/g3'],cwd=pkg,check=True)
        binaries[mode] = binary
    if a.native:
        binaries['native'] = a.native.resolve(strict=True)
    env = dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1')
    with (out/'runs.csv').open('w') as sf:
        writer = csv.writer(sf)
        writer.writerow(['query','round','mode','answer','resources','instructions','cycles'])
        for query in a.queries:
            expected = None
            for k in range(a.rounds):
                order = list(binaries)
                i = k%len(order)
                for mode in order[i:]+order[:i]:
                    case = f'{query}-{k+1}-{mode}'
                    counts = out/(case+'.perf')
                    cmd = ['taskset','-c',str(a.cpu)]
                    if a.perf:
                        cmd += [a.perf,'stat','-x,','-e','instructions:u,cycles:u','-o',counts,'--']
                    cmd += [binaries[mode],'-st','-smt2',ROOT/'queries'/(query+'.smt2')]
                    r = subprocess.run(cmd,capture_output=True,text=True,env=env,check=True)
                    answer = r.stdout.splitlines()[0]
                    stats = {n:v for n,v in STATS.findall(r.stdout) if not any(w in n for w in ('memory','alloc','time'))}
                    if r.stderr or answer != ('unknown' if query.startswith('miss') else 'unsat') or 'rlimit-count' not in stats:
                        raise ValueError((case,r.stderr,answer,stats))
                    if expected is not None and (answer,stats) != expected:
                        raise ValueError((case,expected,answer,stats))
                    expected = answer,stats
                    (out/(case+'.stdout')).write_text(r.stdout)
                    events = {line[2]:int(line[0]) for line in csv.reader(counts.open()) if len(line)>2 and line[2] in ('instructions:u','cycles:u')} if a.perf else {}
                    writer.writerow([query,k+1,mode,answer,stats['rlimit-count'],events.get('instructions:u',''),events.get('cycles:u','')])
                    sf.flush()

if __name__ == '__main__':
    main()
