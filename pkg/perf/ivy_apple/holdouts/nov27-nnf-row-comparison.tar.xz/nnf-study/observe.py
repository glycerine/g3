from pathlib import Path
import os,subprocess as sp,json,tempfile,csv
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
def put(path,s):
 f=w/path.name;f.write_text(s);rep[str(path)]=str(f)
path=front/'phase_observer_trial.go';s=Path(rep[str(path)]).read_text().replace('start := time.Now()','os.Setenv("NNF_FD",fmt.Sprint(fd));start := time.Now()').replace('elapsed := time.Since(start)','os.Unsetenv("NNF_FD");elapsed := time.Since(start)');put(path,s)
path=p/'ast/normal_forms/nnf.go';s=path.read_text().replace('type NNF struct {','type NNF struct {\n Trial [7]int')
for name,index in [('convert',0),('hold',1),('convertQuantifier',2),('convertDefault',3),('cacheResult',4),('skip',5)]:
 i=s.index('func (n *NNF) '+name+'(');j=s.index('\n',i);s=s[:j]+f'\n n.Trial[{index}]++'+s[j:]
s=s.replace('return r, x\n\t\t}', 'if found{n.Trial[6]++};return r,x\n\t\t}',1);put(path,s)
path=p/'smtcore/smt_asserted_nnf.go';s=path.read_text().replace('import (','import ("syscall";"unsafe";"strconv";"os";');i=s.index('func (k *SMTKernel) normalizePendingAssertions')
s=s[:i]+'''func nnfRead(fd int)uint64{if fd<0{return 0};var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&v)),24);if e!=0||n!=24||v[1]!=v[2]{panic("counter")};return v[0]}
'''+s[i:]
k='if err = proc.Transform';s=s.replace(k,'''fd,fe:=strconv.Atoi(os.Getenv("NNF_FD"));if fe!=nil{fd=-1}
 proc.Trial=[7]int{};before:=nnfRead(fd);charge:=k.manager.ResourceLimit().Count()
 '''+k)
k='definitions, definitionProofs :=';s=s.replace(k,'trans:=nnfRead(fd)-before;steps:=k.manager.ResourceLimit().Count()-charge;'+k)
k='return k.appendNNFRewritten(batch, value, p, out, proof)';s=s.replace(k,'''start:=nnfRead(fd);c,e:=k.appendNNFRewritten(batch,value,p,out,proof);cost:=nnfRead(fd)-start;rwsteps,_:=k.preprocessor.NumSteps()
 if fd>=0{final,_:=k.manager.RefGet(out);h:=assertion.Formula;fmt.Fprint(os.Stderr,"NNFROW ",h.Origin(),"/",h.Slot(),"/",h.Generation()," ",h==value," ",final==value," ",len(definitions)," ",steps," ",rwsteps," ",trans," ",cost);for _,v:=range proc.Trial{fmt.Fprint(os.Stderr," ",v)};fmt.Fprintln(os.Stderr)}
 return c,e''');put(path,s)
j=w/'observe.json';j.write_text(json.dumps(ov))
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as t:
 sp.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',w/'observer','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=t,GOTMPDIR=t),check=True)
rank=w;names=(rank/'compat.txt').read_text().splitlines();ex=Path(os.environ['IVY_EXAMPLES']).resolve()
with (w/'rows.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case round batch goal phase handle identity rewrite_identity defs charge rwsteps transform rewrite visits holds quantifiers default inserts skips hits'.split())
 for n in (2,6,7,9):
  ref=rank/'compat'/str(n)/'1/native'
  for i in range(3):
   r=sp.run(['taskset','-c',os.environ.get('CPU','22'),w/'observer',ex/names[n-1]],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=60);rest=bytearray();rows=[]
   for line in r.stderr.splitlines(keepends=True):
    if line.startswith(b'NNFROW '):rows.append(line.decode().split()[1:])
    elif line.startswith(b'STAGE-COUNT '):
     _,b,g,phase,_,_,en,ac,_=line.decode().split();assert en==ac
     for row in rows:o.writerow([n,i,b,g,phase,*row])
     rows=[]
    else:rest.extend(line)
   assert not rows and (r.returncode,r.stdout,rest)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());f.flush()
