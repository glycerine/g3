from pathlib import Path
import os,subprocess as sp,json,tempfile,csv,re,shlex,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
build=p.parent/'build';src=p.parent/'src/smt';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
s=(src/'asserted_formulas.cpp').read_text()
i=s.index('void asserted_formulas::nnf_cnf()');j=s.index('swap_asserted_formulas(new_fmls);',i)
h,t=s[:i],s[i:j];k='apply_nnf(n, push_todo, push_todo_prs, r1, pr1);';t=t.replace(k,'''const char *v=getenv("NNF_FD");int fd=v?atoi(v):-1;auto rd=[&](){unsigned long long c[3];if(fd<0)return 0ULL;if(read(fd,c,sizeof(c))!=sizeof(c)||c[1]!=c[2])abort();return c[0];};auto a=rd();'''+k+'''auto transform=rd()-a;bool same=n==r1.get();''')
k='m_rewriter(n, r1, pr1);';t=t.replace(k,'a=rd();'+k)
k='push_assertion(r1, pr, new_fmls);';t=t.replace(k,k+'''auto rewrite=rd()-a;if(fd>=0)fprintf(stderr,"NNFN %d %d %d %d %u %llu %llu\\n",int(same),int(n==r1.get()),int(sz2-1),int(k),m_rewriter.get_num_steps(),transform,rewrite);''')
s='#include <unistd.h>\n#include <cstdlib>\n#include <cstdio>\n'+h+t+s[j:]
f=w/'asserted_formulas.cpp';f.write_text(s)
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as temp:
 d=Path(temp);obj=d/'asserted_formulas.o';sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,f],cwd=build,check=True)
 lib=d/'study.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);sp.run(['ar','r',lib,obj],check=True)
 ov={'Replace':{str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt')}};rep=ov['Replace']
 path=front/'smt/quantifier.go';f=d/'quantifier.go';f.write_text(path.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));rep[str(path)]=str(f)
 rep[str(front/'phase_observer_trial.go')]=str(w/'phase_observer_trial.go');rep[str(front/'z3bridge_solver_model.go')]=str(w/'native-bridge.go.txt')
 j=d/'native.json';j.write_text(json.dumps(ov));exe=d/'native';sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off,classic_z3','-pgo=off','-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=temp,GOTMPDIR=temp),check=True)
 rank=w;names=(rank/'compat.txt').read_text().splitlines();ex=Path(os.environ['IVY_EXAMPLES']).resolve()
 with (w/'native.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case round batch goal phase identity rewrite_identity defs index rwsteps transform rewrite'.split())
  for n in (2,6,7,9):
   ref=rank/'compat'/str(n)/'1/native'
   for i in range(3):
    r=sp.run(['taskset','-c',os.environ.get('CPU','22'),exe,ex/names[n-1]],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=60);rest=bytearray();rows=[]
    for line in r.stderr.splitlines(keepends=True):
     if line.startswith(b'NNFN '):rows.append(line.decode().split()[1:])
     elif line.startswith(b'STAGE-COUNT '):
      _,b,g,phase,_,_,en,ac,_=line.decode().split();assert en==ac
      for row in rows:o.writerow([n,i,b,g,phase,*row])
      rows=[]
     else:rest.extend(line)
    assert not rows and (r.returncode,r.stdout,rest)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),rest[:500];f.flush()
