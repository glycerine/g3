import csv,collections,statistics as st
from pathlib import Path
r=list(csv.DictReader((Path(__file__).parent/'stages.csv').open()))
for c in ('2','4','8','3'):
 d=collections.defaultdict(list); sums=collections.defaultdict(list)
 for i in ('0','1','2'):
  vals=collections.Counter();phase=collections.Counter()
  for x in r:
   if x['case']!=c or x['round']!=i:continue
   m=x['mode'];a=x['phase'];v=int(x['instructions']);phase[m,'push' if a=='first' else a]+=v
   if a=='check':vals[x['batch'],x['goal'],m]+=v
  for k,v in vals.items():d[k].append(v)
  for k,v in phase.items():sums[k].append(v)
 gaps=[]
 for b,g,m in d:
  if m=='g3' and (b,g,'native') in d:gaps.append((st.median(d[b,g,m])-st.median(d[b,g,'native']),b,g,st.median(d[b,g,m]),st.median(d[b,g,'native'])))
 print(c,[(b,g,round(a/1e6,2),round(z/1e6,2),round(diff/1e6,2)) for diff,b,g,a,z in sorted(gaps,reverse=True)[:3]],{k:round(st.median(v)/1e6,2) for k,v in sums.items() if k[1] in ('push','check','early')})
