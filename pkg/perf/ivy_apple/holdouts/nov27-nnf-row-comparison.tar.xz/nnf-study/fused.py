from pathlib import Path
import os,csv,subprocess as sp,tempfile,json,time
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
path=p/'ast/rewriter/rewriter_engine.go';s=path.read_text()
# Keep source-order lookup on custom configurations, proof and checked paths.
path2=p/'ast/ast_core_accessors.go';src=path2.read_text();a=src.index('func (m *ASTManager) NodeShape');b=src.index('\n}',a)+2
shape=src[a:b].replace('NodeShape(', 'RewriteShape(').replace('numArgs uint32, err','numArgs uint32, possibleKey bool, err').replace('return 0, 0, 0, e','return 0,0,0,false,e').replace('count, nil','count,n.hasFlag(astWasSubstitutionKey),nil').replace('n.rc, 0, nil','n.rc,0,n.hasFlag(astWasSubstitutionKey),nil')
f2=w/'fused-shape.go';f2.write_text(src+'\n'+shape+'\n')
s=s.replace('sub, subProof, found, e := r.cfg.GetSubst(t)',"""var sub,subProof ast.ASTHandle
var found,shaped bool
var kind ast.ASTKind
var rc,n uint32
var e error
if cfg,ok:=r.cfg.(*theoryRewriterConfiguration);ok && !ast.ASTValidateHandles && !ast.ASTSourceDebug && !c.proofGen && depth!=0 {
 var possible bool
 kind,rc,n,possible,e=m.RewriteShape(t)
 if e!=nil{return false,e}
 shaped=true
 if possible && cfg.hasSubstitution {sub,subProof,found,e=cfg.GetSubst(t)}
} else { sub,subProof,found,e=r.cfg.GetSubst(t) }""",1)
a=s.index('kind, rc, n, e := m.NodeShape(t)',s.index('func (r *rewriterEngine) visit('));s=s[:a]+s[a:].replace('kind, rc, n, e := m.NodeShape(t)','if !shaped {kind,rc,n,e=m.NodeShape(t)}',1)
f=w/'fused-engine.go';f.write_text(s);sp.run(['gofmt','-w',f,f2],check=True)
rank=w;names=(rank/'compat.txt').read_text().splitlines();ex=Path(os.environ['IVY_EXAMPLES']).resolve()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as temp:
 d=Path(temp)
 for mode in ('base','trial'):
  ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt')}}
  if mode=='trial':ov['Replace'].update({str(path):str(f),str(path2):str(f2)})
  j=d/(mode+'.json');j.write_text(json.dumps(ov))
  sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',d/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=temp,GOTMPDIR=temp),check=True)
 codes={x['case']:int(x['exit']) for x in csv.DictReader((rank/'ranking.csv').open())}
 with (w/'fused.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case round mode instructions elapsed_ms'.split())
  for n in (2,6,7,9,1,3,4,5,8,10,11,12):
   ref=rank/'compat'/str(n)/'1/native'
   for i in range(3):
    for mode in (('base','trial') if i%2==0 else ('trial','base')):
     st=d/'stat';start=time.monotonic();r=sp.run(['taskset','-c',os.environ.get('CPU','20'),os.environ.get('PERF','perf'),'stat','-x,','-e','instructions:u','-o',st,'--',d/mode,ex/names[n-1]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=120)
     assert (r.returncode,r.stdout,r.stderr)==(codes[names[n-1]],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());v,=[int(x[0]) for x in csv.reader(st.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100];o.writerow([n,i,mode,v,round(1000*(time.monotonic()-start),2)]);f.flush()
