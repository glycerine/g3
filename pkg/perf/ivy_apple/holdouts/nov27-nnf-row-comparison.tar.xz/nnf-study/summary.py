import csv,collections,statistics as stat
from pathlib import Path
w=Path(__file__).resolve().parent
def rows(file,case,phase,i):
 d=collections.defaultdict(list)
 for x in csv.DictReader((w/(file+'.csv')).open()):
  if x['case']==str(case) and x['phase']==phase and x['round']==str(i):d[x['batch']].append(x)
 return d
for case in (2,6,7,9):
 rounds=[]
 for i in range(3):
  g=rows('rows',case,'push',i);z=rows('native',case,'first',i); keys=g.keys() & z.keys(); pairs=[]
  for key in keys:
   assert len(g[key])==len(z[key]);pairs.extend(zip(g[key],z[key]))
  result=[]
  for a,b in pairs:
   assert a['defs']==b['defs']=='0' and (a['identity']=='true')==(b['identity']=='1') and (a['rewrite_identity']=='true')==(b['rewrite_identity']=='1')
  for side in (0,1):
   xs=[p[side] for p in pairs];result += [sum(int(x[k]) for x in xs) for k in ('transform','rewrite','rwsteps')]
  rounds.append(result)
 print(case,len(keys),len(pairs),sum(a['rwsteps']!=b['rwsteps'] for a,b in pairs),[round(stat.median(v)/ (1 if j in (2,5) else 1e6),2) for j,v in enumerate(zip(*rounds))])
for name in ('trial','engine','fused','uf','confirm'):
 xs=[]
 for p in [w/(name+'.csv'),w/(name+'-rest.csv')]:
  if p.exists(): xs.extend(csv.DictReader(p.open()))
 for c in sorted({x['case'] for x in xs},key=int):
  a,b=[[int(x['instructions']) for x in xs if x['case']==c and x['mode']==m] for m in ('base','trial')]
  if len(a)==len(b) and len(a)>=3: print(name,c,round(100*(stat.median(b)/stat.median(a)-1),2))
