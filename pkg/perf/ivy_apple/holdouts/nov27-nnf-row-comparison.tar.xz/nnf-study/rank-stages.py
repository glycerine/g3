from pathlib import Path
import os,csv,subprocess as sp,tempfile,json
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();rank=w;names=(rank/'compat.txt').read_text().splitlines();ex=Path(os.environ['IVY_EXAMPLES']).resolve()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as temp:
 d=Path(temp)
 for mode in ('g3','native'):
  ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}}
  if mode=='native':ov['Replace'][str(front/'z3bridge_solver_model.go')]=str(w/'native-bridge.go.txt')
  j=d/(mode+'.json');j.write_text(json.dumps(ov));tags='xtrace_off'+(',classic_z3' if mode=='native' else '')
  sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags',tags,'-pgo='+('off' if mode=='native' else str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',d/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=temp,GOTMPDIR=temp),check=True)
 with (w/'stages.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case round mode batch goal phase instructions'.split())
  for n in (2,4,8,3):
   ref=rank/'compat'/str(n)/'1/native'
   for i in range(3):
    for mode in (('g3','native') if i%2==0 else ('native','g3')):
     r=sp.run(['taskset','-c',os.environ.get('CPU','22'),d/mode,ex/names[n-1]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=120);rest=bytearray()
     for line in r.stderr.splitlines(keepends=True):
      if line.startswith(b'STAGE-COUNT '):
       _,b,g,phase,c,_,en,ac,_=line.decode().split();assert en==ac;o.writerow([n,i,mode,b,g,phase,c])
      else:rest.extend(line)
     assert (r.returncode,r.stdout,rest)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),rest[:500];f.flush()
