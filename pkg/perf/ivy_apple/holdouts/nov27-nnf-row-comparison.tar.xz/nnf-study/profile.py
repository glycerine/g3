from pathlib import Path
import os,subprocess as sp,tempfile,csv,collections
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
rank=w;ex=Path(os.environ['IVY_EXAMPLES']).resolve();case=(rank/'compat.txt').read_text().splitlines()[1];gold=rank/'compat/2/1/native';perf=os.environ.get('PERF','perf')
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as tn:
 import json
 d=Path(tn);overlay=d/'release.json';overlay.write_text(json.dumps({'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt')}}));exe=d/'g3';sp.run(['go','build','-buildvcs=false','-mod=readonly','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',overlay,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=tn,GOTMPDIR=tn),check=True)
 counts=collections.Counter()
 for i in range(5):
  data=d/'profile.data';r=sp.run(['taskset','-c',os.environ.get('CPU','22'),perf,'record','-q','-e','instructions:u','-c','200003','--call-graph','fp','-o',data,'--',exe,ex/case],cwd=d,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True)
  assert (r.returncode,r.stdout,r.stderr)==(0,(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),r.stderr[:500]
  cmd=sp.Popen([perf,'script','--no-inline','-i',data,'-F','ip,sym'],stdout=sp.PIPE,text=True);stack=[]
  for line in cmd.stdout:
   if line.strip():
    name=line.strip().split(None,1);stack.append(name[-1].split('+0x')[0])
   elif stack:
    if any('appendNNFRewritten' in frame for frame in stack):counts[tuple(stack[:next(i for i,f in enumerate(stack) if 'appendNNFRewritten' in f)+1])]+=1
    stack=[]
  assert cmd.wait()==0
 with (w/'rewrite-stacks.csv').open('w') as f:
  o=csv.writer(f);o.writerow(['samples','stack_leaf_first']);o.writerows((n,';'.join(s)) for s,n in counts.most_common())
