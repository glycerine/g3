"""Test clause-page generation columns with the same physical byte charge."""

import argparse
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("variants", nargs="+", choices=("head", "tail"))
p.add_argument("--goivy", action="store_true")
opts = p.parse_args()
original = pkg / "arena/clause_pages.go"

for name in opts.variants:
    out = root / name
    out.mkdir(exist_ok=True)
    text = original.read_text()

    def edit(old, new):
        global text
        if text.count(old) != 1:
            raise ValueError((old, text.count(old)))
        text = text.replace(old, new)

    edit("_               uint64 // Keep the directory stride at 64 bytes on amd64.",
         "generationBase, payloadBase uint32")
    edit("clausePageChunkBytes/stride)", "clausePageChunkBytes/(stride+clausePageHeaderBytes))")
    edit("bytes := uint64(count) * uint64(stride)", "bytes := uint64(count) * uint64(stride+clausePageHeaderBytes)")
    edit("data: make([]byte, int(bytes)), stride: stride, count: count, epoch: 1, maximum: 1,",
         """data: make([]byte, int(bytes)), stride: stride, count: count, epoch: 1, maximum: 1,
            BASES,"""
            .replace("BASES", "payloadBase: count * clausePageHeaderBytes" if name == "head" else "generationBase: count * stride"))
    edit("stride := size + clausePageHeaderBytes", "stride := size")
    edit("bytes := uint64(page.count) * uint64(stride)", "bytes := uint64(page.count) * uint64(stride+clausePageHeaderBytes)")
    edit("start := index*stride + clausePageHeaderBytes", "start := page.payloadBase + index*stride")
    edit("binary.LittleEndian.PutUint32(page.data[index*stride:], generation)",
         "binary.LittleEndian.PutUint32(page.data[page.generationBase+index*clausePageHeaderBytes:], generation)")
    edit("if r == (SmallBytesRef{}) {", "if r.Slot == 0 && r.Generation == 0 {")
    edit("""\tstart := index * p.stride
\tend := start + p.stride
\trow := p.data[start:end:end]
\tif binary.LittleEndian.Uint32(row) != uint32(r.Generation) {
\t\treturn nil, ErrInvalidSlot
\t}
\treturn row[clausePageHeaderBytes:], nil""",
         """    data := p.data
          if binary.LittleEndian.Uint32(data[p.generationBase+index*clausePageHeaderBytes:]) != uint32(r.Generation) {
              return nil, ErrInvalidSlot
          }
          start := p.payloadBase + index*p.stride
          end := start + p.stride
          return data[start:end:end], nil""")
    edit("binary.LittleEndian.PutUint32(p.data[index*p.stride:], 0)",
         "binary.LittleEndian.PutUint32(p.data[p.generationBase+index*clausePageHeaderBytes:], 0)")
    source = out / original.name
    source.write_bytes(subprocess.check_output(["gofmt"], input=text.encode()))
    patches = {original: source}
    cwd, name_out, command = pkg, "g3", ("./cmd/g3",)
    if opts.goivy:
        patches[Path.home() / "g3/pkg" / original.relative_to(pkg)] = source
        cwd, name_out, command = Path.home() / "ivy/goivy", "goivy_check", ("-tags=xtrace_off", "./cmd/goivy_check")
    overlay = out / (name_out + ".json")
    overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k,v in patches.items()}}))
    subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", overlay,
                    "-o", out/name_out, *command], cwd=cwd, check=True)
