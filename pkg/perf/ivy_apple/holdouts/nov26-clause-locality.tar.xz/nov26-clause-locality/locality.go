package sat

import (
	"encoding/json"
	"fmt"
	"os"
)

type localityPage struct {
	owner      uint64
	page, kind uint32
}

type localityCounts struct {
	Scans, Nonempty, Visits, Unique, DistinctPages, PeakVisits, PeakClauses, PeakPages uint64
	SamePage, Ref32, Ref128, Ref512, Page4, Page16                                     uint64
	Recent1, Recent8, Recent64, Recent512, FirstVisit                                  uint64
	Sizes                                                                              [10]uint64
}

type localityCounter struct {
	Value                        localityCounts
	scan, clauses, pages, visits uint64
	refScans                     map[StoredClauseRef]uint64
	pageScans                    map[localityPage]uint64
	last                         map[StoredClauseRef]uint64
	ref32                        [32]StoredClauseRef
	ref128                       [128]StoredClauseRef
	ref512                       [512]StoredClauseRef
	lastPage                     localityPage
	page4                        [4]localityPage
	page16                       [16]localityPage
}

var propagationLocality, watchListLocality, subsumptionLocality localityCounter

func (c *localityCounter) begin() {
	if c.scan == 0 {
		c.refScans = make(map[StoredClauseRef]uint64)
		c.pageScans = make(map[localityPage]uint64)
		c.last = make(map[StoredClauseRef]uint64)
	}
	c.scan++
	c.visits, c.clauses, c.pages = 0, 0, 0
}

func (c *localityCounter) end() {
	d := &c.Value
	d.Scans++
	if c.visits != 0 {
		d.Nonempty++
	}
	d.Unique += c.clauses
	d.DistinctPages += c.pages
	d.PeakVisits = max(c.visits, d.PeakVisits)
	d.PeakClauses = max(c.clauses, d.PeakClauses)
	d.PeakPages = max(c.pages, d.PeakPages)
	v, bucket := c.visits, 0
	for v > 1 && bucket+1 < len(d.Sizes) {
		v >>= 1
		bucket++
	}
	d.Sizes[bucket]++
}

func (c *localityCounter) visit(ref StoredClauseRef) {
	p := localityPage{ref.owner, (ref.slot - 1) >> 6, ref.storageKind}
	d := &c.Value
	d.Visits++
	c.visits++
	if c.refScans[ref] != c.scan {
		c.refScans[ref] = c.scan
		c.clauses++
	}
	if c.pageScans[p] != c.scan {
		c.pageScans[p] = c.scan
		c.pages++
	}
	if prev := c.last[ref]; prev == 0 {
		d.FirstVisit++
	} else {
		gap := d.Visits - prev
		if gap <= 1 {
			d.Recent1++
		}
		if gap <= 8 {
			d.Recent8++
		}
		if gap <= 64 {
			d.Recent64++
		}
		if gap <= 512 {
			d.Recent512++
		}
	}
	c.last[ref] = d.Visits
	h := ref.slot ^ (ref.slot >> 9)
	if i := h % 32; c.ref32[i] == ref {
		d.Ref32++
	} else {
		c.ref32[i] = ref
	}
	if i := h % 128; c.ref128[i] == ref {
		d.Ref128++
	} else {
		c.ref128[i] = ref
	}
	if i := h % 512; c.ref512[i] == ref {
		d.Ref512++
	} else {
		c.ref512[i] = ref
	}
	if c.lastPage == p {
		d.SamePage++
	}
	c.lastPage = p
	if i := p.page % 4; c.page4[i] == p {
		d.Page4++
	} else {
		c.page4[i] = p
	}
	if i := p.page % 16; c.page16[i] == p {
		d.Page16++
	} else {
		c.page16[i] = p
	}
}

func PrintClauseLocality() {
	data, err := json.Marshal(map[string]localityCounts{
		"propagation": propagationLocality.Value, "list": watchListLocality.Value,
		"subsumption": subsumptionLocality.Value,
	})
	if err != nil {
		panic(err)
	}
	fmt.Fprintln(os.Stderr, "CLAUSE-LOCALITY", string(data))
}
