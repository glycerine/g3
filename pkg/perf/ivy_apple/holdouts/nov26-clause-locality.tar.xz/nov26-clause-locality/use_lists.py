"""Build independent SAT occurrence-list storage and scan alternatives."""

import argparse
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("variants", nargs="+")
p.add_argument("--goivy", action="store_true")
a = p.parse_args()
file = "sat/sat_solver_clause_use_lists.go"
subsumption = "sat/sat_solver_simplifier_subsumption.go"

for variant in a.variants:
    parts = variant.split("+")
    if set(parts)-{"packed", "bulk"}:
        p.error(f"unknown variant {variant}")
    dst = root / variant
    dst.mkdir(exist_ok=True)
    patches = {}

    def read(path):
        path = pkg / path
        return patches.get(path, path).read_text()

    def put(path, code):
        src = pkg / path
        patched = dst / src.name
        patched.write_text(code)
        patches[src] = patched

    def edit(path, old, new):
        code = read(path)
        if code.count(old) != 1:
            raise ValueError((path, old, code.count(old)))
        put(path, code.replace(old, new))

    def body(path, function, next_fn, code):
        text = read(path)
        begin = text.index(function)
        end = text.index(next_fn,begin+len(function))
        put(path, text[:begin]+code.rstrip()+"\n"+text[end:])

    if "packed" in parts:
        edit(file, "payload  []StoredClauseRef", "payload  []satUseClause")
        edit(file, "records               []satClauseUseListRecord",
             "records []satClauseUseListRecord\n exceptional []StoredClauseRef\n exceptionalIDs map[StoredClauseRef]uint32")
        edit(file, "\tu.records = u.records[:0]",
             "\tu.records = u.records[:0]\n\tu.exceptional = nil\n\tu.exceptionalIDs = nil")
        edit(file, "\tu.records = nil",
             "\tu.records = nil\n\tu.exceptional = nil\n\tu.exceptionalIDs = nil")
        edit(file, "return r.payload[i], nil", "return v.owner.decodeClause(r.payload[i]), nil")
        edit(file, "\tr.payload[i] = c\n\treturn nil",
             "\tvar ref satUseClause\n\tref, e = v.owner.encodeClause(c)\n\tif e != nil { return e }\n\tr.payload[i] = ref\n\treturn nil")
        edit(file, "r.payload = append(r.payload, c)",
             "ref, e := v.owner.encodeClause(c)\n\tif e != nil { return e }\n\tr.payload = append(r.payload, ref)")
        edit(file, "r.payload[len(r.payload)-1] = StoredClauseRef{}", "r.payload[len(r.payload)-1] = satUseClause{}")
        edit(subsumption, "c2 := record.payload[it.i]", "encoded := record.payload[it.i]\n\t\tc2 := k.useList.decodeClause(encoded)")
        edit(subsumption, "record.payload[it.j] = c2", "record.payload[it.j] = encoded")
        put(file,read(file)+"""
// Each ordinary occurrence uses the allocator of the enclosing use lists.
// Preserve exceptional tokens exactly, including a foreign owner or zero
// generation. These are diagnosed when the source actually reads the clause.
type satUseClause struct { slot, generation uint32 }

const satUseDirect = uint32(1)<<31

func (u *satClauseUseLists) encodeClause(c StoredClauseRef) (satUseClause, error) {
    if c.owner == u.allocator.origin && c.slot < satUseDirect && c.generation != 0 && c.storageKind <= 1 {
        return satUseClause{slot:c.slot | c.storageKind<<31, generation:c.generation}, nil
    }
    if c == (StoredClauseRef{}) {
        return satUseClause{}, nil
    }
    if index := u.exceptionalIDs[c]; index != 0 {
        return satUseClause{slot:index}, nil
    }
    if uint64(len(u.exceptional)) >= uint64(^uint32(0)) {
        return satUseClause{}, arena.ErrSlotLimit
    }
    if u.exceptionalIDs == nil {
        u.exceptionalIDs = make(map[StoredClauseRef]uint32)
    }
    u.exceptional = append(u.exceptional, c)
    index := uint32(len(u.exceptional))
    u.exceptionalIDs[c] = index
    return satUseClause{slot:index}, nil
}

func (u *satClauseUseLists) decodeClause(ref satUseClause) StoredClauseRef {
    if ref.generation != 0 {
        return StoredClauseRef{owner:u.allocator.origin, slot:ref.slot & (satUseDirect-1),
                               generation:ref.generation, storageKind:ref.slot>>31}
    }
    if ref.slot == 0 {
        return StoredClauseRef{}
    }
    return u.exceptional[ref.slot-1]
}
""")
    if "bulk" in parts:
        value = "v.owner.decodeClause(token)" if "packed" in parts else "token"
        body(file,"func (v satClauseUseListView) contains(", "func (v satClauseUseListView) removed(", """
func (v satClauseUseListView) contains(c StoredClauseRef) (bool, error) {
    r, e := v.record()
    if e != nil { return false, e }
    for _, token := range r.payload {
        if VALUE == c { return true, nil }
    }
    return false, nil
}
""".replace("VALUE",value))
        edit(file, """\tfor i := uint32(0); uint64(i) < uint64(len(r.payload)); i++ {
\t\tx, e := v.read(i)
\t\tif e != nil {
\t\t\treturn e
\t\t}
\t\tif x != c {
\t\t\tcontinue
\t\t}
\t\tfor j := i + 1; uint64(j) < uint64(len(r.payload)); j++ {
\t\t\tx, e = v.read(j)
\t\t\tif e != nil {
\t\t\t\treturn e
\t\t\t}
\t\t\tif e = v.write(j-1, x); e != nil {
\t\t\t\treturn e
\t\t\t}
\t\t}
\t\tr.payload[len(r.payload)-1] = ZERO
\t\tr.payload = r.payload[:len(r.payload)-1]
\t\tbreak
\t}""".replace("ZERO","satUseClause{}" if "packed" in parts else "StoredClauseRef{}"),
           """
        for i, token := range r.payload {
            if VALUE != c { continue }
            copy(r.payload[i:], r.payload[i+1:])
            end := len(r.payload)-1
            clear(r.payload[end:])
            r.payload = r.payload[:end]
            break
        }""".replace("VALUE", value))
        decode = "it.view.owner.decodeClause(token)" if "packed" in parts else "token"
        body(file,"func (it *satClauseUseListsIterator) consume()", "func (it *satClauseUseListsIterator) Current()", """
func (it *satClauseUseListsIterator) consume() error {
    if it.AtEnd() { return nil }
    r, e := it.view.record()
    if e != nil { return e }
    for !it.AtEnd() {
        if e := satWatchLogicalBounds(it.i, len(r.payload)); e != nil { return e }
        token := r.payload[it.i]
        dead, e := it.view.owner.allocator.Removed(VALUE)
        if e != nil { return e }
        if !dead {
            if e := satWatchLogicalBounds(it.j, len(r.payload)); e != nil { return e }
            r.payload[it.j] = token
            return nil
        }
        it.i++
    }
    return nil
}
""".replace("VALUE",decode))

    for path in patches.values():
        subprocess.run(["gofmt", "-w", path], check=True)
    cwd, name, command = pkg, "g3", ("./cmd/g3",)
    if a.goivy:
        for src, dest in list(patches.items()):
            patches[Path.home() / "g3/pkg" / src.relative_to(pkg)] = dest
        cwd, name, command = Path.home() / "ivy/goivy", "goivy_check", ("-tags=xtrace_off", "./cmd/goivy_check")
    overlay = dst / (name+".json")
    overlay.write_text(json.dumps({"Replace": {str(k):str(v) for k,v in patches.items()}}))
    subprocess.run(["go","build","-pgo=off","-buildvcs=false","-mod=readonly","-overlay",overlay,
                    "-o",dst/name,*command], cwd=cwd, check=True)
