"""Measure trivial DIMACS invocation, with and without explicit core tracking."""
import argparse
import csv
import io
import os
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cpu', type=int, required=True)
parser.add_argument('--perf', default='perf')
parser.add_argument('--rounds', type=int, default=21)
parser.add_argument('--wall-only', action='store_true')
parser.add_argument('engines', nargs='+')
args = parser.parse_args()
env = dict(os.environ, GOMAXPROCS='1', LC_ALL='C')
engines = [arg.split('=', 1) for arg in args.engines]
events = [] if args.wall_only else ['instructions', 'cycles']
writer = csv.writer(sys.stdout)
writer.writerow(('case','engine','round',*events,'milliseconds','stdout'))
for name, flags, cnf, expected in (
    ('default', [], 'p cnf 1 1\n1 0\n', 'sat\n1\n'),
    ('core', ['sat.dimacs.core=true'], 'p cnf 2 4\n1 2 0\n-1 2 0\n1 -2 0\n-1 -2 0\n', 'unsat\ncore\n'),
):
    baseline = None
    for turn in range(args.rounds):
        offset = turn % len(engines)
        for label, binary in engines[offset:] + engines[:offset]:
            command = ['taskset', '-c', str(args.cpu)]
            if events:
                command.extend([args.perf, 'stat', '-x,', '-e',
                                ','.join(event + ':u' for event in events), '--'])
            command.extend([binary, *flags, '-dimacs', '-in'])
            start = time.monotonic()
            run = subprocess.run(command, input=cnf, capture_output=True, text=True, env=env, check=True)
            ms = (time.monotonic() - start)*1e3
            normalized = '\n'.join(line.rstrip() for line in run.stdout.splitlines()) + '\n'
            if not normalized.startswith(expected) or (name=='default' and normalized != expected) or (label!='native' and baseline is not None and normalized != baseline):
                raise ValueError((name,label,run.stdout))
            if label!='native':
                baseline=normalized
            counts = {}
            for row in csv.reader(io.StringIO(run.stderr)):
                if len(row) >= 5 and row[2].split(':')[0] in events:
                    if float(row[4]) < 99.5:
                        raise ValueError((name,label,'multiplexed counter',row))
                    counts[row[2].split(':')[0]] = int(row[0])
            writer.writerow((name,label,turn+1,*(counts[event] for event in events),f'{ms:.3f}',run.stdout))
            sys.stdout.flush()
