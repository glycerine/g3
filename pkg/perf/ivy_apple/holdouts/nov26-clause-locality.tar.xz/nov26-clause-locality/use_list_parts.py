"""Isolate the stable erase and iterator improvements and try one route borrow."""
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
root = Path(__file__).resolve().parent
src = pkg / 'sat/sat_solver_clause_use_lists.go'
baseline = src.read_text()
bulk = (root / 'bulk' / src.name).read_text()


def use_section(text, name, next_name, code):
    begin = text.index('func ' + name)
    end = text.index('func ' + next_name, begin)
    start = code.index('func ' + name)
    stop = code.index('func ' + next_name, start)
    return text[:begin] + code[start:stop] + text[end:]


for name in ('erase', 'consume', 'bulk-route'):
    text = baseline
    if name == 'erase':
        text = use_section(text, '(v satClauseUseListView) EraseNotRemoved', '(v satClauseUseListView) Reset', bulk)
    elif name == 'consume':
        text = use_section(text, '(it *satClauseUseListsIterator) consume', '(it *satClauseUseListsIterator) Current', bulk)
    else:
        text = bulk.replace('n, e := u.allocator.Size(c)', 'clause, e := u.allocator.view(c)')
        text = text.replace('for i := uint32(0); i < n; i++ {\n\t\tl, e := u.allocator.Literal(c, i)\n\t\tif e != nil {\n\t\t\treturn e\n\t\t}',
                            'if len(clause) < 8 {\n\t\treturn arena.ErrBounds\n\t}\n\tfor i, n := uint32(0), clause.size(); i < n; i++ {\n\t\tif satClauseLiteralsOffset + 4*(uint64(i)+1) > uint64(len(clause)) {\n\t\t\treturn arena.ErrBounds\n\t\t}\n\t\tl := clause.literal(i)')
        assert 'u.allocator.Literal' not in text
    directory = root / name
    directory.mkdir(exist_ok=True)
    alt = directory / src.name
    alt.write_bytes(subprocess.check_output(['gofmt'], input=text.encode()))
    overlay = directory / 'overlay.json'
    overlay.write_text(json.dumps({'Replace': {str(src): str(alt)}}))
    subprocess.run(['go', 'build', '-pgo=off', '-buildvcs=false', '-mod=readonly', '-overlay', overlay,
                    '-o', directory / 'g3', './cmd/g3'], cwd=pkg, check=True)
