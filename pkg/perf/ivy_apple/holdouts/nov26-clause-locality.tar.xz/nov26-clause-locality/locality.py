"""Build an untimed census of clause address reuse."""

import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
out = Path(__file__).resolve().parent
dst = out / "observer"
dst.mkdir(exist_ok=True)
paths = {pkg / "sat/clause_locality_observer.go": out / "locality.go"}


def patch(name, edits):
    p = pkg / name
    content = p.read_text()
    for before, after in edits:
        assert content.count(before) == 1, before
        content = content.replace(before, after)
    src = dst / p.name
    src.write_bytes(subprocess.check_output(["gofmt"], input=content.encode()))
    paths[p] = src


patch("sat/sat_solver_propagation.go", [
    ("\tv := s.variables\n\ttracing := s.tracingPropagation()", "\tpropagationLocality.begin()\n\tdefer propagationLocality.end()\n\tv := s.variables\n\ttracing := s.tracingPropagation()"),
    ("\t\tassignment := v.assignment", "\t\twatchListLocality.begin()\n\t\tassignment := v.assignment"),
    ("\t\t\t\tc := StoredClauseRef(off)\n\t\t\t\tclause, e := s.clauses.view(c)",
     "\t\t\t\tc := StoredClauseRef(off)\n\t\t\t\tpropagationLocality.visit(c)\n\t\t\t\twatchListLocality.visit(c)\n\t\t\t\tclause, e := s.clauses.view(c)"),
    ("\t\tif destinations != nil {\n\t\t\t// The list record", "\t\twatchListLocality.end()\n\t\tif destinations != nil {\n\t\t\t// The list record"),
    # Complete the active list before returning through conflict cleanup.
    ("\t// A conflict preserves the unread suffix", "\twatchListLocality.end()\n\t// A conflict preserves the unread suffix"),
])
patch("sat/sat_solver_simplifier_subsumption.go", [
    ("\tstarted := false\n\tdefer func() {", "\tsubsumptionLocality.begin()\n\tdefer subsumptionLocality.end()\n\tstarted := false\n\tdefer func() {"),
    ("\t\tc2 := record.payload[it.i]\n\t\tv2, e := k.allocator.view(c2)", "\t\tc2 := record.payload[it.i]\n\t\tsubsumptionLocality.visit(c2)\n\t\tv2, e := k.allocator.view(c2)"),
])
main = (pkg / "cmd/g3/main.go").read_text()
entry = [("func main() {", "func main() {\n defer sat.PrintClauseLocality()")]
if '"github.com/glycerine/g3/pkg/sat"' not in main:
    entry.append(("package main", 'package main\n import "github.com/glycerine/g3/pkg/sat"'))
patch("cmd/g3/main.go", entry)
overlay = dst / "overlay.json"
overlay.write_text(json.dumps({"Replace": {str(k): str(v) for k, v in paths.items()}}))
subprocess.run(["go", "build", "-pgo=off", "-buildvcs=false", "-mod=readonly", "-overlay", overlay,
                "-o", dst / "g3", "./cmd/g3"], cwd=pkg, check=True)
