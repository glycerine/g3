"""Check census results against uninstrumented runs, then print reuse statistics."""
import csv
import json
from pathlib import Path
import sys

pkg = Path.cwd()
root = Path(__file__).resolve().parent
sys.path.insert(0, str(pkg / 'perf/ivy_raft'))
from watch_propagation import check_output

fixtures = Path(sys.argv[1])
normal = {}
for filename in ('generations.csv', 'generations-pigeon.csv'):
    with (root / filename).open() as f:
        for row in csv.DictReader(f):
            if row['engine'] == 'g3':
                normal[row['case']] = row
checks = ('conflicts', 'decisions', 'propagations', 'ternary-propagations', 'binary-propagations')
writer = csv.writer(sys.stdout)
keys = ('Scans', 'Visits', 'Unique', 'DistinctPages', 'Ref32', 'Ref128', 'Ref512', 'SamePage', 'Page4', 'Page16')
writer.writerow(('case', 'site', *keys))
for name in ('random-208-3', 'random-208-4', 'pigeon8-s0'):
    rows = [line.strip().split() for line in (fixtures / (name + '.cnf')).read_text().splitlines()
            if line.strip() and not line.lstrip().startswith('c')]
    variables, count = map(int, rows[0][2:])
    clauses = []
    clause = []
    for row in rows[1:]:
        for literal in map(int, row):
            if literal == 0:
                clauses.append(clause)
                clause = []
            else:
                clause.append(literal)
    assert not clause and len(clauses) == count
    expected = normal[name]
    stats = check_output((root / (name + '.stdout')).read_text(), expected['answer'], variables, clauses)
    assert all(stats.get(key, 0) == int(expected[key]) for key in checks), name
    report, = [line.split(' ', 1)[1] for line in (root / (name + '.stderr')).read_text().splitlines()
               if line.startswith('CLAUSE-LOCALITY ')]
    for site, values in json.loads(report).items():
        writer.writerow((name, site, *(values[key] for key in keys)))
