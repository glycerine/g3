"""Build an untimed census of stable occurrence erasures and shifted records."""
import json
from pathlib import Path
import subprocess

pkg = Path.cwd()
root = Path(__file__).resolve().parent
out = root / 'erase-census'
out.mkdir(exist_ok=True)
replace = {}


def write(name, edits):
    src = pkg / name
    text = src.read_text()
    for before, after in edits:
        assert text.count(before) == 1, before
        text = text.replace(before, after)
    target = out / src.name
    target.write_bytes(subprocess.check_output(['gofmt'], input=text.encode()))
    replace[str(src)] = str(target)


write('sat/sat_solver_clause_use_lists.go', [
    ('import (', 'import (\n"fmt"\n"os"'),
    ('// No callbacks run while moving', 'eraseCalls++\n\t// No callbacks run while moving'),
    ('for i, ref := range r.payload {', 'for i, ref := range r.payload {\n eraseProbes++'),
    ('copy(r.payload[i:], r.payload[i+1:])', 'eraseMoves += uint64(len(r.payload)-i-1)\n eraseHits++\n copy(r.payload[i:], r.payload[i+1:])'),
    ('type satClauseUseListRecord struct {', '''var eraseCalls, eraseProbes, eraseMoves, eraseHits uint64
func PrintOccurrenceErasures() {
 fmt.Fprintf(os.Stderr, "OCCURRENCE-ERASE calls=%d found=%d compared=%d shifted=%d\\n", eraseCalls, eraseHits, eraseProbes, eraseMoves)
}

type satClauseUseListRecord struct {'''),
])
main = pkg / 'cmd/g3/main.go'
edits = [('func main() {', 'func main() {\n defer sat.PrintOccurrenceErasures()')]
if '"github.com/glycerine/g3/pkg/sat"' not in main.read_text():
    edits.append(('package main', 'package main\n import "github.com/glycerine/g3/pkg/sat"'))
write('cmd/g3/main.go', edits)
overlay = out / 'overlay.json'
overlay.write_text(json.dumps({'Replace': replace}))
subprocess.run(['go', 'build', '-pgo=off', '-buildvcs=false', '-mod=readonly', '-overlay', overlay,
                '-o', out / 'g3', './cmd/g3'], cwd=pkg, check=True)
