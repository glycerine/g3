from pathlib import Path
import os
w=Path(__file__).resolve().parent
s=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0]
s=s[:s.index('subprocess.run([*flags')]+s[s.index('def run'):]
modes={'base':w/'base','release':w/'release','native':Path('/tmp/g3-flash-marginal/abc-control/native')}
exec(s)
if os.getenv('PANEL'):
 with concurrent.futures.ThreadPoolExecutor(6) as pool:
  jobs=[pool.submit(run,1+2*i,'panel'+str(i),cases[i::6],1,['release']) for i in range(6)]
  for job in jobs:job.result()
else:
 run(int(os.getenv('CPU','18')),os.environ['STEM'],[cases[int(i)-1] for i in os.environ['CASES'].split()],int(os.getenv('ROUNDS','5')),os.environ.get('MODES','base release native').split())
