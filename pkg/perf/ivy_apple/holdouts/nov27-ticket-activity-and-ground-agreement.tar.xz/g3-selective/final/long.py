from pathlib import Path
import json,subprocess
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/apple-source/goivy').resolve()
a=w/'apple.go.txt';base=(front/'z3bridge_solver_model.go').read_text()
old=(p/'build/.boolean-enode-cost/frontend/goivy/z3bridge_solver_model.go').read_text()
assert old.replace('if shrink && !s.opts.DisableModelShrinking {','if shrink {')==base
a.write_text((w/'z3bridge_solver_model.go').read_text().replace('if shrink && !s.opts.DisableModelShrinking {','if shrink {'))
j=w/'apple.json';j.write_text(json.dumps({'Replace':{str(front/'z3bridge_solver_model.go'):str(a),str(front/'z3bridge_guarded_equalities.go'):str(w/'z3bridge_guarded_equalities.go')}}))
for m,extra in [('base',[]),('release',['-overlay',j])]:
 subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),*extra,'-o',w/('apple-'+m),'./cmd/goivy_check'],cwd=front,check=True)
s=Path('/tmp/g3-plan-budget/long.py').read_text();s=s[:s.index('bin=Path')]+s[s.index("ex=Path"):]
s=s.replace("modes=['base','256','512']","modes=['base','release']").replace('for m in modes[i:]+modes[:i]:','for m in modes[i%2:]+modes[:i%2]:').replace("exe=bin/m if apple else (Path('/tmp/g3-live-frame-cost/recheck/baseline') if m=='base' else w/m/'release')","exe=w/(('apple-'+m) if apple else m)")
exec(s)
