from pathlib import Path
import os,csv,subprocess,json,collections
p=Path.cwd();w=Path(__file__).resolve().parent
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();f=front/'z3bridge_solver_model.go';ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())['Replace'];s=Path(ov[str(f)]).read_text()
s=s.replace('s.showVCsBase(clauses)','s.showVCsBase(clauses);studyBatch++;batch:=studyBatch',1)+'\nvar studyBatch int\n'
s=s.replace('for _, fc := range finalCond {','for ordinal,fc:=range finalCond {',1)
key='res, err := s.decideZ3With(z3solver, finalCheck)'
s=s.replace(key,'''g:=index+1
                marked:=batch==8 && g==1 || batch==6 && (g==5 || g==6 || g==26)
                if marked { z3solver.StudyStats(batch,g,"before") }
                '''+key+'''
                if marked { z3solver.StudyStats(batch,g,"after") }''')
bridge=w/'stats-bridge.go.txt';bridge.write_text(s)
g3='''
func(s *Z3Solver) StudyStats(b,g int,when string) {
 s.ctx.do(func(){z,err:=s.c.Statistics();fail(err);defer z.Close()
 n,e:=z.Size();fail(e)
 for i:=uint32(0);i<n;i++ {is,e:=z.IsUint(i);fail(e);if is{k,e:=z.Key(i);fail(e);v,e:=z.UintValue(i);fail(e);println("COUNT",b,g,when,v,k)}}})
}
'''
native='''
func(s *Z3Solver) StudyStats(b,g int,when string) {
 s.ctx.do(func(){c:=s.ctx.c;z:=C.Z3_solver_get_statistics(c,s.c)
 C.Z3_stats_inc_ref(c,z); defer C.Z3_stats_dec_ref(c,z)
 n:=C.Z3_stats_size(c,z)
 for i:=C.uint(0);i<n;i++ {if bool(C.Z3_stats_is_uint(c,z,i)){k:=C.GoString(C.Z3_stats_get_key(c,z,i));v:=C.Z3_stats_get_uint_value(c,z,i);println("COUNT",b,g,when,uint(v),k)}}})
}
'''
with (w/'stats.csv').open('w') as fcsv:
 out=csv.writer(fcsv);out.writerow('engine round batch goal name before after delta'.split())
 for e,src,extra in [('g3','g3_solver.go',g3),('z3','quantifier.go',native)]:
  k=front/'smt'/src;dest=w/(e+'-stats.go');dest.write_text(k.read_text()+extra);j=w/(e+'-stats.json');j.write_text(json.dumps({'Replace':{**ov,str(k):str(dest),str(f):str(bridge)}}))
  cmd=['go','build','-mod=readonly','-buildvcs=false','-modfile',str((p/'build/.boolean-enode-cost/heap/study.mod').resolve()),'-tags','xtrace_off'+(',classic_z3' if e=='z3' else ''),'-overlay',j,'-pgo='+str((p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof').resolve()),'-o',w/(e+'-stats'),'./cmd/goivy_check'];subprocess.run(cmd,cwd=front,check=True)
  ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows/compat/4/1/native')
  for i in range(3):
   r=subprocess.run(['taskset','-c','12',w/(e+'-stats'),ex/'test/arm_rules3.ivy'],cwd='/tmp/g3-frame-child',env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,check=True,timeout=60)
   keep=[];stats=collections.defaultdict(dict)
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'COUNT '):
     _,b,g,when,v,k=l.decode().strip().split(' ',5);stats[b,g,k][when]=int(v)
    else:keep.append(l)
   assert (r.stdout,b''.join(keep))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
   for (b,g,k),v in stats.items():out.writerow([e,i,b,g,k,v.get('before',0),v.get('after',0),v.get('after',0)-v.get('before',0)])
   fcsv.flush()
