from pathlib import Path
import os,subprocess
w=Path(__file__).resolve().parent;d=w/'arith-inputs';d.mkdir(exist_ok=True)
p=Path('/tmp/g3-reduction-rows');ns=(p/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');exe=Path('/tmp/g3-ticket-stages/dump-native')
for nr in [14,15]:
 name=ns[nr-1];ref=p/'compat'/str(nr)/'1/native'
 r=subprocess.run([exe,ex/name],cwd=w,env=dict(os.environ,XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TICKET_CASE=str(nr),TICKET_DIR=str(d),TICKET_TARGETS=',2/3,2/22,2/25,2/30,'),capture_output=True)
 assert (r.returncode,r.stdout,r.stderr)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,r.returncode,r.stderr[:300])
assert len(list(d.glob('*.smt2')))==8
