from pathlib import Path
import sys,json,re,subprocess,shlex,shutil,os,csv
w=Path(__file__).resolve().parent;p=Path.cwd();old=w.parent/'g3-clause-confirmation';n=(p/'build/.witness-origin/search-native').resolve();b=(p/'build/.boolean-enode-cost').resolve();f=b/'frontend/goivy'
e=sys.argv[1];files=json.loads((w/(e+'.json')).read_text())['Replace']
def save(k,s):
 dst=w/(e+'-all-'+k.name);dst.write_text(s);files[str(k)]=files[str(k.resolve())]=str(dst)
if e=='g3':
 k=p/'smtcore/smt_search.go';s=Path(files[str(k)]).read_text()
 a='if k.internalizer==trialOwner && witnessTrace()';assert s.count(a)==1
 save(k,s.replace(a,'if witnessTrace(){println("WT split",variable,smtDecisionLiteral(variable,phase).Sign(),witnessTree(k.manager,k.internalizer.boolExpr[variable]))};'+a))
else:
 build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 s=(n/'smt_context.cpp').read_text();a='if(active() && witness_owner==this){std::ostringstream';assert s.count(a)==1
 s=s.replace(a,'if(active()){std::ostringstream o;shape(o,bool_var2expr(var));fprintf(stderr,"WT split %u %s %s\\n",var,is_pos?"false":"true",o.str().c_str());}\n'+a)
 dst=w/'smt_context.cpp';dst.write_text(s);obj=w/'smt_context.o';lib=w/'liball.a';shutil.copyfile(w/'libevents.a',lib)
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dst],cwd=build,check=True);subprocess.run(['ar','r',lib,obj],check=True)
 k=f/'smt/quantifier.go';save(k,Path(files[str(k)]).read_text().replace(str(w/'libevents.a'),str(lib)))
source=(w/'observe.py').read_text().split("ov=w/(e+'.json')",1)[1].replace("binary=w/e","binary=w/('all-'+e)").replace("w/(e+'.csv')","w/('all-'+e+'.csv')")
ov=w/('all-'+e+'.json');exec("ov=ov"+source)
