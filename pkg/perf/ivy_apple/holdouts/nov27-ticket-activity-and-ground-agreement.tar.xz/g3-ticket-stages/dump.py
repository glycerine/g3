from pathlib import Path
import subprocess,json,sys,os,csv
w=Path(__file__).resolve().parent
p=Path.cwd()
f=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
mod=(p/'build/.boolean-enode-cost/heap/study.mod').resolve()
src=f/'z3bridge_solver_model.go'
s=src.read_text().replace('import (','import (\n "path/filepath"\n',1)
if '"os"' not in s:s=s.replace('import (','import (\n "os"\n',1)
key='z3solver := s.newZ3Solver()'
pos=s.index('func (s *Solver) GetSmallModelWithCond(');prefix,s=s[:pos],s[pos:]
pos=s.index(key);s=s[:pos]+'ticketBatch++; batch := ticketBatch\n\t'+s[pos:]
s=s.replace('for _, fc := range finalCond {','for ordinal, fc := range finalCond {',1)
key='res, err := s.decideZ3With(z3solver, finalCheck)';assert s.count(key)==1
s=s.replace(key,'''if targets := os.Getenv("TICKET_TARGETS"); strings.Contains(targets, fmt.Sprintf(",%d/%d,",batch,ordinal+1)) {
                name := fmt.Sprintf("%s-%d-%d.smt2",os.Getenv("TICKET_CASE"),batch,ordinal+1)
                text := z3solver.String()+"\\n(check-sat)\\n(get-info :all-statistics)\\n"
                if e:=os.WriteFile(filepath.Join(os.Getenv("TICKET_DIR"),name),[]byte(text),0600);e!=nil {panic(e)}
            }
            '''+key)
s=prefix+'var ticketBatch int\n\n'+s
if '"strings"' not in s:s=s.replace('import (','import (\n "strings"\n',1)
dest=w/'dump.go.txt';dest.write_text(s);ov=w/'dump.json';ov.write_text(json.dumps({'Replace':{str(src):str(dest)}}))
exe=w/'dump-native'
subprocess.run(['go','build','-buildvcs=false','-mod=readonly','-modfile',mod,'-pgo=off','-tags','xtrace_off,classic_z3','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=f,check=True)
p=Path('/tmp/g3-reduction-rows');ns=(p/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples');out=w/'fixtures';out.mkdir(exist_ok=True)
for n,targets in [(3,',4/55,7/1,'),(6,',16/1,14/44,14/45,'),(8,',12/8,14/8,16/1,'),(12,',10/27,13/28,')]:
 name=ns[n-1];r=subprocess.run([exe,ex/name],cwd=w,env=dict(os.environ,XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TICKET_CASE=str(n),TICKET_DIR=str(out),TICKET_TARGETS=targets),capture_output=True)
 ref=p/'compat'/str(n)/'1/native'
 assert (r.returncode,r.stdout,r.stderr)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,r.returncode,r.stderr[:300])
assert len(list(out.glob('*.smt2')))==10
