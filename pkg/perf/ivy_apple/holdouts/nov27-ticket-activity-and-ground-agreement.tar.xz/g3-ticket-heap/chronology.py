from pathlib import Path
import subprocess as sp,collections,csv,itertools,sys
w=Path(__file__).resolve().parent;p=Path.cwd();exec((w/'transfer.py').read_text().split("d=w/'transfer'")[0])
reuse=Path('/tmp/g3-ticket-focus/reuse/3');d=w/'chronology';d.mkdir(exist_ok=True);mode=sys.argv[1];engine=p.parent/'build/z3' if mode=='native' else w/'g3-cli'
with (w/('chronology-'+mode+'.csv')).open('w') as f:
 o=csv.writer(f);o.writerow('batch goal earlier instances base answer'.split())
 for b in range(2,6):
  t=Terms();fmt=lambda x:t.render(t.expand(x,{}));checked={}
  for n in (37,55,56):
   forms,(base,goal)=source(w/'obligations'/f'3-{b}-{n}.smt2');baseID=t.expand(base,{});bd=set(leaves(base));qsyms=set(leaves(goal));decls={x[1]:x for x in forms if x[0].startswith('declare')};pool={k:v[-1] for k,v in decls.items() if k in qsyms and v[0]=='declare-fun' and not v[2] and v[-1]!='Bool'};lemmas=set();used=0
   for g in range(1,n):
    src=reuse/f'3-{b}-{g}.smt2'
    if not src.exists():continue
    early,ass=source(src)
    if len(ass)!=2 or t.expand(ass[0],{})!=baseID:continue
    old=ass[1];syms=set(leaves(old))
    if {'exists','forall'} & syms:continue
    local={x[1]:x for x in early if x[0].startswith('declare') and x[1] in syms};fresh={k:v[-1] for k,v in local.items() if k not in bd and v[0]=='declare-fun' and not v[2] and v[-1]!='Bool'}
    if len(fresh)>5 or any(decls.get(k)!=v for k,v in local.items() if k not in fresh):continue
    tuples=list(itertools.product(*[[v for v in pool if pool[v]==sort] for sort in fresh.values()]))
    if not tuples:continue
    if g not in checked:
     vars=['|prior-proof-ground-'+str(i)+'|' for i in range(len(fresh))];assert set(vars).isdisjoint(set(leaves(early)));body=['not',subst(old,dict(zip(fresh,vars)))];lemma=['forall',list(map(list,zip(vars,fresh.values()))),body] if vars else body
     text='\n'.join([*(fmt(x) for x in early if x[0].startswith('declare')),'(assert '+fmt(ass[0])+')','(assert (not '+fmt(lemma)+'))','(check-sat)'])
     a=sp.run([engine,'smt.macro_finder=true','-in'],input=text,capture_output=True,text=True,timeout=20);checked[g]=a.stdout.strip()=='unsat' and not a.stderr and a.returncode==0
    if not checked[g]:continue
    used+=1
    for values in tuples:lemmas.add('(assert (not '+fmt(subst(old,dict(zip(fresh,values))))+'))')
   for level in ('ground','goal'):
    text=(w/'ground-inputs'/f'3-{b}-{n}-{level}.smt2').read_text().split('(check-sat)')[0]+'\n'.join(sorted(lemmas))+'\n(check-sat)\n'
    if mode=='native':(d/f'{b}-{n}-{level}.smt2').write_text(text)
    r=sp.run([engine,'-in'],input=text,text=True,capture_output=True,timeout=15);assert r.returncode==0 and not r.stderr and r.stdout.strip() in ('sat','unsat'),r.stdout[:100];o.writerow([b,n,used,len(lemmas),level,r.stdout.strip()]);f.flush()
