from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'measure.py').read_text();a=s.index(" path=p/'smtcore");b=s.index(" dest=w/path.name")
s=s[:a]+''' path=p/'smtcore/smt_internalizer_state.go';key='initialActivity = -float64(s.random.Next()%1000) / 1000';replace(path,path.read_text().replace(key,key+';if TrialInit>0 {println("TRACE init",TrialInit,variable,int(-1000*initialActivity+0.5))}')+'\\nvar TrialInit int\\n')
else:
 path=p.parent/'src/smt/smt_internalizer.cpp';key='m_activity[v]      = -((m_random() % 1000) / 1000.0);';s=path.read_text().replace(key,'{'+key+' if(const char* init=getenv("BATCH_INIT"))fprintf(stderr,"WT init %s %d %.0f\\\\n",init,v,-1000*m_activity[v]);}')
'''+s[b:];a=s.index("j=w/(mode+'.json')");s=s[:a]+'''path=front/'z3bridge_solver_model.go';ss=Path(ov['Replace'][str(path)]).read_text();key='for index, fc := range finalCond {';statement='smtcore.TrialInit=0;if batch==2 && index<8 {smtcore.TrialInit=index+1}' if mode=='go' else 'os.Unsetenv("BATCH_INIT");if batch==2 && index<8 {os.Setenv("BATCH_INIT",strconv.Itoa(index+1))}';replace(path,ss.replace(key,key+statement))
'''+s[a:];s=s.replace("w/'smt_case_split_queue.o'","w/'smt_internalizer.o'").replace("w/'heap.a'","w/'init.a'").replace("'-o',w/mode","'-o',w/('init-'+mode)").replace("sp.run([w/mode,ex/case]","sp.run([w/('init-'+mode),ex/case]").replace("GOAL='55'","GOAL='0'").replace("w/(mode+'.txt')","w/(mode+'-init.txt')").replace("if l.startswith(b'HEAP ')","if l.startswith((b'WT init',b'TRACE init'))")
exec(s)
