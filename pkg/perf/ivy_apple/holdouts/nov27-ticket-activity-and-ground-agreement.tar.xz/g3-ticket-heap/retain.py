from pathlib import Path
import json,os,csv,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();old=Path('/tmp/g3-ticket-splits');ov=json.loads((old/'meter.json').read_text());path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text()
k='nextGroup, provenThrough := 0, 0';assert s.count(k)==1;s=s.replace(k,k+'''
 var prior []smt.Z3Expr
 remember:=func(i int,goal smt.Z3Expr){if !s.opts.Incremental || learnedMode=="" {return}; if learnedMode=="all"{z3solver.Assert(s.tr.Ctx.Not(goal));return};if batch==4 && i==12 || batch==5 && i==38 {prior=append(prior,s.tr.Ctx.Not(goal))}}
''')
k='if index < provenThrough {';s=s.replace(k,k+'''if learnedMode=="all" || learnedMode=="one" && (batch==4 && index==11 || batch==5 && index==37) {if g,e:=s.ClausesToZ3(cond);e==nil{remember(index+1,g)}};''',1)
s=s.replace('if proveGoal(zCond) {','if proveGoal(zCond) {remember(index+1,zCond);',1)
s=s.replace('provenThrough = nextGroup','remember(index+1,zCond);provenThrough = nextGroup',1)
k='z3solver.Assert(zCond)\n\t\t\t\t// Python';assert s.count(k)==1;s=s.replace(k,'''if learnedMode=="one" && index==55 && s.opts.Incremental {for _,h:=range prior{z3solver.Assert(h)}}
                '''+k)
k='z3solver.Pop()\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t} else {';assert s.count(k)==1;s=s.replace(k,k.replace('z3solver.Pop()','z3solver.Pop();if res==smt.Unsat{remember(index+1,zCond)}'))
dest=w/'retain-bridge.go.txt';dest.write_text(s+'\nvar learnedMode=os.Getenv("EXPERIMENT")\n');ov['Replace'][str(path)]=str(dest)
j=w/'retain.json';j.write_text(json.dumps(ov));src=(old/'trial.py').read_text();s=src[src.index("sp.run(['go','build'"):].replace("w/'trials.csv'","w/'retain.csv'").replace("w/'trial'","w/'retain'").replace("[(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]","[(3,b,56,['','one','all']) for b in (4,5)]").replace("w/'whole.stat'","w/'retain.stat'").replace('case round policy','case batch round policy').replace('o.writerow([nr,i,mode','o.writerow([nr,b,i,mode').replace('range(5)','range(3)');exec(s)
