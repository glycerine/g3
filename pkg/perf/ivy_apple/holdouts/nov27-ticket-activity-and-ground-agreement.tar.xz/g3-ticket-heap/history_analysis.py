from pathlib import Path
import csv
w=Path(__file__).resolve().parent
def rows(e):return {(int(r['goal']),int(r['step'])):{int(x): (float(a),int(v)) for x,a,v in (y.split('/') for y in r['heap'].split())} for r in csv.DictReader((w/(e+'-history.csv')).open())}
g=rows('go');n=rows('native')
for k in sorted(g.keys()|n.keys()):
 if k[1]!=1:continue
 a=g.get(k,{});b=n.get(k,{})
 ds=[x for x in a.keys()&b.keys() if abs(a[x][0]-b[x][0])>max(1,abs(b[x][0]))*0.000006]
 print(k[0],len(a),len(b),len(a.keys()^b.keys()),len(ds),a.get(130),b.get(130))
