from pathlib import Path
import os,json,csv,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;old=Path('/tmp/g3-ticket-splits');front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads((old/'meter.json').read_text())
def save(path,s):
 dest=w/('reseed-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text();k='var end func(string);';s=s.replace(k,'''if batch==2 {smtcore.TrialGoal=index+1};'''+k);save(path,s)
path=p/'smtcore/smt_case_split_queue.go';s=path.read_text().replace('import (','import ("os";',1);k='threshold := int(frequency * float64(z3rand.Max))'
seed=0;before={}
for i in range(1,10000):
 oldSeed=seed;seed=(seed*214013+2531011)&0xffffffff;before.setdefault((seed>>16)&32767,oldSeed)
for goal in (5,8,14):
 d=int(next(l for l in (w/f'native-draw-{goal}.txt').read_text().splitlines() if ' draw ' in l).split()[2])
 key=str(goal);k2='if trialSeed=="'+key+'" && TrialGoal=='+key+' && !trialSet {trialSet=true;q.state.random.SetSeed('+str(before[d])+');println("TRIAL seed",TrialGoal)};';s=s.replace(k,k2+k,1)
save(path,s+'\nvar TrialGoal int\nvar trialSet bool\nvar trialSeed=os.Getenv("EXPERIMENT")\n')
j=w/'reseed.json';j.write_text(json.dumps(ov));src=(old/'trial.py').read_text();s=src[src.index("sp.run(['go','build'"):].replace("w/'trials.csv'","w/'seeds.csv'").replace("[(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]","[(3,2,g,['default','5','8','14']) for g in (8,14,55)]").replace('case round policy','case goal round policy').replace('o.writerow([nr,i,mode','o.writerow([nr,g,i,mode');exec(s)
