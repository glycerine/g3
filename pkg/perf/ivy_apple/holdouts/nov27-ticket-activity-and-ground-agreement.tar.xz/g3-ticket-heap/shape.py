from pathlib import Path
import json,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads(Path('/tmp/g3-arm-pass/release.json').read_text());path=p/'api/api_order_abstraction.go';s=path.read_text().replace('import (','import ("os";',1)
k='proved, err = p.proveAssertions(parent, assertions, maxSteps, reuse)';assert s.count(k)==1
s=s.replace(k,'''if shapeMode!="" && reuse && p.expectedGoals>=24 && goal.IsNull() && len(assertions)>1 && hasOriginalAssertions(s.solver) && p.plans.reusable(parent) && trialPairedGoal(parent,assertions[len(assertions)-1]) {
 proofs,e:=parent.ProofsEnabled();if e!=nil{return false,e};if !proofs{var g groundInstanceSolver
 yes,e:=g.prove(s,parent,assertions,min(maxSteps,2000000),1);err=errors.Join(e,g.close());if shapeMode=="log"{println("TRIAL pair",yes)};if yes || err!=nil || limit.CancelFlag(){return yes && err==nil,err}}
 }
 '''+k)
s+='''
var shapeMode=os.Getenv("SHARED_BIND")
func trialPairedGoal(m *ast.ASTManager,h ast.ASTHandle)bool{
 // A guarded equality between two predicates applied to the identical tuple of constants.
 child:=func(x ast.ASTHandle,i uint32)ast.ASTHandle{y,_:=m.GetArg(x,i);return y}
 has:=func(x ast.ASTHandle,op int32,n uint32)bool{v,e:=m.NodeHeader(x);return e==nil && v.Kind==ast.ASTApp && v.Family==m.BasicFamilyID() && v.DeclKind==op && v.NumArgs==n}
 if has(h,ast.ASTOpAnd,1){h=child(h,0)}
 if !has(h,ast.ASTOpNot,1){return false};h=child(h,0)
 if !has(h,ast.ASTOpImplies,2){return false};h=child(h,1)
 if !has(h,ast.ASTOpEq,2) && !has(h,ast.ASTOpIff,2){return false}
 a,b:=child(h,0),child(h,1);ad,e:=m.NodeHeader(a);if e!=nil || ad.Kind!=ast.ASTApp || ad.Family!=ast.NullFamilyID || ad.NumArgs!=2{return false}
 bd,e:=m.NodeHeader(b);if e!=nil || bd.Kind!=ast.ASTApp || bd.Family!=ast.NullFamilyID || bd.NumArgs!=ad.NumArgs{return false}
 ok,e:=m.HasBoolSort(a);if e!=nil || !ok{return false}
 for i:=uint32(0);i<ad.NumArgs;i++{x:=child(a,i);if x!=child(b,i){return false};hd,e:=m.NodeHeader(x);if e!=nil || hd.Kind!=ast.ASTApp || hd.Family!=ast.NullFamilyID || hd.NumArgs!=0{return false}}
 return true
}
'''
dest=w/'shape.go';dest.write_text(s);ov['Replace'][str(path)]=str(dest);j=w/'shape.json';j.write_text(json.dumps(ov));src=Path('/tmp/g3-ticket-splits/shared.py').read_text();exec(src[src.index("sp.run(['go','build'"):].replace("w/'shared'","w/'shape'"))
