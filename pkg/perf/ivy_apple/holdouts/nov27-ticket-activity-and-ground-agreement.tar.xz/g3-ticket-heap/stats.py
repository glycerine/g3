from pathlib import Path
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-arm-pass/stats.py').read_text().replace('batch==8 && g==1 || batch==6 && (g==5 || g==6 || g==26)','true').replace('compat/4/1/native','compat/3/1/native').replace("ex/'test/arm_rules3.ivy'","ex/Path('/tmp/g3-reduction-rows/compat.txt').read_text().splitlines()[2]").replace('range(3)','range(2)')
exec(s)
