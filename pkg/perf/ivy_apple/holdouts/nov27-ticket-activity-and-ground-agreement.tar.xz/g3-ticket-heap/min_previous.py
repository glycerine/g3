from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'chronology.py').read_text().replace("for b in range(2,6):","for b in (4,5):").replace("for n in (37,55,56):","for n in (56,):").replace("lemmas=set();used=0","lemmas=set();groups={};used=0")
k="for values in tuples:lemmas.add('(assert (not '+fmt(subst(old,dict(zip(fresh,values))))+'))')"
s=s.replace(k,"groups[g]=sorted({'(assert (not '+fmt(subst(old,dict(zip(fresh,values))))+'))' for values in tuples})");s=s[:s.index("   for level in ('ground','goal'):")]+'''
   base=(w/'ground-inputs'/f'3-{b}-{n}-goal.smt2').read_text().split('(check-sat)')[0]
   def proves(rows):
    query=base+'\\n'.join(rows)+'\\n(check-sat)';r=sp.run([engine,'-in'],input=query,text=True,capture_output=True,timeout=15);assert r.returncode==0 and not r.stderr and r.stdout.strip() in ('sat','unsat');return r.stdout.strip()=='unsat'
   assert not proves([])
   for g,rows in groups.items():
    if not proves(rows):continue
    keep=rows.copy()
    for q in rows:
     trial=[x for x in keep if x!=q]
     if proves(trial):keep=trial
    o.writerow([b,n,g,len(keep),'; '.join(keep),'unsat']);f.flush()
'''
s=s.replace("('chronology-'+mode+'.csv')","('singleton-'+mode+'.csv')").replace("'batch goal earlier instances base answer'","'batch goal earlier instances lemmas answer'")
exec(s)
