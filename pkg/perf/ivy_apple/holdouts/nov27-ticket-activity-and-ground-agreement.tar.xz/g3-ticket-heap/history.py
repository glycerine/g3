from pathlib import Path
import os,subprocess as sp,csv,sys,collections
w=Path(__file__).resolve().parent;mode=sys.argv[1];ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');name=(rank/'compat.txt').read_text().splitlines()[2];ref=rank/'compat/3/1/native'
with (w/(mode+'-history.csv')).open('w') as f:
 o=csv.writer(f);o.writerow('goal step heap'.split())
 for i in range(1,56):
  r=sp.run([w/mode,ex/name],cwd=w,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',BATCH='2',GOAL=str(i),GOIVY_INCLUDE=str(ex/'ivy/include')))
  lines=r.stderr.splitlines(keepends=True);assert (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith((b'WT ',b'TRACE ',b'HEAP '))))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
  for l in lines:
   if l.startswith(b'HEAP '):
    _,step,s=l.decode().strip().split(' ',2);o.writerow([i,step,s])
  f.flush()
