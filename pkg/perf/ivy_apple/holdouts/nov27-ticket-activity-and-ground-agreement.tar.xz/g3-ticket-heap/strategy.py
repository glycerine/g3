from pathlib import Path
import json,subprocess as sp,sys,os
p=Path.cwd();w=Path(__file__).resolve().parent;ov=json.loads(Path('/tmp/g3-arm-pass/release.json').read_text())
def save(path,s):
 dest=w/('strategy-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
path=p/'smtcore/smt_case_split_queue.go';s=path.read_text().replace('import (','import ("os";',1).replace('liveParams                            *SMTParams','trialGenerator z3rand.Generator\n trialSeeded bool\n liveParams *SMTParams');i=s.index('threshold :=',s.index('func (q *SMTActivityCaseSplitQueue) randomVariable'));j=s.index('value, err',i);s=s[:i]+'''if trialStrategy=="none"{return SMTNullBoolVar,nil};gen:=&q.state.random;if trialStrategy=="separate" || trialStrategy=="separate-reset"{gen=&q.trialGenerator};
 '''+s[i:j].replace('q.state.random.Next()','gen.Next()')+s[j:];save(path,s+'\nvar trialStrategy=os.Getenv("SHARED_BIND")\n')
path=p/'smtcore/smt_search.go';s=path.read_text().replace('queue.phaseDefault = false','''if trialStrategy=="reset"{k.internalizer.random.SetSeed(k.smtState.RandomSeed)};if trialStrategy=="separate-reset" || trialStrategy=="separate" && !queue.trialSeeded{queue.trialGenerator.SetSeed(k.smtState.RandomSeed);queue.trialSeeded=true};queue.phaseDefault = false''',1);save(path,s)
j=w/'strategy.json';j.write_text(json.dumps(ov));src=Path('/tmp/g3-ticket-splits/shared.py').read_text();s=src[src.index("sp.run(['go','build'"):];front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();exec(s.replace("w/'shared'","w/'strategy'"))
