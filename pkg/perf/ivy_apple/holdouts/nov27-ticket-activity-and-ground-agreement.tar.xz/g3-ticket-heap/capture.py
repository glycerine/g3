from pathlib import Path
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-ticket-first/arith_capture.py').read_text().replace('arith-inputs','obligations').replace('for nr in [14,15]','for nr in [3]').replace(',2/3,2/22,2/25,2/30,',',2/37,3/37,4/37,5/37,2/55,3/55,4/55,5/55,2/56,3/56,4/56,5/56,7/1,').replace('==8','==13');exec(s)
