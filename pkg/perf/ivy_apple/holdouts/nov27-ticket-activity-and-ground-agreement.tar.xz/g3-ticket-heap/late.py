from pathlib import Path
import json,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();path=p/'api/api_order_abstraction.go';s=(w/'arity.go').read_text()
a=s.index('if shapeMode!=""');b=s.index('proved, err = p.proveAssertions',a);block=s[a:b];s=s[:a]+s[b:];k='return p.enumeration.check(parent, assertions, goal.IsNull())';s=s.replace(k,'proved,err=p.enumeration.check(parent,assertions,goal.IsNull())')
a=s.index(k) if k in s else s.index('proved,err=p.enumeration.check');b=s.index('return proved, err',a);s=s[:b]+block.replace('if shapeMode!=""','if !proved && err==nil && !limit.CancelFlag() && shapeMode!=""')+s[b:]
dest=w/'late.go';dest.write_text(s);ov=json.loads((w/'arity.json').read_text());ov['Replace'][str(path)]=str(dest);j=w/'late.json';j.write_text(json.dumps(ov));src=Path('/tmp/g3-ticket-splits/shared.py').read_text();exec(src[src.index("sp.run(['go','build'"):].replace("w/'shared'","w/'late'"))
