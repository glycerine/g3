from pathlib import Path
import os,json,csv,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();old=Path('/tmp/g3-ticket-splits');ov=json.loads((old/'meter.json').read_text())
def save(path,s):
 dest=w/('ground-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
path=p/'api/api_order_abstraction.go';s=path.read_text()+'''
func(s *APISimpleSolver) TrialGround() bool {
 m,e:=s.owner.command.Manager();if e!=nil {panic(e)};a,e:=solver.Assertions(s.solver);if e!=nil{panic(e)}
 var g groundInstanceSolver
 yes,e:=g.prove(s,m,a,2000000,1);if e!=nil{panic(e)};if e:=g.close();e!=nil{panic(e)};println("TRIAL ground",yes,len(a));return yes
}
''';save(path,s)
path=front/'smt/g3_solver.go';save(path,path.read_text()+'\nfunc(s *Z3Solver) TrialGround()bool{var yes bool;s.ctx.do(func(){yes=s.c.TrialGround()});return yes}\n')
path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text();k='res, err := s.decideZ3With(z3solver, finalCheck)';s=s.replace(k,'''if profileGround!="" && batch>=2 && batch<=5 && (index==36 || profileGround=="all" && (index==54 || index==55)) {old:=finalCheck;finalCheck=func()smt.Z3CheckResult{if z3solver.TrialGround(){return smt.Unsat};return old()}}
 '''+k);save(path,s+'\nvar profileGround=os.Getenv("EXPERIMENT")\n')
j=w/'liveground.json';j.write_text(json.dumps(ov));src=(old/'trial.py').read_text();s=src[src.index("sp.run(['go','build'"):].replace("w/'trials.csv'","w/'liveground.csv'").replace("w/'trial'","w/'liveground'").replace("[(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]","[(3,b,g,['','small','all']) for b,g in ((2,55),(3,37),(4,37),(5,37))]").replace("w/'whole.stat'","w/'liveground.stat'").replace('case round policy','case batch goal round policy').replace('o.writerow([nr,i,mode','o.writerow([nr,b,g,i,mode').replace('n,len(actions)','n,[(a.decode().strip()) for a in actions]').replace('range(5)','range(3)');exec(s)
