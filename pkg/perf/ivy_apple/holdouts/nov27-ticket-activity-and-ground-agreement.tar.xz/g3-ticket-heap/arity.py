from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'shape.py').read_text().replace('ad.NumArgs!=2','ad.NumArgs==0 || ad.NumArgs>4 || shapeMode=="binary" && ad.NumArgs!=2').replace("w/'shape.go'","w/'arity.go'").replace("w/'shape.json'","w/'arity.json'").replace('"w/\'shape\'"','"w/\'arity\'"')
exec(s)
