from pathlib import Path
import csv,subprocess as sp,os,sys,collections
w=Path(__file__).resolve().parent;ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');names=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
cpu=int(sys.argv[1]);indices=list(map(int,sys.argv[2:])) or list(range(cpu+1,229,6))
with (w/f'shape-counts-{cpu}.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['case','yes','no','status'])
 for i in indices:
  ref=rank/'compat'/str(i)/'1/native';name=names[i-1];r=sp.run([w/'shape',ex/name],cwd='/tmp/g3-ticket-splits',capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',SHARED_BIND='log',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1'),timeout=90)
  lines=r.stderr.splitlines(keepends=True);a=collections.Counter(l.strip().split()[-1] for l in lines if l.startswith(b'TRIAL pair'))
  o.writerow([i,a[b'true'],a[b'false'],'match' if (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith(b'TRIAL pair')))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()) else 'different']);f.flush()
