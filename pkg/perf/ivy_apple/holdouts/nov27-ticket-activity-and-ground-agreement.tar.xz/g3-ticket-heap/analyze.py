from pathlib import Path
w=Path(__file__).resolve().parent
def read(m):
 return [[tuple(map(float,x.split('/'))) for x in l.split()[2:]] for l in (w/(m+'.txt')).read_text().splitlines()]
for i,(g,n) in enumerate(zip(read('go'),read('native')),1):
 print('decision',i,'size',len(g),len(n),'first differing index',next((j for j,(a,b) in enumerate(zip(g,n)) if a!=b),None),'first IDs', [int(x[0]) for x in g[:4]], [int(x[0]) for x in n[:4]])
 ga={int(x): (i,a,v) for i,(x,a,v) in enumerate(g)};na={int(x): (i,a,v) for i,(x,a,v) in enumerate(n)}
 print('IDs in Go only',sorted(ga.keys()-na.keys()),'native only',sorted(na.keys()-ga.keys()))
 print('activities differ',[(x,ga[x][1],na[x][1]) for x in sorted(ga.keys()&na.keys()) if ga[x][1]!=na[x][1]][:12])
 print('130,169 index/activity/assignment',[(x,ga.get(x),na.get(x)) for x in [130,169]])
