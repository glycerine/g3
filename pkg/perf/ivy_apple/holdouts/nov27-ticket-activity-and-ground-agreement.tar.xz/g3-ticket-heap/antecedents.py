from pathlib import Path
import sys
w=Path(__file__).resolve().parent
s=(w/'measure.py').read_text()
i=s.index("if mode=='go':");j=s.index("j=w/(mode+'.json')")
t=s[i:j];a=t.index(" path=p/'smtcore");b=t.index(" dest=w/path.name")
t=t[:a]+''' path=p/'smtcore/smt_conflict_resolver.go';key='if marks[variable] || level <= userBaseLevel {';replace(path,path.read_text().replace(key,'if TrialActive{println("TRACE antecedent",int(literal),level,userBaseLevel,marks[variable])};'+key))
else:
 path=p.parent/'src/smt/smt_conflict_resolution.cpp';key='if (!m_ctx.is_marked(var) && lvl > m_ctx.get_base_level()) {';s=path.read_text().replace(key,'if(getenv("G3_WITNESS_STAGE"))fprintf(stderr,"WT antecedent %u %u %u %s\\\\n",antecedent.index(),lvl,m_ctx.get_base_level(),m_ctx.is_marked(var)?"true":"false");'+key,1)
'''+t[b:]
t=t.replace("w/'smt_case_split_queue.o'","w/'smt_conflict_resolution.o'").replace("w/'heap.a'","w/'conflict.a'")
s=s[:i]+t+s[j:];s=s.replace("'-o',w/mode","'-o',w/('ant-'+mode)").replace("sp.run([w/mode,ex/case]","sp.run([w/('ant-'+mode),ex/case]")
i=s.index('r=sp.run([w/');s=s[:i]+"for goal in (5,8,10,11,14,15):\n"+'\n'.join(' '+l for l in s[i:].splitlines());s=s.replace("GOAL='55'","GOAL=str(goal)").replace("w/(mode+'.txt')","w/(mode+'-ant-'+str(goal)+'.txt')").replace("if l.startswith(b'HEAP ')","if l.startswith((b'WT antecedent',b'TRACE antecedent',b'WT split',b'TRACE split'))")
exec(s)
