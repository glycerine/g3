from pathlib import Path
import sys,subprocess as sp,csv,itertools,collections
w=Path(__file__).resolve().parent;p=Path.cwd();sys.path.insert(0,'/tmp/g3-ticket-focus/reuse');from analyze import Terms,parse
def source(path):
 f=parse(path.read_text());a=[x[1] for x in f if x[0]=='assert'];return f,a
def leaves(x):
 if isinstance(x,str):yield x
 else:
  for v in x:yield from leaves(v)
def subst(x,d):return d.get(x,x) if isinstance(x,str) else [subst(i,d) for i in x]
def solve(path):
 a=[sp.check_output([exe,'-in'],input=path.read_text(),text=True,timeout=10).strip() for exe in (p.parent/'build/z3',w/'g3-cli')];assert a[0]==a[1] and a[0] in ('sat','unsat');return a[0]
d=w/'transfer';d.mkdir(exist_ok=True)
with (w/'transfer.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['batch','later_goal','fresh','bindings','validated','ground_answer'])
 for b in range(2,6):
  t=Terms();forms,(base,g)=source(w/'obligations'/f'3-{b}-37.smt2')
  sig={r[1]:r[-1] for r in forms if r[0]=='declare-fun' and not r[2] and r[-1]!='Bool'}
  fresh=sorted((set(leaves(g)) & sig.keys())-set(leaves(base)));assert fresh
  def fmt(x):return t.render(t.expand(x,{}))
  vs=['|abstract-goal-constant-'+str(i)+'|' for i in range(len(fresh))];assert not(set(vs)&set(leaves(forms)))
  q=['forall',[[v,sig[k]] for v,k in zip(vs,fresh)],['not',subst(g,dict(zip(fresh,vs)))]]
  control=d/f'{b}-valid.smt2';control.write_text('\n'.join([*(fmt(x) for x in forms if x[0].startswith('declare')),'(assert '+fmt(base)+')','(assert (not '+fmt(q)+'))','(check-sat)'])+'\n');assert solve(control)=='unsat'
  for n in (55,56):
   later,(base2,query)=source(w/'obligations'/f'3-{b}-{n}.smt2');assert t.expand(base,{})==t.expand(base2,{})
   laterSig={r[1]:r[-1] for r in later if r[0]=='declare-fun' and not r[2]};pool=sorted(set(leaves(query))&laterSig.keys());tuples=list(itertools.product(*[[a for a in pool if laterSig[a]==sig[k]] for k in fresh]));text=(w/'ground-inputs'/f'3-{b}-{n}-goal.smt2').read_text().split('(check-sat)')[0]
   out=d/f'{b}-{n}.smt2';out.write_text(text+'\n'.join('(assert (not '+fmt(subst(g,dict(zip(fresh,values))))+'))' for values in tuples)+'\n(check-sat)\n');o.writerow([b,n,' '.join(fresh),len(tuples),'unsat',solve(out)]);f.flush()
