from pathlib import Path
import csv,collections,statistics as st
w=Path(__file__).resolve().parent
for grouping,files,field in [(['case'],w.glob('panel*.csv'),'instructions'),(['batch','goal'],[w/'strategy-stages.csv'],'check_instructions')]:
 data=collections.defaultdict(lambda:collections.defaultdict(list))
 for f in files:
  for r in csv.DictReader(f.open()):
   assert r.get('status','match')=='match',r
   data[tuple(r[k] for k in grouping)][r['policy']].append(int(r[field]))
 for k,groups in data.items():
  print(*k,[(mode,len(rs),round((st.median(rs)/st.median(groups['off'])-1)*100,2)) for mode,rs in groups.items()])
