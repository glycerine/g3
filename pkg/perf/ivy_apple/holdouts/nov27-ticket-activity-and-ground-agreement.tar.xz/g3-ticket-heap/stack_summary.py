from pathlib import Path
import csv,collections
w=Path(__file__).resolve().parent
for mode in ['go','native']:
 tally=collections.Counter();leaf=collections.Counter();rounds=set();total=0
 for r in csv.DictReader((w/f'stacks-{mode}.csv').open()):
  weight=int(r['samples']);total+=weight;rounds.add(r['round']);frames=r['stack'].splitlines();leaf[frames[0]]+=weight
  for f in set(frames):tally[f]+=weight
 print(mode,total,'rounds',len(rounds))
 for key,ctr in [('inclusive',tally),('leaf',leaf)]:
  result=[(f,n) for f,n in ctr.most_common() if ('smtcore.' in f or 'pkg/ast' in f or 'smt::' in f or 'rewriter' in f or 'ast_manager' in f or 'runtime.' in f) and ('SMTKernel' not in f and 'solver::check' not in f and 'context::search' not in f and 'SMTSolver' not in f and 'context::setup_and_check' not in f)]
  print(key,[(f.split('/pkg/')[-1][:100],round(100*n/total,1)) for f,n in result[:20]])
