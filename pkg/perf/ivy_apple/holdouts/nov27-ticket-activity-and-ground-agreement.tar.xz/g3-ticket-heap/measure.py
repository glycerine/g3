from pathlib import Path
import csv,json,subprocess as sp,re,shlex,shutil,os,sys
p=Path.cwd(); w=Path(__file__).resolve().parent; old=Path('/tmp/g3-ticket-splits'); front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(); build=p.parent/'build'
mode=sys.argv[1]; ov=json.loads((old/('overlay.json' if mode=='go' else 'native.json')).read_text())
def replace(path,s):
 dest=w/(mode+'-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
if mode=='go':
 path=p/'smtcore/smt_activity_heap_queue.go';s=Path(ov['Replace'][str(path)]).read_text()
 s=s.replace('if TrialActive {trialPop++;','if TrialActive {trialPop++; if trialPop<=7 { vals,_:=h.AppendValues(nil);fmt.Fprintf(os.Stderr,"HEAP %d",trialPop);for _,x:=range vals {a,_:=q.state.Assignment(NewSMTLiteral(x,false));fmt.Fprintf(os.Stderr," %d/%g/%d",x,q.state.activity[x],a)};fmt.Fprintln(os.Stderr)};')
 replace(path,s)
else:
 path=p.parent/'src/smt/smt_case_split_queue.cpp';s=path.read_text().replace('while (!m_queue.empty()) {','''if(getenv("G3_WITNESS_STAGE")){static int step=0;if(++step<=7){fprintf(stderr,"HEAP %d",step);for(int x:m_queue)fprintf(stderr," %d/%g/%d",x,m_context.get_activity(x),(int)m_context.get_assignment(x));fprintf(stderr,"\\n");}}
            while (!m_queue.empty()) {''',1)
 dest=w/path.name;dest.write_text(s);flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l)
 inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 obj=w/'smt_case_split_queue.o';lib=w/'heap.a';sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dest],cwd=build,check=True)
 shutil.copyfile('/tmp/g3-queue-arrivals/liball.a',lib);sp.run(['ar','r',lib,obj],check=True)
 path=front/'smt/quantifier.go';replace(path,Path(ov['Replace'][str(path)]).read_text().replace('/tmp/g3-queue-arrivals/liball.a',str(lib)))
j=w/(mode+'.json');j.write_text(json.dumps(ov))
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off'+(',classic_z3' if mode=='native' else ''),'-pgo=off','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/mode,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');case=(rank/'compat.txt').read_text().splitlines()[2]
r=sp.run([w/mode,ex/case],cwd=w,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',BATCH='2',GOAL='55',G3_WITNESS_TRACE='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
lines=r.stderr.splitlines(keepends=True);ref=rank/'compat/3/1/native'
assert (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith((b'HEAP ',b'WT ',b'TRACE '))))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
(w/(mode+'.txt')).write_bytes(b''.join(l for l in lines if l.startswith(b'HEAP ')))
