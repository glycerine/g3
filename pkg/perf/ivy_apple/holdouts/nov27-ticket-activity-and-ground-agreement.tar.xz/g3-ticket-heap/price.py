from pathlib import Path
import json,os,csv,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;old=Path('/tmp/g3-ticket-splits');front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads((old/'meter.json').read_text())
def save(path,s):
 dest=w/('price-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
path=p/'smtcore/smt_activity_heap_queue.go';s=Path(ov['Replace'][str(path)]).read_text();k='if TrialActive {trialPop++;';s=s.replace(k,k+'''if trialPop==1 && (trialHistory=="score" || trialHistory=="pair") {for _,v:=range []int32{130,112}{if v==112 && trialHistory=="score"{break};if !h.Contains(v){panic("missing candidate")};q.state.activity[v]=2.49048;if err:=h.Decreased(v);err!=nil{panic(err)};println("TRIAL score",v)}};''')+'\nvar trialHistory=os.Getenv("EXPERIMENT")\n';save(path,s)
path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text();s=s.replace('if os.Getenv("MODE")=="ordinary"', 'if os.Getenv("MODE")=="ordinary" || batch==2 && (trialHistory=="fourteen" && index==13 || trialHistory=="earlier" && index<54)');save(path,s+'\nvar trialHistory=os.Getenv("EXPERIMENT")\n')
j=w/'price.json';j.write_text(json.dumps(ov));src=(old/'trial.py').read_text();s=src[src.index("sp.run(['go','build'"):].replace("w/'trials.csv'","w/'prices.csv'").replace("[(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]","[(3,2,55,['default','score','pair','fourteen','earlier'])]");exec(s)
