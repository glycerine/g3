from pathlib import Path
import csv,collections,statistics
w=Path(__file__).resolve().parent
counts=collections.defaultdict(dict)
for r in csv.DictReader((w/'stats.csv').open()):
 if r['round']=='0':counts[(r['engine'],r['batch'],r['goal'])][r['name']]=int(r['delta'])
rows=[r for r in csv.DictReader(Path('/tmp/g3-ticket-splits/final/stage-goals.csv').open()) if 'popl18' in r['case'] and r['phase']=='check']
fields='quant instantiations|mk bool var|mk clause|conflicts|decisions|propagations|binary propagations|added eqs|final checks'.split('|')
with (w/'rank.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['batch','goal','g3','z3','gap','class',*[e+' '+n for e in ('g3','z3') for n in fields]])
 for r in sorted(rows,key=lambda r:-int(r['difference'])):
  b,g=r['batch'],r['goal'];a=counts['g3',b,g];c=counts['z3',b,g];ns=[[v.get(n,0) for n in fields] for v in (a,c)]
  cl='one side only' if not a or not c else 'exact' if ns[0]==ns[1] else 'volume within 10%' if all(abs(x-y)<=.1*max(x,y) for x,y in zip(*ns)) else 'different'
  o.writerow([b,g,r['g3'],r['linked'],r['difference'],cl,*ns[0],*ns[1]])
d=collections.defaultdict(list)
for r in csv.DictReader((w/'rank.csv').open()):d[r['class']].append(int(r['gap']))
print({k:(len(v),round(sum(v)/1e6,2)) for k,v in d.items()})
