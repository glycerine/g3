from pathlib import Path
import re,csv,subprocess as sp
w=Path(__file__).resolve().parent
with (w/'ground-cores.csv').open('w') as f:
 o=csv.writer(f);o.writerow('query clauses core_size native g3'.split())
 for inp in sorted((w/'ground-inputs').glob('*-goal.smt2')):
  lines=inp.read_text().splitlines();decl=[l for l in lines if l.startswith('(declare')];rows=[l for l in lines if l.startswith('(assert ')];tracked=['(set-option :produce-unsat-cores true)',*decl,*['(assert (! '+l[len('(assert '):-1]+' :named lbl'+str(i)+'))' for i,l in enumerate(rows)],'(check-sat)','(get-unsat-core)']
  r=sp.run([Path.cwd().parent/'build/z3','smt.core.minimize=true','-in'],input='\n'.join(tracked),capture_output=True,text=True,timeout=20)
  if r.stdout.startswith('sat\n'):continue
  assert r.stdout.startswith('unsat\n('),r.stdout;ids=list(map(int,re.findall('lbl([0-9]+)',r.stdout)));assert ids
  sub='\n'.join([*decl,*[rows[i] for i in sorted(ids)],'(check-sat)'])+'\n';(w/'ground-inputs'/(inp.stem+'-core.smt2')).write_text(sub)
  answers=[sp.check_output([exe,'-in'],input=sub,text=True).strip() for exe in (Path.cwd().parent/'build/z3',w/'g3-cli')];assert answers==['unsat','unsat'];o.writerow([inp.stem,len(rows),len(ids),*answers])
