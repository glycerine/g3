from pathlib import Path
import csv,sys,subprocess as sp
w=Path(__file__).resolve().parent;sys.path.insert(0,'/tmp/g3-ticket-focus/reuse');from analyze import parse,Terms
with (w/'boolean.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['query','atoms','z3','g3'])
 for inp in sorted((w/'ground-inputs').glob('*-goal.smt2')):
  t=Terms();forms=parse(inp.read_text());sorts={r[1]:r[-1] for r in forms if r[0]=='declare-fun'};atoms={}
  def project(x):
   if isinstance(x,str):
    if x in ('true','false'):return x
    op=x
   else:
    op=x[0]
    if op in ('and','or','=>','not','xor','distinct','='):
     if op not in ('distinct','=') or boolean(x[1]):return '('+' '.join([op,*map(project,x[1:])])+')'
     if op=='=' and x[1]==x[2] and len(x)==3:return 'true'
     if op=='=' and len(x)==3:x=[op,*sorted(x[1:],key=repr)]
    if op=='ite' and boolean(x[2]):return '('+' '.join([op,*map(project,x[1:])])+')'
   return atoms.setdefault(t.expand(x,{}),'p'+str(len(atoms)))
  def boolean(x):
   if isinstance(x,str):return x in ('true','false') or sorts.get(x)=='Bool'
   return x[0] in ('and','or','=>','not','xor','distinct','=') or (boolean(x[2]) if x[0]=='ite' else sorts.get(x[0])=='Bool')
  rows=[project(r[1]) for r in forms if r[0]=='assert']
  text='\n'.join([*('(declare-const '+x+' Bool)' for x in atoms.values()),*('(assert '+r+')' for r in rows),'(check-sat)'])+'\n';target=w/'ground-inputs'/(inp.stem+'-bool.smt2');target.write_text(text)
  ans=[sp.check_output([exe,'-in'],input=text,text=True).strip() for exe in (Path.cwd().parent/'build/z3',w/'g3-cli')];assert ans[0]==ans[1] and ans[0] in ('sat','unsat');o.writerow([inp.stem,len(atoms),*ans])
