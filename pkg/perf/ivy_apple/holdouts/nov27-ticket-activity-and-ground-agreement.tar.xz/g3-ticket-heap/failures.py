from pathlib import Path
import json,subprocess as sp,os
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads((w/'liveground.json').read_text())
def save(path,s):
 dest=w/('fail-'+path.name);dest.write_text(s);ov['Replace'][str(path)]=str(dest)
path=p/'api/api_ground_instances.go';s=path.read_text().replace('if q == nil || err != nil {','if minRules==1 {if q==nil {println("PROBE no-projection",s.pool.Disabled(),steps)} else{println("PROBE projection",q.Work,q.Variables,len(q.Clauses))}};if q == nil || err != nil {').replace('if !complete {','if minRules==1{println("PROBE reduced",conflict,complete)};if !complete {');save(path,s)
path=p/'api/internal/order/ground_instance_pool.go';s=path.read_text().replace('if err == inapplicable || err == errBitLimit {','if minRules==1 {println("PROBE refusal",err.Error(),p.g.compiler.work)};if err == inapplicable || err == errBitLimit {');save(path,s)
path=p/'api/api_ground_instances.go';j=w/'failures.json';j.write_text(json.dumps(ov));src=Path('/tmp/g3-ticket-splits/shared.py').read_text();exec(src[src.index("sp.run(['go','build'"):].replace("w/'shared'","w/'failures'"))
rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples');r=sp.run([w/'failures',ex/(rank/'compat.txt').read_text().splitlines()[2]],env=dict(os.environ,EXPERIMENT='all',XTRACE_OFF='1',GOMAXPROCS='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,check=True);lines=r.stderr.splitlines(keepends=True);ref=rank/'compat/3/1/native';assert (r.stdout,b''.join(l for l in lines if not l.startswith((b'PROBE ',b'TRIAL '))))==((ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
(w/'failures.txt').write_bytes(b''.join(l for l in lines if l.startswith((b'PROBE ',b'TRIAL '))))
