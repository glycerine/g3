from pathlib import Path
import json,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads(Path('/tmp/g3-arm-pass/release.json').read_text());path=p/'api/api_predicate_agreement.go';s=path.read_text().replace('import (','import ("os";',1)
k='for i := range arity {';s=s.replace(k,'''var seen [4]ast.ASTHandle
 distinct:=0
 '''+k);k='h, err := m.NodeHeader(left)';s=s.replace(k,'''st,e:=m.GetSort(left);if e!=nil{return false};found:=false;for _,x:=range seen[:distinct]{if st==x{found=true}};if !found{seen[distinct]=st;distinct++}
 '''+k)
k='return true\n}';s=s.replace(k,'''guard,_:=m.GetArg(root.term,0);gh,_:=m.NodeHeader(guard)
 atomic:=gh.Kind==ast.ASTApp && gh.Family==ast.NullFamilyID && gh.NumArgs==0
 if affinity=="off"{return false}
 if affinity=="sort"{return distinct==int(arity)}
 if affinity=="multi"{return distinct>=2}
 if affinity=="atomic"{return atomic}
 if affinity=="simple"{return atomic && distinct>=2}
 return true
}''');s=s.replace('err = errors.Join(err, private.close())','if affinity=="log"{println("TRIAL pair",proved)};err = errors.Join(err, private.close())')+'\nvar affinity=os.Getenv("SHARED_BIND")\n'
b=w/'affinity.go';b.write_text(s);ov['Replace'][str(path)]=str(b);j=w/'affinity.json';j.write_text(json.dumps(ov));src=Path('/tmp/g3-ticket-splits/shared.py').read_text();exec(src[src.index("sp.run(['go','build'"):].replace("w/'shared'","w/'affinity'"))
