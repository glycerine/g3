from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'coverage.py').read_text().replace('(trialPolicy=="tuple" || trialPolicy=="wide")','trialPolicy!="standard"').replace('trialPolicy!="congruence" && trialPolicy!="wide"','trialPolicy=="standard"')
s=s.replace("save(path,s)\npath=p/'api/api_ground_instances.go'",'''s=s.replace('if e := g.compiler.charge(1 + len(a)); e != nil {', 'if e := g.compiler.charge(1 + len(a)); e != nil {',1)
k='other := g.arguments[ot.start : ot.start+ot.count]';s=s.replace(k,k+"""\n if p.trialWide && len(a)>1 && trialPolicy!="wide" && trialPolicy!="standard"{matched:=0;for j,x:=range a{if x==other[j]{matched++}};if trialPolicy=="one" && matched+1<len(a) || trialPolicy=="prefix" && a[0]!=other[0] || trialPolicy=="suffix" && a[len(a)-1]!=other[len(a)-1]{continue}}
""");save(path,s)
path=p/'api/api_ground_instances.go' ''').replace("w/'coverage.csv'","w/'congruence.csv'").replace('"w/\'coverage\'"','"w/\'congruence\'"').replace("'off','standard','tuple','congruence','depth','wide'","'off','standard','one','prefix','suffix','wide'")
exec(s)
