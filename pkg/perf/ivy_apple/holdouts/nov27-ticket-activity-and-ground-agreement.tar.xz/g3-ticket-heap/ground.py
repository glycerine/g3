from pathlib import Path
import functools,collections,itertools,csv,sys,subprocess,os
w=Path(__file__).resolve().parent;sys.path.insert(0,'/tmp/g3-ticket-focus/reuse');from analyze import Terms,parse
with (w/'ground.csv').open('w') as out:
 o=csv.writer(out);o.writerow('query seed base universals instances goal_constants projected_bytes native g3'.split())
 for f in sorted((w/'obligations').glob('*.smt2')):
  t=Terms();forms=parse(f.read_text());decl=[x for x in forms if x[0].startswith('declare-')];sig={r[1]:r[-1] for r in decl if r[0]=='declare-fun' and not r[2] and r[-1]!='Bool'};base,goal=[list(t.conjuncts(t.expand(x[1],{}))) for x in forms if x[0]=='assert']
  def head(x):
   v=t.terms[x];return t.terms[v[0]] if isinstance(v,tuple) and v else None
  def visit(x):
   yield x
   if isinstance(t.terms[x],tuple):
    for y in t.terms[x]:yield from visit(y)
  cs=collections.defaultdict(list)
  for x in dict.fromkeys(z for g in goal for z in visit(g)):
   if t.terms[x] in sig:cs[sig[t.terms[x]]].append(x)
  for mode in ('ground','goal','one-extra'):
   pools={k:list(v) for k,v in cs.items()}
   if mode=='one-extra':
    for n,sort in sig.items():
     xs=pools.setdefault(sort,[])
     if len(xs)==len(cs.get(sort,[])) and t.node(n) not in xs:xs.append(t.node(n))
   keep=[];nu=ni=0
   for x in base:
    if head(x)!='forall':
     if not any(head(y) in ('forall','exists') for y in visit(x)):keep.append(x)
     continue
    _,decls,body=t.terms[x]
    if mode=='ground' or any(head(y) in ('forall','exists') for y in visit(body)):continue
    bind=[t.terms[v] for v in t.terms[decls]];sets=[pools.get(t.terms[sort],[]) for _,sort in bind];nu+=1
    for values in itertools.product(*sets):
     env=dict(zip([name for name,_ in bind],values))
     @functools.lru_cache(None)
     def sub(y):
      v=t.terms[y];return env.get(y,y) if isinstance(v,str) else t.node(tuple(sub(z) for z in v))
     keep.append(sub(body));ni+=1
   text='\n'.join([*(t.render(t.expand(d,{})) for d in decl),*('(assert '+t.render(x)+')' for x in dict.fromkeys(keep+goal)),'(check-sat)'])+'\n'
   dest=w/'ground-inputs';dest.mkdir(exist_ok=True);(dest/(f.stem+'-'+mode+'.smt2')).write_text(text)
   answers=[]
   for exe in (Path.cwd().parent/'build/z3',w/'g3-cli'):
    r=subprocess.run([exe,'-in'],input=text,text=True,capture_output=True,timeout=15);ans=r.stdout.strip();assert r.returncode==0 and not r.stderr and ans in ('sat','unsat','unknown'),(f,mode,r.stdout[:300],r.stderr[:300]);answers.append(ans)
   o.writerow([f.stem,mode,len(base),nu,ni,sum(map(len,cs.values())),len(text),*answers]);out.flush()
