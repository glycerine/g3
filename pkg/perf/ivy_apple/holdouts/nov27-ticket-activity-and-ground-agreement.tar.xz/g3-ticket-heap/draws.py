from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'measure.py').read_text();a=s.index(" path=p/'smtcore");b=s.index(" dest=w/path.name")
s=s[:a]+''' path=p/'smtcore/smt_case_split_queue.go';key='if int(q.state.random.Next()) >= threshold';replace(path,path.read_text().replace(key,'roll:=int(q.state.random.Next());if TrialActive{println("TRACE draw",roll,threshold,len(q.state.boolExpr))}; if roll >= threshold'))
else:
 path=p.parent/'src/smt/smt_case_split_queue.cpp';key='if (m_context.get_random_value() < static_cast<int>(m_params.m_random_var_freq * random_gen::max_value())) {';s=path.read_text().replace(key,'int roll=m_context.get_random_value();if(getenv("G3_WITNESS_STAGE"))fprintf(stderr,"WT draw %d %d %u\\\\n",roll,static_cast<int>(m_params.m_random_var_freq*random_gen::max_value()),m_context.get_num_b_internalized());if (roll < static_cast<int>(m_params.m_random_var_freq * random_gen::max_value())) {',1)
'''+s[b:]
s=s.replace("w/'heap.a'","w/'draw.a'").replace("'-o',w/mode","'-o',w/('draw-'+mode)").replace("sp.run([w/mode,ex/case]","sp.run([w/('draw-'+mode),ex/case]")
i=s.index('r=sp.run([w/');s=s[:i]+"for goal in range(1,16):\n"+'\n'.join(' '+l for l in s[i:].splitlines());s=s.replace("GOAL='55'","GOAL=str(goal)").replace("w/(mode+'.txt')","w/(mode+'-draw-'+str(goal)+'.txt')").replace("if l.startswith(b'HEAP ')","if l.startswith((b'WT draw',b'TRACE draw',b'WT split',b'TRACE split'))")
exec(s)
