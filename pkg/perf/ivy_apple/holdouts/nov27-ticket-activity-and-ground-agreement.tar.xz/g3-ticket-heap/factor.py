from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'price.py').read_text();a=s.index("s=s.replace('if os.Getenv");b=s.index(";save(path",a)
s=s[:a]+'''s=s.replace('if os.Getenv("MODE")=="ordinary"', 'if batch==2 && index==13 && trialHistory=="stopgroups"{groupEqualities=false}; if batch==2 && index==13 && trialHistory=="justcheck"{finalCheck=z3solver.Check};if os.Getenv("MODE")=="ordinary"');s=s.replace('if groupEqualities && index >= nextGroup','if !(trialHistory=="skipgroup" && batch==2 && index==13) && groupEqualities && index >= nextGroup')'''+s[b:]
s=s.replace("w/'prices.csv'","w/'factors.csv'").replace("'default','score','pair','fourteen','earlier'","'default','justcheck','stopgroups','skipgroup'")
exec(s)
