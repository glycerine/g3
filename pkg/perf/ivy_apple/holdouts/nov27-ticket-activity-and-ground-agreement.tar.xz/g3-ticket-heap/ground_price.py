from pathlib import Path
import os,csv,subprocess as sp,sys
w=Path(__file__).resolve().parent;p=Path.cwd();engine=sys.argv[1];exe=w/'g3-cli' if engine=='go' else p.parent/'build/z3';cpu='28' if engine=='go' else '29';perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/f'ground-price-{engine}.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['query','mode','round','instructions','answer'])
 for src in sorted((w/'obligations').glob('*.smt2')):
  for i in range(3):
   modes=['full','goal','goal-bool','goal-core'];modes=modes[i:]+modes[:i]
   for mode in modes:
    inp=src if mode=='full' else w/'ground-inputs'/(src.stem+'-'+mode+'.smt2')
    if not inp.exists():continue
    text=inp.read_text().split('(check-sat)')[0]+'(check-sat)\n';stat=w/f'ground-price-{engine}.stat'
    r=sp.run(['taskset','-c',cpu,perf,'stat','-x,','-o',stat,'-e','instructions:u','--',exe,'smt.macro_finder=true','-in'],input=('(reset)\n'.join([text]*5)),text=True,capture_output=True,timeout=60,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
    lines=r.stdout.strip().splitlines();assert r.returncode==0 and len(lines)==5 and len(set(lines))==1 and lines[0] in ('sat','unsat') and not r.stderr,(engine,src,mode,r.stdout[:300],r.stderr[:300]);ins,=[int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100];o.writerow([src.stem,mode,i,ins/5,lines[0]]);f.flush()
