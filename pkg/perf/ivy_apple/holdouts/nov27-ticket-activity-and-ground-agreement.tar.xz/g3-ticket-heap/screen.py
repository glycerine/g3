from pathlib import Path
import os,csv,concurrent.futures,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();rank=Path('/tmp/g3-reduction-rows');ex=Path('/home/jaten/ivy/ivy-lang-examples')
cases=(rank/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((rank/'ranking.csv').open())}
stem=os.getenv('STEM','screen');policy=os.getenv('POLICY','prefix');exe=os.getenv('EXE','shared')
def run(worker):
 with (w/f'{stem}-{worker}.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case policy status instructions'.split())
  for idx in range(worker,len(cases),6):
   n=cases[idx];d=rank/'compat'/str(idx+1)/'1/native';expect=codes[n],(d/'stdout').read_bytes(),(d/'stderr').read_bytes()
   for mode in (['off',policy] if (idx//6)%2==0 else [policy,'off']):
    stat=w/f'{stem}-{worker}.stat'
    try:r=sp.run(['taskset','-c',str(1+2*worker),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/exe,ex/n],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),SHARED_BIND='' if mode=='off' else mode),capture_output=True,timeout=100)
    except sp.TimeoutExpired:o.writerow([idx+1,mode,'timeout',0]);f.flush();continue
    val,=[int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100]
    o.writerow([idx+1,mode,'match' if (r.returncode,r.stdout,r.stderr)==expect else 'different',val]);f.flush()
with concurrent.futures.ThreadPoolExecutor(6) as pool:list(pool.map(run,range(6)))
