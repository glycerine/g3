from pathlib import Path
import os,json,csv,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();old=Path('/tmp/g3-ticket-splits');ov=json.loads((old/'meter.json').read_text())
path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text();k='if index < provenThrough {';assert s.count(k)==1
s=s.replace(k,'''if profileCeiling!="" && batch>=2 && batch<=5 {
 g:=index+1
 prop:=g==37 && batch>=3
 euf:=g==37 || batch==2 && (g==55 || g==56) || batch==3 && g==56 || batch==5 && g==55
 if profileCeiling=="boolean" && prop || profileCeiling=="ground" && euf {
 println("TRIAL bound",batch,g);overallResult=smt.Unsat;fc.Unsat();continue
 }}
 '''+k);dest=w/'ceiling-bridge.go.txt';dest.write_text(s+'\nvar profileCeiling=os.Getenv("EXPERIMENT")\n');ov['Replace'][str(path)]=str(dest)
j=w/'ceiling.json';j.write_text(json.dumps(ov));src=(old/'trial.py').read_text();s=src[src.index("sp.run(['go','build'"):].replace("w/'trials.csv'","w/'ceiling.csv'").replace("w/'trial'","w/'ceiling'").replace("[(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]","[(3,7,1,['default','boolean','ground'])]").replace("w/'whole.stat'","w/'ceiling.stat'");exec(s)
