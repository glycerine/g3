from pathlib import Path
import csv,os,json,subprocess as sp,re,collections,sys
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();mode=sys.argv[1]
ov=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text());path=front/'z3bridge_solver_model.go';s=Path(ov['Replace'][str(path)]).read_text().replace('s.showVCsBase(clauses)','s.showVCsBase(clauses);profileBatch++; batch:=profileBatch',1)
k='res, err := s.decideZ3With(z3solver, finalCheck)';assert s.count(k)==1;s=s.replace(k,'profile:=batch==7 && index==0;if profile {profileSignal("enable")};'+k+';if profile{profileSignal("disable")}')
s+='''
var profileBatch int
func profileSignal(command string){ctl,e:=os.OpenFile(os.Getenv("PROFILE_CTL"),os.O_WRONLY,0);if e!=nil{panic(e)};ack,e:=os.OpenFile(os.Getenv("PROFILE_ACK"),os.O_RDONLY,0);if e!=nil{panic(e)};_,e=ctl.WriteString(command+"\\n");if e!=nil{panic(e)};var buf [32]byte;n,e:=ack.Read(buf[:]);if e!=nil || n<3 || string(buf[:3])!="ack"{panic("perf ack")};ctl.Close();ack.Close()}
'''
dest=w/('profile-'+mode+'-bridge.go.txt');dest.write_text(s);ov['Replace'][str(path)]=str(dest);j=w/('profile-'+mode+'.json');j.write_text(json.dumps(ov));exe=w/('profile-'+mode)
sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off'+(',classic_z3' if mode=='native' else ''),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
ctl=w/('ctl-'+mode);ack=w/('ack-'+mode)
for f in (ctl,ack):
 if not f.exists():os.mkfifo(f)
keepers=[os.open(f,os.O_RDWR|os.O_NONBLOCK) for f in (ctl,ack)]
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf';ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');ref=rank/'compat/3/1/native'
env=dict(os.environ,PROFILE_CTL=str(ctl),PROFILE_ACK=str(ack),GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),DEBUGINFOD_URLS='')
with (w/('stacks-'+mode+'.csv')).open('w') as f:
 o=csv.writer(f);o.writerow(['round','period','samples','stack'])
 for i in range(16):
  period=900001+17*i;data=w/('record-'+mode+'.data')
  r=sp.run(['taskset','-c','25' if mode=='go' else '26',perf,'record','--control=fifo:'+str(ctl)+','+str(ack),'-D','-1','-q','-B','-N','-e','instructions:u','-c',str(period),'--call-graph','fp,48' if mode=='go' else 'dwarf,8192','-o',data,exe,ex/(rank/'compat.txt').read_text().splitlines()[2]],env=env,cwd=w,capture_output=True,timeout=40)
  err=b''.join(l for l in r.stderr.splitlines(keepends=True) if l.strip() not in (b'Events enabled',b'Events disabled'))
  assert (r.returncode,r.stdout,err)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),r.stderr[-500:]
  raw=sp.check_output([perf,'script','--no-inline','-F','tid,event,ip,sym','-i',data],env=env,text=True);counts=collections.Counter()
  for event in raw.strip().split('\n\n'):
   lines=event.splitlines()
   if len(lines)>1:counts['\n'.join(re.sub(r'^\s*[0-9a-f]+\s+','',x).strip() for x in lines[1:])]+=1
  assert sum(counts.values())>25
  for stack,n in counts.items():o.writerow([i,period,n,stack])
  f.flush()
