from pathlib import Path
import json,os,csv,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();old=Path('/tmp/g3-ticket-splits')
ov=json.loads((w/'strategy.json').read_text());ov['Replace'].update(json.loads((old/'meter.json').read_text())['Replace'])
j=w/'strat-meter.json';j.write_text(json.dumps(ov));src=(old/'trial.py').read_text()
s=src[src.index("sp.run(['go','build'"):].replace("w/'trials.csv'","w/'strategy-stages.csv'").replace("w/'trial'","w/'strat-meter'").replace("[(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]","[(3,b,g,['off','none','reset','separate','separate-reset']) for b,g in [(2,55),(7,1),(5,55),(2,56)]]").replace('case round policy','case batch goal round policy').replace('o.writerow([nr,i,mode','o.writerow([nr,b,g,i,mode').replace('EXPERIMENT=mode','SHARED_BIND=mode').replace('range(5)','range(3)').replace("w/'whole.stat'","w/'strat-stage.stat'");exec(s)
