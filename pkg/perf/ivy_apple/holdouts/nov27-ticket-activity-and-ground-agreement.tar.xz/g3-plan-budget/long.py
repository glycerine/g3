from pathlib import Path
import subprocess,sys,os,csv,time,concurrent.futures
w=Path(__file__).resolve().parent;p=Path.cwd();front=p/'build/.boolean-enode-cost/apple-source/goivy'
bin=Path('/wd_black1tb/home/jaten/tmp/g3-nov27-private-budget');bin.mkdir(exist_ok=True)
flags=['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')]
for mode in ['base','256','512']:
 args=[] if mode=='base' else ['-overlay',w/mode/'trial.json']
 subprocess.run([*flags,*args,'-o',bin/mode,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples')
def run(pair):
 name,cpu=pair;apple=name!='raft_no_assume';d=w/name;d.mkdir(exist_ok=True)
 ref=((p/'build/.boolean-enode-cost/apple-final') if apple else Path('/tmp/g3-nov22b/end-panel-final/large-a'))/name/'1/native'
 spec=ex/('doc/examples/apple/ord_live.ivy' if apple else 'examples/raft/raft_no_assume.ivy')
 with (d/'long.csv').open('w') as f:
  out=csv.writer(f);out.writerow(['case','round','mode','status','instructions','ms'])
  modes=['base','256','512']
  for i in range(3):
   for m in modes[i:]+modes[:i]:
    exe=bin/m if apple else (Path('/tmp/g3-live-frame-cost/recheck/baseline') if m=='base' else w/m/'release')
    stat=d/'stat';start=time.monotonic()
    r=subprocess.run(['taskset','-c',str(cpu),'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,*(['isolate='+name] if apple else []),spec],cwd=d,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),timeout=180)
    ms=(time.monotonic()-start)*1000;assert (r.returncode,r.stdout,r.stderr)==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(name,m,r.stderr[-250:])
    ins=next(v[0] for v in csv.reader(stat.open()) if len(v)>4 and v[2]=='instructions:u' and float(v[4])==100);out.writerow([name,i,m,'match',ins,round(ms,3)]);f.flush()
with concurrent.futures.ThreadPoolExecutor(3) as pool:list(pool.map(run,[('raft_no_assume',2),('rfn2',4),('dramc_nb2',16)]))
