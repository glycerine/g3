from pathlib import Path
import re,csv,collections,itertools
w=Path(__file__).resolve().parent
tokens=re.compile(r';[^\n]*|\(|\)|\|[^|]*\||"(?:[^"]|"")*"|[^\s();]+')
def parse(s):
 stack=[[]]
 for tok in tokens.findall(s):
  if tok[0]==';':continue
  if tok=='(':stack.append([])
  elif tok==')':v=stack.pop();stack[-1].append(v)
  else:stack[-1].append(tok)
 assert len(stack)==1
 return stack[0]
class Terms:
 def __init__(self):self.ids={};self.terms=[]
 def node(self,t):
  if t not in self.ids:self.ids[t]=len(self.terms); self.terms.append(t)
  return self.ids[t]
 def expand(self,x,env):
  if isinstance(x,str):return env[x] if x in env else self.node(x)
  if x and x[0]=='let':
   names={k:self.expand(v,env) for k,v in x[1]};return self.expand(x[2],{**env,**names})
  if x and x[0] in ('forall','exists'):assert not any(n in env for n,_ in x[1])
  return self.node(tuple(self.expand(z,env) for z in x))
 def conjuncts(self,i):
  v=self.terms[i]
  if isinstance(v,tuple) and v and self.terms[v[0]]=='and':
   for x in v[1:]:yield from self.conjuncts(x)
  else:yield i
 def render(self,i):
  v=self.terms[i]
  return v if isinstance(v,str) else '('+' '.join(self.render(x) for x in v)+')'
def data(nr):
 t=Terms();history=[];decl={};groups=collections.defaultdict(list)
 for f in sorted((w/str(nr)).glob('*.smt2'),key=lambda f:tuple(map(int,f.stem.split('-')[1:]))):
  forms=parse(f.read_text());a=[];signature=collections.defaultdict(set)
  for x in forms:
   if x[0]=='assert':a.append(frozenset(t.conjuncts(t.expand(x[1],{}))))
   elif x[0] in ['declare-sort','declare-fun','declare-const']:
    v=t.expand(x,{});signature[x[1]].add(v)
   else:assert x[0] in ('check-sat','get-info'),x[0]
  if len(a)!=2:
   assert nr==8,(f,len(a));continue
  b,g=map(int,f.stem.split('-')[1:]);decl[len(history)]=signature;history.append((b,g,*a));groups[a[1]].append(len(history)-1)
 return t,history,decl,groups
def compatible(left,right):return all(left[k]==right[k] for k in left.keys() & right.keys())
if __name__=='__main__':
 with (w/'coverage.csv').open('w') as f:
  o=csv.writer(f);o.writerow('input batch goal previous_same_goal previous_contained_full distinct_intersections'.split())
  for nr in [3,6,8]:
   t,h,decl,groups=data(nr)
   n=0
   for i,(b,g,base,goal) in enumerate(h):
    prev=[j for j in groups[goal] if j<i and compatible(decl[j],decl[i])];intersections={h[j][2]&base for j in prev};contained=[j for j in prev if h[j][2]<=base];o.writerow([nr,b,g,len(prev),len(contained),len(intersections)])
    n+=len(intersections)
   print(nr,len(h),len(groups),sum(len(v)-1 for v in groups.values()),n)
