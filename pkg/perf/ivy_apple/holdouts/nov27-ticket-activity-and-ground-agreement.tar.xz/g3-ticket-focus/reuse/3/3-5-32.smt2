(declare-sort ticket_protocol.ticket)
(declare-sort ticket_protocol.thread)
(declare-fun ticket_protocol.request_flag () Bool)
(declare-fun __m_ticket_protocol.l2s.w_request_flag () Bool)
(declare-fun ticket_protocol.l2s.w_request_flag () Bool)
(declare-fun |__new_fml:t_a| () ticket_protocol.thread)
(declare-fun __m_ticket_protocol.l2s.w_last_scheduled
             (ticket_protocol.thread)
             Bool)
(declare-fun ticket_protocol.l2s.w_last_scheduled (ticket_protocol.thread) Bool)
(declare-fun __m_ticket_protocol.l2s.d_ticket_b (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun ticket_protocol.l2s.d_ticket (ticket_protocol.ticket) Bool)
(declare-fun __m_ticket_protocol.l2s.d_ticket_a (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(declare-fun __m_ticket_protocol.l2s.d_ticket (ticket_protocol.ticket) Bool)
(declare-fun |__new_fml:k2_a| () ticket_protocol.ticket)
(declare-fun __ticket_protocol.l2s.d_ticket (ticket_protocol.ticket) Bool)
(declare-fun |__new_fml:k1_a| () ticket_protocol.ticket)
(declare-fun __ticket_protocol.l2s.d_thread (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.d_thread (ticket_protocol.thread) Bool)
(declare-fun |__fml:k2| () ticket_protocol.ticket)
(declare-fun |__fml:k1| () ticket_protocol.ticket)
(declare-fun |__fml:t| () ticket_protocol.thread)
(declare-fun __ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun __ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun |__fml:y| () ticket_protocol.ticket)
(declare-fun |__new_loc:0| () ticket_protocol.ticket)
(declare-fun |__new_fml:x| () ticket_protocol.ticket)
(declare-fun __ticket_protocol.l2s.w_request_flag () Bool)
(declare-fun __ticket_protocol.l2s.w_last_scheduled
             (ticket_protocol.thread)
             Bool)
(declare-fun __ticket_protocol.l2s.waiting () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ticket_protocol.l2s.frozen () Bool)
(declare-fun __ts0__ts0_b_a () Bool)
(declare-fun ticket_protocol.l2s.saved () Bool)
(declare-fun __ts0__ts0__ts0_a_a () Bool)
(declare-fun __ticket_protocol.l2s.s_m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.l2s.s_m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun __ticket_protocol.l2s.s_next_ticket () ticket_protocol.ticket)
(declare-fun ticket_protocol.l2s.s_next_ticket () ticket_protocol.ticket)
(declare-fun __ticket_protocol.l2s.s_service () ticket_protocol.ticket)
(declare-fun __ticket_protocol.service () ticket_protocol.ticket)
(declare-fun ticket_protocol.l2s.s_service () ticket_protocol.ticket)
(declare-fun __ticket_protocol.l2s.s_pc3 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.s_pc3 (ticket_protocol.thread) Bool)
(declare-fun __ticket_protocol.l2s.s_pc2 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.s_pc2 (ticket_protocol.thread) Bool)
(declare-fun __ticket_protocol.l2s.s_pc1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.s_pc1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.frozen () Bool)
(declare-fun __ts0__ts0_a_a () Bool)
(declare-fun __ticket_protocol.l2s.a_ticket (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.l2s.a_ticket (ticket_protocol.ticket) Bool)
(declare-fun __ticket_protocol.l2s.a_thread (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.a_thread (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.l2s.waiting () Bool)
(declare-fun ticket_protocol.le
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.zero () ticket_protocol.ticket)
(declare-fun __ticket_protocol.l2s.saved () Bool)
(declare-fun ticket_protocol.t0 () ticket_protocol.thread)
(declare-fun @T2 () ticket_protocol.thread)
(declare-fun @T1 () ticket_protocol.thread)
(assert (let ((a!1 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (or (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                 (not (ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
      (a!2 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (or (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                 (not (__ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!3 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (or (not (ticket_protocol.pc2 |T:ticket_protocol.thread|))
                 (not (__ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!4 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|K2:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |K1:ticket_protocol.ticket|)
                      (ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |K2:ticket_protocol.ticket|))
                 (= |K1:ticket_protocol.ticket| |K2:ticket_protocol.ticket|))))
      (a!5 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                    (|T2:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (__ticket_protocol.pc3 |T1:ticket_protocol.thread|)
                      (__ticket_protocol.pc3 |T2:ticket_protocol.thread|))
                 (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!6 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (not (= ticket_protocol.next_ticket ticket_protocol.zero))
                      (ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|))
                 (not (ticket_protocol.le
                        ticket_protocol.next_ticket
                        |M:ticket_protocol.ticket|)))))
      (a!7 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (or (ticket_protocol.pc2 |T:ticket_protocol.thread|)
                     (__ticket_protocol.pc3 |T:ticket_protocol.thread|))
                 (not (= ticket_protocol.next_ticket ticket_protocol.zero)))))
      (a!8 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T1:ticket_protocol.thread| ticket_protocol.thread)
                    (|T2:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (ticket_protocol.m
                        |T1:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|)
                      (ticket_protocol.m
                        |T2:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|)
                      (not (= |M:ticket_protocol.ticket| ticket_protocol.zero)))
                 (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!9 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (ticket_protocol.pc2 |T:ticket_protocol.thread|)
                      (ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|))
                 (ticket_protocol.le
                   __ticket_protocol.service
                   |M:ticket_protocol.ticket|))))
      (a!10 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (not (and (not (__ticket_protocol.pc1 |T1:ticket_protocol.thread|))
                        (not (__ticket_protocol.pc1 |T2:ticket_protocol.thread|))
                        (ticket_protocol.m
                          |T1:ticket_protocol.thread|
                          ticket_protocol.zero)
                        (ticket_protocol.m
                          |T2:ticket_protocol.thread|
                          ticket_protocol.zero)
                        (not (= |T1:ticket_protocol.thread|
                                |T2:ticket_protocol.thread|))))))
      (a!11 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K2:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (=> (and (__ticket_protocol.l2s.s_m
                             |T:ticket_protocol.thread|
                             |K1:ticket_protocol.ticket|)
                           (__ticket_protocol.l2s.s_m
                             |T:ticket_protocol.thread|
                             |K2:ticket_protocol.ticket|))
                      (= |K1:ticket_protocol.ticket|
                         |K2:ticket_protocol.ticket|)))))
      (a!12 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (or (__ticket_protocol.l2s.s_pc1 |T:ticket_protocol.thread|)
                      (__ticket_protocol.l2s.s_pc2 |T:ticket_protocol.thread|)
                      (__ticket_protocol.l2s.s_pc3 |T:ticket_protocol.thread|)))))
      (a!13 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (or (not (__ticket_protocol.l2s.s_pc1
                             |T:ticket_protocol.thread|))
                      (not (__ticket_protocol.l2s.s_pc2
                             |T:ticket_protocol.thread|))))))
      (a!14 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (or (not (__ticket_protocol.l2s.s_pc1
                             |T:ticket_protocol.thread|))
                      (not (__ticket_protocol.l2s.s_pc3
                             |T:ticket_protocol.thread|))))))
      (a!15 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (or (not (__ticket_protocol.l2s.s_pc2
                             |T:ticket_protocol.thread|))
                      (not (__ticket_protocol.l2s.s_pc3
                             |T:ticket_protocol.thread|))))))
      (a!16 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (=> (and (__ticket_protocol.l2s.s_pc3
                             |T1:ticket_protocol.thread|)
                           (__ticket_protocol.l2s.s_pc3
                             |T2:ticket_protocol.thread|))
                      (= |T1:ticket_protocol.thread|
                         |T2:ticket_protocol.thread|)))))
      (a!17 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (=> (= __ticket_protocol.l2s.s_next_ticket
                         ticket_protocol.zero)
                      (__ticket_protocol.l2s.s_m
                        |T:ticket_protocol.thread|
                        ticket_protocol.zero)))))
      (a!18 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (=> (or (__ticket_protocol.l2s.s_pc2
                            |T:ticket_protocol.thread|)
                          (__ticket_protocol.l2s.s_pc3
                            |T:ticket_protocol.thread|))
                      (not (= __ticket_protocol.l2s.s_next_ticket
                              ticket_protocol.zero))))))
      (a!19 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (=> (and (__ticket_protocol.l2s.s_pc2
                             |T:ticket_protocol.thread|)
                           (__ticket_protocol.l2s.s_m
                             |T:ticket_protocol.thread|
                             |M:ticket_protocol.ticket|))
                      (ticket_protocol.le
                        __ticket_protocol.l2s.s_service
                        |M:ticket_protocol.ticket|)))))
      (a!20 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> __ticket_protocol.l2s.saved
                  (=> (__ticket_protocol.l2s.s_pc3 |T:ticket_protocol.thread|)
                      (__ticket_protocol.l2s.s_m
                        |T:ticket_protocol.thread|
                        __ticket_protocol.l2s.s_service)))))
      (a!21 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> __ticket_protocol.l2s.saved
                  (= (__ticket_protocol.l2s.s_m
                       ticket_protocol.t0
                       |K:ticket_protocol.ticket|)
                     (ticket_protocol.m
                       ticket_protocol.t0
                       |K:ticket_protocol.ticket|)))))
      (a!22 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
                       (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|)
                       (not (= |M:ticket_protocol.ticket| ticket_protocol.zero)))
                  (not (ticket_protocol.le
                         __ticket_protocol.service
                         |M:ticket_protocol.ticket|)))))
      (a!23 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (ticket_protocol.m
                                  |T:ticket_protocol.thread|
                                  |K:ticket_protocol.ticket|)
                                (not (__ticket_protocol.pc1
                                       |T:ticket_protocol.thread|))))))
                (=> (and (not (ticket_protocol.le
                                ticket_protocol.next_ticket
                                |K:ticket_protocol.ticket|))
                         (ticket_protocol.le
                           __ticket_protocol.service
                           |K:ticket_protocol.ticket|))
                    a!1))))
      (a!24 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (__ticket_protocol.l2s.s_m
                                  |T:ticket_protocol.thread|
                                  |K:ticket_protocol.ticket|)
                                (not (__ticket_protocol.l2s.s_pc1
                                       |T:ticket_protocol.thread|))))))
                (=> (and (not (ticket_protocol.le
                                __ticket_protocol.l2s.s_next_ticket
                                |K:ticket_protocol.ticket|))
                         (ticket_protocol.le
                           __ticket_protocol.l2s.s_service
                           |K:ticket_protocol.ticket|))
                    a!1))))
      (a!25 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                  (__ticket_protocol.l2s.d_thread |T:ticket_protocol.thread|))))
      (a!26 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not __ticket_protocol.l2s.waiting)
                       (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |K:ticket_protocol.ticket|)
                       (ticket_protocol.m
                         ticket_protocol.t0
                         |K0:ticket_protocol.ticket|)
                       (not (ticket_protocol.le
                              |K0:ticket_protocol.ticket|
                              |K:ticket_protocol.ticket|))
                       (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|)))
                  (__ticket_protocol.l2s.a_thread |T:ticket_protocol.thread|))))
      (a!27 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K0:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (not __ticket_protocol.l2s.waiting)
                       (ticket_protocol.m
                         ticket_protocol.t0
                         |K0:ticket_protocol.ticket|)
                       (ticket_protocol.le
                         |K:ticket_protocol.ticket|
                         |K0:ticket_protocol.ticket|))
                  (__ticket_protocol.l2s.a_ticket |K:ticket_protocol.ticket|))))
      (a!28 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and __ticket_protocol.l2s.saved
                       (__ticket_protocol.l2s.w_last_scheduled
                         |T:ticket_protocol.thread|))
                  (= (__ticket_protocol.l2s.s_pc1 |T:ticket_protocol.thread|)
                     (__ticket_protocol.pc1 |T:ticket_protocol.thread|)))))
      (a!29 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and __ticket_protocol.l2s.saved
                       (__ticket_protocol.l2s.w_last_scheduled
                         |T:ticket_protocol.thread|))
                  (= (__ticket_protocol.l2s.s_pc2 |T:ticket_protocol.thread|)
                     (ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
      (a!30 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and __ticket_protocol.l2s.saved
                       (__ticket_protocol.l2s.w_last_scheduled
                         |T:ticket_protocol.thread|))
                  (= (__ticket_protocol.l2s.s_pc3 |T:ticket_protocol.thread|)
                     (__ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!31 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and __ticket_protocol.l2s.saved
                       (__ticket_protocol.l2s.w_last_scheduled
                         |T:ticket_protocol.thread|))
                  (= (__ticket_protocol.l2s.s_m
                       |T:ticket_protocol.thread|
                       |K:ticket_protocol.ticket|)
                     (ticket_protocol.m
                       |T:ticket_protocol.thread|
                       |K:ticket_protocol.ticket|)))))
      (a!32 (= ticket_protocol.l2s.frozen
               (ite __ts0__ts0_b_a
                    (and (not __ts0__ts0__ts0_a_a) __ticket_protocol.l2s.frozen)
                    __ticket_protocol.l2s.frozen)))
      (a!33 (forall ((|Z:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (not (ticket_protocol.le
                         |Z:ticket_protocol.ticket|
                         |__new_fml:x|))
                  (ticket_protocol.le |__fml:y| |Z:ticket_protocol.ticket|))))
      (a!34 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|Y:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|Z:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (ticket_protocol.le
                         |X:ticket_protocol.ticket|
                         |Y:ticket_protocol.ticket|)
                       (ticket_protocol.le
                         |Y:ticket_protocol.ticket|
                         |Z:ticket_protocol.ticket|))
                  (ticket_protocol.le
                    |X:ticket_protocol.ticket|
                    |Z:ticket_protocol.ticket|))))
      (a!35 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (ticket_protocol.le
                         |X:ticket_protocol.ticket|
                         |Y:ticket_protocol.ticket|)
                       (ticket_protocol.le
                         |Y:ticket_protocol.ticket|
                         |X:ticket_protocol.ticket|))
                  (= |X:ticket_protocol.ticket| |Y:ticket_protocol.ticket|))))
      (a!36 (= ticket_protocol.l2s.waiting
               (ite __ts0_c
                    (and (not __ts0__ts0_a_a) __ticket_protocol.l2s.waiting)
                    __ticket_protocol.l2s.waiting)))
      (a!37 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.l2s.a_thread |V0:ticket_protocol.thread|)
                 (ite __ts0_c
                      (ite __ts0__ts0_a_a
                           (__ticket_protocol.l2s.d_thread
                             |V0:ticket_protocol.thread|)
                           (__ticket_protocol.l2s.a_thread
                             |V0:ticket_protocol.thread|))
                      (__ticket_protocol.l2s.a_thread
                        |V0:ticket_protocol.thread|)))))
      (a!38 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (ticket_protocol.l2s.a_ticket |V0:ticket_protocol.ticket|)
                 (ite __ts0_c
                      (ite __ts0__ts0_a_a
                           (__ticket_protocol.l2s.d_ticket
                             |V0:ticket_protocol.ticket|)
                           (__ticket_protocol.l2s.a_ticket
                             |V0:ticket_protocol.ticket|))
                      (__ticket_protocol.l2s.a_ticket
                        |V0:ticket_protocol.ticket|)))))
      (a!39 (= ticket_protocol.l2s.s_service
               (ite __ts0_c
                    __ticket_protocol.l2s.s_service
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              __ticket_protocol.service
                              __ticket_protocol.l2s.s_service)
                         __ticket_protocol.l2s.s_service))))
      (a!40 (= ticket_protocol.l2s.s_next_ticket
               (ite __ts0_c
                    __ticket_protocol.l2s.s_next_ticket
                    (ite __ts0__ts0_b_a
                         (ite __ts0__ts0__ts0_a_a
                              ticket_protocol.next_ticket
                              __ticket_protocol.l2s.s_next_ticket)
                         __ticket_protocol.l2s.s_next_ticket))))
      (a!41 (= __m_ticket_protocol.l2s.w_request_flag
               (ite __ts0_c
                    __ticket_protocol.l2s.w_request_flag
                    (ite __ts0__ts0_b_a
                         (or __ts0__ts0__ts0_a_a
                             __ticket_protocol.l2s.w_request_flag)
                         __ticket_protocol.l2s.w_request_flag))))
      (a!42 (and __ticket_protocol.l2s.waiting
                 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
                   (not (__ticket_protocol.l2s.w_last_scheduled
                          |T:ticket_protocol.thread|)))
                 (not __ticket_protocol.l2s.w_request_flag)))
      (a!43 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.pc3 |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      false
                      (__ticket_protocol.pc3 |V0:ticket_protocol.thread|)))))
      (a!44 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.pc1 |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      true
                      (__ticket_protocol.pc1 |V0:ticket_protocol.thread|)))))
      (a!45 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.l2s.d_thread |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__new_fml:t_a|))
                      true
                      (__ticket_protocol.l2s.d_thread
                        |V0:ticket_protocol.thread|)))))
      (a!46 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (__m_ticket_protocol.l2s.d_ticket |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket| |__new_fml:k1_a|))
                      true
                      (__ticket_protocol.l2s.d_ticket
                        |V0:ticket_protocol.ticket|)))))
      (a!47 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (__m_ticket_protocol.l2s.d_ticket_a
                   |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket| |__new_fml:k2_a|))
                      true
                      (__m_ticket_protocol.l2s.d_ticket
                        |V0:ticket_protocol.ticket|)))))
      (a!48 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (__m_ticket_protocol.l2s.d_ticket_b
                   |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket|
                              ticket_protocol.service))
                      true
                      (__m_ticket_protocol.l2s.d_ticket_a
                        |V0:ticket_protocol.ticket|)))))
      (a!49 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (ticket_protocol.l2s.d_ticket |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket|
                              ticket_protocol.next_ticket))
                      true
                      (__m_ticket_protocol.l2s.d_ticket_b
                        |V0:ticket_protocol.ticket|)))))
      (a!50 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.l2s.w_last_scheduled
                   |V0:ticket_protocol.thread|)
                 (and (__m_ticket_protocol.l2s.w_last_scheduled
                        |V0:ticket_protocol.thread|)
                      (not (= |V0:ticket_protocol.thread| |__new_fml:t_a|)))))))
  (and (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (or (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
             (ticket_protocol.pc2 |T:ticket_protocol.thread|)
             (__ticket_protocol.pc3 |T:ticket_protocol.thread|)))
       a!1
       a!2
       a!3
       a!4
       a!5
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (= ticket_protocol.next_ticket ticket_protocol.zero)
             (ticket_protocol.m |T:ticket_protocol.thread| ticket_protocol.zero)))
       a!6
       a!7
       a!8
       a!9
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (__ticket_protocol.pc3 |T:ticket_protocol.thread|)
             (ticket_protocol.m
               |T:ticket_protocol.thread|
               __ticket_protocol.service)))
       (ticket_protocol.le
         __ticket_protocol.service
         ticket_protocol.next_ticket)
       a!10
       (or __ticket_protocol.l2s.waiting
           __ticket_protocol.l2s.frozen
           __ticket_protocol.l2s.saved)
       (or (not __ticket_protocol.l2s.waiting)
           (not __ticket_protocol.l2s.frozen))
       (or (not __ticket_protocol.l2s.waiting)
           (not __ticket_protocol.l2s.saved))
       (or (not __ticket_protocol.l2s.frozen) (not __ticket_protocol.l2s.saved))
       a!11
       a!12
       a!13
       a!14
       a!15
       a!16
       a!17
       (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                (|T:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (=> (and (not (= __ticket_protocol.l2s.s_next_ticket
                                     ticket_protocol.zero))
                             (__ticket_protocol.l2s.s_m
                               |T:ticket_protocol.thread|
                               |M:ticket_protocol.ticket|))
                        (not (ticket_protocol.le
                               __ticket_protocol.l2s.s_next_ticket
                               |M:ticket_protocol.ticket|)))))
           (=> __ticket_protocol.l2s.saved a!1)))
       a!18
       (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                (|T1:ticket_protocol.thread| ticket_protocol.thread)
                (|T2:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (=> (and (__ticket_protocol.l2s.s_m
                               |T1:ticket_protocol.thread|
                               |M:ticket_protocol.ticket|)
                             (__ticket_protocol.l2s.s_m
                               |T2:ticket_protocol.thread|
                               |M:ticket_protocol.ticket|)
                             (not (= |M:ticket_protocol.ticket|
                                     ticket_protocol.zero)))
                        (= |T1:ticket_protocol.thread|
                           |T2:ticket_protocol.thread|))))
           (=> __ticket_protocol.l2s.saved a!1)))
       a!19
       a!20
       (=> __ticket_protocol.l2s.saved
           (ticket_protocol.le
             __ticket_protocol.l2s.s_service
             __ticket_protocol.l2s.s_next_ticket))
       (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                (|T2:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (not (and (not (__ticket_protocol.l2s.s_pc1
                                     |T1:ticket_protocol.thread|))
                              (not (__ticket_protocol.l2s.s_pc1
                                     |T2:ticket_protocol.thread|))
                              (__ticket_protocol.l2s.s_m
                                |T1:ticket_protocol.thread|
                                ticket_protocol.zero)
                              (__ticket_protocol.l2s.s_m
                                |T2:ticket_protocol.thread|
                                ticket_protocol.zero)
                              (not (= |T1:ticket_protocol.thread|
                                      |T2:ticket_protocol.thread|))))))
           (=> __ticket_protocol.l2s.saved a!1)))
       (= __ticket_protocol.l2s.w_request_flag
          (not ticket_protocol.request_flag))
       (=> __ticket_protocol.l2s.frozen ticket_protocol.request_flag)
       (=> __ticket_protocol.l2s.saved ticket_protocol.request_flag)
       (=> ticket_protocol.request_flag
           (ticket_protocol.pc2 ticket_protocol.t0))
       a!21
       (=> __ticket_protocol.l2s.saved
           (ticket_protocol.le
             __ticket_protocol.l2s.s_service
             __ticket_protocol.service))
       a!22
       a!23
       (exists ((|M:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.m ticket_protocol.t0 |M:ticket_protocol.ticket|))
       (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                (|T:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (=> (and (__ticket_protocol.l2s.s_pc1
                               |T:ticket_protocol.thread|)
                             (__ticket_protocol.l2s.s_m
                               |T:ticket_protocol.thread|
                               |M:ticket_protocol.ticket|)
                             (not (= |M:ticket_protocol.ticket|
                                     ticket_protocol.zero)))
                        (not (ticket_protocol.le
                               __ticket_protocol.l2s.s_service
                               |M:ticket_protocol.ticket|)))))
           (=> __ticket_protocol.l2s.saved a!1)))
       (=> __ticket_protocol.l2s.saved a!24)
       (=> __ticket_protocol.l2s.saved
           (exists ((|M:ticket_protocol.ticket| ticket_protocol.ticket))
             (__ticket_protocol.l2s.s_m
               ticket_protocol.t0
               |M:ticket_protocol.ticket|)))
       (__ticket_protocol.l2s.d_thread ticket_protocol.t0)
       a!25
       (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
         (=> (ticket_protocol.le
               |K:ticket_protocol.ticket|
               ticket_protocol.next_ticket)
             (__ticket_protocol.l2s.d_ticket |K:ticket_protocol.ticket|)))
       (=> (not __ticket_protocol.l2s.waiting)
           (__ticket_protocol.l2s.a_thread ticket_protocol.t0))
       a!26
       a!27
       a!28
       a!29
       a!30
       a!31
       (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                (|K0:ticket_protocol.ticket| ticket_protocol.ticket)
                (|T:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (and (and __ticket_protocol.l2s.saved
                              (__ticket_protocol.l2s.s_m
                                |T:ticket_protocol.thread|
                                __ticket_protocol.l2s.s_service)
                              (not (__ticket_protocol.l2s.w_last_scheduled
                                     |T:ticket_protocol.thread|)))
                         (__ticket_protocol.l2s.s_pc2
                           |T:ticket_protocol.thread|)
                         (ticket_protocol.m
                           |T:ticket_protocol.thread|
                           |K:ticket_protocol.ticket|)
                         (ticket_protocol.m
                           ticket_protocol.t0
                           |K0:ticket_protocol.ticket|)))
               (a!2 (or (and (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
                             (= |K:ticket_protocol.ticket|
                                __ticket_protocol.l2s.s_service))
                        (and (ticket_protocol.pc2 |T:ticket_protocol.thread|)
                             (not (ticket_protocol.le
                                    |K:ticket_protocol.ticket|
                                    |K0:ticket_protocol.ticket|)))
                        (and (__ticket_protocol.pc3 |T:ticket_protocol.thread|)
                             (= |K:ticket_protocol.ticket|
                                __ticket_protocol.l2s.s_service)))))
           (=> a!1 a!2)))
       (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket)
                (|K0:ticket_protocol.ticket| ticket_protocol.ticket)
                (|T:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (and (and __ticket_protocol.l2s.saved
                              (__ticket_protocol.l2s.s_m
                                |T:ticket_protocol.thread|
                                __ticket_protocol.l2s.s_service)
                              (not (__ticket_protocol.l2s.w_last_scheduled
                                     |T:ticket_protocol.thread|)))
                         (__ticket_protocol.l2s.s_pc3
                           |T:ticket_protocol.thread|)
                         (ticket_protocol.m
                           |T:ticket_protocol.thread|
                           |K:ticket_protocol.ticket|)
                         (ticket_protocol.m
                           ticket_protocol.t0
                           |K0:ticket_protocol.ticket|)))
               (a!2 (or (and (and (__ticket_protocol.pc1
                                    |T:ticket_protocol.thread|)
                                  (= |K:ticket_protocol.ticket|
                                     __ticket_protocol.l2s.s_service))
                             (not (ticket_protocol.le
                                    __ticket_protocol.service
                                    __ticket_protocol.l2s.s_service)))
                        (and (ticket_protocol.pc2 |T:ticket_protocol.thread|)
                             (not (ticket_protocol.le
                                    |K:ticket_protocol.ticket|
                                    |K0:ticket_protocol.ticket|))))))
           (=> a!1 a!2)))
       (or (not __ts0_c)
           (= ticket_protocol.l2s.saved __ticket_protocol.l2s.saved))
       (or __ts0_c
           __ts0__ts0_b_a
           (= ticket_protocol.l2s.saved __ticket_protocol.l2s.saved))
       (or __ts0_c a!32)
       (__ticket_protocol.pc3 |__fml:t|)
       (= |__fml:k1| __ticket_protocol.service)
       (not (ticket_protocol.le |__fml:y| |__new_fml:x|))
       a!33
       (= |__fml:k2| |__new_loc:0|)
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.le
           |X:ticket_protocol.ticket|
           |X:ticket_protocol.ticket|))
       a!34
       a!35
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                (|Y:ticket_protocol.ticket| ticket_protocol.ticket))
         (or (ticket_protocol.le
               |X:ticket_protocol.ticket|
               |Y:ticket_protocol.ticket|)
             (ticket_protocol.le
               |Y:ticket_protocol.ticket|
               |X:ticket_protocol.ticket|)))
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (ticket_protocol.le ticket_protocol.zero |X:ticket_protocol.ticket|))
       a!36
       a!37
       a!38
       (= __ts0__ts0_a_a ticket_protocol.l2s.frozen)
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (ite __ts0_c
                         (__ticket_protocol.l2s.s_pc1
                           |V0:ticket_protocol.thread|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (__ticket_protocol.pc1
                                     |V0:ticket_protocol.thread|)
                                   (__ticket_protocol.l2s.s_pc1
                                     |V0:ticket_protocol.thread|))
                              (__ticket_protocol.l2s.s_pc1
                                |V0:ticket_protocol.thread|)))))
           (= (ticket_protocol.l2s.s_pc1 |V0:ticket_protocol.thread|) a!1)))
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (ite __ts0_c
                         (__ticket_protocol.l2s.s_pc2
                           |V0:ticket_protocol.thread|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (ticket_protocol.pc2
                                     |V0:ticket_protocol.thread|)
                                   (__ticket_protocol.l2s.s_pc2
                                     |V0:ticket_protocol.thread|))
                              (__ticket_protocol.l2s.s_pc2
                                |V0:ticket_protocol.thread|)))))
           (= (ticket_protocol.l2s.s_pc2 |V0:ticket_protocol.thread|) a!1)))
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (ite __ts0_c
                         (__ticket_protocol.l2s.s_pc3
                           |V0:ticket_protocol.thread|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (__ticket_protocol.pc3
                                     |V0:ticket_protocol.thread|)
                                   (__ticket_protocol.l2s.s_pc3
                                     |V0:ticket_protocol.thread|))
                              (__ticket_protocol.l2s.s_pc3
                                |V0:ticket_protocol.thread|)))))
           (= (ticket_protocol.l2s.s_pc3 |V0:ticket_protocol.thread|) a!1)))
       a!39
       a!40
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread)
                (|V1:ticket_protocol.ticket| ticket_protocol.ticket))
         (let ((a!1 (ite __ts0_c
                         (__ticket_protocol.l2s.s_m
                           |V0:ticket_protocol.thread|
                           |V1:ticket_protocol.ticket|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (ticket_protocol.m
                                     |V0:ticket_protocol.thread|
                                     |V1:ticket_protocol.ticket|)
                                   (__ticket_protocol.l2s.s_m
                                     |V0:ticket_protocol.thread|
                                     |V1:ticket_protocol.ticket|))
                              (__ticket_protocol.l2s.s_m
                                |V0:ticket_protocol.thread|
                                |V1:ticket_protocol.ticket|)))))
           (= (ticket_protocol.l2s.s_m
                |V0:ticket_protocol.thread|
                |V1:ticket_protocol.ticket|)
              a!1)))
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (ite __ts0_c
                         (__ticket_protocol.l2s.w_last_scheduled
                           |V0:ticket_protocol.thread|)
                         (ite __ts0__ts0_b_a
                              (ite __ts0__ts0__ts0_a_a
                                   (__ticket_protocol.l2s.d_thread
                                     |V0:ticket_protocol.thread|)
                                   (__ticket_protocol.l2s.w_last_scheduled
                                     |V0:ticket_protocol.thread|))
                              (__ticket_protocol.l2s.w_last_scheduled
                                |V0:ticket_protocol.thread|)))))
           (= (__m_ticket_protocol.l2s.w_last_scheduled
                |V0:ticket_protocol.thread|)
              a!1)))
       a!41
       (= __ts0__ts0__ts0_a_a ticket_protocol.l2s.saved)
       (= __ts0__ts0_b_a __ticket_protocol.l2s.frozen)
       (= __ts0_c a!42)
       (= |__new_fml:x| |__fml:k1|)
       (= |__new_loc:0| |__fml:y|)
       (= ticket_protocol.service |__fml:k2|)
       a!43
       a!44
       (= |__new_fml:t_a| |__fml:t|)
       (= |__new_fml:k1_a| |__fml:k1|)
       (= |__new_fml:k2_a| |__fml:k2|)
       a!45
       a!46
       a!47
       a!48
       a!49
       a!50
       (= ticket_protocol.l2s.w_request_flag
          (and __m_ticket_protocol.l2s.w_request_flag
               (not ticket_protocol.request_flag))))))
(assert (let ((a!1 (not (and (not (ticket_protocol.l2s.s_pc1 @T1))
                     (not (ticket_protocol.l2s.s_pc1 @T2))
                     (ticket_protocol.l2s.s_m @T1 ticket_protocol.zero)
                     (ticket_protocol.l2s.s_m @T2 ticket_protocol.zero)
                     (not (= @T1 @T2))))))
  (and (not (=> ticket_protocol.l2s.saved a!1)))))

(check-sat)
(get-info :all-statistics)
