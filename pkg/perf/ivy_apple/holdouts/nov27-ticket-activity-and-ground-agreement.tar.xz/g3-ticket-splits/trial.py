from pathlib import Path
import os,csv,subprocess as sp,json,collections as c
w=Path(__file__).resolve().parent;p=Path.cwd();front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();ov=json.loads((w/'meter.json').read_text())
def save(a,s):
 b=w/('trial-'+a.name);b.write_text(s);ov['Replace'][str(a)]=str(b)
a=p/'smtcore/smt_model_checker.go';s=a.read_text();k='func (c *SMTModelChecker) Check(model *protomodel.ProtoModel, quantifiers []ast.ASTHandle) (bool, error) {'
s=s.replace(k,k+'''
 if TrialActive {if trialOwner==nil {trialOwner=c};if trialOwner==c {trialCandidate++;trialWitness=0}}
''');k='status, bindings, err := c.tableScratch.check';i=s.index(k);j=s.index('\n',i);s=s[:j]+'''
 if TrialActive && c==trialOwner && status==lbool.True {
 trialWitness++
 if trialMode=="all" || trialCandidate==1 && (trialMode=="firstmodel" || trialMode=="first" && trialWitness==1 || trialMode=="other" && trialWitness>1) {
 println("TRIAL delegate",trialCandidate,trialWitness);status=lbool.Undef
 }
 }
'''+s[j:];s=s.replace('import (','import ("os";',1)+'\nvar trialOwner *SMTModelChecker\nvar trialMode=os.Getenv("EXPERIMENT")\nvar trialCandidate,trialWitness int\n';save(a,s)
a=p/'smtcore/smt_qi_queue_schedule.go';s=a.read_text().replace('q.newEntries = append','if TrialActive{trialOffers++};q.newEntries = append',1)
k='sinceLastCheck := 0';s=s.replace(k,'''if TrialActive && trialMode=="order" && trialOffers==100 && len(q.newEntries)==42 {
 x:=q.newEntries[23];copy(q.newEntries[17:24],q.newEntries[16:23]);q.newEntries[16]=x;println("TRIAL reorder")
 }
 '''+k,1);save(a,s+'\nvar trialOffers int\n')
j=w/'trial.json';j.write_text(json.dumps(ov));sp.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-tags','xtrace_off','-buildvcs=false','-mod=readonly','-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'trial','./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');ref=Path('/tmp/g3-reduction-rows')
with (w/'trials.csv').open('w') as f:
 o=csv.writer(f);o.writerow('case round policy check_instructions process_instructions interventions'.split())
 for nr,b,g,modes in [(3,2,55,['default','order']),(6,16,1,['default','first','other','firstmodel','all'])]:
  name=(ref/'compat.txt').read_text().splitlines()[nr-1];d=ref/'compat'/str(nr)/'1/native'
  for i in range(5):
   for mode in modes[i%len(modes):]+modes[:i%len(modes)]:
    stat=w/'whole.stat';r=sp.run(['taskset','-c','14','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',w/'trial',ex/name],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',GOIVY_INCLUDE=str(ex/'ivy/include'),XTRACE_OFF='1',BATCH=str(b),GOAL=str(g),EXPERIMENT=mode),cwd=w,capture_output=True,check=True);rest=[];actions=[];check=[]
    for l in r.stderr.splitlines(keepends=True):
     if l.startswith(b'TRIAL '):actions.append(l)
     elif l.startswith(b'STAGE-COUNT '):a=l.split();assert a[6]==a[7];check.append(int(a[4]))
     else:rest.append(l)
    assert len(check)==1 and (r.stdout,b''.join(rest))==((d/'stdout').read_bytes(),(d/'stderr').read_bytes())
    n,=[int(x[0]) for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100]
    o.writerow([nr,i,mode,check[0],n,len(actions)]);f.flush()
