from common import *
import live_checks as lc,holdouts as ho
rd=d/'apple-skip-intervention';rd.mkdir(exist_ok=True)
def make():
 b=lc.bridge;s=b.read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('\n\tif overallResult == smt.Unsat',i);body=s[i:j]
 body=once(body,'z3solver := s.newZ3Solver()','studyBatch++;batch:=studyBatch;z3solver := s.newZ3Solver()')
 body=once(body,'for _, fc := range finalCond {','for g, fc := range finalCond {smt.StudyCoordinate(batch,g+1)')
 ed={b:s[:i]+body+s[j:]+'\nvar studyBatch int\n'}
 q=lc.core;ed[q]=q.read_text()+'\nfunc StudyCoordinate(batch,goal int){api.StudyBatch,api.StudyGoal=batch,goal}\n'
 q=pkg/'api/api_ground_instances.go';s=once(q.read_text(),'import (','import ("os";')
 s=once(s,'type groundInstanceSolver struct {','type groundInstanceSolver struct {\n studyOrdinal int')
 x='if s.pool.Disabled() {\n\t\treturn false, nil';s=once(s,x,'''s.studyOrdinal++;if s.studyOrdinal<=2&&(studyMode=="all"||studyMode=="force"||studyMode=="only13"&&StudyBatch==13||studyMode=="except13"&&StudyBatch!=13||studyMode=="only14"&&StudyBatch==14){return false,nil};'''+x)
 ed[q]=s+'\nvar StudyBatch,StudyGoal int\nvar studyMode=os.Getenv("STUDY_INTERVENE")\n'
 q=pkg/'api/api_order_abstraction.go';s=once(q.read_text(),'"math"','"math"\n"fmt"\n"os"')
 i=s.index('var candidate *recentRefutations');s=s[:i]+'''observe:=StudyBatch==13 && StudyGoal==132||StudyBatch==14 && StudyGoal==110
 if observe{fmt.Fprintln(os.Stderr,"ROUTE",StudyBatch,StudyGoal,"entry",!goal.IsNull(),p.previousGoalProved,p.plans.uses);if studyMode=="force"&&StudyBatch==13&&!goal.IsNull(){return false,nil}}
 '''+s[i:]
 for k,line in [('assertions','proved, err = p.proveAssertions(parent, assertions, maxSteps, reuse)'),('relevant','proved, err = p.proveRelevantPremises(parent, assertions)')]:
  s=once(s,line,line+';if observe{fmt.Fprintln(os.Stderr,"ROUTE",StudyBatch,StudyGoal,"'+k+'",proved,err)}')
 x='return p.enumeration.check(parent, assertions)';s=once(s,x,'proved,err=p.enumeration.check(parent,assertions);if observe{fmt.Fprintln(os.Stderr,"ROUTE",StudyBatch,StudyGoal,"enum",proved,err)};return proved,err')
 ed[q]=s;q=pkg/'api/api_goal_instances_check.go';s=once(q.read_text(),'"errors"','"errors"\n"fmt"\n"os"')
 x='reuse := p.plans.reusable(parent)';s=once(s,x,'''observe:=StudyBatch==13 && StudyGoal==132||StudyBatch==14 && StudyGoal==110
 if observe{defer func(){fmt.Fprintln(os.Stderr,"ROUTE",StudyBatch,StudyGoal,"plan",fmt.Sprintf("%T",plan),maxSteps,p.plans.uses,proved,err)}()}
 '''+x)
 x='answer, err := aux.child.Check()';s=once(s,x,x+';if observe{fmt.Fprintln(os.Stderr,"ROUTE",StudyBatch,StudyGoal,"private",answer,err,limit.IncOffset(0))}')
 ed[q]=s;return build(rd/'checker',o=overlay(rd/'overlay',ed))
def lane(b,mode,c):
 _,n,sp,iso,rc,ref=ho.jobs()[0];out=rd/mode;out.mkdir()
 with (out/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow(['round','instructions','cycles','exit','match'])
  for i in range(1,3):
   p=out/f'{i}.perf';call=subprocess.run(['taskset','-c',str(c),perf,'stat','-x,','-o',p,'-e','instructions:u,cycles:u','--',b,examples/sp],cwd=out,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100',STUDY_INTERVENE=mode));other=bytearray()
   with(out/f'{i}.log').open('wb')as l:
    for line in call.stderr.splitlines(keepends=True):
     if line.startswith(b'ROUTE '):l.write(line)
     else:other.extend(line)
   good=(call.returncode,call.stdout,other)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes());ct=[int(l.split(',')[0])for l in p.read_text().splitlines()if ':u'in l];wr.writerow([i,*ct,call.returncode,int(good)]);f.flush();assert good,(mode,call.returncode,other[-300:]);print(mode,i,round(ct[0]/1e9,2),flush=True)
if __name__=='__main__':
 b=make()
 with ThreadPoolExecutor(6)as ex:
  fs=[ex.submit(lane,b,k,c)for k,c in zip(('none','all','only13','except13','only14','force'),[17,46,6,13,31,42])]
  for f in fs:f.result()
