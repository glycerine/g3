from common import *
import live_checks as lc,holdouts as ho
rd=d/'apple-batch-causality';rd.mkdir(exist_ok=True)
def make():
 ed={};b=lc.bridge;s=b.read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('\n\tif overallResult == smt.Unsat',i);body=s[i:j]
 body=once(body,'z3solver := s.newZ3Solver()','studyBatch++;batch:=studyBatch;z3solver := s.newZ3Solver()')
 body=once(body,'for _, fc := range finalCond {','for g, fc := range finalCond {')
 body=once(body,'if proveGoal(zCond) {','z3solver.StudyState(batch,g+1,"before",zCond);yes:=proveGoal(zCond);z3solver.StudyState(batch,g+1,fmt.Sprint("early-",yes),zCond);if yes {')
 x='res, err := s.decideZ3With(z3solver, finalCheck)';body=once(body,x,'z3solver.StudyState(batch,g+1,"check",zCond);'+x+';z3solver.StudyState(batch,g+1,"result",zCond)')
 for x,n in [('z3solver.Push()','pushed'),('z3solver.Pop()','popped')]:
  body=body.replace(x,x+';z3solver.StudyState(batch,g+1,"'+n+'",zCond)')
 ed[b]=s[:i]+body+s[j:]+'\nvar studyBatch int\n'
 k=lc.core;s=once(k.read_text(),'import (','import ("fmt";"os";')
 s+='''
func(s *Z3Solver)StudyState(b,g int,stage string,e Z3Expr){
 if b!=12&&b!=13&&b!=14{return}
 s.ctx.do(func(){
 m,err:=s.ctx.c.Manager();fail(err);id,err:=m.GetASTID(e.c);fail(err)
 a:=m.StudyASTState();fmt.Fprintln(os.Stderr,"STATE",b,g,stage,id,e.c.Slot(),e.c.Generation(),a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10],len(s.ctx.roots))
 if stage=="check"||stage=="result"{st,err:=s.c.Statistics();fail(err);v,err:=st.String();fail(err);fail(st.Close());fmt.Fprintln(os.Stderr,"SEARCH",b,g,stage,strconv.Quote(v))}
 })
}
''';ed[k]=s
 k=pkg/'ast/ast_core_stats.go';ed[k]=k.read_text()+'''
func(m *ASTManager)StudyASTState()[11]uint32{return [11]uint32{m.nextNode,m.freeNode,m.liveNodes,m.liveReferences,m.liveParameters,m.liveInfos,m.ExprIDs.Range(),m.declIDs.Range(),m.freshID,m.nextReference,m.freeReference}}
'''
 k=pkg/'api/api_ground_instances.go';s=once(k.read_text(),'import (','import ("os";"strconv";')
 s=once(s,'type groundInstanceSolver struct {','type groundInstanceSolver struct {\n studyOrdinal int')
 s=once(s,'if s.pool.Disabled() {','if s.pool.Disabled() {')if s.count('if s.pool.Disabled() {')==1 else s
 x='if s.pool.Disabled() {\n\t\treturn false, nil';s=once(s,x,'s.studyOrdinal++;if s.studyOrdinal<=studySkip{return false,nil};'+x)
 ed[k]=s+'\nvar studySkip=func()int{x,_:=strconv.Atoi(os.Getenv("G3_POOL_SKIP"));return x}()\n'
 return build(rd/'checker',o=overlay(rd/'overlay',ed))
def runone(b,k,cpu):
 _,n,sp,iso,rc,ref=ho.jobs()[0];od=rd/str(k);od.mkdir();raw=bytearray()
 with(od/'stdout').open('wb')as out,gzip.open(od/'states.csv.gz','wt')as sf,gzip.open(od/'stats.csv.gz','wt')as tf:
  sw,tw=csv.writer(sf),csv.writer(tf);sw.writerow('batch goal stage ast_id slot generation next_node free_node live_nodes live_refs live_params live_info expression_ids decl_ids fresh_id next_ref free_ref frontend_roots'.split());tw.writerow(['batch','goal','stage','stat','value'])
  with subprocess.Popen(['taskset','-c',str(cpu),b,examples/sp],cwd=od,stdout=out,stderr=subprocess.PIPE,env=dict(env,GOMAXPROCS='1',GOGC='100',G3_POOL_SKIP=str(k)))as pr:
   for line in pr.stderr:
    if line.startswith(b'STATE '):sw.writerow(line.decode().split()[1:])
    elif line.startswith(b'SEARCH '):
     _,ba,g,st,v=line.decode().split(maxsplit=4);tw.writerows((ba,g,st,name,value)for name,value in re.findall(r':([\w-]+)\s+(\d+)(?=[\s)])',json.loads(v)))
    else:raw.extend(line)
   ret=pr.wait()
 assert(ret,(od/'stdout').read_bytes(),raw)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(k,ret,raw[-500:])
 (od/'validated').write_text('full output and exit matched\n');print(k,'complete',flush=True)
if __name__=='__main__':
 b=make()
 with ThreadPoolExecutor(2)as e:
  fs=[e.submit(runone,b,k,c)for k,c in [(0,25),(2,33)]]
  for f in fs:f.result()
