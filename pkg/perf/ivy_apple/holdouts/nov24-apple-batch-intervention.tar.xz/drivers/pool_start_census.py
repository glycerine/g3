from common import *
import sibling_cost_differences as sc,holdouts as ho,stage_frontier as sf
rd=d/'pool-start-census';rd.mkdir(exist_ok=True)
def make():
 src=d/'sibling-cost-differences/overlay';ed={Path(p).resolve():Path(f).read_text() for p,f in json.loads((src/'overlay.json').read_text())['Replace'].items()}
 p=pkg/'api/api_ground_instances.go';s=ed[p];s=once(s,'type groundInstanceSolver struct {','type groundInstanceSolver struct {\n studyOrdinal int')
 x='if s.pool.Disabled() {\n\t\treturn false, nil';s=once(s,x,'''s.studyOrdinal++;stage:="new";nv,nc,nu,work:=0,0,0,0
 defer func(){fmt.Fprintln(os.Stderr,"POOL-GOAL",s.studyOrdinal,len(base),stage,nv,nc,nu,work,proved)}()
 if s.studyOrdinal<=studySkip{stage="skipped";return false,nil}
 if s.pool.Disabled() {stage="disabled";return false,nil''')
 s=once(s,'import (','import ("fmt";"strconv";');s+='\nvar studySkip=func()int{x,_:=strconv.Atoi(os.Getenv("G3_POOL_SKIP"));return x}()\n'
 x='if q == nil || err != nil {';s=once(s,x,x+' stage="empty";if s.pool.Disabled(){stage="stopped"};')
 x='if !limit.IncOffset(q.Work) {';s=once(s,x,'nv,nc,work=q.Variables,len(q.Clauses),int(q.Work);'+x)
 x='if conflict {';s=once(s,x,'nu=len(q.PermanentUnits());stage="units";'+x)
 x='return s.search(src, m, q)';s=once(s,x,'stage="search";'+x);ed[p]=s
 g=pkg/'api/internal/order/ground_instance_pool.go';s=once(g.read_text(),'import (','import ("os";"fmt";')
 x='defer func() {\n\t\tif err == nil';s=once(s,x,'stage:="index";'+x)
 x='p.disable()\n\t\tif err == inapplicable';s=once(s,x,'fmt.Fprintln(os.Stderr,"POOL-FAIL",stage,len(p.rules),len(p.g.terms),len(p.instances),len(p.g.compiler.Clauses),p.g.compiler.Vars,len(p.installed),err);'+x)
 for x,stage in [('if err := p.join(key, n);','join'),('id, err := p.root(goal)','goal'),('if err := p.compileTerms();','encode'),('p.need(lit)','clauses')]:s=once(s,x,'stage="'+stage+'";'+x)
 ed[g]=s
 return build(rd/'checker',o=overlay(rd/'overlay',ed))
def lane(j,b,skip):
 c,n,sp,iso,rc,ref=j;sd=rd/n/('skip'+str(skip));sd.mkdir(parents=True);scope=[];groups=defaultdict(Counter);rest=bytearray();records=[];fails=[]
 with(sd/'stdout').open('wb')as out,subprocess.Popen(['taskset','-c',str(c),b,examples/sp],env=dict(env,GOMAXPROCS='1',GOGC='100',G3_POOL_SKIP=str(skip),G3_INSTANCE_COST_MODE='bounded'),cwd=sd,stdout=out,stderr=subprocess.PIPE)as pr:
  for line in pr.stderr:
   if line.startswith(b'COST-OPEN '):scope.append([int(line.split()[1]),0])
   elif line.startswith(b'COST-CLOSE '):assert scope.pop()[0]==int(line.split()[1])
   elif line.startswith(b'COST-GOAL '):ba,g=map(int,line.split()[1:]);assert ba==scope[-1][0];scope[-1][1]=g
   elif line.startswith(b'INNER-CHECK '):
    _,kind,_,lo,hi,cost,base=line.split();groups[tuple(scope[-1]) if scope else (0,0)][kind.decode()]+=int(cost)-int(base)
   elif line.startswith(b'POOL-GOAL '):records.append([*scope[-1],*line.decode().split()[1:]])
   elif line.startswith(b'POOL-FAIL '):fails.append([*scope[-1],*line.decode().split(maxsplit=8)[1:]])
   else:rest.extend(line)
  code=pr.wait()
 assert not scope and (code,(sd/'stdout').read_bytes(),rest)==(rc,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(n,code,rest[-300:]);ks='early push check pop instances project reduce search'.split()
 for name,fields,rows in [('calls','batch goal ordinal base stage variables clauses units work proved'.split(),records),('failures','batch goal stage rules terms instances rows vars groups reason'.split(),fails),('costs',['batch','goal',*ks],[[*k,*[v[x]for x in ks]]for k,v in sorted(groups.items())])]:
  with gzip.open(sd/(name+'.csv.gz'),'wt')as f:z=csv.writer(f);z.writerow(fields);z.writerows(rows)
 (sd/'validated').write_text('complete transcript and exit matched\n');print(n,skip,{k:round(sum(v[k]for v in groups.values())/1e9,2)for k in ks},dict(Counter(v[4]for v in records)),len(fails),flush=True)
def main():
 b=make();js=[j for j in sf.jobs()if j[1]=='tlb']+ho.jobs()[:3]
 with ThreadPoolExecutor(6)as e:
  fs=[e.submit(lane,(cpu,*j[1:]),b,skip)for cpu,(j,skip)in zip([3,17,25,45,26,9,39,35],[(j,skip)for j in js for skip in [0,2]])]
  for f in fs:f.result()
if __name__=='__main__':main()
