"""Compare bounded repairs on the same signed and UNSAT holdouts."""
from pathlib import Path
from collections import defaultdict
from statistics import median
import csv, io, os, subprocess, sys, time

root = Path.cwd()
base = root/'build/.nov26-planted-search'
fixtures = base/'repair-reuse'
out = base/'repair-adaptive'
sys.path.insert(0, str(root/'perf/ivy_raft'))
from watch_propagation import check_output

perf = '/usr/lib/linux-tools/6.17.0-35-generic/perf'
env = dict(os.environ, GOMAXPROCS='1')
engines = {'repair-reuse': fixtures/'g3'}
engines.update((name, out/name) for name in sys.argv[1:])
with (out/'compare.csv').open('w') as results:
    writer = csv.writer(results)
    writer.writerow(('case', 'engine', 'round', 'answer', 'variables_created', 'instructions', 'milliseconds'))
    for file in sorted([*fixtures.glob('w*.cnf'), *fixtures.glob('hidden-*.cnf')]):
        clauses = []
        for line in file.read_text().splitlines():
            if line.startswith('p '):
                n = int(line.split()[2])
            elif not line.startswith('c'):
                clauses.append([int(l) for l in line.split()[:-1]])
        expected = 'unsat' if file.name.startswith('hidden-') else 'sat'
        labels = list(engines)
        for turn in range(3):
            for label in labels[turn:]+labels[:turn]:
                start = time.monotonic()
                res = subprocess.run(['taskset', '-c', '9', perf, 'stat', '-x,', '-e', 'instructions:u',
                                      '--', engines[label], '-st', '-dimacs', file], env=env,
                                     capture_output=True, text=True, check=True)
                ms = (time.monotonic()-start)*1000
                check_output(res.stdout, expected, n, clauses)
                inst, = [int(r[0]) for r in csv.reader(io.StringIO(res.stderr)) if len(r)>=5 and r[2]=='instructions:u']
                writer.writerow((file.stem, label, turn, expected, int(':mk-bool-var' in res.stdout), inst, f'{ms:.3f}'))
        results.flush()
with (out/'compare.csv').open() as results:
    grouped = defaultdict(lambda: defaultdict(list))
    for r in csv.DictReader(results):
        grouped[r['engine']][r['case']].append(r)
    for label, cases in grouped.items():
        misses = [case for case, rows in cases.items() if rows[0]['answer']=='sat' and rows[0]['variables_created']=='1']
        hidden = median(int(r['instructions']) for r in cases['hidden-contradiction-8'])
        work = sum(median(int(r['instructions']) for r in rows) for case, rows in cases.items() if rows[0]['answer']=='sat')
        print(f'{label:18} misses {misses} total SAT {work/1e6:.2f} M hidden {hidden/1e6:.2f} M')
