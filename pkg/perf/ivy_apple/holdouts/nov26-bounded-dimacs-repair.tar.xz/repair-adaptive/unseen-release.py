"""Test repair policies on a second set of signed formulas and contradictions."""
from pathlib import Path
import sys

root = Path.cwd()
base = root/'build/.nov26-planted-search'
out = base/'repair-adaptive'/'unseen'
out.mkdir(exist_ok=True)
source = (base/'repair-reuse'/'holdouts.py').read_text()
head, _, _ = source.partition('cases=[]')
head = head.replace("out=base/'repair-reuse'", f'out=Path({str(out)!r})')
scope = {}
exec(head, scope)
planted, dimacs = scope['planted'], scope['dimacs']

for width, n, count in ((3,384,1152),(3,330,1340),(4,512,2200),(6,1200,5000)):
    for seed in (112,721,830,1337,1975,2309):
        clauses = planted(width,n,count,seed)
        (out/f'w{width}-n{n}-{seed}.cnf').write_text(dimacs(n,clauses))
    a, b = n+1, n+2
    clauses.extend([[a,b],[a,-b],[-a,b],[-a,-b]])
    (out/f'hidden-{width}-{n}.cnf').write_text(dimacs(n+2,clauses))

source = (base/'repair-adaptive'/'compare.py').read_text()
source = source.replace("fixtures = base/'repair-reuse'", f'fixtures = Path({str(out)!r})')
source = source.replace("engines = {'repair-reuse': fixtures/'g3'}",
                        "engines = {'baseline': base/'model-final'/'g3','release': base/'repair-final'/'g3','z3': root.parent/'build/z3'}")
source = source.replace("out/'compare.csv'", "out/'unseen-release.csv'")
source = source.replace("hidden = median(int(r['instructions']) for r in cases['hidden-contradiction-8'])",
                        "hidden = sum(median(int(r['instructions']) for r in rows) for rows in cases.values() if rows[0]['answer']=='unsat')")
exec(source)
