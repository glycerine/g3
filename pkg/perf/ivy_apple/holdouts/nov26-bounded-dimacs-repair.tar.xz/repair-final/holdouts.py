"""Check signed planted models and deliberate contradictions through the actual DIMACS CLI."""
from pathlib import Path
from collections import Counter
import csv, os, random, subprocess, sys, time
root=Path.cwd()
base=root/'build/.nov26-planted-search'
out=base/'repair-final'
sys.path.insert(0,str(root/'perf/ivy_raft'))
from watch_propagation import dimacs, check_output, formulas
perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'

def planted(width, n, count, seed):
    rng=random.Random(seed)
    signs=[None]+[rng.choice((-1,1)) for _ in range(n)]
    clauses=[]
    for _ in range(count):
        vs=rng.sample(range(1,n+1),width)
        row=[v*rng.choice((-1,1)) for v in vs]
        if not any(l*signs[abs(l)]>0 for l in row):
            i=rng.randrange(width)
            row[i]=-row[i]
        clauses.append(row)
    return clauses

cases=[]
for width,n,count in ((3,768,2400),(5,1200,4800),(8,2048,10000)):
    for seed in (155,177,189,248,752):
        clauses=planted(width,n,count,seed+width)
        cases.append((f'w{width}-{seed}',n,clauses,'sat',False))
    # Disjoint from the planted variables, this binary component forbids
    # all possibilities. It exercises a complete bounded repair miss.
    if width==8:
        a,b=n+1,n+2
        cases.append((f'hidden-contradiction-{width}',n+2,clauses+[[a,b],[a,-b],[-a,b],[-a,-b]],'unsat',False))
for name,n,cs,status in formulas(3):
    if name in ('pigeon7','pigeon8-s1'):
        cases.append((name,n,cs,status,True))
engines={'baseline':base/'model-final/g3','release':out/'g3','z3':root.parent/'build/z3'}
env=dict(os.environ,GOMAXPROCS='1')
with (out/'holdouts.csv').open('w') as stream:
    writer=csv.writer(stream)
    writer.writerow(['case','engine','answer','round','milliseconds','instructions','decisions','conflicts'])
    for name,n,clauses,expect,padded in cases:
        file=out/(name+'.cnf')
        pad='c '+' '*6000+'\n' if padded else ''
        file.write_text(pad+dimacs(n,clauses))
        for turn in range(1,4 if expect=='unsat' else 3):
            labels=list(engines)
            for engine in labels[turn-1:]+labels[:turn-1]:
                counts=out/'perf.csv'
                start=time.monotonic()
                p=subprocess.run(['taskset','-c','9',perf,'stat','-x,','-o',counts,'-e','instructions:u','--',
                                  engines[engine],'-st','-dimacs',file],
                                  capture_output=True,text=True,env=env,timeout=180,check=True)
                ms=(time.monotonic()-start)*1000
                st=check_output(p.stdout,expect,n,clauses)
                inst,=[int(r[0]) for r in csv.reader(counts.open()) if len(r)>=5 and r[2]=='instructions:u']
                writer.writerow([name,engine,expect,turn,f'{ms:.3f}',inst,st.get('decisions',0),st.get('conflicts',0)])
                stream.flush()
