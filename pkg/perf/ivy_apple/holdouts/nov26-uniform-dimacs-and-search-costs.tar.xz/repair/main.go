// Isolate a bounded, single-threaded DIMACS model-repair trial.
package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"strings"

	"github.com/glycerine/g3/pkg/sat"
)

type repair struct {
	clauses     [][]sat.DIMACSLiteral
	value       []bool
	count       []int
	failed      []int
	positions   []int
	occurrences [][]int
	rng         uint32
}

func bit(lit sat.DIMACSLiteral) int {
	if lit < 0 {
		return int(-lit)*2 + 1
	}
	return int(lit) * 2
}

func (r *repair) random(n int) int {
	r.rng ^= r.rng << 13
	r.rng ^= r.rng >> 17
	r.rng ^= r.rng << 5
	return int(r.rng % uint32(n))
}

func (r *repair) bump(clause, delta int) {
	old := r.count[clause]
	r.count[clause] = old + delta
	if old == 0 {
		at := r.positions[clause]
		last := r.failed[len(r.failed)-1]
		r.failed[at] = last
		r.positions[last] = at
		r.failed = r.failed[:len(r.failed)-1]
	} else if old+delta == 0 {
		r.positions[clause] = len(r.failed)
		r.failed = append(r.failed, clause)
	}
}

func (r *repair) liveLiteral(v int) int {
	if r.value[v] {
		return v * 2
	}
	return v*2 + 1
}

func (r *repair) flip(v int) {
	live := r.liveLiteral(v)
	for _, clause := range r.occurrences[live] {
		r.bump(clause, -1)
	}
	for _, clause := range r.occurrences[live^1] {
		r.bump(clause, 1)
	}
	r.value[v] = !r.value[v]
}

func model(cnf sat.DIMACSCNF) ([]bool, int) {
	if cnf.VariableCount == 0 || cnf.VariableCount > 100000 {
		return nil, 0
	}
	n := int(cnf.VariableCount) + 1
	r := repair{
		clauses:     cnf.Clauses,
		value:       make([]bool, n),
		count:       make([]int, len(cnf.Clauses)),
		positions:   make([]int, len(cnf.Clauses)),
		occurrences: make([][]int, 2*n),
		rng:         0x53721aef,
	}
	for ci, c := range r.clauses {
		if len(c) == 0 {
			return nil, 0
		}
		for _, l := range c {
			b := bit(l)
			r.occurrences[b] = append(r.occurrences[b], ci)
			if b&1 != 0 {
				r.count[ci]++
			}
		}
		if r.count[ci] == 0 {
			r.positions[ci] = len(r.failed)
			r.failed = append(r.failed, ci)
		}
	}
	limit := 16 * n
	for i := 0; i < limit; i++ {
		if len(r.failed) == 0 {
			return r.value, i
		}
		row := r.clauses[r.failed[r.random(len(r.failed))]]
		bestVar, bestBreaks := 0, int(^uint(0)>>1)
		for _, l := range row {
			v := bit(l) / 2
			breaks := 0
			for _, ci := range r.occurrences[r.liveLiteral(v)] {
				if r.count[ci] == 1 {
					breaks++
				}
			}
			if breaks < bestBreaks {
				bestVar, bestBreaks = v, breaks
				if breaks == 0 {
					break
				}
			}
		}
		if bestBreaks > 0 && r.random(4) == 0 {
			bestVar = bit(row[r.random(len(row))]) / 2
		}
		r.flip(bestVar)
	}
	return nil, limit
}

func tryRepair(path string) bool {
	f, err := os.Open(path)
	if err != nil {
		return false
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil || !info.Mode().IsRegular() || info.Size() > 4<<20 {
		return false
	}
	cnf, err := sat.ReadDIMACSCNF(f)
	if err != nil {
		return false
	}
	values, flips := model(cnf)
	fmt.Fprintf(os.Stderr, "repair %d flips sat=%t\n", flips, values != nil)
	if values == nil {
		return false
	}
	out := bufio.NewWriterSize(os.Stdout, 4096)
	fmt.Fprintln(out, "sat")
	var tmp [24]byte
	for i := 1; i < len(values); i++ {
		lit := i
		if !values[i] {
			lit = -lit
		}
		word := strconv.AppendInt(tmp[:0], int64(lit), 10)
		out.Write(append(word, ' '))
	}
	out.WriteByte('\n')
	if err = out.Flush(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	return true
}
func main() {
	for _, a := range os.Args[1:] {
		if strings.HasSuffix(a, ".cnf") && tryRepair(a) {
			return
		}
	}
	p := exec.Command(os.Getenv("G3_BASELINE"), os.Args[1:]...)
	p.Stdout, p.Stderr, p.Stdin = os.Stdout, os.Stderr, os.Stdin
	if err := p.Run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
