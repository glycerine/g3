"""Instrument equivalent native and Go SAT search regions on their calling threads."""
from concurrent.futures import ThreadPoolExecutor
import csv, json, os, re, shlex, subprocess, sys
from pathlib import Path
pkg=Path.cwd()
work=pkg/'build/.nov26-planted-search'
build=pkg.parent/'build'
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache',GOMAXPROCS='1')
labels=('check','propagate','conflict','clean','simplify_problem','simplifier','decision',
        'model','scc','probe','asymm','empty')
sys.path[:0]=[str(pkg/'perf/ivy_raft')]
from watch_propagation import formulas, dimacs, check_output

def insert_once(s, sig, text):
    if s.count(sig)!=1: raise ValueError(sig)
    return s.replace(sig, sig+'\n'+text)

def build_go():
    edits={
        'sat/sat_solver_search.go': [(0, 'func (s *Solver) checkCoreSpan(count uint32, span satSolverLiteralSpan, maxLevel uint32) (lbool.LBool, error) {'),
                                     (4, 'func (s *Solver) simplifyProblem() error {')],
        'sat/sat_solver_propagation.go': [(1, 'func (s *satSolverPropagationState) propagateCore(update bool) (bool, error) {')],
        'sat/sat_solver_conflict_resolution.go': [(2, 'func (s *satSolverConflictResolution) resolveConflict() (bool, error) {')],
        'sat/sat_cleaner.go': [(3, 'func (c *satCleaner) run(force bool) (done bool, err error) {')],
        'sat/sat_simplifier.go': [(5, 'func (s *satSimplifier) Run(learned bool) (err error) {')],
        'sat/sat_solver_model.go': [(7, 'func (s *Solver) mkModel() error {')],
        'sat/sat_scc.go': [(8, 'func (c *satSCC) run() (count uint32, err error) {')],
        'sat/sat_asymm_branch.go': [(10, 'func (a *satAsymmBranch) run(force bool) (err error) {')],
    }
    for file,id,signature in [('sat/sat_solver_decision.go',6,'func .* decide'),('sat/sat_solver_probing_algorithm.go',9,'func .* run')]:
        match=re.search('(?m)^'+signature+r'\([^\n]+', (pkg/file).read_text())
        if match is None: raise ValueError((file,signature))
        edits[file]=[(id,match[0])]
    paths={}
    def save(rel,data):
        file=work/(Path(rel).stem+'-phases.go')
        file.write_bytes(subprocess.check_output(['gofmt'],input=data.encode()))
        paths[str(pkg/rel)]=str(file)
    for rel, changes in edits.items():
        s=(pkg/rel).read_text()
        for id,sig in changes:
            s=insert_once(s,sig,'defer leaveSearchPhase(%d, enterSearchPhase())'%id)
        save(rel,s)
    rel='shell/dimacs_frontend.go'
    s=insert_once((pkg/rel).read_text(), 'if err == nil && status == lbool.Undef {',
                  'sat.BeginSearchObservation()\ndefer sat.EndSearchObservation()')
    save(rel,s)
    save('sat/search_phase_observer.go',(work/'phase-counter.go.txt').read_text())
    overlay=work/'phases-overlay.json'
    overlay.write_text(json.dumps({'Replace':paths}))
    binary=work/'go-phases'
    subprocess.run(['go','build','-p','12','-buildvcs=false','-pgo=off','-overlay='+str(overlay),'-o',binary,'./cmd/g3'],
                   check=True,env=env)
    return binary

def build_cpp():
    cflags=(build/'config.mk').read_text()
    make=(build/'Makefile').read_text()
    def words(name,s):return shlex.split(re.search(r'^'+name+r'\s*=\s*(.*?)\s*$',s,re.M)[1])
    edits={
        'sat/sat_solver.cpp': [(0,'lbool solver::check(unsigned num_lits, literal const* lits) {'),
                               (1,'bool solver::propagate_core(bool update) {'),
                               (2,'bool solver::resolve_conflict() {'),
                               (4,'void solver::simplify_problem() {'),
                               (6,'bool solver::decide() {'),
                               (7,'void solver::mk_model() {')],
        'sat/sat_cleaner.cpp':[(3,'bool cleaner::operator()(bool force) {')],
        'sat/sat_simplifier.cpp':[(5,'void simplifier::operator()(bool learned) {')],
        'shell/dimacs_frontend.cpp':[],
    }
    for file,id,name in [('sat/sat_scc.cpp',8,'operator'),('sat/sat_probing.cpp',9,'operator'),('sat/sat_asymm_branch.cpp',10,'operator')]:
        match=re.search(r'(?m)^ +\w+ \w+::'+name+r'\(\)\([^\n]+', (pkg.parent/'src'/file).read_text())
        if match is None: raise ValueError((file,name))
        edits[file]=[(id,match[0])]
    object_files=[]
    for rel,changes in edits.items():
        s=(pkg.parent/'src'/rel).read_text()
        for id,sig in changes: s=insert_once(s,sig,'phase_scope observed_region(%d);'%id)
        if rel=='shell/dimacs_frontend.cpp':
            s=insert_once(s,'lbool r;','dimacs_search_stats observe;')
        source=work/(Path(rel).stem+'-phases.cpp')
        prelude='#include "phase-counter.h"\n'
        if rel=='shell/dimacs_frontend.cpp':
            prelude+='int g3_phase_fd=-1;\nuint64_t g3_phase_instructions[12]{};\nuint64_t g3_phase_calls[12]{};\n'
        source.write_text(prelude+s)
        obj=source.with_suffix('.o')
        incl=re.search(r'\$\((includes_\d+)\).*\.\./src/'+re.escape(rel)+r'$',make,re.M)[1]
        subprocess.run([*words('CXX',cflags),*words('CXXFLAGS',cflags),*words(incl,make),'-o',obj,source],cwd=build,check=True)
        object_files.append(str(obj))
    commands=[shlex.split(ln) for ln in subprocess.check_output(['make','-n','-W','shell/main.o','z3'],cwd=build,text=True).splitlines()
              if 'shell/main.o' in ln and ' -o z3 ' in ln]
    binary=work/'z3-phases'
    args,=commands
    args[args.index('-o')+1]=str(binary)
    if 'shell/dimacs_frontend.o' in args:
        args.remove('shell/dimacs_frontend.o')
    args[args.index('shell/main.o'):args.index('shell/main.o')]=object_files
    subprocess.run(args,cwd=build,check=True)
    return binary

if __name__=='__main__':
    with ThreadPoolExecutor(2) as pool:
        a,b=pool.submit(build_go),pool.submit(build_cpp)
        engines={'g3':a.result(),'z3':b.result()}
    with (work/'phases.csv').open('w') as f:
        w=csv.writer(f)
        w.writerow(['case','engine','round','phase','calls','instructions','decisions','conflicts'])
        for name,n,clauses,expected in formulas():
            if name not in ('planted3','propagate3','planted8'):
                continue
            path=work/(name+'.cnf')
            path.write_text(dimacs(n,clauses))
            for i in range(1,6):
                for engine in list(engines)[::1 if i%2 else -1]:
                    run=subprocess.run(['taskset','-c','11',engines[engine],'-st','-dimacs',path],capture_output=True,text=True,env=env,check=True)
                    st=check_output(run.stdout,expected,n,clauses)
                    if name=='planted3': assert (st['decisions'],st['conflicts'])==(465,114),st
                    for row in run.stderr.splitlines():
                        marker,phase,calls,inst=row.split()
                        assert marker=='SEARCH-PHASE'
                        w.writerow([name,engine,i,labels[int(phase)],calls,inst,st.get('decisions',0),st.get('conflicts',0)])
                    f.flush()
