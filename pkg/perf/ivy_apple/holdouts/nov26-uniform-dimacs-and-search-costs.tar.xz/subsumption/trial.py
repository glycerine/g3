"""Pass clause views from the subsumption filter to the exact scan."""
import json, os, subprocess, sys
from pathlib import Path
pkg=Path.cwd()
mode=sys.argv[1]
out=pkg/'build/.nov26-planted-search/subsumption'/mode
out.mkdir(parents=True,exist_ok=True)
src=pkg/'sat/sat_solver_simplifier_subsumption.go'
s=src.read_text()
for i in (0,1):
	start=s.index('func (k *satSimplifierKernel) subsumes'+str(i)+'(')
	loc=s.index('\n\tn2 := v2.size()',start)
	args=', out *Literal' if i==1 else ''
	invoke=', out' if i==1 else ''
	s=s[:loc]+f'''
	return k.subsumesBorrowed{i}(c1, nil, v2{invoke})
}}

func (k *satSimplifierKernel) subsumesBorrowed{i}(c1 StoredClauseRef, v1, v2 satClauseView{args}) (bool, error) {{
	var e error'''+s[loc:]
	loc=s.index('\n\tv1, e := k.clauseView(c1)',loc)
	bnd=s.index('\n\tn1 := v1.size()',loc)
	s=s[:loc]+'''
	if v1 == nil {
		v1, e = k.clauseView(c1)
		if e != nil {
			return false, e
		}
	}'''+s[bnd:]
start=s.index('func (k *satSimplifierKernel) candidate')
end=s.index('func (k *satSimplifierKernel) collectSubsumed1Core',start)
s=s[:start]+'''// candidate borrows the two clauses for a local filter and exact scan.
// Cache the source within an occurrence scan. Discard it before publishing
// output, where an allocation-failure transport can reenter the owner.
func (k *satSimplifierKernel) candidate(c1, c2 StoredClauseRef, source *satClauseView) (satClauseView, error) {
	if c2 == c1 {
		return nil, nil
	}
	v1 := *source
	if v1 == nil {
		var e error
		v1, e = k.clauseView(c1)
		if e != nil { return nil, e }
		*source = v1
	}
	n1 := v1.size()
	v2, e := k.clauseView(c2)
	if e != nil {
		return nil, e
	}
	n2 := v2.size()
	if n1 > n2 || !satApproxSet(v1.word(3)).approxSubset(satApproxSet(v2.word(3))) {
		return nil, nil
	}
	k.subCounter = int32(uint32(k.subCounter) - (n1 + n2))
	return v2, nil
}
'''+s[end:]
s=s.replace('for !it.AtEnd() {','var source satClauseView\n\tfor !it.AtEnd() {')
s=s.replace('yes, e := k.candidate(c, c2)','target, e := k.candidate(c, c2, &source)')
for i in (0,1):
	target=', &l' if i==1 else ''
	aux='var l Literal\n\t\t\t' if i==1 else ''
	old=f'if yes {{\n\t\t\t{aux}yes, e = k.subsumes{i}(c, c2{target})'
	new=f'if target != nil {{\n\t\t\t{aux}yes, e := k.subsumesBorrowed{i}(c, source, target{target})'
	assert s.count(old)==1
	s=s.replace(old,new)
s=s.replace('if e = out.Push(c2);','source = nil\n\t\t\t\tif e = out.Push(c2);')
if mode=='views-only':
    s=s.replace('if e = it.Next(); e != nil {','source = nil\n\t\tif e = it.Next(); e != nil {')
elif mode!='cached-source':
    raise ValueError(mode)
obj=out/src.name
obj.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({"Replace":{str(src):str(obj)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
with (out/'tests.log').open('w') as file:
    subprocess.run(['go','test','-p','8','-count=1','-overlay='+str(overlay),'./sat'],env=env,stdout=file,stderr=file,check=True)
subprocess.run(['go','build','-p','8','-buildvcs=false','-overlay='+str(overlay),'-o',out/'g3','./cmd/g3'],env=env,check=True)
