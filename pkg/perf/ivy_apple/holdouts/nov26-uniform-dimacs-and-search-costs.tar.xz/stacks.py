"""Measure actual instruction stacks for the remaining matched SAT search gap."""
from pathlib import Path
from collections import Counter
import csv, gzip, os, subprocess, sys
pkg=Path.cwd()
out=pkg/'build/.nov26-planted-search'
sys.path[:0]=[str(pkg/'perf/ivy_raft'),str(pkg/'perf/ivy_apple')]
from watch_propagation import formulas, dimacs, check_output
from stack_costs import samples

perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
engines={'g3': pkg/'build/.nov26-cnf-profile/attach-production/g3','z3':pkg.parent/'build/z3'}
labels = {
    'propagate': ('propagateCore', 'propagate_core'),
    'add model': ('mkModel','mk_model'),
    'conflict': ('resolveConflict', 'resolve_conflict'),
    'clean': ('satCleaner).run','cleaner::operator()'),
    'subsumption': ('simplifier).subsume','simplifier::subsume', 'SubsumeClauses'),
    'elimination': ('simplifier).elim','simplifier::elim', 'elim_vars'),
    'simplify': ('satSimplifier).Run','satSimplifier).simplify','simplifier::operator()', 'simplifyProblem', 'simplify_problem'),
    'SCC': ('satSCC).run','sat_scc::operator()','scc::operator()'),
    'probe': ('satSolverProbing).run','sat::probing::operator()'),
    'asymmetric branch': ('satAsymmBranch).run','sat::asymm_branch::operator()'),
    'decide': ('satSolverDecision).decide','solver::decide'),
    'ingest': ('ParseDIMACS','parse_dimacs','read_clause<'),
    'print result': ('(*DIMACSFrontend).writeResult','display_model','writeDIMACSModel'),
    'solve': ('checkCoreSpan','sat::solver::check'),
}
def symbolize(stack):
    for f in stack:
        for label,names in labels.items():
            if any(n in f for n in names):
                return label
    return 'other'

with (out/'stacks.csv').open('w') as f:
    w=csv.writer(f)
    w.writerow(['case','engine','round','phase','parent','leaf','samples'])
    for name,n,clauses,expect in formulas():
        if name not in ('planted3','propagate3','planted8'):
            continue
        cnf=out/(name+'.cnf')
        cnf.write_text(dimacs(n,clauses))
        for r in range(1,5):
            for engine in list(engines)[::1 if r%2==1 else -1]:
                target=out/f'{name}-{engine}-{r}'
                data=target.with_suffix('.data')
                trace=target.with_suffix('.gz')
                p=subprocess.run(['taskset','-c','10',perf,'record','--no-buildid','--call-graph','dwarf,8192','-m','2048',
                                  '-e','instructions:u','-c','70001','-o',data,'--',engines[engine],'-st','-dimacs',cnf],
                                 capture_output=True,env=dict(os.environ,GOMAXPROCS='1'),check=True)
                assert b'lost' not in p.stderr.lower() and b'throttl' not in p.stderr.lower(),p.stderr
                stats=check_output(p.stdout.decode(),expect,n,clauses)
                assert name!='planted3' or (stats['decisions'],stats['conflicts'])==(465,114),stats
                p=subprocess.run([perf,'script','--no-inline','-i',data,'-F','event,ip,sym,dso'],capture_output=True,check=True)
                assert b'lost' not in p.stderr.lower(),p.stderr
                with gzip.open(trace,'wb',compresslevel=1) as stream:
                    stream.write(p.stdout)
                c=Counter((symbolize(s),s[1] if len(s)>1 else '',s[0]) for s in samples(trace) if s)
                assert c,trace
                w.writerows((name,engine,r,*k,count) for k,count in sorted(c.items()))
                f.flush()
                data.unlink()
