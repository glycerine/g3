"""Test the stable size order without repeated arena reads in each comparison."""
import json, os, subprocess, sys
from pathlib import Path
pkg=Path.cwd()
out=pkg/'build/.nov26-planted-search/sort'/sys.argv[1]
out.mkdir(parents=True,exist_ok=True)
src=pkg/'sat/sat_asymm_branch_storage.go'
s=src.read_text()
sig='g.scratch = make([]StoredClauseRef, n)'
s=s.replace(sig,'''if g.sortSmallClauseSizes() {
		g.lifecycle.budget.Release(bytes)
		return nil
	}
	'''+sig,1)
if sys.argv[1]=='sorted':
	s+='''
func (g *satAsymmBranch) sortSmallClauseSizes() bool {
	a:=g.lifecycle.propagation.clauses
	previous:=^uint32(0)
	for _,ref:=range g.lifecycle.Original {
		size,err:=a.Size(ref)
		if err!=nil || size>previous {return false}
		previous=size
	}
	return true
}
'''
elif sys.argv[1]=='count':
	s+='''
func (g *satAsymmBranch) sortSmallClauseSizes() bool {
	const maxSize = 64
	clauses := g.lifecycle.Original
	if len(clauses) > 1<<16 {return false}
	a:=g.lifecycle.propagation.clauses
	var counts [maxSize+1]int
	sizes:=make([]uint8,len(clauses))
	previous:=uint32(maxSize)
	sorted:=true
	for i,ref:=range clauses {
		size,err:=a.Size(ref)
		if err!=nil || size>maxSize {return false}
		sorted=sorted && size<=previous
		previous=size
		sizes[i]=uint8(size)
		counts[size]++
	}
	if sorted {return true}
	next:=0
	for size:=maxSize;size>=0;size-- {
		count:=counts[size]
		counts[size]=next
		next+=count
	}
	sortedClauses:=make([]StoredClauseRef,len(clauses))
	for i,size:=range sizes {
		sortedClauses[counts[size]]=clauses[i]
		counts[size]++
	}
	copy(clauses,sortedClauses)
	return true
}
'''
else:
    raise ValueError(sys.argv[1])
obj=out/src.name
obj.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({"Replace": {str(src): str(obj)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
with (out/'tests.log').open('w') as file:
    subprocess.run(['go','test','-p','8','-count=1','-overlay='+str(overlay),'./sat'],env=env,stdout=file,stderr=file,check=True)
subprocess.run(['go','build','-p','8','-buildvcs=false','-overlay='+str(overlay),'-o',out/'g3','./cmd/g3'],env=env,check=True)
