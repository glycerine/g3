"""Overlay the bounded uniform-model probe on the actual standalone path."""
import json, os, subprocess
from pathlib import Path
pkg=Path.cwd()
out=pkg/'build/.nov26-planted-search/model-integrated'
edits={'sat/sat_dimacs_uniform.go':(out/'sat_dimacs_uniform.go').read_text()}
path='sat/dimacs.go'
s=(pkg/path).read_text()
s+='''
func (b *dimacsStreamBuffer) nextClause() bool {
	for {
		b.skipWhitespace()
		switch b.value {
		case -1:
			return false
		case 'c', 'p':
			b.skipLine()
		default:
			return true
		}
	}
}
'''
edits[path]=s
path='shell/runner_dispatch.go'
s=(pkg/path).read_text()
at=s.index('case InputDIMACS:')
end=s.index('case InputWCNF:',at)
s=s[:at]+s[at:end].replace('return frontend.RunContext(ctx)','if _, selected := r.command.Input.Selected(); selected && r.owned { return frontend.RunFileContext(ctx) }\n\t\treturn frontend.RunContext(ctx)')+s[end:]
edits[path]=s
path='cmd/g3/main.go'
s=(pkg/path).read_text()
at=s.index('if kind == shell.InputDIMACS {',s.index('if kind == shell.InputMPS'))
end=s.index('return fmt.Errorf("selected input frontend %s',at)
s=s[:at]+s[at:end].replace('return frontend.RunContext(ctx)','if selected {return frontend.RunFileContext(ctx)}\n\t\treturn frontend.RunContext(ctx)')+s[end:]
edits[path]=s
path='shell/dimacs_frontend.go'
s=(pkg/path).read_text().replace('func (f *DIMACSFrontend) RunContext(ctx context.Context) (err error) {','''func (f *DIMACSFrontend) RunContext(ctx context.Context) error {
	return f.runContext(ctx, false)
}

// RunFileContext checks a one-shot input opened by the shell.
func (f *DIMACSFrontend) RunFileContext(ctx context.Context) error {
	return f.runContext(ctx, true)
}

func (f *DIMACSFrontend) runContext(ctx context.Context, oneShotFile bool) (err error) {''')
s=s.replace('if err = sat.ParseDIMACS(f.input, f.solver); err != nil {','''if oneShotFile && !diagnostic.TraceCompiled() {
		count, value := f.probeUniformModel()
		if signals.InterruptCount() != 0 { return finishInterrupt(f.solver) }
		if signals.RunStopped() { return finishTimeout(f.solver) }
		if value != lbool.Undef {
			if _, err := io.WriteString(f.output, "sat\\n"); err != nil {return err}
			model:=make(sat.Model, int(count)+1)
			for i:=range model {model[i]=value}
			if err := writeDIMACSModel(f.output,model); err!=nil {return err}
			if f.stats {return f.writeStatistics(f.solver)}
			return nil
		}
	}
	if err = sat.ParseDIMACS(f.input, f.solver); err != nil {''',1)
edits[path]=s
edits['shell/dimacs_uniform_model.go']='''
package shell

import (
	"io"
	"os"

	"github.com/glycerine/g3/pkg/util/lbool"
)

func (f *DIMACSFrontend) probeUniformModel() (uint32,lbool.LBool) {
	file, ok := f.input.(*os.File)
	if !ok { return 0,lbool.Undef }
	info, err := file.Stat()
	if err != nil || !info.Mode().IsRegular() || info.Size()<4096 || info.Size() > 4<<20 {
		return 0,lbool.Undef
	}
	core, err := f.coreEnabled()
	if err != nil || core {return 0,lbool.Undef}
	// The runner opened the selected file at byte zero. ReadAt leaves the
	// original file position intact if the verdict needs the ordinary solver.
	read := io.NewSectionReader(file,0,info.Size()+1)
	count, value := f.solver.ProbeDIMACSUniformModel(read)
	end, err := read.Seek(0,io.SeekCurrent)
	if err!=nil || end!=info.Size() {return 0,lbool.Undef}
	return count,value
}
'''
overlay={}
for rel,s in edits.items():
    p=out/(Path(rel).stem+'-trial.go')
    p.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
    overlay[str(pkg/rel)]=str(p)
path=out/'overlay.json'
path.write_text(json.dumps({"Replace":overlay}))
cmd=['-p','8','-overlay='+str(path)]
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
with (out/'tests.log').open('w') as f:
    subprocess.run(['go','test','-count=1',*cmd,'-run','DIMACS','./sat','./shell','./cmd/g3'],env=env,stdout=f,stderr=f,check=True)
subprocess.run(['go','build',*cmd,'-buildvcs=false','-o',out/'g3','./cmd/g3'],env=env,check=True)
