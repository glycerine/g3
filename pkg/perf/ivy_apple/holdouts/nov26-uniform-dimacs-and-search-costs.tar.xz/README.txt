Matched native and Go DIMACS study, Linux amd64, Threadripper 3960X, Go 1.27.3.
Native controls use the build in this fork. Baseline Go SAT code is 6ed5d6e09.
The uniform-model change is 9c85114a1. All controls run with GOMAXPROCS=1.

phases.py, phase-counter.go.txt and phase-counter.h build observer binaries
with this repo's native build flags. See phases.csv for three inputs and
detail/ for the finer decomposition. The phase observations are inclusive
and have 200 empty calibration intervals per execution.
stacks.py and the compressed traces separately sample actual call stacks.
File-based control comparisons use CPU 7 for uniform models and CPU 8 for
model repair. see each runner for its exact options and input mode.
model-integrated/dispatch-inactive.csv is the early experiment before
the CLI's separate DIMACS dispatch called the probe. Final builds use both
one-shot entry points, and recorded models are checked against the original
CNFs on every measured run.
The short sort, duplicate-bins, use-list, and subsumption studies preserve
the exact tested Go overlays. combined/controls.csv uses standard input
for all three engines to expose ordinary search.
The repair and repair-flat studies are standalone, and the repair-integrated
study uses a local overlay for the real CLI. None ships in 9c85114a1.
