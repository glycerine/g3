#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <unistd.h>

extern int g3_phase_fd;
extern uint64_t g3_phase_instructions[18];
extern uint64_t g3_phase_calls[18];

inline uint64_t read_phase_cost() {
    uint64_t data[3];
    if (read(g3_phase_fd, data, sizeof(data)) != sizeof(data) || data[1] != data[2])
        std::abort();
    return data[0];
}

struct phase_scope {
    int id;
    uint64_t start;
    explicit phase_scope(int index):
        id(index), start(g3_phase_fd >= 0 ? read_phase_cost() : 0) {}
    ~phase_scope() {
        if (!start) return;
        g3_phase_instructions[id]+=read_phase_cost()-start;
        ++g3_phase_calls[id];
    }
};

struct dimacs_search_stats {
    dimacs_search_stats() {
        perf_event_attr a{};
        a.size=sizeof(a);
        a.type=PERF_TYPE_HARDWARE;
        a.config=PERF_COUNT_HW_INSTRUCTIONS;
        a.read_format=PERF_FORMAT_TOTAL_TIME_ENABLED | PERF_FORMAT_TOTAL_TIME_RUNNING;
        a.exclude_kernel=1;
        a.exclude_hv=1;
        g3_phase_fd=syscall(SYS_perf_event_open,&a,0,-1,-1,0);
        if (g3_phase_fd<0) std::abort();
        for (int i=0;i<200;++i) {phase_scope s(11);}
    }
    ~dimacs_search_stats() {
        close(g3_phase_fd);
        g3_phase_fd=-1;
        for (uint64_t i=0;i<18;++i)
            std::fprintf(stderr,"SEARCH-PHASE %llu %llu %llu\n",
                         (unsigned long long)i, (unsigned long long)g3_phase_calls[i],
                         (unsigned long long)g3_phase_instructions[i]);
    }
};
