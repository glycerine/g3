"""Integrate the compact model repair as a bounded one-shot probe."""
import json,os,subprocess
from pathlib import Path
pkg=Path.cwd()
work=pkg/'build/.nov26-planted-search/repair-integrated'
base=work.parent/'repair-flat'
edits={}
file='sat/sat_dimacs_uniform.go'
s=(pkg/file).read_text()
signature='func (s *Solver) ProbeDIMACSUniformModel(input io.Reader) (uint32, lbool.LBool) {'
body=s[s.index(signature)+len(signature):s.index('\n\treturn scanDIMACSUniformModel(input, s.Limit)')]
s=s.replace(body,'''\n\tif !s.canProbeDIMACSModel(input) { return 0,lbool.Undef }''',1)
at=s.index('func scanDIMACSUniformModel')
s=s[:at]+'''func (s *Solver) canProbeDIMACSModel(input io.Reader) bool {'''+body.replace('return 0, lbool.Undef','return false')+'''
	return true
}

'''+s[at:]
edits[file]=s
file='sat/dimacs_compact_trial.go'
edits[file]=(base/'parser.go').read_text()
source=(base/'main.go').read_text()
body=source[source.index('type repair struct'):source.index('func tryRepair')]
body=body.replace('sat.CompactDIMACSTrial','CompactDIMACSTrial')
body=body.replace('func model(cnf CompactDIMACSTrial) ([]uint32, int) {','func repairDIMACSModel(cnf CompactDIMACSTrial, limitState *control.Reslimit) ([]uint32, int) {')
body=body.replace('limit := 16 * len(r.value)','limit := 16 * len(r.value)\n\twork := min(25*len(cnf.Words),2000000)')
body=body.replace('for i := 0; i < limit; i++ {','for i := 0; i < limit && work>0; i++ {\n if i%64==0 && limitState.CancelFlag(){ return nil,i }')
body=body.replace('for _, ci := range r.occurrence(live) {','occurrences := r.occurrence(live)\n\t\t\twork -= len(occurrences)+1\n\t\t\tfor _, ci := range occurrences {')
body=body.replace('for _, ci := range r.occurrence(best) {','work -= len(r.occurrence(best))+len(r.occurrence(best^1))+1\n\t\tfor _, ci := range r.occurrence(best) {')
edits['sat/sat_dimacs_repair_probe.go']='''package sat
import (
	"io"
	"github.com/glycerine/g3/pkg/util/control"
	"github.com/glycerine/g3/pkg/util/lbool"
)
'''+body+'''
func (s *Solver) ProbeDIMACSRepair(in io.Reader, size int) Model {
	if !s.canProbeDIMACSModel(in) {return nil}
	cnf, ok:=TrialCompactDIMACS(in,size)
	// Reject empty input and failed scans before admitting model repair.
	if !ok || cnf.Variables==0 || s.Limit.CancelFlag(){return nil}
	words,_:=repairDIMACSModel(cnf,s.Limit)
	if words==nil || s.Limit.CancelFlag(){return nil}
	model:=make(Model,len(words))
	for i,word:=range words {model[i]=lbool.FromBool(word&1==0)}
	return model
}
'''
file='shell/dimacs_uniform_model.go'
s=(pkg/file).read_text().replace('"github.com/glycerine/g3/pkg/util/lbool"','"github.com/glycerine/g3/pkg/util/lbool"\n"github.com/glycerine/g3/pkg/sat"')
s=s.replace('probeUniformModel() (uint32, lbool.LBool)','probeFileModel() sat.Model')
s=s.replace('return 0, lbool.Undef','return nil')
at=s.index('count, value := ')
s=s[:at]+'''count, value := f.solver.ProbeDIMACSUniformModel(read)
	var model sat.Model
	if value != lbool.Undef {
		model=make(sat.Model,int(count)+1)
		for i:=range model {model[i]=value}
	} else if _,err:=read.Seek(0,io.SeekStart); err==nil {
		model=f.solver.ProbeDIMACSRepair(read,int(info.Size()))
	}
	end, err := read.Seek(0, io.SeekCurrent)
	if err != nil || end != info.Size() {
		return nil
	}
	return model
}
'''
edits[file]=s
file='shell/dimacs_frontend.go'
s=(pkg/file).read_text().replace('count, value := f.probeUniformModel()','model := f.probeFileModel()')
start=s.index('if value != lbool.Undef {')
end=s.index('if err := writeDIMACSModel',start)
s=s[:start]+'''if model != nil {
			if err := writeShellText(f.output, "sat\\n"); err != nil {
				return err
			}
			'''+s[end:]
edits[file]=s
overlay={}
for path,source in edits.items():
    f=work/Path(path).name
    f.write_bytes(subprocess.check_output(['gofmt'],input=source.encode()))
    overlay[str(pkg/path)]=str(f)
path=work/'overlay.json'
path.write_text(json.dumps({"Replace":overlay}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
subprocess.run(['go','build','-p','8','-overlay='+str(path),'-buildvcs=false','-o',work/'g3','./cmd/g3'],
               env=env,check=True)
