"""Check bounded model-repair misses on padded standard UNSAT and malformed cases."""
import csv,os,subprocess,sys,time
from pathlib import Path
p=Path.cwd()
out=p/'build/.nov26-planted-search/repair-integrated'
sys.path.insert(0,str(p/'perf/ivy_raft'))
from watch_propagation import formulas,dimacs,check_output

perf = '/usr/lib/linux-tools/6.17.0-35-generic/perf'
pad='c ' + ' '*6000 + '\n'
cases = {name: (pad+dimacs(n,clauses),n,clauses,exp)
         for name,n,clauses,exp in formulas(3) if name in ('pigeon7','pigeon8-s1')}
cases['contradictory-units']=(pad+'p cnf 1 2\n1 0\n-1 0\n',1,[[1],[-1]],'unsat')
cases['malformed']=(pad+'p cnf 3 2\n1 0\n2 -3 x\n',0,[],'error')
engines={'baseline':p/'build/.nov26-planted-search/model-final/g3','repair':out/'g3'}
env=dict(os.environ,GOMAXPROCS='1')
for name,(source,count,clauses,expected) in cases.items():
    (out/(name+'.cnf')).write_text(source)
with (out/'fallback.csv').open('w') as f:
    w=csv.writer(f)
    w.writerow(['case','engine','round','instructions','seconds','answer'])
    for name,(_,count,clauses,expected) in cases.items():
        for r in range(1,10):
            for engine in list(engines)[::1 if r%2 else -1]:
                result=out/f'{name}-{engine}-{r}.perf'
                start=time.monotonic()
                run=subprocess.run(['taskset','-c','9',perf,'stat','-x,','-e','instructions:u',
                                    '-o',result,'--',engines[engine],'-st','-dimacs',out/(name+'.cnf')],
                                   capture_output=True,text=True,env=env)
                seconds=time.monotonic()-start
                if expected=='error':
                    assert run.returncode==3 and 'unexpected char: 120' in run.stderr and not run.stdout.startswith('sat'), run
                else:
                    assert run.returncode==0,run
                    check_output(run.stdout,expected,count,clauses)
                rows=list(csv.reader(result.open()))
                inst,=[int(row[0]) for row in rows if len(row)>=5 and row[2]=='instructions:u']
                result.unlink()
                w.writerow([name,engine,r,inst,f'{seconds:.6f}',expected])
                f.flush()
