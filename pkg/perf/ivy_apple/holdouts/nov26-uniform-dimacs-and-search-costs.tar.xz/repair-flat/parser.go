package sat

import "io"

type CompactDIMACSTrial struct {
	Variables uint32
	Words     []uint32
	Ends      []uint32
}

// TrialCompactDIMACS uses the normal scanner with flat literal storage.
func TrialCompactDIMACS(in io.Reader, bytes int) (result CompactDIMACSTrial, parsed bool) {
	b := newDIMACSStreamBuffer(in)
	defer b.syncShared()
	result.Words = make([]uint32, 0, bytes/4)
	result.Ends = make([]uint32, 0, bytes/20)
	for b.nextClause() {
		for {
			lit, err := b.parseInt()
			if err != nil || lit < -100000 || lit > 100000 {
				return CompactDIMACSTrial{}, false
			}
			if lit == 0 {
				break
			}
			sign := uint32(0)
			if lit < 0 {
				lit = -lit
				sign = 1
			}
			result.Variables = max(result.Variables, uint32(lit))
			result.Words = append(result.Words, uint32(lit)*2+sign)
		}
		result.Ends = append(result.Ends, uint32(len(result.Words)))
	}
	return result, true
}
