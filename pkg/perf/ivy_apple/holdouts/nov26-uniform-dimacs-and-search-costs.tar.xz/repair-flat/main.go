package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"strings"

	"github.com/glycerine/g3/pkg/sat"
)

type repair struct {
	cnf           sat.CompactDIMACSTrial
	value         []uint32 // true literal for each variable
	count         []uint32
	failed        []uint32
	positions     []uint32
	offsets       []uint32
	occurrenceIDs []uint32
	rng           uint32
}

func (r *repair) random(n int) int {
	r.rng ^= r.rng << 13
	r.rng ^= r.rng >> 17
	r.rng ^= r.rng << 5
	return int(r.rng % uint32(n))
}

func (r *repair) occurrence(word uint32) []uint32 {
	return r.occurrenceIDs[r.offsets[word]:r.offsets[word+1]]
}

func (r *repair) bump(clause uint32, delta int32) {
	old := r.count[clause]
	now := old + uint32(delta)
	r.count[clause] = now
	if old == 0 {
		at := r.positions[clause]
		last := r.failed[len(r.failed)-1]
		r.failed[at] = last
		r.positions[last] = at
		r.failed = r.failed[:len(r.failed)-1]
	} else if now == 0 {
		r.positions[clause] = uint32(len(r.failed))
		r.failed = append(r.failed, clause)
	}
}

func (r *repair) clause(id uint32) []uint32 {
	start := uint32(0)
	if id > 0 {
		start = r.cnf.Ends[id-1]
	}
	return r.cnf.Words[start:r.cnf.Ends[id]]
}

func construct(cnf sat.CompactDIMACSTrial) (r repair, ok bool) {
	n := int(cnf.Variables) + 1
	r = repair{
		cnf:       cnf,
		value:     make([]uint32, n),
		count:     make([]uint32, len(cnf.Ends)),
		positions: make([]uint32, len(cnf.Ends)),
		offsets:   make([]uint32, 2*n+1),
		rng:       0x53721aef,
	}
	for i := range r.value {
		r.value[i] = uint32(i)*2 + 1
	}
	for _, lit := range cnf.Words {
		r.offsets[lit+1]++
	}
	for i := 1; i < len(r.offsets); i++ {
		r.offsets[i] += r.offsets[i-1]
	}
	r.occurrenceIDs = make([]uint32, len(cnf.Words))
	next := append([]uint32(nil), r.offsets...)
	for i := range cnf.Ends {
		ci := uint32(i)
		c := r.clause(ci)
		if len(c) == 0 {
			return r, false
		}
		t := uint32(0)
		for _, lit := range c {
			r.occurrenceIDs[next[lit]] = ci
			next[lit]++
			t += lit & 1
		}
		r.count[i] = t
		if t == 0 {
			r.positions[i] = uint32(len(r.failed))
			r.failed = append(r.failed, ci)
		}
	}
	return r, true
}

func (r *repair) validate() bool {
	for i := range r.cnf.Ends {
		satisfied := false
		for _, l := range r.clause(uint32(i)) {
			if r.value[l>>1] == l {
				satisfied = true
				break
			}
		}
		if !satisfied {
			return false
		}
	}
	return true
}

func model(cnf sat.CompactDIMACSTrial) ([]uint32, int) {
	r, ok := construct(cnf)
	if !ok {
		return nil, 0
	}
	limit := 16 * len(r.value)
	for i := 0; i < limit; i++ {
		if len(r.failed) == 0 {
			if !r.validate() {
				panic("repair produced an invalid model")
			}
			return r.value, i
		}
		row := r.clause(r.failed[r.random(len(r.failed))])
		best, score := uint32(0), int(^uint(0)>>1)
		for _, lit := range row {
			live := r.value[lit>>1]
			b := 0
			for _, ci := range r.occurrence(live) {
				if r.count[ci] == 1 {
					b++
				}
			}
			if b < score {
				best, score = live, b
				if b == 0 {
					break
				}
			}
		}
		if score > 0 && r.random(4) == 0 {
			best = r.value[row[r.random(len(row))]>>1]
		}
		for _, ci := range r.occurrence(best) {
			r.bump(ci, -1)
		}
		for _, ci := range r.occurrence(best ^ 1) {
			r.bump(ci, 1)
		}
		r.value[best>>1] ^= 1
	}
	return nil, limit
}
func tryRepair(path string) bool {
	f, err := os.Open(path)
	if err != nil {
		return false
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil || !info.Mode().IsRegular() || info.Size() > 4<<20 {
		return false
	}
	cnf, ok := sat.TrialCompactDIMACS(f, int(info.Size()))
	if !ok {
		return false
	}
	values, flips := model(cnf)
	fmt.Fprintf(os.Stderr, "repair %d flips sat=%t\n", flips, values != nil)
	if values == nil {
		return false
	}
	out := bufio.NewWriterSize(os.Stdout, 4096)
	fmt.Fprintln(out, "sat")
	var tmp [24]byte
	for i := 1; i < len(values); i++ {
		lit := i
		if values[i]&1 != 0 {
			lit = -lit
		}
		word := strconv.AppendInt(tmp[:0], int64(lit), 10)
		out.Write(append(word, ' '))
	}
	out.WriteByte('\n')
	if err = out.Flush(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	return true
}
func main() {
	for _, a := range os.Args[1:] {
		if strings.HasSuffix(a, ".cnf") && tryRepair(a) {
			return
		}
	}
	p := exec.Command(os.Getenv("G3_BASELINE"), os.Args[1:]...)
	p.Stdout, p.Stderr, p.Stdin = os.Stdout, os.Stderr, os.Stdin
	if err := p.Run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
