"""Borrow a clause once during occurrence-list registration and erasure."""
import json, os, subprocess
from pathlib import Path
pkg=Path.cwd()
out=pkg/'build/.nov26-planted-search/use-list'
src=pkg/'sat/sat_solver_clause_use_lists.go'
s=src.read_text()
start=s.index('n, e := u.allocator.Size(c)')
end=s.index('\n\t\tv, e := u.Get(l)',start)
s=s[:start]+'''clause, e := u.allocator.view(c)
	if e != nil { return e }
	if len(clause)<8 { return arena.ErrBounds }
	n := clause.size()
	for i := uint32(0); i < n; i++ {
		l, e := clause.attachmentLiteral(i)
		if e != nil { return e }
		if mode == 2 && l == except { continue }
		if !satStorageSourceDebug {
			index:=l.index()
			if uint64(index) >= uint64(len(u.records)) { return arena.ErrBounds }
			record:=&u.records[index]
			if mode==0 {
				if e=record.insert(c);e!=nil{return e}
			} else {
				record.liveSize--
			}
			continue
		}'''+s[end:]
old='''	if uint64(len(r.payload)) >= uint64(^uint32(0)) {
		return arena.ErrBounds
	}
	r.payload = append(r.payload, c)
	r.liveSize++
	return nil
}'''
assert s.count(old)==1
s=s.replace(old,'''	return r.insert(c)
}
func (r *satClauseUseListRecord) insert(c StoredClauseRef) error {
'''+old,1)
obj=out/src.name
obj.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({"Replace":{str(src):str(obj)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
with (out/'tests.log').open('w') as f:
    subprocess.run(['go','test','-count=1','-overlay='+str(overlay),'./sat'],env=env,stdout=f,stderr=f,check=True)
subprocess.run(['go','build','-buildvcs=false','-overlay='+str(overlay),'-o',out/'g3','./cmd/g3'],env=env,check=True)
