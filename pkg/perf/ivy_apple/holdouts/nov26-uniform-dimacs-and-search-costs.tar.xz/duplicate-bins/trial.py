"""Try bypassing a stable sort and compaction when binary watches are already distinct."""
import json, os, subprocess
from pathlib import Path
pkg=Path.cwd()
out=pkg/'build/.nov26-planted-search/duplicate-bins'
src=pkg/'sat/sat_simplifier_duplicate_bins.go'
s=src.read_text().replace('import "sort"', '''import (
 "sort"
 "github.com/glycerine/g3/pkg/util/diagnostic"
)''')
target='''if e = s.sortBinaryWatches(w); e != nil {'''
s=s.replace(target,'''if !satStorageSourceDebug && !diagnostic.TraceCompiled() {
			it, err := s.watchIterator(w)
			if err != nil { return err }
			if it.backing == nil || uniqueBinaryPrefix(it.backing.data) { continue }
		}
		'''+target,1)
s+='''
// The stable sort leaves nonbinary watches in order. A prefix of already
// unique, ascending binary watches needs neither sorting nor compaction.
func uniqueBinaryPrefix(watches []satWatchWords) bool {
	last := uint32(DefaultLiteral())
	first := true
	nonBinary := false
	for _, w := range watches {
		if w.val2&3 != 0 {
			nonBinary = true
			continue
		}
		if nonBinary || w.val1 == last || !first && w.val1 < last {
			return false
		}
		first = false
		last = w.val1
	}
	return true
}
'''
obj=out/src.name
obj.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
overlay=out/'overlay.json'
overlay.write_text(json.dumps({"Replace":{str(src):str(obj)}}))
env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache')
with (out/'tests.log').open('w') as file:
    subprocess.run(['go','test','-p','6','-count=1','-overlay='+str(overlay),'./sat'],env=env,stdout=file,stderr=file,check=True)
subprocess.run(['go','build','-p','6','-buildvcs=false','-overlay='+str(overlay),'-o',out/'g3','./cmd/g3'],env=env,check=True)
