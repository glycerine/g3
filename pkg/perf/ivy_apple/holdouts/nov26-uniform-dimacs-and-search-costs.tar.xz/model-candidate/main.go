// DIMACS experiment for complete, directly validated monotone assignments.
package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"strings"

	"github.com/glycerine/g3/pkg/sat"
)

func candidateModel(path string) error {
	f, e := os.Open(path)
	if e != nil {
		return e
	}
	defer f.Close()
	info, e := f.Stat()
	if e != nil {
		return e
	}
	if !info.Mode().IsRegular() || info.Size() > 4<<20 {
		return fmt.Errorf("outside experimental input bounds")
	}
	cnf, e := sat.ReadDIMACSCNF(f)
	if e != nil {
		return e
	}
	if cnf.VariableCount > 100000 {
		return fmt.Errorf("outside experimental variable bounds")
	}
	allFalse, allTrue := true, true
	for _, clause := range cnf.Clauses {
		hasPos, hasNeg := false, false
		for _, lit := range clause {
			hasPos = hasPos || lit > 0
			hasNeg = hasNeg || lit < 0
		}
		allTrue = allTrue && hasPos
		allFalse = allFalse && hasNeg
		if !allTrue && !allFalse {
			return fmt.Errorf("candidate failed")
		}
	}
	b := bufio.NewWriterSize(os.Stdout, 4096)
	if _, e := b.WriteString("sat\n"); e != nil {
		return e
	}
	var word [24]byte
	for i := int64(1); i <= int64(cnf.VariableCount); i++ {
		lit := i
		if !allTrue {
			lit = -lit
		}
		tmp := strconv.AppendInt(word[:0], lit, 10)
		tmp = append(tmp, ' ')
		if _, e = b.Write(tmp); e != nil {
			return e
		}
	}
	if e = b.WriteByte('\n'); e != nil {
		return e
	}
	return b.Flush()
}

func main() {
	for _, arg := range os.Args[1:] {
		if strings.HasSuffix(arg, ".cnf") && candidateModel(arg) == nil {
			return
		}
	}
	p := exec.Command(os.Getenv("G3_BASELINE"), os.Args[1:]...)
	p.Stdout, p.Stderr, p.Stdin = os.Stdout, os.Stderr, os.Stdin
	if e := p.Run(); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
