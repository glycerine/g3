from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/release.py').read().decode()
s=s.replace("('base','trial','apple')","('trial','native','apple','apple-native')").replace("name=='apple'","name.startswith('apple')").replace("name=='native'","name.endswith('native')").replace("mode=='apple'","mode.startswith('apple')")
s=s[:s.index(' def measure(')]+"""
 def measure(index,case,rounds):
    path=out/('frontier-'+str(case)+'.csv')
    apple=isinstance(case,str)
    with path.open('a') as f:
        w=csv.writer(f)
        if f.tell()==0:w.writerow(['case','round','engine','instructions','cycles','wall_ms'])
        for i in rounds:
            order=['apple','apple-native'] if apple else ['trial','native']
            if (i+index)%2:order.reverse()
            for mode in order:
                w.writerow([case,i,mode,*run(case,mode,cpus[index%len(cpus)],True)])
                f.flush()
 def phase(cases,rounds):
    with ThreadPoolExecutor(len(cpus)) as pool:
        def group(k):
            for idx,case in cases:
                if idx%len(cpus)==k:measure(idx,case,rounds)
        jobs=[pool.submit(group,k) for k in range(len(cpus))]
        for job in jobs:job.result()
 cases=list(enumerate(range(1,len(names)+1)))
 phase(cases,range(2))
 import statistics as st
 gaps=[]
 for idx,case in cases:
    rows=list(csv.DictReader((out/('frontier-'+str(case)+'.csv')).open()))
    diffs=[]
    for metric in ('instructions','wall_ms'):
        med={k:st.median(float(r[metric]) for r in rows if r['engine']==k) for k in ['trial','native']}
        diffs.append(med['trial']-med['native'])
    gaps.append((*diffs,idx,case))
 top=set()
 for col in (0,1):
    top.update((x[2],x[3]) for x in sorted(gaps,key=lambda x:-x[col])[:12])
 phase(sorted(top),range(2,9))
 phase([(0,'rfn2'),(1,'dramc_nb2')],range(3))
"""
exec(compile(s,'frontier','exec'))
