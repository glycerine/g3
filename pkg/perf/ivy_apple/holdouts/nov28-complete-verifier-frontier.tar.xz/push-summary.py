from pathlib import Path
import csv,collections,sys
root=Path(__file__).resolve().parent
code=(Path('perf/ivy_apple/holdouts/first_push_profile.py')).read_text()
ns={};exec(code[code.index('STAGES ='):code.index('def read',code.index('def classify'))] if 'def read' in code[code.index('def classify'):] else code[code.index('STAGES ='):code.index('def main')],ns)
d=root/'pushstacks';counts=collections.defaultdict(collections.Counter);n=collections.defaultdict(set)
for x in csv.DictReader((d/'stacks.csv').open()):
 k=x['case'],x['engine'];n[k].add(x['round']);stage=ns['classify'](x['stack'].splitlines())[0];counts[k][stage]+=int(x['period'])*int(x['samples'])
for k,v in sorted(counts.items()):print(k,len(n[k]),[(s,round(num/(len(n[k])*1e6),1)) for s,num in v.most_common(6)])
