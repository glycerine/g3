from pathlib import Path
import tarfile
from trial import panel
with tarfile.open('perf/ivy_apple/holdouts/nov27-ground-projection-outcomes.tar.xz') as t:
    a={};exec(t.extractfile('observe.py').read().decode().replace('from driver import panel','').split('if __name__==')[0],a)
    src=t.extractfile('paired.py').read().decode()
    b={'observe_patch':a['patch'],'census':a['run'],'Path':Path};exec(src[src.index('def patch('):src.index('if __name__==')],b)
def run(s):
    s=b['run'](s);a=' for case in [4,8,3,6]:'
    assert a in s
    return s.replace(a,' for case in [7,2,4,3,8,14,15]:')
panel(['base','native'],b['patch'],run)
