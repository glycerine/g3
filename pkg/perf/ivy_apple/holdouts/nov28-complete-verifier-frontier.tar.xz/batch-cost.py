from pathlib import Path
import csv,statistics as st,collections
d=Path(__file__).resolve().parent/'frontier-stages'
with (d/'batch-cost.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['case','engine','batch','concrete_goals','first_goal','first_push','all_push','all_decide','all_prove'])
    for case in [2,3,4,7,8,14,15]:
     for eng in ['base','native']:
        reps=[]
        for src in sorted(d.glob(f'{case}-{eng}-*.csv')):
            buckets=collections.defaultdict(lambda:collections.defaultdict(list))
            for row in csv.DictReader(src.open()):
                if row['op']=='frontend':buckets[int(row['batch'])][row['reason']].append((int(row['goal']),int(row['value'])))
            reps.append(buckets)
        for batch in sorted(set.union(*(set(x) for x in reps))):
            rows=[]
            for rep in reps:
                g=rep[batch]
                first=g['push'][0] if g['push'] else (0,0)
                rows.append([len({n for n,_ in g['decide']}),first[0],first[1],*[sum(v for _,v in g[k]) for k in ['push','decide','proveGoal']]])
            w.writerow([case,eng,batch,*map(st.median,zip(*rows))])
for case in [2,3,4,7,8,14,15]:
    r=[v for v in csv.DictReader((d/'batch-cost.csv').open()) if int(v['case'])==case and v['engine']=='base' and float(v['concrete_goals'])>0]
    for n in [1,3,8]:
        q=[v for v in r if float(v['concrete_goals'])<=n]
        print(case,n,len(q),len(r),*[round(sum(float(x[k]) for x in q)/1e6,1) for k in ['first_push','all_decide']])
