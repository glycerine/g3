import os,csv,statistics as st
from pathlib import Path
d=Path(__file__).resolve().parent/'frontier'
ref=Path(os.environ.get('NNF_REFERENCE','/tmp/g3-reduction-rows'))
names=(ref/'compat.txt').read_text().splitlines() if (ref/'compat.txt').exists() else (d/'compat.txt').read_text().splitlines()
output=[]
for f in sorted(d.glob('frontier-*.csv')):
    key=f.stem.removeprefix('frontier-')
    r=list(csv.DictReader(f.open()))
    r=[x for x in r if x.get('wall_ms') and x['engine']]
    pairs={}
    for x in r:
        pairs.setdefault(int(x['round']),{})['Z3' if x['engine'].endswith('native') else 'g3']=x
    rounds=[v for v in pairs.values() if len(v)==2]
    if not rounds:continue
    line={'case':key,'spec':names[int(key)-1] if key.isdigit() else key,'pairs':len(rounds)}
    for m in ['wall_ms','instructions']:
        for e in ['g3','Z3']:
            line[e+'_'+m]=round(st.median(float(v[e][m]) for v in rounds),3)
        line['excess_'+m]=round(st.median(float(v['g3'][m])-float(v['Z3'][m]) for v in rounds),3)
        line['ratio_'+m]=round(st.median(float(v['g3'][m])/float(v['Z3'][m]) for v in rounds),4)
    output.append(line)
if output:
    with (d/'ranking.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(sorted(output,key=lambda l:-l['excess_instructions']))
    for l in sorted(output,key=lambda l:-l['excess_instructions'])[:12]:
        print(l['case'],l['pairs'],round(l['excess_instructions']/1e6),round(l['excess_wall_ms']),l['ratio_wall_ms'],l['spec'])
    print('at least two pairs',sum(l['pairs']>=2 for l in output),'at least nine',sum(l['pairs']>=9 for l in output))
