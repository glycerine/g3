from pathlib import Path
import csv,statistics as st
from collections import defaultdict
d=Path(__file__).resolve().parent
r=list(csv.DictReader((d/'frontier/ranking.csv').open()))
assert {x['case'] for x in r}==set(str(n) for n in range(1,229))|{'rfn2','dramc_nb2'}
for x in r:
 key=x['case'];rows=list(csv.DictReader((d/'frontier'/('frontier-'+key+'.csv')).open()))
 pairs=defaultdict(list)
 for v in rows:
    assert int(v['instructions'])>0 and float(v['wall_ms'])>0
    pairs[int(v['round'])].append(v['engine'])
 modes=['native','trial'] if key.isdigit() else ['apple','apple-native']
 assert all(sorted(v)==modes for v in pairs.values())
 assert len(pairs)==int(x['pairs']) and (len(pairs) in (2,9) if key.isdigit() else len(pairs)==3)
print(len(r),'workloads',sum(int(x['pairs']) for x in r),'paired runs')
stacks=list(csv.DictReader((d/'pushstacks/stacks.csv').open()))
assert len({(x['case'],x['engine'],x['round']) for x in stacks})==30
for x in stacks:assert int(x['samples'])>0
for e in ['base','native']:
 for i in [0,1]:
    for c in [7,2,4,3,8,14,15]:
        v=list(csv.DictReader((d/'frontier-stages'/f'{c}-{e}-{i}.csv').open()))
        assert any(x['reason']=='push' for x in v) and any(x['reason']=='decide' for x in v)
