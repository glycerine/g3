from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-ticket-cost-and-root-lifetimes.tar.xz') as t:s=t.extractfile('./sample.py').read().decode()
s=s[:s.index("exec(compile(s,'stack-trial'")]
context={}
exec(s,context)
s=context['s']
a=s.index("    marker=b'res, err :=");b=s.index('    mp={}',a)
s=s[:a]+'''    marker=b'if s.opts.Incremental {\\n\\t\\t\\t\\t\\tz3solver.Push()'
    assert bridge.count(marker)==1
    bridge=bridge.replace(marker,b'if s.opts.Incremental {\\n stopCheck:=startStage(batch,index+1);z3solver.Push();stopCheck("push")')
'''+s[b:]
s=s.replace('for case,batch,goal in [(8,12,8),(8,12,16),(8,14,8),(8,13,8)]:','for case,batch,g3goal in [(4,6,1),(2,32,15),(7,6,5),(3,5,2),(8,12,2)]:\n            goal=1 if eng=="z3" else g3goal')
s=s.replace('1500007+i*200','850007+i*200')
exec(compile(s,'pushstacks','exec'))
