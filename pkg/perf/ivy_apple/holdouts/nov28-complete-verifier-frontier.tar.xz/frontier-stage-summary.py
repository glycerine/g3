from pathlib import Path
import csv,statistics as st,collections
d=Path(__file__).resolve().parent/'frontier-stages'
for case in [2,3,4,7,8,14,15]:
    obs={}
    for engine in ['base','native']:
        reps=[]
        for f in sorted(d.glob(f'{case}-{engine}-*.csv')):
            v=collections.Counter()
            for x in csv.DictReader(f.open()):
                if x['op']=='frontend':v[x['reason'],int(x['batch']),int(x['goal'])]+=int(x['value'])
            reps.append(v)
        if reps:obs[engine]={k:st.median(r[k] for r in reps) for k in set.union(*(set(r) for r in reps))}
    if len(obs)!=2:continue
    delta=collections.Counter({k:(obs['base'].get(k,0)-obs['native'].get(k,0))/1e6 for k in set(obs['base'])|set(obs['native'])})
    for label in ['proveGoal','push','decide']:
        totals=[sum(v for k,v in obs[e].items() if k[0]==label)/1e6 for e in ['base','native']]
        print(case,label,*[round(x,1) for x in totals],[(k[1:],round(v,1)) for k,v in delta.most_common() if k[0]==label][:3])
