package api

import (
	"testing"
	"unsafe"
)

func TestStudyRecentSize(t *testing.T) {
	t.Logf("recentRefutations=%d", unsafe.Sizeof(recentRefutations{}))
}
