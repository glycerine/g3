from common import *
import private_policies as pp,macro_identity as mi,stage_frontier as sf,holdouts as ho
root=d/'finite-subset-trials';root.mkdir(exist_ok=True)
ap=pkg/'api';od=ap/'internal/order';af=ap/'api_order_abstraction.go';gn=ap/'api_verification_goal.go';bv=ap/'api_order_boolean.go';rel=od/'relax.go'
def edits(v,observer=False):
 es=pp.edits('ematch') if v.startswith('ematch') else {}
 if v=='control':return es
 es[rel]=once(rel.read_text(),'unbounded          bool','unbounded bool\n trialFiniteModel bool')
 x='if _, ok := t.widths[sort]; !ok {'
 es[rel]=once(es[rel],x,'''if t.trialFiniteModel {if _,ok:=t.widths[sort];!ok{yes,e:=t.m.IsUninterpretedSort(sort);if e!=nil{return 0,e};if !yes{return 0,inapplicable};t.widths[sort]=1};id:=domainID(len(t.parents));t.parents=append(t.parents,id);t.domainSorts=append(t.domainSorts,sort);return id,nil}
 '''+x)
 es[od/'subset_model_trial.go']='''package order
import "github.com/glycerine/g3/pkg/ast"
// Encode every selected source formula with exactly two elements per uninterpreted sort.
// Only a successful SAT assignment can make a private refutation unnecessary.
func TrialTwoModel(m *ast.ASTManager,src []ast.ASTHandle,steps uint32)(*BooleanProblem,error){
 b,e:=m.MkBoolSort();if e!=nil{return nil,e}
 t:=inference{m:m,boolSort:b,bvFamily:ast.NullFamilyID,trialFiniteModel:true,widths:make(map[ast.ASTHandle]uint32),declIDs:make(map[ast.ASTHandle]int32),numerals:make(map[ast.ASTHandle]int32)}
 for _,h:=range src{id,e:=t.read(h,0);if e==inapplicable{return nil,nil};if e!=nil{return nil,e};if t.terms[id].domain!=boolean{return nil,nil};t.assertions=append(t.assertions,id)}
 if !t.quantified||len(t.widths)==0||t.visits>int(steps){return nil,nil}
 p,e:=t.booleanProblem(steps-uint32(t.visits));if e==inapplicable{return nil,nil};return p,e
}
'''
 es[af]=once(es.get(af,af.read_text()),'type orderProofState struct {','type orderProofState struct {\n trialModel *bool')
 s=once(bv.read_text(),'type orderBooleanSolver struct {','type orderBooleanSolver struct {\n trialModel *bool')
 s=once(s,'b := p.bits\n','b:=p.bits;b.trialModel=p.trialModel\n')
 s=once(s,'if len(k.Clauses) == 0 {','if len(k.Clauses) == 0 {if b.trialModel!=nil{*b.trialModel=true};')
 s=once(s,'answer, err := b.solver.Check([]sat.Literal{disabled.Negated()})','answer, err := b.solver.Check([]sat.Literal{disabled.Negated()});if b.trialModel!=nil && err==nil && answer==lbool.True{*b.trialModel=true}')
 es[bv]=s+'''
func(p *orderProofState)trialSatisfiable(m *ast.ASTManager,src []ast.ASTHandle,steps uint32)(bool,error){
 k,e:=order.TrialTwoModel(m,src,steps);if k==nil||e!=nil{return false,e}
 yes:=false;probe:=orderProofState{source:p.source,trialModel:&yes};_,e=probe.checkBoolean(m,k,steps);e=errors.Join(e,probe.release());return yes&&e==nil&&!m.ResourceLimit().CancelFlag(),e
}
'''
 s=gn.read_text();x='return p.checkProofPlan(m, &shortPremisePlan{source: assertions, selected: input}, steps)'
 guard='steps==100000' if 'wide'in v else 'true';steps='30000' if '30'in v else '200000'
 code='if '+guard+' {yes,e:=p.trialSatisfiable(m,input,'+steps+');if e!=nil{return false,e};if yes{return false,nil}}'
 if observer:
  s=once(s,'import "github.com/glycerine/g3/pkg/ast"','import ("fmt";"os";"github.com/glycerine/g3/pkg/ast")')
  code=code.replace('if yes{return false,nil}','if yes{fmt.Fprintln(os.Stderr,"FINITE-HIT",steps,len(input));old,e:=p.checkProofPlan(m,&shortPremisePlan{source:assertions,selected:input},steps);if old||e!=nil{panic("model contradicted by proof")};return false,nil}')
 es[gn]=once(s,x,code+'\n'+x)
 return es
def mk(v,observer=False):
 if v=='control':return d/'production-connected/checker/goivy_check'
 rd=root/(v+('-audit'if observer else ''));o=overlay(rd/'overlay',edits(v,observer));b=build(rd/'checker',o=o);(rd/'build-info.txt').write_text(linked(b));return b
def main():
 vs=['control','wide30','wide200','all30','all200','ematch-wide200'];ho.root=root
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 js=[j for j in sf.jobs() if j[1]in ('tlb','ticket_protocol','hybrid','arm_rules3','alternating_bit_protocol','test_liveness2','flash2','hermes_rmw_o3','cubicle')];js +=[(c,*j[1:5],j[-1])for c,j in zip([2,4,8,10],(j for j in mi.jobs()if j[1]in ('rfn2','cf_live','raftok','toy-consensus')))]
 with ThreadPoolExecutor(12)as ex:list(ex.map(lambda j:ho.measure_spec(j,bs,3),js))
if __name__=='__main__':main()
