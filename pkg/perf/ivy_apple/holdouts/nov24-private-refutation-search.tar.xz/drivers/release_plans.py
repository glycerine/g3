from common import *
import holdouts as ho,macro_identity as mi,stage_frontier as sf,ground_release_controls as gc,binder_exits as binder
root=d/'production-plans';root.mkdir(exist_ok=True);before=d/'production-connected/checker/goivy_check'
files=['api_order_abstraction.go','api_proof_plan_context.go','api_enumeration_refutation.go','api_raft_order_scopes_benchmark_test.go','api_order_instance_test.go']
def previous():
 es={}
 for n in files:
  p=pkg/'api'/n
  es[p]=subprocess.check_output(['git','show','2fdeac3be:pkg/api/'+n],cwd=pkg,text=True)
 return overlay(root/'prior-api',es)
def tests(tags):
 dst=root/('focused-'+(tags or 'default')+'.log')
 with(w/'build.lock').open('a')as f,dst.open('w')as out:
  fcntl.flock(f,fcntl.LOCK_SH);args=['go','test','-count=1','-p','4']+(['-tags='+tags]if tags else[])+['./api','-run','Test(TicketPrivatePlans|VerificationPlans|VerificationDefinitionSelection|OrderProofTemporaryGoal|ShortPremises|OrderAbstraction|Witness|Enumeration)']
  p=subprocess.run(args,cwd=pkg,env=env,stdout=out,stderr=out)
 print('focused',tags,p.returncode,flush=True);assert not p.returncode,dst
def bench(o):
 for v,ol in [('prior',o),('production',None)]:
  with(w/'build.lock').open('a')as f,(root/(v+'-bench-build.log')).open('w')as out:
   fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-c','-p','3','-o',root/(v+'.test'),*(['-overlay='+str(ol)]if ol else[]),'./api'],cwd=pkg,stdout=out,stderr=out)
 for i in range(5):
  for v in (['prior','production'] if i%2==0 else ['production','prior']):
   with(root/(v+'.bench')).open('a')as out:run(['taskset','-c','39',root/(v+'.test'),'-test.run=^$','-test.bench=^BenchmarkTicketPrivatePlans$','-test.benchtime=10x','-test.count=1'],cwd=pkg/'api',stdout=out,stderr=out,env=dict(env,GOMAXPROCS='1'))
 print('bench complete',flush=True)
def audit():
 with ThreadPoolExecutor(5)as ex:
  jobs=[ex.submit(tests,t)for t in ['', 'g3debug','g3checked']]+[ex.submit(bench,previous()),ex.submit(build,root/'checker')]
  b=jobs[-1].result()
  (root/'build-info.txt').write_text(linked(b))
  for f in jobs:f.result()
 return b
def main():
 b=audit();bins={'prior':before,'production':b,'native':native};ho.root=root;gc.d=root
 js=ho.jobs()+[(c,*j[1:5],j[-1])for c,j in zip([2,5,8,11,14,17,19],(j for j in mi.jobs()if j[1]in ('tlb','raftok','rfn2','dramc_nb2','cf_live','hybrid_reliable_broadcast_cisa','toy-consensus')))];ns={j[1]for j in js};js += [j for j in sf.jobs()if j[1]not in ns]
 with ThreadPoolExecutor(12)as ex:
  fs=[ex.submit(ho.measure_spec,j,bins,3)for j in js]+[ex.submit(gc.corpus,b)]
  for f in fs:f.result()
if __name__=='__main__':main()
