from common import *
import macro_identity as mi,holdouts as ho,stage_frontier as sf
root=d/'private-policies';root.mkdir(exist_ok=True)
q=pkg/'api/api_order_abstraction.go';pc=pkg/'api/api_proof_plan_context.go';rel=pkg/'api/api_verification_goal.go'
cases={'ematch':['params.SetBool("smt.mbqi", false)'],'one-model':['params.SetUInt("smt.mbqi.max_iterations", 1)'],'four-models':['params.SetUInt("smt.mbqi.max_iterations", 4)'],'no-macros':['params.SetBool("smt.macro_finder", false)'],'rel1':['params.SetUInt("smt.relevancy", 1)'],'ematch-rel1':['params.SetUInt("smt.relevancy", 1)','params.SetBool("smt.mbqi", false)'],'no-wide':[],'wide12k':[]}
def edits(v):
 if v=='control':return {}
 if v in ('no-wide','wide12k'):
  s=rel.read_text()
  if v=='no-wide':
   i=s.index('if yes, err := check(defs.selectRows(m, symbols, true)');j=s.index('var subset',i);s=s[:i]+s[j:]
  else:s=once(s,'symbols, true), 100000','symbols, true), 12000')
  return {rel:s}
 s=once(q.read_text(),'type orderProofState struct {','type orderProofState struct {\n privatePlansTrial bool')
 s=once(s,'return p.child.SetParameters(params)','if p.privatePlansTrial {\n'+'\n'.join('if err:='+a+';err!=nil{return err}'for a in cases[v])+'\n};return p.child.SetParameters(params)')
 t=once(pc.read_text(),'&orderProofState{source: source}','&orderProofState{source:source,privatePlansTrial:true}')
 return {q:s,pc:t}
def mk(v):
 if v=='control':return d/'production-connected/checker/goivy_check'
 sub=root/v;sub.mkdir(exist_ok=True);o=overlay(sub/'overlay',edits(v));b=build(sub/'checker',o=o);(sub/'build-info.txt').write_text(linked(b))
 return b
def main():
 vs=['control',*cases];ho.root=root
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 js=[j for j in sf.jobs() if j[1]not in ('cubicle','SCP_problem_simplified','flash_example')];js += [(k,*j[1:5],j[-1])for k,j in zip([3,6,9,15],(j for j in mi.jobs()if j[1]in ('raftok','rfn2','cf_live','toy-consensus')))]
 with ThreadPoolExecutor(11)as ex:list(ex.map(lambda j:ho.measure_spec(j,bs,3),js))
if __name__=='__main__':main()
