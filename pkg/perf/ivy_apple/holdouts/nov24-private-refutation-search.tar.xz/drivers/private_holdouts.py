from common import *
import holdouts as ho,ground_release_controls as gc
root=d/'private-holdouts';root.mkdir(exist_ok=True)
vs={'control':d/'production-connected/checker/goivy_check',**{v:d/'private-policies'/v/'checker/goivy_check'for v in ['ematch','no-wide','wide12k']}}
ho.root=root;gc.d=root
with ThreadPoolExecutor(5)as ex:
 tasks=[ex.submit(ho.measure_spec,(c,*j[1:]),vs,2)for c,j in zip([3,7,11],ho.jobs()[:3])];tasks.append(ex.submit(gc.corpus,vs['ematch']))
 for f in tasks:f.result()
