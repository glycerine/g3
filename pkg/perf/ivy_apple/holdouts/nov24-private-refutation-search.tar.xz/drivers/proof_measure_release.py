from common import *
import stage_frontier as sf,macro_identity as mi,binder_exits as binder
from types import SimpleNamespace
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
import private_plan_cost as pc,rotating_verification as rv
from panel import measure,EVENTS
root=d/'proof-measure-release';root.mkdir(exist_ok=True);binary=d/'production-plans/checker/goivy_check'
def obs():
 j=next(j for j in sf.jobs() if j[1]=='ticket_protocol');path=root/'cost'
 with(w/'build.lock').open('a')as lk,(root/'cost.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run([sys.executable,pc.__file__,'--goivy',ivy,'--spec',examples/j[2],'--reference',j[-1],'--cpu','18','--rounds','2','--capture-inputs','--abc',prior/'spec-survey/with-abc-native/abc','--output',path],stdout=f,stderr=f)
 for n in [1,2]:
  g=list(csv.DictReader(gzip.open(path/str(n)/'plans.csv.gz','rt')));e=list(csv.DictReader(gzip.open(d/'plan-inputs/ticket_protocol'/f'{n}-ematch/plans.csv.gz','rt')))
  compare=lambda xs:[tuple(r[k]for k in ['batch','goal','ordinal','kind','selected','proved','verdict','used'])for r in xs]
  assert compare(g)==compare(e)
 print('portable exact',flush=True)
def trace():
 rd=root/'trace';rd.mkdir(exist_ok=True);sd=rd/'checker';sd.mkdir(exist_ok=True)
 b=sd/'goivy_check'
 with(w/'build.lock').open('a')as f,(sd/'build.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-mod=readonly','-modfile='+str(w/'local-checkout.mod'),'-o',b,'./cmd/goivy_check'],cwd=ivy,stdout=log,stderr=log)
 (sd/'build-info.txt').write_text(linked(b));(sd/'abc').exists() or (sd/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc');binder.root=rd;binder.trace({'before-trace':d/'production-connected/trace/checker/goivy_check','after-trace':b});print('trace ok',flush=True)
def quiet(n,sp,iso,rc,ref):
 vs={'prior':d/'production-connected/checker/goivy_check','production':binary,'native':native};rd=root/n;rd.mkdir();rs=0;tries=0
 with(rd/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['round','attempt','engine','cpu','before','sibling','occupancy','match','wall','user','sys','rss',*EVENTS])
  while rs<7 and tries<100:
   ids=list(range(48));a=rv.ticks(ids);time.sleep(3);b=rv.ticks(ids);candidates=range(1 if n=='ticket_protocol'else 2,24,2);idle={c:min(rv.idle(a,b,c),rv.idle(a,b,c+24))for c in candidates};c=max(idle,key=idle.get)
   if idle[c]<.95:time.sleep(4);continue
   tries+=1;keys=list(vs);ok=True
   for v in keys[rs%3:]+keys[:rs%3]:
    target=rd/f'{rs+1}-{tries}-{v}';cfg=SimpleNamespace(cpu=c,perf=perf,spec=examples/sp,isolate=iso)
    x=rv.ticks([c,c+24]);ret,t,cts=measure(vs[v],cfg,target,rc,100);y=rv.ticks([c,c+24]);sib=rv.idle(x,y,c+24);occ=(float(t[1])+float(t[2]))/float(t[0]);match=ret==rc and all((target/k).read_bytes()==(ref/k).read_bytes()for k in ('stdout','stderr'));assert match
    z.writerow([rs+1,tries,v,c,idle[c],sib,occ,int(match),*t,*cts]);f.flush()
    if min(sib,occ)<.95:ok=False;break
   if ok:rs+=1
   print('quiet',n,tries,rs,flush=True)
  assert rs==7
if __name__=='__main__':
 jobs=[j[1:]for j in sf.jobs()if j[1]=='ticket_protocol']+[(*j[1:5],j[-1])for j in mi.jobs()if j[1]=='cf_live']
 with ThreadPoolExecutor(4)as ex:
  fs=[ex.submit(quiet,*j)for j in jobs]+[ex.submit(obs),ex.submit(trace)]
  for f in fs:f.result()
