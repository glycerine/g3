from common import *
from statistics import median
root=d/'stage-frontier'
def groups(path,fn):
 out=defaultdict(list)
 for f in sorted(path.glob(fn)):
  for r in csv.DictReader(gzip.open(f,'rt')):out[int(r['batch']),int(r.get('condition',r.get('goal')))].append(r)
 return out
def analyze(n,report=True):
 r=root/'outer/runs'/n;eng=['g3','native']
 for e in eng:
  if not (r/f'1-{e}/phases.csv.gz').is_file():return
 a,b=(groups(r,f'1-{e}/phases.csv.gz')for e in eng)
 inner=groups(root/'inner'/n,'1-g3/checks.csv.gz');priv=groups(root/'private'/n,'1/private.csv.gz');rows=[];stages=defaultdict(Counter);parts=defaultdict(Counter)
 for coord,ls in a.items():
  phase={r['stage']:int(r['instructions']) for r in ls};native={r['stage']:int(r['instructions'])for r in b.get(coord,[])}
  if 'check' not in native and 'early'not in phase:continue
  lane='early-hit'if 'early'in phase and 'check'not in phase else 'early-miss'if 'early'in phase else 'physical'
  pieces=priv.get(coord,[])
  for piece in pieces:
   for k,v in piece.items():
    if k not in ['batch','goal','stage','ordinal','early']and v:parts[(lane,piece['stage'])][k]+=int(v)
  p=stages[lane];p['n']+=1;p.update({x:phase.get(x,0)for x in ['early','check','push','pop','assert']});p['Z3']+=sum(native.get(x,0) for x in ['check','push','pop','assert'])
  for z in inner.get(coord,[]):p['concrete']+=int(z['solver']);p['late-proof']+=int(z['proof'])
  rows.append((sum(phase.get(x,0)-native.get(x,0)for x in ['early','check','push','pop','assert']),coord,lane,parts))
 if report:
  print(n, [(k,dict((p,round(v/1e9,3)if p!='n'else v)for p,v in s.items()))for k,s in stages.items()])
  print(' top',[(round(k/1e9,3),p,l)for k,p,l,_ in sorted(rows,key=lambda x:-x[0])[:4]])
  if priv:print(' private',[(l,[(k,round(v/1e9,3))for k,v in s.most_common(6)])for l,s in parts.items()])
if __name__=='__main__':
 for p in sorted((root/'outer/runs').iterdir()):analyze(p.name)
