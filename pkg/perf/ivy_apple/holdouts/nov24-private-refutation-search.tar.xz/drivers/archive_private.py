from common import *
import io,tarfile
rd=d/'production-plans';od=d/'private-plan-report';od.mkdir(exist_ok=True)
def emit(n,cols,ls):
 with(od/n).open('w') as f:z=csv.writer(f);z.writerow(cols);z.writerows(ls)
def summarize():
 proc=[]
 for p in sorted(rd.glob('*/runs.csv')):
  rows=readcsv(p)
  if len(rows)!=9:continue
  assert all(r['match']=='1'for r in rows)
  proc.append([p.parent.name,*(median(int(r['instructions:u'])for r in rows if r['engine']==v)for v in ['prior','production','native'])])
 emit('production.csv',['spec','previous_g3','release_g3','linked_z3'],proc)
 ps=[]
 for p in sorted((d/'plan-inputs').glob('*/*/plans.csv.gz')):
  if not p.parent.name[0].isdigit():continue
  groups=defaultdict(list);i,en=p.parent.name.split('-')
  for r in csv.DictReader(gzip.open(p,'rt')):groups[r['kind'],r['proved'],r['verdict']].append(r)
  for key,rs in sorted(groups.items()):ps.append([p.parent.parent.name,i,en,*key,len(rs),*[sum(int(r[k])for r in rs)for k in ['total','setup','assertion','check']]])
 emit('private-search.csv','spec round engine plan proved decision count total setup assertion check'.split(),ps)
 corpus=sorted([r for p in (rd/'corpus').glob('*.csv')for r in readcsv(p)],key=lambda r:int(r['index']))
 assert len(corpus)==228 and all(r['stdout']==r['stderr']=='1'and r['timeout']=='0'for r in corpus)
 emit('corpus.csv',corpus[0].keys(),[list(r.values())for r in corpus])
def main():
 summarize();dst=pkg/'perf/ivy_apple/holdouts/nov24-private-refutation-search.tar.xz'
 with tarfile.open(dst,'w:xz',preset=3)as ar:
  def put(n,b):
   h=tarfile.TarInfo(str(n));h.size=len(b);ar.addfile(h,io.BytesIO(b))
  def tree(path,pats,tag):
   files=set(p for pat in pats for p in path.glob(pat)if p.is_file())
   for p in sorted(files):put(tag+'/'+str(p.relative_to(path)),p.read_bytes())
  put('README.txt',b'''GoIvy 3d552b46c. Production compares g3 d9d52ea74 and b7caff4fa with the native Z3 linked by the same frontend. See PERF_STUDY.md for workload and resource semantics. Whole-checker measurements are pinned, single-worker runs with GOGC=100. The five allocations benchmark samples use ten iterations each. Every verifier row checks the expected exit and both output streams. summary/production.csv lists only cases having all three rotations of all three engines. corpus rows with ok=0 are expected verification failures. Timing on a shared host can be noisy. The nested instrumentation and captures are separate from production runs and measure instructions retired on the solver thread only. The wide optional plan is short-100000; per helper, only verdict -1 establishes a proof. A result of 1 is SAT on a subset of the full assertions, and 0 denotes inconclusive. The observed assertion and check columns are components of total. Their instrumentation and serialization add overhead. Two observer runs on ticket from the portable CLI independently matched goal, stage selection, solver steps and proof return. Each SMT capture ends in a check-sat on the selected premises only. These witnesses come from the local public example corpus. The stage census, policy and restricted-model trials are separate exploratory runs. In particular, UNSAT on a restricted domain cannot establish unrestricted unsatisfiability. Source-instrumentation scripts under drivers refer to the original temporary directories and supplement the portable holdouts/private_plan_cost.py and api.BenchmarkTicketPrivatePlans in the source tree.''')
  tree(d/'private-plan-wall',['*/runs.csv'],'timing');tree(d,['timed_policy.py','report_private.py'],'drivers')
  tree(od,['*.csv'],'summary');tree(rd,['*.bench','focused-*.log','build-info.txt'],'production')
  for p in sorted(rd.glob('*/runs.csv')):
   rs=readcsv(p)
   if len(rs)==9 and all(r['match']=='1'for r in rs):put('production/'+str(p.relative_to(rd)),p.read_bytes())
  tree(d/'plan-inputs',['*/*/plans.csv.gz','*/1-control/*.smt2.gz','*/build-info.txt'],'observed')
  tree(d/'proof-measure-release',['cost/*/plans.csv.gz','cost/build/build-info.txt','cost.log','trace/trace.csv','trace/paxos.txt'],'reproduction')
  tree(d/'subset-models',['*/results.csv'],'finite-models')
  for n in ['private-policies','finite-subset-trials','private-holdouts']:tree(d/n,['*/runs.csv','*/build-info.txt'],n)
  tree(d/'stage-frontier',['outer/runs/*/1-*/phases.csv.gz','inner/*/1-g3-stats/checks.csv.gz','inner/*/1-native-stats/checks.csv.gz','private/*/1/private.csv.gz'],'stage-census')
  tree(d,['stage_frontier.py','analyze_frontier.py','plan_inputs.py','private_policies.py','finite_subset_trials.py','private_holdouts.py','subset_models.py','release_plans.py','archive_private.py','proof_measure_release.py'],'drivers')
 print(dst,dst.stat().st_size,flush=True)
if __name__=='__main__':main()
