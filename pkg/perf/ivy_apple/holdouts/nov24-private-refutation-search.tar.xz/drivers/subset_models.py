from common import *
import itertools
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));from batch_prefix_replay import parse,smt,standard_declarations
root=d/'subset-models';root.mkdir(exist_ok=True)
def finite(script,width):
 forms=parse(script);toks=set(re.findall(r'[^()\s]+',script));out=[];num=0;domains={}
 # This fork prints both a nullary and an applied declaration with the same
 # name. Rename only nullary uses, respecting simultaneous let and binder scope.
 declarations=defaultdict(list)
 for cmd in forms:
  if cmd[0]=='declare-fun':declarations[cmd[1]].append(cmd)
 renames={name:'__subsetNullary'+str(i)for i,(name,ds)in enumerate(declarations.items())if len(ds)>1 and sum(not a[2]for a in ds)==1}
 assert not toks.intersection(renames.values())
 def term(x,bound):
  if isinstance(x,str):return x if x in bound else renames.get(x,x)
  if not x:return x
  h,*args=x
  if h in ('forall','exists','lambda'):return(h,args[0],term(args[1],bound.union(k for k,_ in args[0])))
  if h=='let':return(h,tuple((k,term(v,bound))for k,v in args[0]),term(args[1],bound.union(k for k,_ in args[0])))
  if h=='as'and len(args)==2:return(h,renames.get(args[0],args[0]),args[1])
  if h=='!':
   out=[h,term(args[0],bound)]
   for k,v in zip(args[1::2],args[2::2]):out.extend((k,tuple(term(t,bound)for t in v)if k==':pattern'else term(v,bound)if k==':no-pattern'else v))
   return tuple(out)
  return (h,*(term(t,bound)for t in args))
 for cmd in forms:
  if cmd[0]=='declare-fun' and not cmd[2] and cmd[1]in renames:out.append((cmd[0],renames[cmd[1]],*cmd[2:]))
  elif cmd[0]=='assert':out.append(('assert',term(cmd[1],set())))
  elif width and cmd[0]=='declare-sort' and cmd[2]=='0':
   h=cmd[1];xs=[]
   for k in range(width):
    name=f'__g3Subset{num}_{k}';assert name not in toks;xs.append(name)
   domains[h]=tuple(xs);out.append(('declare-datatype',h,tuple((x,)for x in xs)));num+=1
  else:out.append(cmd)
 return '\n'.join(smt(c)for c in out)+'\n'
def lane(task):
 cpu,n,td=task;rd=root/n;rd.mkdir(exist_ok=True);meta={int(r['ordinal']):r for r in csv.DictReader(gzip.open(td/'plans.csv.gz','rt'))};fns=sorted(td.glob('*.smt2.gz'))
 with(rd/'results.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['ordinal','kind','batch','goal','original_plan','plan_instructions','width','answer','rlimit','instances','seconds'])
  for file in sorted(fns,key=lambda p:-int(meta[int(p.name[:5])]['check'])):
   oid=int(file.name[:5]);r=meta[oid];src=standard_declarations(gzip.open(file,'rt').read())
   for width in [0,1,2,3]:
    if width>=2 and r['kind']!='short-100000':continue
    s=finite(src,width);start=time.perf_counter();p=subprocess.run(['taskset','-c',str(cpu),pkg.parent/'build/z3','-st','-in','-smt2','rlimit=300000'],input=s.encode(),cwd=rd,capture_output=True,timeout=12);tm=time.perf_counter()-start;ls=p.stdout.decode().splitlines()
    assert p.returncode==0 and ls and ls[0]in ('sat','unsat','unknown') and not p.stderr,(file,width,ls[:4],p.stderr[-200:]);ans=ls[0];stats=dict(re.findall(r':([\w-]+)\s+(\d+)\b',p.stdout.decode()))
    if ans=='sat':assert r['proved']=='false',(file,width,ans)
    if width==0 and ans=='unsat':assert r['verdict']!='1',file
    z.writerow([oid,r['kind'],r['batch'],r['goal'],r['verdict'],r['check'],width,ans,stats.get('rlimit-count',0),stats.get('quant-instantiations',0),round(tm,5)]);f.flush()
 print(n,len(fns),flush=True)
if __name__=='__main__':
 names=['ticket_protocol','hybrid','cf_live','rfn2','alternating_bit_protocol','arm_rules3','cubicle','test_liveness2','flash2','raftok'];ts=[(c,n,d/'plan-inputs'/n/'1-control')for c,n in zip([1,3,5,7,9,11,13,15,17,19],names)]
 with ThreadPoolExecutor(8)as ex:list(ex.map(lane,ts))
