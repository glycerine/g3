from common import *
import stage_frontier as sf,private_policies as pp,macro_identity as mi
root=d/'plan-inputs';root.mkdir(exist_ok=True);q=pkg/'api/api_goal_instances_check.go';bridge=ivy.resolve()/'z3bridge_solver_model.go'
def make(v):
 ed=pp.edits('ematch') if v=='ematch' else {}
 qw=root.parent/'stage-frontier/private/overlay/z3bridge_solver_model.go';ed[bridge]=qw.read_text()
 rw=pkg/'api/api_verification_goal.go';s=rw.read_text()
 s=once(s,'return p.checkProofPlan(m, &shortPremisePlan{source: assertions, selected: input}, steps)','return p.checkProofPlan(m, &shortPremisePlan{source: assertions, selected: input,trialKind:steps}, steps)');ed[rw]=s
 sh=pkg/'api/api_short_premises.go';ed[sh]=once(sh.read_text(),'type shortPremisePlan struct {','type shortPremisePlan struct {\n trialKind uint32')
 s=q.read_text();x='aux, err := p.plans.acquire';i=s.index(x);s=s[:i]+'''trialCount++;trialN:=trialCount
 kind:="other";num:=0;var selected []ast.ASTHandle
 switch z:=plan.(type){case *shortPremisePlan:kind=fmt.Sprintf("short-%d",z.trialKind);num=len(z.selected);selected=z.selected;case *witnessInstancePlan:kind="witness";num=len(z.assertions);case *goalInstancePlan:kind="ground";num=len(z.ground)}
 var measures [4]uint64;var used uint64;verdict:=0
 start:=trialPlanStart();defer func(){end:=trialPlanRead();trialPlanClose();fmt.Fprintln(os.Stderr,"PLAN",trialN,kind,num,maxSteps,used,proved,verdict,end-start,measures)
 if os.Getenv("PLAN_CAPTURE")!="" && (kind=="short-100000" || kind=="short-6000" || kind=="short-5000") && len(selected)>0{
 ctx:=SMTContext{smtContextState:p.source.owner}
 data,e:=ctx.BenchmarkSMT2(selected[len(selected)-1],APIBenchmarkConfig{Assumptions:selected[:len(selected)-1]});if e!=nil{panic(e)}
 f,e:=os.Create(fmt.Sprintf("%05d-%s-%t.smt2.gz",trialN,kind,proved));if e!=nil{panic(e)};z:=gzip.NewWriter(f);if _,e=z.Write([]byte(data));e!=nil{panic(e)};if e=z.Close();e!=nil{panic(e)};if e=f.Close();e!=nil{panic(e)}
 }}()
 '''+s[i:]
 s=once(s,'m, err := aux.ctx.Manager()','measures[0]=trialPlanRead()-start; m, err := aux.ctx.Manager()')
 s=once(s,'complete, err := plan.assertIn(parent, m, aux.child)','xx:=trialPlanRead();u0:=limit.Count();defer func(){used=limit.Count()-u0}();complete,err:=plan.assertIn(parent,m,aux.child);measures[1]=trialPlanRead()-xx')
 s=once(s,'answer, err := aux.child.Check()','xx=trialPlanRead();answer,err:=aux.child.Check();measures[2]=trialPlanRead()-xx;verdict=int(answer)')
 s=once(s,'import (','import (\n"os";"fmt";"compress/gzip"');ed[q]=s
 fn=(w/'plan-cost/overlay/plan_cost_observer.go').read_text();a=fn.index('func beginPlanCost()');b=fn.index('\na := readCounter()',a)if '\na := readCounter()'in fn[a:] else fn.index('\n\ta := readCounter()',a)
 f=fn[:b].replace('beginPlanCost()','trialPlanStart()').replace('readCounter()','trialPlanRead()').replace('"fmt"','').replace('"os"','')
 ed[pkg/'api/plan_meter.go']=f+'\n return trialPlanRead()\n}\nvar trialCount int\nfunc trialPlanClose(){syscall.Close(int(fd));runtime.UnlockOSThread()}\n'
 od=root/v;b=build(od/'checker',o=overlay(od/'overlay',ed));(od/'build-info.txt').write_text(linked(b));return b
def jobs():
 ls=[j for j in sf.jobs()if j[1]in ('ticket_protocol','alternating_bit_protocol','arm_rules3','hybrid','flash2','hermes_rmw_o3','tlb','cubicle','test_liveness2')]
 return ls+[(k,*j[1:5],j[-1])for k,j in zip([4,6,8,10],(j for j in mi.jobs()if j[1]in ('rfn2','cf_live','raftok','dramc_nb2')))]
def lane(j,bs):
 c,n,sp,iso,rc,ref=j
 for i in range(2):
  for v,b in list(bs.items())[::1 if i==0 else -1]:
   rd=root/n/f'{i+1}-{v}';rd.mkdir(parents=True);save=(i==0 and v=='control' and n not in ('tlb','dramc_nb2','hermes_rmw_o3'))
   p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else []),examples/sp],cwd=rd,env=dict(env,GOMAXPROCS='1',PLAN_CAPTURE='1'if save else''),capture_output=True);goal=(0,0,'none');other=bytearray()
   with gzip.open(rd/'plans.csv.gz','wt')as out:
    z=csv.writer(out);z.writerow('batch goal stage ordinal kind selected limit used proved verdict total setup assertion check unused'.split())
    for line in p.stderr.splitlines(keepends=True):
     if line.startswith(b'QUERY '):_,bid,g,kind=line.decode().split();goal=(bid,g,kind)
     elif line.startswith(b'PLAN '):z.writerow([*goal,*[s.strip('[]')for s in line.decode().split()[1:]]])
     else:other.extend(line)
   assert p.returncode==rc and tuple((ref/k).read_bytes()for k in ['stdout','stderr'])==(p.stdout,other),(n,v,p.returncode,other[-200:])
   (rd/'validated').write_text('matched\n');print(n,i+1,v,flush=True)
def main():
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(['control','ematch'],ex.map(make,['control','ematch'])))
 with ThreadPoolExecutor(10)as ex:list(ex.map(lambda j:lane(j,bs),jobs()))
if __name__=='__main__':main()
