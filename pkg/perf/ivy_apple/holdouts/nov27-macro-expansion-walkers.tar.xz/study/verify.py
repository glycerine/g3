"""Compare an applied release prototype's complete output with native."""
from pathlib import Path
import concurrent.futures,csv,os,shutil,subprocess,sys,tempfile
ref=Path(os.environ['NNF_REFERENCE']);examples=Path(os.environ['IVY_EXAMPLES'])
names=(ref/'compat.txt').read_text().splitlines()
with (ref/'ranking.csv').open() as f:codes={r['case']:int(r['exit']) for r in csv.DictReader(f)}
cpus=os.environ['CPUS'].split(',')
with tempfile.TemporaryDirectory() as temp:
    d=Path(temp);exe=d/'goivy_check';shutil.copy(sys.argv[1],exe)
    (d/'abc').symlink_to(Path(os.environ['ABC']).resolve(strict=True))
    def run(i):
        name=names[i-1];gold=ref/'compat'/str(i)/'1/native'
        work=d/str(i);work.mkdir()
        r=subprocess.run(['taskset','-c',cpus[i%len(cpus)],exe,examples/name],cwd=work,capture_output=True,timeout=240,env=dict(os.environ,WALK_MODE='recycle',GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
        assert (r.returncode,r.stdout,r.stderr)==(codes[name],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(i,r.returncode,r.stderr[:800])
        return [i,r.returncode,'match']
    with concurrent.futures.ThreadPoolExecutor(len(cpus)) as pool,(Path(os.environ['RESULTS'])/'applied.csv').open('w') as f:
        out=csv.writer(f);out.writerow(['case','exit','transcript'])
        for row in pool.map(run,range(1,len(names)+1)):out.writerow(row);f.flush()
