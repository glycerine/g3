"""Run whole-process release measurements with the uninstrumented walker."""
from pathlib import Path
import csv,json,os,subprocess,tarfile,tempfile
here=Path(__file__).resolve().parent
pkg=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
ref=Path(os.environ['NNF_REFERENCE']);examples=Path(os.environ['IVY_EXAMPLES'])
names=(ref/'compat.txt').read_text().splitlines()
with (ref/'ranking.csv').open() as f:codes={r['case']:int(r['exit']) for r in csv.DictReader(f)}
with tempfile.TemporaryDirectory() as td:
    d=Path(td)
    with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t:t.extractall(d,filter='data')
    src=d/'study/release-sources'
    cases=[4,2,6,3,8,10,1,227,228]
    modes=['base','adaptive']
    for mode in ['recycle']:
        rep={str(front/name):str(src/source) for name,source in [('z3bridge_solver_model.go','regular.go.txt'),('z3bridge_guarded_equalities.go','regular-guards.go.txt')]}
        def overlay(path,code):
            target=d/(mode+'-'+path.name);target.write_text(code);rep[str(path)]=str(target)
        if mode!='base':
            path=pkg/'smtcore/smt_kernel.go';s=path.read_text().replace('import (','import ("os";',1)
            key='k.simplifyInitialPushOnce = false\n\tk.skipRepeatedPreprocessing = true'
            assert s.count(key)==1
            overlay(path,s.replace(key,key+'\n k.assertedMacros.ResetWalkTrial(k.reduceWalkOK())\n defer func(){ k.assertedMacros.StudyWalk=false }()')+'''
var studyWalkEnabled=os.Getenv("WALK_MODE")=="adaptive"
func(k *SMTKernel) reduceWalkOK()bool{return studyWalkEnabled && !ast.ASTValidateHandles && !diagnostic.TraceCompiled() && !k.manager.NumeralService().RuntimeOwner().AllocationLimited()}
''')
            path=pkg/'ast/macros/macro_manager.go';overlay(path,path.read_text().replace('type Manager struct {','type Manager struct {\n StudyWalk bool; studyPlan planTrial'))
            path=pkg/'ast/macros/macro_expander.go';s=path.read_text();i=s.index('func (m *Manager) expandMacrosStep(')
            key='cfg := &macroExpanderConfig{owner: m}'
            assert s.count(key)==1
            s=s.replace(key,'''if !proofs && m.StudyWalk {
                root,e:=m.manager.RefGet(oldTerm);if e!=nil{panic(e)}
                if m.applyStudyPlan(root,out) {
                    v,e:=m.manager.RefGet(out);if e!=nil{panic(e)};if v==root{break}
                    if e=m.manager.AssignRef(oldTerm,out);e!=nil{panic(e)}
                    changed=true;continue
                }
            }
            '''+key);overlay(path,s)
            s=(here/'sparse/walker.go.txt').read_text()
            s=s[:s.index('var walkClock')]+s[s.index('type walkOp'):]
            s+='''
func(m *Manager) applyStudyPlan(t ast.ASTHandle,out ast.ASTRef)bool{
    p:=planTrial{owner:m}
    if _,ok:=p.compile(t,make(map[ast.ASTHandle]int));!ok{return false}
    cfg:=macroExpanderConfig{owner:m}
    v:=t;var pins []ast.ASTRef;if len(p.ops)!=0{v,pins=p.execute(&cfg)}
    if !m.manager.ResourceLimit().TryIncOffset(max(uint32(1),2*p.frames)){panic("bounded trial")}
    if e:=m.manager.SetRef(out,v);e!=nil{panic(e)}
    for i:=len(pins)-1;i>=0;i-- {if e:=m.manager.DelRef(&pins[i]);e!=nil{panic(e)}}
    if e:=cfg.close();e!=nil{panic(e)};return true
}
'''
            s=s.replace('owner *Manager','owner *Manager\n values []ast.ASTHandle\n pins []ast.ASTRef\n scopes []map[ast.ASTHandle]int')
            s=s.replace('compile(t ast.ASTHandle,cache map[ast.ASTHandle]int)','compile(t ast.ASTHandle,depth int)').replace('p.visits++;','cache:=p.scopes[depth];p.visits++;')
            s=s.replace('childCache:=cache','childDepth:=depth').replace('childCache=make(map[ast.ASTHandle]int)','childDepth++;p.resetScope(childDepth)').replace('p.compile(arg,childCache)','p.compile(arg,childDepth)')
            s=s.replace('p:=planTrial{owner:m}','p:=&m.studyPlan;p.owner=m;p.frames=0;p.visits=0;p.ops=p.ops[:0];p.children=p.children[:0];p.resetScope(0)').replace('p.compile(t,make(map[ast.ASTHandle]int))','p.compile(t,0)')
            s=s.replace('values:=make([]ast.ASTHandle,len(p.ops))','if cap(p.values)<len(p.ops){p.values=make([]ast.ASTHandle,len(p.ops))};values:=p.values[:len(p.ops)]')
            s=s.replace('var pins []ast.ASTRef\n    for i,op','pins:=p.pins[:0]\n    for i,op').replace('return values[len(values)-1],pins','p.pins=pins;return values[len(values)-1],pins')
            s+='\nfunc(p *planTrial) resetScope(depth int){if depth==len(p.scopes){p.scopes=append(p.scopes,make(map[ast.ASTHandle]int))}else{clear(p.scopes[depth])}}\n'
            s=s.replace('owner *Manager\n','owner *Manager\n accepted,rejected int\n',1)
            s=s.replace('if _,ok:=p.compile(t,0);!ok{return false}','''if _,ok:=p.compile(t,0);!ok{p.rejected++;if p.rejected>=8 && p.rejected>p.accepted {m.StudyWalk=false};return false};p.accepted++''')
            s+='\nfunc(m *Manager) ResetWalkTrial(enable bool){m.StudyWalk=enable;m.studyPlan.accepted=0;m.studyPlan.rejected=0}\n'
            overlay(pkg/'ast/macros/trial_walk.go',s)
        o=d/'overlay.json';o.write_text(json.dumps({'Replace':rep}))
        subprocess.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',os.environ['GOIVY_MODFILE'],'-overlay',o,'-o',d/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=str(d/'cache'),GOTMPDIR=td),check=True)
    with (Path(os.environ['RESULTS'])/'process.csv').open('w') as f:
        out=csv.writer(f);out.writerow(['case','round','mode','instructions','exit'])
        for case in cases:
            name=names[case-1];gold=ref/'compat'/str(case)/'1/native'
            for i in range(7):
                for mode in modes[i%len(modes):]+modes[:i%len(modes)]:
                    r=subprocess.run(['taskset','-c',os.environ['CPU'],os.environ.get('PERF','perf'),'stat','-x,','-e','instructions:u','-o',d/'stat','--',d/'recycle',examples/name],cwd=d,capture_output=True,timeout=240,env=dict(os.environ,GOGC='100',WALK_MODE=mode,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
                    assert (r.returncode,r.stdout,r.stderr)==(codes[name],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(case,mode,r.stderr[:1200])
                    rows=[r for r in csv.reader((d/'stat').read_text().splitlines()) if len(r)>4 and r[2]=='instructions:u' and float(r[4])==100]
                    assert len(rows)==1
                    out.writerow([case,i,mode,int(rows[0][0]),r.returncode]);f.flush()
