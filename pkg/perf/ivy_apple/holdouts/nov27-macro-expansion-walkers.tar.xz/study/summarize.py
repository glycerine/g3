"""Compute medians after summing all selected pushes in each complete process."""
from pathlib import Path
import collections,csv,statistics
w=Path(__file__).resolve().parent
def read(name):
    with (w/name).open() as f:return list(csv.DictReader(f))
cases=(2,4,6,3,8,227)
with (w/'stages-summary.csv').open('w') as f:
    out=csv.writer(f)
    cols=['accepted','changed','fallback','wrong_expr','wrong_steps','generic_accepted','generic_fallback','walker_accepted','walker_fallback','push_ins']
    out.writerow(['implementation','case','batches','mode',*cols])
    for variant,path in [('recursive','walk.csv'),('plan','plan/walk.csv')]:
        rows=read(path)
        for case in cases:
            for focus in (['all','31-33'] if case==2 else ['all']):
                for mode in sorted({x['mode'] for x in rows}):
                    selection=[x for x in rows if x['case']==str(case) and x['mode']==mode and (focus=='all' or x['batch'] in ('31','32','33'))]
                    assert {int(x['round']) for x in selection}=={0,1,2}
                    out.writerow([variant,case,focus,mode,*[statistics.median(sum(int(x[k]) for x in selection if int(x['round'])==i) for i in range(3)) for k in cols]])
with (w/'process-summary.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['experiment','case','mode','base','candidate','percent_change'])
    for variant,path in [('dense','process.csv'),('sparse','sparse/process.csv')]:
        rows=read(path)
        for case in sorted({int(x['case']) for x in rows}):
            for mode in sorted({x['mode'] for x in rows}-{'base'}):
                def med(engine):
                    selected=[x for x in rows if int(x['case'])==case and x['mode']==engine]
                    assert {int(x['round']) for x in selected}=={0,1,2}
                    return statistics.median(int(x['instructions']) for x in selected)
                a,b=med('base'),med(mode);out.writerow([variant,case,mode,a,b,100*(b/a-1)])
with (w/'paired.csv').open('w') as f:
    out=csv.writer(f);out.writerow(['experiment','case','rounds','paired_median_change_percent','pairs_faster'])
    for exp,mode,rounds in [('recycle','recycle',3),('toggle','recycle',7),('adaptive','adaptive',7)]:
        rows=read(exp+'/process.csv')
        for case in sorted({int(x['case']) for x in rows}):
            pairs={}
            for x in rows:
                if int(x['case'])==case:pairs.setdefault(int(x['round']),{})[x['mode']]=int(x['instructions'])
            assert set(pairs)==set(range(rounds))
            delta=[100*(v[mode]/v['base']-1) for v in pairs.values()]
            out.writerow([exp,case,rounds,statistics.median(delta),sum(n<0 for n in delta)])
