"""Run whole-process release measurements with the uninstrumented walker."""
from pathlib import Path
import csv,json,os,subprocess,tarfile,tempfile
here=Path(__file__).resolve().parent
pkg=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
ref=Path(os.environ['NNF_REFERENCE']);examples=Path(os.environ['IVY_EXAMPLES'])
names=(ref/'compat.txt').read_text().splitlines()
with (ref/'ranking.csv').open() as f:codes={r['case']:int(r['exit']) for r in csv.DictReader(f)}
with tempfile.TemporaryDirectory() as td:
    d=Path(td)
    with tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t:t.extractall(d,filter='data')
    src=d/'study/release-sources'
    cases=[2,4,6,3,8,5,9,10,11,12,1,227]
    modes=['base','sparse']
    for mode in modes:
        rep={str(front/name):str(src/source) for name,source in [('z3bridge_solver_model.go','regular.go.txt'),('z3bridge_guarded_equalities.go','regular-guards.go.txt')]}
        def overlay(path,code):
            target=d/(mode+'-'+path.name);target.write_text(code);rep[str(path)]=str(target)
        if mode!='base':
            path=pkg/'smtcore/smt_kernel.go';s=path.read_text()
            key='k.simplifyInitialPushOnce = false\n\tk.skipRepeatedPreprocessing = true'
            assert s.count(key)==1
            overlay(path,s.replace(key,key+'\n k.assertedMacros.StudyWalk = k.reduceWalkOK()\n defer func(){ k.assertedMacros.StudyWalk=false }()')+'''
func(k *SMTKernel) reduceWalkOK()bool{return !ast.ASTValidateHandles && !diagnostic.TraceCompiled() && !k.manager.NumeralService().RuntimeOwner().AllocationLimited()}
''')
            path=pkg/'ast/macros/macro_manager.go';overlay(path,path.read_text().replace('type Manager struct {','type Manager struct {\n StudyWalk bool'))
            path=pkg/'ast/macros/macro_expander.go';s=path.read_text();i=s.index('func (m *Manager) expandMacrosStep(')
            s=s[:i]+s[i:].replace('if proofs {','''if !proofs && m.StudyWalk && m.applyStudyPlan(old,out) {
                    // output published by plan
                } else if proofs {''',1);overlay(path,s)
            s=(here/'sparse/walker.go.txt').read_text()
            s=s[:s.index('var walkClock')]+s[s.index('type walkOp'):]
            s+='''
func(m *Manager) applyStudyPlan(t ast.ASTHandle,out ast.ASTRef)bool{
    p:=planTrial{owner:m}
    if _,ok:=p.compile(t,make(map[ast.ASTHandle]int));!ok{return false}
    cfg:=macroExpanderConfig{owner:m}
    v:=t;var pins []ast.ASTRef;if len(p.ops)!=0{v,pins=p.execute(&cfg)}
    if !m.manager.ResourceLimit().TryIncOffset(max(uint32(1),2*p.frames)){panic("bounded trial")}
    if e:=m.manager.SetRef(out,v);e!=nil{panic(e)}
    for i:=len(pins)-1;i>=0;i-- {if e:=m.manager.DelRef(&pins[i]);e!=nil{panic(e)}}
    if e:=cfg.close();e!=nil{panic(e)};return true
}
'''
            if mode=='sparse':
                s=s.replace('p:=planTrial{owner:m}','var ops [48]walkOp;var edges [64]int;p:=planTrial{owner:m,ops:ops[:0],children:edges[:0]}')
                s=s.replace('values:=make([]ast.ASTHandle,len(p.ops))','var local [48]ast.ASTHandle;var values []ast.ASTHandle;if len(p.ops)>len(local){values=make([]ast.ASTHandle,len(p.ops))}else{values=local[:len(p.ops)]}')
            overlay(pkg/'ast/macros/trial_walk.go',s)
        o=d/'overlay.json';o.write_text(json.dumps({'Replace':rep}))
        subprocess.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',os.environ['GOIVY_MODFILE'],'-overlay',o,'-o',d/mode,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=str(d/'cache'),GOTMPDIR=td),check=True)
    with (Path(os.environ['RESULTS'])/'process.csv').open('w') as f:
        out=csv.writer(f);out.writerow(['case','round','mode','instructions','exit'])
        for case in cases:
            name=names[case-1];gold=ref/'compat'/str(case)/'1/native'
            for i in range(3):
                for mode in modes[i%len(modes):]+modes[:i%len(modes)]:
                    r=subprocess.run(['taskset','-c',os.environ['CPU'],os.environ.get('PERF','perf'),'stat','-x,','-e','instructions:u','-o',d/'stat','--',d/mode,examples/name],cwd=d,capture_output=True,timeout=240,env=dict(os.environ,GOGC='100',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
                    assert (r.returncode,r.stdout,r.stderr)==(codes[name],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(case,mode,r.stderr[:1200])
                    rows=[r for r in csv.reader((d/'stat').read_text().splitlines()) if len(r)>4 and r[2]=='instructions:u' and float(r[4])==100]
                    assert len(rows)==1
                    out.writerow([case,i,mode,int(rows[0][0]),r.returncode]);f.flush()
