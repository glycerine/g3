from pathlib import Path
import csv,json,os,subprocess,sys
w=Path(__file__).resolve().parent;old=w.parent/'g3-clause-confirmation';p=Path.cwd();b=(p/'build/.boolean-enode-cost').resolve();f=b/'frontend/goivy';files=json.loads((old/'observer.json').read_text())['Replace']
def save(k,s):
 dst=w/('intervention-'+k.name);dst.write_text(s);files[str(k)]=files[str(k.resolve())]=str(dst)
k=f/'phase_observer_trial.go';s=Path(files[str(k)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";')
a='start := time.Now()';assert s.count(a)==1
s=s.replace(a,'''smtcore.TrialSplit=0
if os.Getenv("TRIAL_FORCE")=="1" {
 if batch==31 && goal==34{smtcore.TrialSplit=91}
 if batch==11 && goal==5{smtcore.TrialSplit=41}
}
smtcore.TrialCountdown=3
'''+a)
a='elapsed := time.Since(start)';s=s.replace(a,a+'; if phase=="check" && smtcore.TrialSplit!=0 {panic("missed intervention")};smtcore.TrialSplit=0');save(k,s)
k=p/'smtcore/smt_activity_heap_queue.go';s=k.read_text();a='return q.state.popBasicActivityHeap()';assert s.count(a)==1
s=s.replace(a,'''if TrialSplit!=0{
 TrialCountdown--
 if TrialCountdown==0 {
 v:=TrialSplit;TrialSplit=0;value,err:=q.state.Assignment(NewSMTLiteral(v,false))
 if err!=nil || value!=lbool.Undef || !h.Contains(v){panic("ineligible trial split")}
 return v,lbool.Undef,h.Erase(v)
 }
}
'''+a);save(k,s+'\nvar TrialSplit,TrialCountdown int32\n')
ov=w/'intervention.json';ov.write_text(json.dumps({'Replace':files}));exe=w/'intervention'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',b/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=f,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');gold=p/'build/.bool-scan/golden/reference/hybrid';out=(w/'intervention.csv').open('w');wr=csv.writer(out);wr.writerow(['round','force','batch','goal','phase','instructions'])
for rnd in range(5):
 for force in [rnd%2,1-rnd%2]:
  r=subprocess.run(['taskset','-c','14',exe,ex/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',TRIAL_FORCE=str(force),XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True)
  keep=[];seen=set()
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'STAGE-COUNT '):
    _,bat,g,ph,ins,empty,en,run,ns=line.decode().split();assert en==run and int(run)>0 and (bat,g,ph) not in seen;seen.add((bat,g,ph));wr.writerow([rnd+1,force,bat,g,ph,ins])
   else:keep.append(line)
  if r.returncode:sys.exit(b''.join(keep)[-12000:].decode())
  assert len([x for x in seen if x[2]=='check'])==534 and r.stdout==(gold/'stdout').read_bytes() and b''.join(keep)==(gold/'stderr').read_bytes()
  out.flush()
