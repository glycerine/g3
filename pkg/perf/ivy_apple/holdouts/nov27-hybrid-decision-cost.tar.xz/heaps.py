from pathlib import Path
import csv,json,os,re,shlex,shutil,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();b=(p/'build/.boolean-enode-cost').resolve();f=b/'frontend/goivy';n=(p/'build/.witness-origin/search-native').resolve()
e=sys.argv[1];files=json.loads((w/('all-'+e+'.json')).read_text())['Replace']
def save(k,s):
 dst=w/(e+'-heap-'+k.name);dst.write_text(s);files[str(k)]=files[str(k.resolve())]=str(dst)
def sub(s,a,z):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
k=f/'phase_observer_trial.go';s=Path(files[str(k)]).read_text();save(k,sub(s,'if target { os.Setenv','if target { os.Setenv("WT_STEP","0"); os.Setenv'))
if e=='g3':
 k=p/'smtcore/smt_case_split_queue.go';s=k.read_text();s=sub(s,'import (','import ("os"; "strconv";')
 a='next, preferred, err := q.selectVariable()'
 s=sub(s,a,'''if witnessTrace() {
 step,_:=strconv.Atoi(os.Getenv("WT_STEP"));step++;os.Setenv("WT_STEP",strconv.Itoa(step))
 if step<=3 {
 println("WT strat",q.strategy)
 for i,expr:=range q.state.boolExpr {v:=int32(i);if i==0{continue};val,err:=q.state.Assignment(NewSMTLiteral(v,false));if err!=nil{panic(err)};println("WT var",i,int(val),strconv.FormatFloat(q.state.activity[i],'g',17,64),witnessTree(q.state.manager,expr))}
 for idx,h:=range []*uheap.Int{q.state.basicActivity,q.state.delayedActivity}{if h!=nil{vals,_:=h.AppendValues(nil);for pos,v:=range vals{println("WT heap",idx,pos,v)}}}
 }
 }
 '''+a)
 s=sub(s,'if int(q.state.random.Next()) >= threshold','draw:=int(q.state.random.Next());if witnessTrace() && len(os.Getenv("WT_STEP"))==1 {println("WT draw",draw,threshold)};if draw >= threshold')
 s=sub(s,'import ("os";','import (uheap "github.com/glycerine/g3/pkg/util/heap";"os";')
 save(k,s)
else:
 build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l);inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1]);lib=w/'libheap.a';shutil.copyfile(w/'liball.a',lib)
 for unit in ['smt_context','smt_case_split_queue']:
  k=p.parent/'src/smt'/(unit+'.cpp')
  if unit=='smt_context':
   s=(w/k.name).read_text();a='m_case_split_queue->next_case_split(var, phase);'
   s=sub(s,a,'''if(active()) {int step=atoi(getenv("WT_STEP"))+1;setenv("WT_STEP",std::to_string(step).c_str(),1);if(step<=3)for(unsigned v=0;v<get_num_b_internalized();++v){std::ostringstream o;shape(o,bool_var2expr(v));fprintf(stderr,"WT var %u %d %.17g %s\\n",v,int(get_assignment(v)),get_activity(v),o.str().c_str());}}
'''+a)
  else:
   s=(n/'qi_queue.cpp').read_text().split('/*++')[0]+k.read_text();a='if (m_context.get_random_value() < static_cast<int>(m_params.m_random_var_freq * random_gen::max_value()))'
   i=s.index(a);s=s[:i]+s[i:].replace(a,'''auto draw=m_context.get_random_value();if(active() && atoi(getenv("WT_STEP"))<=9){fprintf(stderr,"WT draw %d %d\\n",draw,int(m_params.m_random_var_freq*random_gen::max_value()));if(atoi(getenv("WT_STEP"))<=3){unsigned i=0;for(unsigned v:m_queue)fprintf(stderr,"WT heap 0 %u %u\\n",i++,v);}} if (draw < static_cast<int>(m_params.m_random_var_freq * random_gen::max_value()))''',1)
   a='act_case_split_queue::next_case_split(next, phase);';i=s.index(a);s=s[:i]+s[i:].replace(a,'''if(active() && atoi(getenv("WT_STEP"))<=3){unsigned i=0;for(unsigned v:m_delayed_queue)fprintf(stderr,"WT heap 1 %u %u\\n",i++,v);}'''+a,1)
  dst=w/('heap-'+k.name);dst.write_text(s);obj=w/(unit+'.o');subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,dst],cwd=build,check=True);subprocess.run(['ar','r',lib,obj],check=True)
 k=f/'smt/quantifier.go';save(k,Path(files[str(k)]).read_text().replace(str(w/'liball.a'),str(lib)))
source=(w/'observe.py').read_text().split("ov=w/(e+'.json')",1)[1].replace("binary=w/e","binary=w/('heap-'+e)").replace("w/(e+'.csv')","w/('heap-'+e+'.csv')")
ov=w/('heap-'+e+'.json');exec("ov=ov"+source)
