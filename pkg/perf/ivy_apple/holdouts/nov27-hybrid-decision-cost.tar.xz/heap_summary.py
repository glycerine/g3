import csv,re
from pathlib import Path
w=Path(__file__).resolve().parent
def read(file,batch):
 return [(r['event'],r['value']) for r in csv.DictReader((w/file).open()) if r['batch']==batch]
for batch in ['31','11']:
 obs=[]
 for e in ['g3','z3']:
  a=read('heap-'+e+'.csv',batch)
  assert [(k,v) for k,v in a if k not in {'heap','strat','draw','var'}]==read('all-'+e+'.csv',batch)
  s=[i for i,r in enumerate(a) if r[0]=='split'][:3];cur=[]
  for lo,hi in zip([-1]+s[:2],s):
   rows=a[lo+1:hi+1];var={};h=[[],[]];draw=[]
   for k,v in rows:
    if k=='var':
     i,val,act,expr=v.split(' ',3);var[int(i)]=(int(val),float(act),expr)
    if k=='heap':
     j,pos,i=map(int,v.split());assert len(h[j])==pos;h[j].append(i)
    if k=='draw':draw.append(v)
   cur.append((var,h,draw,rows[-1][1]))
  obs.append(cur)
 for j,(g,z) in enumerate(zip(*obs)):
  print('batch',batch,'decision',j+1)
  for name,(var,h,draw,pick) in zip(['g3','z3'],[g,z]):
   print(name,'vars',len(var),'heaps',list(map(len,h)),'draw',draw,'picked',pick,'eligible',sum(v[0]==0 for v in var.values()))
  for n,(gh,zh) in enumerate(zip(g[1],z[1])):
   diff=next((i for i,(x,y) in enumerate(zip(gh,zh)) if x!=y),min(len(gh),len(zh)))
   print('heap',n,'common prefix',diff,'next entries',gh[diff:diff+3],zh[diff:diff+3])
  both=set(g[0])&set(z[0]);print('different assignments',sum(g[0][i][0]!=z[0][i][0] for i in both),'different activity',sum(g[0][i][1]!=z[0][i][1] for i in both))
  if j==2:
   for i in [int(g[3].split()[0]),int(z[3].split()[0])]:
    for name,(var,h,_,_) in zip(['g3','z3'],[g,z]):
     print(name,i,var.get(i),[(n,hi.index(i)) for n,hi in enumerate(h) if i in hi])
