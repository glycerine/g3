import csv,collections,statistics
from pathlib import Path
w=Path(__file__).resolve().parent
tot=collections.defaultdict(lambda:collections.defaultdict(int))
for r in csv.DictReader((w/'intervention.csv').open()):
 b,g,p=r['batch'],r['goal'],r['phase']
 keys=['all observed stages']
 if p=='check':
  keys.append('all concrete checks')
  if (b,g) in [('31','34'),('11','5')]:keys.append(b+'/'+g)
  if b in ['31','11']:keys.append('batch '+b+' checks')
 for k in keys:tot[k,int(r['force'])][int(r['round'])]+=int(r['instructions'])
for k in dict.fromkeys(k for k,force in tot):
 a,b=[list(tot[k,i].values()) for i in range(2)];assert len(a)==len(b)==5
 print(k,*(round(statistics.median(x)/1e6,3) for x in [a,b]),'M instructions',round(100*(statistics.median(b)/statistics.median(a)-1),2),'%')
