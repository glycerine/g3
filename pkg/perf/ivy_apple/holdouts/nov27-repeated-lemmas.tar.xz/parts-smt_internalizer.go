package smtcore

// Source: src/smt/smt_internalizer.cpp assertion, formula, gate, and default
// uninterpreted-term internalization.

import ("os";
	"errors"
	"fmt"
	"slices"

	"github.com/glycerine/g3/pkg/ast"
	"github.com/glycerine/g3/pkg/util/lbool"
)

const smtDeepExpressionThreshold uint32 = 1024

func (s *SMTInternalizerState) SetRelevancy(propagator *SMTRelevancyPropagator) error {
	if err := s.open(); err != nil {
		return err
	}
	if propagator != nil && propagator.context != s.context {
		return ast.ErrASTDomain
	}
	if propagator != nil && propagator.internalizer != nil && propagator.internalizer != s {
		return ast.ErrASTDomain
	}
	if s.relevancy != nil && s.relevancy.internalizer == s {
		s.relevancy.internalizer = nil
	}
	if propagator != nil {
		propagator.internalizer = s
	}
	s.relevancy = propagator
	s.context.relevancy = propagator
	return nil
}

func (s *SMTInternalizerState) isBoolean(expression ast.ASTHandle) (bool, error) {
	return s.manager.HasBoolSort(expression)
}

func (s *SMTInternalizerState) basicOperation(expression ast.ASTHandle) (int32, bool, error) {
	header, err := s.manager.NodeHeader(expression)
	if err != nil || header.Kind != ast.ASTApp || header.Family != s.manager.BasicFamilyID() {
		return 0, false, err
	}
	return header.DeclKind, true, nil
}

// The source's uninterpreted-term path applies the sort constraint twice.
// A theory callback can change the solver, so look up both the sort and its
// current theory again after an actual callback.
func (s *SMTInternalizerState) applySortConstraint(expression ast.ASTHandle, node *SMTEnode, calls int) error {
	for i := 0; i < calls; i++ {
		sort, err := s.manager.GetSort(expression)
		if err != nil {
			return err
		}
		family, err := s.manager.GetFamilyID(sort)
		if err != nil {
			return err
		}
		theory := s.theories[family]
		if theory == nil {
			return nil
		}
		if err := theory.ApplySortConstraint(node, sort); err != nil {
			return err
		}
	}
	return nil
}

func smtInternalizerGateOperation(operation int32) bool {
	return operation == ast.ASTOpAnd || operation == ast.ASTOpOr || operation == ast.ASTOpIff || operation == ast.ASTOpIte || operation == ast.ASTOpImplies
}

// numClauseRecords counts the stored clauses: m_aux_clauses, m_lemmas and
// the watch-only binary clauses.
func (s *SMTInternalizerState) numClauseRecords() int {
	return len(s.auxClauses) + len(s.lemmas) + s.binaryClauses.count()
}

// clauseRecordLists returns the concrete auxiliary clauses and lemmas in source order.
func (s *SMTInternalizerState) clauseRecordLists() [2][]*SMTClause {
	return [2][]*SMTClause{s.auxClauses, s.lemmas}
}

// Clauses lists the auxiliary clauses, then the lemmas in m_lemmas order,
// then the watch-only binary clauses.
func (s *SMTInternalizerState) Clauses() []SMTInternalizedClause {
	if s == nil {
		return nil
	}
	result := make([]SMTInternalizedClause, 0, s.numClauseRecords())
	for _, records := range s.clauseRecordLists() {
		for _, r := range records {
			out := SMTInternalizedClause{Root: r.directoryFlags&smtRecordRoot != 0, closeWatches: r.watchProgress()}
			if e := r.directoryDetails(); e != nil {
				out.Proof = e.proof
			}
			literals := r.Literals()
			if r.directoryFlags&smtRecordRetired != 0 {
				literals = r.directoryLiterals()
			}
			out.Literals = append([]SMTLiteral(nil), literals...)
			result = append(result, out)
		}
	}
	return s.binaryClauses.appendSnapshots(result)
}

func (s *SMTInternalizerState) Inconsistent() bool { return s != nil && s.inconsistent }

func (s *SMTInternalizerState) assignLiteral(literal SMTLiteral) error {
	return s.AssignLiteral(literal, NewSMTBooleanAxiom())
}

func (s *SMTInternalizerState) addClause(literals []SMTLiteral, root bool, proof ast.ASTHandle) error {
	return s.addClauseKind(literals, root, SMTClauseAux, proof)
}

func (s *SMTInternalizerState) addClauseKind(literals []SMTLiteral, root bool, kind SMTClauseKind, proof ast.ASTHandle) error {
	return s.addClauseKindWithDeleteHandler(literals, root, kind, proof, nil)
}

func (s *SMTInternalizerState) addClauseKindWithDeleteHandler(literals []SMTLiteral, root bool, kind SMTClauseKind, proof ast.ASTHandle, deleteHandler SMTClauseDeleteHandler) error {
	return s.addClauseKindWithJustificationAndDeleteHandler(literals, root, kind, proof, nil, deleteHandler)
}

// smtClauseSeenScanLimit is the clause length up to which duplicate and
// complementary literals are found by scanning the kept literals.
const smtClauseSeenScanLimit = 16

func (s *SMTInternalizerState) addClauseKindWithJustificationAndDeleteHandler(literals []SMTLiteral, root bool, kind SMTClauseKind, proof ast.ASTHandle, justification SMTJustification, deleteHandler SMTClauseDeleteHandler) error {
	kept := s.clauseKeptScratch[:0]
	ordered := kind == SMTClauseAux || kind == SMTClauseAuxLemma
	if ordered {
		// simplify_aux_clause_literals and simplify_aux_lemma_literals both
		// sort the literals (by index) first.
		// Filter the sorted copy in place. The write index never passes
		// the current read index, including when dropping duplicates.
		literals = append(kept, literals...)
		kept = literals[:0]
		slices.Sort(literals)
	}
	// Adjacent indices are the two polarities of a variable. Only
	// unsorted clauses need a membership table or a scan of earlier literals.
	var seen map[SMTLiteral]struct{}
	if !ordered && len(literals) > smtClauseSeenScanLimit {
		seen = make(map[SMTLiteral]struct{}, len(literals))
	}
	removedFalse := s.clauseRemovedScratch[:0]
	// Return the grown buffers even when a true literal or a tautology ends
	// simplification early. A nested clause from a proof or assignment
	// callback must use separate storage until this call returns.
	s.clauseKeptScratch = nil
	s.clauseRemovedScratch = nil
	defer func() {
		s.clauseKeptScratch = kept[:0]
		s.clauseRemovedScratch = removedFalse[:0]
	}()

	for _, literal := range literals {
		if literal == SMTTrueLiteral {
			return nil
		}
		if literal == SMTFalseLiteral {
			removedFalse = append(removedFalse, SMTTrueLiteral)
			continue
		}
		negated := literal.Negated()
		foundNegated, foundLiteral := false, false
		if ordered {
			if count := len(kept); count > 0 {
				previous := kept[count-1]
				foundLiteral, foundNegated = literal == previous, negated == previous
			}
		} else if seen != nil {
			_, foundNegated = seen[negated]
			_, foundLiteral = seen[literal]
		} else {
			for _, k := range kept {
				if k == negated {
					foundNegated = true
				} else if k == literal {
					foundLiteral = true
				}
			}
		}
		if foundNegated {
			return nil
		}
		if foundLiteral {
			continue
		}
		// simplify_aux_lemma_literals: a literal true at or below the base
		// level makes the lemma true; false literals are kept.
		if kind == SMTClauseAuxLemma && s.booleanData[literal.Var()].ScopeLevel() <= s.baseLevel {
			value, err := s.Assignment(literal)
			if err != nil {
				return err
			}
			if value == lbool.True {
				return nil
			}
		}
		if kind == SMTClauseAux {
			value, err := s.Assignment(literal)
			if err != nil {
				return err
			}
			if value == lbool.True {
				return nil
			}
			if value == lbool.False {
				removedFalse = append(removedFalse, literal.Negated())
				continue
			}
		}
		if seen != nil {
			seen[literal] = struct{}{}
		}
		kept = append(kept, literal)
	}
	return s.storeSimplifiedClause(kept, removedFalse, root, kind, proof, justification, deleteHandler)
}

func (s *SMTInternalizerState) storeSimplifiedClause(kept, removedFalse []SMTLiteral, root bool, kind SMTClauseKind, proof ast.ASTHandle, justification SMTJustification, deleteHandler SMTClauseDeleteHandler) error {
	// mk_clause: j = unit_resolution_justification(j, simp_lits) whenever
	// false literals were removed; the clause's proof is then built lazily
	// from that justification (the proof wrapper of pr resolved with the
	// removed literals), not here.
	if !proof.IsNull() && len(removedFalse) != 0 && justification == nil {
		wrapper, err := NewSMTJustificationProofWrapper(s.manager, proof, false)
		if err != nil {
			return err
		}
		justification, proof = wrapper, ast.ASTHandle{}
	}
	// Source mk_clause wraps even a null antecedent when simplifying an
	// auxiliary clause. Those true literals still explain the removed false
	// disjuncts; dropping them loses assumption cores for new QI lemmas.
	// A concrete proof already carries this resolution in the branch above.
	if len(removedFalse) != 0 && (justification != nil || proof.IsNull()) {
		region := true
		if justification != nil {
			region = justification.InRegion()
		}
		updated, err := NewSMTUnitResolutionJustification(region, justification, removedFalse)
		if err != nil {
			return err
		}
		justification = updated
	}
	s.statistics.NumMkLits += uint32(len(kept))
	if len(kept) == 0 {
		// A clause simplified to false still has a derivation. Preserve the
		// resolved proof just as for a unit clause; an axiom conflict here
		// would turn the final refutation into an open hypothesis of false.
		if justification == nil && !proof.IsNull() {
			owner, err := NewSMTJustificationProofWrapper(s.manager, proof, false)
			if err != nil {
				return err
			}
			justification = owner
		}
		conflict := NewSMTBooleanAxiom()
		if justification != nil {
			wrapped, err := NewSMTBooleanJustification(justification)
			if err != nil {
				return err
			}
			conflict = wrapped
			if justification != s.registeredJustification {
				s.ownedJustifications = append(s.ownedJustifications, justification)
			}
		}
		s.setBooleanConflict(conflict, SMTNullLiteral)
		return nil
	}
	if len(kept) == 1 {
		if justification != nil {
			wrapped, err := NewSMTBooleanJustification(justification)
			if err != nil {
				return err
			}
			before := len(s.assignedLiterals)
			beforeAssignment := s.assignment[kept[0].Index()]
			err = s.AssignLiteral(kept[0], wrapped)
			if (err == nil || len(s.assignedLiterals) != before || s.assignment[kept[0].Index()] != beforeAssignment) && justification != s.registeredJustification {
				s.ownedJustifications = append(s.ownedJustifications, justification)
			}
			return err
		}
		if !proof.IsNull() {
			owner, err := NewSMTJustificationProofWrapper(s.manager, proof, false)
			if err != nil {
				return err
			}
			wrapped, err := NewSMTBooleanJustification(owner)
			if err != nil {
				return errors.Join(err, owner.Release(s.manager))
			}
			before := len(s.assignedLiterals)
			beforeAssignment := s.assignment[kept[0].Index()]
			err = s.AssignLiteral(kept[0], wrapped)
			if err != nil && len(s.assignedLiterals) == before && s.assignment[kept[0].Index()] == beforeAssignment {
				return errors.Join(err, owner.Release(s.manager))
			}
			s.ownedJustifications = append(s.ownedJustifications, owner)
			return err
		}
		return s.assignLiteral(kept[0])
	}
	// mk_clause case 2 tries use_binary_clause_opt on the literals as
	// simplified, before the default case selects watch literals.
	// use_binary_clause_opt: a lemma (any kind but aux) is refused only at
	// relevancy level 2 or more, and may be stored above scope 0; an aux
	// clause only at scope 0. Both need base level 0 and atoms internalized
	// at level 0.
	lemma := kind != SMTClauseAux
	if len(kept) == 2 && s.binaryClauseOptimization && !(lemma && s.relevancyLevel >= 2) &&
		s.binaryClauseBaseLevel() == 0 && (lemma || s.scopeLevel == 0) &&
		s.booleanData[kept[0].Var()].InternalLevel() == 0 && s.booleanData[kept[1].Var()].InternalLevel() == 0 {
		first, second := kept[0], kept[1]
		if err := s.watches[first.Negated().Index()].InsertLiteral(second); err != nil {
			return err
		}
		if err := s.watches[second.Negated().Index()].InsertLiteral(first); err != nil {
			_ = s.watches[first.Negated().Index()].RemoveLiteral(second)
			return err
		}
		s.binaryClauses.add(first, second, root, lemma, proof)
		value, err := s.Assignment(second)
		if err != nil {
			return err
		}
		if value == lbool.False {
			if err = s.AssignLiteral(first, s.binaryReason(second.Negated())); err != nil {
				return err
			}
		}
		s.statistics.NumMkBinClause++
		return nil
	}
	firstWatch, secondWatch := 0, 1
	if kind == SMTClauseLearned {
		watch, err := s.selectLearnedWatchLiteral(kept)
		if err != nil {
			return err
		}
		kept[1], kept[watch] = kept[watch], kept[1]
		secondWatch = watch
	} else if kind == SMTClauseAuxLemma {
		first, err := s.selectWatchLiteral(kept, 0)
		if err != nil {
			return err
		}
		kept[0], kept[first] = kept[first], kept[0]
		second, err := s.selectWatchLiteral(kept, 1)
		if err != nil {
			return err
		}
		kept[1], kept[second] = kept[second], kept[1]
		firstWatch, secondWatch = first, second
	}
	clause, owner, err := s.makeClauseWithJustificationAndDeleteHandler(kept, kind, proof, justification, deleteHandler)
	if err != nil {
		return err
	}
	if clause.ReinternalizeAtoms() {
		// C++ saves atoms before selecting watch positions. Restore that
		// original order in the atom owner, without changing the live watches.
		off := clause.atomOffset()
		clause.atoms.Swap(off+1, off+secondWatch)
		clause.atoms.Swap(off, off+firstWatch)
	}
	if kind == SMTClauseAux && owner != nil && owner == s.registeredJustification {
		owner = nil
	} else if kind == SMTClauseAux && owner != nil {
		// mk_justification puts a justification with a del_eh in
		// m_justifications: it dies with its scope (or flush), not with the
		// auxiliary clause, which clause::deallocate leaves alone.
		s.ownedJustifications = append(s.ownedJustifications, owner)
		owner = nil
	}
	clause.registerDirectory(root, proof, owner)
	if lemma {
		clause.lemmaIndex = len(s.lemmas)
		s.lemmas = append(s.lemmas, clause) // m_lemmas.push_back(cls)
	} else {
		s.auxClauses = append(s.auxClauses, clause) // m_aux_clauses.push_back(cls)
	}
	// Source mk_clause counts a two-literal clause that is not stored as a
	// binary watch only in m_num_mk_clause (case 2 falls through).
	s.statistics.NumMkClause++
	firstValue, err := s.Assignment(kept[0])
	if err != nil {
		return err
	}
	secondValue, err := s.Assignment(kept[1])
	if err != nil {
		return err
	}
	// The source's else-if branch is taken whenever literal 0 is not false,
	// so a true first watch with a false second watch is marked too.
	if kind == SMTClauseAuxLemma && s.scopeLevel > s.baseLevel &&
		(firstValue == lbool.False || secondValue == lbool.False) {
		// Source also revisits unit/conflicting auxiliary lemmas whose atoms
		// survive, since their assignment can belong to the discarded scope:
		// mark_for_reinit(cls, m_scope_lvl, save_atoms).
		clause.reinit = true
		s.markForReinit(clause, s.scopeLevel)
	}
	if firstValue == lbool.False {
		s.setBooleanConflict(NewSMTBooleanClause(clause), SMTNullLiteral)
	} else if secondValue == lbool.False && firstValue == lbool.Undef {
		if err = s.AssignLiteral(kept[0], NewSMTBooleanClause(clause)); err != nil {
			return err
		}
	}
	return nil
}

func (s *SMTInternalizerState) selectLearnedWatchLiteral(literals []SMTLiteral) (int, error) {
	if len(literals) < 2 {
		return -1, ast.ErrASTDomain
	}
	selected := -1
	var selectedLevel uint32
	for index := 1; index < len(literals); index++ {
		value, err := s.Assignment(literals[index])
		if err != nil {
			return -1, err
		}
		if value == lbool.True {
			return -1, ast.ErrASTDomain
		}
		level := s.scopeLevel
		if value == lbool.False {
			level = s.booleanData[literals[index].Var()].ScopeLevel()
		}
		if selected == -1 || level > selectedLevel {
			selected, selectedLevel = index, level
		}
	}
	return selected, nil
}

func (s *SMTInternalizerState) selectWatchLiteral(literals []SMTLiteral, startingAt int) (int, error) {
	if len(literals) < 2 || startingAt < 0 || startingAt >= len(literals) {
		return -1, ast.ErrASTDomain
	}
	minTrue, maxFalse, unknown := -1, -1, -1
	for index := startingAt; index < len(literals); index++ {
		value, err := s.literalAssignment(literals[index])
		if err != nil {
			return -1, err
		}
		switch value {
		case lbool.False:
			if maxFalse == -1 || s.booleanData[literals[index].Var()].ScopeLevel() > s.booleanData[literals[maxFalse].Var()].ScopeLevel() {
				maxFalse = index
			}
		case lbool.Undef:
			unknown = index
		case lbool.True:
			if minTrue == -1 || s.booleanData[literals[index].Var()].ScopeLevel() < s.booleanData[literals[minTrue].Var()].ScopeLevel() {
				minTrue = index
			}
		}
	}
	if minTrue != -1 {
		return minTrue, nil
	}
	if unknown != -1 {
		return unknown, nil
	}
	if maxFalse != -1 {
		return maxFalse, nil
	}
	return -1, ast.ErrASTDomain
}

// AddLearnedClause installs a conflict lemma into the current logical scope.
func (s *SMTInternalizerState) AddLearnedClause(literals []SMTLiteral) error {
	return s.AddLearnedClauseWithProof(literals, ast.ASTHandle{})
}

func (s *SMTInternalizerState) addTheoryAxiom(theory SMTTheoryID, literals []SMTLiteral) error {
	return s.addTheoryAxiomWithParameters(theory, literals, nil)
}

func (s *SMTInternalizerState) addTheoryAxiomWithParameters(theory SMTTheoryID, literals []SMTLiteral, parameters []ast.ASTParameter) error {
	proofs, err := s.manager.ProofsEnabled()
	if err != nil || !proofs {
		if err != nil {
			return err
		}
		return s.addClause(literals, false, ast.ASTHandle{})
	}
	justification, err := NewSMTTheoryAxiomJustification(s.manager, theory, literals, parameters)
	if err != nil {
		return err
	}
	beforeClauses, beforeOwners := s.numClauseRecords(), len(s.ownedJustifications)
	err = s.addClauseKindWithJustificationAndDeleteHandler(literals, false, SMTClauseAux, ast.ASTHandle{}, justification, nil)
	if s.numClauseRecords() == beforeClauses && len(s.ownedJustifications) == beforeOwners {
		return errors.Join(err, justification.Release(s.manager))
	}
	if len(parameters) != 0 {
		// Parameter-bearing region justifications require their own scoped
		// destructor, including when the clause stores a resolution wrapper.
		registered := false
		for _, owner := range s.ownedJustifications[beforeOwners:] {
			registered = registered || owner == justification
		}
		if !registered {
			s.ownedJustifications = append(s.ownedJustifications, justification)
		}
	}
	return err
}

// AddLearnedClauseWithProof installs a conflict lemma and transfers an owned
// reference to its proof wrapper when proof production is enabled.
func (s *SMTInternalizerState) AddLearnedClauseWithProof(literals []SMTLiteral, proof ast.ASTHandle) error {
	return s.addLearnedClauseWithProof(literals, proof, true)
}

func (s *SMTInternalizerState) addLearnedClauseWithProof(literals []SMTLiteral, proof ast.ASTHandle, captureUnit bool) error {
	if err := s.open(); err != nil {
		return err
	}
	if len(literals) == 0 {
		return ast.ErrASTDomain
	}
	unitCount := len(s.learnedUnits)
	if captureUnit && s.searching && len(literals) == 1 {
		if err := s.captureLearnedUnit(literals[0], proof); err != nil {
			return err
		}
	}
	if err := s.addClauseKind(literals, false, SMTClauseLearned, proof); err != nil {
		if len(s.learnedUnits) != unitCount {
			err = errors.Join(err, s.discardLearnedUnitsFrom(unitCount))
		}
		return err
	}
	return nil
}

func (s *SMTInternalizerState) markRelevant(expression ast.ASTHandle) error {
	if s.relevancy == nil {
		return s.context.SetRelevant(expression, true)
	}
	// context::mark_as_relevant marks n and then propagates relevancy
	// (smt_context.h); the propagator's own marking does not propagate.
	if err := s.relevancy.MarkRelevant(expression); err != nil {
		return err
	}
	return s.relevancy.Propagate()
}

// markLiteralRelevant is context::mark_as_relevant(literal):
// mark_as_relevant(bool_var2expr(l.var())). bool_var2expr(true_bool_var)
// is the true expression, so the true literal marks true.
func (s *SMTInternalizerState) markLiteralRelevant(literal SMTLiteral) error {
	if literal.Var() == SMTTrueBoolVar {
		truth, err := s.manager.MkTrue()
		if err != nil {
			return err
		}
		return s.markRelevant(truth)
	}
	atom, err := s.BoolExpression(literal.Var())
	if err != nil {
		return err
	}
	return s.markRelevant(atom)
}

func (s *SMTInternalizerState) ensureBooleanEnode(expression ast.ASTHandle, variable int32, suppressArguments, mergeTruthValue, congruenceEnabled bool) error {
	node, err := s.attachBooleanEnode(expression, variable, suppressArguments, mergeTruthValue, congruenceEnabled)
	if err != nil {
		return err
	}
	return s.propagateBooleanEnode(variable, node)
}

// attachBooleanEnode is mk_enode followed by set_enode_flag, without
// propagate_bool_var_enode, as in context::internalize_formula_core.
func (s *SMTInternalizerState) attachBooleanEnode(expression ast.ASTHandle, variable int32, suppressArguments, mergeTruthValue, congruenceEnabled bool) (*SMTEnode, error) {
	node := s.context.enodes.get(expression)
	if node == nil {
		var err error
		node, err = s.MkEnode(expression, suppressArguments, mergeTruthValue, congruenceEnabled)
		if err != nil {
			return nil, err
		}
	} else if mergeTruthValue {
		node.mergeTruthValue = true
	}
	data, err := s.BooleanData(variable)
	if err != nil {
		return nil, err
	}
	// A variable created in this scope retires with the enode. Only a
	// surviving variable needs its flag restored separately on pop.
	s.setEnodeFlag(variable, data.InternalLevel() == s.scopeLevel)
	return node, nil
}

// setMergeTF is context::set_merge_tf: once enabled, the enode is merged
// with true/false whenever its Boolean variable is assigned.
func (s *SMTInternalizerState) setMergeTF(node *SMTEnode, variable int32, isNewVar bool) error {
	if node.mergeTruthValue {
		return nil
	}
	if !isNewVar {
		s.mergeTFTrail = append(s.mergeTFTrail, node)
	}
	node.mergeTruthValue = true
	literal := NewSMTLiteral(variable, false)
	value, err := s.Assignment(literal)
	if err != nil || value == lbool.Undef {
		return err
	}
	constant, err := s.booleanValueEnode(value == lbool.True)
	if err != nil {
		return err
	}
	if value == lbool.False {
		literal = literal.Negated()
	}
	return s.assignEquality(node, constant, NewSMTEqualityEquation(literal)) // push_eq
}

func (s *SMTInternalizerState) Internalize(expression ast.ASTHandle, gateContext bool) error {
	if err := s.open(); err != nil {
		return err
	}
	// Validate the incoming expression before reading its arena slot.
	header, boolean, err := s.manager.ExpressionHeader(expression)
	if err != nil {
		return err
	}
	kind := header.Kind
	if kind == ast.ASTVar {
		return ast.ErrASTDomain
	}
	if boolean {
		return s.internalizeFormula(expression, gateContext, &header)
	}
	if kind != ast.ASTApp || gateContext {
		return ast.ErrASTDomain
	}
	return s.internalizeTerm(expression, &header)
}

// smtHeaderBasicOperation is basicOperation on an already read header.
func (s *SMTInternalizerState) smtHeaderBasicOperation(header *ast.ASTNodeHeader) (int32, bool) {
	if header.Kind != ast.ASTApp || header.Family != s.manager.BasicFamilyID() {
		return 0, false
	}
	return header.DeclKind, true
}

func (s *SMTInternalizerState) internalizeFormula(expression ast.ASTHandle, gateContext bool, header *ast.ASTNodeHeader) error {
	if s.manager.IsTrue(expression) || s.manager.IsFalse(expression) {
		if !gateContext {
			_, err := s.booleanValueEnode(s.manager.IsTrue(expression))
			return err
		}
		return nil
	}
	op, basic := s.smtHeaderBasicOperation(header)
	var err error
	if basic && op == ast.ASTOpNot && gateContext {
		child, err := s.manager.GetArg(expression, 0)
		if err != nil {
			return err
		}
		return s.Internalize(child, true)
	}
	if variable, found := s.boolVar.lookup(expression); found {
		// Source: n was already internalized as a Boolean. Outside a gate
		// it needs an enode merged with true/false.
		if !gateContext {
			if node := s.context.enodes.get(expression); node != nil {
				return s.setMergeTF(node, variable, false)
			}
			return s.ensureBooleanEnode(expression, variable, true, true, false)
		}
		return nil
	}
	if header.Kind == ast.ASTQuantifier {
		return s.internalizeQuantifier(expression, gateContext)
	}
	if basic && op == ast.ASTOpDistinct {
		return s.internalizeDistinct(expression, gateContext)
	}
	if !basic {
		// expressionTheory: an application's family is its declaration's.
		if theory := s.theories[header.Family]; theory != nil {
			handled, err := theory.InternalizeAtom(expression, gateContext)
			if err != nil {
				return err
			}
			if handled {
				return s.finishTheoryAtom(expression, gateContext)
			}
		}
	}
	if err = s.internalizeFormulaCoreOp(expression, gateContext, header, true); err != nil {
		return err
	}
	if basic && op == ast.ASTOpEq {
		variable, _ := s.boolVar.lookup(expression)
		data, err := s.BooleanData(variable)
		if err != nil {
			return err
		}
		data.SetEquality()
		left, err := s.manager.GetArg(expression, 0)
		if err != nil {
			return err
		}
		sort, err := s.manager.GetSort(left)
		if err != nil {
			return err
		}
		family, err := s.manager.GetFamilyID(sort)
		if err != nil {
			return err
		}
		if theory := s.theories[family]; theory != nil {
			if err = theory.InternalizeEquality(expression, variable); err != nil {
				return err
			}
		}
	}
	return nil
}

// finishTheoryAtom is the tail of context::internalize_theory_atom after the
// theory internalized the atom.
func (s *SMTInternalizerState) finishTheoryAtom(expression ast.ASTHandle, gateContext bool) error {
	variable, found := s.boolVar.lookup(expression)
	if !found {
		return ast.ErrASTDomain
	}
	if !gateContext {
		// Not in the context of a gate: the formula must have an enode.
		if node := s.context.enodes.get(expression); node == nil {
			if _, err := s.MkEnode(expression, true, true, false); err != nil {
				return err
			}
		} else {
			s.setEnodeFlag(variable, true)
			if err := s.setMergeTF(node, variable, true); err != nil {
				return err
			}
		}
	}
	if node := s.context.enodes.get(expression); node != nil {
		s.setEnodeFlag(variable, true)
		return s.propagateBooleanEnode(variable, node)
	}
	return nil
}

// setEnodeFlag is context::set_enode_flag.
func (s *SMTInternalizerState) setEnodeFlag(variable int32, isNewVar bool) {
	data := &s.booleanData[variable]
	if !data.IsENode() {
		if !isNewVar {
			s.enodeFlagTrail = append(s.enodeFlagTrail, variable)
		}
		data.SetENode()
	}
}

func (s *SMTInternalizerState) internalizeQuantifier(expression ast.ASTHandle, gateContext bool) error {
	if !gateContext || s.quantifiers == nil {
		return ast.ErrASTDomain
	}
	forall, err := s.manager.IsForall(expression)
	if err != nil || !forall {
		if err != nil {
			return err
		}
		return ast.ErrASTDomain
	}
	variable, err := s.MkBoolVar(expression)
	if err != nil {
		return err
	}
	data, err := s.BooleanData(variable)
	if err != nil {
		return err
	}
	data.SetQuantifier()
	generation := s.generation
	if cached, found := s.cachedGeneration.get(expression); found {
		generation = cached
	}
	if err = s.quantifiers.Add(expression, generation); err != nil {
		return err
	}
	// default_qm_plugin::add: if (m_fparams->m_mbqi && mbqi_enabled(q)) {
	// m_active = true; m_model_finder->register_quantifier(q); }
	if qm := s.quantifierManager; qm != nil && qm.mbqi {
		enabled, err := qm.mbqiEnabled(expression)
		if err != nil {
			return errors.Join(err, s.quantifiers.Delete(expression))
		}
		if enabled {
			qm.pluginActive = true
			if qm.modelFinder != nil {
				if err = qm.modelFinder.RegisterQuantifier(expression); err != nil {
					return errors.Join(err, s.quantifiers.Delete(expression))
				}
			}
		}
	}
	return nil
}

func (s *SMTInternalizerState) internalizeDistinct(expression ast.ASTHandle, gateContext bool) error {
	count, err := s.manager.GetNumArgs(expression)
	if err != nil {
		return err
	}
	arguments := make([]ast.ASTHandle, count)
	for index := range arguments {
		arguments[index], err = s.manager.GetArg(expression, uint32(index))
		if err != nil {
			return err
		}
	}
	expanded, err := s.manager.MkDistinctExpanded(arguments)
	if err != nil {
		return err
	}
	if err = s.Internalize(expanded, true); err != nil {
		return err
	}
	variable, err := s.MkBoolVar(expression)
	if err != nil {
		return err
	}
	literal := NewSMTLiteral(variable, false)
	definition, err := s.Literal(expanded)
	if err != nil {
		return err
	}
	if err = s.addGateClause([]SMTLiteral{literal.Negated(), definition}); err != nil {
		return err
	}
	if err = s.addGateClause([]SMTLiteral{literal, definition.Negated()}); err != nil {
		return err
	}
	if s.relevancy != nil {
		if err = s.relevancy.AddDependency(expression, expanded); err != nil {
			return err
		}
	}
	if !gateContext {
		return s.ensureBooleanEnode(expression, variable, true, true, false)
	}
	return nil
}

func (s *SMTInternalizerState) internalizeFormulaCore(expression ast.ASTHandle, gateContext bool) error {
	header, err := s.manager.NodeHeader(expression)
	if err != nil {
		return err
	}
	if header.Kind != ast.ASTApp {
		return ast.ErrASTDomain
	}
	return s.internalizeFormulaCoreOp(expression, gateContext, &header, false)
}

func (s *SMTInternalizerState) internalizeFormulaCoreOp(expression ast.ASTHandle, gateContext bool, header *ast.ASTNodeHeader, knownBoolean bool) error {
	op, basic := s.smtHeaderBasicOperation(header)
	count := header.NumArgs
	var err error
	isGate := basic && (smtInternalizerGateOperation(op) || op == ast.ASTOpNot)
	for index := uint32(0); index < count; index++ {
		argument, err := s.manager.GetArg(expression, index)
		if err != nil {
			return err
		}
		if err = s.Internalize(argument, isGate); err != nil {
			return fmt.Errorf("internalize formula child %d: %w", index, err)
		}
	}
	variable, isNew := s.boolVar.lookup(expression)
	if !isNew {
		if knownBoolean {
			variable, err = s.mkBoolVar(expression, header, false)
		} else {
			variable, err = s.MkBoolVar(expression)
		}
		if err != nil {
			return fmt.Errorf("internalize formula Boolean variable: %w", err)
		}
		isNew = true
	} else {
		isNew = false
	}
	if (!gateContext || !isGate && count > 0) && s.context.enodes.get(expression) == nil {
		if _, err = s.attachBooleanEnode(expression, variable, isGate, !gateContext, true); err != nil {
			return fmt.Errorf("internalize formula enode: %w", err)
		}
	}
	if isNew && basic && (smtInternalizerGateOperation(op) || op == ast.ASTOpNot) {
		if err = s.addGateConstraints(expression, op); err != nil {
			return fmt.Errorf("internalize formula gate constraints: %w", err)
		}
	}
	return nil
}

func (s *SMTInternalizerState) argumentLiterals(expression ast.ASTHandle) ([]SMTLiteral, error) {
	count, err := s.manager.GetNumArgs(expression)
	if err != nil {
		return nil, err
	}
	result := make([]SMTLiteral, count)
	for index := range result {
		argument, err := s.manager.GetArg(expression, uint32(index))
		if err != nil {
			return nil, err
		}
		result[index], err = s.Literal(argument)
		if err != nil {
			return nil, err
		}
	}
	return result, nil
}

func (s *SMTInternalizerState) clauseLiteralExpressions(literals []SMTLiteral) ([]ast.ASTHandle, error) {
	result := make([]ast.ASTHandle, len(literals))
	for index, literal := range literals {
		// The reserved true variable has no boolExpr entry in the Go
		// table. mk_clause_def_axiom maps it through m_bool_var2expr, so
		// true_literal is true and false_literal is the raw (not true).
		if literal == SMTTrueLiteral || literal == SMTFalseLiteral {
			truth, err := s.manager.MkTrue()
			if err == nil && literal == SMTFalseLiteral {
				truth, err = s.manager.MkNot(truth)
			}
			if err != nil {
				return nil, err
			}
			result[index] = truth
			continue
		}
		expression, err := s.BoolExpression(literal.Var())
		if err != nil {
			return nil, err
		}
		if literal.Sign() {
			expression, err = s.manager.MkNot(expression)
			if err != nil {
				return nil, err
			}
		}
		result[index] = expression
	}
	return result, nil
}

func (s *SMTInternalizerState) gateClauseProof(literals []SMTLiteral) (ast.ASTHandle, error) {
	proofs, err := s.manager.ProofsEnabled()
	if err != nil || !proofs {
		return ast.ASTHandle{}, err
	}
	expressions, err := s.clauseLiteralExpressions(literals)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	fact, err := s.manager.MkOrArgs(expressions)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	return s.manager.MkProofDefAxiom(fact)
}

func (s *SMTInternalizerState) addGateClause(literals []SMTLiteral) error {
	proof, err := s.gateClauseProof(literals)
	if err != nil {
		return err
	}
	return s.addWrappedProofClause(literals, false, proof)
}

// addWrappedProofClause is mk_clause(lits, mk_justification(
// justification_proof_wrapper(*this, pr))) of mk_gate_clause and
// mk_root_clause: the wrapper joins m_justifications before mk_clause, so its
// proof dies with the scope even when the clause simplifies away.
func (s *SMTInternalizerState) addWrappedProofClause(literals []SMTLiteral, root bool, proof ast.ASTHandle) error {
	if proof.IsNull() {
		return s.addClause(literals, root, proof)
	}
	wrapper, err := NewSMTJustificationProofWrapper(s.manager, proof, true)
	if err != nil {
		return err
	}
	s.ownedJustifications = append(s.ownedJustifications, wrapper)
	previous := s.registeredJustification
	s.registeredJustification = wrapper
	defer func() { s.registeredJustification = previous }()
	return s.addClauseKindWithJustificationAndDeleteHandler(literals, root, SMTClauseAux, ast.ASTHandle{}, wrapper, nil)
}

func (s *SMTInternalizerState) rootClauseProof(literals []SMTLiteral, assertionProof ast.ASTHandle) (ast.ASTHandle, error) {
	proofs, err := s.manager.ProofsEnabled()
	if err != nil || !proofs {
		return ast.ASTHandle{}, err
	}
	if assertionProof.IsNull() {
		return ast.ASTHandle{}, ast.ErrASTDomain
	}
	fact, err := s.manager.GetProofFact(assertionProof)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	operation, basic, err := s.basicOperation(fact)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	if basic && operation == ast.ASTOpOr {
		return assertionProof, nil
	}
	expressions, err := s.clauseLiteralExpressions(literals)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	negatedFact, err := s.manager.MkNot(fact)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	expressions = append(expressions, negatedFact)
	definition, err := s.manager.MkOrArgs(expressions)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	definitionProof, err := s.manager.MkProofDefAxiom(definition)
	if err != nil {
		return ast.ASTHandle{}, err
	}
	return s.manager.MkProofUnitResolution([]ast.ASTHandle{definitionProof, assertionProof})
}

func (s *SMTInternalizerState) addRootClause(literals []SMTLiteral, assertionProof ast.ASTHandle) error {
	proof, err := s.rootClauseProof(literals, assertionProof)
	if err != nil {
		return err
	}
	return s.addWrappedProofClause(literals, true, proof)
}

// assignRootLiteral is the assign of context::assert_default, which justifies
// the literal with a justification_proof_wrapper even without a proof.
func (s *SMTInternalizerState) assignRootLiteral(literal SMTLiteral, proof ast.ASTHandle) error {
	justification := NewSMTBooleanAxiom()
	if proof.IsNull() {
		// With proofs enabled the source always has an assertion proof; a
		// caller without one keeps the axiom the proof builder can close.
		if proofs, err := s.manager.ProofsEnabled(); err != nil || proofs {
			if err != nil {
				return err
			}
			return s.AssignLiteral(literal, justification)
		}
	}
	owner, err := NewSMTJustificationProofWrapper(s.manager, proof, false)
	if err != nil {
		return err
	}
	justification, err = NewSMTBooleanJustification(owner)
	if err != nil {
		return errors.Join(err, owner.Release(s.manager))
	}
	if err = s.AssignLiteral(literal, justification); err != nil {
		return errors.Join(err, owner.Release(s.manager))
	}
	s.ownedJustifications = append(s.ownedJustifications, owner)
	return nil
}

func (s *SMTInternalizerState) addGateConstraints(expression ast.ASTHandle, operation int32) error {
	variable := s.boolVar.get(expression)
	literal := NewSMTLiteral(variable, false)
	arguments, err := s.argumentLiterals(expression)
	if err != nil {
		return err
	}
	if gate := s.boolGate(variable); gate != nil {
		// Children precede their gate in scope order, so these literal indices
		// remain live for the owning Boolean variable's whole lifetime.
		gate.literals = arguments
	}
	add := func(values ...SMTLiteral) error { return s.addGateClause(values) }
	switch operation {
	case ast.ASTOpNot:
		if len(arguments) != 1 {
			return ast.ErrASTDomain
		}
		if err = add(literal.Negated(), arguments[0].Negated()); err != nil {
			return err
		}
		return add(literal, arguments[0])
	case ast.ASTOpAnd:
		for _, argument := range arguments {
			if err = add(literal.Negated(), argument); err != nil {
				return err
			}
		}
		last := []SMTLiteral{literal}
		for _, argument := range arguments {
			last = append(last, argument.Negated())
		}
		if err = s.addGateClause(last); err != nil {
			return err
		}
		if s.relevancy != nil {
			return s.relevancy.AddAndWatches(expression)
		}
	case ast.ASTOpOr:
		for _, argument := range arguments {
			if err = add(literal, argument.Negated()); err != nil {
				return err
			}
		}
		last := []SMTLiteral{literal.Negated()}
		last = append(last, arguments...)
		if err = s.addGateClause(last); err != nil {
			return err
		}
		if s.relevancy != nil {
			return s.relevancy.AddOrWatches(expression)
		}
	case ast.ASTOpIff:
		if len(arguments) != 2 {
			return ast.ErrASTDomain
		}
		for _, clause := range [][]SMTLiteral{
			{literal.Negated(), arguments[0], arguments[1].Negated()}, {literal.Negated(), arguments[0].Negated(), arguments[1]},
			{literal, arguments[0], arguments[1]}, {literal, arguments[0].Negated(), arguments[1].Negated()},
		} {
			if err = s.addGateClause(clause); err != nil {
				return err
			}
		}
	case ast.ASTOpImplies:
		if len(arguments) != 2 {
			return ast.ErrASTDomain
		}
		for _, clause := range [][]SMTLiteral{
			{literal.Negated(), arguments[0].Negated(), arguments[1]},
			{literal, arguments[0]},
			{literal, arguments[1].Negated()},
		} {
			if err = s.addGateClause(clause); err != nil {
				return err
			}
		}
		if s.relevancy != nil {
			left, getErr := s.manager.GetArg(expression, 0)
			if getErr != nil {
				return getErr
			}
			right, getErr := s.manager.GetArg(expression, 1)
			if getErr != nil {
				return getErr
			}
			if err = s.relevancy.AddDependency(expression, left); err != nil {
				return err
			}
			return s.relevancy.AddDependency(expression, right)
		}
	case ast.ASTOpIte:
		if len(arguments) != 3 {
			return ast.ErrASTDomain
		}
		for _, clause := range [][]SMTLiteral{
			{literal.Negated(), arguments[0].Negated(), arguments[1]}, {literal.Negated(), arguments[0], arguments[2]},
			{literal, arguments[0].Negated(), arguments[1].Negated()}, {literal, arguments[0], arguments[2].Negated()},
		} {
			if err = s.addGateClause(clause); err != nil {
				return err
			}
		}
		if s.relevancy != nil {
			return s.relevancy.AddITEWatches(expression)
		}
	}
	return nil
}

func (s *SMTInternalizerState) internalizeTerm(expression ast.ASTHandle, header *ast.ASTNodeHeader) error {
	theory := s.theories[header.Family]
	if node := s.context.enodes.get(expression); node != nil {
		if theory != nil && !theory.IsAttachedToVariable(node) {
			handled, err := theory.InternalizeTerm(expression)
			if err != nil {
				return err
			}
			if handled && s.context.enodes.get(expression) == nil {
				return ast.ErrASTDomain
			}
		}
		return nil
	}
	op, basic := s.smtHeaderBasicOperation(header)
	if basic && op == ast.ASTOpIte {
		return s.internalizeTermITE(expression)
	}
	count := header.NumArgs
	if theory != nil {
		handled, err := theory.InternalizeTerm(expression)
		if err != nil {
			return err
		}
		if handled {
			node := s.context.enodes.get(expression)
			if node == nil {
				return ast.ErrASTDomain
			}
			return s.applySortConstraint(expression, node, 1)
		}
		// The callback can release the expression before returning unhandled.
		count, err = s.manager.GetNumArgs(expression)
		if err != nil {
			return err
		}
	}
	var inputs *smtTermInputs
	if theory == nil && !ast.ASTValidateHandles && !smtcoreSourceDebug && !ast.ASTSourceDebug && s.manager.TraceStream == nil && !s.manager.Budget().InjectionArmed() {
		children, ok, err := s.existingTermChildren(expression, count)
		if err != nil {
			return err
		}
		if ok {
			inputs = &smtTermInputs{header: *header, children: children}
		}
	}
	if inputs == nil {
		for index := uint32(0); index < count; index++ {
			argument, err := s.manager.GetArg(expression, index)
			if err != nil {
				return err
			}
			if err = s.Internalize(argument, false); err != nil {
				return err
			}
		}
	}
	node, err := s.mkEnode(expression, false, false, true, inputs)
	if err != nil {
		return err
	}
	// internalize_uninterpreted ends with apply_sort_cnstr(n, e), and
	// internalize_term applies it once more after it returns.
	return s.applySortConstraint(expression, node, 2)
}

// A term already in the equality graph needs no recursive internalization
// when its declaration family has no theory and the term is non-Boolean.
func (s *SMTInternalizerState) existingTermChildren(expression ast.ASTHandle, count uint32) ([]*SMTEnode, bool, error) {
	if count == 0 {
		return nil, true, nil
	}
	if count > 2 {
		return nil, false, nil
	}
	var pair [2]*SMTEnode
	for i := uint32(0); i < count; i++ {
		h, err := s.manager.GetArg(expression, i)
		if err != nil {
			return nil, false, err
		}
		child := s.context.enodes.get(h)
		if child == nil || child.root == nil || child.boolean || s.theories[child.family] != nil {
			return nil, false, nil
		}
		pair[i] = child
	}
	if count == 1 {
		return []*SMTEnode{pair[0]}, true, nil
	}
	return []*SMTEnode{pair[0], pair[1]}, true, nil
}

func (s *SMTInternalizerState) internalizeTermITE(expression ast.ASTHandle) error {
	condition, err := s.manager.GetArg(expression, 0)
	if err != nil {
		return err
	}
	thenTerm, err := s.manager.GetArg(expression, 1)
	if err != nil {
		return err
	}
	elseTerm, err := s.manager.GetArg(expression, 2)
	if err != nil {
		return err
	}
	thenEquality, err := s.mkEqualityAtom(expression, thenTerm) // mk_eq_atom(n, t)
	if err != nil {
		return err
	}
	elseEquality, err := s.mkEqualityAtom(expression, elseTerm) // mk_eq_atom(n, e)
	if err != nil {
		return err
	}
	if _, err = s.MkEnode(expression, true, false, false); err != nil {
		return fmt.Errorf("internalize term ITE enode: %w", err)
	}
	for _, item := range []struct {
		expression ast.ASTHandle
		gate       bool
	}{{condition, true}, {thenTerm, false}, {elseTerm, false}, {thenEquality, true}, {elseEquality, true}} {
		if err = s.Internalize(item.expression, item.gate); err != nil {
			return fmt.Errorf("internalize term ITE child %d: %w", item.expression.Slot(), err)
		}
	}
	conditionLiteral, err := s.Literal(condition)
	if err != nil {
		return err
	}
	thenLiteral, err := s.Literal(thenEquality)
	if err != nil {
		return err
	}
	elseLiteral, err := s.Literal(elseEquality)
	if err != nil {
		return err
	}
	if err = s.addGateClause([]SMTLiteral{conditionLiteral.Negated(), thenLiteral}); err != nil {
		return fmt.Errorf("internalize term ITE then clause: %w", err)
	}
	if err = s.addGateClause([]SMTLiteral{conditionLiteral, elseLiteral}); err != nil {
		return fmt.Errorf("internalize term ITE else clause: %w", err)
	}
	if s.relevancy != nil {
		return s.relevancy.AddTermITEWatches(expression, thenEquality, elseEquality)
	}
	return nil
}

func (s *SMTInternalizerState) preInternalizeDeep(expression ast.ASTHandle) error {
	depth, err := s.manager.GetDepth(expression)
	if err != nil || depth <= smtDeepExpressionThreshold {
		return err
	}
	order, err := NewSMTInternalizationOrder(s.manager, s.context)
	if err != nil {
		return err
	}
	order.variables = s.boolVar
	for _, theory := range s.theoryOrder {
		if !theory.DefaultInternalizer() {
			if err = order.SetNonDefaultFamily(theory.FamilyID(), true); err != nil {
				return err
			}
		}
	}
	items, err := order.Sort(expression)
	if err != nil {
		return err
	}
	for _, item := range items {
		kind, err := s.manager.GetKind(item.Expression)
		if err != nil {
			return err
		}
		if kind == ast.ASTApp {
			family, err := s.manager.GetFamilyID(item.Expression)
			if err != nil {
				return err
			}
			// Concrete theory internalizers retain the source top-down walk.
			if family != ast.NullFamilyID && family != s.manager.BasicFamilyID() {
				continue
			}
		}
		if err = s.Internalize(item.Expression, item.GateContext); err != nil {
			return fmt.Errorf("pre-internalize deep expression: %w", err)
		}
	}
	return nil
}

func (s *SMTInternalizerState) Assert(expression, proof ast.ASTHandle, generation uint32) error {
	return s.assertExpression(expression, proof, generation, nil)
}

// instanceArguments, when supplied, came from constructing this very lemma.
// Keep the ordinary assertion order, including preprocessing and relevance.
func (s *SMTInternalizerState) assertExpression(expression, proof ast.ASTHandle, generation uint32, instanceArguments []ast.ASTHandle) error {
	fd:=-1;if s.observing==expression{fd=studyFD()};startCount:=studyRd(fd);var missedCost uint64;previousGeneration := s.generation
	if err := s.SetGeneration(generation); err != nil {
		return err
	}
	defer func() { s.generation = previousGeneration }()
	boolean, err := s.isBoolean(expression)
	if err != nil || !boolean {
		if err != nil {
			return err
		}
		return ast.ErrASTDomain
	}
	if err = s.preInternalizeDeep(expression); err != nil {
		return err
	}
	op, basic, err := s.basicOperation(expression)
	if err != nil {
		return err
	}
	if basic && smtInternalizerGateOperation(op) {
		arguments := instanceArguments
		if arguments == nil {
			arguments, err = s.argumentHandles(expression)
			if err != nil {
				return err
			}
		}
		switch op {
		case ast.ASTOpAnd:
			return ast.ErrASTDomain
		case ast.ASTOpOr:
			literals := make([]SMTLiteral, len(arguments))
			for index, argument := range arguments {
				if instanceArguments != nil {
					if literal, found := s.boundInstanceLiteral(argument); found {
						literals[index] = literal
						continue
					}
				}
				before:=studyRd(fd);if err = s.Internalize(argument, true); err != nil {
					return err
				}
				literals[index], err = s.Literal(argument);missedCost+=studyRd(fd)-before
				if err != nil {
					return err
				}
			}
			missedCost+=0;beforeClause:=studyRd(fd);start:=len(s.auxClauses);if err = s.addRootClause(literals, proof); err != nil {
				return err
			}
			afterClause:=studyRd(fd);if s.observing==expression && len(s.auxClauses)==start+1{s.observedClause=s.auxClauses[start];s.observedPosition=start};if s.relevancy != nil {
				if err = s.relevancy.addAssertedOrWatches(expression, arguments, literals); err != nil {
					return err
				}
			}
		if fd>=0{last:=studyRd(fd);fmt.Fprintln(os.Stderr,"PART",beforeClause-startCount-missedCost,missedCost,afterClause-beforeClause,last-afterClause)};case ast.ASTOpIff:
			for _, argument := range arguments {
				if err = s.Internalize(argument, true); err != nil {
					return err
				}
			}
			left, err := s.Literal(arguments[0])
			if err != nil {
				return err
			}
			right, err := s.Literal(arguments[1])
			if err != nil {
				return err
			}
			if err = s.addRootClause([]SMTLiteral{left, right.Negated()}, proof); err != nil {
				return err
			}
			if err = s.addRootClause([]SMTLiteral{left.Negated(), right}, proof); err != nil {
				return err
			}
		case ast.ASTOpImplies:
			if len(arguments) != 2 {
				return ast.ErrASTDomain
			}
			if err = s.Internalize(expression, true); err != nil {
				return err
			}
			literal, literalErr := s.Literal(expression)
			if literalErr != nil {
				return literalErr
			}
			if err = s.assignRootLiteral(literal, proof); err != nil {
				return err
			}
		case ast.ASTOpIte:
			for _, argument := range arguments {
				if err = s.Internalize(argument, true); err != nil {
					return err
				}
			}
			condition, err := s.Literal(arguments[0])
			if err != nil {
				return err
			}
			thenLiteral, err := s.Literal(arguments[1])
			if err != nil {
				return err
			}
			elseLiteral, err := s.Literal(arguments[2])
			if err != nil {
				return err
			}
			if err = s.addRootClause([]SMTLiteral{condition.Negated(), thenLiteral}, proof); err != nil {
				return err
			}
			if err = s.addRootClause([]SMTLiteral{condition, elseLiteral}, proof); err != nil {
				return err
			}
			if s.relevancy != nil {
				if err = s.relevancy.AddITEWatches(expression); err != nil {
					return err
				}
			}
		}
		return s.markRelevant(expression)
	}
	if basic && op == ast.ASTOpDistinct {
		if err = s.assertDistinct(expression, proof); err != nil {
			return err
		}
		return s.markRelevant(expression)
	}
	return s.assertDefault(expression, proof)
}

// assertDefault is context::assert_default.
func (s *SMTInternalizerState) assertDefault(expression, proof ast.ASTHandle) error {
	if err := s.Internalize(expression, true); err != nil {
		return err
	}
	literal, err := s.Literal(expression)
	if err != nil {
		return err
	}
	if err = s.assignRootLiteral(literal, proof); err != nil {
		return err
	}
	if literal.Var() < SMTFirstBoolVar {
		return nil
	}
	return s.markRelevant(s.boolExpr[literal.Var()])
}

// smtDistinctSizeThreshold is DISTINCT_SZ_THRESHOLD.
const smtDistinctSizeThreshold = 32

// assertDistinct is context::assert_distinct: a large distinct (without
// proofs) maps its arguments injectively, through a fresh function, onto
// fresh interpreted values of a fresh sort.
func (s *SMTInternalizerState) assertDistinct(expression, proof ast.ASTHandle) (resultErr error) {
	arguments, err := s.argumentHandles(expression)
	if err != nil {
		return err
	}
	proofs, err := s.manager.ProofsEnabled()
	if err != nil {
		return err
	}
	if len(arguments) == 0 || len(arguments) <= smtDistinctSizeThreshold || proofs {
		return s.assertDefault(expression, proof)
	}
	m := s.manager
	sort, err := m.GetSort(arguments[0])
	if err != nil {
		return err
	}
	// sort_ref u and func_decl_ref f, released after the loop (f first).
	u, err := m.MkFreshSort("distinct-elems")
	if err != nil {
		return err
	}
	if err = m.IncRef(u); err != nil {
		return err
	}
	defer func() { resultErr = errors.Join(resultErr, m.DecRef(u)) }()
	prefix, err := m.Symbols.Intern("distinct-aux-f")
	if err != nil {
		return err
	}
	suffix, err := m.Symbols.Intern("")
	if err != nil {
		return err
	}
	f, err := m.MkFreshFuncDecl(prefix, suffix, []ast.ASTHandle{sort}, u)
	if err != nil {
		return err
	}
	if err = m.IncRef(f); err != nil {
		return err
	}
	defer func() { resultErr = errors.Join(resultErr, m.DecRef(f)) }()
	for _, argument := range arguments {
		if err = s.assertDistinctArgument(f, u, argument); err != nil {
			return err
		}
	}
	return nil
}

// assertDistinctArgument is one assert_distinct iteration; its app_refs
// fapp, val and eq are released in reverse order.
func (s *SMTInternalizerState) assertDistinctArgument(f, u, argument ast.ASTHandle) (resultErr error) {
	m := s.manager
	fapp, err := m.MkApp(f, []ast.ASTHandle{argument})
	if err != nil {
		return err
	}
	if err = m.IncRef(fapp); err != nil {
		return err
	}
	defer func() { resultErr = errors.Join(resultErr, m.DecRef(fapp)) }()
	val, err := m.MkFreshConst("unique-value", u)
	if err != nil {
		return err
	}
	if err = m.IncRef(val); err != nil {
		return err
	}
	defer func() { resultErr = errors.Join(resultErr, m.DecRef(val)) }()
	node, err := s.MkEnode(val, false, false, true)
	if err != nil {
		return err
	}
	if err = node.MarkAsInterpreted(); err != nil {
		return err
	}
	eq, err := m.MkEq(fapp, val)
	if err != nil {
		return err
	}
	if err = m.IncRef(eq); err != nil {
		return err
	}
	defer func() { resultErr = errors.Join(resultErr, m.DecRef(eq)) }()
	if err = s.assertDefault(eq, ast.ASTHandle{}); err != nil {
		return err
	}
	return s.markRelevant(eq)
}

func (s *SMTInternalizerState) argumentHandles(expression ast.ASTHandle) ([]ast.ASTHandle, error) {
	count, err := s.manager.GetNumArgs(expression)
	if err != nil {
		return nil, err
	}
	result := make([]ast.ASTHandle, count)
	for index := range result {
		result[index], err = s.manager.GetArg(expression, uint32(index))
		if err != nil {
			return nil, err
		}
	}
	return result, nil
}

func (s *SMTInternalizerState) InternalizeInstance(instance *SMTQIInstance) error {
	return s.internalizeInstance(instance, nil)
}

func (s *SMTInternalizerState) internalizeInstance(instance *SMTQIInstance, arguments []ast.ASTHandle) error {
	if instance == nil || instance.manager != s.manager {
		return ast.ErrASTDomain
	}
	if instance.ReducedTrue() {
		return nil
	}
	lemma, err := instance.Lemma()
	if err != nil {
		return err
	}
	proof, err := instance.Proof()
	if err != nil {
		return err
	}
	return s.assertExpression(lemma, proof, instance.Generation(), arguments)
}

// Bound gate operands already have their variable in this solver. An outer
// NOT uses its immediate operand's variable, as Literal does. If that operand
// is also a NOT, Internalize can still have work to do beneath it.
func (s *SMTInternalizerState) boundInstanceLiteral(argument ast.ASTHandle) (SMTLiteral, bool) {
	if s.closed || s.pendingPop != nil || s.closing || s.context.assignments.s != s {
		return SMTNullLiteral, false
	}
	if v, found := s.boolVar.lookup(argument); found && s.notChild(v).IsNull() {
		return NewSMTLiteral(v, false), true
	}
	_, child, err := s.manager.IsNot(argument)
	if err == nil && !child.IsNull() {
		if v, found := s.boolVar.lookup(child); found && s.notChild(v).IsNull() {
			return NewSMTLiteral(v, true), true
		}
	}
	return SMTNullLiteral, false
}

// binaryClauseBaseLevel is context::m_base_lvl as use_binary_clause_opt reads
// it.
//
// use_binary_clause_opt also refuses binary clauses whose variables were
// internalized above scope 0, and any clause once m_base_lvl > 0. Source
// additionally permits binary lemmas above scope 0 when relevancy is below 2;
// the clause trail here pops every binary record created above scope 0, so
// those lemmas stay ordinary clauses.
func (s *SMTInternalizerState) binaryClauseBaseLevel() uint32 { return s.baseLevel }

// numSearchConflicts is context::get_num_conflicts, m_num_conflicts: the
// conflicts since the last init_search.
func (s *SMTInternalizerState) numSearchConflicts() uint32 {
	return s.statistics.NumConflicts - s.searchConflictBase
}

// pushBaseScope is the m_base_lvl++ and m_search_lvl++ of context::push,
// after its push_scope.
func (s *SMTInternalizerState) pushBaseScope() { s.baseLevel++; s.searchLevel++ }

// popToBaseLevel is context::pop_to_base_lvl.
func (s *SMTInternalizerState) popToBaseLevel() error {
	if s.scopeLevel > s.baseLevel {
		return s.PopScopes(s.scopeLevel - s.baseLevel)
	}
	return nil
}
