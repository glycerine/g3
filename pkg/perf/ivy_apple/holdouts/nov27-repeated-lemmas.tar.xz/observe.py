from pathlib import Path
import json,os,subprocess as sp,tempfile
p=Path.cwd();w=Path(__file__).resolve().parent;prev=Path('/tmp/g3-first-qi')
ov=json.loads((prev/'check-g3.json').read_text());rep=ov['Replace']
def put(path,s):
 f=w/path.name;f.write_text(s);rep[str(path)]=str(f)
path=p/'smtcore/smt_qi_instance.go';s=Path(rep[str(path)]).read_text()
k='type SMTQIInstanceBuilder struct {';s=s.replace(k,'''type observedQIKey struct{ q,body ast.ASTHandle }
type observedQICall struct{ rewritten,lemma ast.ASTHandle; charge uint64; cl *SMTClause; auxIndex int; scope uint32 }
'''+k+'''
 observed map[observedQIKey]observedQICall
 key observedQIKey
 prev observedQICall
 seen,liveRewritten,liveLemma bool
 beforeCharge,charge uint64
 rewritten ast.ASTHandle
''')
k='fd:=studyFD();a:=studyRd(fd);if err = rw.Rewrite(instance, simplified);'
s=s.replace(k,'''b.key=observedQIKey{prepared.quantifier,instance};b.prev,b.seen=b.observed[b.key];b.liveRewritten=b.seen && b.manager.IsLiveHandle(b.prev.rewritten);b.liveLemma=b.seen && b.manager.IsLiveHandle(b.prev.lemma);b.beforeCharge=b.manager.ResourceLimit().Count()
'''+k)
k='studyLog(fd,a,"R",b.manager.IsTrue(rewritten))';s=s.replace(k,k+';b.rewritten=rewritten;b.charge=b.manager.ResourceLimit().Count()-b.beforeCharge')
k='fd:=studyFD();a:=studyRd(fd);err=internalizer.internalizeInstance';s=s.replace(k,'''lemma,_:=result.Lemma();fd:=studyFD()
 if fd>=0{
 recorded:=false;for _,l:=range b.registry.schedule.instances{if l==lemma{recorded=true;break}}
 cl:=b.prev.cl;active:=cl!=nil && b.prev.auxIndex<len(internalizer.auxClauses) && internalizer.auxClauses[b.prev.auxIndex]==cl && !cl.closed && !cl.Deleted() && cl.activeClause()!=nil
 bound:=0;args:=locals.arguments;if args==nil{args,_=internalizer.argumentHandles(lemma)};for _,arg:=range args{if _,ok:=internalizer.boundInstanceLiteral(arg);ok{bound++}}
 fmt.Fprintln(os.Stderr,"OBS",b.seen,b.liveRewritten,b.prev.rewritten==b.rewritten,b.charge==b.prev.charge,b.liveLemma,b.prev.lemma==lemma,recorded,cl!=nil,active,len(args),bound,b.prev.scope,scope,b.charge)
 }
 internalizer.observing=lemma;internalizer.observedClause=nil;a:=studyRd(fd);err=internalizer.internalizeInstance''')
k='studyLog(fd,a,"A",false);';s=s.replace(k,k+'''internalizer.observing=ast.ASTHandle{};if b.observed==nil{b.observed=make(map[observedQIKey]observedQICall)};b.observed[b.key]=observedQICall{b.rewritten,lemma,b.charge,internalizer.observedClause,internalizer.observedPosition,scope};''')
put(path,s)
path=p/'smtcore/smt_internalizer_state.go';s=path.read_text().replace('type SMTInternalizerState struct {','type SMTInternalizerState struct {\n observing ast.ASTHandle;observedClause *SMTClause; observedPosition int');put(path,s)
path=p/'smtcore/smt_internalizer.go';s=path.read_text();i=s.index('func (s *SMTInternalizerState) assertExpression');h,t=s[:i],s[i:];k='if err = s.addRootClause(literals, proof); err != nil {';t=t.replace(k,'start:=len(s.auxClauses);'+k,1);k='if s.relevancy != nil {';t=t.replace(k,'if s.observing==expression && len(s.auxClauses)==start+1{s.observedClause=s.auxClauses[start];s.observedPosition=start};'+k,1);put(path,h+t)
j=w/'obs.json';j.write_text(json.dumps(ov));front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve()
with tempfile.TemporaryDirectory(prefix='qi-observe-',dir=Path.home()/'tmp') as d:
 sp.run(['go','build','-tags','xtrace_off','-mod=readonly','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-overlay',j,'-o',w/'observe','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=d,GOTMPDIR=d),check=True)
