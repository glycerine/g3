from pathlib import Path
w=Path(__file__).resolve().parent;exec((w/'expand.py').read_text().split("with (w/'expanded.csv'")[0])
exec('def normalized'+(w/'normalize.py').read_text().split('def normalized',1)[1].split("with (w/'normalize.csv'")[0])
def constants(t,into,bound=frozenset()):
 if isinstance(t,str):
  if t not in bound and t in sig and not sig[t][0] and sig[t][1]!='Bool':into[sig[t][1]].add(t)
 elif t[0]=='forall':constants(t[2],into,bound.union(n for n,st in t[1]))
 else:
  for a in t[1:]:constants(a,into,bound)
with (w/'goalpool.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal seed terms extra rows_bytes answer'.split())
 for b,g in [(12,8),(14,8),(13,8),(15,8),(16,1)]:
  path=w/'captures'/f'8-{b}-{g}.smt2';fs=parse(normalized(path));old={x[1] for x in parse(path.read_text()) if x[0]=='declare-fun'};decl=[x for x in fs if x[0].startswith('declare')];sig={x[1]:(x[2],x[3]) for x in decl if x[0]=='declare-fun'};rules=[expand(x[1],{}) for x in fs if x[0]=='assert']; goals=[expand(x[1],{}) for x in fs[fs.index(('push',))+1:] if x[0]=='assert']
  for r in rules:audit(r,True)
  for mode in ['goal','goal+units','goal+fresh','goal+units+fresh']:
   pool=collections.defaultdict(set)
   for t in goals:constants(t,pool)
   if 'units' in mode:
    for r in rules:
     v=r[1] if isinstance(r,tuple) and r[0]=='not' else r
     if isinstance(v,tuple) and (v[0]=='=' or v[0] in sig):constants(v,pool)
   if 'fresh' in mode:
    for n,(dom,sort) in sig.items():
     if not dom and sort!='Bool' and n not in old:pool[sort].add(n)
   n=sum(map(len,pool.values()));rows,_,_=go(pool);extra=collections.defaultdict(set)
   for r in rows:apps(r,extra)
   for sort,v in extra.items():pool[sort].update(v)
   _,ans,size=go(pool);out.writerow([b,g,mode,n,sum(map(len,extra.values())),size,ans]);f.flush()
