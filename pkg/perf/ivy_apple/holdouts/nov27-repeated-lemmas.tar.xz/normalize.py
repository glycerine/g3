from pathlib import Path
import csv,subprocess as sp,os,sys,time,re
p=Path.cwd();w=Path(__file__).resolve().parent
sys.path[:0]=[str(p.parent/'build/python'),str(p/'perf/ivy_apple/goal_instances/finite_models')]
import z3
from syntax import parse,smt
def normalized(path):
 forms=parse(path.read_text());decls='\n'.join(smt(x) for x in forms if x[0].startswith('declare-'));base,goal=[x for x in forms if x[0]=='assert']
 ctx=z3.Context(); tactic=z3.Then(z3.Tactic('simplify',ctx=ctx),z3.With(z3.Tactic('nnf',ctx=ctx),mode='full'))
 res=[];declarations={}
 for row in [base,goal]:
  g=tactic(z3.parse_smt2_string(decls+'\n'+smt(row),ctx=ctx))[0];s=z3.Solver(ctx=ctx);s.add(*list(g));rows=parse(s.sexpr())
  for x in rows:
   if x[0].startswith('declare-'):declarations[x]=1
  res.append([x for x in rows if x[0]=='assert'])
 return '\n'.join(map(smt,[*declarations,*res[0],('push',),*res[1],('check-sat',),('get-info',':all-statistics')]))
with (w/'normalize.csv').open('w') as f:
 out=csv.writer(f);out.writerow('goal engine instructions instances decisions conflicts'.split())
 for path in sorted((w/'captures').glob('*.smt2')):
  script=normalized(path)
  for name,exe in [('g3','/tmp/g3-witness-match/g3'),('native',p.parent/'build/z3')]:
   stat=w/'norm.stat';r=sp.run(['taskset','-c','30','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,'smt.macro_finder=true','-in'],input=script,text=True,capture_output=True,timeout=20,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'))
   assert r.returncode==0 and not r.stderr and r.stdout.startswith('unsat\n'),(path,r.stdout[:300],r.stderr[:300])
   a=dict(re.findall(r':([\w-]+)\s+(\d+)',r.stdout));ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
   out.writerow([path.stem,name,ins,*[a.get(k,0) for k in ('quant-instantiations','decisions','conflicts')]]);f.flush()
