import csv
from collections import defaultdict
from pathlib import Path
w=Path(__file__).resolve().parent
rows=list(csv.DictReader((w/'events.csv').open()))
for n in sorted({(r['case'],r['batch'],r['goal']) for r in rows}):
 a=[r for r in rows if (r['case'],r['batch'],r['goal'])==n and r['round']=='0' and r['hit']=='1']
 if not a:continue
 print(*n,len(a),{k:sum(r[k]=='true' for r in a) for k in 'seen rewrite_live same_rewrite same_charge lemma_live same_lemma recorded previous_clause active_clause'.split()},'bound',sum(int(r['bound']) for r in a),sum(int(r['arguments']) for r in a))
