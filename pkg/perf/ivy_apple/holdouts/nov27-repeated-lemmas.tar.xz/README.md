# Repeated quantifier instances and small ground proofs

Baseline g3 commit 50af58ff9. Run this command from the extracted directory with paths to the g3 shell and this repository's native Z3 shell. It checks the five original obligations and their five ground reductions with both executables.

    python3 verify_ground.py /path/to/g3 /path/to/z3

The captures directory contains all 35 selected automatic Ticket obligations. Each sparse-*.smt2 is standalone. A SAT result on a weakened input is inconclusive about the original. The scripts only accept an UNSAT result as a proof. cores.csv uses a separate experiment that preserved the goal and selected original premises.

To replicate the ground experiments on the original host, extract this archive at /tmp/g3-repeat-qi. Run scripts from pkg with the fork's Python bindings at ../build/python and shells at ../build/z3 and /tmp/g3-witness-match/g3. Place the included hints.py under /tmp/g3-witness-match. Run ground.py, expand.py, shrink.py, sparse.py, normalize.py, goalpool.py and diagonal.py. The reducer and sparse extractor traverse captures in a fixed order so the fresh Skolem names correspond across processes. shrink.py calls both solvers for each accepted reduction. Hold PYTHONHASHSEED at 0 for reproducible reductions. The native fork's tactic implementation provides normalization in these offline experiments.

observe.py and parts.py layer counters over the November 27 first-push queue comparison's check-g3 overlay. run.py and parts_run.py reproduce the event captures. The *.json maps and Go source snapshots retain the exact measured replacements. Paths reference the local GoIvy frontend, compiler profile, study.mod, native golden transcripts and example corpus from the preceding verifier studies. replay.py builds a deliberately optimistic weak-cache price experiment. Use EXE=trial CASES='8 3 6 2 4 12 10 5' MODES='off identity all' ROUNDS=3 CPU=28 STEM=weak with replay_run.py. The cached charge can differ from the actual one. This binary is for measurement only.

Hardware counters cover the solver thread in events.csv and parts.csv, and the complete verifier process in weak.csv. Diagnostic writes affect inclusive assertion timing in parts.csv. Use its four disjoint subwindows for attribution. The split, normalized and sparse shell counters include startup and parsing. They exclude proof discovery and external normalization time. Consult PERF_STUDY.md for the complete verifier comparison and distinctions between replay protocols.
