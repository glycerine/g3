from pathlib import Path
import os,csv,subprocess as sp,sys
w=Path(__file__).resolve().parent;ref=Path('/tmp/g3-reduction-rows');cases=(ref/'compat.txt').read_text().splitlines();ex=Path('/home/jaten/ivy/ivy-lang-examples')
with (w/'events.csv').open('w') as f:
 out=csv.writer(f);out.writerow('case round batch goal hit seen rewrite_live same_rewrite same_charge lemma_live same_lemma recorded previous_clause active_clause arguments bound old_scope scope charge rewrite_instructions assert_instructions'.split())
 for n in (8,3,6,2):
  d=ref/'compat'/str(n)/'1/native'
  for i in range(3):
   r=sp.run(['taskset','-c','23',w/'observe',ex/cases[n-1]],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=60)
   rest=bytearray();active=None;obs=None
   for l in r.stderr.splitlines(keepends=True):
    a=l.decode().strip().split()
    if l.startswith(b'OPEN '):active=a[1:]
    elif l.startswith(b'STAGE-COUNT '):active=None
    elif active and a and a[0] in ('S','C','R','A','OBS'):
     if a[0]=='S':hit=a[1]
     if a[0]=='R':rewrite=a[2]
     if a[0]=='OBS':obs=a[1:]
     if a[0]=='A':assert obs;out.writerow([n,i,*active,hit,*obs,rewrite,a[2]]);obs=None
    else:rest.extend(l)
   assert (r.returncode,r.stdout,rest)==(0,(d/'stdout').read_bytes(),(d/'stderr').read_bytes()),rest[-400:];f.flush()
