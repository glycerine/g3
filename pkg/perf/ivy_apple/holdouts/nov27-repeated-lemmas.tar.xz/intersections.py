from pathlib import Path
from collections import defaultdict
import sys,csv,os,subprocess as sp
w=Path(__file__).resolve().parent;p=Path.cwd();sys.path.insert(0,str(p/'perf/ivy_apple/goal_instances/finite_models'));from syntax import parse,smt
sys.path.insert(0,'/tmp/g3-witness-match');from hints import expand,conjuncts
stage=list(csv.DictReader(open('/tmp/g3-first-qi/stage-goals.csv')))
rows={(int(r['batch']),int(r['goal'])):int(r['g3']) for r in stage if r['case'].endswith('ticket_l2s_auto.ivy') and r['phase']=='check' and int(r['g3'])>5000000}
d=w/'captures';d.mkdir(exist_ok=True);ex=Path('/home/jaten/ivy/ivy-lang-examples');spec='doc/examples/liveness/ticket_l2s_auto.ivy'
r=sp.run(['/tmp/g3-ticket-stages/dump-native',ex/spec],cwd=w,env=dict(os.environ,XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TICKET_CASE='8',TICKET_DIR=str(d),TICKET_TARGETS=','+','.join(f'{b}/{g}' for b,g in rows)+','),capture_output=True,check=True)
ref=Path('/tmp/g3-reduction-rows/compat/8/1/native');assert r.stdout==(ref/'stdout').read_bytes() and r.stderr==(ref/'stderr').read_bytes()
seen=defaultdict(list)
with (w/'intersections.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal prior_batch prior_goal common total result instructions_window'.split())
 for key,cost in sorted(rows.items()):
  b,g=key;src=parse((d/f'8-{b}-{g}.smt2').read_text());base,goal=[expand(v[1],{}) for v in src if v[0]=='assert'];declarations=[v for v in src if v[0].startswith('declare-')]
  base=list(dict.fromkeys(conjuncts(base)))
  for prev,other in seen[goal]:
   if b==prev[0]:continue
   common=[v for v in base if v in other];text='\n'.join(map(smt,declarations+[('assert',v) for v in common]+[('assert',goal),('check-sat',)]))
   rr=sp.run([p.parent/'build/z3','smt.macro_finder=true','-T:2','-in'],input=text,text=True,capture_output=True,timeout=5);answer=rr.stdout.strip();assert rr.returncode==0 and answer in ('unsat','sat','unknown','timeout'),(answer[:200],rr.stderr)
   if answer=='unsat':
    r=sp.run(['/tmp/g3-witness-match/g3','smt.macro_finder=true','-T:3','-in'],input=text,text=True,capture_output=True,timeout=6);answer+='-'+r.stdout.strip();assert r.returncode==0
   out.writerow([b,g,*prev,len(common),len(base),answer,cost]);f.flush()
  seen[goal].append((key,set(base)))
