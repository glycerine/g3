(declare-sort ticket_protocol.ticket)
(declare-sort ticket_protocol.thread)
(declare-sort index)
(declare-fun __ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun |__fml:t| () ticket_protocol.thread)
(declare-fun ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun __ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun |__fml:y| () ticket_protocol.ticket)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun __ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun |__new_fml:x| () ticket_protocol.ticket)
(declare-fun __ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun ticket_protocol.scheduled.now () Bool)
(declare-fun __m_ticket_protocol.scheduled.now () Bool)
(declare-fun |__new_fml:val| () ticket_protocol.thread)
(declare-fun ticket_protocol.scheduled.value () ticket_protocol.thread)
(declare-fun |<:ticket_protocol.ticket:ticket_protocol.ticket|
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun |0:ticket_protocol.ticket| () ticket_protocol.ticket)
(declare-fun ticket_protocol.ticket.succ
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun |0:index| () index)
(declare-fun index.succ (index index) Bool)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(declare-fun ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun __ticket_protocol.scheduled.now () Bool)
(declare-fun @M () ticket_protocol.ticket)
(declare-fun @T () ticket_protocol.thread)
(assert (let ((a!1 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (or (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                 (not (__ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
      (a!2 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (or (not (__ticket_protocol.pc1 |T:ticket_protocol.thread|))
                 (not (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!3 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (or (not (__ticket_protocol.pc2 |T:ticket_protocol.thread|))
                 (not (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!4 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|K2:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (__ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |K1:ticket_protocol.ticket|)
                      (__ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |K2:ticket_protocol.ticket|))
                 (= |K1:ticket_protocol.ticket| |K2:ticket_protocol.ticket|))))
      (a!5 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                    (|T2:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (ticket_protocol.pc3 |T1:ticket_protocol.thread|)
                      (ticket_protocol.pc3 |T2:ticket_protocol.thread|))
                 (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!6 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (not (= __ticket_protocol.next_ticket
                              |0:ticket_protocol.ticket|))
                      (__ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|))
                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                   |M:ticket_protocol.ticket|
                   __ticket_protocol.next_ticket))))
      (a!7 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (or (__ticket_protocol.pc2 |T:ticket_protocol.thread|)
                     (ticket_protocol.pc3 |T:ticket_protocol.thread|))
                 (not (= __ticket_protocol.next_ticket
                         |0:ticket_protocol.ticket|)))))
      (a!8 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T1:ticket_protocol.thread| ticket_protocol.thread)
                    (|T2:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (__ticket_protocol.m
                        |T1:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|)
                      (__ticket_protocol.m
                        |T2:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|)
                      (not (= |M:ticket_protocol.ticket|
                              |0:ticket_protocol.ticket|)))
                 (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!9 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (__ticket_protocol.pc2 |T:ticket_protocol.thread|)
                      (__ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|))
                 (or (= ticket_protocol.service |M:ticket_protocol.ticket|)
                     (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                       ticket_protocol.service
                       |M:ticket_protocol.ticket|)))))
      (a!10 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (not (and (not (__ticket_protocol.pc1 |T1:ticket_protocol.thread|))
                        (not (__ticket_protocol.pc1 |T2:ticket_protocol.thread|))
                        (__ticket_protocol.m
                          |T1:ticket_protocol.thread|
                          |0:ticket_protocol.ticket|)
                        (__ticket_protocol.m
                          |T2:ticket_protocol.thread|
                          |0:ticket_protocol.ticket|)
                        (not (= |T1:ticket_protocol.thread|
                                |T2:ticket_protocol.thread|))))))
      (a!11 (forall ((|Y:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                    |__new_fml:x|
                    |Y:ticket_protocol.ticket|)
                  (or (= |__fml:y| |Y:ticket_protocol.ticket|)
                      (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                        |__fml:y|
                        |Y:ticket_protocol.ticket|)))))
      (a!12 (forall ((|T:index| index) (|U:index| index) (|V:index| index))
              (=> (and (|<:index:index| |T:index| |U:index|)
                       (|<:index:index| |U:index| |V:index|))
                  (|<:index:index| |T:index| |V:index|))))
      (a!13 (forall ((|T:index| index) (|U:index| index))
              (not (and (|<:index:index| |T:index| |U:index|)
                        (|<:index:index| |U:index| |T:index|)))))
      (a!14 (forall ((|T:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|U:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|V:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                         |T:ticket_protocol.ticket|
                         |U:ticket_protocol.ticket|)
                       (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                         |U:ticket_protocol.ticket|
                         |V:ticket_protocol.ticket|))
                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                    |T:ticket_protocol.ticket|
                    |V:ticket_protocol.ticket|))))
      (a!15 (forall ((|T:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|U:ticket_protocol.ticket| ticket_protocol.ticket))
              (not (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                          |T:ticket_protocol.ticket|
                          |U:ticket_protocol.ticket|)
                        (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                          |U:ticket_protocol.ticket|
                          |T:ticket_protocol.ticket|)))))
      (a!16 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread)
                     (|V1:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (ticket_protocol.m
                   |V0:ticket_protocol.thread|
                   |V1:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      (= |V1:ticket_protocol.ticket|
                         __ticket_protocol.next_ticket)
                      (__ticket_protocol.m
                        |V0:ticket_protocol.thread|
                        |V1:ticket_protocol.ticket|)))))
      (a!17 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.pc1 |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      false
                      (__ticket_protocol.pc1 |V0:ticket_protocol.thread|)))))
      (a!18 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (= (ticket_protocol.pc2 |V0:ticket_protocol.thread|)
                 (ite (and (= |V0:ticket_protocol.thread| |__fml:t|))
                      true
                      (__ticket_protocol.pc2 |V0:ticket_protocol.thread|))))))
  (and (not __ticket_protocol.scheduled.now)
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (or (__ticket_protocol.pc1 |T:ticket_protocol.thread|)
             (__ticket_protocol.pc2 |T:ticket_protocol.thread|)
             (ticket_protocol.pc3 |T:ticket_protocol.thread|)))
       a!1
       a!2
       a!3
       a!4
       a!5
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (= __ticket_protocol.next_ticket |0:ticket_protocol.ticket|)
             (__ticket_protocol.m
               |T:ticket_protocol.thread|
               |0:ticket_protocol.ticket|)))
       a!6
       a!7
       a!8
       a!9
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (ticket_protocol.pc3 |T:ticket_protocol.thread|)
             (__ticket_protocol.m
               |T:ticket_protocol.thread|
               ticket_protocol.service)))
       (or (= ticket_protocol.service __ticket_protocol.next_ticket)
           (|<:ticket_protocol.ticket:ticket_protocol.ticket|
             ticket_protocol.service
             __ticket_protocol.next_ticket))
       a!10
       (__ticket_protocol.pc1 |__fml:t|)
       (|<:ticket_protocol.ticket:ticket_protocol.ticket|
         |__new_fml:x|
         |__fml:y|)
       a!11
       (ticket_protocol.ticket.succ |__new_fml:x| |__fml:y|)
       (forall ((|X:index| index) (|Y:index| index) (|Z:index| index))
         (let ((a!1 (and (|<:index:index| |X:index| |Z:index|)
                         (not (and (|<:index:index| |X:index| |Y:index|)
                                   (|<:index:index| |Y:index| |Z:index|))))))
           (=> (index.succ |X:index| |Z:index|) a!1)))
       a!12
       a!13
       (forall ((|T:index| index) (|U:index| index))
         (or (|<:index:index| |T:index| |U:index|)
             (= |T:index| |U:index|)
             (|<:index:index| |U:index| |T:index|)))
       (forall ((|X:index| index))
         (or (= |0:index| |X:index|) (|<:index:index| |0:index| |X:index|)))
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                (|Y:ticket_protocol.ticket| ticket_protocol.ticket)
                (|Z:ticket_protocol.ticket| ticket_protocol.ticket))
         (let ((a!1 (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                           |X:ticket_protocol.ticket|
                           |Z:ticket_protocol.ticket|)
                         (not (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                     |X:ticket_protocol.ticket|
                                     |Y:ticket_protocol.ticket|)
                                   (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                     |Y:ticket_protocol.ticket|
                                     |Z:ticket_protocol.ticket|))))))
           (=> (ticket_protocol.ticket.succ
                 |X:ticket_protocol.ticket|
                 |Z:ticket_protocol.ticket|)
               a!1)))
       a!14
       a!15
       (forall ((|T:ticket_protocol.ticket| ticket_protocol.ticket)
                (|U:ticket_protocol.ticket| ticket_protocol.ticket))
         (or (|<:ticket_protocol.ticket:ticket_protocol.ticket|
               |T:ticket_protocol.ticket|
               |U:ticket_protocol.ticket|)
             (= |T:ticket_protocol.ticket| |U:ticket_protocol.ticket|)
             (|<:ticket_protocol.ticket:ticket_protocol.ticket|
               |U:ticket_protocol.ticket|
               |T:ticket_protocol.ticket|)))
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (or (= |0:ticket_protocol.ticket| |X:ticket_protocol.ticket|)
             (|<:ticket_protocol.ticket:ticket_protocol.ticket|
               |0:ticket_protocol.ticket|
               |X:ticket_protocol.ticket|)))
       (= |__new_fml:val| |__fml:t|)
       (= ticket_protocol.scheduled.value |__new_fml:val|)
       __m_ticket_protocol.scheduled.now
       (not ticket_protocol.scheduled.now)
       a!16
       (= |__new_fml:x| __ticket_protocol.next_ticket)
       (= ticket_protocol.next_ticket |__fml:y|)
       a!17
       a!18)))
(assert (let ((a!1 (=> (and (not (= ticket_protocol.next_ticket
                            |0:ticket_protocol.ticket|))
                    (ticket_protocol.m @T @M))
               (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                 @M
                 ticket_protocol.next_ticket))))
  (and (not a!1))))

(check-sat)
(get-info :all-statistics)
