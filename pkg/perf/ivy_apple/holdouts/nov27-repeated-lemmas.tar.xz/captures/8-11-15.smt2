(declare-sort ticket_protocol.ticket)
(declare-sort ticket_protocol.thread)
(declare-sort index)
(declare-fun __m_l2s_d_a (ticket_protocol.ticket) Bool)
(declare-fun _X () ticket_protocol.ticket)
(declare-fun l2s_d (ticket_protocol.ticket) Bool)
(declare-fun __m_l2s_d (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.next_ticket () ticket_protocol.ticket)
(declare-fun __l2s_d (ticket_protocol.ticket) Bool)
(declare-fun ticket_protocol.service () ticket_protocol.ticket)
(declare-fun __l2s_w_0 (ticket_protocol.thread) Bool)
(declare-fun l2s_g_0 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.scheduled.value () ticket_protocol.thread)
(declare-fun ticket_protocol.scheduled.now () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun l2s_w_0 (ticket_protocol.thread) Bool)
(declare-fun __l2s_w_1 () Bool)
(declare-fun l2s_g_2 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun ticket_protocol.m
             (ticket_protocol.thread ticket_protocol.ticket)
             Bool)
(declare-fun _T () ticket_protocol.thread)
(declare-fun ticket_protocol.pc2 (ticket_protocol.thread) Bool)
(declare-fun l2s_w_1 () Bool)
(declare-fun __l2s_s_1 (ticket_protocol.thread) Bool)
(declare-fun ticket_protocol.pc3 (ticket_protocol.thread) Bool)
(declare-fun l2s_s_1 (ticket_protocol.thread) Bool)
(declare-fun __l2s_s_2 (ticket_protocol.ticket) Bool)
(declare-fun |<:ticket_protocol.ticket:ticket_protocol.ticket|
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun l2s_s_2 (ticket_protocol.ticket) Bool)
(declare-fun __l2s_s_0 (ticket_protocol.thread) Bool)
(declare-fun l2s_s_0 (ticket_protocol.thread) Bool)
(declare-fun __l2s_s_3 (ticket_protocol.ticket) Bool)
(declare-fun l2s_s_3 (ticket_protocol.ticket) Bool)
(declare-fun __l2s_saved () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun __l2s_a_a (ticket_protocol.ticket) Bool)
(declare-fun l2s_a (ticket_protocol.ticket) Bool)
(declare-fun l2s_d (index) Bool)
(declare-fun __l2s_a (index) Bool)
(declare-fun l2s_a (index) Bool)
(declare-fun __l2s_frozen () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun |0:ticket_protocol.ticket| () ticket_protocol.ticket)
(declare-fun ticket_protocol.ticket.succ
             (ticket_protocol.ticket ticket_protocol.ticket)
             Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun |0:index| () index)
(declare-fun index.succ (index index) Bool)
(declare-fun l2s_g_1 (ticket_protocol.thread) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun ticket_protocol.pc1 (ticket_protocol.thread) Bool)
(declare-fun l2s_init_2 () Bool)
(declare-fun l2s_init_1 (ticket_protocol.thread) Bool)
(declare-fun l2s_init_0 (ticket_protocol.thread) Bool)
(declare-fun @X () ticket_protocol.ticket)
(assert (let ((a!1 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                    (|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (and (ticket_protocol.pc1 |T:ticket_protocol.thread|)
                      (ticket_protocol.m
                        |T:ticket_protocol.thread|
                        |M:ticket_protocol.ticket|)
                      (not (= |M:ticket_protocol.ticket|
                              |0:ticket_protocol.ticket|)))
                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                   |M:ticket_protocol.ticket|
                   ticket_protocol.service))))
      (a!2 (forall ((|K:ticket_protocol.ticket| ticket_protocol.ticket))
             (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                          (and (ticket_protocol.m
                                 |T:ticket_protocol.thread|
                                 |K:ticket_protocol.ticket|)
                               (not (ticket_protocol.pc1
                                      |T:ticket_protocol.thread|))))))
               (=> (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                          |K:ticket_protocol.ticket|
                          ticket_protocol.next_ticket)
                        (or (= ticket_protocol.service
                               |K:ticket_protocol.ticket|)
                            (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                              ticket_protocol.service
                              |K:ticket_protocol.ticket|)))
                   a!1))))
      (a!3 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
             (let ((a!1 (and (or (= ticket_protocol.service
                                    |X:ticket_protocol.ticket|)
                                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                   ticket_protocol.service
                                   |X:ticket_protocol.ticket|))
                             (or (= |X:ticket_protocol.ticket| _X)
                                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                   |X:ticket_protocol.ticket|
                                   _X))
                             (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                               (and (ticket_protocol.m
                                      |T:ticket_protocol.thread|
                                      |X:ticket_protocol.ticket|)
                                    (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|))))))
               (=> (and (not l2s_init_2)
                        (or (not __l2s_waiting) (not __l2s_w_1)))
                   (=> a!1 (and (__l2s_d |X:ticket_protocol.ticket|)))))))
      (a!4 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> (or (= |X:ticket_protocol.ticket| ticket_protocol.next_ticket)
                     (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                       |X:ticket_protocol.ticket|
                       ticket_protocol.next_ticket))
                 (and (__l2s_d |X:ticket_protocol.ticket|)))))
      (a!5 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
             (let ((a!1 (and (or (= ticket_protocol.service
                                    |X:ticket_protocol.ticket|)
                                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                   ticket_protocol.service
                                   |X:ticket_protocol.ticket|))
                             (or (= |X:ticket_protocol.ticket| _X)
                                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                   |X:ticket_protocol.ticket|
                                   _X))
                             (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                               (and (ticket_protocol.m
                                      |T:ticket_protocol.thread|
                                      |X:ticket_protocol.ticket|)
                                    (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|))))))
               (=> (and (not l2s_init_2) (not __l2s_waiting))
                   (=> (not (=> a!1 false))
                       (and (__l2s_a_a |X:ticket_protocol.ticket|)))))))
      (a!6 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
             (=> (and (not l2s_init_2) __l2s_saved)
                 (=> (not (__l2s_s_3 |X:ticket_protocol.ticket|))
                     (and (__l2s_a_a |X:ticket_protocol.ticket|))))))
      (a!7 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
             (let ((a!1 (and (or (= ticket_protocol.service
                                    |X:ticket_protocol.ticket|)
                                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                   ticket_protocol.service
                                   |X:ticket_protocol.ticket|))
                             (or (= |X:ticket_protocol.ticket| _X)
                                 (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                   |X:ticket_protocol.ticket|
                                   _X))
                             (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                               (and (ticket_protocol.m
                                      |T:ticket_protocol.thread|
                                      |X:ticket_protocol.ticket|)
                                    (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|))))))
               (=> (not l2s_init_2)
                   (=> (and __l2s_saved (__l2s_s_3 |X:ticket_protocol.ticket|))
                       (=> a!1 false))))))
      (a!8 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (__l2s_s_0 |T:ticket_protocol.thread|)))
      (a!9 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (=> (__l2s_s_0 |T:ticket_protocol.thread|)
                 (not (__l2s_w_0 |T:ticket_protocol.thread|)))))
      (a!11 (exists ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (and (or (= ticket_protocol.service
                                     |X:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |X:ticket_protocol.ticket|))
                              (or (= |X:ticket_protocol.ticket| _X)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    |X:ticket_protocol.ticket|
                                    _X))
                              (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                                (and (ticket_protocol.m
                                       |T:ticket_protocol.thread|
                                       |X:ticket_protocol.ticket|)
                                     (ticket_protocol.pc2
                                       |T:ticket_protocol.thread|))))))
                (and (not (__l2s_s_3 |X:ticket_protocol.ticket|))
                     (=> a!1 false)))))
      (a!12 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_init_1 |T:ticket_protocol.thread|)
                  (l2s_g_1 |T:ticket_protocol.thread|))))
      (a!13 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (__l2s_s_0 |T:ticket_protocol.thread|)
                       __l2s_saved
                       (not l2s_init_2)
                       (__l2s_w_0 |T:ticket_protocol.thread|))
                  (and (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         ticket_protocol.service)
                       (ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
      (a!14 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (ticket_protocol.m
                                  |T:ticket_protocol.thread|
                                  |X:ticket_protocol.ticket|)
                                (or (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|)
                                    (ticket_protocol.pc3
                                      |T:ticket_protocol.thread|))))))
              (let ((a!2 (and (or (= ticket_protocol.service
                                     |X:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |X:ticket_protocol.ticket|))
                              (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                |X:ticket_protocol.ticket|
                                _X)
                              a!1)))
                (=> true (=> a!2 (and (__l2s_d |X:ticket_protocol.ticket|))))))))
      (a!15 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (ticket_protocol.m
                                  |T:ticket_protocol.thread|
                                  |X:ticket_protocol.ticket|)
                                (or (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|)
                                    (ticket_protocol.pc3
                                      |T:ticket_protocol.thread|))))))
              (let ((a!2 (and (or (= ticket_protocol.service
                                     |X:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |X:ticket_protocol.ticket|))
                              (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                |X:ticket_protocol.ticket|
                                _X)
                              a!1)))
                (=> (and true (not __l2s_waiting))
                    (=> (not (=> a!2 false))
                        (and (__l2s_a_a |X:ticket_protocol.ticket|))))))))
      (a!16 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and true __l2s_saved)
                  (=> (not (__l2s_s_2 |X:ticket_protocol.ticket|))
                      (and (__l2s_a_a |X:ticket_protocol.ticket|))))))
      (a!17 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (ticket_protocol.m
                                  |T:ticket_protocol.thread|
                                  |X:ticket_protocol.ticket|)
                                (or (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|)
                                    (ticket_protocol.pc3
                                      |T:ticket_protocol.thread|))))))
              (let ((a!2 (and (or (= ticket_protocol.service
                                     |X:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |X:ticket_protocol.ticket|))
                              (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                |X:ticket_protocol.ticket|
                                _X)
                              a!1)))
                (=> true
                    (=> (and __l2s_saved (__l2s_s_2 |X:ticket_protocol.ticket|))
                        (=> a!2 false)))))))
      (a!18 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (__l2s_s_1 |T:ticket_protocol.thread|)))
      (a!19 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (__l2s_s_1 |T:ticket_protocol.thread|)
                  (not (__l2s_w_0 |T:ticket_protocol.thread|)))))
      (a!21 (exists ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (ticket_protocol.m
                                  |T:ticket_protocol.thread|
                                  |X:ticket_protocol.ticket|)
                                (or (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|)
                                    (ticket_protocol.pc3
                                      |T:ticket_protocol.thread|))))))
              (let ((a!2 (and (or (= ticket_protocol.service
                                     |X:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |X:ticket_protocol.ticket|))
                              (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                |X:ticket_protocol.ticket|
                                _X)
                              a!1)))
                (and (not (__l2s_s_2 |X:ticket_protocol.ticket|))
                     (=> a!2 false))))))
      (a!22 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (__l2s_s_1 |T:ticket_protocol.thread|)
                       __l2s_saved
                       true
                       (__l2s_w_0 |T:ticket_protocol.thread|))
                  (and (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         ticket_protocol.service)
                       (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!23 (not (and (not l2s_init_2) (or (not __l2s_waiting) (not __l2s_w_1)))))
      (a!24 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (and (or (= ticket_protocol.service
                                     |X:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |X:ticket_protocol.ticket|))
                              (or (= |X:ticket_protocol.ticket| _X)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    |X:ticket_protocol.ticket|
                                    _X))
                              (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                                (and (ticket_protocol.m
                                       |T:ticket_protocol.thread|
                                       |X:ticket_protocol.ticket|)
                                     (ticket_protocol.pc2
                                       |T:ticket_protocol.thread|))))))
                (=> (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                           _X
                           ticket_protocol.next_ticket)
                         (ticket_protocol.pc2 _T)
                         (ticket_protocol.m _T _X))
                    (=> a!1 false)))))
      (a!25 (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (ticket_protocol.m
                                  |T:ticket_protocol.thread|
                                  |X:ticket_protocol.ticket|)
                                (or (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|)
                                    (ticket_protocol.pc3
                                      |T:ticket_protocol.thread|))))))
              (let ((a!2 (and (or (= ticket_protocol.service
                                     |X:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |X:ticket_protocol.ticket|))
                              (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                |X:ticket_protocol.ticket|
                                _X)
                              a!1)))
                (=> (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                           _X
                           ticket_protocol.next_ticket)
                         (ticket_protocol.pc2 _T)
                         (ticket_protocol.m _T _X))
                    (=> a!2 false))))))
      (a!26 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_0 |T:ticket_protocol.thread|)
                  (or (not __l2s_waiting)
                      (not (__l2s_w_0 |T:ticket_protocol.thread|))))))
      (a!27 (=> (and (not l2s_init_2) (or (not __l2s_waiting) (not __l2s_w_1)))
                l2s_g_3))
      (a!28 (not (=> (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
                       (l2s_init_1 |T:ticket_protocol.thread|))
                     l2s_init_2)))
      (a!29 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (or (not (ticket_protocol.pc1 |T:ticket_protocol.thread|))
                  (not (ticket_protocol.pc2 |T:ticket_protocol.thread|)))))
      (a!30 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (or (not (ticket_protocol.pc1 |T:ticket_protocol.thread|))
                  (not (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!31 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (or (not (ticket_protocol.pc2 |T:ticket_protocol.thread|))
                  (not (ticket_protocol.pc3 |T:ticket_protocol.thread|)))))
      (a!32 (forall ((|K1:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|K2:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |K1:ticket_protocol.ticket|)
                       (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |K2:ticket_protocol.ticket|))
                  (= |K1:ticket_protocol.ticket| |K2:ticket_protocol.ticket|))))
      (a!33 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (ticket_protocol.pc3 |T1:ticket_protocol.thread|)
                       (ticket_protocol.pc3 |T2:ticket_protocol.thread|))
                  (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!34 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (not (= ticket_protocol.next_ticket
                               |0:ticket_protocol.ticket|))
                       (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|))
                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                    |M:ticket_protocol.ticket|
                    ticket_protocol.next_ticket))))
      (a!35 (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (or (ticket_protocol.pc2 |T:ticket_protocol.thread|)
                      (ticket_protocol.pc3 |T:ticket_protocol.thread|))
                  (not (= ticket_protocol.next_ticket
                          |0:ticket_protocol.ticket|)))))
      (a!36 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (ticket_protocol.m
                         |T1:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|)
                       (ticket_protocol.m
                         |T2:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|)
                       (not (= |M:ticket_protocol.ticket|
                               |0:ticket_protocol.ticket|)))
                  (= |T1:ticket_protocol.thread| |T2:ticket_protocol.thread|))))
      (a!37 (forall ((|M:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|T:ticket_protocol.thread| ticket_protocol.thread))
              (=> (and (ticket_protocol.pc2 |T:ticket_protocol.thread|)
                       (ticket_protocol.m
                         |T:ticket_protocol.thread|
                         |M:ticket_protocol.ticket|))
                  (or (= ticket_protocol.service |M:ticket_protocol.ticket|)
                      (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                        ticket_protocol.service
                        |M:ticket_protocol.ticket|)))))
      (a!38 (forall ((|T1:ticket_protocol.thread| ticket_protocol.thread)
                     (|T2:ticket_protocol.thread| ticket_protocol.thread))
              (not (and (not (ticket_protocol.pc1 |T1:ticket_protocol.thread|))
                        (not (ticket_protocol.pc1 |T2:ticket_protocol.thread|))
                        (ticket_protocol.m
                          |T1:ticket_protocol.thread|
                          |0:ticket_protocol.ticket|)
                        (ticket_protocol.m
                          |T2:ticket_protocol.thread|
                          |0:ticket_protocol.ticket|)
                        (not (= |T1:ticket_protocol.thread|
                                |T2:ticket_protocol.thread|))))))
      (a!39 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (or (not __ts0_c)
                  (not __ts0_a)
                  (not (__l2s_w_0 |V0:ticket_protocol.thread|)))))
      (a!40 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_0 |V0:ticket_protocol.thread|)
                  (not (and ticket_protocol.scheduled.now
                            (= ticket_protocol.scheduled.value
                               |V0:ticket_protocol.thread|))))))
      (a!41 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (=> (l2s_g_1 |V0:ticket_protocol.thread|)
                  (not (l2s_g_0 |V0:ticket_protocol.thread|)))))
      (a!42 (=> l2s_g_2
                (=> (and (ticket_protocol.pc2 _T) (ticket_protocol.m _T _X))
                    (not l2s_g_3))))
      (a!43 (forall ((|T:index| index) (|U:index| index) (|V:index| index))
              (=> (and (|<:index:index| |T:index| |U:index|)
                       (|<:index:index| |U:index| |V:index|))
                  (|<:index:index| |T:index| |V:index|))))
      (a!44 (forall ((|T:index| index) (|U:index| index))
              (not (and (|<:index:index| |T:index| |U:index|)
                        (|<:index:index| |U:index| |T:index|)))))
      (a!45 (forall ((|T:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|U:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|V:ticket_protocol.ticket| ticket_protocol.ticket))
              (=> (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                         |T:ticket_protocol.ticket|
                         |U:ticket_protocol.ticket|)
                       (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                         |U:ticket_protocol.ticket|
                         |V:ticket_protocol.ticket|))
                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                    |T:ticket_protocol.ticket|
                    |V:ticket_protocol.ticket|))))
      (a!46 (forall ((|T:ticket_protocol.ticket| ticket_protocol.ticket)
                     (|U:ticket_protocol.ticket| ticket_protocol.ticket))
              (not (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                          |T:ticket_protocol.ticket|
                          |U:ticket_protocol.ticket|)
                        (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                          |U:ticket_protocol.ticket|
                          |T:ticket_protocol.ticket|)))))
      (a!47 (forall ((|V0:index| index))
              (= (l2s_a |V0:index|)
                 (ite __ts0_d
                      (__l2s_a |V0:index|)
                      (ite __ts0_b (__l2s_a |V0:index|) (l2s_d |V0:index|))))))
      (a!48 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (l2s_a |V0:ticket_protocol.ticket|)
                 (ite __ts0_d
                      (__l2s_a_a |V0:ticket_protocol.ticket|)
                      (ite __ts0_b
                           (__l2s_a_a |V0:ticket_protocol.ticket|)
                           (__l2s_d |V0:ticket_protocol.ticket|))))))
      (a!49 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (and (or (= ticket_protocol.service
                                     |V0:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |V0:ticket_protocol.ticket|))
                              (or (= |V0:ticket_protocol.ticket| _X)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    |V0:ticket_protocol.ticket|
                                    _X))
                              (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                                (and (ticket_protocol.m
                                       |T:ticket_protocol.thread|
                                       |V0:ticket_protocol.ticket|)
                                     (ticket_protocol.pc2
                                       |T:ticket_protocol.thread|))))))
                (= (l2s_s_3 |V0:ticket_protocol.ticket|)
                   (ite __ts0_d
                        (__l2s_s_3 |V0:ticket_protocol.ticket|)
                        (ite __ts0_b
                             (=> a!1 false)
                             (__l2s_s_3 |V0:ticket_protocol.ticket|)))))))
      (a!50 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
                           (and (ticket_protocol.m
                                  |T:ticket_protocol.thread|
                                  |V0:ticket_protocol.ticket|)
                                (or (ticket_protocol.pc2
                                      |T:ticket_protocol.thread|)
                                    (ticket_protocol.pc3
                                      |T:ticket_protocol.thread|))))))
              (let ((a!2 (and (or (= ticket_protocol.service
                                     |V0:ticket_protocol.ticket|)
                                  (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                    ticket_protocol.service
                                    |V0:ticket_protocol.ticket|))
                              (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                |V0:ticket_protocol.ticket|
                                _X)
                              a!1)))
                (= (l2s_s_2 |V0:ticket_protocol.ticket|)
                   (ite __ts0_d
                        (__l2s_s_2 |V0:ticket_protocol.ticket|)
                        (ite __ts0_b
                             (=> a!2 false)
                             (__l2s_s_2 |V0:ticket_protocol.ticket|))))))))
      (a!51 (not (=> (and (ticket_protocol.pc2 _T) (ticket_protocol.m _T _X))
                     (not l2s_g_3))))
      (a!53 (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
              (let ((a!1 (and (not (and ticket_protocol.scheduled.now
                                        (= ticket_protocol.scheduled.value
                                           |V0:ticket_protocol.thread|)))
                              (not (l2s_g_0 |V0:ticket_protocol.thread|)))))
                (= (l2s_w_0 |V0:ticket_protocol.thread|)
                   (ite __ts0_d
                        (__l2s_w_0 |V0:ticket_protocol.thread|)
                        (ite __ts0_b
                             a!1
                             (__l2s_w_0 |V0:ticket_protocol.thread|)))))))
      (a!54 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (__m_l2s_d |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket|
                              ticket_protocol.service))
                      true
                      (__l2s_d |V0:ticket_protocol.ticket|)))))
      (a!55 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (__m_l2s_d_a |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket|
                              ticket_protocol.next_ticket))
                      true
                      (__m_l2s_d |V0:ticket_protocol.ticket|)))))
      (a!56 (forall ((|V0:ticket_protocol.ticket| ticket_protocol.ticket))
              (= (l2s_d |V0:ticket_protocol.ticket|)
                 (ite (and (= |V0:ticket_protocol.ticket| _X))
                      true
                      (__m_l2s_d_a |V0:ticket_protocol.ticket|))))))
(let ((a!10 (and __l2s_saved
                 (not l2s_init_2)
                 a!8
                 (not (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
                        (__l2s_s_3 |X:ticket_protocol.ticket|)))
                 a!9))
      (a!20 (and __l2s_saved
                 true
                 a!18
                 (not (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
                        (__l2s_s_2 |X:ticket_protocol.ticket|)))
                 a!19))
      (a!52 (ite __ts0_d
                 __l2s_w_1
                 (ite __ts0_b (and (not a!51) (not l2s_g_2)) __l2s_w_1))))
  (and a!1
       a!2
       a!3
       a!4
       a!5
       a!6
       a!7
       (=> a!10 a!11)
       a!12
       a!13
       a!14
       a!4
       a!15
       a!16
       a!17
       (=> a!20 a!21)
       a!12
       a!22
       (or a!23 (not a!24) (not true) (not a!25))
       (=> (and __l2s_saved true) (or a!8 a!18))
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (l2s_g_1 |T:ticket_protocol.thread|))
       a!26
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (not (l2s_init_0 |T:ticket_protocol.thread|)))
       (=> l2s_g_2 (or (not __l2s_waiting) (not __l2s_w_1)))
       (not l2s_init_2)
       (or (not l2s_init_2) l2s_g_2)
       (=> (and (not l2s_init_2) l2s_g_2)
           (or (not __l2s_waiting) (not __l2s_w_1)))
       a!27
       (or __l2s_waiting __l2s_frozen __l2s_saved)
       (or (not __l2s_waiting) (not __l2s_frozen))
       (or (not __l2s_waiting) (not __l2s_saved))
       (or (not __l2s_frozen) (not __l2s_saved))
       (__l2s_d ticket_protocol.service)
       (__l2s_d ticket_protocol.next_ticket)
       (__l2s_d _X)
       a!28
       (not ticket_protocol.scheduled.now)
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (or (ticket_protocol.pc1 |T:ticket_protocol.thread|)
             (ticket_protocol.pc2 |T:ticket_protocol.thread|)
             (ticket_protocol.pc3 |T:ticket_protocol.thread|)))
       a!29
       a!30
       a!31
       a!32
       a!33
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (= ticket_protocol.next_ticket |0:ticket_protocol.ticket|)
             (ticket_protocol.m
               |T:ticket_protocol.thread|
               |0:ticket_protocol.ticket|)))
       a!34
       a!35
       a!36
       a!37
       (forall ((|T:ticket_protocol.thread| ticket_protocol.thread))
         (=> (ticket_protocol.pc3 |T:ticket_protocol.thread|)
             (ticket_protocol.m
               |T:ticket_protocol.thread|
               ticket_protocol.service)))
       (or (= ticket_protocol.service ticket_protocol.next_ticket)
           (|<:ticket_protocol.ticket:ticket_protocol.ticket|
             ticket_protocol.service
             ticket_protocol.next_ticket))
       a!38
       (or __ts0_c __ts0_d)
       (or (not __ts0_c) __ts0_a __ts0_b)
       (or (not __ts0_c) (not __ts0_a) __l2s_waiting)
       (or (not __ts0_c) (not __ts0_a) (not __l2s_w_1))
       a!39
       (or (not __ts0_c) (not __ts0_b) __l2s_frozen)
       a!40
       a!41
       a!42
       (=> l2s_g_3 (not (ticket_protocol.pc3 _T)))
       (forall ((|X:index| index) (|Y:index| index) (|Z:index| index))
         (let ((a!1 (and (|<:index:index| |X:index| |Z:index|)
                         (not (and (|<:index:index| |X:index| |Y:index|)
                                   (|<:index:index| |Y:index| |Z:index|))))))
           (=> (index.succ |X:index| |Z:index|) a!1)))
       a!43
       a!44
       (forall ((|T:index| index) (|U:index| index))
         (or (|<:index:index| |T:index| |U:index|)
             (= |T:index| |U:index|)
             (|<:index:index| |U:index| |T:index|)))
       (forall ((|X:index| index))
         (or (= |0:index| |X:index|) (|<:index:index| |0:index| |X:index|)))
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket)
                (|Y:ticket_protocol.ticket| ticket_protocol.ticket)
                (|Z:ticket_protocol.ticket| ticket_protocol.ticket))
         (let ((a!1 (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                           |X:ticket_protocol.ticket|
                           |Z:ticket_protocol.ticket|)
                         (not (and (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                     |X:ticket_protocol.ticket|
                                     |Y:ticket_protocol.ticket|)
                                   (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                                     |Y:ticket_protocol.ticket|
                                     |Z:ticket_protocol.ticket|))))))
           (=> (ticket_protocol.ticket.succ
                 |X:ticket_protocol.ticket|
                 |Z:ticket_protocol.ticket|)
               a!1)))
       a!45
       a!46
       (forall ((|T:ticket_protocol.ticket| ticket_protocol.ticket)
                (|U:ticket_protocol.ticket| ticket_protocol.ticket))
         (or (|<:ticket_protocol.ticket:ticket_protocol.ticket|
               |T:ticket_protocol.ticket|
               |U:ticket_protocol.ticket|)
             (= |T:ticket_protocol.ticket| |U:ticket_protocol.ticket|)
             (|<:ticket_protocol.ticket:ticket_protocol.ticket|
               |U:ticket_protocol.ticket|
               |T:ticket_protocol.ticket|)))
       (forall ((|X:ticket_protocol.ticket| ticket_protocol.ticket))
         (or (= |0:ticket_protocol.ticket| |X:ticket_protocol.ticket|)
             (|<:ticket_protocol.ticket:ticket_protocol.ticket|
               |0:ticket_protocol.ticket|
               |X:ticket_protocol.ticket|)))
       (= l2s_waiting
          (ite __ts0_d __l2s_waiting (ite __ts0_b __l2s_waiting false)))
       (= l2s_frozen (ite __ts0_d __l2s_frozen (ite __ts0_b false true)))
       a!47
       a!48
       (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved)))
       a!49
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (ite __ts0_d
                         (__l2s_s_0 |V0:ticket_protocol.thread|)
                         (ite __ts0_b
                              (and (ticket_protocol.m
                                     |V0:ticket_protocol.thread|
                                     ticket_protocol.service)
                                   (ticket_protocol.pc2
                                     |V0:ticket_protocol.thread|))
                              (__l2s_s_0 |V0:ticket_protocol.thread|)))))
           (= (l2s_s_0 |V0:ticket_protocol.thread|) a!1)))
       a!50
       (forall ((|V0:ticket_protocol.thread| ticket_protocol.thread))
         (let ((a!1 (ite __ts0_d
                         (__l2s_s_1 |V0:ticket_protocol.thread|)
                         (ite __ts0_b
                              (and (ticket_protocol.m
                                     |V0:ticket_protocol.thread|
                                     ticket_protocol.service)
                                   (ticket_protocol.pc3
                                     |V0:ticket_protocol.thread|))
                              (__l2s_s_1 |V0:ticket_protocol.thread|)))))
           (= (l2s_s_1 |V0:ticket_protocol.thread|) a!1)))
       (= l2s_w_1 a!52)
       a!53
       a!54
       a!55
       a!56))))
(assert (let ((a!1 (exists ((|T:ticket_protocol.thread| ticket_protocol.thread))
             (and (ticket_protocol.m |T:ticket_protocol.thread| @X)
                  (or (ticket_protocol.pc2 |T:ticket_protocol.thread|)
                      (ticket_protocol.pc3 |T:ticket_protocol.thread|))))))
(let ((a!2 (=> (and (or (= ticket_protocol.service @X)
                        (|<:ticket_protocol.ticket:ticket_protocol.ticket|
                          ticket_protocol.service
                          @X))
                    (|<:ticket_protocol.ticket:ticket_protocol.ticket| @X _X)
                    a!1)
               false)))
(let ((a!3 (=> true (=> (and l2s_saved (l2s_s_2 @X)) a!2))))
  (and (not a!3))))))

(check-sat)
(get-info :all-statistics)
