from pathlib import Path
import os,json,tempfile,subprocess as sp
p=Path.cwd();w=Path(__file__).resolve().parent;front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve();base=json.loads(Path('/tmp/g3-ticket-first/validation/final.json').read_text())
def put(path,s):
 f=w/('trial-'+path.name);f.write_text(s);base['Replace'][str(path)]=str(f)
path=p/'smtcore/smt_qi_instance.go';s=path.read_text().replace('import (','import ("os";',1)
s=s.replace('type SMTQIInstanceBuilder struct {','''var reuseTrial=os.Getenv("REUSE_QI")
type qiObservation struct {raw,result ast.ASTHandle;steps uint32}
type SMTQIInstanceBuilder struct {
 trialRows []qiObservation
 trialSubHit bool
''')
s=s.replace('if _, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance);','if b.trialSubHit, err = b.substitution.Instantiate(quantifier, bindings, prepared.instance);')
k='if err = rw.Rewrite(instance, simplified); err != nil {\n\t\t\treturn nil, err\n\t\t}'
assert s.count(k)==1;s=s.replace(k,'''if reuseTrial!="" && !b.manager.Budget().InjectionArmed() && b.manager.TraceStream==nil && !ast.ASTValidateHandles && !diagnostic.TraceCompiled(){
 if b.trialRows==nil{b.trialRows=make([]qiObservation,4096)}
 slot:=&b.trialRows[instance.Slot()%uint32(len(b.trialRows))];rl:=b.manager.ResourceLimit()
 if b.trialSubHit && slot.raw==instance && (reuseTrial!="identity" || slot.result==instance) && b.manager.IsLiveHandle(slot.result) && rl.TryIncOffset(slot.steps){
   if err=b.manager.SetRef(simplified,slot.result);err!=nil{return nil,err}
 }else{
   before:=rl.Count();if err=rw.Rewrite(instance,simplified);err!=nil{return nil,err};v,e:=b.manager.RefGet(simplified);if e!=nil{return nil,e};*slot=qiObservation{instance,v,uint32(rl.Count()-before)}
 }
 }else{'''+k+'}')
put(path,s)
j=w/'trial.json';j.write_text(json.dumps(base))
with tempfile.TemporaryDirectory(prefix='qi-weak-',dir=Path.home()/'tmp') as d:
 sp.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',p/'build/.boolean-enode-cost/heap/study.mod','-o',w/'trial','./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=d,GOTMPDIR=d),check=True)
