from pathlib import Path
source=(Path(__file__).resolve().parent/'expand.py').read_text().split("with (w/'expanded.csv'")[0]
exec(source)
import time
with (w/'shrink.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal policy seed_terms retained bytes calls answer terms'.split())
 for b,g in [(14,8),(12,8),(16,1),(15,8),(13,8)]:
  decl,rules,pool,sig,old=ground(w/'captures'/f'8-{b}-{g}.smt2','facts')
  rows,_,_=go(pool); extra=collections.defaultdict(set)
  for row in rows:apps(row,extra)
  for st,v in extra.items():pool[st].update(v)
  initial=sorted(((st,v) for st,vs in pool.items() for v in vs),key=repr)
  for policy,items in [('forward',initial),('reverse',initial[::-1])]:
   kept=list(items);n=2;calls=0
   def probe(entries):
    global calls
    calls+=1;ps=collections.defaultdict(set)
    for st,v in entries:ps[st].add(v)
    _,ans,size=go(ps);return ans,size
   while kept:
    width=(len(kept)+n-1)//n
    for start in range(0,len(kept),width):
     attempt=kept[:start]+kept[start+width:];ans,size=probe(attempt)
     if ans=='unsat':
      kept=attempt;n=max(2,n-1);break
    else:
     if width==1:break
     n=min(len(kept),n*2)
   ans,size=probe(kept);assert ans=='unsat'
   out.writerow([b,g,policy,len(items),len(kept),size,calls,ans,' '.join(smt(v) for _,v in kept)]);f.flush()
