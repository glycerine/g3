"""Check every retained ground proof and its original quantified obligation."""
import argparse
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("g3", type=Path)
parser.add_argument("z3", type=Path)
args = parser.parse_args()
directory = Path(__file__).resolve().parent
for proof in sorted(directory.glob("sparse-*.smt2")):
    case = proof.stem.removeprefix("sparse-")
    original = directory / "captures" / f"8-{case}.smt2"
    for path in (original, proof):
        query = path.read_text().split("(check-sat)", 1)[0] + "\n(check-sat)\n"
        for executable in (args.g3, args.z3):
            result = subprocess.run(
                [executable.resolve(), "smt.macro_finder=true", "-in"],
                input=query, text=True, capture_output=True, timeout=60, check=True,
            )
            if result.stdout.strip() != "unsat" or result.stderr:
                raise RuntimeError((executable, path, result.stdout, result.stderr))
    print(case, "original and ground proof matched")
