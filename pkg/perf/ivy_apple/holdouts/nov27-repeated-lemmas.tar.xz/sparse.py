from pathlib import Path
exec((Path(__file__).resolve().parent/'expand.py').read_text().split("with (w/'expanded.csv'")[0])
import os,re
from hints import conjuncts
with (w/'sparse.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal pool rows core bytes engine instructions'.split())
 for b,g in [(14,8),(12,8),(16,1),(15,8),(13,8)]:
  opts=[r for r in csv.DictReader((w/'shrink.csv').open()) if (int(r['batch']),int(r['goal']))==(b,g)]
  if not opts:raise RuntimeError((b,g,"missing term pool"))
  choice=min(opts,key=lambda r:int(r['bytes']))
  decl,rules,pool,sig,old=ground(w/'captures'/f'8-{b}-{g}.smt2','facts')
  # Match the normalization order in shrink.py to reproduce its fresh binder names.
  selected=parse(choice['terms']);args=collections.defaultdict(list)
  for t in selected:
   k=t if isinstance(t,str) else t[0]
   if k not in sig:raise RuntimeError((b,g,k))
   args[sig[k][1]].append(t)
  else:
   terms=list(dict.fromkeys(x for r in rules for x in conjuncts(inst(r,{},args))))
   declarations='\n'.join(map(smt,decl));labelled='\n'.join('(assert (! '+smt(t)+' :named row'+str(i)+'))' for i,t in enumerate(terms))
   z=p.parent/'build/z3';ans=sp.run([z,'-in'],input='(set-option :produce-unsat-cores true)\n'+declarations+'\n'+labelled+'\n(check-sat)\n(get-unsat-core)',text=True,capture_output=True)
   if not ans.stdout.startswith('unsat\n'):raise RuntimeError((b,g,ans.stdout))
   ids=sorted(map(int,re.findall(r'row(\d+)',ans.stdout)));text=declarations+'\n'+'\n'.join('(assert '+smt(terms[i])+')' for i in ids)+'\n(check-sat)\n'
   (w/f'sparse-{b}-{g}.smt2').write_text(text)
   for name,exe in [('g3','/tmp/g3-witness-match/g3'),('native',z)]:
    stat=w/'sparse.stat';r=sp.run(['taskset','-c','30','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,'-in'],input=text,text=True,capture_output=True,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'));assert r.stdout.strip()=='unsat' and r.returncode==0
    ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    out.writerow([b,g,len(selected),len(terms),len(ids),len(text),name,ins]);f.flush()
