from pathlib import Path
import sys,csv,subprocess as sp,re,os
w=Path(__file__).resolve().parent;p=Path.cwd();sys.path.insert(0,str(p/'perf/ivy_apple/goal_instances/finite_models'));from syntax import parse,smt
sys.path.insert(0,'/tmp/g3-witness-match');from hints import expand
def split(t,neg=False):
 if not isinstance(t,str):
  if t[0]=='not':yield from split(t[1],not neg);return
  if t[0]==('or' if neg else 'and'):
   for ch in t[1:]:yield from split(ch,neg)
   return
  if t[0]=='=>' and neg:
   yield from split(t[1]);yield from split(t[2],True);return
 yield ('not',t) if neg else t
def qfree(t):
 if isinstance(t,str):return True
 return t[0] not in ('forall','exists') and all(qfree(x) for x in t[1:])
def generate(path,mode,pushed=True):
 src=parse(path.read_text());base,goal=[v for v in src if v[0]=='assert'];rows=list(split(expand(goal[1],{})));fs=[v for v in src if v[0].startswith('declare-')]+[base]
 if pushed:fs.append(('push',))
 if mode=='units':fs += [('assert',v) for v in rows if qfree(v)]+[goal]
 elif mode=='split':fs += [('assert',v) for v in rows]
 elif mode=='reverse':fs += [('assert',v) for v in rows[::-1]]
 else:fs += [goal]
 return '\n'.join(map(smt,fs+[('check-sat',),('get-info',':all-statistics')])),len(rows)
if __name__=='__main__':
 with (w/'split.csv').open('w') as f:
  o=csv.writer(f);o.writerow('goal policy factors engine instructions instances decisions conflicts'.split())
  for path in sorted((w/'captures').glob('*.smt2')):
   for mode in ['off','units','split','reverse']:
    text,n=generate(path,mode)
    if mode!='off' and n<2:continue
    for name,exe in [('g3','/tmp/g3-witness-match/g3'),('native',p.parent/'build/z3')]:
     stat=w/'split.stat';r=sp.run(['taskset','-c','30','/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',stat,'-e','instructions:u','--',exe,'smt.macro_finder=true','-in'],input=text,text=True,capture_output=True,timeout=15,env=dict(os.environ,GOGC='off',GOMAXPROCS='1'));assert r.returncode==0 and r.stdout.startswith('unsat\n') and not r.stderr,(path,r.stderr,r.stdout[:200])
     a=dict(re.findall(r':([\w-]+)\s+(\d+)',r.stdout));ins=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
     o.writerow([path.stem,mode,n,name,ins,*[a.get(k,0) for k in ('quant-instantiations','decisions','conflicts')]]);f.flush()
