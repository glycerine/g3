from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'ground.py').read_text().split('with (w/')[0];i=s.index(" rows=[inst(");s=s[:i]+''' return decl,rules,pool,sig,old
''';exec(s)
def apps(t,col):
 if isinstance(t,str):return
 if t[0] in sig and t[0] not in old and sig[t[0]][1]!='Bool':col[sig[t[0]][1]].add(t)
 for z in t[1:]:apps(z,col)
def go(pool):
 args={k:sorted(v,key=repr) for k,v in pool.items()};rows=[inst(r,{},args) for r in rules];script='\n'.join(map(smt,decl+[('assert',x) for x in rows]+[('check-sat',)]))
 if len(script)>16_000_000:return rows,'over-size',len(script)
 rr=sp.run([p.parent/'build/z3','-T:4','-in'],input=script,text=True,capture_output=True,timeout=7,check=True);ans=rr.stdout.strip();assert ans in ('unsat','sat','timeout')
 if ans=='unsat':
  rr=sp.run(['/tmp/g3-witness-match/g3','-T:6','-in'],input=script,text=True,capture_output=True,timeout=9,check=True);assert rr.stdout.strip()==ans
 return rows,ans,len(script)
with (w/'expanded.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal source seed original extra bytes answer'.split())
 for b,g in [(14,8),(15,8),(13,8),(12,8),(16,1)]:
  for src,path in [('core',w/f'core-{b}-{g}.smt2'),('full',w/'captures'/f'8-{b}-{g}.smt2')]:
   for seed in ('witness','facts'):
    decl,rules,pool,sig,old=ground(path,seed);n=sum(map(len,pool.values()));rows,ans,size=go(pool);extra=collections.defaultdict(set)
    for r in rows:apps(r,extra)
    for sort,v in extra.items():pool[sort].update(v)
    count=sum(map(len,extra.values()))
    if count<80:_,ans,size=go(pool)
    else:ans,size='term-cap',0
    out.writerow([b,g,src,seed,n,count,size,ans]);f.flush()
