"""Compare source-valid existential instantiation hints with a fresh-witness extension."""
from pathlib import Path
import sys, collections, argparse
sys.path.insert(0,str(Path.cwd()/'perf/ivy_apple/goal_instances/finite_models'))
from syntax import parse,smt,fresh_names

def expand(t,env):
    if isinstance(t,str):
        return env.get(t,t)
    if t[0]=='let':
        return expand(t[2],dict(env,**{n:expand(v,env) for n,v in t[1]}))
    if t[0] in ('forall','exists'):
        return (t[0],t[1],expand(t[2],{n:v for n,v in env.items() if n not in dict(t[1])}))
    return tuple(expand(x,env) for x in t)

def conjuncts(t):
    if isinstance(t,tuple) and t[0]=='and':
        for x in t[1:]:
            yield from conjuncts(x)
    else:
        yield t

def atom(t):
    neg=isinstance(t,tuple) and t[0]=='not'
    return neg,t[1] if neg else t

def rule_hints(forms,mode):
    roots=[term for r in forms if r[0]=='assert' for term in conjuncts(expand(r[1],{}))]
    sig={r[1]:(r[2],r[3]) for r in forms if r[0]=='declare-fun'}
    facts=collections.defaultdict(list)
    for r in roots:
        neg,t=atom(r)
        if isinstance(t,tuple) and t[0] in sig and all(x in sig and not sig[x][0] for x in t[1:]):
            facts[t[0],neg].append(t[1:])
    result=[];names=fresh_names(forms,'ground!w!')
    for r in roots:
        if not isinstance(r,tuple) or r[0]!='forall' or len(r[1])!=1:continue
        var,sort=r[1][0];body=r[2]
        if not isinstance(body,tuple) or body[0]!='=>' or not isinstance(body[2],tuple) or body[2][0]!='exists':continue
        candidates=[]
        for cond in conjuncts(body[1]):
            neg,t=atom(cond)
            if not isinstance(t,tuple) or t[0] not in sig:continue
            for args in facts[t[0],neg]:
                for i,x in enumerate(t[1:]):
                    if x==var and args[i] not in candidates:candidates.append(args[i])
        for arg in candidates:
            g=expand(body,{var:arg})
            if mode=='fresh':
                local={}
                for v,st in g[2][1]:
                    n=next(names);result.append(('declare-fun',n,(),st));local[v]=n
                g=('=>',g[1],expand(g[2][2],local))
            result.append(('assert',g))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('directory',type=Path)
    a=p.parse_args();a.directory.mkdir(exist_ok=True);s=a.input.read_text().split('(check-sat)')[0];f=parse(s)
    for mode in ('base','exists','fresh'):
        hints=[] if mode=='base' else rule_hints(f,mode)
        (a.directory/(mode+'.smt2')).write_text(s+'\n'+'\n'.join(map(smt,hints))+'\n(check-sat)\n')
        print(mode,len(hints))
