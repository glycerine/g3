from pathlib import Path
w=Path(__file__).resolve().parent
s=(w/'observe.py').read_text()
i=s.index('j=w/');s=s[:i]+'''path=p/'smtcore/smt_internalizer.go';s=Path(rep[str(path)]).read_text();i=s.index('func (s *SMTInternalizerState) assertExpression(');h,t=s[:i],s[i:]
k='previousGeneration := s.generation';t=t.replace(k,'fd:=-1;if s.observing==expression{fd=studyFD()};startCount:=studyRd(fd);var missedCost uint64;'+k,1)
k='if err = s.Internalize(argument, true); err != nil {';t=t.replace(k,'before:=studyRd(fd);'+k,1)
k='start:=len(s.auxClauses)';t=t.replace(k,'missedCost+=0;beforeClause:=studyRd(fd);'+k,1)
k='literals[index], err = s.Literal(argument)';t=t.replace(k,k+';missedCost+=studyRd(fd)-before',1)
k='if s.observing==expression && len(s.auxClauses)==start+1';t=t.replace(k,'afterClause:=studyRd(fd);'+k,1)
k='case ast.ASTOpIff:';t=t.replace(k,'if fd>=0{last:=studyRd(fd);fmt.Fprintln(os.Stderr,"PART",beforeClause-startCount-missedCost,missedCost,afterClause-beforeClause,last-afterClause)};'+k,1)
s=h+t;s=s.replace('import (','import ("os";',1);put(path,s)
'''+s[i:];s=s.replace("w/'obs.json'","w/'parts.json'").replace("w/'observe'","w/'parts'").replace('f=w/path.name','f=w/("parts-"+path.name)')
exec(s)
