from pathlib import Path
import csv,sys,subprocess as sp,collections,itertools
p=Path.cwd();w=Path(__file__).resolve().parent;sys.path[:0]=[str(p.parent/'build/python'),str(p/'perf/ivy_apple/goal_instances/finite_models'),'/tmp/g3-witness-match'];import z3;from syntax import parse,smt;from hints import expand
# After NNF all surviving binders must occur in positive polarity.
def inst(t,env,pool):
 if isinstance(t,str):return env.get(t,t)
 if t[0]=='forall':
  bind=t[1];rows=[inst(t[2],dict(env,**dict(zip([n for n,_ in bind],v))),pool) for v in itertools.product(*(pool.get(st,()) for n,st in bind))];return ('and',*rows) if rows else 'true'
 if t[0]=='!':return inst(t[1],env,pool)
 assert t[0] not in ('exists','let');return tuple(inst(a,env,pool) for a in t)
def audit(t,positive):
 if isinstance(t,str):return
 if t[0]=='!':audit(t[1],positive);return
 if t[0]=='forall':assert positive;audit(t[2],True);return
 assert t[0]!='exists'
 for ch in t[1:]:audit(ch,positive and t[0] in ('and','or'))
def ground(path,which):
 src=parse(path.read_text());old={x[1] for x in src if x[0]=='declare-fun'}
 goal=z3.Then('simplify',z3.With(z3.Tactic('nnf'),mode='full'))(z3.parse_smt2_file(str(path)))[0];z=z3.Solver();z.add(*list(goal));fs=parse(z.sexpr())
 decl=[f for f in fs if f[0].startswith('declare')];rules=[expand(f[1],{}) for f in fs if f[0]=='assert'];sig={f[1]:(f[2],f[3]) for f in decl if f[0]=='declare-fun'}
 for r in rules:audit(r,True)
 pool=collections.defaultdict(set)
 for n,(dom,st) in sig.items():
  if not dom and st!='Bool' and (n not in old or which=='all'):pool[st].add(n)
 if which in ('facts','all'):
  for r in rules:
   v=r[1] if isinstance(r,tuple) and r[0]=='not' else r
   if isinstance(v,tuple) and (v[0]=='=' or v[0] in sig):
    for a in v[1:]:
     if a in sig and not sig[a][0] and sig[a][1]!='Bool':pool[sig[a][1]].add(a)
 rows=[inst(r,{}, {k:sorted(v) for k,v in pool.items()}) for r in rules];script='\n'.join(map(smt,decl+[('assert',r) for r in rows]+[('check-sat',)]))
 results=[]
 for exe in (p.parent/'build/z3','/tmp/g3-witness-match/g3'):
  r=sp.run([exe,'-in'],input=script,text=True,capture_output=True,check=True,timeout=20);results.append(r.stdout.strip())
 assert results[0]==results[1] and results[0] in ('sat','unsat')
 return sum(map(len,pool.values())),len(script),results[0]
with (w/'ground.csv').open('w') as f:
 o=csv.writer(f);o.writerow('batch goal source pool terms bytes answer'.split())
 for b,g in [(12,8),(14,8),(13,8),(15,8),(16,1)]:
  for src,path in [('full',w/'captures'/f'8-{b}-{g}.smt2'),('core',w/f'core-{b}-{g}.smt2')]:
   for mode in ('witness','facts','all'):
    o.writerow([b,g,src,mode,*ground(path,mode)]);f.flush()
