from pathlib import Path
import csv,sys,subprocess as sp,os,re
w=Path(__file__).resolve().parent;p=Path.cwd();sys.path.insert(0,str(p/'perf/ivy_apple/goal_instances/finite_models'));from syntax import parse,smt
sys.path.insert(0,'/tmp/g3-witness-match');from hints import expand,conjuncts
with (w/'cores.csv').open('w') as f:
 o=csv.writer(f);o.writerow('batch goal base core subset engine result instantiations decisions conflicts'.split())
 for b,g in [(12,8),(14,8),(16,1),(13,8),(15,8)]:
  src=parse((w/'captures'/f'8-{b}-{g}.smt2').read_text());decs=[smt(x) for x in src if x[0].startswith('declare-')];base,goal=[expand(x[1],{}) for x in src if x[0]=='assert'];rows=list(dict.fromkeys(conjuncts(base)));decl='\n'.join(decs)
  labels=['(assert (! '+smt(t)+' :named ax'+str(i)+'))' for i,t in enumerate(rows)]
  def cli(text,exe):
   r=sp.run([exe,'smt.macro_finder=true','-in'],input=text,text=True,capture_output=True,timeout=15);assert r.returncode==0 and not r.stderr,(r.stderr,r.stdout[:300]);return r.stdout.strip()
  z=p.parent/'build/z3';r=cli('(set-option :produce-unsat-cores true)\n'+decl+'\n'+'\n'.join(labels)+'\n(assert '+smt(goal)+')\n(check-sat)\n(get-unsat-core)',z);assert r.startswith('unsat\n')
  ids=sorted(map(int,re.findall(r'ax(\d+)',r)));(w/f'core-{b}-{g}.txt').write_text('\n'.join(str(i)+' '+smt(rows[i]) for i in ids))
  for subset,items in [('full',rows),('core',[rows[i] for i in ids]),('ground',[x for x in rows if all(s not in smt(x) for s in ('(forall ','(exists '))])]:
   text=decl+'\n'+'\n'.join('(assert '+smt(x)+')' for x in items)+'\n(assert '+smt(goal)+')\n(check-sat)\n(get-info :all-statistics)'; 
   if subset=='core':(w/f'core-{b}-{g}.smt2').write_text(text)
   for name,exe in [('native',z),('g3','/tmp/g3-witness-match/g3')]:
    r=cli(text,exe);stats=dict(re.findall(r':([\w-]+)\s+(\d+)',r));o.writerow([b,g,len(rows),len(ids),subset,name,r.splitlines()[0],*[stats.get(k,0) for k in ('quant-instantiations','decisions','conflicts')]]);f.flush()
