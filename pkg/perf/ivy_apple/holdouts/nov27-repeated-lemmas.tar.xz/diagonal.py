from pathlib import Path
w=Path(__file__).resolve().parent
exec((w/'expand.py').read_text().split("with (w/'expanded.csv'")[0])
def narrow(t,env,pool):
 if isinstance(t,str):return env.get(t,t)
 if t[0]=='forall':
  bind=t[1];rows=[]
  for values in itertools.product(*(pool.get(st,()) for _,st in bind)):
   bysort=collections.defaultdict(set)
   for (_,st),v in zip(bind,values):bysort[st].add(v)
   if any(len(v)>width for v in bysort.values()):continue
   rows.append(narrow(t[2],dict(env,**dict(zip((n for n,_ in bind),values))),pool))
  return ('and',*rows) if rows else 'true'
 if t[0]=='!':return narrow(t[1],env,pool)
 return tuple(narrow(a,env,pool) for a in t)
with (w/'diagonal.csv').open('w') as f:
 out=csv.writer(f);out.writerow('batch goal width terms bytes answer'.split())
 for b,g in [(12,8),(14,8),(13,8),(15,8),(16,1)]:
  decl,rules,pool,sig,old=ground(w/'captures'/f'8-{b}-{g}.smt2','facts')
  rows,_,_=go(pool);extra=collections.defaultdict(set)
  for row in rows:apps(row,extra)
  for st,v in extra.items():pool[st].update(v)
  fullInst=inst
  for width in (1,2):
   inst=narrow
   _,ans,size=go(pool);out.writerow([b,g,width,sum(map(len,pool.values())),size,ans]);f.flush()
  inst=fullInst
