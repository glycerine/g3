import json,os,subprocess,sys,tempfile
from pathlib import Path
here=Path(__file__).resolve().parent
pkg=Path(sys.argv[1]).resolve()
def write(kind,filename):
 folder=here/'overlays'/kind
 files=json.loads((folder/'files.json').read_text())
 Path(filename).write_text(json.dumps({'Replace':{str(pkg/name):str(folder/short) for name,short in files.items()}}))
if sys.argv[2]=='--overlay':
 write(sys.argv[3],sys.argv[4])
else:
 mode=sys.argv[2];src=Path(sys.argv[3]).resolve();out=Path(sys.argv[4]).resolve()
 with tempfile.TemporaryDirectory() as d:
  overlay=Path(d)/'overlay.json';write('offline',overlay)
  env=dict(os.environ,GOMAXPROCS='1',GROUND_MODE=mode,OFFLINE_INPUTS=str(src),OFFLINE_OUTPUT=str(out),OFFLINE_WORKERS='1',OFFLINE_SHARD='0')
  subprocess.run(['go','test','-count=1','-overlay='+str(overlay),'-run','^TestGroundProjectionExperiment$','-timeout','20m','./api'],cwd=pkg,env=env,check=True)
