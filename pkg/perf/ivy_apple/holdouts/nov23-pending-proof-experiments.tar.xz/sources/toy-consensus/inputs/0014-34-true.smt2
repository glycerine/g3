(set-info :status unknown)
(declare-sort msg 0)
 (declare-datatypes ((msg_kind 0)) (((msg_kind.request_vote) (msg_kind.vote) (msg_kind.leader))))
 (declare-sort node.iter.t 0)
 (declare-sort node 0)
 (declare-fun |__fml:y| () node.iter.t)
(declare-fun |__new_fml:x| () node)
(declare-fun node.iter.val (node.iter.t) node)
(declare-fun __D () node)
(declare-fun __M () msg)
(declare-fun |__ts0__m_fml:x_a_a| () node.iter.t)
(declare-fun |__new_fml:x_a| () node.iter.t)
(declare-fun |0:node| () node)
(declare-fun node.max () node)
(declare-fun msg.vote (msg) node)
(declare-fun msg.src (msg) node)
(declare-fun msg.kind (msg) msg_kind)
(declare-fun |__fml:m| () msg)
(declare-fun |__new_loc:0| () node.iter.t)
(declare-fun |__m_loc:iter_a| () node.iter.t)
(declare-fun |__ts0__new_fml:dst_a_a| () node)
(declare-fun |__ts0__new_fml:v_a| () msg)
(declare-fun |__new_loc:iter| () node.iter.t)
(declare-fun |__m_loc:iter| () node.iter.t)
(declare-fun |__ts0__new_loc:n_a| () node)
(declare-fun |__fml:src| () node)
(declare-fun |__ts0__new_fml:src_a_b| () node)
(declare-fun |__ts0__new_fml:dst_b| () node)
(declare-fun |__ts0__new_fml:m_a_a| () msg)
(declare-fun |__ts0__new_fml:src_a_a_a| () node)
(declare-fun __shim.sent (msg node) Bool)
(declare-fun __net.spec.sent (msg node) Bool)
(declare-fun node.iter.is_end (node.iter.t) Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun shim.sent (msg node) Bool)
(declare-fun __m_net.spec.sent (msg node) Bool)
(declare-fun __ts0__ts0_a_a () Bool)
(declare-fun |<:node:node| (node node) Bool)
(declare-fun net.spec.sent (msg node) Bool)
(declare-fun node.succ (node node) Bool)
(assert
 (forall ((|D:node| node) (|M:msg| msg) )(=> (__net.spec.sent |M:msg| |D:node|) (__shim.sent |M:msg| |D:node|)))
 )
(assert
 (not (node.iter.is_end |__fml:y|)))
(assert
 (let ((?x169 (node.iter.val |__fml:y|)))
 (= ?x169 |__new_fml:x|)))
(assert
 (or __ts0_b __ts0_c))
(assert
 (let (($x679 (not __ts0_b)))
 (or $x679 (not (=> (__net.spec.sent __M __D) (shim.sent __M __D))))))
(assert
 (forall ((|D:node| node) (|M:msg| msg) )(let (($x478 (not __ts0_c)))
 (or $x478 (=> (__m_net.spec.sent |M:msg| |D:node|) (shim.sent |M:msg| |D:node|)))))
 )
(assert
 (let (($x478 (not __ts0_c)))
 (or $x478 (or (not __ts0__ts0_a_a) (not (node.iter.is_end |__ts0__m_fml:x_a_a|))))))
(assert
 (forall ((|X:node| node) (|Y:node| node) )(let (($x785 (node.iter.is_end |__new_fml:x_a|)))
 (let (($x1670 (not $x785)))
 (let ((?x1666 (node.iter.val |__new_fml:x_a|)))
 (let ((?x842 (node.iter.val |__ts0__m_fml:x_a_a|)))
 (let (($x836 (|<:node:node| ?x842 ?x1666)))
 (let (($x1680 (and (not (and (|<:node:node| ?x842 |Y:node|) (|<:node:node| |Y:node| ?x1666))) $x836 $x1670)))
 (let (($x1682 (or (and (or (= |X:node| ?x842) (|<:node:node| |X:node| ?x842)) $x785) $x1680)))
 (let (($x2891 (not __ts0__ts0_a_a)))
 (let (($x478 (not __ts0_c)))
 (or $x478 (or $x2891 $x1682))))))))))))
 )
(assert
 (let (($x2891 (not __ts0__ts0_a_a)))
 (let (($x861 (or $x2891 (not (=> (net.spec.sent __M __D) (shim.sent __M __D))))))
 (let (($x478 (not __ts0_c)))
 (or $x478 $x861)))))
(assert
 (let (($x478 (not __ts0_c)))
 (or $x478 (or __ts0__ts0_a_a false))))
(assert
 (forall ((|N:node| node) )(or (= |N:node| |0:node|) (|<:node:node| |0:node| |N:node|)))
 )
(assert
 (forall ((|X:node| node) (|Y:node| node) (|Z:node| node) )(let (($x76 (and (|<:node:node| |X:node| |Z:node|) (not (and (|<:node:node| |X:node| |Y:node|) (|<:node:node| |Y:node| |Z:node|))))))
 (=> (node.succ |X:node| |Z:node|) $x76)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) (|V:node| node) )(=> (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |V:node|)) (|<:node:node| |T:node| |V:node|)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(not (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(let (($x71 (|<:node:node| |T:node| |U:node|)))
 (or $x71 (= |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|X:node| node) )(or (= |0:node| |X:node|) (|<:node:node| |0:node| |X:node|)))
 )
(assert
 (forall ((|X:node| node) )(or (= |X:node| node.max) (|<:node:node| |X:node| node.max)))
 )
(assert
 (forall ((|X:msg| msg) (|Y:msg| msg) )(let (($x1348 (and (= (msg.kind |X:msg|) (msg.kind |Y:msg|)) (= (msg.src |X:msg|) (msg.src |Y:msg|)) (= (msg.vote |X:msg|) (msg.vote |Y:msg|)))))
 (=> $x1348 (= |X:msg| |Y:msg|))))
 )
(assert
 (forall ((|X:node.iter.t| node.iter.t) (|Y:node.iter.t| node.iter.t) )(let (($x25 (and (= (node.iter.is_end |X:node.iter.t|) (node.iter.is_end |Y:node.iter.t|)) (= (node.iter.val |X:node.iter.t|) (node.iter.val |Y:node.iter.t|)))))
 (=> $x25 (= |X:node.iter.t| |Y:node.iter.t|))))
 )
(assert
 (forall ((|V0:msg| msg) (|V1:node| node) )(= (shim.sent |V0:msg| |V1:node|) (ite (and (= |V0:msg| |__fml:m|)) true (__shim.sent |V0:msg| |V1:node|))))
 )
(assert
 (= |__new_fml:x| |0:node|))
(assert
 (= |__new_loc:0| |__fml:y|))
(assert
 (= |__m_loc:iter_a| |__new_loc:0|))
(assert
 (forall ((|V0:msg| msg) (|V1:node| node) )(let (($x1017 (__m_net.spec.sent |V0:msg| |V1:node|)))
 (let (($x3296 (ite (and (= |V0:msg| |__ts0__new_fml:v_a|) (= |V1:node| |__ts0__new_fml:dst_a_a|)) true $x1017)))
 (let (($x2211 (net.spec.sent |V0:msg| |V1:node|)))
 (= $x2211 (ite __ts0_c $x3296 (__net.spec.sent |V0:msg| |V1:node|)))))))
 )
(assert
 (= |__new_loc:iter| (ite __ts0_c |__new_fml:x_a| |__m_loc:iter_a|)))
(assert
 (let ((?x1123 (node.iter.val |__m_loc:iter|)))
 (= |__ts0__new_loc:n_a| ?x1123)))
(assert
 (= |__ts0__new_fml:src_a_b| |__fml:src|))
(assert
 (= |__ts0__new_fml:dst_b| |__ts0__new_loc:n_a|))
(assert
 (= |__ts0__new_fml:m_a_a| |__fml:m|))
(assert
 (= |__ts0__new_fml:src_a_a_a| |__fml:src|))
(assert
 (= |__ts0__new_fml:dst_a_a| |__ts0__new_loc:n_a|))
(assert
 (= |__ts0__new_fml:v_a| |__fml:m|))
(assert
 (= |__ts0__m_fml:x_a_a| |__m_loc:iter|))
(assert
 (let (($x1238 (not (node.iter.is_end |__m_loc:iter|))))
 (= __ts0__ts0_a_a $x1238)))
(assert
 (let (($x155 (not false)))
 (and $x155)))
(check-sat)
