(set-info :status unknown)
(declare-sort msg 0)
 (declare-datatypes ((msg_kind 0)) (((msg_kind.request_vote) (msg_kind.vote) (msg_kind.leader))))
 (declare-sort node 0)
 (declare-sort nset 0)
 (declare-fun msg.src (msg) node)
(declare-fun msg.kind (msg) msg_kind)
(declare-fun msg.vote (msg) node)
(declare-fun __toy_system.voters (node) nset)
(declare-fun toy_protocol.quorum () nset)
(declare-fun |__loc:msg| () msg)
(declare-fun |__loc:msg_nd| () msg)
(declare-fun |__m_loc:msg| () msg)
(declare-fun |__loc:msg_nd_a| () msg)
(declare-fun |__fml:self| () node)
(declare-fun |__ts0__new_fml:n| () node)
(declare-fun |__ts0__m_fml:s_a| () nset)
(declare-fun |__new_fml:s_a| () nset)
(declare-fun |__new_loc:msg| () msg)
(declare-fun |__new_fml:src| () node)
(declare-fun |__new_fml:m| () msg)
(declare-fun toy_system.voters (node) nset)
(declare-fun |__ts0__new_fml:v| () node)
(declare-fun |__ts0__new_fml:n_a| () node)
(declare-fun @M2 () msg)
(declare-fun @M1 () msg)
(declare-fun @N2 () node)
(declare-fun @N1 () node)
(declare-fun __shim.sent (msg node) Bool)
(declare-fun __toy_protocol.voted (node node) Bool)
(declare-fun nset.member (node nset) Bool)
(declare-fun toy_protocol.isleader (node) Bool)
(declare-fun __toy_system.alreadyvoted (node) Bool)
(declare-fun nset.majority (nset) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun toy_protocol.voted (node node) Bool)
(declare-fun shim.sent (msg node) Bool)
(declare-fun toy_system.alreadyvoted (node) Bool)
(assert
 (forall ((|M1:msg| msg) (|M2:msg| msg) (|N1:node| node) (|N2:node| node) )(let (($x3274 (and (__shim.sent |M1:msg| |N1:node|) (= (msg.kind |M1:msg|) msg_kind.leader) (__shim.sent |M2:msg| |N2:node|) (= (msg.kind |M2:msg|) msg_kind.leader))))
 (=> $x3274 (= (msg.src |M1:msg|) (msg.src |M2:msg|)))))
 )
(assert
 (forall ((|M:msg| msg) (|N:node| node) )(=> (and (__shim.sent |M:msg| |N:node|) (= (msg.kind |M:msg|) msg_kind.vote)) (__toy_protocol.voted (msg.src |M:msg|) (msg.vote |M:msg|))))
 )
(assert
 (forall ((|N1:node| node) (|N2:node| node) )(let (($x2140 (__toy_protocol.voted |N1:node| |N2:node|)))
 (=> (nset.member |N1:node| (__toy_system.voters |N2:node|)) $x2140)))
 )
(assert
 (forall ((|M:msg| msg) (|N:node| node) )(=> (and (__shim.sent |M:msg| |N:node|) (= (msg.kind |M:msg|) msg_kind.leader)) (toy_protocol.isleader (msg.src |M:msg|))))
 )
(assert
 (forall ((|N1:node| node) (|N2:node| node) )(let (($x2140 (__toy_protocol.voted |N1:node| |N2:node|)))
 (=> $x2140 (__toy_system.alreadyvoted |N1:node|))))
 )
(assert
 (forall ((|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (toy_protocol.isleader |N:node|) (toy_protocol.isleader |M:node|)) $x1361)))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (__toy_protocol.voted |L:node| |N:node|) (__toy_protocol.voted |L:node| |M:node|)) $x1361)))
 )
(assert
 (forall ((|N:node| node) )(let (($x3961 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (__toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3379 (toy_protocol.isleader |N:node|)))
 (=> $x3379 (and $x4102 $x3961))))))
 )
(assert
 (= (msg.src |__loc:msg_nd|) (msg.src |__loc:msg|)))
(assert
 (= (msg.vote |__loc:msg_nd|) (msg.vote |__loc:msg|)))
(assert
 (= (msg.kind |__loc:msg_nd|) msg_kind.request_vote))
(assert
 (= (msg.kind |__loc:msg_nd_a|) (msg.kind |__m_loc:msg|)))
(assert
 (= (msg.vote |__loc:msg_nd_a|) (msg.vote |__m_loc:msg|)))
(assert
 (= (msg.src |__loc:msg_nd_a|) |__fml:self|))
(assert
 (forall ((|N:node| node) )(let (($x3574 (= (nset.member |N:node| |__new_fml:s_a|) (or (nset.member |N:node| |__ts0__m_fml:s_a|) (= |N:node| |__ts0__new_fml:n|)))))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x3574))))
 )
(assert
 (forall ((|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (let (($x1138 (=> (and (toy_protocol.isleader |N:node|) (toy_protocol.isleader |M:node|)) $x1361)))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x1138)))))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (let (($x3511 (=> (and (__toy_protocol.voted |L:node| |N:node|) (__toy_protocol.voted |L:node| |M:node|)) $x1361)))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x3511)))))
 )
(assert
 (forall ((|N:node| node) )(let (($x3961 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (__toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3379 (toy_protocol.isleader |N:node|)))
 (let (($x35 (not __ts0_a)))
 (or $x35 (=> $x3379 (and $x4102 $x3961))))))))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (let (($x3244 (=> (and (toy_protocol.voted |L:node| |N:node|) (toy_protocol.voted |L:node| |M:node|)) $x1361)))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x3244)))))
 )
(assert
 (forall ((|N:node| node) )(let (($x709 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3379 (toy_protocol.isleader |N:node|)))
 (let (($x3983 (=> $x3379 (and $x4102 $x709))))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x3983)))))))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (toy_protocol.voted |L:node| |N:node|) (toy_protocol.voted |L:node| |M:node|)) $x1361)))
 )
(assert
 (forall ((|N:node| node) )(let (($x709 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3379 (toy_protocol.isleader |N:node|)))
 (=> $x3379 (and $x4102 $x709))))))
 )
(assert
 (forall ((|X:msg| msg) (|Y:msg| msg) )(let (($x1348 (and (= (msg.kind |X:msg|) (msg.kind |Y:msg|)) (= (msg.src |X:msg|) (msg.src |Y:msg|)) (= (msg.vote |X:msg|) (msg.vote |Y:msg|)))))
 (=> $x1348 (= |X:msg| |Y:msg|))))
 )
(assert
 (= |__m_loc:msg| |__loc:msg_nd|))
(assert
 (= |__new_loc:msg| |__loc:msg_nd_a|))
(assert
 (= |__new_fml:src| |__fml:self|))
(assert
 (= |__new_fml:m| |__new_loc:msg|))
(assert
 (forall ((|V0:msg| msg) (|V1:node| node) )(let (($x1140 (shim.sent |V0:msg| |V1:node|)))
 (= $x1140 (ite (and (= |V0:msg| |__new_fml:m|)) true (__shim.sent |V0:msg| |V1:node|)))))
 )
(assert
 (forall ((|V0:node| node) )(let (($x3333 (__toy_system.alreadyvoted |V0:node|)))
 (let (($x4091 (toy_system.alreadyvoted |V0:node|)))
 (= $x4091 (ite __ts0_a (ite (and (= |V0:node| |__fml:self|)) true $x3333) $x3333)))))
 )
(assert
 (= |__ts0__m_fml:s_a| (__toy_system.voters |__fml:self|)))
(assert
 (= |__ts0__new_fml:n| |__fml:self|))
(assert
 (forall ((|V0:node| node) )(let ((?x715 (__toy_system.voters |V0:node|)))
 (let ((?x2051 (ite __ts0_a (ite (and (= |V0:node| |__fml:self|)) |__new_fml:s_a| ?x715) ?x715)))
 (let ((?x2678 (toy_system.voters |V0:node|)))
 (= ?x2678 ?x2051)))))
 )
(assert
 (= |__ts0__new_fml:v| |__fml:self|))
(assert
 (= |__ts0__new_fml:n_a| |__fml:self|))
(assert
 (forall ((|V0:node| node) (|V1:node| node) )(let (($x2140 (__toy_protocol.voted |V0:node| |V1:node|)))
 (let (($x3497 (ite (and (= |V0:node| |__ts0__new_fml:v|) (= |V1:node| |__ts0__new_fml:n_a|)) true $x2140)))
 (let (($x1388 (toy_protocol.voted |V0:node| |V1:node|)))
 (= $x1388 (ite __ts0_a $x3497 $x2140))))))
 )
(assert
 (= __ts0_a (not (__toy_system.alreadyvoted |__fml:self|))))
(assert
 (let (($x3695 (and (shim.sent @M1 @N1) (= (msg.kind @M1) msg_kind.leader) (shim.sent @M2 @N2) (= (msg.kind @M2) msg_kind.leader))))
 (and (not (=> $x3695 (= (msg.src @M1) (msg.src @M2)))))))
(check-sat)
