(set-info :status unknown)
(declare-sort node.iter.t 0)
 (declare-sort nset.arr 0)
 (declare-sort node 0)
 (declare-sort nset 0)
 (declare-fun |__fml:x| () node)
(declare-fun |0:node| () node)
(declare-fun |__fml:y| () node)
(declare-fun node.max () node)
(declare-fun nset.arr.end (nset.arr) Int)
(declare-fun node.iter.val (node.iter.t) node)
(declare-fun nset.repr (nset) nset.arr)
(declare-fun nset.card (nset) Int)
(declare-fun nset.all () nset)
(declare-fun @T () nset)
(declare-fun @S () nset)
(declare-fun nset.member (node nset) Bool)
(declare-fun nset.majority (nset) Bool)
(declare-fun |<:node:node| (node node) Bool)
(declare-fun node.succ (node node) Bool)
(declare-fun nset.arr.value (nset.arr Int node) Bool)
(declare-fun node.iter.is_end (node.iter.t) Bool)
(declare-fun node.iter.done (node node.iter.t) Bool)
(assert
 (forall ((|S:nset| nset) (|T:nset| nset) )(let (($x1473 (exists ((|N:node| node) )(and (nset.member |N:node| |S:nset|) (nset.member |N:node| |T:nset|)))
 ))
 (=> (and (nset.majority |S:nset|) (nset.majority |T:nset|)) $x1473)))
 )
(assert
 (|<:node:node| |0:node| |__fml:x|))
(assert
 (|<:node:node| |__fml:y| |__fml:x|))
(assert
 (forall ((|Y:node| node) )(=> (|<:node:node| |Y:node| |__fml:x|) (or (= |Y:node| |__fml:y|) (|<:node:node| |Y:node| |__fml:y|))))
 )
(assert
 (node.succ |__fml:y| |__fml:x|))
(assert
 (forall ((|N:node| node) )(or (= |N:node| |0:node|) (|<:node:node| |0:node| |N:node|)))
 )
(assert
 (forall ((|X:node| node) (|Y:node| node) (|Z:node| node) )(let (($x76 (and (|<:node:node| |X:node| |Z:node|) (not (and (|<:node:node| |X:node| |Y:node|) (|<:node:node| |Y:node| |Z:node|))))))
 (=> (node.succ |X:node| |Z:node|) $x76)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) (|V:node| node) )(=> (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |V:node|)) (|<:node:node| |T:node| |V:node|)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(not (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(let (($x71 (|<:node:node| |T:node| |U:node|)))
 (or $x71 (= |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|X:node| node) )(or (= |0:node| |X:node|) (|<:node:node| |0:node| |X:node|)))
 )
(assert
 (forall ((|X:node| node) )(or (= |X:node| node.max) (|<:node:node| |X:node| node.max)))
 )
(assert
 (forall ((|X:nset.arr| nset.arr) )(<= 0 (nset.arr.end |X:nset.arr|)))
 )
(assert
 (forall ((|A:nset.arr| nset.arr) (|X:nset.index| Int) (|Y1:node| node) (|Y2:node| node) )(=> (and (nset.arr.value |A:nset.arr| |X:nset.index| |Y1:node|) (nset.arr.value |A:nset.arr| |X:nset.index| |Y2:node|)) (= |Y1:node| |Y2:node|)))
 )
(assert
 (forall ((|X:node.iter.t| node.iter.t) (|Y:node.iter.t| node.iter.t) )(let (($x25 (and (= (node.iter.is_end |X:node.iter.t|) (node.iter.is_end |Y:node.iter.t|)) (= (node.iter.val |X:node.iter.t|) (node.iter.val |Y:node.iter.t|)))))
 (=> $x25 (= |X:node.iter.t| |Y:node.iter.t|))))
 )
(assert
 (forall ((|X:nset| nset) (|Y:nset| nset) )(=> (and (= (nset.repr |X:nset|) (nset.repr |Y:nset|))) (= |X:nset| |Y:nset|)))
 )
(assert
 (forall ((|X:node| node) (|Y:node.iter.t| node.iter.t) )(= (node.iter.done |X:node| |Y:node.iter.t|) (or (node.iter.is_end |Y:node.iter.t|) (|<:node:node| |X:node| (node.iter.val |Y:node.iter.t|)))))
 )
(assert
 (forall ((|N:node| node) (|S:nset| nset) )(let (($x305 (exists ((|I:nset.index| Int) )(and (<= 0 |I:nset.index|) (< |I:nset.index| (nset.arr.end (nset.repr |S:nset|))) (nset.arr.value (nset.repr |S:nset|) |I:nset.index| |N:node|)))
 ))
 (= (nset.member |N:node| |S:nset|) $x305)))
 )
(assert
 (forall ((|S:nset| nset) )(= (nset.majority |S:nset|) (> (+ (nset.card |S:nset|) (nset.card |S:nset|)) (nset.card nset.all))))
 )
(assert
 (let (($x526 (exists ((|N:node| node) )(and (nset.member |N:node| @S) (nset.member |N:node| @T)))
 ))
 (and (not (=> (and (nset.majority @S) (nset.majority @T)) $x526)))))
(check-sat)
