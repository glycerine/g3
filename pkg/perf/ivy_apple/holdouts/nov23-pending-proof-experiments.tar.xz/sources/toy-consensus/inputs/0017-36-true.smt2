(set-info :status unknown)
(declare-sort msg 0)
 (declare-datatypes ((msg_kind 0)) (((msg_kind.request_vote) (msg_kind.vote) (msg_kind.leader))))
 (declare-sort node 0)
 (declare-sort nset 0)
 (declare-fun msg.src (msg) node)
(declare-fun msg.kind (msg) msg_kind)
(declare-fun msg.vote (msg) node)
(declare-fun toy_system.voters (node) nset)
(declare-fun toy_protocol.quorum () nset)
(declare-fun |__fml:dst| () node)
(declare-fun |__fml:m| () msg)
(declare-fun |__loc:reply| () msg)
(declare-fun |__loc:reply_nd| () msg)
(declare-fun |__ts0__m_loc:reply| () msg)
(declare-fun |__loc:reply_nd_a| () msg)
(declare-fun |__ts0__m_loc:reply_a| () msg)
(declare-fun |__loc:reply_nd_b| () msg)
(declare-fun |__ts0__new_loc:reply| () msg)
(declare-fun |__ts0__new_fml:src| () node)
(declare-fun |__ts0__new_fml:m| () msg)
(declare-fun |__ts0__new_fml:v| () node)
(declare-fun |__ts0__new_fml:n| () node)
(declare-fun @M2 () msg)
(declare-fun @M1 () msg)
(declare-fun @N2 () node)
(declare-fun @N1 () node)
(declare-fun __shim.sent (msg node) Bool)
(declare-fun __toy_protocol.voted (node node) Bool)
(declare-fun nset.member (node nset) Bool)
(declare-fun toy_protocol.isleader (node) Bool)
(declare-fun __toy_system.alreadyvoted (node) Bool)
(declare-fun nset.majority (nset) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun toy_protocol.voted (node node) Bool)
(declare-fun toy_system.alreadyvoted (node) Bool)
(declare-fun shim.sent (msg node) Bool)
(assert
 (forall ((|M1:msg| msg) (|M2:msg| msg) (|N1:node| node) (|N2:node| node) )(let (($x3274 (and (__shim.sent |M1:msg| |N1:node|) (= (msg.kind |M1:msg|) msg_kind.leader) (__shim.sent |M2:msg| |N2:node|) (= (msg.kind |M2:msg|) msg_kind.leader))))
 (=> $x3274 (= (msg.src |M1:msg|) (msg.src |M2:msg|)))))
 )
(assert
 (forall ((|M:msg| msg) (|N:node| node) )(=> (and (__shim.sent |M:msg| |N:node|) (= (msg.kind |M:msg|) msg_kind.vote)) (__toy_protocol.voted (msg.src |M:msg|) (msg.vote |M:msg|))))
 )
(assert
 (forall ((|N1:node| node) (|N2:node| node) )(let (($x2140 (__toy_protocol.voted |N1:node| |N2:node|)))
 (=> (nset.member |N1:node| (toy_system.voters |N2:node|)) $x2140)))
 )
(assert
 (forall ((|M:msg| msg) (|N:node| node) )(=> (and (__shim.sent |M:msg| |N:node|) (= (msg.kind |M:msg|) msg_kind.leader)) (toy_protocol.isleader (msg.src |M:msg|))))
 )
(assert
 (forall ((|N1:node| node) (|N2:node| node) )(let (($x2140 (__toy_protocol.voted |N1:node| |N2:node|)))
 (=> $x2140 (__toy_system.alreadyvoted |N1:node|))))
 )
(assert
 (forall ((|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (toy_protocol.isleader |N:node|) (toy_protocol.isleader |M:node|)) $x1361)))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (__toy_protocol.voted |L:node| |N:node|) (__toy_protocol.voted |L:node| |M:node|)) $x1361)))
 )
(assert
 (forall ((|N:node| node) )(let (($x3961 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (__toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3379 (toy_protocol.isleader |N:node|)))
 (=> $x3379 (and $x4102 $x3961))))))
 )
(assert
 (__shim.sent |__fml:m| |__fml:dst|))
(assert
 (let ((?x2222 (msg.kind |__fml:m|)))
 (= ?x2222 msg_kind.request_vote)))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.src |__loc:reply_nd|) (msg.src |__loc:reply|)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.vote |__loc:reply_nd|) (msg.vote |__loc:reply|)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.kind |__loc:reply_nd|) msg_kind.vote))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.kind |__loc:reply_nd_a|) (msg.kind |__ts0__m_loc:reply|)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.vote |__loc:reply_nd_a|) (msg.vote |__ts0__m_loc:reply|)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.src |__loc:reply_nd_a|) |__fml:dst|))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.kind |__loc:reply_nd_b|) (msg.kind |__ts0__m_loc:reply_a|)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.src |__loc:reply_nd_b|) (msg.src |__ts0__m_loc:reply_a|)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (msg.vote |__loc:reply_nd_b|) (msg.src |__fml:m|)))))
(assert
 (forall ((|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (let (($x35 (not __ts0_a)))
 (or $x35 (=> (and (toy_protocol.isleader |N:node|) (toy_protocol.isleader |M:node|)) $x1361)))))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (let (($x3244 (=> (and (toy_protocol.voted |L:node| |N:node|) (toy_protocol.voted |L:node| |M:node|)) $x1361)))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x3244)))))
 )
(assert
 (forall ((|N:node| node) )(let (($x709 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3379 (toy_protocol.isleader |N:node|)))
 (let (($x35 (not __ts0_a)))
 (or $x35 (=> $x3379 (and $x4102 $x709))))))))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (toy_protocol.voted |L:node| |N:node|) (toy_protocol.voted |L:node| |M:node|)) $x1361)))
 )
(assert
 (forall ((|N:node| node) )(let (($x709 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3379 (toy_protocol.isleader |N:node|)))
 (=> $x3379 (and $x4102 $x709))))))
 )
(assert
 (forall ((|X:msg| msg) (|Y:msg| msg) )(let (($x1348 (and (= (msg.kind |X:msg|) (msg.kind |Y:msg|)) (= (msg.src |X:msg|) (msg.src |Y:msg|)) (= (msg.vote |X:msg|) (msg.vote |Y:msg|)))))
 (=> $x1348 (= |X:msg| |Y:msg|))))
 )
(assert
 (forall ((|V0:node| node) )(let (($x3351 (ite __ts0_a (ite (and (= |V0:node| |__fml:dst|)) true (__toy_system.alreadyvoted |V0:node|)) (__toy_system.alreadyvoted |V0:node|))))
 (= (toy_system.alreadyvoted |V0:node|) $x3351)))
 )
(assert
 (= |__ts0__m_loc:reply| |__loc:reply_nd|))
(assert
 (= |__ts0__m_loc:reply_a| |__loc:reply_nd_a|))
(assert
 (= |__ts0__new_loc:reply| |__loc:reply_nd_b|))
(assert
 (= |__ts0__new_fml:src| |__fml:dst|))
(assert
 (= |__ts0__new_fml:m| |__ts0__new_loc:reply|))
(assert
 (forall ((|V0:msg| msg) (|V1:node| node) )(let (($x1014 (__shim.sent |V0:msg| |V1:node|)))
 (let (($x1140 (shim.sent |V0:msg| |V1:node|)))
 (= $x1140 (ite __ts0_a (ite (and (= |V0:msg| |__ts0__new_fml:m|)) true $x1014) $x1014)))))
 )
(assert
 (= |__ts0__new_fml:v| |__fml:dst|))
(assert
 (let ((?x2929 (msg.src |__fml:m|)))
 (= |__ts0__new_fml:n| ?x2929)))
(assert
 (forall ((|V0:node| node) (|V1:node| node) )(let (($x2140 (__toy_protocol.voted |V0:node| |V1:node|)))
 (let (($x3282 (ite (and (= |V0:node| |__ts0__new_fml:v|) (= |V1:node| |__ts0__new_fml:n|)) true $x2140)))
 (let (($x1388 (toy_protocol.voted |V0:node| |V1:node|)))
 (= $x1388 (ite __ts0_a $x3282 $x2140))))))
 )
(assert
 (= __ts0_a (not (__toy_system.alreadyvoted |__fml:dst|))))
(assert
 (let (($x3695 (and (shim.sent @M1 @N1) (= (msg.kind @M1) msg_kind.leader) (shim.sent @M2 @N2) (= (msg.kind @M2) msg_kind.leader))))
 (and (not (=> $x3695 (= (msg.src @M1) (msg.src @M2)))))))
(check-sat)
