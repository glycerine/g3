(set-info :status unknown)
(declare-sort node.iter.t 0)
 (declare-sort node 0)
 (declare-fun |__fml:x| () node.iter.t)
(declare-fun |__new_fml:x_a| () node)
(declare-fun node.iter.val (node.iter.t) node)
(declare-fun |__fml:y| () node.iter.t)
(declare-fun |__fml:y_nd| () node.iter.t)
(declare-fun |__m_fml:y| () node.iter.t)
(declare-fun |__fml:y_nd_a| () node.iter.t)
(declare-fun |0:node| () node)
(declare-fun |__new_fml:y| () node.iter.t)
(declare-fun |__ts0__new_fml:x_a_b| () node)
(declare-fun |__fml:y_a| () node)
(declare-fun |__fml:y_a_a| () node.iter.t)
(declare-fun |__ts0__new_fml:x_a_a_a| () node)
(declare-fun |__new_fml:x| () node.iter.t)
(declare-fun __Y () node)
(declare-fun __X () node)
(declare-fun node.max () node)
(declare-fun |__ts0__new_loc:0_a| () node)
(declare-fun node.iter.is_end (node.iter.t) Bool)
(declare-fun |<:node:node| (node node) Bool)
(declare-fun |__fml:r| () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun node.succ (node node) Bool)
(declare-fun |__new_loc:0| () Bool)
(assert
 (not (node.iter.is_end |__fml:x|)))
(assert
 (let (($x41 (exists ((|S:node| node) )(|<:node:node| |__new_fml:x_a| |S:node|))
 ))
 (= |__fml:r| (not $x41))))
(assert
 (let ((?x186 (node.iter.val |__fml:y_nd|)))
 (let (($x163 (= ?x186 (node.iter.val |__fml:y|))))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x163)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (or (node.iter.is_end |__fml:y_nd|) (not true)))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (or (not (node.iter.is_end |__fml:y_nd|)) true))))
(assert
 (let (($x181 (= (node.iter.is_end |__fml:y_nd_a|) (node.iter.is_end |__m_fml:y|))))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x181))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 (= (node.iter.val |__fml:y_nd_a|) |0:node|))))
(assert
 (let (($x157 (node.iter.is_end |__new_fml:y|)))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x157))))
(assert
 (let ((?x168 (node.iter.val |__new_fml:y|)))
 (let (($x228 (= ?x168 |0:node|)))
 (let (($x35 (not __ts0_a)))
 (or $x35 $x228)))))
(assert
 (let (($x233 (exists ((|S:node| node) )(|<:node:node| |__ts0__new_fml:x_a_b| |S:node|))
 ))
 (or __ts0_a $x233)))
(assert
 (or __ts0_a (|<:node:node| |__ts0__new_fml:x_a_b| |__fml:y_a|)))
(assert
 (forall ((|Y:node| node) )(let (($x242 (=> (|<:node:node| |__ts0__new_fml:x_a_b| |Y:node|) (or (= |__fml:y_a| |Y:node|) (|<:node:node| |__fml:y_a| |Y:node|)))))
 (or __ts0_a $x242)))
 )
(assert
 (or __ts0_a (node.succ |__ts0__new_fml:x_a_b| |__fml:y_a|)))
(assert
 (or __ts0_a (= (node.iter.val |__fml:y_nd|) (node.iter.val |__fml:y_a_a|))))
(assert
 (let (($x155 (not false)))
 (let (($x200 (node.iter.is_end |__fml:y_nd|)))
 (let (($x165 (or $x200 $x155)))
 (or __ts0_a $x165)))))
(assert
 (let (($x200 (node.iter.is_end |__fml:y_nd|)))
 (let (($x197 (not $x200)))
 (let (($x198 (or $x197 false)))
 (or __ts0_a $x198)))))
(assert
 (let (($x181 (= (node.iter.is_end |__fml:y_nd_a|) (node.iter.is_end |__m_fml:y|))))
 (or __ts0_a $x181)))
(assert
 (or __ts0_a (= (node.iter.val |__fml:y_nd_a|) |__ts0__new_fml:x_a_a_a|)))
(assert
 (let (($x157 (node.iter.is_end |__new_fml:y|)))
 (let (($x161 (not $x157)))
 (or __ts0_a $x161))))
(assert
 (or __ts0_a (= (node.iter.val |__new_fml:y|) |__ts0__new_fml:x_a_a_a|)))
(assert
 (let (($x266 (and (|<:node:node| (node.iter.val |__fml:x|) __Y) (|<:node:node| __Y (node.iter.val |__new_fml:x|)))))
 (let (($x270 (and (not $x266) (|<:node:node| (node.iter.val |__fml:x|) (node.iter.val |__new_fml:x|)) (not (node.iter.is_end |__new_fml:x|)))))
 (let (($x260 (node.iter.is_end |__new_fml:x|)))
 (let (($x259 (or (= __X (node.iter.val |__fml:x|)) (|<:node:node| __X (node.iter.val |__fml:x|)))))
 (not (or (and $x259 $x260) $x270)))))))
(assert
 (forall ((|N:node| node) )(or (= |N:node| |0:node|) (|<:node:node| |0:node| |N:node|)))
 )
(assert
 (forall ((|X:node| node) (|Y:node| node) (|Z:node| node) )(let (($x76 (and (|<:node:node| |X:node| |Z:node|) (not (and (|<:node:node| |X:node| |Y:node|) (|<:node:node| |Y:node| |Z:node|))))))
 (=> (node.succ |X:node| |Z:node|) $x76)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) (|V:node| node) )(=> (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |V:node|)) (|<:node:node| |T:node| |V:node|)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(not (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(let (($x71 (|<:node:node| |T:node| |U:node|)))
 (or $x71 (= |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|X:node| node) )(or (= |0:node| |X:node|) (|<:node:node| |0:node| |X:node|)))
 )
(assert
 (forall ((|X:node| node) )(or (= |X:node| node.max) (|<:node:node| |X:node| node.max)))
 )
(assert
 (forall ((|X:node.iter.t| node.iter.t) (|Y:node.iter.t| node.iter.t) )(let (($x25 (and (= (node.iter.is_end |X:node.iter.t|) (node.iter.is_end |Y:node.iter.t|)) (= (node.iter.val |X:node.iter.t|) (node.iter.val |Y:node.iter.t|)))))
 (=> $x25 (= |X:node.iter.t| |Y:node.iter.t|))))
 )
(assert
 (let ((?x125 (node.iter.val |__fml:x|)))
 (= |__new_fml:x_a| ?x125)))
(assert
 (= |__new_loc:0| |__fml:r|))
(assert
 (= |__m_fml:y| |__fml:y_nd|))
(assert
 (= |__new_fml:y| |__fml:y_nd_a|))
(assert
 (= |__new_fml:x| |__new_fml:y|))
(assert
 (let ((?x125 (node.iter.val |__fml:x|)))
 (= |__ts0__new_fml:x_a_b| ?x125)))
(assert
 (= |__ts0__new_loc:0_a| |__fml:y_a|))
(assert
 (= |__ts0__new_fml:x_a_a_a| |__ts0__new_loc:0_a|))
(assert
 (= __ts0_a |__new_loc:0|))
(assert
 (let (($x155 (not false)))
 (and $x155)))
(check-sat)
