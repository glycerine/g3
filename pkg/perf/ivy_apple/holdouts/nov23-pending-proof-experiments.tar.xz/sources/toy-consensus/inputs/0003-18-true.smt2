(set-info :status unknown)
(declare-sort node.iter.t 0)
 (declare-sort node 0)
 (declare-fun |__fml:x| () node.iter.t)
(declare-fun |__new_fml:x_a| () node)
(declare-fun |__new_fml:x_a_a| () node)
(declare-fun |0:node| () node)
(declare-fun node.max () node)
(declare-fun node.iter.val (node.iter.t) node)
(declare-fun |__loc:0| () node)
(declare-fun |__new_loc:0| () node)
(declare-fun |__new_fml:x| () node.iter.t)
(declare-fun node.iter.is_end (node.iter.t) Bool)
(declare-fun |<:node:node| (node node) Bool)
(declare-fun |__fml:r| () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun node.succ (node node) Bool)
(declare-fun |__new_loc:0_a| () Bool)
(assert
 (not (node.iter.is_end |__fml:x|)))
(assert
 (let (($x41 (exists ((|S:node| node) )(|<:node:node| |__new_fml:x_a| |S:node|))
 ))
 (= |__fml:r| (not $x41))))
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 false)))
(assert
 (forall ((|S:node| node) )(or __ts0_a (not (|<:node:node| |__new_fml:x_a_a| |S:node|))))
 )
(assert
 (forall ((|N:node| node) )(or (= |N:node| |0:node|) (|<:node:node| |0:node| |N:node|)))
 )
(assert
 (forall ((|X:node| node) (|Y:node| node) (|Z:node| node) )(let (($x76 (and (|<:node:node| |X:node| |Z:node|) (not (and (|<:node:node| |X:node| |Y:node|) (|<:node:node| |Y:node| |Z:node|))))))
 (=> (node.succ |X:node| |Z:node|) $x76)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) (|V:node| node) )(=> (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |V:node|)) (|<:node:node| |T:node| |V:node|)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(not (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(let (($x71 (|<:node:node| |T:node| |U:node|)))
 (or $x71 (= |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|X:node| node) )(or (= |0:node| |X:node|) (|<:node:node| |0:node| |X:node|)))
 )
(assert
 (forall ((|X:node| node) )(or (= |X:node| node.max) (|<:node:node| |X:node| node.max)))
 )
(assert
 (forall ((|X:node.iter.t| node.iter.t) (|Y:node.iter.t| node.iter.t) )(let (($x25 (and (= (node.iter.is_end |X:node.iter.t|) (node.iter.is_end |Y:node.iter.t|)) (= (node.iter.val |X:node.iter.t|) (node.iter.val |Y:node.iter.t|)))))
 (=> $x25 (= |X:node.iter.t| |Y:node.iter.t|))))
 )
(assert
 (let ((?x125 (node.iter.val |__fml:x|)))
 (= |__new_fml:x_a| ?x125)))
(assert
 (= |__new_loc:0_a| |__fml:r|))
(assert
 (let ((?x125 (node.iter.val |__fml:x|)))
 (= |__new_fml:x_a_a| ?x125)))
(assert
 (= |__new_loc:0| |__loc:0|))
(assert
 (= |__new_fml:x| |__fml:x|))
(assert
 (= __ts0_a |__new_loc:0_a|))
(assert
 (let (($x155 (not false)))
 (and $x155)))
(check-sat)
