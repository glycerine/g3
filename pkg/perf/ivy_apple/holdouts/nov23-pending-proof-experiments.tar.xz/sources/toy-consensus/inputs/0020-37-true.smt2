(set-info :status unknown)
(declare-sort msg 0)
 (declare-datatypes ((msg_kind 0)) (((msg_kind.request_vote) (msg_kind.vote) (msg_kind.leader))))
 (declare-sort node 0)
 (declare-sort nset 0)
 (declare-fun msg.src (msg) node)
(declare-fun msg.kind (msg) msg_kind)
(declare-fun msg.vote (msg) node)
(declare-fun __toy_system.voters (node) nset)
(declare-fun toy_protocol.quorum () nset)
(declare-fun |__fml:dst| () node)
(declare-fun |__fml:m| () msg)
(declare-fun |__new_fml:n| () node)
(declare-fun |__m_fml:s_a| () nset)
(declare-fun |__new_fml:s_a| () nset)
(declare-fun |__loc:reply| () msg)
(declare-fun |__loc:reply_nd| () msg)
(declare-fun |__m_loc:reply| () msg)
(declare-fun |__loc:reply_nd_a| () msg)
(declare-fun |__new_fml:n_a| () node)
(declare-fun __N () node)
(declare-fun |__new_fml:s| () nset)
(declare-fun toy_system.voters (node) nset)
(declare-fun |__new_loc:reply| () msg)
(declare-fun |__new_fml:src| () node)
(declare-fun |__new_fml:m| () msg)
(declare-fun __shim.sent (msg node) Bool)
(declare-fun toy_protocol.voted (node node) Bool)
(declare-fun nset.member (node nset) Bool)
(declare-fun __toy_protocol.isleader (node) Bool)
(declare-fun toy_system.alreadyvoted (node) Bool)
(declare-fun nset.majority (nset) Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun shim.sent (msg node) Bool)
(declare-fun toy_protocol.isleader (node) Bool)
(assert
 (forall ((|M1:msg| msg) (|M2:msg| msg) (|N1:node| node) (|N2:node| node) )(let (($x3274 (and (__shim.sent |M1:msg| |N1:node|) (= (msg.kind |M1:msg|) msg_kind.leader) (__shim.sent |M2:msg| |N2:node|) (= (msg.kind |M2:msg|) msg_kind.leader))))
 (=> $x3274 (= (msg.src |M1:msg|) (msg.src |M2:msg|)))))
 )
(assert
 (forall ((|M:msg| msg) (|N:node| node) )(=> (and (__shim.sent |M:msg| |N:node|) (= (msg.kind |M:msg|) msg_kind.vote)) (toy_protocol.voted (msg.src |M:msg|) (msg.vote |M:msg|))))
 )
(assert
 (forall ((|N1:node| node) (|N2:node| node) )(let (($x1388 (toy_protocol.voted |N1:node| |N2:node|)))
 (=> (nset.member |N1:node| (__toy_system.voters |N2:node|)) $x1388)))
 )
(assert
 (forall ((|M:msg| msg) (|N:node| node) )(=> (and (__shim.sent |M:msg| |N:node|) (= (msg.kind |M:msg|) msg_kind.leader)) (__toy_protocol.isleader (msg.src |M:msg|))))
 )
(assert
 (forall ((|N1:node| node) (|N2:node| node) )(let (($x1388 (toy_protocol.voted |N1:node| |N2:node|)))
 (=> $x1388 (toy_system.alreadyvoted |N1:node|))))
 )
(assert
 (forall ((|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (__toy_protocol.isleader |N:node|) (__toy_protocol.isleader |M:node|)) $x1361)))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (=> (and (toy_protocol.voted |L:node| |N:node|) (toy_protocol.voted |L:node| |M:node|)) $x1361)))
 )
(assert
 (forall ((|N:node| node) )(let (($x709 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3216 (__toy_protocol.isleader |N:node|)))
 (=> $x3216 (and $x4102 $x709))))))
 )
(assert
 (__shim.sent |__fml:m| |__fml:dst|))
(assert
 (let ((?x2222 (msg.kind |__fml:m|)))
 (= ?x2222 msg_kind.vote)))
(assert
 (forall ((|N:node| node) )(let (($x3169 (nset.member |N:node| |__new_fml:s_a|)))
 (let (($x679 (not __ts0_b)))
 (or $x679 (= $x3169 (or (nset.member |N:node| |__m_fml:s_a|) (= |N:node| |__new_fml:n|)))))))
 )
(assert
 (forall ((|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (let (($x3028 (=> (and (__toy_protocol.isleader |N:node|) (__toy_protocol.isleader |M:node|)) $x1361)))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x3028)))))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(let (($x1361 (= |N:node| |M:node|)))
 (let (($x3244 (=> (and (toy_protocol.voted |L:node| |N:node|) (toy_protocol.voted |L:node| |M:node|)) $x1361)))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x3244)))))
 )
(assert
 (forall ((|N:node| node) )(let (($x709 (forall ((|M:node| node) )(let (($x1667 (nset.member |M:node| toy_protocol.quorum)))
 (=> $x1667 (toy_protocol.voted |M:node| |N:node|))))
 ))
 (let (($x4102 (nset.majority toy_protocol.quorum)))
 (let (($x3216 (__toy_protocol.isleader |N:node|)))
 (let (($x679 (not __ts0_b)))
 (or $x679 (=> $x3216 (and $x4102 $x709))))))))
 )
(assert
 (let (($x701 (= (msg.src |__loc:reply_nd|) (msg.src |__loc:reply|))))
 (let (($x35 (not __ts0_a)))
 (let (($x3163 (or $x35 $x701)))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x3163))))))
(assert
 (let (($x732 (= (msg.vote |__loc:reply_nd|) (msg.vote |__loc:reply|))))
 (let (($x35 (not __ts0_a)))
 (let (($x3284 (or $x35 $x732)))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x3284))))))
(assert
 (let (($x679 (not __ts0_b)))
 (or $x679 (or (not __ts0_a) (= (msg.kind |__loc:reply_nd|) msg_kind.leader)))))
(assert
 (let (($x35 (not __ts0_a)))
 (let (($x3554 (or $x35 (= (msg.kind |__loc:reply_nd_a|) (msg.kind |__m_loc:reply|)))))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x3554)))))
(assert
 (let (($x35 (not __ts0_a)))
 (let (($x3323 (or $x35 (= (msg.vote |__loc:reply_nd_a|) (msg.vote |__m_loc:reply|)))))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x3323)))))
(assert
 (let (($x3241 (= (msg.src |__loc:reply_nd_a|) |__fml:dst|)))
 (let (($x35 (not __ts0_a)))
 (let (($x3172 (or $x35 $x3241)))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x3172))))))
(assert
 (let (($x995 (nset.member __N |__new_fml:s|)))
 (let (($x2690 (and (nset.majority |__new_fml:s|) (=> $x995 (toy_protocol.voted __N |__new_fml:n_a|)))))
 (let (($x35 (not __ts0_a)))
 (let (($x679 (not __ts0_b)))
 (or $x679 (or $x35 (not $x2690))))))))
(assert
 (let (($x162 (or __ts0_a false)))
 (let (($x679 (not __ts0_b)))
 (or $x679 $x162))))
(assert
 (or __ts0_b false))
(assert
 (forall ((|X:msg| msg) (|Y:msg| msg) )(let (($x1348 (and (= (msg.kind |X:msg|) (msg.kind |Y:msg|)) (= (msg.src |X:msg|) (msg.src |Y:msg|)) (= (msg.vote |X:msg|) (msg.vote |Y:msg|)))))
 (=> $x1348 (= |X:msg| |Y:msg|))))
 )
(assert
 (let ((?x2257 (__toy_system.voters |__fml:dst|)))
 (= |__m_fml:s_a| ?x2257)))
(assert
 (let ((?x2929 (msg.src |__fml:m|)))
 (= |__new_fml:n| ?x2929)))
(assert
 (forall ((|V0:node| node) )(let ((?x715 (__toy_system.voters |V0:node|)))
 (let ((?x2678 (toy_system.voters |V0:node|)))
 (= ?x2678 (ite (and (= |V0:node| |__fml:dst|)) |__new_fml:s_a| ?x715)))))
 )
(assert
 (= |__m_loc:reply| |__loc:reply_nd|))
(assert
 (= |__new_loc:reply| |__loc:reply_nd_a|))
(assert
 (= |__new_fml:src| |__fml:dst|))
(assert
 (= |__new_fml:m| |__new_loc:reply|))
(assert
 (forall ((|V0:msg| msg) (|V1:node| node) )(let (($x1140 (shim.sent |V0:msg| |V1:node|)))
 (= $x1140 (ite (and (= |V0:msg| |__new_fml:m|)) true (__shim.sent |V0:msg| |V1:node|)))))
 )
(assert
 (= |__new_fml:n_a| |__fml:dst|))
(assert
 (let ((?x2270 (toy_system.voters |__fml:dst|)))
 (= |__new_fml:s| ?x2270)))
(assert
 (forall ((|V0:node| node) )(let (($x3216 (__toy_protocol.isleader |V0:node|)))
 (let (($x3379 (toy_protocol.isleader |V0:node|)))
 (= $x3379 $x3216))))
 )
(assert
 (let ((?x2270 (toy_system.voters |__fml:dst|)))
 (let (($x2232 (nset.majority ?x2270)))
 (= __ts0_a $x2232))))
(assert
 (= __ts0_b (= (msg.vote |__fml:m|) |__fml:dst|)))
(assert
 (let (($x155 (not false)))
 (and $x155)))
(check-sat)
