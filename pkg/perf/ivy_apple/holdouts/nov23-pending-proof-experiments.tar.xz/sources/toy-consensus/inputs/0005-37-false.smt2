(set-info :status unknown)
(declare-sort node 0)
 (declare-sort nset.arr 0)
 (declare-sort node.iter.t 0)
 (declare-sort nset 0)
 (declare-fun nset.arr.end (nset.arr) Int)
(declare-fun |__fml:a| () nset.arr)
(declare-fun nset.repr (nset) nset.arr)
(declare-fun __nset.all_nd () nset)
(declare-fun |__fml:y| () node.iter.t)
(declare-fun |__new_fml:x| () node)
(declare-fun node.iter.val (node.iter.t) node)
(declare-fun __m_nset.card (nset) Int)
(declare-fun __m_nset.all () nset)
(declare-fun |__m_loc:i| () node.iter.t)
(declare-fun |0:node| () node)
(declare-fun node.max () node)
(declare-fun __nset.card (nset) Int)
(declare-fun __nset.all () nset)
(declare-fun __m_nset.card_a (nset) Int)
(declare-fun __m_nset.all_a () nset)
(declare-fun |__new_loc:0| () node.iter.t)
(declare-fun |__m_loc:i_a| () node.iter.t)
(declare-fun nset.all () nset)
(declare-fun nset.card (nset) Int)
(declare-fun |__new_loc:i| () node.iter.t)
(declare-fun @T () nset)
(declare-fun @S () nset)
(declare-fun node.iter.is_end (node.iter.t) Bool)
(declare-fun nset.member (node nset) Bool)
(declare-fun node.iter.done (node node.iter.t) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun |<:node:node| (node node) Bool)
(declare-fun node.succ (node node) Bool)
(declare-fun nset.arr.value (nset.arr Int node) Bool)
(declare-fun __nset.majority (nset) Bool)
(declare-fun __m_nset.majority (nset) Bool)
(declare-fun __m_nset.majority_a (nset) Bool)
(declare-fun __m_nset.majority_a_a (nset) Bool)
(declare-fun __m_nset.majority_c (nset) Bool)
(declare-fun __m_nset.majority_b (nset) Bool)
(declare-fun nset.majority (nset) Bool)
(assert
 (= (nset.arr.end |__fml:a|) 0))
(assert
 (= (nset.repr __nset.all_nd) |__fml:a|))
(assert
 (not (node.iter.is_end |__fml:y|)))
(assert
 (let ((?x169 (node.iter.val |__fml:y|)))
 (= ?x169 |__new_fml:x|)))
(assert
 (forall ((|S:nset| nset) (|T:nset| nset) )(let ((?x447 (__m_nset.card __m_nset.all)))
 (let (($x448 (forall ((|N:node| node) )(not (and (nset.member |N:node| |S:nset|) (nset.member |N:node| |T:nset|))))
 ))
 (=> $x448 (<= (+ (__m_nset.card |S:nset|) (__m_nset.card |T:nset|)) ?x447)))))
 )
(assert
 (forall ((|N:node| node) )(= (node.iter.done |N:node| |__m_loc:i|) (nset.member |N:node| __m_nset.all)))
 )
(assert
 (forall ((|S:nset| nset) )(let ((?x432 (__m_nset.card |S:nset|)))
 (<= 0 ?x432)))
 )
(assert
 (let (($x35 (not __ts0_a)))
 (or $x35 false)))
(assert
 (forall ((|N:node| node) )(or (= |N:node| |0:node|) (|<:node:node| |0:node| |N:node|)))
 )
(assert
 (forall ((|X:node| node) (|Y:node| node) (|Z:node| node) )(let (($x76 (and (|<:node:node| |X:node| |Z:node|) (not (and (|<:node:node| |X:node| |Y:node|) (|<:node:node| |Y:node| |Z:node|))))))
 (=> (node.succ |X:node| |Z:node|) $x76)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) (|V:node| node) )(=> (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |V:node|)) (|<:node:node| |T:node| |V:node|)))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(not (and (|<:node:node| |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|T:node| node) (|U:node| node) )(let (($x71 (|<:node:node| |T:node| |U:node|)))
 (or $x71 (= |T:node| |U:node|) (|<:node:node| |U:node| |T:node|))))
 )
(assert
 (forall ((|X:node| node) )(or (= |0:node| |X:node|) (|<:node:node| |0:node| |X:node|)))
 )
(assert
 (forall ((|X:node| node) )(or (= |X:node| node.max) (|<:node:node| |X:node| node.max)))
 )
(assert
 (forall ((|X:nset.arr| nset.arr) )(<= 0 (nset.arr.end |X:nset.arr|)))
 )
(assert
 (forall ((|A:nset.arr| nset.arr) (|X:nset.index| Int) (|Y1:node| node) (|Y2:node| node) )(=> (and (nset.arr.value |A:nset.arr| |X:nset.index| |Y1:node|) (nset.arr.value |A:nset.arr| |X:nset.index| |Y2:node|)) (= |Y1:node| |Y2:node|)))
 )
(assert
 (forall ((|X:node.iter.t| node.iter.t) (|Y:node.iter.t| node.iter.t) )(let (($x25 (and (= (node.iter.is_end |X:node.iter.t|) (node.iter.is_end |Y:node.iter.t|)) (= (node.iter.val |X:node.iter.t|) (node.iter.val |Y:node.iter.t|)))))
 (=> $x25 (= |X:node.iter.t| |Y:node.iter.t|))))
 )
(assert
 (forall ((|X:nset| nset) (|Y:nset| nset) )(=> (and (= (nset.repr |X:nset|) (nset.repr |Y:nset|))) (= |X:nset| |Y:nset|)))
 )
(assert
 (forall ((|S:nset| nset) )(= (__nset.majority |S:nset|) (> (+ (__nset.card |S:nset|) (__nset.card |S:nset|)) (__nset.card __nset.all))))
 )
(assert
 (forall ((|V0:nset| nset) )(let ((?x438 (__m_nset.card_a |V0:nset|)))
 (= ?x438 0)))
 )
(assert
 (= __m_nset.all_a __nset.all_nd))
(assert
 (forall ((|S:nset| nset) )(let ((?x488 (__m_nset.card_a __nset.all)))
 (let ((?x438 (__m_nset.card_a |S:nset|)))
 (let ((?x467 (+ ?x438 ?x438)))
 (= (__m_nset.majority |S:nset|) (> ?x467 ?x488))))))
 )
(assert
 (= |__new_fml:x| |0:node|))
(assert
 (= |__new_loc:0| |__fml:y|))
(assert
 (= |__m_loc:i_a| |__new_loc:0|))
(assert
 (forall ((|S:nset| nset) )(let ((?x381 (__m_nset.card_a __m_nset.all)))
 (let ((?x438 (__m_nset.card_a |S:nset|)))
 (let ((?x467 (+ ?x438 ?x438)))
 (= (__m_nset.majority_a |S:nset|) (> ?x467 ?x381))))))
 )
(assert
 (forall ((|S:nset| nset) )(let ((?x381 (__m_nset.card_a __m_nset.all)))
 (let ((?x438 (__m_nset.card_a |S:nset|)))
 (let ((?x467 (+ ?x438 ?x438)))
 (= (__m_nset.majority_a_a |S:nset|) (> ?x467 ?x381))))))
 )
(assert
 (= nset.all __m_nset.all))
(assert
 (forall ((|V0:nset| nset) )(let ((?x432 (__m_nset.card |V0:nset|)))
 (let ((?x377 (nset.card |V0:nset|)))
 (= ?x377 ?x432))))
 )
(assert
 (= |__new_loc:i| |__m_loc:i|))
(assert
 (= __ts0_a (not (node.iter.is_end |__m_loc:i|))))
(assert
 (forall ((|S:nset| nset) )(let ((?x447 (__m_nset.card __m_nset.all)))
 (= (__m_nset.majority_c |S:nset|) (> (+ (__m_nset.card |S:nset|) (__m_nset.card |S:nset|)) ?x447))))
 )
(assert
 (forall ((|S:nset| nset) )(let ((?x484 (__m_nset.card_a __m_nset.all_a)))
 (let ((?x438 (__m_nset.card_a |S:nset|)))
 (let ((?x467 (+ ?x438 ?x438)))
 (= (__m_nset.majority_b |S:nset|) (> ?x467 ?x484))))))
 )
(assert
 (forall ((|X:node| node) (|Y:node.iter.t| node.iter.t) )(= (node.iter.done |X:node| |Y:node.iter.t|) (or (node.iter.is_end |Y:node.iter.t|) (|<:node:node| |X:node| (node.iter.val |Y:node.iter.t|)))))
 )
(assert
 (forall ((|N:node| node) (|S:nset| nset) )(let (($x305 (exists ((|I:nset.index| Int) )(and (<= 0 |I:nset.index|) (< |I:nset.index| (nset.arr.end (nset.repr |S:nset|))) (nset.arr.value (nset.repr |S:nset|) |I:nset.index| |N:node|)))
 ))
 (= (nset.member |N:node| |S:nset|) $x305)))
 )
(assert
 (forall ((|S:nset| nset) )(= (nset.majority |S:nset|) (> (+ (nset.card |S:nset|) (nset.card |S:nset|)) (nset.card nset.all))))
 )
(assert
 (let (($x526 (exists ((|N:node| node) )(and (nset.member |N:node| @S) (nset.member |N:node| @T)))
 ))
 (and (not (=> (and (nset.majority @S) (nset.majority @T)) $x526)))))
(check-sat)
