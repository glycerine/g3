(set-info :status unknown)
(declare-sort node 0)
 (declare-sort nset 0)
 (declare-fun __toy_protocol.quorum () nset)
(declare-fun |__fml:s| () nset)
(declare-fun |__fml:n| () node)
(declare-fun toy_protocol.quorum () nset)
(declare-fun @M () node)
(declare-fun @N () node)
(declare-fun __toy_protocol.isleader (node) Bool)
(declare-fun toy_protocol.voted (node node) Bool)
(declare-fun nset.member (node nset) Bool)
(declare-fun nset.majority (nset) Bool)
(declare-fun toy_protocol.isleader (node) Bool)
(assert
 (forall ((|M:node| node) (|N:node| node) )(=> (and (__toy_protocol.isleader |N:node|) (__toy_protocol.isleader |M:node|)) (= |N:node| |M:node|)))
 )
(assert
 (forall ((|L:node| node) (|M:node| node) (|N:node| node) )(=> (and (toy_protocol.voted |L:node| |N:node|) (toy_protocol.voted |L:node| |M:node|)) (= |N:node| |M:node|)))
 )
(assert
 (forall ((|N:node| node) )(let (($x3638 (forall ((|M:node| node) )(=> (nset.member |M:node| __toy_protocol.quorum) (toy_protocol.voted |M:node| |N:node|)))
 ))
 (let (($x3636 (nset.majority __toy_protocol.quorum)))
 (let (($x3216 (__toy_protocol.isleader |N:node|)))
 (=> $x3216 (and $x3636 $x3638))))))
 )
(assert
 (forall ((|S:nset| nset) (|T:nset| nset) )(let (($x1473 (exists ((|N:node| node) )(and (nset.member |N:node| |S:nset|) (nset.member |N:node| |T:nset|)))
 ))
 (=> (and (nset.majority |S:nset|) (nset.majority |T:nset|)) $x1473)))
 )
(assert
 (nset.majority |__fml:s|))
(assert
 (forall ((|N:node| node) )(=> (nset.member |N:node| |__fml:s|) (toy_protocol.voted |N:node| |__fml:n|)))
 )
(assert
 (forall ((|V0:node| node) )(= (toy_protocol.isleader |V0:node|) (ite (and (= |V0:node| |__fml:n|)) true (__toy_protocol.isleader |V0:node|))))
 )
(assert
 (= toy_protocol.quorum |__fml:s|))
(assert
 (let (($x1083 (= @N @M)))
 (let (($x3925 (not (=> (and (toy_protocol.isleader @N) (toy_protocol.isleader @M)) $x1083))))
 (and $x3925))))
(check-sat)
