(set-info :status unknown)
(declare-sort tlb.pmap 0)
 (declare-sort tlb.processor 0)
 (declare-fun tlb.writepmap (tlb.processor) tlb.pmap)
(declare-fun @P () tlb.processor)
(declare-fun tlb.currentcpu (tlb.processor tlb.processor) Bool)
(declare-fun tlb.plock (tlb.pmap) Bool)
(declare-fun tlb.actionlock (tlb.processor) Bool)
(declare-fun tlb.actionneeded (tlb.processor) Bool)
(declare-fun tlb.interrupt (tlb.processor) Bool)
(declare-fun tlb.active (tlb.processor) Bool)
(declare-fun tlb.error () Bool)
(declare-fun tlb.scheduled (tlb.processor) Bool)
(declare-fun tlb.pc_b1 (tlb.processor) Bool)
(declare-fun tlb.pc_i1 (tlb.processor) Bool)
(declare-fun tlb.pc_i2 (tlb.processor) Bool)
(declare-fun tlb.pc_i3 (tlb.processor) Bool)
(declare-fun tlb.pc_i4 (tlb.processor) Bool)
(declare-fun tlb.pc_i5 (tlb.processor) Bool)
(declare-fun tlb.pc_i6 (tlb.processor) Bool)
(declare-fun tlb.pc_i7 (tlb.processor) Bool)
(declare-fun tlb.pc_i8 (tlb.processor) Bool)
(declare-fun tlb.pc_i9 (tlb.processor) Bool)
(declare-fun tlb.pc_i11 (tlb.processor) Bool)
(declare-fun tlb.pc_i12 (tlb.processor) Bool)
(declare-fun tlb.pc_i14 (tlb.processor) Bool)
(declare-fun tlb.pc_i15 (tlb.processor) Bool)
(declare-fun tlb.pc_m2 (tlb.processor) Bool)
(declare-fun tlb.pc_m3 (tlb.processor) Bool)
(declare-fun tlb.pc_m5 (tlb.processor) Bool)
(declare-fun tlb.pc_r1 (tlb.processor) Bool)
(declare-fun tlb.pc_r2 (tlb.processor) Bool)
(declare-fun tlb.pc_r3 (tlb.processor) Bool)
(declare-fun tlb.pc_r5 (tlb.processor) Bool)
(declare-fun tlb.pc_r6 (tlb.processor) Bool)
(declare-fun tlb.pc_r7 (tlb.processor) Bool)
(declare-fun tlb.pc_r8 (tlb.processor) Bool)
(assert
 (forall ((|V0:tlb.processor| tlb.processor) (|V1:tlb.processor| tlb.processor) )(not (tlb.currentcpu |V0:tlb.processor| |V1:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.pmap| tlb.pmap) )(not (tlb.plock |V0:tlb.pmap|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.actionlock |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.actionneeded |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.interrupt |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(tlb.active |V0:tlb.processor|))
 )
(assert
 (not tlb.error))
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.scheduled |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(tlb.pc_b1 |V0:tlb.processor|))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i1 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i2 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i3 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i4 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i5 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i6 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i7 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i8 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i9 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i11 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i12 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i14 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_i15 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_m2 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_m3 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_m5 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_r1 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_r2 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_r3 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_r5 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_r6 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_r7 |V0:tlb.processor|)))
 )
(assert
 (forall ((|V0:tlb.processor| tlb.processor) )(not (tlb.pc_r8 |V0:tlb.processor|)))
 )
(assert
 (let (($x195 (or (tlb.pc_i3 @P) (tlb.pc_i4 @P) (tlb.pc_i5 @P) (tlb.pc_i6 @P) (tlb.pc_i7 @P) (tlb.pc_i8 @P) (tlb.pc_i9 @P) (tlb.pc_i11 @P) (tlb.pc_i12 @P) (tlb.pc_i14 @P))))
 (and (not (=> $x195 (tlb.plock (tlb.writepmap @P)))))))
(check-sat)
