(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun cache.wait (id) wait_type)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun home () id)
(declare-fun dir.hptr () id)
(declare-fun real_owner () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __invack (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun dir.real (id) Bool)
(declare-fun __invnet (id) Bool)
(declare-fun invnet (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun __cache.invmarked (id) Bool)
(declare-fun cache.invmarked (id) Bool)
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let ((?x20 (cache.wait |Y:id|)))
 (let (($x21 (= ?x20 none)))
 (let (($x875 (and (= (__cache.state_ |X:id|) exclusive) (= (cache.wait |X:id|) none) (= (__cache.state_ |Y:id|) exclusive) $x21 (not (= |X:id| |Y:id|)))))
 (not $x875)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (net.put |Y:id| |X:id|)) (not (net.put |Z:id| |X:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (net.get |X:id| |Y:id|)) (not (net.get |X:id| |Z:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (net.putX |Y:id| |X:id|)) (not (net.putX |Z:id| |X:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (net.getX |X:id| |Y:id|)) (not (net.getX |X:id| |Z:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(or (not (net.get |X:id| |Z:id|)) (not (net.put |Y:id| |X:id|))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(or (not (net.getX |X:id| |Z:id|)) (not (net.putX |Y:id| |X:id|))))
 )
(assert
 (forall ((|Y:id| id) )(not (net.getX home |Y:id|)))
 )
(assert
 (let (($x65 (not dir.head)))
 (or (dir.shlist dir.hptr) $x65)))
(assert
 (forall ((|X:id| id) )(let (($x529 (not (net.get |X:id| home))))
 (let ((?x20 (cache.wait |X:id|)))
 (let (($x530 (= ?x20 get)))
 (or $x530 $x529)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x537 (not (net.put home |X:id|))))
 (let ((?x20 (cache.wait |X:id|)))
 (let (($x530 (= ?x20 get)))
 (or $x530 $x537)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x74 (not (rp_net |X:id|))))
 (let (($x537 (not (net.put home |X:id|))))
 (or $x537 $x74))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (or $x868 (not (= (cache.wait |X:id|) getX)))))
 )
(assert
 (forall ((|X:id| id) )(let ((?x20 (cache.wait |X:id|)))
 (let (($x549 (= ?x20 getX)))
 (or $x549 (not (net.getX |X:id| home))))))
 )
(assert
 (forall ((|X:id| id) )(let (($x565 (not (net.putX home |X:id|))))
 (let ((?x20 (cache.wait |X:id|)))
 (let (($x549 (= ?x20 getX)))
 (or $x549 $x565)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(or (not (net.getX |V1:id| |V0:id|)) (not (= (cache.wait |V1:id|) none))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x583 (= |Y:id| home)))
 (or $x583 (not (net.shwb |X:id| |Y:id|)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x37 (not (net.get |V0:id| |V1:id|))))
 (or (= (__cache.state_ |V0:id|) invalid) $x37)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x594 (not (net.put |V1:id| |V0:id|))))
 (or (= (__cache.state_ |V0:id|) invalid) $x594)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x37 (not (net.get |V0:id| |V1:id|))))
 (or (= (cache.wait |V0:id|) get) $x37)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x594 (not (net.put |V1:id| |V0:id|))))
 (or (= (cache.wait |V0:id|) get) $x594)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x47 (not (net.getX |V0:id| |V1:id|))))
 (or (= (cache.wait |V0:id|) getX) $x47)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x614 (not (net.putX |V1:id| |V0:id|))))
 (or (= (cache.wait |V0:id|) getX) $x614)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x57 (not (net.fack |V0:id| |V1:id|))))
 (let (($x583 (= |V1:id| home)))
 (or $x583 $x57))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (or $x868 dir.head)))
 )
(assert
 (forall ((|X:id| id) )(let (($x912 (not (__invack |X:id|))))
 (or (= (__cache.state_ |X:id|) invalid) $x912)))
 )
(assert
 (forall ((|X:id| id) )(let (($x969 (not (= (__cache.state_ |X:id|) shared))))
 (or $x969 (not (= (cache.wait |X:id|) get)))))
 )
(assert
 (let (($x264 (= (cache.wait real_owner) get)))
 (not $x264)))
(assert
 (let (($x31 (not dir.dirty)))
 (let (($x280 (= dir.hptr real_owner)))
 (or $x280 $x31 dir.pending))))
(assert
 (forall ((|X:id| id) )(let (($x565 (not (net.putX home |X:id|))))
 (let (($x280 (= dir.hptr real_owner)))
 (or $x280 $x565))))
 )
(assert
 (forall ((|X:id| id) )(let (($x653 (= |X:id| real_owner)))
 (or (dir.real |X:id|) $x653 (= (__cache.state_ |X:id|) invalid))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x868 (not (= (__cache.state_ |V0:id|) exclusive))))
 (let (($x68 (dir.shlist |V0:id|)))
 (or $x68 (= |V0:id| requester) $x868))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x42 (not (net.put |V0:id| |V1:id|))))
 (let (($x583 (= |V1:id| home)))
 (let (($x68 (dir.shlist |V1:id|)))
 (or $x68 $x583 $x42)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (let (($x68 (dir.shlist |X:id|)))
 (or $x68 $x868))))
 )
(assert
 (forall ((|X:id| id) )(let (($x68 (dir.shlist |X:id|)))
 (let (($x69 (not $x68)))
 (or $x69 dir.head))))
 )
(assert
 (forall ((|X:id| id) )(let (($x529 (not (net.get |X:id| home))))
 (let (($x68 (dir.shlist |X:id|)))
 (let (($x69 (not $x68)))
 (or $x69 $x529)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x537 (not (net.put home |X:id|))))
 (let (($x68 (dir.shlist |X:id|)))
 (or $x68 $x537))))
 )
(assert
 (forall ((|X:id| id) )(let (($x565 (not (net.putX home |X:id|))))
 (let (($x68 (dir.shlist |X:id|)))
 (or $x68 $x565))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x42 (not (net.put |X:id| |Y:id|))))
 (let (($x68 (dir.shlist |Y:id|)))
 (or $x68 $x42))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x42 (not (net.put |X:id| |Y:id|))))
 (let (($x68 (dir.shlist |Y:id|)))
 (or $x68 $x42 dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x42 (not (net.put |X:id| |Y:id|))))
 (let (($x68 (dir.shlist |Y:id|)))
 (or $x68 $x42 dir.pending))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x969 (not (= (__cache.state_ |V0:id|) shared))))
 (let (($x912 (not (__invack |V0:id|))))
 (or $x912 $x969))))
 )
(assert
 (forall ((|X:id| id) )(let (($x912 (not (__invack |X:id|))))
 (or $x912 (not (__invnet |X:id|)))))
 )
(assert
 (let (($x352 (net.fack requester home)))
 (not $x352)))
(assert
 (forall ((|Y:id| id) )(not (net.get home |Y:id|)))
 )
(assert
 (forall ((|V0:id| id) )(not (net.put dir.hptr |V0:id|)))
 )
(assert
 (forall ((|X:id| id) )(not (net.put home |X:id|)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x594 (not (net.put |V1:id| |V0:id|))))
 (or $x594 (not (rp_net |V0:id|)))))
 )
(assert
 (forall ((|X:id| id) )(not (net.putX home |X:id|)))
 )
(assert
 (forall ((|X:id| id) )(let (($x565 (not (net.putX home |X:id|))))
 (or $x565 dir.head)))
 )
(assert
 (forall ((|X:id| id) )(not (net.putX real_owner |X:id|)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x614 (not (net.putX |Y:id| |X:id|))))
 (or $x614 dir.dirty)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x614 (not (net.putX |Y:id| |X:id|))))
 (or $x614 dir.head)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x594 (not (net.put |Y:id| |X:id|))))
 (or $x594 dir.head)))
 )
(assert
 (forall ((|X:id| id) )(not (net.shwb |X:id| home)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x52 (not (net.putX |X:id| |Y:id|))))
 (or (= real_owner |Y:id|) $x52)))
 )
(assert
 (forall ((|X:id| id) )(let (($x969 (not (= (__cache.state_ |X:id|) shared))))
 (let (($x74 (not (rp_net |X:id|))))
 (or $x74 $x969))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x52 (not (net.putX |V0:id| |V1:id|))))
 (or (= |V0:id| home) $x52)))
 )
(assert
 (forall ((|V0:id| id) )(let (($x969 (not (= (__cache.state_ |V0:id|) shared))))
 (let (($x653 (= |V0:id| real_owner)))
 (or $x653 $x969))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(or (= |V1:id| |V0:id|) (not (net.shwb |V0:id| home)) (not (net.shwb |V1:id| home))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (or (= |X:id| dir.hptr) $x868)))
 )
(assert
 (forall ((|X:id| id) )(let (($x565 (not (net.putX home |X:id|))))
 (or (= |X:id| dir.hptr) $x565)))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (let (($x653 (= |X:id| real_owner)))
 (or $x653 $x868))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x57 (not (net.fack |X:id| |Y:id|))))
 (or (= |X:id| real_owner) $x57)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x47 (not (net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or (= |X:id| requester) $x583 $x47))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x47 (not (net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x47))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x47 (not (net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x47 dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x47 (not (net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x47 dir.head))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x37 (not (net.get |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x37 dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x37 (not (net.get |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x37 dir.head))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x614 (not (net.putX |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x614))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x614 (not (net.putX |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x614 dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x614 (not (net.putX |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x614 dir.head))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x594 (not (net.put |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x594 dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x47 (not (net.getX |X:id| |Y:id|))))
 (let (($x653 (= |Y:id| real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x653 $x47)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x37 (not (net.get |X:id| |Y:id|))))
 (let (($x653 (= |Y:id| real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x653 $x37)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x614 (not (net.putX |Y:id| |X:id|))))
 (let (($x653 (= |Y:id| real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x653 $x614)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x594 (not (net.put |Y:id| |X:id|))))
 (let (($x653 (= |Y:id| real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x653 $x594)))))
 )
(assert
 (__invnet __dst))
(assert
 (not (= __dst home)))
(assert
 (forall ((|V0:id| id) )(= (invnet |V0:id|) (ite (and (= |V0:id| __dst)) false (__invnet |V0:id|))))
 )
(assert
 (forall ((|V0:id| id) )(= (invack |V0:id|) (ite (and (= |V0:id| __dst)) true (__invack |V0:id|))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x1071 (or (= (cache.wait __dst) get) (__cache.invmarked __dst))))
 (let (($x1095 (and (= |V0:id| __dst))))
 (= (cache.invmarked |V0:id|) (ite $x1095 $x1071 (__cache.invmarked |V0:id|))))))
 )
(assert
 (forall ((|V0:id| id) )(let ((?x12 (cache.state_ |V0:id|)))
 (= ?x12 (ite (and (= |V0:id| __dst)) invalid (__cache.state_ |V0:id|)))))
 )
(assert
 (let ((?x113 (cache.state_ @X)))
 (let (($x114 (= ?x113 exclusive)))
 (and $x114 (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))))
(check-sat)
