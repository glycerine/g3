(set-info :status unknown)
(declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-fun cache.state_ (id) cache_state_)
(declare-fun cache.wait (id) wait_type)
(declare-fun home () id)
(declare-fun real_owner () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.invmarked (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun wbnet.wb () Bool)
(declare-fun invnet (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun nakc () Bool)
(assert
 (forall ((|V0:id| id) )(= (cache.state_ |V0:id|) invalid))
 )
(assert
 (forall ((|V0:id| id) )(= (cache.wait |V0:id|) none))
 )
(assert
 (forall ((|V0:id| id) )(not (cache.invmarked |V0:id|)))
 )
(assert
 (not dir.pending))
(assert
 (not dir.dirty))
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(not (net.get |V0:id| |V1:id|)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(not (net.put |V0:id| |V1:id|)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(not (net.getX |V0:id| |V1:id|)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(not (net.putX |V0:id| |V1:id|)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(not (net.fack |V0:id| |V1:id|)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(not (net.shwb |V0:id| |V1:id|)))
 )
(assert
 (not dir.head))
(assert
 (forall ((|V0:id| id) )(not (dir.shlist |V0:id|)))
 )
(assert
 (forall ((|V0:id| id) )(not (rp_net |V0:id|)))
 )
(assert
 (not wbnet.wb))
(assert
 (= real_owner home))
(assert
 (forall ((|V0:id| id) )(not (invnet |V0:id|)))
 )
(assert
 (forall ((|V0:id| id) )(not (invack |V0:id|)))
 )
(assert
 (not nakc))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(check-sat)
