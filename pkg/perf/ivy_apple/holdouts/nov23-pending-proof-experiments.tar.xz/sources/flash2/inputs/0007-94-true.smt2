(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun cache.wait (id) wait_type)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun home () id)
(declare-fun __dir.hptr () id)
(declare-fun __real_owner () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun dir.hptr () id)
(declare-fun real_owner () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun __net.putX (id id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun __dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun __dir.dirty () Bool)
(declare-fun __dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun dir.dirty () Bool)
(declare-fun dir.head () Bool)
(declare-fun dir.real (id) Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun __cache.invmarked (id) Bool)
(declare-fun dir.local_ () Bool)
(declare-fun cache.invmarked (id) Bool)
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let ((?x20 (cache.wait |Y:id|)))
 (let (($x21 (= ?x20 none)))
 (let (($x875 (and (= (__cache.state_ |X:id|) exclusive) (= (cache.wait |X:id|) none) (= (__cache.state_ |Y:id|) exclusive) $x21 (not (= |X:id| |Y:id|)))))
 (not $x875)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (net.put |Y:id| |X:id|)) (not (net.put |Z:id| |X:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (net.get |X:id| |Y:id|)) (not (net.get |X:id| |Z:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (__net.putX |Y:id| |X:id|)) (not (__net.putX |Z:id| |X:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(let (($x98 (= |Y:id| |Z:id|)))
 (or $x98 (not (__net.getX |X:id| |Y:id|)) (not (__net.getX |X:id| |Z:id|)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(or (not (net.get |X:id| |Z:id|)) (not (net.put |Y:id| |X:id|))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) (|Z:id| id) )(or (not (__net.getX |X:id| |Z:id|)) (not (__net.putX |Y:id| |X:id|))))
 )
(assert
 (forall ((|Y:id| id) )(not (__net.getX home |Y:id|)))
 )
(assert
 (let (($x1369 (not __dir.head)))
 (let (($x522 (__dir.shlist __dir.hptr)))
 (or $x522 $x1369))))
(assert
 (forall ((|X:id| id) )(let (($x529 (not (net.get |X:id| home))))
 (let ((?x20 (cache.wait |X:id|)))
 (let (($x530 (= ?x20 get)))
 (or $x530 $x529)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x537 (not (net.put home |X:id|))))
 (let ((?x20 (cache.wait |X:id|)))
 (let (($x530 (= ?x20 get)))
 (or $x530 $x537)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x74 (not (rp_net |X:id|))))
 (let (($x537 (not (net.put home |X:id|))))
 (or $x537 $x74))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (or $x868 (not (= (cache.wait |X:id|) getX)))))
 )
(assert
 (forall ((|X:id| id) )(let ((?x20 (cache.wait |X:id|)))
 (let (($x549 (= ?x20 getX)))
 (or $x549 (not (__net.getX |X:id| home))))))
 )
(assert
 (forall ((|X:id| id) )(let (($x1718 (not (__net.putX home |X:id|))))
 (let ((?x20 (cache.wait |X:id|)))
 (let (($x549 (= ?x20 getX)))
 (or $x549 $x1718)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(or (not (__net.getX |V1:id| |V0:id|)) (not (= (cache.wait |V1:id|) none))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x583 (= |Y:id| home)))
 (or $x583 (not (net.shwb |X:id| |Y:id|)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x37 (not (net.get |V0:id| |V1:id|))))
 (or (= (__cache.state_ |V0:id|) invalid) $x37)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x594 (not (net.put |V1:id| |V0:id|))))
 (or (= (__cache.state_ |V0:id|) invalid) $x594)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x37 (not (net.get |V0:id| |V1:id|))))
 (let ((?x111 (cache.wait |V0:id|)))
 (let (($x599 (= ?x111 get)))
 (or $x599 $x37)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x594 (not (net.put |V1:id| |V0:id|))))
 (let ((?x111 (cache.wait |V0:id|)))
 (let (($x599 (= ?x111 get)))
 (or $x599 $x594)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x1539 (not (__net.getX |V0:id| |V1:id|))))
 (let ((?x111 (cache.wait |V0:id|)))
 (let (($x607 (= ?x111 getX)))
 (or $x607 $x1539)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x1667 (not (__net.putX |V1:id| |V0:id|))))
 (let ((?x111 (cache.wait |V0:id|)))
 (let (($x607 (= ?x111 getX)))
 (or $x607 $x1667)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x57 (not (net.fack |V0:id| |V1:id|))))
 (let (($x583 (= |V1:id| home)))
 (or $x583 $x57))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (or $x868 __dir.head)))
 )
(assert
 (forall ((|X:id| id) )(let (($x88 (invack |X:id|)))
 (let (($x89 (not $x88)))
 (let ((?x879 (__cache.state_ |X:id|)))
 (let (($x913 (= ?x879 invalid)))
 (or $x913 $x89))))))
 )
(assert
 (forall ((|X:id| id) )(let (($x969 (not (= (__cache.state_ |X:id|) shared))))
 (or $x969 (not (= (cache.wait |X:id|) get)))))
 )
(assert
 (not (= (cache.wait __real_owner) get)))
(assert
 (let (($x1466 (not __dir.dirty)))
 (let (($x1132 (= __dir.hptr __real_owner)))
 (or $x1132 $x1466 dir.pending))))
(assert
 (forall ((|X:id| id) )(let (($x1718 (not (__net.putX home |X:id|))))
 (let (($x1132 (= __dir.hptr __real_owner)))
 (or $x1132 $x1718))))
 )
(assert
 (forall ((|X:id| id) )(let ((?x879 (__cache.state_ |X:id|)))
 (let (($x913 (= ?x879 invalid)))
 (let (($x1103 (= |X:id| __real_owner)))
 (let (($x1041 (__dir.real |X:id|)))
 (or $x1041 $x1103 $x913))))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x868 (not (= (__cache.state_ |V0:id|) exclusive))))
 (let (($x662 (= |V0:id| requester)))
 (let (($x663 (__dir.shlist |V0:id|)))
 (or $x663 $x662 $x868)))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x42 (not (net.put |V0:id| |V1:id|))))
 (let (($x583 (= |V1:id| home)))
 (let (($x663 (__dir.shlist |V1:id|)))
 (or $x663 $x583 $x42)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (let (($x663 (__dir.shlist |X:id|)))
 (or $x663 $x868))))
 )
(assert
 (forall ((|X:id| id) )(let (($x663 (__dir.shlist |X:id|)))
 (let (($x676 (not $x663)))
 (or $x676 __dir.head))))
 )
(assert
 (forall ((|X:id| id) )(let (($x529 (not (net.get |X:id| home))))
 (let (($x663 (__dir.shlist |X:id|)))
 (let (($x676 (not $x663)))
 (or $x676 $x529)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x537 (not (net.put home |X:id|))))
 (let (($x663 (__dir.shlist |X:id|)))
 (or $x663 $x537))))
 )
(assert
 (forall ((|X:id| id) )(let (($x1718 (not (__net.putX home |X:id|))))
 (let (($x663 (__dir.shlist |X:id|)))
 (or $x663 $x1718))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x42 (not (net.put |X:id| |Y:id|))))
 (let (($x663 (__dir.shlist |Y:id|)))
 (or $x663 $x42))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x42 (not (net.put |X:id| |Y:id|))))
 (let (($x663 (__dir.shlist |Y:id|)))
 (or $x663 $x42 __dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x42 (not (net.put |X:id| |Y:id|))))
 (let (($x663 (__dir.shlist |Y:id|)))
 (or $x663 $x42 dir.pending))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x969 (not (= (__cache.state_ |V0:id|) shared))))
 (let (($x88 (invack |V0:id|)))
 (let (($x89 (not $x88)))
 (or $x89 $x969)))))
 )
(assert
 (forall ((|X:id| id) )(let (($x84 (not (invnet |X:id|))))
 (let (($x88 (invack |X:id|)))
 (let (($x89 (not $x88)))
 (or $x89 $x84)))))
 )
(assert
 (let (($x352 (net.fack requester home)))
 (not $x352)))
(assert
 (forall ((|Y:id| id) )(not (net.get home |Y:id|)))
 )
(assert
 (forall ((|V0:id| id) )(not (net.put __dir.hptr |V0:id|)))
 )
(assert
 (forall ((|X:id| id) )(not (net.put home |X:id|)))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x594 (not (net.put |V1:id| |V0:id|))))
 (or $x594 (not (rp_net |V0:id|)))))
 )
(assert
 (forall ((|X:id| id) )(not (__net.putX home |X:id|)))
 )
(assert
 (forall ((|X:id| id) )(let (($x1718 (not (__net.putX home |X:id|))))
 (or $x1718 __dir.head)))
 )
(assert
 (forall ((|X:id| id) )(not (__net.putX __real_owner |X:id|)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1667 (not (__net.putX |Y:id| |X:id|))))
 (or $x1667 __dir.dirty)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1667 (not (__net.putX |Y:id| |X:id|))))
 (or $x1667 __dir.head)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x594 (not (net.put |Y:id| |X:id|))))
 (or $x594 __dir.head)))
 )
(assert
 (forall ((|X:id| id) )(not (net.shwb |X:id| home)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(or (= __real_owner |Y:id|) (not (__net.putX |X:id| |Y:id|))))
 )
(assert
 (forall ((|X:id| id) )(let (($x969 (not (= (__cache.state_ |X:id|) shared))))
 (let (($x74 (not (rp_net |X:id|))))
 (or $x74 $x969))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x763 (= |V0:id| home)))
 (or $x763 (not (__net.putX |V0:id| |V1:id|)))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x969 (not (= (__cache.state_ |V0:id|) shared))))
 (let (($x1103 (= |V0:id| __real_owner)))
 (or $x1103 $x969))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(or (= |V1:id| |V0:id|) (not (net.shwb |V0:id| home)) (not (net.shwb |V1:id| home))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (let (($x783 (= |X:id| __dir.hptr)))
 (or $x783 $x868))))
 )
(assert
 (forall ((|X:id| id) )(let (($x1718 (not (__net.putX home |X:id|))))
 (let (($x783 (= |X:id| __dir.hptr)))
 (or $x783 $x1718))))
 )
(assert
 (forall ((|X:id| id) )(let (($x868 (not (= (__cache.state_ |X:id|) exclusive))))
 (let (($x1103 (= |X:id| __real_owner)))
 (or $x1103 $x868))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x57 (not (net.fack |X:id| |Y:id|))))
 (or (= |X:id| __real_owner) $x57)))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1539 (not (__net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or (= |X:id| requester) $x583 $x1539))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1539 (not (__net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1539))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1539 (not (__net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1539 __dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1539 (not (__net.getX |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1539 __dir.head))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x37 (not (net.get |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x37 __dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x37 (not (net.get |X:id| |Y:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x37 __dir.head))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1667 (not (__net.putX |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1667))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1667 (not (__net.putX |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1667 __dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1667 (not (__net.putX |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1667 __dir.head))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x594 (not (net.put |Y:id| |X:id|))))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x594 __dir.dirty))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1539 (not (__net.getX |X:id| |Y:id|))))
 (let (($x1103 (= |Y:id| __real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1103 $x1539)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x37 (not (net.get |X:id| |Y:id|))))
 (let (($x1103 (= |Y:id| __real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1103 $x37)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x1667 (not (__net.putX |Y:id| |X:id|))))
 (let (($x1103 (= |Y:id| __real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1103 $x1667)))))
 )
(assert
 (forall ((|X:id| id) (|Y:id| id) )(let (($x594 (not (net.put |Y:id| |X:id|))))
 (let (($x1103 (= |Y:id| __real_owner)))
 (let (($x583 (= |Y:id| home)))
 (or $x583 $x1103 $x594)))))
 )
(assert
 (__net.getX __src home))
(assert
 (not (= home __src)))
(assert
 (not dir.pending))
(assert
 (not __dir.dirty))
(assert
 (let (($x1369 (not __dir.head)))
 (or $x1369 (= __src __dir.hptr))))
(assert
 (forall ((|X:id| id) )(let (($x859 (= |X:id| __src)))
 (let (($x663 (__dir.shlist |X:id|)))
 (let (($x676 (not $x663)))
 (let (($x1369 (not __dir.head)))
 (or $x1369 $x676 $x859))))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x583 (= |V1:id| home)))
 (let (($x850 (and (= |V0:id| __src) $x583)))
 (= (net.getX |V0:id| |V1:id|) (ite $x850 false (__net.getX |V0:id| |V1:id|))))))
 )
(assert
 dir.dirty)
(assert
 dir.head)
(assert
 (= dir.hptr __src))
(assert
 (forall ((|V0:id| id) )(let (($x859 (= |V0:id| __src)))
 (let (($x654 (dir.real |V0:id|)))
 (= $x654 $x859))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x859 (= |V0:id| __src)))
 (let (($x68 (dir.shlist |V0:id|)))
 (= $x68 $x859))))
 )
(assert
 (forall ((|V0:id| id) (|V1:id| id) )(let (($x1043 (ite (and (= |V0:id| home) (= |V1:id| __src)) true (__net.putX |V0:id| |V1:id|))))
 (= (net.putX |V0:id| |V1:id|) $x1043)))
 )
(assert
 (= real_owner __src))
(assert
 (forall ((|V0:id| id) )(let ((?x12 (cache.state_ |V0:id|)))
 (= ?x12 (ite (and (= |V0:id| home)) invalid (__cache.state_ |V0:id|)))))
 )
(assert
 (forall ((|V0:id| id) )(let (($x1188 (or (and (= (cache.wait home) get) dir.local_) (__cache.invmarked home))))
 (let (($x25 (cache.invmarked |V0:id|)))
 (= $x25 (ite (and (= |V0:id| home)) $x1188 (__cache.invmarked |V0:id|))))))
 )
(assert
 (let ((?x113 (cache.state_ @X)))
 (let (($x114 (= ?x113 exclusive)))
 (and $x114 (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))))
(check-sat)
