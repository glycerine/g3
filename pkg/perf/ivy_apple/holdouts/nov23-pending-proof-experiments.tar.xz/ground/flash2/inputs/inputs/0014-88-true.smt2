(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun __real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun real_owner () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun __net.put (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (cache.wait __real_owner) get)))
(assert
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__net.get __src __dst))
(assert
 (not (= __dst __src)))
(assert
 (let (($x275 (= __dst home)))
 (not $x275)))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (= ?x277 exclusive)))
(assert
 (= real_owner (ite __ts0_a home __real_owner)))
(assert
 (= __ts0_a (not (= __src home))))
(assert
 (let ((?x319 (cache.wait @Y)))
 (let (($x320 (= ?x319 none)))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 none)))
 (and (= (cache.state_ @X) exclusive) $x315 (= (cache.state_ @Y) exclusive) $x320 (not (= @X @Y))))))))
(assert
 (let ((?x312 (cache.state_ @X)))
 (= ?x312 (ite (and (= @X __dst)) shared (__cache.state_ @X)))))
(assert
 (let ((?x317 (cache.state_ @Y)))
 (= ?x317 (ite (and (= @Y __dst)) shared (__cache.state_ @Y)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x353 (not $x272)))
 (let (($x352 (= __dst __real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x352 $x353))))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x353 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x353 dir.head)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x353 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x353 dir.dirty)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester __real_owner) $x187)))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x278 (= ?x277 exclusive)))
 (let (($x359 (not $x278)))
 (let (($x352 (= __dst __real_owner)))
 (or $x352 $x359))))))
(assert
 (let (($x363 (not (= (__cache.state_ @X) exclusive))))
 (let (($x361 (= @X __real_owner)))
 (or $x361 $x363))))
(assert
 (let (($x367 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x365 (= @Y __real_owner)))
 (or $x365 $x367))))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x278 (= ?x277 exclusive)))
 (let (($x359 (not $x278)))
 (or (= __dst dir.hptr) $x359)))))
(assert
 (let (($x363 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x363)))
(assert
 (let (($x367 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x367)))
(assert
 (let (($x376 (not (= (__cache.state_ __dst) shared))))
 (let (($x352 (= __dst __real_owner)))
 (or $x352 $x376))))
(assert
 (let (($x379 (not (= (__cache.state_ @X) shared))))
 (let (($x361 (= @X __real_owner)))
 (or $x361 $x379))))
(assert
 (let (($x382 (not (= (__cache.state_ @Y) shared))))
 (let (($x365 (= @Y __real_owner)))
 (or $x365 $x382))))
(assert
 (let (($x376 (not (= (__cache.state_ __dst) shared))))
 (or (not (rp_net __dst)) $x376)))
(assert
 (let (($x379 (not (= (__cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x379)))
(assert
 (let (($x382 (not (= (__cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x382)))
(assert
 (not (__net.get home __dst)))
(assert
 (let (($x376 (not (= (__cache.state_ __dst) shared))))
 (let (($x396 (not (invack __dst))))
 (or $x396 $x376))))
(assert
 (let (($x379 (not (= (__cache.state_ @X) shared))))
 (let (($x399 (not (invack @X))))
 (or $x399 $x379))))
(assert
 (let (($x382 (not (= (__cache.state_ @Y) shared))))
 (let (($x402 (not (invack @Y))))
 (or $x402 $x382))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x405))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408))))
(assert
 (let (($x412 (not (__net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x410 (not $x58)))
 (or $x410 $x412)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x410 (not $x58)))
 (or $x410 dir.head))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x417))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x419 $x408)))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x421 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x421 $x417)))))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x424 (= ?x277 invalid)))
 (let (($x352 (= __dst __real_owner)))
 (or (dir.real __dst) $x352 $x424)))))
(assert
 (let ((?x344 (__cache.state_ @X)))
 (let (($x427 (= ?x344 invalid)))
 (let (($x361 (= @X __real_owner)))
 (or (dir.real @X) $x361 $x427)))))
(assert
 (let ((?x349 (__cache.state_ @Y)))
 (let (($x430 (= ?x349 invalid)))
 (let (($x365 (= @Y __real_owner)))
 (or (dir.real @Y) $x365 $x430)))))
(assert
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (let (($x145 (= dir.hptr __real_owner)))
 (or (dir.real dir.hptr) $x145 $x433)))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 $x405))))
(assert
 (let (($x142 (not (= (cache.wait __real_owner) get))))
 (let (($x438 (not (= (__cache.state_ __real_owner) shared))))
 (or $x438 $x142))))
(assert
 (let (($x379 (not (= (__cache.state_ @X) shared))))
 (or $x379 (not (= (cache.wait @X) get)))))
(assert
 (let (($x382 (not (= (__cache.state_ @Y) shared))))
 (or $x382 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x396 (not (invack __dst))))
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x424 (= ?x277 invalid)))
 (or $x424 $x396)))))
(assert
 (let (($x399 (not (invack @X))))
 (let ((?x344 (__cache.state_ @X)))
 (let (($x427 (= ?x344 invalid)))
 (or $x427 $x399)))))
(assert
 (let (($x402 (not (invack @Y))))
 (let ((?x349 (__cache.state_ @Y)))
 (let (($x430 (= ?x349 invalid)))
 (or $x430 $x402)))))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x278 (= ?x277 exclusive)))
 (let (($x359 (not $x278)))
 (or $x359 dir.head)))))
(assert
 (let (($x363 (not (= (__cache.state_ @X) exclusive))))
 (or $x363 dir.head)))
(assert
 (let (($x367 (not (= (__cache.state_ @Y) exclusive))))
 (or $x367 dir.head)))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x417 dir.head)))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x454 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x456 (= home home)))
 (or $x456 $x187))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x405)))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x461 (= ?x458 get)))
 (or $x461 $x408)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x353 (not $x272)))
 (let ((?x463 (cache.wait __src)))
 (let (($x464 (= ?x463 get)))
 (or $x464 $x353))))))
(assert
 (let (($x394 (not (__net.get home __dst))))
 (let ((?x466 (cache.wait home)))
 (let (($x467 (= ?x466 get)))
 (or $x467 $x394)))))
(assert
 (let (($x412 (not (__net.get dir.hptr home))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x461 (= ?x458 get)))
 (or $x461 $x412)))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (or $x433 $x408)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x353 (not $x272)))
 (let ((?x471 (__cache.state_ __src)))
 (let (($x472 (= ?x471 invalid)))
 (or $x472 $x353))))))
(assert
 (let (($x394 (not (__net.get home __dst))))
 (let ((?x474 (__cache.state_ home)))
 (let (($x475 (= ?x474 invalid)))
 (or $x475 $x394)))))
(assert
 (let (($x412 (not (__net.get dir.hptr home))))
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (or $x433 $x412)))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x405)))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (let ((?x140 (cache.wait __real_owner)))
 (let (($x478 (= ?x140 getX)))
 (or $x478 $x480)))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (let ((?x314 (cache.wait @X)))
 (let (($x482 (= ?x314 getX)))
 (or $x482 $x484)))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (let ((?x319 (cache.wait @Y)))
 (let (($x486 (= ?x319 getX)))
 (or $x486 $x488)))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x491)))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (let ((?x463 (cache.wait __src)))
 (let (($x493 (= ?x463 getX)))
 (or $x493 $x495)))))
(assert
 (let (($x499 (not (net.getX home home))))
 (let ((?x466 (cache.wait home)))
 (let (($x497 (= ?x466 getX)))
 (or $x497 $x499)))))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x454 (not (= (cache.wait __real_owner) getX)))))
(assert
 (let (($x363 (not (= (__cache.state_ @X) exclusive))))
 (or $x363 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x367 (not (= (__cache.state_ @Y) exclusive))))
 (or $x367 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x417 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x510 (not (= (__cache.state_ __src) exclusive))))
 (or $x510 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x514 (not (= (__cache.state_ home) exclusive))))
 (or $x514 (not (= (cache.wait home) getX)))))
(assert
 (let (($x518 (not (rp_net dir.hptr))))
 (let (($x408 (not (__net.put home dir.hptr))))
 (or $x408 $x518))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x461 (= ?x458 get)))
 (or $x461 $x408)))))
(assert
 (let (($x521 (not (__net.get __src home))))
 (let ((?x463 (cache.wait __src)))
 (let (($x464 (= ?x463 get)))
 (or $x464 $x521)))))
(assert
 (let (($x524 (not (__net.get home home))))
 (let ((?x466 (cache.wait home)))
 (let (($x467 (= ?x466 get)))
 (or $x467 $x524)))))
(assert
 (let (($x412 (not (__net.get dir.hptr home))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x461 (= ?x458 get)))
 (or $x461 $x412)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x408)))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x405)))))
(assert
 (let (($x394 (not (__net.get home __dst))))
 (let (($x352 (= __dst __real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x352 $x394)))))
(assert
 (let (($x412 (not (__net.get dir.hptr home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x412)))))
(assert
 (let (($x521 (not (__net.get __src home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x521)))))
(assert
 (let (($x524 (not (__net.get home home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x524)))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x480)))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x484)))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x488)))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x491)))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x495)))))
(assert
 (let (($x499 (not (net.getX home home))))
 (let (($x526 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x526 $x499)))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x408 dir.dirty))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405 dir.head))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405 dir.dirty))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405))))
(assert
 (let (($x394 (not (__net.get home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x394 dir.head))))
(assert
 (let (($x412 (not (__net.get dir.hptr home))))
 (let (($x456 (= home home)))
 (or $x456 $x412 dir.head))))
(assert
 (let (($x521 (not (__net.get __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x521 dir.head))))
(assert
 (let (($x524 (not (__net.get home home))))
 (let (($x456 (= home home)))
 (or $x456 $x524 dir.head))))
(assert
 (let (($x394 (not (__net.get home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x394 dir.dirty))))
(assert
 (let (($x412 (not (__net.get dir.hptr home))))
 (let (($x456 (= home home)))
 (or $x456 $x412 dir.dirty))))
(assert
 (let (($x521 (not (__net.get __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x521 dir.dirty))))
(assert
 (let (($x524 (not (__net.get home home))))
 (let (($x456 (= home home)))
 (or $x456 $x524 dir.dirty))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (let (($x456 (= home home)))
 (or $x456 $x480 dir.head))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (let (($x456 (= home home)))
 (or $x456 $x484 dir.head))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (let (($x456 (= home home)))
 (or $x456 $x488 dir.head))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (let (($x456 (= home home)))
 (or $x456 $x491 dir.head))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x495 dir.head))))
(assert
 (let (($x499 (not (net.getX home home))))
 (let (($x456 (= home home)))
 (or $x456 $x499 dir.head))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (let (($x456 (= home home)))
 (or $x456 $x480 dir.dirty))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (let (($x456 (= home home)))
 (or $x456 $x484 dir.dirty))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (let (($x456 (= home home)))
 (or $x456 $x488 dir.dirty))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (let (($x456 (= home home)))
 (or $x456 $x491 dir.dirty))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x495 dir.dirty))))
(assert
 (let (($x499 (not (net.getX home home))))
 (let (($x456 (= home home)))
 (or $x456 $x499 dir.dirty))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (let (($x456 (= home home)))
 (or $x456 $x480))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (let (($x456 (= home home)))
 (or $x456 $x484))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (let (($x456 (= home home)))
 (or $x456 $x488))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (let (($x456 (= home home)))
 (or $x456 $x491))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x495))))
(assert
 (let (($x499 (not (net.getX home home))))
 (let (($x456 (= home home)))
 (or $x456 $x499))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (let (($x456 (= home home)))
 (or (= __real_owner requester) $x456 $x480))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (let (($x456 (= home home)))
 (or (= @X requester) $x456 $x484))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (let (($x456 (= home home)))
 (or (= @Y requester) $x456 $x488))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (let (($x456 (= home home)))
 (let (($x421 (= dir.hptr requester)))
 (or $x421 $x456 $x491)))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (let (($x456 (= home home)))
 (or (= __src requester) $x456 $x495))))
(assert
 (let (($x499 (not (net.getX home home))))
 (let (($x456 (= home home)))
 (or (= home requester) $x456 $x499))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 $x417))))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x581 (= __real_owner __real_owner)))
 (or $x581 $x454))))
(assert
 (let (($x510 (not (= (__cache.state_ __src) exclusive))))
 (let (($x583 (= __src __real_owner)))
 (or $x583 $x510))))
(assert
 (let (($x514 (not (= (__cache.state_ home) exclusive))))
 (let (($x526 (= home __real_owner)))
 (or $x526 $x514))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x586 (= dir.hptr dir.hptr)))
 (or $x586 $x405))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x586 (= dir.hptr dir.hptr)))
 (or $x586 $x417))))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x589 (= __real_owner dir.hptr)))
 (or $x589 $x454))))
(assert
 (let (($x510 (not (= (__cache.state_ __src) exclusive))))
 (or (= __src dir.hptr) $x510)))
(assert
 (let (($x514 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x514)))
(assert
 (let (($x596 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 $x596))))
(assert
 (let (($x438 (not (= (__cache.state_ __real_owner) shared))))
 (let (($x581 (= __real_owner __real_owner)))
 (or $x581 $x438))))
(assert
 (let (($x600 (not (= (__cache.state_ __src) shared))))
 (let (($x583 (= __src __real_owner)))
 (or $x583 $x600))))
(assert
 (let (($x603 (not (= (__cache.state_ home) shared))))
 (let (($x526 (= home __real_owner)))
 (or $x526 $x603))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405))))
(assert
 (let (($x596 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x518 (not (rp_net dir.hptr))))
 (or $x518 $x596))))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (let (($x589 (= __real_owner dir.hptr)))
 (or $x589 $x405))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (or $x408 dir.head)))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (or $x405 dir.head)))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (or $x405 dir.dirty)))
(assert
 (not (net.putX __real_owner dir.hptr)))
(assert
 (let (($x405 (not (net.putX home dir.hptr))))
 (or $x405 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x518 (not (rp_net dir.hptr))))
 (let (($x408 (not (__net.put home dir.hptr))))
 (or $x408 $x518))))
(assert
 (not (__net.put home dir.hptr)))
(assert
 (not (__net.put dir.hptr dir.hptr)))
(assert
 (not (__net.get home home)))
(assert
 (let (($x396 (not (invack __dst))))
 (or $x396 (not (invnet __dst)))))
(assert
 (let (($x399 (not (invack @X))))
 (or $x399 (not (invnet @X)))))
(assert
 (let (($x402 (not (invack @Y))))
 (or $x402 (not (invnet @Y)))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408 dir.pending))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x613 dir.pending))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408 dir.dirty))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x613 dir.dirty))))
(assert
 (let (($x408 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x613))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x419 $x613)))))
(assert
 (let (($x596 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x596 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x600 (not (= (__cache.state_ __src) shared))))
 (or $x600 (not (= (cache.wait __src) get)))))
(assert
 (let (($x603 (not (= (__cache.state_ home) shared))))
 (or $x603 (not (= (cache.wait home) get)))))
(assert
 (let (($x510 (not (= (__cache.state_ __src) exclusive))))
 (or $x510 dir.head)))
(assert
 (let (($x514 (not (= (__cache.state_ home) exclusive))))
 (or $x514 dir.head)))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x611)))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (let ((?x140 (cache.wait __real_owner)))
 (let (($x478 (= ?x140 getX)))
 (or $x478 $x480)))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (let ((?x314 (cache.wait @X)))
 (let (($x482 (= ?x314 getX)))
 (or $x482 $x484)))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (let ((?x319 (cache.wait @Y)))
 (let (($x486 (= ?x319 getX)))
 (or $x486 $x488)))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x491)))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (let ((?x463 (cache.wait __src)))
 (let (($x493 (= ?x463 getX)))
 (or $x493 $x495)))))
(assert
 (let (($x499 (not (net.getX home home))))
 (let ((?x466 (cache.wait home)))
 (let (($x497 (= ?x466 getX)))
 (or $x497 $x499)))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x461 (= ?x458 get)))
 (or $x461 $x613)))))
(assert
 (let (($x521 (not (__net.get __src home))))
 (let ((?x463 (cache.wait __src)))
 (let (($x464 (= ?x463 get)))
 (or $x464 $x521)))))
(assert
 (let (($x524 (not (__net.get home home))))
 (let ((?x466 (cache.wait home)))
 (let (($x467 (= ?x466 get)))
 (or $x467 $x524)))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (or $x433 $x613)))))
(assert
 (let (($x521 (not (__net.get __src home))))
 (let ((?x471 (__cache.state_ __src)))
 (let (($x472 (= ?x471 invalid)))
 (or $x472 $x521)))))
(assert
 (let (($x524 (not (__net.get home home))))
 (let ((?x474 (__cache.state_ home)))
 (let (($x475 (= ?x474 invalid)))
 (or $x475 $x524)))))
(assert
 (let (($x480 (not (net.getX __real_owner home))))
 (or $x480 (not (= (cache.wait __real_owner) none)))))
(assert
 (let (($x484 (not (net.getX @X home))))
 (or $x484 (not (= (cache.wait @X) none)))))
(assert
 (let (($x488 (not (net.getX @Y home))))
 (or $x488 (not (= (cache.wait @Y) none)))))
(assert
 (let (($x491 (not (net.getX dir.hptr home))))
 (or $x491 (not (= (cache.wait dir.hptr) none)))))
(assert
 (let (($x495 (not (net.getX __src home))))
 (or $x495 (not (= (cache.wait __src) none)))))
(assert
 (let (($x499 (not (net.getX home home))))
 (or $x499 (not (= (cache.wait home) none)))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr __real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x613)))))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (let (($x581 (= __real_owner __real_owner)))
 (let (($x659 (= __real_owner home)))
 (or $x659 $x581 $x611)))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x613 dir.dirty))))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (let (($x659 (= __real_owner home)))
 (or $x659 $x611 dir.head))))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (let (($x659 (= __real_owner home)))
 (or $x659 $x611 dir.dirty))))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (let (($x659 (= __real_owner home)))
 (or $x659 $x611))))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (let (($x659 (= __real_owner home)))
 (or $x659 $x611))))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (let (($x589 (= __real_owner dir.hptr)))
 (or $x589 $x611))))
(assert
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (or $x613 dir.head)))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (or $x611 dir.head)))
(assert
 (let (($x611 (not (net.putX __real_owner dir.hptr))))
 (or $x611 dir.dirty)))
(assert
 (let (($x518 (not (rp_net dir.hptr))))
 (let (($x613 (not (__net.put dir.hptr dir.hptr))))
 (or $x613 $x518))))
(check-sat)
