(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun __dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun __real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun dir.hptr () id)
(declare-fun real_owner () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun __dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun __dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun dir.dirty () Bool)
(declare-fun dir.head () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun __net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun __dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x56 (not __dir.head)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x56))))
(assert
 (not (= (cache.wait __real_owner) get)))
(assert
 (let (($x144 (not __dir.dirty)))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x144 dir.pending))))
(assert
 (not (net.fack requester home)))
(assert
 (__net.getX __src home))
(assert
 (not (= home __src)))
(assert
 (not dir.pending))
(assert
 (not __dir.dirty))
(assert
 (let (($x56 (not __dir.head)))
 (or $x56 (= __src __dir.hptr))))
(assert
 dir.dirty)
(assert
 dir.head)
(assert
 (= dir.hptr __src))
(assert
 (= real_owner __src))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x320 (cache.state_ @X)))
 (= ?x320 (ite (and (= @X home)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x325 (cache.state_ @Y)))
 (= ?x325 (ite (and (= @Y home)) invalid (__cache.state_ @Y)))))
(assert
 (let (($x58 (__dir.shlist __dir.hptr)))
 (let (($x360 (not $x58)))
 (let (($x56 (not __dir.head)))
 (or $x56 $x360 (= __dir.hptr __src))))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (let (($x364 (= home __real_owner)))
 (let (($x363 (= home home)))
 (or $x363 $x364 $x365))))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (let (($x363 (= home home)))
 (or $x363 $x365 __dir.head)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (let (($x363 (= home home)))
 (or $x363 $x365 __dir.dirty)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (let (($x363 (= home home)))
 (or $x363 $x365)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (let (($x363 (= home home)))
 (or (= __src requester) $x363 $x365)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester __real_owner) $x187)))
(assert
 (let (($x376 (not (= (__cache.state_ @X) exclusive))))
 (let (($x374 (= @X __real_owner)))
 (or $x374 $x376))))
(assert
 (let (($x380 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x378 (= @Y __real_owner)))
 (or $x378 $x380))))
(assert
 (let (($x376 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X __dir.hptr) $x376)))
(assert
 (let (($x380 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y __dir.hptr) $x380)))
(assert
 (let (($x387 (not (= (__cache.state_ @X) shared))))
 (let (($x374 (= @X __real_owner)))
 (or $x374 $x387))))
(assert
 (let (($x390 (not (= (__cache.state_ @Y) shared))))
 (let (($x378 (= @Y __real_owner)))
 (or $x378 $x390))))
(assert
 (let (($x387 (not (= (__cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x387)))
(assert
 (let (($x390 (not (= (__cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x390)))
(assert
 (let (($x387 (not (= (__cache.state_ @X) shared))))
 (let (($x399 (not (invack @X))))
 (or $x399 $x387))))
(assert
 (let (($x390 (not (= (__cache.state_ @Y) shared))))
 (let (($x402 (not (invack @Y))))
 (or $x402 $x390))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x405))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x408))))
(assert
 (let (($x411 (not (net.get __dir.hptr home))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (let (($x360 (not $x58)))
 (or $x360 $x411)))))
(assert
 (let (($x58 (__dir.shlist __dir.hptr)))
 (let (($x360 (not $x58)))
 (or $x360 __dir.head))))
(assert
 (let (($x416 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x416))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let (($x418 (= __dir.hptr home)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x418 $x408)))))
(assert
 (let (($x416 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 (= __dir.hptr requester) $x416))))
(assert
 (let ((?x352 (__cache.state_ @X)))
 (let (($x423 (= ?x352 invalid)))
 (let (($x374 (= @X __real_owner)))
 (or (__dir.real @X) $x374 $x423)))))
(assert
 (let ((?x357 (__cache.state_ @Y)))
 (let (($x426 (= ?x357 invalid)))
 (let (($x378 (= @Y __real_owner)))
 (or (__dir.real @Y) $x378 $x426)))))
(assert
 (let ((?x414 (__cache.state_ __dir.hptr)))
 (let (($x429 (= ?x414 invalid)))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or (__dir.real __dir.hptr) $x145 $x429)))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x405))))
(assert
 (let (($x142 (not (= (cache.wait __real_owner) get))))
 (let (($x434 (not (= (__cache.state_ __real_owner) shared))))
 (or $x434 $x142))))
(assert
 (let (($x387 (not (= (__cache.state_ @X) shared))))
 (or $x387 (not (= (cache.wait @X) get)))))
(assert
 (let (($x390 (not (= (__cache.state_ @Y) shared))))
 (or $x390 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x399 (not (invack @X))))
 (let ((?x352 (__cache.state_ @X)))
 (let (($x423 (= ?x352 invalid)))
 (or $x423 $x399)))))
(assert
 (let (($x402 (not (invack @Y))))
 (let ((?x357 (__cache.state_ @Y)))
 (let (($x426 (= ?x357 invalid)))
 (or $x426 $x402)))))
(assert
 (let (($x376 (not (= (__cache.state_ @X) exclusive))))
 (or $x376 __dir.head)))
(assert
 (let (($x380 (not (= (__cache.state_ @Y) exclusive))))
 (or $x380 __dir.head)))
(assert
 (let (($x416 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (or $x416 __dir.head)))
(assert
 (let (($x448 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x448 __dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x363 (= home home)))
 (or $x363 $x187))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x452 (= ?x451 getX)))
 (or $x452 $x405)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (or (= (cache.wait __src) getX) $x365))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x457 (= ?x451 get)))
 (or $x457 $x408)))))
(assert
 (let (($x411 (not (net.get __dir.hptr home))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x457 (= ?x451 get)))
 (or $x457 $x411)))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let ((?x414 (__cache.state_ __dir.hptr)))
 (let (($x429 (= ?x414 invalid)))
 (or $x429 $x408)))))
(assert
 (let (($x411 (not (net.get __dir.hptr home))))
 (let ((?x414 (__cache.state_ __dir.hptr)))
 (let (($x429 (= ?x414 invalid)))
 (or $x429 $x411)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (or $x365 (not (= (cache.wait __src) none))))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x452 (= ?x451 getX)))
 (or $x452 $x405)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x365 (not $x271)))
 (or (= (cache.wait __src) getX) $x365))))
(assert
 (let (($x376 (not (= (__cache.state_ @X) exclusive))))
 (or $x376 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x380 (not (= (__cache.state_ @Y) exclusive))))
 (or $x380 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x416 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (or $x416 (not (= (cache.wait __dir.hptr) getX)))))
(assert
 (let (($x448 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x448 (not (= (cache.wait __real_owner) getX)))))
(assert
 (let (($x477 (not (rp_net __dir.hptr))))
 (let (($x408 (not (net.put home __dir.hptr))))
 (or $x408 $x477))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x457 (= ?x451 get)))
 (or $x457 $x408)))))
(assert
 (let (($x411 (not (net.get __dir.hptr home))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x457 (= ?x451 get)))
 (or $x457 $x411)))))
(assert
 (not (__net.getX home home)))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let (($x364 (= home __real_owner)))
 (let (($x363 (= home home)))
 (or $x363 $x364 $x408)))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x364 (= home __real_owner)))
 (let (($x363 (= home home)))
 (or $x363 $x364 $x405)))))
(assert
 (let (($x411 (not (net.get __dir.hptr home))))
 (let (($x364 (= home __real_owner)))
 (let (($x363 (= home home)))
 (or $x363 $x364 $x411)))))
(assert
 (let (($x480 (not (__net.getX home home))))
 (let (($x364 (= home __real_owner)))
 (let (($x363 (= home home)))
 (or $x363 $x364 $x480)))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let (($x363 (= home home)))
 (or $x363 $x408 __dir.dirty))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x363 (= home home)))
 (or $x363 $x405 __dir.head))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x363 (= home home)))
 (or $x363 $x405 __dir.dirty))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x363 (= home home)))
 (or $x363 $x405))))
(assert
 (let (($x411 (not (net.get __dir.hptr home))))
 (let (($x363 (= home home)))
 (or $x363 $x411 __dir.head))))
(assert
 (let (($x411 (not (net.get __dir.hptr home))))
 (let (($x363 (= home home)))
 (or $x363 $x411 __dir.dirty))))
(assert
 (let (($x480 (not (__net.getX home home))))
 (let (($x363 (= home home)))
 (or $x363 $x480 __dir.head))))
(assert
 (let (($x480 (not (__net.getX home home))))
 (let (($x363 (= home home)))
 (or $x363 $x480 __dir.dirty))))
(assert
 (let (($x480 (not (__net.getX home home))))
 (let (($x363 (= home home)))
 (or $x363 $x480))))
(assert
 (let (($x480 (not (__net.getX home home))))
 (let (($x363 (= home home)))
 (or (= home requester) $x363 $x480))))
(assert
 (let (($x416 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x416))))
(assert
 (let (($x448 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x497 (= __real_owner __real_owner)))
 (or $x497 $x448))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x499 (= __dir.hptr __dir.hptr)))
 (or $x499 $x405))))
(assert
 (let (($x416 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x499 (= __dir.hptr __dir.hptr)))
 (or $x499 $x416))))
(assert
 (let (($x448 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x502 (= __real_owner __dir.hptr)))
 (or $x502 $x448))))
(assert
 (let (($x505 (not (= (__cache.state_ __dir.hptr) shared))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x505))))
(assert
 (let (($x434 (not (= (__cache.state_ __real_owner) shared))))
 (let (($x497 (= __real_owner __real_owner)))
 (or $x497 $x434))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x363 (= home home)))
 (or $x363 $x405))))
(assert
 (let (($x505 (not (= (__cache.state_ __dir.hptr) shared))))
 (let (($x477 (not (rp_net __dir.hptr))))
 (or $x477 $x505))))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (let (($x502 (= __real_owner __dir.hptr)))
 (or $x502 $x405))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (or $x408 __dir.head)))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (or $x405 __dir.head)))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (or $x405 __dir.dirty)))
(assert
 (not (__net.putX __real_owner __dir.hptr)))
(assert
 (let (($x405 (not (__net.putX home __dir.hptr))))
 (or $x405 __dir.head)))
(assert
 (not (__net.putX home __dir.hptr)))
(assert
 (let (($x477 (not (rp_net __dir.hptr))))
 (let (($x408 (not (net.put home __dir.hptr))))
 (or $x408 $x477))))
(assert
 (not (net.put home __dir.hptr)))
(assert
 (not (net.put __dir.hptr __dir.hptr)))
(assert
 (not (net.get home home)))
(assert
 (let (($x399 (not (invack @X))))
 (or $x399 (not (invnet @X)))))
(assert
 (let (($x402 (not (invack @Y))))
 (or $x402 (not (invnet @Y)))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x408 dir.pending))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x516 dir.pending))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x408 __dir.dirty))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x516 __dir.dirty))))
(assert
 (let (($x408 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x408))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x516))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x418 (= __dir.hptr home)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x418 $x516)))))
(assert
 (let (($x505 (not (= (__cache.state_ __dir.hptr) shared))))
 (or $x505 (not (= (cache.wait __dir.hptr) get)))))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x452 (= ?x451 getX)))
 (or $x452 $x514)))))
(assert
 (let (($x480 (not (__net.getX home home))))
 (let ((?x308 (cache.wait home)))
 (let (($x534 (= ?x308 getX)))
 (or $x534 $x480)))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let ((?x451 (cache.wait __dir.hptr)))
 (let (($x457 (= ?x451 get)))
 (or $x457 $x516)))))
(assert
 (let (($x518 (not (net.get home home))))
 (let ((?x308 (cache.wait home)))
 (let (($x309 (= ?x308 get)))
 (or $x309 $x518)))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let ((?x414 (__cache.state_ __dir.hptr)))
 (let (($x429 (= ?x414 invalid)))
 (or $x429 $x516)))))
(assert
 (let (($x518 (not (net.get home home))))
 (or (= (__cache.state_ home) invalid) $x518)))
(assert
 (let (($x480 (not (__net.getX home home))))
 (or $x480 (not (= (cache.wait home) none)))))
(assert
 (let (($x480 (not (__net.getX home home))))
 (let ((?x308 (cache.wait home)))
 (let (($x534 (= ?x308 getX)))
 (or $x534 $x480)))))
(assert
 (let (($x546 (not (= (__cache.state_ home) exclusive))))
 (or $x546 (not (= (cache.wait home) getX)))))
(assert
 (let (($x518 (not (net.get home home))))
 (let ((?x308 (cache.wait home)))
 (let (($x309 (= ?x308 get)))
 (or $x309 $x518)))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x418 (= __dir.hptr home)))
 (or $x418 $x145 $x516)))))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x497 (= __real_owner __real_owner)))
 (let (($x550 (= __real_owner home)))
 (or $x550 $x497 $x514)))))
(assert
 (let (($x518 (not (net.get home home))))
 (let (($x364 (= home __real_owner)))
 (let (($x363 (= home home)))
 (or $x363 $x364 $x518)))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x418 (= __dir.hptr home)))
 (or $x418 $x516 __dir.dirty))))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x550 (= __real_owner home)))
 (or $x550 $x514 __dir.head))))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x550 (= __real_owner home)))
 (or $x550 $x514 __dir.dirty))))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x550 (= __real_owner home)))
 (or $x550 $x514))))
(assert
 (let (($x518 (not (net.get home home))))
 (let (($x363 (= home home)))
 (or $x363 $x518 __dir.head))))
(assert
 (let (($x518 (not (net.get home home))))
 (let (($x363 (= home home)))
 (or $x363 $x518 __dir.dirty))))
(assert
 (let (($x546 (not (= (__cache.state_ home) exclusive))))
 (let (($x364 (= home __real_owner)))
 (or $x364 $x546))))
(assert
 (let (($x546 (not (= (__cache.state_ home) exclusive))))
 (or (= home __dir.hptr) $x546)))
(assert
 (let (($x563 (not (= (__cache.state_ home) shared))))
 (let (($x364 (= home __real_owner)))
 (or $x364 $x563))))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x550 (= __real_owner home)))
 (or $x550 $x514))))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x502 (= __real_owner __dir.hptr)))
 (or $x502 $x514))))
(assert
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (or $x516 __dir.head)))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (or $x514 __dir.head)))
(assert
 (let (($x514 (not (__net.putX __real_owner __dir.hptr))))
 (or $x514 __dir.dirty)))
(assert
 (let (($x477 (not (rp_net __dir.hptr))))
 (let (($x516 (not (net.put __dir.hptr __dir.hptr))))
 (or $x516 $x477))))
(assert
 (let (($x563 (not (= (__cache.state_ home) shared))))
 (or $x563 (not (= (cache.wait home) get)))))
(assert
 (let (($x546 (not (= (__cache.state_ home) exclusive))))
 (or $x546 __dir.head)))
(check-sat)
