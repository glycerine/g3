(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun __cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.put (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (let (($x271 (= __dst home)))
 (not $x271)))
(assert
 (__net.put __src __dst))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x292 (cache.state_ @X)))
 (= ?x292 (ite (and (= @X __dst)) shared (__cache.state_ @X)))))
(assert
 (let ((?x297 (cache.state_ @Y)))
 (= ?x297 (ite (and (= @Y __dst)) shared (__cache.state_ @Y)))))
(assert
 (let ((?x294 (cache.wait @X)))
 (= ?x294 (ite (and (= @X __dst)) none (__cache.wait @X)))))
(assert
 (let ((?x299 (cache.wait @Y)))
 (= ?x299 (ite (and (= @Y __dst)) none (__cache.wait @Y)))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let (($x338 (= __src home)))
 (or $x338 (= __src real_owner) $x340)))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let (($x338 (= __src home)))
 (or $x338 $x340 dir.dirty)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x347 (not (= (__cache.state_ @X) exclusive))))
 (let (($x345 (= @X real_owner)))
 (or $x345 $x347))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x349 (= @Y real_owner)))
 (or $x349 $x351))))
(assert
 (let (($x347 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x347)))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x351)))
(assert
 (let (($x358 (not (= (__cache.state_ @X) shared))))
 (let (($x345 (= @X real_owner)))
 (or $x345 $x358))))
(assert
 (let (($x361 (not (= (__cache.state_ @Y) shared))))
 (let (($x349 (= @Y real_owner)))
 (or $x349 $x361))))
(assert
 (let (($x358 (not (= (__cache.state_ @X) shared))))
 (let (($x364 (not (rp_net @X))))
 (or $x364 $x358))))
(assert
 (let (($x361 (not (= (__cache.state_ @Y) shared))))
 (let (($x367 (not (rp_net @Y))))
 (or $x367 $x361))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (or $x340 dir.head))))
(assert
 (let (($x371 (not (rp_net __dst))))
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (or $x340 $x371)))))
(assert
 (not (__net.put home __dst)))
(assert
 (not (__net.put dir.hptr __dst)))
(assert
 (let (($x358 (not (= (__cache.state_ @X) shared))))
 (let (($x378 (not (invack @X))))
 (or $x378 $x358))))
(assert
 (let (($x361 (not (= (__cache.state_ @Y) shared))))
 (let (($x381 (not (invack @Y))))
 (or $x381 $x361))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x340 dir.pending)))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x374 dir.pending))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x376 dir.pending))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x340 dir.dirty)))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x374 dir.dirty))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x376 dir.dirty))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x340)))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x374))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x376))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x394))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x397))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x400))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x374))))
(assert
 (let (($x404 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x402 (not $x58)))
 (or $x402 $x404)))))
(assert
 (let (($x408 (not (net.get __dst home))))
 (let (($x383 (dir.shlist __dst)))
 (let (($x406 (not $x383)))
 (or $x406 $x408)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x402 (not $x58)))
 (or $x402 dir.head))))
(assert
 (let (($x383 (dir.shlist __dst)))
 (let (($x406 (not $x383)))
 (or $x406 dir.head))))
(assert
 (let (($x347 (not (= (__cache.state_ @X) exclusive))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x347))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x351))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let (($x271 (= __dst home)))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x271 $x340))))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let (($x271 (= __dst home)))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x271 $x374)))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let (($x271 (= __dst home)))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x271 $x376)))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x419 $x400)))))
(assert
 (let (($x347 (not (= (__cache.state_ @X) exclusive))))
 (let (($x421 (= @X requester)))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x421 $x347)))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x423 (= @Y requester)))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x423 $x351)))))
(assert
 (let ((?x324 (__cache.state_ @X)))
 (let (($x426 (= ?x324 invalid)))
 (let (($x345 (= @X real_owner)))
 (or (dir.real @X) $x345 $x426)))))
(assert
 (let ((?x329 (__cache.state_ @Y)))
 (let (($x429 (= ?x329 invalid)))
 (let (($x349 (= @Y real_owner)))
 (or (dir.real @Y) $x349 $x429)))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x394))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x397))))
(assert
 (let (($x358 (not (= (__cache.state_ @X) shared))))
 (or $x358 (not (= (__cache.wait @X) get)))))
(assert
 (let (($x361 (not (= (__cache.state_ @Y) shared))))
 (or $x361 (not (= (__cache.wait @Y) get)))))
(assert
 (let (($x378 (not (invack @X))))
 (let ((?x324 (__cache.state_ @X)))
 (let (($x426 (= ?x324 invalid)))
 (or $x426 $x378)))))
(assert
 (let (($x381 (not (invack @Y))))
 (let ((?x329 (__cache.state_ @Y)))
 (let (($x429 (= ?x329 invalid)))
 (or $x429 $x381)))))
(assert
 (let (($x347 (not (= (__cache.state_ @X) exclusive))))
 (or $x347 dir.head)))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) exclusive))))
 (or $x351 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x443 (= home home)))
 (or $x443 $x187))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x446 (= ?x445 getX)))
 (or $x446 $x394)))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x449 (= ?x448 getX)))
 (or $x449 $x397)))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x451 (= ?x448 get)))
 (or $x451 $x340))))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x451 (= ?x448 get)))
 (or $x451 $x374)))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x451 (= ?x448 get)))
 (or $x451 $x376)))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x455 (= ?x445 get)))
 (or $x455 $x400)))))
(assert
 (let (($x404 (not (net.get dir.hptr home))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x455 (= ?x445 get)))
 (or $x455 $x404)))))
(assert
 (let (($x408 (not (net.get __dst home))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x451 (= ?x448 get)))
 (or $x451 $x408)))))
(assert
 (let (($x274 (__net.put __src __dst)))
 (let (($x340 (not $x274)))
 (let ((?x459 (__cache.state_ __dst)))
 (let (($x460 (= ?x459 invalid)))
 (or $x460 $x340))))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let ((?x459 (__cache.state_ __dst)))
 (let (($x460 (= ?x459 invalid)))
 (or $x460 $x374)))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let ((?x459 (__cache.state_ __dst)))
 (let (($x460 (= ?x459 invalid)))
 (or $x460 $x376)))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let ((?x464 (__cache.state_ dir.hptr)))
 (let (($x465 (= ?x464 invalid)))
 (or $x465 $x400)))))
(assert
 (let (($x404 (not (net.get dir.hptr home))))
 (let ((?x464 (__cache.state_ dir.hptr)))
 (let (($x465 (= ?x464 invalid)))
 (or $x465 $x404)))))
(assert
 (let (($x408 (not (net.get __dst home))))
 (let ((?x459 (__cache.state_ __dst)))
 (let (($x460 (= ?x459 invalid)))
 (or $x460 $x408)))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x446 (= ?x445 getX)))
 (or $x446 $x394)))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x449 (= ?x448 getX)))
 (or $x449 $x397)))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x469 (= ?x140 getX)))
 (or $x469 $x471)))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (let ((?x332 (__cache.wait @X)))
 (let (($x473 (= ?x332 getX)))
 (or $x473 $x475)))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (let ((?x335 (__cache.wait @Y)))
 (let (($x477 (= ?x335 getX)))
 (or $x477 $x479)))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x446 (= ?x445 getX)))
 (or $x446 $x482)))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x449 (= ?x448 getX)))
 (or $x449 $x485)))))
(assert
 (let (($x347 (not (= (__cache.state_ @X) exclusive))))
 (or $x347 (not (= (__cache.wait @X) getX)))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) exclusive))))
 (or $x351 (not (= (__cache.wait @Y) getX)))))
(assert
 (let (($x492 (not (= (__cache.state_ __dst) exclusive))))
 (or $x492 (not (= (__cache.wait __dst) getX)))))
(assert
 (let (($x496 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x496 (not (= (__cache.wait dir.hptr) getX)))))
(assert
 (let (($x364 (not (rp_net @X))))
 (let (($x500 (not (__net.put home @X))))
 (or $x500 $x364))))
(assert
 (let (($x367 (not (rp_net @Y))))
 (let (($x503 (not (__net.put home @Y))))
 (or $x503 $x367))))
(assert
 (let (($x371 (not (rp_net __dst))))
 (let (($x374 (not (__net.put home __dst))))
 (or $x374 $x371))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x507)))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let ((?x332 (__cache.wait @X)))
 (let (($x433 (= ?x332 get)))
 (or $x433 $x500)))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let ((?x335 (__cache.wait @Y)))
 (let (($x436 (= ?x335 get)))
 (or $x436 $x503)))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x455 (= ?x445 get)))
 (or $x455 $x400)))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x451 (= ?x448 get)))
 (or $x451 $x374)))))
(assert
 (let (($x404 (not (net.get dir.hptr home))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x455 (= ?x445 get)))
 (or $x455 $x404)))))
(assert
 (let (($x408 (not (net.get __dst home))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x451 (= ?x448 get)))
 (or $x451 $x408)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x374)))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x376)))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x400)))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x500)))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x503)))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x507)))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x394)))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x397)))))
(assert
 (let (($x404 (not (net.get dir.hptr home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x404)))))
(assert
 (let (($x408 (not (net.get __dst home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x408)))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x471)))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x475)))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x479)))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x482)))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x485)))))
(assert
 (let (($x512 (not (net.getX home home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x512)))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (let (($x443 (= home home)))
 (or $x443 $x374 dir.dirty))))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x376 dir.dirty))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let (($x443 (= home home)))
 (or $x443 $x400 dir.dirty))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let (($x443 (= home home)))
 (or $x443 $x500 dir.dirty))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let (($x443 (= home home)))
 (or $x443 $x503 dir.dirty))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let (($x443 (= home home)))
 (or $x443 $x507 dir.dirty))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x443 (= home home)))
 (or $x443 $x394 dir.head))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x443 (= home home)))
 (or $x443 $x397 dir.head))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x443 (= home home)))
 (or $x443 $x394 dir.dirty))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x443 (= home home)))
 (or $x443 $x397 dir.dirty))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x443 (= home home)))
 (or $x443 $x394))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x443 (= home home)))
 (or $x443 $x397))))
(assert
 (let (($x404 (not (net.get dir.hptr home))))
 (let (($x443 (= home home)))
 (or $x443 $x404 dir.head))))
(assert
 (let (($x408 (not (net.get __dst home))))
 (let (($x443 (= home home)))
 (or $x443 $x408 dir.head))))
(assert
 (let (($x404 (not (net.get dir.hptr home))))
 (let (($x443 (= home home)))
 (or $x443 $x404 dir.dirty))))
(assert
 (let (($x408 (not (net.get __dst home))))
 (let (($x443 (= home home)))
 (or $x443 $x408 dir.dirty))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (let (($x443 (= home home)))
 (or $x443 $x471 dir.head))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (let (($x443 (= home home)))
 (or $x443 $x475 dir.head))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (let (($x443 (= home home)))
 (or $x443 $x479 dir.head))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (let (($x443 (= home home)))
 (or $x443 $x482 dir.head))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (let (($x443 (= home home)))
 (or $x443 $x485 dir.head))))
(assert
 (let (($x512 (not (net.getX home home))))
 (let (($x443 (= home home)))
 (or $x443 $x512 dir.head))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (let (($x443 (= home home)))
 (or $x443 $x471 dir.dirty))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (let (($x443 (= home home)))
 (or $x443 $x475 dir.dirty))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (let (($x443 (= home home)))
 (or $x443 $x479 dir.dirty))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (let (($x443 (= home home)))
 (or $x443 $x482 dir.dirty))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (let (($x443 (= home home)))
 (or $x443 $x485 dir.dirty))))
(assert
 (let (($x512 (not (net.getX home home))))
 (let (($x443 (= home home)))
 (or $x443 $x512 dir.dirty))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (let (($x443 (= home home)))
 (or $x443 $x471))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (let (($x443 (= home home)))
 (or $x443 $x475))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (let (($x443 (= home home)))
 (or $x443 $x479))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (let (($x443 (= home home)))
 (or $x443 $x482))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (let (($x443 (= home home)))
 (or $x443 $x485))))
(assert
 (let (($x512 (not (net.getX home home))))
 (let (($x443 (= home home)))
 (or $x443 $x512))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (let (($x443 (= home home)))
 (let (($x564 (= real_owner requester)))
 (or $x564 $x443 $x471)))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (let (($x443 (= home home)))
 (let (($x421 (= @X requester)))
 (or $x421 $x443 $x475)))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (let (($x443 (= home home)))
 (let (($x423 (= @Y requester)))
 (or $x423 $x443 $x479)))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (let (($x443 (= home home)))
 (let (($x568 (= dir.hptr requester)))
 (or $x568 $x443 $x482)))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (let (($x443 (= home home)))
 (let (($x570 (= __dst requester)))
 (or $x570 $x443 $x485)))))
(assert
 (let (($x512 (not (net.getX home home))))
 (let (($x443 (= home home)))
 (let (($x572 (= home requester)))
 (or $x572 $x443 $x512)))))
(assert
 (let (($x492 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x574 (= __dst real_owner)))
 (or $x574 $x492))))
(assert
 (let (($x496 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x496))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x577 (= dir.hptr dir.hptr)))
 (or $x577 $x394))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x579 (= __dst dir.hptr)))
 (or $x579 $x397))))
(assert
 (let (($x492 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x579 (= __dst dir.hptr)))
 (or $x579 $x492))))
(assert
 (let (($x496 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x577 (= dir.hptr dir.hptr)))
 (or $x577 $x496))))
(assert
 (let (($x584 (not (= (__cache.state_ __dst) shared))))
 (let (($x574 (= __dst real_owner)))
 (or $x574 $x584))))
(assert
 (let (($x587 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x587))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x443 (= home home)))
 (or $x443 $x394))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x443 (= home home)))
 (or $x443 $x397))))
(assert
 (let (($x584 (not (= (__cache.state_ __dst) shared))))
 (let (($x371 (not (rp_net __dst))))
 (or $x371 $x584))))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (let (($x590 (= real_owner dir.hptr)))
 (or $x590 $x394))))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (let (($x592 (= real_owner __dst)))
 (or $x592 $x397))))
(assert
 (let (($x374 (not (__net.put home __dst))))
 (or $x374 dir.head)))
(assert
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (or $x376 dir.head)))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (or $x400 dir.head)))
(assert
 (let (($x500 (not (__net.put home @X))))
 (or $x500 dir.head)))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (or $x503 dir.head)))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (or $x507 dir.head)))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (or $x394 dir.head)))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (or $x397 dir.head)))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (or $x394 dir.dirty)))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (or $x397 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner __dst)))
(assert
 (let (($x394 (not (net.putX home dir.hptr))))
 (or $x394 dir.head)))
(assert
 (let (($x397 (not (net.putX home __dst))))
 (or $x397 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home __dst)))
(assert
 (let (($x371 (not (rp_net __dst))))
 (let (($x374 (not (__net.put home __dst))))
 (or $x374 $x371))))
(assert
 (let (($x371 (not (rp_net __dst))))
 (let (($x376 (not (__net.put dir.hptr __dst))))
 (or $x376 $x371))))
(assert
 (let (($x610 (not (rp_net dir.hptr))))
 (let (($x400 (not (__net.put home dir.hptr))))
 (or $x400 $x610))))
(assert
 (let (($x364 (not (rp_net @X))))
 (let (($x500 (not (__net.put home @X))))
 (or $x500 $x364))))
(assert
 (let (($x367 (not (rp_net @Y))))
 (let (($x503 (not (__net.put home @Y))))
 (or $x503 $x367))))
(assert
 (let (($x613 (not (rp_net real_owner))))
 (let (($x507 (not (__net.put home real_owner))))
 (or $x507 $x613))))
(assert
 (not (__net.put home dir.hptr)))
(assert
 (not (__net.put home @X)))
(assert
 (not (__net.put home @Y)))
(assert
 (not (__net.put home real_owner)))
(assert
 (not (__net.put dir.hptr dir.hptr)))
(assert
 (not (__net.put dir.hptr @X)))
(assert
 (not (__net.put dir.hptr @Y)))
(assert
 (not (__net.put dir.hptr real_owner)))
(assert
 (not (net.get home home)))
(assert
 (let (($x378 (not (invack @X))))
 (or $x378 (not (invnet @X)))))
(assert
 (let (($x381 (not (invack @Y))))
 (or $x381 (not (invnet @Y)))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x400 dir.pending))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x500 dir.pending))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x503 dir.pending))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x507 dir.pending))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x616 dir.pending))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x618 dir.pending))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x620 dir.pending))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x622 dir.pending))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x400 dir.dirty))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x500 dir.dirty))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x503 dir.dirty))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x507 dir.dirty))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x616 dir.dirty))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x618 dir.dirty))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x620 dir.dirty))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x622 dir.dirty))))
(assert
 (let (($x400 (not (__net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x400))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x500))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x503))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x507))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x616))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x618))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x620))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x622))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x500))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x503))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x507))))
(assert
 (let (($x624 (not (net.get home home))))
 (let (($x655 (dir.shlist home)))
 (let (($x656 (not $x655)))
 (or $x656 $x624)))))
(assert
 (or (not (dir.shlist @X)) dir.head))
(assert
 (or (not (dir.shlist @Y)) dir.head))
(assert
 (or (not (dir.shlist real_owner)) dir.head))
(assert
 (let (($x655 (dir.shlist home)))
 (let (($x656 (not $x655)))
 (or $x656 dir.head))))
(assert
 (let (($x492 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x492))))
(assert
 (let (($x496 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x496))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let (($x667 (= @X home)))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x667 $x500)))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let (($x669 (= @Y home)))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x669 $x503)))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let (($x671 (= real_owner home)))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x671 $x507)))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x419 $x616)))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let (($x667 (= @X home)))
 (let (($x412 (dir.shlist @X)))
 (or $x412 $x667 $x618)))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let (($x669 (= @Y home)))
 (let (($x414 (dir.shlist @Y)))
 (or $x414 $x669 $x620)))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let (($x671 (= real_owner home)))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x671 $x622)))))
(assert
 (let (($x492 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x570 (= __dst requester)))
 (let (($x383 (dir.shlist __dst)))
 (or $x383 $x570 $x492)))))
(assert
 (let (($x496 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x568 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x568 $x496)))))
(assert
 (let (($x584 (not (= (__cache.state_ __dst) shared))))
 (or $x584 (not (= (__cache.wait __dst) get)))))
(assert
 (let (($x587 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x587 (not (= (__cache.wait dir.hptr) get)))))
(assert
 (let (($x492 (not (= (__cache.state_ __dst) exclusive))))
 (or $x492 dir.head)))
(assert
 (let (($x496 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x496 dir.head)))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x446 (= ?x445 getX)))
 (or $x446 $x605)))))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x449 (= ?x448 getX)))
 (or $x449 $x607)))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x469 (= ?x140 getX)))
 (or $x469 $x471)))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (let ((?x332 (__cache.wait @X)))
 (let (($x473 (= ?x332 getX)))
 (or $x473 $x475)))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (let ((?x335 (__cache.wait @Y)))
 (let (($x477 (= ?x335 getX)))
 (or $x477 $x479)))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x446 (= ?x445 getX)))
 (or $x446 $x482)))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (let ((?x448 (__cache.wait __dst)))
 (let (($x449 (= ?x448 getX)))
 (or $x449 $x485)))))
(assert
 (let (($x512 (not (net.getX home home))))
 (let ((?x687 (__cache.wait home)))
 (let (($x688 (= ?x687 getX)))
 (or $x688 $x512)))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let ((?x332 (__cache.wait @X)))
 (let (($x433 (= ?x332 get)))
 (or $x433 $x500)))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let ((?x335 (__cache.wait @Y)))
 (let (($x436 (= ?x335 get)))
 (or $x436 $x503)))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x507)))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let ((?x445 (__cache.wait dir.hptr)))
 (let (($x455 (= ?x445 get)))
 (or $x455 $x616)))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let ((?x332 (__cache.wait @X)))
 (let (($x433 (= ?x332 get)))
 (or $x433 $x618)))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let ((?x335 (__cache.wait @Y)))
 (let (($x436 (= ?x335 get)))
 (or $x436 $x620)))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x622)))))
(assert
 (let (($x624 (not (net.get home home))))
 (let ((?x687 (__cache.wait home)))
 (let (($x694 (= ?x687 get)))
 (or $x694 $x624)))))
(assert
 (let (($x500 (not (__net.put home @X))))
 (let ((?x324 (__cache.state_ @X)))
 (let (($x426 (= ?x324 invalid)))
 (or $x426 $x500)))))
(assert
 (let (($x503 (not (__net.put home @Y))))
 (let ((?x329 (__cache.state_ @Y)))
 (let (($x429 (= ?x329 invalid)))
 (or $x429 $x503)))))
(assert
 (let (($x507 (not (__net.put home real_owner))))
 (let ((?x698 (__cache.state_ real_owner)))
 (let (($x699 (= ?x698 invalid)))
 (or $x699 $x507)))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let ((?x464 (__cache.state_ dir.hptr)))
 (let (($x465 (= ?x464 invalid)))
 (or $x465 $x616)))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let ((?x324 (__cache.state_ @X)))
 (let (($x426 (= ?x324 invalid)))
 (or $x426 $x618)))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let ((?x329 (__cache.state_ @Y)))
 (let (($x429 (= ?x329 invalid)))
 (or $x429 $x620)))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let ((?x698 (__cache.state_ real_owner)))
 (let (($x699 (= ?x698 invalid)))
 (or $x699 $x622)))))
(assert
 (let (($x624 (not (net.get home home))))
 (let ((?x705 (__cache.state_ home)))
 (let (($x706 (= ?x705 invalid)))
 (or $x706 $x624)))))
(assert
 (let (($x471 (not (net.getX real_owner home))))
 (or $x471 (not (= (__cache.wait real_owner) none)))))
(assert
 (let (($x475 (not (net.getX @X home))))
 (or $x475 (not (= (__cache.wait @X) none)))))
(assert
 (let (($x479 (not (net.getX @Y home))))
 (or $x479 (not (= (__cache.wait @Y) none)))))
(assert
 (let (($x482 (not (net.getX dir.hptr home))))
 (or $x482 (not (= (__cache.wait dir.hptr) none)))))
(assert
 (let (($x485 (not (net.getX __dst home))))
 (or $x485 (not (= (__cache.wait __dst) none)))))
(assert
 (let (($x512 (not (net.getX home home))))
 (or $x512 (not (= (__cache.wait home) none)))))
(assert
 (let (($x512 (not (net.getX home home))))
 (let ((?x687 (__cache.wait home)))
 (let (($x688 (= ?x687 getX)))
 (or $x688 $x512)))))
(assert
 (let (($x727 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x727 (not (= (__cache.wait real_owner) getX)))))
(assert
 (let (($x731 (not (= (__cache.state_ home) exclusive))))
 (or $x731 (not (= (__cache.wait home) getX)))))
(assert
 (let (($x610 (not (rp_net dir.hptr))))
 (let (($x400 (not (__net.put home dir.hptr))))
 (or $x400 $x610))))
(assert
 (let (($x613 (not (rp_net real_owner))))
 (let (($x507 (not (__net.put home real_owner))))
 (or $x507 $x613))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let ((?x687 (__cache.wait home)))
 (let (($x694 (= ?x687 get)))
 (or $x694 $x735)))))
(assert
 (let (($x624 (not (net.get home home))))
 (let ((?x687 (__cache.wait home)))
 (let (($x694 (= ?x687 get)))
 (or $x694 $x624)))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x616)))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x618)))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x620)))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x622)))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x735)))))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (let (($x742 (= real_owner real_owner)))
 (let (($x671 (= real_owner home)))
 (or $x671 $x742 $x605)))))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (let (($x742 (= real_owner real_owner)))
 (let (($x671 (= real_owner home)))
 (or $x671 $x742 $x607)))))
(assert
 (let (($x624 (not (net.get home home))))
 (let (($x513 (= home real_owner)))
 (let (($x443 (= home home)))
 (or $x443 $x513 $x624)))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x616 dir.dirty))))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x618 dir.dirty))))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x620 dir.dirty))))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x622 dir.dirty))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let (($x443 (= home home)))
 (or $x443 $x735 dir.dirty))))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x605 dir.head))))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x607 dir.head))))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x605 dir.dirty))))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x607 dir.dirty))))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x605))))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x607))))
(assert
 (let (($x624 (not (net.get home home))))
 (let (($x443 (= home home)))
 (or $x443 $x624 dir.head))))
(assert
 (let (($x624 (not (net.get home home))))
 (let (($x443 (= home home)))
 (or $x443 $x624 dir.dirty))))
(assert
 (let (($x727 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x742 (= real_owner real_owner)))
 (or $x742 $x727))))
(assert
 (let (($x731 (not (= (__cache.state_ home) exclusive))))
 (let (($x513 (= home real_owner)))
 (or $x513 $x731))))
(assert
 (let (($x727 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x590 (= real_owner dir.hptr)))
 (or $x590 $x727))))
(assert
 (let (($x731 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x731)))
(assert
 (let (($x765 (not (= (__cache.state_ real_owner) shared))))
 (let (($x742 (= real_owner real_owner)))
 (or $x742 $x765))))
(assert
 (let (($x768 (not (= (__cache.state_ home) shared))))
 (let (($x513 (= home real_owner)))
 (or $x513 $x768))))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x605))))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (let (($x671 (= real_owner home)))
 (or $x671 $x607))))
(assert
 (let (($x587 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x610 (not (rp_net dir.hptr))))
 (or $x610 $x587))))
(assert
 (let (($x765 (not (= (__cache.state_ real_owner) shared))))
 (let (($x613 (not (rp_net real_owner))))
 (or $x613 $x765))))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (let (($x590 (= real_owner dir.hptr)))
 (or $x590 $x605))))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (let (($x592 (= real_owner __dst)))
 (or $x592 $x607))))
(assert
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (or $x616 dir.head)))
(assert
 (let (($x618 (not (__net.put dir.hptr @X))))
 (or $x618 dir.head)))
(assert
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (or $x620 dir.head)))
(assert
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (or $x622 dir.head)))
(assert
 (let (($x735 (not (__net.put home home))))
 (or $x735 dir.head)))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (or $x605 dir.head)))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (or $x607 dir.head)))
(assert
 (let (($x605 (not (net.putX real_owner dir.hptr))))
 (or $x605 dir.dirty)))
(assert
 (let (($x607 (not (net.putX real_owner __dst))))
 (or $x607 dir.dirty)))
(assert
 (let (($x610 (not (rp_net dir.hptr))))
 (let (($x616 (not (__net.put dir.hptr dir.hptr))))
 (or $x616 $x610))))
(assert
 (let (($x364 (not (rp_net @X))))
 (let (($x618 (not (__net.put dir.hptr @X))))
 (or $x618 $x364))))
(assert
 (let (($x367 (not (rp_net @Y))))
 (let (($x620 (not (__net.put dir.hptr @Y))))
 (or $x620 $x367))))
(assert
 (let (($x613 (not (rp_net real_owner))))
 (let (($x622 (not (__net.put dir.hptr real_owner))))
 (or $x622 $x613))))
(assert
 (let (($x788 (not (rp_net home))))
 (let (($x735 (not (__net.put home home))))
 (or $x735 $x788))))
(assert
 (not (__net.put home home)))
(assert
 (not (__net.put dir.hptr home)))
(assert
 (let (($x735 (not (__net.put home home))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x735 dir.pending))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x791 dir.pending))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x735 dir.dirty))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x791 dir.dirty))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x735))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x791))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x735))))
(assert
 (let (($x727 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x727))))
(assert
 (let (($x731 (not (= (__cache.state_ home) exclusive))))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x731))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let (($x443 (= home home)))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x443 $x735)))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let (($x443 (= home home)))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x443 $x791)))))
(assert
 (let (($x727 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x564 (= real_owner requester)))
 (let (($x634 (dir.shlist real_owner)))
 (or $x634 $x564 $x727)))))
(assert
 (let (($x731 (not (= (__cache.state_ home) exclusive))))
 (let (($x572 (= home requester)))
 (let (($x655 (dir.shlist home)))
 (or $x655 $x572 $x731)))))
(assert
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (let (($x142 (not $x141)))
 (let (($x765 (not (= (__cache.state_ real_owner) shared))))
 (or $x765 $x142))))))
(assert
 (let (($x768 (not (= (__cache.state_ home) shared))))
 (or $x768 (not (= (__cache.wait home) get)))))
(assert
 (let (($x727 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x727 dir.head)))
(assert
 (let (($x731 (not (= (__cache.state_ home) exclusive))))
 (or $x731 dir.head)))
(assert
 (let (($x735 (not (__net.put home home))))
 (let ((?x687 (__cache.wait home)))
 (let (($x694 (= ?x687 get)))
 (or $x694 $x735)))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let ((?x687 (__cache.wait home)))
 (let (($x694 (= ?x687 get)))
 (or $x694 $x791)))))
(assert
 (let (($x735 (not (__net.put home home))))
 (let ((?x705 (__cache.state_ home)))
 (let (($x706 (= ?x705 invalid)))
 (or $x706 $x735)))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let ((?x705 (__cache.state_ home)))
 (let (($x706 (= ?x705 invalid)))
 (or $x706 $x791)))))
(assert
 (let (($x788 (not (rp_net home))))
 (let (($x735 (not (__net.put home home))))
 (or $x735 $x788))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x791)))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x791 dir.dirty))))
(assert
 (let (($x768 (not (= (__cache.state_ home) shared))))
 (let (($x788 (not (rp_net home))))
 (or $x788 $x768))))
(assert
 (let (($x791 (not (__net.put dir.hptr home))))
 (or $x791 dir.head)))
(assert
 (let (($x788 (not (rp_net home))))
 (let (($x791 (not (__net.put dir.hptr home))))
 (or $x791 $x788))))
(check-sat)
