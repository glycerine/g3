(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun __dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun __dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __wbnet.wb () Bool)
(declare-fun wbnet.wb () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun dir.head () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 (not __dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not __dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 __wbnet.wb)
(assert
 (not wbnet.wb))
(assert
 (not dir.dirty))
(assert
 (not dir.head))
(assert
 (let (($x327 (not (= (cache.state_ @X) exclusive))))
 (let (($x367 (not (net.getX home @Y))))
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x355 (= @Y @Z)))
 (let (($x368 (and (or $x355 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x355 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x355 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x355 $x354 $x346) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x346 (not (net.putX @Y @X))) $x367 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x327 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x368)))))))))
(assert
 (let (($x340 (dir.shlist dir.hptr)))
 (not $x340)))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x390 (= @Y real_owner)))
 (let (($x306 (= @Y home)))
 (or $x306 $x390 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x393 (= @Z real_owner)))
 (let (($x392 (= @Z home)))
 (or $x392 $x393 $x364)))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x333)))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let (($x398 (= @V1 real_owner)))
 (let (($x281 (= @V1 home)))
 (or $x281 $x398 $x295)))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x390 (= @Y real_owner)))
 (let (($x306 (= @Y home)))
 (or $x306 $x390 $x343)))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x393 (= @Z real_owner)))
 (let (($x392 (= @Z home)))
 (or $x392 $x393 $x358)))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x318)))))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (let (($x398 (= @V1 real_owner)))
 (let (($x281 (= @V1 home)))
 (or $x281 $x398 $x289)))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let (($x390 (= @Y real_owner)))
 (let (($x306 (= @Y home)))
 (or $x306 $x390 $x361)))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let (($x393 (= @Z real_owner)))
 (let (($x392 (= @Z home)))
 (or $x392 $x393 $x351)))))
(assert
 (let (($x338 (not (net.get @X home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x338)))))
(assert
 (let (($x299 (not (net.get @V0 @V1))))
 (let (($x398 (= @V1 real_owner)))
 (let (($x281 (= @V1 home)))
 (or $x281 $x398 $x299)))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x390 (= @Y real_owner)))
 (let (($x306 (= @Y home)))
 (or $x306 $x390 $x354)))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x393 (= @Z real_owner)))
 (let (($x392 (= @Z home)))
 (or $x392 $x393 $x346)))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x390 (= @Y real_owner)))
 (let (($x306 (= @Y home)))
 (or $x306 $x390 $x367)))))
(assert
 (let (($x323 (not (net.getX @X home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x323)))))
(assert
 (let (($x312 (not (net.getX @V1 @V0))))
 (let (($x413 (= @V0 real_owner)))
 (let (($x412 (= @V0 home)))
 (or $x412 $x413 $x312)))))
(assert
 (let (($x292 (not (net.getX @V0 @V1))))
 (let (($x398 (= @V1 real_owner)))
 (let (($x281 (= @V1 home)))
 (or $x281 $x398 $x292)))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x306 (= @Y home)))
 (or $x306 $x349 __dir.dirty))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x392 (= @Z home)))
 (or $x392 $x364 __dir.dirty))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let (($x395 (= home home)))
 (or $x395 $x333 __dir.dirty))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x295 __dir.dirty))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x306 (= @Y home)))
 (or $x306 $x343 __dir.head))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x392 (= @Z home)))
 (or $x392 $x358 __dir.head))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x395 (= home home)))
 (or $x395 $x318 __dir.head))))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x289 __dir.head))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x306 (= @Y home)))
 (or $x306 $x343 __dir.dirty))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x392 (= @Z home)))
 (or $x392 $x358 __dir.dirty))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x395 (= home home)))
 (or $x395 $x318 __dir.dirty))))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x289 __dir.dirty))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x306 (= @Y home)))
 (or $x306 $x343))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x392 (= @Z home)))
 (or $x392 $x358))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x395 (= home home)))
 (or $x395 $x318))))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x289))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x361 __dir.head))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x351 __dir.head))))
(assert
 (let (($x338 (not (net.get @X home))))
 (let (($x395 (= home home)))
 (or $x395 $x338 __dir.head))))
(assert
 (let (($x299 (not (net.get @V0 @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x299 __dir.head))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x361 __dir.dirty))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x351 __dir.dirty))))
(assert
 (let (($x338 (not (net.get @X home))))
 (let (($x395 (= home home)))
 (or $x395 $x338 __dir.dirty))))
(assert
 (let (($x299 (not (net.get @V0 @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x299 __dir.dirty))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x354 __dir.head))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x346 __dir.head))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x367 __dir.head))))
(assert
 (let (($x323 (not (net.getX @X home))))
 (let (($x395 (= home home)))
 (or $x395 $x323 __dir.head))))
(assert
 (let (($x312 (not (net.getX @V1 @V0))))
 (let (($x412 (= @V0 home)))
 (or $x412 $x312 __dir.head))))
(assert
 (let (($x292 (not (net.getX @V0 @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x292 __dir.head))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x354 __dir.dirty))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x346 __dir.dirty))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x367 __dir.dirty))))
(assert
 (let (($x323 (not (net.getX @X home))))
 (let (($x395 (= home home)))
 (or $x395 $x323 __dir.dirty))))
(assert
 (let (($x312 (not (net.getX @V1 @V0))))
 (let (($x412 (= @V0 home)))
 (or $x412 $x312 __dir.dirty))))
(assert
 (let (($x292 (not (net.getX @V0 @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x292 __dir.dirty))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x354))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x346))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x367))))
(assert
 (let (($x323 (not (net.getX @X home))))
 (let (($x395 (= home home)))
 (or $x395 $x323))))
(assert
 (let (($x312 (not (net.getX @V1 @V0))))
 (let (($x412 (= @V0 home)))
 (or $x412 $x312))))
(assert
 (let (($x292 (not (net.getX @V0 @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x292))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x306 (= @Y home)))
 (let (($x458 (= @X requester)))
 (or $x458 $x306 $x354)))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x392 (= @Z home)))
 (let (($x458 (= @X requester)))
 (or $x458 $x392 $x346)))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x306 (= @Y home)))
 (let (($x461 (= home requester)))
 (or $x461 $x306 $x367)))))
(assert
 (let (($x323 (not (net.getX @X home))))
 (let (($x395 (= home home)))
 (let (($x458 (= @X requester)))
 (or $x458 $x395 $x323)))))
(assert
 (let (($x312 (not (net.getX @V1 @V0))))
 (let (($x412 (= @V0 home)))
 (let (($x464 (= @V1 requester)))
 (or $x464 $x412 $x312)))))
(assert
 (let (($x292 (not (net.getX @V0 @V1))))
 (let (($x281 (= @V1 home)))
 (let (($x466 (= @V0 requester)))
 (or $x466 $x281 $x292)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x284 (not (net.fack @V0 @V1))))
 (let (($x413 (= @V0 real_owner)))
 (or $x413 $x284))))
(assert
 (let (($x327 (not (= (cache.state_ @X) exclusive))))
 (let (($x471 (= @X real_owner)))
 (or $x471 $x327))))
(assert
 (let (($x474 (not (= (cache.state_ @V0) exclusive))))
 (let (($x413 (= @V0 real_owner)))
 (or $x413 $x474))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x476 (= @X dir.hptr)))
 (or $x476 $x318))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x478 (= @V0 dir.hptr)))
 (or $x478 $x480))))
(assert
 (let (($x327 (not (= (cache.state_ @X) exclusive))))
 (let (($x476 (= @X dir.hptr)))
 (or $x476 $x327))))
(assert
 (let (($x474 (not (= (cache.state_ @V0) exclusive))))
 (let (($x478 (= @V0 dir.hptr)))
 (or $x478 $x474))))
(assert
 (let (($x485 (not (= (cache.state_ @X) shared))))
 (let (($x471 (= @X real_owner)))
 (or $x471 $x485))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) shared))))
 (let (($x413 (= @V0 real_owner)))
 (or $x413 $x488))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x306 (= @Y home)))
 (or $x306 $x343))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x392 (= @Z home)))
 (or $x392 $x358))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x395 (= home home)))
 (or $x395 $x318))))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x289))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x395 (= home home)))
 (or $x395 $x480))))
(assert
 (let (($x485 (not (= (cache.state_ @X) shared))))
 (let (($x331 (not (rp_net @X))))
 (or $x331 $x485))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x492 (= real_owner @X)))
 (or $x492 $x343))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x492 (= real_owner @X)))
 (or $x492 $x358))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x492 (= real_owner @X)))
 (or $x492 $x318))))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (let (($x496 (= real_owner @V0)))
 (or $x496 $x289))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x496 (= real_owner @V0)))
 (or $x496 $x480))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (or $x349 __dir.head)))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (or $x364 __dir.head)))
(assert
 (let (($x333 (not (net.put home @X))))
 (or $x333 __dir.head)))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (or $x295 __dir.head)))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (or $x343 __dir.head)))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (or $x358 __dir.head)))
(assert
 (let (($x318 (not (net.putX home @X))))
 (or $x318 __dir.head)))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (or $x289 __dir.head)))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (or $x480 __dir.head)))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (or $x343 __dir.dirty)))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (or $x358 __dir.dirty)))
(assert
 (let (($x318 (not (net.putX home @X))))
 (or $x318 __dir.dirty)))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (or $x289 __dir.dirty)))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (or $x480 __dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x318 (not (net.putX home @X))))
 (or $x318 __dir.head)))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (or $x480 __dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x331 (not (rp_net @X))))
 (let (($x349 (not (net.put @Y @X))))
 (or $x349 $x331))))
(assert
 (let (($x331 (not (rp_net @X))))
 (let (($x364 (not (net.put @Z @X))))
 (or $x364 $x331))))
(assert
 (let (($x331 (not (rp_net @X))))
 (let (($x333 (not (net.put home @X))))
 (or $x333 $x331))))
(assert
 (let (($x522 (not (rp_net @V0))))
 (let (($x295 (not (net.put @V1 @V0))))
 (or $x295 $x522))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x485 (not (= (cache.state_ @X) shared))))
 (let (($x539 (not (invack @X))))
 (or $x539 $x485))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) shared))))
 (let (($x542 (not (invack @V0))))
 (or $x542 $x488))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x349 dir.pending))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x364 dir.pending))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x333 dir.pending))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x295 dir.pending))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x525 dir.pending))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x527 dir.pending))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x529 dir.pending))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x349 __dir.dirty))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x364 __dir.dirty))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x333 __dir.dirty))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x295 __dir.dirty))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x525 __dir.dirty))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x527 __dir.dirty))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x529 __dir.dirty))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x349))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x364))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x333))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x295))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x525))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x527))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x529))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x568))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x318))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x480))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x573))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x333))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x525))))
(assert
 (let (($x577 (not (net.get dir.hptr home))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (let (($x575 (not $x58)))
 (or $x575 $x577)))))
(assert
 (let (($x338 (not (net.get @X home))))
 (let (($x544 (__dir.shlist @X)))
 (let (($x579 (not $x544)))
 (or $x579 $x338)))))
(assert
 (let (($x583 (not (net.get @V0 home))))
 (let (($x548 (__dir.shlist @V0)))
 (let (($x581 (not $x548)))
 (or $x581 $x583)))))
(assert
 (let (($x58 (__dir.shlist dir.hptr)))
 (let (($x575 (not $x58)))
 (or $x575 __dir.head))))
(assert
 (let (($x544 (__dir.shlist @X)))
 (let (($x579 (not $x544)))
 (or $x579 __dir.head))))
(assert
 (let (($x548 (__dir.shlist @V0)))
 (let (($x581 (not $x548)))
 (or $x581 __dir.head))))
(assert
 (let (($x327 (not (= (cache.state_ @X) exclusive))))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x327))))
(assert
 (let (($x474 (not (= (cache.state_ @V0) exclusive))))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x474))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x590 (= @X home)))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x590 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x590 (= @X home)))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x590 $x364)))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let (($x590 (= @X home)))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x590 $x333)))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let (($x412 (= @V0 home)))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x412 $x295)))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let (($x412 (= @V0 home)))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x412 $x525)))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let (($x590 (= @X home)))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x590 $x527)))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let (($x412 (= @V0 home)))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x412 $x529)))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let (($x598 (= dir.hptr home)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x598 $x573)))))
(assert
 (let (($x327 (not (= (cache.state_ @X) exclusive))))
 (let (($x458 (= @X requester)))
 (let (($x544 (__dir.shlist @X)))
 (or $x544 $x458 $x327)))))
(assert
 (let (($x474 (not (= (cache.state_ @V0) exclusive))))
 (let (($x466 (= @V0 requester)))
 (let (($x548 (__dir.shlist @V0)))
 (or $x548 $x466 $x474)))))
(assert
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (let (($x471 (= @X real_owner)))
 (or (dir.real @X) $x471 $x603)))))
(assert
 (let ((?x301 (cache.state_ @V0)))
 (let (($x302 (= ?x301 invalid)))
 (let (($x413 (= @V0 real_owner)))
 (or (dir.real @V0) $x413 $x302)))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x318))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x480))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x568))))
(assert
 (let (($x485 (not (= (cache.state_ @X) shared))))
 (or $x485 (not (= (cache.wait @X) get)))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) shared))))
 (or $x488 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x539 (not (invack @X))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x539)))))
(assert
 (let (($x542 (not (invack @V0))))
 (let ((?x301 (cache.state_ @V0)))
 (let (($x302 (= ?x301 invalid)))
 (or $x302 $x542)))))
(assert
 (let (($x327 (not (= (cache.state_ @X) exclusive))))
 (or $x327 __dir.head)))
(assert
 (let (($x474 (not (= (cache.state_ @V0) exclusive))))
 (or $x474 __dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x395 (= home home)))
 (or $x395 $x187))))
(assert
 (let (($x284 (not (net.fack @V0 @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x284))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x343)))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x358)))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x318)))))
(assert
 (let (($x289 (not (net.putX @V1 @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x287 (= ?x286 getX)))
 (or $x287 $x289)))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x287 (= ?x286 getX)))
 (or $x287 $x480)))))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x516)))))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x287 (= ?x286 getX)))
 (or $x287 $x518)))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x625 (= ?x624 getX)))
 (or $x625 $x568)))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x354)))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x346)))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x367)))))
(assert
 (let (($x323 (not (net.getX @X home))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x323)))))
(assert
 (let (($x312 (not (net.getX @V1 @V0))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x632 (= ?x313 getX)))
 (or $x632 $x312)))))
(assert
 (let (($x292 (not (net.getX @V0 @V1))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x287 (= ?x286 getX)))
 (or $x287 $x292)))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x364)))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x333)))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x296 (= ?x286 get)))
 (or $x296 $x295)))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x296 (= ?x286 get)))
 (or $x296 $x525)))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x527)))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x296 (= ?x286 get)))
 (or $x296 $x529)))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x639 (= ?x624 get)))
 (or $x639 $x573)))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x361)))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x351)))))
(assert
 (let (($x338 (not (net.get @X home))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x338)))))
(assert
 (let (($x299 (not (net.get @V0 @V1))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x296 (= ?x286 get)))
 (or $x296 $x299)))))
(assert
 (let (($x531 (not (net.get home @Y))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x531)))))
(assert
 (let (($x533 (not (net.get home @Z))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x533)))))
(assert
 (let (($x535 (not (net.get home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x535)))))
(assert
 (let (($x537 (not (net.get home @V1))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x537)))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x364)))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x333)))))
(assert
 (let (($x295 (not (net.put @V1 @V0))))
 (let ((?x301 (cache.state_ @V0)))
 (let (($x302 (= ?x301 invalid)))
 (or $x302 $x295)))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let ((?x301 (cache.state_ @V0)))
 (let (($x302 (= ?x301 invalid)))
 (or $x302 $x525)))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x527)))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let ((?x301 (cache.state_ @V0)))
 (let (($x302 (= ?x301 invalid)))
 (or $x302 $x529)))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let ((?x654 (cache.state_ dir.hptr)))
 (let (($x655 (= ?x654 invalid)))
 (or $x655 $x573)))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x361)))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x351)))))
(assert
 (let (($x338 (not (net.get @X home))))
 (let ((?x325 (cache.state_ @X)))
 (let (($x603 (= ?x325 invalid)))
 (or $x603 $x338)))))
(assert
 (let (($x299 (not (net.get @V0 @V1))))
 (let ((?x301 (cache.state_ @V0)))
 (let (($x302 (= ?x301 invalid)))
 (or $x302 $x299)))))
(assert
 (let (($x531 (not (net.get home @Y))))
 (let ((?x660 (cache.state_ home)))
 (let (($x661 (= ?x660 invalid)))
 (or $x661 $x531)))))
(assert
 (let (($x533 (not (net.get home @Z))))
 (let ((?x660 (cache.state_ home)))
 (let (($x661 (= ?x660 invalid)))
 (or $x661 $x533)))))
(assert
 (let (($x535 (not (net.get home home))))
 (let ((?x660 (cache.state_ home)))
 (let (($x661 (= ?x660 invalid)))
 (or $x661 $x535)))))
(assert
 (let (($x537 (not (net.get home @V1))))
 (let ((?x660 (cache.state_ home)))
 (let (($x661 (= ?x660 invalid)))
 (or $x661 $x537)))))
(assert
 (let (($x306 (= @Y home)))
 (or $x306 (not (net.shwb @X @Y)))))
(assert
 (let (($x395 (= home home)))
 (or $x395 (not (net.shwb @X home)))))
(assert
 (let (($x668 (not (= (cache.wait @X) none))))
 (let (($x354 (not (net.getX @X @Y))))
 (or $x354 $x668))))
(assert
 (let (($x668 (not (= (cache.wait @X) none))))
 (let (($x346 (not (net.getX @X @Z))))
 (or $x346 $x668))))
(assert
 (let (($x672 (not (= (cache.wait home) none))))
 (let (($x367 (not (net.getX home @Y))))
 (or $x367 $x672))))
(assert
 (let (($x668 (not (= (cache.wait @X) none))))
 (let (($x323 (not (net.getX @X home))))
 (or $x323 $x668))))
(assert
 (let (($x315 (not (= (cache.wait @V1) none))))
 (let (($x312 (not (net.getX @V1 @V0))))
 (or $x312 $x315))))
(assert
 (let (($x676 (not (= (cache.wait @V0) none))))
 (let (($x292 (not (net.getX @V0 @V1))))
 (or $x292 $x676))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x678 (= ?x140 getX)))
 (or $x678 $x680)))))
(assert
 (let (($x318 (not (net.putX home @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x318)))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x632 (= ?x313 getX)))
 (or $x632 $x683)))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x287 (= ?x286 getX)))
 (or $x287 $x480)))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x625 (= ?x624 getX)))
 (or $x625 $x568)))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x686)))))
(assert
 (let (($x323 (not (net.getX @X home))))
 (let ((?x319 (cache.wait @X)))
 (let (($x320 (= ?x319 getX)))
 (or $x320 $x323)))))
(assert
 (let (($x689 (not (net.getX home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x689)))))
(assert
 (let (($x692 (not (net.getX @V1 home))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x632 (= ?x313 getX)))
 (or $x632 $x692)))))
(assert
 (let (($x695 (not (net.getX @V0 home))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x287 (= ?x286 getX)))
 (or $x287 $x695)))))
(assert
 (let (($x327 (not (= (cache.state_ @X) exclusive))))
 (or $x327 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x474 (not (= (cache.state_ @V0) exclusive))))
 (or $x474 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x700 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x700 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x704 (not (= (cache.state_ home) exclusive))))
 (or $x704 (not (= (cache.wait home) getX)))))
(assert
 (let (($x331 (not (rp_net @X))))
 (let (($x333 (not (net.put home @X))))
 (or $x333 $x331))))
(assert
 (let (($x522 (not (rp_net @V0))))
 (let (($x525 (not (net.put home @V0))))
 (or $x525 $x522))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x709)))))
(assert
 (let (($x333 (not (net.put home @X))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x333)))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x711 (= ?x313 get)))
 (or $x711 $x713)))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x296 (= ?x286 get)))
 (or $x296 $x525)))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x639 (= ?x624 get)))
 (or $x639 $x573)))))
(assert
 (let (($x716 (not (net.put home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x716)))))
(assert
 (let (($x719 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x719)))))
(assert
 (let (($x338 (not (net.get @X home))))
 (let ((?x319 (cache.wait @X)))
 (let (($x335 (= ?x319 get)))
 (or $x335 $x338)))))
(assert
 (let (($x722 (not (net.get @V1 home))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x711 (= ?x313 get)))
 (or $x711 $x722)))))
(assert
 (let (($x583 (not (net.get @V0 home))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x296 (= ?x286 get)))
 (or $x296 $x583)))))
(assert
 (let (($x577 (not (net.get dir.hptr home))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x639 (= ?x624 get)))
 (or $x639 $x577)))))
(assert
 (let (($x535 (not (net.get home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x535)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x525)))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x145 $x527)))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x145 $x529)))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x573)))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x709)))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x713)))))
(assert
 (let (($x716 (not (net.put home home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x716)))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x480)))))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (let (($x741 (= real_owner real_owner)))
 (let (($x740 (= real_owner home)))
 (or $x740 $x741 $x516)))))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (let (($x741 (= real_owner real_owner)))
 (let (($x740 (= real_owner home)))
 (or $x740 $x741 $x518)))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x568)))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x680)))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x683)))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x686)))))
(assert
 (let (($x531 (not (net.get home @Y))))
 (let (($x390 (= @Y real_owner)))
 (let (($x306 (= @Y home)))
 (or $x306 $x390 $x531)))))
(assert
 (let (($x533 (not (net.get home @Z))))
 (let (($x393 (= @Z real_owner)))
 (let (($x392 (= @Z home)))
 (or $x392 $x393 $x533)))))
(assert
 (let (($x535 (not (net.get home home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x535)))))
(assert
 (let (($x537 (not (net.get home @V1))))
 (let (($x398 (= @V1 real_owner)))
 (let (($x281 (= @V1 home)))
 (or $x281 $x398 $x537)))))
(assert
 (let (($x577 (not (net.get dir.hptr home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x577)))))
(assert
 (let (($x583 (not (net.get @V0 home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x583)))))
(assert
 (let (($x719 (not (net.get real_owner home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x719)))))
(assert
 (let (($x722 (not (net.get @V1 home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x722)))))
(assert
 (let (($x689 (not (net.getX home home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x689)))))
(assert
 (let (($x692 (not (net.getX @V1 home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x692)))))
(assert
 (let (($x695 (not (net.getX @V0 home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x695)))))
(assert
 (let (($x727 (not (net.getX home @Z))))
 (let (($x393 (= @Z real_owner)))
 (let (($x392 (= @Z home)))
 (or $x392 $x393 $x727)))))
(assert
 (let (($x729 (not (net.getX home @V0))))
 (let (($x413 (= @V0 real_owner)))
 (let (($x412 (= @V0 home)))
 (or $x412 $x413 $x729)))))
(assert
 (let (($x731 (not (net.getX home @V1))))
 (let (($x398 (= @V1 real_owner)))
 (let (($x281 (= @V1 home)))
 (or $x281 $x398 $x731)))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (let (($x395 (= home home)))
 (or $x395 $x525 __dir.dirty))))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x527 __dir.dirty))))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x529 __dir.dirty))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let (($x395 (= home home)))
 (or $x395 $x573 __dir.dirty))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let (($x395 (= home home)))
 (or $x395 $x709 __dir.dirty))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let (($x395 (= home home)))
 (or $x395 $x713 __dir.dirty))))
(assert
 (let (($x716 (not (net.put home home))))
 (let (($x395 (= home home)))
 (or $x395 $x716 __dir.dirty))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x395 (= home home)))
 (or $x395 $x480 __dir.head))))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x516 __dir.head))))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x518 __dir.head))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x395 (= home home)))
 (or $x395 $x568 __dir.head))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x395 (= home home)))
 (or $x395 $x680 __dir.head))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x395 (= home home)))
 (or $x395 $x683 __dir.head))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x395 (= home home)))
 (or $x395 $x686 __dir.head))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x395 (= home home)))
 (or $x395 $x480 __dir.dirty))))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x516 __dir.dirty))))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x518 __dir.dirty))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x395 (= home home)))
 (or $x395 $x568 __dir.dirty))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x395 (= home home)))
 (or $x395 $x680 __dir.dirty))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x395 (= home home)))
 (or $x395 $x683 __dir.dirty))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x395 (= home home)))
 (or $x395 $x686 __dir.dirty))))
(assert
 (let (($x480 (not (net.putX home @V0))))
 (let (($x395 (= home home)))
 (or $x395 $x480))))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x516))))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x518))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x395 (= home home)))
 (or $x395 $x568))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x395 (= home home)))
 (or $x395 $x680))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x395 (= home home)))
 (or $x395 $x683))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x395 (= home home)))
 (or $x395 $x686))))
(assert
 (let (($x531 (not (net.get home @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x531 __dir.head))))
(assert
 (let (($x533 (not (net.get home @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x533 __dir.head))))
(assert
 (let (($x535 (not (net.get home home))))
 (let (($x395 (= home home)))
 (or $x395 $x535 __dir.head))))
(assert
 (let (($x537 (not (net.get home @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x537 __dir.head))))
(assert
 (let (($x577 (not (net.get dir.hptr home))))
 (let (($x395 (= home home)))
 (or $x395 $x577 __dir.head))))
(assert
 (let (($x583 (not (net.get @V0 home))))
 (let (($x395 (= home home)))
 (or $x395 $x583 __dir.head))))
(assert
 (let (($x719 (not (net.get real_owner home))))
 (let (($x395 (= home home)))
 (or $x395 $x719 __dir.head))))
(assert
 (let (($x722 (not (net.get @V1 home))))
 (let (($x395 (= home home)))
 (or $x395 $x722 __dir.head))))
(assert
 (let (($x531 (not (net.get home @Y))))
 (let (($x306 (= @Y home)))
 (or $x306 $x531 __dir.dirty))))
(assert
 (let (($x533 (not (net.get home @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x533 __dir.dirty))))
(assert
 (let (($x535 (not (net.get home home))))
 (let (($x395 (= home home)))
 (or $x395 $x535 __dir.dirty))))
(assert
 (let (($x537 (not (net.get home @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x537 __dir.dirty))))
(assert
 (let (($x577 (not (net.get dir.hptr home))))
 (let (($x395 (= home home)))
 (or $x395 $x577 __dir.dirty))))
(assert
 (let (($x583 (not (net.get @V0 home))))
 (let (($x395 (= home home)))
 (or $x395 $x583 __dir.dirty))))
(assert
 (let (($x719 (not (net.get real_owner home))))
 (let (($x395 (= home home)))
 (or $x395 $x719 __dir.dirty))))
(assert
 (let (($x722 (not (net.get @V1 home))))
 (let (($x395 (= home home)))
 (or $x395 $x722 __dir.dirty))))
(assert
 (let (($x689 (not (net.getX home home))))
 (let (($x395 (= home home)))
 (or $x395 $x689 __dir.head))))
(assert
 (let (($x692 (not (net.getX @V1 home))))
 (let (($x395 (= home home)))
 (or $x395 $x692 __dir.head))))
(assert
 (let (($x695 (not (net.getX @V0 home))))
 (let (($x395 (= home home)))
 (or $x395 $x695 __dir.head))))
(assert
 (let (($x727 (not (net.getX home @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x727 __dir.head))))
(assert
 (let (($x729 (not (net.getX home @V0))))
 (let (($x412 (= @V0 home)))
 (or $x412 $x729 __dir.head))))
(assert
 (let (($x731 (not (net.getX home @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x731 __dir.head))))
(assert
 (let (($x689 (not (net.getX home home))))
 (let (($x395 (= home home)))
 (or $x395 $x689 __dir.dirty))))
(assert
 (let (($x692 (not (net.getX @V1 home))))
 (let (($x395 (= home home)))
 (or $x395 $x692 __dir.dirty))))
(assert
 (let (($x695 (not (net.getX @V0 home))))
 (let (($x395 (= home home)))
 (or $x395 $x695 __dir.dirty))))
(assert
 (let (($x727 (not (net.getX home @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x727 __dir.dirty))))
(assert
 (let (($x729 (not (net.getX home @V0))))
 (let (($x412 (= @V0 home)))
 (or $x412 $x729 __dir.dirty))))
(assert
 (let (($x731 (not (net.getX home @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x731 __dir.dirty))))
(assert
 (let (($x689 (not (net.getX home home))))
 (let (($x395 (= home home)))
 (or $x395 $x689))))
(assert
 (let (($x692 (not (net.getX @V1 home))))
 (let (($x395 (= home home)))
 (or $x395 $x692))))
(assert
 (let (($x695 (not (net.getX @V0 home))))
 (let (($x395 (= home home)))
 (or $x395 $x695))))
(assert
 (let (($x727 (not (net.getX home @Z))))
 (let (($x392 (= @Z home)))
 (or $x392 $x727))))
(assert
 (let (($x729 (not (net.getX home @V0))))
 (let (($x412 (= @V0 home)))
 (or $x412 $x729))))
(assert
 (let (($x731 (not (net.getX home @V1))))
 (let (($x281 (= @V1 home)))
 (or $x281 $x731))))
(assert
 (let (($x689 (not (net.getX home home))))
 (let (($x395 (= home home)))
 (let (($x461 (= home requester)))
 (or $x461 $x395 $x689)))))
(assert
 (let (($x692 (not (net.getX @V1 home))))
 (let (($x395 (= home home)))
 (let (($x464 (= @V1 requester)))
 (or $x464 $x395 $x692)))))
(assert
 (let (($x695 (not (net.getX @V0 home))))
 (let (($x395 (= home home)))
 (let (($x466 (= @V0 requester)))
 (or $x466 $x395 $x695)))))
(assert
 (let (($x727 (not (net.getX home @Z))))
 (let (($x392 (= @Z home)))
 (let (($x461 (= home requester)))
 (or $x461 $x392 $x727)))))
(assert
 (let (($x729 (not (net.getX home @V0))))
 (let (($x412 (= @V0 home)))
 (let (($x461 (= home requester)))
 (or $x461 $x412 $x729)))))
(assert
 (let (($x731 (not (net.getX home @V1))))
 (let (($x281 (= @V1 home)))
 (let (($x461 (= home requester)))
 (or $x461 $x281 $x731)))))
(assert
 (let (($x700 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x700))))
(assert
 (let (($x704 (not (= (cache.state_ home) exclusive))))
 (let (($x396 (= home real_owner)))
 (or $x396 $x704))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x831 (= dir.hptr dir.hptr)))
 (or $x831 $x568))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x833 (= real_owner dir.hptr)))
 (or $x833 $x680))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x835 (= @V1 dir.hptr)))
 (or $x835 $x683))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x837 (= home dir.hptr)))
 (or $x837 $x686))))
(assert
 (let (($x700 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x831 (= dir.hptr dir.hptr)))
 (or $x831 $x700))))
(assert
 (let (($x704 (not (= (cache.state_ home) exclusive))))
 (let (($x837 (= home dir.hptr)))
 (or $x837 $x704))))
(assert
 (let (($x842 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x842))))
(assert
 (let (($x845 (not (= (cache.state_ home) shared))))
 (let (($x396 (= home real_owner)))
 (or $x396 $x845))))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x516))))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x518))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x395 (= home home)))
 (or $x395 $x568))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x395 (= home home)))
 (or $x395 $x680))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x395 (= home home)))
 (or $x395 $x683))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x395 (= home home)))
 (or $x395 $x686))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) shared))))
 (let (($x522 (not (rp_net @V0))))
 (or $x522 $x488))))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (let (($x492 (= real_owner @X)))
 (or $x492 $x516))))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (let (($x496 (= real_owner @V0)))
 (or $x496 $x518))))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (let (($x833 (= real_owner dir.hptr)))
 (or $x833 $x568))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x741 (= real_owner real_owner)))
 (or $x741 $x680))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x852 (= real_owner @V1)))
 (or $x852 $x683))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x686))))
(assert
 (let (($x525 (not (net.put home @V0))))
 (or $x525 __dir.head)))
(assert
 (let (($x527 (not (net.put dir.hptr @X))))
 (or $x527 __dir.head)))
(assert
 (let (($x529 (not (net.put dir.hptr @V0))))
 (or $x529 __dir.head)))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (or $x573 __dir.head)))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (or $x709 __dir.head)))
(assert
 (let (($x713 (not (net.put home @V1))))
 (or $x713 __dir.head)))
(assert
 (let (($x716 (not (net.put home home))))
 (or $x716 __dir.head)))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (or $x516 __dir.head)))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (or $x518 __dir.head)))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (or $x568 __dir.head)))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (or $x680 __dir.head)))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (or $x683 __dir.head)))
(assert
 (let (($x686 (not (net.putX home home))))
 (or $x686 __dir.head)))
(assert
 (let (($x516 (not (net.putX real_owner @X))))
 (or $x516 __dir.dirty)))
(assert
 (let (($x518 (not (net.putX real_owner @V0))))
 (or $x518 __dir.dirty)))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (or $x568 __dir.dirty)))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (or $x680 __dir.dirty)))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (or $x683 __dir.dirty)))
(assert
 (let (($x686 (not (net.putX home home))))
 (or $x686 __dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x568 (not (net.putX home dir.hptr))))
 (or $x568 __dir.head)))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (or $x680 __dir.head)))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (or $x683 __dir.head)))
(assert
 (let (($x686 (not (net.putX home home))))
 (or $x686 __dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x522 (not (rp_net @V0))))
 (let (($x525 (not (net.put home @V0))))
 (or $x525 $x522))))
(assert
 (let (($x331 (not (rp_net @X))))
 (let (($x527 (not (net.put dir.hptr @X))))
 (or $x527 $x331))))
(assert
 (let (($x522 (not (rp_net @V0))))
 (let (($x529 (not (net.put dir.hptr @V0))))
 (or $x529 $x522))))
(assert
 (let (($x885 (not (rp_net dir.hptr))))
 (let (($x573 (not (net.put home dir.hptr))))
 (or $x573 $x885))))
(assert
 (let (($x888 (not (rp_net real_owner))))
 (let (($x709 (not (net.put home real_owner))))
 (or $x709 $x888))))
(assert
 (let (($x891 (not (rp_net @V1))))
 (let (($x713 (not (net.put home @V1))))
 (or $x713 $x891))))
(assert
 (let (($x894 (not (rp_net home))))
 (let (($x716 (not (net.put home home))))
 (or $x716 $x894))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x539 (not (invack @X))))
 (or $x539 (not (invnet @X)))))
(assert
 (let (($x542 (not (invack @V0))))
 (or $x542 (not (invnet @V0)))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x573 dir.pending))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x709 dir.pending))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x713 dir.pending))))
(assert
 (let (($x716 (not (net.put home home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x716 dir.pending))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x897 dir.pending))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x899 dir.pending))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x901 dir.pending))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x903 dir.pending))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x573 __dir.dirty))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x709 __dir.dirty))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x713 __dir.dirty))))
(assert
 (let (($x716 (not (net.put home home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x716 __dir.dirty))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x897 __dir.dirty))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x899 __dir.dirty))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x901 __dir.dirty))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x903 __dir.dirty))))
(assert
 (let (($x573 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x573))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x709))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x713))))
(assert
 (let (($x716 (not (net.put home home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x716))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x897))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x899))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x901))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x903))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x680))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x683))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x686))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x709))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x713))))
(assert
 (let (($x716 (not (net.put home home))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x716))))
(assert
 (let (($x719 (not (net.get real_owner home))))
 (let (($x911 (__dir.shlist real_owner)))
 (let (($x939 (not $x911)))
 (or $x939 $x719)))))
(assert
 (let (($x722 (not (net.get @V1 home))))
 (let (($x913 (__dir.shlist @V1)))
 (let (($x941 (not $x913)))
 (or $x941 $x722)))))
(assert
 (let (($x535 (not (net.get home home))))
 (let (($x915 (__dir.shlist home)))
 (let (($x943 (not $x915)))
 (or $x943 $x535)))))
(assert
 (let (($x911 (__dir.shlist real_owner)))
 (let (($x939 (not $x911)))
 (or $x939 __dir.head))))
(assert
 (let (($x913 (__dir.shlist @V1)))
 (let (($x941 (not $x913)))
 (or $x941 __dir.head))))
(assert
 (let (($x915 (__dir.shlist home)))
 (let (($x943 (not $x915)))
 (or $x943 __dir.head))))
(assert
 (let (($x700 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x700))))
(assert
 (let (($x704 (not (= (cache.state_ home) exclusive))))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x704))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let (($x740 (= real_owner home)))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x740 $x709)))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let (($x281 (= @V1 home)))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x281 $x713)))))
(assert
 (let (($x716 (not (net.put home home))))
 (let (($x395 (= home home)))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x395 $x716)))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let (($x598 (= dir.hptr home)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x598 $x897)))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let (($x740 (= real_owner home)))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x740 $x899)))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let (($x281 (= @V1 home)))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x281 $x901)))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let (($x395 (= home home)))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x395 $x903)))))
(assert
 (let (($x700 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x957 (= dir.hptr requester)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x957 $x700)))))
(assert
 (let (($x704 (not (= (cache.state_ home) exclusive))))
 (let (($x461 (= home requester)))
 (let (($x915 (__dir.shlist home)))
 (or $x915 $x461 $x704)))))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x680))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x683))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x686))))
(assert
 (let (($x842 (not (= (cache.state_ dir.hptr) shared))))
 (or $x842 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x845 (not (= (cache.state_ home) shared))))
 (or $x845 (not (= (cache.wait home) get)))))
(assert
 (let (($x700 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x700 __dir.head)))
(assert
 (let (($x704 (not (= (cache.state_ home) exclusive))))
 (or $x704 __dir.head)))
(assert
 (let (($x680 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x678 (= ?x140 getX)))
 (or $x678 $x680)))))
(assert
 (let (($x683 (not (net.putX home @V1))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x632 (= ?x313 getX)))
 (or $x632 $x683)))))
(assert
 (let (($x686 (not (net.putX home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x686)))))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x625 (= ?x624 getX)))
 (or $x625 $x875)))))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x678 (= ?x140 getX)))
 (or $x678 $x877)))))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x632 (= ?x313 getX)))
 (or $x632 $x879)))))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x881)))))
(assert
 (let (($x689 (not (net.getX home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x689)))))
(assert
 (let (($x692 (not (net.getX @V1 home))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x632 (= ?x313 getX)))
 (or $x632 $x692)))))
(assert
 (let (($x695 (not (net.getX @V0 home))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x287 (= ?x286 getX)))
 (or $x287 $x695)))))
(assert
 (let (($x727 (not (net.getX home @Z))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x727)))))
(assert
 (let (($x729 (not (net.getX home @V0))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x729)))))
(assert
 (let (($x731 (not (net.getX home @V1))))
 (let ((?x629 (cache.wait home)))
 (let (($x630 (= ?x629 getX)))
 (or $x630 $x731)))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x709)))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x711 (= ?x313 get)))
 (or $x711 $x713)))))
(assert
 (let (($x716 (not (net.put home home))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x716)))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x639 (= ?x624 get)))
 (or $x639 $x897)))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x899)))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x711 (= ?x313 get)))
 (or $x711 $x901)))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let ((?x629 (cache.wait home)))
 (let (($x643 (= ?x629 get)))
 (or $x643 $x903)))))
(assert
 (let (($x577 (not (net.get dir.hptr home))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x639 (= ?x624 get)))
 (or $x639 $x577)))))
(assert
 (let (($x583 (not (net.get @V0 home))))
 (let ((?x286 (cache.wait @V0)))
 (let (($x296 (= ?x286 get)))
 (or $x296 $x583)))))
(assert
 (let (($x719 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x719)))))
(assert
 (let (($x722 (not (net.get @V1 home))))
 (let ((?x313 (cache.wait @V1)))
 (let (($x711 (= ?x313 get)))
 (or $x711 $x722)))))
(assert
 (let (($x709 (not (net.put home real_owner))))
 (let ((?x980 (cache.state_ real_owner)))
 (let (($x981 (= ?x980 invalid)))
 (or $x981 $x709)))))
(assert
 (let (($x713 (not (net.put home @V1))))
 (let ((?x983 (cache.state_ @V1)))
 (let (($x984 (= ?x983 invalid)))
 (or $x984 $x713)))))
(assert
 (let (($x716 (not (net.put home home))))
 (let ((?x660 (cache.state_ home)))
 (let (($x661 (= ?x660 invalid)))
 (or $x661 $x716)))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let ((?x654 (cache.state_ dir.hptr)))
 (let (($x655 (= ?x654 invalid)))
 (or $x655 $x897)))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let ((?x980 (cache.state_ real_owner)))
 (let (($x981 (= ?x980 invalid)))
 (or $x981 $x899)))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let ((?x983 (cache.state_ @V1)))
 (let (($x984 (= ?x983 invalid)))
 (or $x984 $x901)))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let ((?x660 (cache.state_ home)))
 (let (($x661 (= ?x660 invalid)))
 (or $x661 $x903)))))
(assert
 (let (($x577 (not (net.get dir.hptr home))))
 (let ((?x654 (cache.state_ dir.hptr)))
 (let (($x655 (= ?x654 invalid)))
 (or $x655 $x577)))))
(assert
 (let (($x583 (not (net.get @V0 home))))
 (let ((?x301 (cache.state_ @V0)))
 (let (($x302 (= ?x301 invalid)))
 (or $x302 $x583)))))
(assert
 (let (($x719 (not (net.get real_owner home))))
 (let ((?x980 (cache.state_ real_owner)))
 (let (($x981 (= ?x980 invalid)))
 (or $x981 $x719)))))
(assert
 (let (($x722 (not (net.get @V1 home))))
 (let ((?x983 (cache.state_ @V1)))
 (let (($x984 (= ?x983 invalid)))
 (or $x984 $x722)))))
(assert
 (let (($x672 (not (= (cache.wait home) none))))
 (let (($x689 (not (net.getX home home))))
 (or $x689 $x672))))
(assert
 (let (($x315 (not (= (cache.wait @V1) none))))
 (let (($x692 (not (net.getX @V1 home))))
 (or $x692 $x315))))
(assert
 (let (($x676 (not (= (cache.wait @V0) none))))
 (let (($x695 (not (net.getX @V0 home))))
 (or $x695 $x676))))
(assert
 (let (($x672 (not (= (cache.wait home) none))))
 (let (($x727 (not (net.getX home @Z))))
 (or $x727 $x672))))
(assert
 (let (($x672 (not (= (cache.wait home) none))))
 (let (($x729 (not (net.getX home @V0))))
 (or $x729 $x672))))
(assert
 (let (($x672 (not (= (cache.wait home) none))))
 (let (($x731 (not (net.getX home @V1))))
 (or $x731 $x672))))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x678 (= ?x140 getX)))
 (or $x678 $x1002)))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x625 (= ?x624 getX)))
 (or $x625 $x1005)))))
(assert
 (let (($x1008 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1008 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1012 (not (= (cache.state_ @V1) exclusive))))
 (or $x1012 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x885 (not (rp_net dir.hptr))))
 (let (($x573 (not (net.put home dir.hptr))))
 (or $x573 $x885))))
(assert
 (let (($x888 (not (rp_net real_owner))))
 (let (($x709 (not (net.put home real_owner))))
 (or $x709 $x888))))
(assert
 (let (($x891 (not (rp_net @V1))))
 (let (($x713 (not (net.put home @V1))))
 (or $x713 $x891))))
(assert
 (let (($x894 (not (rp_net home))))
 (let (($x716 (not (net.put home home))))
 (or $x716 $x894))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x145 $x897)))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x145 $x899)))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x145 $x901)))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x145 $x903)))))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (let (($x741 (= real_owner real_owner)))
 (let (($x740 (= real_owner home)))
 (or $x740 $x741 $x875)))))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (let (($x741 (= real_owner real_owner)))
 (let (($x740 (= real_owner home)))
 (or $x740 $x741 $x877)))))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (let (($x741 (= real_owner real_owner)))
 (let (($x740 (= real_owner home)))
 (or $x740 $x741 $x879)))))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (let (($x741 (= real_owner real_owner)))
 (let (($x740 (= real_owner home)))
 (or $x740 $x741 $x881)))))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x1002)))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (let (($x396 (= home real_owner)))
 (let (($x395 (= home home)))
 (or $x395 $x396 $x1005)))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x897 __dir.dirty))))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x899 __dir.dirty))))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x901 __dir.dirty))))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (let (($x598 (= dir.hptr home)))
 (or $x598 $x903 __dir.dirty))))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x875 __dir.head))))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x877 __dir.head))))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x879 __dir.head))))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x881 __dir.head))))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x875 __dir.dirty))))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x877 __dir.dirty))))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x879 __dir.dirty))))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x881 __dir.dirty))))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x875))))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x877))))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x879))))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x881))))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (let (($x395 (= home home)))
 (or $x395 $x1002 __dir.head))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (let (($x395 (= home home)))
 (or $x395 $x1005 __dir.head))))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (let (($x395 (= home home)))
 (or $x395 $x1002 __dir.dirty))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (let (($x395 (= home home)))
 (or $x395 $x1005 __dir.dirty))))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (let (($x395 (= home home)))
 (or $x395 $x1002))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (let (($x395 (= home home)))
 (or $x395 $x1005))))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (let (($x395 (= home home)))
 (let (($x1047 (= real_owner requester)))
 (or $x1047 $x395 $x1002)))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (let (($x395 (= home home)))
 (let (($x957 (= dir.hptr requester)))
 (or $x957 $x395 $x1005)))))
(assert
 (let (($x1008 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x741 (= real_owner real_owner)))
 (or $x741 $x1008))))
(assert
 (let (($x1012 (not (= (cache.state_ @V1) exclusive))))
 (let (($x398 (= @V1 real_owner)))
 (or $x398 $x1012))))
(assert
 (let (($x1008 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x833 (= real_owner dir.hptr)))
 (or $x833 $x1008))))
(assert
 (let (($x1012 (not (= (cache.state_ @V1) exclusive))))
 (let (($x835 (= @V1 dir.hptr)))
 (or $x835 $x1012))))
(assert
 (let (($x1055 (not (= (cache.state_ real_owner) shared))))
 (let (($x741 (= real_owner real_owner)))
 (or $x741 $x1055))))
(assert
 (let (($x1058 (not (= (cache.state_ @V1) shared))))
 (let (($x398 (= @V1 real_owner)))
 (or $x398 $x1058))))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x875))))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x877))))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x879))))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x881))))
(assert
 (let (($x842 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x885 (not (rp_net dir.hptr))))
 (or $x885 $x842))))
(assert
 (let (($x845 (not (= (cache.state_ home) shared))))
 (let (($x894 (not (rp_net home))))
 (or $x894 $x845))))
(assert
 (let (($x1055 (not (= (cache.state_ real_owner) shared))))
 (let (($x888 (not (rp_net real_owner))))
 (or $x888 $x1055))))
(assert
 (let (($x1058 (not (= (cache.state_ @V1) shared))))
 (let (($x891 (not (rp_net @V1))))
 (or $x891 $x1058))))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (let (($x833 (= real_owner dir.hptr)))
 (or $x833 $x875))))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (let (($x741 (= real_owner real_owner)))
 (or $x741 $x877))))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (let (($x852 (= real_owner @V1)))
 (or $x852 $x879))))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (let (($x740 (= real_owner home)))
 (or $x740 $x881))))
(assert
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (or $x897 __dir.head)))
(assert
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (or $x899 __dir.head)))
(assert
 (let (($x901 (not (net.put dir.hptr @V1))))
 (or $x901 __dir.head)))
(assert
 (let (($x903 (not (net.put dir.hptr home))))
 (or $x903 __dir.head)))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (or $x875 __dir.head)))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (or $x877 __dir.head)))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (or $x879 __dir.head)))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (or $x881 __dir.head)))
(assert
 (let (($x875 (not (net.putX real_owner dir.hptr))))
 (or $x875 __dir.dirty)))
(assert
 (let (($x877 (not (net.putX real_owner real_owner))))
 (or $x877 __dir.dirty)))
(assert
 (let (($x879 (not (net.putX real_owner @V1))))
 (or $x879 __dir.dirty)))
(assert
 (let (($x881 (not (net.putX real_owner home))))
 (or $x881 __dir.dirty)))
(assert
 (let (($x885 (not (rp_net dir.hptr))))
 (let (($x897 (not (net.put dir.hptr dir.hptr))))
 (or $x897 $x885))))
(assert
 (let (($x888 (not (rp_net real_owner))))
 (let (($x899 (not (net.put dir.hptr real_owner))))
 (or $x899 $x888))))
(assert
 (let (($x891 (not (rp_net @V1))))
 (let (($x901 (not (net.put dir.hptr @V1))))
 (or $x901 $x891))))
(assert
 (let (($x894 (not (rp_net home))))
 (let (($x903 (not (net.put dir.hptr home))))
 (or $x903 $x894))))
(assert
 (let (($x1008 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x1008))))
(assert
 (let (($x1012 (not (= (cache.state_ @V1) exclusive))))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x1012))))
(assert
 (let (($x1008 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x1047 (= real_owner requester)))
 (let (($x911 (__dir.shlist real_owner)))
 (or $x911 $x1047 $x1008)))))
(assert
 (let (($x1012 (not (= (cache.state_ @V1) exclusive))))
 (let (($x464 (= @V1 requester)))
 (let (($x913 (__dir.shlist @V1)))
 (or $x913 $x464 $x1012)))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (let (($x142 (not $x141)))
 (let (($x1055 (not (= (cache.state_ real_owner) shared))))
 (or $x1055 $x142))))))
(assert
 (let (($x1058 (not (= (cache.state_ @V1) shared))))
 (or $x1058 (not (= (cache.wait @V1) get)))))
(assert
 (let (($x1008 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1008 __dir.head)))
(assert
 (let (($x1012 (not (= (cache.state_ @V1) exclusive))))
 (or $x1012 __dir.head)))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x678 (= ?x140 getX)))
 (or $x678 $x1002)))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (let ((?x624 (cache.wait dir.hptr)))
 (let (($x625 (= ?x624 getX)))
 (or $x625 $x1005)))))
(assert
 (let (($x1002 (not (net.getX real_owner home))))
 (or $x1002 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x1005 (not (net.getX dir.hptr home))))
 (or $x1005 (not (= (cache.wait dir.hptr) none)))))
(check-sat)
