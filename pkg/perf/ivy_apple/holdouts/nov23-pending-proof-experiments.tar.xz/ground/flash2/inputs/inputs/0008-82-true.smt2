(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__net.getX __src home))
(assert
 (let (($x272 (= home __src)))
 (not $x272)))
(assert
 (let (($x278 (= __src dir.hptr)))
 (or dir.pending (and dir.dirty (not (= (cache.state_ home) exclusive))) $x278)))
(assert
 (let (($x333 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x349 (net.getX @X @Z)))
 (let (($x350 (not $x349)))
 (let (($x359 (= @Y @Z)))
 (let (($x372 (and (or $x359 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x359 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x359 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x359 (not (net.getX @X @Y)) $x350) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x350 (not (net.putX @Y @X))) (not (net.getX home @Y)) $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x333 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x372))))))))))
(assert
 (let (($x395 (__net.getX @X @Y)))
 (let (($x357 (net.getX @X @Y)))
 (= $x357 (ite (and (= @X __src) (= @Y home)) false $x395)))))
(assert
 (let (($x400 (__net.getX @X @Z)))
 (let (($x349 (net.getX @X @Z)))
 (= $x349 (ite (and (= @X __src) (= @Z home)) false $x400)))))
(assert
 (let (($x404 (__net.getX home @Y)))
 (let (($x370 (net.getX home @Y)))
 (= $x370 (ite (and (= home __src) (= @Y home)) false $x404)))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x328 (net.getX @X home)))
 (= $x328 (ite (and (= @X __src) (= home home)) false $x409)))))
(assert
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x317 (net.getX @V1 @V0)))
 (= $x317 (ite (and (= @V1 __src) (= @V0 home)) false $x415)))))
(assert
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x297 (net.getX @V0 @V1)))
 (= $x297 (ite (and (= @V0 __src) (= @V1 home)) false $x420)))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let (($x423 (= @Y real_owner)))
 (let (($x312 (= @Y home)))
 (or $x312 $x423 $x353)))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let (($x425 (= @Z real_owner)))
 (let (($x398 (= @Z home)))
 (or $x398 $x425 $x368)))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x339)))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let (($x429 (= @V1 real_owner)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x429 $x301)))))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (let (($x423 (= @Y real_owner)))
 (let (($x312 (= @Y home)))
 (or $x312 $x423 $x347)))))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (let (($x425 (= @Z real_owner)))
 (let (($x398 (= @Z home)))
 (or $x398 $x425 $x362)))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x324)))))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (let (($x429 (= @V1 real_owner)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x429 $x295)))))
(assert
 (let (($x365 (not (net.get @X @Y))))
 (let (($x423 (= @Y real_owner)))
 (let (($x312 (= @Y home)))
 (or $x312 $x423 $x365)))))
(assert
 (let (($x355 (not (net.get @X @Z))))
 (let (($x425 (= @Z real_owner)))
 (let (($x398 (= @Z home)))
 (or $x398 $x425 $x355)))))
(assert
 (let (($x344 (not (net.get @X home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x344)))))
(assert
 (let (($x305 (not (net.get @V0 @V1))))
 (let (($x429 (= @V1 real_owner)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x429 $x305)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x439))))))
(assert
 (let (($x395 (__net.getX @X @Y)))
 (let (($x441 (not $x395)))
 (let (($x423 (= @Y real_owner)))
 (let (($x312 (= @Y home)))
 (or $x312 $x423 $x441))))))
(assert
 (let (($x400 (__net.getX @X @Z)))
 (let (($x443 (not $x400)))
 (let (($x425 (= @Z real_owner)))
 (let (($x398 (= @Z home)))
 (or $x398 $x425 $x443))))))
(assert
 (let (($x404 (__net.getX home @Y)))
 (let (($x445 (not $x404)))
 (let (($x423 (= @Y real_owner)))
 (let (($x312 (= @Y home)))
 (or $x312 $x423 $x445))))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x447))))))
(assert
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x450 (not $x415)))
 (let (($x449 (= @V0 real_owner)))
 (let (($x413 (= @V0 home)))
 (or $x413 $x449 $x450))))))
(assert
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x452 (not $x420)))
 (let (($x429 (= @V1 real_owner)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x429 $x452))))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let (($x312 (= @Y home)))
 (or $x312 $x353 dir.dirty))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let (($x398 (= @Z home)))
 (or $x398 $x368 dir.dirty))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let (($x407 (= home home)))
 (or $x407 $x339 dir.dirty))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x301 dir.dirty))))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (let (($x312 (= @Y home)))
 (or $x312 $x347 dir.head))))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (let (($x398 (= @Z home)))
 (or $x398 $x362 dir.head))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x407 (= home home)))
 (or $x407 $x324 dir.head))))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x295 dir.head))))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (let (($x312 (= @Y home)))
 (or $x312 $x347 dir.dirty))))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (let (($x398 (= @Z home)))
 (or $x398 $x362 dir.dirty))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x407 (= home home)))
 (or $x407 $x324 dir.dirty))))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x295 dir.dirty))))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (let (($x312 (= @Y home)))
 (or $x312 $x347))))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (let (($x398 (= @Z home)))
 (or $x398 $x362))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x407 (= home home)))
 (or $x407 $x324))))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x295))))
(assert
 (let (($x365 (not (net.get @X @Y))))
 (let (($x312 (= @Y home)))
 (or $x312 $x365 dir.head))))
(assert
 (let (($x355 (not (net.get @X @Z))))
 (let (($x398 (= @Z home)))
 (or $x398 $x355 dir.head))))
(assert
 (let (($x344 (not (net.get @X home))))
 (let (($x407 (= home home)))
 (or $x407 $x344 dir.head))))
(assert
 (let (($x305 (not (net.get @V0 @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x305 dir.head))))
(assert
 (let (($x365 (not (net.get @X @Y))))
 (let (($x312 (= @Y home)))
 (or $x312 $x365 dir.dirty))))
(assert
 (let (($x355 (not (net.get @X @Z))))
 (let (($x398 (= @Z home)))
 (or $x398 $x355 dir.dirty))))
(assert
 (let (($x344 (not (net.get @X home))))
 (let (($x407 (= home home)))
 (or $x407 $x344 dir.dirty))))
(assert
 (let (($x305 (not (net.get @V0 @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x305 dir.dirty))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (let (($x407 (= home home)))
 (or $x407 $x439 dir.head)))))
(assert
 (let (($x395 (__net.getX @X @Y)))
 (let (($x441 (not $x395)))
 (let (($x312 (= @Y home)))
 (or $x312 $x441 dir.head)))))
(assert
 (let (($x400 (__net.getX @X @Z)))
 (let (($x443 (not $x400)))
 (let (($x398 (= @Z home)))
 (or $x398 $x443 dir.head)))))
(assert
 (let (($x404 (__net.getX home @Y)))
 (let (($x445 (not $x404)))
 (let (($x312 (= @Y home)))
 (or $x312 $x445 dir.head)))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (let (($x407 (= home home)))
 (or $x407 $x447 dir.head)))))
(assert
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x450 (not $x415)))
 (let (($x413 (= @V0 home)))
 (or $x413 $x450 dir.head)))))
(assert
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x452 (not $x420)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x452 dir.head)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (let (($x407 (= home home)))
 (or $x407 $x439 dir.dirty)))))
(assert
 (let (($x395 (__net.getX @X @Y)))
 (let (($x441 (not $x395)))
 (let (($x312 (= @Y home)))
 (or $x312 $x441 dir.dirty)))))
(assert
 (let (($x400 (__net.getX @X @Z)))
 (let (($x443 (not $x400)))
 (let (($x398 (= @Z home)))
 (or $x398 $x443 dir.dirty)))))
(assert
 (let (($x404 (__net.getX home @Y)))
 (let (($x445 (not $x404)))
 (let (($x312 (= @Y home)))
 (or $x312 $x445 dir.dirty)))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (let (($x407 (= home home)))
 (or $x407 $x447 dir.dirty)))))
(assert
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x450 (not $x415)))
 (let (($x413 (= @V0 home)))
 (or $x413 $x450 dir.dirty)))))
(assert
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x452 (not $x420)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x452 dir.dirty)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (let (($x407 (= home home)))
 (or $x407 $x439)))))
(assert
 (let (($x395 (__net.getX @X @Y)))
 (let (($x441 (not $x395)))
 (let (($x312 (= @Y home)))
 (or $x312 $x441)))))
(assert
 (let (($x400 (__net.getX @X @Z)))
 (let (($x443 (not $x400)))
 (let (($x398 (= @Z home)))
 (or $x398 $x443)))))
(assert
 (let (($x404 (__net.getX home @Y)))
 (let (($x445 (not $x404)))
 (let (($x312 (= @Y home)))
 (or $x312 $x445)))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (let (($x407 (= home home)))
 (or $x407 $x447)))))
(assert
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x450 (not $x415)))
 (let (($x413 (= @V0 home)))
 (or $x413 $x450)))))
(assert
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x452 (not $x420)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x452)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (let (($x407 (= home home)))
 (or (= __src requester) $x407 $x439)))))
(assert
 (let (($x395 (__net.getX @X @Y)))
 (let (($x441 (not $x395)))
 (let (($x312 (= @Y home)))
 (let (($x501 (= @X requester)))
 (or $x501 $x312 $x441))))))
(assert
 (let (($x400 (__net.getX @X @Z)))
 (let (($x443 (not $x400)))
 (let (($x398 (= @Z home)))
 (let (($x501 (= @X requester)))
 (or $x501 $x398 $x443))))))
(assert
 (let (($x404 (__net.getX home @Y)))
 (let (($x445 (not $x404)))
 (let (($x312 (= @Y home)))
 (let (($x504 (= home requester)))
 (or $x504 $x312 $x445))))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (let (($x407 (= home home)))
 (let (($x501 (= @X requester)))
 (or $x501 $x407 $x447))))))
(assert
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x450 (not $x415)))
 (let (($x413 (= @V0 home)))
 (let (($x507 (= @V1 requester)))
 (or $x507 $x413 $x450))))))
(assert
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x452 (not $x420)))
 (let (($x287 (= @V1 home)))
 (let (($x509 (= @V0 requester)))
 (or $x509 $x287 $x452))))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x290 (not (net.fack @V0 @V1))))
 (let (($x449 (= @V0 real_owner)))
 (or $x449 $x290))))
(assert
 (let (($x276 (not (= (cache.state_ home) exclusive))))
 (let (($x427 (= home real_owner)))
 (or $x427 $x276))))
(assert
 (let (($x333 (not (= (cache.state_ @X) exclusive))))
 (let (($x515 (= @X real_owner)))
 (or $x515 $x333))))
(assert
 (let (($x518 (not (= (cache.state_ @V0) exclusive))))
 (let (($x449 (= @V0 real_owner)))
 (or $x449 $x518))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x520 (= @X dir.hptr)))
 (or $x520 $x324))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x522 (= @V0 dir.hptr)))
 (or $x522 $x524))))
(assert
 (let (($x276 (not (= (cache.state_ home) exclusive))))
 (let (($x526 (= home dir.hptr)))
 (or $x526 $x276))))
(assert
 (let (($x333 (not (= (cache.state_ @X) exclusive))))
 (let (($x520 (= @X dir.hptr)))
 (or $x520 $x333))))
(assert
 (let (($x518 (not (= (cache.state_ @V0) exclusive))))
 (let (($x522 (= @V0 dir.hptr)))
 (or $x522 $x518))))
(assert
 (let (($x531 (not (= (cache.state_ home) shared))))
 (let (($x427 (= home real_owner)))
 (or $x427 $x531))))
(assert
 (let (($x534 (not (= (cache.state_ @X) shared))))
 (let (($x515 (= @X real_owner)))
 (or $x515 $x534))))
(assert
 (let (($x537 (not (= (cache.state_ @V0) shared))))
 (let (($x449 (= @V0 real_owner)))
 (or $x449 $x537))))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (let (($x312 (= @Y home)))
 (or $x312 $x347))))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (let (($x398 (= @Z home)))
 (or $x398 $x362))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x407 (= home home)))
 (or $x407 $x324))))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x295))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x407 (= home home)))
 (or $x407 $x524))))
(assert
 (let (($x534 (not (= (cache.state_ @X) shared))))
 (let (($x337 (not (rp_net @X))))
 (or $x337 $x534))))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (let (($x541 (= real_owner @X)))
 (or $x541 $x347))))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (let (($x541 (= real_owner @X)))
 (or $x541 $x362))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x541 (= real_owner @X)))
 (or $x541 $x324))))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (let (($x545 (= real_owner @V0)))
 (or $x545 $x295))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x545 (= real_owner @V0)))
 (or $x545 $x524))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (or $x353 dir.head)))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (or $x368 dir.head)))
(assert
 (let (($x339 (not (net.put home @X))))
 (or $x339 dir.head)))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (or $x301 dir.head)))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (or $x347 dir.head)))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (or $x362 dir.head)))
(assert
 (let (($x324 (not (net.putX home @X))))
 (or $x324 dir.head)))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (or $x295 dir.head)))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (or $x524 dir.head)))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (or $x347 dir.dirty)))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (or $x362 dir.dirty)))
(assert
 (let (($x324 (not (net.putX home @X))))
 (or $x324 dir.dirty)))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (or $x295 dir.dirty)))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (or $x524 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x324 (not (net.putX home @X))))
 (or $x324 dir.head)))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (or $x524 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x337 (not (rp_net @X))))
 (let (($x353 (not (net.put @Y @X))))
 (or $x353 $x337))))
(assert
 (let (($x337 (not (rp_net @X))))
 (let (($x368 (not (net.put @Z @X))))
 (or $x368 $x337))))
(assert
 (let (($x337 (not (rp_net @X))))
 (let (($x339 (not (net.put home @X))))
 (or $x339 $x337))))
(assert
 (let (($x571 (not (rp_net @V0))))
 (let (($x301 (not (net.put @V1 @V0))))
 (or $x301 $x571))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x531 (not (= (cache.state_ home) shared))))
 (let (($x588 (not (invack home))))
 (or $x588 $x531))))
(assert
 (let (($x534 (not (= (cache.state_ @X) shared))))
 (let (($x591 (not (invack @X))))
 (or $x591 $x534))))
(assert
 (let (($x537 (not (= (cache.state_ @V0) shared))))
 (let (($x594 (not (invack @V0))))
 (or $x594 $x537))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x353 dir.pending))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x368 dir.pending))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x339 dir.pending))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x301 dir.pending))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x574 dir.pending))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x576 dir.pending))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x578 dir.pending))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x353 dir.dirty))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x368 dir.dirty))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x339 dir.dirty))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x301 dir.dirty))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x574 dir.dirty))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x576 dir.dirty))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x578 dir.dirty))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x353))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x368))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x339))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x301))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x574))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x576))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x578))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x620))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x324))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x524))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x625))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x339))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x574))))
(assert
 (let (($x629 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x627 (not $x58)))
 (or $x627 $x629)))))
(assert
 (let (($x344 (not (net.get @X home))))
 (let (($x596 (dir.shlist @X)))
 (let (($x631 (not $x596)))
 (or $x631 $x344)))))
(assert
 (let (($x635 (not (net.get @V0 home))))
 (let (($x600 (dir.shlist @V0)))
 (let (($x633 (not $x600)))
 (or $x633 $x635)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x627 (not $x58)))
 (or $x627 dir.head))))
(assert
 (let (($x596 (dir.shlist @X)))
 (let (($x631 (not $x596)))
 (or $x631 dir.head))))
(assert
 (let (($x600 (dir.shlist @V0)))
 (let (($x633 (not $x600)))
 (or $x633 dir.head))))
(assert
 (let (($x276 (not (= (cache.state_ home) exclusive))))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x276))))
(assert
 (let (($x333 (not (= (cache.state_ @X) exclusive))))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x333))))
(assert
 (let (($x518 (not (= (cache.state_ @V0) exclusive))))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x518))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let (($x644 (= @X home)))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x644 $x353)))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let (($x644 (= @X home)))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x644 $x368)))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let (($x644 (= @X home)))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x644 $x339)))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let (($x413 (= @V0 home)))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x413 $x301)))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let (($x413 (= @V0 home)))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x413 $x574)))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let (($x644 (= @X home)))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x644 $x576)))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let (($x413 (= @V0 home)))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x413 $x578)))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let (($x652 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x652 $x625)))))
(assert
 (let (($x276 (not (= (cache.state_ home) exclusive))))
 (let (($x504 (= home requester)))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x504 $x276)))))
(assert
 (let (($x333 (not (= (cache.state_ @X) exclusive))))
 (let (($x501 (= @X requester)))
 (let (($x596 (dir.shlist @X)))
 (or $x596 $x501 $x333)))))
(assert
 (let (($x518 (not (= (cache.state_ @V0) exclusive))))
 (let (($x509 (= @V0 requester)))
 (let (($x600 (dir.shlist @V0)))
 (or $x600 $x509 $x518)))))
(assert
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (let (($x427 (= home real_owner)))
 (or (dir.real home) $x427 $x658)))))
(assert
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (let (($x515 (= @X real_owner)))
 (or (dir.real @X) $x515 $x661)))))
(assert
 (let ((?x307 (cache.state_ @V0)))
 (let (($x308 (= ?x307 invalid)))
 (let (($x449 (= @V0 real_owner)))
 (or (dir.real @V0) $x449 $x308)))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x324))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x524))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x620))))
(assert
 (let (($x531 (not (= (cache.state_ home) shared))))
 (or $x531 (not (= (cache.wait home) get)))))
(assert
 (let (($x534 (not (= (cache.state_ @X) shared))))
 (or $x534 (not (= (cache.wait @X) get)))))
(assert
 (let (($x537 (not (= (cache.state_ @V0) shared))))
 (or $x537 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x588 (not (invack home))))
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (or $x658 $x588)))))
(assert
 (let (($x591 (not (invack @X))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x591)))))
(assert
 (let (($x594 (not (invack @V0))))
 (let ((?x307 (cache.state_ @V0)))
 (let (($x308 (= ?x307 invalid)))
 (or $x308 $x594)))))
(assert
 (let (($x276 (not (= (cache.state_ home) exclusive))))
 (or $x276 dir.head)))
(assert
 (let (($x333 (not (= (cache.state_ @X) exclusive))))
 (or $x333 dir.head)))
(assert
 (let (($x518 (not (= (cache.state_ @V0) exclusive))))
 (or $x518 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x407 (= home home)))
 (or $x407 $x187))))
(assert
 (let (($x290 (not (net.fack @V0 @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x290))))
(assert
 (let (($x347 (not (net.putX @Y @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x347)))))
(assert
 (let (($x362 (not (net.putX @Z @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x362)))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x324)))))
(assert
 (let (($x295 (not (net.putX @V1 @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x293 (= ?x292 getX)))
 (or $x293 $x295)))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x293 (= ?x292 getX)))
 (or $x293 $x524)))))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x565)))))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x293 (= ?x292 getX)))
 (or $x293 $x567)))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x689 (= ?x688 getX)))
 (or $x689 $x620)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (let ((?x691 (cache.wait __src)))
 (let (($x692 (= ?x691 getX)))
 (or $x692 $x439))))))
(assert
 (let (($x395 (__net.getX @X @Y)))
 (let (($x441 (not $x395)))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x441))))))
(assert
 (let (($x400 (__net.getX @X @Z)))
 (let (($x443 (not $x400)))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x443))))))
(assert
 (let (($x404 (__net.getX home @Y)))
 (let (($x445 (not $x404)))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x445))))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x447))))))
(assert
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x450 (not $x415)))
 (let ((?x319 (cache.wait @V1)))
 (let (($x699 (= ?x319 getX)))
 (or $x699 $x450))))))
(assert
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x452 (not $x420)))
 (let ((?x292 (cache.wait @V0)))
 (let (($x293 (= ?x292 getX)))
 (or $x293 $x452))))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x353)))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x368)))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x339)))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x302 (= ?x292 get)))
 (or $x302 $x301)))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x302 (= ?x292 get)))
 (or $x302 $x574)))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x576)))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x302 (= ?x292 get)))
 (or $x302 $x578)))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x707 (= ?x688 get)))
 (or $x707 $x625)))))
(assert
 (let (($x365 (not (net.get @X @Y))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x365)))))
(assert
 (let (($x355 (not (net.get @X @Z))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x355)))))
(assert
 (let (($x344 (not (net.get @X home))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x344)))))
(assert
 (let (($x305 (not (net.get @V0 @V1))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x302 (= ?x292 get)))
 (or $x302 $x305)))))
(assert
 (let (($x580 (not (net.get home @Y))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x580)))))
(assert
 (let (($x582 (not (net.get home @Z))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x582)))))
(assert
 (let (($x584 (not (net.get home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x584)))))
(assert
 (let (($x586 (not (net.get home @V1))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x586)))))
(assert
 (let (($x353 (not (net.put @Y @X))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x353)))))
(assert
 (let (($x368 (not (net.put @Z @X))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x368)))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x339)))))
(assert
 (let (($x301 (not (net.put @V1 @V0))))
 (let ((?x307 (cache.state_ @V0)))
 (let (($x308 (= ?x307 invalid)))
 (or $x308 $x301)))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let ((?x307 (cache.state_ @V0)))
 (let (($x308 (= ?x307 invalid)))
 (or $x308 $x574)))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x576)))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let ((?x307 (cache.state_ @V0)))
 (let (($x308 (= ?x307 invalid)))
 (or $x308 $x578)))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let ((?x721 (cache.state_ dir.hptr)))
 (let (($x722 (= ?x721 invalid)))
 (or $x722 $x625)))))
(assert
 (let (($x365 (not (net.get @X @Y))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x365)))))
(assert
 (let (($x355 (not (net.get @X @Z))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x355)))))
(assert
 (let (($x344 (not (net.get @X home))))
 (let ((?x331 (cache.state_ @X)))
 (let (($x661 (= ?x331 invalid)))
 (or $x661 $x344)))))
(assert
 (let (($x305 (not (net.get @V0 @V1))))
 (let ((?x307 (cache.state_ @V0)))
 (let (($x308 (= ?x307 invalid)))
 (or $x308 $x305)))))
(assert
 (let (($x580 (not (net.get home @Y))))
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (or $x658 $x580)))))
(assert
 (let (($x582 (not (net.get home @Z))))
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (or $x658 $x582)))))
(assert
 (let (($x584 (not (net.get home home))))
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (or $x658 $x584)))))
(assert
 (let (($x586 (not (net.get home @V1))))
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (or $x658 $x586)))))
(assert
 (let (($x312 (= @Y home)))
 (or $x312 (not (net.shwb @X @Y)))))
(assert
 (let (($x407 (= home home)))
 (or $x407 (not (net.shwb @X home)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (or $x439 (not (= (cache.wait __src) none))))))
(assert
 (let (($x736 (not (= (cache.wait @X) none))))
 (let (($x395 (__net.getX @X @Y)))
 (let (($x441 (not $x395)))
 (or $x441 $x736)))))
(assert
 (let (($x736 (not (= (cache.wait @X) none))))
 (let (($x400 (__net.getX @X @Z)))
 (let (($x443 (not $x400)))
 (or $x443 $x736)))))
(assert
 (let (($x740 (not (= (cache.wait home) none))))
 (let (($x404 (__net.getX home @Y)))
 (let (($x445 (not $x404)))
 (or $x445 $x740)))))
(assert
 (let (($x736 (not (= (cache.wait @X) none))))
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (or $x447 $x736)))))
(assert
 (let (($x321 (not (= (cache.wait @V1) none))))
 (let (($x415 (__net.getX @V1 @V0)))
 (let (($x450 (not $x415)))
 (or $x450 $x321)))))
(assert
 (let (($x745 (not (= (cache.wait @V0) none))))
 (let (($x420 (__net.getX @V0 @V1)))
 (let (($x452 (not $x420)))
 (or $x452 $x745)))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x747 (= ?x140 getX)))
 (or $x747 $x749)))))
(assert
 (let (($x324 (not (net.putX home @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x324)))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x699 (= ?x319 getX)))
 (or $x699 $x752)))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x293 (= ?x292 getX)))
 (or $x293 $x524)))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x755)))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x689 (= ?x688 getX)))
 (or $x689 $x620)))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let ((?x691 (cache.wait __src)))
 (let (($x692 (= ?x691 getX)))
 (or $x692 $x758)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x439 (not $x271)))
 (let ((?x691 (cache.wait __src)))
 (let (($x692 (= ?x691 getX)))
 (or $x692 $x439))))))
(assert
 (let (($x409 (__net.getX @X home)))
 (let (($x447 (not $x409)))
 (let ((?x325 (cache.wait @X)))
 (let (($x326 (= ?x325 getX)))
 (or $x326 $x447))))))
(assert
 (let (($x761 (not (__net.getX home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x761)))))
(assert
 (let (($x764 (not (__net.getX @V1 home))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x699 (= ?x319 getX)))
 (or $x699 $x764)))))
(assert
 (let (($x767 (not (__net.getX @V0 home))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x293 (= ?x292 getX)))
 (or $x293 $x767)))))
(assert
 (let (($x276 (not (= (cache.state_ home) exclusive))))
 (or $x276 (not (= (cache.wait home) getX)))))
(assert
 (let (($x333 (not (= (cache.state_ @X) exclusive))))
 (or $x333 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x518 (not (= (cache.state_ @V0) exclusive))))
 (or $x518 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x774 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x774 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x337 (not (rp_net @X))))
 (let (($x339 (not (net.put home @X))))
 (or $x339 $x337))))
(assert
 (let (($x571 (not (rp_net @V0))))
 (let (($x574 (not (net.put home @V0))))
 (or $x574 $x571))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x779)))))
(assert
 (let (($x339 (not (net.put home @X))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x339)))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x781 (= ?x319 get)))
 (or $x781 $x783)))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x302 (= ?x292 get)))
 (or $x302 $x574)))))
(assert
 (let (($x786 (not (net.put home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x786)))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x707 (= ?x688 get)))
 (or $x707 $x625)))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let ((?x691 (cache.wait __src)))
 (let (($x788 (= ?x691 get)))
 (or $x788 $x790)))))
(assert
 (let (($x793 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x793)))))
(assert
 (let (($x344 (not (net.get @X home))))
 (let ((?x325 (cache.wait @X)))
 (let (($x341 (= ?x325 get)))
 (or $x341 $x344)))))
(assert
 (let (($x796 (not (net.get @V1 home))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x781 (= ?x319 get)))
 (or $x781 $x796)))))
(assert
 (let (($x635 (not (net.get @V0 home))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x302 (= ?x292 get)))
 (or $x302 $x635)))))
(assert
 (let (($x584 (not (net.get home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x584)))))
(assert
 (let (($x629 (not (net.get dir.hptr home))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x707 (= ?x688 get)))
 (or $x707 $x629)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let ((?x691 (cache.wait __src)))
 (let (($x788 (= ?x691 get)))
 (or $x788 $x801)))))
(assert
 (not (__net.getX home home)))
(assert
 (let (($x404 (__net.getX home @Y)))
 (not $x404)))
(assert
 (not (__net.getX home @Z)))
(assert
 (not (__net.getX home @V0)))
(assert
 (not (__net.getX home @V1)))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x574)))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x576)))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x578)))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x625)))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x779)))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x783)))))
(assert
 (let (($x786 (not (net.put home home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x786)))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x790)))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x524)))))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (let (($x819 (= real_owner real_owner)))
 (let (($x818 (= real_owner home)))
 (or $x818 $x819 $x565)))))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (let (($x819 (= real_owner real_owner)))
 (let (($x818 (= real_owner home)))
 (or $x818 $x819 $x567)))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x620)))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x749)))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x752)))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x755)))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x758)))))
(assert
 (let (($x580 (not (net.get home @Y))))
 (let (($x423 (= @Y real_owner)))
 (let (($x312 (= @Y home)))
 (or $x312 $x423 $x580)))))
(assert
 (let (($x582 (not (net.get home @Z))))
 (let (($x425 (= @Z real_owner)))
 (let (($x398 (= @Z home)))
 (or $x398 $x425 $x582)))))
(assert
 (let (($x584 (not (net.get home home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x584)))))
(assert
 (let (($x586 (not (net.get home @V1))))
 (let (($x429 (= @V1 real_owner)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x429 $x586)))))
(assert
 (let (($x629 (not (net.get dir.hptr home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x629)))))
(assert
 (let (($x635 (not (net.get @V0 home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x635)))))
(assert
 (let (($x793 (not (net.get real_owner home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x793)))))
(assert
 (let (($x796 (not (net.get @V1 home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x796)))))
(assert
 (let (($x761 (not (__net.getX home home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x761)))))
(assert
 (let (($x764 (not (__net.getX @V1 home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x764)))))
(assert
 (let (($x767 (not (__net.getX @V0 home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x767)))))
(assert
 (let (($x804 (not (__net.getX home @Z))))
 (let (($x425 (= @Z real_owner)))
 (let (($x398 (= @Z home)))
 (or $x398 $x425 $x804)))))
(assert
 (let (($x806 (not (__net.getX home @V0))))
 (let (($x449 (= @V0 real_owner)))
 (let (($x413 (= @V0 home)))
 (or $x413 $x449 $x806)))))
(assert
 (let (($x808 (not (__net.getX home @V1))))
 (let (($x429 (= @V1 real_owner)))
 (let (($x287 (= @V1 home)))
 (or $x287 $x429 $x808)))))
(assert
 (let (($x574 (not (net.put home @V0))))
 (let (($x407 (= home home)))
 (or $x407 $x574 dir.dirty))))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x576 dir.dirty))))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x578 dir.dirty))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let (($x407 (= home home)))
 (or $x407 $x625 dir.dirty))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let (($x407 (= home home)))
 (or $x407 $x779 dir.dirty))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let (($x407 (= home home)))
 (or $x407 $x783 dir.dirty))))
(assert
 (let (($x786 (not (net.put home home))))
 (let (($x407 (= home home)))
 (or $x407 $x786 dir.dirty))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let (($x407 (= home home)))
 (or $x407 $x790 dir.dirty))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x407 (= home home)))
 (or $x407 $x524 dir.head))))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x565 dir.head))))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x567 dir.head))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x407 (= home home)))
 (or $x407 $x620 dir.head))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x407 (= home home)))
 (or $x407 $x749 dir.head))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x407 (= home home)))
 (or $x407 $x752 dir.head))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x407 (= home home)))
 (or $x407 $x755 dir.head))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x407 (= home home)))
 (or $x407 $x758 dir.head))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x407 (= home home)))
 (or $x407 $x524 dir.dirty))))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x565 dir.dirty))))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x567 dir.dirty))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x407 (= home home)))
 (or $x407 $x620 dir.dirty))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x407 (= home home)))
 (or $x407 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x407 (= home home)))
 (or $x407 $x752 dir.dirty))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x407 (= home home)))
 (or $x407 $x755 dir.dirty))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x407 (= home home)))
 (or $x407 $x758 dir.dirty))))
(assert
 (let (($x524 (not (net.putX home @V0))))
 (let (($x407 (= home home)))
 (or $x407 $x524))))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x565))))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x567))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x407 (= home home)))
 (or $x407 $x620))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x407 (= home home)))
 (or $x407 $x749))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x407 (= home home)))
 (or $x407 $x752))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x407 (= home home)))
 (or $x407 $x755))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x407 (= home home)))
 (or $x407 $x758))))
(assert
 (let (($x580 (not (net.get home @Y))))
 (let (($x312 (= @Y home)))
 (or $x312 $x580 dir.head))))
(assert
 (let (($x582 (not (net.get home @Z))))
 (let (($x398 (= @Z home)))
 (or $x398 $x582 dir.head))))
(assert
 (let (($x584 (not (net.get home home))))
 (let (($x407 (= home home)))
 (or $x407 $x584 dir.head))))
(assert
 (let (($x586 (not (net.get home @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x586 dir.head))))
(assert
 (let (($x629 (not (net.get dir.hptr home))))
 (let (($x407 (= home home)))
 (or $x407 $x629 dir.head))))
(assert
 (let (($x635 (not (net.get @V0 home))))
 (let (($x407 (= home home)))
 (or $x407 $x635 dir.head))))
(assert
 (let (($x793 (not (net.get real_owner home))))
 (let (($x407 (= home home)))
 (or $x407 $x793 dir.head))))
(assert
 (let (($x796 (not (net.get @V1 home))))
 (let (($x407 (= home home)))
 (or $x407 $x796 dir.head))))
(assert
 (let (($x580 (not (net.get home @Y))))
 (let (($x312 (= @Y home)))
 (or $x312 $x580 dir.dirty))))
(assert
 (let (($x582 (not (net.get home @Z))))
 (let (($x398 (= @Z home)))
 (or $x398 $x582 dir.dirty))))
(assert
 (let (($x584 (not (net.get home home))))
 (let (($x407 (= home home)))
 (or $x407 $x584 dir.dirty))))
(assert
 (let (($x586 (not (net.get home @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x586 dir.dirty))))
(assert
 (let (($x629 (not (net.get dir.hptr home))))
 (let (($x407 (= home home)))
 (or $x407 $x629 dir.dirty))))
(assert
 (let (($x635 (not (net.get @V0 home))))
 (let (($x407 (= home home)))
 (or $x407 $x635 dir.dirty))))
(assert
 (let (($x793 (not (net.get real_owner home))))
 (let (($x407 (= home home)))
 (or $x407 $x793 dir.dirty))))
(assert
 (let (($x796 (not (net.get @V1 home))))
 (let (($x407 (= home home)))
 (or $x407 $x796 dir.dirty))))
(assert
 (let (($x761 (not (__net.getX home home))))
 (let (($x407 (= home home)))
 (or $x407 $x761 dir.head))))
(assert
 (let (($x764 (not (__net.getX @V1 home))))
 (let (($x407 (= home home)))
 (or $x407 $x764 dir.head))))
(assert
 (let (($x767 (not (__net.getX @V0 home))))
 (let (($x407 (= home home)))
 (or $x407 $x767 dir.head))))
(assert
 (let (($x804 (not (__net.getX home @Z))))
 (let (($x398 (= @Z home)))
 (or $x398 $x804 dir.head))))
(assert
 (let (($x806 (not (__net.getX home @V0))))
 (let (($x413 (= @V0 home)))
 (or $x413 $x806 dir.head))))
(assert
 (let (($x808 (not (__net.getX home @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x808 dir.head))))
(assert
 (let (($x761 (not (__net.getX home home))))
 (let (($x407 (= home home)))
 (or $x407 $x761 dir.dirty))))
(assert
 (let (($x764 (not (__net.getX @V1 home))))
 (let (($x407 (= home home)))
 (or $x407 $x764 dir.dirty))))
(assert
 (let (($x767 (not (__net.getX @V0 home))))
 (let (($x407 (= home home)))
 (or $x407 $x767 dir.dirty))))
(assert
 (let (($x804 (not (__net.getX home @Z))))
 (let (($x398 (= @Z home)))
 (or $x398 $x804 dir.dirty))))
(assert
 (let (($x806 (not (__net.getX home @V0))))
 (let (($x413 (= @V0 home)))
 (or $x413 $x806 dir.dirty))))
(assert
 (let (($x808 (not (__net.getX home @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x808 dir.dirty))))
(assert
 (let (($x761 (not (__net.getX home home))))
 (let (($x407 (= home home)))
 (or $x407 $x761))))
(assert
 (let (($x764 (not (__net.getX @V1 home))))
 (let (($x407 (= home home)))
 (or $x407 $x764))))
(assert
 (let (($x767 (not (__net.getX @V0 home))))
 (let (($x407 (= home home)))
 (or $x407 $x767))))
(assert
 (let (($x804 (not (__net.getX home @Z))))
 (let (($x398 (= @Z home)))
 (or $x398 $x804))))
(assert
 (let (($x806 (not (__net.getX home @V0))))
 (let (($x413 (= @V0 home)))
 (or $x413 $x806))))
(assert
 (let (($x808 (not (__net.getX home @V1))))
 (let (($x287 (= @V1 home)))
 (or $x287 $x808))))
(assert
 (let (($x761 (not (__net.getX home home))))
 (let (($x407 (= home home)))
 (let (($x504 (= home requester)))
 (or $x504 $x407 $x761)))))
(assert
 (let (($x764 (not (__net.getX @V1 home))))
 (let (($x407 (= home home)))
 (let (($x507 (= @V1 requester)))
 (or $x507 $x407 $x764)))))
(assert
 (let (($x767 (not (__net.getX @V0 home))))
 (let (($x407 (= home home)))
 (let (($x509 (= @V0 requester)))
 (or $x509 $x407 $x767)))))
(assert
 (let (($x804 (not (__net.getX home @Z))))
 (let (($x398 (= @Z home)))
 (let (($x504 (= home requester)))
 (or $x504 $x398 $x804)))))
(assert
 (let (($x806 (not (__net.getX home @V0))))
 (let (($x413 (= @V0 home)))
 (let (($x504 (= home requester)))
 (or $x504 $x413 $x806)))))
(assert
 (let (($x808 (not (__net.getX home @V1))))
 (let (($x287 (= @V1 home)))
 (let (($x504 (= home requester)))
 (or $x504 $x287 $x808)))))
(assert
 (let (($x774 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x774))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x913 (= dir.hptr dir.hptr)))
 (or $x913 $x620))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x915 (= real_owner dir.hptr)))
 (or $x915 $x749))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x917 (= @V1 dir.hptr)))
 (or $x917 $x752))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x526 (= home dir.hptr)))
 (or $x526 $x755))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x278 (= __src dir.hptr)))
 (or $x278 $x758))))
(assert
 (let (($x774 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x913 (= dir.hptr dir.hptr)))
 (or $x913 $x774))))
(assert
 (let (($x923 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x923))))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x565))))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x567))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x407 (= home home)))
 (or $x407 $x620))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x407 (= home home)))
 (or $x407 $x749))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x407 (= home home)))
 (or $x407 $x752))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x407 (= home home)))
 (or $x407 $x755))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x407 (= home home)))
 (or $x407 $x758))))
(assert
 (let (($x537 (not (= (cache.state_ @V0) shared))))
 (let (($x571 (not (rp_net @V0))))
 (or $x571 $x537))))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (let (($x541 (= real_owner @X)))
 (or $x541 $x565))))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (let (($x545 (= real_owner @V0)))
 (or $x545 $x567))))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (let (($x915 (= real_owner dir.hptr)))
 (or $x915 $x620))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x819 (= real_owner real_owner)))
 (or $x819 $x749))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x752)))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x755))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (or (= real_owner __src) $x758)))
(assert
 (let (($x574 (not (net.put home @V0))))
 (or $x574 dir.head)))
(assert
 (let (($x576 (not (net.put dir.hptr @X))))
 (or $x576 dir.head)))
(assert
 (let (($x578 (not (net.put dir.hptr @V0))))
 (or $x578 dir.head)))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (or $x625 dir.head)))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (or $x779 dir.head)))
(assert
 (let (($x783 (not (net.put home @V1))))
 (or $x783 dir.head)))
(assert
 (let (($x786 (not (net.put home home))))
 (or $x786 dir.head)))
(assert
 (let (($x790 (not (net.put home __src))))
 (or $x790 dir.head)))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (or $x565 dir.head)))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (or $x567 dir.head)))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (or $x620 dir.head)))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (or $x749 dir.head)))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (or $x752 dir.head)))
(assert
 (let (($x755 (not (net.putX home home))))
 (or $x755 dir.head)))
(assert
 (let (($x758 (not (net.putX home __src))))
 (or $x758 dir.head)))
(assert
 (let (($x565 (not (net.putX real_owner @X))))
 (or $x565 dir.dirty)))
(assert
 (let (($x567 (not (net.putX real_owner @V0))))
 (or $x567 dir.dirty)))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (or $x620 dir.dirty)))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (or $x749 dir.dirty)))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (or $x752 dir.dirty)))
(assert
 (let (($x755 (not (net.putX home home))))
 (or $x755 dir.dirty)))
(assert
 (let (($x758 (not (net.putX home __src))))
 (or $x758 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (not (net.putX real_owner __src)))
(assert
 (let (($x620 (not (net.putX home dir.hptr))))
 (or $x620 dir.head)))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (or $x749 dir.head)))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (or $x752 dir.head)))
(assert
 (let (($x755 (not (net.putX home home))))
 (or $x755 dir.head)))
(assert
 (let (($x758 (not (net.putX home __src))))
 (or $x758 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (not (net.putX home __src)))
(assert
 (let (($x571 (not (rp_net @V0))))
 (let (($x574 (not (net.put home @V0))))
 (or $x574 $x571))))
(assert
 (let (($x337 (not (rp_net @X))))
 (let (($x576 (not (net.put dir.hptr @X))))
 (or $x576 $x337))))
(assert
 (let (($x571 (not (rp_net @V0))))
 (let (($x578 (not (net.put dir.hptr @V0))))
 (or $x578 $x571))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (or $x625 (not (rp_net dir.hptr)))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (or $x779 (not (rp_net real_owner)))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (or $x783 (not (rp_net @V1)))))
(assert
 (let (($x786 (not (net.put home home))))
 (or $x786 (not (rp_net home)))))
(assert
 (let (($x790 (not (net.put home __src))))
 (or $x790 (not (rp_net __src)))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (let (($x588 (not (invack home))))
 (or $x588 (not (invnet home)))))
(assert
 (let (($x591 (not (invack @X))))
 (or $x591 (not (invnet @X)))))
(assert
 (let (($x594 (not (invack @V0))))
 (or $x594 (not (invnet @V0)))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x625 dir.pending))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x779 dir.pending))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x783 dir.pending))))
(assert
 (let (($x786 (not (net.put home home))))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x786 dir.pending))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let (($x1009 (dir.shlist __src)))
 (or $x1009 $x790 dir.pending))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x985 dir.pending))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x987 dir.pending))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x989 dir.pending))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x625 dir.dirty))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x779 dir.dirty))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x783 dir.dirty))))
(assert
 (let (($x786 (not (net.put home home))))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x786 dir.dirty))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let (($x1009 (dir.shlist __src)))
 (or $x1009 $x790 dir.dirty))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x985 dir.dirty))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x987 dir.dirty))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x989 dir.dirty))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x625))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x779))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x783))))
(assert
 (let (($x786 (not (net.put home home))))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x786))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let (($x1009 (dir.shlist __src)))
 (or $x1009 $x790))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x985))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x987))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x989))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x755))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x749))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x752))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x1009 (dir.shlist __src)))
 (or $x1009 $x758))))
(assert
 (let (($x786 (not (net.put home home))))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x786))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x779))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x783))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let (($x1009 (dir.shlist __src)))
 (or $x1009 $x790))))
(assert
 (let (($x584 (not (net.get home home))))
 (let (($x640 (dir.shlist home)))
 (let (($x1033 (not $x640)))
 (or $x1033 $x584)))))
(assert
 (let (($x793 (not (net.get real_owner home))))
 (let (($x1004 (dir.shlist real_owner)))
 (let (($x1035 (not $x1004)))
 (or $x1035 $x793)))))
(assert
 (let (($x796 (not (net.get @V1 home))))
 (let (($x1006 (dir.shlist @V1)))
 (let (($x1037 (not $x1006)))
 (or $x1037 $x796)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let (($x1009 (dir.shlist __src)))
 (let (($x1039 (not $x1009)))
 (or $x1039 $x801)))))
(assert
 (let (($x640 (dir.shlist home)))
 (let (($x1033 (not $x640)))
 (or $x1033 dir.head))))
(assert
 (let (($x1004 (dir.shlist real_owner)))
 (let (($x1035 (not $x1004)))
 (or $x1035 dir.head))))
(assert
 (let (($x1006 (dir.shlist @V1)))
 (let (($x1037 (not $x1006)))
 (or $x1037 dir.head))))
(assert
 (let (($x1009 (dir.shlist __src)))
 (let (($x1039 (not $x1009)))
 (or $x1039 dir.head))))
(assert
 (let (($x774 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x774))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let (($x818 (= real_owner home)))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x818 $x779)))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let (($x287 (= @V1 home)))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x287 $x783)))))
(assert
 (let (($x786 (not (net.put home home))))
 (let (($x407 (= home home)))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x407 $x786)))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let (($x1009 (dir.shlist __src)))
 (or $x1009 (= __src home) $x790))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let (($x652 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x652 $x985)))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let (($x818 (= real_owner home)))
 (let (($x1004 (dir.shlist real_owner)))
 (or $x1004 $x818 $x987)))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let (($x287 (= @V1 home)))
 (let (($x1006 (dir.shlist @V1)))
 (or $x1006 $x287 $x989)))))
(assert
 (let (($x991 (not (net.put dir.hptr home))))
 (let (($x407 (= home home)))
 (let (($x640 (dir.shlist home)))
 (or $x640 $x407 $x991)))))
(assert
 (let (($x774 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x1055 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1055 $x774)))))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x749))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x752))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x755))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x758))))
(assert
 (let (($x923 (not (= (cache.state_ dir.hptr) shared))))
 (or $x923 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x774 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x774 dir.head)))
(assert
 (let (($x749 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x747 (= ?x140 getX)))
 (or $x747 $x749)))))
(assert
 (let (($x752 (not (net.putX home @V1))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x699 (= ?x319 getX)))
 (or $x699 $x752)))))
(assert
 (let (($x755 (not (net.putX home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x755)))))
(assert
 (let (($x758 (not (net.putX home __src))))
 (let ((?x691 (cache.wait __src)))
 (let (($x692 (= ?x691 getX)))
 (or $x692 $x758)))))
(assert
 (let (($x958 (not (net.putX real_owner dir.hptr))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x689 (= ?x688 getX)))
 (or $x689 $x958)))))
(assert
 (let (($x960 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x747 (= ?x140 getX)))
 (or $x747 $x960)))))
(assert
 (let (($x962 (not (net.putX real_owner @V1))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x699 (= ?x319 getX)))
 (or $x699 $x962)))))
(assert
 (let (($x964 (not (net.putX real_owner home))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x964)))))
(assert
 (let (($x761 (not (__net.getX home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x761)))))
(assert
 (let (($x764 (not (__net.getX @V1 home))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x699 (= ?x319 getX)))
 (or $x699 $x764)))))
(assert
 (let (($x767 (not (__net.getX @V0 home))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x293 (= ?x292 getX)))
 (or $x293 $x767)))))
(assert
 (let (($x804 (not (__net.getX home @Z))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x804)))))
(assert
 (let (($x806 (not (__net.getX home @V0))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x806)))))
(assert
 (let (($x808 (not (__net.getX home @V1))))
 (let ((?x668 (cache.wait home)))
 (let (($x696 (= ?x668 getX)))
 (or $x696 $x808)))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x779)))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x781 (= ?x319 get)))
 (or $x781 $x783)))))
(assert
 (let (($x786 (not (net.put home home))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x786)))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let ((?x691 (cache.wait __src)))
 (let (($x788 (= ?x691 get)))
 (or $x788 $x790)))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x707 (= ?x688 get)))
 (or $x707 $x985)))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x987)))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x781 (= ?x319 get)))
 (or $x781 $x989)))))
(assert
 (let (($x991 (not (net.put dir.hptr home))))
 (let ((?x668 (cache.wait home)))
 (let (($x669 (= ?x668 get)))
 (or $x669 $x991)))))
(assert
 (let (($x629 (not (net.get dir.hptr home))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x707 (= ?x688 get)))
 (or $x707 $x629)))))
(assert
 (let (($x635 (not (net.get @V0 home))))
 (let ((?x292 (cache.wait @V0)))
 (let (($x302 (= ?x292 get)))
 (or $x302 $x635)))))
(assert
 (let (($x793 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x793)))))
(assert
 (let (($x796 (not (net.get @V1 home))))
 (let ((?x319 (cache.wait @V1)))
 (let (($x781 (= ?x319 get)))
 (or $x781 $x796)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let ((?x691 (cache.wait __src)))
 (let (($x788 (= ?x691 get)))
 (or $x788 $x801)))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (let ((?x1075 (cache.state_ real_owner)))
 (let (($x1076 (= ?x1075 invalid)))
 (or $x1076 $x779)))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (let ((?x1078 (cache.state_ @V1)))
 (let (($x1079 (= ?x1078 invalid)))
 (or $x1079 $x783)))))
(assert
 (let (($x786 (not (net.put home home))))
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (or $x658 $x786)))))
(assert
 (let (($x790 (not (net.put home __src))))
 (let ((?x1082 (cache.state_ __src)))
 (let (($x1083 (= ?x1082 invalid)))
 (or $x1083 $x790)))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let ((?x721 (cache.state_ dir.hptr)))
 (let (($x722 (= ?x721 invalid)))
 (or $x722 $x985)))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let ((?x1075 (cache.state_ real_owner)))
 (let (($x1076 (= ?x1075 invalid)))
 (or $x1076 $x987)))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let ((?x1078 (cache.state_ @V1)))
 (let (($x1079 (= ?x1078 invalid)))
 (or $x1079 $x989)))))
(assert
 (let (($x991 (not (net.put dir.hptr home))))
 (let ((?x274 (cache.state_ home)))
 (let (($x658 (= ?x274 invalid)))
 (or $x658 $x991)))))
(assert
 (let (($x629 (not (net.get dir.hptr home))))
 (let ((?x721 (cache.state_ dir.hptr)))
 (let (($x722 (= ?x721 invalid)))
 (or $x722 $x629)))))
(assert
 (let (($x635 (not (net.get @V0 home))))
 (let ((?x307 (cache.state_ @V0)))
 (let (($x308 (= ?x307 invalid)))
 (or $x308 $x635)))))
(assert
 (let (($x793 (not (net.get real_owner home))))
 (let ((?x1075 (cache.state_ real_owner)))
 (let (($x1076 (= ?x1075 invalid)))
 (or $x1076 $x793)))))
(assert
 (let (($x796 (not (net.get @V1 home))))
 (let ((?x1078 (cache.state_ @V1)))
 (let (($x1079 (= ?x1078 invalid)))
 (or $x1079 $x796)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let ((?x1082 (cache.state_ __src)))
 (let (($x1083 (= ?x1082 invalid)))
 (or $x1083 $x801)))))
(assert
 (let (($x740 (not (= (cache.wait home) none))))
 (let (($x761 (not (__net.getX home home))))
 (or $x761 $x740))))
(assert
 (let (($x321 (not (= (cache.wait @V1) none))))
 (let (($x764 (not (__net.getX @V1 home))))
 (or $x764 $x321))))
(assert
 (let (($x745 (not (= (cache.wait @V0) none))))
 (let (($x767 (not (__net.getX @V0 home))))
 (or $x767 $x745))))
(assert
 (let (($x740 (not (= (cache.wait home) none))))
 (let (($x804 (not (__net.getX home @Z))))
 (or $x804 $x740))))
(assert
 (let (($x740 (not (= (cache.wait home) none))))
 (let (($x806 (not (__net.getX home @V0))))
 (or $x806 $x740))))
(assert
 (let (($x740 (not (= (cache.wait home) none))))
 (let (($x808 (not (__net.getX home @V1))))
 (or $x808 $x740))))
(assert
 (let (($x1101 (not (__net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x747 (= ?x140 getX)))
 (or $x747 $x1101)))))
(assert
 (let (($x1104 (not (__net.getX dir.hptr home))))
 (let ((?x688 (cache.wait dir.hptr)))
 (let (($x689 (= ?x688 getX)))
 (or $x689 $x1104)))))
(assert
 (let (($x1107 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1107 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1111 (not (= (cache.state_ @V1) exclusive))))
 (or $x1111 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x1115 (not (= (cache.state_ __src) exclusive))))
 (or $x1115 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x625 (not (net.put home dir.hptr))))
 (or $x625 (not (rp_net dir.hptr)))))
(assert
 (let (($x779 (not (net.put home real_owner))))
 (or $x779 (not (rp_net real_owner)))))
(assert
 (let (($x783 (not (net.put home @V1))))
 (or $x783 (not (rp_net @V1)))))
(assert
 (let (($x786 (not (net.put home home))))
 (or $x786 (not (rp_net home)))))
(assert
 (let (($x790 (not (net.put home __src))))
 (or $x790 (not (rp_net __src)))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x985)))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x987)))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x989)))))
(assert
 (let (($x991 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x991)))))
(assert
 (let (($x993 (not (net.put dir.hptr __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x993)))))
(assert
 (let (($x958 (not (net.putX real_owner dir.hptr))))
 (let (($x819 (= real_owner real_owner)))
 (let (($x818 (= real_owner home)))
 (or $x818 $x819 $x958)))))
(assert
 (let (($x960 (not (net.putX real_owner real_owner))))
 (let (($x819 (= real_owner real_owner)))
 (let (($x818 (= real_owner home)))
 (or $x818 $x819 $x960)))))
(assert
 (let (($x962 (not (net.putX real_owner @V1))))
 (let (($x819 (= real_owner real_owner)))
 (let (($x818 (= real_owner home)))
 (or $x818 $x819 $x962)))))
(assert
 (let (($x964 (not (net.putX real_owner home))))
 (let (($x819 (= real_owner real_owner)))
 (let (($x818 (= real_owner home)))
 (or $x818 $x819 $x964)))))
(assert
 (let (($x966 (not (net.putX real_owner __src))))
 (let (($x819 (= real_owner real_owner)))
 (let (($x818 (= real_owner home)))
 (or $x818 $x819 $x966)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x801)))))
(assert
 (let (($x1101 (not (__net.getX real_owner home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x1101)))))
(assert
 (let (($x1104 (not (__net.getX dir.hptr home))))
 (let (($x427 (= home real_owner)))
 (let (($x407 (= home home)))
 (or $x407 $x427 $x1104)))))
(assert
 (let (($x985 (not (net.put dir.hptr dir.hptr))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x985 dir.dirty))))
(assert
 (let (($x987 (not (net.put dir.hptr real_owner))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x987 dir.dirty))))
(assert
 (let (($x989 (not (net.put dir.hptr @V1))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x989 dir.dirty))))
(assert
 (let (($x991 (not (net.put dir.hptr home))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x991 dir.dirty))))
(assert
 (let (($x993 (not (net.put dir.hptr __src))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x993 dir.dirty))))
(assert
 (let (($x958 (not (net.putX real_owner dir.hptr))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x958 dir.head))))
(assert
 (let (($x960 (not (net.putX real_owner real_owner))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x960 dir.head))))
(assert
 (let (($x962 (not (net.putX real_owner @V1))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x962 dir.head))))
(assert
 (let (($x964 (not (net.putX real_owner home))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x964 dir.head))))
(assert
 (let (($x966 (not (net.putX real_owner __src))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x966 dir.head))))
(assert
 (let (($x958 (not (net.putX real_owner dir.hptr))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x958 dir.dirty))))
(assert
 (let (($x960 (not (net.putX real_owner real_owner))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x960 dir.dirty))))
(assert
 (let (($x962 (not (net.putX real_owner @V1))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x962 dir.dirty))))
(assert
 (let (($x964 (not (net.putX real_owner home))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x964 dir.dirty))))
(assert
 (let (($x966 (not (net.putX real_owner __src))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x966 dir.dirty))))
(assert
 (let (($x958 (not (net.putX real_owner dir.hptr))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x958))))
(assert
 (let (($x960 (not (net.putX real_owner real_owner))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x960))))
(assert
 (let (($x962 (not (net.putX real_owner @V1))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x962))))
(assert
 (let (($x964 (not (net.putX real_owner home))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x964))))
(assert
 (let (($x966 (not (net.putX real_owner __src))))
 (let (($x818 (= real_owner home)))
 (or $x818 $x966))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let (($x407 (= home home)))
 (or $x407 $x801 dir.head))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let (($x407 (= home home)))
 (or $x407 $x801 dir.dirty))))
(assert
 (let (($x1101 (not (__net.getX real_owner home))))
 (let (($x407 (= home home)))
 (or $x407 $x1101 dir.head))))
(assert
 (let (($x1104 (not (__net.getX dir.hptr home))))
 (let (($x407 (= home home)))
 (or $x407 $x1104 dir.head))))
(assert
 (let (($x1101 (not (__net.getX real_owner home))))
 (let (($x407 (= home home)))
 (or $x407 $x1101 dir.dirty))))
(assert
 (let (($x1104 (not (__net.getX dir.hptr home))))
 (let (($x407 (= home home)))
 (or $x407 $x1104 dir.dirty))))
(assert
 (let (($x1101 (not (__net.getX real_owner home))))
 (let (($x407 (= home home)))
 (or $x407 $x1101))))
(assert
 (let (($x1104 (not (__net.getX dir.hptr home))))
 (let (($x407 (= home home)))
 (or $x407 $x1104))))
(assert
 (let (($x1101 (not (__net.getX real_owner home))))
 (let (($x407 (= home home)))
 (or (= real_owner requester) $x407 $x1101))))
(assert
 (let (($x1104 (not (__net.getX dir.hptr home))))
 (let (($x407 (= home home)))
 (let (($x1055 (= dir.hptr requester)))
 (or $x1055 $x407 $x1104)))))
(assert
 (let (($x1107 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x819 (= real_owner real_owner)))
 (or $x819 $x1107))))
(assert
 (let (($x1111 (not (= (cache.state_ @V1) exclusive))))
 (let (($x429 (= @V1 real_owner)))
 (or $x429 $x1111))))
(assert
 (let (($x1115 (not (= (cache.state_ __src) exclusive))))
 (or (= __src real_owner) $x1115)))
(assert
 (let (($x1107 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x915 (= real_owner dir.hptr)))
 (or $x915 $x1107))))
(assert
 (let (($x1111 (not (= (cache.state_ @V1) exclusive))))
 (let (($x917 (= @V1 dir.hptr)))
 (or $x917 $x1111))))
(assert
 (let (($x1115 (not (= (cache.state_ __src) exclusive))))
 (let (($x278 (= __src dir.hptr)))
 (or $x278 $x1115))))
(assert
 (let (($x819 (= real_owner real_owner)))
 (or $x819 (not (= (cache.state_ real_owner) shared)))))
(assert
 (let (($x429 (= @V1 real_owner)))
 (or $x429 (not (= (cache.state_ @V1) shared)))))
(check-sat)
