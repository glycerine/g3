(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun nakc () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__net.get __src __dst))
(assert
 (not (= __dst __src)))
(assert
 (let (($x275 (= __dst home)))
 (not $x275)))
(assert
 (not (= (cache.state_ __dst) exclusive)))
(assert
 nakc)
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x373 (not (net.getX home @Y))))
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x361 (= @Y @Z)))
 (let (($x374 (and (or $x361 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x361 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x361 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x361 $x360 $x352) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x352 (not (net.putX @Y @X))) $x373 $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x335 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x374)))))))))))
(assert
 (let (($x398 (__net.get @X @Y)))
 (let (($x366 (net.get @X @Y)))
 (= $x366 (ite (and (= @X __src) (= @Y __dst)) false $x398)))))
(assert
 (let (($x403 (__net.get @X @Z)))
 (let (($x356 (net.get @X @Z)))
 (= $x356 (ite (and (= @X __src) (= @Z __dst)) false $x403)))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x345 (net.get @X home)))
 (= $x345 (ite (and (= @X __src) (= home __dst)) false $x408)))))
(assert
 (let (($x414 (__net.get @V0 @V1)))
 (let (($x306 (net.get @V0 @V1)))
 (= $x306 (ite (and (= @V0 __src) (= @V1 __dst)) false $x414)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x417 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x417 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x420 (= @Z real_owner)))
 (let (($x419 (= @Z home)))
 (or $x419 $x420 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x425 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x425 $x303)))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x417 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x417 $x349)))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x420 (= @Z real_owner)))
 (let (($x419 (= @Z home)))
 (or $x419 $x420 $x364)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x425 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x425 $x297)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x432 (not $x272)))
 (let (($x431 (= __dst real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x431 $x432))))))
(assert
 (let (($x398 (__net.get @X @Y)))
 (let (($x434 (not $x398)))
 (let (($x417 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x417 $x434))))))
(assert
 (let (($x403 (__net.get @X @Z)))
 (let (($x436 (not $x403)))
 (let (($x420 (= @Z real_owner)))
 (let (($x419 (= @Z home)))
 (or $x419 $x420 $x436))))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x438 (not $x408)))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x438))))))
(assert
 (let (($x414 (__net.get @V0 @V1)))
 (let (($x440 (not $x414)))
 (let (($x425 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x425 $x440))))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x417 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x417 $x360)))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x420 (= @Z real_owner)))
 (let (($x419 (= @Z home)))
 (or $x419 $x420 $x352)))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x417 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x417 $x373)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x447 (= @V0 real_owner)))
 (let (($x446 (= @V0 home)))
 (or $x446 $x447 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x425 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x425 $x300)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x355 dir.dirty))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x419 (= @Z home)))
 (or $x419 $x370 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x422 (= home home)))
 (or $x422 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x303 dir.dirty))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349 dir.head))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x419 (= @Z home)))
 (or $x419 $x364 dir.head))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x422 (= home home)))
 (or $x422 $x326 dir.head))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.head))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349 dir.dirty))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x419 (= @Z home)))
 (or $x419 $x364 dir.dirty))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x422 (= home home)))
 (or $x422 $x326 dir.dirty))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.dirty))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x419 (= @Z home)))
 (or $x419 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x422 (= home home)))
 (or $x422 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x432 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x432 dir.head)))))
(assert
 (let (($x398 (__net.get @X @Y)))
 (let (($x434 (not $x398)))
 (let (($x314 (= @Y home)))
 (or $x314 $x434 dir.head)))))
(assert
 (let (($x403 (__net.get @X @Z)))
 (let (($x436 (not $x403)))
 (let (($x419 (= @Z home)))
 (or $x419 $x436 dir.head)))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x438 (not $x408)))
 (let (($x422 (= home home)))
 (or $x422 $x438 dir.head)))))
(assert
 (let (($x414 (__net.get @V0 @V1)))
 (let (($x440 (not $x414)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x440 dir.head)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x432 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x432 dir.dirty)))))
(assert
 (let (($x398 (__net.get @X @Y)))
 (let (($x434 (not $x398)))
 (let (($x314 (= @Y home)))
 (or $x314 $x434 dir.dirty)))))
(assert
 (let (($x403 (__net.get @X @Z)))
 (let (($x436 (not $x403)))
 (let (($x419 (= @Z home)))
 (or $x419 $x436 dir.dirty)))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x438 (not $x408)))
 (let (($x422 (= home home)))
 (or $x422 $x438 dir.dirty)))))
(assert
 (let (($x414 (__net.get @V0 @V1)))
 (let (($x440 (not $x414)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x440 dir.dirty)))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x360 dir.head))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x352 dir.head))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x373 dir.head))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x422 (= home home)))
 (or $x422 $x331 dir.head))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x446 (= @V0 home)))
 (or $x446 $x320 dir.head))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300 dir.head))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x360 dir.dirty))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x352 dir.dirty))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x373 dir.dirty))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x422 (= home home)))
 (or $x422 $x331 dir.dirty))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x446 (= @V0 home)))
 (or $x446 $x320 dir.dirty))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300 dir.dirty))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x360))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x352))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x373))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x422 (= home home)))
 (or $x422 $x331))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x446 (= @V0 home)))
 (or $x446 $x320))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (let (($x494 (= @X requester)))
 (or $x494 $x314 $x360)))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x419 (= @Z home)))
 (let (($x494 (= @X requester)))
 (or $x494 $x419 $x352)))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (let (($x497 (= home requester)))
 (or $x497 $x314 $x373)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x422 (= home home)))
 (let (($x494 (= @X requester)))
 (or $x494 $x422 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x446 (= @V0 home)))
 (let (($x500 (= @V1 requester)))
 (or $x500 $x446 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x502 (= @V0 requester)))
 (or $x502 $x289 $x300)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x447 (= @V0 real_owner)))
 (or $x447 $x292))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x431 (= __dst real_owner)))
 (or $x431 $x279))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x508 (= @X real_owner)))
 (or $x508 $x335))))
(assert
 (let (($x511 (not (= (cache.state_ @V0) exclusive))))
 (let (($x447 (= @V0 real_owner)))
 (or $x447 $x511))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x513 (= @X dir.hptr)))
 (or $x513 $x326))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x515 (= @V0 dir.hptr)))
 (or $x515 $x517))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x519 (= __dst dir.hptr)))
 (or $x519 $x279))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x513 (= @X dir.hptr)))
 (or $x513 $x335))))
(assert
 (let (($x511 (not (= (cache.state_ @V0) exclusive))))
 (let (($x515 (= @V0 dir.hptr)))
 (or $x515 $x511))))
(assert
 (let (($x524 (not (= (cache.state_ __dst) shared))))
 (let (($x431 (= __dst real_owner)))
 (or $x431 $x524))))
(assert
 (let (($x527 (not (= (cache.state_ @X) shared))))
 (let (($x508 (= @X real_owner)))
 (or $x508 $x527))))
(assert
 (let (($x530 (not (= (cache.state_ @V0) shared))))
 (let (($x447 (= @V0 real_owner)))
 (or $x447 $x530))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x419 (= @Z home)))
 (or $x419 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x422 (= home home)))
 (or $x422 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x422 (= home home)))
 (or $x422 $x517))))
(assert
 (let (($x527 (not (= (cache.state_ @X) shared))))
 (let (($x339 (not (rp_net @X))))
 (or $x339 $x527))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x534 (= real_owner @X)))
 (or $x534 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x534 (= real_owner @X)))
 (or $x534 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x534 (= real_owner @X)))
 (or $x534 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x538 (= real_owner @V0)))
 (or $x538 $x297))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x538 (= real_owner @V0)))
 (or $x538 $x517))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (or $x355 dir.head)))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (or $x370 dir.head)))
(assert
 (let (($x341 (not (net.put home @X))))
 (or $x341 dir.head)))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 dir.head)))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (or $x349 dir.head)))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (or $x364 dir.head)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.head)))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (or $x517 dir.head)))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (or $x349 dir.dirty)))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (or $x364 dir.dirty)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.dirty)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.dirty)))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (or $x517 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (or $x517 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x355 (not (net.put @Y @X))))
 (or $x355 $x339))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x370 (not (net.put @Z @X))))
 (or $x370 $x339))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x339))))
(assert
 (let (($x564 (not (rp_net @V0))))
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 $x564))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (__net.get home __dst)))
(assert
 (not (__net.get home @Y)))
(assert
 (not (__net.get home @Z)))
(assert
 (not (__net.get home home)))
(assert
 (not (__net.get home @V1)))
(assert
 (let (($x524 (not (= (cache.state_ __dst) shared))))
 (let (($x583 (not (invack __dst))))
 (or $x583 $x524))))
(assert
 (let (($x527 (not (= (cache.state_ @X) shared))))
 (let (($x586 (not (invack @X))))
 (or $x586 $x527))))
(assert
 (let (($x530 (not (= (cache.state_ @V0) shared))))
 (let (($x589 (not (invack @V0))))
 (or $x589 $x530))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x355 dir.pending))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x370 dir.pending))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x341 dir.pending))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x303 dir.pending))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x567 dir.pending))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x569 dir.pending))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x571 dir.pending))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x355 dir.dirty))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x370 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x303 dir.dirty))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x567 dir.dirty))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x569 dir.dirty))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x571 dir.dirty))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x355))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x370))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x341))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x303))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x567))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x569))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x571))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x615))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x326))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x517))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x620))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x341))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x567))))
(assert
 (let (($x624 (not (__net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x622 (not $x58)))
 (or $x622 $x624)))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x438 (not $x408)))
 (let (($x591 (dir.shlist @X)))
 (let (($x626 (not $x591)))
 (or $x626 $x438))))))
(assert
 (let (($x630 (not (__net.get @V0 home))))
 (let (($x595 (dir.shlist @V0)))
 (let (($x628 (not $x595)))
 (or $x628 $x630)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x622 (not $x58)))
 (or $x622 dir.head))))
(assert
 (let (($x591 (dir.shlist @X)))
 (let (($x626 (not $x591)))
 (or $x626 dir.head))))
(assert
 (let (($x595 (dir.shlist @V0)))
 (let (($x628 (not $x595)))
 (or $x628 dir.head))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x279))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x335))))
(assert
 (let (($x511 (not (= (cache.state_ @V0) exclusive))))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x511))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x639 (= @X home)))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x639 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x639 (= @X home)))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x639 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x639 (= @X home)))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x639 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x446 (= @V0 home)))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x446 $x303)))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let (($x446 (= @V0 home)))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x446 $x567)))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let (($x639 (= @X home)))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x639 $x569)))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let (($x446 (= @V0 home)))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x446 $x571)))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let (($x647 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x647 $x620)))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x649 (= __dst requester)))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x649 $x279)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x494 (= @X requester)))
 (let (($x591 (dir.shlist @X)))
 (or $x591 $x494 $x335)))))
(assert
 (let (($x511 (not (= (cache.state_ @V0) exclusive))))
 (let (($x502 (= @V0 requester)))
 (let (($x595 (dir.shlist @V0)))
 (or $x595 $x502 $x511)))))
(assert
 (let ((?x277 (cache.state_ __dst)))
 (let (($x654 (= ?x277 invalid)))
 (let (($x431 (= __dst real_owner)))
 (or (dir.real __dst) $x431 $x654)))))
(assert
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (let (($x508 (= @X real_owner)))
 (or (dir.real @X) $x508 $x657)))))
(assert
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (let (($x447 (= @V0 real_owner)))
 (or (dir.real @V0) $x447 $x310)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x326))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x517))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x615))))
(assert
 (let (($x524 (not (= (cache.state_ __dst) shared))))
 (or $x524 (not (= (cache.wait __dst) get)))))
(assert
 (let (($x527 (not (= (cache.state_ @X) shared))))
 (or $x527 (not (= (cache.wait @X) get)))))
(assert
 (let (($x530 (not (= (cache.state_ @V0) shared))))
 (or $x530 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x583 (not (invack __dst))))
 (let ((?x277 (cache.state_ __dst)))
 (let (($x654 (= ?x277 invalid)))
 (or $x654 $x583)))))
(assert
 (let (($x586 (not (invack @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x586)))))
(assert
 (let (($x589 (not (invack @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x589)))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (or $x279 dir.head)))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 dir.head)))
(assert
 (let (($x511 (not (= (cache.state_ @V0) exclusive))))
 (or $x511 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x422 (= home home)))
 (or $x422 $x187))))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x292))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x349)))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x364)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x297)))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x517)))))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x558)))))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x560)))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x685 (= ?x684 getX)))
 (or $x685 $x615)))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x360)))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x352)))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let ((?x689 (cache.wait home)))
 (let (($x690 (= ?x689 getX)))
 (or $x690 $x373)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x692 (= ?x321 getX)))
 (or $x692 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x300)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x303)))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x567)))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x569)))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x571)))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x699 (= ?x684 get)))
 (or $x699 $x620)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x432 (not $x272)))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 get)))
 (or $x702 $x432))))))
(assert
 (let (($x398 (__net.get @X @Y)))
 (let (($x434 (not $x398)))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x434))))))
(assert
 (let (($x403 (__net.get @X @Z)))
 (let (($x436 (not $x403)))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x436))))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x438 (not $x408)))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x438))))))
(assert
 (let (($x414 (__net.get @V0 @V1)))
 (let (($x440 (not $x414)))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x440))))))
(assert
 (let (($x573 (not (__net.get home __dst))))
 (let ((?x689 (cache.wait home)))
 (let (($x708 (= ?x689 get)))
 (or $x708 $x573)))))
(assert
 (let (($x575 (not (__net.get home @Y))))
 (let ((?x689 (cache.wait home)))
 (let (($x708 (= ?x689 get)))
 (or $x708 $x575)))))
(assert
 (let (($x577 (not (__net.get home @Z))))
 (let ((?x689 (cache.wait home)))
 (let (($x708 (= ?x689 get)))
 (or $x708 $x577)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x303)))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x567)))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x569)))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x571)))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let ((?x718 (cache.state_ dir.hptr)))
 (let (($x719 (= ?x718 invalid)))
 (or $x719 $x620)))))
(assert
 (let (($x272 (__net.get __src __dst)))
 (let (($x432 (not $x272)))
 (let ((?x721 (cache.state_ __src)))
 (let (($x722 (= ?x721 invalid)))
 (or $x722 $x432))))))
(assert
 (let (($x398 (__net.get @X @Y)))
 (let (($x434 (not $x398)))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x434))))))
(assert
 (let (($x403 (__net.get @X @Z)))
 (let (($x436 (not $x403)))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x436))))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x438 (not $x408)))
 (let ((?x333 (cache.state_ @X)))
 (let (($x657 (= ?x333 invalid)))
 (or $x657 $x438))))))
(assert
 (let (($x414 (__net.get @V0 @V1)))
 (let (($x440 (not $x414)))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x440))))))
(assert
 (let (($x573 (not (__net.get home __dst))))
 (let ((?x728 (cache.state_ home)))
 (let (($x729 (= ?x728 invalid)))
 (or $x729 $x573)))))
(assert
 (let (($x575 (not (__net.get home @Y))))
 (let ((?x728 (cache.state_ home)))
 (let (($x729 (= ?x728 invalid)))
 (or $x729 $x575)))))
(assert
 (let (($x577 (not (__net.get home @Z))))
 (let ((?x728 (cache.state_ home)))
 (let (($x729 (= ?x728 invalid)))
 (or $x729 $x577)))))
(assert
 (let (($x314 (= @Y home)))
 (or $x314 (not (net.shwb @X @Y)))))
(assert
 (let (($x422 (= home home)))
 (or $x422 (not (net.shwb @X home)))))
(assert
 (let (($x735 (not (= (cache.wait @X) none))))
 (let (($x360 (not (net.getX @X @Y))))
 (or $x360 $x735))))
(assert
 (let (($x735 (not (= (cache.wait @X) none))))
 (let (($x352 (not (net.getX @X @Z))))
 (or $x352 $x735))))
(assert
 (let (($x739 (not (= (cache.wait home) none))))
 (let (($x373 (not (net.getX home @Y))))
 (or $x373 $x739))))
(assert
 (let (($x735 (not (= (cache.wait @X) none))))
 (let (($x331 (not (net.getX @X home))))
 (or $x331 $x735))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x320 (not (net.getX @V1 @V0))))
 (or $x320 $x323))))
(assert
 (let (($x743 (not (= (cache.wait @V0) none))))
 (let (($x300 (not (net.getX @V0 @V1))))
 (or $x300 $x743))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x517)))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x685 (= ?x684 getX)))
 (or $x685 $x615)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x331)))))
(assert
 (let (($x746 (not (net.getX home home))))
 (let ((?x689 (cache.wait home)))
 (let (($x690 (= ?x689 getX)))
 (or $x690 $x746)))))
(assert
 (let (($x749 (not (net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x692 (= ?x321 getX)))
 (or $x692 $x749)))))
(assert
 (let (($x752 (not (net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x752)))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (or $x279 (not (= (cache.wait __dst) getX)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x511 (not (= (cache.state_ @V0) exclusive))))
 (or $x511 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x760 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x760 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x764 (not (= (cache.state_ __src) exclusive))))
 (or $x764 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x769 (not (= (cache.state_ home) exclusive))))
 (or $x769 (not (= (cache.wait home) getX)))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x339))))
(assert
 (let (($x564 (not (rp_net @V0))))
 (let (($x567 (not (net.put home @V0))))
 (or $x567 $x564))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x567)))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x699 (= ?x684 get)))
 (or $x699 $x620)))))
(assert
 (let (($x774 (not (__net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x774)))))
(assert
 (let (($x408 (__net.get @X home)))
 (let (($x438 (not $x408)))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x438))))))
(assert
 (let (($x778 (not (__net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x776 (= ?x321 get)))
 (or $x776 $x778)))))
(assert
 (let (($x630 (not (__net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x630)))))
(assert
 (let (($x782 (not (__net.get __dst home))))
 (let ((?x664 (cache.wait __dst)))
 (let (($x665 (= ?x664 get)))
 (or $x665 $x782)))))
(assert
 (let (($x624 (not (__net.get dir.hptr home))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x699 (= ?x684 get)))
 (or $x699 $x624)))))
(assert
 (let (($x579 (not (__net.get home home))))
 (let ((?x689 (cache.wait home)))
 (let (($x708 (= ?x689 get)))
 (or $x708 $x579)))))
(assert
 (let (($x787 (not (__net.get __src home))))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 get)))
 (or $x702 $x787)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x567)))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x647 (= dir.hptr home)))
 (or $x647 $x145 $x569)))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x647 (= dir.hptr home)))
 (or $x647 $x145 $x571)))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x620)))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x517)))))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (let (($x801 (= real_owner real_owner)))
 (let (($x800 (= real_owner home)))
 (or $x800 $x801 $x558)))))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (let (($x801 (= real_owner real_owner)))
 (let (($x800 (= real_owner home)))
 (or $x800 $x801 $x560)))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x615)))))
(assert
 (let (($x573 (not (__net.get home __dst))))
 (let (($x431 (= __dst real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x431 $x573)))))
(assert
 (let (($x575 (not (__net.get home @Y))))
 (let (($x417 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x417 $x575)))))
(assert
 (let (($x577 (not (__net.get home @Z))))
 (let (($x420 (= @Z real_owner)))
 (let (($x419 (= @Z home)))
 (or $x419 $x420 $x577)))))
(assert
 (let (($x579 (not (__net.get home home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x579)))))
(assert
 (let (($x581 (not (__net.get home @V1))))
 (let (($x425 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x425 $x581)))))
(assert
 (let (($x624 (not (__net.get dir.hptr home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x624)))))
(assert
 (let (($x630 (not (__net.get @V0 home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x630)))))
(assert
 (let (($x774 (not (__net.get real_owner home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x774)))))
(assert
 (let (($x746 (not (net.getX home home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x746)))))
(assert
 (let (($x749 (not (net.getX @V1 home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x749)))))
(assert
 (let (($x752 (not (net.getX @V0 home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x752)))))
(assert
 (let (($x790 (not (net.getX home @Z))))
 (let (($x420 (= @Z real_owner)))
 (let (($x419 (= @Z home)))
 (or $x419 $x420 $x790)))))
(assert
 (let (($x792 (not (net.getX home @V0))))
 (let (($x447 (= @V0 real_owner)))
 (let (($x446 (= @V0 home)))
 (or $x446 $x447 $x792)))))
(assert
 (let (($x794 (not (net.getX home @V1))))
 (let (($x425 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x425 $x794)))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (let (($x422 (= home home)))
 (or $x422 $x567 dir.dirty))))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (let (($x647 (= dir.hptr home)))
 (or $x647 $x569 dir.dirty))))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (let (($x647 (= dir.hptr home)))
 (or $x647 $x571 dir.dirty))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let (($x422 (= home home)))
 (or $x422 $x620 dir.dirty))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x422 (= home home)))
 (or $x422 $x517 dir.head))))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x558 dir.head))))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x560 dir.head))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x422 (= home home)))
 (or $x422 $x615 dir.head))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x422 (= home home)))
 (or $x422 $x517 dir.dirty))))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x558 dir.dirty))))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x560 dir.dirty))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x422 (= home home)))
 (or $x422 $x615 dir.dirty))))
(assert
 (let (($x517 (not (net.putX home @V0))))
 (let (($x422 (= home home)))
 (or $x422 $x517))))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x558))))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x560))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x422 (= home home)))
 (or $x422 $x615))))
(assert
 (let (($x573 (not (__net.get home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x573 dir.head))))
(assert
 (let (($x575 (not (__net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x575 dir.head))))
(assert
 (let (($x577 (not (__net.get home @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x577 dir.head))))
(assert
 (let (($x579 (not (__net.get home home))))
 (let (($x422 (= home home)))
 (or $x422 $x579 dir.head))))
(assert
 (let (($x581 (not (__net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x581 dir.head))))
(assert
 (let (($x624 (not (__net.get dir.hptr home))))
 (let (($x422 (= home home)))
 (or $x422 $x624 dir.head))))
(assert
 (let (($x630 (not (__net.get @V0 home))))
 (let (($x422 (= home home)))
 (or $x422 $x630 dir.head))))
(assert
 (let (($x774 (not (__net.get real_owner home))))
 (let (($x422 (= home home)))
 (or $x422 $x774 dir.head))))
(assert
 (let (($x573 (not (__net.get home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x573 dir.dirty))))
(assert
 (let (($x575 (not (__net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x575 dir.dirty))))
(assert
 (let (($x577 (not (__net.get home @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x577 dir.dirty))))
(assert
 (let (($x579 (not (__net.get home home))))
 (let (($x422 (= home home)))
 (or $x422 $x579 dir.dirty))))
(assert
 (let (($x581 (not (__net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x581 dir.dirty))))
(assert
 (let (($x624 (not (__net.get dir.hptr home))))
 (let (($x422 (= home home)))
 (or $x422 $x624 dir.dirty))))
(assert
 (let (($x630 (not (__net.get @V0 home))))
 (let (($x422 (= home home)))
 (or $x422 $x630 dir.dirty))))
(assert
 (let (($x774 (not (__net.get real_owner home))))
 (let (($x422 (= home home)))
 (or $x422 $x774 dir.dirty))))
(assert
 (let (($x746 (not (net.getX home home))))
 (let (($x422 (= home home)))
 (or $x422 $x746 dir.head))))
(assert
 (let (($x749 (not (net.getX @V1 home))))
 (let (($x422 (= home home)))
 (or $x422 $x749 dir.head))))
(assert
 (let (($x752 (not (net.getX @V0 home))))
 (let (($x422 (= home home)))
 (or $x422 $x752 dir.head))))
(assert
 (let (($x790 (not (net.getX home @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x790 dir.head))))
(assert
 (let (($x792 (not (net.getX home @V0))))
 (let (($x446 (= @V0 home)))
 (or $x446 $x792 dir.head))))
(assert
 (let (($x794 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x794 dir.head))))
(assert
 (let (($x746 (not (net.getX home home))))
 (let (($x422 (= home home)))
 (or $x422 $x746 dir.dirty))))
(assert
 (let (($x749 (not (net.getX @V1 home))))
 (let (($x422 (= home home)))
 (or $x422 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.getX @V0 home))))
 (let (($x422 (= home home)))
 (or $x422 $x752 dir.dirty))))
(assert
 (let (($x790 (not (net.getX home @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x790 dir.dirty))))
(assert
 (let (($x792 (not (net.getX home @V0))))
 (let (($x446 (= @V0 home)))
 (or $x446 $x792 dir.dirty))))
(assert
 (let (($x794 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x794 dir.dirty))))
(assert
 (let (($x746 (not (net.getX home home))))
 (let (($x422 (= home home)))
 (or $x422 $x746))))
(assert
 (let (($x749 (not (net.getX @V1 home))))
 (let (($x422 (= home home)))
 (or $x422 $x749))))
(assert
 (let (($x752 (not (net.getX @V0 home))))
 (let (($x422 (= home home)))
 (or $x422 $x752))))
(assert
 (let (($x790 (not (net.getX home @Z))))
 (let (($x419 (= @Z home)))
 (or $x419 $x790))))
(assert
 (let (($x792 (not (net.getX home @V0))))
 (let (($x446 (= @V0 home)))
 (or $x446 $x792))))
(assert
 (let (($x794 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x794))))
(assert
 (let (($x746 (not (net.getX home home))))
 (let (($x422 (= home home)))
 (let (($x497 (= home requester)))
 (or $x497 $x422 $x746)))))
(assert
 (let (($x749 (not (net.getX @V1 home))))
 (let (($x422 (= home home)))
 (let (($x500 (= @V1 requester)))
 (or $x500 $x422 $x749)))))
(assert
 (let (($x752 (not (net.getX @V0 home))))
 (let (($x422 (= home home)))
 (let (($x502 (= @V0 requester)))
 (or $x502 $x422 $x752)))))
(assert
 (let (($x790 (not (net.getX home @Z))))
 (let (($x419 (= @Z home)))
 (let (($x497 (= home requester)))
 (or $x497 $x419 $x790)))))
(assert
 (let (($x792 (not (net.getX home @V0))))
 (let (($x446 (= @V0 home)))
 (let (($x497 (= home requester)))
 (or $x497 $x446 $x792)))))
(assert
 (let (($x794 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x497 (= home requester)))
 (or $x497 $x289 $x794)))))
(assert
 (let (($x760 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x760))))
(assert
 (let (($x764 (not (= (cache.state_ __src) exclusive))))
 (let (($x875 (= __src real_owner)))
 (or $x875 $x764))))
(assert
 (let (($x769 (not (= (cache.state_ home) exclusive))))
 (let (($x423 (= home real_owner)))
 (or $x423 $x769))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x878 (= dir.hptr dir.hptr)))
 (or $x878 $x615))))
(assert
 (let (($x760 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x878 (= dir.hptr dir.hptr)))
 (or $x878 $x760))))
(assert
 (let (($x764 (not (= (cache.state_ __src) exclusive))))
 (let (($x881 (= __src dir.hptr)))
 (or $x881 $x764))))
(assert
 (let (($x769 (not (= (cache.state_ home) exclusive))))
 (let (($x883 (= home dir.hptr)))
 (or $x883 $x769))))
(assert
 (let (($x886 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x886))))
(assert
 (let (($x889 (not (= (cache.state_ __src) shared))))
 (let (($x875 (= __src real_owner)))
 (or $x875 $x889))))
(assert
 (let (($x892 (not (= (cache.state_ home) shared))))
 (let (($x423 (= home real_owner)))
 (or $x423 $x892))))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x558))))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x560))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x422 (= home home)))
 (or $x422 $x615))))
(assert
 (let (($x530 (not (= (cache.state_ @V0) shared))))
 (let (($x564 (not (rp_net @V0))))
 (or $x564 $x530))))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (let (($x534 (= real_owner @X)))
 (or $x534 $x558))))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (let (($x538 (= real_owner @V0)))
 (or $x538 $x560))))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (let (($x897 (= real_owner dir.hptr)))
 (or $x897 $x615))))
(assert
 (let (($x567 (not (net.put home @V0))))
 (or $x567 dir.head)))
(assert
 (let (($x569 (not (net.put dir.hptr @X))))
 (or $x569 dir.head)))
(assert
 (let (($x571 (not (net.put dir.hptr @V0))))
 (or $x571 dir.head)))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (or $x620 dir.head)))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (or $x558 dir.head)))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (or $x560 dir.head)))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (or $x615 dir.head)))
(assert
 (let (($x558 (not (net.putX real_owner @X))))
 (or $x558 dir.dirty)))
(assert
 (let (($x560 (not (net.putX real_owner @V0))))
 (or $x560 dir.dirty)))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (or $x615 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x615 (not (net.putX home dir.hptr))))
 (or $x615 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x564 (not (rp_net @V0))))
 (let (($x567 (not (net.put home @V0))))
 (or $x567 $x564))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x569 (not (net.put dir.hptr @X))))
 (or $x569 $x339))))
(assert
 (let (($x564 (not (rp_net @V0))))
 (let (($x571 (not (net.put dir.hptr @V0))))
 (or $x571 $x564))))
(assert
 (let (($x914 (not (rp_net dir.hptr))))
 (let (($x620 (not (net.put home dir.hptr))))
 (or $x620 $x914))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (let (($x583 (not (invack __dst))))
 (or $x583 (not (invnet __dst)))))
(assert
 (let (($x586 (not (invack @X))))
 (or $x586 (not (invnet @X)))))
(assert
 (let (($x589 (not (invack @V0))))
 (or $x589 (not (invnet @V0)))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x620 dir.pending))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x917 dir.pending))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x620 dir.dirty))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x917 dir.dirty))))
(assert
 (let (($x620 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x620))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x917))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x933))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x936))))
(assert
 (let (($x782 (not (__net.get __dst home))))
 (let (($x635 (dir.shlist __dst)))
 (let (($x938 (not $x635)))
 (or $x938 $x782)))))
(assert
 (let (($x635 (dir.shlist __dst)))
 (let (($x938 (not $x635)))
 (or $x938 dir.head))))
(assert
 (let (($x760 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x760))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let (($x647 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x647 $x917)))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let (($x275 (= __dst home)))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x275 $x936)))))
(assert
 (let (($x760 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x944 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x944 $x760)))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x933))))
(assert
 (let (($x886 (not (= (cache.state_ dir.hptr) shared))))
 (or $x886 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x889 (not (= (cache.state_ __src) shared))))
 (or $x889 (not (= (cache.wait __src) get)))))
(assert
 (let (($x892 (not (= (cache.state_ home) shared))))
 (or $x892 (not (= (cache.wait home) get)))))
(assert
 (let (($x760 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x760 dir.head)))
(assert
 (let (($x764 (not (= (cache.state_ __src) exclusive))))
 (or $x764 dir.head)))
(assert
 (let (($x769 (not (= (cache.state_ home) exclusive))))
 (or $x769 dir.head)))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x685 (= ?x684 getX)))
 (or $x685 $x910)))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let ((?x664 (cache.wait __dst)))
 (let (($x754 (= ?x664 getX)))
 (or $x754 $x933)))))
(assert
 (let (($x746 (not (net.getX home home))))
 (let ((?x689 (cache.wait home)))
 (let (($x690 (= ?x689 getX)))
 (or $x690 $x746)))))
(assert
 (let (($x749 (not (net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x692 (= ?x321 getX)))
 (or $x692 $x749)))))
(assert
 (let (($x752 (not (net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x752)))))
(assert
 (let (($x790 (not (net.getX home @Z))))
 (let ((?x689 (cache.wait home)))
 (let (($x690 (= ?x689 getX)))
 (or $x690 $x790)))))
(assert
 (let (($x792 (not (net.getX home @V0))))
 (let ((?x689 (cache.wait home)))
 (let (($x690 (= ?x689 getX)))
 (or $x690 $x792)))))
(assert
 (let (($x794 (not (net.getX home @V1))))
 (let ((?x689 (cache.wait home)))
 (let (($x690 (= ?x689 getX)))
 (or $x690 $x794)))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x699 (= ?x684 get)))
 (or $x699 $x917)))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let ((?x664 (cache.wait __dst)))
 (let (($x665 (= ?x664 get)))
 (or $x665 $x936)))))
(assert
 (let (($x579 (not (__net.get home home))))
 (let ((?x689 (cache.wait home)))
 (let (($x708 (= ?x689 get)))
 (or $x708 $x579)))))
(assert
 (let (($x581 (not (__net.get home @V1))))
 (let ((?x689 (cache.wait home)))
 (let (($x708 (= ?x689 get)))
 (or $x708 $x581)))))
(assert
 (let (($x624 (not (__net.get dir.hptr home))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x699 (= ?x684 get)))
 (or $x699 $x624)))))
(assert
 (let (($x630 (not (__net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x630)))))
(assert
 (let (($x774 (not (__net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x774)))))
(assert
 (let (($x778 (not (__net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x776 (= ?x321 get)))
 (or $x776 $x778)))))
(assert
 (let (($x782 (not (__net.get __dst home))))
 (let ((?x664 (cache.wait __dst)))
 (let (($x665 (= ?x664 get)))
 (or $x665 $x782)))))
(assert
 (let (($x787 (not (__net.get __src home))))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 get)))
 (or $x702 $x787)))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let ((?x718 (cache.state_ dir.hptr)))
 (let (($x719 (= ?x718 invalid)))
 (or $x719 $x917)))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let ((?x277 (cache.state_ __dst)))
 (let (($x654 (= ?x277 invalid)))
 (or $x654 $x936)))))
(assert
 (let (($x579 (not (__net.get home home))))
 (let ((?x728 (cache.state_ home)))
 (let (($x729 (= ?x728 invalid)))
 (or $x729 $x579)))))
(assert
 (let (($x581 (not (__net.get home @V1))))
 (let ((?x728 (cache.state_ home)))
 (let (($x729 (= ?x728 invalid)))
 (or $x729 $x581)))))
(assert
 (let (($x624 (not (__net.get dir.hptr home))))
 (let ((?x718 (cache.state_ dir.hptr)))
 (let (($x719 (= ?x718 invalid)))
 (or $x719 $x624)))))
(assert
 (let (($x630 (not (__net.get @V0 home))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x630)))))
(assert
 (let (($x774 (not (__net.get real_owner home))))
 (or (= (cache.state_ real_owner) invalid) $x774)))
(assert
 (let (($x778 (not (__net.get @V1 home))))
 (or (= (cache.state_ @V1) invalid) $x778)))
(assert
 (let (($x782 (not (__net.get __dst home))))
 (let ((?x277 (cache.state_ __dst)))
 (let (($x654 (= ?x277 invalid)))
 (or $x654 $x782)))))
(assert
 (let (($x787 (not (__net.get __src home))))
 (let ((?x721 (cache.state_ __src)))
 (let (($x722 (= ?x721 invalid)))
 (or $x722 $x787)))))
(assert
 (let (($x739 (not (= (cache.wait home) none))))
 (let (($x746 (not (net.getX home home))))
 (or $x746 $x739))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x749 (not (net.getX @V1 home))))
 (or $x749 $x323))))
(assert
 (let (($x743 (not (= (cache.wait @V0) none))))
 (let (($x752 (not (net.getX @V0 home))))
 (or $x752 $x743))))
(assert
 (let (($x739 (not (= (cache.wait home) none))))
 (let (($x790 (not (net.getX home @Z))))
 (or $x790 $x739))))
(assert
 (let (($x739 (not (= (cache.wait home) none))))
 (let (($x792 (not (net.getX home @V0))))
 (or $x792 $x739))))
(assert
 (let (($x739 (not (= (cache.wait home) none))))
 (let (($x794 (not (net.getX home @V1))))
 (or $x794 $x739))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x984 (= ?x140 getX)))
 (or $x984 $x986)))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x692 (= ?x321 getX)))
 (or $x692 $x989)))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let ((?x664 (cache.wait __dst)))
 (let (($x754 (= ?x664 getX)))
 (or $x754 $x933)))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let ((?x689 (cache.wait home)))
 (let (($x690 (= ?x689 getX)))
 (or $x690 $x992)))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let ((?x701 (cache.wait __src)))
 (let (($x765 (= ?x701 getX)))
 (or $x765 $x995)))))
(assert
 (let (($x998 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x984 (= ?x140 getX)))
 (or $x984 $x998)))))
(assert
 (let (($x1001 (not (net.getX __dst home))))
 (let ((?x664 (cache.wait __dst)))
 (let (($x754 (= ?x664 getX)))
 (or $x754 $x1001)))))
(assert
 (let (($x1004 (not (net.getX dir.hptr home))))
 (let ((?x684 (cache.wait dir.hptr)))
 (let (($x685 (= ?x684 getX)))
 (or $x685 $x1004)))))
(assert
 (let (($x1007 (not (net.getX __src home))))
 (let ((?x701 (cache.wait __src)))
 (let (($x765 (= ?x701 getX)))
 (or $x765 $x1007)))))
(assert
 (let (($x1010 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1010 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1014 (not (= (cache.state_ @V1) exclusive))))
 (or $x1014 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x914 (not (rp_net dir.hptr))))
 (let (($x620 (not (net.put home dir.hptr))))
 (or $x620 $x914))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x1018)))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x776 (= ?x321 get)))
 (or $x776 $x1021)))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let ((?x664 (cache.wait __dst)))
 (let (($x665 (= ?x664 get)))
 (or $x665 $x936)))))
(assert
 (let (($x1024 (not (net.put home home))))
 (let ((?x689 (cache.wait home)))
 (let (($x708 (= ?x689 get)))
 (or $x708 $x1024)))))
(assert
 (let (($x1027 (not (net.put home __src))))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 get)))
 (or $x702 $x1027)))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x647 (= dir.hptr home)))
 (or $x647 $x145 $x917)))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x936)))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x1018)))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x1021)))))
(assert
 (let (($x1024 (not (net.put home home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x1024)))))
(assert
 (let (($x1027 (not (net.put home __src))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x1027)))))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (let (($x801 (= real_owner real_owner)))
 (let (($x800 (= real_owner home)))
 (or $x800 $x801 $x910)))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x933)))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x986)))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x989)))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x992)))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x995)))))
(assert
 (let (($x778 (not (__net.get @V1 home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x778)))))
(assert
 (let (($x782 (not (__net.get __dst home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x782)))))
(assert
 (let (($x787 (not (__net.get __src home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x787)))))
(assert
 (let (($x998 (not (net.getX real_owner home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x998)))))
(assert
 (let (($x1001 (not (net.getX __dst home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x1001)))))
(assert
 (let (($x1004 (not (net.getX dir.hptr home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x1004)))))
(assert
 (let (($x1007 (not (net.getX __src home))))
 (let (($x423 (= home real_owner)))
 (let (($x422 (= home home)))
 (or $x422 $x423 $x1007)))))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (let (($x647 (= dir.hptr home)))
 (or $x647 $x917 dir.dirty))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let (($x422 (= home home)))
 (or $x422 $x936 dir.dirty))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (let (($x422 (= home home)))
 (or $x422 $x1018 dir.dirty))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (let (($x422 (= home home)))
 (or $x422 $x1021 dir.dirty))))
(assert
 (let (($x1024 (not (net.put home home))))
 (let (($x422 (= home home)))
 (or $x422 $x1024 dir.dirty))))
(assert
 (let (($x1027 (not (net.put home __src))))
 (let (($x422 (= home home)))
 (or $x422 $x1027 dir.dirty))))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x910 dir.head))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x422 (= home home)))
 (or $x422 $x933 dir.head))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x422 (= home home)))
 (or $x422 $x986 dir.head))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let (($x422 (= home home)))
 (or $x422 $x989 dir.head))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x422 (= home home)))
 (or $x422 $x992 dir.head))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let (($x422 (= home home)))
 (or $x422 $x995 dir.head))))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x910 dir.dirty))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x422 (= home home)))
 (or $x422 $x933 dir.dirty))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x422 (= home home)))
 (or $x422 $x986 dir.dirty))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let (($x422 (= home home)))
 (or $x422 $x989 dir.dirty))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x422 (= home home)))
 (or $x422 $x992 dir.dirty))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let (($x422 (= home home)))
 (or $x422 $x995 dir.dirty))))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x910))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x422 (= home home)))
 (or $x422 $x933))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x422 (= home home)))
 (or $x422 $x986))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let (($x422 (= home home)))
 (or $x422 $x989))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x422 (= home home)))
 (or $x422 $x992))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let (($x422 (= home home)))
 (or $x422 $x995))))
(assert
 (let (($x778 (not (__net.get @V1 home))))
 (let (($x422 (= home home)))
 (or $x422 $x778 dir.head))))
(assert
 (let (($x782 (not (__net.get __dst home))))
 (let (($x422 (= home home)))
 (or $x422 $x782 dir.head))))
(assert
 (let (($x787 (not (__net.get __src home))))
 (let (($x422 (= home home)))
 (or $x422 $x787 dir.head))))
(assert
 (let (($x778 (not (__net.get @V1 home))))
 (let (($x422 (= home home)))
 (or $x422 $x778 dir.dirty))))
(assert
 (let (($x782 (not (__net.get __dst home))))
 (let (($x422 (= home home)))
 (or $x422 $x782 dir.dirty))))
(assert
 (let (($x787 (not (__net.get __src home))))
 (let (($x422 (= home home)))
 (or $x422 $x787 dir.dirty))))
(assert
 (let (($x998 (not (net.getX real_owner home))))
 (let (($x422 (= home home)))
 (or $x422 $x998 dir.head))))
(assert
 (let (($x1001 (not (net.getX __dst home))))
 (let (($x422 (= home home)))
 (or $x422 $x1001 dir.head))))
(assert
 (let (($x1004 (not (net.getX dir.hptr home))))
 (let (($x422 (= home home)))
 (or $x422 $x1004 dir.head))))
(assert
 (let (($x1007 (not (net.getX __src home))))
 (let (($x422 (= home home)))
 (or $x422 $x1007 dir.head))))
(assert
 (let (($x998 (not (net.getX real_owner home))))
 (let (($x422 (= home home)))
 (or $x422 $x998 dir.dirty))))
(assert
 (let (($x1001 (not (net.getX __dst home))))
 (let (($x422 (= home home)))
 (or $x422 $x1001 dir.dirty))))
(assert
 (let (($x1004 (not (net.getX dir.hptr home))))
 (let (($x422 (= home home)))
 (or $x422 $x1004 dir.dirty))))
(assert
 (let (($x1007 (not (net.getX __src home))))
 (let (($x422 (= home home)))
 (or $x422 $x1007 dir.dirty))))
(assert
 (let (($x998 (not (net.getX real_owner home))))
 (let (($x422 (= home home)))
 (or $x422 $x998))))
(assert
 (let (($x1001 (not (net.getX __dst home))))
 (let (($x422 (= home home)))
 (or $x422 $x1001))))
(assert
 (let (($x1004 (not (net.getX dir.hptr home))))
 (let (($x422 (= home home)))
 (or $x422 $x1004))))
(assert
 (let (($x1007 (not (net.getX __src home))))
 (let (($x422 (= home home)))
 (or $x422 $x1007))))
(assert
 (let (($x998 (not (net.getX real_owner home))))
 (let (($x422 (= home home)))
 (or (= real_owner requester) $x422 $x998))))
(assert
 (let (($x1001 (not (net.getX __dst home))))
 (let (($x422 (= home home)))
 (let (($x649 (= __dst requester)))
 (or $x649 $x422 $x1001)))))
(assert
 (let (($x1004 (not (net.getX dir.hptr home))))
 (let (($x422 (= home home)))
 (let (($x944 (= dir.hptr requester)))
 (or $x944 $x422 $x1004)))))
(assert
 (let (($x1007 (not (net.getX __src home))))
 (let (($x422 (= home home)))
 (or (= __src requester) $x422 $x1007))))
(assert
 (let (($x1010 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x801 (= real_owner real_owner)))
 (or $x801 $x1010))))
(assert
 (let (($x1014 (not (= (cache.state_ @V1) exclusive))))
 (let (($x425 (= @V1 real_owner)))
 (or $x425 $x1014))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x519 (= __dst dir.hptr)))
 (or $x519 $x933))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x897 (= real_owner dir.hptr)))
 (or $x897 $x986))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let (($x1100 (= @V1 dir.hptr)))
 (or $x1100 $x989))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x883 (= home dir.hptr)))
 (or $x883 $x992))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let (($x881 (= __src dir.hptr)))
 (or $x881 $x995))))
(assert
 (let (($x1010 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x897 (= real_owner dir.hptr)))
 (or $x897 $x1010))))
(assert
 (let (($x1014 (not (= (cache.state_ @V1) exclusive))))
 (let (($x1100 (= @V1 dir.hptr)))
 (or $x1100 $x1014))))
(assert
 (let (($x801 (= real_owner real_owner)))
 (or $x801 (not (= (cache.state_ real_owner) shared)))))
(assert
 (let (($x425 (= @V1 real_owner)))
 (or $x425 (not (= (cache.state_ @V1) shared)))))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x910))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (let (($x422 (= home home)))
 (or $x422 $x933))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x422 (= home home)))
 (or $x422 $x986))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let (($x422 (= home home)))
 (or $x422 $x989))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x422 (= home home)))
 (or $x422 $x992))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let (($x422 (= home home)))
 (or $x422 $x995))))
(assert
 (let (($x886 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x914 (not (rp_net dir.hptr))))
 (or $x914 $x886))))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (let (($x897 (= real_owner dir.hptr)))
 (or $x897 $x910))))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (or (= real_owner __dst) $x933)))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x801 (= real_owner real_owner)))
 (or $x801 $x986))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x989)))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x800 (= real_owner home)))
 (or $x800 $x992))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (or (= real_owner __src) $x995)))
(assert
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (or $x917 dir.head)))
(assert
 (let (($x936 (not (net.put home __dst))))
 (or $x936 dir.head)))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (or $x1018 dir.head)))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (or $x1021 dir.head)))
(assert
 (let (($x1024 (not (net.put home home))))
 (or $x1024 dir.head)))
(assert
 (let (($x1027 (not (net.put home __src))))
 (or $x1027 dir.head)))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (or $x910 dir.head)))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (or $x933 dir.head)))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (or $x986 dir.head)))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (or $x989 dir.head)))
(assert
 (let (($x992 (not (net.putX home home))))
 (or $x992 dir.head)))
(assert
 (let (($x995 (not (net.putX home __src))))
 (or $x995 dir.head)))
(assert
 (let (($x910 (not (net.putX real_owner dir.hptr))))
 (or $x910 dir.dirty)))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (or $x933 dir.dirty)))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (or $x986 dir.dirty)))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (or $x989 dir.dirty)))
(assert
 (let (($x992 (not (net.putX home home))))
 (or $x992 dir.dirty)))
(assert
 (let (($x995 (not (net.putX home __src))))
 (or $x995 dir.dirty)))
(assert
 (not (net.putX real_owner __dst)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (not (net.putX real_owner __src)))
(assert
 (let (($x933 (not (net.putX home __dst))))
 (or $x933 dir.head)))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (or $x986 dir.head)))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (or $x989 dir.head)))
(assert
 (let (($x992 (not (net.putX home home))))
 (or $x992 dir.head)))
(assert
 (let (($x995 (not (net.putX home __src))))
 (or $x995 dir.head)))
(assert
 (not (net.putX home __dst)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (not (net.putX home __src)))
(assert
 (let (($x914 (not (rp_net dir.hptr))))
 (let (($x917 (not (net.put dir.hptr dir.hptr))))
 (or $x917 $x914))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (or $x936 (not (rp_net __dst)))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (or $x1018 (not (rp_net real_owner)))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (or $x1021 (not (rp_net @V1)))))
(assert
 (let (($x1024 (not (net.put home home))))
 (or $x1024 (not (rp_net home)))))
(assert
 (let (($x1027 (not (net.put home __src))))
 (or $x1027 (not (rp_net __src)))))
(assert
 (not (net.put home __dst)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put dir.hptr __dst)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x936 dir.pending))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x1018 dir.pending))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x1021 dir.pending))))
(assert
 (let (($x1024 (not (net.put home home))))
 (let (($x1181 (dir.shlist home)))
 (or $x1181 $x1024 dir.pending))))
(assert
 (let (($x1027 (not (net.put home __src))))
 (let (($x1183 (dir.shlist __src)))
 (or $x1183 $x1027 dir.pending))))
(assert
 (let (($x1167 (not (net.put dir.hptr __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x1167 dir.pending))))
(assert
 (let (($x1169 (not (net.put dir.hptr real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x1169 dir.pending))))
(assert
 (let (($x1171 (not (net.put dir.hptr @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x1171 dir.pending))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x936 dir.dirty))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x1018 dir.dirty))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x1021 dir.dirty))))
(assert
 (let (($x1024 (not (net.put home home))))
 (let (($x1181 (dir.shlist home)))
 (or $x1181 $x1024 dir.dirty))))
(assert
 (let (($x1027 (not (net.put home __src))))
 (let (($x1183 (dir.shlist __src)))
 (or $x1183 $x1027 dir.dirty))))
(assert
 (let (($x1167 (not (net.put dir.hptr __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x1167 dir.dirty))))
(assert
 (let (($x1169 (not (net.put dir.hptr real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x1169 dir.dirty))))
(assert
 (let (($x1171 (not (net.put dir.hptr @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x1171 dir.dirty))))
(assert
 (let (($x936 (not (net.put home __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x936))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x1018))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x1021))))
(assert
 (let (($x1024 (not (net.put home home))))
 (let (($x1181 (dir.shlist home)))
 (or $x1181 $x1024))))
(assert
 (let (($x1027 (not (net.put home __src))))
 (let (($x1183 (dir.shlist __src)))
 (or $x1183 $x1027))))
(assert
 (let (($x1167 (not (net.put dir.hptr __dst))))
 (let (($x635 (dir.shlist __dst)))
 (or $x635 $x1167))))
(assert
 (let (($x1169 (not (net.put dir.hptr real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x1169))))
(assert
 (let (($x1171 (not (net.put dir.hptr @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x1171))))
(assert
 (let (($x986 (not (net.putX home real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x986))))
(assert
 (let (($x989 (not (net.putX home @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x989))))
(assert
 (let (($x992 (not (net.putX home home))))
 (let (($x1181 (dir.shlist home)))
 (or $x1181 $x992))))
(assert
 (let (($x995 (not (net.putX home __src))))
 (let (($x1183 (dir.shlist __src)))
 (or $x1183 $x995))))
(assert
 (let (($x1018 (not (net.put home real_owner))))
 (let (($x1177 (dir.shlist real_owner)))
 (or $x1177 $x1018))))
(assert
 (let (($x1021 (not (net.put home @V1))))
 (let (($x1179 (dir.shlist @V1)))
 (or $x1179 $x1021))))
(check-sat)
