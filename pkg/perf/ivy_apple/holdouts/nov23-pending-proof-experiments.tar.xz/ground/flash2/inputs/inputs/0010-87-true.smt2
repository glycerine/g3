(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun dir.local_ () Bool)
(declare-fun dir.pending () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun __m_net.get (id id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) __dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__net.get __src home))
(assert
 (not (= home __src)))
(assert
 (not __dir.pending))
(assert
 dir.dirty)
(assert
 (not dir.local_))
(assert
 (let (($x277 (= __src dir.hptr)))
 (not $x277)))
(assert
 dir.pending)
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x376 (not (net.getX home @Y))))
 (let (($x355 (not (net.getX @X @Z))))
 (let (($x363 (not (net.getX @X @Y))))
 (let (($x364 (= @Y @Z)))
 (let (($x377 (and (or $x364 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x364 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x364 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x364 $x363 $x355) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x355 (not (net.putX @Y @X))) $x376 $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x338 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x377)))))))))))
(assert
 (let (($x401 (__m_net.get @X @Y)))
 (let (($x369 (net.get @X @Y)))
 (= $x369 (ite (and (= @X __src) (= @Y dir.hptr)) true $x401)))))
(assert
 (let (($x406 (__m_net.get @X @Z)))
 (let (($x359 (net.get @X @Z)))
 (= $x359 (ite (and (= @X __src) (= @Z dir.hptr)) true $x406)))))
(assert
 (let (($x411 (__m_net.get @X home)))
 (let (($x348 (net.get @X home)))
 (= $x348 (ite (and (= @X __src) (= home dir.hptr)) true $x411)))))
(assert
 (let (($x417 (__m_net.get @V0 @V1)))
 (let (($x309 (net.get @V0 @V1)))
 (= $x309 (ite (and (= @V0 __src) (= @V1 dir.hptr)) true $x417)))))
(assert
 (let (($x421 (__net.get @X @Y)))
 (let (($x401 (__m_net.get @X @Y)))
 (= $x401 (ite (and (= @X __src) (= @Y home)) false $x421)))))
(assert
 (let (($x426 (__net.get @X @Z)))
 (let (($x406 (__m_net.get @X @Z)))
 (= $x406 (ite (and (= @X __src) (= @Z home)) false $x426)))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x411 (__m_net.get @X home)))
 (= $x411 (ite (and (= @X __src) (= home home)) false $x431)))))
(assert
 (let (($x435 (__net.get @V0 @V1)))
 (let (($x417 (__m_net.get @V0 @V1)))
 (= $x417 (ite (and (= @V0 __src) (= @V1 home)) false $x435)))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let (($x438 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x438 $x358)))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let (($x440 (= @Z real_owner)))
 (let (($x424 (= @Z home)))
 (or $x424 $x440 $x373)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x444 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x444 $x306)))))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (let (($x438 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x438 $x352)))))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (let (($x440 (= @Z real_owner)))
 (let (($x424 (= @Z home)))
 (or $x424 $x440 $x367)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x329)))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x444 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x444 $x300)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x450 (not $x271)))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x450))))))
(assert
 (let (($x421 (__net.get @X @Y)))
 (let (($x452 (not $x421)))
 (let (($x438 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x438 $x452))))))
(assert
 (let (($x426 (__net.get @X @Z)))
 (let (($x454 (not $x426)))
 (let (($x440 (= @Z real_owner)))
 (let (($x424 (= @Z home)))
 (or $x424 $x440 $x454))))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x456 (not $x431)))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x456))))))
(assert
 (let (($x435 (__net.get @V0 @V1)))
 (let (($x458 (not $x435)))
 (let (($x444 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x444 $x458))))))
(assert
 (let (($x363 (not (net.getX @X @Y))))
 (let (($x438 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x438 $x363)))))
(assert
 (let (($x355 (not (net.getX @X @Z))))
 (let (($x440 (= @Z real_owner)))
 (let (($x424 (= @Z home)))
 (or $x424 $x440 $x355)))))
(assert
 (let (($x376 (not (net.getX home @Y))))
 (let (($x438 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x438 $x376)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x334)))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x465 (= @V0 real_owner)))
 (let (($x464 (= @V0 home)))
 (or $x464 $x465 $x323)))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x444 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x444 $x303)))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x358 dir.dirty))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let (($x424 (= @Z home)))
 (or $x424 $x373 dir.dirty))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x429 (= home home)))
 (or $x429 $x344 dir.dirty))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x306 dir.dirty))))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x352 dir.head))))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (let (($x424 (= @Z home)))
 (or $x424 $x367 dir.head))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x429 (= home home)))
 (or $x429 $x329 dir.head))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300 dir.head))))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x352 dir.dirty))))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (let (($x424 (= @Z home)))
 (or $x424 $x367 dir.dirty))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x429 (= home home)))
 (or $x429 $x329 dir.dirty))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300 dir.dirty))))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x352))))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (let (($x424 (= @Z home)))
 (or $x424 $x367))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x429 (= home home)))
 (or $x429 $x329))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x450 (not $x271)))
 (let (($x429 (= home home)))
 (or $x429 $x450 dir.head)))))
(assert
 (let (($x421 (__net.get @X @Y)))
 (let (($x452 (not $x421)))
 (let (($x317 (= @Y home)))
 (or $x317 $x452 dir.head)))))
(assert
 (let (($x426 (__net.get @X @Z)))
 (let (($x454 (not $x426)))
 (let (($x424 (= @Z home)))
 (or $x424 $x454 dir.head)))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x456 (not $x431)))
 (let (($x429 (= home home)))
 (or $x429 $x456 dir.head)))))
(assert
 (let (($x435 (__net.get @V0 @V1)))
 (let (($x458 (not $x435)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x458 dir.head)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x450 (not $x271)))
 (let (($x429 (= home home)))
 (or $x429 $x450 dir.dirty)))))
(assert
 (let (($x421 (__net.get @X @Y)))
 (let (($x452 (not $x421)))
 (let (($x317 (= @Y home)))
 (or $x317 $x452 dir.dirty)))))
(assert
 (let (($x426 (__net.get @X @Z)))
 (let (($x454 (not $x426)))
 (let (($x424 (= @Z home)))
 (or $x424 $x454 dir.dirty)))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x456 (not $x431)))
 (let (($x429 (= home home)))
 (or $x429 $x456 dir.dirty)))))
(assert
 (let (($x435 (__net.get @V0 @V1)))
 (let (($x458 (not $x435)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x458 dir.dirty)))))
(assert
 (let (($x363 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x363 dir.head))))
(assert
 (let (($x355 (not (net.getX @X @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x355 dir.head))))
(assert
 (let (($x376 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x376 dir.head))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x334 dir.head))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x464 (= @V0 home)))
 (or $x464 $x323 dir.head))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x303 dir.head))))
(assert
 (let (($x363 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x363 dir.dirty))))
(assert
 (let (($x355 (not (net.getX @X @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x355 dir.dirty))))
(assert
 (let (($x376 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x376 dir.dirty))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x334 dir.dirty))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x464 (= @V0 home)))
 (or $x464 $x323 dir.dirty))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x303 dir.dirty))))
(assert
 (let (($x363 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x363))))
(assert
 (let (($x355 (not (net.getX @X @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x355))))
(assert
 (let (($x376 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x376))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x334))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x464 (= @V0 home)))
 (or $x464 $x323))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x303))))
(assert
 (let (($x363 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (let (($x512 (= @X requester)))
 (or $x512 $x317 $x363)))))
(assert
 (let (($x355 (not (net.getX @X @Z))))
 (let (($x424 (= @Z home)))
 (let (($x512 (= @X requester)))
 (or $x512 $x424 $x355)))))
(assert
 (let (($x376 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (let (($x515 (= home requester)))
 (or $x515 $x317 $x376)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (let (($x512 (= @X requester)))
 (or $x512 $x429 $x334)))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x464 (= @V0 home)))
 (let (($x518 (= @V1 requester)))
 (or $x518 $x464 $x323)))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x520 (= @V0 requester)))
 (or $x520 $x292 $x303)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x295 (not (net.fack @V0 @V1))))
 (let (($x465 (= @V0 real_owner)))
 (or $x465 $x295))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x525 (= @X real_owner)))
 (or $x525 $x338))))
(assert
 (let (($x528 (not (= (cache.state_ @V0) exclusive))))
 (let (($x465 (= @V0 real_owner)))
 (or $x465 $x528))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x530 (= @X dir.hptr)))
 (or $x530 $x329))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x532 (= @V0 dir.hptr)))
 (or $x532 $x534))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x530 (= @X dir.hptr)))
 (or $x530 $x338))))
(assert
 (let (($x528 (not (= (cache.state_ @V0) exclusive))))
 (let (($x532 (= @V0 dir.hptr)))
 (or $x532 $x528))))
(assert
 (let (($x539 (not (= (cache.state_ @X) shared))))
 (let (($x525 (= @X real_owner)))
 (or $x525 $x539))))
(assert
 (let (($x542 (not (= (cache.state_ @V0) shared))))
 (let (($x465 (= @V0 real_owner)))
 (or $x465 $x542))))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x352))))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (let (($x424 (= @Z home)))
 (or $x424 $x367))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x429 (= home home)))
 (or $x429 $x329))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x429 (= home home)))
 (or $x429 $x534))))
(assert
 (let (($x539 (not (= (cache.state_ @X) shared))))
 (let (($x342 (not (rp_net @X))))
 (or $x342 $x539))))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (let (($x546 (= real_owner @X)))
 (or $x546 $x352))))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (let (($x546 (= real_owner @X)))
 (or $x546 $x367))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x546 (= real_owner @X)))
 (or $x546 $x329))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x550 (= real_owner @V0)))
 (or $x550 $x300))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x550 (= real_owner @V0)))
 (or $x550 $x534))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (or $x358 dir.head)))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (or $x373 dir.head)))
(assert
 (let (($x344 (not (net.put home @X))))
 (or $x344 dir.head)))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (or $x306 dir.head)))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (or $x352 dir.head)))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (or $x367 dir.head)))
(assert
 (let (($x329 (not (net.putX home @X))))
 (or $x329 dir.head)))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (or $x300 dir.head)))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (or $x534 dir.head)))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (or $x352 dir.dirty)))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (or $x367 dir.dirty)))
(assert
 (let (($x329 (not (net.putX home @X))))
 (or $x329 dir.dirty)))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (or $x300 dir.dirty)))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (or $x534 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x329 (not (net.putX home @X))))
 (or $x329 dir.head)))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (or $x534 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x358 (not (net.put @Y @X))))
 (or $x358 $x342))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x373 (not (net.put @Z @X))))
 (or $x373 $x342))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x344 (not (net.put home @X))))
 (or $x344 $x342))))
(assert
 (let (($x576 (not (rp_net @V0))))
 (let (($x306 (not (net.put @V1 @V0))))
 (or $x306 $x576))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (__net.get home home)))
(assert
 (not (__net.get home @Y)))
(assert
 (not (__net.get home @Z)))
(assert
 (not (__net.get home @V1)))
(assert
 (let (($x539 (not (= (cache.state_ @X) shared))))
 (let (($x593 (not (invack @X))))
 (or $x593 $x539))))
(assert
 (let (($x542 (not (= (cache.state_ @V0) shared))))
 (let (($x596 (not (invack @V0))))
 (or $x596 $x542))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x358 __dir.pending))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x373 __dir.pending))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x344 __dir.pending))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x306 __dir.pending))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x579 __dir.pending))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x581 __dir.pending))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x583 __dir.pending))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x358 dir.dirty))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x373 dir.dirty))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x344 dir.dirty))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x306 dir.dirty))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x579 dir.dirty))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x581 dir.dirty))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x583 dir.dirty))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x358))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x373))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x344))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x306))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x579))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x581))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x583))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x622))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x329))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x534))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x627))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x344))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x579))))
(assert
 (let (($x631 (not (__net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x629 (not $x58)))
 (or $x629 $x631)))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x456 (not $x431)))
 (let (($x598 (dir.shlist @X)))
 (let (($x633 (not $x598)))
 (or $x633 $x456))))))
(assert
 (let (($x637 (not (__net.get @V0 home))))
 (let (($x602 (dir.shlist @V0)))
 (let (($x635 (not $x602)))
 (or $x635 $x637)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x629 (not $x58)))
 (or $x629 dir.head))))
(assert
 (let (($x598 (dir.shlist @X)))
 (let (($x633 (not $x598)))
 (or $x633 dir.head))))
(assert
 (let (($x602 (dir.shlist @V0)))
 (let (($x635 (not $x602)))
 (or $x635 dir.head))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x338))))
(assert
 (let (($x528 (not (= (cache.state_ @V0) exclusive))))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x528))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let (($x644 (= @X home)))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x644 $x358)))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let (($x644 (= @X home)))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x644 $x373)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x644 (= @X home)))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x644 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x464 (= @V0 home)))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x464 $x306)))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let (($x464 (= @V0 home)))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x464 $x579)))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let (($x644 (= @X home)))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x644 $x581)))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let (($x464 (= @V0 home)))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x464 $x583)))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let (($x652 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x652 $x627)))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x512 (= @X requester)))
 (let (($x598 (dir.shlist @X)))
 (or $x598 $x512 $x338)))))
(assert
 (let (($x528 (not (= (cache.state_ @V0) exclusive))))
 (let (($x520 (= @V0 requester)))
 (let (($x602 (dir.shlist @V0)))
 (or $x602 $x520 $x528)))))
(assert
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (let (($x525 (= @X real_owner)))
 (or (dir.real @X) $x525 $x657)))))
(assert
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (let (($x465 (= @V0 real_owner)))
 (or (dir.real @V0) $x465 $x313)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x329))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x534))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x622))))
(assert
 (let (($x539 (not (= (cache.state_ @X) shared))))
 (or $x539 (not (= (cache.wait @X) get)))))
(assert
 (let (($x542 (not (= (cache.state_ @V0) shared))))
 (or $x542 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x593 (not (invack @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x593)))))
(assert
 (let (($x596 (not (invack @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x596)))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (or $x338 dir.head)))
(assert
 (let (($x528 (not (= (cache.state_ @V0) exclusive))))
 (or $x528 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x429 (= home home)))
 (or $x429 $x187))))
(assert
 (let (($x295 (not (net.fack @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x295))))
(assert
 (let (($x352 (not (net.putX @Y @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x352)))))
(assert
 (let (($x367 (not (net.putX @Z @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x367)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x329)))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x300)))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x534)))))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x570)))))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x572)))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x679 (= ?x678 getX)))
 (or $x679 $x622)))))
(assert
 (let (($x363 (not (net.getX @X @Y))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x363)))))
(assert
 (let (($x355 (not (net.getX @X @Z))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x355)))))
(assert
 (let (($x376 (not (net.getX home @Y))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x376)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x334)))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x686 (= ?x324 getX)))
 (or $x686 $x323)))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x303)))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x358)))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x373)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x306)))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x579)))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x581)))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x583)))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x693 (= ?x678 get)))
 (or $x693 $x627)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x450 (not $x271)))
 (let ((?x695 (cache.wait __src)))
 (let (($x696 (= ?x695 get)))
 (or $x696 $x450))))))
(assert
 (let (($x421 (__net.get @X @Y)))
 (let (($x452 (not $x421)))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x452))))))
(assert
 (let (($x426 (__net.get @X @Z)))
 (let (($x454 (not $x426)))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x454))))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x456 (not $x431)))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x456))))))
(assert
 (let (($x435 (__net.get @V0 @V1)))
 (let (($x458 (not $x435)))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x458))))))
(assert
 (let (($x585 (not (__net.get home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x585)))))
(assert
 (let (($x587 (not (__net.get home @Y))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x587)))))
(assert
 (let (($x589 (not (__net.get home @Z))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x589)))))
(assert
 (let (($x358 (not (net.put @Y @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x358)))))
(assert
 (let (($x373 (not (net.put @Z @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x373)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x306)))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x579)))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x581)))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x583)))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let ((?x712 (cache.state_ dir.hptr)))
 (let (($x713 (= ?x712 invalid)))
 (or $x713 $x627)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x450 (not $x271)))
 (let ((?x715 (cache.state_ __src)))
 (let (($x716 (= ?x715 invalid)))
 (or $x716 $x450))))))
(assert
 (let (($x421 (__net.get @X @Y)))
 (let (($x452 (not $x421)))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x452))))))
(assert
 (let (($x426 (__net.get @X @Z)))
 (let (($x454 (not $x426)))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x454))))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x456 (not $x431)))
 (let ((?x336 (cache.state_ @X)))
 (let (($x657 (= ?x336 invalid)))
 (or $x657 $x456))))))
(assert
 (let (($x435 (__net.get @V0 @V1)))
 (let (($x458 (not $x435)))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x458))))))
(assert
 (let (($x585 (not (__net.get home home))))
 (let ((?x722 (cache.state_ home)))
 (let (($x723 (= ?x722 invalid)))
 (or $x723 $x585)))))
(assert
 (let (($x587 (not (__net.get home @Y))))
 (let ((?x722 (cache.state_ home)))
 (let (($x723 (= ?x722 invalid)))
 (or $x723 $x587)))))
(assert
 (let (($x589 (not (__net.get home @Z))))
 (let ((?x722 (cache.state_ home)))
 (let (($x723 (= ?x722 invalid)))
 (or $x723 $x589)))))
(assert
 (let (($x317 (= @Y home)))
 (or $x317 (not (net.shwb @X @Y)))))
(assert
 (let (($x429 (= home home)))
 (or $x429 (not (net.shwb @X home)))))
(assert
 (let (($x729 (not (= (cache.wait @X) none))))
 (let (($x363 (not (net.getX @X @Y))))
 (or $x363 $x729))))
(assert
 (let (($x729 (not (= (cache.wait @X) none))))
 (let (($x355 (not (net.getX @X @Z))))
 (or $x355 $x729))))
(assert
 (let (($x733 (not (= (cache.wait home) none))))
 (let (($x376 (not (net.getX home @Y))))
 (or $x376 $x733))))
(assert
 (let (($x729 (not (= (cache.wait @X) none))))
 (let (($x334 (not (net.getX @X home))))
 (or $x334 $x729))))
(assert
 (let (($x326 (not (= (cache.wait @V1) none))))
 (let (($x323 (not (net.getX @V1 @V0))))
 (or $x323 $x326))))
(assert
 (let (($x737 (not (= (cache.wait @V0) none))))
 (let (($x303 (not (net.getX @V0 @V1))))
 (or $x303 $x737))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x739 (= ?x140 getX)))
 (or $x739 $x741)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x329)))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x686 (= ?x324 getX)))
 (or $x686 $x744)))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x534)))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x679 (= ?x678 getX)))
 (or $x679 $x622)))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x747)))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let ((?x695 (cache.wait __src)))
 (let (($x749 (= ?x695 getX)))
 (or $x749 $x751)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x334)))))
(assert
 (let (($x754 (not (net.getX home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x754)))))
(assert
 (let (($x757 (not (net.getX @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x686 (= ?x324 getX)))
 (or $x686 $x757)))))
(assert
 (let (($x760 (not (net.getX @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x760)))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (or $x338 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x528 (not (= (cache.state_ @V0) exclusive))))
 (or $x528 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x765 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x765 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x769 (not (= (cache.state_ __src) exclusive))))
 (or $x769 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x773 (not (= (cache.state_ home) exclusive))))
 (or $x773 (not (= (cache.wait home) getX)))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x344 (not (net.put home @X))))
 (or $x344 $x342))))
(assert
 (let (($x576 (not (rp_net @V0))))
 (let (($x579 (not (net.put home @V0))))
 (or $x579 $x576))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x778)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x344)))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x780 (= ?x324 get)))
 (or $x780 $x782)))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x579)))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x693 (= ?x678 get)))
 (or $x693 $x627)))))
(assert
 (let (($x785 (not (net.put home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x785)))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let ((?x695 (cache.wait __src)))
 (let (($x696 (= ?x695 get)))
 (or $x696 $x788)))))
(assert
 (let (($x791 (not (__net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x791)))))
(assert
 (let (($x431 (__net.get @X home)))
 (let (($x456 (not $x431)))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x456))))))
(assert
 (let (($x794 (not (__net.get @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x780 (= ?x324 get)))
 (or $x780 $x794)))))
(assert
 (let (($x637 (not (__net.get @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x637)))))
(assert
 (let (($x631 (not (__net.get dir.hptr home))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x693 (= ?x678 get)))
 (or $x693 $x631)))))
(assert
 (let (($x585 (not (__net.get home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x585)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x450 (not $x271)))
 (let ((?x695 (cache.wait __src)))
 (let (($x696 (= ?x695 get)))
 (or $x696 $x450))))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x579)))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x581)))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x583)))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x627)))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x778)))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x782)))))
(assert
 (let (($x785 (not (net.put home home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x785)))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x788)))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x534)))))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (let (($x814 (= real_owner real_owner)))
 (let (($x813 (= real_owner home)))
 (or $x813 $x814 $x570)))))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (let (($x814 (= real_owner real_owner)))
 (let (($x813 (= real_owner home)))
 (or $x813 $x814 $x572)))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x622)))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x741)))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x744)))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x747)))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x751)))))
(assert
 (let (($x585 (not (__net.get home home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x585)))))
(assert
 (let (($x587 (not (__net.get home @Y))))
 (let (($x438 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x438 $x587)))))
(assert
 (let (($x589 (not (__net.get home @Z))))
 (let (($x440 (= @Z real_owner)))
 (let (($x424 (= @Z home)))
 (or $x424 $x440 $x589)))))
(assert
 (let (($x591 (not (__net.get home @V1))))
 (let (($x444 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x444 $x591)))))
(assert
 (let (($x631 (not (__net.get dir.hptr home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x631)))))
(assert
 (let (($x637 (not (__net.get @V0 home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x637)))))
(assert
 (let (($x791 (not (__net.get real_owner home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x791)))))
(assert
 (let (($x794 (not (__net.get @V1 home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x794)))))
(assert
 (let (($x754 (not (net.getX home home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x754)))))
(assert
 (let (($x757 (not (net.getX @V1 home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x757)))))
(assert
 (let (($x760 (not (net.getX @V0 home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x760)))))
(assert
 (let (($x799 (not (net.getX home @Z))))
 (let (($x440 (= @Z real_owner)))
 (let (($x424 (= @Z home)))
 (or $x424 $x440 $x799)))))
(assert
 (let (($x801 (not (net.getX home @V0))))
 (let (($x465 (= @V0 real_owner)))
 (let (($x464 (= @V0 home)))
 (or $x464 $x465 $x801)))))
(assert
 (let (($x803 (not (net.getX home @V1))))
 (let (($x444 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x444 $x803)))))
(assert
 (let (($x579 (not (net.put home @V0))))
 (let (($x429 (= home home)))
 (or $x429 $x579 dir.dirty))))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x581 dir.dirty))))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x583 dir.dirty))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x627 dir.dirty))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let (($x429 (= home home)))
 (or $x429 $x778 dir.dirty))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let (($x429 (= home home)))
 (or $x429 $x782 dir.dirty))))
(assert
 (let (($x785 (not (net.put home home))))
 (let (($x429 (= home home)))
 (or $x429 $x785 dir.dirty))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let (($x429 (= home home)))
 (or $x429 $x788 dir.dirty))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x429 (= home home)))
 (or $x429 $x534 dir.head))))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x570 dir.head))))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x572 dir.head))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x622 dir.head))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x429 (= home home)))
 (or $x429 $x741 dir.head))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x429 (= home home)))
 (or $x429 $x744 dir.head))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x747 dir.head))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x429 (= home home)))
 (or $x429 $x751 dir.head))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x429 (= home home)))
 (or $x429 $x534 dir.dirty))))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x570 dir.dirty))))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x572 dir.dirty))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x622 dir.dirty))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x429 (= home home)))
 (or $x429 $x741 dir.dirty))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x429 (= home home)))
 (or $x429 $x744 dir.dirty))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x747 dir.dirty))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x429 (= home home)))
 (or $x429 $x751 dir.dirty))))
(assert
 (let (($x534 (not (net.putX home @V0))))
 (let (($x429 (= home home)))
 (or $x429 $x534))))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x570))))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x572))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x622))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x429 (= home home)))
 (or $x429 $x741))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x429 (= home home)))
 (or $x429 $x744))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x747))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x429 (= home home)))
 (or $x429 $x751))))
(assert
 (let (($x585 (not (__net.get home home))))
 (let (($x429 (= home home)))
 (or $x429 $x585 dir.head))))
(assert
 (let (($x587 (not (__net.get home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x587 dir.head))))
(assert
 (let (($x589 (not (__net.get home @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x589 dir.head))))
(assert
 (let (($x591 (not (__net.get home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x591 dir.head))))
(assert
 (let (($x631 (not (__net.get dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x631 dir.head))))
(assert
 (let (($x637 (not (__net.get @V0 home))))
 (let (($x429 (= home home)))
 (or $x429 $x637 dir.head))))
(assert
 (let (($x791 (not (__net.get real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x791 dir.head))))
(assert
 (let (($x794 (not (__net.get @V1 home))))
 (let (($x429 (= home home)))
 (or $x429 $x794 dir.head))))
(assert
 (let (($x585 (not (__net.get home home))))
 (let (($x429 (= home home)))
 (or $x429 $x585 dir.dirty))))
(assert
 (let (($x587 (not (__net.get home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x587 dir.dirty))))
(assert
 (let (($x589 (not (__net.get home @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x589 dir.dirty))))
(assert
 (let (($x591 (not (__net.get home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x591 dir.dirty))))
(assert
 (let (($x631 (not (__net.get dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x631 dir.dirty))))
(assert
 (let (($x637 (not (__net.get @V0 home))))
 (let (($x429 (= home home)))
 (or $x429 $x637 dir.dirty))))
(assert
 (let (($x791 (not (__net.get real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x791 dir.dirty))))
(assert
 (let (($x794 (not (__net.get @V1 home))))
 (let (($x429 (= home home)))
 (or $x429 $x794 dir.dirty))))
(assert
 (let (($x754 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x754 dir.head))))
(assert
 (let (($x757 (not (net.getX @V1 home))))
 (let (($x429 (= home home)))
 (or $x429 $x757 dir.head))))
(assert
 (let (($x760 (not (net.getX @V0 home))))
 (let (($x429 (= home home)))
 (or $x429 $x760 dir.head))))
(assert
 (let (($x799 (not (net.getX home @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x799 dir.head))))
(assert
 (let (($x801 (not (net.getX home @V0))))
 (let (($x464 (= @V0 home)))
 (or $x464 $x801 dir.head))))
(assert
 (let (($x803 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x803 dir.head))))
(assert
 (let (($x754 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x754 dir.dirty))))
(assert
 (let (($x757 (not (net.getX @V1 home))))
 (let (($x429 (= home home)))
 (or $x429 $x757 dir.dirty))))
(assert
 (let (($x760 (not (net.getX @V0 home))))
 (let (($x429 (= home home)))
 (or $x429 $x760 dir.dirty))))
(assert
 (let (($x799 (not (net.getX home @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x799 dir.dirty))))
(assert
 (let (($x801 (not (net.getX home @V0))))
 (let (($x464 (= @V0 home)))
 (or $x464 $x801 dir.dirty))))
(assert
 (let (($x803 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x803 dir.dirty))))
(assert
 (let (($x754 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x754))))
(assert
 (let (($x757 (not (net.getX @V1 home))))
 (let (($x429 (= home home)))
 (or $x429 $x757))))
(assert
 (let (($x760 (not (net.getX @V0 home))))
 (let (($x429 (= home home)))
 (or $x429 $x760))))
(assert
 (let (($x799 (not (net.getX home @Z))))
 (let (($x424 (= @Z home)))
 (or $x424 $x799))))
(assert
 (let (($x801 (not (net.getX home @V0))))
 (let (($x464 (= @V0 home)))
 (or $x464 $x801))))
(assert
 (let (($x803 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x803))))
(assert
 (let (($x754 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (let (($x515 (= home requester)))
 (or $x515 $x429 $x754)))))
(assert
 (let (($x757 (not (net.getX @V1 home))))
 (let (($x429 (= home home)))
 (let (($x518 (= @V1 requester)))
 (or $x518 $x429 $x757)))))
(assert
 (let (($x760 (not (net.getX @V0 home))))
 (let (($x429 (= home home)))
 (let (($x520 (= @V0 requester)))
 (or $x520 $x429 $x760)))))
(assert
 (let (($x799 (not (net.getX home @Z))))
 (let (($x424 (= @Z home)))
 (let (($x515 (= home requester)))
 (or $x515 $x424 $x799)))))
(assert
 (let (($x801 (not (net.getX home @V0))))
 (let (($x464 (= @V0 home)))
 (let (($x515 (= home requester)))
 (or $x515 $x464 $x801)))))
(assert
 (let (($x803 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x515 (= home requester)))
 (or $x515 $x292 $x803)))))
(assert
 (let (($x765 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x765))))
(assert
 (let (($x769 (not (= (cache.state_ __src) exclusive))))
 (let (($x908 (= __src real_owner)))
 (or $x908 $x769))))
(assert
 (let (($x773 (not (= (cache.state_ home) exclusive))))
 (let (($x442 (= home real_owner)))
 (or $x442 $x773))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x911 (= dir.hptr dir.hptr)))
 (or $x911 $x622))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x913 (= real_owner dir.hptr)))
 (or $x913 $x741))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x415 (= @V1 dir.hptr)))
 (or $x415 $x744))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x409 (= home dir.hptr)))
 (or $x409 $x747))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x277 (= __src dir.hptr)))
 (or $x277 $x751))))
(assert
 (let (($x765 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x911 (= dir.hptr dir.hptr)))
 (or $x911 $x765))))
(assert
 (let (($x769 (not (= (cache.state_ __src) exclusive))))
 (let (($x277 (= __src dir.hptr)))
 (or $x277 $x769))))
(assert
 (let (($x773 (not (= (cache.state_ home) exclusive))))
 (let (($x409 (= home dir.hptr)))
 (or $x409 $x773))))
(assert
 (let (($x922 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x922))))
(assert
 (let (($x925 (not (= (cache.state_ __src) shared))))
 (let (($x908 (= __src real_owner)))
 (or $x908 $x925))))
(assert
 (let (($x928 (not (= (cache.state_ home) shared))))
 (let (($x442 (= home real_owner)))
 (or $x442 $x928))))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x570))))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x572))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x622))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x429 (= home home)))
 (or $x429 $x741))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x429 (= home home)))
 (or $x429 $x744))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x747))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x429 (= home home)))
 (or $x429 $x751))))
(assert
 (let (($x542 (not (= (cache.state_ @V0) shared))))
 (let (($x576 (not (rp_net @V0))))
 (or $x576 $x542))))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (let (($x546 (= real_owner @X)))
 (or $x546 $x570))))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (let (($x550 (= real_owner @V0)))
 (or $x550 $x572))))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (let (($x913 (= real_owner dir.hptr)))
 (or $x913 $x622))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x814 (= real_owner real_owner)))
 (or $x814 $x741))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x744)))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x747))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (or (= real_owner __src) $x751)))
(assert
 (let (($x579 (not (net.put home @V0))))
 (or $x579 dir.head)))
(assert
 (let (($x581 (not (net.put dir.hptr @X))))
 (or $x581 dir.head)))
(assert
 (let (($x583 (not (net.put dir.hptr @V0))))
 (or $x583 dir.head)))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (or $x627 dir.head)))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (or $x778 dir.head)))
(assert
 (let (($x782 (not (net.put home @V1))))
 (or $x782 dir.head)))
(assert
 (let (($x785 (not (net.put home home))))
 (or $x785 dir.head)))
(assert
 (let (($x788 (not (net.put home __src))))
 (or $x788 dir.head)))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (or $x570 dir.head)))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (or $x572 dir.head)))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (or $x622 dir.head)))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (or $x741 dir.head)))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (or $x744 dir.head)))
(assert
 (let (($x747 (not (net.putX home home))))
 (or $x747 dir.head)))
(assert
 (let (($x751 (not (net.putX home __src))))
 (or $x751 dir.head)))
(assert
 (let (($x570 (not (net.putX real_owner @X))))
 (or $x570 dir.dirty)))
(assert
 (let (($x572 (not (net.putX real_owner @V0))))
 (or $x572 dir.dirty)))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (or $x622 dir.dirty)))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (or $x741 dir.dirty)))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (or $x744 dir.dirty)))
(assert
 (let (($x747 (not (net.putX home home))))
 (or $x747 dir.dirty)))
(assert
 (let (($x751 (not (net.putX home __src))))
 (or $x751 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (not (net.putX real_owner __src)))
(assert
 (let (($x622 (not (net.putX home dir.hptr))))
 (or $x622 dir.head)))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (or $x741 dir.head)))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (or $x744 dir.head)))
(assert
 (let (($x747 (not (net.putX home home))))
 (or $x747 dir.head)))
(assert
 (let (($x751 (not (net.putX home __src))))
 (or $x751 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (not (net.putX home __src)))
(assert
 (let (($x576 (not (rp_net @V0))))
 (let (($x579 (not (net.put home @V0))))
 (or $x579 $x576))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x581 (not (net.put dir.hptr @X))))
 (or $x581 $x342))))
(assert
 (let (($x576 (not (rp_net @V0))))
 (let (($x583 (not (net.put dir.hptr @V0))))
 (or $x583 $x576))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (or $x627 (not (rp_net dir.hptr)))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (or $x778 (not (rp_net real_owner)))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (or $x782 (not (rp_net @V1)))))
(assert
 (let (($x785 (not (net.put home home))))
 (or $x785 (not (rp_net home)))))
(assert
 (let (($x788 (not (net.put home __src))))
 (or $x788 (not (rp_net __src)))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (let (($x593 (not (invack @X))))
 (or $x593 (not (invnet @X)))))
(assert
 (let (($x596 (not (invack @V0))))
 (or $x596 (not (invnet @V0)))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x627 __dir.pending))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x778 __dir.pending))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x782 __dir.pending))))
(assert
 (let (($x785 (not (net.put home home))))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x785 __dir.pending))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 $x788 __dir.pending))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x990 __dir.pending))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x992 __dir.pending))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x994 __dir.pending))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x627 dir.dirty))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x778 dir.dirty))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x782 dir.dirty))))
(assert
 (let (($x785 (not (net.put home home))))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x785 dir.dirty))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 $x788 dir.dirty))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x990 dir.dirty))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x992 dir.dirty))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x994 dir.dirty))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x627))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x778))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x782))))
(assert
 (let (($x785 (not (net.put home home))))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x785))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 $x788))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x990))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x992))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x994))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x741))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x744))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x747))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 $x751))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x778))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x782))))
(assert
 (let (($x785 (not (net.put home home))))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x785))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 $x788))))
(assert
 (let (($x791 (not (__net.get real_owner home))))
 (let (($x1006 (dir.shlist real_owner)))
 (let (($x1036 (not $x1006)))
 (or $x1036 $x791)))))
(assert
 (let (($x794 (not (__net.get @V1 home))))
 (let (($x1008 (dir.shlist @V1)))
 (let (($x1038 (not $x1008)))
 (or $x1038 $x794)))))
(assert
 (let (($x585 (not (__net.get home home))))
 (let (($x1010 (dir.shlist home)))
 (let (($x1040 (not $x1010)))
 (or $x1040 $x585)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x450 (not $x271)))
 (let (($x1012 (dir.shlist __src)))
 (let (($x1042 (not $x1012)))
 (or $x1042 $x450))))))
(assert
 (let (($x1006 (dir.shlist real_owner)))
 (let (($x1036 (not $x1006)))
 (or $x1036 dir.head))))
(assert
 (let (($x1008 (dir.shlist @V1)))
 (let (($x1038 (not $x1008)))
 (or $x1038 dir.head))))
(assert
 (let (($x1010 (dir.shlist home)))
 (let (($x1040 (not $x1010)))
 (or $x1040 dir.head))))
(assert
 (let (($x1012 (dir.shlist __src)))
 (let (($x1042 (not $x1012)))
 (or $x1042 dir.head))))
(assert
 (let (($x765 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x765))))
(assert
 (let (($x769 (not (= (cache.state_ __src) exclusive))))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 $x769))))
(assert
 (let (($x773 (not (= (cache.state_ home) exclusive))))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x773))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let (($x813 (= real_owner home)))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x813 $x778)))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x292 $x782)))))
(assert
 (let (($x785 (not (net.put home home))))
 (let (($x429 (= home home)))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x429 $x785)))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 (= __src home) $x788))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let (($x652 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x652 $x990)))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let (($x813 (= real_owner home)))
 (let (($x1006 (dir.shlist real_owner)))
 (or $x1006 $x813 $x992)))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x1008 (dir.shlist @V1)))
 (or $x1008 $x292 $x994)))))
(assert
 (let (($x996 (not (net.put dir.hptr home))))
 (let (($x429 (= home home)))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x429 $x996)))))
(assert
 (let (($x765 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x1060 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1060 $x765)))))
(assert
 (let (($x769 (not (= (cache.state_ __src) exclusive))))
 (let (($x1062 (= __src requester)))
 (let (($x1012 (dir.shlist __src)))
 (or $x1012 $x1062 $x769)))))
(assert
 (let (($x773 (not (= (cache.state_ home) exclusive))))
 (let (($x515 (= home requester)))
 (let (($x1010 (dir.shlist home)))
 (or $x1010 $x515 $x773)))))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x741))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x744))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x747))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x751))))
(assert
 (let (($x922 (not (= (cache.state_ dir.hptr) shared))))
 (or $x922 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x925 (not (= (cache.state_ __src) shared))))
 (or $x925 (not (= (cache.wait __src) get)))))
(assert
 (let (($x928 (not (= (cache.state_ home) shared))))
 (or $x928 (not (= (cache.wait home) get)))))
(assert
 (let (($x765 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x765 dir.head)))
(assert
 (let (($x769 (not (= (cache.state_ __src) exclusive))))
 (or $x769 dir.head)))
(assert
 (let (($x773 (not (= (cache.state_ home) exclusive))))
 (or $x773 dir.head)))
(assert
 (let (($x741 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x739 (= ?x140 getX)))
 (or $x739 $x741)))))
(assert
 (let (($x744 (not (net.putX home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x686 (= ?x324 getX)))
 (or $x686 $x744)))))
(assert
 (let (($x747 (not (net.putX home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x747)))))
(assert
 (let (($x751 (not (net.putX home __src))))
 (let ((?x695 (cache.wait __src)))
 (let (($x749 (= ?x695 getX)))
 (or $x749 $x751)))))
(assert
 (let (($x963 (not (net.putX real_owner dir.hptr))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x679 (= ?x678 getX)))
 (or $x679 $x963)))))
(assert
 (let (($x965 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x739 (= ?x140 getX)))
 (or $x739 $x965)))))
(assert
 (let (($x967 (not (net.putX real_owner @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x686 (= ?x324 getX)))
 (or $x686 $x967)))))
(assert
 (let (($x969 (not (net.putX real_owner home))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x969)))))
(assert
 (let (($x754 (not (net.getX home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x754)))))
(assert
 (let (($x757 (not (net.getX @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x686 (= ?x324 getX)))
 (or $x686 $x757)))))
(assert
 (let (($x760 (not (net.getX @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x760)))))
(assert
 (let (($x799 (not (net.getX home @Z))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x799)))))
(assert
 (let (($x801 (not (net.getX home @V0))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x801)))))
(assert
 (let (($x803 (not (net.getX home @V1))))
 (let ((?x683 (cache.wait home)))
 (let (($x684 (= ?x683 getX)))
 (or $x684 $x803)))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x778)))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x780 (= ?x324 get)))
 (or $x780 $x782)))))
(assert
 (let (($x785 (not (net.put home home))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x785)))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let ((?x695 (cache.wait __src)))
 (let (($x696 (= ?x695 get)))
 (or $x696 $x788)))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x693 (= ?x678 get)))
 (or $x693 $x990)))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x992)))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x780 (= ?x324 get)))
 (or $x780 $x994)))))
(assert
 (let (($x996 (not (net.put dir.hptr home))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x996)))))
(assert
 (let (($x591 (not (__net.get home @V1))))
 (let ((?x683 (cache.wait home)))
 (let (($x702 (= ?x683 get)))
 (or $x702 $x591)))))
(assert
 (let (($x631 (not (__net.get dir.hptr home))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x693 (= ?x678 get)))
 (or $x693 $x631)))))
(assert
 (let (($x637 (not (__net.get @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x637)))))
(assert
 (let (($x791 (not (__net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x791)))))
(assert
 (let (($x794 (not (__net.get @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x780 (= ?x324 get)))
 (or $x780 $x794)))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (let ((?x1090 (cache.state_ real_owner)))
 (let (($x1091 (= ?x1090 invalid)))
 (or $x1091 $x778)))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (let ((?x1093 (cache.state_ @V1)))
 (let (($x1094 (= ?x1093 invalid)))
 (or $x1094 $x782)))))
(assert
 (let (($x785 (not (net.put home home))))
 (let ((?x722 (cache.state_ home)))
 (let (($x723 (= ?x722 invalid)))
 (or $x723 $x785)))))
(assert
 (let (($x788 (not (net.put home __src))))
 (let ((?x715 (cache.state_ __src)))
 (let (($x716 (= ?x715 invalid)))
 (or $x716 $x788)))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let ((?x712 (cache.state_ dir.hptr)))
 (let (($x713 (= ?x712 invalid)))
 (or $x713 $x990)))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let ((?x1090 (cache.state_ real_owner)))
 (let (($x1091 (= ?x1090 invalid)))
 (or $x1091 $x992)))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let ((?x1093 (cache.state_ @V1)))
 (let (($x1094 (= ?x1093 invalid)))
 (or $x1094 $x994)))))
(assert
 (let (($x996 (not (net.put dir.hptr home))))
 (let ((?x722 (cache.state_ home)))
 (let (($x723 (= ?x722 invalid)))
 (or $x723 $x996)))))
(assert
 (let (($x591 (not (__net.get home @V1))))
 (let ((?x722 (cache.state_ home)))
 (let (($x723 (= ?x722 invalid)))
 (or $x723 $x591)))))
(assert
 (let (($x631 (not (__net.get dir.hptr home))))
 (let ((?x712 (cache.state_ dir.hptr)))
 (let (($x713 (= ?x712 invalid)))
 (or $x713 $x631)))))
(assert
 (let (($x637 (not (__net.get @V0 home))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x637)))))
(assert
 (let (($x791 (not (__net.get real_owner home))))
 (let ((?x1090 (cache.state_ real_owner)))
 (let (($x1091 (= ?x1090 invalid)))
 (or $x1091 $x791)))))
(assert
 (let (($x794 (not (__net.get @V1 home))))
 (let ((?x1093 (cache.state_ @V1)))
 (let (($x1094 (= ?x1093 invalid)))
 (or $x1094 $x794)))))
(assert
 (let (($x733 (not (= (cache.wait home) none))))
 (let (($x754 (not (net.getX home home))))
 (or $x754 $x733))))
(assert
 (let (($x326 (not (= (cache.wait @V1) none))))
 (let (($x757 (not (net.getX @V1 home))))
 (or $x757 $x326))))
(assert
 (let (($x737 (not (= (cache.wait @V0) none))))
 (let (($x760 (not (net.getX @V0 home))))
 (or $x760 $x737))))
(assert
 (let (($x733 (not (= (cache.wait home) none))))
 (let (($x799 (not (net.getX home @Z))))
 (or $x799 $x733))))
(assert
 (let (($x733 (not (= (cache.wait home) none))))
 (let (($x801 (not (net.getX home @V0))))
 (or $x801 $x733))))
(assert
 (let (($x733 (not (= (cache.wait home) none))))
 (let (($x803 (not (net.getX home @V1))))
 (or $x803 $x733))))
(assert
 (let (($x1114 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x739 (= ?x140 getX)))
 (or $x739 $x1114)))))
(assert
 (let (($x1117 (not (net.getX dir.hptr home))))
 (let ((?x678 (cache.wait dir.hptr)))
 (let (($x679 (= ?x678 getX)))
 (or $x679 $x1117)))))
(assert
 (let (($x1120 (not (net.getX __src home))))
 (let ((?x695 (cache.wait __src)))
 (let (($x749 (= ?x695 getX)))
 (or $x749 $x1120)))))
(assert
 (let (($x1123 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1123 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1127 (not (= (cache.state_ @V1) exclusive))))
 (or $x1127 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x627 (not (net.put home dir.hptr))))
 (or $x627 (not (rp_net dir.hptr)))))
(assert
 (let (($x778 (not (net.put home real_owner))))
 (or $x778 (not (rp_net real_owner)))))
(assert
 (let (($x782 (not (net.put home @V1))))
 (or $x782 (not (rp_net @V1)))))
(assert
 (let (($x785 (not (net.put home home))))
 (or $x785 (not (rp_net home)))))
(assert
 (let (($x788 (not (net.put home __src))))
 (or $x788 (not (rp_net __src)))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x990)))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x992)))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x994)))))
(assert
 (let (($x996 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x996)))))
(assert
 (let (($x998 (not (net.put dir.hptr __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x145 $x998)))))
(assert
 (let (($x963 (not (net.putX real_owner dir.hptr))))
 (let (($x814 (= real_owner real_owner)))
 (let (($x813 (= real_owner home)))
 (or $x813 $x814 $x963)))))
(assert
 (let (($x965 (not (net.putX real_owner real_owner))))
 (let (($x814 (= real_owner real_owner)))
 (let (($x813 (= real_owner home)))
 (or $x813 $x814 $x965)))))
(assert
 (let (($x967 (not (net.putX real_owner @V1))))
 (let (($x814 (= real_owner real_owner)))
 (let (($x813 (= real_owner home)))
 (or $x813 $x814 $x967)))))
(assert
 (let (($x969 (not (net.putX real_owner home))))
 (let (($x814 (= real_owner real_owner)))
 (let (($x813 (= real_owner home)))
 (or $x813 $x814 $x969)))))
(assert
 (let (($x971 (not (net.putX real_owner __src))))
 (let (($x814 (= real_owner real_owner)))
 (let (($x813 (= real_owner home)))
 (or $x813 $x814 $x971)))))
(assert
 (let (($x1114 (not (net.getX real_owner home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x1114)))))
(assert
 (let (($x1117 (not (net.getX dir.hptr home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x1117)))))
(assert
 (let (($x1120 (not (net.getX __src home))))
 (let (($x442 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x442 $x1120)))))
(assert
 (let (($x990 (not (net.put dir.hptr dir.hptr))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x990 dir.dirty))))
(assert
 (let (($x992 (not (net.put dir.hptr real_owner))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x992 dir.dirty))))
(assert
 (let (($x994 (not (net.put dir.hptr @V1))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x994 dir.dirty))))
(assert
 (let (($x996 (not (net.put dir.hptr home))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x996 dir.dirty))))
(assert
 (let (($x998 (not (net.put dir.hptr __src))))
 (let (($x652 (= dir.hptr home)))
 (or $x652 $x998 dir.dirty))))
(assert
 (let (($x963 (not (net.putX real_owner dir.hptr))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x963 dir.head))))
(assert
 (let (($x965 (not (net.putX real_owner real_owner))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x965 dir.head))))
(assert
 (let (($x967 (not (net.putX real_owner @V1))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x967 dir.head))))
(assert
 (let (($x969 (not (net.putX real_owner home))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x969 dir.head))))
(assert
 (let (($x971 (not (net.putX real_owner __src))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x971 dir.head))))
(assert
 (let (($x963 (not (net.putX real_owner dir.hptr))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x963 dir.dirty))))
(assert
 (let (($x965 (not (net.putX real_owner real_owner))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x965 dir.dirty))))
(assert
 (let (($x967 (not (net.putX real_owner @V1))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x967 dir.dirty))))
(assert
 (let (($x969 (not (net.putX real_owner home))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x969 dir.dirty))))
(assert
 (let (($x971 (not (net.putX real_owner __src))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x971 dir.dirty))))
(assert
 (let (($x963 (not (net.putX real_owner dir.hptr))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x963))))
(assert
 (let (($x965 (not (net.putX real_owner real_owner))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x965))))
(assert
 (let (($x967 (not (net.putX real_owner @V1))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x967))))
(assert
 (let (($x969 (not (net.putX real_owner home))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x969))))
(assert
 (let (($x971 (not (net.putX real_owner __src))))
 (let (($x813 (= real_owner home)))
 (or $x813 $x971))))
(assert
 (let (($x1114 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x1114 dir.head))))
(assert
 (let (($x1117 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x1117 dir.head))))
(assert
 (let (($x1120 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x1120 dir.head))))
(assert
 (let (($x1114 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x1114 dir.dirty))))
(assert
 (let (($x1117 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x1117 dir.dirty))))
(assert
 (let (($x1120 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x1120 dir.dirty))))
(assert
 (let (($x1114 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x1114))))
(assert
 (let (($x1117 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x1117))))
(assert
 (let (($x1120 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x1120))))
(assert
 (let (($x1114 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or (= real_owner requester) $x429 $x1114))))
(assert
 (let (($x1117 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (let (($x1060 (= dir.hptr requester)))
 (or $x1060 $x429 $x1117)))))
(assert
 (let (($x1120 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (let (($x1062 (= __src requester)))
 (or $x1062 $x429 $x1120)))))
(assert
 (let (($x1123 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x814 (= real_owner real_owner)))
 (or $x814 $x1123))))
(assert
 (let (($x1127 (not (= (cache.state_ @V1) exclusive))))
 (let (($x444 (= @V1 real_owner)))
 (or $x444 $x1127))))
(assert
 (let (($x1123 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x913 (= real_owner dir.hptr)))
 (or $x913 $x1123))))
(assert
 (let (($x1127 (not (= (cache.state_ @V1) exclusive))))
 (let (($x415 (= @V1 dir.hptr)))
 (or $x415 $x1127))))
(assert
 (let (($x814 (= real_owner real_owner)))
 (or $x814 (not (= (cache.state_ real_owner) shared)))))
(check-sat)
