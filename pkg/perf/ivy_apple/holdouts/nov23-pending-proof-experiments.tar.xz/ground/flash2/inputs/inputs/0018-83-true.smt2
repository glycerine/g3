(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __rp_net (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun __dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x56 (not dir.head)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x56))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__rp_net __src))
(assert
 (let (($x272 (= dir.hptr __src)))
 (not $x272)))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x375 (not (net.getX home @Y))))
 (let (($x354 (not (net.getX @X @Z))))
 (let (($x362 (not (net.getX @X @Y))))
 (let (($x363 (= @Y @Z)))
 (let (($x376 (and (or $x363 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x363 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x363 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x363 $x362 $x354) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x354 (not (net.putX @Y @X))) $x375 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x335 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x376)))))))))
(assert
 (let (($x348 (dir.shlist dir.hptr)))
 (= $x348 (ite (and (= dir.hptr __src)) false (__dir.shlist dir.hptr)))))
(assert
 (let (($x338 (rp_net @X)))
 (= $x338 (ite (and (= @X __src)) false (__rp_net @X)))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let (($x405 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x405 $x357)))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let (($x408 (= @Z real_owner)))
 (let (($x407 (= @Z home)))
 (or $x407 $x408 $x372)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x413 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x413 $x303)))))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (let (($x405 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x405 $x351)))))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (let (($x408 (= @Z real_owner)))
 (let (($x407 (= @Z home)))
 (or $x407 $x408 $x366)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x413 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x413 $x297)))))
(assert
 (let (($x369 (not (net.get @X @Y))))
 (let (($x405 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x405 $x369)))))
(assert
 (let (($x359 (not (net.get @X @Z))))
 (let (($x408 (= @Z real_owner)))
 (let (($x407 (= @Z home)))
 (or $x407 $x408 $x359)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x413 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x413 $x307)))))
(assert
 (let (($x362 (not (net.getX @X @Y))))
 (let (($x405 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x405 $x362)))))
(assert
 (let (($x354 (not (net.getX @X @Z))))
 (let (($x408 (= @Z real_owner)))
 (let (($x407 (= @Z home)))
 (or $x407 $x408 $x354)))))
(assert
 (let (($x375 (not (net.getX home @Y))))
 (let (($x405 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x405 $x375)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x428 (= @V0 real_owner)))
 (let (($x427 (= @V0 home)))
 (or $x427 $x428 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x413 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x413 $x300)))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x357 dir.dirty))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let (($x407 (= @Z home)))
 (or $x407 $x372 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x410 (= home home)))
 (or $x410 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x303 dir.dirty))))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x351 dir.head))))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (let (($x407 (= @Z home)))
 (or $x407 $x366 dir.head))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x410 (= home home)))
 (or $x410 $x326 dir.head))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.head))))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x351 dir.dirty))))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (let (($x407 (= @Z home)))
 (or $x407 $x366 dir.dirty))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x410 (= home home)))
 (or $x410 $x326 dir.dirty))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.dirty))))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x351))))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (let (($x407 (= @Z home)))
 (or $x407 $x366))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x410 (= home home)))
 (or $x410 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x369 (not (net.get @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x369 dir.head))))
(assert
 (let (($x359 (not (net.get @X @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x359 dir.head))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x410 (= home home)))
 (or $x410 $x346 dir.head))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x307 dir.head))))
(assert
 (let (($x369 (not (net.get @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x369 dir.dirty))))
(assert
 (let (($x359 (not (net.get @X @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x359 dir.dirty))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x410 (= home home)))
 (or $x410 $x346 dir.dirty))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x307 dir.dirty))))
(assert
 (let (($x362 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x362 dir.head))))
(assert
 (let (($x354 (not (net.getX @X @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x354 dir.head))))
(assert
 (let (($x375 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x375 dir.head))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x410 (= home home)))
 (or $x410 $x331 dir.head))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x427 (= @V0 home)))
 (or $x427 $x320 dir.head))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300 dir.head))))
(assert
 (let (($x362 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x362 dir.dirty))))
(assert
 (let (($x354 (not (net.getX @X @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x354 dir.dirty))))
(assert
 (let (($x375 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x375 dir.dirty))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x410 (= home home)))
 (or $x410 $x331 dir.dirty))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x427 (= @V0 home)))
 (or $x427 $x320 dir.dirty))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300 dir.dirty))))
(assert
 (let (($x362 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x362))))
(assert
 (let (($x354 (not (net.getX @X @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x354))))
(assert
 (let (($x375 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x375))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x410 (= home home)))
 (or $x410 $x331))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x427 (= @V0 home)))
 (or $x427 $x320))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300))))
(assert
 (let (($x362 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (let (($x473 (= @X requester)))
 (or $x473 $x314 $x362)))))
(assert
 (let (($x354 (not (net.getX @X @Z))))
 (let (($x407 (= @Z home)))
 (let (($x473 (= @X requester)))
 (or $x473 $x407 $x354)))))
(assert
 (let (($x375 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (let (($x476 (= home requester)))
 (or $x476 $x314 $x375)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x410 (= home home)))
 (let (($x473 (= @X requester)))
 (or $x473 $x410 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x427 (= @V0 home)))
 (let (($x479 (= @V1 requester)))
 (or $x479 $x427 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x481 (= @V0 requester)))
 (or $x481 $x289 $x300)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x428 (= @V0 real_owner)))
 (or $x428 $x292))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x486 (= @X real_owner)))
 (or $x486 $x335))))
(assert
 (let (($x489 (not (= (cache.state_ @V0) exclusive))))
 (let (($x428 (= @V0 real_owner)))
 (or $x428 $x489))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x491 (= @X dir.hptr)))
 (or $x491 $x326))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x493 (= @V0 dir.hptr)))
 (or $x493 $x495))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x491 (= @X dir.hptr)))
 (or $x491 $x335))))
(assert
 (let (($x489 (not (= (cache.state_ @V0) exclusive))))
 (let (($x493 (= @V0 dir.hptr)))
 (or $x493 $x489))))
(assert
 (let (($x500 (not (= (cache.state_ @X) shared))))
 (let (($x486 (= @X real_owner)))
 (or $x486 $x500))))
(assert
 (let (($x503 (not (= (cache.state_ @V0) shared))))
 (let (($x428 (= @V0 real_owner)))
 (or $x428 $x503))))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x351))))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (let (($x407 (= @Z home)))
 (or $x407 $x366))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x410 (= home home)))
 (or $x410 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x410 (= home home)))
 (or $x410 $x495))))
(assert
 (let (($x500 (not (= (cache.state_ @X) shared))))
 (let (($x402 (__rp_net @X)))
 (let (($x506 (not $x402)))
 (or $x506 $x500)))))
(assert
 (let (($x503 (not (= (cache.state_ @V0) shared))))
 (let (($x509 (not (__rp_net @V0))))
 (or $x509 $x503))))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x351))))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x366))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x515 (= real_owner @V0)))
 (or $x515 $x297))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x515 (= real_owner @V0)))
 (or $x515 $x495))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (or $x357 dir.head)))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (or $x372 dir.head)))
(assert
 (let (($x341 (not (net.put home @X))))
 (or $x341 dir.head)))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 dir.head)))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (or $x351 dir.head)))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (or $x366 dir.head)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.head)))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (or $x495 dir.head)))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (or $x351 dir.dirty)))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (or $x366 dir.dirty)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.dirty)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.dirty)))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (or $x495 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (or $x495 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x402 (__rp_net @X)))
 (let (($x506 (not $x402)))
 (let (($x357 (not (net.put @Y @X))))
 (or $x357 $x506)))))
(assert
 (let (($x402 (__rp_net @X)))
 (let (($x506 (not $x402)))
 (let (($x372 (not (net.put @Z @X))))
 (or $x372 $x506)))))
(assert
 (let (($x402 (__rp_net @X)))
 (let (($x506 (not $x402)))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x506)))))
(assert
 (let (($x509 (not (__rp_net @V0))))
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 $x509))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x500 (not (= (cache.state_ @X) shared))))
 (let (($x557 (not (invack @X))))
 (or $x557 $x500))))
(assert
 (let (($x503 (not (= (cache.state_ @V0) shared))))
 (let (($x560 (not (invack @V0))))
 (or $x560 $x503))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x357 dir.pending))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x372 dir.pending))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x341 dir.pending))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x303 dir.pending))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x543 dir.pending))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x545 dir.pending))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x547 dir.pending))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x357 dir.dirty))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x372 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x303 dir.dirty))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x543 dir.dirty))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x545 dir.dirty))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x547 dir.dirty))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x357))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x372))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x341))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x303))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x543))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x545))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x547))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x586))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x326))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x495))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x591))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x341))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x543))))
(assert
 (let (($x595 (not (net.get dir.hptr home))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (let (($x593 (not $x58)))
 (or $x593 $x595)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x562 (__dir.shlist @X)))
 (let (($x597 (not $x562)))
 (or $x597 $x346)))))
(assert
 (let (($x601 (not (net.get @V0 home))))
 (let (($x566 (__dir.shlist @V0)))
 (let (($x599 (not $x566)))
 (or $x599 $x601)))))
(assert
 (let (($x58 (__dir.shlist dir.hptr)))
 (let (($x593 (not $x58)))
 (or $x593 dir.head))))
(assert
 (let (($x562 (__dir.shlist @X)))
 (let (($x597 (not $x562)))
 (or $x597 dir.head))))
(assert
 (let (($x566 (__dir.shlist @V0)))
 (let (($x599 (not $x566)))
 (or $x599 dir.head))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x335))))
(assert
 (let (($x489 (not (= (cache.state_ @V0) exclusive))))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x489))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let (($x608 (= @X home)))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x608 $x357)))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let (($x608 (= @X home)))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x608 $x372)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x608 (= @X home)))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x608 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x427 (= @V0 home)))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x427 $x303)))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let (($x427 (= @V0 home)))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x427 $x543)))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let (($x608 (= @X home)))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x608 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let (($x427 (= @V0 home)))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x427 $x547)))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let (($x616 (= dir.hptr home)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x616 $x591)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x473 (= @X requester)))
 (let (($x562 (__dir.shlist @X)))
 (or $x562 $x473 $x335)))))
(assert
 (let (($x489 (not (= (cache.state_ @V0) exclusive))))
 (let (($x481 (= @V0 requester)))
 (let (($x566 (__dir.shlist @V0)))
 (or $x566 $x481 $x489)))))
(assert
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (let (($x486 (= @X real_owner)))
 (or (__dir.real @X) $x486 $x621)))))
(assert
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (let (($x428 (= @V0 real_owner)))
 (or (__dir.real @V0) $x428 $x310)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x326))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x495))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x586))))
(assert
 (let (($x500 (not (= (cache.state_ @X) shared))))
 (or $x500 (not (= (cache.wait @X) get)))))
(assert
 (let (($x503 (not (= (cache.state_ @V0) shared))))
 (or $x503 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x557 (not (invack @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x557)))))
(assert
 (let (($x560 (not (invack @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x560)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 dir.head)))
(assert
 (let (($x489 (not (= (cache.state_ @V0) exclusive))))
 (or $x489 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x410 (= home home)))
 (or $x410 $x187))))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x292))))
(assert
 (let (($x351 (not (net.putX @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x351)))))
(assert
 (let (($x366 (not (net.putX @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x366)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x297)))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x495)))))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x535)))))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x537)))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x643 (= ?x642 getX)))
 (or $x643 $x586)))))
(assert
 (let (($x362 (not (net.getX @X @Y))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x362)))))
(assert
 (let (($x354 (not (net.getX @X @Z))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x354)))))
(assert
 (let (($x375 (not (net.getX home @Y))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x375)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x650 (= ?x321 getX)))
 (or $x650 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x300)))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x357)))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x372)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x303)))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x543)))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x547)))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x657 (= ?x642 get)))
 (or $x657 $x591)))))
(assert
 (let (($x369 (not (net.get @X @Y))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x369)))))
(assert
 (let (($x359 (not (net.get @X @Z))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x359)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x307)))))
(assert
 (let (($x549 (not (net.get home @Y))))
 (let ((?x647 (cache.wait home)))
 (let (($x661 (= ?x647 get)))
 (or $x661 $x549)))))
(assert
 (let (($x551 (not (net.get home @Z))))
 (let ((?x647 (cache.wait home)))
 (let (($x661 (= ?x647 get)))
 (or $x661 $x551)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x661 (= ?x647 get)))
 (or $x661 $x553)))))
(assert
 (let (($x555 (not (net.get home @V1))))
 (let ((?x647 (cache.wait home)))
 (let (($x661 (= ?x647 get)))
 (or $x661 $x555)))))
(assert
 (let (($x357 (not (net.put @Y @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x357)))))
(assert
 (let (($x372 (not (net.put @Z @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x372)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x303)))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x543)))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x547)))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let ((?x672 (cache.state_ dir.hptr)))
 (let (($x673 (= ?x672 invalid)))
 (or $x673 $x591)))))
(assert
 (let (($x369 (not (net.get @X @Y))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x369)))))
(assert
 (let (($x359 (not (net.get @X @Z))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x359)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x621 (= ?x333 invalid)))
 (or $x621 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x307)))))
(assert
 (let (($x549 (not (net.get home @Y))))
 (let ((?x678 (cache.state_ home)))
 (let (($x679 (= ?x678 invalid)))
 (or $x679 $x549)))))
(assert
 (let (($x551 (not (net.get home @Z))))
 (let ((?x678 (cache.state_ home)))
 (let (($x679 (= ?x678 invalid)))
 (or $x679 $x551)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let ((?x678 (cache.state_ home)))
 (let (($x679 (= ?x678 invalid)))
 (or $x679 $x553)))))
(assert
 (let (($x555 (not (net.get home @V1))))
 (let ((?x678 (cache.state_ home)))
 (let (($x679 (= ?x678 invalid)))
 (or $x679 $x555)))))
(assert
 (let (($x314 (= @Y home)))
 (or $x314 (not (net.shwb @X @Y)))))
(assert
 (let (($x410 (= home home)))
 (or $x410 (not (net.shwb @X home)))))
(assert
 (let (($x686 (not (= (cache.wait @X) none))))
 (let (($x362 (not (net.getX @X @Y))))
 (or $x362 $x686))))
(assert
 (let (($x686 (not (= (cache.wait @X) none))))
 (let (($x354 (not (net.getX @X @Z))))
 (or $x354 $x686))))
(assert
 (let (($x690 (not (= (cache.wait home) none))))
 (let (($x375 (not (net.getX home @Y))))
 (or $x375 $x690))))
(assert
 (let (($x686 (not (= (cache.wait @X) none))))
 (let (($x331 (not (net.getX @X home))))
 (or $x331 $x686))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x320 (not (net.getX @V1 @V0))))
 (or $x320 $x323))))
(assert
 (let (($x694 (not (= (cache.wait @V0) none))))
 (let (($x300 (not (net.getX @V0 @V1))))
 (or $x300 $x694))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x696 (= ?x140 getX)))
 (or $x696 $x698)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x650 (= ?x321 getX)))
 (or $x650 $x701)))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x495)))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x643 (= ?x642 getX)))
 (or $x643 $x586)))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x704)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x331)))))
(assert
 (let (($x707 (not (net.getX home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x707)))))
(assert
 (let (($x710 (not (net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x650 (= ?x321 getX)))
 (or $x650 $x710)))))
(assert
 (let (($x713 (not (net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x713)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x489 (not (= (cache.state_ @V0) exclusive))))
 (or $x489 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x718 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x718 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x722 (not (= (cache.state_ home) exclusive))))
 (or $x722 (not (= (cache.wait home) getX)))))
(assert
 (let (($x271 (__rp_net __src)))
 (let (($x727 (not $x271)))
 (let (($x726 (not (net.put home __src))))
 (or $x726 $x727)))))
(assert
 (let (($x402 (__rp_net @X)))
 (let (($x506 (not $x402)))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x506)))))
(assert
 (let (($x509 (not (__rp_net @V0))))
 (let (($x543 (not (net.put home @V0))))
 (or $x543 $x509))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x731)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x733 (= ?x321 get)))
 (or $x733 $x735)))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x543)))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x657 (= ?x642 get)))
 (or $x657 $x591)))))
(assert
 (let (($x738 (not (net.put home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x661 (= ?x647 get)))
 (or $x661 $x738)))))
(assert
 (let (($x741 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x741)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x346)))))
(assert
 (let (($x744 (not (net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x733 (= ?x321 get)))
 (or $x733 $x744)))))
(assert
 (let (($x601 (not (net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x601)))))
(assert
 (let (($x595 (not (net.get dir.hptr home))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x657 (= ?x642 get)))
 (or $x657 $x595)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x661 (= ?x647 get)))
 (or $x661 $x553)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x543)))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x145 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x145 $x547)))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x591)))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x726)))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x731)))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x735)))))
(assert
 (let (($x738 (not (net.put home home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x738)))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x495)))))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x535)))))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x537)))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x586)))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x698)))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x701)))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x704)))))
(assert
 (let (($x549 (not (net.get home @Y))))
 (let (($x405 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x405 $x549)))))
(assert
 (let (($x551 (not (net.get home @Z))))
 (let (($x408 (= @Z real_owner)))
 (let (($x407 (= @Z home)))
 (or $x407 $x408 $x551)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x553)))))
(assert
 (let (($x555 (not (net.get home @V1))))
 (let (($x413 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x413 $x555)))))
(assert
 (let (($x595 (not (net.get dir.hptr home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x595)))))
(assert
 (let (($x601 (not (net.get @V0 home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x601)))))
(assert
 (let (($x741 (not (net.get real_owner home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x741)))))
(assert
 (let (($x744 (not (net.get @V1 home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x744)))))
(assert
 (let (($x707 (not (net.getX home home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x707)))))
(assert
 (let (($x710 (not (net.getX @V1 home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x710)))))
(assert
 (let (($x713 (not (net.getX @V0 home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x713)))))
(assert
 (let (($x749 (not (net.getX home @Z))))
 (let (($x408 (= @Z real_owner)))
 (let (($x407 (= @Z home)))
 (or $x407 $x408 $x749)))))
(assert
 (let (($x751 (not (net.getX home @V0))))
 (let (($x428 (= @V0 real_owner)))
 (let (($x427 (= @V0 home)))
 (or $x427 $x428 $x751)))))
(assert
 (let (($x753 (not (net.getX home @V1))))
 (let (($x413 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x413 $x753)))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (let (($x410 (= home home)))
 (or $x410 $x543 dir.dirty))))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x545 dir.dirty))))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x547 dir.dirty))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let (($x410 (= home home)))
 (or $x410 $x591 dir.dirty))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let (($x410 (= home home)))
 (or $x410 $x726 dir.dirty))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let (($x410 (= home home)))
 (or $x410 $x731 dir.dirty))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let (($x410 (= home home)))
 (or $x410 $x735 dir.dirty))))
(assert
 (let (($x738 (not (net.put home home))))
 (let (($x410 (= home home)))
 (or $x410 $x738 dir.dirty))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x410 (= home home)))
 (or $x410 $x495 dir.head))))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x535 dir.head))))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x537 dir.head))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x410 (= home home)))
 (or $x410 $x586 dir.head))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x410 (= home home)))
 (or $x410 $x698 dir.head))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x410 (= home home)))
 (or $x410 $x701 dir.head))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x410 (= home home)))
 (or $x410 $x704 dir.head))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x410 (= home home)))
 (or $x410 $x495 dir.dirty))))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x535 dir.dirty))))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x537 dir.dirty))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x410 (= home home)))
 (or $x410 $x586 dir.dirty))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x410 (= home home)))
 (or $x410 $x698 dir.dirty))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x410 (= home home)))
 (or $x410 $x701 dir.dirty))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x410 (= home home)))
 (or $x410 $x704 dir.dirty))))
(assert
 (let (($x495 (not (net.putX home @V0))))
 (let (($x410 (= home home)))
 (or $x410 $x495))))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x535))))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x537))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x410 (= home home)))
 (or $x410 $x586))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x410 (= home home)))
 (or $x410 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x410 (= home home)))
 (or $x410 $x701))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x410 (= home home)))
 (or $x410 $x704))))
(assert
 (let (($x549 (not (net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x549 dir.head))))
(assert
 (let (($x551 (not (net.get home @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x551 dir.head))))
(assert
 (let (($x553 (not (net.get home home))))
 (let (($x410 (= home home)))
 (or $x410 $x553 dir.head))))
(assert
 (let (($x555 (not (net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x555 dir.head))))
(assert
 (let (($x595 (not (net.get dir.hptr home))))
 (let (($x410 (= home home)))
 (or $x410 $x595 dir.head))))
(assert
 (let (($x601 (not (net.get @V0 home))))
 (let (($x410 (= home home)))
 (or $x410 $x601 dir.head))))
(assert
 (let (($x741 (not (net.get real_owner home))))
 (let (($x410 (= home home)))
 (or $x410 $x741 dir.head))))
(assert
 (let (($x744 (not (net.get @V1 home))))
 (let (($x410 (= home home)))
 (or $x410 $x744 dir.head))))
(assert
 (let (($x549 (not (net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x549 dir.dirty))))
(assert
 (let (($x551 (not (net.get home @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x551 dir.dirty))))
(assert
 (let (($x553 (not (net.get home home))))
 (let (($x410 (= home home)))
 (or $x410 $x553 dir.dirty))))
(assert
 (let (($x555 (not (net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x555 dir.dirty))))
(assert
 (let (($x595 (not (net.get dir.hptr home))))
 (let (($x410 (= home home)))
 (or $x410 $x595 dir.dirty))))
(assert
 (let (($x601 (not (net.get @V0 home))))
 (let (($x410 (= home home)))
 (or $x410 $x601 dir.dirty))))
(assert
 (let (($x741 (not (net.get real_owner home))))
 (let (($x410 (= home home)))
 (or $x410 $x741 dir.dirty))))
(assert
 (let (($x744 (not (net.get @V1 home))))
 (let (($x410 (= home home)))
 (or $x410 $x744 dir.dirty))))
(assert
 (let (($x707 (not (net.getX home home))))
 (let (($x410 (= home home)))
 (or $x410 $x707 dir.head))))
(assert
 (let (($x710 (not (net.getX @V1 home))))
 (let (($x410 (= home home)))
 (or $x410 $x710 dir.head))))
(assert
 (let (($x713 (not (net.getX @V0 home))))
 (let (($x410 (= home home)))
 (or $x410 $x713 dir.head))))
(assert
 (let (($x749 (not (net.getX home @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x749 dir.head))))
(assert
 (let (($x751 (not (net.getX home @V0))))
 (let (($x427 (= @V0 home)))
 (or $x427 $x751 dir.head))))
(assert
 (let (($x753 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x753 dir.head))))
(assert
 (let (($x707 (not (net.getX home home))))
 (let (($x410 (= home home)))
 (or $x410 $x707 dir.dirty))))
(assert
 (let (($x710 (not (net.getX @V1 home))))
 (let (($x410 (= home home)))
 (or $x410 $x710 dir.dirty))))
(assert
 (let (($x713 (not (net.getX @V0 home))))
 (let (($x410 (= home home)))
 (or $x410 $x713 dir.dirty))))
(assert
 (let (($x749 (not (net.getX home @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x749 dir.dirty))))
(assert
 (let (($x751 (not (net.getX home @V0))))
 (let (($x427 (= @V0 home)))
 (or $x427 $x751 dir.dirty))))
(assert
 (let (($x753 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x753 dir.dirty))))
(assert
 (let (($x707 (not (net.getX home home))))
 (let (($x410 (= home home)))
 (or $x410 $x707))))
(assert
 (let (($x710 (not (net.getX @V1 home))))
 (let (($x410 (= home home)))
 (or $x410 $x710))))
(assert
 (let (($x713 (not (net.getX @V0 home))))
 (let (($x410 (= home home)))
 (or $x410 $x713))))
(assert
 (let (($x749 (not (net.getX home @Z))))
 (let (($x407 (= @Z home)))
 (or $x407 $x749))))
(assert
 (let (($x751 (not (net.getX home @V0))))
 (let (($x427 (= @V0 home)))
 (or $x427 $x751))))
(assert
 (let (($x753 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x753))))
(assert
 (let (($x707 (not (net.getX home home))))
 (let (($x410 (= home home)))
 (let (($x476 (= home requester)))
 (or $x476 $x410 $x707)))))
(assert
 (let (($x710 (not (net.getX @V1 home))))
 (let (($x410 (= home home)))
 (let (($x479 (= @V1 requester)))
 (or $x479 $x410 $x710)))))
(assert
 (let (($x713 (not (net.getX @V0 home))))
 (let (($x410 (= home home)))
 (let (($x481 (= @V0 requester)))
 (or $x481 $x410 $x713)))))
(assert
 (let (($x749 (not (net.getX home @Z))))
 (let (($x407 (= @Z home)))
 (let (($x476 (= home requester)))
 (or $x476 $x407 $x749)))))
(assert
 (let (($x751 (not (net.getX home @V0))))
 (let (($x427 (= @V0 home)))
 (let (($x476 (= home requester)))
 (or $x476 $x427 $x751)))))
(assert
 (let (($x753 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x476 (= home requester)))
 (or $x476 $x289 $x753)))))
(assert
 (let (($x718 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x718))))
(assert
 (let (($x722 (not (= (cache.state_ home) exclusive))))
 (let (($x411 (= home real_owner)))
 (or $x411 $x722))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x855 (= dir.hptr dir.hptr)))
 (or $x855 $x586))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x857 (= real_owner dir.hptr)))
 (or $x857 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x859 (= @V1 dir.hptr)))
 (or $x859 $x701))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x861 (= home dir.hptr)))
 (or $x861 $x704))))
(assert
 (let (($x718 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x855 (= dir.hptr dir.hptr)))
 (or $x855 $x718))))
(assert
 (let (($x722 (not (= (cache.state_ home) exclusive))))
 (let (($x861 (= home dir.hptr)))
 (or $x861 $x722))))
(assert
 (let (($x866 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x866))))
(assert
 (let (($x869 (not (= (cache.state_ home) shared))))
 (let (($x411 (= home real_owner)))
 (or $x411 $x869))))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x535))))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x537))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x410 (= home home)))
 (or $x410 $x586))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x410 (= home home)))
 (or $x410 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x410 (= home home)))
 (or $x410 $x701))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x410 (= home home)))
 (or $x410 $x704))))
(assert
 (let (($x873 (not (= (cache.state_ __src) shared))))
 (let (($x271 (__rp_net __src)))
 (let (($x727 (not $x271)))
 (or $x727 $x873)))))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x535))))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (let (($x515 (= real_owner @V0)))
 (or $x515 $x537))))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (let (($x857 (= real_owner dir.hptr)))
 (or $x857 $x586))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x879 (= real_owner @V1)))
 (or $x879 $x701))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x704))))
(assert
 (let (($x543 (not (net.put home @V0))))
 (or $x543 dir.head)))
(assert
 (let (($x545 (not (net.put dir.hptr @X))))
 (or $x545 dir.head)))
(assert
 (let (($x547 (not (net.put dir.hptr @V0))))
 (or $x547 dir.head)))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (or $x591 dir.head)))
(assert
 (let (($x726 (not (net.put home __src))))
 (or $x726 dir.head)))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (or $x731 dir.head)))
(assert
 (let (($x735 (not (net.put home @V1))))
 (or $x735 dir.head)))
(assert
 (let (($x738 (not (net.put home home))))
 (or $x738 dir.head)))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (or $x535 dir.head)))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (or $x537 dir.head)))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (or $x586 dir.head)))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (or $x698 dir.head)))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (or $x701 dir.head)))
(assert
 (let (($x704 (not (net.putX home home))))
 (or $x704 dir.head)))
(assert
 (let (($x535 (not (net.putX real_owner @X))))
 (or $x535 dir.dirty)))
(assert
 (let (($x537 (not (net.putX real_owner @V0))))
 (or $x537 dir.dirty)))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (or $x586 dir.dirty)))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (or $x698 dir.dirty)))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (or $x701 dir.dirty)))
(assert
 (let (($x704 (not (net.putX home home))))
 (or $x704 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x586 (not (net.putX home dir.hptr))))
 (or $x586 dir.head)))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (or $x698 dir.head)))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (or $x701 dir.head)))
(assert
 (let (($x704 (not (net.putX home home))))
 (or $x704 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x509 (not (__rp_net @V0))))
 (let (($x543 (not (net.put home @V0))))
 (or $x543 $x509))))
(assert
 (let (($x402 (__rp_net @X)))
 (let (($x506 (not $x402)))
 (let (($x545 (not (net.put dir.hptr @X))))
 (or $x545 $x506)))))
(assert
 (let (($x509 (not (__rp_net @V0))))
 (let (($x547 (not (net.put dir.hptr @V0))))
 (or $x547 $x509))))
(assert
 (let (($x913 (not (__rp_net dir.hptr))))
 (let (($x591 (not (net.put home dir.hptr))))
 (or $x591 $x913))))
(assert
 (let (($x271 (__rp_net __src)))
 (let (($x727 (not $x271)))
 (let (($x726 (not (net.put home __src))))
 (or $x726 $x727)))))
(assert
 (let (($x916 (not (__rp_net real_owner))))
 (let (($x731 (not (net.put home real_owner))))
 (or $x731 $x916))))
(assert
 (let (($x919 (not (__rp_net @V1))))
 (let (($x735 (not (net.put home @V1))))
 (or $x735 $x919))))
(assert
 (let (($x922 (not (__rp_net home))))
 (let (($x738 (not (net.put home home))))
 (or $x738 $x922))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x557 (not (invack @X))))
 (or $x557 (not (invnet @X)))))
(assert
 (let (($x560 (not (invack @V0))))
 (or $x560 (not (invnet @V0)))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x591 dir.pending))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x726 dir.pending))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x731 dir.pending))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let (($x945 (__dir.shlist @V1)))
 (or $x945 $x735 dir.pending))))
(assert
 (let (($x738 (not (net.put home home))))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x738 dir.pending))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x925 dir.pending))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x927 dir.pending))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x929 dir.pending))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x591 dir.dirty))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x726 dir.dirty))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x731 dir.dirty))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let (($x945 (__dir.shlist @V1)))
 (or $x945 $x735 dir.dirty))))
(assert
 (let (($x738 (not (net.put home home))))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x738 dir.dirty))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x925 dir.dirty))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x927 dir.dirty))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x929 dir.dirty))))
(assert
 (let (($x591 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x591))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x726))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x731))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let (($x945 (__dir.shlist @V1)))
 (or $x945 $x735))))
(assert
 (let (($x738 (not (net.put home home))))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x738))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x925))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x927))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x929))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x968))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x945 (__dir.shlist @V1)))
 (or $x945 $x701))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x704))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x726))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x731))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let (($x945 (__dir.shlist @V1)))
 (or $x945 $x735))))
(assert
 (let (($x738 (not (net.put home home))))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x738))))
(assert
 (let (($x975 (not (net.get __src home))))
 (let (($x941 (__dir.shlist __src)))
 (let (($x973 (not $x941)))
 (or $x973 $x975)))))
(assert
 (let (($x741 (not (net.get real_owner home))))
 (let (($x943 (__dir.shlist real_owner)))
 (let (($x977 (not $x943)))
 (or $x977 $x741)))))
(assert
 (let (($x744 (not (net.get @V1 home))))
 (let (($x945 (__dir.shlist @V1)))
 (let (($x979 (not $x945)))
 (or $x979 $x744)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let (($x947 (__dir.shlist home)))
 (let (($x981 (not $x947)))
 (or $x981 $x553)))))
(assert
 (let (($x941 (__dir.shlist __src)))
 (let (($x973 (not $x941)))
 (or $x973 dir.head))))
(assert
 (let (($x943 (__dir.shlist real_owner)))
 (let (($x977 (not $x943)))
 (or $x977 dir.head))))
(assert
 (let (($x945 (__dir.shlist @V1)))
 (let (($x979 (not $x945)))
 (or $x979 dir.head))))
(assert
 (let (($x947 (__dir.shlist home)))
 (let (($x981 (not $x947)))
 (or $x981 dir.head))))
(assert
 (let (($x718 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x718))))
(assert
 (let (($x722 (not (= (cache.state_ home) exclusive))))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x722))))
(assert
 (let (($x990 (not (= (cache.state_ __src) exclusive))))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x990))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let (($x992 (= __src home)))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x992 $x726)))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let (($x763 (= real_owner home)))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x763 $x731)))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x945 (__dir.shlist @V1)))
 (or $x945 $x289 $x735)))))
(assert
 (let (($x738 (not (net.put home home))))
 (let (($x410 (= home home)))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x410 $x738)))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let (($x616 (= dir.hptr home)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x616 $x925)))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let (($x992 (= __src home)))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x992 $x927)))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let (($x763 (= real_owner home)))
 (let (($x943 (__dir.shlist real_owner)))
 (or $x943 $x763 $x929)))))
(assert
 (let (($x931 (not (net.put dir.hptr @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x945 (__dir.shlist @V1)))
 (or $x945 $x289 $x931)))))
(assert
 (let (($x718 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x1001 (= dir.hptr requester)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x1001 $x718)))))
(assert
 (let (($x722 (not (= (cache.state_ home) exclusive))))
 (let (($x476 (= home requester)))
 (let (($x947 (__dir.shlist home)))
 (or $x947 $x476 $x722)))))
(assert
 (let (($x990 (not (= (cache.state_ __src) exclusive))))
 (let (($x1004 (= __src requester)))
 (let (($x941 (__dir.shlist __src)))
 (or $x941 $x1004 $x990)))))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x701))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x704))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x968))))
(assert
 (let (($x866 (not (= (cache.state_ dir.hptr) shared))))
 (or $x866 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x869 (not (= (cache.state_ home) shared))))
 (or $x869 (not (= (cache.wait home) get)))))
(assert
 (let (($x873 (not (= (cache.state_ __src) shared))))
 (or $x873 (not (= (cache.wait __src) get)))))
(assert
 (let (($x718 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x718 dir.head)))
(assert
 (let (($x722 (not (= (cache.state_ home) exclusive))))
 (or $x722 dir.head)))
(assert
 (let (($x990 (not (= (cache.state_ __src) exclusive))))
 (or $x990 dir.head)))
(assert
 (let (($x698 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x696 (= ?x140 getX)))
 (or $x696 $x698)))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x650 (= ?x321 getX)))
 (or $x650 $x701)))))
(assert
 (let (($x704 (not (net.putX home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x704)))))
(assert
 (let (($x903 (not (net.putX real_owner dir.hptr))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x643 (= ?x642 getX)))
 (or $x643 $x903)))))
(assert
 (let (($x905 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x696 (= ?x140 getX)))
 (or $x696 $x905)))))
(assert
 (let (($x907 (not (net.putX real_owner @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x650 (= ?x321 getX)))
 (or $x650 $x907)))))
(assert
 (let (($x909 (not (net.putX real_owner home))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x909)))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1025 (= ?x1014 getX)))
 (or $x1025 $x968)))))
(assert
 (let (($x707 (not (net.getX home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x707)))))
(assert
 (let (($x710 (not (net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x650 (= ?x321 getX)))
 (or $x650 $x710)))))
(assert
 (let (($x713 (not (net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x713)))))
(assert
 (let (($x749 (not (net.getX home @Z))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x749)))))
(assert
 (let (($x751 (not (net.getX home @V0))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x751)))))
(assert
 (let (($x753 (not (net.getX home @V1))))
 (let ((?x647 (cache.wait home)))
 (let (($x648 (= ?x647 getX)))
 (or $x648 $x753)))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1015 (= ?x1014 get)))
 (or $x1015 $x726)))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x731)))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x733 (= ?x321 get)))
 (or $x733 $x735)))))
(assert
 (let (($x738 (not (net.put home home))))
 (let ((?x647 (cache.wait home)))
 (let (($x661 (= ?x647 get)))
 (or $x661 $x738)))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x657 (= ?x642 get)))
 (or $x657 $x925)))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1015 (= ?x1014 get)))
 (or $x1015 $x927)))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x929)))))
(assert
 (let (($x931 (not (net.put dir.hptr @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x733 (= ?x321 get)))
 (or $x733 $x931)))))
(assert
 (let (($x595 (not (net.get dir.hptr home))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x657 (= ?x642 get)))
 (or $x657 $x595)))))
(assert
 (let (($x601 (not (net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x601)))))
(assert
 (let (($x741 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x741)))))
(assert
 (let (($x744 (not (net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x733 (= ?x321 get)))
 (or $x733 $x744)))))
(assert
 (let (($x975 (not (net.get __src home))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1015 (= ?x1014 get)))
 (or $x1015 $x975)))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let ((?x871 (cache.state_ __src)))
 (let (($x1036 (= ?x871 invalid)))
 (or $x1036 $x726)))))
(assert
 (let (($x731 (not (net.put home real_owner))))
 (let ((?x1038 (cache.state_ real_owner)))
 (let (($x1039 (= ?x1038 invalid)))
 (or $x1039 $x731)))))
(assert
 (let (($x735 (not (net.put home @V1))))
 (let ((?x1041 (cache.state_ @V1)))
 (let (($x1042 (= ?x1041 invalid)))
 (or $x1042 $x735)))))
(assert
 (let (($x738 (not (net.put home home))))
 (let ((?x678 (cache.state_ home)))
 (let (($x679 (= ?x678 invalid)))
 (or $x679 $x738)))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let ((?x672 (cache.state_ dir.hptr)))
 (let (($x673 (= ?x672 invalid)))
 (or $x673 $x925)))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let ((?x871 (cache.state_ __src)))
 (let (($x1036 (= ?x871 invalid)))
 (or $x1036 $x927)))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let ((?x1038 (cache.state_ real_owner)))
 (let (($x1039 (= ?x1038 invalid)))
 (or $x1039 $x929)))))
(assert
 (let (($x931 (not (net.put dir.hptr @V1))))
 (let ((?x1041 (cache.state_ @V1)))
 (let (($x1042 (= ?x1041 invalid)))
 (or $x1042 $x931)))))
(assert
 (let (($x595 (not (net.get dir.hptr home))))
 (let ((?x672 (cache.state_ dir.hptr)))
 (let (($x673 (= ?x672 invalid)))
 (or $x673 $x595)))))
(assert
 (let (($x601 (not (net.get @V0 home))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x601)))))
(assert
 (let (($x741 (not (net.get real_owner home))))
 (let ((?x1038 (cache.state_ real_owner)))
 (let (($x1039 (= ?x1038 invalid)))
 (or $x1039 $x741)))))
(assert
 (let (($x744 (not (net.get @V1 home))))
 (let ((?x1041 (cache.state_ @V1)))
 (let (($x1042 (= ?x1041 invalid)))
 (or $x1042 $x744)))))
(assert
 (let (($x975 (not (net.get __src home))))
 (let ((?x871 (cache.state_ __src)))
 (let (($x1036 (= ?x871 invalid)))
 (or $x1036 $x975)))))
(assert
 (let (($x690 (not (= (cache.wait home) none))))
 (let (($x707 (not (net.getX home home))))
 (or $x707 $x690))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x710 (not (net.getX @V1 home))))
 (or $x710 $x323))))
(assert
 (let (($x694 (not (= (cache.wait @V0) none))))
 (let (($x713 (not (net.getX @V0 home))))
 (or $x713 $x694))))
(assert
 (let (($x690 (not (= (cache.wait home) none))))
 (let (($x749 (not (net.getX home @Z))))
 (or $x749 $x690))))
(assert
 (let (($x690 (not (= (cache.wait home) none))))
 (let (($x751 (not (net.getX home @V0))))
 (or $x751 $x690))))
(assert
 (let (($x690 (not (= (cache.wait home) none))))
 (let (($x753 (not (net.getX home @V1))))
 (or $x753 $x690))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1025 (= ?x1014 getX)))
 (or $x1025 $x968)))))
(assert
 (let (($x1061 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x696 (= ?x140 getX)))
 (or $x696 $x1061)))))
(assert
 (let (($x1064 (not (net.getX dir.hptr home))))
 (let ((?x642 (cache.wait dir.hptr)))
 (let (($x643 (= ?x642 getX)))
 (or $x643 $x1064)))))
(assert
 (let (($x1067 (not (net.getX __src home))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1025 (= ?x1014 getX)))
 (or $x1025 $x1067)))))
(assert
 (let (($x1070 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1070 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1074 (not (= (cache.state_ @V1) exclusive))))
 (or $x1074 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x990 (not (= (cache.state_ __src) exclusive))))
 (or $x990 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x913 (not (__rp_net dir.hptr))))
 (let (($x591 (not (net.put home dir.hptr))))
 (or $x591 $x913))))
(assert
 (let (($x916 (not (__rp_net real_owner))))
 (let (($x731 (not (net.put home real_owner))))
 (or $x731 $x916))))
(assert
 (let (($x919 (not (__rp_net @V1))))
 (let (($x735 (not (net.put home @V1))))
 (or $x735 $x919))))
(assert
 (let (($x922 (not (__rp_net home))))
 (let (($x738 (not (net.put home home))))
 (or $x738 $x922))))
(assert
 (let (($x726 (not (net.put home __src))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1015 (= ?x1014 get)))
 (or $x1015 $x726)))))
(assert
 (let (($x975 (not (net.get __src home))))
 (let ((?x1014 (cache.wait __src)))
 (let (($x1015 (= ?x1014 get)))
 (or $x1015 $x975)))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x145 $x925)))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x145 $x927)))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x145 $x929)))))
(assert
 (let (($x931 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x145 $x931)))))
(assert
 (let (($x933 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x145 $x933)))))
(assert
 (let (($x903 (not (net.putX real_owner dir.hptr))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x903)))))
(assert
 (let (($x905 (not (net.putX real_owner real_owner))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x905)))))
(assert
 (let (($x907 (not (net.putX real_owner @V1))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x907)))))
(assert
 (let (($x909 (not (net.putX real_owner home))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x909)))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x968)))))
(assert
 (let (($x975 (not (net.get __src home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x975)))))
(assert
 (let (($x1061 (not (net.getX real_owner home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x1061)))))
(assert
 (let (($x1064 (not (net.getX dir.hptr home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x1064)))))
(assert
 (let (($x1067 (not (net.getX __src home))))
 (let (($x411 (= home real_owner)))
 (let (($x410 (= home home)))
 (or $x410 $x411 $x1067)))))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x925 dir.dirty))))
(assert
 (let (($x927 (not (net.put dir.hptr __src))))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x927 dir.dirty))))
(assert
 (let (($x929 (not (net.put dir.hptr real_owner))))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x929 dir.dirty))))
(assert
 (let (($x931 (not (net.put dir.hptr @V1))))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x931 dir.dirty))))
(assert
 (let (($x933 (not (net.put dir.hptr home))))
 (let (($x616 (= dir.hptr home)))
 (or $x616 $x933 dir.dirty))))
(assert
 (let (($x903 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x903 dir.head))))
(assert
 (let (($x905 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x905 dir.head))))
(assert
 (let (($x907 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x907 dir.head))))
(assert
 (let (($x909 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x909 dir.head))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x410 (= home home)))
 (or $x410 $x968 dir.head))))
(assert
 (let (($x903 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x903 dir.dirty))))
(assert
 (let (($x905 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x905 dir.dirty))))
(assert
 (let (($x907 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x907 dir.dirty))))
(assert
 (let (($x909 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x909 dir.dirty))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x410 (= home home)))
 (or $x410 $x968 dir.dirty))))
(assert
 (let (($x903 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x903))))
(assert
 (let (($x905 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x905))))
(assert
 (let (($x907 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x907))))
(assert
 (let (($x909 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x909))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x410 (= home home)))
 (or $x410 $x968))))
(assert
 (let (($x975 (not (net.get __src home))))
 (let (($x410 (= home home)))
 (or $x410 $x975 dir.head))))
(assert
 (let (($x975 (not (net.get __src home))))
 (let (($x410 (= home home)))
 (or $x410 $x975 dir.dirty))))
(assert
 (let (($x1061 (not (net.getX real_owner home))))
 (let (($x410 (= home home)))
 (or $x410 $x1061 dir.head))))
(assert
 (let (($x1064 (not (net.getX dir.hptr home))))
 (let (($x410 (= home home)))
 (or $x410 $x1064 dir.head))))
(assert
 (let (($x1067 (not (net.getX __src home))))
 (let (($x410 (= home home)))
 (or $x410 $x1067 dir.head))))
(assert
 (let (($x1061 (not (net.getX real_owner home))))
 (let (($x410 (= home home)))
 (or $x410 $x1061 dir.dirty))))
(assert
 (let (($x1064 (not (net.getX dir.hptr home))))
 (let (($x410 (= home home)))
 (or $x410 $x1064 dir.dirty))))
(assert
 (let (($x1067 (not (net.getX __src home))))
 (let (($x410 (= home home)))
 (or $x410 $x1067 dir.dirty))))
(assert
 (let (($x1061 (not (net.getX real_owner home))))
 (let (($x410 (= home home)))
 (or $x410 $x1061))))
(assert
 (let (($x1064 (not (net.getX dir.hptr home))))
 (let (($x410 (= home home)))
 (or $x410 $x1064))))
(assert
 (let (($x1067 (not (net.getX __src home))))
 (let (($x410 (= home home)))
 (or $x410 $x1067))))
(assert
 (let (($x1061 (not (net.getX real_owner home))))
 (let (($x410 (= home home)))
 (or (= real_owner requester) $x410 $x1061))))
(assert
 (let (($x1064 (not (net.getX dir.hptr home))))
 (let (($x410 (= home home)))
 (let (($x1001 (= dir.hptr requester)))
 (or $x1001 $x410 $x1064)))))
(assert
 (let (($x1067 (not (net.getX __src home))))
 (let (($x410 (= home home)))
 (let (($x1004 (= __src requester)))
 (or $x1004 $x410 $x1067)))))
(assert
 (let (($x990 (not (= (cache.state_ __src) exclusive))))
 (let (($x1128 (= __src real_owner)))
 (or $x1128 $x990))))
(assert
 (let (($x1070 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x1070))))
(assert
 (let (($x1074 (not (= (cache.state_ @V1) exclusive))))
 (let (($x413 (= @V1 real_owner)))
 (or $x413 $x1074))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x1132 (= __src dir.hptr)))
 (or $x1132 $x968))))
(assert
 (let (($x990 (not (= (cache.state_ __src) exclusive))))
 (let (($x1132 (= __src dir.hptr)))
 (or $x1132 $x990))))
(assert
 (let (($x1070 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x857 (= real_owner dir.hptr)))
 (or $x857 $x1070))))
(assert
 (let (($x1074 (not (= (cache.state_ @V1) exclusive))))
 (let (($x859 (= @V1 dir.hptr)))
 (or $x859 $x1074))))
(assert
 (let (($x873 (not (= (cache.state_ __src) shared))))
 (let (($x1128 (= __src real_owner)))
 (or $x1128 $x873))))
(assert
 (let (($x1139 (not (= (cache.state_ real_owner) shared))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x1139))))
(assert
 (let (($x1142 (not (= (cache.state_ @V1) shared))))
 (let (($x413 (= @V1 real_owner)))
 (or $x413 $x1142))))
(assert
 (let (($x903 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x903))))
(assert
 (let (($x905 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x905))))
(assert
 (let (($x907 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x907))))
(assert
 (let (($x909 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x909))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (let (($x410 (= home home)))
 (or $x410 $x968))))
(assert
 (let (($x866 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x913 (not (__rp_net dir.hptr))))
 (or $x913 $x866))))
(assert
 (let (($x869 (not (= (cache.state_ home) shared))))
 (let (($x922 (not (__rp_net home))))
 (or $x922 $x869))))
(assert
 (let (($x1139 (not (= (cache.state_ real_owner) shared))))
 (let (($x916 (not (__rp_net real_owner))))
 (or $x916 $x1139))))
(assert
 (let (($x1142 (not (= (cache.state_ @V1) shared))))
 (let (($x919 (not (__rp_net @V1))))
 (or $x919 $x1142))))
(assert
 (let (($x903 (not (net.putX real_owner dir.hptr))))
 (let (($x857 (= real_owner dir.hptr)))
 (or $x857 $x903))))
(assert
 (let (($x905 (not (net.putX real_owner real_owner))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x905))))
(assert
 (let (($x907 (not (net.putX real_owner @V1))))
 (let (($x879 (= real_owner @V1)))
 (or $x879 $x907))))
(assert
 (let (($x909 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x909))))
(assert
 (let (($x968 (not (net.putX home __src))))
 (or (= real_owner __src) $x968)))
(assert
 (let (($x925 (not (net.put dir.hptr dir.hptr))))
 (or $x925 dir.head)))
(check-sat)
