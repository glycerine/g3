(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun __cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (__cache.wait real_owner) get)))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (not (= __src home)))
(assert
 (let ((?x273 (cache.state_ __src)))
 (= ?x273 invalid)))
(assert
 (let ((?x275 (__cache.wait __src)))
 (= ?x275 none)))
(assert
 (let ((?x295 (cache.state_ @Y)))
 (let (($x296 (= ?x295 exclusive)))
 (let ((?x290 (cache.state_ @X)))
 (let (($x291 (= ?x290 exclusive)))
 (and $x291 (= (cache.wait @X) none) $x296 (= (cache.wait @Y) none) (not (= @X @Y))))))))
(assert
 (let ((?x292 (cache.wait @X)))
 (= ?x292 (ite (and (= @X __src)) get (__cache.wait @X)))))
(assert
 (let ((?x297 (cache.wait @Y)))
 (= ?x297 (ite (and (= @Y __src)) get (__cache.wait @Y)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x334 (not (= (cache.state_ __src) exclusive))))
 (let (($x332 (= __src real_owner)))
 (or $x332 $x334))))
(assert
 (let ((?x290 (cache.state_ @X)))
 (let (($x291 (= ?x290 exclusive)))
 (let (($x337 (not $x291)))
 (let (($x336 (= @X real_owner)))
 (or $x336 $x337))))))
(assert
 (let ((?x295 (cache.state_ @Y)))
 (let (($x296 (= ?x295 exclusive)))
 (let (($x340 (not $x296)))
 (let (($x339 (= @Y real_owner)))
 (or $x339 $x340))))))
(assert
 (let (($x334 (not (= (cache.state_ __src) exclusive))))
 (or (= __src dir.hptr) $x334)))
(assert
 (let ((?x290 (cache.state_ @X)))
 (let (($x291 (= ?x290 exclusive)))
 (let (($x337 (not $x291)))
 (or (= @X dir.hptr) $x337)))))
(assert
 (let ((?x295 (cache.state_ @Y)))
 (let (($x296 (= ?x295 exclusive)))
 (let (($x340 (not $x296)))
 (or (= @Y dir.hptr) $x340)))))
(assert
 (let (($x349 (not (= (cache.state_ __src) shared))))
 (let (($x332 (= __src real_owner)))
 (or $x332 $x349))))
(assert
 (let (($x352 (not (= (cache.state_ @X) shared))))
 (let (($x336 (= @X real_owner)))
 (or $x336 $x352))))
(assert
 (let (($x355 (not (= (cache.state_ @Y) shared))))
 (let (($x339 (= @Y real_owner)))
 (or $x339 $x355))))
(assert
 (let (($x349 (not (= (cache.state_ __src) shared))))
 (or (not (rp_net __src)) $x349)))
(assert
 (let (($x352 (not (= (cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x352)))
(assert
 (let (($x355 (not (= (cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x355)))
(assert
 (let (($x349 (not (= (cache.state_ __src) shared))))
 (let (($x367 (not (invack __src))))
 (or $x367 $x349))))
(assert
 (let (($x352 (not (= (cache.state_ @X) shared))))
 (let (($x370 (not (invack @X))))
 (or $x370 $x352))))
(assert
 (let (($x355 (not (= (cache.state_ @Y) shared))))
 (let (($x373 (not (invack @Y))))
 (or $x373 $x355))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x376))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x379))))
(assert
 (let (($x383 (not (__net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x381 (not $x58)))
 (or $x381 $x383)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x381 (not $x58)))
 (or $x381 dir.head))))
(assert
 (let (($x388 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x388))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let (($x390 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x390 $x379)))))
(assert
 (let (($x388 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x392 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x392 $x388)))))
(assert
 (let ((?x273 (cache.state_ __src)))
 (let (($x274 (= ?x273 invalid)))
 (let (($x332 (= __src real_owner)))
 (or (dir.real __src) $x332 $x274)))))
(assert
 (let ((?x290 (cache.state_ @X)))
 (let (($x397 (= ?x290 invalid)))
 (let (($x336 (= @X real_owner)))
 (or (dir.real @X) $x336 $x397)))))
(assert
 (let ((?x295 (cache.state_ @Y)))
 (let (($x400 (= ?x295 invalid)))
 (let (($x339 (= @Y real_owner)))
 (or (dir.real @Y) $x339 $x400)))))
(assert
 (let ((?x386 (cache.state_ dir.hptr)))
 (let (($x403 (= ?x386 invalid)))
 (let (($x145 (= dir.hptr real_owner)))
 (or (dir.real dir.hptr) $x145 $x403)))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x376))))
(assert
 (let (($x142 (not (= (__cache.wait real_owner) get))))
 (let (($x408 (not (= (cache.state_ real_owner) shared))))
 (or $x408 $x142))))
(assert
 (let (($x349 (not (= (cache.state_ __src) shared))))
 (or $x349 (not (= (__cache.wait __src) get)))))
(assert
 (let (($x352 (not (= (cache.state_ @X) shared))))
 (or $x352 (not (= (__cache.wait @X) get)))))
(assert
 (let (($x355 (not (= (cache.state_ @Y) shared))))
 (or $x355 (not (= (__cache.wait @Y) get)))))
(assert
 (let (($x367 (not (invack __src))))
 (let ((?x273 (cache.state_ __src)))
 (let (($x274 (= ?x273 invalid)))
 (or $x274 $x367)))))
(assert
 (let (($x370 (not (invack @X))))
 (let ((?x290 (cache.state_ @X)))
 (let (($x397 (= ?x290 invalid)))
 (or $x397 $x370)))))
(assert
 (let (($x373 (not (invack @Y))))
 (let ((?x295 (cache.state_ @Y)))
 (let (($x400 (= ?x295 invalid)))
 (or $x400 $x373)))))
(assert
 (let (($x334 (not (= (cache.state_ __src) exclusive))))
 (or $x334 dir.head)))
(assert
 (let ((?x290 (cache.state_ @X)))
 (let (($x291 (= ?x290 exclusive)))
 (let (($x337 (not $x291)))
 (or $x337 dir.head)))))
(assert
 (let ((?x295 (cache.state_ @Y)))
 (let (($x296 (= ?x295 exclusive)))
 (let (($x340 (not $x296)))
 (or $x340 dir.head)))))
(assert
 (let (($x388 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x388 dir.head)))
(assert
 (let (($x427 (not (= (cache.state_ real_owner) exclusive))))
 (or $x427 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x429 (= home home)))
 (or $x429 $x187))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x376)))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x379)))))
(assert
 (let (($x383 (not (__net.get dir.hptr home))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x383)))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let ((?x386 (cache.state_ dir.hptr)))
 (let (($x403 (= ?x386 invalid)))
 (or $x403 $x379)))))
(assert
 (let (($x383 (not (__net.get dir.hptr home))))
 (let ((?x386 (cache.state_ dir.hptr)))
 (let (($x403 (= ?x386 invalid)))
 (or $x403 $x383)))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x376)))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x439 (= ?x140 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let ((?x275 (__cache.wait __src)))
 (let (($x443 (= ?x275 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let ((?x322 (__cache.wait @X)))
 (let (($x447 (= ?x322 getX)))
 (or $x447 $x449)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let ((?x327 (__cache.wait @Y)))
 (let (($x451 (= ?x327 getX)))
 (or $x451 $x453)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x456)))))
(assert
 (let (($x427 (not (= (cache.state_ real_owner) exclusive))))
 (or $x427 (not (= (__cache.wait real_owner) getX)))))
(assert
 (let (($x334 (not (= (cache.state_ __src) exclusive))))
 (or $x334 (not (= (__cache.wait __src) getX)))))
(assert
 (let ((?x290 (cache.state_ @X)))
 (let (($x291 (= ?x290 exclusive)))
 (let (($x337 (not $x291)))
 (or $x337 (not (= (__cache.wait @X) getX)))))))
(assert
 (let ((?x295 (cache.state_ @Y)))
 (let (($x296 (= ?x295 exclusive)))
 (let (($x340 (not $x296)))
 (or $x340 (not (= (__cache.wait @Y) getX)))))))
(assert
 (let (($x388 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x388 (not (= (__cache.wait dir.hptr) getX)))))
(assert
 (let (($x469 (not (rp_net dir.hptr))))
 (let (($x379 (not (net.put home dir.hptr))))
 (or $x379 $x469))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x379)))))
(assert
 (let (($x383 (not (__net.get dir.hptr home))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x383)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x379)))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x376)))))
(assert
 (let (($x383 (not (__net.get dir.hptr home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x383)))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x441)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x445)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x449)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x453)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x456)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x472)))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x379 dir.dirty))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x376 dir.head))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x376 dir.dirty))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x376))))
(assert
 (let (($x383 (not (__net.get dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x383 dir.head))))
(assert
 (let (($x383 (not (__net.get dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x383 dir.dirty))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x441 dir.head))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x445 dir.head))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x449 dir.head))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or $x429 $x453 dir.head))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x456 dir.head))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x472 dir.head))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x441 dir.dirty))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x445 dir.dirty))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x449 dir.dirty))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or $x429 $x453 dir.dirty))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x456 dir.dirty))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x472 dir.dirty))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x441))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x445))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x449))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or $x429 $x453))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x456))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x472))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or (= real_owner requester) $x429 $x441))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or (= __src requester) $x429 $x445))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or (= @X requester) $x429 $x449))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or (= @Y requester) $x429 $x453))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (let (($x392 (= dir.hptr requester)))
 (or $x392 $x429 $x456)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or (= home requester) $x429 $x472))))
(assert
 (let (($x388 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x388))))
(assert
 (let (($x427 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x519 (= real_owner real_owner)))
 (or $x519 $x427))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x521 (= dir.hptr dir.hptr)))
 (or $x521 $x376))))
(assert
 (let (($x388 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x521 (= dir.hptr dir.hptr)))
 (or $x521 $x388))))
(assert
 (let (($x427 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x524 (= real_owner dir.hptr)))
 (or $x524 $x427))))
(assert
 (let (($x527 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x527))))
(assert
 (let (($x408 (not (= (cache.state_ real_owner) shared))))
 (let (($x519 (= real_owner real_owner)))
 (or $x519 $x408))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x376))))
(assert
 (let (($x527 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x469 (not (rp_net dir.hptr))))
 (or $x469 $x527))))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (let (($x524 (= real_owner dir.hptr)))
 (or $x524 $x376))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (or $x379 dir.head)))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (or $x376 dir.head)))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (or $x376 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x376 (not (net.putX home dir.hptr))))
 (or $x376 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x469 (not (rp_net dir.hptr))))
 (let (($x379 (not (net.put home dir.hptr))))
 (or $x379 $x469))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (__net.get home home)))
(assert
 (let (($x367 (not (invack __src))))
 (or $x367 (not (invnet __src)))))
(assert
 (let (($x370 (not (invack @X))))
 (or $x370 (not (invnet @X)))))
(assert
 (let (($x373 (not (invack @Y))))
 (or $x373 (not (invnet @Y)))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x379 dir.pending))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x538 dir.pending))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x379 dir.dirty))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x538 dir.dirty))))
(assert
 (let (($x379 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x379))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x538))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x390 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x390 $x538)))))
(assert
 (let (($x527 (not (= (cache.state_ dir.hptr) shared))))
 (or $x527 (not (= (__cache.wait dir.hptr) get)))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x536)))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x439 (= ?x140 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let ((?x275 (__cache.wait __src)))
 (let (($x443 (= ?x275 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let ((?x322 (__cache.wait @X)))
 (let (($x447 (= ?x322 getX)))
 (or $x447 $x449)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let ((?x327 (__cache.wait @Y)))
 (let (($x451 (= ?x327 getX)))
 (or $x451 $x453)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x456)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let ((?x559 (__cache.wait home)))
 (let (($x560 (= ?x559 getX)))
 (or $x560 $x472)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let ((?x431 (__cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x538)))))
(assert
 (let (($x540 (not (__net.get home home))))
 (let ((?x559 (__cache.wait home)))
 (let (($x563 (= ?x559 get)))
 (or $x563 $x540)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let ((?x386 (cache.state_ dir.hptr)))
 (let (($x403 (= ?x386 invalid)))
 (or $x403 $x538)))))
(assert
 (let (($x540 (not (__net.get home home))))
 (or (= (cache.state_ home) invalid) $x540)))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (or $x441 (not (= (__cache.wait real_owner) none)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (or $x445 (not (= (__cache.wait __src) none)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (or $x449 (not (= (__cache.wait @X) none)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (or $x453 (not (= (__cache.wait @Y) none)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (or $x456 (not (= (__cache.wait dir.hptr) none)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (or $x472 (not (= (__cache.wait home) none)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let ((?x559 (__cache.wait home)))
 (let (($x560 (= ?x559 getX)))
 (or $x560 $x472)))))
(assert
 (let (($x587 (not (= (cache.state_ home) exclusive))))
 (or $x587 (not (= (__cache.wait home) getX)))))
(assert
 (let (($x540 (not (__net.get home home))))
 (let ((?x559 (__cache.wait home)))
 (let (($x563 (= ?x559 get)))
 (or $x563 $x540)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x390 (= dir.hptr home)))
 (or $x390 $x145 $x538)))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x519 (= real_owner real_owner)))
 (let (($x591 (= real_owner home)))
 (or $x591 $x519 $x536)))))
(assert
 (let (($x540 (not (__net.get home home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x540)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x390 (= dir.hptr home)))
 (or $x390 $x538 dir.dirty))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x591 (= real_owner home)))
 (or $x591 $x536 dir.head))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x591 (= real_owner home)))
 (or $x591 $x536 dir.dirty))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x591 (= real_owner home)))
 (or $x591 $x536))))
(assert
 (let (($x540 (not (__net.get home home))))
 (let (($x429 (= home home)))
 (or $x429 $x540 dir.head))))
(assert
 (let (($x540 (not (__net.get home home))))
 (let (($x429 (= home home)))
 (or $x429 $x540 dir.dirty))))
(assert
 (let (($x587 (not (= (cache.state_ home) exclusive))))
 (let (($x473 (= home real_owner)))
 (or $x473 $x587))))
(assert
 (let (($x587 (not (= (cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x587)))
(assert
 (let (($x604 (not (= (cache.state_ home) shared))))
 (let (($x473 (= home real_owner)))
 (or $x473 $x604))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x591 (= real_owner home)))
 (or $x591 $x536))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x524 (= real_owner dir.hptr)))
 (or $x524 $x536))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (or $x538 dir.head)))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (or $x536 dir.head)))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (or $x536 dir.dirty)))
(assert
 (let (($x469 (not (rp_net dir.hptr))))
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (or $x538 $x469))))
(assert
 (let (($x604 (not (= (cache.state_ home) shared))))
 (or $x604 (not (= (__cache.wait home) get)))))
(assert
 (let (($x587 (not (= (cache.state_ home) exclusive))))
 (or $x587 dir.head)))
(check-sat)
