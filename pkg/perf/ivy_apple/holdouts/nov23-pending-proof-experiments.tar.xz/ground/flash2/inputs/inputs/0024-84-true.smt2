(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __cache.invmarked (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x144 (not dir.dirty)))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x144 dir.pending))))
(assert
 (not (net.fack requester home)))
(assert
 (let ((?x270 (cache.state_ home)))
 (= ?x270 invalid)))
(assert
 (let ((?x272 (cache.wait home)))
 (= ?x272 none)))
(assert
 (not dir.pending))
(assert
 (not dir.dirty))
(assert
 (__cache.invmarked home))
(assert
 (let (($x329 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x367 (not (net.getX home @Y))))
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x355 (= @Y @Z)))
 (let (($x368 (and (or $x355 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x355 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x355 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x355 $x354 $x346) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x346 (not (net.putX @Y @X))) $x367 $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x329 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x368)))))))))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x389 (= @Y real_owner)))
 (let (($x308 (= @Y home)))
 (or $x308 $x389 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x392 (= @Z real_owner)))
 (let (($x391 (= @Z home)))
 (or $x391 $x392 $x364)))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x335)))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let (($x397 (= @V1 real_owner)))
 (let (($x283 (= @V1 home)))
 (or $x283 $x397 $x297)))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x389 (= @Y real_owner)))
 (let (($x308 (= @Y home)))
 (or $x308 $x389 $x343)))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x392 (= @Z real_owner)))
 (let (($x391 (= @Z home)))
 (or $x391 $x392 $x358)))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x320)))))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (let (($x397 (= @V1 real_owner)))
 (let (($x283 (= @V1 home)))
 (or $x283 $x397 $x291)))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let (($x389 (= @Y real_owner)))
 (let (($x308 (= @Y home)))
 (or $x308 $x389 $x361)))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let (($x392 (= @Z real_owner)))
 (let (($x391 (= @Z home)))
 (or $x391 $x392 $x351)))))
(assert
 (let (($x340 (not (net.get @X home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x340)))))
(assert
 (let (($x301 (not (net.get @V0 @V1))))
 (let (($x397 (= @V1 real_owner)))
 (let (($x283 (= @V1 home)))
 (or $x283 $x397 $x301)))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x389 (= @Y real_owner)))
 (let (($x308 (= @Y home)))
 (or $x308 $x389 $x354)))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x392 (= @Z real_owner)))
 (let (($x391 (= @Z home)))
 (or $x391 $x392 $x346)))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x389 (= @Y real_owner)))
 (let (($x308 (= @Y home)))
 (or $x308 $x389 $x367)))))
(assert
 (let (($x325 (not (net.getX @X home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x325)))))
(assert
 (let (($x314 (not (net.getX @V1 @V0))))
 (let (($x412 (= @V0 real_owner)))
 (let (($x411 (= @V0 home)))
 (or $x411 $x412 $x314)))))
(assert
 (let (($x294 (not (net.getX @V0 @V1))))
 (let (($x397 (= @V1 real_owner)))
 (let (($x283 (= @V1 home)))
 (or $x283 $x397 $x294)))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x308 (= @Y home)))
 (or $x308 $x349 dir.dirty))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x391 (= @Z home)))
 (or $x391 $x364 dir.dirty))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let (($x394 (= home home)))
 (or $x394 $x335 dir.dirty))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x297 dir.dirty))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x308 (= @Y home)))
 (or $x308 $x343 dir.head))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x391 (= @Z home)))
 (or $x391 $x358 dir.head))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x394 (= home home)))
 (or $x394 $x320 dir.head))))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x291 dir.head))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x308 (= @Y home)))
 (or $x308 $x343 dir.dirty))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x391 (= @Z home)))
 (or $x391 $x358 dir.dirty))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x394 (= home home)))
 (or $x394 $x320 dir.dirty))))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x291 dir.dirty))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x308 (= @Y home)))
 (or $x308 $x343))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x391 (= @Z home)))
 (or $x391 $x358))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x394 (= home home)))
 (or $x394 $x320))))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x291))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x361 dir.head))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x351 dir.head))))
(assert
 (let (($x340 (not (net.get @X home))))
 (let (($x394 (= home home)))
 (or $x394 $x340 dir.head))))
(assert
 (let (($x301 (not (net.get @V0 @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x301 dir.head))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x361 dir.dirty))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x351 dir.dirty))))
(assert
 (let (($x340 (not (net.get @X home))))
 (let (($x394 (= home home)))
 (or $x394 $x340 dir.dirty))))
(assert
 (let (($x301 (not (net.get @V0 @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x301 dir.dirty))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x354 dir.head))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x346 dir.head))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x367 dir.head))))
(assert
 (let (($x325 (not (net.getX @X home))))
 (let (($x394 (= home home)))
 (or $x394 $x325 dir.head))))
(assert
 (let (($x314 (not (net.getX @V1 @V0))))
 (let (($x411 (= @V0 home)))
 (or $x411 $x314 dir.head))))
(assert
 (let (($x294 (not (net.getX @V0 @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x294 dir.head))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x354 dir.dirty))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x346 dir.dirty))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x367 dir.dirty))))
(assert
 (let (($x325 (not (net.getX @X home))))
 (let (($x394 (= home home)))
 (or $x394 $x325 dir.dirty))))
(assert
 (let (($x314 (not (net.getX @V1 @V0))))
 (let (($x411 (= @V0 home)))
 (or $x411 $x314 dir.dirty))))
(assert
 (let (($x294 (not (net.getX @V0 @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x294 dir.dirty))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x354))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x346))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x367))))
(assert
 (let (($x325 (not (net.getX @X home))))
 (let (($x394 (= home home)))
 (or $x394 $x325))))
(assert
 (let (($x314 (not (net.getX @V1 @V0))))
 (let (($x411 (= @V0 home)))
 (or $x411 $x314))))
(assert
 (let (($x294 (not (net.getX @V0 @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x294))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let (($x308 (= @Y home)))
 (let (($x457 (= @X requester)))
 (or $x457 $x308 $x354)))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let (($x391 (= @Z home)))
 (let (($x457 (= @X requester)))
 (or $x457 $x391 $x346)))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let (($x308 (= @Y home)))
 (let (($x460 (= home requester)))
 (or $x460 $x308 $x367)))))
(assert
 (let (($x325 (not (net.getX @X home))))
 (let (($x394 (= home home)))
 (let (($x457 (= @X requester)))
 (or $x457 $x394 $x325)))))
(assert
 (let (($x314 (not (net.getX @V1 @V0))))
 (let (($x411 (= @V0 home)))
 (let (($x463 (= @V1 requester)))
 (or $x463 $x411 $x314)))))
(assert
 (let (($x294 (not (net.getX @V0 @V1))))
 (let (($x283 (= @V1 home)))
 (let (($x465 (= @V0 requester)))
 (or $x465 $x283 $x294)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x286 (not (net.fack @V0 @V1))))
 (let (($x412 (= @V0 real_owner)))
 (or $x412 $x286))))
(assert
 (let (($x471 (not (= (cache.state_ home) exclusive))))
 (let (($x395 (= home real_owner)))
 (or $x395 $x471))))
(assert
 (let (($x329 (not (= (cache.state_ @X) exclusive))))
 (let (($x473 (= @X real_owner)))
 (or $x473 $x329))))
(assert
 (let (($x476 (not (= (cache.state_ @V0) exclusive))))
 (let (($x412 (= @V0 real_owner)))
 (or $x412 $x476))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x478 (= @X dir.hptr)))
 (or $x478 $x320))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x480 (= @V0 dir.hptr)))
 (or $x480 $x482))))
(assert
 (let (($x471 (not (= (cache.state_ home) exclusive))))
 (let (($x484 (= home dir.hptr)))
 (or $x484 $x471))))
(assert
 (let (($x329 (not (= (cache.state_ @X) exclusive))))
 (let (($x478 (= @X dir.hptr)))
 (or $x478 $x329))))
(assert
 (let (($x476 (not (= (cache.state_ @V0) exclusive))))
 (let (($x480 (= @V0 dir.hptr)))
 (or $x480 $x476))))
(assert
 (let (($x489 (not (= (cache.state_ home) shared))))
 (let (($x395 (= home real_owner)))
 (or $x395 $x489))))
(assert
 (let (($x492 (not (= (cache.state_ @X) shared))))
 (let (($x473 (= @X real_owner)))
 (or $x473 $x492))))
(assert
 (let (($x495 (not (= (cache.state_ @V0) shared))))
 (let (($x412 (= @V0 real_owner)))
 (or $x412 $x495))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x308 (= @Y home)))
 (or $x308 $x343))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x391 (= @Z home)))
 (or $x391 $x358))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x394 (= home home)))
 (or $x394 $x320))))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x291))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x394 (= home home)))
 (or $x394 $x482))))
(assert
 (let (($x492 (not (= (cache.state_ @X) shared))))
 (let (($x333 (not (rp_net @X))))
 (or $x333 $x492))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let (($x499 (= real_owner @X)))
 (or $x499 $x343))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let (($x499 (= real_owner @X)))
 (or $x499 $x358))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x499 (= real_owner @X)))
 (or $x499 $x320))))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (let (($x503 (= real_owner @V0)))
 (or $x503 $x291))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x503 (= real_owner @V0)))
 (or $x503 $x482))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (or $x349 dir.head)))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (or $x364 dir.head)))
(assert
 (let (($x335 (not (net.put home @X))))
 (or $x335 dir.head)))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (or $x297 dir.head)))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (or $x343 dir.head)))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (or $x358 dir.head)))
(assert
 (let (($x320 (not (net.putX home @X))))
 (or $x320 dir.head)))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (or $x291 dir.head)))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (or $x482 dir.head)))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (or $x343 dir.dirty)))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (or $x358 dir.dirty)))
(assert
 (let (($x320 (not (net.putX home @X))))
 (or $x320 dir.dirty)))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (or $x291 dir.dirty)))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (or $x482 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x320 (not (net.putX home @X))))
 (or $x320 dir.head)))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (or $x482 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x333 (not (rp_net @X))))
 (let (($x349 (not (net.put @Y @X))))
 (or $x349 $x333))))
(assert
 (let (($x333 (not (rp_net @X))))
 (let (($x364 (not (net.put @Z @X))))
 (or $x364 $x333))))
(assert
 (let (($x333 (not (rp_net @X))))
 (let (($x335 (not (net.put home @X))))
 (or $x335 $x333))))
(assert
 (let (($x529 (not (rp_net @V0))))
 (let (($x297 (not (net.put @V1 @V0))))
 (or $x297 $x529))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x489 (not (= (cache.state_ home) shared))))
 (let (($x546 (not (invack home))))
 (or $x546 $x489))))
(assert
 (let (($x492 (not (= (cache.state_ @X) shared))))
 (let (($x549 (not (invack @X))))
 (or $x549 $x492))))
(assert
 (let (($x495 (not (= (cache.state_ @V0) shared))))
 (let (($x552 (not (invack @V0))))
 (or $x552 $x495))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x349 dir.pending))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x364 dir.pending))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x335 dir.pending))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x297 dir.pending))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x532 dir.pending))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x534 dir.pending))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x536 dir.pending))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x349 dir.dirty))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x364 dir.dirty))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x335 dir.dirty))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x297 dir.dirty))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x532 dir.dirty))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x534 dir.dirty))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x536 dir.dirty))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x349))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x364))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x335))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x297))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x532))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x534))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x536))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x578))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x320))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x482))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x583))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x335))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x532))))
(assert
 (let (($x587 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x585 (not $x58)))
 (or $x585 $x587)))))
(assert
 (let (($x340 (not (net.get @X home))))
 (let (($x554 (dir.shlist @X)))
 (let (($x589 (not $x554)))
 (or $x589 $x340)))))
(assert
 (let (($x593 (not (net.get @V0 home))))
 (let (($x558 (dir.shlist @V0)))
 (let (($x591 (not $x558)))
 (or $x591 $x593)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x585 (not $x58)))
 (or $x585 dir.head))))
(assert
 (let (($x554 (dir.shlist @X)))
 (let (($x589 (not $x554)))
 (or $x589 dir.head))))
(assert
 (let (($x558 (dir.shlist @V0)))
 (let (($x591 (not $x558)))
 (or $x591 dir.head))))
(assert
 (let (($x471 (not (= (cache.state_ home) exclusive))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x471))))
(assert
 (let (($x329 (not (= (cache.state_ @X) exclusive))))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x329))))
(assert
 (let (($x476 (not (= (cache.state_ @V0) exclusive))))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x476))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let (($x602 (= @X home)))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x602 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let (($x602 (= @X home)))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x602 $x364)))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let (($x602 (= @X home)))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x602 $x335)))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let (($x411 (= @V0 home)))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x411 $x297)))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let (($x411 (= @V0 home)))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x411 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let (($x602 (= @X home)))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x602 $x534)))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let (($x411 (= @V0 home)))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x411 $x536)))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let (($x610 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x610 $x583)))))
(assert
 (let (($x471 (not (= (cache.state_ home) exclusive))))
 (let (($x460 (= home requester)))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x460 $x471)))))
(assert
 (let (($x329 (not (= (cache.state_ @X) exclusive))))
 (let (($x457 (= @X requester)))
 (let (($x554 (dir.shlist @X)))
 (or $x554 $x457 $x329)))))
(assert
 (let (($x476 (not (= (cache.state_ @V0) exclusive))))
 (let (($x465 (= @V0 requester)))
 (let (($x558 (dir.shlist @V0)))
 (or $x558 $x465 $x476)))))
(assert
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (let (($x395 (= home real_owner)))
 (or (dir.real home) $x395 $x271)))))
(assert
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (let (($x473 (= @X real_owner)))
 (or (dir.real @X) $x473 $x618)))))
(assert
 (let ((?x303 (cache.state_ @V0)))
 (let (($x304 (= ?x303 invalid)))
 (let (($x412 (= @V0 real_owner)))
 (or (dir.real @V0) $x412 $x304)))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x320))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x482))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x578))))
(assert
 (let (($x489 (not (= (cache.state_ home) shared))))
 (or $x489 (not (= (cache.wait home) get)))))
(assert
 (let (($x492 (not (= (cache.state_ @X) shared))))
 (or $x492 (not (= (cache.wait @X) get)))))
(assert
 (let (($x495 (not (= (cache.state_ @V0) shared))))
 (or $x495 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x546 (not (invack home))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x546)))))
(assert
 (let (($x549 (not (invack @X))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x549)))))
(assert
 (let (($x552 (not (invack @V0))))
 (let ((?x303 (cache.state_ @V0)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x552)))))
(assert
 (let (($x471 (not (= (cache.state_ home) exclusive))))
 (or $x471 dir.head)))
(assert
 (let (($x329 (not (= (cache.state_ @X) exclusive))))
 (or $x329 dir.head)))
(assert
 (let (($x476 (not (= (cache.state_ @V0) exclusive))))
 (or $x476 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x394 (= home home)))
 (or $x394 $x187))))
(assert
 (let (($x286 (not (net.fack @V0 @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x286))))
(assert
 (let (($x343 (not (net.putX @Y @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x343)))))
(assert
 (let (($x358 (not (net.putX @Z @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x358)))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x320)))))
(assert
 (let (($x291 (not (net.putX @V1 @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x289 (= ?x288 getX)))
 (or $x289 $x291)))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x289 (= ?x288 getX)))
 (or $x289 $x482)))))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x523)))))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x289 (= ?x288 getX)))
 (or $x289 $x525)))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x578)))))
(assert
 (let (($x354 (not (net.getX @X @Y))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x354)))))
(assert
 (let (($x346 (not (net.getX @X @Z))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x346)))))
(assert
 (let (($x367 (not (net.getX home @Y))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x367)))))
(assert
 (let (($x325 (not (net.getX @X home))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x325)))))
(assert
 (let (($x314 (not (net.getX @V1 @V0))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x651 (= ?x315 getX)))
 (or $x651 $x314)))))
(assert
 (let (($x294 (not (net.getX @V0 @V1))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x289 (= ?x288 getX)))
 (or $x289 $x294)))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x364)))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x335)))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x298 (= ?x288 get)))
 (or $x298 $x297)))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x298 (= ?x288 get)))
 (or $x298 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x534)))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x298 (= ?x288 get)))
 (or $x298 $x536)))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x658 (= ?x644 get)))
 (or $x658 $x583)))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x361)))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x351)))))
(assert
 (let (($x340 (not (net.get @X home))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x340)))))
(assert
 (let (($x301 (not (net.get @V0 @V1))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x298 (= ?x288 get)))
 (or $x298 $x301)))))
(assert
 (let (($x538 (not (net.get home @Y))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x538)))))
(assert
 (let (($x540 (not (net.get home @Z))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x540)))))
(assert
 (let (($x542 (not (net.get home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x542)))))
(assert
 (let (($x544 (not (net.get home @V1))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x544)))))
(assert
 (let (($x349 (not (net.put @Y @X))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x349)))))
(assert
 (let (($x364 (not (net.put @Z @X))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x364)))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x335)))))
(assert
 (let (($x297 (not (net.put @V1 @V0))))
 (let ((?x303 (cache.state_ @V0)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x297)))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let ((?x303 (cache.state_ @V0)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x534)))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let ((?x303 (cache.state_ @V0)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x536)))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let ((?x672 (cache.state_ dir.hptr)))
 (let (($x673 (= ?x672 invalid)))
 (or $x673 $x583)))))
(assert
 (let (($x361 (not (net.get @X @Y))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x361)))))
(assert
 (let (($x351 (not (net.get @X @Z))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x351)))))
(assert
 (let (($x340 (not (net.get @X home))))
 (let ((?x327 (cache.state_ @X)))
 (let (($x618 (= ?x327 invalid)))
 (or $x618 $x340)))))
(assert
 (let (($x301 (not (net.get @V0 @V1))))
 (let ((?x303 (cache.state_ @V0)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x301)))))
(assert
 (let (($x538 (not (net.get home @Y))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x538)))))
(assert
 (let (($x540 (not (net.get home @Z))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x540)))))
(assert
 (let (($x542 (not (net.get home home))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x542)))))
(assert
 (let (($x544 (not (net.get home @V1))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x544)))))
(assert
 (let (($x308 (= @Y home)))
 (or $x308 (not (net.shwb @X @Y)))))
(assert
 (let (($x394 (= home home)))
 (or $x394 (not (net.shwb @X home)))))
(assert
 (let (($x684 (not (= (cache.wait @X) none))))
 (let (($x354 (not (net.getX @X @Y))))
 (or $x354 $x684))))
(assert
 (let (($x684 (not (= (cache.wait @X) none))))
 (let (($x346 (not (net.getX @X @Z))))
 (or $x346 $x684))))
(assert
 (let ((?x272 (cache.wait home)))
 (let (($x273 (= ?x272 none)))
 (let (($x687 (not $x273)))
 (let (($x367 (not (net.getX home @Y))))
 (or $x367 $x687))))))
(assert
 (let (($x684 (not (= (cache.wait @X) none))))
 (let (($x325 (not (net.getX @X home))))
 (or $x325 $x684))))
(assert
 (let (($x317 (not (= (cache.wait @V1) none))))
 (let (($x314 (not (net.getX @V1 @V0))))
 (or $x314 $x317))))
(assert
 (let (($x691 (not (= (cache.wait @V0) none))))
 (let (($x294 (not (net.getX @V0 @V1))))
 (or $x294 $x691))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x693 (= ?x140 getX)))
 (or $x693 $x695)))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x698)))))
(assert
 (let (($x320 (not (net.putX home @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x320)))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x651 (= ?x315 getX)))
 (or $x651 $x701)))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x289 (= ?x288 getX)))
 (or $x289 $x482)))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x578)))))
(assert
 (let (($x325 (not (net.getX @X home))))
 (let ((?x321 (cache.wait @X)))
 (let (($x322 (= ?x321 getX)))
 (or $x322 $x325)))))
(assert
 (let (($x704 (not (net.getX home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x704)))))
(assert
 (let (($x707 (not (net.getX @V1 home))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x651 (= ?x315 getX)))
 (or $x651 $x707)))))
(assert
 (let (($x710 (not (net.getX @V0 home))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x289 (= ?x288 getX)))
 (or $x289 $x710)))))
(assert
 (let (($x471 (not (= (cache.state_ home) exclusive))))
 (or $x471 (not (= (cache.wait home) getX)))))
(assert
 (let (($x329 (not (= (cache.state_ @X) exclusive))))
 (or $x329 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x476 (not (= (cache.state_ @V0) exclusive))))
 (or $x476 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x717 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x717 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x333 (not (rp_net @X))))
 (let (($x335 (not (net.put home @X))))
 (or $x335 $x333))))
(assert
 (let (($x529 (not (rp_net @V0))))
 (let (($x532 (not (net.put home @V0))))
 (or $x532 $x529))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x722)))))
(assert
 (let (($x725 (not (net.put home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x725)))))
(assert
 (let (($x335 (not (net.put home @X))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x335)))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x727 (= ?x315 get)))
 (or $x727 $x729)))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x298 (= ?x288 get)))
 (or $x298 $x532)))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x658 (= ?x644 get)))
 (or $x658 $x583)))))
(assert
 (let (($x732 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x732)))))
(assert
 (let (($x542 (not (net.get home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x542)))))
(assert
 (let (($x340 (not (net.get @X home))))
 (let ((?x321 (cache.wait @X)))
 (let (($x337 (= ?x321 get)))
 (or $x337 $x340)))))
(assert
 (let (($x735 (not (net.get @V1 home))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x727 (= ?x315 get)))
 (or $x727 $x735)))))
(assert
 (let (($x593 (not (net.get @V0 home))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x298 (= ?x288 get)))
 (or $x298 $x593)))))
(assert
 (let (($x587 (not (net.get dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x658 (= ?x644 get)))
 (or $x658 $x587)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x145 $x534)))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x145 $x536)))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x583)))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x722)))))
(assert
 (let (($x725 (not (net.put home home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x725)))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x729)))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x482)))))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (let (($x754 (= real_owner real_owner)))
 (let (($x753 (= real_owner home)))
 (or $x753 $x754 $x523)))))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (let (($x754 (= real_owner real_owner)))
 (let (($x753 (= real_owner home)))
 (or $x753 $x754 $x525)))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x578)))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x695)))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x698)))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x701)))))
(assert
 (let (($x538 (not (net.get home @Y))))
 (let (($x389 (= @Y real_owner)))
 (let (($x308 (= @Y home)))
 (or $x308 $x389 $x538)))))
(assert
 (let (($x540 (not (net.get home @Z))))
 (let (($x392 (= @Z real_owner)))
 (let (($x391 (= @Z home)))
 (or $x391 $x392 $x540)))))
(assert
 (let (($x542 (not (net.get home home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x542)))))
(assert
 (let (($x544 (not (net.get home @V1))))
 (let (($x397 (= @V1 real_owner)))
 (let (($x283 (= @V1 home)))
 (or $x283 $x397 $x544)))))
(assert
 (let (($x587 (not (net.get dir.hptr home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x587)))))
(assert
 (let (($x593 (not (net.get @V0 home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x593)))))
(assert
 (let (($x732 (not (net.get real_owner home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x732)))))
(assert
 (let (($x735 (not (net.get @V1 home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x735)))))
(assert
 (let (($x704 (not (net.getX home home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x704)))))
(assert
 (let (($x707 (not (net.getX @V1 home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x707)))))
(assert
 (let (($x710 (not (net.getX @V0 home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x710)))))
(assert
 (let (($x740 (not (net.getX home @Z))))
 (let (($x392 (= @Z real_owner)))
 (let (($x391 (= @Z home)))
 (or $x391 $x392 $x740)))))
(assert
 (let (($x742 (not (net.getX home @V0))))
 (let (($x412 (= @V0 real_owner)))
 (let (($x411 (= @V0 home)))
 (or $x411 $x412 $x742)))))
(assert
 (let (($x744 (not (net.getX home @V1))))
 (let (($x397 (= @V1 real_owner)))
 (let (($x283 (= @V1 home)))
 (or $x283 $x397 $x744)))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (let (($x394 (= home home)))
 (or $x394 $x532 dir.dirty))))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x534 dir.dirty))))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x536 dir.dirty))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let (($x394 (= home home)))
 (or $x394 $x583 dir.dirty))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let (($x394 (= home home)))
 (or $x394 $x722 dir.dirty))))
(assert
 (let (($x725 (not (net.put home home))))
 (let (($x394 (= home home)))
 (or $x394 $x725 dir.dirty))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let (($x394 (= home home)))
 (or $x394 $x729 dir.dirty))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x394 (= home home)))
 (or $x394 $x482 dir.head))))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x523 dir.head))))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x525 dir.head))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x394 (= home home)))
 (or $x394 $x578 dir.head))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x394 (= home home)))
 (or $x394 $x695 dir.head))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x394 (= home home)))
 (or $x394 $x698 dir.head))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x394 (= home home)))
 (or $x394 $x701 dir.head))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x394 (= home home)))
 (or $x394 $x482 dir.dirty))))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x523 dir.dirty))))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x525 dir.dirty))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x394 (= home home)))
 (or $x394 $x578 dir.dirty))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x394 (= home home)))
 (or $x394 $x695 dir.dirty))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x394 (= home home)))
 (or $x394 $x698 dir.dirty))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x394 (= home home)))
 (or $x394 $x701 dir.dirty))))
(assert
 (let (($x482 (not (net.putX home @V0))))
 (let (($x394 (= home home)))
 (or $x394 $x482))))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x523))))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x525))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x394 (= home home)))
 (or $x394 $x578))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x394 (= home home)))
 (or $x394 $x695))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x394 (= home home)))
 (or $x394 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x394 (= home home)))
 (or $x394 $x701))))
(assert
 (let (($x538 (not (net.get home @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x538 dir.head))))
(assert
 (let (($x540 (not (net.get home @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x540 dir.head))))
(assert
 (let (($x542 (not (net.get home home))))
 (let (($x394 (= home home)))
 (or $x394 $x542 dir.head))))
(assert
 (let (($x544 (not (net.get home @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x544 dir.head))))
(assert
 (let (($x587 (not (net.get dir.hptr home))))
 (let (($x394 (= home home)))
 (or $x394 $x587 dir.head))))
(assert
 (let (($x593 (not (net.get @V0 home))))
 (let (($x394 (= home home)))
 (or $x394 $x593 dir.head))))
(assert
 (let (($x732 (not (net.get real_owner home))))
 (let (($x394 (= home home)))
 (or $x394 $x732 dir.head))))
(assert
 (let (($x735 (not (net.get @V1 home))))
 (let (($x394 (= home home)))
 (or $x394 $x735 dir.head))))
(assert
 (let (($x538 (not (net.get home @Y))))
 (let (($x308 (= @Y home)))
 (or $x308 $x538 dir.dirty))))
(assert
 (let (($x540 (not (net.get home @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x540 dir.dirty))))
(assert
 (let (($x542 (not (net.get home home))))
 (let (($x394 (= home home)))
 (or $x394 $x542 dir.dirty))))
(assert
 (let (($x544 (not (net.get home @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x544 dir.dirty))))
(assert
 (let (($x587 (not (net.get dir.hptr home))))
 (let (($x394 (= home home)))
 (or $x394 $x587 dir.dirty))))
(assert
 (let (($x593 (not (net.get @V0 home))))
 (let (($x394 (= home home)))
 (or $x394 $x593 dir.dirty))))
(assert
 (let (($x732 (not (net.get real_owner home))))
 (let (($x394 (= home home)))
 (or $x394 $x732 dir.dirty))))
(assert
 (let (($x735 (not (net.get @V1 home))))
 (let (($x394 (= home home)))
 (or $x394 $x735 dir.dirty))))
(assert
 (let (($x704 (not (net.getX home home))))
 (let (($x394 (= home home)))
 (or $x394 $x704 dir.head))))
(assert
 (let (($x707 (not (net.getX @V1 home))))
 (let (($x394 (= home home)))
 (or $x394 $x707 dir.head))))
(assert
 (let (($x710 (not (net.getX @V0 home))))
 (let (($x394 (= home home)))
 (or $x394 $x710 dir.head))))
(assert
 (let (($x740 (not (net.getX home @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x740 dir.head))))
(assert
 (let (($x742 (not (net.getX home @V0))))
 (let (($x411 (= @V0 home)))
 (or $x411 $x742 dir.head))))
(assert
 (let (($x744 (not (net.getX home @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x744 dir.head))))
(assert
 (let (($x704 (not (net.getX home home))))
 (let (($x394 (= home home)))
 (or $x394 $x704 dir.dirty))))
(assert
 (let (($x707 (not (net.getX @V1 home))))
 (let (($x394 (= home home)))
 (or $x394 $x707 dir.dirty))))
(assert
 (let (($x710 (not (net.getX @V0 home))))
 (let (($x394 (= home home)))
 (or $x394 $x710 dir.dirty))))
(assert
 (let (($x740 (not (net.getX home @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x740 dir.dirty))))
(assert
 (let (($x742 (not (net.getX home @V0))))
 (let (($x411 (= @V0 home)))
 (or $x411 $x742 dir.dirty))))
(assert
 (let (($x744 (not (net.getX home @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x744 dir.dirty))))
(assert
 (let (($x704 (not (net.getX home home))))
 (let (($x394 (= home home)))
 (or $x394 $x704))))
(assert
 (let (($x707 (not (net.getX @V1 home))))
 (let (($x394 (= home home)))
 (or $x394 $x707))))
(assert
 (let (($x710 (not (net.getX @V0 home))))
 (let (($x394 (= home home)))
 (or $x394 $x710))))
(assert
 (let (($x740 (not (net.getX home @Z))))
 (let (($x391 (= @Z home)))
 (or $x391 $x740))))
(assert
 (let (($x742 (not (net.getX home @V0))))
 (let (($x411 (= @V0 home)))
 (or $x411 $x742))))
(assert
 (let (($x744 (not (net.getX home @V1))))
 (let (($x283 (= @V1 home)))
 (or $x283 $x744))))
(assert
 (let (($x704 (not (net.getX home home))))
 (let (($x394 (= home home)))
 (let (($x460 (= home requester)))
 (or $x460 $x394 $x704)))))
(assert
 (let (($x707 (not (net.getX @V1 home))))
 (let (($x394 (= home home)))
 (let (($x463 (= @V1 requester)))
 (or $x463 $x394 $x707)))))
(assert
 (let (($x710 (not (net.getX @V0 home))))
 (let (($x394 (= home home)))
 (let (($x465 (= @V0 requester)))
 (or $x465 $x394 $x710)))))
(assert
 (let (($x740 (not (net.getX home @Z))))
 (let (($x391 (= @Z home)))
 (let (($x460 (= home requester)))
 (or $x460 $x391 $x740)))))
(assert
 (let (($x742 (not (net.getX home @V0))))
 (let (($x411 (= @V0 home)))
 (let (($x460 (= home requester)))
 (or $x460 $x411 $x742)))))
(assert
 (let (($x744 (not (net.getX home @V1))))
 (let (($x283 (= @V1 home)))
 (let (($x460 (= home requester)))
 (or $x460 $x283 $x744)))))
(assert
 (let (($x717 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x717))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x843 (= dir.hptr dir.hptr)))
 (or $x843 $x578))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x845 (= real_owner dir.hptr)))
 (or $x845 $x695))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x484 (= home dir.hptr)))
 (or $x484 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x848 (= @V1 dir.hptr)))
 (or $x848 $x701))))
(assert
 (let (($x717 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x843 (= dir.hptr dir.hptr)))
 (or $x843 $x717))))
(assert
 (let (($x852 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x852))))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x523))))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x525))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x394 (= home home)))
 (or $x394 $x578))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x394 (= home home)))
 (or $x394 $x695))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x394 (= home home)))
 (or $x394 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x394 (= home home)))
 (or $x394 $x701))))
(assert
 (let (($x495 (not (= (cache.state_ @V0) shared))))
 (let (($x529 (not (rp_net @V0))))
 (or $x529 $x495))))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (let (($x499 (= real_owner @X)))
 (or $x499 $x523))))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (let (($x503 (= real_owner @V0)))
 (or $x503 $x525))))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (let (($x845 (= real_owner dir.hptr)))
 (or $x845 $x578))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x754 (= real_owner real_owner)))
 (or $x754 $x695))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x860 (= real_owner @V1)))
 (or $x860 $x701))))
(assert
 (let (($x532 (not (net.put home @V0))))
 (or $x532 dir.head)))
(assert
 (let (($x534 (not (net.put dir.hptr @X))))
 (or $x534 dir.head)))
(assert
 (let (($x536 (not (net.put dir.hptr @V0))))
 (or $x536 dir.head)))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (or $x583 dir.head)))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (or $x722 dir.head)))
(assert
 (let (($x725 (not (net.put home home))))
 (or $x725 dir.head)))
(assert
 (let (($x729 (not (net.put home @V1))))
 (or $x729 dir.head)))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (or $x523 dir.head)))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (or $x525 dir.head)))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (or $x578 dir.head)))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (or $x695 dir.head)))
(assert
 (let (($x698 (not (net.putX home home))))
 (or $x698 dir.head)))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (or $x701 dir.head)))
(assert
 (let (($x523 (not (net.putX real_owner @X))))
 (or $x523 dir.dirty)))
(assert
 (let (($x525 (not (net.putX real_owner @V0))))
 (or $x525 dir.dirty)))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (or $x578 dir.dirty)))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (or $x695 dir.dirty)))
(assert
 (let (($x698 (not (net.putX home home))))
 (or $x698 dir.dirty)))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (or $x701 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner home)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (let (($x578 (not (net.putX home dir.hptr))))
 (or $x578 dir.head)))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (or $x695 dir.head)))
(assert
 (let (($x698 (not (net.putX home home))))
 (or $x698 dir.head)))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (or $x701 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home home)))
(assert
 (not (net.putX home @V1)))
(assert
 (let (($x529 (not (rp_net @V0))))
 (let (($x532 (not (net.put home @V0))))
 (or $x532 $x529))))
(assert
 (let (($x333 (not (rp_net @X))))
 (let (($x534 (not (net.put dir.hptr @X))))
 (or $x534 $x333))))
(assert
 (let (($x529 (not (rp_net @V0))))
 (let (($x536 (not (net.put dir.hptr @V0))))
 (or $x536 $x529))))
(assert
 (let (($x892 (not (rp_net dir.hptr))))
 (let (($x583 (not (net.put home dir.hptr))))
 (or $x583 $x892))))
(assert
 (let (($x895 (not (rp_net real_owner))))
 (let (($x722 (not (net.put home real_owner))))
 (or $x722 $x895))))
(assert
 (let (($x898 (not (rp_net home))))
 (let (($x725 (not (net.put home home))))
 (or $x725 $x898))))
(assert
 (let (($x901 (not (rp_net @V1))))
 (let (($x729 (not (net.put home @V1))))
 (or $x729 $x901))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (let (($x546 (not (invack home))))
 (or $x546 (not (invnet home)))))
(assert
 (let (($x549 (not (invack @X))))
 (or $x549 (not (invnet @X)))))
(assert
 (let (($x552 (not (invack @V0))))
 (or $x552 (not (invnet @V0)))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x583 dir.pending))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x722 dir.pending))))
(assert
 (let (($x725 (not (net.put home home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x725 dir.pending))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x729 dir.pending))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x904 dir.pending))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x906 dir.pending))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x908 dir.pending))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x910 dir.pending))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x583 dir.dirty))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x722 dir.dirty))))
(assert
 (let (($x725 (not (net.put home home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x725 dir.dirty))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x729 dir.dirty))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x904 dir.dirty))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x906 dir.dirty))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x908 dir.dirty))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x910 dir.dirty))))
(assert
 (let (($x583 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x583))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x722))))
(assert
 (let (($x725 (not (net.put home home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x725))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x729))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x904))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x906))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x908))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x910))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x698))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x695))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x701))))
(assert
 (let (($x725 (not (net.put home home))))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x725))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x722))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x729))))
(assert
 (let (($x542 (not (net.get home home))))
 (let (($x598 (dir.shlist home)))
 (let (($x948 (not $x598)))
 (or $x948 $x542)))))
(assert
 (let (($x732 (not (net.get real_owner home))))
 (let (($x921 (dir.shlist real_owner)))
 (let (($x950 (not $x921)))
 (or $x950 $x732)))))
(assert
 (let (($x735 (not (net.get @V1 home))))
 (let (($x924 (dir.shlist @V1)))
 (let (($x952 (not $x924)))
 (or $x952 $x735)))))
(assert
 (let (($x598 (dir.shlist home)))
 (let (($x948 (not $x598)))
 (or $x948 dir.head))))
(assert
 (let (($x921 (dir.shlist real_owner)))
 (let (($x950 (not $x921)))
 (or $x950 dir.head))))
(assert
 (let (($x924 (dir.shlist @V1)))
 (let (($x952 (not $x924)))
 (or $x952 dir.head))))
(assert
 (let (($x717 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x717))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let (($x753 (= real_owner home)))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x753 $x722)))))
(assert
 (let (($x725 (not (net.put home home))))
 (let (($x394 (= home home)))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x394 $x725)))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let (($x283 (= @V1 home)))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x283 $x729)))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let (($x610 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x610 $x904)))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let (($x753 (= real_owner home)))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x753 $x906)))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let (($x394 (= home home)))
 (let (($x598 (dir.shlist home)))
 (or $x598 $x394 $x908)))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let (($x283 (= @V1 home)))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x283 $x910)))))
(assert
 (let (($x717 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x965 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x965 $x717)))))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x695))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x698))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x701))))
(assert
 (let (($x852 (not (= (cache.state_ dir.hptr) shared))))
 (or $x852 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x717 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x717 dir.head)))
(assert
 (let (($x695 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x693 (= ?x140 getX)))
 (or $x693 $x695)))))
(assert
 (let (($x698 (not (net.putX home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x698)))))
(assert
 (let (($x701 (not (net.putX home @V1))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x651 (= ?x315 getX)))
 (or $x651 $x701)))))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x882)))))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x693 (= ?x140 getX)))
 (or $x693 $x884)))))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x886)))))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x651 (= ?x315 getX)))
 (or $x651 $x888)))))
(assert
 (let (($x704 (not (net.getX home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x704)))))
(assert
 (let (($x707 (not (net.getX @V1 home))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x651 (= ?x315 getX)))
 (or $x651 $x707)))))
(assert
 (let (($x710 (not (net.getX @V0 home))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x289 (= ?x288 getX)))
 (or $x289 $x710)))))
(assert
 (let (($x740 (not (net.getX home @Z))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x740)))))
(assert
 (let (($x742 (not (net.getX home @V0))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x742)))))
(assert
 (let (($x744 (not (net.getX home @V1))))
 (let ((?x272 (cache.wait home)))
 (let (($x649 (= ?x272 getX)))
 (or $x649 $x744)))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x722)))))
(assert
 (let (($x725 (not (net.put home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x725)))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x727 (= ?x315 get)))
 (or $x727 $x729)))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x658 (= ?x644 get)))
 (or $x658 $x904)))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x906)))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let ((?x272 (cache.wait home)))
 (let (($x625 (= ?x272 get)))
 (or $x625 $x908)))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x727 (= ?x315 get)))
 (or $x727 $x910)))))
(assert
 (let (($x587 (not (net.get dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x658 (= ?x644 get)))
 (or $x658 $x587)))))
(assert
 (let (($x593 (not (net.get @V0 home))))
 (let ((?x288 (cache.wait @V0)))
 (let (($x298 (= ?x288 get)))
 (or $x298 $x593)))))
(assert
 (let (($x732 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x732)))))
(assert
 (let (($x735 (not (net.get @V1 home))))
 (let ((?x315 (cache.wait @V1)))
 (let (($x727 (= ?x315 get)))
 (or $x727 $x735)))))
(assert
 (let (($x722 (not (net.put home real_owner))))
 (let ((?x984 (cache.state_ real_owner)))
 (let (($x985 (= ?x984 invalid)))
 (or $x985 $x722)))))
(assert
 (let (($x725 (not (net.put home home))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x725)))))
(assert
 (let (($x729 (not (net.put home @V1))))
 (let ((?x988 (cache.state_ @V1)))
 (let (($x989 (= ?x988 invalid)))
 (or $x989 $x729)))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let ((?x672 (cache.state_ dir.hptr)))
 (let (($x673 (= ?x672 invalid)))
 (or $x673 $x904)))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let ((?x984 (cache.state_ real_owner)))
 (let (($x985 (= ?x984 invalid)))
 (or $x985 $x906)))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x908)))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let ((?x988 (cache.state_ @V1)))
 (let (($x989 (= ?x988 invalid)))
 (or $x989 $x910)))))
(assert
 (let (($x587 (not (net.get dir.hptr home))))
 (let ((?x672 (cache.state_ dir.hptr)))
 (let (($x673 (= ?x672 invalid)))
 (or $x673 $x587)))))
(assert
 (let (($x593 (not (net.get @V0 home))))
 (let ((?x303 (cache.state_ @V0)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x593)))))
(assert
 (let (($x732 (not (net.get real_owner home))))
 (let ((?x984 (cache.state_ real_owner)))
 (let (($x985 (= ?x984 invalid)))
 (or $x985 $x732)))))
(assert
 (let (($x735 (not (net.get @V1 home))))
 (let ((?x988 (cache.state_ @V1)))
 (let (($x989 (= ?x988 invalid)))
 (or $x989 $x735)))))
(assert
 (let ((?x272 (cache.wait home)))
 (let (($x273 (= ?x272 none)))
 (let (($x687 (not $x273)))
 (let (($x704 (not (net.getX home home))))
 (or $x704 $x687))))))
(assert
 (let (($x317 (not (= (cache.wait @V1) none))))
 (let (($x707 (not (net.getX @V1 home))))
 (or $x707 $x317))))
(assert
 (let (($x691 (not (= (cache.wait @V0) none))))
 (let (($x710 (not (net.getX @V0 home))))
 (or $x710 $x691))))
(assert
 (let ((?x272 (cache.wait home)))
 (let (($x273 (= ?x272 none)))
 (let (($x687 (not $x273)))
 (let (($x740 (not (net.getX home @Z))))
 (or $x740 $x687))))))
(assert
 (let ((?x272 (cache.wait home)))
 (let (($x273 (= ?x272 none)))
 (let (($x687 (not $x273)))
 (let (($x742 (not (net.getX home @V0))))
 (or $x742 $x687))))))
(assert
 (let ((?x272 (cache.wait home)))
 (let (($x273 (= ?x272 none)))
 (let (($x687 (not $x273)))
 (let (($x744 (not (net.getX home @V1))))
 (or $x744 $x687))))))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x693 (= ?x140 getX)))
 (or $x693 $x1006)))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x1009)))))
(assert
 (let (($x1012 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1012 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1016 (not (= (cache.state_ @V1) exclusive))))
 (or $x1016 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x892 (not (rp_net dir.hptr))))
 (let (($x583 (not (net.put home dir.hptr))))
 (or $x583 $x892))))
(assert
 (let (($x895 (not (rp_net real_owner))))
 (let (($x722 (not (net.put home real_owner))))
 (or $x722 $x895))))
(assert
 (let (($x898 (not (rp_net home))))
 (let (($x725 (not (net.put home home))))
 (or $x725 $x898))))
(assert
 (let (($x901 (not (rp_net @V1))))
 (let (($x729 (not (net.put home @V1))))
 (or $x729 $x901))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x145 $x904)))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x145 $x906)))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x145 $x908)))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x145 $x910)))))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (let (($x754 (= real_owner real_owner)))
 (let (($x753 (= real_owner home)))
 (or $x753 $x754 $x882)))))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (let (($x754 (= real_owner real_owner)))
 (let (($x753 (= real_owner home)))
 (or $x753 $x754 $x884)))))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (let (($x754 (= real_owner real_owner)))
 (let (($x753 (= real_owner home)))
 (or $x753 $x754 $x886)))))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (let (($x754 (= real_owner real_owner)))
 (let (($x753 (= real_owner home)))
 (or $x753 $x754 $x888)))))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x1006)))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (let (($x395 (= home real_owner)))
 (let (($x394 (= home home)))
 (or $x394 $x395 $x1009)))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x904 dir.dirty))))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x906 dir.dirty))))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x908 dir.dirty))))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (let (($x610 (= dir.hptr home)))
 (or $x610 $x910 dir.dirty))))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x882 dir.head))))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x884 dir.head))))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x886 dir.head))))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x888 dir.head))))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x882 dir.dirty))))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x884 dir.dirty))))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x886 dir.dirty))))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x888 dir.dirty))))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x882))))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x884))))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x886))))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x888))))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (let (($x394 (= home home)))
 (or $x394 $x1006 dir.head))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (let (($x394 (= home home)))
 (or $x394 $x1009 dir.head))))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (let (($x394 (= home home)))
 (or $x394 $x1006 dir.dirty))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (let (($x394 (= home home)))
 (or $x394 $x1009 dir.dirty))))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (let (($x394 (= home home)))
 (or $x394 $x1006))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (let (($x394 (= home home)))
 (or $x394 $x1009))))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (let (($x394 (= home home)))
 (let (($x1051 (= real_owner requester)))
 (or $x1051 $x394 $x1006)))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (let (($x394 (= home home)))
 (let (($x965 (= dir.hptr requester)))
 (or $x965 $x394 $x1009)))))
(assert
 (let (($x1012 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x754 (= real_owner real_owner)))
 (or $x754 $x1012))))
(assert
 (let (($x1016 (not (= (cache.state_ @V1) exclusive))))
 (let (($x397 (= @V1 real_owner)))
 (or $x397 $x1016))))
(assert
 (let (($x1012 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x845 (= real_owner dir.hptr)))
 (or $x845 $x1012))))
(assert
 (let (($x1016 (not (= (cache.state_ @V1) exclusive))))
 (let (($x848 (= @V1 dir.hptr)))
 (or $x848 $x1016))))
(assert
 (let (($x1059 (not (= (cache.state_ real_owner) shared))))
 (let (($x754 (= real_owner real_owner)))
 (or $x754 $x1059))))
(assert
 (let (($x1062 (not (= (cache.state_ @V1) shared))))
 (let (($x397 (= @V1 real_owner)))
 (or $x397 $x1062))))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x882))))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x884))))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x886))))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x888))))
(assert
 (let (($x489 (not (= (cache.state_ home) shared))))
 (let (($x898 (not (rp_net home))))
 (or $x898 $x489))))
(assert
 (let (($x852 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x892 (not (rp_net dir.hptr))))
 (or $x892 $x852))))
(assert
 (let (($x1059 (not (= (cache.state_ real_owner) shared))))
 (let (($x895 (not (rp_net real_owner))))
 (or $x895 $x1059))))
(assert
 (let (($x1062 (not (= (cache.state_ @V1) shared))))
 (let (($x901 (not (rp_net @V1))))
 (or $x901 $x1062))))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (let (($x845 (= real_owner dir.hptr)))
 (or $x845 $x882))))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (let (($x754 (= real_owner real_owner)))
 (or $x754 $x884))))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (let (($x753 (= real_owner home)))
 (or $x753 $x886))))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (let (($x860 (= real_owner @V1)))
 (or $x860 $x888))))
(assert
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (or $x904 dir.head)))
(assert
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (or $x906 dir.head)))
(assert
 (let (($x908 (not (net.put dir.hptr home))))
 (or $x908 dir.head)))
(assert
 (let (($x910 (not (net.put dir.hptr @V1))))
 (or $x910 dir.head)))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (or $x882 dir.head)))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (or $x884 dir.head)))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (or $x886 dir.head)))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (or $x888 dir.head)))
(assert
 (let (($x882 (not (net.putX real_owner dir.hptr))))
 (or $x882 dir.dirty)))
(assert
 (let (($x884 (not (net.putX real_owner real_owner))))
 (or $x884 dir.dirty)))
(assert
 (let (($x886 (not (net.putX real_owner home))))
 (or $x886 dir.dirty)))
(assert
 (let (($x888 (not (net.putX real_owner @V1))))
 (or $x888 dir.dirty)))
(assert
 (let (($x892 (not (rp_net dir.hptr))))
 (let (($x904 (not (net.put dir.hptr dir.hptr))))
 (or $x904 $x892))))
(assert
 (let (($x895 (not (rp_net real_owner))))
 (let (($x906 (not (net.put dir.hptr real_owner))))
 (or $x906 $x895))))
(assert
 (let (($x898 (not (rp_net home))))
 (let (($x908 (not (net.put dir.hptr home))))
 (or $x908 $x898))))
(assert
 (let (($x901 (not (rp_net @V1))))
 (let (($x910 (not (net.put dir.hptr @V1))))
 (or $x910 $x901))))
(assert
 (let (($x1012 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x1012))))
(assert
 (let (($x1016 (not (= (cache.state_ @V1) exclusive))))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x1016))))
(assert
 (let (($x1012 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x1051 (= real_owner requester)))
 (let (($x921 (dir.shlist real_owner)))
 (or $x921 $x1051 $x1012)))))
(assert
 (let (($x1016 (not (= (cache.state_ @V1) exclusive))))
 (let (($x463 (= @V1 requester)))
 (let (($x924 (dir.shlist @V1)))
 (or $x924 $x463 $x1016)))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (let (($x142 (not $x141)))
 (let (($x1059 (not (= (cache.state_ real_owner) shared))))
 (or $x1059 $x142))))))
(assert
 (let (($x1062 (not (= (cache.state_ @V1) shared))))
 (or $x1062 (not (= (cache.wait @V1) get)))))
(assert
 (let (($x1012 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1012 dir.head)))
(assert
 (let (($x1016 (not (= (cache.state_ @V1) exclusive))))
 (or $x1016 dir.head)))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x693 (= ?x140 getX)))
 (or $x693 $x1006)))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x1009)))))
(assert
 (let (($x1006 (not (net.getX real_owner home))))
 (or $x1006 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x1009 (not (net.getX dir.hptr home))))
 (or $x1009 (not (= (cache.wait dir.hptr) none)))))
(check-sat)
