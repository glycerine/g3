(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __invnet (id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun __invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (cache.wait real_owner) get)))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__invnet __dst))
(assert
 (not (= __dst home)))
(assert
 (let ((?x305 (cache.wait @Y)))
 (let (($x306 (= ?x305 none)))
 (let ((?x300 (cache.wait @X)))
 (let (($x301 (= ?x300 none)))
 (and (= (cache.state_ @X) exclusive) $x301 (= (cache.state_ @Y) exclusive) $x306 (not (= @X @Y))))))))
(assert
 (let ((?x298 (cache.state_ @X)))
 (= ?x298 (ite (and (= @X __dst)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x303 (cache.state_ @Y)))
 (= ?x303 (ite (and (= @Y __dst)) invalid (__cache.state_ @Y)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x342 (not (= (__cache.state_ @X) exclusive))))
 (let (($x340 (= @X real_owner)))
 (or $x340 $x342))))
(assert
 (let (($x346 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x344 (= @Y real_owner)))
 (or $x344 $x346))))
(assert
 (let (($x342 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x342)))
(assert
 (let (($x346 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x346)))
(assert
 (let (($x353 (not (= (__cache.state_ @X) shared))))
 (let (($x340 (= @X real_owner)))
 (or $x340 $x353))))
(assert
 (let (($x356 (not (= (__cache.state_ @Y) shared))))
 (let (($x344 (= @Y real_owner)))
 (or $x344 $x356))))
(assert
 (let (($x353 (not (= (__cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x353)))
(assert
 (let (($x356 (not (= (__cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x356)))
(assert
 (let (($x365 (not (__invack __dst))))
 (or $x365 (not (__invnet __dst)))))
(assert
 (let (($x370 (not (= (__cache.state_ __dst) shared))))
 (let (($x365 (not (__invack __dst))))
 (or $x365 $x370))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x373))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x376))))
(assert
 (let (($x380 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x378 (not $x58)))
 (or $x378 $x380)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x378 (not $x58)))
 (or $x378 dir.head))))
(assert
 (let (($x385 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x385))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let (($x387 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x387 $x376)))))
(assert
 (let (($x385 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x389 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x389 $x385)))))
(assert
 (let (($x340 (= @X real_owner)))
 (or (dir.real @X) $x340 (= (__cache.state_ @X) invalid))))
(assert
 (let (($x344 (= @Y real_owner)))
 (or (dir.real @Y) $x344 (= (__cache.state_ @Y) invalid))))
(assert
 (let ((?x368 (__cache.state_ __dst)))
 (let (($x399 (= ?x368 invalid)))
 (let (($x398 (= __dst real_owner)))
 (or (dir.real __dst) $x398 $x399)))))
(assert
 (let ((?x383 (__cache.state_ dir.hptr)))
 (let (($x402 (= ?x383 invalid)))
 (let (($x145 (= dir.hptr real_owner)))
 (or (dir.real dir.hptr) $x145 $x402)))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x373))))
(assert
 (let (($x142 (not (= (cache.wait real_owner) get))))
 (let (($x407 (not (= (__cache.state_ real_owner) shared))))
 (or $x407 $x142))))
(assert
 (let (($x353 (not (= (__cache.state_ @X) shared))))
 (or $x353 (not (= (cache.wait @X) get)))))
(assert
 (let (($x356 (not (= (__cache.state_ @Y) shared))))
 (or $x356 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x365 (not (__invack __dst))))
 (let ((?x368 (__cache.state_ __dst)))
 (let (($x399 (= ?x368 invalid)))
 (or $x399 $x365)))))
(assert
 (let (($x342 (not (= (__cache.state_ @X) exclusive))))
 (or $x342 dir.head)))
(assert
 (let (($x346 (not (= (__cache.state_ @Y) exclusive))))
 (or $x346 dir.head)))
(assert
 (let (($x419 (not (= (__cache.state_ __dst) exclusive))))
 (or $x419 dir.head)))
(assert
 (let (($x385 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x385 dir.head)))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x423 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x425 (= home home)))
 (or $x425 $x187))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x373)))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x376)))))
(assert
 (let (($x380 (not (net.get dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x380)))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let ((?x383 (__cache.state_ dir.hptr)))
 (let (($x402 (= ?x383 invalid)))
 (or $x402 $x376)))))
(assert
 (let (($x380 (not (net.get dir.hptr home))))
 (let ((?x383 (__cache.state_ dir.hptr)))
 (let (($x402 (= ?x383 invalid)))
 (or $x402 $x380)))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x373)))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x435 (= ?x140 getX)))
 (or $x435 $x437)))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (let ((?x300 (cache.wait @X)))
 (let (($x439 (= ?x300 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (let ((?x305 (cache.wait @Y)))
 (let (($x443 (= ?x305 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x448)))))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x423 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x342 (not (= (__cache.state_ @X) exclusive))))
 (or $x342 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x346 (not (= (__cache.state_ @Y) exclusive))))
 (or $x346 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x385 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x385 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x459 (not (rp_net dir.hptr))))
 (let (($x376 (not (net.put home dir.hptr))))
 (or $x376 $x459))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x376)))))
(assert
 (let (($x380 (not (net.get dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x380)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x376)))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x373)))))
(assert
 (let (($x380 (not (net.get dir.hptr home))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x380)))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x437)))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x441)))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x445)))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x448)))))
(assert
 (let (($x462 (not (net.getX home home))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x462)))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x376 dir.dirty))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x373 dir.head))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x373 dir.dirty))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x373))))
(assert
 (let (($x380 (not (net.get dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x380 dir.head))))
(assert
 (let (($x380 (not (net.get dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x380 dir.dirty))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or $x425 $x437 dir.head))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or $x425 $x441 dir.head))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or $x425 $x445 dir.head))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x448 dir.head))))
(assert
 (let (($x462 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or $x425 $x462 dir.head))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or $x425 $x437 dir.dirty))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or $x425 $x441 dir.dirty))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or $x425 $x445 dir.dirty))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x448 dir.dirty))))
(assert
 (let (($x462 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or $x425 $x462 dir.dirty))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or $x425 $x437))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or $x425 $x441))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or $x425 $x445))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x448))))
(assert
 (let (($x462 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or $x425 $x462))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or (= real_owner requester) $x425 $x437))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or (= @X requester) $x425 $x441))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or (= @Y requester) $x425 $x445))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (let (($x389 (= dir.hptr requester)))
 (or $x389 $x425 $x448)))))
(assert
 (let (($x462 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or (= home requester) $x425 $x462))))
(assert
 (let (($x419 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x398 (= __dst real_owner)))
 (or $x398 $x419))))
(assert
 (let (($x385 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x385))))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x504 (= real_owner real_owner)))
 (or $x504 $x423))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x506 (= dir.hptr dir.hptr)))
 (or $x506 $x373))))
(assert
 (let (($x419 (not (= (__cache.state_ __dst) exclusive))))
 (or (= __dst dir.hptr) $x419)))
(assert
 (let (($x385 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x506 (= dir.hptr dir.hptr)))
 (or $x506 $x385))))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x511 (= real_owner dir.hptr)))
 (or $x511 $x423))))
(assert
 (let (($x370 (not (= (__cache.state_ __dst) shared))))
 (let (($x398 (= __dst real_owner)))
 (or $x398 $x370))))
(assert
 (let (($x515 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x515))))
(assert
 (let (($x407 (not (= (__cache.state_ real_owner) shared))))
 (let (($x504 (= real_owner real_owner)))
 (or $x504 $x407))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x373))))
(assert
 (let (($x515 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x459 (not (rp_net dir.hptr))))
 (or $x459 $x515))))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (let (($x511 (= real_owner dir.hptr)))
 (or $x511 $x373))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (or $x376 dir.head)))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (or $x373 dir.head)))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (or $x373 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x373 (not (net.putX home dir.hptr))))
 (or $x373 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x459 (not (rp_net dir.hptr))))
 (let (($x376 (not (net.put home dir.hptr))))
 (or $x376 $x459))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.get home home)))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x376 dir.pending))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x526 dir.pending))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x376 dir.dirty))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x526 dir.dirty))))
(assert
 (let (($x376 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x376))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x526))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let (($x387 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x387 $x526)))))
(assert
 (let (($x515 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x515 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x524)))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x435 (= ?x140 getX)))
 (or $x435 $x437)))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (let ((?x300 (cache.wait @X)))
 (let (($x439 (= ?x300 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (let ((?x305 (cache.wait @Y)))
 (let (($x443 (= ?x305 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x448)))))
(assert
 (let (($x462 (not (net.getX home home))))
 (let ((?x538 (cache.wait home)))
 (let (($x539 (= ?x538 getX)))
 (or $x539 $x462)))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x526)))))
(assert
 (let (($x528 (not (net.get home home))))
 (let ((?x538 (cache.wait home)))
 (let (($x542 (= ?x538 get)))
 (or $x542 $x528)))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let ((?x383 (__cache.state_ dir.hptr)))
 (let (($x402 (= ?x383 invalid)))
 (or $x402 $x526)))))
(assert
 (let (($x528 (not (net.get home home))))
 (or (= (__cache.state_ home) invalid) $x528)))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (or $x437 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x441 (not (net.getX @X home))))
 (or $x441 (not (= (cache.wait @X) none)))))
(assert
 (let (($x445 (not (net.getX @Y home))))
 (or $x445 (not (= (cache.wait @Y) none)))))
(assert
 (let (($x448 (not (net.getX dir.hptr home))))
 (or $x448 (not (= (cache.wait dir.hptr) none)))))
(assert
 (let (($x462 (not (net.getX home home))))
 (or $x462 (not (= (cache.wait home) none)))))
(assert
 (let (($x462 (not (net.getX home home))))
 (let ((?x538 (cache.wait home)))
 (let (($x539 (= ?x538 getX)))
 (or $x539 $x462)))))
(assert
 (let (($x562 (not (= (__cache.state_ home) exclusive))))
 (or $x562 (not (= (cache.wait home) getX)))))
(assert
 (let (($x528 (not (net.get home home))))
 (let ((?x538 (cache.wait home)))
 (let (($x542 (= ?x538 get)))
 (or $x542 $x528)))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x387 (= dir.hptr home)))
 (or $x387 $x145 $x526)))))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (let (($x504 (= real_owner real_owner)))
 (let (($x566 (= real_owner home)))
 (or $x566 $x504 $x524)))))
(assert
 (let (($x528 (not (net.get home home))))
 (let (($x463 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x463 $x528)))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (let (($x387 (= dir.hptr home)))
 (or $x387 $x526 dir.dirty))))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (let (($x566 (= real_owner home)))
 (or $x566 $x524 dir.head))))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (let (($x566 (= real_owner home)))
 (or $x566 $x524 dir.dirty))))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (let (($x566 (= real_owner home)))
 (or $x566 $x524))))
(assert
 (let (($x528 (not (net.get home home))))
 (let (($x425 (= home home)))
 (or $x425 $x528 dir.head))))
(assert
 (let (($x528 (not (net.get home home))))
 (let (($x425 (= home home)))
 (or $x425 $x528 dir.dirty))))
(assert
 (let (($x562 (not (= (__cache.state_ home) exclusive))))
 (let (($x463 (= home real_owner)))
 (or $x463 $x562))))
(assert
 (let (($x562 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x562)))
(assert
 (let (($x579 (not (= (__cache.state_ home) shared))))
 (let (($x463 (= home real_owner)))
 (or $x463 $x579))))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (let (($x566 (= real_owner home)))
 (or $x566 $x524))))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (let (($x511 (= real_owner dir.hptr)))
 (or $x511 $x524))))
(assert
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (or $x526 dir.head)))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (or $x524 dir.head)))
(assert
 (let (($x524 (not (net.putX real_owner dir.hptr))))
 (or $x524 dir.dirty)))
(assert
 (let (($x459 (not (rp_net dir.hptr))))
 (let (($x526 (not (net.put dir.hptr dir.hptr))))
 (or $x526 $x459))))
(assert
 (let (($x579 (not (= (__cache.state_ home) shared))))
 (or $x579 (not (= (cache.wait home) get)))))
(assert
 (let (($x562 (not (= (__cache.state_ home) exclusive))))
 (or $x562 dir.head)))
(check-sat)
