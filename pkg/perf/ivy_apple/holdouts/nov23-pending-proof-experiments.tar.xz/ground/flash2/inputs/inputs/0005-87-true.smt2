(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __invack (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun __dir.local_ () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun dir.local_ () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invnet (id) Bool)
(declare-fun __dir.real (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x144 (not dir.dirty)))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x144 __dir.pending))))
(assert
 (not (net.fack requester home)))
(assert
 __dir.pending)
(assert
 (__invack src))
(assert
 (let (($x272 (= src home)))
 (not $x272)))
(assert
 (not dir.pending))
(assert
 (= dir.local_ (and (not __ts0_a) __dir.local_)))
(assert
 (= __ts0_a (and __dir.local_ (not dir.dirty))))
(assert
 (let (($x344 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x382 (not (net.getX home @Y))))
 (let (($x361 (not (net.getX @X @Z))))
 (let (($x369 (not (net.getX @X @Y))))
 (let (($x370 (= @Y @Z)))
 (let (($x383 (and (or $x370 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x370 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x370 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x370 $x369 $x361) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x361 (not (net.putX @Y @X))) $x382 $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x344 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x383)))))))))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let (($x404 (= @Y real_owner)))
 (let (($x323 (= @Y home)))
 (or $x323 $x404 $x364)))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let (($x407 (= @Z real_owner)))
 (let (($x406 (= @Z home)))
 (or $x406 $x407 $x379)))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x350)))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let (($x412 (= @V1 real_owner)))
 (let (($x298 (= @V1 home)))
 (or $x298 $x412 $x312)))))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (let (($x404 (= @Y real_owner)))
 (let (($x323 (= @Y home)))
 (or $x323 $x404 $x358)))))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (let (($x407 (= @Z real_owner)))
 (let (($x406 (= @Z home)))
 (or $x406 $x407 $x373)))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x335)))))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (let (($x412 (= @V1 real_owner)))
 (let (($x298 (= @V1 home)))
 (or $x298 $x412 $x306)))))
(assert
 (let (($x376 (not (net.get @X @Y))))
 (let (($x404 (= @Y real_owner)))
 (let (($x323 (= @Y home)))
 (or $x323 $x404 $x376)))))
(assert
 (let (($x366 (not (net.get @X @Z))))
 (let (($x407 (= @Z real_owner)))
 (let (($x406 (= @Z home)))
 (or $x406 $x407 $x366)))))
(assert
 (let (($x355 (not (net.get @X home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x355)))))
(assert
 (let (($x316 (not (net.get @V0 @V1))))
 (let (($x412 (= @V1 real_owner)))
 (let (($x298 (= @V1 home)))
 (or $x298 $x412 $x316)))))
(assert
 (let (($x369 (not (net.getX @X @Y))))
 (let (($x404 (= @Y real_owner)))
 (let (($x323 (= @Y home)))
 (or $x323 $x404 $x369)))))
(assert
 (let (($x361 (not (net.getX @X @Z))))
 (let (($x407 (= @Z real_owner)))
 (let (($x406 (= @Z home)))
 (or $x406 $x407 $x361)))))
(assert
 (let (($x382 (not (net.getX home @Y))))
 (let (($x404 (= @Y real_owner)))
 (let (($x323 (= @Y home)))
 (or $x323 $x404 $x382)))))
(assert
 (let (($x340 (not (net.getX @X home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x340)))))
(assert
 (let (($x329 (not (net.getX @V1 @V0))))
 (let (($x427 (= @V0 real_owner)))
 (let (($x426 (= @V0 home)))
 (or $x426 $x427 $x329)))))
(assert
 (let (($x309 (not (net.getX @V0 @V1))))
 (let (($x412 (= @V1 real_owner)))
 (let (($x298 (= @V1 home)))
 (or $x298 $x412 $x309)))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let (($x323 (= @Y home)))
 (or $x323 $x364 dir.dirty))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let (($x406 (= @Z home)))
 (or $x406 $x379 dir.dirty))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let (($x409 (= home home)))
 (or $x409 $x350 dir.dirty))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x312 dir.dirty))))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (let (($x323 (= @Y home)))
 (or $x323 $x358 dir.head))))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (let (($x406 (= @Z home)))
 (or $x406 $x373 dir.head))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x409 (= home home)))
 (or $x409 $x335 dir.head))))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x306 dir.head))))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (let (($x323 (= @Y home)))
 (or $x323 $x358 dir.dirty))))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (let (($x406 (= @Z home)))
 (or $x406 $x373 dir.dirty))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x409 (= home home)))
 (or $x409 $x335 dir.dirty))))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x306 dir.dirty))))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (let (($x323 (= @Y home)))
 (or $x323 $x358))))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (let (($x406 (= @Z home)))
 (or $x406 $x373))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x409 (= home home)))
 (or $x409 $x335))))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x306))))
(assert
 (let (($x376 (not (net.get @X @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x376 dir.head))))
(assert
 (let (($x366 (not (net.get @X @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x366 dir.head))))
(assert
 (let (($x355 (not (net.get @X home))))
 (let (($x409 (= home home)))
 (or $x409 $x355 dir.head))))
(assert
 (let (($x316 (not (net.get @V0 @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x316 dir.head))))
(assert
 (let (($x376 (not (net.get @X @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x376 dir.dirty))))
(assert
 (let (($x366 (not (net.get @X @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x366 dir.dirty))))
(assert
 (let (($x355 (not (net.get @X home))))
 (let (($x409 (= home home)))
 (or $x409 $x355 dir.dirty))))
(assert
 (let (($x316 (not (net.get @V0 @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x316 dir.dirty))))
(assert
 (let (($x369 (not (net.getX @X @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x369 dir.head))))
(assert
 (let (($x361 (not (net.getX @X @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x361 dir.head))))
(assert
 (let (($x382 (not (net.getX home @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x382 dir.head))))
(assert
 (let (($x340 (not (net.getX @X home))))
 (let (($x409 (= home home)))
 (or $x409 $x340 dir.head))))
(assert
 (let (($x329 (not (net.getX @V1 @V0))))
 (let (($x426 (= @V0 home)))
 (or $x426 $x329 dir.head))))
(assert
 (let (($x309 (not (net.getX @V0 @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x309 dir.head))))
(assert
 (let (($x369 (not (net.getX @X @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x369 dir.dirty))))
(assert
 (let (($x361 (not (net.getX @X @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x361 dir.dirty))))
(assert
 (let (($x382 (not (net.getX home @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x382 dir.dirty))))
(assert
 (let (($x340 (not (net.getX @X home))))
 (let (($x409 (= home home)))
 (or $x409 $x340 dir.dirty))))
(assert
 (let (($x329 (not (net.getX @V1 @V0))))
 (let (($x426 (= @V0 home)))
 (or $x426 $x329 dir.dirty))))
(assert
 (let (($x309 (not (net.getX @V0 @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x309 dir.dirty))))
(assert
 (let (($x369 (not (net.getX @X @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x369))))
(assert
 (let (($x361 (not (net.getX @X @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x361))))
(assert
 (let (($x382 (not (net.getX home @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x382))))
(assert
 (let (($x340 (not (net.getX @X home))))
 (let (($x409 (= home home)))
 (or $x409 $x340))))
(assert
 (let (($x329 (not (net.getX @V1 @V0))))
 (let (($x426 (= @V0 home)))
 (or $x426 $x329))))
(assert
 (let (($x309 (not (net.getX @V0 @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x309))))
(assert
 (let (($x369 (not (net.getX @X @Y))))
 (let (($x323 (= @Y home)))
 (let (($x472 (= @X requester)))
 (or $x472 $x323 $x369)))))
(assert
 (let (($x361 (not (net.getX @X @Z))))
 (let (($x406 (= @Z home)))
 (let (($x472 (= @X requester)))
 (or $x472 $x406 $x361)))))
(assert
 (let (($x382 (not (net.getX home @Y))))
 (let (($x323 (= @Y home)))
 (let (($x475 (= home requester)))
 (or $x475 $x323 $x382)))))
(assert
 (let (($x340 (not (net.getX @X home))))
 (let (($x409 (= home home)))
 (let (($x472 (= @X requester)))
 (or $x472 $x409 $x340)))))
(assert
 (let (($x329 (not (net.getX @V1 @V0))))
 (let (($x426 (= @V0 home)))
 (let (($x478 (= @V1 requester)))
 (or $x478 $x426 $x329)))))
(assert
 (let (($x309 (not (net.getX @V0 @V1))))
 (let (($x298 (= @V1 home)))
 (let (($x480 (= @V0 requester)))
 (or $x480 $x298 $x309)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x301 (not (net.fack @V0 @V1))))
 (let (($x427 (= @V0 real_owner)))
 (or $x427 $x301))))
(assert
 (let (($x344 (not (= (cache.state_ @X) exclusive))))
 (let (($x485 (= @X real_owner)))
 (or $x485 $x344))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) exclusive))))
 (let (($x427 (= @V0 real_owner)))
 (or $x427 $x488))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x490 (= @X dir.hptr)))
 (or $x490 $x335))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x492 (= @V0 dir.hptr)))
 (or $x492 $x494))))
(assert
 (let (($x344 (not (= (cache.state_ @X) exclusive))))
 (let (($x490 (= @X dir.hptr)))
 (or $x490 $x344))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) exclusive))))
 (let (($x492 (= @V0 dir.hptr)))
 (or $x492 $x488))))
(assert
 (let (($x499 (not (= (cache.state_ @X) shared))))
 (let (($x485 (= @X real_owner)))
 (or $x485 $x499))))
(assert
 (let (($x502 (not (= (cache.state_ @V0) shared))))
 (let (($x427 (= @V0 real_owner)))
 (or $x427 $x502))))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (let (($x323 (= @Y home)))
 (or $x323 $x358))))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (let (($x406 (= @Z home)))
 (or $x406 $x373))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x409 (= home home)))
 (or $x409 $x335))))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x306))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x409 (= home home)))
 (or $x409 $x494))))
(assert
 (let (($x499 (not (= (cache.state_ @X) shared))))
 (let (($x348 (not (rp_net @X))))
 (or $x348 $x499))))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (let (($x506 (= real_owner @X)))
 (or $x506 $x358))))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (let (($x506 (= real_owner @X)))
 (or $x506 $x373))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x506 (= real_owner @X)))
 (or $x506 $x335))))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (let (($x510 (= real_owner @V0)))
 (or $x510 $x306))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x510 (= real_owner @V0)))
 (or $x510 $x494))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (or $x364 dir.head)))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (or $x379 dir.head)))
(assert
 (let (($x350 (not (net.put home @X))))
 (or $x350 dir.head)))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (or $x312 dir.head)))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (or $x358 dir.head)))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (or $x373 dir.head)))
(assert
 (let (($x335 (not (net.putX home @X))))
 (or $x335 dir.head)))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (or $x306 dir.head)))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (or $x494 dir.head)))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (or $x358 dir.dirty)))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (or $x373 dir.dirty)))
(assert
 (let (($x335 (not (net.putX home @X))))
 (or $x335 dir.dirty)))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (or $x306 dir.dirty)))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (or $x494 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x335 (not (net.putX home @X))))
 (or $x335 dir.head)))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (or $x494 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x348 (not (rp_net @X))))
 (let (($x364 (not (net.put @Y @X))))
 (or $x364 $x348))))
(assert
 (let (($x348 (not (rp_net @X))))
 (let (($x379 (not (net.put @Z @X))))
 (or $x379 $x348))))
(assert
 (let (($x348 (not (rp_net @X))))
 (let (($x350 (not (net.put home @X))))
 (or $x350 $x348))))
(assert
 (let (($x536 (not (rp_net @V0))))
 (let (($x312 (not (net.put @V1 @V0))))
 (or $x312 $x536))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x271 (__invack src)))
 (let (($x552 (not $x271)))
 (or $x552 (not (invnet src))))))
(assert
 (let (($x558 (not (= (cache.state_ src) shared))))
 (let (($x271 (__invack src)))
 (let (($x552 (not $x271)))
 (or $x552 $x558)))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x364 __dir.pending))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x379 __dir.pending))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x350 __dir.pending))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x312 __dir.pending))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x539 __dir.pending))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x541 __dir.pending))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x543 __dir.pending))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x364 dir.dirty))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x379 dir.dirty))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x350 dir.dirty))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x312 dir.dirty))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x539 dir.dirty))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x541 dir.dirty))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x543 dir.dirty))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x364))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x379))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x350))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x312))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x539))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x541))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x543))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x584))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x335))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x494))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x589))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x350))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x539))))
(assert
 (let (($x593 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x591 (not $x58)))
 (or $x591 $x593)))))
(assert
 (let (($x355 (not (net.get @X home))))
 (let (($x560 (dir.shlist @X)))
 (let (($x595 (not $x560)))
 (or $x595 $x355)))))
(assert
 (let (($x599 (not (net.get @V0 home))))
 (let (($x564 (dir.shlist @V0)))
 (let (($x597 (not $x564)))
 (or $x597 $x599)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x591 (not $x58)))
 (or $x591 dir.head))))
(assert
 (let (($x560 (dir.shlist @X)))
 (let (($x595 (not $x560)))
 (or $x595 dir.head))))
(assert
 (let (($x564 (dir.shlist @V0)))
 (let (($x597 (not $x564)))
 (or $x597 dir.head))))
(assert
 (let (($x344 (not (= (cache.state_ @X) exclusive))))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x344))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) exclusive))))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x488))))
(assert
 (let (($x608 (not (= (cache.state_ src) exclusive))))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x608))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let (($x610 (= @X home)))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x610 $x364)))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let (($x610 (= @X home)))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x610 $x379)))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let (($x610 (= @X home)))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x610 $x350)))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let (($x426 (= @V0 home)))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x426 $x312)))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let (($x426 (= @V0 home)))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x426 $x539)))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let (($x610 (= @X home)))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x610 $x541)))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let (($x426 (= @V0 home)))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x426 $x543)))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let (($x618 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x618 $x589)))))
(assert
 (let (($x344 (not (= (cache.state_ @X) exclusive))))
 (let (($x472 (= @X requester)))
 (let (($x560 (dir.shlist @X)))
 (or $x560 $x472 $x344)))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) exclusive))))
 (let (($x480 (= @V0 requester)))
 (let (($x564 (dir.shlist @V0)))
 (or $x564 $x480 $x488)))))
(assert
 (let (($x608 (not (= (cache.state_ src) exclusive))))
 (let (($x622 (= src requester)))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x622 $x608)))))
(assert
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (let (($x485 (= @X real_owner)))
 (let (($x624 (__dir.real @X)))
 (or $x624 $x485 $x625))))))
(assert
 (let ((?x318 (cache.state_ @V0)))
 (let (($x319 (= ?x318 invalid)))
 (let (($x427 (= @V0 real_owner)))
 (let (($x627 (__dir.real @V0)))
 (or $x627 $x427 $x319))))))
(assert
 (let ((?x556 (cache.state_ src)))
 (let (($x631 (= ?x556 invalid)))
 (let (($x630 (= src real_owner)))
 (let (($x629 (__dir.real src)))
 (or $x629 $x630 $x631))))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x335))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x494))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x584))))
(assert
 (let (($x499 (not (= (cache.state_ @X) shared))))
 (or $x499 (not (= (cache.wait @X) get)))))
(assert
 (let (($x502 (not (= (cache.state_ @V0) shared))))
 (or $x502 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x558 (not (= (cache.state_ src) shared))))
 (or $x558 (not (= (cache.wait src) get)))))
(assert
 (let (($x271 (__invack src)))
 (let (($x552 (not $x271)))
 (let ((?x556 (cache.state_ src)))
 (let (($x631 (= ?x556 invalid)))
 (or $x631 $x552))))))
(assert
 (let (($x344 (not (= (cache.state_ @X) exclusive))))
 (or $x344 dir.head)))
(assert
 (let (($x488 (not (= (cache.state_ @V0) exclusive))))
 (or $x488 dir.head)))
(assert
 (let (($x608 (not (= (cache.state_ src) exclusive))))
 (or $x608 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x409 (= home home)))
 (or $x409 $x187))))
(assert
 (let (($x301 (not (net.fack @V0 @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x301))))
(assert
 (let (($x358 (not (net.putX @Y @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x358)))))
(assert
 (let (($x373 (not (net.putX @Z @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x373)))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x335)))))
(assert
 (let (($x306 (not (net.putX @V1 @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x304 (= ?x303 getX)))
 (or $x304 $x306)))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x304 (= ?x303 getX)))
 (or $x304 $x494)))))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x530)))))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x304 (= ?x303 getX)))
 (or $x304 $x532)))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x655 (= ?x654 getX)))
 (or $x655 $x584)))))
(assert
 (let (($x369 (not (net.getX @X @Y))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x369)))))
(assert
 (let (($x361 (not (net.getX @X @Z))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x361)))))
(assert
 (let (($x382 (not (net.getX home @Y))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x382)))))
(assert
 (let (($x340 (not (net.getX @X home))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x340)))))
(assert
 (let (($x329 (not (net.getX @V1 @V0))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x662 (= ?x330 getX)))
 (or $x662 $x329)))))
(assert
 (let (($x309 (not (net.getX @V0 @V1))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x304 (= ?x303 getX)))
 (or $x304 $x309)))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x364)))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x379)))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x350)))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x313 (= ?x303 get)))
 (or $x313 $x312)))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x313 (= ?x303 get)))
 (or $x313 $x539)))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x541)))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x313 (= ?x303 get)))
 (or $x313 $x543)))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x669 (= ?x654 get)))
 (or $x669 $x589)))))
(assert
 (let (($x376 (not (net.get @X @Y))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x376)))))
(assert
 (let (($x366 (not (net.get @X @Z))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x366)))))
(assert
 (let (($x355 (not (net.get @X home))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x355)))))
(assert
 (let (($x316 (not (net.get @V0 @V1))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x313 (= ?x303 get)))
 (or $x313 $x316)))))
(assert
 (let (($x545 (not (net.get home @Y))))
 (let ((?x659 (cache.wait home)))
 (let (($x673 (= ?x659 get)))
 (or $x673 $x545)))))
(assert
 (let (($x547 (not (net.get home @Z))))
 (let ((?x659 (cache.wait home)))
 (let (($x673 (= ?x659 get)))
 (or $x673 $x547)))))
(assert
 (let (($x549 (not (net.get home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x673 (= ?x659 get)))
 (or $x673 $x549)))))
(assert
 (let (($x551 (not (net.get home @V1))))
 (let ((?x659 (cache.wait home)))
 (let (($x673 (= ?x659 get)))
 (or $x673 $x551)))))
(assert
 (let (($x364 (not (net.put @Y @X))))
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (or $x625 $x364)))))
(assert
 (let (($x379 (not (net.put @Z @X))))
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (or $x625 $x379)))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (or $x625 $x350)))))
(assert
 (let (($x312 (not (net.put @V1 @V0))))
 (let ((?x318 (cache.state_ @V0)))
 (let (($x319 (= ?x318 invalid)))
 (or $x319 $x312)))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let ((?x318 (cache.state_ @V0)))
 (let (($x319 (= ?x318 invalid)))
 (or $x319 $x539)))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (or $x625 $x541)))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let ((?x318 (cache.state_ @V0)))
 (let (($x319 (= ?x318 invalid)))
 (or $x319 $x543)))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let ((?x684 (cache.state_ dir.hptr)))
 (let (($x685 (= ?x684 invalid)))
 (or $x685 $x589)))))
(assert
 (let (($x376 (not (net.get @X @Y))))
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (or $x625 $x376)))))
(assert
 (let (($x366 (not (net.get @X @Z))))
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (or $x625 $x366)))))
(assert
 (let (($x355 (not (net.get @X home))))
 (let ((?x342 (cache.state_ @X)))
 (let (($x625 (= ?x342 invalid)))
 (or $x625 $x355)))))
(assert
 (let (($x316 (not (net.get @V0 @V1))))
 (let ((?x318 (cache.state_ @V0)))
 (let (($x319 (= ?x318 invalid)))
 (or $x319 $x316)))))
(assert
 (let (($x545 (not (net.get home @Y))))
 (let ((?x690 (cache.state_ home)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x545)))))
(assert
 (let (($x547 (not (net.get home @Z))))
 (let ((?x690 (cache.state_ home)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x547)))))
(assert
 (let (($x549 (not (net.get home home))))
 (let ((?x690 (cache.state_ home)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x549)))))
(assert
 (let (($x551 (not (net.get home @V1))))
 (let ((?x690 (cache.state_ home)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x551)))))
(assert
 (let (($x323 (= @Y home)))
 (or $x323 (not (net.shwb @X @Y)))))
(assert
 (let (($x409 (= home home)))
 (or $x409 (not (net.shwb @X home)))))
(assert
 (let (($x698 (not (= (cache.wait @X) none))))
 (let (($x369 (not (net.getX @X @Y))))
 (or $x369 $x698))))
(assert
 (let (($x698 (not (= (cache.wait @X) none))))
 (let (($x361 (not (net.getX @X @Z))))
 (or $x361 $x698))))
(assert
 (let (($x702 (not (= (cache.wait home) none))))
 (let (($x382 (not (net.getX home @Y))))
 (or $x382 $x702))))
(assert
 (let (($x698 (not (= (cache.wait @X) none))))
 (let (($x340 (not (net.getX @X home))))
 (or $x340 $x698))))
(assert
 (let (($x332 (not (= (cache.wait @V1) none))))
 (let (($x329 (not (net.getX @V1 @V0))))
 (or $x329 $x332))))
(assert
 (let (($x706 (not (= (cache.wait @V0) none))))
 (let (($x309 (not (net.getX @V0 @V1))))
 (or $x309 $x706))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x708 (= ?x140 getX)))
 (or $x708 $x710)))))
(assert
 (let (($x335 (not (net.putX home @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x335)))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x662 (= ?x330 getX)))
 (or $x662 $x713)))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x304 (= ?x303 getX)))
 (or $x304 $x494)))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let ((?x640 (cache.wait src)))
 (let (($x715 (= ?x640 getX)))
 (or $x715 $x717)))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x655 (= ?x654 getX)))
 (or $x655 $x584)))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x720)))))
(assert
 (let (($x340 (not (net.getX @X home))))
 (let ((?x336 (cache.wait @X)))
 (let (($x337 (= ?x336 getX)))
 (or $x337 $x340)))))
(assert
 (let (($x723 (not (net.getX home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x723)))))
(assert
 (let (($x726 (not (net.getX @V1 home))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x662 (= ?x330 getX)))
 (or $x662 $x726)))))
(assert
 (let (($x729 (not (net.getX @V0 home))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x304 (= ?x303 getX)))
 (or $x304 $x729)))))
(assert
 (let (($x344 (not (= (cache.state_ @X) exclusive))))
 (or $x344 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x488 (not (= (cache.state_ @V0) exclusive))))
 (or $x488 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x608 (not (= (cache.state_ src) exclusive))))
 (or $x608 (not (= (cache.wait src) getX)))))
(assert
 (let (($x736 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x736 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (or $x740 (not (= (cache.wait home) getX)))))
(assert
 (let (($x348 (not (rp_net @X))))
 (let (($x350 (not (net.put home @X))))
 (or $x350 $x348))))
(assert
 (let (($x536 (not (rp_net @V0))))
 (let (($x539 (not (net.put home @V0))))
 (or $x539 $x536))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x745)))))
(assert
 (let (($x350 (not (net.put home @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x350)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x747 (= ?x330 get)))
 (or $x747 $x749)))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x313 (= ?x303 get)))
 (or $x313 $x539)))))
(assert
 (let (($x752 (not (net.put home src))))
 (let ((?x640 (cache.wait src)))
 (let (($x641 (= ?x640 get)))
 (or $x641 $x752)))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x669 (= ?x654 get)))
 (or $x669 $x589)))))
(assert
 (let (($x755 (not (net.put home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x673 (= ?x659 get)))
 (or $x673 $x755)))))
(assert
 (let (($x758 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x758)))))
(assert
 (let (($x355 (not (net.get @X home))))
 (let ((?x336 (cache.wait @X)))
 (let (($x352 (= ?x336 get)))
 (or $x352 $x355)))))
(assert
 (let (($x761 (not (net.get @V1 home))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x747 (= ?x330 get)))
 (or $x747 $x761)))))
(assert
 (let (($x599 (not (net.get @V0 home))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x313 (= ?x303 get)))
 (or $x313 $x599)))))
(assert
 (let (($x765 (not (net.get src home))))
 (let ((?x640 (cache.wait src)))
 (let (($x641 (= ?x640 get)))
 (or $x641 $x765)))))
(assert
 (let (($x593 (not (net.get dir.hptr home))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x669 (= ?x654 get)))
 (or $x669 $x593)))))
(assert
 (let (($x549 (not (net.get home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x673 (= ?x659 get)))
 (or $x673 $x549)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (or (not (__dir.real @X)) (= @X src)))
(assert
 (or (not (__dir.real @V0)) (= @V0 src)))
(assert
 (or (not (__dir.real src)) (= src src)))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x539)))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x541)))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x543)))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x589)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x749)))))
(assert
 (let (($x752 (not (net.put home src))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x752)))))
(assert
 (let (($x755 (not (net.put home home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x755)))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x494)))))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (let (($x793 (= real_owner real_owner)))
 (let (($x792 (= real_owner home)))
 (or $x792 $x793 $x530)))))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (let (($x793 (= real_owner real_owner)))
 (let (($x792 (= real_owner home)))
 (or $x792 $x793 $x532)))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x584)))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x710)))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x713)))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x717)))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x720)))))
(assert
 (let (($x545 (not (net.get home @Y))))
 (let (($x404 (= @Y real_owner)))
 (let (($x323 (= @Y home)))
 (or $x323 $x404 $x545)))))
(assert
 (let (($x547 (not (net.get home @Z))))
 (let (($x407 (= @Z real_owner)))
 (let (($x406 (= @Z home)))
 (or $x406 $x407 $x547)))))
(assert
 (let (($x549 (not (net.get home home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x549)))))
(assert
 (let (($x551 (not (net.get home @V1))))
 (let (($x412 (= @V1 real_owner)))
 (let (($x298 (= @V1 home)))
 (or $x298 $x412 $x551)))))
(assert
 (let (($x593 (not (net.get dir.hptr home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x593)))))
(assert
 (let (($x599 (not (net.get @V0 home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x599)))))
(assert
 (let (($x758 (not (net.get real_owner home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x758)))))
(assert
 (let (($x761 (not (net.get @V1 home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x761)))))
(assert
 (let (($x723 (not (net.getX home home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x723)))))
(assert
 (let (($x726 (not (net.getX @V1 home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x726)))))
(assert
 (let (($x729 (not (net.getX @V0 home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x729)))))
(assert
 (let (($x769 (not (net.getX home @Z))))
 (let (($x407 (= @Z real_owner)))
 (let (($x406 (= @Z home)))
 (or $x406 $x407 $x769)))))
(assert
 (let (($x771 (not (net.getX home @V0))))
 (let (($x427 (= @V0 real_owner)))
 (let (($x426 (= @V0 home)))
 (or $x426 $x427 $x771)))))
(assert
 (let (($x773 (not (net.getX home @V1))))
 (let (($x412 (= @V1 real_owner)))
 (let (($x298 (= @V1 home)))
 (or $x298 $x412 $x773)))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (let (($x409 (= home home)))
 (or $x409 $x539 dir.dirty))))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x541 dir.dirty))))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x543 dir.dirty))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let (($x409 (= home home)))
 (or $x409 $x589 dir.dirty))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x409 (= home home)))
 (or $x409 $x745 dir.dirty))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x409 (= home home)))
 (or $x409 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.put home src))))
 (let (($x409 (= home home)))
 (or $x409 $x752 dir.dirty))))
(assert
 (let (($x755 (not (net.put home home))))
 (let (($x409 (= home home)))
 (or $x409 $x755 dir.dirty))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x409 (= home home)))
 (or $x409 $x494 dir.head))))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x530 dir.head))))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x532 dir.head))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x409 (= home home)))
 (or $x409 $x584 dir.head))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x409 (= home home)))
 (or $x409 $x710 dir.head))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x409 (= home home)))
 (or $x409 $x713 dir.head))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x409 (= home home)))
 (or $x409 $x717 dir.head))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x409 (= home home)))
 (or $x409 $x720 dir.head))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x409 (= home home)))
 (or $x409 $x494 dir.dirty))))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x530 dir.dirty))))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x532 dir.dirty))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x409 (= home home)))
 (or $x409 $x584 dir.dirty))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x409 (= home home)))
 (or $x409 $x710 dir.dirty))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x409 (= home home)))
 (or $x409 $x713 dir.dirty))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x409 (= home home)))
 (or $x409 $x717 dir.dirty))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x409 (= home home)))
 (or $x409 $x720 dir.dirty))))
(assert
 (let (($x494 (not (net.putX home @V0))))
 (let (($x409 (= home home)))
 (or $x409 $x494))))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x530))))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x532))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x409 (= home home)))
 (or $x409 $x584))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x409 (= home home)))
 (or $x409 $x710))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x409 (= home home)))
 (or $x409 $x713))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x409 (= home home)))
 (or $x409 $x717))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x409 (= home home)))
 (or $x409 $x720))))
(assert
 (let (($x545 (not (net.get home @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x545 dir.head))))
(assert
 (let (($x547 (not (net.get home @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x547 dir.head))))
(assert
 (let (($x549 (not (net.get home home))))
 (let (($x409 (= home home)))
 (or $x409 $x549 dir.head))))
(assert
 (let (($x551 (not (net.get home @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x551 dir.head))))
(assert
 (let (($x593 (not (net.get dir.hptr home))))
 (let (($x409 (= home home)))
 (or $x409 $x593 dir.head))))
(assert
 (let (($x599 (not (net.get @V0 home))))
 (let (($x409 (= home home)))
 (or $x409 $x599 dir.head))))
(assert
 (let (($x758 (not (net.get real_owner home))))
 (let (($x409 (= home home)))
 (or $x409 $x758 dir.head))))
(assert
 (let (($x761 (not (net.get @V1 home))))
 (let (($x409 (= home home)))
 (or $x409 $x761 dir.head))))
(assert
 (let (($x545 (not (net.get home @Y))))
 (let (($x323 (= @Y home)))
 (or $x323 $x545 dir.dirty))))
(assert
 (let (($x547 (not (net.get home @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x547 dir.dirty))))
(assert
 (let (($x549 (not (net.get home home))))
 (let (($x409 (= home home)))
 (or $x409 $x549 dir.dirty))))
(assert
 (let (($x551 (not (net.get home @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x551 dir.dirty))))
(assert
 (let (($x593 (not (net.get dir.hptr home))))
 (let (($x409 (= home home)))
 (or $x409 $x593 dir.dirty))))
(assert
 (let (($x599 (not (net.get @V0 home))))
 (let (($x409 (= home home)))
 (or $x409 $x599 dir.dirty))))
(assert
 (let (($x758 (not (net.get real_owner home))))
 (let (($x409 (= home home)))
 (or $x409 $x758 dir.dirty))))
(assert
 (let (($x761 (not (net.get @V1 home))))
 (let (($x409 (= home home)))
 (or $x409 $x761 dir.dirty))))
(assert
 (let (($x723 (not (net.getX home home))))
 (let (($x409 (= home home)))
 (or $x409 $x723 dir.head))))
(assert
 (let (($x726 (not (net.getX @V1 home))))
 (let (($x409 (= home home)))
 (or $x409 $x726 dir.head))))
(assert
 (let (($x729 (not (net.getX @V0 home))))
 (let (($x409 (= home home)))
 (or $x409 $x729 dir.head))))
(assert
 (let (($x769 (not (net.getX home @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x769 dir.head))))
(assert
 (let (($x771 (not (net.getX home @V0))))
 (let (($x426 (= @V0 home)))
 (or $x426 $x771 dir.head))))
(assert
 (let (($x773 (not (net.getX home @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x773 dir.head))))
(assert
 (let (($x723 (not (net.getX home home))))
 (let (($x409 (= home home)))
 (or $x409 $x723 dir.dirty))))
(assert
 (let (($x726 (not (net.getX @V1 home))))
 (let (($x409 (= home home)))
 (or $x409 $x726 dir.dirty))))
(assert
 (let (($x729 (not (net.getX @V0 home))))
 (let (($x409 (= home home)))
 (or $x409 $x729 dir.dirty))))
(assert
 (let (($x769 (not (net.getX home @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x769 dir.dirty))))
(assert
 (let (($x771 (not (net.getX home @V0))))
 (let (($x426 (= @V0 home)))
 (or $x426 $x771 dir.dirty))))
(assert
 (let (($x773 (not (net.getX home @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x773 dir.dirty))))
(assert
 (let (($x723 (not (net.getX home home))))
 (let (($x409 (= home home)))
 (or $x409 $x723))))
(assert
 (let (($x726 (not (net.getX @V1 home))))
 (let (($x409 (= home home)))
 (or $x409 $x726))))
(assert
 (let (($x729 (not (net.getX @V0 home))))
 (let (($x409 (= home home)))
 (or $x409 $x729))))
(assert
 (let (($x769 (not (net.getX home @Z))))
 (let (($x406 (= @Z home)))
 (or $x406 $x769))))
(assert
 (let (($x771 (not (net.getX home @V0))))
 (let (($x426 (= @V0 home)))
 (or $x426 $x771))))
(assert
 (let (($x773 (not (net.getX home @V1))))
 (let (($x298 (= @V1 home)))
 (or $x298 $x773))))
(assert
 (let (($x723 (not (net.getX home home))))
 (let (($x409 (= home home)))
 (let (($x475 (= home requester)))
 (or $x475 $x409 $x723)))))
(assert
 (let (($x726 (not (net.getX @V1 home))))
 (let (($x409 (= home home)))
 (let (($x478 (= @V1 requester)))
 (or $x478 $x409 $x726)))))
(assert
 (let (($x729 (not (net.getX @V0 home))))
 (let (($x409 (= home home)))
 (let (($x480 (= @V0 requester)))
 (or $x480 $x409 $x729)))))
(assert
 (let (($x769 (not (net.getX home @Z))))
 (let (($x406 (= @Z home)))
 (let (($x475 (= home requester)))
 (or $x475 $x406 $x769)))))
(assert
 (let (($x771 (not (net.getX home @V0))))
 (let (($x426 (= @V0 home)))
 (let (($x475 (= home requester)))
 (or $x475 $x426 $x771)))))
(assert
 (let (($x773 (not (net.getX home @V1))))
 (let (($x298 (= @V1 home)))
 (let (($x475 (= home requester)))
 (or $x475 $x298 $x773)))))
(assert
 (let (($x608 (not (= (cache.state_ src) exclusive))))
 (let (($x630 (= src real_owner)))
 (or $x630 $x608))))
(assert
 (let (($x736 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x736))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x410 (= home real_owner)))
 (or $x410 $x740))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x889 (= dir.hptr dir.hptr)))
 (or $x889 $x584))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x891 (= real_owner dir.hptr)))
 (or $x891 $x710))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x893 (= @V1 dir.hptr)))
 (or $x893 $x713))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x895 (= src dir.hptr)))
 (or $x895 $x717))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x897 (= home dir.hptr)))
 (or $x897 $x720))))
(assert
 (let (($x608 (not (= (cache.state_ src) exclusive))))
 (let (($x895 (= src dir.hptr)))
 (or $x895 $x608))))
(assert
 (let (($x736 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x889 (= dir.hptr dir.hptr)))
 (or $x889 $x736))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x897 (= home dir.hptr)))
 (or $x897 $x740))))
(assert
 (let (($x558 (not (= (cache.state_ src) shared))))
 (let (($x630 (= src real_owner)))
 (or $x630 $x558))))
(assert
 (let (($x904 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x904))))
(assert
 (let (($x907 (not (= (cache.state_ home) shared))))
 (let (($x410 (= home real_owner)))
 (or $x410 $x907))))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x530))))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x532))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x409 (= home home)))
 (or $x409 $x584))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x409 (= home home)))
 (or $x409 $x710))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x409 (= home home)))
 (or $x409 $x713))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x409 (= home home)))
 (or $x409 $x717))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x409 (= home home)))
 (or $x409 $x720))))
(assert
 (let (($x502 (not (= (cache.state_ @V0) shared))))
 (let (($x536 (not (rp_net @V0))))
 (or $x536 $x502))))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (let (($x506 (= real_owner @X)))
 (or $x506 $x530))))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (let (($x510 (= real_owner @V0)))
 (or $x510 $x532))))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (let (($x891 (= real_owner dir.hptr)))
 (or $x891 $x584))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x793 (= real_owner real_owner)))
 (or $x793 $x710))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x713)))
(assert
 (let (($x717 (not (net.putX home src))))
 (or (= real_owner src) $x717)))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x720))))
(assert
 (let (($x539 (not (net.put home @V0))))
 (or $x539 dir.head)))
(assert
 (let (($x541 (not (net.put dir.hptr @X))))
 (or $x541 dir.head)))
(assert
 (let (($x543 (not (net.put dir.hptr @V0))))
 (or $x543 dir.head)))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (or $x589 dir.head)))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (or $x745 dir.head)))
(assert
 (let (($x749 (not (net.put home @V1))))
 (or $x749 dir.head)))
(assert
 (let (($x752 (not (net.put home src))))
 (or $x752 dir.head)))
(assert
 (let (($x755 (not (net.put home home))))
 (or $x755 dir.head)))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (or $x530 dir.head)))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (or $x532 dir.head)))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (or $x584 dir.head)))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (or $x710 dir.head)))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (or $x713 dir.head)))
(assert
 (let (($x717 (not (net.putX home src))))
 (or $x717 dir.head)))
(assert
 (let (($x720 (not (net.putX home home))))
 (or $x720 dir.head)))
(assert
 (let (($x530 (not (net.putX real_owner @X))))
 (or $x530 dir.dirty)))
(assert
 (let (($x532 (not (net.putX real_owner @V0))))
 (or $x532 dir.dirty)))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (or $x584 dir.dirty)))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (or $x710 dir.dirty)))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (or $x713 dir.dirty)))
(assert
 (let (($x717 (not (net.putX home src))))
 (or $x717 dir.dirty)))
(assert
 (let (($x720 (not (net.putX home home))))
 (or $x720 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner src)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x584 (not (net.putX home dir.hptr))))
 (or $x584 dir.head)))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (or $x710 dir.head)))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (or $x713 dir.head)))
(assert
 (let (($x717 (not (net.putX home src))))
 (or $x717 dir.head)))
(assert
 (let (($x720 (not (net.putX home home))))
 (or $x720 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home src)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x536 (not (rp_net @V0))))
 (let (($x539 (not (net.put home @V0))))
 (or $x539 $x536))))
(assert
 (let (($x348 (not (rp_net @X))))
 (let (($x541 (not (net.put dir.hptr @X))))
 (or $x541 $x348))))
(assert
 (let (($x536 (not (rp_net @V0))))
 (let (($x543 (not (net.put dir.hptr @V0))))
 (or $x543 $x536))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (or $x589 (not (rp_net dir.hptr)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (or $x745 (not (rp_net real_owner)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (or $x749 (not (rp_net @V1)))))
(assert
 (let (($x963 (not (rp_net src))))
 (let (($x752 (not (net.put home src))))
 (or $x752 $x963))))
(assert
 (let (($x755 (not (net.put home home))))
 (or $x755 (not (rp_net home)))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home src)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr src)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x589 __dir.pending))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x745 __dir.pending))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x749 __dir.pending))))
(assert
 (let (($x752 (not (net.put home src))))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x752 __dir.pending))))
(assert
 (let (($x755 (not (net.put home home))))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x755 __dir.pending))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x969 __dir.pending))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x971 __dir.pending))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x973 __dir.pending))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x589 dir.dirty))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x745 dir.dirty))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.put home src))))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x752 dir.dirty))))
(assert
 (let (($x755 (not (net.put home home))))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x755 dir.dirty))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x969 dir.dirty))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x971 dir.dirty))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x973 dir.dirty))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x589))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x745))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x749))))
(assert
 (let (($x752 (not (net.put home src))))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x752))))
(assert
 (let (($x755 (not (net.put home home))))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x755))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x969))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x971))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x973))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x717))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x710))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x713))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x720))))
(assert
 (let (($x752 (not (net.put home src))))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x752))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x745))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x749))))
(assert
 (let (($x755 (not (net.put home home))))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x755))))
(assert
 (let (($x765 (not (net.get src home))))
 (let (($x606 (dir.shlist src)))
 (let (($x1008 (not $x606)))
 (or $x1008 $x765)))))
(assert
 (let (($x758 (not (net.get real_owner home))))
 (let (($x979 (dir.shlist real_owner)))
 (let (($x1010 (not $x979)))
 (or $x1010 $x758)))))
(assert
 (let (($x761 (not (net.get @V1 home))))
 (let (($x981 (dir.shlist @V1)))
 (let (($x1012 (not $x981)))
 (or $x1012 $x761)))))
(assert
 (let (($x549 (not (net.get home home))))
 (let (($x984 (dir.shlist home)))
 (let (($x1014 (not $x984)))
 (or $x1014 $x549)))))
(assert
 (let (($x606 (dir.shlist src)))
 (let (($x1008 (not $x606)))
 (or $x1008 dir.head))))
(assert
 (let (($x979 (dir.shlist real_owner)))
 (let (($x1010 (not $x979)))
 (or $x1010 dir.head))))
(assert
 (let (($x981 (dir.shlist @V1)))
 (let (($x1012 (not $x981)))
 (or $x1012 dir.head))))
(assert
 (let (($x984 (dir.shlist home)))
 (let (($x1014 (not $x984)))
 (or $x1014 dir.head))))
(assert
 (let (($x736 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x736))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x740))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x792 (= real_owner home)))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x792 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x298 (= @V1 home)))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x298 $x749)))))
(assert
 (let (($x752 (not (net.put home src))))
 (let (($x272 (= src home)))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x272 $x752)))))
(assert
 (let (($x755 (not (net.put home home))))
 (let (($x409 (= home home)))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x409 $x755)))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let (($x618 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x618 $x969)))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let (($x792 (= real_owner home)))
 (let (($x979 (dir.shlist real_owner)))
 (or $x979 $x792 $x971)))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let (($x298 (= @V1 home)))
 (let (($x981 (dir.shlist @V1)))
 (or $x981 $x298 $x973)))))
(assert
 (let (($x975 (not (net.put dir.hptr src))))
 (let (($x272 (= src home)))
 (let (($x606 (dir.shlist src)))
 (or $x606 $x272 $x975)))))
(assert
 (let (($x736 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x1030 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1030 $x736)))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x475 (= home requester)))
 (let (($x984 (dir.shlist home)))
 (or $x984 $x475 $x740)))))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x710))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x713))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x717))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x720))))
(assert
 (let (($x904 (not (= (cache.state_ dir.hptr) shared))))
 (or $x904 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x907 (not (= (cache.state_ home) shared))))
 (or $x907 (not (= (cache.wait home) get)))))
(assert
 (let (($x736 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x736 dir.head)))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (or $x740 dir.head)))
(assert
 (let (($x710 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x708 (= ?x140 getX)))
 (or $x708 $x710)))))
(assert
 (let (($x713 (not (net.putX home @V1))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x662 (= ?x330 getX)))
 (or $x662 $x713)))))
(assert
 (let (($x717 (not (net.putX home src))))
 (let ((?x640 (cache.wait src)))
 (let (($x715 (= ?x640 getX)))
 (or $x715 $x717)))))
(assert
 (let (($x720 (not (net.putX home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x720)))))
(assert
 (let (($x942 (not (net.putX real_owner dir.hptr))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x655 (= ?x654 getX)))
 (or $x655 $x942)))))
(assert
 (let (($x944 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x708 (= ?x140 getX)))
 (or $x708 $x944)))))
(assert
 (let (($x946 (not (net.putX real_owner @V1))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x662 (= ?x330 getX)))
 (or $x662 $x946)))))
(assert
 (let (($x948 (not (net.putX real_owner src))))
 (let ((?x640 (cache.wait src)))
 (let (($x715 (= ?x640 getX)))
 (or $x715 $x948)))))
(assert
 (let (($x723 (not (net.getX home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x723)))))
(assert
 (let (($x726 (not (net.getX @V1 home))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x662 (= ?x330 getX)))
 (or $x662 $x726)))))
(assert
 (let (($x729 (not (net.getX @V0 home))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x304 (= ?x303 getX)))
 (or $x304 $x729)))))
(assert
 (let (($x769 (not (net.getX home @Z))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x769)))))
(assert
 (let (($x771 (not (net.getX home @V0))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x771)))))
(assert
 (let (($x773 (not (net.getX home @V1))))
 (let ((?x659 (cache.wait home)))
 (let (($x660 (= ?x659 getX)))
 (or $x660 $x773)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x747 (= ?x330 get)))
 (or $x747 $x749)))))
(assert
 (let (($x752 (not (net.put home src))))
 (let ((?x640 (cache.wait src)))
 (let (($x641 (= ?x640 get)))
 (or $x641 $x752)))))
(assert
 (let (($x755 (not (net.put home home))))
 (let ((?x659 (cache.wait home)))
 (let (($x673 (= ?x659 get)))
 (or $x673 $x755)))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x669 (= ?x654 get)))
 (or $x669 $x969)))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x971)))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x747 (= ?x330 get)))
 (or $x747 $x973)))))
(assert
 (let (($x975 (not (net.put dir.hptr src))))
 (let ((?x640 (cache.wait src)))
 (let (($x641 (= ?x640 get)))
 (or $x641 $x975)))))
(assert
 (let (($x593 (not (net.get dir.hptr home))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x669 (= ?x654 get)))
 (or $x669 $x593)))))
(assert
 (let (($x599 (not (net.get @V0 home))))
 (let ((?x303 (cache.wait @V0)))
 (let (($x313 (= ?x303 get)))
 (or $x313 $x599)))))
(assert
 (let (($x758 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x758)))))
(assert
 (let (($x761 (not (net.get @V1 home))))
 (let ((?x330 (cache.wait @V1)))
 (let (($x747 (= ?x330 get)))
 (or $x747 $x761)))))
(assert
 (let (($x765 (not (net.get src home))))
 (let ((?x640 (cache.wait src)))
 (let (($x641 (= ?x640 get)))
 (or $x641 $x765)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let ((?x1054 (cache.state_ real_owner)))
 (let (($x1055 (= ?x1054 invalid)))
 (or $x1055 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x1057 (cache.state_ @V1)))
 (let (($x1058 (= ?x1057 invalid)))
 (or $x1058 $x749)))))
(assert
 (let (($x752 (not (net.put home src))))
 (let ((?x556 (cache.state_ src)))
 (let (($x631 (= ?x556 invalid)))
 (or $x631 $x752)))))
(assert
 (let (($x755 (not (net.put home home))))
 (let ((?x690 (cache.state_ home)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x755)))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let ((?x684 (cache.state_ dir.hptr)))
 (let (($x685 (= ?x684 invalid)))
 (or $x685 $x969)))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let ((?x1054 (cache.state_ real_owner)))
 (let (($x1055 (= ?x1054 invalid)))
 (or $x1055 $x971)))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let ((?x1057 (cache.state_ @V1)))
 (let (($x1058 (= ?x1057 invalid)))
 (or $x1058 $x973)))))
(assert
 (let (($x975 (not (net.put dir.hptr src))))
 (let ((?x556 (cache.state_ src)))
 (let (($x631 (= ?x556 invalid)))
 (or $x631 $x975)))))
(assert
 (let (($x593 (not (net.get dir.hptr home))))
 (let ((?x684 (cache.state_ dir.hptr)))
 (let (($x685 (= ?x684 invalid)))
 (or $x685 $x593)))))
(assert
 (let (($x599 (not (net.get @V0 home))))
 (let ((?x318 (cache.state_ @V0)))
 (let (($x319 (= ?x318 invalid)))
 (or $x319 $x599)))))
(assert
 (let (($x758 (not (net.get real_owner home))))
 (let ((?x1054 (cache.state_ real_owner)))
 (let (($x1055 (= ?x1054 invalid)))
 (or $x1055 $x758)))))
(assert
 (let (($x761 (not (net.get @V1 home))))
 (let ((?x1057 (cache.state_ @V1)))
 (let (($x1058 (= ?x1057 invalid)))
 (or $x1058 $x761)))))
(assert
 (let (($x765 (not (net.get src home))))
 (let ((?x556 (cache.state_ src)))
 (let (($x631 (= ?x556 invalid)))
 (or $x631 $x765)))))
(assert
 (let (($x702 (not (= (cache.wait home) none))))
 (let (($x723 (not (net.getX home home))))
 (or $x723 $x702))))
(assert
 (let (($x332 (not (= (cache.wait @V1) none))))
 (let (($x726 (not (net.getX @V1 home))))
 (or $x726 $x332))))
(assert
 (let (($x706 (not (= (cache.wait @V0) none))))
 (let (($x729 (not (net.getX @V0 home))))
 (or $x729 $x706))))
(assert
 (let (($x702 (not (= (cache.wait home) none))))
 (let (($x769 (not (net.getX home @Z))))
 (or $x769 $x702))))
(assert
 (let (($x702 (not (= (cache.wait home) none))))
 (let (($x771 (not (net.getX home @V0))))
 (or $x771 $x702))))
(assert
 (let (($x702 (not (= (cache.wait home) none))))
 (let (($x773 (not (net.getX home @V1))))
 (or $x773 $x702))))
(assert
 (let (($x1078 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x708 (= ?x140 getX)))
 (or $x708 $x1078)))))
(assert
 (let (($x1081 (not (net.getX src home))))
 (let ((?x640 (cache.wait src)))
 (let (($x715 (= ?x640 getX)))
 (or $x715 $x1081)))))
(assert
 (let (($x1084 (not (net.getX dir.hptr home))))
 (let ((?x654 (cache.wait dir.hptr)))
 (let (($x655 (= ?x654 getX)))
 (or $x655 $x1084)))))
(assert
 (let (($x1087 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1087 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1091 (not (= (cache.state_ @V1) exclusive))))
 (or $x1091 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x589 (not (net.put home dir.hptr))))
 (or $x589 (not (rp_net dir.hptr)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (or $x745 (not (rp_net real_owner)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (or $x749 (not (rp_net @V1)))))
(assert
 (let (($x963 (not (rp_net src))))
 (let (($x752 (not (net.put home src))))
 (or $x752 $x963))))
(assert
 (let (($x755 (not (net.put home home))))
 (or $x755 (not (rp_net home)))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x969)))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x971)))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x973)))))
(assert
 (let (($x975 (not (net.put dir.hptr src))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x975)))))
(assert
 (let (($x977 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x977)))))
(assert
 (let (($x942 (not (net.putX real_owner dir.hptr))))
 (let (($x793 (= real_owner real_owner)))
 (let (($x792 (= real_owner home)))
 (or $x792 $x793 $x942)))))
(assert
 (let (($x944 (not (net.putX real_owner real_owner))))
 (let (($x793 (= real_owner real_owner)))
 (let (($x792 (= real_owner home)))
 (or $x792 $x793 $x944)))))
(assert
 (let (($x946 (not (net.putX real_owner @V1))))
 (let (($x793 (= real_owner real_owner)))
 (let (($x792 (= real_owner home)))
 (or $x792 $x793 $x946)))))
(assert
 (let (($x948 (not (net.putX real_owner src))))
 (let (($x793 (= real_owner real_owner)))
 (let (($x792 (= real_owner home)))
 (or $x792 $x793 $x948)))))
(assert
 (let (($x950 (not (net.putX real_owner home))))
 (let (($x793 (= real_owner real_owner)))
 (let (($x792 (= real_owner home)))
 (or $x792 $x793 $x950)))))
(assert
 (let (($x765 (not (net.get src home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x765)))))
(assert
 (let (($x1078 (not (net.getX real_owner home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x1078)))))
(assert
 (let (($x1081 (not (net.getX src home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x1081)))))
(assert
 (let (($x1084 (not (net.getX dir.hptr home))))
 (let (($x410 (= home real_owner)))
 (let (($x409 (= home home)))
 (or $x409 $x410 $x1084)))))
(assert
 (let (($x969 (not (net.put dir.hptr dir.hptr))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x969 dir.dirty))))
(assert
 (let (($x971 (not (net.put dir.hptr real_owner))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x971 dir.dirty))))
(assert
 (let (($x973 (not (net.put dir.hptr @V1))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x973 dir.dirty))))
(assert
 (let (($x975 (not (net.put dir.hptr src))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x975 dir.dirty))))
(assert
 (let (($x977 (not (net.put dir.hptr home))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x977 dir.dirty))))
(assert
 (let (($x942 (not (net.putX real_owner dir.hptr))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x942 dir.head))))
(assert
 (let (($x944 (not (net.putX real_owner real_owner))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x944 dir.head))))
(assert
 (let (($x946 (not (net.putX real_owner @V1))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x946 dir.head))))
(assert
 (let (($x948 (not (net.putX real_owner src))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x948 dir.head))))
(assert
 (let (($x950 (not (net.putX real_owner home))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x950 dir.head))))
(assert
 (let (($x942 (not (net.putX real_owner dir.hptr))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x942 dir.dirty))))
(assert
 (let (($x944 (not (net.putX real_owner real_owner))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x944 dir.dirty))))
(assert
 (let (($x946 (not (net.putX real_owner @V1))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x946 dir.dirty))))
(assert
 (let (($x948 (not (net.putX real_owner src))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x948 dir.dirty))))
(assert
 (let (($x950 (not (net.putX real_owner home))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x950 dir.dirty))))
(assert
 (let (($x942 (not (net.putX real_owner dir.hptr))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x942))))
(assert
 (let (($x944 (not (net.putX real_owner real_owner))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x944))))
(assert
 (let (($x946 (not (net.putX real_owner @V1))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x946))))
(assert
 (let (($x948 (not (net.putX real_owner src))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x948))))
(assert
 (let (($x950 (not (net.putX real_owner home))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x950))))
(assert
 (let (($x765 (not (net.get src home))))
 (let (($x409 (= home home)))
 (or $x409 $x765 dir.head))))
(assert
 (let (($x765 (not (net.get src home))))
 (let (($x409 (= home home)))
 (or $x409 $x765 dir.dirty))))
(assert
 (let (($x1078 (not (net.getX real_owner home))))
 (let (($x409 (= home home)))
 (or $x409 $x1078 dir.head))))
(assert
 (let (($x1081 (not (net.getX src home))))
 (let (($x409 (= home home)))
 (or $x409 $x1081 dir.head))))
(assert
 (let (($x1084 (not (net.getX dir.hptr home))))
 (let (($x409 (= home home)))
 (or $x409 $x1084 dir.head))))
(assert
 (let (($x1078 (not (net.getX real_owner home))))
 (let (($x409 (= home home)))
 (or $x409 $x1078 dir.dirty))))
(assert
 (let (($x1081 (not (net.getX src home))))
 (let (($x409 (= home home)))
 (or $x409 $x1081 dir.dirty))))
(assert
 (let (($x1084 (not (net.getX dir.hptr home))))
 (let (($x409 (= home home)))
 (or $x409 $x1084 dir.dirty))))
(assert
 (let (($x1078 (not (net.getX real_owner home))))
 (let (($x409 (= home home)))
 (or $x409 $x1078))))
(assert
 (let (($x1081 (not (net.getX src home))))
 (let (($x409 (= home home)))
 (or $x409 $x1081))))
(assert
 (let (($x1084 (not (net.getX dir.hptr home))))
 (let (($x409 (= home home)))
 (or $x409 $x1084))))
(assert
 (let (($x1078 (not (net.getX real_owner home))))
 (let (($x409 (= home home)))
 (or (= real_owner requester) $x409 $x1078))))
(assert
 (let (($x1081 (not (net.getX src home))))
 (let (($x409 (= home home)))
 (let (($x622 (= src requester)))
 (or $x622 $x409 $x1081)))))
(assert
 (let (($x1084 (not (net.getX dir.hptr home))))
 (let (($x409 (= home home)))
 (let (($x1030 (= dir.hptr requester)))
 (or $x1030 $x409 $x1084)))))
(assert
 (let (($x1087 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x793 (= real_owner real_owner)))
 (or $x793 $x1087))))
(assert
 (let (($x1091 (not (= (cache.state_ @V1) exclusive))))
 (let (($x412 (= @V1 real_owner)))
 (or $x412 $x1091))))
(assert
 (let (($x1087 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x891 (= real_owner dir.hptr)))
 (or $x891 $x1087))))
(assert
 (let (($x1091 (not (= (cache.state_ @V1) exclusive))))
 (let (($x893 (= @V1 dir.hptr)))
 (or $x893 $x1091))))
(assert
 (let (($x793 (= real_owner real_owner)))
 (or $x793 (not (= (cache.state_ real_owner) shared)))))
(assert
 (let (($x412 (= @V1 real_owner)))
 (or $x412 (not (= (cache.state_ @V1) shared)))))
(assert
 (let (($x942 (not (net.putX real_owner dir.hptr))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x942))))
(assert
 (let (($x944 (not (net.putX real_owner real_owner))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x944))))
(assert
 (let (($x946 (not (net.putX real_owner @V1))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x946))))
(assert
 (let (($x948 (not (net.putX real_owner src))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x948))))
(assert
 (let (($x950 (not (net.putX real_owner home))))
 (let (($x792 (= real_owner home)))
 (or $x792 $x950))))
(assert
 (let (($x558 (not (= (cache.state_ src) shared))))
 (let (($x963 (not (rp_net src))))
 (or $x963 $x558))))
(check-sat)
