(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __nakc () Bool)
(declare-fun dir.pending () Bool)
(declare-fun nakc () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) __dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 __nakc)
(assert
 (not dir.pending))
(assert
 (not nakc))
(assert
 (let (($x322 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x360 (not (net.getX home @Y))))
 (let (($x339 (not (net.getX @X @Z))))
 (let (($x347 (not (net.getX @X @Y))))
 (let (($x348 (= @Y @Z)))
 (let (($x361 (and (or $x348 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x348 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x348 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x348 $x347 $x339) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x339 (not (net.putX @Y @X))) $x360 $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x322 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x361)))))))))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let (($x382 (= @Y real_owner)))
 (let (($x301 (= @Y home)))
 (or $x301 $x382 $x342)))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let (($x385 (= @Z real_owner)))
 (let (($x384 (= @Z home)))
 (or $x384 $x385 $x357)))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x328)))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let (($x390 (= @V1 real_owner)))
 (let (($x276 (= @V1 home)))
 (or $x276 $x390 $x290)))))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (let (($x382 (= @Y real_owner)))
 (let (($x301 (= @Y home)))
 (or $x301 $x382 $x336)))))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (let (($x385 (= @Z real_owner)))
 (let (($x384 (= @Z home)))
 (or $x384 $x385 $x351)))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x313)))))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (let (($x390 (= @V1 real_owner)))
 (let (($x276 (= @V1 home)))
 (or $x276 $x390 $x284)))))
(assert
 (let (($x354 (not (net.get @X @Y))))
 (let (($x382 (= @Y real_owner)))
 (let (($x301 (= @Y home)))
 (or $x301 $x382 $x354)))))
(assert
 (let (($x344 (not (net.get @X @Z))))
 (let (($x385 (= @Z real_owner)))
 (let (($x384 (= @Z home)))
 (or $x384 $x385 $x344)))))
(assert
 (let (($x333 (not (net.get @X home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x333)))))
(assert
 (let (($x294 (not (net.get @V0 @V1))))
 (let (($x390 (= @V1 real_owner)))
 (let (($x276 (= @V1 home)))
 (or $x276 $x390 $x294)))))
(assert
 (let (($x347 (not (net.getX @X @Y))))
 (let (($x382 (= @Y real_owner)))
 (let (($x301 (= @Y home)))
 (or $x301 $x382 $x347)))))
(assert
 (let (($x339 (not (net.getX @X @Z))))
 (let (($x385 (= @Z real_owner)))
 (let (($x384 (= @Z home)))
 (or $x384 $x385 $x339)))))
(assert
 (let (($x360 (not (net.getX home @Y))))
 (let (($x382 (= @Y real_owner)))
 (let (($x301 (= @Y home)))
 (or $x301 $x382 $x360)))))
(assert
 (let (($x318 (not (net.getX @X home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x318)))))
(assert
 (let (($x307 (not (net.getX @V1 @V0))))
 (let (($x405 (= @V0 real_owner)))
 (let (($x404 (= @V0 home)))
 (or $x404 $x405 $x307)))))
(assert
 (let (($x287 (not (net.getX @V0 @V1))))
 (let (($x390 (= @V1 real_owner)))
 (let (($x276 (= @V1 home)))
 (or $x276 $x390 $x287)))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let (($x301 (= @Y home)))
 (or $x301 $x342 dir.dirty))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let (($x384 (= @Z home)))
 (or $x384 $x357 dir.dirty))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let (($x387 (= home home)))
 (or $x387 $x328 dir.dirty))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x290 dir.dirty))))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (let (($x301 (= @Y home)))
 (or $x301 $x336 dir.head))))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (let (($x384 (= @Z home)))
 (or $x384 $x351 dir.head))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x387 (= home home)))
 (or $x387 $x313 dir.head))))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x284 dir.head))))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (let (($x301 (= @Y home)))
 (or $x301 $x336 dir.dirty))))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (let (($x384 (= @Z home)))
 (or $x384 $x351 dir.dirty))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x387 (= home home)))
 (or $x387 $x313 dir.dirty))))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x284 dir.dirty))))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (let (($x301 (= @Y home)))
 (or $x301 $x336))))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (let (($x384 (= @Z home)))
 (or $x384 $x351))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x387 (= home home)))
 (or $x387 $x313))))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x284))))
(assert
 (let (($x354 (not (net.get @X @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x354 dir.head))))
(assert
 (let (($x344 (not (net.get @X @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x344 dir.head))))
(assert
 (let (($x333 (not (net.get @X home))))
 (let (($x387 (= home home)))
 (or $x387 $x333 dir.head))))
(assert
 (let (($x294 (not (net.get @V0 @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x294 dir.head))))
(assert
 (let (($x354 (not (net.get @X @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x354 dir.dirty))))
(assert
 (let (($x344 (not (net.get @X @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x344 dir.dirty))))
(assert
 (let (($x333 (not (net.get @X home))))
 (let (($x387 (= home home)))
 (or $x387 $x333 dir.dirty))))
(assert
 (let (($x294 (not (net.get @V0 @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x294 dir.dirty))))
(assert
 (let (($x347 (not (net.getX @X @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x347 dir.head))))
(assert
 (let (($x339 (not (net.getX @X @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x339 dir.head))))
(assert
 (let (($x360 (not (net.getX home @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x360 dir.head))))
(assert
 (let (($x318 (not (net.getX @X home))))
 (let (($x387 (= home home)))
 (or $x387 $x318 dir.head))))
(assert
 (let (($x307 (not (net.getX @V1 @V0))))
 (let (($x404 (= @V0 home)))
 (or $x404 $x307 dir.head))))
(assert
 (let (($x287 (not (net.getX @V0 @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x287 dir.head))))
(assert
 (let (($x347 (not (net.getX @X @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x347 dir.dirty))))
(assert
 (let (($x339 (not (net.getX @X @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x339 dir.dirty))))
(assert
 (let (($x360 (not (net.getX home @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x360 dir.dirty))))
(assert
 (let (($x318 (not (net.getX @X home))))
 (let (($x387 (= home home)))
 (or $x387 $x318 dir.dirty))))
(assert
 (let (($x307 (not (net.getX @V1 @V0))))
 (let (($x404 (= @V0 home)))
 (or $x404 $x307 dir.dirty))))
(assert
 (let (($x287 (not (net.getX @V0 @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x287 dir.dirty))))
(assert
 (let (($x347 (not (net.getX @X @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x347))))
(assert
 (let (($x339 (not (net.getX @X @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x339))))
(assert
 (let (($x360 (not (net.getX home @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x360))))
(assert
 (let (($x318 (not (net.getX @X home))))
 (let (($x387 (= home home)))
 (or $x387 $x318))))
(assert
 (let (($x307 (not (net.getX @V1 @V0))))
 (let (($x404 (= @V0 home)))
 (or $x404 $x307))))
(assert
 (let (($x287 (not (net.getX @V0 @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x287))))
(assert
 (let (($x347 (not (net.getX @X @Y))))
 (let (($x301 (= @Y home)))
 (let (($x450 (= @X requester)))
 (or $x450 $x301 $x347)))))
(assert
 (let (($x339 (not (net.getX @X @Z))))
 (let (($x384 (= @Z home)))
 (let (($x450 (= @X requester)))
 (or $x450 $x384 $x339)))))
(assert
 (let (($x360 (not (net.getX home @Y))))
 (let (($x301 (= @Y home)))
 (let (($x453 (= home requester)))
 (or $x453 $x301 $x360)))))
(assert
 (let (($x318 (not (net.getX @X home))))
 (let (($x387 (= home home)))
 (let (($x450 (= @X requester)))
 (or $x450 $x387 $x318)))))
(assert
 (let (($x307 (not (net.getX @V1 @V0))))
 (let (($x404 (= @V0 home)))
 (let (($x456 (= @V1 requester)))
 (or $x456 $x404 $x307)))))
(assert
 (let (($x287 (not (net.getX @V0 @V1))))
 (let (($x276 (= @V1 home)))
 (let (($x458 (= @V0 requester)))
 (or $x458 $x276 $x287)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x279 (not (net.fack @V0 @V1))))
 (let (($x405 (= @V0 real_owner)))
 (or $x405 $x279))))
(assert
 (let (($x322 (not (= (cache.state_ @X) exclusive))))
 (let (($x463 (= @X real_owner)))
 (or $x463 $x322))))
(assert
 (let (($x466 (not (= (cache.state_ @V0) exclusive))))
 (let (($x405 (= @V0 real_owner)))
 (or $x405 $x466))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x468 (= @X dir.hptr)))
 (or $x468 $x313))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x470 (= @V0 dir.hptr)))
 (or $x470 $x472))))
(assert
 (let (($x322 (not (= (cache.state_ @X) exclusive))))
 (let (($x468 (= @X dir.hptr)))
 (or $x468 $x322))))
(assert
 (let (($x466 (not (= (cache.state_ @V0) exclusive))))
 (let (($x470 (= @V0 dir.hptr)))
 (or $x470 $x466))))
(assert
 (let (($x477 (not (= (cache.state_ @X) shared))))
 (let (($x463 (= @X real_owner)))
 (or $x463 $x477))))
(assert
 (let (($x480 (not (= (cache.state_ @V0) shared))))
 (let (($x405 (= @V0 real_owner)))
 (or $x405 $x480))))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (let (($x301 (= @Y home)))
 (or $x301 $x336))))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (let (($x384 (= @Z home)))
 (or $x384 $x351))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x387 (= home home)))
 (or $x387 $x313))))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x284))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x387 (= home home)))
 (or $x387 $x472))))
(assert
 (let (($x477 (not (= (cache.state_ @X) shared))))
 (let (($x326 (not (rp_net @X))))
 (or $x326 $x477))))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (let (($x484 (= real_owner @X)))
 (or $x484 $x336))))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (let (($x484 (= real_owner @X)))
 (or $x484 $x351))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x484 (= real_owner @X)))
 (or $x484 $x313))))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (let (($x488 (= real_owner @V0)))
 (or $x488 $x284))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x488 (= real_owner @V0)))
 (or $x488 $x472))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (or $x342 dir.head)))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (or $x357 dir.head)))
(assert
 (let (($x328 (not (net.put home @X))))
 (or $x328 dir.head)))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (or $x290 dir.head)))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (or $x336 dir.head)))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (or $x351 dir.head)))
(assert
 (let (($x313 (not (net.putX home @X))))
 (or $x313 dir.head)))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (or $x284 dir.head)))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (or $x472 dir.head)))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (or $x336 dir.dirty)))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (or $x351 dir.dirty)))
(assert
 (let (($x313 (not (net.putX home @X))))
 (or $x313 dir.dirty)))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (or $x284 dir.dirty)))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (or $x472 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x313 (not (net.putX home @X))))
 (or $x313 dir.head)))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (or $x472 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x326 (not (rp_net @X))))
 (let (($x342 (not (net.put @Y @X))))
 (or $x342 $x326))))
(assert
 (let (($x326 (not (rp_net @X))))
 (let (($x357 (not (net.put @Z @X))))
 (or $x357 $x326))))
(assert
 (let (($x326 (not (rp_net @X))))
 (let (($x328 (not (net.put home @X))))
 (or $x328 $x326))))
(assert
 (let (($x514 (not (rp_net @V0))))
 (let (($x290 (not (net.put @V1 @V0))))
 (or $x290 $x514))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x477 (not (= (cache.state_ @X) shared))))
 (let (($x531 (not (invack @X))))
 (or $x531 $x477))))
(assert
 (let (($x480 (not (= (cache.state_ @V0) shared))))
 (let (($x534 (not (invack @V0))))
 (or $x534 $x480))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x342 __dir.pending))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x357 __dir.pending))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x328 __dir.pending))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x290 __dir.pending))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x517 __dir.pending))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x519 __dir.pending))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x521 __dir.pending))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x342 dir.dirty))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x357 dir.dirty))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x328 dir.dirty))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x290 dir.dirty))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x517 dir.dirty))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x519 dir.dirty))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x521 dir.dirty))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x342))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x357))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x328))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x290))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x517))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x519))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x521))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x560))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x313))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x472))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x565))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x328))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x517))))
(assert
 (let (($x569 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x567 (not $x58)))
 (or $x567 $x569)))))
(assert
 (let (($x333 (not (net.get @X home))))
 (let (($x536 (dir.shlist @X)))
 (let (($x571 (not $x536)))
 (or $x571 $x333)))))
(assert
 (let (($x575 (not (net.get @V0 home))))
 (let (($x540 (dir.shlist @V0)))
 (let (($x573 (not $x540)))
 (or $x573 $x575)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x567 (not $x58)))
 (or $x567 dir.head))))
(assert
 (let (($x536 (dir.shlist @X)))
 (let (($x571 (not $x536)))
 (or $x571 dir.head))))
(assert
 (let (($x540 (dir.shlist @V0)))
 (let (($x573 (not $x540)))
 (or $x573 dir.head))))
(assert
 (let (($x322 (not (= (cache.state_ @X) exclusive))))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x322))))
(assert
 (let (($x466 (not (= (cache.state_ @V0) exclusive))))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x466))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let (($x582 (= @X home)))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x582 $x342)))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let (($x582 (= @X home)))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x582 $x357)))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let (($x582 (= @X home)))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x582 $x328)))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let (($x404 (= @V0 home)))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x404 $x290)))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let (($x404 (= @V0 home)))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x404 $x517)))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let (($x582 (= @X home)))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x582 $x519)))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let (($x404 (= @V0 home)))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x404 $x521)))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let (($x590 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x590 $x565)))))
(assert
 (let (($x322 (not (= (cache.state_ @X) exclusive))))
 (let (($x450 (= @X requester)))
 (let (($x536 (dir.shlist @X)))
 (or $x536 $x450 $x322)))))
(assert
 (let (($x466 (not (= (cache.state_ @V0) exclusive))))
 (let (($x458 (= @V0 requester)))
 (let (($x540 (dir.shlist @V0)))
 (or $x540 $x458 $x466)))))
(assert
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (let (($x463 (= @X real_owner)))
 (or (dir.real @X) $x463 $x595)))))
(assert
 (let ((?x296 (cache.state_ @V0)))
 (let (($x297 (= ?x296 invalid)))
 (let (($x405 (= @V0 real_owner)))
 (or (dir.real @V0) $x405 $x297)))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x313))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x472))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x560))))
(assert
 (let (($x477 (not (= (cache.state_ @X) shared))))
 (or $x477 (not (= (cache.wait @X) get)))))
(assert
 (let (($x480 (not (= (cache.state_ @V0) shared))))
 (or $x480 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x531 (not (invack @X))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x531)))))
(assert
 (let (($x534 (not (invack @V0))))
 (let ((?x296 (cache.state_ @V0)))
 (let (($x297 (= ?x296 invalid)))
 (or $x297 $x534)))))
(assert
 (let (($x322 (not (= (cache.state_ @X) exclusive))))
 (or $x322 dir.head)))
(assert
 (let (($x466 (not (= (cache.state_ @V0) exclusive))))
 (or $x466 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x387 (= home home)))
 (or $x387 $x187))))
(assert
 (let (($x279 (not (net.fack @V0 @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x279))))
(assert
 (let (($x336 (not (net.putX @Y @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x336)))))
(assert
 (let (($x351 (not (net.putX @Z @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x351)))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x313)))))
(assert
 (let (($x284 (not (net.putX @V1 @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x282 (= ?x281 getX)))
 (or $x282 $x284)))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x282 (= ?x281 getX)))
 (or $x282 $x472)))))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x508)))))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x282 (= ?x281 getX)))
 (or $x282 $x510)))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x617 (= ?x616 getX)))
 (or $x617 $x560)))))
(assert
 (let (($x347 (not (net.getX @X @Y))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x347)))))
(assert
 (let (($x339 (not (net.getX @X @Z))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x339)))))
(assert
 (let (($x360 (not (net.getX home @Y))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x360)))))
(assert
 (let (($x318 (not (net.getX @X home))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x318)))))
(assert
 (let (($x307 (not (net.getX @V1 @V0))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x624 (= ?x308 getX)))
 (or $x624 $x307)))))
(assert
 (let (($x287 (not (net.getX @V0 @V1))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x282 (= ?x281 getX)))
 (or $x282 $x287)))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x342)))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x357)))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x328)))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x291 (= ?x281 get)))
 (or $x291 $x290)))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x291 (= ?x281 get)))
 (or $x291 $x517)))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x519)))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x291 (= ?x281 get)))
 (or $x291 $x521)))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x631 (= ?x616 get)))
 (or $x631 $x565)))))
(assert
 (let (($x354 (not (net.get @X @Y))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x354)))))
(assert
 (let (($x344 (not (net.get @X @Z))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x344)))))
(assert
 (let (($x333 (not (net.get @X home))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x333)))))
(assert
 (let (($x294 (not (net.get @V0 @V1))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x291 (= ?x281 get)))
 (or $x291 $x294)))))
(assert
 (let (($x523 (not (net.get home @Y))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x523)))))
(assert
 (let (($x525 (not (net.get home @Z))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x525)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x527)))))
(assert
 (let (($x529 (not (net.get home @V1))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x529)))))
(assert
 (let (($x342 (not (net.put @Y @X))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x342)))))
(assert
 (let (($x357 (not (net.put @Z @X))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x357)))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x328)))))
(assert
 (let (($x290 (not (net.put @V1 @V0))))
 (let ((?x296 (cache.state_ @V0)))
 (let (($x297 (= ?x296 invalid)))
 (or $x297 $x290)))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let ((?x296 (cache.state_ @V0)))
 (let (($x297 (= ?x296 invalid)))
 (or $x297 $x517)))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x519)))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let ((?x296 (cache.state_ @V0)))
 (let (($x297 (= ?x296 invalid)))
 (or $x297 $x521)))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let ((?x646 (cache.state_ dir.hptr)))
 (let (($x647 (= ?x646 invalid)))
 (or $x647 $x565)))))
(assert
 (let (($x354 (not (net.get @X @Y))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x354)))))
(assert
 (let (($x344 (not (net.get @X @Z))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x344)))))
(assert
 (let (($x333 (not (net.get @X home))))
 (let ((?x320 (cache.state_ @X)))
 (let (($x595 (= ?x320 invalid)))
 (or $x595 $x333)))))
(assert
 (let (($x294 (not (net.get @V0 @V1))))
 (let ((?x296 (cache.state_ @V0)))
 (let (($x297 (= ?x296 invalid)))
 (or $x297 $x294)))))
(assert
 (let (($x523 (not (net.get home @Y))))
 (let ((?x652 (cache.state_ home)))
 (let (($x653 (= ?x652 invalid)))
 (or $x653 $x523)))))
(assert
 (let (($x525 (not (net.get home @Z))))
 (let ((?x652 (cache.state_ home)))
 (let (($x653 (= ?x652 invalid)))
 (or $x653 $x525)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let ((?x652 (cache.state_ home)))
 (let (($x653 (= ?x652 invalid)))
 (or $x653 $x527)))))
(assert
 (let (($x529 (not (net.get home @V1))))
 (let ((?x652 (cache.state_ home)))
 (let (($x653 (= ?x652 invalid)))
 (or $x653 $x529)))))
(assert
 (let (($x301 (= @Y home)))
 (or $x301 (not (net.shwb @X @Y)))))
(assert
 (let (($x387 (= home home)))
 (or $x387 (not (net.shwb @X home)))))
(assert
 (let (($x660 (not (= (cache.wait @X) none))))
 (let (($x347 (not (net.getX @X @Y))))
 (or $x347 $x660))))
(assert
 (let (($x660 (not (= (cache.wait @X) none))))
 (let (($x339 (not (net.getX @X @Z))))
 (or $x339 $x660))))
(assert
 (let (($x664 (not (= (cache.wait home) none))))
 (let (($x360 (not (net.getX home @Y))))
 (or $x360 $x664))))
(assert
 (let (($x660 (not (= (cache.wait @X) none))))
 (let (($x318 (not (net.getX @X home))))
 (or $x318 $x660))))
(assert
 (let (($x310 (not (= (cache.wait @V1) none))))
 (let (($x307 (not (net.getX @V1 @V0))))
 (or $x307 $x310))))
(assert
 (let (($x668 (not (= (cache.wait @V0) none))))
 (let (($x287 (not (net.getX @V0 @V1))))
 (or $x287 $x668))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x670 (= ?x140 getX)))
 (or $x670 $x672)))))
(assert
 (let (($x313 (not (net.putX home @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x313)))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x624 (= ?x308 getX)))
 (or $x624 $x675)))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x282 (= ?x281 getX)))
 (or $x282 $x472)))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x617 (= ?x616 getX)))
 (or $x617 $x560)))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x678)))))
(assert
 (let (($x318 (not (net.getX @X home))))
 (let ((?x314 (cache.wait @X)))
 (let (($x315 (= ?x314 getX)))
 (or $x315 $x318)))))
(assert
 (let (($x681 (not (net.getX home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x681)))))
(assert
 (let (($x684 (not (net.getX @V1 home))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x624 (= ?x308 getX)))
 (or $x624 $x684)))))
(assert
 (let (($x687 (not (net.getX @V0 home))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x282 (= ?x281 getX)))
 (or $x282 $x687)))))
(assert
 (let (($x322 (not (= (cache.state_ @X) exclusive))))
 (or $x322 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x466 (not (= (cache.state_ @V0) exclusive))))
 (or $x466 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x692 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x692 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x696 (not (= (cache.state_ home) exclusive))))
 (or $x696 (not (= (cache.wait home) getX)))))
(assert
 (let (($x326 (not (rp_net @X))))
 (let (($x328 (not (net.put home @X))))
 (or $x328 $x326))))
(assert
 (let (($x514 (not (rp_net @V0))))
 (let (($x517 (not (net.put home @V0))))
 (or $x517 $x514))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x701)))))
(assert
 (let (($x328 (not (net.put home @X))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x328)))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x703 (= ?x308 get)))
 (or $x703 $x705)))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x291 (= ?x281 get)))
 (or $x291 $x517)))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x631 (= ?x616 get)))
 (or $x631 $x565)))))
(assert
 (let (($x708 (not (net.put home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x708)))))
(assert
 (let (($x711 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x711)))))
(assert
 (let (($x333 (not (net.get @X home))))
 (let ((?x314 (cache.wait @X)))
 (let (($x330 (= ?x314 get)))
 (or $x330 $x333)))))
(assert
 (let (($x714 (not (net.get @V1 home))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x703 (= ?x308 get)))
 (or $x703 $x714)))))
(assert
 (let (($x575 (not (net.get @V0 home))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x291 (= ?x281 get)))
 (or $x291 $x575)))))
(assert
 (let (($x569 (not (net.get dir.hptr home))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x631 (= ?x616 get)))
 (or $x631 $x569)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x527)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x517)))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x145 $x519)))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x145 $x521)))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x565)))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x701)))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x705)))))
(assert
 (let (($x708 (not (net.put home home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x708)))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x472)))))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (let (($x733 (= real_owner real_owner)))
 (let (($x732 (= real_owner home)))
 (or $x732 $x733 $x508)))))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (let (($x733 (= real_owner real_owner)))
 (let (($x732 (= real_owner home)))
 (or $x732 $x733 $x510)))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x560)))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x672)))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x675)))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x678)))))
(assert
 (let (($x523 (not (net.get home @Y))))
 (let (($x382 (= @Y real_owner)))
 (let (($x301 (= @Y home)))
 (or $x301 $x382 $x523)))))
(assert
 (let (($x525 (not (net.get home @Z))))
 (let (($x385 (= @Z real_owner)))
 (let (($x384 (= @Z home)))
 (or $x384 $x385 $x525)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x527)))))
(assert
 (let (($x529 (not (net.get home @V1))))
 (let (($x390 (= @V1 real_owner)))
 (let (($x276 (= @V1 home)))
 (or $x276 $x390 $x529)))))
(assert
 (let (($x569 (not (net.get dir.hptr home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x569)))))
(assert
 (let (($x575 (not (net.get @V0 home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x575)))))
(assert
 (let (($x711 (not (net.get real_owner home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x711)))))
(assert
 (let (($x714 (not (net.get @V1 home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x714)))))
(assert
 (let (($x681 (not (net.getX home home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x681)))))
(assert
 (let (($x684 (not (net.getX @V1 home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x684)))))
(assert
 (let (($x687 (not (net.getX @V0 home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x687)))))
(assert
 (let (($x719 (not (net.getX home @Z))))
 (let (($x385 (= @Z real_owner)))
 (let (($x384 (= @Z home)))
 (or $x384 $x385 $x719)))))
(assert
 (let (($x721 (not (net.getX home @V0))))
 (let (($x405 (= @V0 real_owner)))
 (let (($x404 (= @V0 home)))
 (or $x404 $x405 $x721)))))
(assert
 (let (($x723 (not (net.getX home @V1))))
 (let (($x390 (= @V1 real_owner)))
 (let (($x276 (= @V1 home)))
 (or $x276 $x390 $x723)))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (let (($x387 (= home home)))
 (or $x387 $x517 dir.dirty))))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x519 dir.dirty))))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x521 dir.dirty))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let (($x387 (= home home)))
 (or $x387 $x565 dir.dirty))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let (($x387 (= home home)))
 (or $x387 $x701 dir.dirty))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let (($x387 (= home home)))
 (or $x387 $x705 dir.dirty))))
(assert
 (let (($x708 (not (net.put home home))))
 (let (($x387 (= home home)))
 (or $x387 $x708 dir.dirty))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x387 (= home home)))
 (or $x387 $x472 dir.head))))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x508 dir.head))))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x510 dir.head))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x387 (= home home)))
 (or $x387 $x560 dir.head))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x387 (= home home)))
 (or $x387 $x672 dir.head))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x387 (= home home)))
 (or $x387 $x675 dir.head))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x387 (= home home)))
 (or $x387 $x678 dir.head))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x387 (= home home)))
 (or $x387 $x472 dir.dirty))))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x508 dir.dirty))))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x510 dir.dirty))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x387 (= home home)))
 (or $x387 $x560 dir.dirty))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x387 (= home home)))
 (or $x387 $x672 dir.dirty))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x387 (= home home)))
 (or $x387 $x675 dir.dirty))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x387 (= home home)))
 (or $x387 $x678 dir.dirty))))
(assert
 (let (($x472 (not (net.putX home @V0))))
 (let (($x387 (= home home)))
 (or $x387 $x472))))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x508))))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x510))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x387 (= home home)))
 (or $x387 $x560))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x387 (= home home)))
 (or $x387 $x672))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x387 (= home home)))
 (or $x387 $x675))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x387 (= home home)))
 (or $x387 $x678))))
(assert
 (let (($x523 (not (net.get home @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x523 dir.head))))
(assert
 (let (($x525 (not (net.get home @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x525 dir.head))))
(assert
 (let (($x527 (not (net.get home home))))
 (let (($x387 (= home home)))
 (or $x387 $x527 dir.head))))
(assert
 (let (($x529 (not (net.get home @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x529 dir.head))))
(assert
 (let (($x569 (not (net.get dir.hptr home))))
 (let (($x387 (= home home)))
 (or $x387 $x569 dir.head))))
(assert
 (let (($x575 (not (net.get @V0 home))))
 (let (($x387 (= home home)))
 (or $x387 $x575 dir.head))))
(assert
 (let (($x711 (not (net.get real_owner home))))
 (let (($x387 (= home home)))
 (or $x387 $x711 dir.head))))
(assert
 (let (($x714 (not (net.get @V1 home))))
 (let (($x387 (= home home)))
 (or $x387 $x714 dir.head))))
(assert
 (let (($x523 (not (net.get home @Y))))
 (let (($x301 (= @Y home)))
 (or $x301 $x523 dir.dirty))))
(assert
 (let (($x525 (not (net.get home @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x525 dir.dirty))))
(assert
 (let (($x527 (not (net.get home home))))
 (let (($x387 (= home home)))
 (or $x387 $x527 dir.dirty))))
(assert
 (let (($x529 (not (net.get home @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x529 dir.dirty))))
(assert
 (let (($x569 (not (net.get dir.hptr home))))
 (let (($x387 (= home home)))
 (or $x387 $x569 dir.dirty))))
(assert
 (let (($x575 (not (net.get @V0 home))))
 (let (($x387 (= home home)))
 (or $x387 $x575 dir.dirty))))
(assert
 (let (($x711 (not (net.get real_owner home))))
 (let (($x387 (= home home)))
 (or $x387 $x711 dir.dirty))))
(assert
 (let (($x714 (not (net.get @V1 home))))
 (let (($x387 (= home home)))
 (or $x387 $x714 dir.dirty))))
(assert
 (let (($x681 (not (net.getX home home))))
 (let (($x387 (= home home)))
 (or $x387 $x681 dir.head))))
(assert
 (let (($x684 (not (net.getX @V1 home))))
 (let (($x387 (= home home)))
 (or $x387 $x684 dir.head))))
(assert
 (let (($x687 (not (net.getX @V0 home))))
 (let (($x387 (= home home)))
 (or $x387 $x687 dir.head))))
(assert
 (let (($x719 (not (net.getX home @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x719 dir.head))))
(assert
 (let (($x721 (not (net.getX home @V0))))
 (let (($x404 (= @V0 home)))
 (or $x404 $x721 dir.head))))
(assert
 (let (($x723 (not (net.getX home @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x723 dir.head))))
(assert
 (let (($x681 (not (net.getX home home))))
 (let (($x387 (= home home)))
 (or $x387 $x681 dir.dirty))))
(assert
 (let (($x684 (not (net.getX @V1 home))))
 (let (($x387 (= home home)))
 (or $x387 $x684 dir.dirty))))
(assert
 (let (($x687 (not (net.getX @V0 home))))
 (let (($x387 (= home home)))
 (or $x387 $x687 dir.dirty))))
(assert
 (let (($x719 (not (net.getX home @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x719 dir.dirty))))
(assert
 (let (($x721 (not (net.getX home @V0))))
 (let (($x404 (= @V0 home)))
 (or $x404 $x721 dir.dirty))))
(assert
 (let (($x723 (not (net.getX home @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x723 dir.dirty))))
(assert
 (let (($x681 (not (net.getX home home))))
 (let (($x387 (= home home)))
 (or $x387 $x681))))
(assert
 (let (($x684 (not (net.getX @V1 home))))
 (let (($x387 (= home home)))
 (or $x387 $x684))))
(assert
 (let (($x687 (not (net.getX @V0 home))))
 (let (($x387 (= home home)))
 (or $x387 $x687))))
(assert
 (let (($x719 (not (net.getX home @Z))))
 (let (($x384 (= @Z home)))
 (or $x384 $x719))))
(assert
 (let (($x721 (not (net.getX home @V0))))
 (let (($x404 (= @V0 home)))
 (or $x404 $x721))))
(assert
 (let (($x723 (not (net.getX home @V1))))
 (let (($x276 (= @V1 home)))
 (or $x276 $x723))))
(assert
 (let (($x681 (not (net.getX home home))))
 (let (($x387 (= home home)))
 (let (($x453 (= home requester)))
 (or $x453 $x387 $x681)))))
(assert
 (let (($x684 (not (net.getX @V1 home))))
 (let (($x387 (= home home)))
 (let (($x456 (= @V1 requester)))
 (or $x456 $x387 $x684)))))
(assert
 (let (($x687 (not (net.getX @V0 home))))
 (let (($x387 (= home home)))
 (let (($x458 (= @V0 requester)))
 (or $x458 $x387 $x687)))))
(assert
 (let (($x719 (not (net.getX home @Z))))
 (let (($x384 (= @Z home)))
 (let (($x453 (= home requester)))
 (or $x453 $x384 $x719)))))
(assert
 (let (($x721 (not (net.getX home @V0))))
 (let (($x404 (= @V0 home)))
 (let (($x453 (= home requester)))
 (or $x453 $x404 $x721)))))
(assert
 (let (($x723 (not (net.getX home @V1))))
 (let (($x276 (= @V1 home)))
 (let (($x453 (= home requester)))
 (or $x453 $x276 $x723)))))
(assert
 (let (($x692 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x692))))
(assert
 (let (($x696 (not (= (cache.state_ home) exclusive))))
 (let (($x388 (= home real_owner)))
 (or $x388 $x696))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x823 (= dir.hptr dir.hptr)))
 (or $x823 $x560))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x825 (= real_owner dir.hptr)))
 (or $x825 $x672))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x827 (= @V1 dir.hptr)))
 (or $x827 $x675))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x829 (= home dir.hptr)))
 (or $x829 $x678))))
(assert
 (let (($x692 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x823 (= dir.hptr dir.hptr)))
 (or $x823 $x692))))
(assert
 (let (($x696 (not (= (cache.state_ home) exclusive))))
 (let (($x829 (= home dir.hptr)))
 (or $x829 $x696))))
(assert
 (let (($x834 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x834))))
(assert
 (let (($x837 (not (= (cache.state_ home) shared))))
 (let (($x388 (= home real_owner)))
 (or $x388 $x837))))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x508))))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x510))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x387 (= home home)))
 (or $x387 $x560))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x387 (= home home)))
 (or $x387 $x672))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x387 (= home home)))
 (or $x387 $x675))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x387 (= home home)))
 (or $x387 $x678))))
(assert
 (let (($x480 (not (= (cache.state_ @V0) shared))))
 (let (($x514 (not (rp_net @V0))))
 (or $x514 $x480))))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (let (($x484 (= real_owner @X)))
 (or $x484 $x508))))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (let (($x488 (= real_owner @V0)))
 (or $x488 $x510))))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (let (($x825 (= real_owner dir.hptr)))
 (or $x825 $x560))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x733 (= real_owner real_owner)))
 (or $x733 $x672))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x844 (= real_owner @V1)))
 (or $x844 $x675))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x678))))
(assert
 (let (($x517 (not (net.put home @V0))))
 (or $x517 dir.head)))
(assert
 (let (($x519 (not (net.put dir.hptr @X))))
 (or $x519 dir.head)))
(assert
 (let (($x521 (not (net.put dir.hptr @V0))))
 (or $x521 dir.head)))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (or $x565 dir.head)))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (or $x701 dir.head)))
(assert
 (let (($x705 (not (net.put home @V1))))
 (or $x705 dir.head)))
(assert
 (let (($x708 (not (net.put home home))))
 (or $x708 dir.head)))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (or $x508 dir.head)))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (or $x510 dir.head)))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (or $x560 dir.head)))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (or $x672 dir.head)))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (or $x675 dir.head)))
(assert
 (let (($x678 (not (net.putX home home))))
 (or $x678 dir.head)))
(assert
 (let (($x508 (not (net.putX real_owner @X))))
 (or $x508 dir.dirty)))
(assert
 (let (($x510 (not (net.putX real_owner @V0))))
 (or $x510 dir.dirty)))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (or $x560 dir.dirty)))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (or $x672 dir.dirty)))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (or $x675 dir.dirty)))
(assert
 (let (($x678 (not (net.putX home home))))
 (or $x678 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x560 (not (net.putX home dir.hptr))))
 (or $x560 dir.head)))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (or $x672 dir.head)))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (or $x675 dir.head)))
(assert
 (let (($x678 (not (net.putX home home))))
 (or $x678 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x514 (not (rp_net @V0))))
 (let (($x517 (not (net.put home @V0))))
 (or $x517 $x514))))
(assert
 (let (($x326 (not (rp_net @X))))
 (let (($x519 (not (net.put dir.hptr @X))))
 (or $x519 $x326))))
(assert
 (let (($x514 (not (rp_net @V0))))
 (let (($x521 (not (net.put dir.hptr @V0))))
 (or $x521 $x514))))
(assert
 (let (($x877 (not (rp_net dir.hptr))))
 (let (($x565 (not (net.put home dir.hptr))))
 (or $x565 $x877))))
(assert
 (let (($x880 (not (rp_net real_owner))))
 (let (($x701 (not (net.put home real_owner))))
 (or $x701 $x880))))
(assert
 (let (($x883 (not (rp_net @V1))))
 (let (($x705 (not (net.put home @V1))))
 (or $x705 $x883))))
(assert
 (let (($x886 (not (rp_net home))))
 (let (($x708 (not (net.put home home))))
 (or $x708 $x886))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x531 (not (invack @X))))
 (or $x531 (not (invnet @X)))))
(assert
 (let (($x534 (not (invack @V0))))
 (or $x534 (not (invnet @V0)))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x565 __dir.pending))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x701 __dir.pending))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x705 __dir.pending))))
(assert
 (let (($x708 (not (net.put home home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x708 __dir.pending))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x889 __dir.pending))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x891 __dir.pending))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x893 __dir.pending))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x895 __dir.pending))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x565 dir.dirty))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x701 dir.dirty))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x705 dir.dirty))))
(assert
 (let (($x708 (not (net.put home home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x708 dir.dirty))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x889 dir.dirty))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x891 dir.dirty))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x893 dir.dirty))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x895 dir.dirty))))
(assert
 (let (($x565 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x565))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x701))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x705))))
(assert
 (let (($x708 (not (net.put home home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x708))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x889))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x891))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x893))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x895))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x672))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x675))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x678))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x701))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x705))))
(assert
 (let (($x708 (not (net.put home home))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x708))))
(assert
 (let (($x711 (not (net.get real_owner home))))
 (let (($x903 (dir.shlist real_owner)))
 (let (($x931 (not $x903)))
 (or $x931 $x711)))))
(assert
 (let (($x714 (not (net.get @V1 home))))
 (let (($x905 (dir.shlist @V1)))
 (let (($x933 (not $x905)))
 (or $x933 $x714)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let (($x907 (dir.shlist home)))
 (let (($x935 (not $x907)))
 (or $x935 $x527)))))
(assert
 (let (($x903 (dir.shlist real_owner)))
 (let (($x931 (not $x903)))
 (or $x931 dir.head))))
(assert
 (let (($x905 (dir.shlist @V1)))
 (let (($x933 (not $x905)))
 (or $x933 dir.head))))
(assert
 (let (($x907 (dir.shlist home)))
 (let (($x935 (not $x907)))
 (or $x935 dir.head))))
(assert
 (let (($x692 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x692))))
(assert
 (let (($x696 (not (= (cache.state_ home) exclusive))))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x696))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let (($x732 (= real_owner home)))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x732 $x701)))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let (($x276 (= @V1 home)))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x276 $x705)))))
(assert
 (let (($x708 (not (net.put home home))))
 (let (($x387 (= home home)))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x387 $x708)))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let (($x590 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x590 $x889)))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let (($x732 (= real_owner home)))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x732 $x891)))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let (($x276 (= @V1 home)))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x276 $x893)))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let (($x387 (= home home)))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x387 $x895)))))
(assert
 (let (($x692 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x949 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x949 $x692)))))
(assert
 (let (($x696 (not (= (cache.state_ home) exclusive))))
 (let (($x453 (= home requester)))
 (let (($x907 (dir.shlist home)))
 (or $x907 $x453 $x696)))))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x672))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x675))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x678))))
(assert
 (let (($x834 (not (= (cache.state_ dir.hptr) shared))))
 (or $x834 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x837 (not (= (cache.state_ home) shared))))
 (or $x837 (not (= (cache.wait home) get)))))
(assert
 (let (($x692 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x692 dir.head)))
(assert
 (let (($x696 (not (= (cache.state_ home) exclusive))))
 (or $x696 dir.head)))
(assert
 (let (($x672 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x670 (= ?x140 getX)))
 (or $x670 $x672)))))
(assert
 (let (($x675 (not (net.putX home @V1))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x624 (= ?x308 getX)))
 (or $x624 $x675)))))
(assert
 (let (($x678 (not (net.putX home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x678)))))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x617 (= ?x616 getX)))
 (or $x617 $x867)))))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x670 (= ?x140 getX)))
 (or $x670 $x869)))))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x624 (= ?x308 getX)))
 (or $x624 $x871)))))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x873)))))
(assert
 (let (($x681 (not (net.getX home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x681)))))
(assert
 (let (($x684 (not (net.getX @V1 home))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x624 (= ?x308 getX)))
 (or $x624 $x684)))))
(assert
 (let (($x687 (not (net.getX @V0 home))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x282 (= ?x281 getX)))
 (or $x282 $x687)))))
(assert
 (let (($x719 (not (net.getX home @Z))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x719)))))
(assert
 (let (($x721 (not (net.getX home @V0))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x721)))))
(assert
 (let (($x723 (not (net.getX home @V1))))
 (let ((?x621 (cache.wait home)))
 (let (($x622 (= ?x621 getX)))
 (or $x622 $x723)))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x701)))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x703 (= ?x308 get)))
 (or $x703 $x705)))))
(assert
 (let (($x708 (not (net.put home home))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x708)))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x631 (= ?x616 get)))
 (or $x631 $x889)))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x891)))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x703 (= ?x308 get)))
 (or $x703 $x893)))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let ((?x621 (cache.wait home)))
 (let (($x635 (= ?x621 get)))
 (or $x635 $x895)))))
(assert
 (let (($x569 (not (net.get dir.hptr home))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x631 (= ?x616 get)))
 (or $x631 $x569)))))
(assert
 (let (($x575 (not (net.get @V0 home))))
 (let ((?x281 (cache.wait @V0)))
 (let (($x291 (= ?x281 get)))
 (or $x291 $x575)))))
(assert
 (let (($x711 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x711)))))
(assert
 (let (($x714 (not (net.get @V1 home))))
 (let ((?x308 (cache.wait @V1)))
 (let (($x703 (= ?x308 get)))
 (or $x703 $x714)))))
(assert
 (let (($x701 (not (net.put home real_owner))))
 (let ((?x972 (cache.state_ real_owner)))
 (let (($x973 (= ?x972 invalid)))
 (or $x973 $x701)))))
(assert
 (let (($x705 (not (net.put home @V1))))
 (let ((?x975 (cache.state_ @V1)))
 (let (($x976 (= ?x975 invalid)))
 (or $x976 $x705)))))
(assert
 (let (($x708 (not (net.put home home))))
 (let ((?x652 (cache.state_ home)))
 (let (($x653 (= ?x652 invalid)))
 (or $x653 $x708)))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let ((?x646 (cache.state_ dir.hptr)))
 (let (($x647 (= ?x646 invalid)))
 (or $x647 $x889)))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let ((?x972 (cache.state_ real_owner)))
 (let (($x973 (= ?x972 invalid)))
 (or $x973 $x891)))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let ((?x975 (cache.state_ @V1)))
 (let (($x976 (= ?x975 invalid)))
 (or $x976 $x893)))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let ((?x652 (cache.state_ home)))
 (let (($x653 (= ?x652 invalid)))
 (or $x653 $x895)))))
(assert
 (let (($x569 (not (net.get dir.hptr home))))
 (let ((?x646 (cache.state_ dir.hptr)))
 (let (($x647 (= ?x646 invalid)))
 (or $x647 $x569)))))
(assert
 (let (($x575 (not (net.get @V0 home))))
 (let ((?x296 (cache.state_ @V0)))
 (let (($x297 (= ?x296 invalid)))
 (or $x297 $x575)))))
(assert
 (let (($x711 (not (net.get real_owner home))))
 (let ((?x972 (cache.state_ real_owner)))
 (let (($x973 (= ?x972 invalid)))
 (or $x973 $x711)))))
(assert
 (let (($x714 (not (net.get @V1 home))))
 (let ((?x975 (cache.state_ @V1)))
 (let (($x976 (= ?x975 invalid)))
 (or $x976 $x714)))))
(assert
 (let (($x664 (not (= (cache.wait home) none))))
 (let (($x681 (not (net.getX home home))))
 (or $x681 $x664))))
(assert
 (let (($x310 (not (= (cache.wait @V1) none))))
 (let (($x684 (not (net.getX @V1 home))))
 (or $x684 $x310))))
(assert
 (let (($x668 (not (= (cache.wait @V0) none))))
 (let (($x687 (not (net.getX @V0 home))))
 (or $x687 $x668))))
(assert
 (let (($x664 (not (= (cache.wait home) none))))
 (let (($x719 (not (net.getX home @Z))))
 (or $x719 $x664))))
(assert
 (let (($x664 (not (= (cache.wait home) none))))
 (let (($x721 (not (net.getX home @V0))))
 (or $x721 $x664))))
(assert
 (let (($x664 (not (= (cache.wait home) none))))
 (let (($x723 (not (net.getX home @V1))))
 (or $x723 $x664))))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x670 (= ?x140 getX)))
 (or $x670 $x994)))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x617 (= ?x616 getX)))
 (or $x617 $x997)))))
(assert
 (let (($x1000 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1000 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1004 (not (= (cache.state_ @V1) exclusive))))
 (or $x1004 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x877 (not (rp_net dir.hptr))))
 (let (($x565 (not (net.put home dir.hptr))))
 (or $x565 $x877))))
(assert
 (let (($x880 (not (rp_net real_owner))))
 (let (($x701 (not (net.put home real_owner))))
 (or $x701 $x880))))
(assert
 (let (($x883 (not (rp_net @V1))))
 (let (($x705 (not (net.put home @V1))))
 (or $x705 $x883))))
(assert
 (let (($x886 (not (rp_net home))))
 (let (($x708 (not (net.put home home))))
 (or $x708 $x886))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x145 $x889)))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x145 $x891)))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x145 $x893)))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x145 $x895)))))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (let (($x733 (= real_owner real_owner)))
 (let (($x732 (= real_owner home)))
 (or $x732 $x733 $x867)))))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (let (($x733 (= real_owner real_owner)))
 (let (($x732 (= real_owner home)))
 (or $x732 $x733 $x869)))))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (let (($x733 (= real_owner real_owner)))
 (let (($x732 (= real_owner home)))
 (or $x732 $x733 $x871)))))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (let (($x733 (= real_owner real_owner)))
 (let (($x732 (= real_owner home)))
 (or $x732 $x733 $x873)))))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x994)))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (let (($x388 (= home real_owner)))
 (let (($x387 (= home home)))
 (or $x387 $x388 $x997)))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x889 dir.dirty))))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x891 dir.dirty))))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x893 dir.dirty))))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (let (($x590 (= dir.hptr home)))
 (or $x590 $x895 dir.dirty))))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x867 dir.head))))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x869 dir.head))))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x871 dir.head))))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x873 dir.head))))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x867 dir.dirty))))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x869 dir.dirty))))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x871 dir.dirty))))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x873 dir.dirty))))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x867))))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x869))))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x871))))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x873))))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (let (($x387 (= home home)))
 (or $x387 $x994 dir.head))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (let (($x387 (= home home)))
 (or $x387 $x997 dir.head))))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (let (($x387 (= home home)))
 (or $x387 $x994 dir.dirty))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (let (($x387 (= home home)))
 (or $x387 $x997 dir.dirty))))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (let (($x387 (= home home)))
 (or $x387 $x994))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (let (($x387 (= home home)))
 (or $x387 $x997))))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (let (($x387 (= home home)))
 (let (($x1039 (= real_owner requester)))
 (or $x1039 $x387 $x994)))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (let (($x387 (= home home)))
 (let (($x949 (= dir.hptr requester)))
 (or $x949 $x387 $x997)))))
(assert
 (let (($x1000 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x733 (= real_owner real_owner)))
 (or $x733 $x1000))))
(assert
 (let (($x1004 (not (= (cache.state_ @V1) exclusive))))
 (let (($x390 (= @V1 real_owner)))
 (or $x390 $x1004))))
(assert
 (let (($x1000 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x825 (= real_owner dir.hptr)))
 (or $x825 $x1000))))
(assert
 (let (($x1004 (not (= (cache.state_ @V1) exclusive))))
 (let (($x827 (= @V1 dir.hptr)))
 (or $x827 $x1004))))
(assert
 (let (($x1047 (not (= (cache.state_ real_owner) shared))))
 (let (($x733 (= real_owner real_owner)))
 (or $x733 $x1047))))
(assert
 (let (($x1050 (not (= (cache.state_ @V1) shared))))
 (let (($x390 (= @V1 real_owner)))
 (or $x390 $x1050))))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x867))))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x869))))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x871))))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x873))))
(assert
 (let (($x834 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x877 (not (rp_net dir.hptr))))
 (or $x877 $x834))))
(assert
 (let (($x837 (not (= (cache.state_ home) shared))))
 (let (($x886 (not (rp_net home))))
 (or $x886 $x837))))
(assert
 (let (($x1047 (not (= (cache.state_ real_owner) shared))))
 (let (($x880 (not (rp_net real_owner))))
 (or $x880 $x1047))))
(assert
 (let (($x1050 (not (= (cache.state_ @V1) shared))))
 (let (($x883 (not (rp_net @V1))))
 (or $x883 $x1050))))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (let (($x825 (= real_owner dir.hptr)))
 (or $x825 $x867))))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (let (($x733 (= real_owner real_owner)))
 (or $x733 $x869))))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (let (($x844 (= real_owner @V1)))
 (or $x844 $x871))))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (let (($x732 (= real_owner home)))
 (or $x732 $x873))))
(assert
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (or $x889 dir.head)))
(assert
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (or $x891 dir.head)))
(assert
 (let (($x893 (not (net.put dir.hptr @V1))))
 (or $x893 dir.head)))
(assert
 (let (($x895 (not (net.put dir.hptr home))))
 (or $x895 dir.head)))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (or $x867 dir.head)))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (or $x869 dir.head)))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (or $x871 dir.head)))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (or $x873 dir.head)))
(assert
 (let (($x867 (not (net.putX real_owner dir.hptr))))
 (or $x867 dir.dirty)))
(assert
 (let (($x869 (not (net.putX real_owner real_owner))))
 (or $x869 dir.dirty)))
(assert
 (let (($x871 (not (net.putX real_owner @V1))))
 (or $x871 dir.dirty)))
(assert
 (let (($x873 (not (net.putX real_owner home))))
 (or $x873 dir.dirty)))
(assert
 (let (($x877 (not (rp_net dir.hptr))))
 (let (($x889 (not (net.put dir.hptr dir.hptr))))
 (or $x889 $x877))))
(assert
 (let (($x880 (not (rp_net real_owner))))
 (let (($x891 (not (net.put dir.hptr real_owner))))
 (or $x891 $x880))))
(assert
 (let (($x883 (not (rp_net @V1))))
 (let (($x893 (not (net.put dir.hptr @V1))))
 (or $x893 $x883))))
(assert
 (let (($x886 (not (rp_net home))))
 (let (($x895 (not (net.put dir.hptr home))))
 (or $x895 $x886))))
(assert
 (let (($x1000 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x1000))))
(assert
 (let (($x1004 (not (= (cache.state_ @V1) exclusive))))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x1004))))
(assert
 (let (($x1000 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x1039 (= real_owner requester)))
 (let (($x903 (dir.shlist real_owner)))
 (or $x903 $x1039 $x1000)))))
(assert
 (let (($x1004 (not (= (cache.state_ @V1) exclusive))))
 (let (($x456 (= @V1 requester)))
 (let (($x905 (dir.shlist @V1)))
 (or $x905 $x456 $x1004)))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (let (($x142 (not $x141)))
 (let (($x1047 (not (= (cache.state_ real_owner) shared))))
 (or $x1047 $x142))))))
(assert
 (let (($x1050 (not (= (cache.state_ @V1) shared))))
 (or $x1050 (not (= (cache.wait @V1) get)))))
(assert
 (let (($x1000 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1000 dir.head)))
(assert
 (let (($x1004 (not (= (cache.state_ @V1) exclusive))))
 (or $x1004 dir.head)))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x670 (= ?x140 getX)))
 (or $x670 $x994)))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (let ((?x616 (cache.wait dir.hptr)))
 (let (($x617 (= ?x616 getX)))
 (or $x617 $x997)))))
(assert
 (let (($x994 (not (net.getX real_owner home))))
 (or $x994 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x997 (not (net.getX dir.hptr home))))
 (or $x997 (not (= (cache.wait dir.hptr) none)))))
(check-sat)
