(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun __src () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (cache.wait real_owner) get)))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (= ?x271 shared)))
(assert
 (let ((?x273 (cache.wait __src)))
 (= ?x273 none)))
(assert
 (not (= __src home)))
(assert
 (let ((?x295 (cache.wait @Y)))
 (let (($x296 (= ?x295 none)))
 (let ((?x290 (cache.wait @X)))
 (let (($x291 (= ?x290 none)))
 (and (= (cache.state_ @X) exclusive) $x291 (= (cache.state_ @Y) exclusive) $x296 (not (= @X @Y))))))))
(assert
 (let ((?x288 (cache.state_ @X)))
 (= ?x288 (ite (and (= @X __src)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x293 (cache.state_ @Y)))
 (= ?x293 (ite (and (= @Y __src)) invalid (__cache.state_ @Y)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x332 (not (= (__cache.state_ __src) exclusive))))
 (let (($x330 (= __src real_owner)))
 (or $x330 $x332))))
(assert
 (let (($x336 (not (= (__cache.state_ @X) exclusive))))
 (let (($x334 (= @X real_owner)))
 (or $x334 $x336))))
(assert
 (let (($x340 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x338 (= @Y real_owner)))
 (or $x338 $x340))))
(assert
 (let (($x332 (not (= (__cache.state_ __src) exclusive))))
 (or (= __src dir.hptr) $x332)))
(assert
 (let (($x336 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x336)))
(assert
 (let (($x340 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x340)))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x272 (= ?x271 shared)))
 (let (($x348 (not $x272)))
 (let (($x330 (= __src real_owner)))
 (or $x330 $x348))))))
(assert
 (let (($x351 (not (= (__cache.state_ @X) shared))))
 (let (($x334 (= @X real_owner)))
 (or $x334 $x351))))
(assert
 (let (($x354 (not (= (__cache.state_ @Y) shared))))
 (let (($x338 (= @Y real_owner)))
 (or $x338 $x354))))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x272 (= ?x271 shared)))
 (let (($x348 (not $x272)))
 (or (not (__rp_net __src)) $x348)))))
(assert
 (let (($x351 (not (= (__cache.state_ @X) shared))))
 (or (not (__rp_net @X)) $x351)))
(assert
 (let (($x354 (not (= (__cache.state_ @Y) shared))))
 (or (not (__rp_net @Y)) $x354)))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x272 (= ?x271 shared)))
 (let (($x348 (not $x272)))
 (let (($x366 (not (invack __src))))
 (or $x366 $x348))))))
(assert
 (let (($x351 (not (= (__cache.state_ @X) shared))))
 (let (($x369 (not (invack @X))))
 (or $x369 $x351))))
(assert
 (let (($x354 (not (= (__cache.state_ @Y) shared))))
 (let (($x372 (not (invack @Y))))
 (or $x372 $x354))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378))))
(assert
 (let (($x382 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x380 (not $x58)))
 (or $x380 $x382)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x380 (not $x58)))
 (or $x380 dir.head))))
(assert
 (let (($x387 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x387))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x389 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x389 $x378)))))
(assert
 (let (($x387 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x391 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x391 $x387)))))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x394 (= ?x271 invalid)))
 (let (($x330 (= __src real_owner)))
 (or (dir.real __src) $x330 $x394)))))
(assert
 (let ((?x320 (__cache.state_ @X)))
 (let (($x397 (= ?x320 invalid)))
 (let (($x334 (= @X real_owner)))
 (or (dir.real @X) $x334 $x397)))))
(assert
 (let ((?x325 (__cache.state_ @Y)))
 (let (($x400 (= ?x325 invalid)))
 (let (($x338 (= @Y real_owner)))
 (or (dir.real @Y) $x338 $x400)))))
(assert
 (let ((?x385 (__cache.state_ dir.hptr)))
 (let (($x403 (= ?x385 invalid)))
 (let (($x145 (= dir.hptr real_owner)))
 (or (dir.real dir.hptr) $x145 $x403)))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x375))))
(assert
 (let (($x142 (not (= (cache.wait real_owner) get))))
 (let (($x408 (not (= (__cache.state_ real_owner) shared))))
 (or $x408 $x142))))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x272 (= ?x271 shared)))
 (let (($x348 (not $x272)))
 (or $x348 (not (= (cache.wait __src) get)))))))
(assert
 (let (($x351 (not (= (__cache.state_ @X) shared))))
 (or $x351 (not (= (cache.wait @X) get)))))
(assert
 (let (($x354 (not (= (__cache.state_ @Y) shared))))
 (or $x354 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x366 (not (invack __src))))
 (let ((?x271 (__cache.state_ __src)))
 (let (($x394 (= ?x271 invalid)))
 (or $x394 $x366)))))
(assert
 (let (($x369 (not (invack @X))))
 (let ((?x320 (__cache.state_ @X)))
 (let (($x397 (= ?x320 invalid)))
 (or $x397 $x369)))))
(assert
 (let (($x372 (not (invack @Y))))
 (let ((?x325 (__cache.state_ @Y)))
 (let (($x400 (= ?x325 invalid)))
 (or $x400 $x372)))))
(assert
 (let (($x332 (not (= (__cache.state_ __src) exclusive))))
 (or $x332 dir.head)))
(assert
 (let (($x336 (not (= (__cache.state_ @X) exclusive))))
 (or $x336 dir.head)))
(assert
 (let (($x340 (not (= (__cache.state_ @Y) exclusive))))
 (or $x340 dir.head)))
(assert
 (let (($x387 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x387 dir.head)))
(assert
 (let (($x427 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x427 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x429 (= home home)))
 (or $x429 $x187))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x375)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x378)))))
(assert
 (let (($x382 (not (net.get dir.hptr home))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x382)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let ((?x385 (__cache.state_ dir.hptr)))
 (let (($x403 (= ?x385 invalid)))
 (or $x403 $x378)))))
(assert
 (let (($x382 (not (net.get dir.hptr home))))
 (let ((?x385 (__cache.state_ dir.hptr)))
 (let (($x403 (= ?x385 invalid)))
 (or $x403 $x382)))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x375)))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x439 (= ?x140 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let ((?x273 (cache.wait __src)))
 (let (($x443 (= ?x273 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let ((?x290 (cache.wait @X)))
 (let (($x447 (= ?x290 getX)))
 (or $x447 $x449)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let ((?x295 (cache.wait @Y)))
 (let (($x451 (= ?x295 getX)))
 (or $x451 $x453)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x456)))))
(assert
 (let (($x427 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x427 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x332 (not (= (__cache.state_ __src) exclusive))))
 (or $x332 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x336 (not (= (__cache.state_ @X) exclusive))))
 (or $x336 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x340 (not (= (__cache.state_ @Y) exclusive))))
 (or $x340 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x387 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x387 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x469 (not (__rp_net dir.hptr))))
 (let (($x378 (not (net.put home dir.hptr))))
 (or $x378 $x469))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x378)))))
(assert
 (let (($x382 (not (net.get dir.hptr home))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x382)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x378)))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x375)))))
(assert
 (let (($x382 (not (net.get dir.hptr home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x382)))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x441)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x445)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x449)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x453)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x456)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x472)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x378 dir.dirty))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x375 dir.head))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x375 dir.dirty))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x375))))
(assert
 (let (($x382 (not (net.get dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x382 dir.head))))
(assert
 (let (($x382 (not (net.get dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x382 dir.dirty))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x441 dir.head))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x445 dir.head))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x449 dir.head))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or $x429 $x453 dir.head))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x456 dir.head))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x472 dir.head))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x441 dir.dirty))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x445 dir.dirty))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x449 dir.dirty))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or $x429 $x453 dir.dirty))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x456 dir.dirty))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x472 dir.dirty))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or $x429 $x441))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or $x429 $x445))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or $x429 $x449))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or $x429 $x453))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (or $x429 $x456))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or $x429 $x472))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let (($x429 (= home home)))
 (or (= real_owner requester) $x429 $x441))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let (($x429 (= home home)))
 (or (= __src requester) $x429 $x445))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let (($x429 (= home home)))
 (or (= @X requester) $x429 $x449))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let (($x429 (= home home)))
 (or (= @Y requester) $x429 $x453))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let (($x429 (= home home)))
 (let (($x391 (= dir.hptr requester)))
 (or $x391 $x429 $x456)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let (($x429 (= home home)))
 (or (= home requester) $x429 $x472))))
(assert
 (let (($x387 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x387))))
(assert
 (let (($x427 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x519 (= real_owner real_owner)))
 (or $x519 $x427))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x521 (= dir.hptr dir.hptr)))
 (or $x521 $x375))))
(assert
 (let (($x387 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x521 (= dir.hptr dir.hptr)))
 (or $x521 $x387))))
(assert
 (let (($x427 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x524 (= real_owner dir.hptr)))
 (or $x524 $x427))))
(assert
 (let (($x527 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x527))))
(assert
 (let (($x408 (not (= (__cache.state_ real_owner) shared))))
 (let (($x519 (= real_owner real_owner)))
 (or $x519 $x408))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x429 (= home home)))
 (or $x429 $x375))))
(assert
 (let (($x527 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x469 (not (__rp_net dir.hptr))))
 (or $x469 $x527))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x524 (= real_owner dir.hptr)))
 (or $x524 $x375))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (or $x378 dir.head)))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (or $x375 dir.head)))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (or $x375 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (or $x375 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x469 (not (__rp_net dir.hptr))))
 (let (($x378 (not (net.put home dir.hptr))))
 (or $x378 $x469))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.get home home)))
(assert
 (let (($x366 (not (invack __src))))
 (or $x366 (not (invnet __src)))))
(assert
 (let (($x369 (not (invack @X))))
 (or $x369 (not (invnet @X)))))
(assert
 (let (($x372 (not (invack @Y))))
 (or $x372 (not (invnet @Y)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378 dir.pending))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x538 dir.pending))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378 dir.dirty))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x538 dir.dirty))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x538))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x389 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x389 $x538)))))
(assert
 (let (($x527 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x527 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x536)))))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x439 (= ?x140 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (let ((?x273 (cache.wait __src)))
 (let (($x443 (= ?x273 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (let ((?x290 (cache.wait @X)))
 (let (($x447 (= ?x290 getX)))
 (or $x447 $x449)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (let ((?x295 (cache.wait @Y)))
 (let (($x451 (= ?x295 getX)))
 (or $x451 $x453)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x432 (= ?x431 getX)))
 (or $x432 $x456)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let ((?x559 (cache.wait home)))
 (let (($x560 (= ?x559 getX)))
 (or $x560 $x472)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let ((?x431 (cache.wait dir.hptr)))
 (let (($x434 (= ?x431 get)))
 (or $x434 $x538)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let ((?x559 (cache.wait home)))
 (let (($x563 (= ?x559 get)))
 (or $x563 $x540)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let ((?x385 (__cache.state_ dir.hptr)))
 (let (($x403 (= ?x385 invalid)))
 (or $x403 $x538)))))
(assert
 (let (($x540 (not (net.get home home))))
 (or (= (__cache.state_ home) invalid) $x540)))
(assert
 (let (($x441 (not (net.getX real_owner home))))
 (or $x441 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x445 (not (net.getX __src home))))
 (or $x445 (not (= (cache.wait __src) none)))))
(assert
 (let (($x449 (not (net.getX @X home))))
 (or $x449 (not (= (cache.wait @X) none)))))
(assert
 (let (($x453 (not (net.getX @Y home))))
 (or $x453 (not (= (cache.wait @Y) none)))))
(assert
 (let (($x456 (not (net.getX dir.hptr home))))
 (or $x456 (not (= (cache.wait dir.hptr) none)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (or $x472 (not (= (cache.wait home) none)))))
(assert
 (let (($x472 (not (net.getX home home))))
 (let ((?x559 (cache.wait home)))
 (let (($x560 (= ?x559 getX)))
 (or $x560 $x472)))))
(assert
 (let (($x585 (not (= (__cache.state_ home) exclusive))))
 (or $x585 (not (= (cache.wait home) getX)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let ((?x559 (cache.wait home)))
 (let (($x563 (= ?x559 get)))
 (or $x563 $x540)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x389 (= dir.hptr home)))
 (or $x389 $x145 $x538)))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x519 (= real_owner real_owner)))
 (let (($x589 (= real_owner home)))
 (or $x589 $x519 $x536)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let (($x473 (= home real_owner)))
 (let (($x429 (= home home)))
 (or $x429 $x473 $x540)))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (let (($x389 (= dir.hptr home)))
 (or $x389 $x538 dir.dirty))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x589 (= real_owner home)))
 (or $x589 $x536 dir.head))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x589 (= real_owner home)))
 (or $x589 $x536 dir.dirty))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x589 (= real_owner home)))
 (or $x589 $x536))))
(assert
 (let (($x540 (not (net.get home home))))
 (let (($x429 (= home home)))
 (or $x429 $x540 dir.head))))
(assert
 (let (($x540 (not (net.get home home))))
 (let (($x429 (= home home)))
 (or $x429 $x540 dir.dirty))))
(assert
 (let (($x585 (not (= (__cache.state_ home) exclusive))))
 (let (($x473 (= home real_owner)))
 (or $x473 $x585))))
(assert
 (let (($x585 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x585)))
(assert
 (let (($x602 (not (= (__cache.state_ home) shared))))
 (let (($x473 (= home real_owner)))
 (or $x473 $x602))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x589 (= real_owner home)))
 (or $x589 $x536))))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (let (($x524 (= real_owner dir.hptr)))
 (or $x524 $x536))))
(assert
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (or $x538 dir.head)))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (or $x536 dir.head)))
(assert
 (let (($x536 (not (net.putX real_owner dir.hptr))))
 (or $x536 dir.dirty)))
(assert
 (let (($x469 (not (__rp_net dir.hptr))))
 (let (($x538 (not (net.put dir.hptr dir.hptr))))
 (or $x538 $x469))))
(assert
 (let (($x602 (not (= (__cache.state_ home) shared))))
 (or $x602 (not (= (cache.wait home) get)))))
(assert
 (let (($x585 (not (= (__cache.state_ home) exclusive))))
 (or $x585 dir.head)))
(check-sat)
