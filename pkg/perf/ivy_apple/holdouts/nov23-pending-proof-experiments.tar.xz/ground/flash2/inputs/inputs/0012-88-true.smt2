(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun __real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun real_owner () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun __net.fack (id id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun __net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (cache.wait __real_owner) get)))
(assert
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (__net.fack requester home)))
(assert
 (__net.getX __src __dst))
(assert
 (not (= __dst __src)))
(assert
 (let (($x275 (= __dst home)))
 (not $x275)))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (= ?x277 exclusive)))
(assert
 (= real_owner __src))
(assert
 (= __ts0_a (not (= __src home))))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x311 (cache.state_ @X)))
 (= ?x311 (ite (and (= @X __dst)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x316 (cache.state_ @Y)))
 (= ?x316 (ite (and (= @Y __dst)) invalid (__cache.state_ @Y)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x352 (not $x272)))
 (let (($x351 (= __dst __real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x351 $x352))))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x352 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x352 dir.head)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x352 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x352 dir.dirty)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x352 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x352)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x352 (not $x272)))
 (let (($x275 (= __dst home)))
 (let (($x357 (= __src requester)))
 (or $x357 $x275 $x352))))))
(assert
 (let (($x187 (not (__net.fack requester home))))
 (or (= requester __real_owner) $x187)))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x278 (= ?x277 exclusive)))
 (let (($x361 (not $x278)))
 (let (($x351 (= __dst __real_owner)))
 (or $x351 $x361))))))
(assert
 (let (($x365 (not (= (__cache.state_ @X) exclusive))))
 (let (($x363 (= @X __real_owner)))
 (or $x363 $x365))))
(assert
 (let (($x369 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x367 (= @Y __real_owner)))
 (or $x367 $x369))))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x278 (= ?x277 exclusive)))
 (let (($x361 (not $x278)))
 (or (= __dst dir.hptr) $x361)))))
(assert
 (let (($x365 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x365)))
(assert
 (let (($x369 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x369)))
(assert
 (let (($x378 (not (= (__cache.state_ __dst) shared))))
 (let (($x351 (= __dst __real_owner)))
 (or $x351 $x378))))
(assert
 (let (($x381 (not (= (__cache.state_ @X) shared))))
 (let (($x363 (= @X __real_owner)))
 (or $x363 $x381))))
(assert
 (let (($x384 (not (= (__cache.state_ @Y) shared))))
 (let (($x367 (= @Y __real_owner)))
 (or $x367 $x384))))
(assert
 (let (($x378 (not (= (__cache.state_ __dst) shared))))
 (or (not (rp_net __dst)) $x378)))
(assert
 (let (($x381 (not (= (__cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x381)))
(assert
 (let (($x384 (not (= (__cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x384)))
(assert
 (let (($x378 (not (= (__cache.state_ __dst) shared))))
 (let (($x396 (not (invack __dst))))
 (or $x396 $x378))))
(assert
 (let (($x381 (not (= (__cache.state_ @X) shared))))
 (let (($x399 (not (invack @X))))
 (or $x399 $x381))))
(assert
 (let (($x384 (not (= (__cache.state_ @Y) shared))))
 (let (($x402 (not (invack @Y))))
 (or $x402 $x384))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x405))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408))))
(assert
 (let (($x412 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x410 (not $x58)))
 (or $x410 $x412)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x410 (not $x58)))
 (or $x410 dir.head))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x417))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x419 $x408)))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (= dir.hptr requester) $x417))))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x424 (= ?x277 invalid)))
 (let (($x351 (= __dst __real_owner)))
 (or (dir.real __dst) $x351 $x424)))))
(assert
 (let ((?x343 (__cache.state_ @X)))
 (let (($x427 (= ?x343 invalid)))
 (let (($x363 (= @X __real_owner)))
 (or (dir.real @X) $x363 $x427)))))
(assert
 (let ((?x348 (__cache.state_ @Y)))
 (let (($x430 (= ?x348 invalid)))
 (let (($x367 (= @Y __real_owner)))
 (or (dir.real @Y) $x367 $x430)))))
(assert
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (let (($x145 (= dir.hptr __real_owner)))
 (or (dir.real dir.hptr) $x145 $x433)))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 $x405))))
(assert
 (let (($x142 (not (= (cache.wait __real_owner) get))))
 (let (($x438 (not (= (__cache.state_ __real_owner) shared))))
 (or $x438 $x142))))
(assert
 (let (($x381 (not (= (__cache.state_ @X) shared))))
 (or $x381 (not (= (cache.wait @X) get)))))
(assert
 (let (($x384 (not (= (__cache.state_ @Y) shared))))
 (or $x384 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x396 (not (invack __dst))))
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x424 (= ?x277 invalid)))
 (or $x424 $x396)))))
(assert
 (let (($x399 (not (invack @X))))
 (let ((?x343 (__cache.state_ @X)))
 (let (($x427 (= ?x343 invalid)))
 (or $x427 $x399)))))
(assert
 (let (($x402 (not (invack @Y))))
 (let ((?x348 (__cache.state_ @Y)))
 (let (($x430 (= ?x348 invalid)))
 (or $x430 $x402)))))
(assert
 (let ((?x277 (__cache.state_ __dst)))
 (let (($x278 (= ?x277 exclusive)))
 (let (($x361 (not $x278)))
 (or $x361 dir.head)))))
(assert
 (let (($x365 (not (= (__cache.state_ @X) exclusive))))
 (or $x365 dir.head)))
(assert
 (let (($x369 (not (= (__cache.state_ @Y) exclusive))))
 (or $x369 dir.head)))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x417 dir.head)))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x454 dir.head)))
(assert
 (let (($x187 (not (__net.fack requester home))))
 (let (($x456 (= home home)))
 (or $x456 $x187))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x405)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x352 (not $x272)))
 (let ((?x461 (cache.wait __src)))
 (let (($x462 (= ?x461 getX)))
 (or $x462 $x352))))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x464 (= ?x458 get)))
 (or $x464 $x408)))))
(assert
 (let (($x412 (not (net.get dir.hptr home))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x464 (= ?x458 get)))
 (or $x464 $x412)))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (or $x433 $x408)))))
(assert
 (let (($x412 (not (net.get dir.hptr home))))
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (or $x433 $x412)))))
(assert
 (let (($x470 (not (= (cache.wait __src) none))))
 (let (($x272 (__net.getX __src __dst)))
 (let (($x352 (not $x272)))
 (or $x352 $x470)))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x405)))))
(assert
 (let (($x473 (not (__net.getX __src home))))
 (let ((?x461 (cache.wait __src)))
 (let (($x462 (= ?x461 getX)))
 (or $x462 $x473)))))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x454 (not (= (cache.wait __real_owner) getX)))))
(assert
 (let (($x365 (not (= (__cache.state_ @X) exclusive))))
 (or $x365 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x369 (not (= (__cache.state_ @Y) exclusive))))
 (or $x369 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x417 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x488 (not (= (__cache.state_ __src) exclusive))))
 (or $x488 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x492 (not (rp_net dir.hptr))))
 (let (($x408 (not (net.put home dir.hptr))))
 (or $x408 $x492))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x464 (= ?x458 get)))
 (or $x464 $x408)))))
(assert
 (let (($x412 (not (net.get dir.hptr home))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x464 (= ?x458 get)))
 (or $x464 $x412)))))
(assert
 (not (__net.getX home __dst)))
(assert
 (not (__net.getX home home)))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let (($x498 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x498 $x408)))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x498 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x498 $x405)))))
(assert
 (let (($x412 (not (net.get dir.hptr home))))
 (let (($x498 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x498 $x412)))))
(assert
 (let (($x473 (not (__net.getX __src home))))
 (let (($x498 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x498 $x473)))))
(assert
 (let (($x495 (not (__net.getX home __dst))))
 (let (($x351 (= __dst __real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x351 $x495)))))
(assert
 (let (($x497 (not (__net.getX home home))))
 (let (($x498 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x498 $x497)))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x408 dir.dirty))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405 dir.head))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405 dir.dirty))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405))))
(assert
 (let (($x412 (not (net.get dir.hptr home))))
 (let (($x456 (= home home)))
 (or $x456 $x412 dir.head))))
(assert
 (let (($x412 (not (net.get dir.hptr home))))
 (let (($x456 (= home home)))
 (or $x456 $x412 dir.dirty))))
(assert
 (let (($x473 (not (__net.getX __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x473 dir.head))))
(assert
 (let (($x495 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x495 dir.head))))
(assert
 (let (($x497 (not (__net.getX home home))))
 (let (($x456 (= home home)))
 (or $x456 $x497 dir.head))))
(assert
 (let (($x473 (not (__net.getX __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x473 dir.dirty))))
(assert
 (let (($x495 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x495 dir.dirty))))
(assert
 (let (($x497 (not (__net.getX home home))))
 (let (($x456 (= home home)))
 (or $x456 $x497 dir.dirty))))
(assert
 (let (($x473 (not (__net.getX __src home))))
 (let (($x456 (= home home)))
 (or $x456 $x473))))
(assert
 (let (($x495 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x495))))
(assert
 (let (($x497 (not (__net.getX home home))))
 (let (($x456 (= home home)))
 (or $x456 $x497))))
(assert
 (let (($x473 (not (__net.getX __src home))))
 (let (($x456 (= home home)))
 (let (($x357 (= __src requester)))
 (or $x357 $x456 $x473)))))
(assert
 (let (($x495 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (let (($x521 (= home requester)))
 (or $x521 $x275 $x495)))))
(assert
 (let (($x497 (not (__net.getX home home))))
 (let (($x456 (= home home)))
 (let (($x521 (= home requester)))
 (or $x521 $x456 $x497)))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 $x417))))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x525 (= __real_owner __real_owner)))
 (or $x525 $x454))))
(assert
 (let (($x488 (not (= (__cache.state_ __src) exclusive))))
 (let (($x527 (= __src __real_owner)))
 (or $x527 $x488))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x529 (= dir.hptr dir.hptr)))
 (or $x529 $x405))))
(assert
 (let (($x417 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x529 (= dir.hptr dir.hptr)))
 (or $x529 $x417))))
(assert
 (let (($x454 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x532 (= __real_owner dir.hptr)))
 (or $x532 $x454))))
(assert
 (let (($x488 (not (= (__cache.state_ __src) exclusive))))
 (or (= __src dir.hptr) $x488)))
(assert
 (let (($x537 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr __real_owner)))
 (or $x145 $x537))))
(assert
 (let (($x438 (not (= (__cache.state_ __real_owner) shared))))
 (let (($x525 (= __real_owner __real_owner)))
 (or $x525 $x438))))
(assert
 (let (($x541 (not (= (__cache.state_ __src) shared))))
 (let (($x527 (= __src __real_owner)))
 (or $x527 $x541))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x456 (= home home)))
 (or $x456 $x405))))
(assert
 (let (($x537 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x492 (not (rp_net dir.hptr))))
 (or $x492 $x537))))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (let (($x532 (= __real_owner dir.hptr)))
 (or $x532 $x405))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (or $x408 dir.head)))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (or $x405 dir.head)))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (or $x405 dir.dirty)))
(assert
 (not (__net.putX __real_owner dir.hptr)))
(assert
 (let (($x405 (not (__net.putX home dir.hptr))))
 (or $x405 dir.head)))
(assert
 (not (__net.putX home dir.hptr)))
(assert
 (let (($x492 (not (rp_net dir.hptr))))
 (let (($x408 (not (net.put home dir.hptr))))
 (or $x408 $x492))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.get home home)))
(assert
 (let (($x396 (not (invack __dst))))
 (or $x396 (not (invnet __dst)))))
(assert
 (let (($x399 (not (invack @X))))
 (or $x399 (not (invnet @X)))))
(assert
 (let (($x402 (not (invack @Y))))
 (or $x402 (not (invnet @Y)))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408 dir.pending))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x551 dir.pending))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408 dir.dirty))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x551 dir.dirty))))
(assert
 (let (($x408 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x408))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x551))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x419 $x551)))))
(assert
 (let (($x537 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x537 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x541 (not (= (__cache.state_ __src) shared))))
 (or $x541 (not (= (cache.wait __src) get)))))
(assert
 (let (($x488 (not (= (__cache.state_ __src) exclusive))))
 (or $x488 dir.head)))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x459 (= ?x458 getX)))
 (or $x459 $x549)))))
(assert
 (let (($x473 (not (__net.getX __src home))))
 (let ((?x461 (cache.wait __src)))
 (let (($x462 (= ?x461 getX)))
 (or $x462 $x473)))))
(assert
 (let (($x495 (not (__net.getX home __dst))))
 (let ((?x576 (cache.wait home)))
 (let (($x577 (= ?x576 getX)))
 (or $x577 $x495)))))
(assert
 (let (($x497 (not (__net.getX home home))))
 (let ((?x576 (cache.wait home)))
 (let (($x577 (= ?x576 getX)))
 (or $x577 $x497)))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let ((?x458 (cache.wait dir.hptr)))
 (let (($x464 (= ?x458 get)))
 (or $x464 $x551)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let ((?x576 (cache.wait home)))
 (let (($x581 (= ?x576 get)))
 (or $x581 $x553)))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let ((?x415 (__cache.state_ dir.hptr)))
 (let (($x433 (= ?x415 invalid)))
 (or $x433 $x551)))))
(assert
 (let (($x553 (not (net.get home home))))
 (or (= (__cache.state_ home) invalid) $x553)))
(assert
 (let (($x470 (not (= (cache.wait __src) none))))
 (let (($x473 (not (__net.getX __src home))))
 (or $x473 $x470))))
(assert
 (let (($x589 (not (= (cache.wait home) none))))
 (let (($x495 (not (__net.getX home __dst))))
 (or $x495 $x589))))
(assert
 (let (($x589 (not (= (cache.wait home) none))))
 (let (($x497 (not (__net.getX home home))))
 (or $x497 $x589))))
(assert
 (let (($x497 (not (__net.getX home home))))
 (let ((?x576 (cache.wait home)))
 (let (($x577 (= ?x576 getX)))
 (or $x577 $x497)))))
(assert
 (let (($x593 (not (= (__cache.state_ home) exclusive))))
 (or $x593 (not (= (cache.wait home) getX)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let ((?x576 (cache.wait home)))
 (let (($x581 (= ?x576 get)))
 (or $x581 $x553)))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr __real_owner)))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x145 $x551)))))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (let (($x525 (= __real_owner __real_owner)))
 (let (($x597 (= __real_owner home)))
 (or $x597 $x525 $x549)))))
(assert
 (let (($x553 (not (net.get home home))))
 (let (($x498 (= home __real_owner)))
 (let (($x456 (= home home)))
 (or $x456 $x498 $x553)))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (let (($x419 (= dir.hptr home)))
 (or $x419 $x551 dir.dirty))))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (let (($x597 (= __real_owner home)))
 (or $x597 $x549 dir.head))))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (let (($x597 (= __real_owner home)))
 (or $x597 $x549 dir.dirty))))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (let (($x597 (= __real_owner home)))
 (or $x597 $x549))))
(assert
 (let (($x553 (not (net.get home home))))
 (let (($x456 (= home home)))
 (or $x456 $x553 dir.head))))
(assert
 (let (($x553 (not (net.get home home))))
 (let (($x456 (= home home)))
 (or $x456 $x553 dir.dirty))))
(assert
 (let (($x593 (not (= (__cache.state_ home) exclusive))))
 (let (($x498 (= home __real_owner)))
 (or $x498 $x593))))
(assert
 (let (($x593 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x593)))
(assert
 (let (($x610 (not (= (__cache.state_ home) shared))))
 (let (($x498 (= home __real_owner)))
 (or $x498 $x610))))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (let (($x597 (= __real_owner home)))
 (or $x597 $x549))))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (let (($x532 (= __real_owner dir.hptr)))
 (or $x532 $x549))))
(assert
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (or $x551 dir.head)))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (or $x549 dir.head)))
(assert
 (let (($x549 (not (__net.putX __real_owner dir.hptr))))
 (or $x549 dir.dirty)))
(assert
 (let (($x492 (not (rp_net dir.hptr))))
 (let (($x551 (not (net.put dir.hptr dir.hptr))))
 (or $x551 $x492))))
(assert
 (let (($x610 (not (= (__cache.state_ home) shared))))
 (or $x610 (not (= (cache.wait home) get)))))
(assert
 (let (($x593 (not (= (__cache.state_ home) exclusive))))
 (or $x593 dir.head)))
(check-sat)
