(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun __dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.shwb (id id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun __dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x56 (not dir.head)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x56))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not __dir.dirty) __dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__net.shwb __src home))
(assert
 (not dir.pending))
(assert
 (not dir.dirty))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x378 (not (net.getX home @Y))))
 (let (($x357 (not (net.getX @X @Z))))
 (let (($x365 (not (net.getX @X @Y))))
 (let (($x366 (= @Y @Z)))
 (let (($x379 (and (or $x366 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x366 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x366 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x366 $x365 $x357) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x357 (not (net.putX @Y @X))) $x378 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x338 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x379)))))))))
(assert
 (let (($x351 (dir.shlist dir.hptr)))
 (= $x351 (ite (and (= dir.hptr __src)) true (__dir.shlist dir.hptr)))))
(assert
 (let (($x406 (__net.shwb @X @Y)))
 (let (($x319 (net.shwb @X @Y)))
 (= $x319 (ite (and (= @X __src) (= @Y home)) false $x406)))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x409 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x409 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x412 (= @Z real_owner)))
 (let (($x411 (= @Z home)))
 (or $x411 $x412 $x375)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x417 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x417 $x306)))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x409 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x409 $x354)))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x412 (= @Z real_owner)))
 (let (($x411 (= @Z home)))
 (or $x411 $x412 $x369)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x329)))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x417 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x417 $x300)))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let (($x409 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x409 $x372)))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let (($x412 (= @Z real_owner)))
 (let (($x411 (= @Z home)))
 (or $x411 $x412 $x362)))))
(assert
 (let (($x349 (not (net.get @X home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x349)))))
(assert
 (let (($x310 (not (net.get @V0 @V1))))
 (let (($x417 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x417 $x310)))))
(assert
 (let (($x365 (not (net.getX @X @Y))))
 (let (($x409 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x409 $x365)))))
(assert
 (let (($x357 (not (net.getX @X @Z))))
 (let (($x412 (= @Z real_owner)))
 (let (($x411 (= @Z home)))
 (or $x411 $x412 $x357)))))
(assert
 (let (($x378 (not (net.getX home @Y))))
 (let (($x409 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x409 $x378)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x334)))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x432 (= @V0 real_owner)))
 (let (($x431 (= @V0 home)))
 (or $x431 $x432 $x323)))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x417 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x417 $x303)))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x360 __dir.dirty))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x411 (= @Z home)))
 (or $x411 $x375 __dir.dirty))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x414 (= home home)))
 (or $x414 $x344 __dir.dirty))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x306 __dir.dirty))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x354 dir.head))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x411 (= @Z home)))
 (or $x411 $x369 dir.head))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x414 (= home home)))
 (or $x414 $x329 dir.head))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300 dir.head))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x354 __dir.dirty))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x411 (= @Z home)))
 (or $x411 $x369 __dir.dirty))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x414 (= home home)))
 (or $x414 $x329 __dir.dirty))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300 __dir.dirty))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x354))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x411 (= @Z home)))
 (or $x411 $x369))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x414 (= home home)))
 (or $x414 $x329))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x372 dir.head))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x362 dir.head))))
(assert
 (let (($x349 (not (net.get @X home))))
 (let (($x414 (= home home)))
 (or $x414 $x349 dir.head))))
(assert
 (let (($x310 (not (net.get @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x310 dir.head))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x372 __dir.dirty))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x362 __dir.dirty))))
(assert
 (let (($x349 (not (net.get @X home))))
 (let (($x414 (= home home)))
 (or $x414 $x349 __dir.dirty))))
(assert
 (let (($x310 (not (net.get @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x310 __dir.dirty))))
(assert
 (let (($x365 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x365 dir.head))))
(assert
 (let (($x357 (not (net.getX @X @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x357 dir.head))))
(assert
 (let (($x378 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x378 dir.head))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x414 (= home home)))
 (or $x414 $x334 dir.head))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x431 (= @V0 home)))
 (or $x431 $x323 dir.head))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x303 dir.head))))
(assert
 (let (($x365 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x365 __dir.dirty))))
(assert
 (let (($x357 (not (net.getX @X @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x357 __dir.dirty))))
(assert
 (let (($x378 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x378 __dir.dirty))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x414 (= home home)))
 (or $x414 $x334 __dir.dirty))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x431 (= @V0 home)))
 (or $x431 $x323 __dir.dirty))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x303 __dir.dirty))))
(assert
 (let (($x365 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x365))))
(assert
 (let (($x357 (not (net.getX @X @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x357))))
(assert
 (let (($x378 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x378))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x414 (= home home)))
 (or $x414 $x334))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x431 (= @V0 home)))
 (or $x431 $x323))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x303))))
(assert
 (let (($x365 (not (net.getX @X @Y))))
 (let (($x317 (= @Y home)))
 (let (($x477 (= @X requester)))
 (or $x477 $x317 $x365)))))
(assert
 (let (($x357 (not (net.getX @X @Z))))
 (let (($x411 (= @Z home)))
 (let (($x477 (= @X requester)))
 (or $x477 $x411 $x357)))))
(assert
 (let (($x378 (not (net.getX home @Y))))
 (let (($x317 (= @Y home)))
 (let (($x480 (= home requester)))
 (or $x480 $x317 $x378)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let (($x414 (= home home)))
 (let (($x477 (= @X requester)))
 (or $x477 $x414 $x334)))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let (($x431 (= @V0 home)))
 (let (($x483 (= @V1 requester)))
 (or $x483 $x431 $x323)))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x485 (= @V0 requester)))
 (or $x485 $x292 $x303)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x295 (not (net.fack @V0 @V1))))
 (let (($x432 (= @V0 real_owner)))
 (or $x432 $x295))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x490 (= @X real_owner)))
 (or $x490 $x338))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) exclusive))))
 (let (($x432 (= @V0 real_owner)))
 (or $x432 $x493))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x495 (= @X dir.hptr)))
 (or $x495 $x329))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x497 (= @V0 dir.hptr)))
 (or $x497 $x499))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x495 (= @X dir.hptr)))
 (or $x495 $x338))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) exclusive))))
 (let (($x497 (= @V0 dir.hptr)))
 (or $x497 $x493))))
(assert
 (let (($x504 (not (= (cache.state_ @X) shared))))
 (let (($x490 (= @X real_owner)))
 (or $x490 $x504))))
(assert
 (let (($x507 (not (= (cache.state_ @V0) shared))))
 (let (($x432 (= @V0 real_owner)))
 (or $x432 $x507))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x317 (= @Y home)))
 (or $x317 $x354))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x411 (= @Z home)))
 (or $x411 $x369))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x414 (= home home)))
 (or $x414 $x329))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x300))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x414 (= home home)))
 (or $x414 $x499))))
(assert
 (let (($x504 (not (= (cache.state_ @X) shared))))
 (let (($x342 (not (rp_net @X))))
 (or $x342 $x504))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x354))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x369))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x329))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let (($x515 (= real_owner @V0)))
 (or $x515 $x300))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x515 (= real_owner @V0)))
 (or $x515 $x499))))
(assert
 (let (($x271 (__net.shwb __src home)))
 (not $x271)))
(assert
 (not (__net.shwb @X home)))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (or $x360 dir.head)))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (or $x375 dir.head)))
(assert
 (let (($x344 (not (net.put home @X))))
 (or $x344 dir.head)))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (or $x306 dir.head)))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (or $x354 dir.head)))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (or $x369 dir.head)))
(assert
 (let (($x329 (not (net.putX home @X))))
 (or $x329 dir.head)))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (or $x300 dir.head)))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (or $x499 dir.head)))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (or $x354 __dir.dirty)))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (or $x369 __dir.dirty)))
(assert
 (let (($x329 (not (net.putX home @X))))
 (or $x329 __dir.dirty)))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (or $x300 __dir.dirty)))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (or $x499 __dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x329 (not (net.putX home @X))))
 (or $x329 dir.head)))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (or $x499 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x360 (not (net.put @Y @X))))
 (or $x360 $x342))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x375 (not (net.put @Z @X))))
 (or $x375 $x342))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x344 (not (net.put home @X))))
 (or $x344 $x342))))
(assert
 (let (($x542 (not (rp_net @V0))))
 (let (($x306 (not (net.put @V1 @V0))))
 (or $x306 $x542))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x504 (not (= (cache.state_ @X) shared))))
 (let (($x559 (not (invack @X))))
 (or $x559 $x504))))
(assert
 (let (($x507 (not (= (cache.state_ @V0) shared))))
 (let (($x562 (not (invack @V0))))
 (or $x562 $x507))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x360 __dir.pending))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x375 __dir.pending))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x344 __dir.pending))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x306 __dir.pending))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x545 __dir.pending))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x547 __dir.pending))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x549 __dir.pending))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x360 __dir.dirty))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x375 __dir.dirty))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x344 __dir.dirty))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x306 __dir.dirty))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x545 __dir.dirty))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x547 __dir.dirty))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x549 __dir.dirty))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x360))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x375))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x344))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x306))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x545))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x547))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x549))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x588))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x329))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x499))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x593))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x344))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x545))))
(assert
 (let (($x597 (not (net.get dir.hptr home))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (let (($x595 (not $x58)))
 (or $x595 $x597)))))
(assert
 (let (($x349 (not (net.get @X home))))
 (let (($x564 (__dir.shlist @X)))
 (let (($x599 (not $x564)))
 (or $x599 $x349)))))
(assert
 (let (($x603 (not (net.get @V0 home))))
 (let (($x568 (__dir.shlist @V0)))
 (let (($x601 (not $x568)))
 (or $x601 $x603)))))
(assert
 (let (($x58 (__dir.shlist dir.hptr)))
 (let (($x595 (not $x58)))
 (or $x595 dir.head))))
(assert
 (let (($x564 (__dir.shlist @X)))
 (let (($x599 (not $x564)))
 (or $x599 dir.head))))
(assert
 (let (($x568 (__dir.shlist @V0)))
 (let (($x601 (not $x568)))
 (or $x601 dir.head))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x338))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) exclusive))))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x493))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x610 (= @X home)))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x610 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x610 (= @X home)))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x610 $x375)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let (($x610 (= @X home)))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x610 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let (($x431 (= @V0 home)))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x431 $x306)))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let (($x431 (= @V0 home)))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x431 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let (($x610 (= @X home)))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x610 $x547)))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let (($x431 (= @V0 home)))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x431 $x549)))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let (($x618 (= dir.hptr home)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x618 $x593)))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (let (($x477 (= @X requester)))
 (let (($x564 (__dir.shlist @X)))
 (or $x564 $x477 $x338)))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) exclusive))))
 (let (($x485 (= @V0 requester)))
 (let (($x568 (__dir.shlist @V0)))
 (or $x568 $x485 $x493)))))
(assert
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (let (($x490 (= @X real_owner)))
 (or (__dir.real @X) $x490 $x623)))))
(assert
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (let (($x432 (= @V0 real_owner)))
 (or (__dir.real @V0) $x432 $x313)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x329))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x499))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x588))))
(assert
 (let (($x504 (not (= (cache.state_ @X) shared))))
 (or $x504 (not (= (cache.wait @X) get)))))
(assert
 (let (($x507 (not (= (cache.state_ @V0) shared))))
 (or $x507 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x559 (not (invack @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x559)))))
(assert
 (let (($x562 (not (invack @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x562)))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (or $x338 dir.head)))
(assert
 (let (($x493 (not (= (cache.state_ @V0) exclusive))))
 (or $x493 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x414 (= home home)))
 (or $x414 $x187))))
(assert
 (let (($x295 (not (net.fack @V0 @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x295))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x354)))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x369)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x329)))))
(assert
 (let (($x300 (not (net.putX @V1 @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x300)))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x499)))))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x536)))))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x538)))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x588)))))
(assert
 (let (($x365 (not (net.getX @X @Y))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x365)))))
(assert
 (let (($x357 (not (net.getX @X @Z))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x357)))))
(assert
 (let (($x378 (not (net.getX home @Y))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x378)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x334)))))
(assert
 (let (($x323 (not (net.getX @V1 @V0))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x652 (= ?x324 getX)))
 (or $x652 $x323)))))
(assert
 (let (($x303 (not (net.getX @V0 @V1))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x303)))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x375)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x306)))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x547)))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x549)))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x659 (= ?x644 get)))
 (or $x659 $x593)))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x372)))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x362)))))
(assert
 (let (($x349 (not (net.get @X home))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x349)))))
(assert
 (let (($x310 (not (net.get @V0 @V1))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x310)))))
(assert
 (let (($x551 (not (net.get home @Y))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x551)))))
(assert
 (let (($x553 (not (net.get home @Z))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x553)))))
(assert
 (let (($x555 (not (net.get home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x555)))))
(assert
 (let (($x557 (not (net.get home @V1))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x557)))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x375)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x344)))))
(assert
 (let (($x306 (not (net.put @V1 @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x306)))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x547)))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x549)))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let ((?x674 (cache.state_ dir.hptr)))
 (let (($x675 (= ?x674 invalid)))
 (or $x675 $x593)))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x372)))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x362)))))
(assert
 (let (($x349 (not (net.get @X home))))
 (let ((?x336 (cache.state_ @X)))
 (let (($x623 (= ?x336 invalid)))
 (or $x623 $x349)))))
(assert
 (let (($x310 (not (net.get @V0 @V1))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x310)))))
(assert
 (let (($x551 (not (net.get home @Y))))
 (let ((?x680 (cache.state_ home)))
 (let (($x681 (= ?x680 invalid)))
 (or $x681 $x551)))))
(assert
 (let (($x553 (not (net.get home @Z))))
 (let ((?x680 (cache.state_ home)))
 (let (($x681 (= ?x680 invalid)))
 (or $x681 $x553)))))
(assert
 (let (($x555 (not (net.get home home))))
 (let ((?x680 (cache.state_ home)))
 (let (($x681 (= ?x680 invalid)))
 (or $x681 $x555)))))
(assert
 (let (($x557 (not (net.get home @V1))))
 (let ((?x680 (cache.state_ home)))
 (let (($x681 (= ?x680 invalid)))
 (or $x681 $x557)))))
(assert
 (let (($x414 (= home home)))
 (or $x414 (not (__net.shwb __src home)))))
(assert
 (let (($x317 (= @Y home)))
 (or $x317 (not (__net.shwb @X @Y)))))
(assert
 (let (($x414 (= home home)))
 (or $x414 (not (__net.shwb @X home)))))
(assert
 (let (($x691 (not (= (cache.wait @X) none))))
 (let (($x365 (not (net.getX @X @Y))))
 (or $x365 $x691))))
(assert
 (let (($x691 (not (= (cache.wait @X) none))))
 (let (($x357 (not (net.getX @X @Z))))
 (or $x357 $x691))))
(assert
 (let (($x695 (not (= (cache.wait home) none))))
 (let (($x378 (not (net.getX home @Y))))
 (or $x378 $x695))))
(assert
 (let (($x691 (not (= (cache.wait @X) none))))
 (let (($x334 (not (net.getX @X home))))
 (or $x334 $x691))))
(assert
 (let (($x326 (not (= (cache.wait @V1) none))))
 (let (($x323 (not (net.getX @V1 @V0))))
 (or $x323 $x326))))
(assert
 (let (($x699 (not (= (cache.wait @V0) none))))
 (let (($x303 (not (net.getX @V0 @V1))))
 (or $x303 $x699))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x701 (= ?x140 getX)))
 (or $x701 $x703)))))
(assert
 (let (($x329 (not (net.putX home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x329)))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x652 (= ?x324 getX)))
 (or $x652 $x706)))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x499)))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x588)))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x709)))))
(assert
 (let (($x334 (not (net.getX @X home))))
 (let ((?x330 (cache.wait @X)))
 (let (($x331 (= ?x330 getX)))
 (or $x331 $x334)))))
(assert
 (let (($x712 (not (net.getX home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x712)))))
(assert
 (let (($x715 (not (net.getX @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x652 (= ?x324 getX)))
 (or $x652 $x715)))))
(assert
 (let (($x718 (not (net.getX @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x718)))))
(assert
 (let (($x338 (not (= (cache.state_ @X) exclusive))))
 (or $x338 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) exclusive))))
 (or $x493 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x723 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x723 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x727 (not (= (cache.state_ home) exclusive))))
 (or $x727 (not (= (cache.wait home) getX)))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x344 (not (net.put home @X))))
 (or $x344 $x342))))
(assert
 (let (($x542 (not (rp_net @V0))))
 (let (($x545 (not (net.put home @V0))))
 (or $x545 $x542))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x732)))))
(assert
 (let (($x344 (not (net.put home @X))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x344)))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x734 (= ?x324 get)))
 (or $x734 $x736)))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x545)))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x659 (= ?x644 get)))
 (or $x659 $x593)))))
(assert
 (let (($x739 (not (net.put home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x739)))))
(assert
 (let (($x742 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x742)))))
(assert
 (let (($x349 (not (net.get @X home))))
 (let ((?x330 (cache.wait @X)))
 (let (($x346 (= ?x330 get)))
 (or $x346 $x349)))))
(assert
 (let (($x745 (not (net.get @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x734 (= ?x324 get)))
 (or $x734 $x745)))))
(assert
 (let (($x603 (not (net.get @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x603)))))
(assert
 (let (($x597 (not (net.get dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x659 (= ?x644 get)))
 (or $x659 $x597)))))
(assert
 (let (($x555 (not (net.get home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x555)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x545)))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x547)))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x549)))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x593)))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x732)))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x736)))))
(assert
 (let (($x739 (not (net.put home home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x739)))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x499)))))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x536)))))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x538)))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x588)))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x703)))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x706)))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x709)))))
(assert
 (let (($x551 (not (net.get home @Y))))
 (let (($x409 (= @Y real_owner)))
 (let (($x317 (= @Y home)))
 (or $x317 $x409 $x551)))))
(assert
 (let (($x553 (not (net.get home @Z))))
 (let (($x412 (= @Z real_owner)))
 (let (($x411 (= @Z home)))
 (or $x411 $x412 $x553)))))
(assert
 (let (($x555 (not (net.get home home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x555)))))
(assert
 (let (($x557 (not (net.get home @V1))))
 (let (($x417 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x417 $x557)))))
(assert
 (let (($x597 (not (net.get dir.hptr home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x597)))))
(assert
 (let (($x603 (not (net.get @V0 home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x603)))))
(assert
 (let (($x742 (not (net.get real_owner home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x742)))))
(assert
 (let (($x745 (not (net.get @V1 home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x745)))))
(assert
 (let (($x712 (not (net.getX home home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x712)))))
(assert
 (let (($x715 (not (net.getX @V1 home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x715)))))
(assert
 (let (($x718 (not (net.getX @V0 home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x718)))))
(assert
 (let (($x750 (not (net.getX home @Z))))
 (let (($x412 (= @Z real_owner)))
 (let (($x411 (= @Z home)))
 (or $x411 $x412 $x750)))))
(assert
 (let (($x752 (not (net.getX home @V0))))
 (let (($x432 (= @V0 real_owner)))
 (let (($x431 (= @V0 home)))
 (or $x431 $x432 $x752)))))
(assert
 (let (($x754 (not (net.getX home @V1))))
 (let (($x417 (= @V1 real_owner)))
 (let (($x292 (= @V1 home)))
 (or $x292 $x417 $x754)))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (let (($x414 (= home home)))
 (or $x414 $x545 __dir.dirty))))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x547 __dir.dirty))))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x549 __dir.dirty))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let (($x414 (= home home)))
 (or $x414 $x593 __dir.dirty))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let (($x414 (= home home)))
 (or $x414 $x732 __dir.dirty))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let (($x414 (= home home)))
 (or $x414 $x736 __dir.dirty))))
(assert
 (let (($x739 (not (net.put home home))))
 (let (($x414 (= home home)))
 (or $x414 $x739 __dir.dirty))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x414 (= home home)))
 (or $x414 $x499 dir.head))))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x536 dir.head))))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x538 dir.head))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x414 (= home home)))
 (or $x414 $x588 dir.head))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x414 (= home home)))
 (or $x414 $x703 dir.head))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x414 (= home home)))
 (or $x414 $x706 dir.head))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x414 (= home home)))
 (or $x414 $x709 dir.head))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x414 (= home home)))
 (or $x414 $x499 __dir.dirty))))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x536 __dir.dirty))))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x538 __dir.dirty))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x414 (= home home)))
 (or $x414 $x588 __dir.dirty))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x414 (= home home)))
 (or $x414 $x703 __dir.dirty))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x414 (= home home)))
 (or $x414 $x706 __dir.dirty))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x414 (= home home)))
 (or $x414 $x709 __dir.dirty))))
(assert
 (let (($x499 (not (net.putX home @V0))))
 (let (($x414 (= home home)))
 (or $x414 $x499))))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x536))))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x538))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x414 (= home home)))
 (or $x414 $x588))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x414 (= home home)))
 (or $x414 $x703))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x414 (= home home)))
 (or $x414 $x706))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x414 (= home home)))
 (or $x414 $x709))))
(assert
 (let (($x551 (not (net.get home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x551 dir.head))))
(assert
 (let (($x553 (not (net.get home @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x553 dir.head))))
(assert
 (let (($x555 (not (net.get home home))))
 (let (($x414 (= home home)))
 (or $x414 $x555 dir.head))))
(assert
 (let (($x557 (not (net.get home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x557 dir.head))))
(assert
 (let (($x597 (not (net.get dir.hptr home))))
 (let (($x414 (= home home)))
 (or $x414 $x597 dir.head))))
(assert
 (let (($x603 (not (net.get @V0 home))))
 (let (($x414 (= home home)))
 (or $x414 $x603 dir.head))))
(assert
 (let (($x742 (not (net.get real_owner home))))
 (let (($x414 (= home home)))
 (or $x414 $x742 dir.head))))
(assert
 (let (($x745 (not (net.get @V1 home))))
 (let (($x414 (= home home)))
 (or $x414 $x745 dir.head))))
(assert
 (let (($x551 (not (net.get home @Y))))
 (let (($x317 (= @Y home)))
 (or $x317 $x551 __dir.dirty))))
(assert
 (let (($x553 (not (net.get home @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x553 __dir.dirty))))
(assert
 (let (($x555 (not (net.get home home))))
 (let (($x414 (= home home)))
 (or $x414 $x555 __dir.dirty))))
(assert
 (let (($x557 (not (net.get home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x557 __dir.dirty))))
(assert
 (let (($x597 (not (net.get dir.hptr home))))
 (let (($x414 (= home home)))
 (or $x414 $x597 __dir.dirty))))
(assert
 (let (($x603 (not (net.get @V0 home))))
 (let (($x414 (= home home)))
 (or $x414 $x603 __dir.dirty))))
(assert
 (let (($x742 (not (net.get real_owner home))))
 (let (($x414 (= home home)))
 (or $x414 $x742 __dir.dirty))))
(assert
 (let (($x745 (not (net.get @V1 home))))
 (let (($x414 (= home home)))
 (or $x414 $x745 __dir.dirty))))
(assert
 (let (($x712 (not (net.getX home home))))
 (let (($x414 (= home home)))
 (or $x414 $x712 dir.head))))
(assert
 (let (($x715 (not (net.getX @V1 home))))
 (let (($x414 (= home home)))
 (or $x414 $x715 dir.head))))
(assert
 (let (($x718 (not (net.getX @V0 home))))
 (let (($x414 (= home home)))
 (or $x414 $x718 dir.head))))
(assert
 (let (($x750 (not (net.getX home @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x750 dir.head))))
(assert
 (let (($x752 (not (net.getX home @V0))))
 (let (($x431 (= @V0 home)))
 (or $x431 $x752 dir.head))))
(assert
 (let (($x754 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x754 dir.head))))
(assert
 (let (($x712 (not (net.getX home home))))
 (let (($x414 (= home home)))
 (or $x414 $x712 __dir.dirty))))
(assert
 (let (($x715 (not (net.getX @V1 home))))
 (let (($x414 (= home home)))
 (or $x414 $x715 __dir.dirty))))
(assert
 (let (($x718 (not (net.getX @V0 home))))
 (let (($x414 (= home home)))
 (or $x414 $x718 __dir.dirty))))
(assert
 (let (($x750 (not (net.getX home @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x750 __dir.dirty))))
(assert
 (let (($x752 (not (net.getX home @V0))))
 (let (($x431 (= @V0 home)))
 (or $x431 $x752 __dir.dirty))))
(assert
 (let (($x754 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x754 __dir.dirty))))
(assert
 (let (($x712 (not (net.getX home home))))
 (let (($x414 (= home home)))
 (or $x414 $x712))))
(assert
 (let (($x715 (not (net.getX @V1 home))))
 (let (($x414 (= home home)))
 (or $x414 $x715))))
(assert
 (let (($x718 (not (net.getX @V0 home))))
 (let (($x414 (= home home)))
 (or $x414 $x718))))
(assert
 (let (($x750 (not (net.getX home @Z))))
 (let (($x411 (= @Z home)))
 (or $x411 $x750))))
(assert
 (let (($x752 (not (net.getX home @V0))))
 (let (($x431 (= @V0 home)))
 (or $x431 $x752))))
(assert
 (let (($x754 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (or $x292 $x754))))
(assert
 (let (($x712 (not (net.getX home home))))
 (let (($x414 (= home home)))
 (let (($x480 (= home requester)))
 (or $x480 $x414 $x712)))))
(assert
 (let (($x715 (not (net.getX @V1 home))))
 (let (($x414 (= home home)))
 (let (($x483 (= @V1 requester)))
 (or $x483 $x414 $x715)))))
(assert
 (let (($x718 (not (net.getX @V0 home))))
 (let (($x414 (= home home)))
 (let (($x485 (= @V0 requester)))
 (or $x485 $x414 $x718)))))
(assert
 (let (($x750 (not (net.getX home @Z))))
 (let (($x411 (= @Z home)))
 (let (($x480 (= home requester)))
 (or $x480 $x411 $x750)))))
(assert
 (let (($x752 (not (net.getX home @V0))))
 (let (($x431 (= @V0 home)))
 (let (($x480 (= home requester)))
 (or $x480 $x431 $x752)))))
(assert
 (let (($x754 (not (net.getX home @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x480 (= home requester)))
 (or $x480 $x292 $x754)))))
(assert
 (let (($x723 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x723))))
(assert
 (let (($x727 (not (= (cache.state_ home) exclusive))))
 (let (($x415 (= home real_owner)))
 (or $x415 $x727))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x854 (= dir.hptr dir.hptr)))
 (or $x854 $x588))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x856 (= real_owner dir.hptr)))
 (or $x856 $x703))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x858 (= @V1 dir.hptr)))
 (or $x858 $x706))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x860 (= home dir.hptr)))
 (or $x860 $x709))))
(assert
 (let (($x723 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x854 (= dir.hptr dir.hptr)))
 (or $x854 $x723))))
(assert
 (let (($x727 (not (= (cache.state_ home) exclusive))))
 (let (($x860 (= home dir.hptr)))
 (or $x860 $x727))))
(assert
 (let (($x865 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x865))))
(assert
 (let (($x868 (not (= (cache.state_ home) shared))))
 (let (($x415 (= home real_owner)))
 (or $x415 $x868))))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x536))))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x538))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x414 (= home home)))
 (or $x414 $x588))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x414 (= home home)))
 (or $x414 $x703))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x414 (= home home)))
 (or $x414 $x706))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x414 (= home home)))
 (or $x414 $x709))))
(assert
 (let (($x507 (not (= (cache.state_ @V0) shared))))
 (let (($x542 (not (rp_net @V0))))
 (or $x542 $x507))))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (let (($x511 (= real_owner @X)))
 (or $x511 $x536))))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (let (($x515 (= real_owner @V0)))
 (or $x515 $x538))))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (let (($x856 (= real_owner dir.hptr)))
 (or $x856 $x588))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x703))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x875 (= real_owner @V1)))
 (or $x875 $x706))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x709))))
(assert
 (let (($x545 (not (net.put home @V0))))
 (or $x545 dir.head)))
(assert
 (let (($x547 (not (net.put dir.hptr @X))))
 (or $x547 dir.head)))
(assert
 (let (($x549 (not (net.put dir.hptr @V0))))
 (or $x549 dir.head)))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (or $x593 dir.head)))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (or $x732 dir.head)))
(assert
 (let (($x736 (not (net.put home @V1))))
 (or $x736 dir.head)))
(assert
 (let (($x739 (not (net.put home home))))
 (or $x739 dir.head)))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (or $x536 dir.head)))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (or $x538 dir.head)))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (or $x588 dir.head)))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (or $x703 dir.head)))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (or $x706 dir.head)))
(assert
 (let (($x709 (not (net.putX home home))))
 (or $x709 dir.head)))
(assert
 (let (($x536 (not (net.putX real_owner @X))))
 (or $x536 __dir.dirty)))
(assert
 (let (($x538 (not (net.putX real_owner @V0))))
 (or $x538 __dir.dirty)))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (or $x588 __dir.dirty)))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (or $x703 __dir.dirty)))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (or $x706 __dir.dirty)))
(assert
 (let (($x709 (not (net.putX home home))))
 (or $x709 __dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x588 (not (net.putX home dir.hptr))))
 (or $x588 dir.head)))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (or $x703 dir.head)))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (or $x706 dir.head)))
(assert
 (let (($x709 (not (net.putX home home))))
 (or $x709 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x542 (not (rp_net @V0))))
 (let (($x545 (not (net.put home @V0))))
 (or $x545 $x542))))
(assert
 (let (($x342 (not (rp_net @X))))
 (let (($x547 (not (net.put dir.hptr @X))))
 (or $x547 $x342))))
(assert
 (let (($x542 (not (rp_net @V0))))
 (let (($x549 (not (net.put dir.hptr @V0))))
 (or $x549 $x542))))
(assert
 (let (($x908 (not (rp_net dir.hptr))))
 (let (($x593 (not (net.put home dir.hptr))))
 (or $x593 $x908))))
(assert
 (let (($x911 (not (rp_net real_owner))))
 (let (($x732 (not (net.put home real_owner))))
 (or $x732 $x911))))
(assert
 (let (($x914 (not (rp_net @V1))))
 (let (($x736 (not (net.put home @V1))))
 (or $x736 $x914))))
(assert
 (let (($x917 (not (rp_net home))))
 (let (($x739 (not (net.put home home))))
 (or $x739 $x917))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x559 (not (invack @X))))
 (or $x559 (not (invnet @X)))))
(assert
 (let (($x562 (not (invack @V0))))
 (or $x562 (not (invnet @V0)))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x593 __dir.pending))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x732 __dir.pending))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x736 __dir.pending))))
(assert
 (let (($x739 (not (net.put home home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x739 __dir.pending))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x920 __dir.pending))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x922 __dir.pending))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x924 __dir.pending))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x926 __dir.pending))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x593 __dir.dirty))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x732 __dir.dirty))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x736 __dir.dirty))))
(assert
 (let (($x739 (not (net.put home home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x739 __dir.dirty))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x920 __dir.dirty))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x922 __dir.dirty))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x924 __dir.dirty))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x926 __dir.dirty))))
(assert
 (let (($x593 (not (net.put home dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x593))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x732))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x736))))
(assert
 (let (($x739 (not (net.put home home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x739))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x920))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x922))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x924))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x926))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x703))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x706))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x709))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x732))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x736))))
(assert
 (let (($x739 (not (net.put home home))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x739))))
(assert
 (let (($x742 (not (net.get real_owner home))))
 (let (($x934 (__dir.shlist real_owner)))
 (let (($x962 (not $x934)))
 (or $x962 $x742)))))
(assert
 (let (($x745 (not (net.get @V1 home))))
 (let (($x936 (__dir.shlist @V1)))
 (let (($x964 (not $x936)))
 (or $x964 $x745)))))
(assert
 (let (($x555 (not (net.get home home))))
 (let (($x938 (__dir.shlist home)))
 (let (($x966 (not $x938)))
 (or $x966 $x555)))))
(assert
 (let (($x934 (__dir.shlist real_owner)))
 (let (($x962 (not $x934)))
 (or $x962 dir.head))))
(assert
 (let (($x936 (__dir.shlist @V1)))
 (let (($x964 (not $x936)))
 (or $x964 dir.head))))
(assert
 (let (($x938 (__dir.shlist home)))
 (let (($x966 (not $x938)))
 (or $x966 dir.head))))
(assert
 (let (($x723 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x723))))
(assert
 (let (($x727 (not (= (cache.state_ home) exclusive))))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x727))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let (($x763 (= real_owner home)))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x763 $x732)))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x292 $x736)))))
(assert
 (let (($x739 (not (net.put home home))))
 (let (($x414 (= home home)))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x414 $x739)))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let (($x618 (= dir.hptr home)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x618 $x920)))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let (($x763 (= real_owner home)))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x763 $x922)))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let (($x292 (= @V1 home)))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x292 $x924)))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let (($x414 (= home home)))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x414 $x926)))))
(assert
 (let (($x723 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x980 (= dir.hptr requester)))
 (let (($x58 (__dir.shlist dir.hptr)))
 (or $x58 $x980 $x723)))))
(assert
 (let (($x727 (not (= (cache.state_ home) exclusive))))
 (let (($x480 (= home requester)))
 (let (($x938 (__dir.shlist home)))
 (or $x938 $x480 $x727)))))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x703))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x706))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x709))))
(assert
 (let (($x865 (not (= (cache.state_ dir.hptr) shared))))
 (or $x865 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x868 (not (= (cache.state_ home) shared))))
 (or $x868 (not (= (cache.wait home) get)))))
(assert
 (let (($x723 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x723 dir.head)))
(assert
 (let (($x727 (not (= (cache.state_ home) exclusive))))
 (or $x727 dir.head)))
(assert
 (let (($x703 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x701 (= ?x140 getX)))
 (or $x701 $x703)))))
(assert
 (let (($x706 (not (net.putX home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x652 (= ?x324 getX)))
 (or $x652 $x706)))))
(assert
 (let (($x709 (not (net.putX home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x709)))))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x898)))))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x701 (= ?x140 getX)))
 (or $x701 $x900)))))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x652 (= ?x324 getX)))
 (or $x652 $x902)))))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x904)))))
(assert
 (let (($x712 (not (net.getX home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x712)))))
(assert
 (let (($x715 (not (net.getX @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x652 (= ?x324 getX)))
 (or $x652 $x715)))))
(assert
 (let (($x718 (not (net.getX @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x298 (= ?x297 getX)))
 (or $x298 $x718)))))
(assert
 (let (($x750 (not (net.getX home @Z))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x750)))))
(assert
 (let (($x752 (not (net.getX home @V0))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x752)))))
(assert
 (let (($x754 (not (net.getX home @V1))))
 (let ((?x649 (cache.wait home)))
 (let (($x650 (= ?x649 getX)))
 (or $x650 $x754)))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x732)))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x734 (= ?x324 get)))
 (or $x734 $x736)))))
(assert
 (let (($x739 (not (net.put home home))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x739)))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x659 (= ?x644 get)))
 (or $x659 $x920)))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x922)))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x734 (= ?x324 get)))
 (or $x734 $x924)))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let ((?x649 (cache.wait home)))
 (let (($x663 (= ?x649 get)))
 (or $x663 $x926)))))
(assert
 (let (($x597 (not (net.get dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x659 (= ?x644 get)))
 (or $x659 $x597)))))
(assert
 (let (($x603 (not (net.get @V0 home))))
 (let ((?x297 (cache.wait @V0)))
 (let (($x307 (= ?x297 get)))
 (or $x307 $x603)))))
(assert
 (let (($x742 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x742)))))
(assert
 (let (($x745 (not (net.get @V1 home))))
 (let ((?x324 (cache.wait @V1)))
 (let (($x734 (= ?x324 get)))
 (or $x734 $x745)))))
(assert
 (let (($x732 (not (net.put home real_owner))))
 (let ((?x1003 (cache.state_ real_owner)))
 (let (($x1004 (= ?x1003 invalid)))
 (or $x1004 $x732)))))
(assert
 (let (($x736 (not (net.put home @V1))))
 (let ((?x1006 (cache.state_ @V1)))
 (let (($x1007 (= ?x1006 invalid)))
 (or $x1007 $x736)))))
(assert
 (let (($x739 (not (net.put home home))))
 (let ((?x680 (cache.state_ home)))
 (let (($x681 (= ?x680 invalid)))
 (or $x681 $x739)))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let ((?x674 (cache.state_ dir.hptr)))
 (let (($x675 (= ?x674 invalid)))
 (or $x675 $x920)))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let ((?x1003 (cache.state_ real_owner)))
 (let (($x1004 (= ?x1003 invalid)))
 (or $x1004 $x922)))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let ((?x1006 (cache.state_ @V1)))
 (let (($x1007 (= ?x1006 invalid)))
 (or $x1007 $x924)))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let ((?x680 (cache.state_ home)))
 (let (($x681 (= ?x680 invalid)))
 (or $x681 $x926)))))
(assert
 (let (($x597 (not (net.get dir.hptr home))))
 (let ((?x674 (cache.state_ dir.hptr)))
 (let (($x675 (= ?x674 invalid)))
 (or $x675 $x597)))))
(assert
 (let (($x603 (not (net.get @V0 home))))
 (let ((?x312 (cache.state_ @V0)))
 (let (($x313 (= ?x312 invalid)))
 (or $x313 $x603)))))
(assert
 (let (($x742 (not (net.get real_owner home))))
 (let ((?x1003 (cache.state_ real_owner)))
 (let (($x1004 (= ?x1003 invalid)))
 (or $x1004 $x742)))))
(assert
 (let (($x745 (not (net.get @V1 home))))
 (let ((?x1006 (cache.state_ @V1)))
 (let (($x1007 (= ?x1006 invalid)))
 (or $x1007 $x745)))))
(assert
 (let (($x695 (not (= (cache.wait home) none))))
 (let (($x712 (not (net.getX home home))))
 (or $x712 $x695))))
(assert
 (let (($x326 (not (= (cache.wait @V1) none))))
 (let (($x715 (not (net.getX @V1 home))))
 (or $x715 $x326))))
(assert
 (let (($x699 (not (= (cache.wait @V0) none))))
 (let (($x718 (not (net.getX @V0 home))))
 (or $x718 $x699))))
(assert
 (let (($x695 (not (= (cache.wait home) none))))
 (let (($x750 (not (net.getX home @Z))))
 (or $x750 $x695))))
(assert
 (let (($x695 (not (= (cache.wait home) none))))
 (let (($x752 (not (net.getX home @V0))))
 (or $x752 $x695))))
(assert
 (let (($x695 (not (= (cache.wait home) none))))
 (let (($x754 (not (net.getX home @V1))))
 (or $x754 $x695))))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x701 (= ?x140 getX)))
 (or $x701 $x1025)))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x1028)))))
(assert
 (let (($x1031 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1031 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1035 (not (= (cache.state_ @V1) exclusive))))
 (or $x1035 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x908 (not (rp_net dir.hptr))))
 (let (($x593 (not (net.put home dir.hptr))))
 (or $x593 $x908))))
(assert
 (let (($x911 (not (rp_net real_owner))))
 (let (($x732 (not (net.put home real_owner))))
 (or $x732 $x911))))
(assert
 (let (($x914 (not (rp_net @V1))))
 (let (($x736 (not (net.put home @V1))))
 (or $x736 $x914))))
(assert
 (let (($x917 (not (rp_net home))))
 (let (($x739 (not (net.put home home))))
 (or $x739 $x917))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x920)))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x922)))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x924)))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x145 $x926)))))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x898)))))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x900)))))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x902)))))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (let (($x764 (= real_owner real_owner)))
 (let (($x763 (= real_owner home)))
 (or $x763 $x764 $x904)))))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x1025)))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (let (($x415 (= home real_owner)))
 (let (($x414 (= home home)))
 (or $x414 $x415 $x1028)))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x920 __dir.dirty))))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x922 __dir.dirty))))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x924 __dir.dirty))))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (let (($x618 (= dir.hptr home)))
 (or $x618 $x926 __dir.dirty))))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x898 dir.head))))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x900 dir.head))))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x902 dir.head))))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x904 dir.head))))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x898 __dir.dirty))))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x900 __dir.dirty))))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x902 __dir.dirty))))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x904 __dir.dirty))))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x898))))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x900))))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x902))))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x904))))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (let (($x414 (= home home)))
 (or $x414 $x1025 dir.head))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (let (($x414 (= home home)))
 (or $x414 $x1028 dir.head))))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (let (($x414 (= home home)))
 (or $x414 $x1025 __dir.dirty))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (let (($x414 (= home home)))
 (or $x414 $x1028 __dir.dirty))))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (let (($x414 (= home home)))
 (or $x414 $x1025))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (let (($x414 (= home home)))
 (or $x414 $x1028))))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (let (($x414 (= home home)))
 (let (($x1070 (= real_owner requester)))
 (or $x1070 $x414 $x1025)))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (let (($x414 (= home home)))
 (let (($x980 (= dir.hptr requester)))
 (or $x980 $x414 $x1028)))))
(assert
 (let (($x1031 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x1031))))
(assert
 (let (($x1035 (not (= (cache.state_ @V1) exclusive))))
 (let (($x417 (= @V1 real_owner)))
 (or $x417 $x1035))))
(assert
 (let (($x1031 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x856 (= real_owner dir.hptr)))
 (or $x856 $x1031))))
(assert
 (let (($x1035 (not (= (cache.state_ @V1) exclusive))))
 (let (($x858 (= @V1 dir.hptr)))
 (or $x858 $x1035))))
(assert
 (let (($x1078 (not (= (cache.state_ real_owner) shared))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x1078))))
(assert
 (let (($x1081 (not (= (cache.state_ @V1) shared))))
 (let (($x417 (= @V1 real_owner)))
 (or $x417 $x1081))))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x898))))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x900))))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x902))))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x904))))
(assert
 (let (($x865 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x908 (not (rp_net dir.hptr))))
 (or $x908 $x865))))
(assert
 (let (($x868 (not (= (cache.state_ home) shared))))
 (let (($x917 (not (rp_net home))))
 (or $x917 $x868))))
(assert
 (let (($x1078 (not (= (cache.state_ real_owner) shared))))
 (let (($x911 (not (rp_net real_owner))))
 (or $x911 $x1078))))
(assert
 (let (($x1081 (not (= (cache.state_ @V1) shared))))
 (let (($x914 (not (rp_net @V1))))
 (or $x914 $x1081))))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (let (($x856 (= real_owner dir.hptr)))
 (or $x856 $x898))))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (let (($x764 (= real_owner real_owner)))
 (or $x764 $x900))))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (let (($x875 (= real_owner @V1)))
 (or $x875 $x902))))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (let (($x763 (= real_owner home)))
 (or $x763 $x904))))
(assert
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (or $x920 dir.head)))
(assert
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (or $x922 dir.head)))
(assert
 (let (($x924 (not (net.put dir.hptr @V1))))
 (or $x924 dir.head)))
(assert
 (let (($x926 (not (net.put dir.hptr home))))
 (or $x926 dir.head)))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (or $x898 dir.head)))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (or $x900 dir.head)))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (or $x902 dir.head)))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (or $x904 dir.head)))
(assert
 (let (($x898 (not (net.putX real_owner dir.hptr))))
 (or $x898 __dir.dirty)))
(assert
 (let (($x900 (not (net.putX real_owner real_owner))))
 (or $x900 __dir.dirty)))
(assert
 (let (($x902 (not (net.putX real_owner @V1))))
 (or $x902 __dir.dirty)))
(assert
 (let (($x904 (not (net.putX real_owner home))))
 (or $x904 __dir.dirty)))
(assert
 (let (($x908 (not (rp_net dir.hptr))))
 (let (($x920 (not (net.put dir.hptr dir.hptr))))
 (or $x920 $x908))))
(assert
 (let (($x911 (not (rp_net real_owner))))
 (let (($x922 (not (net.put dir.hptr real_owner))))
 (or $x922 $x911))))
(assert
 (let (($x914 (not (rp_net @V1))))
 (let (($x924 (not (net.put dir.hptr @V1))))
 (or $x924 $x914))))
(assert
 (let (($x917 (not (rp_net home))))
 (let (($x926 (not (net.put dir.hptr home))))
 (or $x926 $x917))))
(assert
 (let (($x1031 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x1031))))
(assert
 (let (($x1035 (not (= (cache.state_ @V1) exclusive))))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x1035))))
(assert
 (let (($x1031 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x1070 (= real_owner requester)))
 (let (($x934 (__dir.shlist real_owner)))
 (or $x934 $x1070 $x1031)))))
(assert
 (let (($x1035 (not (= (cache.state_ @V1) exclusive))))
 (let (($x483 (= @V1 requester)))
 (let (($x936 (__dir.shlist @V1)))
 (or $x936 $x483 $x1035)))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (let (($x142 (not $x141)))
 (let (($x1078 (not (= (cache.state_ real_owner) shared))))
 (or $x1078 $x142))))))
(assert
 (let (($x1081 (not (= (cache.state_ @V1) shared))))
 (or $x1081 (not (= (cache.wait @V1) get)))))
(assert
 (let (($x1031 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1031 dir.head)))
(assert
 (let (($x1035 (not (= (cache.state_ @V1) exclusive))))
 (or $x1035 dir.head)))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x701 (= ?x140 getX)))
 (or $x701 $x1025)))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (let ((?x644 (cache.wait dir.hptr)))
 (let (($x645 (= ?x644 getX)))
 (or $x645 $x1028)))))
(assert
 (let (($x1025 (not (net.getX real_owner home))))
 (or $x1025 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x1028 (not (net.getX dir.hptr home))))
 (or $x1028 (not (= (cache.wait dir.hptr) none)))))
(check-sat)
