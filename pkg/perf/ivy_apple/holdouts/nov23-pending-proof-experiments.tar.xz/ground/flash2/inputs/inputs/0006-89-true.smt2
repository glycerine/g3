(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun __dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun dir.hptr () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun __dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun cache.invmarked (id) Bool)
(declare-fun dir.head () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __net.put (id id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 (not __dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x144 (not dir.dirty)))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x144 dir.pending))))
(assert
 (not (net.fack requester home)))
(assert
 (__net.get __src home))
(assert
 (not (= home __src)))
(assert
 (not dir.pending))
(assert
 (not dir.dirty))
(assert
 (not (rp_net __src)))
(assert
 (not (cache.invmarked __src)))
(assert
 dir.head)
(assert
 (= dir.hptr __src))
(assert
 (let (($x346 (not (= (cache.state_ @X) exclusive))))
 (let (($x387 (not (net.getX home @Y))))
 (let (($x366 (not (net.getX @X @Z))))
 (let (($x374 (not (net.getX @X @Y))))
 (let (($x375 (= @Y @Z)))
 (let (($x388 (and (or $x375 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x375 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x375 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x375 $x374 $x366) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x366 (not (net.putX @Y @X))) $x387 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x346 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x388)))))))))
(assert
 (let (($x360 (dir.shlist dir.hptr)))
 (= $x360 (ite (and (= dir.hptr __src)) true (__dir.shlist dir.hptr)))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x368 (net.put @Y @X)))
 (= $x368 (ite (and (= @Y home) (= @X __src)) true $x415)))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x383 (net.put @Z @X)))
 (= $x383 (ite (and (= @Z home) (= @X __src)) true $x420)))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x351 (net.put home @X)))
 (= $x351 (ite (and (= home home) (= @X __src)) true $x425)))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x313 (net.put @V1 @V0)))
 (= $x313 (ite (and (= @V1 home) (= @V0 __src)) true $x430)))))
(assert
 (let (($x434 (__net.get @X @Y)))
 (let (($x380 (net.get @X @Y)))
 (= $x380 (ite (and (= @X __src) (= @Y home)) false $x434)))))
(assert
 (let (($x438 (__net.get @X @Z)))
 (let (($x370 (net.get @X @Z)))
 (= $x370 (ite (and (= @X __src) (= @Z home)) false $x438)))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x356 (net.get @X home)))
 (= $x356 (ite (and (= @X __src) (= home home)) false $x442)))))
(assert
 (let (($x446 (__net.get @V0 @V1)))
 (let (($x317 (net.get @V0 @V1)))
 (= $x317 (ite (and (= @V0 __src) (= @V1 home)) false $x446)))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let (($x449 (= @Y real_owner)))
 (let (($x325 (= @Y home)))
 (or $x325 $x449 $x450))))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let (($x452 (= @Z real_owner)))
 (let (($x418 (= @Z home)))
 (or $x418 $x452 $x453))))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x456))))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let (($x458 (= @V1 real_owner)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x458 $x459))))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (let (($x449 (= @Y real_owner)))
 (let (($x325 (= @Y home)))
 (or $x325 $x449 $x363)))))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (let (($x452 (= @Z real_owner)))
 (let (($x418 (= @Z home)))
 (or $x418 $x452 $x378)))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x337)))))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (let (($x458 (= @V1 real_owner)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x458 $x308)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x465 (not $x271)))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x465))))))
(assert
 (let (($x434 (__net.get @X @Y)))
 (let (($x467 (not $x434)))
 (let (($x449 (= @Y real_owner)))
 (let (($x325 (= @Y home)))
 (or $x325 $x449 $x467))))))
(assert
 (let (($x438 (__net.get @X @Z)))
 (let (($x469 (not $x438)))
 (let (($x452 (= @Z real_owner)))
 (let (($x418 (= @Z home)))
 (or $x418 $x452 $x469))))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x471 (not $x442)))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x471))))))
(assert
 (let (($x446 (__net.get @V0 @V1)))
 (let (($x473 (not $x446)))
 (let (($x458 (= @V1 real_owner)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x458 $x473))))))
(assert
 (let (($x374 (not (net.getX @X @Y))))
 (let (($x449 (= @Y real_owner)))
 (let (($x325 (= @Y home)))
 (or $x325 $x449 $x374)))))
(assert
 (let (($x366 (not (net.getX @X @Z))))
 (let (($x452 (= @Z real_owner)))
 (let (($x418 (= @Z home)))
 (or $x418 $x452 $x366)))))
(assert
 (let (($x387 (not (net.getX home @Y))))
 (let (($x449 (= @Y real_owner)))
 (let (($x325 (= @Y home)))
 (or $x325 $x449 $x387)))))
(assert
 (let (($x342 (not (net.getX @X home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x342)))))
(assert
 (let (($x331 (not (net.getX @V1 @V0))))
 (let (($x480 (= @V0 real_owner)))
 (let (($x479 (= @V0 home)))
 (or $x479 $x480 $x331)))))
(assert
 (let (($x311 (not (net.getX @V0 @V1))))
 (let (($x458 (= @V1 real_owner)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x458 $x311)))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let (($x325 (= @Y home)))
 (or $x325 $x450 dir.dirty)))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let (($x418 (= @Z home)))
 (or $x418 $x453 dir.dirty)))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let (($x423 (= home home)))
 (or $x423 $x456 dir.dirty)))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x459 dir.dirty)))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (let (($x325 (= @Y home)))
 (or $x325 $x363 __dir.head))))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (let (($x418 (= @Z home)))
 (or $x418 $x378 __dir.head))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x423 (= home home)))
 (or $x423 $x337 __dir.head))))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x308 __dir.head))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (let (($x325 (= @Y home)))
 (or $x325 $x363 dir.dirty))))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (let (($x418 (= @Z home)))
 (or $x418 $x378 dir.dirty))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x423 (= home home)))
 (or $x423 $x337 dir.dirty))))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x308 dir.dirty))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (let (($x325 (= @Y home)))
 (or $x325 $x363))))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (let (($x418 (= @Z home)))
 (or $x418 $x378))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x423 (= home home)))
 (or $x423 $x337))))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x308))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x465 (not $x271)))
 (let (($x423 (= home home)))
 (or $x423 $x465 __dir.head)))))
(assert
 (let (($x434 (__net.get @X @Y)))
 (let (($x467 (not $x434)))
 (let (($x325 (= @Y home)))
 (or $x325 $x467 __dir.head)))))
(assert
 (let (($x438 (__net.get @X @Z)))
 (let (($x469 (not $x438)))
 (let (($x418 (= @Z home)))
 (or $x418 $x469 __dir.head)))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x471 (not $x442)))
 (let (($x423 (= home home)))
 (or $x423 $x471 __dir.head)))))
(assert
 (let (($x446 (__net.get @V0 @V1)))
 (let (($x473 (not $x446)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x473 __dir.head)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x465 (not $x271)))
 (let (($x423 (= home home)))
 (or $x423 $x465 dir.dirty)))))
(assert
 (let (($x434 (__net.get @X @Y)))
 (let (($x467 (not $x434)))
 (let (($x325 (= @Y home)))
 (or $x325 $x467 dir.dirty)))))
(assert
 (let (($x438 (__net.get @X @Z)))
 (let (($x469 (not $x438)))
 (let (($x418 (= @Z home)))
 (or $x418 $x469 dir.dirty)))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x471 (not $x442)))
 (let (($x423 (= home home)))
 (or $x423 $x471 dir.dirty)))))
(assert
 (let (($x446 (__net.get @V0 @V1)))
 (let (($x473 (not $x446)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x473 dir.dirty)))))
(assert
 (let (($x374 (not (net.getX @X @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x374 __dir.head))))
(assert
 (let (($x366 (not (net.getX @X @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x366 __dir.head))))
(assert
 (let (($x387 (not (net.getX home @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x387 __dir.head))))
(assert
 (let (($x342 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (or $x423 $x342 __dir.head))))
(assert
 (let (($x331 (not (net.getX @V1 @V0))))
 (let (($x479 (= @V0 home)))
 (or $x479 $x331 __dir.head))))
(assert
 (let (($x311 (not (net.getX @V0 @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x311 __dir.head))))
(assert
 (let (($x374 (not (net.getX @X @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x374 dir.dirty))))
(assert
 (let (($x366 (not (net.getX @X @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x366 dir.dirty))))
(assert
 (let (($x387 (not (net.getX home @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x387 dir.dirty))))
(assert
 (let (($x342 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (or $x423 $x342 dir.dirty))))
(assert
 (let (($x331 (not (net.getX @V1 @V0))))
 (let (($x479 (= @V0 home)))
 (or $x479 $x331 dir.dirty))))
(assert
 (let (($x311 (not (net.getX @V0 @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x311 dir.dirty))))
(assert
 (let (($x374 (not (net.getX @X @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x374))))
(assert
 (let (($x366 (not (net.getX @X @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x366))))
(assert
 (let (($x387 (not (net.getX home @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x387))))
(assert
 (let (($x342 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (or $x423 $x342))))
(assert
 (let (($x331 (not (net.getX @V1 @V0))))
 (let (($x479 (= @V0 home)))
 (or $x479 $x331))))
(assert
 (let (($x311 (not (net.getX @V0 @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x311))))
(assert
 (let (($x374 (not (net.getX @X @Y))))
 (let (($x325 (= @Y home)))
 (let (($x527 (= @X requester)))
 (or $x527 $x325 $x374)))))
(assert
 (let (($x366 (not (net.getX @X @Z))))
 (let (($x418 (= @Z home)))
 (let (($x527 (= @X requester)))
 (or $x527 $x418 $x366)))))
(assert
 (let (($x387 (not (net.getX home @Y))))
 (let (($x325 (= @Y home)))
 (let (($x530 (= home requester)))
 (or $x530 $x325 $x387)))))
(assert
 (let (($x342 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (let (($x527 (= @X requester)))
 (or $x527 $x423 $x342)))))
(assert
 (let (($x331 (not (net.getX @V1 @V0))))
 (let (($x479 (= @V0 home)))
 (let (($x533 (= @V1 requester)))
 (or $x533 $x479 $x331)))))
(assert
 (let (($x311 (not (net.getX @V0 @V1))))
 (let (($x300 (= @V1 home)))
 (let (($x535 (= @V0 requester)))
 (or $x535 $x300 $x311)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x303 (not (net.fack @V0 @V1))))
 (let (($x480 (= @V0 real_owner)))
 (or $x480 $x303))))
(assert
 (let (($x346 (not (= (cache.state_ @X) exclusive))))
 (let (($x540 (= @X real_owner)))
 (or $x540 $x346))))
(assert
 (let (($x543 (not (= (cache.state_ @V0) exclusive))))
 (let (($x480 (= @V0 real_owner)))
 (or $x480 $x543))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x545 (= @X __dir.hptr)))
 (or $x545 $x337))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x547 (= @V0 __dir.hptr)))
 (or $x547 $x549))))
(assert
 (let (($x346 (not (= (cache.state_ @X) exclusive))))
 (let (($x545 (= @X __dir.hptr)))
 (or $x545 $x346))))
(assert
 (let (($x543 (not (= (cache.state_ @V0) exclusive))))
 (let (($x547 (= @V0 __dir.hptr)))
 (or $x547 $x543))))
(assert
 (let (($x554 (not (= (cache.state_ @X) shared))))
 (let (($x540 (= @X real_owner)))
 (or $x540 $x554))))
(assert
 (let (($x557 (not (= (cache.state_ @V0) shared))))
 (let (($x480 (= @V0 real_owner)))
 (or $x480 $x557))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (let (($x325 (= @Y home)))
 (or $x325 $x363))))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (let (($x418 (= @Z home)))
 (or $x418 $x378))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x423 (= home home)))
 (or $x423 $x337))))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x308))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x423 (= home home)))
 (or $x423 $x549))))
(assert
 (let (($x554 (not (= (cache.state_ @X) shared))))
 (let (($x350 (not (rp_net @X))))
 (or $x350 $x554))))
(assert
 (let (($x557 (not (= (cache.state_ @V0) shared))))
 (let (($x562 (not (rp_net @V0))))
 (or $x562 $x557))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (let (($x564 (= real_owner @X)))
 (or $x564 $x363))))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (let (($x564 (= real_owner @X)))
 (or $x564 $x378))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x564 (= real_owner @X)))
 (or $x564 $x337))))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (let (($x568 (= real_owner @V0)))
 (or $x568 $x308))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x568 (= real_owner @V0)))
 (or $x568 $x549))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (or $x450 __dir.head))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (or $x453 __dir.head))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (or $x456 __dir.head))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (or $x459 __dir.head))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (or $x363 __dir.head)))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (or $x378 __dir.head)))
(assert
 (let (($x337 (not (net.putX home @X))))
 (or $x337 __dir.head)))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (or $x308 __dir.head)))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (or $x549 __dir.head)))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (or $x363 dir.dirty)))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (or $x378 dir.dirty)))
(assert
 (let (($x337 (not (net.putX home @X))))
 (or $x337 dir.dirty)))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (or $x308 dir.dirty)))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (or $x549 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x337 (not (net.putX home @X))))
 (or $x337 __dir.head)))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (or $x549 __dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x350 (not (rp_net @X))))
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (or $x450 $x350)))))
(assert
 (let (($x350 (not (rp_net @X))))
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (or $x453 $x350)))))
(assert
 (let (($x350 (not (rp_net @X))))
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (or $x456 $x350)))))
(assert
 (let (($x562 (not (rp_net @V0))))
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (or $x459 $x562)))))
(assert
 (let (($x425 (__net.put home @X)))
 (not $x425)))
(assert
 (not (__net.put home @V0)))
(assert
 (not (__net.put __dir.hptr @X)))
(assert
 (not (__net.put __dir.hptr @V0)))
(assert
 (not (__net.get home home)))
(assert
 (not (__net.get home @Y)))
(assert
 (not (__net.get home @Z)))
(assert
 (not (__net.get home @V1)))
(assert
 (let (($x554 (not (= (cache.state_ @X) shared))))
 (let (($x610 (not (invack @X))))
 (or $x610 $x554))))
(assert
 (let (($x557 (not (= (cache.state_ @V0) shared))))
 (let (($x613 (not (invack @V0))))
 (or $x613 $x557))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x450 dir.pending)))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x453 dir.pending)))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x456 dir.pending)))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x459 dir.pending)))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x596 dir.pending))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x598 dir.pending))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x600 dir.pending))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x450 dir.dirty)))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x453 dir.dirty)))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x456 dir.dirty)))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x459 dir.dirty)))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x596 dir.dirty))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x598 dir.dirty))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x600 dir.dirty))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x450)))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x453)))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x456)))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x459)))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x596))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x598))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x600))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x639))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x642))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x337))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x549))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x647))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x650))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x456)))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x596))))
(assert
 (let (($x654 (not (__net.get __dir.hptr home))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (let (($x652 (not $x56)))
 (or $x652 $x654)))))
(assert
 (let (($x658 (not (__net.get dir.hptr home))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (let (($x656 (not $x410)))
 (or $x656 $x658)))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x471 (not $x442)))
 (let (($x615 (__dir.shlist @X)))
 (let (($x660 (not $x615)))
 (or $x660 $x471))))))
(assert
 (let (($x664 (not (__net.get @V0 home))))
 (let (($x619 (__dir.shlist @V0)))
 (let (($x662 (not $x619)))
 (or $x662 $x664)))))
(assert
 (let (($x56 (__dir.shlist __dir.hptr)))
 (let (($x652 (not $x56)))
 (or $x652 __dir.head))))
(assert
 (let (($x410 (__dir.shlist dir.hptr)))
 (let (($x656 (not $x410)))
 (or $x656 __dir.head))))
(assert
 (let (($x615 (__dir.shlist @X)))
 (let (($x660 (not $x615)))
 (or $x660 __dir.head))))
(assert
 (let (($x619 (__dir.shlist @V0)))
 (let (($x662 (not $x619)))
 (or $x662 __dir.head))))
(assert
 (let (($x346 (not (= (cache.state_ @X) exclusive))))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x346))))
(assert
 (let (($x543 (not (= (cache.state_ @V0) exclusive))))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x543))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let (($x672 (= @X home)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x672 $x450))))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let (($x672 (= @X home)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x672 $x453))))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let (($x672 (= @X home)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x672 $x456))))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let (($x479 (= @V0 home)))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x479 $x459))))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let (($x479 (= @V0 home)))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x479 $x596)))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let (($x672 (= @X home)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x672 $x598)))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let (($x479 (= @V0 home)))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x479 $x600)))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let (($x680 (= __dir.hptr home)))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x680 $x647)))))
(assert
 (let (($x346 (not (= (cache.state_ @X) exclusive))))
 (let (($x527 (= @X requester)))
 (let (($x615 (__dir.shlist @X)))
 (or $x615 $x527 $x346)))))
(assert
 (let (($x543 (not (= (cache.state_ @V0) exclusive))))
 (let (($x535 (= @V0 requester)))
 (let (($x619 (__dir.shlist @V0)))
 (or $x619 $x535 $x543)))))
(assert
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (let (($x540 (= @X real_owner)))
 (or (dir.real @X) $x540 $x685)))))
(assert
 (let ((?x320 (cache.state_ @V0)))
 (let (($x321 (= ?x320 invalid)))
 (let (($x480 (= @V0 real_owner)))
 (or (dir.real @V0) $x480 $x321)))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x337))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x549))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x639))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x642))))
(assert
 (let (($x554 (not (= (cache.state_ @X) shared))))
 (or $x554 (not (= (cache.wait @X) get)))))
(assert
 (let (($x557 (not (= (cache.state_ @V0) shared))))
 (or $x557 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x610 (not (invack @X))))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x610)))))
(assert
 (let (($x613 (not (invack @V0))))
 (let ((?x320 (cache.state_ @V0)))
 (let (($x321 (= ?x320 invalid)))
 (or $x321 $x613)))))
(assert
 (let (($x346 (not (= (cache.state_ @X) exclusive))))
 (or $x346 __dir.head)))
(assert
 (let (($x543 (not (= (cache.state_ @V0) exclusive))))
 (or $x543 __dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x423 (= home home)))
 (or $x423 $x187))))
(assert
 (let (($x303 (not (net.fack @V0 @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x303))))
(assert
 (let (($x363 (not (net.putX @Y @X))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x363)))))
(assert
 (let (($x378 (not (net.putX @Z @X))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x378)))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x337)))))
(assert
 (let (($x308 (not (net.putX @V1 @V0))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x306 (= ?x305 getX)))
 (or $x306 $x308)))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x306 (= ?x305 getX)))
 (or $x306 $x549)))))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x588)))))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x306 (= ?x305 getX)))
 (or $x306 $x590)))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x708 (= ?x707 getX)))
 (or $x708 $x639)))))
(assert
 (let (($x374 (not (net.getX @X @Y))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x374)))))
(assert
 (let (($x366 (not (net.getX @X @Z))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x366)))))
(assert
 (let (($x387 (not (net.getX home @Y))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x387)))))
(assert
 (let (($x342 (not (net.getX @X home))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x342)))))
(assert
 (let (($x331 (not (net.getX @V1 @V0))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x715 (= ?x332 getX)))
 (or $x715 $x331)))))
(assert
 (let (($x311 (not (net.getX @V0 @V1))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x306 (= ?x305 getX)))
 (or $x306 $x311)))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x450))))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x453))))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x456))))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let ((?x305 (cache.wait @V0)))
 (let (($x315 (= ?x305 get)))
 (or $x315 $x459))))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x315 (= ?x305 get)))
 (or $x315 $x596)))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x598)))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x315 (= ?x305 get)))
 (or $x315 $x600)))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x724 (= ?x707 get)))
 (or $x724 $x647)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x465 (not $x271)))
 (let ((?x726 (cache.wait __src)))
 (let (($x727 (= ?x726 get)))
 (or $x727 $x465))))))
(assert
 (let (($x434 (__net.get @X @Y)))
 (let (($x467 (not $x434)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x467))))))
(assert
 (let (($x438 (__net.get @X @Z)))
 (let (($x469 (not $x438)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x469))))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x471 (not $x442)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x471))))))
(assert
 (let (($x446 (__net.get @V0 @V1)))
 (let (($x473 (not $x446)))
 (let ((?x305 (cache.wait @V0)))
 (let (($x315 (= ?x305 get)))
 (or $x315 $x473))))))
(assert
 (let (($x602 (not (__net.get home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x733 (= ?x712 get)))
 (or $x733 $x602)))))
(assert
 (let (($x604 (not (__net.get home @Y))))
 (let ((?x712 (cache.wait home)))
 (let (($x733 (= ?x712 get)))
 (or $x733 $x604)))))
(assert
 (let (($x606 (not (__net.get home @Z))))
 (let ((?x712 (cache.wait home)))
 (let (($x733 (= ?x712 get)))
 (or $x733 $x606)))))
(assert
 (let (($x415 (__net.put @Y @X)))
 (let (($x450 (not $x415)))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x450))))))
(assert
 (let (($x420 (__net.put @Z @X)))
 (let (($x453 (not $x420)))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x453))))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x456))))))
(assert
 (let (($x430 (__net.put @V1 @V0)))
 (let (($x459 (not $x430)))
 (let ((?x320 (cache.state_ @V0)))
 (let (($x321 (= ?x320 invalid)))
 (or $x321 $x459))))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let ((?x320 (cache.state_ @V0)))
 (let (($x321 (= ?x320 invalid)))
 (or $x321 $x596)))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x598)))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let ((?x320 (cache.state_ @V0)))
 (let (($x321 (= ?x320 invalid)))
 (or $x321 $x600)))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let ((?x744 (cache.state_ __dir.hptr)))
 (let (($x745 (= ?x744 invalid)))
 (or $x745 $x647)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x465 (not $x271)))
 (let ((?x747 (cache.state_ __src)))
 (let (($x748 (= ?x747 invalid)))
 (or $x748 $x465))))))
(assert
 (let (($x434 (__net.get @X @Y)))
 (let (($x467 (not $x434)))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x467))))))
(assert
 (let (($x438 (__net.get @X @Z)))
 (let (($x469 (not $x438)))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x469))))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x471 (not $x442)))
 (let ((?x344 (cache.state_ @X)))
 (let (($x685 (= ?x344 invalid)))
 (or $x685 $x471))))))
(assert
 (let (($x446 (__net.get @V0 @V1)))
 (let (($x473 (not $x446)))
 (let ((?x320 (cache.state_ @V0)))
 (let (($x321 (= ?x320 invalid)))
 (or $x321 $x473))))))
(assert
 (let (($x602 (not (__net.get home home))))
 (let ((?x754 (cache.state_ home)))
 (let (($x755 (= ?x754 invalid)))
 (or $x755 $x602)))))
(assert
 (let (($x604 (not (__net.get home @Y))))
 (let ((?x754 (cache.state_ home)))
 (let (($x755 (= ?x754 invalid)))
 (or $x755 $x604)))))
(assert
 (let (($x606 (not (__net.get home @Z))))
 (let ((?x754 (cache.state_ home)))
 (let (($x755 (= ?x754 invalid)))
 (or $x755 $x606)))))
(assert
 (let (($x325 (= @Y home)))
 (or $x325 (not (net.shwb @X @Y)))))
(assert
 (let (($x423 (= home home)))
 (or $x423 (not (net.shwb @X home)))))
(assert
 (let (($x761 (not (= (cache.wait @X) none))))
 (let (($x374 (not (net.getX @X @Y))))
 (or $x374 $x761))))
(assert
 (let (($x761 (not (= (cache.wait @X) none))))
 (let (($x366 (not (net.getX @X @Z))))
 (or $x366 $x761))))
(assert
 (let (($x765 (not (= (cache.wait home) none))))
 (let (($x387 (not (net.getX home @Y))))
 (or $x387 $x765))))
(assert
 (let (($x761 (not (= (cache.wait @X) none))))
 (let (($x342 (not (net.getX @X home))))
 (or $x342 $x761))))
(assert
 (let (($x334 (not (= (cache.wait @V1) none))))
 (let (($x331 (not (net.getX @V1 @V0))))
 (or $x331 $x334))))
(assert
 (let (($x769 (not (= (cache.wait @V0) none))))
 (let (($x311 (not (net.getX @V0 @V1))))
 (or $x311 $x769))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x771 (= ?x140 getX)))
 (or $x771 $x773)))))
(assert
 (let (($x337 (not (net.putX home @X))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x337)))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x715 (= ?x332 getX)))
 (or $x715 $x776)))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x306 (= ?x305 getX)))
 (or $x306 $x549)))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x708 (= ?x707 getX)))
 (or $x708 $x639)))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x779)))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (let ((?x726 (cache.wait __src)))
 (let (($x781 (= ?x726 getX)))
 (or $x781 $x783)))))
(assert
 (let (($x342 (not (net.getX @X home))))
 (let ((?x338 (cache.wait @X)))
 (let (($x339 (= ?x338 getX)))
 (or $x339 $x342)))))
(assert
 (let (($x786 (not (net.getX home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x786)))))
(assert
 (let (($x789 (not (net.getX @V1 home))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x715 (= ?x332 getX)))
 (or $x715 $x789)))))
(assert
 (let (($x792 (not (net.getX @V0 home))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x306 (= ?x305 getX)))
 (or $x306 $x792)))))
(assert
 (let (($x346 (not (= (cache.state_ @X) exclusive))))
 (or $x346 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x543 (not (= (cache.state_ @V0) exclusive))))
 (or $x543 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x797 (not (= (cache.state_ __dir.hptr) exclusive))))
 (or $x797 (not (= (cache.wait __dir.hptr) getX)))))
(assert
 (let (($x801 (not (= (cache.state_ __src) exclusive))))
 (or $x801 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x805 (not (= (cache.state_ home) exclusive))))
 (or $x805 (not (= (cache.wait home) getX)))))
(assert
 (let (($x276 (not (rp_net __src))))
 (let (($x809 (not (__net.put home __src))))
 (or $x809 $x276))))
(assert
 (let (($x350 (not (rp_net @X))))
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (or $x456 $x350)))))
(assert
 (let (($x562 (not (rp_net @V0))))
 (let (($x596 (not (__net.put home @V0))))
 (or $x596 $x562))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x813)))))
(assert
 (let (($x425 (__net.put home @X)))
 (let (($x456 (not $x425)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x456))))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x815 (= ?x332 get)))
 (or $x815 $x817)))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x315 (= ?x305 get)))
 (or $x315 $x596)))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x724 (= ?x707 get)))
 (or $x724 $x647)))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x733 (= ?x712 get)))
 (or $x733 $x820)))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let ((?x726 (cache.wait __src)))
 (let (($x727 (= ?x726 get)))
 (or $x727 $x809)))))
(assert
 (let (($x824 (not (__net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x824)))))
(assert
 (let (($x442 (__net.get @X home)))
 (let (($x471 (not $x442)))
 (let ((?x338 (cache.wait @X)))
 (let (($x354 (= ?x338 get)))
 (or $x354 $x471))))))
(assert
 (let (($x827 (not (__net.get @V1 home))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x815 (= ?x332 get)))
 (or $x815 $x827)))))
(assert
 (let (($x664 (not (__net.get @V0 home))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x315 (= ?x305 get)))
 (or $x315 $x664)))))
(assert
 (let (($x654 (not (__net.get __dir.hptr home))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x724 (= ?x707 get)))
 (or $x724 $x654)))))
(assert
 (let (($x602 (not (__net.get home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x733 (= ?x712 get)))
 (or $x733 $x602)))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x465 (not $x271)))
 (let ((?x726 (cache.wait __src)))
 (let (($x727 (= ?x726 get)))
 (or $x727 $x465))))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x596)))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x598)))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x600)))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x647)))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x650)))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x809)))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x813)))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x817)))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x549)))))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 $x588)))))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 $x590)))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x639)))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x642)))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x773)))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x776)))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x779)))))
(assert
 (let (($x602 (not (__net.get home home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x602)))))
(assert
 (let (($x604 (not (__net.get home @Y))))
 (let (($x449 (= @Y real_owner)))
 (let (($x325 (= @Y home)))
 (or $x325 $x449 $x604)))))
(assert
 (let (($x606 (not (__net.get home @Z))))
 (let (($x452 (= @Z real_owner)))
 (let (($x418 (= @Z home)))
 (or $x418 $x452 $x606)))))
(assert
 (let (($x608 (not (__net.get home @V1))))
 (let (($x458 (= @V1 real_owner)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x458 $x608)))))
(assert
 (let (($x654 (not (__net.get __dir.hptr home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x654)))))
(assert
 (let (($x658 (not (__net.get dir.hptr home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x658)))))
(assert
 (let (($x664 (not (__net.get @V0 home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x664)))))
(assert
 (let (($x824 (not (__net.get real_owner home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x824)))))
(assert
 (let (($x786 (not (net.getX home home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x786)))))
(assert
 (let (($x789 (not (net.getX @V1 home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x789)))))
(assert
 (let (($x792 (not (net.getX @V0 home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x792)))))
(assert
 (let (($x832 (not (net.getX home @Z))))
 (let (($x452 (= @Z real_owner)))
 (let (($x418 (= @Z home)))
 (or $x418 $x452 $x832)))))
(assert
 (let (($x834 (not (net.getX home @V0))))
 (let (($x480 (= @V0 real_owner)))
 (let (($x479 (= @V0 home)))
 (or $x479 $x480 $x834)))))
(assert
 (let (($x836 (not (net.getX home @V1))))
 (let (($x458 (= @V1 real_owner)))
 (let (($x300 (= @V1 home)))
 (or $x300 $x458 $x836)))))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (let (($x423 (= home home)))
 (or $x423 $x596 dir.dirty))))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x598 dir.dirty))))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x600 dir.dirty))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x647 dir.dirty))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x650 dir.dirty))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let (($x423 (= home home)))
 (or $x423 $x809 dir.dirty))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let (($x423 (= home home)))
 (or $x423 $x813 dir.dirty))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let (($x423 (= home home)))
 (or $x423 $x817 dir.dirty))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x423 (= home home)))
 (or $x423 $x549 __dir.head))))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x588 __dir.head))))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x590 __dir.head))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x639 __dir.head))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x642 __dir.head))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x423 (= home home)))
 (or $x423 $x773 __dir.head))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let (($x423 (= home home)))
 (or $x423 $x776 __dir.head))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x779 __dir.head))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x423 (= home home)))
 (or $x423 $x549 dir.dirty))))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x588 dir.dirty))))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x590 dir.dirty))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x639 dir.dirty))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x642 dir.dirty))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x423 (= home home)))
 (or $x423 $x773 dir.dirty))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let (($x423 (= home home)))
 (or $x423 $x776 dir.dirty))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x779 dir.dirty))))
(assert
 (let (($x549 (not (net.putX home @V0))))
 (let (($x423 (= home home)))
 (or $x423 $x549))))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x588))))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x590))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x639))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x642))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x423 (= home home)))
 (or $x423 $x773))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let (($x423 (= home home)))
 (or $x423 $x776))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x779))))
(assert
 (let (($x602 (not (__net.get home home))))
 (let (($x423 (= home home)))
 (or $x423 $x602 __dir.head))))
(assert
 (let (($x604 (not (__net.get home @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x604 __dir.head))))
(assert
 (let (($x606 (not (__net.get home @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x606 __dir.head))))
(assert
 (let (($x608 (not (__net.get home @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x608 __dir.head))))
(assert
 (let (($x654 (not (__net.get __dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x654 __dir.head))))
(assert
 (let (($x658 (not (__net.get dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x658 __dir.head))))
(assert
 (let (($x664 (not (__net.get @V0 home))))
 (let (($x423 (= home home)))
 (or $x423 $x664 __dir.head))))
(assert
 (let (($x824 (not (__net.get real_owner home))))
 (let (($x423 (= home home)))
 (or $x423 $x824 __dir.head))))
(assert
 (let (($x602 (not (__net.get home home))))
 (let (($x423 (= home home)))
 (or $x423 $x602 dir.dirty))))
(assert
 (let (($x604 (not (__net.get home @Y))))
 (let (($x325 (= @Y home)))
 (or $x325 $x604 dir.dirty))))
(assert
 (let (($x606 (not (__net.get home @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x606 dir.dirty))))
(assert
 (let (($x608 (not (__net.get home @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x608 dir.dirty))))
(assert
 (let (($x654 (not (__net.get __dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x654 dir.dirty))))
(assert
 (let (($x658 (not (__net.get dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x658 dir.dirty))))
(assert
 (let (($x664 (not (__net.get @V0 home))))
 (let (($x423 (= home home)))
 (or $x423 $x664 dir.dirty))))
(assert
 (let (($x824 (not (__net.get real_owner home))))
 (let (($x423 (= home home)))
 (or $x423 $x824 dir.dirty))))
(assert
 (let (($x786 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x786 __dir.head))))
(assert
 (let (($x789 (not (net.getX @V1 home))))
 (let (($x423 (= home home)))
 (or $x423 $x789 __dir.head))))
(assert
 (let (($x792 (not (net.getX @V0 home))))
 (let (($x423 (= home home)))
 (or $x423 $x792 __dir.head))))
(assert
 (let (($x832 (not (net.getX home @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x832 __dir.head))))
(assert
 (let (($x834 (not (net.getX home @V0))))
 (let (($x479 (= @V0 home)))
 (or $x479 $x834 __dir.head))))
(assert
 (let (($x836 (not (net.getX home @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x836 __dir.head))))
(assert
 (let (($x786 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x786 dir.dirty))))
(assert
 (let (($x789 (not (net.getX @V1 home))))
 (let (($x423 (= home home)))
 (or $x423 $x789 dir.dirty))))
(assert
 (let (($x792 (not (net.getX @V0 home))))
 (let (($x423 (= home home)))
 (or $x423 $x792 dir.dirty))))
(assert
 (let (($x832 (not (net.getX home @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x832 dir.dirty))))
(assert
 (let (($x834 (not (net.getX home @V0))))
 (let (($x479 (= @V0 home)))
 (or $x479 $x834 dir.dirty))))
(assert
 (let (($x836 (not (net.getX home @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x836 dir.dirty))))
(assert
 (let (($x786 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x786))))
(assert
 (let (($x789 (not (net.getX @V1 home))))
 (let (($x423 (= home home)))
 (or $x423 $x789))))
(assert
 (let (($x792 (not (net.getX @V0 home))))
 (let (($x423 (= home home)))
 (or $x423 $x792))))
(assert
 (let (($x832 (not (net.getX home @Z))))
 (let (($x418 (= @Z home)))
 (or $x418 $x832))))
(assert
 (let (($x834 (not (net.getX home @V0))))
 (let (($x479 (= @V0 home)))
 (or $x479 $x834))))
(assert
 (let (($x836 (not (net.getX home @V1))))
 (let (($x300 (= @V1 home)))
 (or $x300 $x836))))
(assert
 (let (($x786 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (let (($x530 (= home requester)))
 (or $x530 $x423 $x786)))))
(assert
 (let (($x789 (not (net.getX @V1 home))))
 (let (($x423 (= home home)))
 (let (($x533 (= @V1 requester)))
 (or $x533 $x423 $x789)))))
(assert
 (let (($x792 (not (net.getX @V0 home))))
 (let (($x423 (= home home)))
 (let (($x535 (= @V0 requester)))
 (or $x535 $x423 $x792)))))
(assert
 (let (($x832 (not (net.getX home @Z))))
 (let (($x418 (= @Z home)))
 (let (($x530 (= home requester)))
 (or $x530 $x418 $x832)))))
(assert
 (let (($x834 (not (net.getX home @V0))))
 (let (($x479 (= @V0 home)))
 (let (($x530 (= home requester)))
 (or $x530 $x479 $x834)))))
(assert
 (let (($x836 (not (net.getX home @V1))))
 (let (($x300 (= @V1 home)))
 (let (($x530 (= home requester)))
 (or $x530 $x300 $x836)))))
(assert
 (let (($x797 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x797))))
(assert
 (let (($x801 (not (= (cache.state_ __src) exclusive))))
 (let (($x941 (= __src real_owner)))
 (or $x941 $x801))))
(assert
 (let (($x805 (not (= (cache.state_ home) exclusive))))
 (let (($x455 (= home real_owner)))
 (or $x455 $x805))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x944 (= __dir.hptr __dir.hptr)))
 (or $x944 $x639))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (or (= dir.hptr __dir.hptr) $x642)))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x948 (= real_owner __dir.hptr)))
 (or $x948 $x773))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (or (= @V1 __dir.hptr) $x776)))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x952 (= home __dir.hptr)))
 (or $x952 $x779))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (let (($x954 (= __src __dir.hptr)))
 (or $x954 $x783))))
(assert
 (let (($x797 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x944 (= __dir.hptr __dir.hptr)))
 (or $x944 $x797))))
(assert
 (let (($x801 (not (= (cache.state_ __src) exclusive))))
 (let (($x954 (= __src __dir.hptr)))
 (or $x954 $x801))))
(assert
 (let (($x805 (not (= (cache.state_ home) exclusive))))
 (let (($x952 (= home __dir.hptr)))
 (or $x952 $x805))))
(assert
 (let (($x960 (not (= (cache.state_ __dir.hptr) shared))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x960))))
(assert
 (let (($x963 (not (= (cache.state_ __src) shared))))
 (let (($x941 (= __src real_owner)))
 (or $x941 $x963))))
(assert
 (let (($x966 (not (= (cache.state_ home) shared))))
 (let (($x455 (= home real_owner)))
 (or $x455 $x966))))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x588))))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x590))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x639))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x642))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x423 (= home home)))
 (or $x423 $x773))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let (($x423 (= home home)))
 (or $x423 $x776))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x779))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (let (($x423 (= home home)))
 (or $x423 $x783))))
(assert
 (let (($x963 (not (= (cache.state_ __src) shared))))
 (let (($x276 (not (rp_net __src))))
 (or $x276 $x963))))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (let (($x564 (= real_owner @X)))
 (or $x564 $x588))))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (let (($x568 (= real_owner @V0)))
 (or $x568 $x590))))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (let (($x948 (= real_owner __dir.hptr)))
 (or $x948 $x639))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (or (= real_owner dir.hptr) $x642)))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x847 (= real_owner real_owner)))
 (or $x847 $x773))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x776)))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x846 (= real_owner home)))
 (or $x846 $x779))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (or (= real_owner __src) $x783)))
(assert
 (let (($x596 (not (__net.put home @V0))))
 (or $x596 __dir.head)))
(assert
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (or $x598 __dir.head)))
(assert
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (or $x600 __dir.head)))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (or $x647 __dir.head)))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (or $x650 __dir.head)))
(assert
 (let (($x809 (not (__net.put home __src))))
 (or $x809 __dir.head)))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (or $x813 __dir.head)))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (or $x817 __dir.head)))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (or $x588 __dir.head)))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (or $x590 __dir.head)))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (or $x639 __dir.head)))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (or $x642 __dir.head)))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (or $x773 __dir.head)))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (or $x776 __dir.head)))
(assert
 (let (($x779 (not (net.putX home home))))
 (or $x779 __dir.head)))
(assert
 (let (($x783 (not (net.putX home __src))))
 (or $x783 __dir.head)))
(assert
 (let (($x588 (not (net.putX real_owner @X))))
 (or $x588 dir.dirty)))
(assert
 (let (($x590 (not (net.putX real_owner @V0))))
 (or $x590 dir.dirty)))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (or $x639 dir.dirty)))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (or $x642 dir.dirty)))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (or $x773 dir.dirty)))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (or $x776 dir.dirty)))
(assert
 (let (($x779 (not (net.putX home home))))
 (or $x779 dir.dirty)))
(assert
 (let (($x783 (not (net.putX home __src))))
 (or $x783 dir.dirty)))
(assert
 (not (net.putX real_owner __dir.hptr)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (not (net.putX real_owner __src)))
(assert
 (let (($x639 (not (net.putX home __dir.hptr))))
 (or $x639 __dir.head)))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (or $x642 __dir.head)))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (or $x773 __dir.head)))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (or $x776 __dir.head)))
(assert
 (let (($x779 (not (net.putX home home))))
 (or $x779 __dir.head)))
(assert
 (let (($x783 (not (net.putX home __src))))
 (or $x783 __dir.head)))
(assert
 (not (net.putX home __dir.hptr)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (not (net.putX home __src)))
(assert
 (let (($x562 (not (rp_net @V0))))
 (let (($x596 (not (__net.put home @V0))))
 (or $x596 $x562))))
(assert
 (let (($x350 (not (rp_net @X))))
 (let (($x598 (not (__net.put __dir.hptr @X))))
 (or $x598 $x350))))
(assert
 (let (($x562 (not (rp_net @V0))))
 (let (($x600 (not (__net.put __dir.hptr @V0))))
 (or $x600 $x562))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (or $x647 (not (rp_net __dir.hptr)))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (or $x650 (not (rp_net dir.hptr)))))
(assert
 (let (($x276 (not (rp_net __src))))
 (let (($x809 (not (__net.put home __src))))
 (or $x809 $x276))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (or $x813 (not (rp_net real_owner)))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (or $x817 (not (rp_net @V1)))))
(assert
 (not (__net.put home __dir.hptr)))
(assert
 (not (__net.put home dir.hptr)))
(assert
 (not (__net.put home __src)))
(assert
 (not (__net.put home real_owner)))
(assert
 (not (__net.put home @V1)))
(assert
 (not (__net.put home home)))
(assert
 (not (__net.put __dir.hptr __dir.hptr)))
(assert
 (not (__net.put __dir.hptr dir.hptr)))
(assert
 (not (__net.put __dir.hptr __src)))
(assert
 (not (__net.put __dir.hptr real_owner)))
(assert
 (not (__net.put __dir.hptr @V1)))
(assert
 (not (__net.put __dir.hptr home)))
(assert
 (let (($x610 (not (invack @X))))
 (or $x610 (not (invnet @X)))))
(assert
 (let (($x613 (not (invack @V0))))
 (or $x613 (not (invnet @V0)))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x647 dir.pending))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x650 dir.pending))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x809 dir.pending))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let (($x1053 (__dir.shlist real_owner)))
 (or $x1053 $x813 dir.pending))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let (($x1055 (__dir.shlist @V1)))
 (or $x1055 $x817 dir.pending))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x820 dir.pending))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x1032 dir.pending))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x1034 dir.pending))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x647 dir.dirty))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x650 dir.dirty))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x809 dir.dirty))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let (($x1053 (__dir.shlist real_owner)))
 (or $x1053 $x813 dir.dirty))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let (($x1055 (__dir.shlist @V1)))
 (or $x1055 $x817 dir.dirty))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x820 dir.dirty))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x1032 dir.dirty))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x1034 dir.dirty))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x647))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x650))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x809))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let (($x1053 (__dir.shlist real_owner)))
 (or $x1053 $x813))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let (($x1055 (__dir.shlist @V1)))
 (or $x1055 $x817))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x820))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x1032))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x1034))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x783))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x1053 (__dir.shlist real_owner)))
 (or $x1053 $x773))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let (($x1055 (__dir.shlist @V1)))
 (or $x1055 $x776))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x779))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x809))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let (($x1053 (__dir.shlist real_owner)))
 (or $x1053 $x813))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let (($x1055 (__dir.shlist @V1)))
 (or $x1055 $x817))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x820))))
(assert
 (let (($x271 (__net.get __src home)))
 (let (($x465 (not $x271)))
 (let (($x1051 (__dir.shlist __src)))
 (let (($x1079 (not $x1051)))
 (or $x1079 $x465))))))
(assert
 (let (($x824 (not (__net.get real_owner home))))
 (let (($x1053 (__dir.shlist real_owner)))
 (let (($x1081 (not $x1053)))
 (or $x1081 $x824)))))
(assert
 (let (($x827 (not (__net.get @V1 home))))
 (let (($x1055 (__dir.shlist @V1)))
 (let (($x1083 (not $x1055)))
 (or $x1083 $x827)))))
(assert
 (let (($x602 (not (__net.get home home))))
 (let (($x1057 (__dir.shlist home)))
 (let (($x1085 (not $x1057)))
 (or $x1085 $x602)))))
(assert
 (let (($x1051 (__dir.shlist __src)))
 (let (($x1079 (not $x1051)))
 (or $x1079 __dir.head))))
(assert
 (let (($x1053 (__dir.shlist real_owner)))
 (let (($x1081 (not $x1053)))
 (or $x1081 __dir.head))))
(assert
 (let (($x1055 (__dir.shlist @V1)))
 (let (($x1083 (not $x1055)))
 (or $x1083 __dir.head))))
(assert
 (let (($x1057 (__dir.shlist home)))
 (let (($x1085 (not $x1057)))
 (or $x1085 __dir.head))))
(assert
 (let (($x797 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x797))))
(assert
 (let (($x801 (not (= (cache.state_ __src) exclusive))))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x801))))
(assert
 (let (($x805 (not (= (cache.state_ home) exclusive))))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x805))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let (($x1094 (= dir.hptr home)))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x1094 $x650)))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let (($x1096 (= __src home)))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x1096 $x809)))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let (($x846 (= real_owner home)))
 (let (($x1053 (__dir.shlist real_owner)))
 (or $x1053 $x846 $x813)))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let (($x300 (= @V1 home)))
 (let (($x1055 (__dir.shlist @V1)))
 (or $x1055 $x300 $x817)))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let (($x423 (= home home)))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x423 $x820)))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let (($x680 (= __dir.hptr home)))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 $x680 $x1032)))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let (($x1094 (= dir.hptr home)))
 (let (($x410 (__dir.shlist dir.hptr)))
 (or $x410 $x1094 $x1034)))))
(assert
 (let (($x1036 (not (__net.put __dir.hptr __src))))
 (let (($x1096 (= __src home)))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 $x1096 $x1036)))))
(assert
 (let (($x797 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x56 (__dir.shlist __dir.hptr)))
 (or $x56 (= __dir.hptr requester) $x797))))
(assert
 (let (($x801 (not (= (cache.state_ __src) exclusive))))
 (let (($x1051 (__dir.shlist __src)))
 (or $x1051 (= __src requester) $x801))))
(assert
 (let (($x805 (not (= (cache.state_ home) exclusive))))
 (let (($x530 (= home requester)))
 (let (($x1057 (__dir.shlist home)))
 (or $x1057 $x530 $x805)))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x773))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x776))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x779))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x783))))
(assert
 (let (($x960 (not (= (cache.state_ __dir.hptr) shared))))
 (or $x960 (not (= (cache.wait __dir.hptr) get)))))
(assert
 (let (($x963 (not (= (cache.state_ __src) shared))))
 (or $x963 (not (= (cache.wait __src) get)))))
(assert
 (let (($x966 (not (= (cache.state_ home) shared))))
 (or $x966 (not (= (cache.wait home) get)))))
(assert
 (let (($x797 (not (= (cache.state_ __dir.hptr) exclusive))))
 (or $x797 __dir.head)))
(assert
 (let (($x801 (not (= (cache.state_ __src) exclusive))))
 (or $x801 __dir.head)))
(assert
 (let (($x805 (not (= (cache.state_ home) exclusive))))
 (or $x805 __dir.head)))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1123 (= ?x1122 getX)))
 (or $x1123 $x642)))))
(assert
 (let (($x773 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x771 (= ?x140 getX)))
 (or $x771 $x773)))))
(assert
 (let (($x776 (not (net.putX home @V1))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x715 (= ?x332 getX)))
 (or $x715 $x776)))))
(assert
 (let (($x779 (not (net.putX home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x779)))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (let ((?x726 (cache.wait __src)))
 (let (($x781 (= ?x726 getX)))
 (or $x781 $x783)))))
(assert
 (let (($x1006 (not (net.putX real_owner __dir.hptr))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x708 (= ?x707 getX)))
 (or $x708 $x1006)))))
(assert
 (let (($x1008 (not (net.putX real_owner dir.hptr))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1123 (= ?x1122 getX)))
 (or $x1123 $x1008)))))
(assert
 (let (($x1010 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x771 (= ?x140 getX)))
 (or $x771 $x1010)))))
(assert
 (let (($x786 (not (net.getX home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x786)))))
(assert
 (let (($x789 (not (net.getX @V1 home))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x715 (= ?x332 getX)))
 (or $x715 $x789)))))
(assert
 (let (($x792 (not (net.getX @V0 home))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x306 (= ?x305 getX)))
 (or $x306 $x792)))))
(assert
 (let (($x832 (not (net.getX home @Z))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x832)))))
(assert
 (let (($x834 (not (net.getX home @V0))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x834)))))
(assert
 (let (($x836 (not (net.getX home @V1))))
 (let ((?x712 (cache.wait home)))
 (let (($x713 (= ?x712 getX)))
 (or $x713 $x836)))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1131 (= ?x1122 get)))
 (or $x1131 $x650)))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let ((?x726 (cache.wait __src)))
 (let (($x727 (= ?x726 get)))
 (or $x727 $x809)))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x813)))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x815 (= ?x332 get)))
 (or $x815 $x817)))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let ((?x712 (cache.wait home)))
 (let (($x733 (= ?x712 get)))
 (or $x733 $x820)))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x724 (= ?x707 get)))
 (or $x724 $x1032)))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1131 (= ?x1122 get)))
 (or $x1131 $x1034)))))
(assert
 (let (($x1036 (not (__net.put __dir.hptr __src))))
 (let ((?x726 (cache.wait __src)))
 (let (($x727 (= ?x726 get)))
 (or $x727 $x1036)))))
(assert
 (let (($x608 (not (__net.get home @V1))))
 (let ((?x712 (cache.wait home)))
 (let (($x733 (= ?x712 get)))
 (or $x733 $x608)))))
(assert
 (let (($x654 (not (__net.get __dir.hptr home))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x724 (= ?x707 get)))
 (or $x724 $x654)))))
(assert
 (let (($x658 (not (__net.get dir.hptr home))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1131 (= ?x1122 get)))
 (or $x1131 $x658)))))
(assert
 (let (($x664 (not (__net.get @V0 home))))
 (let ((?x305 (cache.wait @V0)))
 (let (($x315 (= ?x305 get)))
 (or $x315 $x664)))))
(assert
 (let (($x824 (not (__net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x824)))))
(assert
 (let (($x827 (not (__net.get @V1 home))))
 (let ((?x332 (cache.wait @V1)))
 (let (($x815 (= ?x332 get)))
 (or $x815 $x827)))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let ((?x1138 (cache.state_ dir.hptr)))
 (let (($x1139 (= ?x1138 invalid)))
 (or $x1139 $x650)))))
(assert
 (let (($x809 (not (__net.put home __src))))
 (let ((?x747 (cache.state_ __src)))
 (let (($x748 (= ?x747 invalid)))
 (or $x748 $x809)))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (let ((?x1142 (cache.state_ real_owner)))
 (let (($x1143 (= ?x1142 invalid)))
 (or $x1143 $x813)))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (let ((?x1145 (cache.state_ @V1)))
 (let (($x1146 (= ?x1145 invalid)))
 (or $x1146 $x817)))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let ((?x754 (cache.state_ home)))
 (let (($x755 (= ?x754 invalid)))
 (or $x755 $x820)))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let ((?x744 (cache.state_ __dir.hptr)))
 (let (($x745 (= ?x744 invalid)))
 (or $x745 $x1032)))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let ((?x1138 (cache.state_ dir.hptr)))
 (let (($x1139 (= ?x1138 invalid)))
 (or $x1139 $x1034)))))
(assert
 (let (($x1036 (not (__net.put __dir.hptr __src))))
 (let ((?x747 (cache.state_ __src)))
 (let (($x748 (= ?x747 invalid)))
 (or $x748 $x1036)))))
(assert
 (let (($x608 (not (__net.get home @V1))))
 (let ((?x754 (cache.state_ home)))
 (let (($x755 (= ?x754 invalid)))
 (or $x755 $x608)))))
(assert
 (let (($x654 (not (__net.get __dir.hptr home))))
 (let ((?x744 (cache.state_ __dir.hptr)))
 (let (($x745 (= ?x744 invalid)))
 (or $x745 $x654)))))
(assert
 (let (($x658 (not (__net.get dir.hptr home))))
 (let ((?x1138 (cache.state_ dir.hptr)))
 (let (($x1139 (= ?x1138 invalid)))
 (or $x1139 $x658)))))
(assert
 (let (($x664 (not (__net.get @V0 home))))
 (let ((?x320 (cache.state_ @V0)))
 (let (($x321 (= ?x320 invalid)))
 (or $x321 $x664)))))
(assert
 (let (($x824 (not (__net.get real_owner home))))
 (let ((?x1142 (cache.state_ real_owner)))
 (let (($x1143 (= ?x1142 invalid)))
 (or $x1143 $x824)))))
(assert
 (let (($x827 (not (__net.get @V1 home))))
 (let ((?x1145 (cache.state_ @V1)))
 (let (($x1146 (= ?x1145 invalid)))
 (or $x1146 $x827)))))
(assert
 (let (($x765 (not (= (cache.wait home) none))))
 (let (($x786 (not (net.getX home home))))
 (or $x786 $x765))))
(assert
 (let (($x334 (not (= (cache.wait @V1) none))))
 (let (($x789 (not (net.getX @V1 home))))
 (or $x789 $x334))))
(assert
 (let (($x769 (not (= (cache.wait @V0) none))))
 (let (($x792 (not (net.getX @V0 home))))
 (or $x792 $x769))))
(assert
 (let (($x765 (not (= (cache.wait home) none))))
 (let (($x832 (not (net.getX home @Z))))
 (or $x832 $x765))))
(assert
 (let (($x765 (not (= (cache.wait home) none))))
 (let (($x834 (not (net.getX home @V0))))
 (or $x834 $x765))))
(assert
 (let (($x765 (not (= (cache.wait home) none))))
 (let (($x836 (not (net.getX home @V1))))
 (or $x836 $x765))))
(assert
 (let (($x642 (not (net.putX home dir.hptr))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1123 (= ?x1122 getX)))
 (or $x1123 $x642)))))
(assert
 (let (($x1165 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x771 (= ?x140 getX)))
 (or $x771 $x1165)))))
(assert
 (let (($x1168 (not (net.getX __dir.hptr home))))
 (let ((?x707 (cache.wait __dir.hptr)))
 (let (($x708 (= ?x707 getX)))
 (or $x708 $x1168)))))
(assert
 (let (($x1171 (not (net.getX __src home))))
 (let ((?x726 (cache.wait __src)))
 (let (($x781 (= ?x726 getX)))
 (or $x781 $x1171)))))
(assert
 (let (($x1174 (not (net.getX dir.hptr home))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1123 (= ?x1122 getX)))
 (or $x1123 $x1174)))))
(assert
 (or (not (= (cache.state_ real_owner) exclusive)) (not (= (cache.wait real_owner) getX))))
(assert
 (or (not (= (cache.state_ @V1) exclusive)) (not (= (cache.wait @V1) getX))))
(assert
 (or (not (= (cache.state_ dir.hptr) exclusive)) (not (= (cache.wait dir.hptr) getX))))
(assert
 (let (($x647 (not (__net.put home __dir.hptr))))
 (or $x647 (not (rp_net __dir.hptr)))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (or $x650 (not (rp_net dir.hptr)))))
(assert
 (let (($x813 (not (__net.put home real_owner))))
 (or $x813 (not (rp_net real_owner)))))
(assert
 (let (($x817 (not (__net.put home @V1))))
 (or $x817 (not (rp_net @V1)))))
(assert
 (let (($x650 (not (__net.put home dir.hptr))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1131 (= ?x1122 get)))
 (or $x1131 $x650)))))
(assert
 (let (($x658 (not (__net.get dir.hptr home))))
 (let ((?x1122 (cache.wait dir.hptr)))
 (let (($x1131 (= ?x1122 get)))
 (or $x1131 $x658)))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x820)))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x1032)))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x1034)))))
(assert
 (let (($x1036 (not (__net.put __dir.hptr __src))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x1036)))))
(assert
 (let (($x1038 (not (__net.put __dir.hptr real_owner))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x1038)))))
(assert
 (let (($x1040 (not (__net.put __dir.hptr @V1))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x1040)))))
(assert
 (let (($x1042 (not (__net.put __dir.hptr home))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x145 $x1042)))))
(assert
 (let (($x783 (not (net.putX home __src))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x783)))))
(assert
 (let (($x1006 (not (net.putX real_owner __dir.hptr))))
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 $x1006)))))
(assert
 (let (($x1008 (not (net.putX real_owner dir.hptr))))
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 $x1008)))))
(assert
 (let (($x1010 (not (net.putX real_owner real_owner))))
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 $x1010)))))
(assert
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 (not (net.putX real_owner @V1))))))
(assert
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 (not (net.putX real_owner home))))))
(assert
 (let (($x847 (= real_owner real_owner)))
 (let (($x846 (= real_owner home)))
 (or $x846 $x847 (not (net.putX real_owner __src))))))
(assert
 (let (($x827 (not (__net.get @V1 home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x827)))))
(assert
 (let (($x1165 (not (net.getX real_owner home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x1165)))))
(assert
 (let (($x1168 (not (net.getX __dir.hptr home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x1168)))))
(assert
 (let (($x1171 (not (net.getX __src home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x1171)))))
(assert
 (let (($x1174 (not (net.getX dir.hptr home))))
 (let (($x455 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x455 $x1174)))))
(assert
 (let (($x820 (not (__net.put home home))))
 (let (($x423 (= home home)))
 (or $x423 $x820 dir.dirty))))
(assert
 (let (($x1032 (not (__net.put __dir.hptr __dir.hptr))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x1032 dir.dirty))))
(assert
 (let (($x1034 (not (__net.put __dir.hptr dir.hptr))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x1034 dir.dirty))))
(assert
 (let (($x1036 (not (__net.put __dir.hptr __src))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x1036 dir.dirty))))
(assert
 (let (($x1038 (not (__net.put __dir.hptr real_owner))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x1038 dir.dirty))))
(assert
 (let (($x1040 (not (__net.put __dir.hptr @V1))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x1040 dir.dirty))))
(assert
 (let (($x1042 (not (__net.put __dir.hptr home))))
 (let (($x680 (= __dir.hptr home)))
 (or $x680 $x1042 dir.dirty))))
(check-sat)
