(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun cache.invmarked (id) Bool)
(declare-fun dir.local_ () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (cache.wait real_owner) get)))
(assert
 (let (($x144 (not dir.dirty)))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x144 dir.pending))))
(assert
 (not (net.fack requester home)))
(assert
 (let ((?x270 (__cache.state_ home)))
 (= ?x270 invalid)))
(assert
 (let ((?x272 (cache.wait home)))
 (= ?x272 none)))
(assert
 (not dir.pending))
(assert
 (not dir.dirty))
(assert
 (not (cache.invmarked home)))
(assert
 dir.local_)
(assert
 (let ((?x291 (cache.wait @Y)))
 (let (($x292 (= ?x291 none)))
 (let ((?x286 (cache.wait @X)))
 (let (($x287 (= ?x286 none)))
 (and (= (cache.state_ @X) exclusive) $x287 (= (cache.state_ @Y) exclusive) $x292 (not (= @X @Y))))))))
(assert
 (let ((?x284 (cache.state_ @X)))
 (= ?x284 (ite (and (= @X home)) shared (__cache.state_ @X)))))
(assert
 (let ((?x289 (cache.state_ @Y)))
 (= ?x289 (ite (and (= @Y home)) shared (__cache.state_ @Y)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x328 (not (= (__cache.state_ home) exclusive))))
 (let (($x326 (= home real_owner)))
 (or $x326 $x328))))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (let (($x330 (= @X real_owner)))
 (or $x330 $x332))))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x334 (= @Y real_owner)))
 (or $x334 $x336))))
(assert
 (let (($x328 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x328)))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x332)))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x336)))
(assert
 (let (($x345 (not (= (__cache.state_ home) shared))))
 (let (($x326 (= home real_owner)))
 (or $x326 $x345))))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (let (($x330 (= @X real_owner)))
 (or $x330 $x348))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (let (($x334 (= @Y real_owner)))
 (or $x334 $x351))))
(assert
 (let (($x345 (not (= (__cache.state_ home) shared))))
 (or (not (rp_net home)) $x345)))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x348)))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x351)))
(assert
 (let (($x345 (not (= (__cache.state_ home) shared))))
 (let (($x363 (not (invack home))))
 (or $x363 $x345))))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (let (($x366 (not (invack @X))))
 (or $x366 $x348))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (let (($x369 (not (invack @Y))))
 (or $x369 $x351))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x372))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x377 (not $x58)))
 (or $x377 $x379)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x377 (not $x58)))
 (or $x377 dir.head))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x384))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x386 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x386 $x375)))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x388 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x388 $x384)))))
(assert
 (let ((?x270 (__cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (let (($x326 (= home real_owner)))
 (or (dir.real home) $x326 $x271)))))
(assert
 (let ((?x316 (__cache.state_ @X)))
 (let (($x393 (= ?x316 invalid)))
 (let (($x330 (= @X real_owner)))
 (or (dir.real @X) $x330 $x393)))))
(assert
 (let ((?x321 (__cache.state_ @Y)))
 (let (($x396 (= ?x321 invalid)))
 (let (($x334 (= @Y real_owner)))
 (or (dir.real @Y) $x334 $x396)))))
(assert
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x399 (= ?x382 invalid)))
 (let (($x145 (= dir.hptr real_owner)))
 (or (dir.real dir.hptr) $x145 $x399)))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x372))))
(assert
 (let (($x142 (not (= (cache.wait real_owner) get))))
 (let (($x404 (not (= (__cache.state_ real_owner) shared))))
 (or $x404 $x142))))
(assert
 (let (($x345 (not (= (__cache.state_ home) shared))))
 (or $x345 (not (= (cache.wait home) get)))))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (or $x348 (not (= (cache.wait @X) get)))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (or $x351 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x363 (not (invack home))))
 (let ((?x270 (__cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x363)))))
(assert
 (let (($x366 (not (invack @X))))
 (let ((?x316 (__cache.state_ @X)))
 (let (($x393 (= ?x316 invalid)))
 (or $x393 $x366)))))
(assert
 (let (($x369 (not (invack @Y))))
 (let ((?x321 (__cache.state_ @Y)))
 (let (($x396 (= ?x321 invalid)))
 (or $x396 $x369)))))
(assert
 (let (($x328 (not (= (__cache.state_ home) exclusive))))
 (or $x328 dir.head)))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (or $x332 dir.head)))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (or $x336 dir.head)))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x384 dir.head)))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x423 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x425 (= home home)))
 (or $x425 $x187))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x372)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x375)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x379)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x399 (= ?x382 invalid)))
 (or $x399 $x375)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x399 (= ?x382 invalid)))
 (or $x399 $x379)))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x372)))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x435 (= ?x140 getX)))
 (or $x435 $x437)))))
(assert
 (let (($x441 (not (net.getX home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x439 (= ?x272 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (let ((?x286 (cache.wait @X)))
 (let (($x443 (= ?x286 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (let ((?x291 (cache.wait @Y)))
 (let (($x447 (= ?x291 getX)))
 (or $x447 $x449)))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x452)))))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x423 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x328 (not (= (__cache.state_ home) exclusive))))
 (or $x328 (not (= (cache.wait home) getX)))))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (or $x332 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (or $x336 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x384 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x465 (not (rp_net dir.hptr))))
 (let (($x375 (not (net.put home dir.hptr))))
 (or $x375 $x465))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x375)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x379)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x375)))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x372)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x379)))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x437)))))
(assert
 (let (($x441 (not (net.getX home home))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x441)))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x445)))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x449)))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x452)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x375 dir.dirty))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x372 dir.head))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x372 dir.dirty))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x372))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x379 dir.head))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x379 dir.dirty))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or $x425 $x437 dir.head))))
(assert
 (let (($x441 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or $x425 $x441 dir.head))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or $x425 $x445 dir.head))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or $x425 $x449 dir.head))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x452 dir.head))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or $x425 $x437 dir.dirty))))
(assert
 (let (($x441 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or $x425 $x441 dir.dirty))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or $x425 $x445 dir.dirty))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or $x425 $x449 dir.dirty))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x452 dir.dirty))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or $x425 $x437))))
(assert
 (let (($x441 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or $x425 $x441))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or $x425 $x445))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or $x425 $x449))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (or $x425 $x452))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let (($x425 (= home home)))
 (or (= real_owner requester) $x425 $x437))))
(assert
 (let (($x441 (not (net.getX home home))))
 (let (($x425 (= home home)))
 (or (= home requester) $x425 $x441))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (let (($x425 (= home home)))
 (or (= @X requester) $x425 $x445))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (let (($x425 (= home home)))
 (or (= @Y requester) $x425 $x449))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (let (($x425 (= home home)))
 (let (($x388 (= dir.hptr requester)))
 (or $x388 $x425 $x452)))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x384))))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x506 (= real_owner real_owner)))
 (or $x506 $x423))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x508 (= dir.hptr dir.hptr)))
 (or $x508 $x372))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x508 (= dir.hptr dir.hptr)))
 (or $x508 $x384))))
(assert
 (let (($x423 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x511 (= real_owner dir.hptr)))
 (or $x511 $x423))))
(assert
 (let (($x514 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x514))))
(assert
 (let (($x404 (not (= (__cache.state_ real_owner) shared))))
 (let (($x506 (= real_owner real_owner)))
 (or $x506 $x404))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x425 (= home home)))
 (or $x425 $x372))))
(assert
 (let (($x514 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x465 (not (rp_net dir.hptr))))
 (or $x465 $x514))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x511 (= real_owner dir.hptr)))
 (or $x511 $x372))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (or $x375 dir.head)))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (or $x372 dir.head)))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (or $x372 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (or $x372 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x465 (not (rp_net dir.hptr))))
 (let (($x375 (not (net.put home dir.hptr))))
 (or $x375 $x465))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.get home home)))
(assert
 (let (($x363 (not (invack home))))
 (or $x363 (not (invnet home)))))
(assert
 (let (($x366 (not (invack @X))))
 (or $x366 (not (invnet @X)))))
(assert
 (let (($x369 (not (invack @Y))))
 (or $x369 (not (invnet @Y)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375 dir.pending))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x525 dir.pending))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375 dir.dirty))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x525 dir.dirty))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x525))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let (($x386 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x386 $x525)))))
(assert
 (let (($x514 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x514 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x523)))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x435 (= ?x140 getX)))
 (or $x435 $x437)))))
(assert
 (let (($x441 (not (net.getX home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x439 (= ?x272 getX)))
 (or $x439 $x441)))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (let ((?x286 (cache.wait @X)))
 (let (($x443 (= ?x286 getX)))
 (or $x443 $x445)))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (let ((?x291 (cache.wait @Y)))
 (let (($x447 (= ?x291 getX)))
 (or $x447 $x449)))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x428 (= ?x427 getX)))
 (or $x428 $x452)))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let ((?x427 (cache.wait dir.hptr)))
 (let (($x430 (= ?x427 get)))
 (or $x430 $x525)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x406 (= ?x272 get)))
 (or $x406 $x527)))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x399 (= ?x382 invalid)))
 (or $x399 $x525)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let ((?x270 (__cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x527)))))
(assert
 (let (($x437 (not (net.getX real_owner home))))
 (or $x437 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x441 (not (net.getX home home))))
 (or $x441 (not (= (cache.wait home) none)))))
(assert
 (let (($x445 (not (net.getX @X home))))
 (or $x445 (not (= (cache.wait @X) none)))))
(assert
 (let (($x449 (not (net.getX @Y home))))
 (or $x449 (not (= (cache.wait @Y) none)))))
(assert
 (let (($x452 (not (net.getX dir.hptr home))))
 (or $x452 (not (= (cache.wait dir.hptr) none)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let ((?x272 (cache.wait home)))
 (let (($x406 (= ?x272 get)))
 (or $x406 $x527)))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x386 (= dir.hptr home)))
 (or $x386 $x145 $x525)))))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (let (($x506 (= real_owner real_owner)))
 (let (($x563 (= real_owner home)))
 (or $x563 $x506 $x523)))))
(assert
 (let (($x527 (not (net.get home home))))
 (let (($x326 (= home real_owner)))
 (let (($x425 (= home home)))
 (or $x425 $x326 $x527)))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (let (($x386 (= dir.hptr home)))
 (or $x386 $x525 dir.dirty))))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (let (($x563 (= real_owner home)))
 (or $x563 $x523 dir.head))))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (let (($x563 (= real_owner home)))
 (or $x563 $x523 dir.dirty))))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (let (($x563 (= real_owner home)))
 (or $x563 $x523))))
(assert
 (let (($x527 (not (net.get home home))))
 (let (($x425 (= home home)))
 (or $x425 $x527 dir.head))))
(assert
 (let (($x527 (not (net.get home home))))
 (let (($x425 (= home home)))
 (or $x425 $x527 dir.dirty))))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (let (($x563 (= real_owner home)))
 (or $x563 $x523))))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (let (($x511 (= real_owner dir.hptr)))
 (or $x511 $x523))))
(assert
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (or $x525 dir.head)))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (or $x523 dir.head)))
(assert
 (let (($x523 (not (net.putX real_owner dir.hptr))))
 (or $x523 dir.dirty)))
(assert
 (let (($x465 (not (rp_net dir.hptr))))
 (let (($x525 (not (net.put dir.hptr dir.hptr))))
 (or $x525 $x465))))
(check-sat)
