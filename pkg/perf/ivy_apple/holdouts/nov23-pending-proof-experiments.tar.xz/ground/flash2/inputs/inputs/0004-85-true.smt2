(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun __dst () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __invack (id) Bool)
(declare-fun __dir.real (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 dir.pending)
(assert
 (__invack __src))
(assert
 (let (($x272 (= __src home)))
 (not $x272)))
(assert
 (__dir.real __dst))
(assert
 (not (= __dst __src)))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x373 (not (net.getX home @Y))))
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x361 (= @Y @Z)))
 (let (($x374 (and (or $x361 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x361 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x361 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x361 $x360 $x352) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x352 (not (net.putX @Y @X))) $x373 $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x335 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x374)))))))))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x395 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x395 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x398 (= @Z real_owner)))
 (let (($x397 (= @Z home)))
 (or $x397 $x398 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x403 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x403 $x303)))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x395 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x395 $x349)))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x398 (= @Z real_owner)))
 (let (($x397 (= @Z home)))
 (or $x397 $x398 $x364)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x403 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x403 $x297)))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let (($x395 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x395 $x367)))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let (($x398 (= @Z real_owner)))
 (let (($x397 (= @Z home)))
 (or $x397 $x398 $x357)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x403 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x403 $x307)))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x395 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x395 $x360)))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x398 (= @Z real_owner)))
 (let (($x397 (= @Z home)))
 (or $x397 $x398 $x352)))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x395 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x395 $x373)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x418 (= @V0 real_owner)))
 (let (($x417 (= @V0 home)))
 (or $x417 $x418 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x403 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x403 $x300)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x355 dir.dirty))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x397 (= @Z home)))
 (or $x397 $x370 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x400 (= home home)))
 (or $x400 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x303 dir.dirty))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349 dir.head))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x397 (= @Z home)))
 (or $x397 $x364 dir.head))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x400 (= home home)))
 (or $x400 $x326 dir.head))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.head))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349 dir.dirty))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x397 (= @Z home)))
 (or $x397 $x364 dir.dirty))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x400 (= home home)))
 (or $x400 $x326 dir.dirty))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.dirty))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x397 (= @Z home)))
 (or $x397 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x400 (= home home)))
 (or $x400 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x367 dir.head))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x357 dir.head))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x400 (= home home)))
 (or $x400 $x346 dir.head))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x307 dir.head))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x367 dir.dirty))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x357 dir.dirty))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x400 (= home home)))
 (or $x400 $x346 dir.dirty))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x307 dir.dirty))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x360 dir.head))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x352 dir.head))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x373 dir.head))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x400 (= home home)))
 (or $x400 $x331 dir.head))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x417 (= @V0 home)))
 (or $x417 $x320 dir.head))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300 dir.head))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x360 dir.dirty))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x352 dir.dirty))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x373 dir.dirty))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x400 (= home home)))
 (or $x400 $x331 dir.dirty))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x417 (= @V0 home)))
 (or $x417 $x320 dir.dirty))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300 dir.dirty))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x360))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x352))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x373))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x400 (= home home)))
 (or $x400 $x331))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x417 (= @V0 home)))
 (or $x417 $x320))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x300))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let (($x314 (= @Y home)))
 (let (($x463 (= @X requester)))
 (or $x463 $x314 $x360)))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let (($x397 (= @Z home)))
 (let (($x463 (= @X requester)))
 (or $x463 $x397 $x352)))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let (($x314 (= @Y home)))
 (let (($x466 (= home requester)))
 (or $x466 $x314 $x373)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let (($x400 (= home home)))
 (let (($x463 (= @X requester)))
 (or $x463 $x400 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let (($x417 (= @V0 home)))
 (let (($x469 (= @V1 requester)))
 (or $x469 $x417 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x471 (= @V0 requester)))
 (or $x471 $x289 $x300)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x418 (= @V0 real_owner)))
 (or $x418 $x292))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x476 (= @X real_owner)))
 (or $x476 $x335))))
(assert
 (let (($x479 (not (= (cache.state_ @V0) exclusive))))
 (let (($x418 (= @V0 real_owner)))
 (or $x418 $x479))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x481 (= @X dir.hptr)))
 (or $x481 $x326))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x483 (= @V0 dir.hptr)))
 (or $x483 $x485))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x481 (= @X dir.hptr)))
 (or $x481 $x335))))
(assert
 (let (($x479 (not (= (cache.state_ @V0) exclusive))))
 (let (($x483 (= @V0 dir.hptr)))
 (or $x483 $x479))))
(assert
 (let (($x490 (not (= (cache.state_ @X) shared))))
 (let (($x476 (= @X real_owner)))
 (or $x476 $x490))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) shared))))
 (let (($x418 (= @V0 real_owner)))
 (or $x418 $x493))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x397 (= @Z home)))
 (or $x397 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x400 (= home home)))
 (or $x400 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x400 (= home home)))
 (or $x400 $x485))))
(assert
 (let (($x490 (not (= (cache.state_ @X) shared))))
 (let (($x339 (not (rp_net @X))))
 (or $x339 $x490))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x497 (= real_owner @X)))
 (or $x497 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x497 (= real_owner @X)))
 (or $x497 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x497 (= real_owner @X)))
 (or $x497 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x501 (= real_owner @V0)))
 (or $x501 $x297))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x501 (= real_owner @V0)))
 (or $x501 $x485))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (or $x355 dir.head)))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (or $x370 dir.head)))
(assert
 (let (($x341 (not (net.put home @X))))
 (or $x341 dir.head)))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 dir.head)))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (or $x349 dir.head)))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (or $x364 dir.head)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.head)))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (or $x485 dir.head)))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (or $x349 dir.dirty)))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (or $x364 dir.dirty)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.dirty)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.dirty)))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (or $x485 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (or $x485 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x355 (not (net.put @Y @X))))
 (or $x355 $x339))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x370 (not (net.put @Z @X))))
 (or $x370 $x339))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x339))))
(assert
 (let (($x527 (not (rp_net @V0))))
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 $x527))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x271 (__invack __src)))
 (let (($x543 (not $x271)))
 (or $x543 (not (invnet __src))))))
(assert
 (let (($x549 (not (= (cache.state_ __src) shared))))
 (let (($x271 (__invack __src)))
 (let (($x543 (not $x271)))
 (or $x543 $x549)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x355 dir.pending))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x370 dir.pending))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x341 dir.pending))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x303 dir.pending))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x530 dir.pending))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x532 dir.pending))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x534 dir.pending))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x355 dir.dirty))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x370 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x303 dir.dirty))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x530 dir.dirty))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x532 dir.dirty))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x534 dir.dirty))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x355))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x370))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x341))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x303))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x530))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x532))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x534))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x575))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x326))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x485))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x580))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x341))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x530))))
(assert
 (let (($x584 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x582 (not $x58)))
 (or $x582 $x584)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x551 (dir.shlist @X)))
 (let (($x586 (not $x551)))
 (or $x586 $x346)))))
(assert
 (let (($x590 (not (net.get @V0 home))))
 (let (($x555 (dir.shlist @V0)))
 (let (($x588 (not $x555)))
 (or $x588 $x590)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x582 (not $x58)))
 (or $x582 dir.head))))
(assert
 (let (($x551 (dir.shlist @X)))
 (let (($x586 (not $x551)))
 (or $x586 dir.head))))
(assert
 (let (($x555 (dir.shlist @V0)))
 (let (($x588 (not $x555)))
 (or $x588 dir.head))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x335))))
(assert
 (let (($x479 (not (= (cache.state_ @V0) exclusive))))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x479))))
(assert
 (let (($x599 (not (= (cache.state_ __src) exclusive))))
 (let (($x597 (dir.shlist __src)))
 (or $x597 $x599))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x601 (= @X home)))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x601 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x601 (= @X home)))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x601 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x601 (= @X home)))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x601 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x417 (= @V0 home)))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x417 $x303)))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let (($x417 (= @V0 home)))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x417 $x530)))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let (($x601 (= @X home)))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x601 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let (($x417 (= @V0 home)))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x417 $x534)))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let (($x609 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x609 $x580)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x463 (= @X requester)))
 (let (($x551 (dir.shlist @X)))
 (or $x551 $x463 $x335)))))
(assert
 (let (($x479 (not (= (cache.state_ @V0) exclusive))))
 (let (($x471 (= @V0 requester)))
 (let (($x555 (dir.shlist @V0)))
 (or $x555 $x471 $x479)))))
(assert
 (let (($x599 (not (= (cache.state_ __src) exclusive))))
 (let (($x613 (= __src requester)))
 (let (($x597 (dir.shlist __src)))
 (or $x597 $x613 $x599)))))
(assert
 (let (($x615 (= __dst real_owner)))
 (let (($x275 (__dir.real __dst)))
 (or $x275 $x615 (= (cache.state_ __dst) invalid)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x326))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x485))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x575))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (let (($x142 (not $x141)))
 (let (($x624 (not (= (cache.state_ real_owner) shared))))
 (or $x624 $x142))))))
(assert
 (let (($x490 (not (= (cache.state_ @X) shared))))
 (or $x490 (not (= (cache.wait @X) get)))))
(assert
 (let (($x630 (not (= (cache.state_ @V1) shared))))
 (or $x630 (not (= (cache.wait @V1) get)))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) shared))))
 (or $x493 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x271 (__invack __src)))
 (let (($x543 (not $x271)))
 (let ((?x547 (cache.state_ __src)))
 (let (($x636 (= ?x547 invalid)))
 (or $x636 $x543))))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 dir.head)))
(assert
 (let (($x479 (not (= (cache.state_ @V0) exclusive))))
 (or $x479 dir.head)))
(assert
 (let (($x599 (not (= (cache.state_ __src) exclusive))))
 (or $x599 dir.head)))
(assert
 (let (($x642 (not (= (cache.state_ __dst) exclusive))))
 (or $x642 dir.head)))
(assert
 (let (($x645 (not (= (cache.state_ real_owner) exclusive))))
 (or $x645 dir.head)))
(assert
 (let (($x648 (not (= (cache.state_ @V1) exclusive))))
 (or $x648 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x400 (= home home)))
 (or $x400 $x187))))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x292))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x349)))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x364)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x297)))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x485)))))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x521)))))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x523)))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x657 (= ?x656 getX)))
 (or $x657 $x575)))))
(assert
 (let (($x360 (not (net.getX @X @Y))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x360)))))
(assert
 (let (($x352 (not (net.getX @X @Z))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x352)))))
(assert
 (let (($x373 (not (net.getX home @Y))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x373)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x331)))))
(assert
 (let (($x320 (not (net.getX @V1 @V0))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x664 (= ?x321 getX)))
 (or $x664 $x320)))))
(assert
 (let (($x300 (not (net.getX @V0 @V1))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x300)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x303)))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x530)))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x534)))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x671 (= ?x656 get)))
 (or $x671 $x580)))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x367)))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x357)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x307)))))
(assert
 (let (($x536 (not (net.get home @Y))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x536)))))
(assert
 (let (($x538 (not (net.get home @Z))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x538)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x540)))))
(assert
 (let (($x542 (not (net.get home @V1))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x542)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x680 (= ?x333 invalid)))
 (or $x680 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x680 (= ?x333 invalid)))
 (or $x680 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x680 (= ?x333 invalid)))
 (or $x680 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x303)))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x530)))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x680 (= ?x333 invalid)))
 (or $x680 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x534)))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let ((?x687 (cache.state_ dir.hptr)))
 (let (($x688 (= ?x687 invalid)))
 (or $x688 $x580)))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x680 (= ?x333 invalid)))
 (or $x680 $x367)))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x680 (= ?x333 invalid)))
 (or $x680 $x357)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x680 (= ?x333 invalid)))
 (or $x680 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x307)))))
(assert
 (let (($x536 (not (net.get home @Y))))
 (let ((?x693 (cache.state_ home)))
 (let (($x694 (= ?x693 invalid)))
 (or $x694 $x536)))))
(assert
 (let (($x538 (not (net.get home @Z))))
 (let ((?x693 (cache.state_ home)))
 (let (($x694 (= ?x693 invalid)))
 (or $x694 $x538)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let ((?x693 (cache.state_ home)))
 (let (($x694 (= ?x693 invalid)))
 (or $x694 $x540)))))
(assert
 (let (($x542 (not (net.get home @V1))))
 (let ((?x693 (cache.state_ home)))
 (let (($x694 (= ?x693 invalid)))
 (or $x694 $x542)))))
(assert
 (let (($x314 (= @Y home)))
 (or $x314 (not (net.shwb @X @Y)))))
(assert
 (let (($x400 (= home home)))
 (or $x400 (not (net.shwb @X home)))))
(assert
 (let (($x701 (not (= (cache.wait @X) none))))
 (let (($x360 (not (net.getX @X @Y))))
 (or $x360 $x701))))
(assert
 (let (($x701 (not (= (cache.wait @X) none))))
 (let (($x352 (not (net.getX @X @Z))))
 (or $x352 $x701))))
(assert
 (let (($x705 (not (= (cache.wait home) none))))
 (let (($x373 (not (net.getX home @Y))))
 (or $x373 $x705))))
(assert
 (let (($x701 (not (= (cache.wait @X) none))))
 (let (($x331 (not (net.getX @X home))))
 (or $x331 $x701))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x320 (not (net.getX @V1 @V0))))
 (or $x320 $x323))))
(assert
 (let (($x709 (not (= (cache.wait @V0) none))))
 (let (($x300 (not (net.getX @V0 @V1))))
 (or $x300 $x709))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x711 (= ?x140 getX)))
 (or $x711 $x713)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x664 (= ?x321 getX)))
 (or $x664 $x716)))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x485)))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x657 (= ?x656 getX)))
 (or $x657 $x575)))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x719)))))
(assert
 (let (($x331 (not (net.getX @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x331)))))
(assert
 (let (($x722 (not (net.getX home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x722)))))
(assert
 (let (($x725 (not (net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x664 (= ?x321 getX)))
 (or $x664 $x725)))))
(assert
 (let (($x728 (not (net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x728)))))
(assert
 (let (($x645 (not (= (cache.state_ real_owner) exclusive))))
 (or $x645 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x648 (not (= (cache.state_ @V1) exclusive))))
 (or $x648 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x479 (not (= (cache.state_ @V0) exclusive))))
 (or $x479 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x737 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x737 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x741 (not (= (cache.state_ home) exclusive))))
 (or $x741 (not (= (cache.wait home) getX)))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x339))))
(assert
 (let (($x527 (not (rp_net @V0))))
 (let (($x530 (not (net.put home @V0))))
 (or $x530 $x527))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x746)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x631 (= ?x321 get)))
 (or $x631 $x749)))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x530)))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x671 (= ?x656 get)))
 (or $x671 $x580)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x752)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x755)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x346)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x631 (= ?x321 get)))
 (or $x631 $x758)))))
(assert
 (let (($x590 (not (net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x590)))))
(assert
 (let (($x584 (not (net.get dir.hptr home))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x671 (= ?x656 get)))
 (or $x671 $x584)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x540)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x530)))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x145 $x532)))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x145 $x534)))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x580)))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x746)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x752)))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x485)))))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (let (($x777 (= real_owner real_owner)))
 (let (($x776 (= real_owner home)))
 (or $x776 $x777 $x521)))))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (let (($x777 (= real_owner real_owner)))
 (let (($x776 (= real_owner home)))
 (or $x776 $x777 $x523)))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x575)))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x713)))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x716)))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x719)))))
(assert
 (let (($x536 (not (net.get home @Y))))
 (let (($x395 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x395 $x536)))))
(assert
 (let (($x538 (not (net.get home @Z))))
 (let (($x398 (= @Z real_owner)))
 (let (($x397 (= @Z home)))
 (or $x397 $x398 $x538)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x540)))))
(assert
 (let (($x542 (not (net.get home @V1))))
 (let (($x403 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x403 $x542)))))
(assert
 (let (($x584 (not (net.get dir.hptr home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x584)))))
(assert
 (let (($x590 (not (net.get @V0 home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x590)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x755)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x758)))))
(assert
 (let (($x722 (not (net.getX home home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x722)))))
(assert
 (let (($x725 (not (net.getX @V1 home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x725)))))
(assert
 (let (($x728 (not (net.getX @V0 home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x728)))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x398 (= @Z real_owner)))
 (let (($x397 (= @Z home)))
 (or $x397 $x398 $x763)))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x418 (= @V0 real_owner)))
 (let (($x417 (= @V0 home)))
 (or $x417 $x418 $x765)))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x403 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x403 $x767)))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (let (($x400 (= home home)))
 (or $x400 $x530 dir.dirty))))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x532 dir.dirty))))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x534 dir.dirty))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let (($x400 (= home home)))
 (or $x400 $x580 dir.dirty))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let (($x400 (= home home)))
 (or $x400 $x746 dir.dirty))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x400 (= home home)))
 (or $x400 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x400 (= home home)))
 (or $x400 $x752 dir.dirty))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x400 (= home home)))
 (or $x400 $x485 dir.head))))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x521 dir.head))))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x523 dir.head))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x400 (= home home)))
 (or $x400 $x575 dir.head))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x400 (= home home)))
 (or $x400 $x713 dir.head))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x400 (= home home)))
 (or $x400 $x716 dir.head))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x400 (= home home)))
 (or $x400 $x719 dir.head))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x400 (= home home)))
 (or $x400 $x485 dir.dirty))))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x521 dir.dirty))))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x523 dir.dirty))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x400 (= home home)))
 (or $x400 $x575 dir.dirty))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x400 (= home home)))
 (or $x400 $x713 dir.dirty))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x400 (= home home)))
 (or $x400 $x716 dir.dirty))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x400 (= home home)))
 (or $x400 $x719 dir.dirty))))
(assert
 (let (($x485 (not (net.putX home @V0))))
 (let (($x400 (= home home)))
 (or $x400 $x485))))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x521))))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x523))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x400 (= home home)))
 (or $x400 $x575))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x400 (= home home)))
 (or $x400 $x713))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x400 (= home home)))
 (or $x400 $x716))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x400 (= home home)))
 (or $x400 $x719))))
(assert
 (let (($x536 (not (net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x536 dir.head))))
(assert
 (let (($x538 (not (net.get home @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x538 dir.head))))
(assert
 (let (($x540 (not (net.get home home))))
 (let (($x400 (= home home)))
 (or $x400 $x540 dir.head))))
(assert
 (let (($x542 (not (net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x542 dir.head))))
(assert
 (let (($x584 (not (net.get dir.hptr home))))
 (let (($x400 (= home home)))
 (or $x400 $x584 dir.head))))
(assert
 (let (($x590 (not (net.get @V0 home))))
 (let (($x400 (= home home)))
 (or $x400 $x590 dir.head))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x400 (= home home)))
 (or $x400 $x755 dir.head))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x400 (= home home)))
 (or $x400 $x758 dir.head))))
(assert
 (let (($x536 (not (net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x536 dir.dirty))))
(assert
 (let (($x538 (not (net.get home @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x538 dir.dirty))))
(assert
 (let (($x540 (not (net.get home home))))
 (let (($x400 (= home home)))
 (or $x400 $x540 dir.dirty))))
(assert
 (let (($x542 (not (net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x542 dir.dirty))))
(assert
 (let (($x584 (not (net.get dir.hptr home))))
 (let (($x400 (= home home)))
 (or $x400 $x584 dir.dirty))))
(assert
 (let (($x590 (not (net.get @V0 home))))
 (let (($x400 (= home home)))
 (or $x400 $x590 dir.dirty))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x400 (= home home)))
 (or $x400 $x755 dir.dirty))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x400 (= home home)))
 (or $x400 $x758 dir.dirty))))
(assert
 (let (($x722 (not (net.getX home home))))
 (let (($x400 (= home home)))
 (or $x400 $x722 dir.head))))
(assert
 (let (($x725 (not (net.getX @V1 home))))
 (let (($x400 (= home home)))
 (or $x400 $x725 dir.head))))
(assert
 (let (($x728 (not (net.getX @V0 home))))
 (let (($x400 (= home home)))
 (or $x400 $x728 dir.head))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x763 dir.head))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x417 (= @V0 home)))
 (or $x417 $x765 dir.head))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x767 dir.head))))
(assert
 (let (($x722 (not (net.getX home home))))
 (let (($x400 (= home home)))
 (or $x400 $x722 dir.dirty))))
(assert
 (let (($x725 (not (net.getX @V1 home))))
 (let (($x400 (= home home)))
 (or $x400 $x725 dir.dirty))))
(assert
 (let (($x728 (not (net.getX @V0 home))))
 (let (($x400 (= home home)))
 (or $x400 $x728 dir.dirty))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x763 dir.dirty))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x417 (= @V0 home)))
 (or $x417 $x765 dir.dirty))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x767 dir.dirty))))
(assert
 (let (($x722 (not (net.getX home home))))
 (let (($x400 (= home home)))
 (or $x400 $x722))))
(assert
 (let (($x725 (not (net.getX @V1 home))))
 (let (($x400 (= home home)))
 (or $x400 $x725))))
(assert
 (let (($x728 (not (net.getX @V0 home))))
 (let (($x400 (= home home)))
 (or $x400 $x728))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x397 (= @Z home)))
 (or $x397 $x763))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x417 (= @V0 home)))
 (or $x417 $x765))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x767))))
(assert
 (let (($x722 (not (net.getX home home))))
 (let (($x400 (= home home)))
 (let (($x466 (= home requester)))
 (or $x466 $x400 $x722)))))
(assert
 (let (($x725 (not (net.getX @V1 home))))
 (let (($x400 (= home home)))
 (let (($x469 (= @V1 requester)))
 (or $x469 $x400 $x725)))))
(assert
 (let (($x728 (not (net.getX @V0 home))))
 (let (($x400 (= home home)))
 (let (($x471 (= @V0 requester)))
 (or $x471 $x400 $x728)))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x397 (= @Z home)))
 (let (($x466 (= home requester)))
 (or $x466 $x397 $x763)))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x417 (= @V0 home)))
 (let (($x466 (= home requester)))
 (or $x466 $x417 $x765)))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x466 (= home requester)))
 (or $x466 $x289 $x767)))))
(assert
 (let (($x599 (not (= (cache.state_ __src) exclusive))))
 (let (($x865 (= __src real_owner)))
 (or $x865 $x599))))
(assert
 (let (($x642 (not (= (cache.state_ __dst) exclusive))))
 (let (($x615 (= __dst real_owner)))
 (or $x615 $x642))))
(assert
 (let (($x645 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x777 (= real_owner real_owner)))
 (or $x777 $x645))))
(assert
 (let (($x648 (not (= (cache.state_ @V1) exclusive))))
 (let (($x403 (= @V1 real_owner)))
 (or $x403 $x648))))
(assert
 (let (($x737 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x737))))
(assert
 (let (($x741 (not (= (cache.state_ home) exclusive))))
 (let (($x401 (= home real_owner)))
 (or $x401 $x741))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x872 (= dir.hptr dir.hptr)))
 (or $x872 $x575))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x874 (= real_owner dir.hptr)))
 (or $x874 $x713))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x876 (= @V1 dir.hptr)))
 (or $x876 $x716))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x878 (= home dir.hptr)))
 (or $x878 $x719))))
(assert
 (let (($x599 (not (= (cache.state_ __src) exclusive))))
 (let (($x880 (= __src dir.hptr)))
 (or $x880 $x599))))
(assert
 (let (($x642 (not (= (cache.state_ __dst) exclusive))))
 (or (= __dst dir.hptr) $x642)))
(assert
 (let (($x645 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x874 (= real_owner dir.hptr)))
 (or $x874 $x645))))
(assert
 (let (($x648 (not (= (cache.state_ @V1) exclusive))))
 (let (($x876 (= @V1 dir.hptr)))
 (or $x876 $x648))))
(assert
 (let (($x737 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x872 (= dir.hptr dir.hptr)))
 (or $x872 $x737))))
(assert
 (let (($x741 (not (= (cache.state_ home) exclusive))))
 (let (($x878 (= home dir.hptr)))
 (or $x878 $x741))))
(assert
 (let (($x549 (not (= (cache.state_ __src) shared))))
 (let (($x865 (= __src real_owner)))
 (or $x865 $x549))))
(assert
 (let (($x615 (= __dst real_owner)))
 (or $x615 (not (= (cache.state_ __dst) shared)))))
(assert
 (let (($x624 (not (= (cache.state_ real_owner) shared))))
 (let (($x777 (= real_owner real_owner)))
 (or $x777 $x624))))
(assert
 (let (($x630 (not (= (cache.state_ @V1) shared))))
 (let (($x403 (= @V1 real_owner)))
 (or $x403 $x630))))
(assert
 (let (($x895 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x895))))
(assert
 (let (($x898 (not (= (cache.state_ home) shared))))
 (let (($x401 (= home real_owner)))
 (or $x401 $x898))))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x521))))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x523))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x400 (= home home)))
 (or $x400 $x575))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x400 (= home home)))
 (or $x400 $x713))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x400 (= home home)))
 (or $x400 $x716))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x400 (= home home)))
 (or $x400 $x719))))
(assert
 (let (($x493 (not (= (cache.state_ @V0) shared))))
 (let (($x527 (not (rp_net @V0))))
 (or $x527 $x493))))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (let (($x497 (= real_owner @X)))
 (or $x497 $x521))))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (let (($x501 (= real_owner @V0)))
 (or $x501 $x523))))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (let (($x874 (= real_owner dir.hptr)))
 (or $x874 $x575))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x777 (= real_owner real_owner)))
 (or $x777 $x713))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x905 (= real_owner @V1)))
 (or $x905 $x716))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x719))))
(assert
 (let (($x530 (not (net.put home @V0))))
 (or $x530 dir.head)))
(assert
 (let (($x532 (not (net.put dir.hptr @X))))
 (or $x532 dir.head)))
(assert
 (let (($x534 (not (net.put dir.hptr @V0))))
 (or $x534 dir.head)))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (or $x580 dir.head)))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (or $x746 dir.head)))
(assert
 (let (($x749 (not (net.put home @V1))))
 (or $x749 dir.head)))
(assert
 (let (($x752 (not (net.put home home))))
 (or $x752 dir.head)))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (or $x521 dir.head)))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (or $x523 dir.head)))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (or $x575 dir.head)))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (or $x713 dir.head)))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (or $x716 dir.head)))
(assert
 (let (($x719 (not (net.putX home home))))
 (or $x719 dir.head)))
(assert
 (let (($x521 (not (net.putX real_owner @X))))
 (or $x521 dir.dirty)))
(assert
 (let (($x523 (not (net.putX real_owner @V0))))
 (or $x523 dir.dirty)))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (or $x575 dir.dirty)))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (or $x713 dir.dirty)))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (or $x716 dir.dirty)))
(assert
 (let (($x719 (not (net.putX home home))))
 (or $x719 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x575 (not (net.putX home dir.hptr))))
 (or $x575 dir.head)))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (or $x713 dir.head)))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (or $x716 dir.head)))
(assert
 (let (($x719 (not (net.putX home home))))
 (or $x719 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x527 (not (rp_net @V0))))
 (let (($x530 (not (net.put home @V0))))
 (or $x530 $x527))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x532 (not (net.put dir.hptr @X))))
 (or $x532 $x339))))
(assert
 (let (($x527 (not (rp_net @V0))))
 (let (($x534 (not (net.put dir.hptr @V0))))
 (or $x534 $x527))))
(assert
 (let (($x938 (not (rp_net dir.hptr))))
 (let (($x580 (not (net.put home dir.hptr))))
 (or $x580 $x938))))
(assert
 (let (($x941 (not (rp_net real_owner))))
 (let (($x746 (not (net.put home real_owner))))
 (or $x746 $x941))))
(assert
 (let (($x944 (not (rp_net @V1))))
 (let (($x749 (not (net.put home @V1))))
 (or $x749 $x944))))
(assert
 (let (($x947 (not (rp_net home))))
 (let (($x752 (not (net.put home home))))
 (or $x752 $x947))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x580 dir.pending))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x746 dir.pending))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x749 dir.pending))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x752 dir.pending))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x950 dir.pending))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x952 dir.pending))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x954 dir.pending))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x956 dir.pending))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x580 dir.dirty))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x746 dir.dirty))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x752 dir.dirty))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x950 dir.dirty))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x952 dir.dirty))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x954 dir.dirty))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x956 dir.dirty))))
(assert
 (let (($x580 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x580))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x746))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x749))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x752))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x950))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x952))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x954))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x956))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x597 (dir.shlist __src)))
 (or $x597 $x984))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x713))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x716))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x719))))
(assert
 (let (($x990 (not (net.put home __src))))
 (let (($x597 (dir.shlist __src)))
 (or $x597 $x990))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x746))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x749))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x752))))
(assert
 (let (($x994 (not (net.get __src home))))
 (let (($x597 (dir.shlist __src)))
 (let (($x992 (not $x597)))
 (or $x992 $x994)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x958 (dir.shlist real_owner)))
 (let (($x996 (not $x958)))
 (or $x996 $x755)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x960 (dir.shlist @V1)))
 (let (($x998 (not $x960)))
 (or $x998 $x758)))))
(assert
 (let (($x540 (not (net.get home home))))
 (let (($x962 (dir.shlist home)))
 (let (($x1000 (not $x962)))
 (or $x1000 $x540)))))
(assert
 (let (($x597 (dir.shlist __src)))
 (let (($x992 (not $x597)))
 (or $x992 dir.head))))
(assert
 (let (($x958 (dir.shlist real_owner)))
 (let (($x996 (not $x958)))
 (or $x996 dir.head))))
(assert
 (let (($x960 (dir.shlist @V1)))
 (let (($x998 (not $x960)))
 (or $x998 dir.head))))
(assert
 (let (($x962 (dir.shlist home)))
 (let (($x1000 (not $x962)))
 (or $x1000 dir.head))))
(assert
 (let (($x737 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x737))))
(assert
 (let (($x645 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x645))))
(assert
 (let (($x648 (not (= (cache.state_ @V1) exclusive))))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x648))))
(assert
 (let (($x741 (not (= (cache.state_ home) exclusive))))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x741))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let (($x776 (= real_owner home)))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x776 $x746)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x289 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x400 (= home home)))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x400 $x752)))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let (($x609 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x609 $x950)))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let (($x776 (= real_owner home)))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x776 $x952)))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x289 $x954)))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let (($x400 (= home home)))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x400 $x956)))))
(assert
 (let (($x990 (not (net.put home __src))))
 (let (($x272 (= __src home)))
 (let (($x597 (dir.shlist __src)))
 (or $x597 $x272 $x990)))))
(assert
 (let (($x737 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x1018 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1018 $x737)))))
(assert
 (let (($x645 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x1020 (= real_owner requester)))
 (let (($x958 (dir.shlist real_owner)))
 (or $x958 $x1020 $x645)))))
(assert
 (let (($x648 (not (= (cache.state_ @V1) exclusive))))
 (let (($x469 (= @V1 requester)))
 (let (($x960 (dir.shlist @V1)))
 (or $x960 $x469 $x648)))))
(assert
 (let (($x741 (not (= (cache.state_ home) exclusive))))
 (let (($x466 (= home requester)))
 (let (($x962 (dir.shlist home)))
 (or $x962 $x466 $x741)))))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x713))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x716))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x719))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x984))))
(assert
 (let (($x895 (not (= (cache.state_ dir.hptr) shared))))
 (or $x895 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x898 (not (= (cache.state_ home) shared))))
 (or $x898 (not (= (cache.wait home) get)))))
(assert
 (let (($x737 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x737 dir.head)))
(assert
 (let (($x741 (not (= (cache.state_ home) exclusive))))
 (or $x741 dir.head)))
(assert
 (let (($x713 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x711 (= ?x140 getX)))
 (or $x711 $x713)))))
(assert
 (let (($x716 (not (net.putX home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x664 (= ?x321 getX)))
 (or $x664 $x716)))))
(assert
 (let (($x719 (not (net.putX home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x719)))))
(assert
 (let (($x928 (not (net.putX real_owner dir.hptr))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x657 (= ?x656 getX)))
 (or $x657 $x928)))))
(assert
 (let (($x930 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x711 (= ?x140 getX)))
 (or $x711 $x930)))))
(assert
 (let (($x932 (not (net.putX real_owner @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x664 (= ?x321 getX)))
 (or $x664 $x932)))))
(assert
 (let (($x934 (not (net.putX real_owner home))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x934)))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let ((?x1038 (cache.wait __src)))
 (let (($x1039 (= ?x1038 getX)))
 (or $x1039 $x984)))))
(assert
 (let (($x722 (not (net.getX home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x722)))))
(assert
 (let (($x725 (not (net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x664 (= ?x321 getX)))
 (or $x664 $x725)))))
(assert
 (let (($x728 (not (net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x728)))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x763)))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x765)))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let ((?x661 (cache.wait home)))
 (let (($x662 (= ?x661 getX)))
 (or $x662 $x767)))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x746)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x631 (= ?x321 get)))
 (or $x631 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x752)))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x671 (= ?x656 get)))
 (or $x671 $x950)))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x952)))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x631 (= ?x321 get)))
 (or $x631 $x954)))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let ((?x661 (cache.wait home)))
 (let (($x675 (= ?x661 get)))
 (or $x675 $x956)))))
(assert
 (let (($x990 (not (net.put home __src))))
 (let ((?x1038 (cache.wait __src)))
 (let (($x1048 (= ?x1038 get)))
 (or $x1048 $x990)))))
(assert
 (let (($x584 (not (net.get dir.hptr home))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x671 (= ?x656 get)))
 (or $x671 $x584)))))
(assert
 (let (($x590 (not (net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x590)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x755)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x631 (= ?x321 get)))
 (or $x631 $x758)))))
(assert
 (let (($x994 (not (net.get __src home))))
 (let ((?x1038 (cache.wait __src)))
 (let (($x1048 (= ?x1038 get)))
 (or $x1048 $x994)))))
(assert
 (let (($x746 (not (net.put home real_owner))))
 (let ((?x622 (cache.state_ real_owner)))
 (let (($x1051 (= ?x622 invalid)))
 (or $x1051 $x746)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x628 (cache.state_ @V1)))
 (let (($x1053 (= ?x628 invalid)))
 (or $x1053 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let ((?x693 (cache.state_ home)))
 (let (($x694 (= ?x693 invalid)))
 (or $x694 $x752)))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let ((?x687 (cache.state_ dir.hptr)))
 (let (($x688 (= ?x687 invalid)))
 (or $x688 $x950)))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let ((?x622 (cache.state_ real_owner)))
 (let (($x1051 (= ?x622 invalid)))
 (or $x1051 $x952)))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let ((?x628 (cache.state_ @V1)))
 (let (($x1053 (= ?x628 invalid)))
 (or $x1053 $x954)))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let ((?x693 (cache.state_ home)))
 (let (($x694 (= ?x693 invalid)))
 (or $x694 $x956)))))
(assert
 (let (($x990 (not (net.put home __src))))
 (let ((?x547 (cache.state_ __src)))
 (let (($x636 (= ?x547 invalid)))
 (or $x636 $x990)))))
(assert
 (let (($x584 (not (net.get dir.hptr home))))
 (let ((?x687 (cache.state_ dir.hptr)))
 (let (($x688 (= ?x687 invalid)))
 (or $x688 $x584)))))
(assert
 (let (($x590 (not (net.get @V0 home))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x590)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let ((?x622 (cache.state_ real_owner)))
 (let (($x1051 (= ?x622 invalid)))
 (or $x1051 $x755)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let ((?x628 (cache.state_ @V1)))
 (let (($x1053 (= ?x628 invalid)))
 (or $x1053 $x758)))))
(assert
 (let (($x994 (not (net.get __src home))))
 (let ((?x547 (cache.state_ __src)))
 (let (($x636 (= ?x547 invalid)))
 (or $x636 $x994)))))
(assert
 (let (($x705 (not (= (cache.wait home) none))))
 (let (($x722 (not (net.getX home home))))
 (or $x722 $x705))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x725 (not (net.getX @V1 home))))
 (or $x725 $x323))))
(assert
 (let (($x709 (not (= (cache.wait @V0) none))))
 (let (($x728 (not (net.getX @V0 home))))
 (or $x728 $x709))))
(assert
 (let (($x705 (not (= (cache.wait home) none))))
 (let (($x763 (not (net.getX home @Z))))
 (or $x763 $x705))))
(assert
 (let (($x705 (not (= (cache.wait home) none))))
 (let (($x765 (not (net.getX home @V0))))
 (or $x765 $x705))))
(assert
 (let (($x705 (not (= (cache.wait home) none))))
 (let (($x767 (not (net.getX home @V1))))
 (or $x767 $x705))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let ((?x1038 (cache.wait __src)))
 (let (($x1039 (= ?x1038 getX)))
 (or $x1039 $x984)))))
(assert
 (let (($x1073 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x711 (= ?x140 getX)))
 (or $x711 $x1073)))))
(assert
 (let (($x1076 (not (net.getX dir.hptr home))))
 (let ((?x656 (cache.wait dir.hptr)))
 (let (($x657 (= ?x656 getX)))
 (or $x657 $x1076)))))
(assert
 (let (($x1079 (not (net.getX __src home))))
 (let ((?x1038 (cache.wait __src)))
 (let (($x1039 (= ?x1038 getX)))
 (or $x1039 $x1079)))))
(assert
 (let (($x599 (not (= (cache.state_ __src) exclusive))))
 (or $x599 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x938 (not (rp_net dir.hptr))))
 (let (($x580 (not (net.put home dir.hptr))))
 (or $x580 $x938))))
(assert
 (let (($x941 (not (rp_net real_owner))))
 (let (($x746 (not (net.put home real_owner))))
 (or $x746 $x941))))
(assert
 (let (($x944 (not (rp_net @V1))))
 (let (($x749 (not (net.put home @V1))))
 (or $x749 $x944))))
(assert
 (let (($x947 (not (rp_net home))))
 (let (($x752 (not (net.put home home))))
 (or $x752 $x947))))
(assert
 (let (($x990 (not (net.put home __src))))
 (let ((?x1038 (cache.wait __src)))
 (let (($x1048 (= ?x1038 get)))
 (or $x1048 $x990)))))
(assert
 (let (($x994 (not (net.get __src home))))
 (let ((?x1038 (cache.wait __src)))
 (let (($x1048 (= ?x1038 get)))
 (or $x1048 $x994)))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x145 $x950)))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x145 $x952)))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x145 $x954)))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x145 $x956)))))
(assert
 (let (($x990 (not (net.put home __src))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x990)))))
(assert
 (let (($x928 (not (net.putX real_owner dir.hptr))))
 (let (($x777 (= real_owner real_owner)))
 (let (($x776 (= real_owner home)))
 (or $x776 $x777 $x928)))))
(assert
 (let (($x930 (not (net.putX real_owner real_owner))))
 (let (($x777 (= real_owner real_owner)))
 (let (($x776 (= real_owner home)))
 (or $x776 $x777 $x930)))))
(assert
 (let (($x932 (not (net.putX real_owner @V1))))
 (let (($x777 (= real_owner real_owner)))
 (let (($x776 (= real_owner home)))
 (or $x776 $x777 $x932)))))
(assert
 (let (($x934 (not (net.putX real_owner home))))
 (let (($x777 (= real_owner real_owner)))
 (let (($x776 (= real_owner home)))
 (or $x776 $x777 $x934)))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x984)))))
(assert
 (let (($x994 (not (net.get __src home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x994)))))
(assert
 (let (($x1073 (not (net.getX real_owner home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x1073)))))
(assert
 (let (($x1076 (not (net.getX dir.hptr home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x1076)))))
(assert
 (let (($x1079 (not (net.getX __src home))))
 (let (($x401 (= home real_owner)))
 (let (($x400 (= home home)))
 (or $x400 $x401 $x1079)))))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x950 dir.dirty))))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x952 dir.dirty))))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x954 dir.dirty))))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (let (($x609 (= dir.hptr home)))
 (or $x609 $x956 dir.dirty))))
(assert
 (let (($x990 (not (net.put home __src))))
 (let (($x400 (= home home)))
 (or $x400 $x990 dir.dirty))))
(assert
 (let (($x928 (not (net.putX real_owner dir.hptr))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x928 dir.head))))
(assert
 (let (($x930 (not (net.putX real_owner real_owner))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x930 dir.head))))
(assert
 (let (($x932 (not (net.putX real_owner @V1))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x932 dir.head))))
(assert
 (let (($x934 (not (net.putX real_owner home))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x934 dir.head))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x400 (= home home)))
 (or $x400 $x984 dir.head))))
(assert
 (let (($x928 (not (net.putX real_owner dir.hptr))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x928 dir.dirty))))
(assert
 (let (($x930 (not (net.putX real_owner real_owner))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x930 dir.dirty))))
(assert
 (let (($x932 (not (net.putX real_owner @V1))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x932 dir.dirty))))
(assert
 (let (($x934 (not (net.putX real_owner home))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x934 dir.dirty))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x400 (= home home)))
 (or $x400 $x984 dir.dirty))))
(assert
 (let (($x928 (not (net.putX real_owner dir.hptr))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x928))))
(assert
 (let (($x930 (not (net.putX real_owner real_owner))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x930))))
(assert
 (let (($x932 (not (net.putX real_owner @V1))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x932))))
(assert
 (let (($x934 (not (net.putX real_owner home))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x934))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x400 (= home home)))
 (or $x400 $x984))))
(assert
 (let (($x994 (not (net.get __src home))))
 (let (($x400 (= home home)))
 (or $x400 $x994 dir.head))))
(assert
 (let (($x994 (not (net.get __src home))))
 (let (($x400 (= home home)))
 (or $x400 $x994 dir.dirty))))
(assert
 (let (($x1073 (not (net.getX real_owner home))))
 (let (($x400 (= home home)))
 (or $x400 $x1073 dir.head))))
(assert
 (let (($x1076 (not (net.getX dir.hptr home))))
 (let (($x400 (= home home)))
 (or $x400 $x1076 dir.head))))
(assert
 (let (($x1079 (not (net.getX __src home))))
 (let (($x400 (= home home)))
 (or $x400 $x1079 dir.head))))
(assert
 (let (($x1073 (not (net.getX real_owner home))))
 (let (($x400 (= home home)))
 (or $x400 $x1073 dir.dirty))))
(assert
 (let (($x1076 (not (net.getX dir.hptr home))))
 (let (($x400 (= home home)))
 (or $x400 $x1076 dir.dirty))))
(assert
 (let (($x1079 (not (net.getX __src home))))
 (let (($x400 (= home home)))
 (or $x400 $x1079 dir.dirty))))
(assert
 (let (($x1073 (not (net.getX real_owner home))))
 (let (($x400 (= home home)))
 (or $x400 $x1073))))
(assert
 (let (($x1076 (not (net.getX dir.hptr home))))
 (let (($x400 (= home home)))
 (or $x400 $x1076))))
(assert
 (let (($x1079 (not (net.getX __src home))))
 (let (($x400 (= home home)))
 (or $x400 $x1079))))
(assert
 (let (($x1073 (not (net.getX real_owner home))))
 (let (($x400 (= home home)))
 (let (($x1020 (= real_owner requester)))
 (or $x1020 $x400 $x1073)))))
(assert
 (let (($x1076 (not (net.getX dir.hptr home))))
 (let (($x400 (= home home)))
 (let (($x1018 (= dir.hptr requester)))
 (or $x1018 $x400 $x1076)))))
(assert
 (let (($x1079 (not (net.getX __src home))))
 (let (($x400 (= home home)))
 (let (($x613 (= __src requester)))
 (or $x613 $x400 $x1079)))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x880 (= __src dir.hptr)))
 (or $x880 $x984))))
(assert
 (let (($x928 (not (net.putX real_owner dir.hptr))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x928))))
(assert
 (let (($x930 (not (net.putX real_owner real_owner))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x930))))
(assert
 (let (($x932 (not (net.putX real_owner @V1))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x932))))
(assert
 (let (($x934 (not (net.putX real_owner home))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x934))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (let (($x400 (= home home)))
 (or $x400 $x984))))
(assert
 (let (($x895 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x938 (not (rp_net dir.hptr))))
 (or $x938 $x895))))
(assert
 (let (($x624 (not (= (cache.state_ real_owner) shared))))
 (let (($x941 (not (rp_net real_owner))))
 (or $x941 $x624))))
(assert
 (let (($x630 (not (= (cache.state_ @V1) shared))))
 (let (($x944 (not (rp_net @V1))))
 (or $x944 $x630))))
(assert
 (let (($x898 (not (= (cache.state_ home) shared))))
 (let (($x947 (not (rp_net home))))
 (or $x947 $x898))))
(assert
 (let (($x928 (not (net.putX real_owner dir.hptr))))
 (let (($x874 (= real_owner dir.hptr)))
 (or $x874 $x928))))
(assert
 (let (($x930 (not (net.putX real_owner real_owner))))
 (let (($x777 (= real_owner real_owner)))
 (or $x777 $x930))))
(assert
 (let (($x932 (not (net.putX real_owner @V1))))
 (let (($x905 (= real_owner @V1)))
 (or $x905 $x932))))
(assert
 (let (($x934 (not (net.putX real_owner home))))
 (let (($x776 (= real_owner home)))
 (or $x776 $x934))))
(assert
 (let (($x984 (not (net.putX home __src))))
 (or (= real_owner __src) $x984)))
(assert
 (let (($x950 (not (net.put dir.hptr dir.hptr))))
 (or $x950 dir.head)))
(assert
 (let (($x952 (not (net.put dir.hptr real_owner))))
 (or $x952 dir.head)))
(assert
 (let (($x954 (not (net.put dir.hptr @V1))))
 (or $x954 dir.head)))
(assert
 (let (($x956 (not (net.put dir.hptr home))))
 (or $x956 dir.head)))
(check-sat)
