(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun __requester () id)
(declare-fun __src () id)
(declare-fun requester () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun dir.local_ () Bool)
(declare-fun dir.pending () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun __m_net.getX (id id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) __dir.pending)))
(assert
 (not (net.fack __requester home)))
(assert
 (__net.getX __src home))
(assert
 (let (($x272 (= home __src)))
 (not $x272)))
(assert
 (not __dir.pending))
(assert
 dir.dirty)
(assert
 (not dir.local_))
(assert
 (let (($x277 (= __src dir.hptr)))
 (not $x277)))
(assert
 dir.pending)
(assert
 (= requester __src))
(assert
 (let (($x340 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x356 (net.getX @X @Z)))
 (let (($x357 (not $x356)))
 (let (($x366 (= @Y @Z)))
 (let (($x379 (and (or $x366 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x366 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x366 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x366 (not (net.getX @X @Y)) $x357) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x357 (not (net.putX @Y @X))) (not (net.getX home @Y)) $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x340 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x379))))))))))
(assert
 (let (($x403 (__m_net.getX @X @Y)))
 (let (($x364 (net.getX @X @Y)))
 (= $x364 (ite (and (= @X __src) (= @Y dir.hptr)) true $x403)))))
(assert
 (let (($x408 (__m_net.getX @X @Z)))
 (let (($x356 (net.getX @X @Z)))
 (= $x356 (ite (and (= @X __src) (= @Z dir.hptr)) true $x408)))))
(assert
 (let (($x412 (__m_net.getX home @Y)))
 (let (($x377 (net.getX home @Y)))
 (= $x377 (ite (and (= home __src) (= @Y dir.hptr)) true $x412)))))
(assert
 (let (($x417 (__m_net.getX @X home)))
 (let (($x335 (net.getX @X home)))
 (= $x335 (ite (and (= @X __src) (= home dir.hptr)) true $x417)))))
(assert
 (let (($x423 (__m_net.getX @V1 @V0)))
 (let (($x324 (net.getX @V1 @V0)))
 (= $x324 (ite (and (= @V1 __src) (= @V0 dir.hptr)) true $x423)))))
(assert
 (let (($x429 (__m_net.getX @V0 @V1)))
 (let (($x304 (net.getX @V0 @V1)))
 (= $x304 (ite (and (= @V0 __src) (= @V1 dir.hptr)) true $x429)))))
(assert
 (let (($x433 (__net.getX @X @Y)))
 (let (($x403 (__m_net.getX @X @Y)))
 (= $x403 (ite (and (= @X __src) (= @Y home)) false $x433)))))
(assert
 (let (($x438 (__net.getX @X @Z)))
 (let (($x408 (__m_net.getX @X @Z)))
 (= $x408 (ite (and (= @X __src) (= @Z home)) false $x438)))))
(assert
 (let (($x442 (__net.getX home @Y)))
 (let (($x412 (__m_net.getX home @Y)))
 (= $x412 (ite (and (= home __src) (= @Y home)) false $x442)))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x417 (__m_net.getX @X home)))
 (= $x417 (ite (and (= @X __src) (= home home)) false $x447)))))
(assert
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x423 (__m_net.getX @V1 @V0)))
 (= $x423 (ite (and (= @V1 __src) (= @V0 home)) false $x452)))))
(assert
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x429 (__m_net.getX @V0 @V1)))
 (= $x429 (ite (and (= @V0 __src) (= @V1 home)) false $x456)))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x459 (= @Y real_owner)))
 (let (($x319 (= @Y home)))
 (or $x319 $x459 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x461 (= @Z real_owner)))
 (let (($x436 (= @Z home)))
 (or $x436 $x461 $x375)))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x346)))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let (($x465 (= @V1 real_owner)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x465 $x308)))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x459 (= @Y real_owner)))
 (let (($x319 (= @Y home)))
 (or $x319 $x459 $x354)))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x461 (= @Z real_owner)))
 (let (($x436 (= @Z home)))
 (or $x436 $x461 $x369)))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x331)))))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (let (($x465 (= @V1 real_owner)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x465 $x302)))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let (($x459 (= @Y real_owner)))
 (let (($x319 (= @Y home)))
 (or $x319 $x459 $x372)))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let (($x461 (= @Z real_owner)))
 (let (($x436 (= @Z home)))
 (or $x436 $x461 $x362)))))
(assert
 (let (($x351 (not (net.get @X home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x351)))))
(assert
 (let (($x312 (not (net.get @V0 @V1))))
 (let (($x465 (= @V1 real_owner)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x465 $x312)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x475))))))
(assert
 (let (($x433 (__net.getX @X @Y)))
 (let (($x477 (not $x433)))
 (let (($x459 (= @Y real_owner)))
 (let (($x319 (= @Y home)))
 (or $x319 $x459 $x477))))))
(assert
 (let (($x438 (__net.getX @X @Z)))
 (let (($x479 (not $x438)))
 (let (($x461 (= @Z real_owner)))
 (let (($x436 (= @Z home)))
 (or $x436 $x461 $x479))))))
(assert
 (let (($x442 (__net.getX home @Y)))
 (let (($x481 (not $x442)))
 (let (($x459 (= @Y real_owner)))
 (let (($x319 (= @Y home)))
 (or $x319 $x459 $x481))))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x483))))))
(assert
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x486 (not $x452)))
 (let (($x485 (= @V0 real_owner)))
 (let (($x450 (= @V0 home)))
 (or $x450 $x485 $x486))))))
(assert
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x488 (not $x456)))
 (let (($x465 (= @V1 real_owner)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x465 $x488))))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x319 (= @Y home)))
 (or $x319 $x360 dir.dirty))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x436 (= @Z home)))
 (or $x436 $x375 dir.dirty))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let (($x445 (= home home)))
 (or $x445 $x346 dir.dirty))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x308 dir.dirty))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x319 (= @Y home)))
 (or $x319 $x354 dir.head))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x436 (= @Z home)))
 (or $x436 $x369 dir.head))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x445 (= home home)))
 (or $x445 $x331 dir.head))))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x302 dir.head))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x319 (= @Y home)))
 (or $x319 $x354 dir.dirty))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x436 (= @Z home)))
 (or $x436 $x369 dir.dirty))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x445 (= home home)))
 (or $x445 $x331 dir.dirty))))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x302 dir.dirty))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x319 (= @Y home)))
 (or $x319 $x354))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x436 (= @Z home)))
 (or $x436 $x369))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x445 (= home home)))
 (or $x445 $x331))))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x302))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let (($x319 (= @Y home)))
 (or $x319 $x372 dir.head))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let (($x436 (= @Z home)))
 (or $x436 $x362 dir.head))))
(assert
 (let (($x351 (not (net.get @X home))))
 (let (($x445 (= home home)))
 (or $x445 $x351 dir.head))))
(assert
 (let (($x312 (not (net.get @V0 @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x312 dir.head))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let (($x319 (= @Y home)))
 (or $x319 $x372 dir.dirty))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let (($x436 (= @Z home)))
 (or $x436 $x362 dir.dirty))))
(assert
 (let (($x351 (not (net.get @X home))))
 (let (($x445 (= home home)))
 (or $x445 $x351 dir.dirty))))
(assert
 (let (($x312 (not (net.get @V0 @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x312 dir.dirty))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (let (($x445 (= home home)))
 (or $x445 $x475 dir.head)))))
(assert
 (let (($x433 (__net.getX @X @Y)))
 (let (($x477 (not $x433)))
 (let (($x319 (= @Y home)))
 (or $x319 $x477 dir.head)))))
(assert
 (let (($x438 (__net.getX @X @Z)))
 (let (($x479 (not $x438)))
 (let (($x436 (= @Z home)))
 (or $x436 $x479 dir.head)))))
(assert
 (let (($x442 (__net.getX home @Y)))
 (let (($x481 (not $x442)))
 (let (($x319 (= @Y home)))
 (or $x319 $x481 dir.head)))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (let (($x445 (= home home)))
 (or $x445 $x483 dir.head)))))
(assert
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x486 (not $x452)))
 (let (($x450 (= @V0 home)))
 (or $x450 $x486 dir.head)))))
(assert
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x488 (not $x456)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x488 dir.head)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (let (($x445 (= home home)))
 (or $x445 $x475 dir.dirty)))))
(assert
 (let (($x433 (__net.getX @X @Y)))
 (let (($x477 (not $x433)))
 (let (($x319 (= @Y home)))
 (or $x319 $x477 dir.dirty)))))
(assert
 (let (($x438 (__net.getX @X @Z)))
 (let (($x479 (not $x438)))
 (let (($x436 (= @Z home)))
 (or $x436 $x479 dir.dirty)))))
(assert
 (let (($x442 (__net.getX home @Y)))
 (let (($x481 (not $x442)))
 (let (($x319 (= @Y home)))
 (or $x319 $x481 dir.dirty)))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (let (($x445 (= home home)))
 (or $x445 $x483 dir.dirty)))))
(assert
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x486 (not $x452)))
 (let (($x450 (= @V0 home)))
 (or $x450 $x486 dir.dirty)))))
(assert
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x488 (not $x456)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x488 dir.dirty)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (let (($x445 (= home home)))
 (or $x445 $x475)))))
(assert
 (let (($x433 (__net.getX @X @Y)))
 (let (($x477 (not $x433)))
 (let (($x319 (= @Y home)))
 (or $x319 $x477)))))
(assert
 (let (($x438 (__net.getX @X @Z)))
 (let (($x479 (not $x438)))
 (let (($x436 (= @Z home)))
 (or $x436 $x479)))))
(assert
 (let (($x442 (__net.getX home @Y)))
 (let (($x481 (not $x442)))
 (let (($x319 (= @Y home)))
 (or $x319 $x481)))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (let (($x445 (= home home)))
 (or $x445 $x483)))))
(assert
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x486 (not $x452)))
 (let (($x450 (= @V0 home)))
 (or $x450 $x486)))))
(assert
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x488 (not $x456)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x488)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (let (($x445 (= home home)))
 (or (= __src __requester) $x445 $x475)))))
(assert
 (let (($x433 (__net.getX @X @Y)))
 (let (($x477 (not $x433)))
 (let (($x319 (= @Y home)))
 (let (($x537 (= @X __requester)))
 (or $x537 $x319 $x477))))))
(assert
 (let (($x438 (__net.getX @X @Z)))
 (let (($x479 (not $x438)))
 (let (($x436 (= @Z home)))
 (let (($x537 (= @X __requester)))
 (or $x537 $x436 $x479))))))
(assert
 (let (($x442 (__net.getX home @Y)))
 (let (($x481 (not $x442)))
 (let (($x319 (= @Y home)))
 (let (($x540 (= home __requester)))
 (or $x540 $x319 $x481))))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (let (($x445 (= home home)))
 (let (($x537 (= @X __requester)))
 (or $x537 $x445 $x483))))))
(assert
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x486 (not $x452)))
 (let (($x450 (= @V0 home)))
 (let (($x543 (= @V1 __requester)))
 (or $x543 $x450 $x486))))))
(assert
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x488 (not $x456)))
 (let (($x294 (= @V1 home)))
 (let (($x545 (= @V0 __requester)))
 (or $x545 $x294 $x488))))))
(assert
 (let (($x187 (not (net.fack __requester home))))
 (or (= __requester real_owner) $x187)))
(assert
 (let (($x297 (not (net.fack @V0 @V1))))
 (let (($x485 (= @V0 real_owner)))
 (or $x485 $x297))))
(assert
 (let (($x340 (not (= (cache.state_ @X) exclusive))))
 (let (($x550 (= @X real_owner)))
 (or $x550 $x340))))
(assert
 (let (($x553 (not (= (cache.state_ @V0) exclusive))))
 (let (($x485 (= @V0 real_owner)))
 (or $x485 $x553))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x555 (= @X dir.hptr)))
 (or $x555 $x331))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x421 (= @V0 dir.hptr)))
 (or $x421 $x558))))
(assert
 (let (($x340 (not (= (cache.state_ @X) exclusive))))
 (let (($x555 (= @X dir.hptr)))
 (or $x555 $x340))))
(assert
 (let (($x553 (not (= (cache.state_ @V0) exclusive))))
 (let (($x421 (= @V0 dir.hptr)))
 (or $x421 $x553))))
(assert
 (let (($x563 (not (= (cache.state_ @X) shared))))
 (let (($x550 (= @X real_owner)))
 (or $x550 $x563))))
(assert
 (let (($x566 (not (= (cache.state_ @V0) shared))))
 (let (($x485 (= @V0 real_owner)))
 (or $x485 $x566))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x319 (= @Y home)))
 (or $x319 $x354))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x436 (= @Z home)))
 (or $x436 $x369))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x445 (= home home)))
 (or $x445 $x331))))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x302))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x445 (= home home)))
 (or $x445 $x558))))
(assert
 (let (($x563 (not (= (cache.state_ @X) shared))))
 (let (($x344 (not (rp_net @X))))
 (or $x344 $x563))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let (($x570 (= real_owner @X)))
 (or $x570 $x354))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let (($x570 (= real_owner @X)))
 (or $x570 $x369))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x570 (= real_owner @X)))
 (or $x570 $x331))))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (let (($x574 (= real_owner @V0)))
 (or $x574 $x302))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x574 (= real_owner @V0)))
 (or $x574 $x558))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (or $x360 dir.head)))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (or $x375 dir.head)))
(assert
 (let (($x346 (not (net.put home @X))))
 (or $x346 dir.head)))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (or $x308 dir.head)))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (or $x354 dir.head)))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (or $x369 dir.head)))
(assert
 (let (($x331 (not (net.putX home @X))))
 (or $x331 dir.head)))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (or $x302 dir.head)))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (or $x558 dir.head)))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (or $x354 dir.dirty)))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (or $x369 dir.dirty)))
(assert
 (let (($x331 (not (net.putX home @X))))
 (or $x331 dir.dirty)))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (or $x302 dir.dirty)))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (or $x558 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x331 (not (net.putX home @X))))
 (or $x331 dir.head)))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (or $x558 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x344 (not (rp_net @X))))
 (let (($x360 (not (net.put @Y @X))))
 (or $x360 $x344))))
(assert
 (let (($x344 (not (rp_net @X))))
 (let (($x375 (not (net.put @Z @X))))
 (or $x375 $x344))))
(assert
 (let (($x344 (not (rp_net @X))))
 (let (($x346 (not (net.put home @X))))
 (or $x346 $x344))))
(assert
 (let (($x600 (not (rp_net @V0))))
 (let (($x308 (not (net.put @V1 @V0))))
 (or $x308 $x600))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x563 (not (= (cache.state_ @X) shared))))
 (let (($x617 (not (invack @X))))
 (or $x617 $x563))))
(assert
 (let (($x566 (not (= (cache.state_ @V0) shared))))
 (let (($x620 (not (invack @V0))))
 (or $x620 $x566))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x360 __dir.pending))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x375 __dir.pending))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x346 __dir.pending))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x308 __dir.pending))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x603 __dir.pending))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x605 __dir.pending))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x607 __dir.pending))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x360 dir.dirty))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x375 dir.dirty))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x346 dir.dirty))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x308 dir.dirty))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x603 dir.dirty))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x605 dir.dirty))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x607 dir.dirty))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x360))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x375))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x346))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x308))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x603))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x605))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x607))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x646))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x331))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x558))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x651))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x346))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x603))))
(assert
 (let (($x655 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x653 (not $x58)))
 (or $x653 $x655)))))
(assert
 (let (($x351 (not (net.get @X home))))
 (let (($x622 (dir.shlist @X)))
 (let (($x657 (not $x622)))
 (or $x657 $x351)))))
(assert
 (let (($x661 (not (net.get @V0 home))))
 (let (($x626 (dir.shlist @V0)))
 (let (($x659 (not $x626)))
 (or $x659 $x661)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x653 (not $x58)))
 (or $x653 dir.head))))
(assert
 (let (($x622 (dir.shlist @X)))
 (let (($x657 (not $x622)))
 (or $x657 dir.head))))
(assert
 (let (($x626 (dir.shlist @V0)))
 (let (($x659 (not $x626)))
 (or $x659 dir.head))))
(assert
 (let (($x340 (not (= (cache.state_ @X) exclusive))))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x340))))
(assert
 (let (($x553 (not (= (cache.state_ @V0) exclusive))))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x553))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let (($x668 (= @X home)))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x668 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let (($x668 (= @X home)))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x668 $x375)))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let (($x668 (= @X home)))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x668 $x346)))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let (($x450 (= @V0 home)))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x450 $x308)))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let (($x450 (= @V0 home)))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x450 $x603)))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let (($x668 (= @X home)))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x668 $x605)))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let (($x450 (= @V0 home)))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x450 $x607)))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let (($x676 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x676 $x651)))))
(assert
 (let (($x340 (not (= (cache.state_ @X) exclusive))))
 (let (($x537 (= @X __requester)))
 (let (($x622 (dir.shlist @X)))
 (or $x622 $x537 $x340)))))
(assert
 (let (($x553 (not (= (cache.state_ @V0) exclusive))))
 (let (($x545 (= @V0 __requester)))
 (let (($x626 (dir.shlist @V0)))
 (or $x626 $x545 $x553)))))
(assert
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (let (($x550 (= @X real_owner)))
 (or (dir.real @X) $x550 $x681)))))
(assert
 (let ((?x314 (cache.state_ @V0)))
 (let (($x315 (= ?x314 invalid)))
 (let (($x485 (= @V0 real_owner)))
 (or (dir.real @V0) $x485 $x315)))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x331))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x558))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x646))))
(assert
 (let (($x563 (not (= (cache.state_ @X) shared))))
 (or $x563 (not (= (cache.wait @X) get)))))
(assert
 (let (($x566 (not (= (cache.state_ @V0) shared))))
 (or $x566 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x617 (not (invack @X))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x617)))))
(assert
 (let (($x620 (not (invack @V0))))
 (let ((?x314 (cache.state_ @V0)))
 (let (($x315 (= ?x314 invalid)))
 (or $x315 $x620)))))
(assert
 (let (($x340 (not (= (cache.state_ @X) exclusive))))
 (or $x340 dir.head)))
(assert
 (let (($x553 (not (= (cache.state_ @V0) exclusive))))
 (or $x553 dir.head)))
(assert
 (let (($x187 (not (net.fack __requester home))))
 (let (($x445 (= home home)))
 (or $x445 $x187))))
(assert
 (let (($x297 (not (net.fack @V0 @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x297))))
(assert
 (let (($x354 (not (net.putX @Y @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x354)))))
(assert
 (let (($x369 (not (net.putX @Z @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x369)))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x331)))))
(assert
 (let (($x302 (not (net.putX @V1 @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x300 (= ?x299 getX)))
 (or $x300 $x302)))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x300 (= ?x299 getX)))
 (or $x300 $x558)))))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x594)))))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x300 (= ?x299 getX)))
 (or $x300 $x596)))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x703 (= ?x702 getX)))
 (or $x703 $x646)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (let ((?x705 (cache.wait __src)))
 (let (($x706 (= ?x705 getX)))
 (or $x706 $x475))))))
(assert
 (let (($x433 (__net.getX @X @Y)))
 (let (($x477 (not $x433)))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x477))))))
(assert
 (let (($x438 (__net.getX @X @Z)))
 (let (($x479 (not $x438)))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x479))))))
(assert
 (let (($x442 (__net.getX home @Y)))
 (let (($x481 (not $x442)))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x481))))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x483))))))
(assert
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x486 (not $x452)))
 (let ((?x326 (cache.wait @V1)))
 (let (($x714 (= ?x326 getX)))
 (or $x714 $x486))))))
(assert
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x488 (not $x456)))
 (let ((?x299 (cache.wait @V0)))
 (let (($x300 (= ?x299 getX)))
 (or $x300 $x488))))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x375)))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x346)))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x309 (= ?x299 get)))
 (or $x309 $x308)))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x309 (= ?x299 get)))
 (or $x309 $x603)))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x605)))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x309 (= ?x299 get)))
 (or $x309 $x607)))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x722 (= ?x702 get)))
 (or $x722 $x651)))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x372)))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x362)))))
(assert
 (let (($x351 (not (net.get @X home))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x351)))))
(assert
 (let (($x312 (not (net.get @V0 @V1))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x309 (= ?x299 get)))
 (or $x309 $x312)))))
(assert
 (let (($x609 (not (net.get home @Y))))
 (let ((?x710 (cache.wait home)))
 (let (($x726 (= ?x710 get)))
 (or $x726 $x609)))))
(assert
 (let (($x611 (not (net.get home @Z))))
 (let ((?x710 (cache.wait home)))
 (let (($x726 (= ?x710 get)))
 (or $x726 $x611)))))
(assert
 (let (($x613 (not (net.get home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x726 (= ?x710 get)))
 (or $x726 $x613)))))
(assert
 (let (($x615 (not (net.get home @V1))))
 (let ((?x710 (cache.wait home)))
 (let (($x726 (= ?x710 get)))
 (or $x726 $x615)))))
(assert
 (let (($x360 (not (net.put @Y @X))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x360)))))
(assert
 (let (($x375 (not (net.put @Z @X))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x375)))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x346)))))
(assert
 (let (($x308 (not (net.put @V1 @V0))))
 (let ((?x314 (cache.state_ @V0)))
 (let (($x315 (= ?x314 invalid)))
 (or $x315 $x308)))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let ((?x314 (cache.state_ @V0)))
 (let (($x315 (= ?x314 invalid)))
 (or $x315 $x603)))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x605)))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let ((?x314 (cache.state_ @V0)))
 (let (($x315 (= ?x314 invalid)))
 (or $x315 $x607)))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let ((?x737 (cache.state_ dir.hptr)))
 (let (($x738 (= ?x737 invalid)))
 (or $x738 $x651)))))
(assert
 (let (($x372 (not (net.get @X @Y))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x372)))))
(assert
 (let (($x362 (not (net.get @X @Z))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x362)))))
(assert
 (let (($x351 (not (net.get @X home))))
 (let ((?x338 (cache.state_ @X)))
 (let (($x681 (= ?x338 invalid)))
 (or $x681 $x351)))))
(assert
 (let (($x312 (not (net.get @V0 @V1))))
 (let ((?x314 (cache.state_ @V0)))
 (let (($x315 (= ?x314 invalid)))
 (or $x315 $x312)))))
(assert
 (let (($x609 (not (net.get home @Y))))
 (let ((?x743 (cache.state_ home)))
 (let (($x744 (= ?x743 invalid)))
 (or $x744 $x609)))))
(assert
 (let (($x611 (not (net.get home @Z))))
 (let ((?x743 (cache.state_ home)))
 (let (($x744 (= ?x743 invalid)))
 (or $x744 $x611)))))
(assert
 (let (($x613 (not (net.get home home))))
 (let ((?x743 (cache.state_ home)))
 (let (($x744 (= ?x743 invalid)))
 (or $x744 $x613)))))
(assert
 (let (($x615 (not (net.get home @V1))))
 (let ((?x743 (cache.state_ home)))
 (let (($x744 (= ?x743 invalid)))
 (or $x744 $x615)))))
(assert
 (let (($x319 (= @Y home)))
 (or $x319 (not (net.shwb @X @Y)))))
(assert
 (let (($x445 (= home home)))
 (or $x445 (not (net.shwb @X home)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (or $x475 (not (= (cache.wait __src) none))))))
(assert
 (let (($x754 (not (= (cache.wait @X) none))))
 (let (($x433 (__net.getX @X @Y)))
 (let (($x477 (not $x433)))
 (or $x477 $x754)))))
(assert
 (let (($x754 (not (= (cache.wait @X) none))))
 (let (($x438 (__net.getX @X @Z)))
 (let (($x479 (not $x438)))
 (or $x479 $x754)))))
(assert
 (let (($x758 (not (= (cache.wait home) none))))
 (let (($x442 (__net.getX home @Y)))
 (let (($x481 (not $x442)))
 (or $x481 $x758)))))
(assert
 (let (($x754 (not (= (cache.wait @X) none))))
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (or $x483 $x754)))))
(assert
 (let (($x328 (not (= (cache.wait @V1) none))))
 (let (($x452 (__net.getX @V1 @V0)))
 (let (($x486 (not $x452)))
 (or $x486 $x328)))))
(assert
 (let (($x763 (not (= (cache.wait @V0) none))))
 (let (($x456 (__net.getX @V0 @V1)))
 (let (($x488 (not $x456)))
 (or $x488 $x763)))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x765 (= ?x140 getX)))
 (or $x765 $x767)))))
(assert
 (let (($x331 (not (net.putX home @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x331)))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x714 (= ?x326 getX)))
 (or $x714 $x770)))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x300 (= ?x299 getX)))
 (or $x300 $x558)))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x703 (= ?x702 getX)))
 (or $x703 $x646)))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let ((?x705 (cache.wait __src)))
 (let (($x706 (= ?x705 getX)))
 (or $x706 $x773)))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x776)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x475 (not $x271)))
 (let ((?x705 (cache.wait __src)))
 (let (($x706 (= ?x705 getX)))
 (or $x706 $x475))))))
(assert
 (let (($x447 (__net.getX @X home)))
 (let (($x483 (not $x447)))
 (let ((?x332 (cache.wait @X)))
 (let (($x333 (= ?x332 getX)))
 (or $x333 $x483))))))
(assert
 (let (($x779 (not (__net.getX home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x779)))))
(assert
 (let (($x782 (not (__net.getX @V1 home))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x714 (= ?x326 getX)))
 (or $x714 $x782)))))
(assert
 (let (($x785 (not (__net.getX @V0 home))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x300 (= ?x299 getX)))
 (or $x300 $x785)))))
(assert
 (let (($x340 (not (= (cache.state_ @X) exclusive))))
 (or $x340 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x553 (not (= (cache.state_ @V0) exclusive))))
 (or $x553 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x790 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x790 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x794 (not (= (cache.state_ home) exclusive))))
 (or $x794 (not (= (cache.wait home) getX)))))
(assert
 (let (($x344 (not (rp_net @X))))
 (let (($x346 (not (net.put home @X))))
 (or $x346 $x344))))
(assert
 (let (($x600 (not (rp_net @V0))))
 (let (($x603 (not (net.put home @V0))))
 (or $x603 $x600))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x799)))))
(assert
 (let (($x346 (not (net.put home @X))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x346)))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x801 (= ?x326 get)))
 (or $x801 $x803)))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x309 (= ?x299 get)))
 (or $x309 $x603)))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x722 (= ?x702 get)))
 (or $x722 $x651)))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let ((?x705 (cache.wait __src)))
 (let (($x805 (= ?x705 get)))
 (or $x805 $x807)))))
(assert
 (let (($x810 (not (net.put home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x726 (= ?x710 get)))
 (or $x726 $x810)))))
(assert
 (let (($x813 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x813)))))
(assert
 (let (($x351 (not (net.get @X home))))
 (let ((?x332 (cache.wait @X)))
 (let (($x348 (= ?x332 get)))
 (or $x348 $x351)))))
(assert
 (let (($x816 (not (net.get @V1 home))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x801 (= ?x326 get)))
 (or $x801 $x816)))))
(assert
 (let (($x661 (not (net.get @V0 home))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x309 (= ?x299 get)))
 (or $x309 $x661)))))
(assert
 (let (($x655 (not (net.get dir.hptr home))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x722 (= ?x702 get)))
 (or $x722 $x655)))))
(assert
 (let (($x821 (not (net.get __src home))))
 (let ((?x705 (cache.wait __src)))
 (let (($x805 (= ?x705 get)))
 (or $x805 $x821)))))
(assert
 (let (($x613 (not (net.get home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x726 (= ?x710 get)))
 (or $x726 $x613)))))
(assert
 (not (__net.getX home home)))
(assert
 (let (($x442 (__net.getX home @Y)))
 (not $x442)))
(assert
 (not (__net.getX home @Z)))
(assert
 (not (__net.getX home @V0)))
(assert
 (not (__net.getX home @V1)))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x603)))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x145 $x605)))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x145 $x607)))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x651)))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x799)))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x803)))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x807)))))
(assert
 (let (($x810 (not (net.put home home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x810)))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x558)))))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (let (($x839 (= real_owner real_owner)))
 (let (($x838 (= real_owner home)))
 (or $x838 $x839 $x594)))))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (let (($x839 (= real_owner real_owner)))
 (let (($x838 (= real_owner home)))
 (or $x838 $x839 $x596)))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x646)))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x767)))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x770)))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x773)))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x776)))))
(assert
 (let (($x609 (not (net.get home @Y))))
 (let (($x459 (= @Y real_owner)))
 (let (($x319 (= @Y home)))
 (or $x319 $x459 $x609)))))
(assert
 (let (($x611 (not (net.get home @Z))))
 (let (($x461 (= @Z real_owner)))
 (let (($x436 (= @Z home)))
 (or $x436 $x461 $x611)))))
(assert
 (let (($x613 (not (net.get home home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x613)))))
(assert
 (let (($x615 (not (net.get home @V1))))
 (let (($x465 (= @V1 real_owner)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x465 $x615)))))
(assert
 (let (($x655 (not (net.get dir.hptr home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x655)))))
(assert
 (let (($x661 (not (net.get @V0 home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x661)))))
(assert
 (let (($x813 (not (net.get real_owner home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x813)))))
(assert
 (let (($x816 (not (net.get @V1 home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x816)))))
(assert
 (let (($x779 (not (__net.getX home home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x779)))))
(assert
 (let (($x782 (not (__net.getX @V1 home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x782)))))
(assert
 (let (($x785 (not (__net.getX @V0 home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x785)))))
(assert
 (let (($x824 (not (__net.getX home @Z))))
 (let (($x461 (= @Z real_owner)))
 (let (($x436 (= @Z home)))
 (or $x436 $x461 $x824)))))
(assert
 (let (($x826 (not (__net.getX home @V0))))
 (let (($x485 (= @V0 real_owner)))
 (let (($x450 (= @V0 home)))
 (or $x450 $x485 $x826)))))
(assert
 (let (($x828 (not (__net.getX home @V1))))
 (let (($x465 (= @V1 real_owner)))
 (let (($x294 (= @V1 home)))
 (or $x294 $x465 $x828)))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (let (($x445 (= home home)))
 (or $x445 $x603 dir.dirty))))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x605 dir.dirty))))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x607 dir.dirty))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let (($x445 (= home home)))
 (or $x445 $x651 dir.dirty))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let (($x445 (= home home)))
 (or $x445 $x799 dir.dirty))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let (($x445 (= home home)))
 (or $x445 $x803 dir.dirty))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let (($x445 (= home home)))
 (or $x445 $x807 dir.dirty))))
(assert
 (let (($x810 (not (net.put home home))))
 (let (($x445 (= home home)))
 (or $x445 $x810 dir.dirty))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x445 (= home home)))
 (or $x445 $x558 dir.head))))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x594 dir.head))))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x596 dir.head))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x445 (= home home)))
 (or $x445 $x646 dir.head))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x445 (= home home)))
 (or $x445 $x767 dir.head))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x445 (= home home)))
 (or $x445 $x770 dir.head))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x445 (= home home)))
 (or $x445 $x773 dir.head))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x445 (= home home)))
 (or $x445 $x776 dir.head))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x445 (= home home)))
 (or $x445 $x558 dir.dirty))))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x594 dir.dirty))))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x596 dir.dirty))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x445 (= home home)))
 (or $x445 $x646 dir.dirty))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x445 (= home home)))
 (or $x445 $x767 dir.dirty))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x445 (= home home)))
 (or $x445 $x770 dir.dirty))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x445 (= home home)))
 (or $x445 $x773 dir.dirty))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x445 (= home home)))
 (or $x445 $x776 dir.dirty))))
(assert
 (let (($x558 (not (net.putX home @V0))))
 (let (($x445 (= home home)))
 (or $x445 $x558))))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x594))))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x596))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x445 (= home home)))
 (or $x445 $x646))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x445 (= home home)))
 (or $x445 $x767))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x445 (= home home)))
 (or $x445 $x770))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x445 (= home home)))
 (or $x445 $x773))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x445 (= home home)))
 (or $x445 $x776))))
(assert
 (let (($x609 (not (net.get home @Y))))
 (let (($x319 (= @Y home)))
 (or $x319 $x609 dir.head))))
(assert
 (let (($x611 (not (net.get home @Z))))
 (let (($x436 (= @Z home)))
 (or $x436 $x611 dir.head))))
(assert
 (let (($x613 (not (net.get home home))))
 (let (($x445 (= home home)))
 (or $x445 $x613 dir.head))))
(assert
 (let (($x615 (not (net.get home @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x615 dir.head))))
(assert
 (let (($x655 (not (net.get dir.hptr home))))
 (let (($x445 (= home home)))
 (or $x445 $x655 dir.head))))
(assert
 (let (($x661 (not (net.get @V0 home))))
 (let (($x445 (= home home)))
 (or $x445 $x661 dir.head))))
(assert
 (let (($x813 (not (net.get real_owner home))))
 (let (($x445 (= home home)))
 (or $x445 $x813 dir.head))))
(assert
 (let (($x816 (not (net.get @V1 home))))
 (let (($x445 (= home home)))
 (or $x445 $x816 dir.head))))
(assert
 (let (($x609 (not (net.get home @Y))))
 (let (($x319 (= @Y home)))
 (or $x319 $x609 dir.dirty))))
(assert
 (let (($x611 (not (net.get home @Z))))
 (let (($x436 (= @Z home)))
 (or $x436 $x611 dir.dirty))))
(assert
 (let (($x613 (not (net.get home home))))
 (let (($x445 (= home home)))
 (or $x445 $x613 dir.dirty))))
(assert
 (let (($x615 (not (net.get home @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x615 dir.dirty))))
(assert
 (let (($x655 (not (net.get dir.hptr home))))
 (let (($x445 (= home home)))
 (or $x445 $x655 dir.dirty))))
(assert
 (let (($x661 (not (net.get @V0 home))))
 (let (($x445 (= home home)))
 (or $x445 $x661 dir.dirty))))
(assert
 (let (($x813 (not (net.get real_owner home))))
 (let (($x445 (= home home)))
 (or $x445 $x813 dir.dirty))))
(assert
 (let (($x816 (not (net.get @V1 home))))
 (let (($x445 (= home home)))
 (or $x445 $x816 dir.dirty))))
(assert
 (let (($x779 (not (__net.getX home home))))
 (let (($x445 (= home home)))
 (or $x445 $x779 dir.head))))
(assert
 (let (($x782 (not (__net.getX @V1 home))))
 (let (($x445 (= home home)))
 (or $x445 $x782 dir.head))))
(assert
 (let (($x785 (not (__net.getX @V0 home))))
 (let (($x445 (= home home)))
 (or $x445 $x785 dir.head))))
(assert
 (let (($x824 (not (__net.getX home @Z))))
 (let (($x436 (= @Z home)))
 (or $x436 $x824 dir.head))))
(assert
 (let (($x826 (not (__net.getX home @V0))))
 (let (($x450 (= @V0 home)))
 (or $x450 $x826 dir.head))))
(assert
 (let (($x828 (not (__net.getX home @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x828 dir.head))))
(assert
 (let (($x779 (not (__net.getX home home))))
 (let (($x445 (= home home)))
 (or $x445 $x779 dir.dirty))))
(assert
 (let (($x782 (not (__net.getX @V1 home))))
 (let (($x445 (= home home)))
 (or $x445 $x782 dir.dirty))))
(assert
 (let (($x785 (not (__net.getX @V0 home))))
 (let (($x445 (= home home)))
 (or $x445 $x785 dir.dirty))))
(assert
 (let (($x824 (not (__net.getX home @Z))))
 (let (($x436 (= @Z home)))
 (or $x436 $x824 dir.dirty))))
(assert
 (let (($x826 (not (__net.getX home @V0))))
 (let (($x450 (= @V0 home)))
 (or $x450 $x826 dir.dirty))))
(assert
 (let (($x828 (not (__net.getX home @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x828 dir.dirty))))
(assert
 (let (($x779 (not (__net.getX home home))))
 (let (($x445 (= home home)))
 (or $x445 $x779))))
(assert
 (let (($x782 (not (__net.getX @V1 home))))
 (let (($x445 (= home home)))
 (or $x445 $x782))))
(assert
 (let (($x785 (not (__net.getX @V0 home))))
 (let (($x445 (= home home)))
 (or $x445 $x785))))
(assert
 (let (($x824 (not (__net.getX home @Z))))
 (let (($x436 (= @Z home)))
 (or $x436 $x824))))
(assert
 (let (($x826 (not (__net.getX home @V0))))
 (let (($x450 (= @V0 home)))
 (or $x450 $x826))))
(assert
 (let (($x828 (not (__net.getX home @V1))))
 (let (($x294 (= @V1 home)))
 (or $x294 $x828))))
(assert
 (let (($x779 (not (__net.getX home home))))
 (let (($x445 (= home home)))
 (let (($x540 (= home __requester)))
 (or $x540 $x445 $x779)))))
(assert
 (let (($x782 (not (__net.getX @V1 home))))
 (let (($x445 (= home home)))
 (let (($x543 (= @V1 __requester)))
 (or $x543 $x445 $x782)))))
(assert
 (let (($x785 (not (__net.getX @V0 home))))
 (let (($x445 (= home home)))
 (let (($x545 (= @V0 __requester)))
 (or $x545 $x445 $x785)))))
(assert
 (let (($x824 (not (__net.getX home @Z))))
 (let (($x436 (= @Z home)))
 (let (($x540 (= home __requester)))
 (or $x540 $x436 $x824)))))
(assert
 (let (($x826 (not (__net.getX home @V0))))
 (let (($x450 (= @V0 home)))
 (let (($x540 (= home __requester)))
 (or $x540 $x450 $x826)))))
(assert
 (let (($x828 (not (__net.getX home @V1))))
 (let (($x294 (= @V1 home)))
 (let (($x540 (= home __requester)))
 (or $x540 $x294 $x828)))))
(assert
 (let (($x790 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x790))))
(assert
 (let (($x794 (not (= (cache.state_ home) exclusive))))
 (let (($x463 (= home real_owner)))
 (or $x463 $x794))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x934 (= dir.hptr dir.hptr)))
 (or $x934 $x646))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x936 (= real_owner dir.hptr)))
 (or $x936 $x767))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x427 (= @V1 dir.hptr)))
 (or $x427 $x770))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x277 (= __src dir.hptr)))
 (or $x277 $x773))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x415 (= home dir.hptr)))
 (or $x415 $x776))))
(assert
 (let (($x790 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x934 (= dir.hptr dir.hptr)))
 (or $x934 $x790))))
(assert
 (let (($x794 (not (= (cache.state_ home) exclusive))))
 (let (($x415 (= home dir.hptr)))
 (or $x415 $x794))))
(assert
 (let (($x944 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x944))))
(assert
 (let (($x947 (not (= (cache.state_ home) shared))))
 (let (($x463 (= home real_owner)))
 (or $x463 $x947))))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x594))))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x596))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x445 (= home home)))
 (or $x445 $x646))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x445 (= home home)))
 (or $x445 $x767))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x445 (= home home)))
 (or $x445 $x770))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x445 (= home home)))
 (or $x445 $x773))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x445 (= home home)))
 (or $x445 $x776))))
(assert
 (let (($x566 (not (= (cache.state_ @V0) shared))))
 (let (($x600 (not (rp_net @V0))))
 (or $x600 $x566))))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (let (($x570 (= real_owner @X)))
 (or $x570 $x594))))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (let (($x574 (= real_owner @V0)))
 (or $x574 $x596))))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (let (($x936 (= real_owner dir.hptr)))
 (or $x936 $x646))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x839 (= real_owner real_owner)))
 (or $x839 $x767))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x770)))
(assert
 (let (($x773 (not (net.putX home __src))))
 (or (= real_owner __src) $x773)))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x776))))
(assert
 (let (($x603 (not (net.put home @V0))))
 (or $x603 dir.head)))
(assert
 (let (($x605 (not (net.put dir.hptr @X))))
 (or $x605 dir.head)))
(assert
 (let (($x607 (not (net.put dir.hptr @V0))))
 (or $x607 dir.head)))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (or $x651 dir.head)))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (or $x799 dir.head)))
(assert
 (let (($x803 (not (net.put home @V1))))
 (or $x803 dir.head)))
(assert
 (let (($x807 (not (net.put home __src))))
 (or $x807 dir.head)))
(assert
 (let (($x810 (not (net.put home home))))
 (or $x810 dir.head)))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (or $x594 dir.head)))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (or $x596 dir.head)))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (or $x646 dir.head)))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (or $x767 dir.head)))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (or $x770 dir.head)))
(assert
 (let (($x773 (not (net.putX home __src))))
 (or $x773 dir.head)))
(assert
 (let (($x776 (not (net.putX home home))))
 (or $x776 dir.head)))
(assert
 (let (($x594 (not (net.putX real_owner @X))))
 (or $x594 dir.dirty)))
(assert
 (let (($x596 (not (net.putX real_owner @V0))))
 (or $x596 dir.dirty)))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (or $x646 dir.dirty)))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (or $x767 dir.dirty)))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (or $x770 dir.dirty)))
(assert
 (let (($x773 (not (net.putX home __src))))
 (or $x773 dir.dirty)))
(assert
 (let (($x776 (not (net.putX home home))))
 (or $x776 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner __src)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x646 (not (net.putX home dir.hptr))))
 (or $x646 dir.head)))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (or $x767 dir.head)))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (or $x770 dir.head)))
(assert
 (let (($x773 (not (net.putX home __src))))
 (or $x773 dir.head)))
(assert
 (let (($x776 (not (net.putX home home))))
 (or $x776 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home __src)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x600 (not (rp_net @V0))))
 (let (($x603 (not (net.put home @V0))))
 (or $x603 $x600))))
(assert
 (let (($x344 (not (rp_net @X))))
 (let (($x605 (not (net.put dir.hptr @X))))
 (or $x605 $x344))))
(assert
 (let (($x600 (not (rp_net @V0))))
 (let (($x607 (not (net.put dir.hptr @V0))))
 (or $x607 $x600))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (or $x651 (not (rp_net dir.hptr)))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (or $x799 (not (rp_net real_owner)))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (or $x803 (not (rp_net @V1)))))
(assert
 (let (($x807 (not (net.put home __src))))
 (or $x807 (not (rp_net __src)))))
(assert
 (let (($x810 (not (net.put home home))))
 (or $x810 (not (rp_net home)))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x617 (not (invack @X))))
 (or $x617 (not (invnet @X)))))
(assert
 (let (($x620 (not (invack @V0))))
 (or $x620 (not (invnet @V0)))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x651 __dir.pending))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x799 __dir.pending))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x803 __dir.pending))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let (($x1029 (dir.shlist __src)))
 (or $x1029 $x807 __dir.pending))))
(assert
 (let (($x810 (not (net.put home home))))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x810 __dir.pending))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1009 __dir.pending))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x1011 __dir.pending))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x1013 __dir.pending))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x651 dir.dirty))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x799 dir.dirty))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x803 dir.dirty))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let (($x1029 (dir.shlist __src)))
 (or $x1029 $x807 dir.dirty))))
(assert
 (let (($x810 (not (net.put home home))))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x810 dir.dirty))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1009 dir.dirty))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x1011 dir.dirty))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x1013 dir.dirty))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x651))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x799))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x803))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let (($x1029 (dir.shlist __src)))
 (or $x1029 $x807))))
(assert
 (let (($x810 (not (net.put home home))))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x810))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1009))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x1011))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x1013))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x767))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x770))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x1029 (dir.shlist __src)))
 (or $x1029 $x773))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x776))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x799))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x803))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let (($x1029 (dir.shlist __src)))
 (or $x1029 $x807))))
(assert
 (let (($x810 (not (net.put home home))))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x810))))
(assert
 (let (($x813 (not (net.get real_owner home))))
 (let (($x1025 (dir.shlist real_owner)))
 (let (($x1055 (not $x1025)))
 (or $x1055 $x813)))))
(assert
 (let (($x816 (not (net.get @V1 home))))
 (let (($x1027 (dir.shlist @V1)))
 (let (($x1057 (not $x1027)))
 (or $x1057 $x816)))))
(assert
 (let (($x821 (not (net.get __src home))))
 (let (($x1029 (dir.shlist __src)))
 (let (($x1059 (not $x1029)))
 (or $x1059 $x821)))))
(assert
 (let (($x613 (not (net.get home home))))
 (let (($x1031 (dir.shlist home)))
 (let (($x1061 (not $x1031)))
 (or $x1061 $x613)))))
(assert
 (let (($x1025 (dir.shlist real_owner)))
 (let (($x1055 (not $x1025)))
 (or $x1055 dir.head))))
(assert
 (let (($x1027 (dir.shlist @V1)))
 (let (($x1057 (not $x1027)))
 (or $x1057 dir.head))))
(assert
 (let (($x1029 (dir.shlist __src)))
 (let (($x1059 (not $x1029)))
 (or $x1059 dir.head))))
(assert
 (let (($x1031 (dir.shlist home)))
 (let (($x1061 (not $x1031)))
 (or $x1061 dir.head))))
(assert
 (let (($x790 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x790))))
(assert
 (let (($x794 (not (= (cache.state_ home) exclusive))))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x794))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let (($x838 (= real_owner home)))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x838 $x799)))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let (($x294 (= @V1 home)))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x294 $x803)))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let (($x1071 (= __src home)))
 (let (($x1029 (dir.shlist __src)))
 (or $x1029 $x1071 $x807)))))
(assert
 (let (($x810 (not (net.put home home))))
 (let (($x445 (= home home)))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x445 $x810)))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let (($x676 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x676 $x1009)))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let (($x838 (= real_owner home)))
 (let (($x1025 (dir.shlist real_owner)))
 (or $x1025 $x838 $x1011)))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let (($x294 (= @V1 home)))
 (let (($x1027 (dir.shlist @V1)))
 (or $x1027 $x294 $x1013)))))
(assert
 (let (($x1015 (not (net.put dir.hptr __src))))
 (let (($x1071 (= __src home)))
 (let (($x1029 (dir.shlist __src)))
 (or $x1029 $x1071 $x1015)))))
(assert
 (let (($x790 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x1078 (= dir.hptr __requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x1078 $x790)))))
(assert
 (let (($x794 (not (= (cache.state_ home) exclusive))))
 (let (($x540 (= home __requester)))
 (let (($x1031 (dir.shlist home)))
 (or $x1031 $x540 $x794)))))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x767))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x770))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x773))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x776))))
(assert
 (let (($x944 (not (= (cache.state_ dir.hptr) shared))))
 (or $x944 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x947 (not (= (cache.state_ home) shared))))
 (or $x947 (not (= (cache.wait home) get)))))
(assert
 (let (($x790 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x790 dir.head)))
(assert
 (let (($x794 (not (= (cache.state_ home) exclusive))))
 (or $x794 dir.head)))
(assert
 (let (($x767 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x765 (= ?x140 getX)))
 (or $x765 $x767)))))
(assert
 (let (($x770 (not (net.putX home @V1))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x714 (= ?x326 getX)))
 (or $x714 $x770)))))
(assert
 (let (($x773 (not (net.putX home __src))))
 (let ((?x705 (cache.wait __src)))
 (let (($x706 (= ?x705 getX)))
 (or $x706 $x773)))))
(assert
 (let (($x776 (not (net.putX home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x776)))))
(assert
 (let (($x982 (not (net.putX real_owner dir.hptr))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x703 (= ?x702 getX)))
 (or $x703 $x982)))))
(assert
 (let (($x984 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x765 (= ?x140 getX)))
 (or $x765 $x984)))))
(assert
 (let (($x986 (not (net.putX real_owner @V1))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x714 (= ?x326 getX)))
 (or $x714 $x986)))))
(assert
 (let (($x988 (not (net.putX real_owner __src))))
 (let ((?x705 (cache.wait __src)))
 (let (($x706 (= ?x705 getX)))
 (or $x706 $x988)))))
(assert
 (let (($x779 (not (__net.getX home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x779)))))
(assert
 (let (($x782 (not (__net.getX @V1 home))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x714 (= ?x326 getX)))
 (or $x714 $x782)))))
(assert
 (let (($x785 (not (__net.getX @V0 home))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x300 (= ?x299 getX)))
 (or $x300 $x785)))))
(assert
 (let (($x824 (not (__net.getX home @Z))))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x824)))))
(assert
 (let (($x826 (not (__net.getX home @V0))))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x826)))))
(assert
 (let (($x828 (not (__net.getX home @V1))))
 (let ((?x710 (cache.wait home)))
 (let (($x711 (= ?x710 getX)))
 (or $x711 $x828)))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x799)))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x801 (= ?x326 get)))
 (or $x801 $x803)))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let ((?x705 (cache.wait __src)))
 (let (($x805 (= ?x705 get)))
 (or $x805 $x807)))))
(assert
 (let (($x810 (not (net.put home home))))
 (let ((?x710 (cache.wait home)))
 (let (($x726 (= ?x710 get)))
 (or $x726 $x810)))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x722 (= ?x702 get)))
 (or $x722 $x1009)))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x1011)))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x801 (= ?x326 get)))
 (or $x801 $x1013)))))
(assert
 (let (($x1015 (not (net.put dir.hptr __src))))
 (let ((?x705 (cache.wait __src)))
 (let (($x805 (= ?x705 get)))
 (or $x805 $x1015)))))
(assert
 (let (($x655 (not (net.get dir.hptr home))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x722 (= ?x702 get)))
 (or $x722 $x655)))))
(assert
 (let (($x661 (not (net.get @V0 home))))
 (let ((?x299 (cache.wait @V0)))
 (let (($x309 (= ?x299 get)))
 (or $x309 $x661)))))
(assert
 (let (($x813 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x813)))))
(assert
 (let (($x816 (not (net.get @V1 home))))
 (let ((?x326 (cache.wait @V1)))
 (let (($x801 (= ?x326 get)))
 (or $x801 $x816)))))
(assert
 (let (($x821 (not (net.get __src home))))
 (let ((?x705 (cache.wait __src)))
 (let (($x805 (= ?x705 get)))
 (or $x805 $x821)))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (let ((?x1102 (cache.state_ real_owner)))
 (let (($x1103 (= ?x1102 invalid)))
 (or $x1103 $x799)))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (let ((?x1105 (cache.state_ @V1)))
 (let (($x1106 (= ?x1105 invalid)))
 (or $x1106 $x803)))))
(assert
 (let (($x807 (not (net.put home __src))))
 (let ((?x1108 (cache.state_ __src)))
 (let (($x1109 (= ?x1108 invalid)))
 (or $x1109 $x807)))))
(assert
 (let (($x810 (not (net.put home home))))
 (let ((?x743 (cache.state_ home)))
 (let (($x744 (= ?x743 invalid)))
 (or $x744 $x810)))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let ((?x737 (cache.state_ dir.hptr)))
 (let (($x738 (= ?x737 invalid)))
 (or $x738 $x1009)))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let ((?x1102 (cache.state_ real_owner)))
 (let (($x1103 (= ?x1102 invalid)))
 (or $x1103 $x1011)))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let ((?x1105 (cache.state_ @V1)))
 (let (($x1106 (= ?x1105 invalid)))
 (or $x1106 $x1013)))))
(assert
 (let (($x1015 (not (net.put dir.hptr __src))))
 (let ((?x1108 (cache.state_ __src)))
 (let (($x1109 (= ?x1108 invalid)))
 (or $x1109 $x1015)))))
(assert
 (let (($x655 (not (net.get dir.hptr home))))
 (let ((?x737 (cache.state_ dir.hptr)))
 (let (($x738 (= ?x737 invalid)))
 (or $x738 $x655)))))
(assert
 (let (($x661 (not (net.get @V0 home))))
 (let ((?x314 (cache.state_ @V0)))
 (let (($x315 (= ?x314 invalid)))
 (or $x315 $x661)))))
(assert
 (let (($x813 (not (net.get real_owner home))))
 (let ((?x1102 (cache.state_ real_owner)))
 (let (($x1103 (= ?x1102 invalid)))
 (or $x1103 $x813)))))
(assert
 (let (($x816 (not (net.get @V1 home))))
 (let ((?x1105 (cache.state_ @V1)))
 (let (($x1106 (= ?x1105 invalid)))
 (or $x1106 $x816)))))
(assert
 (let (($x821 (not (net.get __src home))))
 (let ((?x1108 (cache.state_ __src)))
 (let (($x1109 (= ?x1108 invalid)))
 (or $x1109 $x821)))))
(assert
 (let (($x758 (not (= (cache.wait home) none))))
 (let (($x779 (not (__net.getX home home))))
 (or $x779 $x758))))
(assert
 (let (($x328 (not (= (cache.wait @V1) none))))
 (let (($x782 (not (__net.getX @V1 home))))
 (or $x782 $x328))))
(assert
 (let (($x763 (not (= (cache.wait @V0) none))))
 (let (($x785 (not (__net.getX @V0 home))))
 (or $x785 $x763))))
(assert
 (let (($x758 (not (= (cache.wait home) none))))
 (let (($x824 (not (__net.getX home @Z))))
 (or $x824 $x758))))
(assert
 (let (($x758 (not (= (cache.wait home) none))))
 (let (($x826 (not (__net.getX home @V0))))
 (or $x826 $x758))))
(assert
 (let (($x758 (not (= (cache.wait home) none))))
 (let (($x828 (not (__net.getX home @V1))))
 (or $x828 $x758))))
(assert
 (let (($x1128 (not (__net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x765 (= ?x140 getX)))
 (or $x765 $x1128)))))
(assert
 (let (($x1131 (not (__net.getX dir.hptr home))))
 (let ((?x702 (cache.wait dir.hptr)))
 (let (($x703 (= ?x702 getX)))
 (or $x703 $x1131)))))
(assert
 (let (($x1134 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1134 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1138 (not (= (cache.state_ @V1) exclusive))))
 (or $x1138 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x1142 (not (= (cache.state_ __src) exclusive))))
 (or $x1142 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x651 (not (net.put home dir.hptr))))
 (or $x651 (not (rp_net dir.hptr)))))
(assert
 (let (($x799 (not (net.put home real_owner))))
 (or $x799 (not (rp_net real_owner)))))
(assert
 (let (($x803 (not (net.put home @V1))))
 (or $x803 (not (rp_net @V1)))))
(assert
 (let (($x807 (not (net.put home __src))))
 (or $x807 (not (rp_net __src)))))
(assert
 (let (($x810 (not (net.put home home))))
 (or $x810 (not (rp_net home)))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x145 $x1009)))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x145 $x1011)))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x145 $x1013)))))
(assert
 (let (($x1015 (not (net.put dir.hptr __src))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x145 $x1015)))))
(assert
 (let (($x1017 (not (net.put dir.hptr home))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x145 $x1017)))))
(assert
 (let (($x982 (not (net.putX real_owner dir.hptr))))
 (let (($x839 (= real_owner real_owner)))
 (let (($x838 (= real_owner home)))
 (or $x838 $x839 $x982)))))
(assert
 (let (($x984 (not (net.putX real_owner real_owner))))
 (let (($x839 (= real_owner real_owner)))
 (let (($x838 (= real_owner home)))
 (or $x838 $x839 $x984)))))
(assert
 (let (($x986 (not (net.putX real_owner @V1))))
 (let (($x839 (= real_owner real_owner)))
 (let (($x838 (= real_owner home)))
 (or $x838 $x839 $x986)))))
(assert
 (let (($x988 (not (net.putX real_owner __src))))
 (let (($x839 (= real_owner real_owner)))
 (let (($x838 (= real_owner home)))
 (or $x838 $x839 $x988)))))
(assert
 (let (($x990 (not (net.putX real_owner home))))
 (let (($x839 (= real_owner real_owner)))
 (let (($x838 (= real_owner home)))
 (or $x838 $x839 $x990)))))
(assert
 (let (($x821 (not (net.get __src home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x821)))))
(assert
 (let (($x1128 (not (__net.getX real_owner home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x1128)))))
(assert
 (let (($x1131 (not (__net.getX dir.hptr home))))
 (let (($x463 (= home real_owner)))
 (let (($x445 (= home home)))
 (or $x445 $x463 $x1131)))))
(assert
 (let (($x1009 (not (net.put dir.hptr dir.hptr))))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x1009 dir.dirty))))
(assert
 (let (($x1011 (not (net.put dir.hptr real_owner))))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x1011 dir.dirty))))
(assert
 (let (($x1013 (not (net.put dir.hptr @V1))))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x1013 dir.dirty))))
(assert
 (let (($x1015 (not (net.put dir.hptr __src))))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x1015 dir.dirty))))
(assert
 (let (($x1017 (not (net.put dir.hptr home))))
 (let (($x676 (= dir.hptr home)))
 (or $x676 $x1017 dir.dirty))))
(assert
 (let (($x982 (not (net.putX real_owner dir.hptr))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x982 dir.head))))
(assert
 (let (($x984 (not (net.putX real_owner real_owner))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x984 dir.head))))
(assert
 (let (($x986 (not (net.putX real_owner @V1))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x986 dir.head))))
(assert
 (let (($x988 (not (net.putX real_owner __src))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x988 dir.head))))
(assert
 (let (($x990 (not (net.putX real_owner home))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x990 dir.head))))
(assert
 (let (($x982 (not (net.putX real_owner dir.hptr))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x982 dir.dirty))))
(assert
 (let (($x984 (not (net.putX real_owner real_owner))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x984 dir.dirty))))
(assert
 (let (($x986 (not (net.putX real_owner @V1))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x986 dir.dirty))))
(assert
 (let (($x988 (not (net.putX real_owner __src))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x988 dir.dirty))))
(assert
 (let (($x990 (not (net.putX real_owner home))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x990 dir.dirty))))
(assert
 (let (($x982 (not (net.putX real_owner dir.hptr))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x982))))
(assert
 (let (($x984 (not (net.putX real_owner real_owner))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x984))))
(assert
 (let (($x986 (not (net.putX real_owner @V1))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x986))))
(assert
 (let (($x988 (not (net.putX real_owner __src))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x988))))
(assert
 (let (($x990 (not (net.putX real_owner home))))
 (let (($x838 (= real_owner home)))
 (or $x838 $x990))))
(assert
 (let (($x821 (not (net.get __src home))))
 (let (($x445 (= home home)))
 (or $x445 $x821 dir.head))))
(assert
 (let (($x821 (not (net.get __src home))))
 (let (($x445 (= home home)))
 (or $x445 $x821 dir.dirty))))
(assert
 (let (($x1128 (not (__net.getX real_owner home))))
 (let (($x445 (= home home)))
 (or $x445 $x1128 dir.head))))
(assert
 (let (($x1131 (not (__net.getX dir.hptr home))))
 (let (($x445 (= home home)))
 (or $x445 $x1131 dir.head))))
(assert
 (let (($x1128 (not (__net.getX real_owner home))))
 (let (($x445 (= home home)))
 (or $x445 $x1128 dir.dirty))))
(assert
 (let (($x1131 (not (__net.getX dir.hptr home))))
 (let (($x445 (= home home)))
 (or $x445 $x1131 dir.dirty))))
(assert
 (let (($x1128 (not (__net.getX real_owner home))))
 (let (($x445 (= home home)))
 (or $x445 $x1128))))
(assert
 (let (($x1131 (not (__net.getX dir.hptr home))))
 (let (($x445 (= home home)))
 (or $x445 $x1131))))
(assert
 (let (($x1128 (not (__net.getX real_owner home))))
 (let (($x445 (= home home)))
 (or (= real_owner __requester) $x445 $x1128))))
(assert
 (let (($x1131 (not (__net.getX dir.hptr home))))
 (let (($x445 (= home home)))
 (let (($x1078 (= dir.hptr __requester)))
 (or $x1078 $x445 $x1131)))))
(assert
 (let (($x1134 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x839 (= real_owner real_owner)))
 (or $x839 $x1134))))
(assert
 (let (($x1138 (not (= (cache.state_ @V1) exclusive))))
 (let (($x465 (= @V1 real_owner)))
 (or $x465 $x1138))))
(assert
 (let (($x1142 (not (= (cache.state_ __src) exclusive))))
 (or (= __src real_owner) $x1142)))
(assert
 (let (($x1134 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x936 (= real_owner dir.hptr)))
 (or $x936 $x1134))))
(assert
 (let (($x1138 (not (= (cache.state_ @V1) exclusive))))
 (let (($x427 (= @V1 dir.hptr)))
 (or $x427 $x1138))))
(assert
 (let (($x1142 (not (= (cache.state_ __src) exclusive))))
 (let (($x277 (= __src dir.hptr)))
 (or $x277 $x1142))))
(check-sat)
