(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun __src () id)
(declare-fun wbnet.proc () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun wbnet.wb () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (cache.wait real_owner) get)))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (= ?x271 exclusive)))
(assert
 (not (= __src home)))
(assert
 (= wbnet.proc __src))
(assert
 wbnet.wb)
(assert
 (let ((?x292 (cache.wait @Y)))
 (let (($x293 (= ?x292 none)))
 (let ((?x287 (cache.wait @X)))
 (let (($x288 (= ?x287 none)))
 (and (= (cache.state_ @X) exclusive) $x288 (= (cache.state_ @Y) exclusive) $x293 (not (= @X @Y))))))))
(assert
 (let ((?x285 (cache.state_ @X)))
 (= ?x285 (ite (and (= @X __src)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x290 (cache.state_ @Y)))
 (= ?x290 (ite (and (= @Y __src)) invalid (__cache.state_ @Y)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x272 (= ?x271 exclusive)))
 (let (($x328 (not $x272)))
 (let (($x327 (= __src real_owner)))
 (or $x327 $x328))))))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (let (($x330 (= @X real_owner)))
 (or $x330 $x332))))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x334 (= @Y real_owner)))
 (or $x334 $x336))))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x272 (= ?x271 exclusive)))
 (let (($x328 (not $x272)))
 (or (= __src dir.hptr) $x328)))))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x332)))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x336)))
(assert
 (let (($x345 (not (= (__cache.state_ __src) shared))))
 (let (($x327 (= __src real_owner)))
 (or $x327 $x345))))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (let (($x330 (= @X real_owner)))
 (or $x330 $x348))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (let (($x334 (= @Y real_owner)))
 (or $x334 $x351))))
(assert
 (let (($x345 (not (= (__cache.state_ __src) shared))))
 (or (not (rp_net __src)) $x345)))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x348)))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x351)))
(assert
 (let (($x345 (not (= (__cache.state_ __src) shared))))
 (let (($x363 (not (invack __src))))
 (or $x363 $x345))))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (let (($x366 (not (invack @X))))
 (or $x366 $x348))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (let (($x369 (not (invack @Y))))
 (or $x369 $x351))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x372))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x377 (not $x58)))
 (or $x377 $x379)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x377 (not $x58)))
 (or $x377 dir.head))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x384))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x386 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x386 $x375)))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x388 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x388 $x384)))))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x391 (= ?x271 invalid)))
 (let (($x327 (= __src real_owner)))
 (or (dir.real __src) $x327 $x391)))))
(assert
 (let ((?x317 (__cache.state_ @X)))
 (let (($x394 (= ?x317 invalid)))
 (let (($x330 (= @X real_owner)))
 (or (dir.real @X) $x330 $x394)))))
(assert
 (let ((?x322 (__cache.state_ @Y)))
 (let (($x397 (= ?x322 invalid)))
 (let (($x334 (= @Y real_owner)))
 (or (dir.real @Y) $x334 $x397)))))
(assert
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x400 (= ?x382 invalid)))
 (let (($x145 (= dir.hptr real_owner)))
 (or (dir.real dir.hptr) $x145 $x400)))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x372))))
(assert
 (let (($x142 (not (= (cache.wait real_owner) get))))
 (let (($x405 (not (= (__cache.state_ real_owner) shared))))
 (or $x405 $x142))))
(assert
 (let (($x348 (not (= (__cache.state_ @X) shared))))
 (or $x348 (not (= (cache.wait @X) get)))))
(assert
 (let (($x351 (not (= (__cache.state_ @Y) shared))))
 (or $x351 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x363 (not (invack __src))))
 (let ((?x271 (__cache.state_ __src)))
 (let (($x391 (= ?x271 invalid)))
 (or $x391 $x363)))))
(assert
 (let (($x366 (not (invack @X))))
 (let ((?x317 (__cache.state_ @X)))
 (let (($x394 (= ?x317 invalid)))
 (or $x394 $x366)))))
(assert
 (let (($x369 (not (invack @Y))))
 (let ((?x322 (__cache.state_ @Y)))
 (let (($x397 (= ?x322 invalid)))
 (or $x397 $x369)))))
(assert
 (let ((?x271 (__cache.state_ __src)))
 (let (($x272 (= ?x271 exclusive)))
 (let (($x328 (not $x272)))
 (or $x328 dir.head)))))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (or $x332 dir.head)))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (or $x336 dir.head)))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x384 dir.head)))
(assert
 (let (($x421 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x421 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x423 (= home home)))
 (or $x423 $x187))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x426 (= ?x425 getX)))
 (or $x426 $x372)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x428 (= ?x425 get)))
 (or $x428 $x375)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x428 (= ?x425 get)))
 (or $x428 $x379)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x400 (= ?x382 invalid)))
 (or $x400 $x375)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x400 (= ?x382 invalid)))
 (or $x400 $x379)))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x426 (= ?x425 getX)))
 (or $x426 $x372)))))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x433 (= ?x140 getX)))
 (or $x433 $x435)))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (let ((?x287 (cache.wait @X)))
 (let (($x437 (= ?x287 getX)))
 (or $x437 $x439)))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (let ((?x292 (cache.wait @Y)))
 (let (($x441 (= ?x292 getX)))
 (or $x441 $x443)))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x426 (= ?x425 getX)))
 (or $x426 $x446)))))
(assert
 (let (($x421 (not (= (__cache.state_ real_owner) exclusive))))
 (or $x421 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x332 (not (= (__cache.state_ @X) exclusive))))
 (or $x332 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x336 (not (= (__cache.state_ @Y) exclusive))))
 (or $x336 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x384 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x457 (not (rp_net dir.hptr))))
 (let (($x375 (not (net.put home dir.hptr))))
 (or $x375 $x457))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x428 (= ?x425 get)))
 (or $x428 $x375)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x428 (= ?x425 get)))
 (or $x428 $x379)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x375)))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x372)))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x379)))))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x435)))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x439)))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x443)))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x446)))))
(assert
 (let (($x460 (not (net.getX home home))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x460)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x375 dir.dirty))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x372 dir.head))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x372 dir.dirty))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x372))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x379 dir.head))))
(assert
 (let (($x379 (not (net.get dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x379 dir.dirty))))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (let (($x423 (= home home)))
 (or $x423 $x435 dir.head))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (or $x423 $x439 dir.head))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (let (($x423 (= home home)))
 (or $x423 $x443 dir.head))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x446 dir.head))))
(assert
 (let (($x460 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x460 dir.head))))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (let (($x423 (= home home)))
 (or $x423 $x435 dir.dirty))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (or $x423 $x439 dir.dirty))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (let (($x423 (= home home)))
 (or $x423 $x443 dir.dirty))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x446 dir.dirty))))
(assert
 (let (($x460 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x460 dir.dirty))))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (let (($x423 (= home home)))
 (or $x423 $x435))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (or $x423 $x439))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (let (($x423 (= home home)))
 (or $x423 $x443))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (let (($x423 (= home home)))
 (or $x423 $x446))))
(assert
 (let (($x460 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (or $x423 $x460))))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (let (($x423 (= home home)))
 (or (= real_owner requester) $x423 $x435))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (let (($x423 (= home home)))
 (or (= @X requester) $x423 $x439))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (let (($x423 (= home home)))
 (or (= @Y requester) $x423 $x443))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (let (($x423 (= home home)))
 (let (($x388 (= dir.hptr requester)))
 (or $x388 $x423 $x446)))))
(assert
 (let (($x460 (not (net.getX home home))))
 (let (($x423 (= home home)))
 (or (= home requester) $x423 $x460))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x384))))
(assert
 (let (($x421 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x501 (= real_owner real_owner)))
 (or $x501 $x421))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x503 (= dir.hptr dir.hptr)))
 (or $x503 $x372))))
(assert
 (let (($x384 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x503 (= dir.hptr dir.hptr)))
 (or $x503 $x384))))
(assert
 (let (($x421 (not (= (__cache.state_ real_owner) exclusive))))
 (let (($x506 (= real_owner dir.hptr)))
 (or $x506 $x421))))
(assert
 (let (($x509 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x509))))
(assert
 (let (($x405 (not (= (__cache.state_ real_owner) shared))))
 (let (($x501 (= real_owner real_owner)))
 (or $x501 $x405))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x423 (= home home)))
 (or $x423 $x372))))
(assert
 (let (($x509 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x457 (not (rp_net dir.hptr))))
 (or $x457 $x509))))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (let (($x506 (= real_owner dir.hptr)))
 (or $x506 $x372))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (or $x375 dir.head)))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (or $x372 dir.head)))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (or $x372 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x372 (not (net.putX home dir.hptr))))
 (or $x372 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x457 (not (rp_net dir.hptr))))
 (let (($x375 (not (net.put home dir.hptr))))
 (or $x375 $x457))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.get home home)))
(assert
 (let (($x363 (not (invack __src))))
 (or $x363 (not (invnet __src)))))
(assert
 (let (($x366 (not (invack @X))))
 (or $x366 (not (invnet @X)))))
(assert
 (let (($x369 (not (invack @Y))))
 (or $x369 (not (invnet @Y)))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375 dir.pending))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x520 dir.pending))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375 dir.dirty))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x520 dir.dirty))))
(assert
 (let (($x375 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x520))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let (($x386 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x386 $x520)))))
(assert
 (let (($x509 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x509 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x426 (= ?x425 getX)))
 (or $x426 $x518)))))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x433 (= ?x140 getX)))
 (or $x433 $x435)))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (let ((?x287 (cache.wait @X)))
 (let (($x437 (= ?x287 getX)))
 (or $x437 $x439)))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (let ((?x292 (cache.wait @Y)))
 (let (($x441 (= ?x292 getX)))
 (or $x441 $x443)))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x426 (= ?x425 getX)))
 (or $x426 $x446)))))
(assert
 (let (($x460 (not (net.getX home home))))
 (let ((?x541 (cache.wait home)))
 (let (($x542 (= ?x541 getX)))
 (or $x542 $x460)))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let ((?x425 (cache.wait dir.hptr)))
 (let (($x428 (= ?x425 get)))
 (or $x428 $x520)))))
(assert
 (let (($x522 (not (net.get home home))))
 (let ((?x541 (cache.wait home)))
 (let (($x545 (= ?x541 get)))
 (or $x545 $x522)))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let ((?x382 (__cache.state_ dir.hptr)))
 (let (($x400 (= ?x382 invalid)))
 (or $x400 $x520)))))
(assert
 (let (($x522 (not (net.get home home))))
 (or (= (__cache.state_ home) invalid) $x522)))
(assert
 (let (($x435 (not (net.getX real_owner home))))
 (or $x435 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x439 (not (net.getX @X home))))
 (or $x439 (not (= (cache.wait @X) none)))))
(assert
 (let (($x443 (not (net.getX @Y home))))
 (or $x443 (not (= (cache.wait @Y) none)))))
(assert
 (let (($x446 (not (net.getX dir.hptr home))))
 (or $x446 (not (= (cache.wait dir.hptr) none)))))
(assert
 (let (($x460 (not (net.getX home home))))
 (or $x460 (not (= (cache.wait home) none)))))
(assert
 (let (($x460 (not (net.getX home home))))
 (let ((?x541 (cache.wait home)))
 (let (($x542 (= ?x541 getX)))
 (or $x542 $x460)))))
(assert
 (let (($x565 (not (= (__cache.state_ home) exclusive))))
 (or $x565 (not (= (cache.wait home) getX)))))
(assert
 (let (($x522 (not (net.get home home))))
 (let ((?x541 (cache.wait home)))
 (let (($x545 (= ?x541 get)))
 (or $x545 $x522)))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x386 (= dir.hptr home)))
 (or $x386 $x145 $x520)))))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (let (($x501 (= real_owner real_owner)))
 (let (($x569 (= real_owner home)))
 (or $x569 $x501 $x518)))))
(assert
 (let (($x522 (not (net.get home home))))
 (let (($x461 (= home real_owner)))
 (let (($x423 (= home home)))
 (or $x423 $x461 $x522)))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (let (($x386 (= dir.hptr home)))
 (or $x386 $x520 dir.dirty))))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (let (($x569 (= real_owner home)))
 (or $x569 $x518 dir.head))))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (let (($x569 (= real_owner home)))
 (or $x569 $x518 dir.dirty))))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (let (($x569 (= real_owner home)))
 (or $x569 $x518))))
(assert
 (let (($x522 (not (net.get home home))))
 (let (($x423 (= home home)))
 (or $x423 $x522 dir.head))))
(assert
 (let (($x522 (not (net.get home home))))
 (let (($x423 (= home home)))
 (or $x423 $x522 dir.dirty))))
(assert
 (let (($x565 (not (= (__cache.state_ home) exclusive))))
 (let (($x461 (= home real_owner)))
 (or $x461 $x565))))
(assert
 (let (($x565 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x565)))
(assert
 (let (($x582 (not (= (__cache.state_ home) shared))))
 (let (($x461 (= home real_owner)))
 (or $x461 $x582))))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (let (($x569 (= real_owner home)))
 (or $x569 $x518))))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (let (($x506 (= real_owner dir.hptr)))
 (or $x506 $x518))))
(assert
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (or $x520 dir.head)))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (or $x518 dir.head)))
(assert
 (let (($x518 (not (net.putX real_owner dir.hptr))))
 (or $x518 dir.dirty)))
(assert
 (let (($x457 (not (rp_net dir.hptr))))
 (let (($x520 (not (net.put dir.hptr dir.hptr))))
 (or $x520 $x457))))
(assert
 (let (($x582 (not (= (__cache.state_ home) shared))))
 (or $x582 (not (= (cache.wait home) get)))))
(assert
 (let (($x565 (not (= (__cache.state_ home) exclusive))))
 (or $x565 dir.head)))
(check-sat)
