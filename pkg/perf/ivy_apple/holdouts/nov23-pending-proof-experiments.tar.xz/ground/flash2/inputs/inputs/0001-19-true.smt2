(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun home () id)
(declare-fun real_owner () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun dir.head () Bool)
(declare-fun wbnet.wb () Bool)
(declare-fun nakc () Bool)
(assert
 (not dir.pending))
(assert
 (not dir.dirty))
(assert
 (not dir.head))
(assert
 (not wbnet.wb))
(assert
 (= real_owner home))
(assert
 (not nakc))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (= (cache.wait @X) none))
(assert
 (= (cache.wait @Y) none))
(assert
 (let ((?x62 (cache.state_ @X)))
 (= ?x62 invalid)))
(assert
 (let ((?x68 (cache.state_ @Y)))
 (= ?x68 invalid)))
(check-sat)
