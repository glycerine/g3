(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun __dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun __real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun __dst () id)
(declare-fun dir.hptr () id)
(declare-fun real_owner () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun __dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun __dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun __dir.local_ () Bool)
(declare-fun dir.local_ () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun dir.head () Bool)
(declare-fun dir.pending () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun __net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun __dir.real (id) Bool)
(declare-fun __invnet (id) Bool)
(assert
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 (not __dir.head))))
(assert
 (let ((?x140 (cache.wait __real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x144 (not __dir.dirty)))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x144 __dir.pending))))
(assert
 (not (net.fack requester home)))
(assert
 (__net.getX __src home))
(assert
 (not (= home __src)))
(assert
 (not __dir.pending))
(assert
 (not __dir.dirty))
(assert
 (not __dir.local_))
(assert
 __dir.head)
(assert
 (or (not (= __src __dir.hptr)) (and (__dir.shlist __dst) (not (= __dst __src)))))
(assert
 (not dir.local_))
(assert
 dir.dirty)
(assert
 dir.head)
(assert
 (= dir.hptr __src))
(assert
 dir.pending)
(assert
 (= real_owner __src))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x334 (cache.state_ @X)))
 (= ?x334 (ite (and (= @X home)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x339 (cache.state_ @Y)))
 (= ?x339 (ite (and (= @Y home)) invalid (__cache.state_ @Y)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x376))))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (let (($x374 (= home home)))
 (or $x374 $x376 __dir.head)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (let (($x374 (= home home)))
 (or $x374 $x376 __dir.dirty)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (let (($x374 (= home home)))
 (or $x374 $x376)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (let (($x374 (= home home)))
 (let (($x381 (= __src requester)))
 (or $x381 $x374 $x376))))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester __real_owner) $x187)))
(assert
 (let (($x387 (not (= (__cache.state_ @X) exclusive))))
 (let (($x385 (= @X __real_owner)))
 (or $x385 $x387))))
(assert
 (let (($x391 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x389 (= @Y __real_owner)))
 (or $x389 $x391))))
(assert
 (let (($x387 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X __dir.hptr) $x387)))
(assert
 (let (($x391 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y __dir.hptr) $x391)))
(assert
 (let (($x398 (not (= (__cache.state_ @X) shared))))
 (let (($x385 (= @X __real_owner)))
 (or $x385 $x398))))
(assert
 (let (($x401 (not (= (__cache.state_ @Y) shared))))
 (let (($x389 (= @Y __real_owner)))
 (or $x389 $x401))))
(assert
 (let (($x398 (not (= (__cache.state_ @X) shared))))
 (let (($x404 (not (rp_net @X))))
 (or $x404 $x398))))
(assert
 (let (($x401 (not (= (__cache.state_ @Y) shared))))
 (let (($x407 (not (rp_net @Y))))
 (or $x407 $x401))))
(assert
 (let (($x398 (not (= (__cache.state_ @X) shared))))
 (let (($x410 (not (invack @X))))
 (or $x410 $x398))))
(assert
 (let (($x401 (not (= (__cache.state_ @Y) shared))))
 (let (($x413 (not (invack @Y))))
 (or $x413 $x401))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x416))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x419))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x422))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x425))))
(assert
 (let (($x429 (not (net.get __dir.hptr home))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (let (($x427 (not $x58)))
 (or $x427 $x429)))))
(assert
 (let (($x433 (not (net.get __dst home))))
 (let (($x280 (__dir.shlist __dst)))
 (let (($x431 (not $x280)))
 (or $x431 $x433)))))
(assert
 (let (($x58 (__dir.shlist __dir.hptr)))
 (let (($x427 (not $x58)))
 (or $x427 __dir.head))))
(assert
 (let (($x280 (__dir.shlist __dst)))
 (let (($x431 (not $x280)))
 (or $x431 __dir.head))))
(assert
 (let (($x387 (not (= (__cache.state_ @X) exclusive))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x387))))
(assert
 (let (($x391 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x391))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let (($x441 (= __dir.hptr home)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x441 $x422)))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let (($x443 (= __dst home)))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x443 $x425)))))
(assert
 (let (($x387 (not (= (__cache.state_ @X) exclusive))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 (= @X requester) $x387))))
(assert
 (let (($x391 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 (= @Y requester) $x391))))
(assert
 (let ((?x366 (__cache.state_ @X)))
 (let (($x450 (= ?x366 invalid)))
 (let (($x385 (= @X __real_owner)))
 (or (__dir.real @X) $x385 $x450)))))
(assert
 (let ((?x371 (__cache.state_ @Y)))
 (let (($x453 (= ?x371 invalid)))
 (let (($x389 (= @Y __real_owner)))
 (or (__dir.real @Y) $x389 $x453)))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x416))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x419))))
(assert
 (let (($x398 (not (= (__cache.state_ @X) shared))))
 (or $x398 (not (= (cache.wait @X) get)))))
(assert
 (let (($x401 (not (= (__cache.state_ @Y) shared))))
 (or $x401 (not (= (cache.wait @Y) get)))))
(assert
 (let (($x410 (not (invack @X))))
 (let ((?x366 (__cache.state_ @X)))
 (let (($x450 (= ?x366 invalid)))
 (or $x450 $x410)))))
(assert
 (let (($x413 (not (invack @Y))))
 (let ((?x371 (__cache.state_ @Y)))
 (let (($x453 (= ?x371 invalid)))
 (or $x453 $x413)))))
(assert
 (let (($x387 (not (= (__cache.state_ @X) exclusive))))
 (or $x387 __dir.head)))
(assert
 (let (($x391 (not (= (__cache.state_ @Y) exclusive))))
 (or $x391 __dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x374 (= home home)))
 (or $x374 $x187))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x469 (= ?x468 getX)))
 (or $x469 $x416)))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x472 (= ?x471 getX)))
 (or $x472 $x419)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (let ((?x474 (cache.wait __src)))
 (let (($x475 (= ?x474 getX)))
 (or $x475 $x376))))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x477 (= ?x468 get)))
 (or $x477 $x422)))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x479 (= ?x471 get)))
 (or $x479 $x425)))))
(assert
 (let (($x429 (not (net.get __dir.hptr home))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x477 (= ?x468 get)))
 (or $x477 $x429)))))
(assert
 (let (($x433 (not (net.get __dst home))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x479 (= ?x471 get)))
 (or $x479 $x433)))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let ((?x483 (__cache.state_ __dir.hptr)))
 (let (($x484 (= ?x483 invalid)))
 (or $x484 $x422)))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let ((?x486 (__cache.state_ __dst)))
 (let (($x487 (= ?x486 invalid)))
 (or $x487 $x425)))))
(assert
 (let (($x429 (not (net.get __dir.hptr home))))
 (let ((?x483 (__cache.state_ __dir.hptr)))
 (let (($x484 (= ?x483 invalid)))
 (or $x484 $x429)))))
(assert
 (let (($x433 (not (net.get __dst home))))
 (let ((?x486 (__cache.state_ __dst)))
 (let (($x487 (= ?x486 invalid)))
 (or $x487 $x433)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (or $x376 (not (= (cache.wait __src) none))))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x469 (= ?x468 getX)))
 (or $x469 $x416)))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x472 (= ?x471 getX)))
 (or $x472 $x419)))))
(assert
 (let (($x271 (__net.getX __src home)))
 (let (($x376 (not $x271)))
 (let ((?x474 (cache.wait __src)))
 (let (($x475 (= ?x474 getX)))
 (or $x475 $x376))))))
(assert
 (let (($x387 (not (= (__cache.state_ @X) exclusive))))
 (or $x387 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x391 (not (= (__cache.state_ @Y) exclusive))))
 (or $x391 (not (= (cache.wait @Y) getX)))))
(assert
 (let (($x501 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (or $x501 (not (= (cache.wait __dir.hptr) getX)))))
(assert
 (let (($x505 (not (= (__cache.state_ __dst) exclusive))))
 (or $x505 (not (= (cache.wait __dst) getX)))))
(assert
 (let (($x404 (not (rp_net @X))))
 (let (($x509 (not (net.put home @X))))
 (or $x509 $x404))))
(assert
 (let (($x407 (not (rp_net @Y))))
 (let (($x512 (not (net.put home @Y))))
 (or $x512 $x407))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x477 (= ?x468 get)))
 (or $x477 $x422)))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x479 (= ?x471 get)))
 (or $x479 $x425)))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x457 (= ?x336 get)))
 (or $x457 $x509)))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let ((?x341 (cache.wait @Y)))
 (let (($x460 (= ?x341 get)))
 (or $x460 $x512)))))
(assert
 (let (($x429 (not (net.get __dir.hptr home))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x477 (= ?x468 get)))
 (or $x477 $x429)))))
(assert
 (let (($x433 (not (net.get __dst home))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x479 (= ?x471 get)))
 (or $x479 $x433)))))
(assert
 (not (__net.getX home home)))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x422)))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x425)))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x509)))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x512)))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x416)))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x419)))))
(assert
 (let (($x429 (not (net.get __dir.hptr home))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x429)))))
(assert
 (let (($x433 (not (net.get __dst home))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x433)))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x517)))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let (($x374 (= home home)))
 (or $x374 $x422 __dir.dirty))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let (($x374 (= home home)))
 (or $x374 $x425 __dir.dirty))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let (($x374 (= home home)))
 (or $x374 $x509 __dir.dirty))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let (($x374 (= home home)))
 (or $x374 $x512 __dir.dirty))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x374 (= home home)))
 (or $x374 $x416 __dir.head))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x374 (= home home)))
 (or $x374 $x419 __dir.head))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x374 (= home home)))
 (or $x374 $x416 __dir.dirty))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x374 (= home home)))
 (or $x374 $x419 __dir.dirty))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x374 (= home home)))
 (or $x374 $x416))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x374 (= home home)))
 (or $x374 $x419))))
(assert
 (let (($x429 (not (net.get __dir.hptr home))))
 (let (($x374 (= home home)))
 (or $x374 $x429 __dir.head))))
(assert
 (let (($x433 (not (net.get __dst home))))
 (let (($x374 (= home home)))
 (or $x374 $x433 __dir.head))))
(assert
 (let (($x429 (not (net.get __dir.hptr home))))
 (let (($x374 (= home home)))
 (or $x374 $x429 __dir.dirty))))
(assert
 (let (($x433 (not (net.get __dst home))))
 (let (($x374 (= home home)))
 (or $x374 $x433 __dir.dirty))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (let (($x374 (= home home)))
 (or $x374 $x517 __dir.head))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (let (($x374 (= home home)))
 (or $x374 $x517 __dir.dirty))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (let (($x374 (= home home)))
 (or $x374 $x517))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (let (($x374 (= home home)))
 (let (($x544 (= home requester)))
 (or $x544 $x374 $x517)))))
(assert
 (let (($x501 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x501))))
(assert
 (let (($x505 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x547 (= __dst __real_owner)))
 (or $x547 $x505))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x549 (= __dir.hptr __dir.hptr)))
 (or $x549 $x416))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x551 (= __dst __dir.hptr)))
 (or $x551 $x419))))
(assert
 (let (($x501 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x549 (= __dir.hptr __dir.hptr)))
 (or $x549 $x501))))
(assert
 (let (($x505 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x551 (= __dst __dir.hptr)))
 (or $x551 $x505))))
(assert
 (let (($x556 (not (= (__cache.state_ __dir.hptr) shared))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (or $x145 $x556))))
(assert
 (let (($x559 (not (= (__cache.state_ __dst) shared))))
 (let (($x547 (= __dst __real_owner)))
 (or $x547 $x559))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x374 (= home home)))
 (or $x374 $x416))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x374 (= home home)))
 (or $x374 $x419))))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (let (($x561 (= __real_owner __dir.hptr)))
 (or $x561 $x416))))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (let (($x563 (= __real_owner __dst)))
 (or $x563 $x419))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (or $x422 __dir.head)))
(assert
 (let (($x425 (not (net.put home __dst))))
 (or $x425 __dir.head)))
(assert
 (let (($x509 (not (net.put home @X))))
 (or $x509 __dir.head)))
(assert
 (let (($x512 (not (net.put home @Y))))
 (or $x512 __dir.head)))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (or $x416 __dir.head)))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (or $x419 __dir.head)))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (or $x416 __dir.dirty)))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (or $x419 __dir.dirty)))
(assert
 (not (__net.putX __real_owner __dir.hptr)))
(assert
 (not (__net.putX __real_owner __dst)))
(assert
 (let (($x416 (not (__net.putX home __dir.hptr))))
 (or $x416 __dir.head)))
(assert
 (let (($x419 (not (__net.putX home __dst))))
 (or $x419 __dir.head)))
(assert
 (not (__net.putX home __dir.hptr)))
(assert
 (not (__net.putX home __dst)))
(assert
 (let (($x578 (not (rp_net __dir.hptr))))
 (let (($x422 (not (net.put home __dir.hptr))))
 (or $x422 $x578))))
(assert
 (let (($x581 (not (rp_net __dst))))
 (let (($x425 (not (net.put home __dst))))
 (or $x425 $x581))))
(assert
 (let (($x404 (not (rp_net @X))))
 (let (($x509 (not (net.put home @X))))
 (or $x509 $x404))))
(assert
 (let (($x407 (not (rp_net @Y))))
 (let (($x512 (not (net.put home @Y))))
 (or $x512 $x407))))
(assert
 (not (net.put home __dir.hptr)))
(assert
 (not (net.put home __dst)))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @Y)))
(assert
 (not (net.put __dir.hptr __dir.hptr)))
(assert
 (not (net.put __dir.hptr __dst)))
(assert
 (not (net.put __dir.hptr @X)))
(assert
 (not (net.put __dir.hptr @Y)))
(assert
 (not (net.get home home)))
(assert
 (let (($x410 (not (invack @X))))
 (or $x410 (not (__invnet @X)))))
(assert
 (let (($x413 (not (invack @Y))))
 (or $x413 (not (__invnet @Y)))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x422 __dir.pending))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x425 __dir.pending))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x509 __dir.pending))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x512 __dir.pending))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x584 __dir.pending))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x586 __dir.pending))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x588 __dir.pending))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x590 __dir.pending))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x422 __dir.dirty))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x425 __dir.dirty))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x509 __dir.dirty))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x512 __dir.dirty))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x584 __dir.dirty))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x586 __dir.dirty))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x588 __dir.dirty))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x590 __dir.dirty))))
(assert
 (let (($x422 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x422))))
(assert
 (let (($x425 (not (net.put home __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x425))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x509))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x512))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x584))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x586))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x588))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x590))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x509))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x512))))
(assert
 (let (($x592 (not (net.get home home))))
 (let (($x621 (__dir.shlist home)))
 (let (($x622 (not $x621)))
 (or $x622 $x592)))))
(assert
 (or (not (__dir.shlist @X)) __dir.head))
(assert
 (or (not (__dir.shlist @Y)) __dir.head))
(assert
 (let (($x621 (__dir.shlist home)))
 (let (($x622 (not $x621)))
 (or $x622 __dir.head))))
(assert
 (let (($x501 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x501))))
(assert
 (let (($x505 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x505))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let (($x364 (= @X home)))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x364 $x509)))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let (($x369 (= @Y home)))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x369 $x512)))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x441 (= __dir.hptr home)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x441 $x584)))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let (($x443 (= __dst home)))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 $x443 $x586)))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let (($x364 (= @X home)))
 (let (($x437 (__dir.shlist @X)))
 (or $x437 $x364 $x588)))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let (($x369 (= @Y home)))
 (let (($x439 (__dir.shlist @Y)))
 (or $x439 $x369 $x590)))))
(assert
 (let (($x501 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 (= __dir.hptr requester) $x501))))
(assert
 (let (($x505 (not (= (__cache.state_ __dst) exclusive))))
 (let (($x280 (__dir.shlist __dst)))
 (or $x280 (= __dst requester) $x505))))
(assert
 (let (($x556 (not (= (__cache.state_ __dir.hptr) shared))))
 (or $x556 (not (= (cache.wait __dir.hptr) get)))))
(assert
 (let (($x559 (not (= (__cache.state_ __dst) shared))))
 (or $x559 (not (= (cache.wait __dst) get)))))
(assert
 (let (($x501 (not (= (__cache.state_ __dir.hptr) exclusive))))
 (or $x501 __dir.head)))
(assert
 (let (($x505 (not (= (__cache.state_ __dst) exclusive))))
 (or $x505 __dir.head)))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x469 (= ?x468 getX)))
 (or $x469 $x574)))))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x472 (= ?x471 getX)))
 (or $x472 $x576)))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (let ((?x300 (cache.wait home)))
 (let (($x649 (= ?x300 getX)))
 (or $x649 $x517)))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x457 (= ?x336 get)))
 (or $x457 $x509)))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let ((?x341 (cache.wait @Y)))
 (let (($x460 (= ?x341 get)))
 (or $x460 $x512)))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let ((?x468 (cache.wait __dir.hptr)))
 (let (($x477 (= ?x468 get)))
 (or $x477 $x584)))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let ((?x471 (cache.wait __dst)))
 (let (($x479 (= ?x471 get)))
 (or $x479 $x586)))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let ((?x336 (cache.wait @X)))
 (let (($x457 (= ?x336 get)))
 (or $x457 $x588)))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let ((?x341 (cache.wait @Y)))
 (let (($x460 (= ?x341 get)))
 (or $x460 $x590)))))
(assert
 (let (($x592 (not (net.get home home))))
 (let ((?x300 (cache.wait home)))
 (let (($x301 (= ?x300 get)))
 (or $x301 $x592)))))
(assert
 (let (($x509 (not (net.put home @X))))
 (let ((?x366 (__cache.state_ @X)))
 (let (($x450 (= ?x366 invalid)))
 (or $x450 $x509)))))
(assert
 (let (($x512 (not (net.put home @Y))))
 (let ((?x371 (__cache.state_ @Y)))
 (let (($x453 (= ?x371 invalid)))
 (or $x453 $x512)))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let ((?x483 (__cache.state_ __dir.hptr)))
 (let (($x484 (= ?x483 invalid)))
 (or $x484 $x584)))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let ((?x486 (__cache.state_ __dst)))
 (let (($x487 (= ?x486 invalid)))
 (or $x487 $x586)))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let ((?x366 (__cache.state_ @X)))
 (let (($x450 (= ?x366 invalid)))
 (or $x450 $x588)))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let ((?x371 (__cache.state_ @Y)))
 (let (($x453 (= ?x371 invalid)))
 (or $x453 $x590)))))
(assert
 (let (($x592 (not (net.get home home))))
 (let ((?x662 (__cache.state_ home)))
 (let (($x663 (= ?x662 invalid)))
 (or $x663 $x592)))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (or $x517 (not (= (cache.wait home) none)))))
(assert
 (let (($x517 (not (__net.getX home home))))
 (let ((?x300 (cache.wait home)))
 (let (($x649 (= ?x300 getX)))
 (or $x649 $x517)))))
(assert
 (let (($x669 (not (= (__cache.state_ home) exclusive))))
 (or $x669 (not (= (cache.wait home) getX)))))
(assert
 (let (($x578 (not (rp_net __dir.hptr))))
 (let (($x422 (not (net.put home __dir.hptr))))
 (or $x422 $x578))))
(assert
 (let (($x581 (not (rp_net __dst))))
 (let (($x425 (not (net.put home __dst))))
 (or $x425 $x581))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let ((?x140 (cache.wait __real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x673)))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let ((?x474 (cache.wait __src)))
 (let (($x675 (= ?x474 get)))
 (or $x675 $x677)))))
(assert
 (let (($x680 (not (net.put home home))))
 (let ((?x300 (cache.wait home)))
 (let (($x301 (= ?x300 get)))
 (or $x301 $x680)))))
(assert
 (let (($x592 (not (net.get home home))))
 (let ((?x300 (cache.wait home)))
 (let (($x301 (= ?x300 get)))
 (or $x301 $x592)))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x145 $x584)))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x145 $x586)))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x145 $x588)))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x145 $x590)))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x673)))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x677)))))
(assert
 (let (($x680 (not (net.put home home))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x680)))))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x690 (= __real_owner __real_owner)))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x690 $x574)))))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (let (($x690 (= __real_owner __real_owner)))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x690 $x576)))))
(assert
 (let (($x592 (not (net.get home home))))
 (let (($x375 (= home __real_owner)))
 (let (($x374 (= home home)))
 (or $x374 $x375 $x592)))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x584 __dir.dirty))))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x586 __dir.dirty))))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x588 __dir.dirty))))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x590 __dir.dirty))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let (($x374 (= home home)))
 (or $x374 $x673 __dir.dirty))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let (($x374 (= home home)))
 (or $x374 $x677 __dir.dirty))))
(assert
 (let (($x680 (not (net.put home home))))
 (let (($x374 (= home home)))
 (or $x374 $x680 __dir.dirty))))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x574 __dir.head))))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x576 __dir.head))))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x574 __dir.dirty))))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x576 __dir.dirty))))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x574))))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x576))))
(assert
 (let (($x592 (not (net.get home home))))
 (let (($x374 (= home home)))
 (or $x374 $x592 __dir.head))))
(assert
 (let (($x592 (not (net.get home home))))
 (let (($x374 (= home home)))
 (or $x374 $x592 __dir.dirty))))
(assert
 (let (($x669 (not (= (__cache.state_ home) exclusive))))
 (let (($x375 (= home __real_owner)))
 (or $x375 $x669))))
(assert
 (let (($x669 (not (= (__cache.state_ home) exclusive))))
 (or (= home __dir.hptr) $x669)))
(assert
 (let (($x713 (not (= (__cache.state_ home) shared))))
 (let (($x375 (= home __real_owner)))
 (or $x375 $x713))))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x574))))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (let (($x689 (= __real_owner home)))
 (or $x689 $x576))))
(assert
 (let (($x556 (not (= (__cache.state_ __dir.hptr) shared))))
 (let (($x578 (not (rp_net __dir.hptr))))
 (or $x578 $x556))))
(assert
 (let (($x559 (not (= (__cache.state_ __dst) shared))))
 (let (($x581 (not (rp_net __dst))))
 (or $x581 $x559))))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (let (($x561 (= __real_owner __dir.hptr)))
 (or $x561 $x574))))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (let (($x563 (= __real_owner __dst)))
 (or $x563 $x576))))
(assert
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (or $x584 __dir.head)))
(assert
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (or $x586 __dir.head)))
(assert
 (let (($x588 (not (net.put __dir.hptr @X))))
 (or $x588 __dir.head)))
(assert
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (or $x590 __dir.head)))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (or $x673 __dir.head)))
(assert
 (let (($x677 (not (net.put home __src))))
 (or $x677 __dir.head)))
(assert
 (let (($x680 (not (net.put home home))))
 (or $x680 __dir.head)))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (or $x574 __dir.head)))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (or $x576 __dir.head)))
(assert
 (let (($x574 (not (__net.putX __real_owner __dir.hptr))))
 (or $x574 __dir.dirty)))
(assert
 (let (($x576 (not (__net.putX __real_owner __dst))))
 (or $x576 __dir.dirty)))
(assert
 (let (($x578 (not (rp_net __dir.hptr))))
 (let (($x584 (not (net.put __dir.hptr __dir.hptr))))
 (or $x584 $x578))))
(assert
 (let (($x581 (not (rp_net __dst))))
 (let (($x586 (not (net.put __dir.hptr __dst))))
 (or $x586 $x581))))
(assert
 (let (($x404 (not (rp_net @X))))
 (let (($x588 (not (net.put __dir.hptr @X))))
 (or $x588 $x404))))
(assert
 (let (($x407 (not (rp_net @Y))))
 (let (($x590 (not (net.put __dir.hptr @Y))))
 (or $x590 $x407))))
(assert
 (let (($x735 (not (rp_net __real_owner))))
 (let (($x673 (not (net.put home __real_owner))))
 (or $x673 $x735))))
(assert
 (let (($x738 (not (rp_net __src))))
 (let (($x677 (not (net.put home __src))))
 (or $x677 $x738))))
(assert
 (let (($x741 (not (rp_net home))))
 (let (($x680 (not (net.put home home))))
 (or $x680 $x741))))
(assert
 (not (net.put home __real_owner)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put __dir.hptr __real_owner)))
(assert
 (not (net.put __dir.hptr __src)))
(assert
 (not (net.put __dir.hptr home)))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x673 __dir.pending))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x677 __dir.pending))))
(assert
 (let (($x680 (not (net.put home home))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x680 __dir.pending))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x744 __dir.pending))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x746 __dir.pending))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x748 __dir.pending))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x673 __dir.dirty))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x677 __dir.dirty))))
(assert
 (let (($x680 (not (net.put home home))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x680 __dir.dirty))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x744 __dir.dirty))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x746 __dir.dirty))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x748 __dir.dirty))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x673))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x677))))
(assert
 (let (($x680 (not (net.put home home))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x680))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x744))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x746))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x748))))
(assert
 (let (($x680 (not (net.put home home))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x680))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x673))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x677))))
(assert
 (or (not (__dir.shlist __real_owner)) __dir.head))
(assert
 (or (not (__dir.shlist __src)) __dir.head))
(assert
 (let (($x669 (not (= (__cache.state_ home) exclusive))))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x669))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let (($x689 (= __real_owner home)))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x689 $x673)))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let (($x775 (= __src home)))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x775 $x677)))))
(assert
 (let (($x680 (not (net.put home home))))
 (let (($x374 (= home home)))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x374 $x680)))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let (($x689 (= __real_owner home)))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x689 $x744)))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let (($x775 (= __src home)))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x775 $x746)))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let (($x374 (= home home)))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x374 $x748)))))
(assert
 (let (($x669 (not (= (__cache.state_ home) exclusive))))
 (let (($x544 (= home requester)))
 (let (($x621 (__dir.shlist home)))
 (or $x621 $x544 $x669)))))
(assert
 (let (($x713 (not (= (__cache.state_ home) shared))))
 (or $x713 (not (= (cache.wait home) get)))))
(assert
 (let (($x669 (not (= (__cache.state_ home) exclusive))))
 (or $x669 __dir.head)))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let ((?x140 (cache.wait __real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x673)))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let ((?x474 (cache.wait __src)))
 (let (($x675 (= ?x474 get)))
 (or $x675 $x677)))))
(assert
 (let (($x680 (not (net.put home home))))
 (let ((?x300 (cache.wait home)))
 (let (($x301 (= ?x300 get)))
 (or $x301 $x680)))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let ((?x140 (cache.wait __real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x744)))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let ((?x474 (cache.wait __src)))
 (let (($x675 (= ?x474 get)))
 (or $x675 $x746)))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let ((?x300 (cache.wait home)))
 (let (($x301 (= ?x300 get)))
 (or $x301 $x748)))))
(assert
 (let (($x673 (not (net.put home __real_owner))))
 (let ((?x788 (__cache.state_ __real_owner)))
 (let (($x789 (= ?x788 invalid)))
 (or $x789 $x673)))))
(assert
 (let (($x677 (not (net.put home __src))))
 (let ((?x791 (__cache.state_ __src)))
 (let (($x792 (= ?x791 invalid)))
 (or $x792 $x677)))))
(assert
 (let (($x680 (not (net.put home home))))
 (let ((?x662 (__cache.state_ home)))
 (let (($x663 (= ?x662 invalid)))
 (or $x663 $x680)))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let ((?x788 (__cache.state_ __real_owner)))
 (let (($x789 (= ?x788 invalid)))
 (or $x789 $x744)))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let ((?x791 (__cache.state_ __src)))
 (let (($x792 (= ?x791 invalid)))
 (or $x792 $x746)))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let ((?x662 (__cache.state_ home)))
 (let (($x663 (= ?x662 invalid)))
 (or $x663 $x748)))))
(assert
 (let (($x799 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x799 (not (= (cache.wait __real_owner) getX)))))
(assert
 (let (($x804 (not (= (__cache.state_ __src) exclusive))))
 (or $x804 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x735 (not (rp_net __real_owner))))
 (let (($x673 (not (net.put home __real_owner))))
 (or $x673 $x735))))
(assert
 (let (($x738 (not (rp_net __src))))
 (let (($x677 (not (net.put home __src))))
 (or $x677 $x738))))
(assert
 (let (($x741 (not (rp_net home))))
 (let (($x680 (not (net.put home home))))
 (or $x680 $x741))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x145 $x744)))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x145 $x746)))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let (($x145 (= __dir.hptr __real_owner)))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x145 $x748)))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x744 __dir.dirty))))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x746 __dir.dirty))))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (let (($x441 (= __dir.hptr home)))
 (or $x441 $x748 __dir.dirty))))
(assert
 (let (($x799 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x690 (= __real_owner __real_owner)))
 (or $x690 $x799))))
(assert
 (let (($x804 (not (= (__cache.state_ __src) exclusive))))
 (let (($x814 (= __src __real_owner)))
 (or $x814 $x804))))
(assert
 (let (($x799 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x561 (= __real_owner __dir.hptr)))
 (or $x561 $x799))))
(assert
 (let (($x804 (not (= (__cache.state_ __src) exclusive))))
 (let (($x277 (= __src __dir.hptr)))
 (or $x277 $x804))))
(assert
 (let (($x819 (not (= (__cache.state_ __real_owner) shared))))
 (let (($x690 (= __real_owner __real_owner)))
 (or $x690 $x819))))
(assert
 (let (($x822 (not (= (__cache.state_ __src) shared))))
 (let (($x814 (= __src __real_owner)))
 (or $x814 $x822))))
(assert
 (let (($x713 (not (= (__cache.state_ home) shared))))
 (let (($x741 (not (rp_net home))))
 (or $x741 $x713))))
(assert
 (let (($x819 (not (= (__cache.state_ __real_owner) shared))))
 (let (($x735 (not (rp_net __real_owner))))
 (or $x735 $x819))))
(assert
 (let (($x822 (not (= (__cache.state_ __src) shared))))
 (let (($x738 (not (rp_net __src))))
 (or $x738 $x822))))
(assert
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (or $x744 __dir.head)))
(assert
 (let (($x746 (not (net.put __dir.hptr __src))))
 (or $x746 __dir.head)))
(assert
 (let (($x748 (not (net.put __dir.hptr home))))
 (or $x748 __dir.head)))
(assert
 (let (($x735 (not (rp_net __real_owner))))
 (let (($x744 (not (net.put __dir.hptr __real_owner))))
 (or $x744 $x735))))
(assert
 (let (($x738 (not (rp_net __src))))
 (let (($x746 (not (net.put __dir.hptr __src))))
 (or $x746 $x738))))
(assert
 (let (($x741 (not (rp_net home))))
 (let (($x748 (not (net.put __dir.hptr home))))
 (or $x748 $x741))))
(assert
 (let (($x799 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 $x799))))
(assert
 (let (($x804 (not (= (__cache.state_ __src) exclusive))))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x804))))
(assert
 (let (($x799 (not (= (__cache.state_ __real_owner) exclusive))))
 (let (($x749 (__dir.shlist __real_owner)))
 (or $x749 (= __real_owner requester) $x799))))
(assert
 (let (($x804 (not (= (__cache.state_ __src) exclusive))))
 (let (($x381 (= __src requester)))
 (let (($x751 (__dir.shlist __src)))
 (or $x751 $x381 $x804)))))
(assert
 (let ((?x140 (cache.wait __real_owner)))
 (let (($x141 (= ?x140 get)))
 (let (($x142 (not $x141)))
 (let (($x819 (not (= (__cache.state_ __real_owner) shared))))
 (or $x819 $x142))))))
(assert
 (let (($x822 (not (= (__cache.state_ __src) shared))))
 (or $x822 (not (= (cache.wait __src) get)))))
(assert
 (let (($x799 (not (= (__cache.state_ __real_owner) exclusive))))
 (or $x799 __dir.head)))
(assert
 (let (($x804 (not (= (__cache.state_ __src) exclusive))))
 (or $x804 __dir.head)))
(check-sat)
