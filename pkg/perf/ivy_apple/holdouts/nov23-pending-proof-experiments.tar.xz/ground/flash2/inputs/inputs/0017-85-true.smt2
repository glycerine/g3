(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun __cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.putX (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (__cache.wait real_owner) get)))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__net.putX __src __dst))
(assert
 (not (= __dst home)))
(assert
 (let ((?x275 (__cache.wait __dst)))
 (= ?x275 getX)))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x299 (cache.state_ @X)))
 (= ?x299 (ite (and (= @X __dst)) exclusive (__cache.state_ @X)))))
(assert
 (let ((?x304 (cache.state_ @Y)))
 (= ?x304 (ite (and (= @Y __dst)) exclusive (__cache.state_ @Y)))))
(assert
 (let ((?x301 (cache.wait @X)))
 (= ?x301 (ite (and (= @X __dst)) none (__cache.wait @X)))))
(assert
 (let ((?x306 (cache.wait @Y)))
 (= ?x306 (ite (and (= @Y __dst)) none (__cache.wait @Y)))))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (let (($x345 (= __src home)))
 (or $x345 (= __src real_owner) $x347)))))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (let (($x345 (= __src home)))
 (or $x345 $x347 dir.head)))))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (let (($x345 (= __src home)))
 (or $x345 $x347 dir.dirty)))))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (let (($x345 (= __src home)))
 (or $x345 $x347)))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x356 (not (= (__cache.state_ @X) exclusive))))
 (let (($x354 (= @X real_owner)))
 (or $x354 $x356))))
(assert
 (let (($x360 (not (= (__cache.state_ @Y) exclusive))))
 (let (($x358 (= @Y real_owner)))
 (or $x358 $x360))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (or (= __dst dir.hptr) $x364)))
(assert
 (let (($x356 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x356)))
(assert
 (let (($x360 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x360)))
(assert
 (let (($x371 (not (= (__cache.state_ @X) shared))))
 (let (($x354 (= @X real_owner)))
 (or $x354 $x371))))
(assert
 (let (($x374 (not (= (__cache.state_ @Y) shared))))
 (let (($x358 (= @Y real_owner)))
 (or $x358 $x374))))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (let (($x345 (= __src home)))
 (or $x345 $x347)))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let (($x376 (= home home)))
 (or $x376 $x364))))
(assert
 (let (($x371 (not (= (__cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x371)))
(assert
 (let (($x374 (not (= (__cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x374)))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (let (($x384 (= real_owner __dst)))
 (or $x384 $x347)))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let (($x384 (= real_owner __dst)))
 (or $x384 $x364))))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (or $x347 dir.head))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (or $x364 dir.head)))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (or $x347 dir.dirty))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (or $x364 dir.dirty)))
(assert
 (not (__net.putX real_owner __dst)))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (or $x364 dir.head)))
(assert
 (not (__net.putX home __dst)))
(assert
 (let (($x371 (not (= (__cache.state_ @X) shared))))
 (let (($x394 (not (invack @X))))
 (or $x394 $x371))))
(assert
 (let (($x374 (not (= (__cache.state_ @Y) shared))))
 (let (($x397 (not (invack @Y))))
 (or $x397 $x374))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x400))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x403))))
(assert
 (let (($x407 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x405 (not $x58)))
 (or $x405 $x407)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x405 (not $x58)))
 (or $x405 dir.head))))
(assert
 (let (($x412 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x412))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let (($x414 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x414 $x403)))))
(assert
 (let (($x412 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x416 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x416 $x412)))))
(assert
 (let ((?x331 (__cache.state_ @X)))
 (let (($x419 (= ?x331 invalid)))
 (let (($x354 (= @X real_owner)))
 (or (dir.real @X) $x354 $x419)))))
(assert
 (let ((?x336 (__cache.state_ @Y)))
 (let (($x422 (= ?x336 invalid)))
 (let (($x358 (= @Y real_owner)))
 (or (dir.real @Y) $x358 $x422)))))
(assert
 (let ((?x410 (__cache.state_ dir.hptr)))
 (let (($x425 (= ?x410 invalid)))
 (let (($x145 (= dir.hptr real_owner)))
 (or (dir.real dir.hptr) $x145 $x425)))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x364))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x400))))
(assert
 (let (($x371 (not (= (__cache.state_ @X) shared))))
 (or $x371 (not (= (__cache.wait @X) get)))))
(assert
 (let (($x374 (not (= (__cache.state_ @Y) shared))))
 (or $x374 (not (= (__cache.wait @Y) get)))))
(assert
 (let (($x436 (not (= (__cache.state_ dir.hptr) shared))))
 (or $x436 (not (= (__cache.wait dir.hptr) get)))))
(assert
 (let (($x394 (not (invack @X))))
 (let ((?x331 (__cache.state_ @X)))
 (let (($x419 (= ?x331 invalid)))
 (or $x419 $x394)))))
(assert
 (let (($x397 (not (invack @Y))))
 (let ((?x336 (__cache.state_ @Y)))
 (let (($x422 (= ?x336 invalid)))
 (or $x422 $x397)))))
(assert
 (let (($x356 (not (= (__cache.state_ @X) exclusive))))
 (or $x356 dir.head)))
(assert
 (let (($x360 (not (= (__cache.state_ @Y) exclusive))))
 (or $x360 dir.head)))
(assert
 (let (($x412 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x412 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x376 (= home home)))
 (or $x376 $x187))))
(assert
 (let (($x272 (__net.putX __src __dst)))
 (let (($x347 (not $x272)))
 (let ((?x275 (__cache.wait __dst)))
 (let (($x276 (= ?x275 getX)))
 (or $x276 $x347))))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let ((?x275 (__cache.wait __dst)))
 (let (($x276 (= ?x275 getX)))
 (or $x276 $x364)))))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (let ((?x275 (__cache.wait __dst)))
 (let (($x276 (= ?x275 getX)))
 (or $x276 $x392)))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x450 (= ?x437 getX)))
 (or $x450 $x400)))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x438 (= ?x437 get)))
 (or $x438 $x403)))))
(assert
 (let (($x407 (not (net.get dir.hptr home))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x438 (= ?x437 get)))
 (or $x438 $x407)))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let ((?x410 (__cache.state_ dir.hptr)))
 (let (($x425 (= ?x410 invalid)))
 (or $x425 $x403)))))
(assert
 (let (($x407 (not (net.get dir.hptr home))))
 (let ((?x410 (__cache.state_ dir.hptr)))
 (let (($x425 (= ?x410 invalid)))
 (or $x425 $x407)))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let ((?x275 (__cache.wait __dst)))
 (let (($x276 (= ?x275 getX)))
 (or $x276 $x364)))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x450 (= ?x437 getX)))
 (or $x450 $x400)))))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (or (= (__cache.wait real_owner) getX) $x458)))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (let ((?x275 (__cache.wait __dst)))
 (let (($x276 (= ?x275 getX)))
 (or $x276 $x461)))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (let ((?x339 (__cache.wait @X)))
 (let (($x463 (= ?x339 getX)))
 (or $x463 $x465)))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (let ((?x342 (__cache.wait @Y)))
 (let (($x467 (= ?x342 getX)))
 (or $x467 $x469)))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x450 (= ?x437 getX)))
 (or $x450 $x472)))))
(assert
 (let (($x356 (not (= (__cache.state_ @X) exclusive))))
 (or $x356 (not (= (__cache.wait @X) getX)))))
(assert
 (let (($x360 (not (= (__cache.state_ @Y) exclusive))))
 (or $x360 (not (= (__cache.wait @Y) getX)))))
(assert
 (let (($x412 (not (= (__cache.state_ dir.hptr) exclusive))))
 (or $x412 (not (= (__cache.wait dir.hptr) getX)))))
(assert
 (let (($x481 (not (rp_net dir.hptr))))
 (let (($x403 (not (net.put home dir.hptr))))
 (or $x403 $x481))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x438 (= ?x437 get)))
 (or $x438 $x403)))))
(assert
 (let (($x407 (not (net.get dir.hptr home))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x438 (= ?x437 get)))
 (or $x438 $x407)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x403)))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x364)))))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (let (($x489 (= real_owner real_owner)))
 (let (($x488 (= real_owner home)))
 (or $x488 $x489 $x392)))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x400)))))
(assert
 (let (($x407 (not (net.get dir.hptr home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x407)))))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x458)))))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x461)))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x465)))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x469)))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x472)))))
(assert
 (let (($x484 (not (net.getX home home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x484)))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let (($x376 (= home home)))
 (or $x376 $x403 dir.dirty))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let (($x376 (= home home)))
 (or $x376 $x364 dir.head))))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x392 dir.head))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x376 (= home home)))
 (or $x376 $x400 dir.head))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let (($x376 (= home home)))
 (or $x376 $x364 dir.dirty))))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x392 dir.dirty))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x376 (= home home)))
 (or $x376 $x400 dir.dirty))))
(assert
 (let (($x364 (not (__net.putX home __dst))))
 (let (($x376 (= home home)))
 (or $x376 $x364))))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x392))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x376 (= home home)))
 (or $x376 $x400))))
(assert
 (let (($x407 (not (net.get dir.hptr home))))
 (let (($x376 (= home home)))
 (or $x376 $x407 dir.head))))
(assert
 (let (($x407 (not (net.get dir.hptr home))))
 (let (($x376 (= home home)))
 (or $x376 $x407 dir.dirty))))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (let (($x376 (= home home)))
 (or $x376 $x458 dir.head))))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (let (($x376 (= home home)))
 (or $x376 $x461 dir.head))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (let (($x376 (= home home)))
 (or $x376 $x465 dir.head))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (let (($x376 (= home home)))
 (or $x376 $x469 dir.head))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (let (($x376 (= home home)))
 (or $x376 $x472 dir.head))))
(assert
 (let (($x484 (not (net.getX home home))))
 (let (($x376 (= home home)))
 (or $x376 $x484 dir.head))))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (let (($x376 (= home home)))
 (or $x376 $x458 dir.dirty))))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (let (($x376 (= home home)))
 (or $x376 $x461 dir.dirty))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (let (($x376 (= home home)))
 (or $x376 $x465 dir.dirty))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (let (($x376 (= home home)))
 (or $x376 $x469 dir.dirty))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (let (($x376 (= home home)))
 (or $x376 $x472 dir.dirty))))
(assert
 (let (($x484 (not (net.getX home home))))
 (let (($x376 (= home home)))
 (or $x376 $x484 dir.dirty))))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (let (($x376 (= home home)))
 (or $x376 $x458))))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (let (($x376 (= home home)))
 (or $x376 $x461))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (let (($x376 (= home home)))
 (or $x376 $x465))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (let (($x376 (= home home)))
 (or $x376 $x469))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (let (($x376 (= home home)))
 (or $x376 $x472))))
(assert
 (let (($x484 (not (net.getX home home))))
 (let (($x376 (= home home)))
 (or $x376 $x484))))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (let (($x376 (= home home)))
 (or (= real_owner requester) $x376 $x458))))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (let (($x376 (= home home)))
 (or (= __dst requester) $x376 $x461))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (let (($x376 (= home home)))
 (or (= @X requester) $x376 $x465))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (let (($x376 (= home home)))
 (or (= @Y requester) $x376 $x469))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (let (($x376 (= home home)))
 (let (($x416 (= dir.hptr requester)))
 (or $x416 $x376 $x472)))))
(assert
 (let (($x484 (not (net.getX home home))))
 (let (($x376 (= home home)))
 (or (= home requester) $x376 $x484))))
(assert
 (let (($x412 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x412))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x540 (= dir.hptr dir.hptr)))
 (or $x540 $x400))))
(assert
 (let (($x412 (not (= (__cache.state_ dir.hptr) exclusive))))
 (let (($x540 (= dir.hptr dir.hptr)))
 (or $x540 $x412))))
(assert
 (let (($x436 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x436))))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x392))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x376 (= home home)))
 (or $x376 $x400))))
(assert
 (let (($x436 (not (= (__cache.state_ dir.hptr) shared))))
 (let (($x481 (not (rp_net dir.hptr))))
 (or $x481 $x436))))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (let (($x384 (= real_owner __dst)))
 (or $x384 $x392))))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (let (($x546 (= real_owner dir.hptr)))
 (or $x546 $x400))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (or $x403 dir.head)))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (or $x392 dir.head)))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (or $x400 dir.head)))
(assert
 (let (($x392 (not (__net.putX real_owner __dst))))
 (or $x392 dir.dirty)))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (or $x400 dir.dirty)))
(assert
 (not (__net.putX real_owner dir.hptr)))
(assert
 (let (($x400 (not (__net.putX home dir.hptr))))
 (or $x400 dir.head)))
(assert
 (not (__net.putX home dir.hptr)))
(assert
 (let (($x481 (not (rp_net dir.hptr))))
 (let (($x403 (not (net.put home dir.hptr))))
 (or $x403 $x481))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.get home home)))
(assert
 (let (($x394 (not (invack @X))))
 (or $x394 (not (invnet @X)))))
(assert
 (let (($x397 (not (invack @Y))))
 (or $x397 (not (invnet @Y)))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x403 dir.pending))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x556 dir.pending))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x403 dir.dirty))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x556 dir.dirty))))
(assert
 (let (($x403 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x403))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x556))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let (($x414 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x414 $x556)))))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x450 (= ?x437 getX)))
 (or $x450 $x554)))))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (or (= (__cache.wait real_owner) getX) $x458)))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (let ((?x275 (__cache.wait __dst)))
 (let (($x276 (= ?x275 getX)))
 (or $x276 $x461)))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (let ((?x339 (__cache.wait @X)))
 (let (($x463 (= ?x339 getX)))
 (or $x463 $x465)))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (let ((?x342 (__cache.wait @Y)))
 (let (($x467 (= ?x342 getX)))
 (or $x467 $x469)))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x450 (= ?x437 getX)))
 (or $x450 $x472)))))
(assert
 (let (($x484 (not (net.getX home home))))
 (let ((?x572 (__cache.wait home)))
 (let (($x573 (= ?x572 getX)))
 (or $x573 $x484)))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let ((?x437 (__cache.wait dir.hptr)))
 (let (($x438 (= ?x437 get)))
 (or $x438 $x556)))))
(assert
 (let (($x558 (not (net.get home home))))
 (let ((?x572 (__cache.wait home)))
 (let (($x576 (= ?x572 get)))
 (or $x576 $x558)))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let ((?x410 (__cache.state_ dir.hptr)))
 (let (($x425 (= ?x410 invalid)))
 (or $x425 $x556)))))
(assert
 (let (($x558 (not (net.get home home))))
 (or (= (__cache.state_ home) invalid) $x558)))
(assert
 (let (($x458 (not (net.getX real_owner home))))
 (or $x458 (not (= (__cache.wait real_owner) none)))))
(assert
 (let (($x461 (not (net.getX __dst home))))
 (or $x461 (not (= (__cache.wait __dst) none)))))
(assert
 (let (($x465 (not (net.getX @X home))))
 (or $x465 (not (= (__cache.wait @X) none)))))
(assert
 (let (($x469 (not (net.getX @Y home))))
 (or $x469 (not (= (__cache.wait @Y) none)))))
(assert
 (let (($x472 (not (net.getX dir.hptr home))))
 (or $x472 (not (= (__cache.wait dir.hptr) none)))))
(assert
 (let (($x484 (not (net.getX home home))))
 (or $x484 (not (= (__cache.wait home) none)))))
(assert
 (let (($x484 (not (net.getX home home))))
 (let ((?x572 (__cache.wait home)))
 (let (($x573 (= ?x572 getX)))
 (or $x573 $x484)))))
(assert
 (let (($x601 (not (= (__cache.state_ home) exclusive))))
 (or $x601 (not (= (__cache.wait home) getX)))))
(assert
 (let (($x558 (not (net.get home home))))
 (let ((?x572 (__cache.wait home)))
 (let (($x576 (= ?x572 get)))
 (or $x576 $x558)))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x414 (= dir.hptr home)))
 (or $x414 $x145 $x556)))))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (let (($x489 (= real_owner real_owner)))
 (let (($x488 (= real_owner home)))
 (or $x488 $x489 $x554)))))
(assert
 (let (($x558 (not (net.get home home))))
 (let (($x485 (= home real_owner)))
 (let (($x376 (= home home)))
 (or $x376 $x485 $x558)))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (let (($x414 (= dir.hptr home)))
 (or $x414 $x556 dir.dirty))))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x554 dir.head))))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x554 dir.dirty))))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x554))))
(assert
 (let (($x558 (not (net.get home home))))
 (let (($x376 (= home home)))
 (or $x376 $x558 dir.head))))
(assert
 (let (($x558 (not (net.get home home))))
 (let (($x376 (= home home)))
 (or $x376 $x558 dir.dirty))))
(assert
 (let (($x601 (not (= (__cache.state_ home) exclusive))))
 (let (($x485 (= home real_owner)))
 (or $x485 $x601))))
(assert
 (let (($x601 (not (= (__cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x601)))
(assert
 (let (($x617 (not (= (__cache.state_ home) shared))))
 (let (($x485 (= home real_owner)))
 (or $x485 $x617))))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (let (($x488 (= real_owner home)))
 (or $x488 $x554))))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (let (($x546 (= real_owner dir.hptr)))
 (or $x546 $x554))))
(assert
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (or $x556 dir.head)))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (or $x554 dir.head)))
(assert
 (let (($x554 (not (__net.putX real_owner dir.hptr))))
 (or $x554 dir.dirty)))
(assert
 (let (($x481 (not (rp_net dir.hptr))))
 (let (($x556 (not (net.put dir.hptr dir.hptr))))
 (or $x556 $x481))))
(assert
 (let (($x617 (not (= (__cache.state_ home) shared))))
 (or $x617 (not (= (__cache.wait home) get)))))
(assert
 (let (($x601 (not (= (__cache.state_ home) exclusive))))
 (or $x601 dir.head)))
(check-sat)
