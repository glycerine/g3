(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun __dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __src () id)
(declare-fun dir.hptr () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun __net.fack (id id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x56 (not dir.head)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x56))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 (not dir.dirty) __dir.pending)))
(assert
 (not (__net.fack requester home)))
(assert
 (__net.fack __src home))
(assert
 (not dir.pending))
(assert
 (= dir.hptr (ite __ts0_a __src __dir.hptr)))
(assert
 (= __ts0_a dir.dirty))
(assert
 (let (($x337 (not (= (cache.state_ @X) exclusive))))
 (let (($x377 (not (net.getX home @Y))))
 (let (($x356 (not (net.getX @X @Z))))
 (let (($x364 (not (net.getX @X @Y))))
 (let (($x365 (= @Y @Z)))
 (let (($x378 (and (or $x365 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x365 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x365 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x365 $x364 $x356) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x356 (not (net.putX @Y @X))) $x377 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x337 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x378)))))))))
(assert
 (let (($x350 (dir.shlist dir.hptr)))
 (= $x350 (ite __ts0_a (= dir.hptr __src) (__dir.shlist dir.hptr)))))
(assert
 (let (($x405 (__net.fack @V0 @V1)))
 (let (($x293 (net.fack @V0 @V1)))
 (= $x293 (ite (and (= @V0 __src) (= @V1 home)) false $x405)))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let (($x408 (= @Y real_owner)))
 (let (($x316 (= @Y home)))
 (or $x316 $x408 $x359)))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let (($x411 (= @Z real_owner)))
 (let (($x410 (= @Z home)))
 (or $x410 $x411 $x374)))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x343)))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let (($x416 (= @V1 real_owner)))
 (let (($x291 (= @V1 home)))
 (or $x291 $x416 $x305)))))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (let (($x408 (= @Y real_owner)))
 (let (($x316 (= @Y home)))
 (or $x316 $x408 $x353)))))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (let (($x411 (= @Z real_owner)))
 (let (($x410 (= @Z home)))
 (or $x410 $x411 $x368)))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x328)))))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (let (($x416 (= @V1 real_owner)))
 (let (($x291 (= @V1 home)))
 (or $x291 $x416 $x299)))))
(assert
 (let (($x371 (not (net.get @X @Y))))
 (let (($x408 (= @Y real_owner)))
 (let (($x316 (= @Y home)))
 (or $x316 $x408 $x371)))))
(assert
 (let (($x361 (not (net.get @X @Z))))
 (let (($x411 (= @Z real_owner)))
 (let (($x410 (= @Z home)))
 (or $x410 $x411 $x361)))))
(assert
 (let (($x348 (not (net.get @X home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x348)))))
(assert
 (let (($x309 (not (net.get @V0 @V1))))
 (let (($x416 (= @V1 real_owner)))
 (let (($x291 (= @V1 home)))
 (or $x291 $x416 $x309)))))
(assert
 (let (($x364 (not (net.getX @X @Y))))
 (let (($x408 (= @Y real_owner)))
 (let (($x316 (= @Y home)))
 (or $x316 $x408 $x364)))))
(assert
 (let (($x356 (not (net.getX @X @Z))))
 (let (($x411 (= @Z real_owner)))
 (let (($x410 (= @Z home)))
 (or $x410 $x411 $x356)))))
(assert
 (let (($x377 (not (net.getX home @Y))))
 (let (($x408 (= @Y real_owner)))
 (let (($x316 (= @Y home)))
 (or $x316 $x408 $x377)))))
(assert
 (let (($x333 (not (net.getX @X home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x333)))))
(assert
 (let (($x322 (not (net.getX @V1 @V0))))
 (let (($x431 (= @V0 real_owner)))
 (let (($x430 (= @V0 home)))
 (or $x430 $x431 $x322)))))
(assert
 (let (($x302 (not (net.getX @V0 @V1))))
 (let (($x416 (= @V1 real_owner)))
 (let (($x291 (= @V1 home)))
 (or $x291 $x416 $x302)))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let (($x316 (= @Y home)))
 (or $x316 $x359 dir.dirty))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let (($x410 (= @Z home)))
 (or $x410 $x374 dir.dirty))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let (($x413 (= home home)))
 (or $x413 $x343 dir.dirty))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x305 dir.dirty))))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (let (($x316 (= @Y home)))
 (or $x316 $x353 dir.head))))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (let (($x410 (= @Z home)))
 (or $x410 $x368 dir.head))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x413 (= home home)))
 (or $x413 $x328 dir.head))))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x299 dir.head))))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (let (($x316 (= @Y home)))
 (or $x316 $x353 dir.dirty))))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (let (($x410 (= @Z home)))
 (or $x410 $x368 dir.dirty))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x413 (= home home)))
 (or $x413 $x328 dir.dirty))))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x299 dir.dirty))))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (let (($x316 (= @Y home)))
 (or $x316 $x353))))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (let (($x410 (= @Z home)))
 (or $x410 $x368))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x413 (= home home)))
 (or $x413 $x328))))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x299))))
(assert
 (let (($x371 (not (net.get @X @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x371 dir.head))))
(assert
 (let (($x361 (not (net.get @X @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x361 dir.head))))
(assert
 (let (($x348 (not (net.get @X home))))
 (let (($x413 (= home home)))
 (or $x413 $x348 dir.head))))
(assert
 (let (($x309 (not (net.get @V0 @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x309 dir.head))))
(assert
 (let (($x371 (not (net.get @X @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x371 dir.dirty))))
(assert
 (let (($x361 (not (net.get @X @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x361 dir.dirty))))
(assert
 (let (($x348 (not (net.get @X home))))
 (let (($x413 (= home home)))
 (or $x413 $x348 dir.dirty))))
(assert
 (let (($x309 (not (net.get @V0 @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x309 dir.dirty))))
(assert
 (let (($x364 (not (net.getX @X @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x364 dir.head))))
(assert
 (let (($x356 (not (net.getX @X @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x356 dir.head))))
(assert
 (let (($x377 (not (net.getX home @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x377 dir.head))))
(assert
 (let (($x333 (not (net.getX @X home))))
 (let (($x413 (= home home)))
 (or $x413 $x333 dir.head))))
(assert
 (let (($x322 (not (net.getX @V1 @V0))))
 (let (($x430 (= @V0 home)))
 (or $x430 $x322 dir.head))))
(assert
 (let (($x302 (not (net.getX @V0 @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x302 dir.head))))
(assert
 (let (($x364 (not (net.getX @X @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x364 dir.dirty))))
(assert
 (let (($x356 (not (net.getX @X @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x356 dir.dirty))))
(assert
 (let (($x377 (not (net.getX home @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x377 dir.dirty))))
(assert
 (let (($x333 (not (net.getX @X home))))
 (let (($x413 (= home home)))
 (or $x413 $x333 dir.dirty))))
(assert
 (let (($x322 (not (net.getX @V1 @V0))))
 (let (($x430 (= @V0 home)))
 (or $x430 $x322 dir.dirty))))
(assert
 (let (($x302 (not (net.getX @V0 @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x302 dir.dirty))))
(assert
 (let (($x364 (not (net.getX @X @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x364))))
(assert
 (let (($x356 (not (net.getX @X @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x356))))
(assert
 (let (($x377 (not (net.getX home @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x377))))
(assert
 (let (($x333 (not (net.getX @X home))))
 (let (($x413 (= home home)))
 (or $x413 $x333))))
(assert
 (let (($x322 (not (net.getX @V1 @V0))))
 (let (($x430 (= @V0 home)))
 (or $x430 $x322))))
(assert
 (let (($x302 (not (net.getX @V0 @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x302))))
(assert
 (let (($x364 (not (net.getX @X @Y))))
 (let (($x316 (= @Y home)))
 (let (($x476 (= @X requester)))
 (or $x476 $x316 $x364)))))
(assert
 (let (($x356 (not (net.getX @X @Z))))
 (let (($x410 (= @Z home)))
 (let (($x476 (= @X requester)))
 (or $x476 $x410 $x356)))))
(assert
 (let (($x377 (not (net.getX home @Y))))
 (let (($x316 (= @Y home)))
 (let (($x479 (= home requester)))
 (or $x479 $x316 $x377)))))
(assert
 (let (($x333 (not (net.getX @X home))))
 (let (($x413 (= home home)))
 (let (($x476 (= @X requester)))
 (or $x476 $x413 $x333)))))
(assert
 (let (($x322 (not (net.getX @V1 @V0))))
 (let (($x430 (= @V0 home)))
 (let (($x482 (= @V1 requester)))
 (or $x482 $x430 $x322)))))
(assert
 (let (($x302 (not (net.getX @V0 @V1))))
 (let (($x291 (= @V1 home)))
 (let (($x484 (= @V0 requester)))
 (or $x484 $x291 $x302)))))
(assert
 (let (($x187 (not (__net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x271 (__net.fack __src home)))
 (let (($x489 (not $x271)))
 (or (= __src real_owner) $x489))))
(assert
 (let (($x405 (__net.fack @V0 @V1)))
 (let (($x491 (not $x405)))
 (let (($x431 (= @V0 real_owner)))
 (or $x431 $x491)))))
(assert
 (let (($x337 (not (= (cache.state_ @X) exclusive))))
 (let (($x493 (= @X real_owner)))
 (or $x493 $x337))))
(assert
 (let (($x496 (not (= (cache.state_ @V0) exclusive))))
 (let (($x431 (= @V0 real_owner)))
 (or $x431 $x496))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x498 (= @X __dir.hptr)))
 (or $x498 $x328))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x500 (= @V0 __dir.hptr)))
 (or $x500 $x502))))
(assert
 (let (($x337 (not (= (cache.state_ @X) exclusive))))
 (let (($x498 (= @X __dir.hptr)))
 (or $x498 $x337))))
(assert
 (let (($x496 (not (= (cache.state_ @V0) exclusive))))
 (let (($x500 (= @V0 __dir.hptr)))
 (or $x500 $x496))))
(assert
 (let (($x507 (not (= (cache.state_ @X) shared))))
 (let (($x493 (= @X real_owner)))
 (or $x493 $x507))))
(assert
 (let (($x510 (not (= (cache.state_ @V0) shared))))
 (let (($x431 (= @V0 real_owner)))
 (or $x431 $x510))))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (let (($x316 (= @Y home)))
 (or $x316 $x353))))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (let (($x410 (= @Z home)))
 (or $x410 $x368))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x413 (= home home)))
 (or $x413 $x328))))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x299))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x413 (= home home)))
 (or $x413 $x502))))
(assert
 (let (($x507 (not (= (cache.state_ @X) shared))))
 (let (($x341 (not (rp_net @X))))
 (or $x341 $x507))))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (let (($x514 (= real_owner @X)))
 (or $x514 $x353))))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (let (($x514 (= real_owner @X)))
 (or $x514 $x368))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x514 (= real_owner @X)))
 (or $x514 $x328))))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (let (($x518 (= real_owner @V0)))
 (or $x518 $x299))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x518 (= real_owner @V0)))
 (or $x518 $x502))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (or $x359 dir.head)))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (or $x374 dir.head)))
(assert
 (let (($x343 (not (net.put home @X))))
 (or $x343 dir.head)))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (or $x305 dir.head)))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (or $x353 dir.head)))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (or $x368 dir.head)))
(assert
 (let (($x328 (not (net.putX home @X))))
 (or $x328 dir.head)))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (or $x299 dir.head)))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (or $x502 dir.head)))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (or $x353 dir.dirty)))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (or $x368 dir.dirty)))
(assert
 (let (($x328 (not (net.putX home @X))))
 (or $x328 dir.dirty)))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (or $x299 dir.dirty)))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (or $x502 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x328 (not (net.putX home @X))))
 (or $x328 dir.head)))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (or $x502 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x341 (not (rp_net @X))))
 (let (($x359 (not (net.put @Y @X))))
 (or $x359 $x341))))
(assert
 (let (($x341 (not (rp_net @X))))
 (let (($x374 (not (net.put @Z @X))))
 (or $x374 $x341))))
(assert
 (let (($x341 (not (rp_net @X))))
 (let (($x343 (not (net.put home @X))))
 (or $x343 $x341))))
(assert
 (let (($x544 (not (rp_net @V0))))
 (let (($x305 (not (net.put @V1 @V0))))
 (or $x305 $x544))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put __dir.hptr @X)))
(assert
 (not (net.put __dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x507 (not (= (cache.state_ @X) shared))))
 (let (($x561 (not (invack @X))))
 (or $x561 $x507))))
(assert
 (let (($x510 (not (= (cache.state_ @V0) shared))))
 (let (($x564 (not (invack @V0))))
 (or $x564 $x510))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x359 __dir.pending))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x374 __dir.pending))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x343 __dir.pending))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x305 __dir.pending))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x547 __dir.pending))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x549 __dir.pending))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x551 __dir.pending))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x359 dir.dirty))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x374 dir.dirty))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x343 dir.dirty))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x305 dir.dirty))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x547 dir.dirty))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x549 dir.dirty))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x551 dir.dirty))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x359))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x374))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x343))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x305))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x547))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x549))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x551))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x590))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x593))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x328))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x502))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x598))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x601))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x343))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x547))))
(assert
 (let (($x605 (not (net.get __dir.hptr home))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (let (($x603 (not $x58)))
 (or $x603 $x605)))))
(assert
 (let (($x609 (not (net.get dir.hptr home))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (let (($x607 (not $x400)))
 (or $x607 $x609)))))
(assert
 (let (($x348 (not (net.get @X home))))
 (let (($x566 (__dir.shlist @X)))
 (let (($x611 (not $x566)))
 (or $x611 $x348)))))
(assert
 (let (($x615 (not (net.get @V0 home))))
 (let (($x570 (__dir.shlist @V0)))
 (let (($x613 (not $x570)))
 (or $x613 $x615)))))
(assert
 (let (($x58 (__dir.shlist __dir.hptr)))
 (let (($x603 (not $x58)))
 (or $x603 dir.head))))
(assert
 (let (($x400 (__dir.shlist dir.hptr)))
 (let (($x607 (not $x400)))
 (or $x607 dir.head))))
(assert
 (let (($x566 (__dir.shlist @X)))
 (let (($x611 (not $x566)))
 (or $x611 dir.head))))
(assert
 (let (($x570 (__dir.shlist @V0)))
 (let (($x613 (not $x570)))
 (or $x613 dir.head))))
(assert
 (let (($x337 (not (= (cache.state_ @X) exclusive))))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x337))))
(assert
 (let (($x496 (not (= (cache.state_ @V0) exclusive))))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x496))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let (($x623 (= @X home)))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x623 $x359)))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let (($x623 (= @X home)))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x623 $x374)))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let (($x623 (= @X home)))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x623 $x343)))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let (($x430 (= @V0 home)))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x430 $x305)))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let (($x430 (= @V0 home)))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x430 $x547)))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let (($x623 (= @X home)))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x623 $x549)))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let (($x430 (= @V0 home)))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x430 $x551)))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let (($x631 (= __dir.hptr home)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x631 $x598)))))
(assert
 (let (($x337 (not (= (cache.state_ @X) exclusive))))
 (let (($x476 (= @X requester)))
 (let (($x566 (__dir.shlist @X)))
 (or $x566 $x476 $x337)))))
(assert
 (let (($x496 (not (= (cache.state_ @V0) exclusive))))
 (let (($x484 (= @V0 requester)))
 (let (($x570 (__dir.shlist @V0)))
 (or $x570 $x484 $x496)))))
(assert
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (let (($x493 (= @X real_owner)))
 (or (dir.real @X) $x493 $x636)))))
(assert
 (let ((?x311 (cache.state_ @V0)))
 (let (($x312 (= ?x311 invalid)))
 (let (($x431 (= @V0 real_owner)))
 (or (dir.real @V0) $x431 $x312)))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x328))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x502))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x590))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x593))))
(assert
 (let (($x507 (not (= (cache.state_ @X) shared))))
 (or $x507 (not (= (cache.wait @X) get)))))
(assert
 (let (($x510 (not (= (cache.state_ @V0) shared))))
 (or $x510 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x561 (not (invack @X))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x561)))))
(assert
 (let (($x564 (not (invack @V0))))
 (let ((?x311 (cache.state_ @V0)))
 (let (($x312 (= ?x311 invalid)))
 (or $x312 $x564)))))
(assert
 (let (($x337 (not (= (cache.state_ @X) exclusive))))
 (or $x337 dir.head)))
(assert
 (let (($x496 (not (= (cache.state_ @V0) exclusive))))
 (or $x496 dir.head)))
(assert
 (let (($x187 (not (__net.fack requester home))))
 (let (($x413 (= home home)))
 (or $x413 $x187))))
(assert
 (let (($x271 (__net.fack __src home)))
 (let (($x489 (not $x271)))
 (let (($x413 (= home home)))
 (or $x413 $x489)))))
(assert
 (let (($x405 (__net.fack @V0 @V1)))
 (let (($x491 (not $x405)))
 (let (($x291 (= @V1 home)))
 (or $x291 $x491)))))
(assert
 (let (($x353 (not (net.putX @Y @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x353)))))
(assert
 (let (($x368 (not (net.putX @Z @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x368)))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x328)))))
(assert
 (let (($x299 (not (net.putX @V1 @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x297 (= ?x296 getX)))
 (or $x297 $x299)))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x297 (= ?x296 getX)))
 (or $x297 $x502)))))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x538)))))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x297 (= ?x296 getX)))
 (or $x297 $x540)))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x661 (= ?x660 getX)))
 (or $x661 $x590)))))
(assert
 (let (($x364 (not (net.getX @X @Y))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x364)))))
(assert
 (let (($x356 (not (net.getX @X @Z))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x356)))))
(assert
 (let (($x377 (not (net.getX home @Y))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x377)))))
(assert
 (let (($x333 (not (net.getX @X home))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x333)))))
(assert
 (let (($x322 (not (net.getX @V1 @V0))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x668 (= ?x323 getX)))
 (or $x668 $x322)))))
(assert
 (let (($x302 (not (net.getX @V0 @V1))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x297 (= ?x296 getX)))
 (or $x297 $x302)))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x359)))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x374)))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x343)))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x306 (= ?x296 get)))
 (or $x306 $x305)))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x306 (= ?x296 get)))
 (or $x306 $x547)))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x549)))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x306 (= ?x296 get)))
 (or $x306 $x551)))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x675 (= ?x660 get)))
 (or $x675 $x598)))))
(assert
 (let (($x371 (not (net.get @X @Y))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x371)))))
(assert
 (let (($x361 (not (net.get @X @Z))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x361)))))
(assert
 (let (($x348 (not (net.get @X home))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x348)))))
(assert
 (let (($x309 (not (net.get @V0 @V1))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x306 (= ?x296 get)))
 (or $x306 $x309)))))
(assert
 (let (($x553 (not (net.get home @Y))))
 (let ((?x665 (cache.wait home)))
 (let (($x679 (= ?x665 get)))
 (or $x679 $x553)))))
(assert
 (let (($x555 (not (net.get home @Z))))
 (let ((?x665 (cache.wait home)))
 (let (($x679 (= ?x665 get)))
 (or $x679 $x555)))))
(assert
 (let (($x557 (not (net.get home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x679 (= ?x665 get)))
 (or $x679 $x557)))))
(assert
 (let (($x559 (not (net.get home @V1))))
 (let ((?x665 (cache.wait home)))
 (let (($x679 (= ?x665 get)))
 (or $x679 $x559)))))
(assert
 (let (($x359 (not (net.put @Y @X))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x359)))))
(assert
 (let (($x374 (not (net.put @Z @X))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x374)))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x343)))))
(assert
 (let (($x305 (not (net.put @V1 @V0))))
 (let ((?x311 (cache.state_ @V0)))
 (let (($x312 (= ?x311 invalid)))
 (or $x312 $x305)))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let ((?x311 (cache.state_ @V0)))
 (let (($x312 (= ?x311 invalid)))
 (or $x312 $x547)))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x549)))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let ((?x311 (cache.state_ @V0)))
 (let (($x312 (= ?x311 invalid)))
 (or $x312 $x551)))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let ((?x690 (cache.state_ __dir.hptr)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x598)))))
(assert
 (let (($x371 (not (net.get @X @Y))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x371)))))
(assert
 (let (($x361 (not (net.get @X @Z))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x361)))))
(assert
 (let (($x348 (not (net.get @X home))))
 (let ((?x335 (cache.state_ @X)))
 (let (($x636 (= ?x335 invalid)))
 (or $x636 $x348)))))
(assert
 (let (($x309 (not (net.get @V0 @V1))))
 (let ((?x311 (cache.state_ @V0)))
 (let (($x312 (= ?x311 invalid)))
 (or $x312 $x309)))))
(assert
 (let (($x553 (not (net.get home @Y))))
 (let ((?x696 (cache.state_ home)))
 (let (($x697 (= ?x696 invalid)))
 (or $x697 $x553)))))
(assert
 (let (($x555 (not (net.get home @Z))))
 (let ((?x696 (cache.state_ home)))
 (let (($x697 (= ?x696 invalid)))
 (or $x697 $x555)))))
(assert
 (let (($x557 (not (net.get home home))))
 (let ((?x696 (cache.state_ home)))
 (let (($x697 (= ?x696 invalid)))
 (or $x697 $x557)))))
(assert
 (let (($x559 (not (net.get home @V1))))
 (let ((?x696 (cache.state_ home)))
 (let (($x697 (= ?x696 invalid)))
 (or $x697 $x559)))))
(assert
 (let (($x316 (= @Y home)))
 (or $x316 (not (net.shwb @X @Y)))))
(assert
 (let (($x413 (= home home)))
 (or $x413 (not (net.shwb @X home)))))
(assert
 (let (($x704 (not (= (cache.wait @X) none))))
 (let (($x364 (not (net.getX @X @Y))))
 (or $x364 $x704))))
(assert
 (let (($x704 (not (= (cache.wait @X) none))))
 (let (($x356 (not (net.getX @X @Z))))
 (or $x356 $x704))))
(assert
 (let (($x708 (not (= (cache.wait home) none))))
 (let (($x377 (not (net.getX home @Y))))
 (or $x377 $x708))))
(assert
 (let (($x704 (not (= (cache.wait @X) none))))
 (let (($x333 (not (net.getX @X home))))
 (or $x333 $x704))))
(assert
 (let (($x325 (not (= (cache.wait @V1) none))))
 (let (($x322 (not (net.getX @V1 @V0))))
 (or $x322 $x325))))
(assert
 (let (($x712 (not (= (cache.wait @V0) none))))
 (let (($x302 (not (net.getX @V0 @V1))))
 (or $x302 $x712))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x714 (= ?x140 getX)))
 (or $x714 $x716)))))
(assert
 (let (($x328 (not (net.putX home @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x328)))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x668 (= ?x323 getX)))
 (or $x668 $x719)))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x297 (= ?x296 getX)))
 (or $x297 $x502)))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x661 (= ?x660 getX)))
 (or $x661 $x590)))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x722)))))
(assert
 (let (($x333 (not (net.getX @X home))))
 (let ((?x329 (cache.wait @X)))
 (let (($x330 (= ?x329 getX)))
 (or $x330 $x333)))))
(assert
 (let (($x725 (not (net.getX home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x725)))))
(assert
 (let (($x728 (not (net.getX @V1 home))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x668 (= ?x323 getX)))
 (or $x668 $x728)))))
(assert
 (let (($x731 (not (net.getX @V0 home))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x297 (= ?x296 getX)))
 (or $x297 $x731)))))
(assert
 (let (($x337 (not (= (cache.state_ @X) exclusive))))
 (or $x337 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x496 (not (= (cache.state_ @V0) exclusive))))
 (or $x496 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x736 (not (= (cache.state_ __dir.hptr) exclusive))))
 (or $x736 (not (= (cache.wait __dir.hptr) getX)))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (or $x740 (not (= (cache.wait home) getX)))))
(assert
 (let (($x341 (not (rp_net @X))))
 (let (($x343 (not (net.put home @X))))
 (or $x343 $x341))))
(assert
 (let (($x544 (not (rp_net @V0))))
 (let (($x547 (not (net.put home @V0))))
 (or $x547 $x544))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x745)))))
(assert
 (let (($x343 (not (net.put home @X))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x343)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x747 (= ?x323 get)))
 (or $x747 $x749)))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x306 (= ?x296 get)))
 (or $x306 $x547)))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x675 (= ?x660 get)))
 (or $x675 $x598)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x679 (= ?x665 get)))
 (or $x679 $x752)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x755)))))
(assert
 (let (($x348 (not (net.get @X home))))
 (let ((?x329 (cache.wait @X)))
 (let (($x345 (= ?x329 get)))
 (or $x345 $x348)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x747 (= ?x323 get)))
 (or $x747 $x758)))))
(assert
 (let (($x615 (not (net.get @V0 home))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x306 (= ?x296 get)))
 (or $x306 $x615)))))
(assert
 (let (($x605 (not (net.get __dir.hptr home))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x675 (= ?x660 get)))
 (or $x675 $x605)))))
(assert
 (let (($x557 (not (net.get home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x679 (= ?x665 get)))
 (or $x679 $x557)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x547)))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x145 $x549)))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x145 $x551)))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x598)))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x601)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x752)))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x502)))))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (let (($x778 (= real_owner real_owner)))
 (let (($x777 (= real_owner home)))
 (or $x777 $x778 $x538)))))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (let (($x778 (= real_owner real_owner)))
 (let (($x777 (= real_owner home)))
 (or $x777 $x778 $x540)))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x590)))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x593)))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x716)))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x719)))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x722)))))
(assert
 (let (($x553 (not (net.get home @Y))))
 (let (($x408 (= @Y real_owner)))
 (let (($x316 (= @Y home)))
 (or $x316 $x408 $x553)))))
(assert
 (let (($x555 (not (net.get home @Z))))
 (let (($x411 (= @Z real_owner)))
 (let (($x410 (= @Z home)))
 (or $x410 $x411 $x555)))))
(assert
 (let (($x557 (not (net.get home home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x557)))))
(assert
 (let (($x559 (not (net.get home @V1))))
 (let (($x416 (= @V1 real_owner)))
 (let (($x291 (= @V1 home)))
 (or $x291 $x416 $x559)))))
(assert
 (let (($x605 (not (net.get __dir.hptr home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x605)))))
(assert
 (let (($x609 (not (net.get dir.hptr home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x609)))))
(assert
 (let (($x615 (not (net.get @V0 home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x615)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x755)))))
(assert
 (let (($x725 (not (net.getX home home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x725)))))
(assert
 (let (($x728 (not (net.getX @V1 home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x728)))))
(assert
 (let (($x731 (not (net.getX @V0 home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x731)))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x411 (= @Z real_owner)))
 (let (($x410 (= @Z home)))
 (or $x410 $x411 $x763)))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x431 (= @V0 real_owner)))
 (let (($x430 (= @V0 home)))
 (or $x430 $x431 $x765)))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x416 (= @V1 real_owner)))
 (let (($x291 (= @V1 home)))
 (or $x291 $x416 $x767)))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (let (($x413 (= home home)))
 (or $x413 $x547 dir.dirty))))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x549 dir.dirty))))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x551 dir.dirty))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x598 dir.dirty))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x601 dir.dirty))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x413 (= home home)))
 (or $x413 $x745 dir.dirty))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x413 (= home home)))
 (or $x413 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x413 (= home home)))
 (or $x413 $x752 dir.dirty))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x413 (= home home)))
 (or $x413 $x502 dir.head))))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x538 dir.head))))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x540 dir.head))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x590 dir.head))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x593 dir.head))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x413 (= home home)))
 (or $x413 $x716 dir.head))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x413 (= home home)))
 (or $x413 $x719 dir.head))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x413 (= home home)))
 (or $x413 $x722 dir.head))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x413 (= home home)))
 (or $x413 $x502 dir.dirty))))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x538 dir.dirty))))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x540 dir.dirty))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x590 dir.dirty))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x593 dir.dirty))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x413 (= home home)))
 (or $x413 $x716 dir.dirty))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x413 (= home home)))
 (or $x413 $x719 dir.dirty))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x413 (= home home)))
 (or $x413 $x722 dir.dirty))))
(assert
 (let (($x502 (not (net.putX home @V0))))
 (let (($x413 (= home home)))
 (or $x413 $x502))))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x538))))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x540))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x590))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x593))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x413 (= home home)))
 (or $x413 $x716))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x413 (= home home)))
 (or $x413 $x719))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x413 (= home home)))
 (or $x413 $x722))))
(assert
 (let (($x553 (not (net.get home @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x553 dir.head))))
(assert
 (let (($x555 (not (net.get home @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x555 dir.head))))
(assert
 (let (($x557 (not (net.get home home))))
 (let (($x413 (= home home)))
 (or $x413 $x557 dir.head))))
(assert
 (let (($x559 (not (net.get home @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x559 dir.head))))
(assert
 (let (($x605 (not (net.get __dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x605 dir.head))))
(assert
 (let (($x609 (not (net.get dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x609 dir.head))))
(assert
 (let (($x615 (not (net.get @V0 home))))
 (let (($x413 (= home home)))
 (or $x413 $x615 dir.head))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x413 (= home home)))
 (or $x413 $x755 dir.head))))
(assert
 (let (($x553 (not (net.get home @Y))))
 (let (($x316 (= @Y home)))
 (or $x316 $x553 dir.dirty))))
(assert
 (let (($x555 (not (net.get home @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x555 dir.dirty))))
(assert
 (let (($x557 (not (net.get home home))))
 (let (($x413 (= home home)))
 (or $x413 $x557 dir.dirty))))
(assert
 (let (($x559 (not (net.get home @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x559 dir.dirty))))
(assert
 (let (($x605 (not (net.get __dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x605 dir.dirty))))
(assert
 (let (($x609 (not (net.get dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x609 dir.dirty))))
(assert
 (let (($x615 (not (net.get @V0 home))))
 (let (($x413 (= home home)))
 (or $x413 $x615 dir.dirty))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x413 (= home home)))
 (or $x413 $x755 dir.dirty))))
(assert
 (let (($x725 (not (net.getX home home))))
 (let (($x413 (= home home)))
 (or $x413 $x725 dir.head))))
(assert
 (let (($x728 (not (net.getX @V1 home))))
 (let (($x413 (= home home)))
 (or $x413 $x728 dir.head))))
(assert
 (let (($x731 (not (net.getX @V0 home))))
 (let (($x413 (= home home)))
 (or $x413 $x731 dir.head))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x763 dir.head))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x430 (= @V0 home)))
 (or $x430 $x765 dir.head))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x767 dir.head))))
(assert
 (let (($x725 (not (net.getX home home))))
 (let (($x413 (= home home)))
 (or $x413 $x725 dir.dirty))))
(assert
 (let (($x728 (not (net.getX @V1 home))))
 (let (($x413 (= home home)))
 (or $x413 $x728 dir.dirty))))
(assert
 (let (($x731 (not (net.getX @V0 home))))
 (let (($x413 (= home home)))
 (or $x413 $x731 dir.dirty))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x763 dir.dirty))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x430 (= @V0 home)))
 (or $x430 $x765 dir.dirty))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x767 dir.dirty))))
(assert
 (let (($x725 (not (net.getX home home))))
 (let (($x413 (= home home)))
 (or $x413 $x725))))
(assert
 (let (($x728 (not (net.getX @V1 home))))
 (let (($x413 (= home home)))
 (or $x413 $x728))))
(assert
 (let (($x731 (not (net.getX @V0 home))))
 (let (($x413 (= home home)))
 (or $x413 $x731))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x410 (= @Z home)))
 (or $x410 $x763))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x430 (= @V0 home)))
 (or $x430 $x765))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x291 (= @V1 home)))
 (or $x291 $x767))))
(assert
 (let (($x725 (not (net.getX home home))))
 (let (($x413 (= home home)))
 (let (($x479 (= home requester)))
 (or $x479 $x413 $x725)))))
(assert
 (let (($x728 (not (net.getX @V1 home))))
 (let (($x413 (= home home)))
 (let (($x482 (= @V1 requester)))
 (or $x482 $x413 $x728)))))
(assert
 (let (($x731 (not (net.getX @V0 home))))
 (let (($x413 (= home home)))
 (let (($x484 (= @V0 requester)))
 (or $x484 $x413 $x731)))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let (($x410 (= @Z home)))
 (let (($x479 (= home requester)))
 (or $x479 $x410 $x763)))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let (($x430 (= @V0 home)))
 (let (($x479 (= home requester)))
 (or $x479 $x430 $x765)))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let (($x291 (= @V1 home)))
 (let (($x479 (= home requester)))
 (or $x479 $x291 $x767)))))
(assert
 (let (($x736 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x736))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x414 (= home real_owner)))
 (or $x414 $x740))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x873 (= __dir.hptr __dir.hptr)))
 (or $x873 $x590))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x875 (= dir.hptr __dir.hptr)))
 (or $x875 $x593))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x877 (= real_owner __dir.hptr)))
 (or $x877 $x716))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x879 (= @V1 __dir.hptr)))
 (or $x879 $x719))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x881 (= home __dir.hptr)))
 (or $x881 $x722))))
(assert
 (let (($x736 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x873 (= __dir.hptr __dir.hptr)))
 (or $x873 $x736))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x881 (= home __dir.hptr)))
 (or $x881 $x740))))
(assert
 (let (($x886 (not (= (cache.state_ __dir.hptr) shared))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x886))))
(assert
 (let (($x889 (not (= (cache.state_ home) shared))))
 (let (($x414 (= home real_owner)))
 (or $x414 $x889))))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x538))))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x540))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x590))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let (($x413 (= home home)))
 (or $x413 $x593))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x413 (= home home)))
 (or $x413 $x716))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x413 (= home home)))
 (or $x413 $x719))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x413 (= home home)))
 (or $x413 $x722))))
(assert
 (let (($x510 (not (= (cache.state_ @V0) shared))))
 (let (($x544 (not (rp_net @V0))))
 (or $x544 $x510))))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (let (($x514 (= real_owner @X)))
 (or $x514 $x538))))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (let (($x518 (= real_owner @V0)))
 (or $x518 $x540))))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (let (($x877 (= real_owner __dir.hptr)))
 (or $x877 $x590))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (or (= real_owner dir.hptr) $x593)))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x778 (= real_owner real_owner)))
 (or $x778 $x716))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x719)))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x722))))
(assert
 (let (($x547 (not (net.put home @V0))))
 (or $x547 dir.head)))
(assert
 (let (($x549 (not (net.put __dir.hptr @X))))
 (or $x549 dir.head)))
(assert
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (or $x551 dir.head)))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (or $x598 dir.head)))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (or $x601 dir.head)))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (or $x745 dir.head)))
(assert
 (let (($x749 (not (net.put home @V1))))
 (or $x749 dir.head)))
(assert
 (let (($x752 (not (net.put home home))))
 (or $x752 dir.head)))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (or $x538 dir.head)))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (or $x540 dir.head)))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (or $x590 dir.head)))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (or $x593 dir.head)))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (or $x716 dir.head)))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (or $x719 dir.head)))
(assert
 (let (($x722 (not (net.putX home home))))
 (or $x722 dir.head)))
(assert
 (let (($x538 (not (net.putX real_owner @X))))
 (or $x538 dir.dirty)))
(assert
 (let (($x540 (not (net.putX real_owner @V0))))
 (or $x540 dir.dirty)))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (or $x590 dir.dirty)))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (or $x593 dir.dirty)))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (or $x716 dir.dirty)))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (or $x719 dir.dirty)))
(assert
 (let (($x722 (not (net.putX home home))))
 (or $x722 dir.dirty)))
(assert
 (not (net.putX real_owner __dir.hptr)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x590 (not (net.putX home __dir.hptr))))
 (or $x590 dir.head)))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (or $x593 dir.head)))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (or $x716 dir.head)))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (or $x719 dir.head)))
(assert
 (let (($x722 (not (net.putX home home))))
 (or $x722 dir.head)))
(assert
 (not (net.putX home __dir.hptr)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x544 (not (rp_net @V0))))
 (let (($x547 (not (net.put home @V0))))
 (or $x547 $x544))))
(assert
 (let (($x341 (not (rp_net @X))))
 (let (($x549 (not (net.put __dir.hptr @X))))
 (or $x549 $x341))))
(assert
 (let (($x544 (not (rp_net @V0))))
 (let (($x551 (not (net.put __dir.hptr @V0))))
 (or $x551 $x544))))
(assert
 (let (($x936 (not (rp_net __dir.hptr))))
 (let (($x598 (not (net.put home __dir.hptr))))
 (or $x598 $x936))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (or $x601 (not (rp_net dir.hptr)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (or $x745 (not (rp_net real_owner)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (or $x749 (not (rp_net @V1)))))
(assert
 (let (($x948 (not (rp_net home))))
 (let (($x752 (not (net.put home home))))
 (or $x752 $x948))))
(assert
 (not (net.put home __dir.hptr)))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put __dir.hptr __dir.hptr)))
(assert
 (not (net.put __dir.hptr dir.hptr)))
(assert
 (not (net.put __dir.hptr real_owner)))
(assert
 (not (net.put __dir.hptr @V1)))
(assert
 (not (net.put __dir.hptr home)))
(assert
 (let (($x561 (not (invack @X))))
 (or $x561 (not (invnet @X)))))
(assert
 (let (($x564 (not (invack @V0))))
 (or $x564 (not (invnet @V0)))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x598 __dir.pending))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x601 __dir.pending))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x745 __dir.pending))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x970 (__dir.shlist @V1)))
 (or $x970 $x749 __dir.pending))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x752 __dir.pending))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x951 __dir.pending))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x953 __dir.pending))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x955 __dir.pending))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x598 dir.dirty))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x601 dir.dirty))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x745 dir.dirty))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x970 (__dir.shlist @V1)))
 (or $x970 $x749 dir.dirty))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x752 dir.dirty))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x951 dir.dirty))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x953 dir.dirty))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x955 dir.dirty))))
(assert
 (let (($x598 (not (net.put home __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x598))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x601))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x745))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x970 (__dir.shlist @V1)))
 (or $x970 $x749))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x752))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x951))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x953))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x955))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x716))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x970 (__dir.shlist @V1)))
 (or $x970 $x719))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x722))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x745))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x970 (__dir.shlist @V1)))
 (or $x970 $x749))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x752))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let (($x968 (__dir.shlist real_owner)))
 (let (($x994 (not $x968)))
 (or $x994 $x755)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x970 (__dir.shlist @V1)))
 (let (($x996 (not $x970)))
 (or $x996 $x758)))))
(assert
 (let (($x557 (not (net.get home home))))
 (let (($x972 (__dir.shlist home)))
 (let (($x998 (not $x972)))
 (or $x998 $x557)))))
(assert
 (let (($x968 (__dir.shlist real_owner)))
 (let (($x994 (not $x968)))
 (or $x994 dir.head))))
(assert
 (let (($x970 (__dir.shlist @V1)))
 (let (($x996 (not $x970)))
 (or $x996 dir.head))))
(assert
 (let (($x972 (__dir.shlist home)))
 (let (($x998 (not $x972)))
 (or $x998 dir.head))))
(assert
 (let (($x736 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x736))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x740))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let (($x1005 (= dir.hptr home)))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x1005 $x601)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let (($x777 (= real_owner home)))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x777 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let (($x291 (= @V1 home)))
 (let (($x970 (__dir.shlist @V1)))
 (or $x970 $x291 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let (($x413 (= home home)))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x413 $x752)))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x631 (= __dir.hptr home)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x631 $x951)))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let (($x1005 (= dir.hptr home)))
 (let (($x400 (__dir.shlist dir.hptr)))
 (or $x400 $x1005 $x953)))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let (($x777 (= real_owner home)))
 (let (($x968 (__dir.shlist real_owner)))
 (or $x968 $x777 $x955)))))
(assert
 (let (($x957 (not (net.put __dir.hptr @V1))))
 (let (($x291 (= @V1 home)))
 (let (($x970 (__dir.shlist @V1)))
 (or $x970 $x291 $x957)))))
(assert
 (let (($x736 (not (= (cache.state_ __dir.hptr) exclusive))))
 (let (($x1014 (= __dir.hptr requester)))
 (let (($x58 (__dir.shlist __dir.hptr)))
 (or $x58 $x1014 $x736)))))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (let (($x479 (= home requester)))
 (let (($x972 (__dir.shlist home)))
 (or $x972 $x479 $x740)))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x716))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x719))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let (($x145 (= __dir.hptr real_owner)))
 (or $x145 $x722))))
(assert
 (let (($x886 (not (= (cache.state_ __dir.hptr) shared))))
 (or $x886 (not (= (cache.wait __dir.hptr) get)))))
(assert
 (let (($x889 (not (= (cache.state_ home) shared))))
 (or $x889 (not (= (cache.wait home) get)))))
(assert
 (let (($x736 (not (= (cache.state_ __dir.hptr) exclusive))))
 (or $x736 dir.head)))
(assert
 (let (($x740 (not (= (cache.state_ home) exclusive))))
 (or $x740 dir.head)))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1027 (= ?x1026 getX)))
 (or $x1027 $x593)))))
(assert
 (let (($x716 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x714 (= ?x140 getX)))
 (or $x714 $x716)))))
(assert
 (let (($x719 (not (net.putX home @V1))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x668 (= ?x323 getX)))
 (or $x668 $x719)))))
(assert
 (let (($x722 (not (net.putX home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x722)))))
(assert
 (let (($x924 (not (net.putX real_owner __dir.hptr))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x661 (= ?x660 getX)))
 (or $x661 $x924)))))
(assert
 (let (($x926 (not (net.putX real_owner dir.hptr))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1027 (= ?x1026 getX)))
 (or $x1027 $x926)))))
(assert
 (let (($x928 (not (net.putX real_owner real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x714 (= ?x140 getX)))
 (or $x714 $x928)))))
(assert
 (let (($x930 (not (net.putX real_owner @V1))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x668 (= ?x323 getX)))
 (or $x668 $x930)))))
(assert
 (let (($x725 (not (net.getX home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x725)))))
(assert
 (let (($x728 (not (net.getX @V1 home))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x668 (= ?x323 getX)))
 (or $x668 $x728)))))
(assert
 (let (($x731 (not (net.getX @V0 home))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x297 (= ?x296 getX)))
 (or $x297 $x731)))))
(assert
 (let (($x763 (not (net.getX home @Z))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x763)))))
(assert
 (let (($x765 (not (net.getX home @V0))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x765)))))
(assert
 (let (($x767 (not (net.getX home @V1))))
 (let ((?x665 (cache.wait home)))
 (let (($x666 (= ?x665 getX)))
 (or $x666 $x767)))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1036 (= ?x1026 get)))
 (or $x1036 $x601)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x747 (= ?x323 get)))
 (or $x747 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let ((?x665 (cache.wait home)))
 (let (($x679 (= ?x665 get)))
 (or $x679 $x752)))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x675 (= ?x660 get)))
 (or $x675 $x951)))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1036 (= ?x1026 get)))
 (or $x1036 $x953)))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x955)))))
(assert
 (let (($x957 (not (net.put __dir.hptr @V1))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x747 (= ?x323 get)))
 (or $x747 $x957)))))
(assert
 (let (($x605 (not (net.get __dir.hptr home))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x675 (= ?x660 get)))
 (or $x675 $x605)))))
(assert
 (let (($x609 (not (net.get dir.hptr home))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1036 (= ?x1026 get)))
 (or $x1036 $x609)))))
(assert
 (let (($x615 (not (net.get @V0 home))))
 (let ((?x296 (cache.wait @V0)))
 (let (($x306 (= ?x296 get)))
 (or $x306 $x615)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x755)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let ((?x323 (cache.wait @V1)))
 (let (($x747 (= ?x323 get)))
 (or $x747 $x758)))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let ((?x1043 (cache.state_ dir.hptr)))
 (let (($x1044 (= ?x1043 invalid)))
 (or $x1044 $x601)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (let ((?x1046 (cache.state_ real_owner)))
 (let (($x1047 (= ?x1046 invalid)))
 (or $x1047 $x745)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (let ((?x1049 (cache.state_ @V1)))
 (let (($x1050 (= ?x1049 invalid)))
 (or $x1050 $x749)))))
(assert
 (let (($x752 (not (net.put home home))))
 (let ((?x696 (cache.state_ home)))
 (let (($x697 (= ?x696 invalid)))
 (or $x697 $x752)))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let ((?x690 (cache.state_ __dir.hptr)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x951)))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let ((?x1043 (cache.state_ dir.hptr)))
 (let (($x1044 (= ?x1043 invalid)))
 (or $x1044 $x953)))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let ((?x1046 (cache.state_ real_owner)))
 (let (($x1047 (= ?x1046 invalid)))
 (or $x1047 $x955)))))
(assert
 (let (($x957 (not (net.put __dir.hptr @V1))))
 (let ((?x1049 (cache.state_ @V1)))
 (let (($x1050 (= ?x1049 invalid)))
 (or $x1050 $x957)))))
(assert
 (let (($x605 (not (net.get __dir.hptr home))))
 (let ((?x690 (cache.state_ __dir.hptr)))
 (let (($x691 (= ?x690 invalid)))
 (or $x691 $x605)))))
(assert
 (let (($x609 (not (net.get dir.hptr home))))
 (let ((?x1043 (cache.state_ dir.hptr)))
 (let (($x1044 (= ?x1043 invalid)))
 (or $x1044 $x609)))))
(assert
 (let (($x615 (not (net.get @V0 home))))
 (let ((?x311 (cache.state_ @V0)))
 (let (($x312 (= ?x311 invalid)))
 (or $x312 $x615)))))
(assert
 (let (($x755 (not (net.get real_owner home))))
 (let ((?x1046 (cache.state_ real_owner)))
 (let (($x1047 (= ?x1046 invalid)))
 (or $x1047 $x755)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let ((?x1049 (cache.state_ @V1)))
 (let (($x1050 (= ?x1049 invalid)))
 (or $x1050 $x758)))))
(assert
 (let (($x708 (not (= (cache.wait home) none))))
 (let (($x725 (not (net.getX home home))))
 (or $x725 $x708))))
(assert
 (let (($x325 (not (= (cache.wait @V1) none))))
 (let (($x728 (not (net.getX @V1 home))))
 (or $x728 $x325))))
(assert
 (let (($x712 (not (= (cache.wait @V0) none))))
 (let (($x731 (not (net.getX @V0 home))))
 (or $x731 $x712))))
(assert
 (let (($x708 (not (= (cache.wait home) none))))
 (let (($x763 (not (net.getX home @Z))))
 (or $x763 $x708))))
(assert
 (let (($x708 (not (= (cache.wait home) none))))
 (let (($x765 (not (net.getX home @V0))))
 (or $x765 $x708))))
(assert
 (let (($x708 (not (= (cache.wait home) none))))
 (let (($x767 (not (net.getX home @V1))))
 (or $x767 $x708))))
(assert
 (let (($x593 (not (net.putX home dir.hptr))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1027 (= ?x1026 getX)))
 (or $x1027 $x593)))))
(assert
 (let (($x1069 (not (net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x714 (= ?x140 getX)))
 (or $x714 $x1069)))))
(assert
 (let (($x1072 (not (net.getX __dir.hptr home))))
 (let ((?x660 (cache.wait __dir.hptr)))
 (let (($x661 (= ?x660 getX)))
 (or $x661 $x1072)))))
(assert
 (let (($x1075 (not (net.getX dir.hptr home))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1027 (= ?x1026 getX)))
 (or $x1027 $x1075)))))
(assert
 (let (($x1078 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1078 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1082 (not (= (cache.state_ @V1) exclusive))))
 (or $x1082 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x1086 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x1086 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x936 (not (rp_net __dir.hptr))))
 (let (($x598 (not (net.put home __dir.hptr))))
 (or $x598 $x936))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (or $x601 (not (rp_net dir.hptr)))))
(assert
 (let (($x745 (not (net.put home real_owner))))
 (or $x745 (not (rp_net real_owner)))))
(assert
 (let (($x749 (not (net.put home @V1))))
 (or $x749 (not (rp_net @V1)))))
(assert
 (let (($x948 (not (rp_net home))))
 (let (($x752 (not (net.put home home))))
 (or $x752 $x948))))
(assert
 (let (($x601 (not (net.put home dir.hptr))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1036 (= ?x1026 get)))
 (or $x1036 $x601)))))
(assert
 (let (($x609 (not (net.get dir.hptr home))))
 (let ((?x1026 (cache.wait dir.hptr)))
 (let (($x1036 (= ?x1026 get)))
 (or $x1036 $x609)))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x145 $x951)))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x145 $x953)))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x145 $x955)))))
(assert
 (let (($x957 (not (net.put __dir.hptr @V1))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x145 $x957)))))
(assert
 (let (($x959 (not (net.put __dir.hptr home))))
 (let (($x145 (= __dir.hptr real_owner)))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x145 $x959)))))
(assert
 (let (($x924 (not (net.putX real_owner __dir.hptr))))
 (let (($x778 (= real_owner real_owner)))
 (let (($x777 (= real_owner home)))
 (or $x777 $x778 $x924)))))
(assert
 (let (($x926 (not (net.putX real_owner dir.hptr))))
 (let (($x778 (= real_owner real_owner)))
 (let (($x777 (= real_owner home)))
 (or $x777 $x778 $x926)))))
(assert
 (let (($x928 (not (net.putX real_owner real_owner))))
 (let (($x778 (= real_owner real_owner)))
 (let (($x777 (= real_owner home)))
 (or $x777 $x778 $x928)))))
(assert
 (let (($x930 (not (net.putX real_owner @V1))))
 (let (($x778 (= real_owner real_owner)))
 (let (($x777 (= real_owner home)))
 (or $x777 $x778 $x930)))))
(assert
 (let (($x932 (not (net.putX real_owner home))))
 (let (($x778 (= real_owner real_owner)))
 (let (($x777 (= real_owner home)))
 (or $x777 $x778 $x932)))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x758)))))
(assert
 (let (($x1069 (not (net.getX real_owner home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x1069)))))
(assert
 (let (($x1072 (not (net.getX __dir.hptr home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x1072)))))
(assert
 (let (($x1075 (not (net.getX dir.hptr home))))
 (let (($x414 (= home real_owner)))
 (let (($x413 (= home home)))
 (or $x413 $x414 $x1075)))))
(assert
 (let (($x951 (not (net.put __dir.hptr __dir.hptr))))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x951 dir.dirty))))
(assert
 (let (($x953 (not (net.put __dir.hptr dir.hptr))))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x953 dir.dirty))))
(assert
 (let (($x955 (not (net.put __dir.hptr real_owner))))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x955 dir.dirty))))
(assert
 (let (($x957 (not (net.put __dir.hptr @V1))))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x957 dir.dirty))))
(assert
 (let (($x959 (not (net.put __dir.hptr home))))
 (let (($x631 (= __dir.hptr home)))
 (or $x631 $x959 dir.dirty))))
(assert
 (let (($x924 (not (net.putX real_owner __dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x924 dir.head))))
(assert
 (let (($x926 (not (net.putX real_owner dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x926 dir.head))))
(assert
 (let (($x928 (not (net.putX real_owner real_owner))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x928 dir.head))))
(assert
 (let (($x930 (not (net.putX real_owner @V1))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x930 dir.head))))
(assert
 (let (($x932 (not (net.putX real_owner home))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x932 dir.head))))
(assert
 (let (($x924 (not (net.putX real_owner __dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x924 dir.dirty))))
(assert
 (let (($x926 (not (net.putX real_owner dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x926 dir.dirty))))
(assert
 (let (($x928 (not (net.putX real_owner real_owner))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x928 dir.dirty))))
(assert
 (let (($x930 (not (net.putX real_owner @V1))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x930 dir.dirty))))
(assert
 (let (($x932 (not (net.putX real_owner home))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x932 dir.dirty))))
(assert
 (let (($x924 (not (net.putX real_owner __dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x924))))
(assert
 (let (($x926 (not (net.putX real_owner dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x926))))
(assert
 (let (($x928 (not (net.putX real_owner real_owner))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x928))))
(assert
 (let (($x930 (not (net.putX real_owner @V1))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x930))))
(assert
 (let (($x932 (not (net.putX real_owner home))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x932))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x413 (= home home)))
 (or $x413 $x758 dir.head))))
(assert
 (let (($x758 (not (net.get @V1 home))))
 (let (($x413 (= home home)))
 (or $x413 $x758 dir.dirty))))
(assert
 (let (($x1069 (not (net.getX real_owner home))))
 (let (($x413 (= home home)))
 (or $x413 $x1069 dir.head))))
(assert
 (let (($x1072 (not (net.getX __dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x1072 dir.head))))
(assert
 (let (($x1075 (not (net.getX dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x1075 dir.head))))
(assert
 (let (($x1069 (not (net.getX real_owner home))))
 (let (($x413 (= home home)))
 (or $x413 $x1069 dir.dirty))))
(assert
 (let (($x1072 (not (net.getX __dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x1072 dir.dirty))))
(assert
 (let (($x1075 (not (net.getX dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x1075 dir.dirty))))
(assert
 (let (($x1069 (not (net.getX real_owner home))))
 (let (($x413 (= home home)))
 (or $x413 $x1069))))
(assert
 (let (($x1072 (not (net.getX __dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x1072))))
(assert
 (let (($x1075 (not (net.getX dir.hptr home))))
 (let (($x413 (= home home)))
 (or $x413 $x1075))))
(assert
 (let (($x1069 (not (net.getX real_owner home))))
 (let (($x413 (= home home)))
 (or (= real_owner requester) $x413 $x1069))))
(assert
 (let (($x1072 (not (net.getX __dir.hptr home))))
 (let (($x413 (= home home)))
 (let (($x1014 (= __dir.hptr requester)))
 (or $x1014 $x413 $x1072)))))
(assert
 (let (($x1075 (not (net.getX dir.hptr home))))
 (let (($x413 (= home home)))
 (or (= dir.hptr requester) $x413 $x1075))))
(assert
 (let (($x1086 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x1139 (= dir.hptr real_owner)))
 (or $x1139 $x1086))))
(assert
 (let (($x1078 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x778 (= real_owner real_owner)))
 (or $x778 $x1078))))
(assert
 (let (($x1082 (not (= (cache.state_ @V1) exclusive))))
 (let (($x416 (= @V1 real_owner)))
 (or $x416 $x1082))))
(assert
 (let (($x1086 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x875 (= dir.hptr __dir.hptr)))
 (or $x875 $x1086))))
(assert
 (let (($x1078 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x877 (= real_owner __dir.hptr)))
 (or $x877 $x1078))))
(assert
 (let (($x1082 (not (= (cache.state_ @V1) exclusive))))
 (let (($x879 (= @V1 __dir.hptr)))
 (or $x879 $x1082))))
(assert
 (let (($x1139 (= dir.hptr real_owner)))
 (or $x1139 (not (= (cache.state_ dir.hptr) shared)))))
(assert
 (let (($x778 (= real_owner real_owner)))
 (or $x778 (not (= (cache.state_ real_owner) shared)))))
(assert
 (let (($x416 (= @V1 real_owner)))
 (or $x416 (not (= (cache.state_ @V1) shared)))))
(assert
 (let (($x924 (not (net.putX real_owner __dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x924))))
(assert
 (let (($x926 (not (net.putX real_owner dir.hptr))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x926))))
(assert
 (let (($x928 (not (net.putX real_owner real_owner))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x928))))
(assert
 (let (($x930 (not (net.putX real_owner @V1))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x930))))
(assert
 (let (($x932 (not (net.putX real_owner home))))
 (let (($x777 (= real_owner home)))
 (or $x777 $x932))))
(assert
 (let (($x886 (not (= (cache.state_ __dir.hptr) shared))))
 (let (($x936 (not (rp_net __dir.hptr))))
 (or $x936 $x886))))
(assert
 (let (($x889 (not (= (cache.state_ home) shared))))
 (let (($x948 (not (rp_net home))))
 (or $x948 $x889))))
(check-sat)
