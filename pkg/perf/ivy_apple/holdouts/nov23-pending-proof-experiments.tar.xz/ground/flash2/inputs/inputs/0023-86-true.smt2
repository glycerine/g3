(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun __cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun __requester () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun requester () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (not (= (__cache.wait real_owner) get)))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) __dir.pending)))
(assert
 (not (net.fack __requester home)))
(assert
 (let ((?x270 (cache.state_ home)))
 (= ?x270 invalid)))
(assert
 (let ((?x272 (__cache.wait home)))
 (= ?x272 none)))
(assert
 (not __dir.pending))
(assert
 dir.dirty)
(assert
 dir.pending)
(assert
 (= requester home))
(assert
 (let ((?x294 (cache.state_ @Y)))
 (let (($x295 (= ?x294 exclusive)))
 (let ((?x289 (cache.state_ @X)))
 (let (($x290 (= ?x289 exclusive)))
 (and $x290 (= (cache.wait @X) none) $x295 (= (cache.wait @Y) none) (not (= @X @Y))))))))
(assert
 (let ((?x291 (cache.wait @X)))
 (= ?x291 (ite (and (= @X home)) get (__cache.wait @X)))))
(assert
 (let ((?x296 (cache.wait @Y)))
 (= ?x296 (ite (and (= @Y home)) get (__cache.wait @Y)))))
(assert
 (let (($x187 (not (net.fack __requester home))))
 (or (= __requester real_owner) $x187)))
(assert
 (let (($x333 (not (= (cache.state_ home) exclusive))))
 (let (($x331 (= home real_owner)))
 (or $x331 $x333))))
(assert
 (let ((?x289 (cache.state_ @X)))
 (let (($x290 (= ?x289 exclusive)))
 (let (($x336 (not $x290)))
 (let (($x335 (= @X real_owner)))
 (or $x335 $x336))))))
(assert
 (let ((?x294 (cache.state_ @Y)))
 (let (($x295 (= ?x294 exclusive)))
 (let (($x339 (not $x295)))
 (let (($x338 (= @Y real_owner)))
 (or $x338 $x339))))))
(assert
 (let (($x333 (not (= (cache.state_ home) exclusive))))
 (or (= home dir.hptr) $x333)))
(assert
 (let ((?x289 (cache.state_ @X)))
 (let (($x290 (= ?x289 exclusive)))
 (let (($x336 (not $x290)))
 (or (= @X dir.hptr) $x336)))))
(assert
 (let ((?x294 (cache.state_ @Y)))
 (let (($x295 (= ?x294 exclusive)))
 (let (($x339 (not $x295)))
 (or (= @Y dir.hptr) $x339)))))
(assert
 (let (($x348 (not (= (cache.state_ home) shared))))
 (let (($x331 (= home real_owner)))
 (or $x331 $x348))))
(assert
 (let (($x351 (not (= (cache.state_ @X) shared))))
 (let (($x335 (= @X real_owner)))
 (or $x335 $x351))))
(assert
 (let (($x354 (not (= (cache.state_ @Y) shared))))
 (let (($x338 (= @Y real_owner)))
 (or $x338 $x354))))
(assert
 (let (($x348 (not (= (cache.state_ home) shared))))
 (or (not (rp_net home)) $x348)))
(assert
 (let (($x351 (not (= (cache.state_ @X) shared))))
 (or (not (rp_net @X)) $x351)))
(assert
 (let (($x354 (not (= (cache.state_ @Y) shared))))
 (or (not (rp_net @Y)) $x354)))
(assert
 (let (($x348 (not (= (cache.state_ home) shared))))
 (let (($x366 (not (invack home))))
 (or $x366 $x348))))
(assert
 (let (($x351 (not (= (cache.state_ @X) shared))))
 (let (($x369 (not (invack @X))))
 (or $x369 $x351))))
(assert
 (let (($x354 (not (= (cache.state_ @Y) shared))))
 (let (($x372 (not (invack @Y))))
 (or $x372 $x354))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x375))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378))))
(assert
 (let (($x382 (not (__net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x380 (not $x58)))
 (or $x380 $x382)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x380 (not $x58)))
 (or $x380 dir.head))))
(assert
 (let (($x387 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x387))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x389 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x389 $x378)))))
(assert
 (let (($x387 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x391 (= dir.hptr __requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x391 $x387)))))
(assert
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (let (($x331 (= home real_owner)))
 (or (dir.real home) $x331 $x271)))))
(assert
 (let ((?x289 (cache.state_ @X)))
 (let (($x396 (= ?x289 invalid)))
 (let (($x335 (= @X real_owner)))
 (or (dir.real @X) $x335 $x396)))))
(assert
 (let ((?x294 (cache.state_ @Y)))
 (let (($x399 (= ?x294 invalid)))
 (let (($x338 (= @Y real_owner)))
 (or (dir.real @Y) $x338 $x399)))))
(assert
 (let ((?x385 (cache.state_ dir.hptr)))
 (let (($x402 (= ?x385 invalid)))
 (let (($x145 (= dir.hptr real_owner)))
 (or (dir.real dir.hptr) $x145 $x402)))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x375))))
(assert
 (let (($x142 (not (= (__cache.wait real_owner) get))))
 (let (($x407 (not (= (cache.state_ real_owner) shared))))
 (or $x407 $x142))))
(assert
 (let (($x348 (not (= (cache.state_ home) shared))))
 (or $x348 (not (= (__cache.wait home) get)))))
(assert
 (let (($x351 (not (= (cache.state_ @X) shared))))
 (or $x351 (not (= (__cache.wait @X) get)))))
(assert
 (let (($x354 (not (= (cache.state_ @Y) shared))))
 (or $x354 (not (= (__cache.wait @Y) get)))))
(assert
 (let (($x366 (not (invack home))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x366)))))
(assert
 (let (($x369 (not (invack @X))))
 (let ((?x289 (cache.state_ @X)))
 (let (($x396 (= ?x289 invalid)))
 (or $x396 $x369)))))
(assert
 (let (($x372 (not (invack @Y))))
 (let ((?x294 (cache.state_ @Y)))
 (let (($x399 (= ?x294 invalid)))
 (or $x399 $x372)))))
(assert
 (let (($x333 (not (= (cache.state_ home) exclusive))))
 (or $x333 dir.head)))
(assert
 (let ((?x289 (cache.state_ @X)))
 (let (($x290 (= ?x289 exclusive)))
 (let (($x336 (not $x290)))
 (or $x336 dir.head)))))
(assert
 (let ((?x294 (cache.state_ @Y)))
 (let (($x295 (= ?x294 exclusive)))
 (let (($x339 (not $x295)))
 (or $x339 dir.head)))))
(assert
 (let (($x387 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x387 dir.head)))
(assert
 (let (($x426 (not (= (cache.state_ real_owner) exclusive))))
 (or $x426 dir.head)))
(assert
 (let (($x187 (not (net.fack __requester home))))
 (let (($x428 (= home home)))
 (or $x428 $x187))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x431 (= ?x430 getX)))
 (or $x431 $x375)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x433 (= ?x430 get)))
 (or $x433 $x378)))))
(assert
 (let (($x382 (not (__net.get dir.hptr home))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x433 (= ?x430 get)))
 (or $x433 $x382)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let ((?x385 (cache.state_ dir.hptr)))
 (let (($x402 (= ?x385 invalid)))
 (or $x402 $x378)))))
(assert
 (let (($x382 (not (__net.get dir.hptr home))))
 (let ((?x385 (cache.state_ dir.hptr)))
 (let (($x402 (= ?x385 invalid)))
 (or $x402 $x382)))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x431 (= ?x430 getX)))
 (or $x431 $x375)))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x438 (= ?x140 getX)))
 (or $x438 $x440)))))
(assert
 (let (($x444 (not (net.getX home home))))
 (let ((?x272 (__cache.wait home)))
 (let (($x442 (= ?x272 getX)))
 (or $x442 $x444)))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (let ((?x321 (__cache.wait @X)))
 (let (($x446 (= ?x321 getX)))
 (or $x446 $x448)))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (let ((?x326 (__cache.wait @Y)))
 (let (($x450 (= ?x326 getX)))
 (or $x450 $x452)))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x431 (= ?x430 getX)))
 (or $x431 $x455)))))
(assert
 (let (($x426 (not (= (cache.state_ real_owner) exclusive))))
 (or $x426 (not (= (__cache.wait real_owner) getX)))))
(assert
 (let (($x333 (not (= (cache.state_ home) exclusive))))
 (or $x333 (not (= (__cache.wait home) getX)))))
(assert
 (let ((?x289 (cache.state_ @X)))
 (let (($x290 (= ?x289 exclusive)))
 (let (($x336 (not $x290)))
 (or $x336 (not (= (__cache.wait @X) getX)))))))
(assert
 (let ((?x294 (cache.state_ @Y)))
 (let (($x295 (= ?x294 exclusive)))
 (let (($x339 (not $x295)))
 (or $x339 (not (= (__cache.wait @Y) getX)))))))
(assert
 (let (($x387 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x387 (not (= (__cache.wait dir.hptr) getX)))))
(assert
 (let (($x468 (not (rp_net dir.hptr))))
 (let (($x378 (not (net.put home dir.hptr))))
 (or $x378 $x468))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x433 (= ?x430 get)))
 (or $x433 $x378)))))
(assert
 (let (($x382 (not (__net.get dir.hptr home))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x433 (= ?x430 get)))
 (or $x433 $x382)))))
(assert
 (not (net.getX home home)))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x378)))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x375)))))
(assert
 (let (($x382 (not (__net.get dir.hptr home))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x382)))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x440)))))
(assert
 (let (($x444 (not (net.getX home home))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x444)))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x448)))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x452)))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x455)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x428 (= home home)))
 (or $x428 $x378 dir.dirty))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x428 (= home home)))
 (or $x428 $x375 dir.head))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x428 (= home home)))
 (or $x428 $x375 dir.dirty))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x428 (= home home)))
 (or $x428 $x375))))
(assert
 (let (($x382 (not (__net.get dir.hptr home))))
 (let (($x428 (= home home)))
 (or $x428 $x382 dir.head))))
(assert
 (let (($x382 (not (__net.get dir.hptr home))))
 (let (($x428 (= home home)))
 (or $x428 $x382 dir.dirty))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (let (($x428 (= home home)))
 (or $x428 $x440 dir.head))))
(assert
 (let (($x444 (not (net.getX home home))))
 (let (($x428 (= home home)))
 (or $x428 $x444 dir.head))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (let (($x428 (= home home)))
 (or $x428 $x448 dir.head))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (let (($x428 (= home home)))
 (or $x428 $x452 dir.head))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (let (($x428 (= home home)))
 (or $x428 $x455 dir.head))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (let (($x428 (= home home)))
 (or $x428 $x440 dir.dirty))))
(assert
 (let (($x444 (not (net.getX home home))))
 (let (($x428 (= home home)))
 (or $x428 $x444 dir.dirty))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (let (($x428 (= home home)))
 (or $x428 $x448 dir.dirty))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (let (($x428 (= home home)))
 (or $x428 $x452 dir.dirty))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (let (($x428 (= home home)))
 (or $x428 $x455 dir.dirty))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (let (($x428 (= home home)))
 (or $x428 $x440))))
(assert
 (let (($x444 (not (net.getX home home))))
 (let (($x428 (= home home)))
 (or $x428 $x444))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (let (($x428 (= home home)))
 (or $x428 $x448))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (let (($x428 (= home home)))
 (or $x428 $x452))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (let (($x428 (= home home)))
 (or $x428 $x455))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (let (($x428 (= home home)))
 (or (= real_owner __requester) $x428 $x440))))
(assert
 (let (($x444 (not (net.getX home home))))
 (let (($x428 (= home home)))
 (or (= home __requester) $x428 $x444))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (let (($x428 (= home home)))
 (or (= @X __requester) $x428 $x448))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (let (($x428 (= home home)))
 (or (= @Y __requester) $x428 $x452))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (let (($x428 (= home home)))
 (let (($x391 (= dir.hptr __requester)))
 (or $x391 $x428 $x455)))))
(assert
 (let (($x387 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x387))))
(assert
 (let (($x426 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x509 (= real_owner real_owner)))
 (or $x509 $x426))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x511 (= dir.hptr dir.hptr)))
 (or $x511 $x375))))
(assert
 (let (($x387 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x511 (= dir.hptr dir.hptr)))
 (or $x511 $x387))))
(assert
 (let (($x426 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x514 (= real_owner dir.hptr)))
 (or $x514 $x426))))
(assert
 (let (($x517 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x517))))
(assert
 (let (($x407 (not (= (cache.state_ real_owner) shared))))
 (let (($x509 (= real_owner real_owner)))
 (or $x509 $x407))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x428 (= home home)))
 (or $x428 $x375))))
(assert
 (let (($x517 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x468 (not (rp_net dir.hptr))))
 (or $x468 $x517))))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (let (($x514 (= real_owner dir.hptr)))
 (or $x514 $x375))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (or $x378 dir.head)))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (or $x375 dir.head)))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (or $x375 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x375 (not (net.putX home dir.hptr))))
 (or $x375 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x468 (not (rp_net dir.hptr))))
 (let (($x378 (not (net.put home dir.hptr))))
 (or $x378 $x468))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (__net.get home home)))
(assert
 (let (($x366 (not (invack home))))
 (or $x366 (not (invnet home)))))
(assert
 (let (($x369 (not (invack @X))))
 (or $x369 (not (invnet @X)))))
(assert
 (let (($x372 (not (invack @Y))))
 (or $x372 (not (invnet @Y)))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378 __dir.pending))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x528 __dir.pending))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378 dir.dirty))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x528 dir.dirty))))
(assert
 (let (($x378 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x378))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x528))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let (($x389 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x389 $x528)))))
(assert
 (let (($x517 (not (= (cache.state_ dir.hptr) shared))))
 (or $x517 (not (= (__cache.wait dir.hptr) get)))))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x431 (= ?x430 getX)))
 (or $x431 $x526)))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (let ((?x140 (__cache.wait real_owner)))
 (let (($x438 (= ?x140 getX)))
 (or $x438 $x440)))))
(assert
 (let (($x444 (not (net.getX home home))))
 (let ((?x272 (__cache.wait home)))
 (let (($x442 (= ?x272 getX)))
 (or $x442 $x444)))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (let ((?x321 (__cache.wait @X)))
 (let (($x446 (= ?x321 getX)))
 (or $x446 $x448)))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (let ((?x326 (__cache.wait @Y)))
 (let (($x450 (= ?x326 getX)))
 (or $x450 $x452)))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x431 (= ?x430 getX)))
 (or $x431 $x455)))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let ((?x430 (__cache.wait dir.hptr)))
 (let (($x433 (= ?x430 get)))
 (or $x433 $x528)))))
(assert
 (let (($x530 (not (__net.get home home))))
 (let ((?x272 (__cache.wait home)))
 (let (($x409 (= ?x272 get)))
 (or $x409 $x530)))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let ((?x385 (cache.state_ dir.hptr)))
 (let (($x402 (= ?x385 invalid)))
 (or $x402 $x528)))))
(assert
 (let (($x530 (not (__net.get home home))))
 (let ((?x270 (cache.state_ home)))
 (let (($x271 (= ?x270 invalid)))
 (or $x271 $x530)))))
(assert
 (let (($x440 (not (net.getX real_owner home))))
 (or $x440 (not (= (__cache.wait real_owner) none)))))
(assert
 (let (($x444 (not (net.getX home home))))
 (or $x444 (not (= (__cache.wait home) none)))))
(assert
 (let (($x448 (not (net.getX @X home))))
 (or $x448 (not (= (__cache.wait @X) none)))))
(assert
 (let (($x452 (not (net.getX @Y home))))
 (or $x452 (not (= (__cache.wait @Y) none)))))
(assert
 (let (($x455 (not (net.getX dir.hptr home))))
 (or $x455 (not (= (__cache.wait dir.hptr) none)))))
(assert
 (let (($x530 (not (__net.get home home))))
 (let ((?x272 (__cache.wait home)))
 (let (($x409 (= ?x272 get)))
 (or $x409 $x530)))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x389 (= dir.hptr home)))
 (or $x389 $x145 $x528)))))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (let (($x509 (= real_owner real_owner)))
 (let (($x568 (= real_owner home)))
 (or $x568 $x509 $x526)))))
(assert
 (let (($x530 (not (__net.get home home))))
 (let (($x331 (= home real_owner)))
 (let (($x428 (= home home)))
 (or $x428 $x331 $x530)))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (let (($x389 (= dir.hptr home)))
 (or $x389 $x528 dir.dirty))))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (let (($x568 (= real_owner home)))
 (or $x568 $x526 dir.head))))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (let (($x568 (= real_owner home)))
 (or $x568 $x526 dir.dirty))))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (let (($x568 (= real_owner home)))
 (or $x568 $x526))))
(assert
 (let (($x530 (not (__net.get home home))))
 (let (($x428 (= home home)))
 (or $x428 $x530 dir.head))))
(assert
 (let (($x530 (not (__net.get home home))))
 (let (($x428 (= home home)))
 (or $x428 $x530 dir.dirty))))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (let (($x568 (= real_owner home)))
 (or $x568 $x526))))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (let (($x514 (= real_owner dir.hptr)))
 (or $x514 $x526))))
(assert
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (or $x528 dir.head)))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (or $x526 dir.head)))
(assert
 (let (($x526 (not (net.putX real_owner dir.hptr))))
 (or $x526 dir.dirty)))
(assert
 (let (($x468 (not (rp_net dir.hptr))))
 (let (($x528 (not (net.put dir.hptr dir.hptr))))
 (or $x528 $x468))))
(check-sat)
