(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun requester () id)
(declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun nakc () Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun invack (id) Bool)
(declare-fun dir.real (id) Bool)
(declare-fun invnet (id) Bool)
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 (not dir.head))))
(assert
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (not $x141))))
(assert
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 (not dir.dirty) dir.pending)))
(assert
 (not (net.fack requester home)))
(assert
 (__net.getX __src __dst))
(assert
 (not (= __dst __src)))
(assert
 (let (($x275 (= __dst home)))
 (not $x275)))
(assert
 (not (= (cache.state_ __dst) exclusive)))
(assert
 nakc)
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x59 (or $x58 (not dir.head))))
 (let (($x351 (net.getX @X @Z)))
 (let (($x352 (not $x351)))
 (let (($x361 (= @Y @Z)))
 (let (($x374 (and (or $x361 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x361 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x361 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x361 (not (net.getX @X @Y)) $x352) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x352 (not (net.putX @Y @X))) (not (net.getX home @Y)) $x59 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x335 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x374))))))))))
(assert
 (let (($x398 (__net.getX @X @Y)))
 (let (($x359 (net.getX @X @Y)))
 (= $x359 (ite (and (= @X __src) (= @Y __dst)) false $x398)))))
(assert
 (let (($x403 (__net.getX @X @Z)))
 (let (($x351 (net.getX @X @Z)))
 (= $x351 (ite (and (= @X __src) (= @Z __dst)) false $x403)))))
(assert
 (let (($x408 (__net.getX home @Y)))
 (let (($x372 (net.getX home @Y)))
 (= $x372 (ite (and (= home __src) (= @Y __dst)) false $x408)))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x330 (net.getX @X home)))
 (= $x330 (ite (and (= @X __src) (= home __dst)) false $x413)))))
(assert
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x319 (net.getX @V1 @V0)))
 (= $x319 (ite (and (= @V1 __src) (= @V0 __dst)) false $x419)))))
(assert
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x299 (net.getX @V0 @V1)))
 (= $x299 (ite (and (= @V0 __src) (= @V1 __dst)) false $x425)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x428 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x428 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x431 (= @Z real_owner)))
 (let (($x430 (= @Z home)))
 (or $x430 $x431 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x436 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x436 $x303)))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x428 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x428 $x349)))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x431 (= @Z real_owner)))
 (let (($x430 (= @Z home)))
 (or $x430 $x431 $x364)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x436 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x436 $x297)))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let (($x428 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x428 $x367)))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let (($x431 (= @Z real_owner)))
 (let (($x430 (= @Z home)))
 (or $x430 $x431 $x357)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x436 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x436 $x307)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x447 (not $x272)))
 (let (($x446 (= __dst real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x446 $x447))))))
(assert
 (let (($x398 (__net.getX @X @Y)))
 (let (($x449 (not $x398)))
 (let (($x428 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x428 $x449))))))
(assert
 (let (($x403 (__net.getX @X @Z)))
 (let (($x451 (not $x403)))
 (let (($x431 (= @Z real_owner)))
 (let (($x430 (= @Z home)))
 (or $x430 $x431 $x451))))))
(assert
 (let (($x408 (__net.getX home @Y)))
 (let (($x453 (not $x408)))
 (let (($x428 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x428 $x453))))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x455))))))
(assert
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x459 (not $x419)))
 (let (($x458 (= @V0 real_owner)))
 (let (($x457 (= @V0 home)))
 (or $x457 $x458 $x459))))))
(assert
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x461 (not $x425)))
 (let (($x436 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x436 $x461))))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x355 dir.dirty))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x430 (= @Z home)))
 (or $x430 $x370 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x433 (= home home)))
 (or $x433 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x303 dir.dirty))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349 dir.head))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x430 (= @Z home)))
 (or $x430 $x364 dir.head))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x433 (= home home)))
 (or $x433 $x326 dir.head))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.head))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349 dir.dirty))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x430 (= @Z home)))
 (or $x430 $x364 dir.dirty))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x433 (= home home)))
 (or $x433 $x326 dir.dirty))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297 dir.dirty))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x430 (= @Z home)))
 (or $x430 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x433 (= home home)))
 (or $x433 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x367 dir.head))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let (($x430 (= @Z home)))
 (or $x430 $x357 dir.head))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x433 (= home home)))
 (or $x433 $x346 dir.head))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x307 dir.head))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x367 dir.dirty))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let (($x430 (= @Z home)))
 (or $x430 $x357 dir.dirty))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x433 (= home home)))
 (or $x433 $x346 dir.dirty))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x307 dir.dirty))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x447 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x447 dir.head)))))
(assert
 (let (($x398 (__net.getX @X @Y)))
 (let (($x449 (not $x398)))
 (let (($x314 (= @Y home)))
 (or $x314 $x449 dir.head)))))
(assert
 (let (($x403 (__net.getX @X @Z)))
 (let (($x451 (not $x403)))
 (let (($x430 (= @Z home)))
 (or $x430 $x451 dir.head)))))
(assert
 (let (($x408 (__net.getX home @Y)))
 (let (($x453 (not $x408)))
 (let (($x314 (= @Y home)))
 (or $x314 $x453 dir.head)))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (let (($x433 (= home home)))
 (or $x433 $x455 dir.head)))))
(assert
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x459 (not $x419)))
 (let (($x457 (= @V0 home)))
 (or $x457 $x459 dir.head)))))
(assert
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x461 (not $x425)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x461 dir.head)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x447 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x447 dir.dirty)))))
(assert
 (let (($x398 (__net.getX @X @Y)))
 (let (($x449 (not $x398)))
 (let (($x314 (= @Y home)))
 (or $x314 $x449 dir.dirty)))))
(assert
 (let (($x403 (__net.getX @X @Z)))
 (let (($x451 (not $x403)))
 (let (($x430 (= @Z home)))
 (or $x430 $x451 dir.dirty)))))
(assert
 (let (($x408 (__net.getX home @Y)))
 (let (($x453 (not $x408)))
 (let (($x314 (= @Y home)))
 (or $x314 $x453 dir.dirty)))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (let (($x433 (= home home)))
 (or $x433 $x455 dir.dirty)))))
(assert
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x459 (not $x419)))
 (let (($x457 (= @V0 home)))
 (or $x457 $x459 dir.dirty)))))
(assert
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x461 (not $x425)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x461 dir.dirty)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x447 (not $x272)))
 (let (($x275 (= __dst home)))
 (or $x275 $x447)))))
(assert
 (let (($x398 (__net.getX @X @Y)))
 (let (($x449 (not $x398)))
 (let (($x314 (= @Y home)))
 (or $x314 $x449)))))
(assert
 (let (($x403 (__net.getX @X @Z)))
 (let (($x451 (not $x403)))
 (let (($x430 (= @Z home)))
 (or $x430 $x451)))))
(assert
 (let (($x408 (__net.getX home @Y)))
 (let (($x453 (not $x408)))
 (let (($x314 (= @Y home)))
 (or $x314 $x453)))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (let (($x433 (= home home)))
 (or $x433 $x455)))))
(assert
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x459 (not $x419)))
 (let (($x457 (= @V0 home)))
 (or $x457 $x459)))))
(assert
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x461 (not $x425)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x461)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x447 (not $x272)))
 (let (($x275 (= __dst home)))
 (let (($x508 (= __src requester)))
 (or $x508 $x275 $x447))))))
(assert
 (let (($x398 (__net.getX @X @Y)))
 (let (($x449 (not $x398)))
 (let (($x314 (= @Y home)))
 (let (($x510 (= @X requester)))
 (or $x510 $x314 $x449))))))
(assert
 (let (($x403 (__net.getX @X @Z)))
 (let (($x451 (not $x403)))
 (let (($x430 (= @Z home)))
 (let (($x510 (= @X requester)))
 (or $x510 $x430 $x451))))))
(assert
 (let (($x408 (__net.getX home @Y)))
 (let (($x453 (not $x408)))
 (let (($x314 (= @Y home)))
 (let (($x513 (= home requester)))
 (or $x513 $x314 $x453))))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (let (($x433 (= home home)))
 (let (($x510 (= @X requester)))
 (or $x510 $x433 $x455))))))
(assert
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x459 (not $x419)))
 (let (($x457 (= @V0 home)))
 (let (($x516 (= @V1 requester)))
 (or $x516 $x457 $x459))))))
(assert
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x461 (not $x425)))
 (let (($x289 (= @V1 home)))
 (let (($x518 (= @V0 requester)))
 (or $x518 $x289 $x461))))))
(assert
 (let (($x187 (not (net.fack requester home))))
 (or (= requester real_owner) $x187)))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x458 (= @V0 real_owner)))
 (or $x458 $x292))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x446 (= __dst real_owner)))
 (or $x446 $x279))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x524 (= @X real_owner)))
 (or $x524 $x335))))
(assert
 (let (($x527 (not (= (cache.state_ @V0) exclusive))))
 (let (($x458 (= @V0 real_owner)))
 (or $x458 $x527))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x529 (= @X dir.hptr)))
 (or $x529 $x326))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x531 (= @V0 dir.hptr)))
 (or $x531 $x533))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x535 (= __dst dir.hptr)))
 (or $x535 $x279))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x529 (= @X dir.hptr)))
 (or $x529 $x335))))
(assert
 (let (($x527 (not (= (cache.state_ @V0) exclusive))))
 (let (($x531 (= @V0 dir.hptr)))
 (or $x531 $x527))))
(assert
 (let (($x540 (not (= (cache.state_ __dst) shared))))
 (let (($x446 (= __dst real_owner)))
 (or $x446 $x540))))
(assert
 (let (($x543 (not (= (cache.state_ @X) shared))))
 (let (($x524 (= @X real_owner)))
 (or $x524 $x543))))
(assert
 (let (($x546 (not (= (cache.state_ @V0) shared))))
 (let (($x458 (= @V0 real_owner)))
 (or $x458 $x546))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x314 (= @Y home)))
 (or $x314 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x430 (= @Z home)))
 (or $x430 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x433 (= home home)))
 (or $x433 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x297))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x433 (= home home)))
 (or $x433 $x533))))
(assert
 (let (($x543 (not (= (cache.state_ @X) shared))))
 (let (($x339 (not (rp_net @X))))
 (or $x339 $x543))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let (($x550 (= real_owner @X)))
 (or $x550 $x349))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let (($x550 (= real_owner @X)))
 (or $x550 $x364))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x550 (= real_owner @X)))
 (or $x550 $x326))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let (($x554 (= real_owner @V0)))
 (or $x554 $x297))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x554 (= real_owner @V0)))
 (or $x554 $x533))))
(assert
 (not (net.shwb @X home)))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (or $x355 dir.head)))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (or $x370 dir.head)))
(assert
 (let (($x341 (not (net.put home @X))))
 (or $x341 dir.head)))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 dir.head)))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (or $x349 dir.head)))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (or $x364 dir.head)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.head)))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (or $x533 dir.head)))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (or $x349 dir.dirty)))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (or $x364 dir.dirty)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.dirty)))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (or $x297 dir.dirty)))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (or $x533 dir.dirty)))
(assert
 (not (net.putX real_owner @X)))
(assert
 (not (net.putX real_owner @V0)))
(assert
 (let (($x326 (not (net.putX home @X))))
 (or $x326 dir.head)))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (or $x533 dir.head)))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x355 (not (net.put @Y @X))))
 (or $x355 $x339))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x370 (not (net.put @Z @X))))
 (or $x370 $x339))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x339))))
(assert
 (let (($x580 (not (rp_net @V0))))
 (let (($x303 (not (net.put @V1 @V0))))
 (or $x303 $x580))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (not (net.get home @Y)))
(assert
 (not (net.get home @Z)))
(assert
 (not (net.get home home)))
(assert
 (not (net.get home @V1)))
(assert
 (let (($x540 (not (= (cache.state_ __dst) shared))))
 (let (($x597 (not (invack __dst))))
 (or $x597 $x540))))
(assert
 (let (($x543 (not (= (cache.state_ @X) shared))))
 (let (($x600 (not (invack @X))))
 (or $x600 $x543))))
(assert
 (let (($x546 (not (= (cache.state_ @V0) shared))))
 (let (($x603 (not (invack @V0))))
 (or $x603 $x546))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x355 dir.pending))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x370 dir.pending))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x341 dir.pending))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x303 dir.pending))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x583 dir.pending))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x585 dir.pending))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x587 dir.pending))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x355 dir.dirty))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x370 dir.dirty))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x341 dir.dirty))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x303 dir.dirty))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x583 dir.dirty))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x585 dir.dirty))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x587 dir.dirty))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x355))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x370))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x341))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x303))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x583))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x585))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x587))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x629))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x326))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x533))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x634))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x341))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x583))))
(assert
 (let (($x638 (not (net.get dir.hptr home))))
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x636 (not $x58)))
 (or $x636 $x638)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let (($x605 (dir.shlist @X)))
 (let (($x640 (not $x605)))
 (or $x640 $x346)))))
(assert
 (let (($x644 (not (net.get @V0 home))))
 (let (($x609 (dir.shlist @V0)))
 (let (($x642 (not $x609)))
 (or $x642 $x644)))))
(assert
 (let (($x58 (dir.shlist dir.hptr)))
 (let (($x636 (not $x58)))
 (or $x636 dir.head))))
(assert
 (let (($x605 (dir.shlist @X)))
 (let (($x640 (not $x605)))
 (or $x640 dir.head))))
(assert
 (let (($x609 (dir.shlist @V0)))
 (let (($x642 (not $x609)))
 (or $x642 dir.head))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x279))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x335))))
(assert
 (let (($x527 (not (= (cache.state_ @V0) exclusive))))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x527))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let (($x653 (= @X home)))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x653 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let (($x653 (= @X home)))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x653 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let (($x653 (= @X home)))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x653 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let (($x457 (= @V0 home)))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x457 $x303)))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let (($x457 (= @V0 home)))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x457 $x583)))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let (($x653 (= @X home)))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x653 $x585)))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let (($x457 (= @V0 home)))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x457 $x587)))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let (($x661 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x661 $x634)))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (let (($x663 (= __dst requester)))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x663 $x279)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (let (($x510 (= @X requester)))
 (let (($x605 (dir.shlist @X)))
 (or $x605 $x510 $x335)))))
(assert
 (let (($x527 (not (= (cache.state_ @V0) exclusive))))
 (let (($x518 (= @V0 requester)))
 (let (($x609 (dir.shlist @V0)))
 (or $x609 $x518 $x527)))))
(assert
 (let ((?x277 (cache.state_ __dst)))
 (let (($x668 (= ?x277 invalid)))
 (let (($x446 (= __dst real_owner)))
 (or (dir.real __dst) $x446 $x668)))))
(assert
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (let (($x524 (= @X real_owner)))
 (or (dir.real @X) $x524 $x671)))))
(assert
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (let (($x458 (= @V0 real_owner)))
 (or (dir.real @V0) $x458 $x310)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x326))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x533))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x629))))
(assert
 (let (($x540 (not (= (cache.state_ __dst) shared))))
 (or $x540 (not (= (cache.wait __dst) get)))))
(assert
 (let (($x543 (not (= (cache.state_ @X) shared))))
 (or $x543 (not (= (cache.wait @X) get)))))
(assert
 (let (($x546 (not (= (cache.state_ @V0) shared))))
 (or $x546 (not (= (cache.wait @V0) get)))))
(assert
 (let (($x597 (not (invack __dst))))
 (let ((?x277 (cache.state_ __dst)))
 (let (($x668 (= ?x277 invalid)))
 (or $x668 $x597)))))
(assert
 (let (($x600 (not (invack @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x600)))))
(assert
 (let (($x603 (not (invack @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x603)))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (or $x279 dir.head)))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 dir.head)))
(assert
 (let (($x527 (not (= (cache.state_ @V0) exclusive))))
 (or $x527 dir.head)))
(assert
 (let (($x187 (not (net.fack requester home))))
 (let (($x433 (= home home)))
 (or $x433 $x187))))
(assert
 (let (($x292 (not (net.fack @V0 @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x292))))
(assert
 (let (($x349 (not (net.putX @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x349)))))
(assert
 (let (($x364 (not (net.putX @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x364)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x297 (not (net.putX @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x297)))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x533)))))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x574)))))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x576)))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x699 (= ?x698 getX)))
 (or $x699 $x629)))))
(assert
 (let (($x272 (__net.getX __src __dst)))
 (let (($x447 (not $x272)))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 getX)))
 (or $x702 $x447))))))
(assert
 (let (($x398 (__net.getX @X @Y)))
 (let (($x449 (not $x398)))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x449))))))
(assert
 (let (($x403 (__net.getX @X @Z)))
 (let (($x451 (not $x403)))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x451))))))
(assert
 (let (($x408 (__net.getX home @Y)))
 (let (($x453 (not $x408)))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x453))))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x455))))))
(assert
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x459 (not $x419)))
 (let ((?x321 (cache.wait @V1)))
 (let (($x710 (= ?x321 getX)))
 (or $x710 $x459))))))
(assert
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x461 (not $x425)))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x461))))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x303)))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x583)))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x585)))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x587)))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x718 (= ?x698 get)))
 (or $x718 $x634)))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x367)))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x357)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x307)))))
(assert
 (let (($x589 (not (net.get home @Y))))
 (let ((?x706 (cache.wait home)))
 (let (($x722 (= ?x706 get)))
 (or $x722 $x589)))))
(assert
 (let (($x591 (not (net.get home @Z))))
 (let ((?x706 (cache.wait home)))
 (let (($x722 (= ?x706 get)))
 (or $x722 $x591)))))
(assert
 (let (($x593 (not (net.get home home))))
 (let ((?x706 (cache.wait home)))
 (let (($x722 (= ?x706 get)))
 (or $x722 $x593)))))
(assert
 (let (($x595 (not (net.get home @V1))))
 (let ((?x706 (cache.wait home)))
 (let (($x722 (= ?x706 get)))
 (or $x722 $x595)))))
(assert
 (let (($x355 (not (net.put @Y @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x355)))))
(assert
 (let (($x370 (not (net.put @Z @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x370)))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x341)))))
(assert
 (let (($x303 (not (net.put @V1 @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x303)))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x583)))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x585)))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x587)))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let ((?x733 (cache.state_ dir.hptr)))
 (let (($x734 (= ?x733 invalid)))
 (or $x734 $x634)))))
(assert
 (let (($x367 (not (net.get @X @Y))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x367)))))
(assert
 (let (($x357 (not (net.get @X @Z))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x357)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x333 (cache.state_ @X)))
 (let (($x671 (= ?x333 invalid)))
 (or $x671 $x346)))))
(assert
 (let (($x307 (not (net.get @V0 @V1))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x307)))))
(assert
 (let (($x589 (not (net.get home @Y))))
 (let ((?x739 (cache.state_ home)))
 (let (($x740 (= ?x739 invalid)))
 (or $x740 $x589)))))
(assert
 (let (($x591 (not (net.get home @Z))))
 (let ((?x739 (cache.state_ home)))
 (let (($x740 (= ?x739 invalid)))
 (or $x740 $x591)))))
(assert
 (let (($x593 (not (net.get home home))))
 (let ((?x739 (cache.state_ home)))
 (let (($x740 (= ?x739 invalid)))
 (or $x740 $x593)))))
(assert
 (let (($x595 (not (net.get home @V1))))
 (let ((?x739 (cache.state_ home)))
 (let (($x740 (= ?x739 invalid)))
 (or $x740 $x595)))))
(assert
 (let (($x314 (= @Y home)))
 (or $x314 (not (net.shwb @X @Y)))))
(assert
 (let (($x433 (= home home)))
 (or $x433 (not (net.shwb @X home)))))
(assert
 (let (($x747 (not (= (cache.wait __src) none))))
 (let (($x272 (__net.getX __src __dst)))
 (let (($x447 (not $x272)))
 (or $x447 $x747)))))
(assert
 (let (($x750 (not (= (cache.wait @X) none))))
 (let (($x398 (__net.getX @X @Y)))
 (let (($x449 (not $x398)))
 (or $x449 $x750)))))
(assert
 (let (($x750 (not (= (cache.wait @X) none))))
 (let (($x403 (__net.getX @X @Z)))
 (let (($x451 (not $x403)))
 (or $x451 $x750)))))
(assert
 (let (($x754 (not (= (cache.wait home) none))))
 (let (($x408 (__net.getX home @Y)))
 (let (($x453 (not $x408)))
 (or $x453 $x754)))))
(assert
 (let (($x750 (not (= (cache.wait @X) none))))
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (or $x455 $x750)))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x419 (__net.getX @V1 @V0)))
 (let (($x459 (not $x419)))
 (or $x459 $x323)))))
(assert
 (let (($x759 (not (= (cache.wait @V0) none))))
 (let (($x425 (__net.getX @V0 @V1)))
 (let (($x461 (not $x425)))
 (or $x461 $x759)))))
(assert
 (let (($x326 (not (net.putX home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x326)))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x533)))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x699 (= ?x698 getX)))
 (or $x699 $x629)))))
(assert
 (let (($x762 (not (__net.getX __src home))))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 getX)))
 (or $x702 $x762)))))
(assert
 (let (($x413 (__net.getX @X home)))
 (let (($x455 (not $x413)))
 (let ((?x327 (cache.wait @X)))
 (let (($x328 (= ?x327 getX)))
 (or $x328 $x455))))))
(assert
 (let (($x765 (not (__net.getX home home))))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x765)))))
(assert
 (let (($x768 (not (__net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x710 (= ?x321 getX)))
 (or $x710 $x768)))))
(assert
 (let (($x771 (not (__net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x771)))))
(assert
 (let (($x279 (not (= (cache.state_ __dst) exclusive))))
 (or $x279 (not (= (cache.wait __dst) getX)))))
(assert
 (let (($x335 (not (= (cache.state_ @X) exclusive))))
 (or $x335 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x527 (not (= (cache.state_ @V0) exclusive))))
 (or $x527 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x779 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x779 (not (= (cache.wait dir.hptr) getX)))))
(assert
 (let (($x783 (not (= (cache.state_ home) exclusive))))
 (or $x783 (not (= (cache.wait home) getX)))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x341 (not (net.put home @X))))
 (or $x341 $x339))))
(assert
 (let (($x580 (not (rp_net @V0))))
 (let (($x583 (not (net.put home @V0))))
 (or $x583 $x580))))
(assert
 (let (($x341 (not (net.put home @X))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x341)))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x583)))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x718 (= ?x698 get)))
 (or $x718 $x634)))))
(assert
 (let (($x788 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x788)))))
(assert
 (let (($x346 (not (net.get @X home))))
 (let ((?x327 (cache.wait @X)))
 (let (($x343 (= ?x327 get)))
 (or $x343 $x346)))))
(assert
 (let (($x792 (not (net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x790 (= ?x321 get)))
 (or $x790 $x792)))))
(assert
 (let (($x644 (not (net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x644)))))
(assert
 (let (($x796 (not (net.get __dst home))))
 (let ((?x678 (cache.wait __dst)))
 (let (($x679 (= ?x678 get)))
 (or $x679 $x796)))))
(assert
 (let (($x638 (not (net.get dir.hptr home))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x718 (= ?x698 get)))
 (or $x718 $x638)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let ((?x701 (cache.wait __src)))
 (let (($x799 (= ?x701 get)))
 (or $x799 $x801)))))
(assert
 (let (($x593 (not (net.get home home))))
 (let ((?x706 (cache.wait home)))
 (let (($x722 (= ?x706 get)))
 (or $x722 $x593)))))
(assert
 (not (__net.getX home __dst)))
(assert
 (let (($x408 (__net.getX home @Y)))
 (not $x408)))
(assert
 (not (__net.getX home @Z)))
(assert
 (not (__net.getX home home)))
(assert
 (not (__net.getX home @V0)))
(assert
 (not (__net.getX home @V1)))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x583)))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x661 (= dir.hptr home)))
 (or $x661 $x145 $x585)))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x661 (= dir.hptr home)))
 (or $x661 $x145 $x587)))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x634)))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x533)))))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (let (($x817 (= real_owner real_owner)))
 (let (($x816 (= real_owner home)))
 (or $x816 $x817 $x574)))))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (let (($x817 (= real_owner real_owner)))
 (let (($x816 (= real_owner home)))
 (or $x816 $x817 $x576)))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x629)))))
(assert
 (let (($x589 (not (net.get home @Y))))
 (let (($x428 (= @Y real_owner)))
 (let (($x314 (= @Y home)))
 (or $x314 $x428 $x589)))))
(assert
 (let (($x591 (not (net.get home @Z))))
 (let (($x431 (= @Z real_owner)))
 (let (($x430 (= @Z home)))
 (or $x430 $x431 $x591)))))
(assert
 (let (($x593 (not (net.get home home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x593)))))
(assert
 (let (($x595 (not (net.get home @V1))))
 (let (($x436 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x436 $x595)))))
(assert
 (let (($x638 (not (net.get dir.hptr home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x638)))))
(assert
 (let (($x644 (not (net.get @V0 home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x644)))))
(assert
 (let (($x788 (not (net.get real_owner home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x788)))))
(assert
 (let (($x792 (not (net.get @V1 home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x792)))))
(assert
 (let (($x762 (not (__net.getX __src home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x762)))))
(assert
 (let (($x765 (not (__net.getX home home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x765)))))
(assert
 (let (($x768 (not (__net.getX @V1 home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x768)))))
(assert
 (let (($x771 (not (__net.getX @V0 home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x771)))))
(assert
 (let (($x804 (not (__net.getX home __dst))))
 (let (($x446 (= __dst real_owner)))
 (let (($x275 (= __dst home)))
 (or $x275 $x446 $x804)))))
(assert
 (let (($x806 (not (__net.getX home @Z))))
 (let (($x431 (= @Z real_owner)))
 (let (($x430 (= @Z home)))
 (or $x430 $x431 $x806)))))
(assert
 (let (($x808 (not (__net.getX home @V0))))
 (let (($x458 (= @V0 real_owner)))
 (let (($x457 (= @V0 home)))
 (or $x457 $x458 $x808)))))
(assert
 (let (($x810 (not (__net.getX home @V1))))
 (let (($x436 (= @V1 real_owner)))
 (let (($x289 (= @V1 home)))
 (or $x289 $x436 $x810)))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (let (($x433 (= home home)))
 (or $x433 $x583 dir.dirty))))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (let (($x661 (= dir.hptr home)))
 (or $x661 $x585 dir.dirty))))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (let (($x661 (= dir.hptr home)))
 (or $x661 $x587 dir.dirty))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let (($x433 (= home home)))
 (or $x433 $x634 dir.dirty))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x433 (= home home)))
 (or $x433 $x533 dir.head))))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x574 dir.head))))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x576 dir.head))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x433 (= home home)))
 (or $x433 $x629 dir.head))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x433 (= home home)))
 (or $x433 $x533 dir.dirty))))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x574 dir.dirty))))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x576 dir.dirty))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x433 (= home home)))
 (or $x433 $x629 dir.dirty))))
(assert
 (let (($x533 (not (net.putX home @V0))))
 (let (($x433 (= home home)))
 (or $x433 $x533))))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x574))))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x576))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x433 (= home home)))
 (or $x433 $x629))))
(assert
 (let (($x589 (not (net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x589 dir.head))))
(assert
 (let (($x591 (not (net.get home @Z))))
 (let (($x430 (= @Z home)))
 (or $x430 $x591 dir.head))))
(assert
 (let (($x593 (not (net.get home home))))
 (let (($x433 (= home home)))
 (or $x433 $x593 dir.head))))
(assert
 (let (($x595 (not (net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x595 dir.head))))
(assert
 (let (($x638 (not (net.get dir.hptr home))))
 (let (($x433 (= home home)))
 (or $x433 $x638 dir.head))))
(assert
 (let (($x644 (not (net.get @V0 home))))
 (let (($x433 (= home home)))
 (or $x433 $x644 dir.head))))
(assert
 (let (($x788 (not (net.get real_owner home))))
 (let (($x433 (= home home)))
 (or $x433 $x788 dir.head))))
(assert
 (let (($x792 (not (net.get @V1 home))))
 (let (($x433 (= home home)))
 (or $x433 $x792 dir.head))))
(assert
 (let (($x589 (not (net.get home @Y))))
 (let (($x314 (= @Y home)))
 (or $x314 $x589 dir.dirty))))
(assert
 (let (($x591 (not (net.get home @Z))))
 (let (($x430 (= @Z home)))
 (or $x430 $x591 dir.dirty))))
(assert
 (let (($x593 (not (net.get home home))))
 (let (($x433 (= home home)))
 (or $x433 $x593 dir.dirty))))
(assert
 (let (($x595 (not (net.get home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x595 dir.dirty))))
(assert
 (let (($x638 (not (net.get dir.hptr home))))
 (let (($x433 (= home home)))
 (or $x433 $x638 dir.dirty))))
(assert
 (let (($x644 (not (net.get @V0 home))))
 (let (($x433 (= home home)))
 (or $x433 $x644 dir.dirty))))
(assert
 (let (($x788 (not (net.get real_owner home))))
 (let (($x433 (= home home)))
 (or $x433 $x788 dir.dirty))))
(assert
 (let (($x792 (not (net.get @V1 home))))
 (let (($x433 (= home home)))
 (or $x433 $x792 dir.dirty))))
(assert
 (let (($x762 (not (__net.getX __src home))))
 (let (($x433 (= home home)))
 (or $x433 $x762 dir.head))))
(assert
 (let (($x765 (not (__net.getX home home))))
 (let (($x433 (= home home)))
 (or $x433 $x765 dir.head))))
(assert
 (let (($x768 (not (__net.getX @V1 home))))
 (let (($x433 (= home home)))
 (or $x433 $x768 dir.head))))
(assert
 (let (($x771 (not (__net.getX @V0 home))))
 (let (($x433 (= home home)))
 (or $x433 $x771 dir.head))))
(assert
 (let (($x804 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x804 dir.head))))
(assert
 (let (($x806 (not (__net.getX home @Z))))
 (let (($x430 (= @Z home)))
 (or $x430 $x806 dir.head))))
(assert
 (let (($x808 (not (__net.getX home @V0))))
 (let (($x457 (= @V0 home)))
 (or $x457 $x808 dir.head))))
(assert
 (let (($x810 (not (__net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x810 dir.head))))
(assert
 (let (($x762 (not (__net.getX __src home))))
 (let (($x433 (= home home)))
 (or $x433 $x762 dir.dirty))))
(assert
 (let (($x765 (not (__net.getX home home))))
 (let (($x433 (= home home)))
 (or $x433 $x765 dir.dirty))))
(assert
 (let (($x768 (not (__net.getX @V1 home))))
 (let (($x433 (= home home)))
 (or $x433 $x768 dir.dirty))))
(assert
 (let (($x771 (not (__net.getX @V0 home))))
 (let (($x433 (= home home)))
 (or $x433 $x771 dir.dirty))))
(assert
 (let (($x804 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x804 dir.dirty))))
(assert
 (let (($x806 (not (__net.getX home @Z))))
 (let (($x430 (= @Z home)))
 (or $x430 $x806 dir.dirty))))
(assert
 (let (($x808 (not (__net.getX home @V0))))
 (let (($x457 (= @V0 home)))
 (or $x457 $x808 dir.dirty))))
(assert
 (let (($x810 (not (__net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x810 dir.dirty))))
(assert
 (let (($x762 (not (__net.getX __src home))))
 (let (($x433 (= home home)))
 (or $x433 $x762))))
(assert
 (let (($x765 (not (__net.getX home home))))
 (let (($x433 (= home home)))
 (or $x433 $x765))))
(assert
 (let (($x768 (not (__net.getX @V1 home))))
 (let (($x433 (= home home)))
 (or $x433 $x768))))
(assert
 (let (($x771 (not (__net.getX @V0 home))))
 (let (($x433 (= home home)))
 (or $x433 $x771))))
(assert
 (let (($x804 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (or $x275 $x804))))
(assert
 (let (($x806 (not (__net.getX home @Z))))
 (let (($x430 (= @Z home)))
 (or $x430 $x806))))
(assert
 (let (($x808 (not (__net.getX home @V0))))
 (let (($x457 (= @V0 home)))
 (or $x457 $x808))))
(assert
 (let (($x810 (not (__net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (or $x289 $x810))))
(assert
 (let (($x762 (not (__net.getX __src home))))
 (let (($x433 (= home home)))
 (let (($x508 (= __src requester)))
 (or $x508 $x433 $x762)))))
(assert
 (let (($x765 (not (__net.getX home home))))
 (let (($x433 (= home home)))
 (let (($x513 (= home requester)))
 (or $x513 $x433 $x765)))))
(assert
 (let (($x768 (not (__net.getX @V1 home))))
 (let (($x433 (= home home)))
 (let (($x516 (= @V1 requester)))
 (or $x516 $x433 $x768)))))
(assert
 (let (($x771 (not (__net.getX @V0 home))))
 (let (($x433 (= home home)))
 (let (($x518 (= @V0 requester)))
 (or $x518 $x433 $x771)))))
(assert
 (let (($x804 (not (__net.getX home __dst))))
 (let (($x275 (= __dst home)))
 (let (($x513 (= home requester)))
 (or $x513 $x275 $x804)))))
(assert
 (let (($x806 (not (__net.getX home @Z))))
 (let (($x430 (= @Z home)))
 (let (($x513 (= home requester)))
 (or $x513 $x430 $x806)))))
(assert
 (let (($x808 (not (__net.getX home @V0))))
 (let (($x457 (= @V0 home)))
 (let (($x513 (= home requester)))
 (or $x513 $x457 $x808)))))
(assert
 (let (($x810 (not (__net.getX home @V1))))
 (let (($x289 (= @V1 home)))
 (let (($x513 (= home requester)))
 (or $x513 $x289 $x810)))))
(assert
 (let (($x779 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x779))))
(assert
 (let (($x783 (not (= (cache.state_ home) exclusive))))
 (let (($x434 (= home real_owner)))
 (or $x434 $x783))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x902 (= dir.hptr dir.hptr)))
 (or $x902 $x629))))
(assert
 (let (($x779 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x902 (= dir.hptr dir.hptr)))
 (or $x902 $x779))))
(assert
 (let (($x783 (not (= (cache.state_ home) exclusive))))
 (let (($x905 (= home dir.hptr)))
 (or $x905 $x783))))
(assert
 (let (($x908 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x908))))
(assert
 (let (($x911 (not (= (cache.state_ home) shared))))
 (let (($x434 (= home real_owner)))
 (or $x434 $x911))))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x574))))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x576))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x433 (= home home)))
 (or $x433 $x629))))
(assert
 (let (($x546 (not (= (cache.state_ @V0) shared))))
 (let (($x580 (not (rp_net @V0))))
 (or $x580 $x546))))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (let (($x550 (= real_owner @X)))
 (or $x550 $x574))))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (let (($x554 (= real_owner @V0)))
 (or $x554 $x576))))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (let (($x916 (= real_owner dir.hptr)))
 (or $x916 $x629))))
(assert
 (let (($x583 (not (net.put home @V0))))
 (or $x583 dir.head)))
(assert
 (let (($x585 (not (net.put dir.hptr @X))))
 (or $x585 dir.head)))
(assert
 (let (($x587 (not (net.put dir.hptr @V0))))
 (or $x587 dir.head)))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (or $x634 dir.head)))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (or $x574 dir.head)))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (or $x576 dir.head)))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (or $x629 dir.head)))
(assert
 (let (($x574 (not (net.putX real_owner @X))))
 (or $x574 dir.dirty)))
(assert
 (let (($x576 (not (net.putX real_owner @V0))))
 (or $x576 dir.dirty)))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (or $x629 dir.dirty)))
(assert
 (not (net.putX real_owner dir.hptr)))
(assert
 (let (($x629 (not (net.putX home dir.hptr))))
 (or $x629 dir.head)))
(assert
 (not (net.putX home dir.hptr)))
(assert
 (let (($x580 (not (rp_net @V0))))
 (let (($x583 (not (net.put home @V0))))
 (or $x583 $x580))))
(assert
 (let (($x339 (not (rp_net @X))))
 (let (($x585 (not (net.put dir.hptr @X))))
 (or $x585 $x339))))
(assert
 (let (($x580 (not (rp_net @V0))))
 (let (($x587 (not (net.put dir.hptr @V0))))
 (or $x587 $x580))))
(assert
 (let (($x933 (not (rp_net dir.hptr))))
 (let (($x634 (not (net.put home dir.hptr))))
 (or $x634 $x933))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (let (($x597 (not (invack __dst))))
 (or $x597 (not (invnet __dst)))))
(assert
 (let (($x600 (not (invack @X))))
 (or $x600 (not (invnet @X)))))
(assert
 (let (($x603 (not (invack @V0))))
 (or $x603 (not (invnet @V0)))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x634 dir.pending))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x936 dir.pending))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x634 dir.dirty))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x936 dir.dirty))))
(assert
 (let (($x634 (not (net.put home dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x634))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x936))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x952))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x955))))
(assert
 (let (($x796 (not (net.get __dst home))))
 (let (($x649 (dir.shlist __dst)))
 (let (($x957 (not $x649)))
 (or $x957 $x796)))))
(assert
 (let (($x649 (dir.shlist __dst)))
 (let (($x957 (not $x649)))
 (or $x957 dir.head))))
(assert
 (let (($x779 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x779))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let (($x661 (= dir.hptr home)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x661 $x936)))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let (($x275 (= __dst home)))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x275 $x955)))))
(assert
 (let (($x779 (not (= (cache.state_ dir.hptr) exclusive))))
 (let (($x963 (= dir.hptr requester)))
 (let (($x58 (dir.shlist dir.hptr)))
 (or $x58 $x963 $x779)))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x145 (= dir.hptr real_owner)))
 (or $x145 $x952))))
(assert
 (let (($x908 (not (= (cache.state_ dir.hptr) shared))))
 (or $x908 (not (= (cache.wait dir.hptr) get)))))
(assert
 (let (($x911 (not (= (cache.state_ home) shared))))
 (or $x911 (not (= (cache.wait home) get)))))
(assert
 (let (($x779 (not (= (cache.state_ dir.hptr) exclusive))))
 (or $x779 dir.head)))
(assert
 (let (($x783 (not (= (cache.state_ home) exclusive))))
 (or $x783 dir.head)))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x699 (= ?x698 getX)))
 (or $x699 $x929)))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let ((?x678 (cache.wait __dst)))
 (let (($x773 (= ?x678 getX)))
 (or $x773 $x952)))))
(assert
 (let (($x762 (not (__net.getX __src home))))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 getX)))
 (or $x702 $x762)))))
(assert
 (let (($x765 (not (__net.getX home home))))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x765)))))
(assert
 (let (($x768 (not (__net.getX @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x710 (= ?x321 getX)))
 (or $x710 $x768)))))
(assert
 (let (($x771 (not (__net.getX @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x295 (= ?x294 getX)))
 (or $x295 $x771)))))
(assert
 (let (($x804 (not (__net.getX home __dst))))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x804)))))
(assert
 (let (($x806 (not (__net.getX home @Z))))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x806)))))
(assert
 (let (($x808 (not (__net.getX home @V0))))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x808)))))
(assert
 (let (($x810 (not (__net.getX home @V1))))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x810)))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x718 (= ?x698 get)))
 (or $x718 $x936)))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let ((?x678 (cache.wait __dst)))
 (let (($x679 (= ?x678 get)))
 (or $x679 $x955)))))
(assert
 (let (($x638 (not (net.get dir.hptr home))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x718 (= ?x698 get)))
 (or $x718 $x638)))))
(assert
 (let (($x644 (not (net.get @V0 home))))
 (let ((?x294 (cache.wait @V0)))
 (let (($x304 (= ?x294 get)))
 (or $x304 $x644)))))
(assert
 (let (($x788 (not (net.get real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x788)))))
(assert
 (let (($x792 (not (net.get @V1 home))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x790 (= ?x321 get)))
 (or $x790 $x792)))))
(assert
 (let (($x796 (not (net.get __dst home))))
 (let ((?x678 (cache.wait __dst)))
 (let (($x679 (= ?x678 get)))
 (or $x679 $x796)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let ((?x701 (cache.wait __src)))
 (let (($x799 (= ?x701 get)))
 (or $x799 $x801)))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let ((?x733 (cache.state_ dir.hptr)))
 (let (($x734 (= ?x733 invalid)))
 (or $x734 $x936)))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let ((?x277 (cache.state_ __dst)))
 (let (($x668 (= ?x277 invalid)))
 (or $x668 $x955)))))
(assert
 (let (($x638 (not (net.get dir.hptr home))))
 (let ((?x733 (cache.state_ dir.hptr)))
 (let (($x734 (= ?x733 invalid)))
 (or $x734 $x638)))))
(assert
 (let (($x644 (not (net.get @V0 home))))
 (let ((?x309 (cache.state_ @V0)))
 (let (($x310 (= ?x309 invalid)))
 (or $x310 $x644)))))
(assert
 (let (($x788 (not (net.get real_owner home))))
 (or (= (cache.state_ real_owner) invalid) $x788)))
(assert
 (let (($x792 (not (net.get @V1 home))))
 (or (= (cache.state_ @V1) invalid) $x792)))
(assert
 (let (($x796 (not (net.get __dst home))))
 (let ((?x277 (cache.state_ __dst)))
 (let (($x668 (= ?x277 invalid)))
 (or $x668 $x796)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (or (= (cache.state_ __src) invalid) $x801)))
(assert
 (let (($x747 (not (= (cache.wait __src) none))))
 (let (($x762 (not (__net.getX __src home))))
 (or $x762 $x747))))
(assert
 (let (($x754 (not (= (cache.wait home) none))))
 (let (($x765 (not (__net.getX home home))))
 (or $x765 $x754))))
(assert
 (let (($x323 (not (= (cache.wait @V1) none))))
 (let (($x768 (not (__net.getX @V1 home))))
 (or $x768 $x323))))
(assert
 (let (($x759 (not (= (cache.wait @V0) none))))
 (let (($x771 (not (__net.getX @V0 home))))
 (or $x771 $x759))))
(assert
 (let (($x754 (not (= (cache.wait home) none))))
 (let (($x804 (not (__net.getX home __dst))))
 (or $x804 $x754))))
(assert
 (let (($x754 (not (= (cache.wait home) none))))
 (let (($x806 (not (__net.getX home @Z))))
 (or $x806 $x754))))
(assert
 (let (($x754 (not (= (cache.wait home) none))))
 (let (($x808 (not (__net.getX home @V0))))
 (or $x808 $x754))))
(assert
 (let (($x754 (not (= (cache.wait home) none))))
 (let (($x810 (not (__net.getX home @V1))))
 (or $x810 $x754))))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x1002 (= ?x140 getX)))
 (or $x1002 $x1004)))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x710 (= ?x321 getX)))
 (or $x710 $x1007)))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let ((?x678 (cache.wait __dst)))
 (let (($x773 (= ?x678 getX)))
 (or $x773 $x952)))))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (let ((?x701 (cache.wait __src)))
 (let (($x702 (= ?x701 getX)))
 (or $x702 $x1010)))))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let ((?x706 (cache.wait home)))
 (let (($x707 (= ?x706 getX)))
 (or $x707 $x1013)))))
(assert
 (let (($x1016 (not (__net.getX real_owner home))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x1002 (= ?x140 getX)))
 (or $x1002 $x1016)))))
(assert
 (let (($x1019 (not (__net.getX __dst home))))
 (let ((?x678 (cache.wait __dst)))
 (let (($x773 (= ?x678 getX)))
 (or $x773 $x1019)))))
(assert
 (let (($x1022 (not (__net.getX dir.hptr home))))
 (let ((?x698 (cache.wait dir.hptr)))
 (let (($x699 (= ?x698 getX)))
 (or $x699 $x1022)))))
(assert
 (let (($x1025 (not (= (cache.state_ real_owner) exclusive))))
 (or $x1025 (not (= (cache.wait real_owner) getX)))))
(assert
 (let (($x1029 (not (= (cache.state_ @V1) exclusive))))
 (or $x1029 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x1033 (not (= (cache.state_ __src) exclusive))))
 (or $x1033 (not (= (cache.wait __src) getX)))))
(assert
 (let (($x933 (not (rp_net dir.hptr))))
 (let (($x634 (not (net.put home dir.hptr))))
 (or $x634 $x933))))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (let ((?x140 (cache.wait real_owner)))
 (let (($x141 (= ?x140 get)))
 (or $x141 $x1037)))))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (let ((?x321 (cache.wait @V1)))
 (let (($x790 (= ?x321 get)))
 (or $x790 $x1040)))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let ((?x678 (cache.wait __dst)))
 (let (($x679 (= ?x678 get)))
 (or $x679 $x955)))))
(assert
 (let (($x1043 (not (net.put home __src))))
 (let ((?x701 (cache.wait __src)))
 (let (($x799 (= ?x701 get)))
 (or $x799 $x1043)))))
(assert
 (let (($x1046 (not (net.put home home))))
 (let ((?x706 (cache.wait home)))
 (let (($x722 (= ?x706 get)))
 (or $x722 $x1046)))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let (($x145 (= dir.hptr real_owner)))
 (let (($x661 (= dir.hptr home)))
 (or $x661 $x145 $x936)))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x955)))))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1037)))))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1040)))))
(assert
 (let (($x1043 (not (net.put home __src))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1043)))))
(assert
 (let (($x1046 (not (net.put home home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1046)))))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (let (($x817 (= real_owner real_owner)))
 (let (($x816 (= real_owner home)))
 (or $x816 $x817 $x929)))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x952)))))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1004)))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1007)))))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1010)))))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1013)))))
(assert
 (let (($x796 (not (net.get __dst home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x796)))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x801)))))
(assert
 (let (($x1016 (not (__net.getX real_owner home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1016)))))
(assert
 (let (($x1019 (not (__net.getX __dst home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1019)))))
(assert
 (let (($x1022 (not (__net.getX dir.hptr home))))
 (let (($x434 (= home real_owner)))
 (let (($x433 (= home home)))
 (or $x433 $x434 $x1022)))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (let (($x661 (= dir.hptr home)))
 (or $x661 $x936 dir.dirty))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let (($x433 (= home home)))
 (or $x433 $x955 dir.dirty))))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (let (($x433 (= home home)))
 (or $x433 $x1037 dir.dirty))))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (let (($x433 (= home home)))
 (or $x433 $x1040 dir.dirty))))
(assert
 (let (($x1043 (not (net.put home __src))))
 (let (($x433 (= home home)))
 (or $x433 $x1043 dir.dirty))))
(assert
 (let (($x1046 (not (net.put home home))))
 (let (($x433 (= home home)))
 (or $x433 $x1046 dir.dirty))))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x929 dir.head))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x433 (= home home)))
 (or $x433 $x952 dir.head))))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let (($x433 (= home home)))
 (or $x433 $x1004 dir.head))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (let (($x433 (= home home)))
 (or $x433 $x1007 dir.head))))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (let (($x433 (= home home)))
 (or $x433 $x1010 dir.head))))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let (($x433 (= home home)))
 (or $x433 $x1013 dir.head))))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x929 dir.dirty))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x433 (= home home)))
 (or $x433 $x952 dir.dirty))))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let (($x433 (= home home)))
 (or $x433 $x1004 dir.dirty))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (let (($x433 (= home home)))
 (or $x433 $x1007 dir.dirty))))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (let (($x433 (= home home)))
 (or $x433 $x1010 dir.dirty))))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let (($x433 (= home home)))
 (or $x433 $x1013 dir.dirty))))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x929))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x433 (= home home)))
 (or $x433 $x952))))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let (($x433 (= home home)))
 (or $x433 $x1004))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (let (($x433 (= home home)))
 (or $x433 $x1007))))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (let (($x433 (= home home)))
 (or $x433 $x1010))))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let (($x433 (= home home)))
 (or $x433 $x1013))))
(assert
 (let (($x796 (not (net.get __dst home))))
 (let (($x433 (= home home)))
 (or $x433 $x796 dir.head))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let (($x433 (= home home)))
 (or $x433 $x801 dir.head))))
(assert
 (let (($x796 (not (net.get __dst home))))
 (let (($x433 (= home home)))
 (or $x433 $x796 dir.dirty))))
(assert
 (let (($x801 (not (net.get __src home))))
 (let (($x433 (= home home)))
 (or $x433 $x801 dir.dirty))))
(assert
 (let (($x1016 (not (__net.getX real_owner home))))
 (let (($x433 (= home home)))
 (or $x433 $x1016 dir.head))))
(assert
 (let (($x1019 (not (__net.getX __dst home))))
 (let (($x433 (= home home)))
 (or $x433 $x1019 dir.head))))
(assert
 (let (($x1022 (not (__net.getX dir.hptr home))))
 (let (($x433 (= home home)))
 (or $x433 $x1022 dir.head))))
(assert
 (let (($x1016 (not (__net.getX real_owner home))))
 (let (($x433 (= home home)))
 (or $x433 $x1016 dir.dirty))))
(assert
 (let (($x1019 (not (__net.getX __dst home))))
 (let (($x433 (= home home)))
 (or $x433 $x1019 dir.dirty))))
(assert
 (let (($x1022 (not (__net.getX dir.hptr home))))
 (let (($x433 (= home home)))
 (or $x433 $x1022 dir.dirty))))
(assert
 (let (($x1016 (not (__net.getX real_owner home))))
 (let (($x433 (= home home)))
 (or $x433 $x1016))))
(assert
 (let (($x1019 (not (__net.getX __dst home))))
 (let (($x433 (= home home)))
 (or $x433 $x1019))))
(assert
 (let (($x1022 (not (__net.getX dir.hptr home))))
 (let (($x433 (= home home)))
 (or $x433 $x1022))))
(assert
 (let (($x1016 (not (__net.getX real_owner home))))
 (let (($x433 (= home home)))
 (or (= real_owner requester) $x433 $x1016))))
(assert
 (let (($x1019 (not (__net.getX __dst home))))
 (let (($x433 (= home home)))
 (let (($x663 (= __dst requester)))
 (or $x663 $x433 $x1019)))))
(assert
 (let (($x1022 (not (__net.getX dir.hptr home))))
 (let (($x433 (= home home)))
 (let (($x963 (= dir.hptr requester)))
 (or $x963 $x433 $x1022)))))
(assert
 (let (($x1025 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x817 (= real_owner real_owner)))
 (or $x817 $x1025))))
(assert
 (let (($x1029 (not (= (cache.state_ @V1) exclusive))))
 (let (($x436 (= @V1 real_owner)))
 (or $x436 $x1029))))
(assert
 (let (($x1033 (not (= (cache.state_ __src) exclusive))))
 (let (($x1108 (= __src real_owner)))
 (or $x1108 $x1033))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x535 (= __dst dir.hptr)))
 (or $x535 $x952))))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let (($x916 (= real_owner dir.hptr)))
 (or $x916 $x1004))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (let (($x1112 (= @V1 dir.hptr)))
 (or $x1112 $x1007))))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (let (($x1114 (= __src dir.hptr)))
 (or $x1114 $x1010))))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let (($x905 (= home dir.hptr)))
 (or $x905 $x1013))))
(assert
 (let (($x1025 (not (= (cache.state_ real_owner) exclusive))))
 (let (($x916 (= real_owner dir.hptr)))
 (or $x916 $x1025))))
(assert
 (let (($x1029 (not (= (cache.state_ @V1) exclusive))))
 (let (($x1112 (= @V1 dir.hptr)))
 (or $x1112 $x1029))))
(assert
 (let (($x1033 (not (= (cache.state_ __src) exclusive))))
 (let (($x1114 (= __src dir.hptr)))
 (or $x1114 $x1033))))
(assert
 (let (($x817 (= real_owner real_owner)))
 (or $x817 (not (= (cache.state_ real_owner) shared)))))
(assert
 (let (($x436 (= @V1 real_owner)))
 (or $x436 (not (= (cache.state_ @V1) shared)))))
(assert
 (let (($x1108 (= __src real_owner)))
 (or $x1108 (not (= (cache.state_ __src) shared)))))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x929))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (let (($x433 (= home home)))
 (or $x433 $x952))))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let (($x433 (= home home)))
 (or $x433 $x1004))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (let (($x433 (= home home)))
 (or $x433 $x1007))))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (let (($x433 (= home home)))
 (or $x433 $x1010))))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let (($x433 (= home home)))
 (or $x433 $x1013))))
(assert
 (let (($x908 (not (= (cache.state_ dir.hptr) shared))))
 (let (($x933 (not (rp_net dir.hptr))))
 (or $x933 $x908))))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (let (($x916 (= real_owner dir.hptr)))
 (or $x916 $x929))))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (or (= real_owner __dst) $x952)))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (let (($x817 (= real_owner real_owner)))
 (or $x817 $x1004))))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (or (= real_owner @V1) $x1007)))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (or (= real_owner __src) $x1010)))
(assert
 (let (($x1013 (not (net.putX home home))))
 (let (($x816 (= real_owner home)))
 (or $x816 $x1013))))
(assert
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (or $x936 dir.head)))
(assert
 (let (($x955 (not (net.put home __dst))))
 (or $x955 dir.head)))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (or $x1037 dir.head)))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (or $x1040 dir.head)))
(assert
 (let (($x1043 (not (net.put home __src))))
 (or $x1043 dir.head)))
(assert
 (let (($x1046 (not (net.put home home))))
 (or $x1046 dir.head)))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (or $x929 dir.head)))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (or $x952 dir.head)))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (or $x1004 dir.head)))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (or $x1007 dir.head)))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (or $x1010 dir.head)))
(assert
 (let (($x1013 (not (net.putX home home))))
 (or $x1013 dir.head)))
(assert
 (let (($x929 (not (net.putX real_owner dir.hptr))))
 (or $x929 dir.dirty)))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (or $x952 dir.dirty)))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (or $x1004 dir.dirty)))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (or $x1007 dir.dirty)))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (or $x1010 dir.dirty)))
(assert
 (let (($x1013 (not (net.putX home home))))
 (or $x1013 dir.dirty)))
(assert
 (not (net.putX real_owner __dst)))
(assert
 (not (net.putX real_owner real_owner)))
(assert
 (not (net.putX real_owner @V1)))
(assert
 (not (net.putX real_owner __src)))
(assert
 (not (net.putX real_owner home)))
(assert
 (let (($x952 (not (net.putX home __dst))))
 (or $x952 dir.head)))
(assert
 (let (($x1004 (not (net.putX home real_owner))))
 (or $x1004 dir.head)))
(assert
 (let (($x1007 (not (net.putX home @V1))))
 (or $x1007 dir.head)))
(assert
 (let (($x1010 (not (net.putX home __src))))
 (or $x1010 dir.head)))
(assert
 (let (($x1013 (not (net.putX home home))))
 (or $x1013 dir.head)))
(assert
 (not (net.putX home __dst)))
(assert
 (not (net.putX home real_owner)))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home __src)))
(assert
 (not (net.putX home home)))
(assert
 (let (($x933 (not (rp_net dir.hptr))))
 (let (($x936 (not (net.put dir.hptr dir.hptr))))
 (or $x936 $x933))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (or $x955 (not (rp_net __dst)))))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (or $x1037 (not (rp_net real_owner)))))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (or $x1040 (not (rp_net @V1)))))
(assert
 (let (($x1043 (not (net.put home __src))))
 (or $x1043 (not (rp_net __src)))))
(assert
 (let (($x1046 (not (net.put home home))))
 (or $x1046 (not (rp_net home)))))
(assert
 (not (net.put home __dst)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr __dst)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x955 dir.pending))))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (let (($x1194 (dir.shlist real_owner)))
 (or $x1194 $x1037 dir.pending))))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (let (($x1196 (dir.shlist @V1)))
 (or $x1196 $x1040 dir.pending))))
(assert
 (let (($x1043 (not (net.put home __src))))
 (let (($x1198 (dir.shlist __src)))
 (or $x1198 $x1043 dir.pending))))
(assert
 (let (($x1046 (not (net.put home home))))
 (let (($x1200 (dir.shlist home)))
 (or $x1200 $x1046 dir.pending))))
(assert
 (let (($x1184 (not (net.put dir.hptr __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x1184 dir.pending))))
(assert
 (let (($x1186 (not (net.put dir.hptr real_owner))))
 (let (($x1194 (dir.shlist real_owner)))
 (or $x1194 $x1186 dir.pending))))
(assert
 (let (($x1188 (not (net.put dir.hptr @V1))))
 (let (($x1196 (dir.shlist @V1)))
 (or $x1196 $x1188 dir.pending))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x955 dir.dirty))))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (let (($x1194 (dir.shlist real_owner)))
 (or $x1194 $x1037 dir.dirty))))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (let (($x1196 (dir.shlist @V1)))
 (or $x1196 $x1040 dir.dirty))))
(assert
 (let (($x1043 (not (net.put home __src))))
 (let (($x1198 (dir.shlist __src)))
 (or $x1198 $x1043 dir.dirty))))
(assert
 (let (($x1046 (not (net.put home home))))
 (let (($x1200 (dir.shlist home)))
 (or $x1200 $x1046 dir.dirty))))
(assert
 (let (($x1184 (not (net.put dir.hptr __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x1184 dir.dirty))))
(assert
 (let (($x1186 (not (net.put dir.hptr real_owner))))
 (let (($x1194 (dir.shlist real_owner)))
 (or $x1194 $x1186 dir.dirty))))
(assert
 (let (($x1188 (not (net.put dir.hptr @V1))))
 (let (($x1196 (dir.shlist @V1)))
 (or $x1196 $x1188 dir.dirty))))
(assert
 (let (($x955 (not (net.put home __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x955))))
(assert
 (let (($x1037 (not (net.put home real_owner))))
 (let (($x1194 (dir.shlist real_owner)))
 (or $x1194 $x1037))))
(assert
 (let (($x1040 (not (net.put home @V1))))
 (let (($x1196 (dir.shlist @V1)))
 (or $x1196 $x1040))))
(assert
 (let (($x1043 (not (net.put home __src))))
 (let (($x1198 (dir.shlist __src)))
 (or $x1198 $x1043))))
(assert
 (let (($x1046 (not (net.put home home))))
 (let (($x1200 (dir.shlist home)))
 (or $x1200 $x1046))))
(assert
 (let (($x1184 (not (net.put dir.hptr __dst))))
 (let (($x649 (dir.shlist __dst)))
 (or $x649 $x1184))))
(assert
 (let (($x1186 (not (net.put dir.hptr real_owner))))
 (let (($x1194 (dir.shlist real_owner)))
 (or $x1194 $x1186))))
(assert
 (let (($x1188 (not (net.put dir.hptr @V1))))
 (let (($x1196 (dir.shlist @V1)))
 (or $x1196 $x1188))))
(check-sat)
