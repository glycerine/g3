(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun real_owner () id)
(assert
 (let (($x22 (= (cache.state_ @Y) exclusive)))
 (let (($x16 (= (cache.state_ @X) exclusive)))
 (and $x16 (= (cache.wait @X) none) $x22 (= (cache.wait @Y) none) (not (= @X @Y))))))
(assert
 (or (= @X real_owner) (not (= (cache.state_ @X) exclusive))))
(assert
 (or (= @Y real_owner) (not (= (cache.state_ @Y) exclusive))))
(check-sat)
