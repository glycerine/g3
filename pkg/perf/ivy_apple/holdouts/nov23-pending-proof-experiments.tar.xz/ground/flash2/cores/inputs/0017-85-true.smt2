(set-info :status unknown)
(declare-sort id 0)
 (declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun home () id)
(declare-fun __net.putX (id id) Bool)
(assert
 (__net.putX __src __dst))
(assert
 (or (= __src home) (not (__net.putX __src __dst))))
(assert
 (not (__net.putX home __dst)))
(assert
 (or (= home home) (not (__net.putX home __dst))))
(check-sat)
