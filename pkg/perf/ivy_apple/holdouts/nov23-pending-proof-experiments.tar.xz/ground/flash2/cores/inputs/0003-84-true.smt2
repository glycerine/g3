(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun __dst () id)
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x31 (cache.state_ @X)))
 (= ?x31 (ite (and (= @X __dst)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x36 (cache.state_ @Y)))
 (= ?x36 (ite (and (= @Y __dst)) invalid (__cache.state_ @Y)))))
(check-sat)
