(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun __src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun __m_net.getX (id id) Bool)
(assert
 (or (dir.shlist dir.hptr) (not dir.head)))
(assert
 (let (($x109 (= dir.hptr real_owner)))
 (or $x109 (not dir.dirty) __dir.pending)))
(assert
 (__net.getX __src home))
(assert
 (let (($x134 (= home __src)))
 (not $x134)))
(assert
 (not __dir.pending))
(assert
 dir.dirty)
(assert
 (let (($x198 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x37 (or (dir.shlist dir.hptr) (not dir.head))))
 (let (($x212 (net.getX @X @Z)))
 (let (($x213 (not $x212)))
 (let (($x222 (= @Y @Z)))
 (let (($x235 (and (or $x222 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x222 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x222 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x222 (not (net.getX @X @Y)) $x213) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x213 (not (net.putX @Y @X))) (not (net.getX home @Y)) $x37 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x198 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x235)))))))))
(assert
 (let (($x259 (__m_net.getX @X @Y)))
 (let (($x220 (net.getX @X @Y)))
 (= $x220 (ite (and (= @X __src) (= @Y dir.hptr)) true $x259)))))
(assert
 (let (($x264 (__m_net.getX @X @Z)))
 (let (($x212 (net.getX @X @Z)))
 (= $x212 (ite (and (= @X __src) (= @Z dir.hptr)) true $x264)))))
(assert
 (let (($x268 (__m_net.getX home @Y)))
 (let (($x233 (net.getX home @Y)))
 (= $x233 (ite (and (= home __src) (= @Y dir.hptr)) true $x268)))))
(assert
 (let (($x273 (__m_net.getX @X home)))
 (let (($x191 (net.getX @X home)))
 (= $x191 (ite (and (= @X __src) (= home dir.hptr)) true $x273)))))
(assert
 (let (($x279 (__m_net.getX @V1 @V0)))
 (let (($x180 (net.getX @V1 @V0)))
 (= $x180 (ite (and (= @V1 __src) (= @V0 dir.hptr)) true $x279)))))
(assert
 (let (($x285 (__m_net.getX @V0 @V1)))
 (let (($x160 (net.getX @V0 @V1)))
 (= $x160 (ite (and (= @V0 __src) (= @V1 dir.hptr)) true $x285)))))
(assert
 (let (($x289 (__net.getX @X @Y)))
 (let (($x259 (__m_net.getX @X @Y)))
 (= $x259 (ite (and (= @X __src) (= @Y home)) false $x289)))))
(assert
 (let (($x294 (__net.getX @X @Z)))
 (let (($x264 (__m_net.getX @X @Z)))
 (= $x264 (ite (and (= @X __src) (= @Z home)) false $x294)))))
(assert
 (let (($x298 (__net.getX home @Y)))
 (let (($x268 (__m_net.getX home @Y)))
 (= $x268 (ite (and (= home __src) (= @Y home)) false $x298)))))
(assert
 (let (($x303 (__net.getX @X home)))
 (let (($x273 (__m_net.getX @X home)))
 (= $x273 (ite (and (= @X __src) (= home home)) false $x303)))))
(assert
 (let (($x308 (__net.getX @V1 @V0)))
 (let (($x279 (__m_net.getX @V1 @V0)))
 (= $x279 (ite (and (= @V1 __src) (= @V0 home)) false $x308)))))
(assert
 (let (($x312 (__net.getX @V0 @V1)))
 (let (($x285 (__m_net.getX @V0 @V1)))
 (= $x285 (ite (and (= @V0 __src) (= @V1 home)) false $x312)))))
(assert
 (let (($x216 (not (net.put @Y @X))))
 (let (($x315 (= @Y real_owner)))
 (let (($x175 (= @Y home)))
 (or $x175 $x315 $x216)))))
(assert
 (let (($x231 (not (net.put @Z @X))))
 (let (($x317 (= @Z real_owner)))
 (let (($x292 (= @Z home)))
 (or $x292 $x317 $x231)))))
(assert
 (let (($x202 (not (net.put home @X))))
 (let (($x319 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x319 $x202)))))
(assert
 (let (($x164 (not (net.put @V1 @V0))))
 (let (($x321 (= @V1 real_owner)))
 (let (($x150 (= @V1 home)))
 (or $x150 $x321 $x164)))))
(assert
 (let (($x228 (not (net.get @X @Y))))
 (let (($x315 (= @Y real_owner)))
 (let (($x175 (= @Y home)))
 (or $x175 $x315 $x228)))))
(assert
 (let (($x218 (not (net.get @X @Z))))
 (let (($x317 (= @Z real_owner)))
 (let (($x292 (= @Z home)))
 (or $x292 $x317 $x218)))))
(assert
 (let (($x207 (not (net.get @X home))))
 (let (($x319 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x319 $x207)))))
(assert
 (let (($x168 (not (net.get @V0 @V1))))
 (let (($x321 (= @V1 real_owner)))
 (let (($x150 (= @V1 home)))
 (or $x150 $x321 $x168)))))
(assert
 (let (($x210 (not (net.putX @Y @X))))
 (let (($x175 (= @Y home)))
 (or $x175 $x210))))
(assert
 (let (($x225 (not (net.putX @Z @X))))
 (let (($x292 (= @Z home)))
 (or $x292 $x225))))
(assert
 (let (($x187 (not (net.putX home @X))))
 (let (($x301 (= home home)))
 (or $x301 $x187))))
(assert
 (let (($x158 (not (net.putX @V1 @V0))))
 (let (($x150 (= @V1 home)))
 (or $x150 $x158))))
(assert
 (let (($x133 (__net.getX __src home)))
 (let (($x331 (not $x133)))
 (let (($x301 (= home home)))
 (or $x301 $x331)))))
(assert
 (let (($x289 (__net.getX @X @Y)))
 (let (($x333 (not $x289)))
 (let (($x175 (= @Y home)))
 (or $x175 $x333)))))
(assert
 (let (($x294 (__net.getX @X @Z)))
 (let (($x335 (not $x294)))
 (let (($x292 (= @Z home)))
 (or $x292 $x335)))))
(assert
 (let (($x298 (__net.getX home @Y)))
 (let (($x337 (not $x298)))
 (let (($x175 (= @Y home)))
 (or $x175 $x337)))))
(assert
 (let (($x303 (__net.getX @X home)))
 (let (($x339 (not $x303)))
 (let (($x301 (= home home)))
 (or $x301 $x339)))))
(assert
 (let (($x308 (__net.getX @V1 @V0)))
 (let (($x341 (not $x308)))
 (let (($x306 (= @V0 home)))
 (or $x306 $x341)))))
(assert
 (let (($x312 (__net.getX @V0 @V1)))
 (let (($x343 (not $x312)))
 (let (($x150 (= @V1 home)))
 (or $x150 $x343)))))
(assert
 (let (($x210 (not (net.putX @Y @X))))
 (let (($x345 (= real_owner @X)))
 (or $x345 $x210))))
(assert
 (let (($x225 (not (net.putX @Z @X))))
 (let (($x345 (= real_owner @X)))
 (or $x345 $x225))))
(assert
 (let (($x187 (not (net.putX home @X))))
 (let (($x345 (= real_owner @X)))
 (or $x345 $x187))))
(assert
 (let (($x158 (not (net.putX @V1 @V0))))
 (let (($x349 (= real_owner @V0)))
 (or $x349 $x158))))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (let (($x150 (= @V1 home)))
 (or $x150 (not (net.fack @V0 @V1)))))
(assert
 (let (($x133 (__net.getX __src home)))
 (let (($x331 (not $x133)))
 (let ((?x357 (cache.wait __src)))
 (let (($x358 (= ?x357 getX)))
 (or $x358 $x331))))))
(assert
 (let (($x289 (__net.getX @X @Y)))
 (let (($x333 (not $x289)))
 (let ((?x188 (cache.wait @X)))
 (let (($x189 (= ?x188 getX)))
 (or $x189 $x333))))))
(assert
 (let (($x294 (__net.getX @X @Z)))
 (let (($x335 (not $x294)))
 (let ((?x188 (cache.wait @X)))
 (let (($x189 (= ?x188 getX)))
 (or $x189 $x335))))))
(assert
 (let (($x298 (__net.getX home @Y)))
 (let (($x337 (not $x298)))
 (let ((?x362 (cache.wait home)))
 (let (($x363 (= ?x362 getX)))
 (or $x363 $x337))))))
(assert
 (let (($x303 (__net.getX @X home)))
 (let (($x339 (not $x303)))
 (let ((?x188 (cache.wait @X)))
 (let (($x189 (= ?x188 getX)))
 (or $x189 $x339))))))
(assert
 (let (($x308 (__net.getX @V1 @V0)))
 (let (($x341 (not $x308)))
 (let ((?x182 (cache.wait @V1)))
 (let (($x366 (= ?x182 getX)))
 (or $x366 $x341))))))
(assert
 (let (($x312 (__net.getX @V0 @V1)))
 (let (($x343 (not $x312)))
 (let ((?x155 (cache.wait @V0)))
 (let (($x156 (= ?x155 getX)))
 (or $x156 $x343))))))
(assert
 (let (($x228 (not (net.get @X @Y))))
 (let ((?x188 (cache.wait @X)))
 (let (($x204 (= ?x188 get)))
 (or $x204 $x228)))))
(assert
 (let (($x218 (not (net.get @X @Z))))
 (let ((?x188 (cache.wait @X)))
 (let (($x204 (= ?x188 get)))
 (or $x204 $x218)))))
(assert
 (let (($x207 (not (net.get @X home))))
 (let ((?x188 (cache.wait @X)))
 (let (($x204 (= ?x188 get)))
 (or $x204 $x207)))))
(assert
 (let (($x168 (not (net.get @V0 @V1))))
 (let ((?x155 (cache.wait @V0)))
 (let (($x165 (= ?x155 get)))
 (or $x165 $x168)))))
(assert
 (let (($x216 (not (net.put @Y @X))))
 (let ((?x194 (cache.state_ @X)))
 (let (($x371 (= ?x194 invalid)))
 (or $x371 $x216)))))
(assert
 (let (($x231 (not (net.put @Z @X))))
 (let ((?x194 (cache.state_ @X)))
 (let (($x371 (= ?x194 invalid)))
 (or $x371 $x231)))))
(assert
 (let (($x202 (not (net.put home @X))))
 (let ((?x194 (cache.state_ @X)))
 (let (($x371 (= ?x194 invalid)))
 (or $x371 $x202)))))
(assert
 (let (($x164 (not (net.put @V1 @V0))))
 (let ((?x170 (cache.state_ @V0)))
 (let (($x171 (= ?x170 invalid)))
 (or $x171 $x164)))))
(assert
 (let (($x354 (not (net.put dir.hptr @X))))
 (let ((?x194 (cache.state_ @X)))
 (let (($x371 (= ?x194 invalid)))
 (or $x371 $x354)))))
(assert
 (let (($x356 (not (net.put dir.hptr @V0))))
 (let ((?x170 (cache.state_ @V0)))
 (let (($x171 (= ?x170 invalid)))
 (or $x171 $x356)))))
(assert
 (let (($x228 (not (net.get @X @Y))))
 (let ((?x194 (cache.state_ @X)))
 (let (($x371 (= ?x194 invalid)))
 (or $x371 $x228)))))
(assert
 (let (($x218 (not (net.get @X @Z))))
 (let ((?x194 (cache.state_ @X)))
 (let (($x371 (= ?x194 invalid)))
 (or $x371 $x218)))))
(assert
 (let (($x207 (not (net.get @X home))))
 (let ((?x194 (cache.state_ @X)))
 (let (($x371 (= ?x194 invalid)))
 (or $x371 $x207)))))
(assert
 (let (($x168 (not (net.get @V0 @V1))))
 (let ((?x170 (cache.state_ @V0)))
 (let (($x171 (= ?x170 invalid)))
 (or $x171 $x168)))))
(assert
 (let (($x175 (= @Y home)))
 (or $x175 (not (net.shwb @X @Y)))))
(assert
 (let (($x133 (__net.getX __src home)))
 (let (($x331 (not $x133)))
 (or $x331 (not (= (cache.wait __src) none))))))
(assert
 (let (($x384 (not (= (cache.wait @X) none))))
 (let (($x289 (__net.getX @X @Y)))
 (let (($x333 (not $x289)))
 (or $x333 $x384)))))
(assert
 (let (($x384 (not (= (cache.wait @X) none))))
 (let (($x294 (__net.getX @X @Z)))
 (let (($x335 (not $x294)))
 (or $x335 $x384)))))
(assert
 (let (($x388 (not (= (cache.wait home) none))))
 (let (($x298 (__net.getX home @Y)))
 (let (($x337 (not $x298)))
 (or $x337 $x388)))))
(assert
 (let (($x384 (not (= (cache.wait @X) none))))
 (let (($x303 (__net.getX @X home)))
 (let (($x339 (not $x303)))
 (or $x339 $x384)))))
(assert
 (let (($x184 (not (= (cache.wait @V1) none))))
 (let (($x308 (__net.getX @V1 @V0)))
 (let (($x341 (not $x308)))
 (or $x341 $x184)))))
(assert
 (let (($x393 (not (= (cache.wait @V0) none))))
 (let (($x312 (__net.getX @V0 @V1)))
 (let (($x343 (not $x312)))
 (or $x343 $x393)))))
(assert
 (let (($x187 (not (net.putX home @X))))
 (let ((?x188 (cache.wait @X)))
 (let (($x189 (= ?x188 getX)))
 (or $x189 $x187)))))
(assert
 (let (($x352 (not (net.putX home @V0))))
 (let ((?x155 (cache.wait @V0)))
 (let (($x156 (= ?x155 getX)))
 (or $x156 $x352)))))
(assert
 (let (($x303 (__net.getX @X home)))
 (let (($x339 (not $x303)))
 (let ((?x188 (cache.wait @X)))
 (let (($x189 (= ?x188 getX)))
 (or $x189 $x339))))))
(assert
 (let (($x397 (not (__net.getX @V1 home))))
 (let ((?x182 (cache.wait @V1)))
 (let (($x366 (= ?x182 getX)))
 (or $x366 $x397)))))
(assert
 (let (($x400 (not (__net.getX @V0 home))))
 (let ((?x155 (cache.wait @V0)))
 (let (($x156 (= ?x155 getX)))
 (or $x156 $x400)))))
(assert
 (let (($x133 (__net.getX __src home)))
 (let (($x331 (not $x133)))
 (let ((?x357 (cache.wait __src)))
 (let (($x358 (= ?x357 getX)))
 (or $x358 $x331))))))
(assert
 (let (($x403 (not (__net.getX home home))))
 (let ((?x362 (cache.wait home)))
 (let (($x363 (= ?x362 getX)))
 (or $x363 $x403)))))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (let (($x202 (not (net.put home @X))))
 (or $x202 (not (rp_net @X)))))
(assert
 (let (($x202 (not (net.put home @X))))
 (let ((?x188 (cache.wait @X)))
 (let (($x204 (= ?x188 get)))
 (or $x204 $x202)))))
(assert
 (let (($x411 (not (net.put home @V1))))
 (or (= (cache.wait @V1) get) $x411)))
(assert
 (let (($x414 (not (net.put home @V0))))
 (let ((?x155 (cache.wait @V0)))
 (let (($x165 (= ?x155 get)))
 (or $x165 $x414)))))
(assert
 (let (($x418 (not (net.put home __src))))
 (or (= (cache.wait __src) get) $x418)))
(assert
 (let (($x422 (not (net.put home home))))
 (or (= (cache.wait home) get) $x422)))
(assert
 (let (($x207 (not (net.get @X home))))
 (let ((?x188 (cache.wait @X)))
 (let (($x204 (= ?x188 get)))
 (or $x204 $x207)))))
(assert
 (let (($x425 (not (net.get @V0 home))))
 (let ((?x155 (cache.wait @V0)))
 (let (($x165 (= ?x155 get)))
 (or $x165 $x425)))))
(assert
 (not (__net.getX home home)))
(assert
 (let (($x298 (__net.getX home @Y)))
 (not $x298)))
(assert
 (not (__net.getX home @Z)))
(assert
 (not (__net.getX home @V0)))
(assert
 (not (__net.getX home @V1)))
(assert
 (let (($x354 (not (net.put dir.hptr @X))))
 (let (($x109 (= dir.hptr real_owner)))
 (let (($x433 (= dir.hptr home)))
 (or $x433 $x109 $x354)))))
(assert
 (let (($x356 (not (net.put dir.hptr @V0))))
 (let (($x109 (= dir.hptr real_owner)))
 (let (($x433 (= dir.hptr home)))
 (or $x433 $x109 $x356)))))
(assert
 (let (($x411 (not (net.put home @V1))))
 (let (($x319 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x319 $x411)))))
(assert
 (let (($x414 (not (net.put home @V0))))
 (let (($x319 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x319 $x414)))))
(assert
 (let (($x418 (not (net.put home __src))))
 (let (($x319 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x319 $x418)))))
(assert
 (let (($x422 (not (net.put home home))))
 (let (($x319 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x319 $x422)))))
(assert
 (let (($x425 (not (net.get @V0 home))))
 (let (($x319 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x319 $x425)))))
(assert
 (let (($x352 (not (net.putX home @V0))))
 (let (($x301 (= home home)))
 (or $x301 $x352))))
(assert
 (let (($x397 (not (__net.getX @V1 home))))
 (let (($x301 (= home home)))
 (or $x301 $x397))))
(assert
 (let (($x400 (not (__net.getX @V0 home))))
 (let (($x301 (= home home)))
 (or $x301 $x400))))
(assert
 (let (($x403 (not (__net.getX home home))))
 (let (($x301 (= home home)))
 (or $x301 $x403))))
(assert
 (let (($x428 (not (__net.getX home @Z))))
 (let (($x292 (= @Z home)))
 (or $x292 $x428))))
(assert
 (let (($x430 (not (__net.getX home @V0))))
 (let (($x306 (= @V0 home)))
 (or $x306 $x430))))
(assert
 (let (($x432 (not (__net.getX home @V1))))
 (let (($x150 (= @V1 home)))
 (or $x150 $x432))))
(assert
 (let (($x352 (not (net.putX home @V0))))
 (let (($x349 (= real_owner @V0)))
 (or $x349 $x352))))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x397 (not (__net.getX @V1 home))))
 (let ((?x182 (cache.wait @V1)))
 (let (($x366 (= ?x182 getX)))
 (or $x366 $x397)))))
(assert
 (let (($x400 (not (__net.getX @V0 home))))
 (let ((?x155 (cache.wait @V0)))
 (let (($x156 (= ?x155 getX)))
 (or $x156 $x400)))))
(assert
 (let (($x403 (not (__net.getX home home))))
 (let ((?x362 (cache.wait home)))
 (let (($x363 (= ?x362 getX)))
 (or $x363 $x403)))))
(assert
 (let (($x428 (not (__net.getX home @Z))))
 (let ((?x362 (cache.wait home)))
 (let (($x363 (= ?x362 getX)))
 (or $x363 $x428)))))
(assert
 (let (($x430 (not (__net.getX home @V0))))
 (let ((?x362 (cache.wait home)))
 (let (($x363 (= ?x362 getX)))
 (or $x363 $x430)))))
(assert
 (let (($x432 (not (__net.getX home @V1))))
 (let ((?x362 (cache.wait home)))
 (let (($x363 (= ?x362 getX)))
 (or $x363 $x432)))))
(assert
 (let (($x425 (not (net.get @V0 home))))
 (let ((?x155 (cache.wait @V0)))
 (let (($x165 (= ?x155 get)))
 (or $x165 $x425)))))
(assert
 (let (($x411 (not (net.put home @V1))))
 (let ((?x458 (cache.state_ @V1)))
 (let (($x459 (= ?x458 invalid)))
 (or $x459 $x411)))))
(assert
 (let (($x414 (not (net.put home @V0))))
 (let ((?x170 (cache.state_ @V0)))
 (let (($x171 (= ?x170 invalid)))
 (or $x171 $x414)))))
(assert
 (let (($x418 (not (net.put home __src))))
 (let ((?x462 (cache.state_ __src)))
 (let (($x463 (= ?x462 invalid)))
 (or $x463 $x418)))))
(assert
 (let (($x422 (not (net.put home home))))
 (let ((?x465 (cache.state_ home)))
 (let (($x466 (= ?x465 invalid)))
 (or $x466 $x422)))))
(assert
 (let (($x450 (not (net.put dir.hptr @V1))))
 (let ((?x458 (cache.state_ @V1)))
 (let (($x459 (= ?x458 invalid)))
 (or $x459 $x450)))))
(assert
 (let (($x452 (not (net.put dir.hptr __src))))
 (let ((?x462 (cache.state_ __src)))
 (let (($x463 (= ?x462 invalid)))
 (or $x463 $x452)))))
(assert
 (let (($x454 (not (net.put dir.hptr home))))
 (let ((?x465 (cache.state_ home)))
 (let (($x466 (= ?x465 invalid)))
 (or $x466 $x454)))))
(assert
 (let (($x425 (not (net.get @V0 home))))
 (let ((?x170 (cache.state_ @V0)))
 (let (($x171 (= ?x170 invalid)))
 (or $x171 $x425)))))
(assert
 (let (($x184 (not (= (cache.wait @V1) none))))
 (let (($x397 (not (__net.getX @V1 home))))
 (or $x397 $x184))))
(assert
 (let (($x393 (not (= (cache.wait @V0) none))))
 (let (($x400 (not (__net.getX @V0 home))))
 (or $x400 $x393))))
(assert
 (let (($x388 (not (= (cache.wait home) none))))
 (let (($x403 (not (__net.getX home home))))
 (or $x403 $x388))))
(assert
 (let (($x388 (not (= (cache.wait home) none))))
 (let (($x428 (not (__net.getX home @Z))))
 (or $x428 $x388))))
(assert
 (let (($x388 (not (= (cache.wait home) none))))
 (let (($x430 (not (__net.getX home @V0))))
 (or $x430 $x388))))
(assert
 (let (($x388 (not (= (cache.wait home) none))))
 (let (($x432 (not (__net.getX home @V1))))
 (or $x432 $x388))))
(assert
 (or (not (= (cache.state_ @V1) exclusive)) (not (= (cache.wait @V1) getX))))
(assert
 (or (not (= (cache.state_ __src) exclusive)) (not (= (cache.wait __src) getX))))
(assert
 (or (not (= (cache.state_ home) exclusive)) (not (= (cache.wait home) getX))))
(assert
 (let (($x450 (not (net.put dir.hptr @V1))))
 (let (($x109 (= dir.hptr real_owner)))
 (let (($x433 (= dir.hptr home)))
 (or $x433 $x109 $x450)))))
(assert
 (let (($x452 (not (net.put dir.hptr __src))))
 (let (($x109 (= dir.hptr real_owner)))
 (let (($x433 (= dir.hptr home)))
 (or $x433 $x109 $x452)))))
(assert
 (let (($x454 (not (net.put dir.hptr home))))
 (let (($x109 (= dir.hptr real_owner)))
 (let (($x433 (= dir.hptr home)))
 (or $x433 $x109 $x454)))))
(check-sat)
