(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun home () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(assert
 (or (dir.shlist dir.hptr) (not dir.head)))
(assert
 (let (($x168 (not (= (cache.state_ @X) exclusive))))
 (let (($x45 (or (dir.shlist dir.hptr) (not dir.head))))
 (let (($x206 (not (net.getX home @Y))))
 (let (($x185 (not (net.getX @X @Z))))
 (let (($x193 (not (net.getX @X @Y))))
 (let (($x194 (= @Y @Z)))
 (let (($x207 (and (or $x194 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x194 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x194 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x194 $x193 $x185) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x185 (not (net.putX @Y @X))) $x206 $x45 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x168 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x207))))))))))
(assert
 (let (($x182 (not (net.putX @Y @X))))
 (let (($x147 (= @Y home)))
 (or $x147 $x182))))
(assert
 (let (($x197 (not (net.putX @Z @X))))
 (let (($x229 (= @Z home)))
 (or $x229 $x197))))
(assert
 (let (($x159 (not (net.putX home @X))))
 (let (($x231 (= home home)))
 (or $x231 $x159))))
(assert
 (let (($x130 (not (net.putX @V1 @V0))))
 (let (($x122 (= @V1 home)))
 (or $x122 $x130))))
(assert
 (let (($x193 (not (net.getX @X @Y))))
 (let (($x147 (= @Y home)))
 (or $x147 $x193))))
(assert
 (let (($x185 (not (net.getX @X @Z))))
 (let (($x229 (= @Z home)))
 (or $x229 $x185))))
(assert
 (let (($x206 (not (net.getX home @Y))))
 (let (($x147 (= @Y home)))
 (or $x147 $x206))))
(assert
 (let (($x164 (not (net.getX @X home))))
 (let (($x231 (= home home)))
 (or $x231 $x164))))
(assert
 (let (($x153 (not (net.getX @V1 @V0))))
 (let (($x238 (= @V0 home)))
 (or $x238 $x153))))
(assert
 (let (($x133 (not (net.getX @V0 @V1))))
 (let (($x122 (= @V1 home)))
 (or $x122 $x133))))
(assert
 (let (($x168 (not (= (cache.state_ @X) exclusive))))
 (or $x168 dir.head)))
(assert
 (let (($x243 (not (= (cache.state_ @V0) exclusive))))
 (or $x243 dir.head)))
(assert
 (let (($x122 (= @V1 home)))
 (or $x122 (not (net.fack @V0 @V1)))))
(assert
 (let (($x188 (not (net.put @Y @X))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x188)))))
(assert
 (let (($x203 (not (net.put @Z @X))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x203)))))
(assert
 (let (($x174 (not (net.put home @X))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x174)))))
(assert
 (let (($x136 (not (net.put @V1 @V0))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x137 (= ?x127 get)))
 (or $x137 $x136)))))
(assert
 (let (($x200 (not (net.get @X @Y))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x200)))))
(assert
 (let (($x190 (not (net.get @X @Z))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x190)))))
(assert
 (let (($x179 (not (net.get @X home))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x179)))))
(assert
 (let (($x140 (not (net.get @V0 @V1))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x137 (= ?x127 get)))
 (or $x137 $x140)))))
(assert
 (let (($x188 (not (net.put @Y @X))))
 (let ((?x166 (cache.state_ @X)))
 (let (($x249 (= ?x166 invalid)))
 (or $x249 $x188)))))
(assert
 (let (($x203 (not (net.put @Z @X))))
 (let ((?x166 (cache.state_ @X)))
 (let (($x249 (= ?x166 invalid)))
 (or $x249 $x203)))))
(assert
 (let (($x174 (not (net.put home @X))))
 (let ((?x166 (cache.state_ @X)))
 (let (($x249 (= ?x166 invalid)))
 (or $x249 $x174)))))
(assert
 (let (($x136 (not (net.put @V1 @V0))))
 (let ((?x142 (cache.state_ @V0)))
 (let (($x143 (= ?x142 invalid)))
 (or $x143 $x136)))))
(assert
 (let (($x200 (not (net.get @X @Y))))
 (let ((?x166 (cache.state_ @X)))
 (let (($x249 (= ?x166 invalid)))
 (or $x249 $x200)))))
(assert
 (let (($x190 (not (net.get @X @Z))))
 (let ((?x166 (cache.state_ @X)))
 (let (($x249 (= ?x166 invalid)))
 (or $x249 $x190)))))
(assert
 (let (($x179 (not (net.get @X home))))
 (let ((?x166 (cache.state_ @X)))
 (let (($x249 (= ?x166 invalid)))
 (or $x249 $x179)))))
(assert
 (let (($x140 (not (net.get @V0 @V1))))
 (let ((?x142 (cache.state_ @V0)))
 (let (($x143 (= ?x142 invalid)))
 (or $x143 $x140)))))
(assert
 (let (($x147 (= @Y home)))
 (or $x147 (not (net.shwb @X @Y)))))
(assert
 (let (($x257 (not (= (cache.wait @X) none))))
 (let (($x193 (not (net.getX @X @Y))))
 (or $x193 $x257))))
(assert
 (let (($x257 (not (= (cache.wait @X) none))))
 (let (($x185 (not (net.getX @X @Z))))
 (or $x185 $x257))))
(assert
 (let (($x262 (not (= (cache.wait home) none))))
 (let (($x206 (not (net.getX home @Y))))
 (or $x206 $x262))))
(assert
 (let (($x257 (not (= (cache.wait @X) none))))
 (let (($x164 (not (net.getX @X home))))
 (or $x164 $x257))))
(assert
 (let (($x156 (not (= (cache.wait @V1) none))))
 (let (($x153 (not (net.getX @V1 @V0))))
 (or $x153 $x156))))
(assert
 (let (($x266 (not (= (cache.wait @V0) none))))
 (let (($x133 (not (net.getX @V0 @V1))))
 (or $x133 $x266))))
(assert
 (let (($x159 (not (net.putX home @X))))
 (let ((?x160 (cache.wait @X)))
 (let (($x161 (= ?x160 getX)))
 (or $x161 $x159)))))
(assert
 (let (($x269 (not (net.putX home @V0))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x128 (= ?x127 getX)))
 (or $x128 $x269)))))
(assert
 (let (($x164 (not (net.getX @X home))))
 (let ((?x160 (cache.wait @X)))
 (let (($x161 (= ?x160 getX)))
 (or $x161 $x164)))))
(assert
 (let (($x273 (not (net.getX @V1 home))))
 (let ((?x154 (cache.wait @V1)))
 (let (($x271 (= ?x154 getX)))
 (or $x271 $x273)))))
(assert
 (let (($x276 (not (net.getX @V0 home))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x128 (= ?x127 getX)))
 (or $x128 $x276)))))
(assert
 (let (($x280 (not (net.getX home home))))
 (let ((?x260 (cache.wait home)))
 (let (($x278 (= ?x260 getX)))
 (or $x278 $x280)))))
(assert
 (let (($x168 (not (= (cache.state_ @X) exclusive))))
 (or $x168 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x243 (not (= (cache.state_ @V0) exclusive))))
 (or $x243 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x174 (not (net.put home @X))))
 (or $x174 (not (rp_net @X)))))
(assert
 (let (($x174 (not (net.put home @X))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x174)))))
(assert
 (let (($x285 (not (net.put home @V0))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x137 (= ?x127 get)))
 (or $x137 $x285)))))
(assert
 (let (($x179 (not (net.get @X home))))
 (let ((?x160 (cache.wait @X)))
 (let (($x176 (= ?x160 get)))
 (or $x176 $x179)))))
(assert
 (let (($x288 (not (net.get @V0 home))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x137 (= ?x127 get)))
 (or $x137 $x288)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x269 (not (net.putX home @V0))))
 (let (($x231 (= home home)))
 (or $x231 $x269))))
(assert
 (let (($x273 (not (net.getX @V1 home))))
 (let (($x231 (= home home)))
 (or $x231 $x273))))
(assert
 (let (($x276 (not (net.getX @V0 home))))
 (let (($x231 (= home home)))
 (or $x231 $x276))))
(assert
 (let (($x280 (not (net.getX home home))))
 (let (($x231 (= home home)))
 (or $x231 $x280))))
(assert
 (let (($x291 (not (net.getX home @Z))))
 (let (($x229 (= @Z home)))
 (or $x229 $x291))))
(assert
 (let (($x293 (not (net.getX home @V0))))
 (let (($x238 (= @V0 home)))
 (or $x238 $x293))))
(assert
 (let (($x295 (not (net.getX home @V1))))
 (let (($x122 (= @V1 home)))
 (or $x122 $x295))))
(assert
 (let (($x285 (not (net.put home @V0))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x137 (= ?x127 get)))
 (or $x137 $x285)))))
(assert
 (let (($x288 (not (net.get @V0 home))))
 (let ((?x127 (cache.wait @V0)))
 (let (($x137 (= ?x127 get)))
 (or $x137 $x288)))))
(assert
 (let (($x285 (not (net.put home @V0))))
 (let ((?x142 (cache.state_ @V0)))
 (let (($x143 (= ?x142 invalid)))
 (or $x143 $x285)))))
(assert
 (let (($x288 (not (net.get @V0 home))))
 (let ((?x142 (cache.state_ @V0)))
 (let (($x143 (= ?x142 invalid)))
 (or $x143 $x288)))))
(assert
 (let (($x156 (not (= (cache.wait @V1) none))))
 (let (($x273 (not (net.getX @V1 home))))
 (or $x273 $x156))))
(assert
 (let (($x266 (not (= (cache.wait @V0) none))))
 (let (($x276 (not (net.getX @V0 home))))
 (or $x276 $x266))))
(assert
 (let (($x262 (not (= (cache.wait home) none))))
 (let (($x280 (not (net.getX home home))))
 (or $x280 $x262))))
(assert
 (let (($x262 (not (= (cache.wait home) none))))
 (let (($x291 (not (net.getX home @Z))))
 (or $x291 $x262))))
(assert
 (let (($x262 (not (= (cache.wait home) none))))
 (let (($x293 (not (net.getX home @V0))))
 (or $x293 $x262))))
(assert
 (let (($x262 (not (= (cache.wait home) none))))
 (let (($x295 (not (net.getX home @V1))))
 (or $x295 $x262))))
(assert
 (let (($x312 (not (net.putX home @V1))))
 (let ((?x154 (cache.wait @V1)))
 (let (($x271 (= ?x154 getX)))
 (or $x271 $x312)))))
(assert
 (let (($x315 (not (net.putX home home))))
 (let ((?x260 (cache.wait home)))
 (let (($x278 (= ?x260 getX)))
 (or $x278 $x315)))))
(assert
 (let (($x319 (not (net.put home @V1))))
 (let ((?x154 (cache.wait @V1)))
 (let (($x317 (= ?x154 get)))
 (or $x317 $x319)))))
(assert
 (let (($x323 (not (net.put home home))))
 (let ((?x260 (cache.wait home)))
 (let (($x321 (= ?x260 get)))
 (or $x321 $x323)))))
(assert
 (let (($x326 (not (net.get @V1 home))))
 (let ((?x154 (cache.wait @V1)))
 (let (($x317 (= ?x154 get)))
 (or $x317 $x326)))))
(assert
 (let (($x329 (not (net.get home home))))
 (let ((?x260 (cache.wait home)))
 (let (($x321 (= ?x260 get)))
 (or $x321 $x329)))))
(assert
 (let (($x312 (not (net.putX home @V1))))
 (let (($x231 (= home home)))
 (or $x231 $x312))))
(assert
 (let (($x315 (not (net.putX home home))))
 (let (($x231 (= home home)))
 (or $x231 $x315))))
(assert
 (let (($x319 (not (net.put home @V1))))
 (let ((?x154 (cache.wait @V1)))
 (let (($x317 (= ?x154 get)))
 (or $x317 $x319)))))
(assert
 (let (($x323 (not (net.put home home))))
 (let ((?x260 (cache.wait home)))
 (let (($x321 (= ?x260 get)))
 (or $x321 $x323)))))
(assert
 (let (($x326 (not (net.get @V1 home))))
 (let ((?x154 (cache.wait @V1)))
 (let (($x317 (= ?x154 get)))
 (or $x317 $x326)))))
(assert
 (let (($x329 (not (net.get home home))))
 (let ((?x260 (cache.wait home)))
 (let (($x321 (= ?x260 get)))
 (or $x321 $x329)))))
(assert
 (let (($x319 (not (net.put home @V1))))
 (let ((?x333 (cache.state_ @V1)))
 (let (($x334 (= ?x333 invalid)))
 (or $x334 $x319)))))
(assert
 (let (($x323 (not (net.put home home))))
 (let ((?x336 (cache.state_ home)))
 (let (($x337 (= ?x336 invalid)))
 (or $x337 $x323)))))
(assert
 (let (($x326 (not (net.get @V1 home))))
 (let ((?x333 (cache.state_ @V1)))
 (let (($x334 (= ?x333 invalid)))
 (or $x334 $x326)))))
(assert
 (let (($x329 (not (net.get home home))))
 (let ((?x336 (cache.state_ home)))
 (let (($x337 (= ?x336 invalid)))
 (or $x337 $x329)))))
(assert
 (let (($x342 (not (= (cache.state_ @V1) exclusive))))
 (or $x342 (not (= (cache.wait @V1) getX)))))
(assert
 (let (($x346 (not (= (cache.state_ home) exclusive))))
 (or $x346 (not (= (cache.wait home) getX)))))
(assert
 (let (($x342 (not (= (cache.state_ @V1) exclusive))))
 (or $x342 dir.head)))
(assert
 (let (($x346 (not (= (cache.state_ home) exclusive))))
 (or $x346 dir.head)))
(check-sat)
