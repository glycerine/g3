(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun __cache.state_ (id) cache_state_)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun dir.hptr () id)
(declare-fun __net.put (id id) Bool)
(assert
 (__net.put __src __dst))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x42 (cache.state_ @X)))
 (= ?x42 (ite (and (= @X __dst)) shared (__cache.state_ @X)))))
(assert
 (let ((?x48 (cache.state_ @Y)))
 (= ?x48 (ite (and (= @Y __dst)) shared (__cache.state_ @Y)))))
(assert
 (or (= __src home) (= __src real_owner) (not (__net.put __src __dst))))
(assert
 (let (($x89 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X real_owner) $x89)))
(assert
 (let (($x93 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y real_owner) $x93)))
(assert
 (let (($x89 (not (= (__cache.state_ @X) exclusive))))
 (or (= @X dir.hptr) $x89)))
(assert
 (let (($x93 (not (= (__cache.state_ @Y) exclusive))))
 (or (= @Y dir.hptr) $x93)))
(assert
 (not (__net.put home __dst)))
(assert
 (not (__net.put dir.hptr __dst)))
(assert
 (or (= home home) (= home real_owner) (not (__net.put home __dst))))
(assert
 (or (= dir.hptr home) (= dir.hptr real_owner) (not (__net.put dir.hptr __dst))))
(check-sat)
