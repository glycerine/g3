(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun home () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(assert
 (or (dir.shlist dir.hptr) (not dir.head)))
(assert
 (let (($x168 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x45 (or (dir.shlist dir.hptr) (not dir.head))))
 (let (($x204 (not (net.getX home @Y))))
 (let (($x183 (not (net.getX @X @Z))))
 (let (($x191 (not (net.getX @X @Y))))
 (let (($x192 (= @Y @Z)))
 (let (($x205 (and (or $x192 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x192 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x192 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x192 $x191 $x183) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x183 (not (net.putX @Y @X))) $x204 $x45 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x168 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x205))))))))))
(assert
 (let (($x180 (not (net.putX @Y @X))))
 (let (($x145 (= @Y home)))
 (or $x145 $x180))))
(assert
 (let (($x195 (not (net.putX @Z @X))))
 (let (($x227 (= @Z home)))
 (or $x227 $x195))))
(assert
 (let (($x157 (not (net.putX home @X))))
 (let (($x229 (= home home)))
 (or $x229 $x157))))
(assert
 (let (($x128 (not (net.putX @V1 @V0))))
 (let (($x120 (= @V1 home)))
 (or $x120 $x128))))
(assert
 (let (($x191 (not (net.getX @X @Y))))
 (let (($x145 (= @Y home)))
 (or $x145 $x191))))
(assert
 (let (($x183 (not (net.getX @X @Z))))
 (let (($x227 (= @Z home)))
 (or $x227 $x183))))
(assert
 (let (($x204 (not (net.getX home @Y))))
 (let (($x145 (= @Y home)))
 (or $x145 $x204))))
(assert
 (let (($x162 (not (net.getX @X home))))
 (let (($x229 (= home home)))
 (or $x229 $x162))))
(assert
 (let (($x151 (not (net.getX @V1 @V0))))
 (let (($x236 (= @V0 home)))
 (or $x236 $x151))))
(assert
 (let (($x131 (not (net.getX @V0 @V1))))
 (let (($x120 (= @V1 home)))
 (or $x120 $x131))))
(assert
 (let (($x120 (= @V1 home)))
 (or $x120 (not (net.fack @V0 @V1)))))
(assert
 (let (($x186 (not (net.put @Y @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x186)))))
(assert
 (let (($x201 (not (net.put @Z @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x201)))))
(assert
 (let (($x172 (not (net.put home @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x172)))))
(assert
 (let (($x134 (not (net.put @V1 @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x134)))))
(assert
 (let (($x198 (not (net.get @X @Y))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x198)))))
(assert
 (let (($x188 (not (net.get @X @Z))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x188)))))
(assert
 (let (($x177 (not (net.get @X home))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x177)))))
(assert
 (let (($x138 (not (net.get @V0 @V1))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x138)))))
(assert
 (let (($x186 (not (net.put @Y @X))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x243 (= ?x164 invalid)))
 (or $x243 $x186)))))
(assert
 (let (($x201 (not (net.put @Z @X))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x243 (= ?x164 invalid)))
 (or $x243 $x201)))))
(assert
 (let (($x172 (not (net.put home @X))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x243 (= ?x164 invalid)))
 (or $x243 $x172)))))
(assert
 (let (($x134 (not (net.put @V1 @V0))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x134)))))
(assert
 (let (($x198 (not (net.get @X @Y))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x243 (= ?x164 invalid)))
 (or $x243 $x198)))))
(assert
 (let (($x188 (not (net.get @X @Z))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x243 (= ?x164 invalid)))
 (or $x243 $x188)))))
(assert
 (let (($x177 (not (net.get @X home))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x243 (= ?x164 invalid)))
 (or $x243 $x177)))))
(assert
 (let (($x138 (not (net.get @V0 @V1))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x138)))))
(assert
 (let (($x145 (= @Y home)))
 (or $x145 (not (net.shwb @X @Y)))))
(assert
 (let (($x251 (not (= (cache.wait @X) none))))
 (let (($x191 (not (net.getX @X @Y))))
 (or $x191 $x251))))
(assert
 (let (($x251 (not (= (cache.wait @X) none))))
 (let (($x183 (not (net.getX @X @Z))))
 (or $x183 $x251))))
(assert
 (let (($x256 (not (= (cache.wait home) none))))
 (let (($x204 (not (net.getX home @Y))))
 (or $x204 $x256))))
(assert
 (let (($x251 (not (= (cache.wait @X) none))))
 (let (($x162 (not (net.getX @X home))))
 (or $x162 $x251))))
(assert
 (let (($x154 (not (= (cache.wait @V1) none))))
 (let (($x151 (not (net.getX @V1 @V0))))
 (or $x151 $x154))))
(assert
 (let (($x260 (not (= (cache.wait @V0) none))))
 (let (($x131 (not (net.getX @V0 @V1))))
 (or $x131 $x260))))
(assert
 (let (($x157 (not (net.putX home @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x159 (= ?x158 getX)))
 (or $x159 $x157)))))
(assert
 (let (($x263 (not (net.putX home @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x126 (= ?x125 getX)))
 (or $x126 $x263)))))
(assert
 (let (($x162 (not (net.getX @X home))))
 (let ((?x158 (cache.wait @X)))
 (let (($x159 (= ?x158 getX)))
 (or $x159 $x162)))))
(assert
 (let (($x267 (not (net.getX @V1 home))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x265 (= ?x152 getX)))
 (or $x265 $x267)))))
(assert
 (let (($x270 (not (net.getX @V0 home))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x126 (= ?x125 getX)))
 (or $x126 $x270)))))
(assert
 (let (($x274 (not (net.getX home home))))
 (let ((?x254 (cache.wait home)))
 (let (($x272 (= ?x254 getX)))
 (or $x272 $x274)))))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (let (($x172 (not (net.put home @X))))
 (or $x172 (not (rp_net @X)))))
(assert
 (let (($x172 (not (net.put home @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x172)))))
(assert
 (let (($x281 (not (net.put home @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x281)))))
(assert
 (let (($x177 (not (net.get @X home))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x177)))))
(assert
 (let (($x284 (not (net.get @V0 home))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x284)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x263 (not (net.putX home @V0))))
 (let (($x229 (= home home)))
 (or $x229 $x263))))
(assert
 (let (($x267 (not (net.getX @V1 home))))
 (let (($x229 (= home home)))
 (or $x229 $x267))))
(assert
 (let (($x270 (not (net.getX @V0 home))))
 (let (($x229 (= home home)))
 (or $x229 $x270))))
(assert
 (let (($x274 (not (net.getX home home))))
 (let (($x229 (= home home)))
 (or $x229 $x274))))
(assert
 (let (($x287 (not (net.getX home @Z))))
 (let (($x227 (= @Z home)))
 (or $x227 $x287))))
(assert
 (let (($x289 (not (net.getX home @V0))))
 (let (($x236 (= @V0 home)))
 (or $x236 $x289))))
(assert
 (let (($x291 (not (net.getX home @V1))))
 (let (($x120 (= @V1 home)))
 (or $x120 $x291))))
(assert
 (let (($x281 (not (net.put home @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x281)))))
(assert
 (let (($x284 (not (net.get @V0 home))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x284)))))
(assert
 (let (($x281 (not (net.put home @V0))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x281)))))
(assert
 (let (($x284 (not (net.get @V0 home))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x284)))))
(assert
 (let (($x154 (not (= (cache.wait @V1) none))))
 (let (($x267 (not (net.getX @V1 home))))
 (or $x267 $x154))))
(assert
 (let (($x260 (not (= (cache.wait @V0) none))))
 (let (($x270 (not (net.getX @V0 home))))
 (or $x270 $x260))))
(assert
 (let (($x256 (not (= (cache.wait home) none))))
 (let (($x274 (not (net.getX home home))))
 (or $x274 $x256))))
(assert
 (let (($x256 (not (= (cache.wait home) none))))
 (let (($x287 (not (net.getX home @Z))))
 (or $x287 $x256))))
(assert
 (let (($x256 (not (= (cache.wait home) none))))
 (let (($x289 (not (net.getX home @V0))))
 (or $x289 $x256))))
(assert
 (let (($x256 (not (= (cache.wait home) none))))
 (let (($x291 (not (net.getX home @V1))))
 (or $x291 $x256))))
(assert
 (let (($x308 (not (net.putX home @V1))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x265 (= ?x152 getX)))
 (or $x265 $x308)))))
(assert
 (let (($x311 (not (net.putX home home))))
 (let ((?x254 (cache.wait home)))
 (let (($x272 (= ?x254 getX)))
 (or $x272 $x311)))))
(assert
 (let (($x315 (not (net.put home @V1))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x313 (= ?x152 get)))
 (or $x313 $x315)))))
(assert
 (let (($x319 (not (net.put home home))))
 (let ((?x254 (cache.wait home)))
 (let (($x317 (= ?x254 get)))
 (or $x317 $x319)))))
(assert
 (let (($x322 (not (net.get @V1 home))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x313 (= ?x152 get)))
 (or $x313 $x322)))))
(assert
 (let (($x325 (not (net.get home home))))
 (let ((?x254 (cache.wait home)))
 (let (($x317 (= ?x254 get)))
 (or $x317 $x325)))))
(assert
 (let (($x308 (not (net.putX home @V1))))
 (let (($x229 (= home home)))
 (or $x229 $x308))))
(assert
 (let (($x311 (not (net.putX home home))))
 (let (($x229 (= home home)))
 (or $x229 $x311))))
(assert
 (let (($x315 (not (net.put home @V1))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x313 (= ?x152 get)))
 (or $x313 $x315)))))
(assert
 (let (($x319 (not (net.put home home))))
 (let ((?x254 (cache.wait home)))
 (let (($x317 (= ?x254 get)))
 (or $x317 $x319)))))
(assert
 (let (($x322 (not (net.get @V1 home))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x313 (= ?x152 get)))
 (or $x313 $x322)))))
(assert
 (let (($x325 (not (net.get home home))))
 (let ((?x254 (cache.wait home)))
 (let (($x317 (= ?x254 get)))
 (or $x317 $x325)))))
(assert
 (let (($x315 (not (net.put home @V1))))
 (let ((?x329 (cache.state_ @V1)))
 (let (($x330 (= ?x329 invalid)))
 (or $x330 $x315)))))
(assert
 (let (($x319 (not (net.put home home))))
 (let ((?x332 (cache.state_ home)))
 (let (($x333 (= ?x332 invalid)))
 (or $x333 $x319)))))
(assert
 (let (($x322 (not (net.get @V1 home))))
 (let ((?x329 (cache.state_ @V1)))
 (let (($x330 (= ?x329 invalid)))
 (or $x330 $x322)))))
(assert
 (let (($x325 (not (net.get home home))))
 (let ((?x332 (cache.state_ home)))
 (let (($x333 (= ?x332 invalid)))
 (or $x333 $x325)))))
(assert
 (or (not (= (cache.state_ @V1) exclusive)) (not (= (cache.wait @V1) getX))))
(assert
 (or (not (= (cache.state_ home) exclusive)) (not (= (cache.wait home) getX))))
(check-sat)
