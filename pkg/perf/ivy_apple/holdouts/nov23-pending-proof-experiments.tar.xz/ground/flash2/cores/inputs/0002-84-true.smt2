(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun __dir.hptr () id)
(declare-fun home () id)
(declare-fun __src () id)
(declare-fun dir.hptr () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun real_owner () id)
(declare-fun dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun __net.fack (id id) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun dir.shlist (id) Bool)
(assert
 (let (($x42 (not dir.head)))
 (or (__dir.shlist __dir.hptr) $x42)))
(assert
 (__net.fack __src home))
(assert
 (= dir.hptr (ite __ts0_a __src __dir.hptr)))
(assert
 (let (($x190 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x228 (not (net.getX home @Y))))
 (let (($x207 (not (net.getX @X @Z))))
 (let (($x215 (not (net.getX @X @Y))))
 (let (($x216 (= @Y @Z)))
 (let (($x229 (and (or $x216 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x216 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x216 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x216 $x215 $x207) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x207 (not (net.putX @Y @X))) $x228 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x190 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x229)))))))))
(assert
 (let (($x201 (dir.shlist dir.hptr)))
 (= $x201 (ite __ts0_a (= dir.hptr __src) (__dir.shlist dir.hptr)))))
(assert
 (let (($x256 (__net.fack @V0 @V1)))
 (let (($x144 (net.fack @V0 @V1)))
 (= $x144 (ite (and (= @V0 __src) (= @V1 home)) false $x256)))))
(assert
 (let (($x204 (not (net.putX @Y @X))))
 (let (($x167 (= @Y home)))
 (or $x167 $x204))))
(assert
 (let (($x219 (not (net.putX @Z @X))))
 (let (($x260 (= @Z home)))
 (or $x260 $x219))))
(assert
 (let (($x179 (not (net.putX home @X))))
 (let (($x262 (= home home)))
 (or $x262 $x179))))
(assert
 (let (($x150 (not (net.putX @V1 @V0))))
 (let (($x142 (= @V1 home)))
 (or $x142 $x150))))
(assert
 (let (($x215 (not (net.getX @X @Y))))
 (let (($x167 (= @Y home)))
 (or $x167 $x215))))
(assert
 (let (($x207 (not (net.getX @X @Z))))
 (let (($x260 (= @Z home)))
 (or $x260 $x207))))
(assert
 (let (($x228 (not (net.getX home @Y))))
 (let (($x167 (= @Y home)))
 (or $x167 $x228))))
(assert
 (let (($x184 (not (net.getX @X home))))
 (let (($x262 (= home home)))
 (or $x262 $x184))))
(assert
 (let (($x173 (not (net.getX @V1 @V0))))
 (let (($x269 (= @V0 home)))
 (or $x269 $x173))))
(assert
 (let (($x153 (not (net.getX @V0 @V1))))
 (let (($x142 (= @V1 home)))
 (or $x142 $x153))))
(assert
 (let (($x124 (__net.fack __src home)))
 (let (($x273 (not $x124)))
 (or (= __src real_owner) $x273))))
(assert
 (let (($x256 (__net.fack @V0 @V1)))
 (let (($x276 (not $x256)))
 (or (= @V0 real_owner) $x276))))
(assert
 (let (($x124 (__net.fack __src home)))
 (let (($x273 (not $x124)))
 (let (($x262 (= home home)))
 (or $x262 $x273)))))
(assert
 (let (($x256 (__net.fack @V0 @V1)))
 (let (($x276 (not $x256)))
 (let (($x142 (= @V1 home)))
 (or $x142 $x276)))))
(assert
 (let (($x210 (not (net.put @Y @X))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x210)))))
(assert
 (let (($x225 (not (net.put @Z @X))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x225)))))
(assert
 (let (($x194 (not (net.put home @X))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x194)))))
(assert
 (let (($x156 (not (net.put @V1 @V0))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x157 (= ?x147 get)))
 (or $x157 $x156)))))
(assert
 (let (($x222 (not (net.get @X @Y))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x222)))))
(assert
 (let (($x212 (not (net.get @X @Z))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x212)))))
(assert
 (let (($x199 (not (net.get @X home))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x199)))))
(assert
 (let (($x160 (not (net.get @V0 @V1))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x157 (= ?x147 get)))
 (or $x157 $x160)))))
(assert
 (let (($x210 (not (net.put @Y @X))))
 (let ((?x186 (cache.state_ @X)))
 (let (($x284 (= ?x186 invalid)))
 (or $x284 $x210)))))
(assert
 (let (($x225 (not (net.put @Z @X))))
 (let ((?x186 (cache.state_ @X)))
 (let (($x284 (= ?x186 invalid)))
 (or $x284 $x225)))))
(assert
 (let (($x194 (not (net.put home @X))))
 (let ((?x186 (cache.state_ @X)))
 (let (($x284 (= ?x186 invalid)))
 (or $x284 $x194)))))
(assert
 (let (($x156 (not (net.put @V1 @V0))))
 (let ((?x162 (cache.state_ @V0)))
 (let (($x163 (= ?x162 invalid)))
 (or $x163 $x156)))))
(assert
 (let (($x222 (not (net.get @X @Y))))
 (let ((?x186 (cache.state_ @X)))
 (let (($x284 (= ?x186 invalid)))
 (or $x284 $x222)))))
(assert
 (let (($x212 (not (net.get @X @Z))))
 (let ((?x186 (cache.state_ @X)))
 (let (($x284 (= ?x186 invalid)))
 (or $x284 $x212)))))
(assert
 (let (($x199 (not (net.get @X home))))
 (let ((?x186 (cache.state_ @X)))
 (let (($x284 (= ?x186 invalid)))
 (or $x284 $x199)))))
(assert
 (let (($x160 (not (net.get @V0 @V1))))
 (let ((?x162 (cache.state_ @V0)))
 (let (($x163 (= ?x162 invalid)))
 (or $x163 $x160)))))
(assert
 (let (($x167 (= @Y home)))
 (or $x167 (not (net.shwb @X @Y)))))
(assert
 (let (($x292 (not (= (cache.wait @X) none))))
 (let (($x215 (not (net.getX @X @Y))))
 (or $x215 $x292))))
(assert
 (let (($x292 (not (= (cache.wait @X) none))))
 (let (($x207 (not (net.getX @X @Z))))
 (or $x207 $x292))))
(assert
 (let (($x297 (not (= (cache.wait home) none))))
 (let (($x228 (not (net.getX home @Y))))
 (or $x228 $x297))))
(assert
 (let (($x292 (not (= (cache.wait @X) none))))
 (let (($x184 (not (net.getX @X home))))
 (or $x184 $x292))))
(assert
 (let (($x176 (not (= (cache.wait @V1) none))))
 (let (($x173 (not (net.getX @V1 @V0))))
 (or $x173 $x176))))
(assert
 (let (($x301 (not (= (cache.wait @V0) none))))
 (let (($x153 (not (net.getX @V0 @V1))))
 (or $x153 $x301))))
(assert
 (let (($x179 (not (net.putX home @X))))
 (let ((?x180 (cache.wait @X)))
 (let (($x181 (= ?x180 getX)))
 (or $x181 $x179)))))
(assert
 (let (($x304 (not (net.putX home @V0))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x148 (= ?x147 getX)))
 (or $x148 $x304)))))
(assert
 (let (($x184 (not (net.getX @X home))))
 (let ((?x180 (cache.wait @X)))
 (let (($x181 (= ?x180 getX)))
 (or $x181 $x184)))))
(assert
 (let (($x308 (not (net.getX @V1 home))))
 (let ((?x174 (cache.wait @V1)))
 (let (($x306 (= ?x174 getX)))
 (or $x306 $x308)))))
(assert
 (let (($x311 (not (net.getX @V0 home))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x148 (= ?x147 getX)))
 (or $x148 $x311)))))
(assert
 (let (($x315 (not (net.getX home home))))
 (let ((?x295 (cache.wait home)))
 (let (($x313 (= ?x295 getX)))
 (or $x313 $x315)))))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (let (($x194 (not (net.put home @X))))
 (or $x194 (not (rp_net @X)))))
(assert
 (let (($x194 (not (net.put home @X))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x194)))))
(assert
 (let (($x322 (not (net.put home @V0))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x157 (= ?x147 get)))
 (or $x157 $x322)))))
(assert
 (let (($x199 (not (net.get @X home))))
 (let ((?x180 (cache.wait @X)))
 (let (($x196 (= ?x180 get)))
 (or $x196 $x199)))))
(assert
 (let (($x325 (not (net.get @V0 home))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x157 (= ?x147 get)))
 (or $x157 $x325)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x304 (not (net.putX home @V0))))
 (let (($x262 (= home home)))
 (or $x262 $x304))))
(assert
 (let (($x308 (not (net.getX @V1 home))))
 (let (($x262 (= home home)))
 (or $x262 $x308))))
(assert
 (let (($x311 (not (net.getX @V0 home))))
 (let (($x262 (= home home)))
 (or $x262 $x311))))
(assert
 (let (($x315 (not (net.getX home home))))
 (let (($x262 (= home home)))
 (or $x262 $x315))))
(assert
 (let (($x328 (not (net.getX home @Z))))
 (let (($x260 (= @Z home)))
 (or $x260 $x328))))
(assert
 (let (($x330 (not (net.getX home @V0))))
 (let (($x269 (= @V0 home)))
 (or $x269 $x330))))
(assert
 (let (($x332 (not (net.getX home @V1))))
 (let (($x142 (= @V1 home)))
 (or $x142 $x332))))
(assert
 (let (($x322 (not (net.put home @V0))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x157 (= ?x147 get)))
 (or $x157 $x322)))))
(assert
 (let (($x325 (not (net.get @V0 home))))
 (let ((?x147 (cache.wait @V0)))
 (let (($x157 (= ?x147 get)))
 (or $x157 $x325)))))
(assert
 (let (($x322 (not (net.put home @V0))))
 (let ((?x162 (cache.state_ @V0)))
 (let (($x163 (= ?x162 invalid)))
 (or $x163 $x322)))))
(assert
 (let (($x325 (not (net.get @V0 home))))
 (let ((?x162 (cache.state_ @V0)))
 (let (($x163 (= ?x162 invalid)))
 (or $x163 $x325)))))
(assert
 (let (($x176 (not (= (cache.wait @V1) none))))
 (let (($x308 (not (net.getX @V1 home))))
 (or $x308 $x176))))
(assert
 (let (($x301 (not (= (cache.wait @V0) none))))
 (let (($x311 (not (net.getX @V0 home))))
 (or $x311 $x301))))
(assert
 (let (($x297 (not (= (cache.wait home) none))))
 (let (($x315 (not (net.getX home home))))
 (or $x315 $x297))))
(assert
 (let (($x297 (not (= (cache.wait home) none))))
 (let (($x328 (not (net.getX home @Z))))
 (or $x328 $x297))))
(assert
 (let (($x297 (not (= (cache.wait home) none))))
 (let (($x330 (not (net.getX home @V0))))
 (or $x330 $x297))))
(assert
 (let (($x297 (not (= (cache.wait home) none))))
 (let (($x332 (not (net.getX home @V1))))
 (or $x332 $x297))))
(assert
 (let (($x349 (not (net.putX home @V1))))
 (let ((?x174 (cache.wait @V1)))
 (let (($x306 (= ?x174 getX)))
 (or $x306 $x349)))))
(assert
 (let (($x352 (not (net.putX home home))))
 (let ((?x295 (cache.wait home)))
 (let (($x313 (= ?x295 getX)))
 (or $x313 $x352)))))
(assert
 (let (($x356 (not (net.put home @V1))))
 (let ((?x174 (cache.wait @V1)))
 (let (($x354 (= ?x174 get)))
 (or $x354 $x356)))))
(assert
 (let (($x360 (not (net.put home home))))
 (let ((?x295 (cache.wait home)))
 (let (($x358 (= ?x295 get)))
 (or $x358 $x360)))))
(assert
 (let (($x363 (not (net.get @V1 home))))
 (let ((?x174 (cache.wait @V1)))
 (let (($x354 (= ?x174 get)))
 (or $x354 $x363)))))
(assert
 (let (($x366 (not (net.get home home))))
 (let ((?x295 (cache.wait home)))
 (let (($x358 (= ?x295 get)))
 (or $x358 $x366)))))
(assert
 (let (($x349 (not (net.putX home @V1))))
 (let (($x262 (= home home)))
 (or $x262 $x349))))
(assert
 (let (($x352 (not (net.putX home home))))
 (let (($x262 (= home home)))
 (or $x262 $x352))))
(assert
 (let (($x356 (not (net.put home @V1))))
 (let ((?x174 (cache.wait @V1)))
 (let (($x354 (= ?x174 get)))
 (or $x354 $x356)))))
(assert
 (let (($x360 (not (net.put home home))))
 (let ((?x295 (cache.wait home)))
 (let (($x358 (= ?x295 get)))
 (or $x358 $x360)))))
(assert
 (let (($x363 (not (net.get @V1 home))))
 (let ((?x174 (cache.wait @V1)))
 (let (($x354 (= ?x174 get)))
 (or $x354 $x363)))))
(assert
 (let (($x366 (not (net.get home home))))
 (let ((?x295 (cache.wait home)))
 (let (($x358 (= ?x295 get)))
 (or $x358 $x366)))))
(assert
 (let (($x356 (not (net.put home @V1))))
 (let ((?x370 (cache.state_ @V1)))
 (let (($x371 (= ?x370 invalid)))
 (or $x371 $x356)))))
(assert
 (let (($x360 (not (net.put home home))))
 (let ((?x373 (cache.state_ home)))
 (let (($x374 (= ?x373 invalid)))
 (or $x374 $x360)))))
(assert
 (let (($x363 (not (net.get @V1 home))))
 (let ((?x370 (cache.state_ @V1)))
 (let (($x371 (= ?x370 invalid)))
 (or $x371 $x363)))))
(assert
 (let (($x366 (not (net.get home home))))
 (let ((?x373 (cache.state_ home)))
 (let (($x374 (= ?x373 invalid)))
 (or $x374 $x366)))))
(assert
 (or (not (= (cache.state_ @V1) exclusive)) (not (= (cache.wait @V1) getX))))
(assert
 (or (not (= (cache.state_ home) exclusive)) (not (= (cache.wait home) getX))))
(check-sat)
