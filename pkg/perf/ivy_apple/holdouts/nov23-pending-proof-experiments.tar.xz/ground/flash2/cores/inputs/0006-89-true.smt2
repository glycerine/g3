(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun home () id)
(declare-fun __src () id)
(declare-fun dir.hptr () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun __net.get (id id) Bool)
(declare-fun dir.dirty () Bool)
(declare-fun rp_net (id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun __net.put (id id) Bool)
(assert
 (__net.get __src home))
(assert
 (not dir.dirty))
(assert
 (not (rp_net __src)))
(assert
 (= dir.hptr __src))
(assert
 (let (($x180 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x220 (not (net.getX home @Y))))
 (let (($x199 (not (net.getX @X @Z))))
 (let (($x207 (not (net.getX @X @Y))))
 (let (($x208 (= @Y @Z)))
 (let (($x221 (and (or $x208 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x208 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x208 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x208 $x207 $x199) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x199 (not (net.putX @Y @X))) $x220 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x180 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x221)))))))))
(assert
 (let (($x193 (dir.shlist dir.hptr)))
 (= $x193 (ite (and (= dir.hptr __src)) true (__dir.shlist dir.hptr)))))
(assert
 (let (($x248 (__net.put @Y @X)))
 (let (($x201 (net.put @Y @X)))
 (= $x201 (ite (and (= @Y home) (= @X __src)) true $x248)))))
(assert
 (let (($x253 (__net.put @Z @X)))
 (let (($x216 (net.put @Z @X)))
 (= $x216 (ite (and (= @Z home) (= @X __src)) true $x253)))))
(assert
 (let (($x258 (__net.put home @X)))
 (let (($x183 (net.put home @X)))
 (= $x183 (ite (and (= home home) (= @X __src)) true $x258)))))
(assert
 (let (($x263 (__net.put @V1 @V0)))
 (let (($x145 (net.put @V1 @V0)))
 (= $x145 (ite (and (= @V1 home) (= @V0 __src)) true $x263)))))
(assert
 (let (($x267 (__net.get @X @Y)))
 (let (($x213 (net.get @X @Y)))
 (= $x213 (ite (and (= @X __src) (= @Y home)) false $x267)))))
(assert
 (let (($x271 (__net.get @X @Z)))
 (let (($x203 (net.get @X @Z)))
 (= $x203 (ite (and (= @X __src) (= @Z home)) false $x271)))))
(assert
 (let (($x275 (__net.get @X home)))
 (let (($x188 (net.get @X home)))
 (= $x188 (ite (and (= @X __src) (= home home)) false $x275)))))
(assert
 (let (($x279 (__net.get @V0 @V1)))
 (let (($x149 (net.get @V0 @V1)))
 (= $x149 (ite (and (= @V0 __src) (= @V1 home)) false $x279)))))
(assert
 (let (($x248 (__net.put @Y @X)))
 (let (($x282 (not $x248)))
 (let (($x157 (= @Y home)))
 (or $x157 $x282 dir.dirty)))))
(assert
 (let (($x253 (__net.put @Z @X)))
 (let (($x284 (not $x253)))
 (let (($x251 (= @Z home)))
 (or $x251 $x284 dir.dirty)))))
(assert
 (let (($x258 (__net.put home @X)))
 (let (($x286 (not $x258)))
 (let (($x256 (= home home)))
 (or $x256 $x286 dir.dirty)))))
(assert
 (let (($x263 (__net.put @V1 @V0)))
 (let (($x288 (not $x263)))
 (let (($x132 (= @V1 home)))
 (or $x132 $x288 dir.dirty)))))
(assert
 (let (($x196 (not (net.putX @Y @X))))
 (let (($x157 (= @Y home)))
 (or $x157 $x196 dir.dirty))))
(assert
 (let (($x211 (not (net.putX @Z @X))))
 (let (($x251 (= @Z home)))
 (or $x251 $x211 dir.dirty))))
(assert
 (let (($x169 (not (net.putX home @X))))
 (let (($x256 (= home home)))
 (or $x256 $x169 dir.dirty))))
(assert
 (let (($x140 (not (net.putX @V1 @V0))))
 (let (($x132 (= @V1 home)))
 (or $x132 $x140 dir.dirty))))
(assert
 (let (($x105 (__net.get __src home)))
 (let (($x294 (not $x105)))
 (let (($x256 (= home home)))
 (or $x256 $x294 dir.dirty)))))
(assert
 (let (($x267 (__net.get @X @Y)))
 (let (($x296 (not $x267)))
 (let (($x157 (= @Y home)))
 (or $x157 $x296 dir.dirty)))))
(assert
 (let (($x271 (__net.get @X @Z)))
 (let (($x298 (not $x271)))
 (let (($x251 (= @Z home)))
 (or $x251 $x298 dir.dirty)))))
(assert
 (let (($x275 (__net.get @X home)))
 (let (($x300 (not $x275)))
 (let (($x256 (= home home)))
 (or $x256 $x300 dir.dirty)))))
(assert
 (let (($x279 (__net.get @V0 @V1)))
 (let (($x302 (not $x279)))
 (let (($x132 (= @V1 home)))
 (or $x132 $x302 dir.dirty)))))
(assert
 (let (($x207 (not (net.getX @X @Y))))
 (let (($x157 (= @Y home)))
 (or $x157 $x207 dir.dirty))))
(assert
 (let (($x199 (not (net.getX @X @Z))))
 (let (($x251 (= @Z home)))
 (or $x251 $x199 dir.dirty))))
(assert
 (let (($x220 (not (net.getX home @Y))))
 (let (($x157 (= @Y home)))
 (or $x157 $x220 dir.dirty))))
(assert
 (let (($x174 (not (net.getX @X home))))
 (let (($x256 (= home home)))
 (or $x256 $x174 dir.dirty))))
(assert
 (let (($x163 (not (net.getX @V1 @V0))))
 (let (($x308 (= @V0 home)))
 (or $x308 $x163 dir.dirty))))
(assert
 (let (($x143 (not (net.getX @V0 @V1))))
 (let (($x132 (= @V1 home)))
 (or $x132 $x143 dir.dirty))))
(assert
 (let (($x196 (not (net.putX @Y @X))))
 (or $x196 dir.dirty)))
(assert
 (let (($x211 (not (net.putX @Z @X))))
 (or $x211 dir.dirty)))
(assert
 (let (($x169 (not (net.putX home @X))))
 (or $x169 dir.dirty)))
(assert
 (let (($x140 (not (net.putX @V1 @V0))))
 (or $x140 dir.dirty)))
(assert
 (let (($x258 (__net.put home @X)))
 (not $x258)))
(assert
 (not (__net.put home @V0)))
(assert
 (let (($x132 (= @V1 home)))
 (or $x132 (not (net.fack @V0 @V1)))))
(assert
 (let (($x105 (__net.get __src home)))
 (let (($x294 (not $x105)))
 (let ((?x317 (cache.wait __src)))
 (let (($x318 (= ?x317 get)))
 (or $x318 $x294))))))
(assert
 (let (($x267 (__net.get @X @Y)))
 (let (($x296 (not $x267)))
 (let ((?x170 (cache.wait @X)))
 (let (($x186 (= ?x170 get)))
 (or $x186 $x296))))))
(assert
 (let (($x271 (__net.get @X @Z)))
 (let (($x298 (not $x271)))
 (let ((?x170 (cache.wait @X)))
 (let (($x186 (= ?x170 get)))
 (or $x186 $x298))))))
(assert
 (let (($x275 (__net.get @X home)))
 (let (($x300 (not $x275)))
 (let ((?x170 (cache.wait @X)))
 (let (($x186 (= ?x170 get)))
 (or $x186 $x300))))))
(assert
 (let (($x279 (__net.get @V0 @V1)))
 (let (($x302 (not $x279)))
 (let ((?x137 (cache.wait @V0)))
 (let (($x147 (= ?x137 get)))
 (or $x147 $x302))))))
(assert
 (let (($x248 (__net.put @Y @X)))
 (let (($x282 (not $x248)))
 (let ((?x176 (cache.state_ @X)))
 (let (($x324 (= ?x176 invalid)))
 (or $x324 $x282))))))
(assert
 (let (($x253 (__net.put @Z @X)))
 (let (($x284 (not $x253)))
 (let ((?x176 (cache.state_ @X)))
 (let (($x324 (= ?x176 invalid)))
 (or $x324 $x284))))))
(assert
 (let (($x258 (__net.put home @X)))
 (let (($x286 (not $x258)))
 (let ((?x176 (cache.state_ @X)))
 (let (($x324 (= ?x176 invalid)))
 (or $x324 $x286))))))
(assert
 (let (($x263 (__net.put @V1 @V0)))
 (let (($x288 (not $x263)))
 (let ((?x152 (cache.state_ @V0)))
 (let (($x153 (= ?x152 invalid)))
 (or $x153 $x288))))))
(assert
 (let (($x316 (not (__net.put home @V0))))
 (let ((?x152 (cache.state_ @V0)))
 (let (($x153 (= ?x152 invalid)))
 (or $x153 $x316)))))
(assert
 (let (($x105 (__net.get __src home)))
 (let (($x294 (not $x105)))
 (let ((?x330 (cache.state_ __src)))
 (let (($x331 (= ?x330 invalid)))
 (or $x331 $x294))))))
(assert
 (let (($x267 (__net.get @X @Y)))
 (let (($x296 (not $x267)))
 (let ((?x176 (cache.state_ @X)))
 (let (($x324 (= ?x176 invalid)))
 (or $x324 $x296))))))
(assert
 (let (($x271 (__net.get @X @Z)))
 (let (($x298 (not $x271)))
 (let ((?x176 (cache.state_ @X)))
 (let (($x324 (= ?x176 invalid)))
 (or $x324 $x298))))))
(assert
 (let (($x275 (__net.get @X home)))
 (let (($x300 (not $x275)))
 (let ((?x176 (cache.state_ @X)))
 (let (($x324 (= ?x176 invalid)))
 (or $x324 $x300))))))
(assert
 (let (($x279 (__net.get @V0 @V1)))
 (let (($x302 (not $x279)))
 (let ((?x152 (cache.state_ @V0)))
 (let (($x153 (= ?x152 invalid)))
 (or $x153 $x302))))))
(assert
 (let (($x157 (= @Y home)))
 (or $x157 (not (net.shwb @X @Y)))))
(assert
 (let (($x338 (not (= (cache.wait @X) none))))
 (let (($x207 (not (net.getX @X @Y))))
 (or $x207 $x338))))
(assert
 (let (($x338 (not (= (cache.wait @X) none))))
 (let (($x199 (not (net.getX @X @Z))))
 (or $x199 $x338))))
(assert
 (let (($x343 (not (= (cache.wait home) none))))
 (let (($x220 (not (net.getX home @Y))))
 (or $x220 $x343))))
(assert
 (let (($x338 (not (= (cache.wait @X) none))))
 (let (($x174 (not (net.getX @X home))))
 (or $x174 $x338))))
(assert
 (let (($x166 (not (= (cache.wait @V1) none))))
 (let (($x163 (not (net.getX @V1 @V0))))
 (or $x163 $x166))))
(assert
 (let (($x347 (not (= (cache.wait @V0) none))))
 (let (($x143 (not (net.getX @V0 @V1))))
 (or $x143 $x347))))
(assert
 (let (($x169 (not (net.putX home @X))))
 (let ((?x170 (cache.wait @X)))
 (let (($x171 (= ?x170 getX)))
 (or $x171 $x169)))))
(assert
 (let (($x350 (not (net.putX home @V0))))
 (let ((?x137 (cache.wait @V0)))
 (let (($x138 (= ?x137 getX)))
 (or $x138 $x350)))))
(assert
 (let (($x174 (not (net.getX @X home))))
 (let ((?x170 (cache.wait @X)))
 (let (($x171 (= ?x170 getX)))
 (or $x171 $x174)))))
(assert
 (let (($x354 (not (net.getX @V1 home))))
 (let ((?x164 (cache.wait @V1)))
 (let (($x352 (= ?x164 getX)))
 (or $x352 $x354)))))
(assert
 (let (($x357 (not (net.getX @V0 home))))
 (let ((?x137 (cache.wait @V0)))
 (let (($x138 (= ?x137 getX)))
 (or $x138 $x357)))))
(assert
 (let (($x361 (not (net.getX __src home))))
 (let ((?x317 (cache.wait __src)))
 (let (($x359 (= ?x317 getX)))
 (or $x359 $x361)))))
(assert
 (let (($x365 (not (net.getX home home))))
 (let ((?x341 (cache.wait home)))
 (let (($x363 (= ?x341 getX)))
 (or $x363 $x365)))))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (or (not (= (cache.state_ __src) exclusive)) (not (= (cache.wait __src) getX))))
(assert
 (let (($x108 (not (rp_net __src))))
 (let (($x376 (not (__net.put home __src))))
 (or $x376 $x108))))
(assert
 (let (($x182 (not (rp_net @X))))
 (let (($x258 (__net.put home @X)))
 (let (($x286 (not $x258)))
 (or $x286 $x182)))))
(assert
 (let (($x258 (__net.put home @X)))
 (let (($x286 (not $x258)))
 (let ((?x170 (cache.wait @X)))
 (let (($x186 (= ?x170 get)))
 (or $x186 $x286))))))
(assert
 (let (($x382 (not (__net.put home @V1))))
 (let ((?x164 (cache.wait @V1)))
 (let (($x380 (= ?x164 get)))
 (or $x380 $x382)))))
(assert
 (let (($x316 (not (__net.put home @V0))))
 (let ((?x137 (cache.wait @V0)))
 (let (($x147 (= ?x137 get)))
 (or $x147 $x316)))))
(assert
 (let (($x376 (not (__net.put home __src))))
 (let ((?x317 (cache.wait __src)))
 (let (($x318 (= ?x317 get)))
 (or $x318 $x376)))))
(assert
 (let (($x388 (not (__net.put home home))))
 (let ((?x341 (cache.wait home)))
 (let (($x386 (= ?x341 get)))
 (or $x386 $x388)))))
(assert
 (let (($x105 (__net.get __src home)))
 (let (($x294 (not $x105)))
 (let ((?x317 (cache.wait __src)))
 (let (($x318 (= ?x317 get)))
 (or $x318 $x294))))))
(assert
 (let (($x275 (__net.get @X home)))
 (let (($x300 (not $x275)))
 (let ((?x170 (cache.wait @X)))
 (let (($x186 (= ?x170 get)))
 (or $x186 $x300))))))
(assert
 (let (($x391 (not (__net.get @V0 home))))
 (let ((?x137 (cache.wait @V0)))
 (let (($x147 (= ?x137 get)))
 (or $x147 $x391)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x316 (not (__net.put home @V0))))
 (let (($x256 (= home home)))
 (or $x256 $x316 dir.dirty))))
(assert
 (let (($x376 (not (__net.put home __src))))
 (let (($x256 (= home home)))
 (or $x256 $x376 dir.dirty))))
(assert
 (let (($x382 (not (__net.put home @V1))))
 (let (($x256 (= home home)))
 (or $x256 $x382 dir.dirty))))
(assert
 (let (($x388 (not (__net.put home home))))
 (let (($x256 (= home home)))
 (or $x256 $x388 dir.dirty))))
(assert
 (let (($x350 (not (net.putX home @V0))))
 (let (($x256 (= home home)))
 (or $x256 $x350 dir.dirty))))
(assert
 (let (($x391 (not (__net.get @V0 home))))
 (let (($x256 (= home home)))
 (or $x256 $x391 dir.dirty))))
(assert
 (let (($x354 (not (net.getX @V1 home))))
 (let (($x256 (= home home)))
 (or $x256 $x354 dir.dirty))))
(assert
 (let (($x357 (not (net.getX @V0 home))))
 (let (($x256 (= home home)))
 (or $x256 $x357 dir.dirty))))
(assert
 (let (($x361 (not (net.getX __src home))))
 (let (($x256 (= home home)))
 (or $x256 $x361 dir.dirty))))
(assert
 (let (($x365 (not (net.getX home home))))
 (let (($x256 (= home home)))
 (or $x256 $x365 dir.dirty))))
(assert
 (let (($x394 (not (net.getX home @Z))))
 (let (($x251 (= @Z home)))
 (or $x251 $x394 dir.dirty))))
(assert
 (let (($x396 (not (net.getX home @V0))))
 (let (($x308 (= @V0 home)))
 (or $x308 $x396 dir.dirty))))
(assert
 (let (($x398 (not (net.getX home @V1))))
 (let (($x132 (= @V1 home)))
 (or $x132 $x398 dir.dirty))))
(assert
 (let (($x350 (not (net.putX home @V0))))
 (or $x350 dir.dirty)))
(assert
 (not (__net.put home __src)))
(assert
 (not (__net.put home @V1)))
(assert
 (not (__net.put home home)))
(assert
 (let (($x391 (not (__net.get @V0 home))))
 (let ((?x137 (cache.wait @V0)))
 (let (($x147 (= ?x137 get)))
 (or $x147 $x391)))))
(assert
 (let (($x376 (not (__net.put home __src))))
 (let ((?x330 (cache.state_ __src)))
 (let (($x331 (= ?x330 invalid)))
 (or $x331 $x376)))))
(assert
 (let (($x382 (not (__net.put home @V1))))
 (let ((?x414 (cache.state_ @V1)))
 (let (($x415 (= ?x414 invalid)))
 (or $x415 $x382)))))
(assert
 (let (($x388 (not (__net.put home home))))
 (let ((?x417 (cache.state_ home)))
 (let (($x418 (= ?x417 invalid)))
 (or $x418 $x388)))))
(assert
 (let (($x391 (not (__net.get @V0 home))))
 (let ((?x152 (cache.state_ @V0)))
 (let (($x153 (= ?x152 invalid)))
 (or $x153 $x391)))))
(assert
 (let (($x166 (not (= (cache.wait @V1) none))))
 (let (($x354 (not (net.getX @V1 home))))
 (or $x354 $x166))))
(assert
 (let (($x347 (not (= (cache.wait @V0) none))))
 (let (($x357 (not (net.getX @V0 home))))
 (or $x357 $x347))))
(assert
 (let (($x361 (not (net.getX __src home))))
 (or $x361 (not (= (cache.wait __src) none)))))
(assert
 (let (($x343 (not (= (cache.wait home) none))))
 (let (($x365 (not (net.getX home home))))
 (or $x365 $x343))))
(assert
 (let (($x343 (not (= (cache.wait home) none))))
 (let (($x394 (not (net.getX home @Z))))
 (or $x394 $x343))))
(assert
 (let (($x343 (not (= (cache.wait home) none))))
 (let (($x396 (not (net.getX home @V0))))
 (or $x396 $x343))))
(assert
 (let (($x343 (not (= (cache.wait home) none))))
 (let (($x398 (not (net.getX home @V1))))
 (or $x398 $x343))))
(assert
 (or (not (= (cache.state_ @V1) exclusive)) (not (= (cache.wait @V1) getX))))
(assert
 (or (not (= (cache.state_ home) exclusive)) (not (= (cache.wait home) getX))))
(assert
 (let (($x439 (not (__net.get @V1 home))))
 (let ((?x164 (cache.wait @V1)))
 (let (($x380 (= ?x164 get)))
 (or $x380 $x439)))))
(assert
 (let (($x442 (not (__net.get home home))))
 (let ((?x341 (cache.wait home)))
 (let (($x386 (= ?x341 get)))
 (or $x386 $x442)))))
(assert
 (let (($x439 (not (__net.get @V1 home))))
 (let (($x256 (= home home)))
 (or $x256 $x439 dir.dirty))))
(assert
 (let (($x442 (not (__net.get home home))))
 (let (($x256 (= home home)))
 (or $x256 $x442 dir.dirty))))
(assert
 (let (($x439 (not (__net.get @V1 home))))
 (let ((?x164 (cache.wait @V1)))
 (let (($x380 (= ?x164 get)))
 (or $x380 $x439)))))
(assert
 (let (($x442 (not (__net.get home home))))
 (let ((?x341 (cache.wait home)))
 (let (($x386 (= ?x341 get)))
 (or $x386 $x442)))))
(assert
 (let (($x439 (not (__net.get @V1 home))))
 (let ((?x414 (cache.state_ @V1)))
 (let (($x415 (= ?x414 invalid)))
 (or $x415 $x439)))))
(assert
 (let (($x442 (not (__net.get home home))))
 (let ((?x417 (cache.state_ home)))
 (let (($x418 (= ?x417 invalid)))
 (or $x418 $x442)))))
(check-sat)
