(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun home () id)
(declare-fun __src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun real_owner () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __net.getX (id id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(assert
 (or (dir.shlist dir.hptr) (not dir.head)))
(assert
 (__net.getX __src home))
(assert
 (let (($x178 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x37 (or (dir.shlist dir.hptr) (not dir.head))))
 (let (($x192 (net.getX @X @Z)))
 (let (($x193 (not $x192)))
 (let (($x202 (= @Y @Z)))
 (let (($x215 (and (or $x202 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x202 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x202 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x202 (not (net.getX @X @Y)) $x193) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x193 (not (net.putX @Y @X))) (not (net.getX home @Y)) $x37 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x178 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x215)))))))))
(assert
 (let (($x238 (__net.getX @X @Y)))
 (let (($x200 (net.getX @X @Y)))
 (= $x200 (ite (and (= @X __src) (= @Y home)) false $x238)))))
(assert
 (let (($x243 (__net.getX @X @Z)))
 (let (($x192 (net.getX @X @Z)))
 (= $x192 (ite (and (= @X __src) (= @Z home)) false $x243)))))
(assert
 (let (($x248 (__net.getX home @Y)))
 (let (($x213 (net.getX home @Y)))
 (= $x213 (ite (and (= home __src) (= @Y home)) false $x248)))))
(assert
 (let (($x253 (__net.getX @X home)))
 (let (($x171 (net.getX @X home)))
 (= $x171 (ite (and (= @X __src) (= home home)) false $x253)))))
(assert
 (let (($x259 (__net.getX @V1 @V0)))
 (let (($x160 (net.getX @V1 @V0)))
 (= $x160 (ite (and (= @V1 __src) (= @V0 home)) false $x259)))))
(assert
 (let (($x264 (__net.getX @V0 @V1)))
 (let (($x140 (net.getX @V0 @V1)))
 (= $x140 (ite (and (= @V0 __src) (= @V1 home)) false $x264)))))
(assert
 (let (($x190 (not (net.putX @Y @X))))
 (let (($x155 (= @Y home)))
 (or $x155 $x190))))
(assert
 (let (($x205 (not (net.putX @Z @X))))
 (let (($x241 (= @Z home)))
 (or $x241 $x205))))
(assert
 (let (($x167 (not (net.putX home @X))))
 (let (($x251 (= home home)))
 (or $x251 $x167))))
(assert
 (let (($x138 (not (net.putX @V1 @V0))))
 (let (($x130 (= @V1 home)))
 (or $x130 $x138))))
(assert
 (let (($x122 (__net.getX __src home)))
 (let (($x271 (not $x122)))
 (let (($x251 (= home home)))
 (or $x251 $x271)))))
(assert
 (let (($x238 (__net.getX @X @Y)))
 (let (($x273 (not $x238)))
 (let (($x155 (= @Y home)))
 (or $x155 $x273)))))
(assert
 (let (($x243 (__net.getX @X @Z)))
 (let (($x275 (not $x243)))
 (let (($x241 (= @Z home)))
 (or $x241 $x275)))))
(assert
 (let (($x248 (__net.getX home @Y)))
 (let (($x277 (not $x248)))
 (let (($x155 (= @Y home)))
 (or $x155 $x277)))))
(assert
 (let (($x253 (__net.getX @X home)))
 (let (($x279 (not $x253)))
 (let (($x251 (= home home)))
 (or $x251 $x279)))))
(assert
 (let (($x259 (__net.getX @V1 @V0)))
 (let (($x281 (not $x259)))
 (let (($x257 (= @V0 home)))
 (or $x257 $x281)))))
(assert
 (let (($x264 (__net.getX @V0 @V1)))
 (let (($x283 (not $x264)))
 (let (($x130 (= @V1 home)))
 (or $x130 $x283)))))
(assert
 (let (($x190 (not (net.putX @Y @X))))
 (let (($x285 (= real_owner @X)))
 (or $x285 $x190))))
(assert
 (let (($x205 (not (net.putX @Z @X))))
 (let (($x285 (= real_owner @X)))
 (or $x285 $x205))))
(assert
 (let (($x167 (not (net.putX home @X))))
 (let (($x285 (= real_owner @X)))
 (or $x285 $x167))))
(assert
 (let (($x138 (not (net.putX @V1 @V0))))
 (let (($x289 (= real_owner @V0)))
 (or $x289 $x138))))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x130 (= @V1 home)))
 (or $x130 (not (net.fack @V0 @V1)))))
(assert
 (let (($x122 (__net.getX __src home)))
 (let (($x271 (not $x122)))
 (or (= (cache.wait __src) getX) $x271))))
(assert
 (let (($x238 (__net.getX @X @Y)))
 (let (($x273 (not $x238)))
 (let ((?x168 (cache.wait @X)))
 (let (($x169 (= ?x168 getX)))
 (or $x169 $x273))))))
(assert
 (let (($x243 (__net.getX @X @Z)))
 (let (($x275 (not $x243)))
 (let ((?x168 (cache.wait @X)))
 (let (($x169 (= ?x168 getX)))
 (or $x169 $x275))))))
(assert
 (let (($x248 (__net.getX home @Y)))
 (let (($x277 (not $x248)))
 (let ((?x298 (cache.wait home)))
 (let (($x299 (= ?x298 getX)))
 (or $x299 $x277))))))
(assert
 (let (($x253 (__net.getX @X home)))
 (let (($x279 (not $x253)))
 (let ((?x168 (cache.wait @X)))
 (let (($x169 (= ?x168 getX)))
 (or $x169 $x279))))))
(assert
 (let (($x259 (__net.getX @V1 @V0)))
 (let (($x281 (not $x259)))
 (let ((?x162 (cache.wait @V1)))
 (let (($x302 (= ?x162 getX)))
 (or $x302 $x281))))))
(assert
 (let (($x264 (__net.getX @V0 @V1)))
 (let (($x283 (not $x264)))
 (let ((?x135 (cache.wait @V0)))
 (let (($x136 (= ?x135 getX)))
 (or $x136 $x283))))))
(assert
 (let (($x196 (not (net.put @Y @X))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x196)))))
(assert
 (let (($x211 (not (net.put @Z @X))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x211)))))
(assert
 (let (($x182 (not (net.put home @X))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x182)))))
(assert
 (let (($x144 (not (net.put @V1 @V0))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x145 (= ?x135 get)))
 (or $x145 $x144)))))
(assert
 (let (($x208 (not (net.get @X @Y))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x208)))))
(assert
 (let (($x198 (not (net.get @X @Z))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x198)))))
(assert
 (let (($x187 (not (net.get @X home))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x187)))))
(assert
 (let (($x148 (not (net.get @V0 @V1))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x145 (= ?x135 get)))
 (or $x145 $x148)))))
(assert
 (let (($x196 (not (net.put @Y @X))))
 (let ((?x174 (cache.state_ @X)))
 (let (($x309 (= ?x174 invalid)))
 (or $x309 $x196)))))
(assert
 (let (($x211 (not (net.put @Z @X))))
 (let ((?x174 (cache.state_ @X)))
 (let (($x309 (= ?x174 invalid)))
 (or $x309 $x211)))))
(assert
 (let (($x182 (not (net.put home @X))))
 (let ((?x174 (cache.state_ @X)))
 (let (($x309 (= ?x174 invalid)))
 (or $x309 $x182)))))
(assert
 (let (($x144 (not (net.put @V1 @V0))))
 (let ((?x150 (cache.state_ @V0)))
 (let (($x151 (= ?x150 invalid)))
 (or $x151 $x144)))))
(assert
 (let (($x208 (not (net.get @X @Y))))
 (let ((?x174 (cache.state_ @X)))
 (let (($x309 (= ?x174 invalid)))
 (or $x309 $x208)))))
(assert
 (let (($x198 (not (net.get @X @Z))))
 (let ((?x174 (cache.state_ @X)))
 (let (($x309 (= ?x174 invalid)))
 (or $x309 $x198)))))
(assert
 (let (($x187 (not (net.get @X home))))
 (let ((?x174 (cache.state_ @X)))
 (let (($x309 (= ?x174 invalid)))
 (or $x309 $x187)))))
(assert
 (let (($x148 (not (net.get @V0 @V1))))
 (let ((?x150 (cache.state_ @V0)))
 (let (($x151 (= ?x150 invalid)))
 (or $x151 $x148)))))
(assert
 (let (($x155 (= @Y home)))
 (or $x155 (not (net.shwb @X @Y)))))
(assert
 (let (($x122 (__net.getX __src home)))
 (let (($x271 (not $x122)))
 (or $x271 (not (= (cache.wait __src) none))))))
(assert
 (let (($x320 (not (= (cache.wait @X) none))))
 (let (($x238 (__net.getX @X @Y)))
 (let (($x273 (not $x238)))
 (or $x273 $x320)))))
(assert
 (let (($x320 (not (= (cache.wait @X) none))))
 (let (($x243 (__net.getX @X @Z)))
 (let (($x275 (not $x243)))
 (or $x275 $x320)))))
(assert
 (let (($x324 (not (= (cache.wait home) none))))
 (let (($x248 (__net.getX home @Y)))
 (let (($x277 (not $x248)))
 (or $x277 $x324)))))
(assert
 (let (($x320 (not (= (cache.wait @X) none))))
 (let (($x253 (__net.getX @X home)))
 (let (($x279 (not $x253)))
 (or $x279 $x320)))))
(assert
 (let (($x164 (not (= (cache.wait @V1) none))))
 (let (($x259 (__net.getX @V1 @V0)))
 (let (($x281 (not $x259)))
 (or $x281 $x164)))))
(assert
 (let (($x329 (not (= (cache.wait @V0) none))))
 (let (($x264 (__net.getX @V0 @V1)))
 (let (($x283 (not $x264)))
 (or $x283 $x329)))))
(assert
 (let (($x167 (not (net.putX home @X))))
 (let ((?x168 (cache.wait @X)))
 (let (($x169 (= ?x168 getX)))
 (or $x169 $x167)))))
(assert
 (let (($x292 (not (net.putX home @V0))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x136 (= ?x135 getX)))
 (or $x136 $x292)))))
(assert
 (let (($x253 (__net.getX @X home)))
 (let (($x279 (not $x253)))
 (let ((?x168 (cache.wait @X)))
 (let (($x169 (= ?x168 getX)))
 (or $x169 $x279))))))
(assert
 (let (($x333 (not (__net.getX @V1 home))))
 (let ((?x162 (cache.wait @V1)))
 (let (($x302 (= ?x162 getX)))
 (or $x302 $x333)))))
(assert
 (let (($x336 (not (__net.getX @V0 home))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x136 (= ?x135 getX)))
 (or $x136 $x336)))))
(assert
 (let (($x122 (__net.getX __src home)))
 (let (($x271 (not $x122)))
 (or (= (cache.wait __src) getX) $x271))))
(assert
 (let (($x339 (not (__net.getX home home))))
 (let ((?x298 (cache.wait home)))
 (let (($x299 (= ?x298 getX)))
 (or $x299 $x339)))))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (let (($x182 (not (net.put home @X))))
 (or $x182 (not (rp_net @X)))))
(assert
 (let (($x182 (not (net.put home @X))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x182)))))
(assert
 (let (($x346 (not (net.put home @V0))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x145 (= ?x135 get)))
 (or $x145 $x346)))))
(assert
 (let (($x187 (not (net.get @X home))))
 (let ((?x168 (cache.wait @X)))
 (let (($x184 (= ?x168 get)))
 (or $x184 $x187)))))
(assert
 (let (($x349 (not (net.get @V0 home))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x145 (= ?x135 get)))
 (or $x145 $x349)))))
(assert
 (not (__net.getX home home)))
(assert
 (let (($x248 (__net.getX home @Y)))
 (not $x248)))
(assert
 (not (__net.getX home @Z)))
(assert
 (not (__net.getX home @V0)))
(assert
 (not (__net.getX home @V1)))
(assert
 (let (($x292 (not (net.putX home @V0))))
 (let (($x251 (= home home)))
 (or $x251 $x292))))
(assert
 (let (($x333 (not (__net.getX @V1 home))))
 (let (($x251 (= home home)))
 (or $x251 $x333))))
(assert
 (let (($x336 (not (__net.getX @V0 home))))
 (let (($x251 (= home home)))
 (or $x251 $x336))))
(assert
 (let (($x339 (not (__net.getX home home))))
 (let (($x251 (= home home)))
 (or $x251 $x339))))
(assert
 (let (($x352 (not (__net.getX home @Z))))
 (let (($x241 (= @Z home)))
 (or $x241 $x352))))
(assert
 (let (($x354 (not (__net.getX home @V0))))
 (let (($x257 (= @V0 home)))
 (or $x257 $x354))))
(assert
 (let (($x356 (not (__net.getX home @V1))))
 (let (($x130 (= @V1 home)))
 (or $x130 $x356))))
(assert
 (let (($x292 (not (net.putX home @V0))))
 (let (($x289 (= real_owner @V0)))
 (or $x289 $x292))))
(assert
 (let (($x333 (not (__net.getX @V1 home))))
 (let ((?x162 (cache.wait @V1)))
 (let (($x302 (= ?x162 getX)))
 (or $x302 $x333)))))
(assert
 (let (($x336 (not (__net.getX @V0 home))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x136 (= ?x135 getX)))
 (or $x136 $x336)))))
(assert
 (let (($x339 (not (__net.getX home home))))
 (let ((?x298 (cache.wait home)))
 (let (($x299 (= ?x298 getX)))
 (or $x299 $x339)))))
(assert
 (let (($x352 (not (__net.getX home @Z))))
 (let ((?x298 (cache.wait home)))
 (let (($x299 (= ?x298 getX)))
 (or $x299 $x352)))))
(assert
 (let (($x354 (not (__net.getX home @V0))))
 (let ((?x298 (cache.wait home)))
 (let (($x299 (= ?x298 getX)))
 (or $x299 $x354)))))
(assert
 (let (($x356 (not (__net.getX home @V1))))
 (let ((?x298 (cache.wait home)))
 (let (($x299 (= ?x298 getX)))
 (or $x299 $x356)))))
(assert
 (let (($x346 (not (net.put home @V0))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x145 (= ?x135 get)))
 (or $x145 $x346)))))
(assert
 (let (($x349 (not (net.get @V0 home))))
 (let ((?x135 (cache.wait @V0)))
 (let (($x145 (= ?x135 get)))
 (or $x145 $x349)))))
(assert
 (let (($x346 (not (net.put home @V0))))
 (let ((?x150 (cache.state_ @V0)))
 (let (($x151 (= ?x150 invalid)))
 (or $x151 $x346)))))
(assert
 (let (($x349 (not (net.get @V0 home))))
 (let ((?x150 (cache.state_ @V0)))
 (let (($x151 (= ?x150 invalid)))
 (or $x151 $x349)))))
(assert
 (let (($x164 (not (= (cache.wait @V1) none))))
 (let (($x333 (not (__net.getX @V1 home))))
 (or $x333 $x164))))
(assert
 (let (($x329 (not (= (cache.wait @V0) none))))
 (let (($x336 (not (__net.getX @V0 home))))
 (or $x336 $x329))))
(assert
 (let (($x324 (not (= (cache.wait home) none))))
 (let (($x339 (not (__net.getX home home))))
 (or $x339 $x324))))
(assert
 (let (($x324 (not (= (cache.wait home) none))))
 (let (($x352 (not (__net.getX home @Z))))
 (or $x352 $x324))))
(assert
 (let (($x324 (not (= (cache.wait home) none))))
 (let (($x354 (not (__net.getX home @V0))))
 (or $x354 $x324))))
(assert
 (let (($x324 (not (= (cache.wait home) none))))
 (let (($x356 (not (__net.getX home @V1))))
 (or $x356 $x324))))
(check-sat)
