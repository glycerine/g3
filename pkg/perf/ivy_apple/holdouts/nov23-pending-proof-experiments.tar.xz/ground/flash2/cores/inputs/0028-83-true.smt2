(set-info :status unknown)
(declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-fun __cache.state_ (id) cache_state_)
(declare-fun __src () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun real_owner () id)
(assert
 (let ((?x20 (__cache.state_ __src)))
 (= ?x20 shared)))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x30 (cache.state_ @X)))
 (= ?x30 (ite (and (= @X __src)) invalid (__cache.state_ @X)))))
(assert
 (let ((?x36 (cache.state_ @Y)))
 (= ?x36 (ite (and (= @Y __src)) invalid (__cache.state_ @Y)))))
(assert
 (let (($x71 (= __src real_owner)))
 (or $x71 (not (= (__cache.state_ __src) exclusive)))))
(assert
 (let (($x75 (= @X real_owner)))
 (or $x75 (not (= (__cache.state_ @X) exclusive)))))
(assert
 (let (($x79 (= @Y real_owner)))
 (or $x79 (not (= (__cache.state_ @Y) exclusive)))))
(assert
 (let (($x71 (= __src real_owner)))
 (or $x71 (not (= (__cache.state_ __src) shared)))))
(assert
 (let (($x75 (= @X real_owner)))
 (or $x75 (not (= (__cache.state_ @X) shared)))))
(assert
 (let (($x79 (= @Y real_owner)))
 (or $x79 (not (= (__cache.state_ @Y) shared)))))
(check-sat)
