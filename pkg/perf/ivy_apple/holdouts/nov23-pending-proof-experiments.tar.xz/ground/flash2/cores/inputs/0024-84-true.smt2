(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun dir.dirty () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(assert
 (or (dir.shlist dir.hptr) (not dir.head)))
(assert
 (not (= (cache.wait real_owner) get)))
(assert
 (let ((?x125 (cache.wait home)))
 (= ?x125 none)))
(assert
 (not dir.dirty))
(assert
 (let (($x175 (not (= (cache.state_ @X) exclusive))))
 (let (($x33 (or (dir.shlist dir.hptr) (not dir.head))))
 (let (($x213 (not (net.getX home @Y))))
 (let (($x192 (not (net.getX @X @Z))))
 (let (($x200 (not (net.getX @X @Y))))
 (let (($x201 (= @Y @Z)))
 (let (($x214 (and (or $x201 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x201 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x201 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x201 $x200 $x192) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x192 (not (net.putX @Y @X))) $x213 $x33 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x175 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x214))))))))))
(assert
 (let (($x195 (not (net.put @Y @X))))
 (let (($x154 (= @Y home)))
 (or $x154 $x195 dir.dirty))))
(assert
 (let (($x210 (not (net.put @Z @X))))
 (let (($x236 (= @Z home)))
 (or $x236 $x210 dir.dirty))))
(assert
 (let (($x181 (not (net.put home @X))))
 (let (($x238 (= home home)))
 (or $x238 $x181 dir.dirty))))
(assert
 (let (($x143 (not (net.put @V1 @V0))))
 (let (($x129 (= @V1 home)))
 (or $x129 $x143 dir.dirty))))
(assert
 (let (($x189 (not (net.putX @Y @X))))
 (let (($x154 (= @Y home)))
 (or $x154 $x189 dir.dirty))))
(assert
 (let (($x204 (not (net.putX @Z @X))))
 (let (($x236 (= @Z home)))
 (or $x236 $x204 dir.dirty))))
(assert
 (let (($x166 (not (net.putX home @X))))
 (let (($x238 (= home home)))
 (or $x238 $x166 dir.dirty))))
(assert
 (let (($x137 (not (net.putX @V1 @V0))))
 (let (($x129 (= @V1 home)))
 (or $x129 $x137 dir.dirty))))
(assert
 (let (($x207 (not (net.get @X @Y))))
 (let (($x154 (= @Y home)))
 (or $x154 $x207 dir.dirty))))
(assert
 (let (($x197 (not (net.get @X @Z))))
 (let (($x236 (= @Z home)))
 (or $x236 $x197 dir.dirty))))
(assert
 (let (($x186 (not (net.get @X home))))
 (let (($x238 (= home home)))
 (or $x238 $x186 dir.dirty))))
(assert
 (let (($x147 (not (net.get @V0 @V1))))
 (let (($x129 (= @V1 home)))
 (or $x129 $x147 dir.dirty))))
(assert
 (let (($x200 (not (net.getX @X @Y))))
 (let (($x154 (= @Y home)))
 (or $x154 $x200 dir.dirty))))
(assert
 (let (($x192 (not (net.getX @X @Z))))
 (let (($x236 (= @Z home)))
 (or $x236 $x192 dir.dirty))))
(assert
 (let (($x213 (not (net.getX home @Y))))
 (let (($x154 (= @Y home)))
 (or $x154 $x213 dir.dirty))))
(assert
 (let (($x171 (not (net.getX @X home))))
 (let (($x238 (= home home)))
 (or $x238 $x171 dir.dirty))))
(assert
 (let (($x160 (not (net.getX @V1 @V0))))
 (or (= @V0 home) $x160 dir.dirty)))
(assert
 (let (($x140 (not (net.getX @V0 @V1))))
 (let (($x129 (= @V1 home)))
 (or $x129 $x140 dir.dirty))))
(assert
 (let (($x175 (not (= (cache.state_ @X) exclusive))))
 (or (= @X real_owner) $x175)))
(assert
 (let (($x260 (not (= (cache.state_ @V0) exclusive))))
 (or (= @V0 real_owner) $x260)))
(assert
 (let (($x189 (not (net.putX @Y @X))))
 (or $x189 dir.dirty)))
(assert
 (let (($x204 (not (net.putX @Z @X))))
 (or $x204 dir.dirty)))
(assert
 (let (($x166 (not (net.putX home @X))))
 (or $x166 dir.dirty)))
(assert
 (let (($x137 (not (net.putX @V1 @V0))))
 (or $x137 dir.dirty)))
(assert
 (let (($x129 (= @V1 home)))
 (or $x129 (not (net.fack @V0 @V1)))))
(assert
 (let (($x200 (not (net.getX @X @Y))))
 (let ((?x167 (cache.wait @X)))
 (let (($x168 (= ?x167 getX)))
 (or $x168 $x200)))))
(assert
 (let (($x192 (not (net.getX @X @Z))))
 (let ((?x167 (cache.wait @X)))
 (let (($x168 (= ?x167 getX)))
 (or $x168 $x192)))))
(assert
 (let (($x213 (not (net.getX home @Y))))
 (let ((?x125 (cache.wait home)))
 (let (($x268 (= ?x125 getX)))
 (or $x268 $x213)))))
(assert
 (let (($x171 (not (net.getX @X home))))
 (let ((?x167 (cache.wait @X)))
 (let (($x168 (= ?x167 getX)))
 (or $x168 $x171)))))
(assert
 (let (($x160 (not (net.getX @V1 @V0))))
 (let ((?x161 (cache.wait @V1)))
 (let (($x270 (= ?x161 getX)))
 (or $x270 $x160)))))
(assert
 (let (($x140 (not (net.getX @V0 @V1))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x135 (= ?x134 getX)))
 (or $x135 $x140)))))
(assert
 (let (($x195 (not (net.put @Y @X))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x195)))))
(assert
 (let (($x210 (not (net.put @Z @X))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x210)))))
(assert
 (let (($x181 (not (net.put home @X))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x181)))))
(assert
 (let (($x143 (not (net.put @V1 @V0))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x144 (= ?x134 get)))
 (or $x144 $x143)))))
(assert
 (let (($x207 (not (net.get @X @Y))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x207)))))
(assert
 (let (($x197 (not (net.get @X @Z))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x197)))))
(assert
 (let (($x186 (not (net.get @X home))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x186)))))
(assert
 (let (($x147 (not (net.get @V0 @V1))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x144 (= ?x134 get)))
 (or $x144 $x147)))))
(assert
 (let (($x195 (not (net.put @Y @X))))
 (let ((?x173 (cache.state_ @X)))
 (let (($x276 (= ?x173 invalid)))
 (or $x276 $x195)))))
(assert
 (let (($x210 (not (net.put @Z @X))))
 (let ((?x173 (cache.state_ @X)))
 (let (($x276 (= ?x173 invalid)))
 (or $x276 $x210)))))
(assert
 (let (($x181 (not (net.put home @X))))
 (let ((?x173 (cache.state_ @X)))
 (let (($x276 (= ?x173 invalid)))
 (or $x276 $x181)))))
(assert
 (let (($x143 (not (net.put @V1 @V0))))
 (let ((?x149 (cache.state_ @V0)))
 (let (($x150 (= ?x149 invalid)))
 (or $x150 $x143)))))
(assert
 (let (($x207 (not (net.get @X @Y))))
 (let ((?x173 (cache.state_ @X)))
 (let (($x276 (= ?x173 invalid)))
 (or $x276 $x207)))))
(assert
 (let (($x197 (not (net.get @X @Z))))
 (let ((?x173 (cache.state_ @X)))
 (let (($x276 (= ?x173 invalid)))
 (or $x276 $x197)))))
(assert
 (let (($x186 (not (net.get @X home))))
 (let ((?x173 (cache.state_ @X)))
 (let (($x276 (= ?x173 invalid)))
 (or $x276 $x186)))))
(assert
 (let (($x147 (not (net.get @V0 @V1))))
 (let ((?x149 (cache.state_ @V0)))
 (let (($x150 (= ?x149 invalid)))
 (or $x150 $x147)))))
(assert
 (let (($x154 (= @Y home)))
 (or $x154 (not (net.shwb @X @Y)))))
(assert
 (let (($x284 (not (= (cache.wait @X) none))))
 (let (($x200 (not (net.getX @X @Y))))
 (or $x200 $x284))))
(assert
 (let (($x284 (not (= (cache.wait @X) none))))
 (let (($x192 (not (net.getX @X @Z))))
 (or $x192 $x284))))
(assert
 (let ((?x125 (cache.wait home)))
 (let (($x126 (= ?x125 none)))
 (let (($x287 (not $x126)))
 (let (($x213 (not (net.getX home @Y))))
 (or $x213 $x287))))))
(assert
 (let (($x284 (not (= (cache.wait @X) none))))
 (let (($x171 (not (net.getX @X home))))
 (or $x171 $x284))))
(assert
 (let (($x163 (not (= (cache.wait @V1) none))))
 (let (($x160 (not (net.getX @V1 @V0))))
 (or $x160 $x163))))
(assert
 (let (($x291 (not (= (cache.wait @V0) none))))
 (let (($x140 (not (net.getX @V0 @V1))))
 (or $x140 $x291))))
(assert
 (let (($x166 (not (net.putX home @X))))
 (let ((?x167 (cache.wait @X)))
 (let (($x168 (= ?x167 getX)))
 (or $x168 $x166)))))
(assert
 (let (($x294 (not (net.putX home @V0))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x135 (= ?x134 getX)))
 (or $x135 $x294)))))
(assert
 (let (($x298 (not (net.getX real_owner home))))
 (or (= (cache.wait real_owner) getX) $x298)))
(assert
 (let (($x301 (not (net.getX home home))))
 (let ((?x125 (cache.wait home)))
 (let (($x268 (= ?x125 getX)))
 (or $x268 $x301)))))
(assert
 (let (($x171 (not (net.getX @X home))))
 (let ((?x167 (cache.wait @X)))
 (let (($x168 (= ?x167 getX)))
 (or $x168 $x171)))))
(assert
 (let (($x304 (not (net.getX @V1 home))))
 (let ((?x161 (cache.wait @V1)))
 (let (($x270 (= ?x161 getX)))
 (or $x270 $x304)))))
(assert
 (let (($x307 (not (net.getX @V0 home))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x135 (= ?x134 getX)))
 (or $x135 $x307)))))
(assert
 (let (($x175 (not (= (cache.state_ @X) exclusive))))
 (or $x175 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x260 (not (= (cache.state_ @V0) exclusive))))
 (or $x260 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x181 (not (net.put home @X))))
 (or $x181 (not (rp_net @X)))))
(assert
 (let (($x181 (not (net.put home @X))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x181)))))
(assert
 (let (($x312 (not (net.put home @V0))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x144 (= ?x134 get)))
 (or $x144 $x312)))))
(assert
 (let (($x186 (not (net.get @X home))))
 (let ((?x167 (cache.wait @X)))
 (let (($x183 (= ?x167 get)))
 (or $x183 $x186)))))
(assert
 (let (($x315 (not (net.get @V0 home))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x144 (= ?x134 get)))
 (or $x144 $x315)))))
(assert
 (let (($x312 (not (net.put home @V0))))
 (let (($x238 (= home home)))
 (or $x238 $x312 dir.dirty))))
(assert
 (let (($x294 (not (net.putX home @V0))))
 (let (($x238 (= home home)))
 (or $x238 $x294 dir.dirty))))
(assert
 (let (($x315 (not (net.get @V0 home))))
 (let (($x238 (= home home)))
 (or $x238 $x315 dir.dirty))))
(assert
 (let (($x298 (not (net.getX real_owner home))))
 (let (($x238 (= home home)))
 (or $x238 $x298 dir.dirty))))
(assert
 (let (($x301 (not (net.getX home home))))
 (let (($x238 (= home home)))
 (or $x238 $x301 dir.dirty))))
(assert
 (let (($x304 (not (net.getX @V1 home))))
 (let (($x238 (= home home)))
 (or $x238 $x304 dir.dirty))))
(assert
 (let (($x307 (not (net.getX @V0 home))))
 (let (($x238 (= home home)))
 (or $x238 $x307 dir.dirty))))
(assert
 (let (($x294 (not (net.putX home @V0))))
 (or $x294 dir.dirty)))
(assert
 (let (($x298 (not (net.getX real_owner home))))
 (or (= (cache.wait real_owner) getX) $x298)))
(assert
 (let (($x301 (not (net.getX home home))))
 (let ((?x125 (cache.wait home)))
 (let (($x268 (= ?x125 getX)))
 (or $x268 $x301)))))
(assert
 (let (($x304 (not (net.getX @V1 home))))
 (let ((?x161 (cache.wait @V1)))
 (let (($x270 (= ?x161 getX)))
 (or $x270 $x304)))))
(assert
 (let (($x307 (not (net.getX @V0 home))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x135 (= ?x134 getX)))
 (or $x135 $x307)))))
(assert
 (let (($x312 (not (net.put home @V0))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x144 (= ?x134 get)))
 (or $x144 $x312)))))
(assert
 (let (($x315 (not (net.get @V0 home))))
 (let ((?x134 (cache.wait @V0)))
 (let (($x144 (= ?x134 get)))
 (or $x144 $x315)))))
(assert
 (let (($x312 (not (net.put home @V0))))
 (let ((?x149 (cache.state_ @V0)))
 (let (($x150 (= ?x149 invalid)))
 (or $x150 $x312)))))
(assert
 (let (($x315 (not (net.get @V0 home))))
 (let ((?x149 (cache.state_ @V0)))
 (let (($x150 (= ?x149 invalid)))
 (or $x150 $x315)))))
(assert
 (let (($x298 (not (net.getX real_owner home))))
 (or $x298 (not (= (cache.wait real_owner) none)))))
(assert
 (let ((?x125 (cache.wait home)))
 (let (($x126 (= ?x125 none)))
 (let (($x287 (not $x126)))
 (let (($x301 (not (net.getX home home))))
 (or $x301 $x287))))))
(assert
 (let (($x163 (not (= (cache.wait @V1) none))))
 (let (($x304 (not (net.getX @V1 home))))
 (or $x304 $x163))))
(assert
 (let (($x291 (not (= (cache.wait @V0) none))))
 (let (($x307 (not (net.getX @V0 home))))
 (or $x307 $x291))))
(check-sat)
