(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun home () id)
(declare-fun __src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __dir.pending () Bool)
(declare-fun dir.dirty () Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun __m_net.get (id id) Bool)
(assert
 (let (($x42 (dir.shlist dir.hptr)))
 (or $x42 (not dir.head))))
(assert
 (let ((?x103 (cache.wait real_owner)))
 (let (($x104 (= ?x103 get)))
 (not $x104))))
(assert
 (let (($x108 (= dir.hptr real_owner)))
 (or $x108 (not dir.dirty) __dir.pending)))
(assert
 (__net.get __src home))
(assert
 (not __dir.pending))
(assert
 dir.dirty)
(assert
 (not (= __src dir.hptr)))
(assert
 (let (($x210 (not (= (cache.state_ @X) exclusive))))
 (let (($x42 (dir.shlist dir.hptr)))
 (let (($x43 (or $x42 (not dir.head))))
 (let (($x248 (not (net.getX home @Y))))
 (let (($x227 (not (net.getX @X @Z))))
 (let (($x235 (not (net.getX @X @Y))))
 (let (($x236 (= @Y @Z)))
 (let (($x249 (and (or $x236 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x236 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x236 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x236 $x235 $x227) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x227 (not (net.putX @Y @X))) $x248 $x43 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) (or $x210 (not (= (cache.wait @X) getX))) (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x249)))))))))))
(assert
 (let (($x273 (__m_net.get @X @Y)))
 (let (($x241 (net.get @X @Y)))
 (= $x241 (ite (and (= @X __src) (= @Y dir.hptr)) true $x273)))))
(assert
 (let (($x278 (__m_net.get @X @Z)))
 (let (($x231 (net.get @X @Z)))
 (= $x231 (ite (and (= @X __src) (= @Z dir.hptr)) true $x278)))))
(assert
 (let (($x283 (__m_net.get @X home)))
 (let (($x220 (net.get @X home)))
 (= $x220 (ite (and (= @X __src) (= home dir.hptr)) true $x283)))))
(assert
 (let (($x289 (__m_net.get @V0 @V1)))
 (let (($x180 (net.get @V0 @V1)))
 (= $x180 (ite (and (= @V0 __src) (= @V1 dir.hptr)) true $x289)))))
(assert
 (let (($x293 (__net.get @X @Y)))
 (let (($x273 (__m_net.get @X @Y)))
 (= $x273 (ite (and (= @X __src) (= @Y home)) false $x293)))))
(assert
 (let (($x298 (__net.get @X @Z)))
 (let (($x278 (__m_net.get @X @Z)))
 (= $x278 (ite (and (= @X __src) (= @Z home)) false $x298)))))
(assert
 (let (($x303 (__net.get @X home)))
 (let (($x283 (__m_net.get @X home)))
 (= $x283 (ite (and (= @X __src) (= home home)) false $x303)))))
(assert
 (let (($x307 (__net.get @V0 @V1)))
 (let (($x289 (__m_net.get @V0 @V1)))
 (= $x289 (ite (and (= @V0 __src) (= @V1 home)) false $x307)))))
(assert
 (let (($x230 (not (net.put @Y @X))))
 (let (($x310 (= @Y real_owner)))
 (let (($x189 (= @Y home)))
 (or $x189 $x310 $x230)))))
(assert
 (let (($x245 (not (net.put @Z @X))))
 (let (($x312 (= @Z real_owner)))
 (let (($x296 (= @Z home)))
 (or $x296 $x312 $x245)))))
(assert
 (let (($x216 (not (net.put home @X))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x216)))))
(assert
 (let (($x177 (not (net.put @V1 @V0))))
 (let (($x316 (= @V1 real_owner)))
 (let (($x163 (= @V1 home)))
 (or $x163 $x316 $x177)))))
(assert
 (let (($x146 (__net.get __src home)))
 (let (($x318 (not $x146)))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x318))))))
(assert
 (let (($x293 (__net.get @X @Y)))
 (let (($x320 (not $x293)))
 (let (($x310 (= @Y real_owner)))
 (let (($x189 (= @Y home)))
 (or $x189 $x310 $x320))))))
(assert
 (let (($x298 (__net.get @X @Z)))
 (let (($x322 (not $x298)))
 (let (($x312 (= @Z real_owner)))
 (let (($x296 (= @Z home)))
 (or $x296 $x312 $x322))))))
(assert
 (let (($x303 (__net.get @X home)))
 (let (($x324 (not $x303)))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x324))))))
(assert
 (let (($x307 (__net.get @V0 @V1)))
 (let (($x326 (not $x307)))
 (let (($x316 (= @V1 real_owner)))
 (let (($x163 (= @V1 home)))
 (or $x163 $x316 $x326))))))
(assert
 (let (($x224 (not (net.putX @Y @X))))
 (let (($x189 (= @Y home)))
 (or $x189 $x224))))
(assert
 (let (($x239 (not (net.putX @Z @X))))
 (let (($x296 (= @Z home)))
 (or $x296 $x239))))
(assert
 (let (($x201 (not (net.putX home @X))))
 (let (($x301 (= home home)))
 (or $x301 $x201))))
(assert
 (let (($x171 (not (net.putX @V1 @V0))))
 (let (($x163 (= @V1 home)))
 (or $x163 $x171))))
(assert
 (let (($x235 (not (net.getX @X @Y))))
 (let (($x189 (= @Y home)))
 (or $x189 $x235))))
(assert
 (let (($x227 (not (net.getX @X @Z))))
 (let (($x296 (= @Z home)))
 (or $x296 $x227))))
(assert
 (let (($x248 (not (net.getX home @Y))))
 (let (($x189 (= @Y home)))
 (or $x189 $x248))))
(assert
 (let (($x206 (not (net.getX @X home))))
 (let (($x301 (= home home)))
 (or $x301 $x206))))
(assert
 (let (($x195 (not (net.getX @V1 @V0))))
 (let (($x336 (= @V0 home)))
 (or $x336 $x195))))
(assert
 (let (($x174 (not (net.getX @V0 @V1))))
 (let (($x163 (= @V1 home)))
 (or $x163 $x174))))
(assert
 (let (($x210 (not (= (cache.state_ @X) exclusive))))
 (let (($x339 (= @X real_owner)))
 (or $x339 $x210))))
(assert
 (let (($x343 (not (= (cache.state_ @V0) exclusive))))
 (let (($x341 (= @V0 real_owner)))
 (or $x341 $x343))))
(assert
 (let (($x339 (= @X real_owner)))
 (or $x339 (not (= (cache.state_ @X) shared)))))
(assert
 (let (($x341 (= @V0 real_owner)))
 (or $x341 (not (= (cache.state_ @V0) shared)))))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (not (net.put dir.hptr @X)))
(assert
 (not (net.put dir.hptr @V0)))
(assert
 (let (($x230 (not (net.put @Y @X))))
 (let (($x357 (dir.shlist @X)))
 (or $x357 $x230 __dir.pending))))
(assert
 (let (($x245 (not (net.put @Z @X))))
 (let (($x357 (dir.shlist @X)))
 (or $x357 $x245 __dir.pending))))
(assert
 (let (($x216 (not (net.put home @X))))
 (let (($x357 (dir.shlist @X)))
 (or $x357 $x216 __dir.pending))))
(assert
 (let (($x177 (not (net.put @V1 @V0))))
 (let (($x361 (dir.shlist @V0)))
 (or $x361 $x177 __dir.pending))))
(assert
 (let (($x352 (not (net.put home @V0))))
 (let (($x361 (dir.shlist @V0)))
 (or $x361 $x352 __dir.pending))))
(assert
 (let (($x354 (not (net.put dir.hptr @X))))
 (let (($x357 (dir.shlist @X)))
 (or $x357 $x354 __dir.pending))))
(assert
 (let (($x356 (not (net.put dir.hptr @V0))))
 (let (($x361 (dir.shlist @V0)))
 (or $x361 $x356 __dir.pending))))
(assert
 (let (($x367 (not (net.put home dir.hptr))))
 (let (($x42 (dir.shlist dir.hptr)))
 (or $x42 $x367))))
(assert
 (let (($x216 (not (net.put home @X))))
 (let (($x357 (dir.shlist @X)))
 (or $x357 $x216))))
(assert
 (let (($x352 (not (net.put home @V0))))
 (let (($x361 (dir.shlist @V0)))
 (or $x361 $x352))))
(assert
 (let (($x373 (not (__net.get dir.hptr home))))
 (or (not (dir.shlist dir.hptr)) $x373)))
(assert
 (let (($x303 (__net.get @X home)))
 (let (($x324 (not $x303)))
 (or (not (dir.shlist @X)) $x324))))
(assert
 (let (($x379 (not (__net.get @V0 home))))
 (or (not (dir.shlist @V0)) $x379)))
(assert
 (let (($x163 (= @V1 home)))
 (or $x163 (not (net.fack @V0 @V1)))))
(assert
 (let (($x230 (not (net.put @Y @X))))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x230)))))
(assert
 (let (($x245 (not (net.put @Z @X))))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x245)))))
(assert
 (let (($x216 (not (net.put home @X))))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x216)))))
(assert
 (let (($x177 (not (net.put @V1 @V0))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x178 (= ?x168 get)))
 (or $x178 $x177)))))
(assert
 (let (($x352 (not (net.put home @V0))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x178 (= ?x168 get)))
 (or $x178 $x352)))))
(assert
 (let (($x354 (not (net.put dir.hptr @X))))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x354)))))
(assert
 (let (($x356 (not (net.put dir.hptr @V0))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x178 (= ?x168 get)))
 (or $x178 $x356)))))
(assert
 (let (($x367 (not (net.put home dir.hptr))))
 (let ((?x386 (cache.wait dir.hptr)))
 (let (($x387 (= ?x386 get)))
 (or $x387 $x367)))))
(assert
 (let (($x146 (__net.get __src home)))
 (let (($x318 (not $x146)))
 (let ((?x389 (cache.wait __src)))
 (let (($x390 (= ?x389 get)))
 (or $x390 $x318))))))
(assert
 (let (($x293 (__net.get @X @Y)))
 (let (($x320 (not $x293)))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x320))))))
(assert
 (let (($x298 (__net.get @X @Z)))
 (let (($x322 (not $x298)))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x322))))))
(assert
 (let (($x303 (__net.get @X home)))
 (let (($x324 (not $x303)))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x324))))))
(assert
 (let (($x307 (__net.get @V0 @V1)))
 (let (($x326 (not $x307)))
 (let ((?x168 (cache.wait @V0)))
 (let (($x178 (= ?x168 get)))
 (or $x178 $x326))))))
(assert
 (let (($x373 (not (__net.get dir.hptr home))))
 (let ((?x386 (cache.wait dir.hptr)))
 (let (($x387 (= ?x386 get)))
 (or $x387 $x373)))))
(assert
 (let (($x379 (not (__net.get @V0 home))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x178 (= ?x168 get)))
 (or $x178 $x379)))))
(assert
 (let (($x189 (= @Y home)))
 (or $x189 (not (net.shwb @X @Y)))))
(assert
 (let (($x399 (not (= (cache.wait @X) none))))
 (let (($x235 (not (net.getX @X @Y))))
 (or $x235 $x399))))
(assert
 (let (($x399 (not (= (cache.wait @X) none))))
 (let (($x227 (not (net.getX @X @Z))))
 (or $x227 $x399))))
(assert
 (let (($x404 (not (= (cache.wait home) none))))
 (let (($x248 (not (net.getX home @Y))))
 (or $x248 $x404))))
(assert
 (let (($x399 (not (= (cache.wait @X) none))))
 (let (($x206 (not (net.getX @X home))))
 (or $x206 $x399))))
(assert
 (let (($x198 (not (= (cache.wait @V1) none))))
 (let (($x195 (not (net.getX @V1 @V0))))
 (or $x195 $x198))))
(assert
 (let (($x408 (not (= (cache.wait @V0) none))))
 (let (($x174 (not (net.getX @V0 @V1))))
 (or $x174 $x408))))
(assert
 (let (($x201 (not (net.putX home @X))))
 (let ((?x202 (cache.wait @X)))
 (let (($x203 (= ?x202 getX)))
 (or $x203 $x201)))))
(assert
 (let (($x411 (not (net.putX home @V0))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x169 (= ?x168 getX)))
 (or $x169 $x411)))))
(assert
 (let (($x206 (not (net.getX @X home))))
 (let ((?x202 (cache.wait @X)))
 (let (($x203 (= ?x202 getX)))
 (or $x203 $x206)))))
(assert
 (let (($x415 (not (net.getX home home))))
 (or (= (cache.wait home) getX) $x415)))
(assert
 (let (($x419 (not (net.getX @V1 home))))
 (or (= (cache.wait @V1) getX) $x419)))
(assert
 (let (($x422 (not (net.getX @V0 home))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x169 (= ?x168 getX)))
 (or $x169 $x422)))))
(assert
 (let (($x210 (not (= (cache.state_ @X) exclusive))))
 (or $x210 (not (= (cache.wait @X) getX)))))
(assert
 (let (($x343 (not (= (cache.state_ @V0) exclusive))))
 (or $x343 (not (= (cache.wait @V0) getX)))))
(assert
 (let (($x216 (not (net.put home @X))))
 (or $x216 (not (rp_net @X)))))
(assert
 (let (($x427 (not (net.put home real_owner))))
 (let ((?x103 (cache.wait real_owner)))
 (let (($x104 (= ?x103 get)))
 (or $x104 $x427)))))
(assert
 (let (($x216 (not (net.put home @X))))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x216)))))
(assert
 (let (($x431 (not (net.put home @V1))))
 (let ((?x196 (cache.wait @V1)))
 (let (($x429 (= ?x196 get)))
 (or $x429 $x431)))))
(assert
 (let (($x352 (not (net.put home @V0))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x178 (= ?x168 get)))
 (or $x178 $x352)))))
(assert
 (let (($x367 (not (net.put home dir.hptr))))
 (let ((?x386 (cache.wait dir.hptr)))
 (let (($x387 (= ?x386 get)))
 (or $x387 $x367)))))
(assert
 (let (($x434 (not (net.put home __src))))
 (let ((?x389 (cache.wait __src)))
 (let (($x390 (= ?x389 get)))
 (or $x390 $x434)))))
(assert
 (let (($x438 (not (net.put home home))))
 (let ((?x402 (cache.wait home)))
 (let (($x436 (= ?x402 get)))
 (or $x436 $x438)))))
(assert
 (let (($x146 (__net.get __src home)))
 (let (($x318 (not $x146)))
 (let ((?x389 (cache.wait __src)))
 (let (($x390 (= ?x389 get)))
 (or $x390 $x318))))))
(assert
 (let (($x303 (__net.get @X home)))
 (let (($x324 (not $x303)))
 (let ((?x202 (cache.wait @X)))
 (let (($x218 (= ?x202 get)))
 (or $x218 $x324))))))
(assert
 (let (($x379 (not (__net.get @V0 home))))
 (let ((?x168 (cache.wait @V0)))
 (let (($x178 (= ?x168 get)))
 (or $x178 $x379)))))
(assert
 (let (($x373 (not (__net.get dir.hptr home))))
 (let ((?x386 (cache.wait dir.hptr)))
 (let (($x387 (= ?x386 get)))
 (or $x387 $x373)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x352 (not (net.put home @V0))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x352)))))
(assert
 (let (($x354 (not (net.put dir.hptr @X))))
 (let (($x108 (= dir.hptr real_owner)))
 (let (($x447 (= dir.hptr home)))
 (or $x447 $x108 $x354)))))
(assert
 (let (($x356 (not (net.put dir.hptr @V0))))
 (let (($x108 (= dir.hptr real_owner)))
 (let (($x447 (= dir.hptr home)))
 (or $x447 $x108 $x356)))))
(assert
 (let (($x367 (not (net.put home dir.hptr))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x367)))))
(assert
 (let (($x427 (not (net.put home real_owner))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x427)))))
(assert
 (let (($x431 (not (net.put home @V1))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x431)))))
(assert
 (let (($x434 (not (net.put home __src))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x434)))))
(assert
 (let (($x438 (not (net.put home home))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x438)))))
(assert
 (let (($x373 (not (__net.get dir.hptr home))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x373)))))
(assert
 (let (($x379 (not (__net.get @V0 home))))
 (let (($x314 (= home real_owner)))
 (let (($x301 (= home home)))
 (or $x301 $x314 $x379)))))
(assert
 (let (($x411 (not (net.putX home @V0))))
 (let (($x301 (= home home)))
 (or $x301 $x411))))
(assert
 (let (($x415 (not (net.getX home home))))
 (let (($x301 (= home home)))
 (or $x301 $x415))))
(assert
 (let (($x419 (not (net.getX @V1 home))))
 (let (($x301 (= home home)))
 (or $x301 $x419))))
(assert
 (let (($x422 (not (net.getX @V0 home))))
 (let (($x301 (= home home)))
 (or $x301 $x422))))
(assert
 (let (($x441 (not (net.getX home @Z))))
 (let (($x296 (= @Z home)))
 (or $x296 $x441))))
(assert
 (let (($x443 (not (net.getX home @V0))))
 (let (($x336 (= @V0 home)))
 (or $x336 $x443))))
(assert
 (let (($x445 (not (net.getX home @V1))))
 (let (($x163 (= @V1 home)))
 (or $x163 $x445))))
(assert
 (not (net.put home dir.hptr)))
(assert
 (not (net.put home real_owner)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home __src)))
(assert
 (not (net.put home home)))
(assert
 (not (net.put dir.hptr dir.hptr)))
(assert
 (not (net.put dir.hptr real_owner)))
(assert
 (not (net.put dir.hptr @V1)))
(assert
 (not (net.put dir.hptr __src)))
(assert
 (not (net.put dir.hptr home)))
(assert
 (let (($x367 (not (net.put home dir.hptr))))
 (let (($x42 (dir.shlist dir.hptr)))
 (or $x42 $x367 __dir.pending))))
(assert
 (let (($x427 (not (net.put home real_owner))))
 (let (($x475 (dir.shlist real_owner)))
 (or $x475 $x427 __dir.pending))))
(assert
 (let (($x431 (not (net.put home @V1))))
 (let (($x477 (dir.shlist @V1)))
 (or $x477 $x431 __dir.pending))))
(assert
 (let (($x434 (not (net.put home __src))))
 (let (($x479 (dir.shlist __src)))
 (or $x479 $x434 __dir.pending))))
(assert
 (let (($x438 (not (net.put home home))))
 (let (($x481 (dir.shlist home)))
 (or $x481 $x438 __dir.pending))))
(assert
 (let (($x465 (not (net.put dir.hptr dir.hptr))))
 (let (($x42 (dir.shlist dir.hptr)))
 (or $x42 $x465 __dir.pending))))
(assert
 (let (($x467 (not (net.put dir.hptr real_owner))))
 (let (($x475 (dir.shlist real_owner)))
 (or $x475 $x467 __dir.pending))))
(assert
 (let (($x469 (not (net.put dir.hptr @V1))))
 (let (($x477 (dir.shlist @V1)))
 (or $x477 $x469 __dir.pending))))
(assert
 (let (($x427 (not (net.put home real_owner))))
 (let (($x475 (dir.shlist real_owner)))
 (or $x475 $x427))))
(assert
 (let (($x431 (not (net.put home @V1))))
 (let (($x477 (dir.shlist @V1)))
 (or $x477 $x431))))
(assert
 (let (($x434 (not (net.put home __src))))
 (let (($x479 (dir.shlist __src)))
 (or $x479 $x434))))
(assert
 (let (($x438 (not (net.put home home))))
 (let (($x481 (dir.shlist home)))
 (or $x481 $x438))))
(assert
 (let (($x146 (__net.get __src home)))
 (let (($x318 (not $x146)))
 (or (not (dir.shlist __src)) $x318))))
(assert
 (let (($x427 (not (net.put home real_owner))))
 (let ((?x103 (cache.wait real_owner)))
 (let (($x104 (= ?x103 get)))
 (or $x104 $x427)))))
(assert
 (let (($x431 (not (net.put home @V1))))
 (let ((?x196 (cache.wait @V1)))
 (let (($x429 (= ?x196 get)))
 (or $x429 $x431)))))
(assert
 (let (($x434 (not (net.put home __src))))
 (let ((?x389 (cache.wait __src)))
 (let (($x390 (= ?x389 get)))
 (or $x390 $x434)))))
(assert
 (let (($x438 (not (net.put home home))))
 (let ((?x402 (cache.wait home)))
 (let (($x436 (= ?x402 get)))
 (or $x436 $x438)))))
(assert
 (let (($x465 (not (net.put dir.hptr dir.hptr))))
 (let ((?x386 (cache.wait dir.hptr)))
 (let (($x387 (= ?x386 get)))
 (or $x387 $x465)))))
(assert
 (let (($x467 (not (net.put dir.hptr real_owner))))
 (let ((?x103 (cache.wait real_owner)))
 (let (($x104 (= ?x103 get)))
 (or $x104 $x467)))))
(assert
 (let (($x469 (not (net.put dir.hptr @V1))))
 (let ((?x196 (cache.wait @V1)))
 (let (($x429 (= ?x196 get)))
 (or $x429 $x469)))))
(assert
 (let (($x471 (not (net.put dir.hptr __src))))
 (let ((?x389 (cache.wait __src)))
 (let (($x390 (= ?x389 get)))
 (or $x390 $x471)))))
(assert
 (let (($x404 (not (= (cache.wait home) none))))
 (let (($x415 (not (net.getX home home))))
 (or $x415 $x404))))
(assert
 (let (($x198 (not (= (cache.wait @V1) none))))
 (let (($x419 (not (net.getX @V1 home))))
 (or $x419 $x198))))
(assert
 (let (($x408 (not (= (cache.wait @V0) none))))
 (let (($x422 (not (net.getX @V0 home))))
 (or $x422 $x408))))
(assert
 (let (($x404 (not (= (cache.wait home) none))))
 (let (($x441 (not (net.getX home @Z))))
 (or $x441 $x404))))
(assert
 (let (($x404 (not (= (cache.wait home) none))))
 (let (($x443 (not (net.getX home @V0))))
 (or $x443 $x404))))
(assert
 (let (($x404 (not (= (cache.wait home) none))))
 (let (($x445 (not (net.getX home @V1))))
 (or $x445 $x404))))
(assert
 (let (($x504 (not (net.getX real_owner home))))
 (or (= (cache.wait real_owner) getX) $x504)))
(assert
 (let (($x508 (not (net.getX dir.hptr home))))
 (or (= (cache.wait dir.hptr) getX) $x508)))
(assert
 (let (($x512 (not (net.getX __src home))))
 (or (= (cache.wait __src) getX) $x512)))
(assert
 (let (($x465 (not (net.put dir.hptr dir.hptr))))
 (let (($x108 (= dir.hptr real_owner)))
 (let (($x447 (= dir.hptr home)))
 (or $x447 $x108 $x465)))))
(assert
 (let (($x467 (not (net.put dir.hptr real_owner))))
 (let (($x108 (= dir.hptr real_owner)))
 (let (($x447 (= dir.hptr home)))
 (or $x447 $x108 $x467)))))
(assert
 (let (($x469 (not (net.put dir.hptr @V1))))
 (let (($x108 (= dir.hptr real_owner)))
 (let (($x447 (= dir.hptr home)))
 (or $x447 $x108 $x469)))))
(assert
 (let (($x471 (not (net.put dir.hptr __src))))
 (let (($x108 (= dir.hptr real_owner)))
 (let (($x447 (= dir.hptr home)))
 (or $x447 $x108 $x471)))))
(assert
 (let (($x473 (not (net.put dir.hptr home))))
 (let (($x108 (= dir.hptr real_owner)))
 (let (($x447 (= dir.hptr home)))
 (or $x447 $x108 $x473)))))
(assert
 (let (($x504 (not (net.getX real_owner home))))
 (let (($x301 (= home home)))
 (or $x301 $x504))))
(assert
 (let (($x508 (not (net.getX dir.hptr home))))
 (let (($x301 (= home home)))
 (or $x301 $x508))))
(assert
 (let (($x512 (not (net.getX __src home))))
 (let (($x301 (= home home)))
 (or $x301 $x512))))
(assert
 (let (($x471 (not (net.put dir.hptr __src))))
 (let (($x479 (dir.shlist __src)))
 (or $x479 $x471 __dir.pending))))
(assert
 (let (($x473 (not (net.put dir.hptr home))))
 (let (($x481 (dir.shlist home)))
 (or $x481 $x473 __dir.pending))))
(assert
 (let (($x473 (not (net.put dir.hptr home))))
 (let ((?x402 (cache.wait home)))
 (let (($x436 (= ?x402 get)))
 (or $x436 $x473)))))
(assert
 (let (($x504 (not (net.getX real_owner home))))
 (or $x504 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x508 (not (net.getX dir.hptr home))))
 (or $x508 (not (= (cache.wait dir.hptr) none)))))
(assert
 (let (($x512 (not (net.getX __src home))))
 (or $x512 (not (= (cache.wait __src) none)))))
(check-sat)
