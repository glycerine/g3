(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun home () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun dir.shlist (id) Bool)
(declare-fun __net.get (id id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(assert
 (or (dir.shlist dir.hptr) (not dir.head)))
(assert
 (__net.get __src __dst))
(assert
 (let (($x127 (= __dst home)))
 (not $x127)))
(assert
 (let (($x185 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x45 (or (dir.shlist dir.hptr) (not dir.head))))
 (let (($x221 (not (net.getX home @Y))))
 (let (($x200 (not (net.getX @X @Z))))
 (let (($x208 (not (net.getX @X @Y))))
 (let (($x209 (= @Y @Z)))
 (let (($x222 (and (or $x209 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x209 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x209 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x209 $x208 $x200) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x200 (not (net.putX @Y @X))) $x221 $x45 (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x185 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x222))))))))))
(assert
 (let (($x246 (__net.get @X @Y)))
 (let (($x214 (net.get @X @Y)))
 (= $x214 (ite (and (= @X __src) (= @Y __dst)) false $x246)))))
(assert
 (let (($x251 (__net.get @X @Z)))
 (let (($x204 (net.get @X @Z)))
 (= $x204 (ite (and (= @X __src) (= @Z __dst)) false $x251)))))
(assert
 (let (($x256 (__net.get @X home)))
 (let (($x193 (net.get @X home)))
 (= $x193 (ite (and (= @X __src) (= home __dst)) false $x256)))))
(assert
 (let (($x262 (__net.get @V0 @V1)))
 (let (($x154 (net.get @V0 @V1)))
 (= $x154 (ite (and (= @V0 __src) (= @V1 __dst)) false $x262)))))
(assert
 (let (($x197 (not (net.putX @Y @X))))
 (let (($x162 (= @Y home)))
 (or $x162 $x197))))
(assert
 (let (($x212 (not (net.putX @Z @X))))
 (let (($x266 (= @Z home)))
 (or $x266 $x212))))
(assert
 (let (($x174 (not (net.putX home @X))))
 (let (($x268 (= home home)))
 (or $x268 $x174))))
(assert
 (let (($x145 (not (net.putX @V1 @V0))))
 (let (($x137 (= @V1 home)))
 (or $x137 $x145))))
(assert
 (let (($x126 (__net.get __src __dst)))
 (let (($x271 (not $x126)))
 (let (($x127 (= __dst home)))
 (or $x127 $x271 dir.head)))))
(assert
 (let (($x246 (__net.get @X @Y)))
 (let (($x273 (not $x246)))
 (let (($x162 (= @Y home)))
 (or $x162 $x273 dir.head)))))
(assert
 (let (($x251 (__net.get @X @Z)))
 (let (($x275 (not $x251)))
 (let (($x266 (= @Z home)))
 (or $x266 $x275 dir.head)))))
(assert
 (let (($x256 (__net.get @X home)))
 (let (($x277 (not $x256)))
 (let (($x268 (= home home)))
 (or $x268 $x277 dir.head)))))
(assert
 (let (($x262 (__net.get @V0 @V1)))
 (let (($x279 (not $x262)))
 (let (($x137 (= @V1 home)))
 (or $x137 $x279 dir.head)))))
(assert
 (let (($x208 (not (net.getX @X @Y))))
 (let (($x162 (= @Y home)))
 (or $x162 $x208))))
(assert
 (let (($x200 (not (net.getX @X @Z))))
 (let (($x266 (= @Z home)))
 (or $x266 $x200))))
(assert
 (let (($x221 (not (net.getX home @Y))))
 (let (($x162 (= @Y home)))
 (or $x162 $x221))))
(assert
 (let (($x179 (not (net.getX @X home))))
 (let (($x268 (= home home)))
 (or $x268 $x179))))
(assert
 (let (($x168 (not (net.getX @V1 @V0))))
 (let (($x285 (= @V0 home)))
 (or $x285 $x168))))
(assert
 (let (($x148 (not (net.getX @V0 @V1))))
 (let (($x137 (= @V1 home)))
 (or $x137 $x148))))
(assert
 (let (($x137 (= @V1 home)))
 (or $x137 (not (net.fack @V0 @V1)))))
(assert
 (let (($x197 (not (net.putX @Y @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x176 (= ?x175 getX)))
 (or $x176 $x197)))))
(assert
 (let (($x212 (not (net.putX @Z @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x176 (= ?x175 getX)))
 (or $x176 $x212)))))
(assert
 (let (($x174 (not (net.putX home @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x176 (= ?x175 getX)))
 (or $x176 $x174)))))
(assert
 (let (($x145 (not (net.putX @V1 @V0))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x143 (= ?x142 getX)))
 (or $x143 $x145)))))
(assert
 (let (($x203 (not (net.put @Y @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x203)))))
(assert
 (let (($x218 (not (net.put @Z @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x218)))))
(assert
 (let (($x189 (not (net.put home @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x189)))))
(assert
 (let (($x151 (not (net.put @V1 @V0))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x152 (= ?x142 get)))
 (or $x152 $x151)))))
(assert
 (let (($x126 (__net.get __src __dst)))
 (let (($x271 (not $x126)))
 (let ((?x292 (cache.wait __src)))
 (let (($x293 (= ?x292 get)))
 (or $x293 $x271))))))
(assert
 (let (($x246 (__net.get @X @Y)))
 (let (($x273 (not $x246)))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x273))))))
(assert
 (let (($x251 (__net.get @X @Z)))
 (let (($x275 (not $x251)))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x275))))))
(assert
 (let (($x256 (__net.get @X home)))
 (let (($x277 (not $x256)))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x277))))))
(assert
 (let (($x262 (__net.get @V0 @V1)))
 (let (($x279 (not $x262)))
 (let ((?x142 (cache.wait @V0)))
 (let (($x152 (= ?x142 get)))
 (or $x152 $x279))))))
(assert
 (let (($x203 (not (net.put @Y @X))))
 (let ((?x181 (cache.state_ @X)))
 (let (($x299 (= ?x181 invalid)))
 (or $x299 $x203)))))
(assert
 (let (($x218 (not (net.put @Z @X))))
 (let ((?x181 (cache.state_ @X)))
 (let (($x299 (= ?x181 invalid)))
 (or $x299 $x218)))))
(assert
 (let (($x189 (not (net.put home @X))))
 (let ((?x181 (cache.state_ @X)))
 (let (($x299 (= ?x181 invalid)))
 (or $x299 $x189)))))
(assert
 (let (($x151 (not (net.put @V1 @V0))))
 (let ((?x157 (cache.state_ @V0)))
 (let (($x158 (= ?x157 invalid)))
 (or $x158 $x151)))))
(assert
 (let (($x126 (__net.get __src __dst)))
 (let (($x271 (not $x126)))
 (let ((?x303 (cache.state_ __src)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x271))))))
(assert
 (let (($x246 (__net.get @X @Y)))
 (let (($x273 (not $x246)))
 (let ((?x181 (cache.state_ @X)))
 (let (($x299 (= ?x181 invalid)))
 (or $x299 $x273))))))
(assert
 (let (($x251 (__net.get @X @Z)))
 (let (($x275 (not $x251)))
 (let ((?x181 (cache.state_ @X)))
 (let (($x299 (= ?x181 invalid)))
 (or $x299 $x275))))))
(assert
 (let (($x256 (__net.get @X home)))
 (let (($x277 (not $x256)))
 (let ((?x181 (cache.state_ @X)))
 (let (($x299 (= ?x181 invalid)))
 (or $x299 $x277))))))
(assert
 (let (($x262 (__net.get @V0 @V1)))
 (let (($x279 (not $x262)))
 (let ((?x157 (cache.state_ @V0)))
 (let (($x158 (= ?x157 invalid)))
 (or $x158 $x279))))))
(assert
 (let (($x162 (= @Y home)))
 (or $x162 (not (net.shwb @X @Y)))))
(assert
 (let (($x311 (not (= (cache.wait @X) none))))
 (let (($x208 (not (net.getX @X @Y))))
 (or $x208 $x311))))
(assert
 (let (($x311 (not (= (cache.wait @X) none))))
 (let (($x200 (not (net.getX @X @Z))))
 (or $x200 $x311))))
(assert
 (let (($x316 (not (= (cache.wait home) none))))
 (let (($x221 (not (net.getX home @Y))))
 (or $x221 $x316))))
(assert
 (let (($x311 (not (= (cache.wait @X) none))))
 (let (($x179 (not (net.getX @X home))))
 (or $x179 $x311))))
(assert
 (let (($x171 (not (= (cache.wait @V1) none))))
 (let (($x168 (not (net.getX @V1 @V0))))
 (or $x168 $x171))))
(assert
 (let (($x320 (not (= (cache.wait @V0) none))))
 (let (($x148 (not (net.getX @V0 @V1))))
 (or $x148 $x320))))
(assert
 (let (($x174 (not (net.putX home @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x176 (= ?x175 getX)))
 (or $x176 $x174)))))
(assert
 (let (($x323 (not (net.putX home @V0))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x143 (= ?x142 getX)))
 (or $x143 $x323)))))
(assert
 (let (($x179 (not (net.getX @X home))))
 (let ((?x175 (cache.wait @X)))
 (let (($x176 (= ?x175 getX)))
 (or $x176 $x179)))))
(assert
 (let (($x327 (not (net.getX @V1 home))))
 (let ((?x169 (cache.wait @V1)))
 (let (($x325 (= ?x169 getX)))
 (or $x325 $x327)))))
(assert
 (let (($x330 (not (net.getX @V0 home))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x143 (= ?x142 getX)))
 (or $x143 $x330)))))
(assert
 (let (($x334 (not (net.getX __src home))))
 (let ((?x292 (cache.wait __src)))
 (let (($x332 (= ?x292 getX)))
 (or $x332 $x334)))))
(assert
 (let (($x338 (not (net.getX home home))))
 (let ((?x314 (cache.wait home)))
 (let (($x336 (= ?x314 getX)))
 (or $x336 $x338)))))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (or (not (= (cache.state_ __src) exclusive)) (not (= (cache.wait __src) getX))))
(assert
 (let (($x189 (not (net.put home @X))))
 (or $x189 (not (rp_net @X)))))
(assert
 (let (($x189 (not (net.put home @X))))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x189)))))
(assert
 (let (($x349 (not (net.put home @V0))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x152 (= ?x142 get)))
 (or $x152 $x349)))))
(assert
 (let (($x352 (not (__net.get __src home))))
 (let ((?x292 (cache.wait __src)))
 (let (($x293 (= ?x292 get)))
 (or $x293 $x352)))))
(assert
 (let (($x256 (__net.get @X home)))
 (let (($x277 (not $x256)))
 (let ((?x175 (cache.wait @X)))
 (let (($x191 (= ?x175 get)))
 (or $x191 $x277))))))
(assert
 (let (($x355 (not (__net.get @V0 home))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x152 (= ?x142 get)))
 (or $x152 $x355)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x323 (not (net.putX home @V0))))
 (let (($x268 (= home home)))
 (or $x268 $x323))))
(assert
 (let (($x352 (not (__net.get __src home))))
 (let (($x268 (= home home)))
 (or $x268 $x352 dir.head))))
(assert
 (let (($x355 (not (__net.get @V0 home))))
 (let (($x268 (= home home)))
 (or $x268 $x355 dir.head))))
(assert
 (let (($x327 (not (net.getX @V1 home))))
 (let (($x268 (= home home)))
 (or $x268 $x327))))
(assert
 (let (($x330 (not (net.getX @V0 home))))
 (let (($x268 (= home home)))
 (or $x268 $x330))))
(assert
 (let (($x334 (not (net.getX __src home))))
 (let (($x268 (= home home)))
 (or $x268 $x334))))
(assert
 (let (($x338 (not (net.getX home home))))
 (let (($x268 (= home home)))
 (or $x268 $x338))))
(assert
 (let (($x358 (not (net.getX home @Z))))
 (let (($x266 (= @Z home)))
 (or $x266 $x358))))
(assert
 (let (($x360 (not (net.getX home @V0))))
 (let (($x285 (= @V0 home)))
 (or $x285 $x360))))
(assert
 (let (($x362 (not (net.getX home @V1))))
 (let (($x137 (= @V1 home)))
 (or $x137 $x362))))
(assert
 (let (($x323 (not (net.putX home @V0))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x143 (= ?x142 getX)))
 (or $x143 $x323)))))
(assert
 (let (($x349 (not (net.put home @V0))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x152 (= ?x142 get)))
 (or $x152 $x349)))))
(assert
 (let (($x352 (not (__net.get __src home))))
 (let ((?x292 (cache.wait __src)))
 (let (($x293 (= ?x292 get)))
 (or $x293 $x352)))))
(assert
 (let (($x355 (not (__net.get @V0 home))))
 (let ((?x142 (cache.wait @V0)))
 (let (($x152 (= ?x142 get)))
 (or $x152 $x355)))))
(assert
 (let (($x349 (not (net.put home @V0))))
 (let ((?x157 (cache.state_ @V0)))
 (let (($x158 (= ?x157 invalid)))
 (or $x158 $x349)))))
(assert
 (let (($x352 (not (__net.get __src home))))
 (let ((?x303 (cache.state_ __src)))
 (let (($x304 (= ?x303 invalid)))
 (or $x304 $x352)))))
(assert
 (let (($x355 (not (__net.get @V0 home))))
 (let ((?x157 (cache.state_ @V0)))
 (let (($x158 (= ?x157 invalid)))
 (or $x158 $x355)))))
(assert
 (let (($x171 (not (= (cache.wait @V1) none))))
 (let (($x327 (not (net.getX @V1 home))))
 (or $x327 $x171))))
(assert
 (let (($x320 (not (= (cache.wait @V0) none))))
 (let (($x330 (not (net.getX @V0 home))))
 (or $x330 $x320))))
(assert
 (let (($x334 (not (net.getX __src home))))
 (or $x334 (not (= (cache.wait __src) none)))))
(assert
 (let (($x316 (not (= (cache.wait home) none))))
 (let (($x338 (not (net.getX home home))))
 (or $x338 $x316))))
(assert
 (let (($x316 (not (= (cache.wait home) none))))
 (let (($x358 (not (net.getX home @Z))))
 (or $x358 $x316))))
(assert
 (let (($x316 (not (= (cache.wait home) none))))
 (let (($x360 (not (net.getX home @V0))))
 (or $x360 $x316))))
(assert
 (let (($x316 (not (= (cache.wait home) none))))
 (let (($x362 (not (net.getX home @V1))))
 (or $x362 $x316))))
(assert
 (let (($x387 (not (__net.get @V1 home))))
 (or (= (cache.wait @V1) get) $x387)))
(assert
 (let (($x391 (not (__net.get home home))))
 (or (= (cache.wait home) get) $x391)))
(assert
 (let (($x387 (not (__net.get @V1 home))))
 (let (($x268 (= home home)))
 (or $x268 $x387 dir.head))))
(assert
 (let (($x391 (not (__net.get home home))))
 (let (($x268 (= home home)))
 (or $x268 $x391 dir.head))))
(assert
 (let (($x387 (not (__net.get @V1 home))))
 (or (= (cache.wait @V1) get) $x387)))
(assert
 (let (($x391 (not (__net.get home home))))
 (or (= (cache.wait home) get) $x391)))
(assert
 (let (($x387 (not (__net.get @V1 home))))
 (or (= (cache.state_ @V1) invalid) $x387)))
(assert
 (let (($x391 (not (__net.get home home))))
 (or (= (cache.state_ home) invalid) $x391)))
(assert
 (or (not (= (cache.state_ @V1) exclusive)) (not (= (cache.wait @V1) getX))))
(assert
 (or (not (= (cache.state_ home) exclusive)) (not (= (cache.wait home) getX))))
(check-sat)
