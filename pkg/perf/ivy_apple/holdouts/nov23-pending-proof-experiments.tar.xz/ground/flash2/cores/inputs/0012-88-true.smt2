(set-info :status unknown)
(declare-sort id 0)
 (declare-fun __dst () id)
(declare-fun __src () id)
(declare-fun home () id)
(declare-fun __net.getX (id id) Bool)
(assert
 (__net.getX __src __dst))
(assert
 (let (($x16 (= __dst home)))
 (not $x16)))
(assert
 (let (($x16 (= __dst home)))
 (or $x16 (not (__net.getX __src __dst)))))
(check-sat)
