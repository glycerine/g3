(set-info :status unknown)
(declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-fun __cache.state_ (id) cache_state_)
(declare-fun __dst () id)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun dir.hptr () id)
(assert
 (= (__cache.state_ __dst) exclusive))
(assert
 (and (= (cache.state_ @X) exclusive) (= (cache.wait @X) none) (= (cache.state_ @Y) exclusive) (= (cache.wait @Y) none) (not (= @X @Y))))
(assert
 (let ((?x25 (cache.state_ @X)))
 (= ?x25 (ite (and (= @X __dst)) shared (__cache.state_ @X)))))
(assert
 (let ((?x31 (cache.state_ @Y)))
 (= ?x31 (ite (and (= @Y __dst)) shared (__cache.state_ @Y)))))
(assert
 (or (= __dst dir.hptr) (not (= (__cache.state_ __dst) exclusive))))
(assert
 (or (= @X dir.hptr) (not (= (__cache.state_ @X) exclusive))))
(assert
 (or (= @Y dir.hptr) (not (= (__cache.state_ @Y) exclusive))))
(check-sat)
