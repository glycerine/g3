(set-info :status unknown)
(declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-sort id 0)
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun cache.wait (id) wait_type)
(declare-fun real_owner () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun home () id)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun dir.hptr () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun dir.shlist (id) Bool)
(assert
 (not (= (cache.wait real_owner) get)))
(assert
 (not dir.head))
(assert
 (let (($x171 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x210 (not (net.getX home @Y))))
 (let (($x189 (not (net.getX @X @Z))))
 (let (($x197 (not (net.getX @X @Y))))
 (let (($x198 (= @Y @Z)))
 (let (($x211 (and (or $x198 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x198 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x198 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x198 $x197 $x189) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x189 (not (net.putX @Y @X))) $x210 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x171 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x211)))))))))
(assert
 (let (($x186 (not (net.putX @Y @X))))
 (let (($x148 (= @Y home)))
 (or $x148 $x186))))
(assert
 (let (($x201 (not (net.putX @Z @X))))
 (let (($x233 (= @Z home)))
 (or $x233 $x201))))
(assert
 (let (($x160 (not (net.putX home @X))))
 (let (($x235 (= home home)))
 (or $x235 $x160))))
(assert
 (let (($x131 (not (net.putX @V1 @V0))))
 (let (($x123 (= @V1 home)))
 (or $x123 $x131))))
(assert
 (let (($x197 (not (net.getX @X @Y))))
 (let (($x148 (= @Y home)))
 (or $x148 $x197))))
(assert
 (let (($x189 (not (net.getX @X @Z))))
 (let (($x233 (= @Z home)))
 (or $x233 $x189))))
(assert
 (let (($x210 (not (net.getX home @Y))))
 (let (($x148 (= @Y home)))
 (or $x148 $x210))))
(assert
 (let (($x165 (not (net.getX @X home))))
 (let (($x235 (= home home)))
 (or $x235 $x165))))
(assert
 (let (($x154 (not (net.getX @V1 @V0))))
 (let (($x242 (= @V0 home)))
 (or $x242 $x154))))
(assert
 (let (($x134 (not (net.getX @V0 @V1))))
 (let (($x123 (= @V1 home)))
 (or $x123 $x134))))
(assert
 (let (($x186 (not (net.putX @Y @X))))
 (let (($x245 (= real_owner @X)))
 (or $x245 $x186))))
(assert
 (let (($x201 (not (net.putX @Z @X))))
 (let (($x245 (= real_owner @X)))
 (or $x245 $x201))))
(assert
 (let (($x160 (not (net.putX home @X))))
 (let (($x245 (= real_owner @X)))
 (or $x245 $x160))))
(assert
 (let (($x131 (not (net.putX @V1 @V0))))
 (let (($x249 (= real_owner @V0)))
 (or $x249 $x131))))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (let (($x123 (= @V1 home)))
 (or $x123 (not (net.fack @V0 @V1)))))
(assert
 (let (($x192 (not (net.put @Y @X))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x192)))))
(assert
 (let (($x207 (not (net.put @Z @X))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x207)))))
(assert
 (let (($x175 (not (net.put home @X))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x175)))))
(assert
 (let (($x137 (not (net.put @V1 @V0))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x138 (= ?x128 get)))
 (or $x138 $x137)))))
(assert
 (let (($x204 (not (net.get @X @Y))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x204)))))
(assert
 (let (($x194 (not (net.get @X @Z))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x194)))))
(assert
 (let (($x180 (not (net.get @X home))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x180)))))
(assert
 (let (($x141 (not (net.get @V0 @V1))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x138 (= ?x128 get)))
 (or $x138 $x141)))))
(assert
 (let (($x192 (not (net.put @Y @X))))
 (let ((?x167 (cache.state_ @X)))
 (let (($x257 (= ?x167 invalid)))
 (or $x257 $x192)))))
(assert
 (let (($x207 (not (net.put @Z @X))))
 (let ((?x167 (cache.state_ @X)))
 (let (($x257 (= ?x167 invalid)))
 (or $x257 $x207)))))
(assert
 (let (($x175 (not (net.put home @X))))
 (let ((?x167 (cache.state_ @X)))
 (let (($x257 (= ?x167 invalid)))
 (or $x257 $x175)))))
(assert
 (let (($x137 (not (net.put @V1 @V0))))
 (let ((?x143 (cache.state_ @V0)))
 (let (($x144 (= ?x143 invalid)))
 (or $x144 $x137)))))
(assert
 (let (($x204 (not (net.get @X @Y))))
 (let ((?x167 (cache.state_ @X)))
 (let (($x257 (= ?x167 invalid)))
 (or $x257 $x204)))))
(assert
 (let (($x194 (not (net.get @X @Z))))
 (let ((?x167 (cache.state_ @X)))
 (let (($x257 (= ?x167 invalid)))
 (or $x257 $x194)))))
(assert
 (let (($x180 (not (net.get @X home))))
 (let ((?x167 (cache.state_ @X)))
 (let (($x257 (= ?x167 invalid)))
 (or $x257 $x180)))))
(assert
 (let (($x141 (not (net.get @V0 @V1))))
 (let ((?x143 (cache.state_ @V0)))
 (let (($x144 (= ?x143 invalid)))
 (or $x144 $x141)))))
(assert
 (let (($x148 (= @Y home)))
 (or $x148 (not (net.shwb @X @Y)))))
(assert
 (let (($x265 (not (= (cache.wait @X) none))))
 (let (($x197 (not (net.getX @X @Y))))
 (or $x197 $x265))))
(assert
 (let (($x265 (not (= (cache.wait @X) none))))
 (let (($x189 (not (net.getX @X @Z))))
 (or $x189 $x265))))
(assert
 (let (($x270 (not (= (cache.wait home) none))))
 (let (($x210 (not (net.getX home @Y))))
 (or $x210 $x270))))
(assert
 (let (($x265 (not (= (cache.wait @X) none))))
 (let (($x165 (not (net.getX @X home))))
 (or $x165 $x265))))
(assert
 (let (($x157 (not (= (cache.wait @V1) none))))
 (let (($x154 (not (net.getX @V1 @V0))))
 (or $x154 $x157))))
(assert
 (let (($x274 (not (= (cache.wait @V0) none))))
 (let (($x134 (not (net.getX @V0 @V1))))
 (or $x134 $x274))))
(assert
 (let (($x160 (not (net.putX home @X))))
 (let ((?x161 (cache.wait @X)))
 (let (($x162 (= ?x161 getX)))
 (or $x162 $x160)))))
(assert
 (let (($x252 (not (net.putX home @V0))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x129 (= ?x128 getX)))
 (or $x129 $x252)))))
(assert
 (let (($x279 (not (net.getX real_owner home))))
 (or (= (cache.wait real_owner) getX) $x279)))
(assert
 (let (($x165 (not (net.getX @X home))))
 (let ((?x161 (cache.wait @X)))
 (let (($x162 (= ?x161 getX)))
 (or $x162 $x165)))))
(assert
 (let (($x283 (not (net.getX @V1 home))))
 (or (= (cache.wait @V1) getX) $x283)))
(assert
 (let (($x286 (not (net.getX @V0 home))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x129 (= ?x128 getX)))
 (or $x129 $x286)))))
(assert
 (let (($x290 (not (net.getX home home))))
 (or (= (cache.wait home) getX) $x290)))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (let (($x175 (not (net.put home @X))))
 (or $x175 (not (rp_net @X)))))
(assert
 (let (($x175 (not (net.put home @X))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x175)))))
(assert
 (let (($x297 (not (net.put home @V0))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x138 (= ?x128 get)))
 (or $x138 $x297)))))
(assert
 (let (($x180 (not (net.get @X home))))
 (let ((?x161 (cache.wait @X)))
 (let (($x177 (= ?x161 get)))
 (or $x177 $x180)))))
(assert
 (let (($x300 (not (net.get @V0 home))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x138 (= ?x128 get)))
 (or $x138 $x300)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x252 (not (net.putX home @V0))))
 (let (($x235 (= home home)))
 (or $x235 $x252))))
(assert
 (let (($x279 (not (net.getX real_owner home))))
 (let (($x235 (= home home)))
 (or $x235 $x279))))
(assert
 (let (($x283 (not (net.getX @V1 home))))
 (let (($x235 (= home home)))
 (or $x235 $x283))))
(assert
 (let (($x286 (not (net.getX @V0 home))))
 (let (($x235 (= home home)))
 (or $x235 $x286))))
(assert
 (let (($x290 (not (net.getX home home))))
 (let (($x235 (= home home)))
 (or $x235 $x290))))
(assert
 (let (($x303 (not (net.getX home @Z))))
 (let (($x233 (= @Z home)))
 (or $x233 $x303))))
(assert
 (let (($x305 (not (net.getX home @V0))))
 (let (($x242 (= @V0 home)))
 (or $x242 $x305))))
(assert
 (let (($x307 (not (net.getX home @V1))))
 (let (($x123 (= @V1 home)))
 (or $x123 $x307))))
(assert
 (let (($x252 (not (net.putX home @V0))))
 (let (($x249 (= real_owner @V0)))
 (or $x249 $x252))))
(assert
 (let (($x297 (not (net.put home @V0))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x138 (= ?x128 get)))
 (or $x138 $x297)))))
(assert
 (let (($x300 (not (net.get @V0 home))))
 (let ((?x128 (cache.wait @V0)))
 (let (($x138 (= ?x128 get)))
 (or $x138 $x300)))))
(assert
 (let (($x297 (not (net.put home @V0))))
 (let ((?x143 (cache.state_ @V0)))
 (let (($x144 (= ?x143 invalid)))
 (or $x144 $x297)))))
(assert
 (let (($x300 (not (net.get @V0 home))))
 (let ((?x143 (cache.state_ @V0)))
 (let (($x144 (= ?x143 invalid)))
 (or $x144 $x300)))))
(assert
 (let (($x279 (not (net.getX real_owner home))))
 (or $x279 (not (= (cache.wait real_owner) none)))))
(assert
 (let (($x157 (not (= (cache.wait @V1) none))))
 (let (($x283 (not (net.getX @V1 home))))
 (or $x283 $x157))))
(assert
 (let (($x274 (not (= (cache.wait @V0) none))))
 (let (($x286 (not (net.getX @V0 home))))
 (or $x286 $x274))))
(assert
 (let (($x270 (not (= (cache.wait home) none))))
 (let (($x290 (not (net.getX home home))))
 (or $x290 $x270))))
(assert
 (let (($x270 (not (= (cache.wait home) none))))
 (let (($x303 (not (net.getX home @Z))))
 (or $x303 $x270))))
(assert
 (let (($x270 (not (= (cache.wait home) none))))
 (let (($x305 (not (net.getX home @V0))))
 (or $x305 $x270))))
(assert
 (let (($x270 (not (= (cache.wait home) none))))
 (let (($x307 (not (net.getX home @V1))))
 (or $x307 $x270))))
(check-sat)
