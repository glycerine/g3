(set-info :status unknown)
(declare-sort id 0)
 (declare-datatypes ((wait_type 0)) (((none) (get) (getX))))
 (declare-datatypes ((cache_state_ 0)) (((invalid) (shared) (exclusive))))
 (declare-fun dir.hptr () id)
(declare-fun __src () id)
(declare-fun @V1 () id)
(declare-fun @V0 () id)
(declare-fun home () id)
(declare-fun cache.wait (id) wait_type)
(declare-fun cache.state_ (id) cache_state_)
(declare-fun @Y () id)
(declare-fun @X () id)
(declare-fun @Z () id)
(declare-fun dir.head () Bool)
(declare-fun __dir.shlist (id) Bool)
(declare-fun net.fack (id id) Bool)
(declare-fun net.putX (id id) Bool)
(declare-fun net.getX (id id) Bool)
(declare-fun net.put (id id) Bool)
(declare-fun net.get (id id) Bool)
(declare-fun net.shwb (id id) Bool)
(declare-fun rp_net (id) Bool)
(declare-fun dir.shlist (id) Bool)
(assert
 (let (($x34 (not dir.head)))
 (let (($x36 (__dir.shlist dir.hptr)))
 (or $x36 $x34))))
(assert
 (let (($x110 (= dir.hptr __src)))
 (not $x110)))
(assert
 (let (($x168 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX)))))
 (let (($x206 (not (net.getX home @Y))))
 (let (($x185 (not (net.getX @X @Z))))
 (let (($x193 (not (net.getX @X @Y))))
 (let (($x194 (= @Y @Z)))
 (let (($x207 (and (or $x194 (not (net.put @Y @X)) (not (net.put @Z @X))) (or $x194 (not (net.get @X @Y)) (not (net.get @X @Z))) (or $x194 (not (net.putX @Y @X)) (not (net.putX @Z @X))) (or $x194 $x193 $x185) (or (not (net.get @X @Z)) (not (net.put @Y @X))) (or $x185 (not (net.putX @Y @X))) $x206 (or (dir.shlist dir.hptr) (not dir.head)) (or (= (cache.wait @X) get) (not (net.get @X home))) (or (= (cache.wait @X) get) (not (net.put home @X))) (or (not (net.put home @X)) (not (rp_net @X))) $x168 (or (= (cache.wait @X) getX) (not (net.getX @X home))) (or (= (cache.wait @X) getX) (not (net.putX home @X))) (or (not (net.getX @V1 @V0)) (not (= (cache.wait @V1) none))) (or (= @Y home) (not (net.shwb @X @Y))) (or (= (cache.state_ @V0) invalid) (not (net.get @V0 @V1))) (or (= (cache.state_ @V0) invalid) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) get) (not (net.get @V0 @V1))) (or (= (cache.wait @V0) get) (not (net.put @V1 @V0))) (or (= (cache.wait @V0) getX) (not (net.getX @V0 @V1))) (or (= (cache.wait @V0) getX) (not (net.putX @V1 @V0))) (or (= @V1 home) (not (net.fack @V0 @V1))))))
 (and (not $x207)))))))))
(assert
 (let (($x179 (dir.shlist dir.hptr)))
 (= $x179 (ite (and (= dir.hptr __src)) false (__dir.shlist dir.hptr)))))
(assert
 (let (($x182 (not (net.putX @Y @X))))
 (let (($x145 (= @Y home)))
 (or $x145 $x182))))
(assert
 (let (($x197 (not (net.putX @Z @X))))
 (let (($x232 (= @Z home)))
 (or $x232 $x197))))
(assert
 (let (($x157 (not (net.putX home @X))))
 (let (($x234 (= home home)))
 (or $x234 $x157))))
(assert
 (let (($x128 (not (net.putX @V1 @V0))))
 (let (($x120 (= @V1 home)))
 (or $x120 $x128))))
(assert
 (let (($x193 (not (net.getX @X @Y))))
 (let (($x145 (= @Y home)))
 (or $x145 $x193))))
(assert
 (let (($x185 (not (net.getX @X @Z))))
 (let (($x232 (= @Z home)))
 (or $x232 $x185))))
(assert
 (let (($x206 (not (net.getX home @Y))))
 (let (($x145 (= @Y home)))
 (or $x145 $x206))))
(assert
 (let (($x162 (not (net.getX @X home))))
 (let (($x234 (= home home)))
 (or $x234 $x162))))
(assert
 (let (($x151 (not (net.getX @V1 @V0))))
 (let (($x241 (= @V0 home)))
 (or $x241 $x151))))
(assert
 (let (($x131 (not (net.getX @V0 @V1))))
 (let (($x120 (= @V1 home)))
 (or $x120 $x131))))
(assert
 (not (net.putX home @X)))
(assert
 (not (net.putX home @V0)))
(assert
 (not (net.put home @X)))
(assert
 (not (net.put home @V0)))
(assert
 (let (($x120 (= @V1 home)))
 (or $x120 (not (net.fack @V0 @V1)))))
(assert
 (let (($x188 (not (net.put @Y @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x188)))))
(assert
 (let (($x203 (not (net.put @Z @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x203)))))
(assert
 (let (($x172 (not (net.put home @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x172)))))
(assert
 (let (($x134 (not (net.put @V1 @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x134)))))
(assert
 (let (($x247 (not (net.put home @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x247)))))
(assert
 (let (($x200 (not (net.get @X @Y))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x200)))))
(assert
 (let (($x190 (not (net.get @X @Z))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x190)))))
(assert
 (let (($x177 (not (net.get @X home))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x177)))))
(assert
 (let (($x138 (not (net.get @V0 @V1))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x138)))))
(assert
 (let (($x188 (not (net.put @Y @X))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x253 (= ?x164 invalid)))
 (or $x253 $x188)))))
(assert
 (let (($x203 (not (net.put @Z @X))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x253 (= ?x164 invalid)))
 (or $x253 $x203)))))
(assert
 (let (($x172 (not (net.put home @X))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x253 (= ?x164 invalid)))
 (or $x253 $x172)))))
(assert
 (let (($x134 (not (net.put @V1 @V0))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x134)))))
(assert
 (let (($x247 (not (net.put home @V0))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x247)))))
(assert
 (let (($x200 (not (net.get @X @Y))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x253 (= ?x164 invalid)))
 (or $x253 $x200)))))
(assert
 (let (($x190 (not (net.get @X @Z))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x253 (= ?x164 invalid)))
 (or $x253 $x190)))))
(assert
 (let (($x177 (not (net.get @X home))))
 (let ((?x164 (cache.state_ @X)))
 (let (($x253 (= ?x164 invalid)))
 (or $x253 $x177)))))
(assert
 (let (($x138 (not (net.get @V0 @V1))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x138)))))
(assert
 (let (($x145 (= @Y home)))
 (or $x145 (not (net.shwb @X @Y)))))
(assert
 (let (($x262 (not (= (cache.wait @X) none))))
 (let (($x193 (not (net.getX @X @Y))))
 (or $x193 $x262))))
(assert
 (let (($x262 (not (= (cache.wait @X) none))))
 (let (($x185 (not (net.getX @X @Z))))
 (or $x185 $x262))))
(assert
 (let (($x267 (not (= (cache.wait home) none))))
 (let (($x206 (not (net.getX home @Y))))
 (or $x206 $x267))))
(assert
 (let (($x262 (not (= (cache.wait @X) none))))
 (let (($x162 (not (net.getX @X home))))
 (or $x162 $x262))))
(assert
 (let (($x154 (not (= (cache.wait @V1) none))))
 (let (($x151 (not (net.getX @V1 @V0))))
 (or $x151 $x154))))
(assert
 (let (($x271 (not (= (cache.wait @V0) none))))
 (let (($x131 (not (net.getX @V0 @V1))))
 (or $x131 $x271))))
(assert
 (let (($x157 (not (net.putX home @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x159 (= ?x158 getX)))
 (or $x159 $x157)))))
(assert
 (let (($x275 (not (net.putX home @V1))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x273 (= ?x152 getX)))
 (or $x273 $x275)))))
(assert
 (let (($x245 (not (net.putX home @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x126 (= ?x125 getX)))
 (or $x126 $x245)))))
(assert
 (let (($x280 (not (net.putX home home))))
 (let ((?x265 (cache.wait home)))
 (let (($x278 (= ?x265 getX)))
 (or $x278 $x280)))))
(assert
 (let (($x162 (not (net.getX @X home))))
 (let ((?x158 (cache.wait @X)))
 (let (($x159 (= ?x158 getX)))
 (or $x159 $x162)))))
(assert
 (let (($x283 (not (net.getX @V1 home))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x273 (= ?x152 getX)))
 (or $x273 $x283)))))
(assert
 (let (($x286 (not (net.getX @V0 home))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x126 (= ?x125 getX)))
 (or $x126 $x286)))))
(assert
 (let (($x289 (not (net.getX home home))))
 (let ((?x265 (cache.wait home)))
 (let (($x278 (= ?x265 getX)))
 (or $x278 $x289)))))
(assert
 (or (not (= (cache.state_ @X) exclusive)) (not (= (cache.wait @X) getX))))
(assert
 (or (not (= (cache.state_ @V0) exclusive)) (not (= (cache.wait @V0) getX))))
(assert
 (let (($x172 (not (net.put home @X))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x172)))))
(assert
 (let (($x297 (not (net.put home @V1))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x295 (= ?x152 get)))
 (or $x295 $x297)))))
(assert
 (let (($x247 (not (net.put home @V0))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x247)))))
(assert
 (let (($x301 (not (net.put home home))))
 (let ((?x265 (cache.wait home)))
 (let (($x299 (= ?x265 get)))
 (or $x299 $x301)))))
(assert
 (let (($x177 (not (net.get @X home))))
 (let ((?x158 (cache.wait @X)))
 (let (($x174 (= ?x158 get)))
 (or $x174 $x177)))))
(assert
 (let (($x304 (not (net.get @V0 home))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x304)))))
(assert
 (not (net.getX home @Y)))
(assert
 (not (net.getX home @Z)))
(assert
 (not (net.getX home home)))
(assert
 (not (net.getX home @V0)))
(assert
 (not (net.getX home @V1)))
(assert
 (let (($x245 (not (net.putX home @V0))))
 (let (($x234 (= home home)))
 (or $x234 $x245))))
(assert
 (let (($x275 (not (net.putX home @V1))))
 (let (($x234 (= home home)))
 (or $x234 $x275))))
(assert
 (let (($x280 (not (net.putX home home))))
 (let (($x234 (= home home)))
 (or $x234 $x280))))
(assert
 (let (($x283 (not (net.getX @V1 home))))
 (let (($x234 (= home home)))
 (or $x234 $x283))))
(assert
 (let (($x286 (not (net.getX @V0 home))))
 (let (($x234 (= home home)))
 (or $x234 $x286))))
(assert
 (let (($x289 (not (net.getX home home))))
 (let (($x234 (= home home)))
 (or $x234 $x289))))
(assert
 (let (($x307 (not (net.getX home @Z))))
 (let (($x232 (= @Z home)))
 (or $x232 $x307))))
(assert
 (let (($x309 (not (net.getX home @V0))))
 (let (($x241 (= @V0 home)))
 (or $x241 $x309))))
(assert
 (let (($x311 (not (net.getX home @V1))))
 (let (($x120 (= @V1 home)))
 (or $x120 $x311))))
(assert
 (not (net.putX home @V1)))
(assert
 (not (net.putX home home)))
(assert
 (not (net.put home @V1)))
(assert
 (not (net.put home home)))
(assert
 (let (($x297 (not (net.put home @V1))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x295 (= ?x152 get)))
 (or $x295 $x297)))))
(assert
 (let (($x301 (not (net.put home home))))
 (let ((?x265 (cache.wait home)))
 (let (($x299 (= ?x265 get)))
 (or $x299 $x301)))))
(assert
 (let (($x304 (not (net.get @V0 home))))
 (let ((?x125 (cache.wait @V0)))
 (let (($x135 (= ?x125 get)))
 (or $x135 $x304)))))
(assert
 (let (($x297 (not (net.put home @V1))))
 (let ((?x321 (cache.state_ @V1)))
 (let (($x322 (= ?x321 invalid)))
 (or $x322 $x297)))))
(assert
 (let (($x301 (not (net.put home home))))
 (let ((?x324 (cache.state_ home)))
 (let (($x325 (= ?x324 invalid)))
 (or $x325 $x301)))))
(assert
 (let (($x304 (not (net.get @V0 home))))
 (let ((?x140 (cache.state_ @V0)))
 (let (($x141 (= ?x140 invalid)))
 (or $x141 $x304)))))
(assert
 (let (($x154 (not (= (cache.wait @V1) none))))
 (let (($x283 (not (net.getX @V1 home))))
 (or $x283 $x154))))
(assert
 (let (($x271 (not (= (cache.wait @V0) none))))
 (let (($x286 (not (net.getX @V0 home))))
 (or $x286 $x271))))
(assert
 (let (($x267 (not (= (cache.wait home) none))))
 (let (($x289 (not (net.getX home home))))
 (or $x289 $x267))))
(assert
 (let (($x267 (not (= (cache.wait home) none))))
 (let (($x307 (not (net.getX home @Z))))
 (or $x307 $x267))))
(assert
 (let (($x267 (not (= (cache.wait home) none))))
 (let (($x309 (not (net.getX home @V0))))
 (or $x309 $x267))))
(assert
 (let (($x267 (not (= (cache.wait home) none))))
 (let (($x311 (not (net.getX home @V1))))
 (or $x311 $x267))))
(assert
 (or (not (= (cache.state_ @V1) exclusive)) (not (= (cache.wait @V1) getX))))
(assert
 (or (not (= (cache.state_ home) exclusive)) (not (= (cache.wait home) getX))))
(assert
 (let (($x343 (not (net.get @V1 home))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x295 (= ?x152 get)))
 (or $x295 $x343)))))
(assert
 (let (($x346 (not (net.get home home))))
 (let ((?x265 (cache.wait home)))
 (let (($x299 (= ?x265 get)))
 (or $x299 $x346)))))
(assert
 (let (($x343 (not (net.get @V1 home))))
 (let ((?x152 (cache.wait @V1)))
 (let (($x295 (= ?x152 get)))
 (or $x295 $x343)))))
(assert
 (let (($x346 (not (net.get home home))))
 (let ((?x265 (cache.wait home)))
 (let (($x299 (= ?x265 get)))
 (or $x299 $x346)))))
(assert
 (let (($x343 (not (net.get @V1 home))))
 (let ((?x321 (cache.state_ @V1)))
 (let (($x322 (= ?x321 invalid)))
 (or $x322 $x343)))))
(assert
 (let (($x346 (not (net.get home home))))
 (let ((?x324 (cache.state_ home)))
 (let (($x325 (= ?x324 invalid)))
 (or $x325 $x346)))))
(check-sat)
