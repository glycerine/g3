(set-info :status unknown)
(declare-sort id 0)
 (declare-fun home () id)
(declare-fun __src () id)
(declare-fun __net.shwb (id id) Bool)
(assert
 (__net.shwb __src home))
(assert
 (let (($x11 (__net.shwb __src home)))
 (not $x11)))
(check-sat)
