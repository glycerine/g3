(set-info :status unknown)
(declare-sort index 0)
 (declare-sort log 0)
 (declare-sort node 0)
 (declare-fun |__loc:i| () index)
(declare-fun current_log (node) log)
(declare-fun |__fml:n| () node)
(declare-fun |__loc:pi| () index)
(declare-fun index_used (log index) Bool)
(declare-fun |<:index:index| (index index) Bool)
(declare-fun __ts0_a () Bool)
(declare-fun valid (log) Bool)
(assert
 (let ((?x23 (current_log |__fml:n|)))
 (index_used ?x23 |__loc:i|)))
(assert
 (let (($x27 (not __ts0_a)))
 (or $x27 (|<:index:index| |__loc:pi| |__loc:i|))))
(assert
 (let (($x27 (not __ts0_a)))
 (or $x27 (not (index_used (current_log |__fml:n|) |__loc:pi|)))))
(assert
 (or __ts0_a false))
(assert
 (let ((?x23 (current_log |__fml:n|)))
 (valid ?x23)))
(check-sat)
