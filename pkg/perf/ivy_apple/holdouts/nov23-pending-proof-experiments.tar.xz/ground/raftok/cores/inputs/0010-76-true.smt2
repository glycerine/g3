(set-info :status unknown)
(declare-sort index 0)
 (declare-fun |0:index| () index)
(declare-fun |__loc:i| () index)
(declare-fun __ts0_a () Bool)
(assert
 (or (not __ts0_a) false))
(assert
 (or __ts0_a (not (= |__loc:i| |0:index|))))
(check-sat)
