(set-info :status unknown)
(declare-sort index 0)
 (declare-fun |0:index| () index)
(declare-fun |__loc:i| () index)
(assert
 (not (= |__loc:i| |0:index|)))
(check-sat)
