(set-info :status unknown)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(assert
 (or __ts0_a __ts0_b))
(check-sat)
