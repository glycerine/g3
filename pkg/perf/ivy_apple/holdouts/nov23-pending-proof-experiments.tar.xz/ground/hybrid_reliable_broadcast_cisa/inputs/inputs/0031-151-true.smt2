(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_7 () Bool)
(declare-fun __l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun __l2s_g_5 () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun _old_l2s_g_5 () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun _old_l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun _old_l2s_g_9 () Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun __ts0__ts0_a () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun ___old_l2s_g_5 () Bool)
(declare-fun ___old_l2s_g_7 () Bool)
(declare-fun ___old_l2s_g_9 () Bool)
(declare-fun ___old_l2s_g_6 () Bool)
(declare-fun |__loc:nondet| () Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun _old_l2s_g_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun new__old_l2s_g_0_a (hrb.node hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun _old_l2s_g_3 (hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __m_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __m__old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun __l2s_w_2 (hrb.node) Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_4 (hrb.node) Bool)
(declare-fun __l2s_g_3 (hrb.node) Bool)
(declare-fun __l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun ___old_l2s_g_4 (hrb.node) Bool)
(declare-fun ___old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun ___old_l2s_g_3 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not __l2s_g_7))
(assert
 __l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> __l2s_g_5 $x138))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> __l2s_g_6 $x148))))
(assert
 (hrb.member_fc |__fml:n|))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> _old_l2s_g_5 l2s_g_5))))
(assert
 (let (($x334 (=> (and (not _old_l2s_g_5) (not (__hrb.accept hrb.n1))) (not l2s_g_5))))
 (let (($x315 (not __ts0_a)))
 (or $x315 $x334))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> _old_l2s_g_7 l2s_g_7))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> _old_l2s_g_9 l2s_g_9))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> l2s_g_5 (not (hrb.accept hrb.n1))))))
(assert
 (or __ts0_a (= l2s_g_5 __l2s_g_5)))
(assert
 (or __ts0_a (= l2s_g_7 __l2s_g_7)))
(assert
 (or __ts0_a (= l2s_g_9 __l2s_g_9)))
(assert
 (let (($x385 (not __ts0_b)))
 (or $x385 (or (not __ts0__ts0_a) (=> _old_l2s_g_6 l2s_g_6)))))
(assert
 (let (($x445 (=> (and (not _old_l2s_g_6) (not (__hrb.sent_msg_proj hrb.n2))) (not l2s_g_6))))
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 $x445))))))
(assert
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 (=> l2s_g_6 (not (hrb.sent_msg_proj hrb.n2))))))))
(assert
 (let (($x385 (not __ts0_b)))
 (or $x385 (or __ts0__ts0_a (= l2s_g_6 __l2s_g_6)))))
(assert
 (let (($x471 (= l2s_g_6 __l2s_g_6)))
 (or __ts0_b $x471)))
(assert
 (= _old_l2s_g_5 (ite __ts0_a __l2s_g_5 ___old_l2s_g_5)))
(assert
 (= _old_l2s_g_7 (ite __ts0_a __l2s_g_7 ___old_l2s_g_7)))
(assert
 (= _old_l2s_g_9 (ite __ts0_a __l2s_g_9 ___old_l2s_g_9)))
(assert
 (let (($x598 (ite __ts0_b (ite __ts0__ts0_a __l2s_g_6 ___old_l2s_g_6) ___old_l2s_g_6)))
 (= _old_l2s_g_6 $x598)))
(assert
 (= __ts0__ts0_a |__loc:nondet|))
(assert
 (let (($x642 (l2s_g_2 @N @M)))
 (let (($x643 (not $x642)))
 (let (($x639 (hrb.rcv_init @N)))
 (let (($x638 (hrb.correct @N)))
 (let (($x640 (and $x638 $x639)))
 (and (not (=> $x640 $x643)))))))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x359 (hrb.accept hrb.n1)))
 (= $x359 (ite __ts0_a (ite (and (= hrb.n1 |__fml:n|)) true $x137) $x137)))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x679 (__l2s_g_2 @N @M)))
 (let (($x642 (l2s_g_2 @N @M)))
 (let (($x680 (= $x642 $x679)))
 (or __ts0_b $x680)))))
(assert
 (let (($x385 (not __ts0_b)))
 (or $x385 (or __ts0__ts0_a (= (l2s_g_2 @N @M) (__l2s_g_2 @N @M))))))
(assert
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x686 (or $x383 (=> (pending_goal_function_1 hrb.n2) (not (hrb.sent_msg_proj hrb.n2))))))
 (let (($x385 (not __ts0_b)))
 (or $x385 $x686)))))
(assert
 (let (($x692 (=> (and (not (_old_l2s_g_4 hrb.n2)) (not (__hrb.sent_msg_proj hrb.n2))) (not (pending_goal_function_1 hrb.n2)))))
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 $x692))))))
(assert
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 (=> (_old_l2s_g_4 hrb.n2) (pending_goal_function_1 hrb.n2)))))))
(assert
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 (=> (l2s_g_2 @N @M) (not (hrb.sent_msg @N @M))))))))
(assert
 (let (($x707 (l2s_g_1 @N @M)))
 (let (($x708 (not $x707)))
 (let (($x703 (l2s_g_0 @N @M)))
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x710 (or $x383 (=> (and $x703 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x708))))
 (let (($x385 (not __ts0_b)))
 (or $x385 $x710))))))))
(assert
 (let (($x642 (l2s_g_2 @N @M)))
 (let (($x643 (not $x642)))
 (let (($x717 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x643)))
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 $x717))))))))
(assert
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 (=> (_old_l2s_g_2 @N @M) (l2s_g_2 @N @M)))))))
(assert
 (let (($x707 (l2s_g_1 @N @M)))
 (let (($x708 (not $x707)))
 (let (($x704 (hrb.correct @M)))
 (let (($x714 (__hrb.sent_msg @N @M)))
 (let (($x725 (and $x714 $x704)))
 (let (($x726 (=> $x725 $x708)))
 (let (($x729 (=> (and (not (new__old_l2s_g_0_a @N @M)) $x726) (not (l2s_g_0 @N @M)))))
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 $x729))))))))))))
(assert
 (let (($x383 (not __ts0__ts0_a)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or $x383 (=> (new__old_l2s_g_0_a @N @M) (l2s_g_0 @N @M)))))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> (pending_goal_function_0 hrb.n1) (not (hrb.accept hrb.n1))))))
(assert
 (let (($x742 (=> (and (not (_old_l2s_g_3 hrb.n1)) (not (__hrb.accept hrb.n1))) (not (pending_goal_function_0 hrb.n1)))))
 (let (($x315 (not __ts0_a)))
 (or $x315 $x742))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> (_old_l2s_g_3 hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x707 (l2s_g_1 @N @M)))
 (=> $x707 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x707 (l2s_g_1 @N @M)))
 (let (($x708 (not $x707)))
 (let (($x704 (hrb.correct @M)))
 (let (($x714 (__hrb.sent_msg @N @M)))
 (let (($x725 (and $x714 $x704)))
 (let (($x749 (__m_l2s_g_0 @N @M)))
 (=> (and $x749 $x725) $x708))))))))
(assert
 (let (($x707 (l2s_g_1 @N @M)))
 (let (($x708 (not $x707)))
 (=> (and (not (_old_l2s_g_1 @N @M)) (not (__hrb.rcv_msg @N @M))) $x708))))
(assert
 (let (($x707 (l2s_g_1 @N @M)))
 (let (($x752 (_old_l2s_g_1 @N @M)))
 (=> $x752 $x707))))
(assert
 (let (($x707 (l2s_g_1 @N @M)))
 (let (($x708 (not $x707)))
 (let (($x704 (hrb.correct @M)))
 (let (($x714 (__hrb.sent_msg @N @M)))
 (let (($x725 (and $x714 $x704)))
 (let (($x726 (=> $x725 $x708)))
 (=> (and (not (__m__old_l2s_g_0 @N @M)) $x726) (not (__m_l2s_g_0 @N @M))))))))))
(assert
 (let (($x749 (__m_l2s_g_0 @N @M)))
 (let (($x759 (__m__old_l2s_g_0 @N @M)))
 (=> $x759 $x749))))
(assert
 (not (and (__hrb.sent_msg_proj hrb.n2) (__l2s_w_3 hrb.n2))))
(assert
 (not (and (__hrb.accept hrb.n1) (__l2s_w_2 hrb.n1))))
(assert
 (not (and (__hrb.rcv_msg @N @M) (__l2s_w_0 @N @M))))
(assert
 (let (($x774 (__l2s_w_1 |__fml:s| |__fml:n|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (not (and $x287 $x774)))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x780 (__l2s_g_4 hrb.n2)))
 (=> $x780 $x148)))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x782 (__l2s_g_3 hrb.n1)))
 (=> $x782 $x138)))))
(assert
 (let (($x714 (__hrb.sent_msg @N @M)))
 (let (($x715 (not $x714)))
 (let (($x679 (__l2s_g_2 @N @M)))
 (=> $x679 $x715)))))
(assert
 (let (($x754 (__hrb.rcv_msg @N @M)))
 (let (($x755 (not $x754)))
 (let (($x785 (__l2s_g_1 @N @M)))
 (=> $x785 $x755)))))
(assert
 (let (($x704 (hrb.correct @M)))
 (let (($x714 (__hrb.sent_msg @N @M)))
 (let (($x725 (and $x714 $x704)))
 (let (($x787 (__l2s_g_0 @N @M)))
 (=> (and $x787 $x725) (not (__l2s_g_1 @N @M))))))))
(assert
 (let (($x639 (hrb.rcv_init @N)))
 (let (($x791 (hrb.obedient @N)))
 (=> $x791 $x639))))
(assert
 (let (($x801 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x801))))
(assert
 (let (($x809 (hrb.member_fa @N)))
 (let (($x810 (not $x809)))
 (let (($x807 (hrb.member_fs @N)))
 (let (($x808 (not $x807)))
 (let (($x805 (hrb.member_fi @N)))
 (let (($x806 (not $x805)))
 (let (($x638 (hrb.correct @N)))
 (= $x638 (and (not (hrb.member_fc @N)) $x806 $x808 $x810))))))))))
(assert
 (let (($x819 (hrb.member_fa @M)))
 (let (($x820 (not $x819)))
 (let (($x817 (hrb.member_fs @M)))
 (let (($x818 (not $x817)))
 (let (($x704 (hrb.correct @M)))
 (= $x704 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x818 $x820))))))))
(assert
 (let (($x791 (hrb.obedient @N)))
 (= $x791 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x287)))
(assert
 (let (($x714 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x714)))
(assert
 (let (($x714 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (__hrb.rcv_msg @N @M)) $x714)))
(assert
 (let (($x826 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x287 $x826))))
(assert
 (let (($x830 (__hrb.sent_msg_proj @N)))
 (let (($x714 (__hrb.sent_msg @N @M)))
 (=> $x714 $x830))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (__hrb.sent_msg_proj hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n1) (not (__l2s_w_2 hrb.n1))) (or (__hrb.accept hrb.n1) (__l2s_g_3 hrb.n1))))
(assert
 (let (($x754 (__hrb.rcv_msg @N @M)))
 (let (($x848 (l2s_s_1 @N @M)))
 (let (($x704 (hrb.correct @M)))
 (=> (and l2s_saved $x704 $x848 (not (__l2s_w_0 @N @M))) $x754)))))
(assert
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x853 (hrb.rcv_init |__fml:s|)))
 (let (($x852 (hrb.correct |__fml:s|)))
 (=> (and l2s_saved $x852 $x853 (not (__l2s_w_1 |__fml:s| |__fml:n|))) $x287)))))
(assert
 (let (($x714 (__hrb.sent_msg @N @M)))
 (let (($x639 (hrb.rcv_init @N)))
 (let (($x638 (hrb.correct @N)))
 (=> (and l2s_saved $x638 $x639 (not (__l2s_w_1 @N @M))) $x714)))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x639 (hrb.rcv_init @N)))
 (let (($x638 (hrb.correct @N)))
 (let (($x640 (and $x638 $x639)))
 (=> $x640 (not (__l2s_g_2 @N @M)))))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x754 (__hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x754)))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (let (($x826 (__hrb.sent_msg_proj |__fml:s|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:s|)) $x826)))
(assert
 (let (($x830 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x830)))
(assert
 (let (($x714 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x714)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:s|) (hrb.rcv_init |__fml:s|))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x935 (___old_l2s_g_4 hrb.n2)))
 (let (($x688 (_old_l2s_g_4 hrb.n2)))
 (= $x688 (ite __ts0_b (ite __ts0__ts0_a (__l2s_g_4 hrb.n2) $x935) $x935)))))
(assert
 (let (($x714 (__hrb.sent_msg @N @M)))
 (let (($x943 (ite __ts0_b (ite __ts0__ts0_a (ite (and (= @N |__fml:n|)) true $x714) $x714) $x714)))
 (let (($x698 (hrb.sent_msg @N @M)))
 (= $x698 $x943)))))
(assert
 (let (($x945 (___old_l2s_g_2 @N @M)))
 (let (($x712 (_old_l2s_g_2 @N @M)))
 (= $x712 (ite __ts0_b (ite __ts0__ts0_a (__l2s_g_2 @N @M) $x945) $x945)))))
(assert
 (let (($x759 (__m__old_l2s_g_0 @N @M)))
 (let (($x723 (new__old_l2s_g_0_a @N @M)))
 (= $x723 (ite __ts0_b (ite __ts0__ts0_a (__m_l2s_g_0 @N @M) $x759) $x759)))))
(assert
 (let (($x738 (_old_l2s_g_3 hrb.n1)))
 (= $x738 (ite __ts0_a (__l2s_g_3 hrb.n1) (___old_l2s_g_3 hrb.n1)))))
(assert
 (let (($x754 (__hrb.rcv_msg @N @M)))
 (let (($x746 (hrb.rcv_msg @N @M)))
 (= $x746 (ite (and (= @N |__fml:s|) (= @M |__fml:n|)) true $x754)))))
(assert
 (let (($x785 (__l2s_g_1 @N @M)))
 (let (($x752 (_old_l2s_g_1 @N @M)))
 (= $x752 $x785))))
(assert
 (let (($x787 (__l2s_g_0 @N @M)))
 (let (($x759 (__m__old_l2s_g_0 @N @M)))
 (= $x759 $x787))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (let (($x780 (__l2s_g_4 hrb.n2)))
 (let (($x684 (pending_goal_function_1 hrb.n2)))
 (let (($x1004 (= $x684 $x780)))
 (or __ts0_b $x1004)))))
(assert
 (let (($x749 (__m_l2s_g_0 @N @M)))
 (let (($x703 (l2s_g_0 @N @M)))
 (let (($x1006 (= $x703 $x749)))
 (or __ts0_b $x1006)))))
(assert
 (let (($x780 (__l2s_g_4 hrb.n2)))
 (let (($x684 (pending_goal_function_1 hrb.n2)))
 (let (($x1004 (= $x684 $x780)))
 (let (($x385 (not __ts0_b)))
 (or $x385 (or __ts0__ts0_a $x1004)))))))
(assert
 (let (($x385 (not __ts0_b)))
 (or $x385 (or __ts0__ts0_a (= (l2s_g_0 @N @M) (__m_l2s_g_0 @N @M))))))
(assert
 (or __ts0_a (= (pending_goal_function_0 hrb.n1) (__l2s_g_3 hrb.n1))))
(assert
 (let (($x853 (hrb.rcv_init |__fml:s|)))
 (let (($x1014 (hrb.obedient |__fml:s|)))
 (=> $x1014 $x853))))
(assert
 (let (($x1022 (hrb.member_fa |__fml:s|)))
 (let (($x1023 (not $x1022)))
 (let (($x1020 (hrb.member_fs |__fml:s|)))
 (let (($x1021 (not $x1020)))
 (let (($x1018 (hrb.member_fi |__fml:s|)))
 (let (($x1019 (not $x1018)))
 (let (($x852 (hrb.correct |__fml:s|)))
 (= $x852 (and (not (hrb.member_fc |__fml:s|)) $x1019 $x1021 $x1023))))))))))
(assert
 (let (($x825 (hrb.symmetric |__fml:s|)))
 (= $x825 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x829 (hrb.symmetric @N)))
 (= $x829 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x833 (hrb.obedient @M)))
 (= $x833 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x838 (hrb.obedient hrb.n2)))
 (= $x838 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x843 (hrb.obedient hrb.n1)))
 (= $x843 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (let (($x1014 (hrb.obedient |__fml:s|)))
 (= $x1014 (and (not (hrb.member_fs |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (not (and (hrb.member_fs |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fi |__fml:s|))))
(check-sat)
