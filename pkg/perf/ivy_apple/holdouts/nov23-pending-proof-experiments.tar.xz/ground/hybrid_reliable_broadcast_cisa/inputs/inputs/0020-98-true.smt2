(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun _old_l2s_g_3 () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun ___old_l2s_g_3 () Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun new__old_l2s_g_0_a (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __m_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __m__old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun ___old_l2s_g_2 (hrb.node hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 __l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (hrb.member_fi |__fml:n|))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (let (($x234 (not __ts0_a)))
 (or $x234 (=> _old_l2s_g_3 l2s_g_3))))
(assert
 (or __ts0_a (= l2s_g_3 __l2s_g_3)))
(assert
 (= _old_l2s_g_3 (ite __ts0_a __l2s_g_3 ___old_l2s_g_3)))
(assert
 (let (($x424 (l2s_g_2 @N @M)))
 (let (($x425 (not $x424)))
 (let (($x421 (hrb.rcv_init @N)))
 (let (($x420 (hrb.correct @N)))
 (let (($x422 (and $x420 $x421)))
 (and (not (=> $x422 $x425)))))))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x460 (hrb.sent_msg |__fml:s| |__fml:n|)))
 (or __ts0_a_a (= $x460 $x203)))))
(assert
 (or __ts0_a_a (= (l2s_g_2 @N @M) (__l2s_g_2 @N @M))))
(assert
 (let (($x467 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> $x466 $x467))))))
(assert
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> (l2s_g_2 @N @M) (not (hrb.sent_msg @N @M))))))
(assert
 (let (($x478 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x479 (not $x478)))
 (let (($x474 (l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x477 (and $x474 (and (hrb.sent_msg |__fml:s| |__fml:n|) (hrb.correct |__fml:n|)))))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> $x477 $x479))))))))
(assert
 (let (($x485 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x486 (not $x485)))
 (let (($x482 (l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x484 (and $x482 (and (hrb.sent_msg |__fml:n| |__fml:n|) (hrb.correct |__fml:n|)))))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> $x484 $x486))))))))
(assert
 (let (($x493 (l2s_g_1 @N @M)))
 (let (($x494 (not $x493)))
 (let (($x489 (l2s_g_0 @N @M)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> (and $x489 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x494)))))))
(assert
 (let (($x498 (= |__fml:s| |__fml:n|)))
 (let (($x460 (hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or $x460 (not (__hrb.sent_msg |__fml:s| |__fml:n|)) $x498))))))
(assert
 (let (($x502 (= |__fml:n| |__fml:n|)))
 (let (($x467 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or $x467 (not (__hrb.sent_msg |__fml:n| |__fml:n|)) $x502))))))
(assert
 (let (($x498 (= |__fml:s| |__fml:n|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or (not (hrb.sent_msg |__fml:s| |__fml:n|)) $x203 $x498))))))
(assert
 (let (($x502 (= |__fml:n| |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or (not (hrb.sent_msg |__fml:n| |__fml:n|)) $x466 $x502))))))
(assert
 (let (($x424 (l2s_g_2 @N @M)))
 (let (($x425 (not $x424)))
 (let (($x516 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x425)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 $x516))))))
(assert
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> (_old_l2s_g_2 @N @M) (l2s_g_2 @N @M)))))
(assert
 (let (($x478 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x479 (not $x478)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x522 (and $x203 $x475)))
 (let (($x523 (=> $x522 $x479)))
 (let (($x526 (=> (and (not (new__old_l2s_g_0_a |__fml:s| |__fml:n|)) $x523) (not (l2s_g_0 |__fml:s| |__fml:n|)))))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 $x526))))))))))
(assert
 (let (($x485 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x486 (not $x485)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x530 (and $x466 $x475)))
 (let (($x531 (=> $x530 $x486)))
 (let (($x534 (=> (and (not (new__old_l2s_g_0_a |__fml:n| |__fml:n|)) $x531) (not (l2s_g_0 |__fml:n| |__fml:n|)))))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 $x534))))))))))
(assert
 (let (($x493 (l2s_g_1 @N @M)))
 (let (($x494 (not $x493)))
 (let (($x490 (hrb.correct @M)))
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x538 (and $x513 $x490)))
 (let (($x539 (=> $x538 $x494)))
 (let (($x542 (=> (and (not (new__old_l2s_g_0_a @N @M)) $x539) (not (l2s_g_0 @N @M)))))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 $x542))))))))))
(assert
 (let (($x474 (l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x520 (new__old_l2s_g_0_a |__fml:s| |__fml:n|)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> $x520 $x474))))))
(assert
 (let (($x482 (l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x528 (new__old_l2s_g_0_a |__fml:n| |__fml:n|)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> $x528 $x482))))))
(assert
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> (new__old_l2s_g_0_a @N @M) (l2s_g_0 @N @M)))))
(assert
 (let (($x478 (l2s_g_1 |__fml:s| |__fml:n|)))
 (=> $x478 (not (hrb.rcv_msg |__fml:s| |__fml:n|)))))
(assert
 (let (($x485 (l2s_g_1 |__fml:n| |__fml:n|)))
 (=> $x485 (not (hrb.rcv_msg |__fml:n| |__fml:n|)))))
(assert
 (let (($x493 (l2s_g_1 @N @M)))
 (=> $x493 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x478 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x479 (not $x478)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x522 (and $x203 $x475)))
 (let (($x559 (__m_l2s_g_0 |__fml:s| |__fml:n|)))
 (=> (and $x559 $x522) $x479))))))))
(assert
 (let (($x485 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x486 (not $x485)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x530 (and $x466 $x475)))
 (let (($x562 (__m_l2s_g_0 |__fml:n| |__fml:n|)))
 (=> (and $x562 $x530) $x486))))))))
(assert
 (let (($x493 (l2s_g_1 @N @M)))
 (let (($x494 (not $x493)))
 (let (($x490 (hrb.correct @M)))
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x538 (and $x513 $x490)))
 (let (($x565 (__m_l2s_g_0 @N @M)))
 (=> (and $x565 $x538) $x494))))))))
(assert
 (let (($x478 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x479 (not $x478)))
 (let (($x570 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x571 (not $x570)))
 (=> (and (not (_old_l2s_g_1 |__fml:s| |__fml:n|)) $x571) $x479))))))
(assert
 (let (($x485 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x486 (not $x485)))
 (let (($x576 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x577 (not $x576)))
 (=> (and (not (_old_l2s_g_1 |__fml:n| |__fml:n|)) $x577) $x486))))))
(assert
 (let (($x493 (l2s_g_1 @N @M)))
 (let (($x494 (not $x493)))
 (=> (and (not (_old_l2s_g_1 @N @M)) (not (__hrb.rcv_msg @N @M))) $x494))))
(assert
 (let (($x478 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x568 (_old_l2s_g_1 |__fml:s| |__fml:n|)))
 (=> $x568 $x478))))
(assert
 (let (($x485 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x574 (_old_l2s_g_1 |__fml:n| |__fml:n|)))
 (=> $x574 $x485))))
(assert
 (let (($x493 (l2s_g_1 @N @M)))
 (let (($x580 (_old_l2s_g_1 @N @M)))
 (=> $x580 $x493))))
(assert
 (let (($x478 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x479 (not $x478)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x522 (and $x203 $x475)))
 (let (($x523 (=> $x522 $x479)))
 (=> (and (not (__m__old_l2s_g_0 |__fml:s| |__fml:n|)) $x523) (not (__m_l2s_g_0 |__fml:s| |__fml:n|))))))))))
(assert
 (let (($x485 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x486 (not $x485)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x530 (and $x466 $x475)))
 (let (($x531 (=> $x530 $x486)))
 (=> (and (not (__m__old_l2s_g_0 |__fml:n| |__fml:n|)) $x531) (not (__m_l2s_g_0 |__fml:n| |__fml:n|))))))))))
(assert
 (let (($x493 (l2s_g_1 @N @M)))
 (let (($x494 (not $x493)))
 (let (($x490 (hrb.correct @M)))
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x538 (and $x513 $x490)))
 (let (($x539 (=> $x538 $x494)))
 (=> (and (not (__m__old_l2s_g_0 @N @M)) $x539) (not (__m_l2s_g_0 @N @M))))))))))
(assert
 (let (($x559 (__m_l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x589 (__m__old_l2s_g_0 |__fml:s| |__fml:n|)))
 (=> $x589 $x559))))
(assert
 (let (($x562 (__m_l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x594 (__m__old_l2s_g_0 |__fml:n| |__fml:n|)))
 (=> $x594 $x562))))
(assert
 (let (($x565 (__m_l2s_g_0 @N @M)))
 (let (($x599 (__m__old_l2s_g_0 @N @M)))
 (=> $x599 $x565))))
(assert
 (not (and (__hrb.rcv_msg |__fml:s| |__fml:n|) (__l2s_w_0 |__fml:s| |__fml:n|))))
(assert
 (not (and (__hrb.rcv_msg |__fml:n| |__fml:n|) (__l2s_w_0 |__fml:n| |__fml:n|))))
(assert
 (not (and (__hrb.rcv_msg @N @M) (__l2s_w_0 @N @M))))
(assert
 (let (($x616 (__l2s_w_1 |__fml:s| |__fml:n|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (not (and $x203 $x616)))))
(assert
 (let (($x619 (__l2s_w_1 |__fml:n| |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (not (and $x466 $x619)))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x514 (not $x513)))
 (let (($x463 (__l2s_g_2 @N @M)))
 (=> $x463 $x514)))))
(assert
 (let (($x570 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x571 (not $x570)))
 (let (($x626 (__l2s_g_1 |__fml:s| |__fml:n|)))
 (=> $x626 $x571)))))
(assert
 (let (($x576 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x577 (not $x576)))
 (let (($x628 (__l2s_g_1 |__fml:n| |__fml:n|)))
 (=> $x628 $x577)))))
(assert
 (let (($x582 (__hrb.rcv_msg @N @M)))
 (let (($x583 (not $x582)))
 (let (($x630 (__l2s_g_1 @N @M)))
 (=> $x630 $x583)))))
(assert
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x522 (and $x203 $x475)))
 (let (($x632 (__l2s_g_0 |__fml:s| |__fml:n|)))
 (=> (and $x632 $x522) (not (__l2s_g_1 |__fml:s| |__fml:n|))))))))
(assert
 (let (($x475 (hrb.correct |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x530 (and $x466 $x475)))
 (let (($x636 (__l2s_g_0 |__fml:n| |__fml:n|)))
 (=> (and $x636 $x530) (not (__l2s_g_1 |__fml:n| |__fml:n|))))))))
(assert
 (let (($x490 (hrb.correct @M)))
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x538 (and $x513 $x490)))
 (let (($x640 (__l2s_g_0 @N @M)))
 (=> (and $x640 $x538) (not (__l2s_g_1 @N @M))))))))
(assert
 (let (($x652 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x652))))
(assert
 (let (($x660 (hrb.member_fa @N)))
 (let (($x661 (not $x660)))
 (let (($x656 (hrb.member_fi @N)))
 (let (($x657 (not $x656)))
 (let (($x420 (hrb.correct @N)))
 (= $x420 (and (not (hrb.member_fc @N)) $x657 (not (hrb.member_fs @N)) $x661))))))))
(assert
 (let (($x447 (hrb.member_fa |__fml:n|)))
 (let (($x667 (not $x447)))
 (let (($x450 (hrb.member_fs |__fml:n|)))
 (let (($x666 (not $x450)))
 (let (($x201 (hrb.member_fi |__fml:n|)))
 (let (($x665 (not $x201)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (= $x475 (and (not (hrb.member_fc |__fml:n|)) $x665 $x666 $x667))))))))))
(assert
 (let (($x676 (hrb.member_fa @M)))
 (let (($x677 (not $x676)))
 (let (($x674 (hrb.member_fs @M)))
 (let (($x675 (not $x674)))
 (let (($x490 (hrb.correct @M)))
 (= $x490 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x675 $x677))))))))
(assert
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x203)))
(assert
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x251 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x684 (hrb.symmetric |__fml:n|)))
 (let (($x685 (and $x684 $x251)))
 (=> $x685 $x466))))))
(assert
 (let (($x513 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x513)))
(assert
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:s| |__fml:n|)) $x203)))
(assert
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:n| |__fml:n|)) $x466)))
(assert
 (let (($x513 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (__hrb.rcv_msg @N @M)) $x513)))
(assert
 (let (($x681 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x203 $x681))))
(assert
 (let (($x251 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> $x466 $x251))))
(assert
 (let (($x688 (__hrb.sent_msg_proj @N)))
 (let (($x513 (__hrb.sent_msg @N @M)))
 (=> $x513 $x688))))
(assert
 (let (($x570 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x702 (l2s_s_1 |__fml:s| |__fml:n|)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (=> (and l2s_saved $x475 $x702 (not (__l2s_w_0 |__fml:s| |__fml:n|))) $x570)))))
(assert
 (let (($x576 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x706 (l2s_s_1 |__fml:n| |__fml:n|)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (=> (and l2s_saved $x475 $x706 (not (__l2s_w_0 |__fml:n| |__fml:n|))) $x576)))))
(assert
 (let (($x582 (__hrb.rcv_msg @N @M)))
 (let (($x710 (l2s_s_1 @N @M)))
 (let (($x490 (hrb.correct @M)))
 (=> (and l2s_saved $x490 $x710 (not (__l2s_w_0 @N @M))) $x582)))))
(assert
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x715 (hrb.rcv_init |__fml:s|)))
 (let (($x714 (hrb.correct |__fml:s|)))
 (=> (and l2s_saved $x714 $x715 (not (__l2s_w_1 |__fml:s| |__fml:n|))) $x203)))))
(assert
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x719 (hrb.rcv_init |__fml:n|)))
 (let (($x475 (hrb.correct |__fml:n|)))
 (=> (and l2s_saved $x475 $x719 (not (__l2s_w_1 |__fml:n| |__fml:n|))) $x466)))))
(assert
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x421 (hrb.rcv_init @N)))
 (let (($x420 (hrb.correct @N)))
 (=> (and l2s_saved $x420 $x421 (not (__l2s_w_1 @N @M))) $x513)))))
(assert
 (let (($x719 (hrb.rcv_init |__fml:n|)))
 (let (($x691 (hrb.obedient |__fml:n|)))
 (=> $x691 $x719))))
(assert
 (let (($x727 (hrb.rcv_init @M)))
 (let (($x696 (hrb.obedient @M)))
 (=> $x696 $x727))))
(assert
 (__l2s_g_0 |__fml:s| |__fml:n|))
(assert
 (__l2s_g_0 |__fml:n| |__fml:n|))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x421 (hrb.rcv_init @N)))
 (let (($x420 (hrb.correct @N)))
 (let (($x422 (and $x420 $x421)))
 (=> $x422 (not (__l2s_g_2 @N @M)))))))
(assert
 (=> (and l2s_saved (and (l2s_s_4 |__fml:n|) (hrb.obedient |__fml:n|))) (__hrb.accept |__fml:n|)))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @M) (hrb.obedient @M))) (__hrb.accept @M)))
(assert
 (let (($x570 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x743 (and l2s_saved (and (l2s_s_0 |__fml:s| |__fml:n|) (hrb.obedient |__fml:n|)))))
 (=> $x743 $x570))))
(assert
 (let (($x576 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x747 (and l2s_saved (and (l2s_s_0 |__fml:n| |__fml:n|) (hrb.obedient |__fml:n|)))))
 (=> $x747 $x576))))
(assert
 (let (($x582 (__hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x582)))
(assert
 (let (($x681 (__hrb.sent_msg_proj |__fml:s|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:s|)) $x681)))
(assert
 (let (($x251 (__hrb.sent_msg_proj |__fml:n|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:n|)) $x251)))
(assert
 (let (($x688 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x688)))
(assert
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and l2s_saved (l2s_s_1 |__fml:s| |__fml:n|)) $x203)))
(assert
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> (and l2s_saved (l2s_s_1 |__fml:n| |__fml:n|)) $x466)))
(assert
 (let (($x513 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x513)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:s|) (hrb.rcv_init |__fml:s|))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:n|) (hrb.rcv_init |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_9 @M) (hrb.rcv_init @M))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x511 (_old_l2s_g_2 @N @M)))
 (= $x511 (ite __ts0_a_a (__l2s_g_2 @N @M) (___old_l2s_g_2 @N @M)))))
(assert
 (let (($x589 (__m__old_l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x559 (__m_l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x520 (new__old_l2s_g_0_a |__fml:s| |__fml:n|)))
 (= $x520 (ite __ts0_a_a $x559 $x589))))))
(assert
 (let (($x594 (__m__old_l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x562 (__m_l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x528 (new__old_l2s_g_0_a |__fml:n| |__fml:n|)))
 (= $x528 (ite __ts0_a_a $x562 $x594))))))
(assert
 (let (($x536 (new__old_l2s_g_0_a @N @M)))
 (= $x536 (ite __ts0_a_a (__m_l2s_g_0 @N @M) (__m__old_l2s_g_0 @N @M)))))
(assert
 (let (($x570 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x550 (hrb.rcv_msg |__fml:s| |__fml:n|)))
 (= $x550 (ite (and (= |__fml:s| |__fml:s|) (= |__fml:n| |__fml:n|)) true $x570)))))
(assert
 (let (($x576 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x553 (hrb.rcv_msg |__fml:n| |__fml:n|)))
 (= $x553 (ite (and (= |__fml:n| |__fml:s|) (= |__fml:n| |__fml:n|)) true $x576)))))
(assert
 (let (($x582 (__hrb.rcv_msg @N @M)))
 (let (($x556 (hrb.rcv_msg @N @M)))
 (= $x556 (ite (and (= @N |__fml:s|) (= @M |__fml:n|)) true $x582)))))
(assert
 (let (($x626 (__l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x568 (_old_l2s_g_1 |__fml:s| |__fml:n|)))
 (= $x568 $x626))))
(assert
 (let (($x628 (__l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x574 (_old_l2s_g_1 |__fml:n| |__fml:n|)))
 (= $x574 $x628))))
(assert
 (let (($x630 (__l2s_g_1 @N @M)))
 (let (($x580 (_old_l2s_g_1 @N @M)))
 (= $x580 $x630))))
(assert
 (let (($x632 (__l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x589 (__m__old_l2s_g_0 |__fml:s| |__fml:n|)))
 (= $x589 $x632))))
(assert
 (let (($x636 (__l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x594 (__m__old_l2s_g_0 |__fml:n| |__fml:n|)))
 (= $x594 $x636))))
(assert
 (let (($x640 (__l2s_g_0 @N @M)))
 (let (($x599 (__m__old_l2s_g_0 @N @M)))
 (= $x599 $x640))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (let (($x466 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x467 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (or __ts0_a_a (= $x467 $x466)))))
(assert
 (or __ts0_a_a (= (hrb.sent_msg @N @M) (__hrb.sent_msg @N @M))))
(assert
 (or __ts0_a_a (= (l2s_g_0 |__fml:s| |__fml:n|) (__m_l2s_g_0 |__fml:s| |__fml:n|))))
(assert
 (or __ts0_a_a (= (l2s_g_0 |__fml:n| |__fml:n|) (__m_l2s_g_0 |__fml:n| |__fml:n|))))
(assert
 (or __ts0_a_a (= (l2s_g_0 @N @M) (__m_l2s_g_0 @N @M))))
(assert
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (=> (__hrb.sent_msg |__fml:n| @M) (hrb.sent_msg |__fml:n| @M)))))
(assert
 (let (($x908 (= @N |__fml:n|)))
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x514 (not $x513)))
 (let (($x470 (hrb.sent_msg @N @M)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or $x470 $x514 $x908))))))))
(assert
 (let (($x502 (= |__fml:n| |__fml:n|)))
 (let (($x905 (hrb.sent_msg |__fml:n| @M)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or $x905 (not (__hrb.sent_msg |__fml:n| @M)) $x502))))))
(assert
 (let (($x908 (= @N |__fml:n|)))
 (let (($x513 (__hrb.sent_msg @N @M)))
 (let (($x470 (hrb.sent_msg @N @M)))
 (let (($x471 (not $x470)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or $x471 $x513 $x908))))))))
(assert
 (let (($x502 (= |__fml:n| |__fml:n|)))
 (let (($x904 (__hrb.sent_msg |__fml:n| @M)))
 (let (($x254 (not __ts0_a_a)))
 (or $x254 (or (not (hrb.sent_msg |__fml:n| @M)) $x904 $x502))))))
(assert
 (let (($x925 (hrb.member_fa |__fml:s|)))
 (let (($x926 (not $x925)))
 (let (($x921 (hrb.member_fi |__fml:s|)))
 (let (($x922 (not $x921)))
 (let (($x927 (and (not (hrb.member_fc |__fml:s|)) $x922 (not (hrb.member_fs |__fml:s|)) $x926)))
 (let (($x714 (hrb.correct |__fml:s|)))
 (= $x714 $x927))))))))
(assert
 (let (($x680 (hrb.symmetric |__fml:s|)))
 (= $x680 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x684 (hrb.symmetric |__fml:n|)))
 (= $x684 (and (not (hrb.member_fi |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (let (($x687 (hrb.symmetric @N)))
 (= $x687 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x691 (hrb.obedient |__fml:n|)))
 (= $x691 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (let (($x696 (hrb.obedient @M)))
 (= $x696 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x904 (__hrb.sent_msg |__fml:n| @M)))
 (let (($x251 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x684 (hrb.symmetric |__fml:n|)))
 (let (($x685 (and $x684 $x251)))
 (=> $x685 $x904))))))
(assert
 (let (($x251 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x904 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x904 $x251))))
(assert
 (not (and (hrb.member_fs |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fi |__fml:s|))))
(assert
 (or __ts0_a_a (= (hrb.sent_msg |__fml:n| @M) (__hrb.sent_msg |__fml:n| @M))))
(check-sat)
