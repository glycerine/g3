(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun __l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun _old_l2s_g_8 () Bool)
(declare-fun l2s_w_3 (hrb.node) Bool)
(declare-fun pending_goal_function_2 (hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not l2s_g_7))
(assert
 l2s_g_9)
(assert
 (not __l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> l2s_g_5 $x138))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> l2s_g_6 $x148))))
(assert
 (=> _old_l2s_g_8 l2s_g_8))
(assert
 (= _old_l2s_g_8 __l2s_g_8))
(assert
 (and l2s_g_8))
(assert
 (not (and (hrb.sent_msg_proj hrb.n2) (l2s_w_3 hrb.n2))))
(assert
 (not (and (hrb.accept hrb.n1) (pending_goal_function_2 hrb.n1))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x384 (pending_goal_function_1 hrb.n2)))
 (=> $x384 $x148)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x386 (pending_goal_function_0 hrb.n1)))
 (=> $x386 $x138)))))
(assert
 (let (($x396 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x396))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (l2s_w_3 hrb.n2))) (or (hrb.sent_msg_proj hrb.n2) (pending_goal_function_1 hrb.n2))))
(assert
 (let (($x403 (hrb.obedient hrb.n1)))
 (=> (and l2s_saved $x403 (not (pending_goal_function_2 hrb.n1))) (or (hrb.accept hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (let (($x439 (hrb.rcv_init hrb.n2)))
 (let (($x398 (hrb.obedient hrb.n2)))
 (=> $x398 $x439))))
(assert
 (let (($x441 (hrb.rcv_init hrb.n1)))
 (let (($x403 (hrb.obedient hrb.n1)))
 (=> $x403 $x441))))
(assert
 (let (($x398 (hrb.obedient hrb.n2)))
 (= $x398 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x403 (hrb.obedient hrb.n1)))
 (= $x403 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (=> l2s_saved (= (l2s_s_9 hrb.n2) (hrb.rcv_init hrb.n2))))
(assert
 (=> l2s_saved (= (l2s_s_9 hrb.n1) (hrb.rcv_init hrb.n1))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(check-sat)
