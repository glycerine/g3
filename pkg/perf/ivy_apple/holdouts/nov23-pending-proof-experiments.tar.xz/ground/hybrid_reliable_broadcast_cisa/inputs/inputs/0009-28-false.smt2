(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun |__loc:nondet| () Bool)
(declare-fun __ts0__ts0_a () Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(assert
 (hrb.member_fc |__fml:n|))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (= __ts0__ts0_a |__loc:nondet|))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x74)))
(assert
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:s| |__fml:n|)) $x74)))
(assert
 (let (($x183 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x74 $x183))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (let (($x182 (hrb.symmetric |__fml:s|)))
 (= $x182 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x186 (hrb.obedient |__fml:n|)))
 (= $x186 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(check-sat)
