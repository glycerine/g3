(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (let (($x73 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x73)))
(assert
 (let (($x73 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:s| |__fml:n|)) $x73)))
(assert
 (let (($x168 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x73 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x73 $x168))))
(assert
 (let (($x167 (hrb.symmetric |__fml:s|)))
 (= $x167 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x171 (hrb.obedient |__fml:n|)))
 (= $x171 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fi |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(check-sat)
