(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_7 () Bool)
(declare-fun __l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun __l2s_g_5 () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun _old_l2s_g_5 () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun _old_l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun _old_l2s_g_9 () Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun ___old_l2s_g_5 () Bool)
(declare-fun ___old_l2s_g_7 () Bool)
(declare-fun ___old_l2s_g_9 () Bool)
(declare-fun ___old_l2s_g_6 () Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun _old_l2s_g_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun new__old_l2s_g_0_a (hrb.node hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun _old_l2s_g_3 (hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __m_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __m__old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun __l2s_w_2 (hrb.node) Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_4 (hrb.node) Bool)
(declare-fun __l2s_g_3 (hrb.node) Bool)
(declare-fun __l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun ___old_l2s_g_4 (hrb.node) Bool)
(declare-fun ___old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun ___old_l2s_g_3 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not __l2s_g_7))
(assert
 __l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> __l2s_g_5 $x138))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> __l2s_g_6 $x148))))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (let (($x314 (not __ts0_a)))
 (or $x314 (=> _old_l2s_g_5 l2s_g_5))))
(assert
 (let (($x333 (=> (and (not _old_l2s_g_5) (not (__hrb.accept hrb.n1))) (not l2s_g_5))))
 (let (($x314 (not __ts0_a)))
 (or $x314 $x333))))
(assert
 (let (($x314 (not __ts0_a)))
 (or $x314 (=> _old_l2s_g_7 l2s_g_7))))
(assert
 (let (($x314 (not __ts0_a)))
 (or $x314 (=> _old_l2s_g_9 l2s_g_9))))
(assert
 (let (($x314 (not __ts0_a)))
 (or $x314 (=> l2s_g_5 (not (hrb.accept hrb.n1))))))
(assert
 (or __ts0_a (= l2s_g_5 __l2s_g_5)))
(assert
 (or __ts0_a (= l2s_g_7 __l2s_g_7)))
(assert
 (or __ts0_a (= l2s_g_9 __l2s_g_9)))
(assert
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> _old_l2s_g_6 l2s_g_6))))
(assert
 (let (($x433 (=> (and (not _old_l2s_g_6) (not (__hrb.sent_msg_proj hrb.n2))) (not l2s_g_6))))
 (let (($x382 (not __ts0_a_a)))
 (or $x382 $x433))))
(assert
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> l2s_g_6 (not (hrb.sent_msg_proj hrb.n2))))))
(assert
 (or __ts0_a_a (= l2s_g_6 __l2s_g_6)))
(assert
 (= _old_l2s_g_5 (ite __ts0_a __l2s_g_5 ___old_l2s_g_5)))
(assert
 (= _old_l2s_g_7 (ite __ts0_a __l2s_g_7 ___old_l2s_g_7)))
(assert
 (= _old_l2s_g_9 (ite __ts0_a __l2s_g_9 ___old_l2s_g_9)))
(assert
 (= _old_l2s_g_6 (ite __ts0_a_a __l2s_g_6 ___old_l2s_g_6)))
(assert
 (let (($x606 (l2s_g_2 @N @M)))
 (let (($x607 (not $x606)))
 (let (($x603 (hrb.rcv_init @N)))
 (let (($x602 (hrb.correct @N)))
 (let (($x604 (and $x602 $x603)))
 (and (not (=> $x604 $x607)))))))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x358 (hrb.accept hrb.n1)))
 (= $x358 (ite __ts0_a (ite (and (= hrb.n1 |__fml:n|)) true $x137) $x137)))))
(assert
 (or __ts0_a_a (= (l2s_g_2 @N @M) (__l2s_g_2 @N @M))))
(assert
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> (pending_goal_function_1 hrb.n2) (not (hrb.sent_msg_proj hrb.n2))))))
(assert
 (let (($x644 (=> (and (not (_old_l2s_g_4 hrb.n2)) (not (__hrb.sent_msg_proj hrb.n2))) (not (pending_goal_function_1 hrb.n2)))))
 (let (($x382 (not __ts0_a_a)))
 (or $x382 $x644))))
(assert
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> (_old_l2s_g_4 hrb.n2) (pending_goal_function_1 hrb.n2)))))
(assert
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> (l2s_g_2 @N @M) (not (hrb.sent_msg @N @M))))))
(assert
 (let (($x656 (l2s_g_1 @N @M)))
 (let (($x657 (not $x656)))
 (let (($x652 (l2s_g_0 @N @M)))
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> (and $x652 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x657)))))))
(assert
 (let (($x606 (l2s_g_2 @N @M)))
 (let (($x607 (not $x606)))
 (let (($x665 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x607)))
 (let (($x382 (not __ts0_a_a)))
 (or $x382 $x665))))))
(assert
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> (_old_l2s_g_2 @N @M) (l2s_g_2 @N @M)))))
(assert
 (let (($x656 (l2s_g_1 @N @M)))
 (let (($x657 (not $x656)))
 (let (($x653 (hrb.correct @M)))
 (let (($x662 (__hrb.sent_msg @N @M)))
 (let (($x671 (and $x662 $x653)))
 (let (($x672 (=> $x671 $x657)))
 (let (($x675 (=> (and (not (new__old_l2s_g_0_a @N @M)) $x672) (not (l2s_g_0 @N @M)))))
 (let (($x382 (not __ts0_a_a)))
 (or $x382 $x675))))))))))
(assert
 (let (($x382 (not __ts0_a_a)))
 (or $x382 (=> (new__old_l2s_g_0_a @N @M) (l2s_g_0 @N @M)))))
(assert
 (let (($x314 (not __ts0_a)))
 (or $x314 (=> (pending_goal_function_0 hrb.n1) (not (hrb.accept hrb.n1))))))
(assert
 (let (($x686 (=> (and (not (_old_l2s_g_3 hrb.n1)) (not (__hrb.accept hrb.n1))) (not (pending_goal_function_0 hrb.n1)))))
 (let (($x314 (not __ts0_a)))
 (or $x314 $x686))))
(assert
 (let (($x314 (not __ts0_a)))
 (or $x314 (=> (_old_l2s_g_3 hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x656 (l2s_g_1 @N @M)))
 (=> $x656 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x656 (l2s_g_1 @N @M)))
 (let (($x657 (not $x656)))
 (let (($x653 (hrb.correct @M)))
 (let (($x662 (__hrb.sent_msg @N @M)))
 (let (($x671 (and $x662 $x653)))
 (let (($x693 (__m_l2s_g_0 @N @M)))
 (=> (and $x693 $x671) $x657))))))))
(assert
 (let (($x656 (l2s_g_1 @N @M)))
 (let (($x657 (not $x656)))
 (=> (and (not (_old_l2s_g_1 @N @M)) (not (__hrb.rcv_msg @N @M))) $x657))))
(assert
 (let (($x656 (l2s_g_1 @N @M)))
 (let (($x696 (_old_l2s_g_1 @N @M)))
 (=> $x696 $x656))))
(assert
 (let (($x656 (l2s_g_1 @N @M)))
 (let (($x657 (not $x656)))
 (let (($x653 (hrb.correct @M)))
 (let (($x662 (__hrb.sent_msg @N @M)))
 (let (($x671 (and $x662 $x653)))
 (let (($x672 (=> $x671 $x657)))
 (=> (and (not (__m__old_l2s_g_0 @N @M)) $x672) (not (__m_l2s_g_0 @N @M))))))))))
(assert
 (let (($x693 (__m_l2s_g_0 @N @M)))
 (let (($x703 (__m__old_l2s_g_0 @N @M)))
 (=> $x703 $x693))))
(assert
 (not (and (__hrb.sent_msg_proj hrb.n2) (__l2s_w_3 hrb.n2))))
(assert
 (not (and (__hrb.accept hrb.n1) (__l2s_w_2 hrb.n1))))
(assert
 (not (and (__hrb.rcv_msg @N @M) (__l2s_w_0 @N @M))))
(assert
 (let (($x718 (__l2s_w_1 |__fml:s| |__fml:n|)))
 (let (($x286 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (not (and $x286 $x718)))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x724 (__l2s_g_4 hrb.n2)))
 (=> $x724 $x148)))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x726 (__l2s_g_3 hrb.n1)))
 (=> $x726 $x138)))))
(assert
 (let (($x662 (__hrb.sent_msg @N @M)))
 (let (($x663 (not $x662)))
 (let (($x634 (__l2s_g_2 @N @M)))
 (=> $x634 $x663)))))
(assert
 (let (($x698 (__hrb.rcv_msg @N @M)))
 (let (($x699 (not $x698)))
 (let (($x729 (__l2s_g_1 @N @M)))
 (=> $x729 $x699)))))
(assert
 (let (($x653 (hrb.correct @M)))
 (let (($x662 (__hrb.sent_msg @N @M)))
 (let (($x671 (and $x662 $x653)))
 (let (($x731 (__l2s_g_0 @N @M)))
 (=> (and $x731 $x671) (not (__l2s_g_1 @N @M))))))))
(assert
 (let (($x603 (hrb.rcv_init @N)))
 (let (($x735 (hrb.obedient @N)))
 (=> $x735 $x603))))
(assert
 (let (($x745 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x745))))
(assert
 (let (($x753 (hrb.member_fa @N)))
 (let (($x754 (not $x753)))
 (let (($x751 (hrb.member_fs @N)))
 (let (($x752 (not $x751)))
 (let (($x749 (hrb.member_fi @N)))
 (let (($x750 (not $x749)))
 (let (($x602 (hrb.correct @N)))
 (= $x602 (and (not (hrb.member_fc @N)) $x750 $x752 $x754))))))))))
(assert
 (let (($x763 (hrb.member_fa @M)))
 (let (($x764 (not $x763)))
 (let (($x761 (hrb.member_fs @M)))
 (let (($x762 (not $x761)))
 (let (($x653 (hrb.correct @M)))
 (= $x653 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x762 $x764))))))))
(assert
 (let (($x735 (hrb.obedient @N)))
 (= $x735 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x286 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x286)))
(assert
 (let (($x662 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x662)))
(assert
 (let (($x662 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (__hrb.rcv_msg @N @M)) $x662)))
(assert
 (let (($x770 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x286 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x286 $x770))))
(assert
 (let (($x774 (__hrb.sent_msg_proj @N)))
 (let (($x662 (__hrb.sent_msg @N @M)))
 (=> $x662 $x774))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (__hrb.sent_msg_proj hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n1) (not (__l2s_w_2 hrb.n1))) (or (__hrb.accept hrb.n1) (__l2s_g_3 hrb.n1))))
(assert
 (let (($x698 (__hrb.rcv_msg @N @M)))
 (let (($x792 (l2s_s_1 @N @M)))
 (let (($x653 (hrb.correct @M)))
 (=> (and l2s_saved $x653 $x792 (not (__l2s_w_0 @N @M))) $x698)))))
(assert
 (let (($x286 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x797 (hrb.rcv_init |__fml:s|)))
 (let (($x796 (hrb.correct |__fml:s|)))
 (=> (and l2s_saved $x796 $x797 (not (__l2s_w_1 |__fml:s| |__fml:n|))) $x286)))))
(assert
 (let (($x662 (__hrb.sent_msg @N @M)))
 (let (($x603 (hrb.rcv_init @N)))
 (let (($x602 (hrb.correct @N)))
 (=> (and l2s_saved $x602 $x603 (not (__l2s_w_1 @N @M))) $x662)))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x603 (hrb.rcv_init @N)))
 (let (($x602 (hrb.correct @N)))
 (let (($x604 (and $x602 $x603)))
 (=> $x604 (not (__l2s_g_2 @N @M)))))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x698 (__hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x698)))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (let (($x770 (__hrb.sent_msg_proj |__fml:s|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:s|)) $x770)))
(assert
 (let (($x774 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x774)))
(assert
 (let (($x662 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x662)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:s|) (hrb.rcv_init |__fml:s|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x640 (_old_l2s_g_4 hrb.n2)))
 (= $x640 (ite __ts0_a_a (__l2s_g_4 hrb.n2) (___old_l2s_g_4 hrb.n2)))))
(assert
 (let (($x662 (__hrb.sent_msg @N @M)))
 (let (($x648 (hrb.sent_msg @N @M)))
 (= $x648 (ite __ts0_a_a (ite (and (= @N |__fml:n|)) true $x662) $x662)))))
(assert
 (let (($x660 (_old_l2s_g_2 @N @M)))
 (= $x660 (ite __ts0_a_a (__l2s_g_2 @N @M) (___old_l2s_g_2 @N @M)))))
(assert
 (let (($x669 (new__old_l2s_g_0_a @N @M)))
 (= $x669 (ite __ts0_a_a (__m_l2s_g_0 @N @M) (__m__old_l2s_g_0 @N @M)))))
(assert
 (let (($x682 (_old_l2s_g_3 hrb.n1)))
 (= $x682 (ite __ts0_a (__l2s_g_3 hrb.n1) (___old_l2s_g_3 hrb.n1)))))
(assert
 (let (($x698 (__hrb.rcv_msg @N @M)))
 (let (($x690 (hrb.rcv_msg @N @M)))
 (= $x690 (ite (and (= @N |__fml:s|) (= @M |__fml:n|)) true $x698)))))
(assert
 (let (($x729 (__l2s_g_1 @N @M)))
 (let (($x696 (_old_l2s_g_1 @N @M)))
 (= $x696 $x729))))
(assert
 (let (($x731 (__l2s_g_0 @N @M)))
 (let (($x703 (__m__old_l2s_g_0 @N @M)))
 (= $x703 $x731))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (or __ts0_a_a (= (pending_goal_function_1 hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (or __ts0_a_a (= (l2s_g_0 @N @M) (__m_l2s_g_0 @N @M))))
(assert
 (or __ts0_a (= (pending_goal_function_0 hrb.n1) (__l2s_g_3 hrb.n1))))
(assert
 (let (($x797 (hrb.rcv_init |__fml:s|)))
 (let (($x932 (hrb.obedient |__fml:s|)))
 (=> $x932 $x797))))
(assert
 (let (($x940 (hrb.member_fa |__fml:s|)))
 (let (($x941 (not $x940)))
 (let (($x938 (hrb.member_fs |__fml:s|)))
 (let (($x939 (not $x938)))
 (let (($x936 (hrb.member_fi |__fml:s|)))
 (let (($x937 (not $x936)))
 (let (($x796 (hrb.correct |__fml:s|)))
 (= $x796 (and (not (hrb.member_fc |__fml:s|)) $x937 $x939 $x941))))))))))
(assert
 (let (($x769 (hrb.symmetric |__fml:s|)))
 (= $x769 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x773 (hrb.symmetric @N)))
 (= $x773 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x777 (hrb.obedient @M)))
 (= $x777 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x782 (hrb.obedient hrb.n2)))
 (= $x782 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x787 (hrb.obedient hrb.n1)))
 (= $x787 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (let (($x932 (hrb.obedient |__fml:s|)))
 (= $x932 (and (not (hrb.member_fs |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (not (and (hrb.member_fs |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fi |__fml:s|))))
(check-sat)
