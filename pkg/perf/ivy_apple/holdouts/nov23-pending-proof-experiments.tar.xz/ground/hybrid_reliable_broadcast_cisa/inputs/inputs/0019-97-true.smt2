(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun _old_l2s_g_3 () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun ___old_l2s_g_3 () Bool)
(declare-fun |__loc:nondet| () Bool)
(declare-fun __ts0__ts0_a () Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun __ts0_b () Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun new__old_l2s_g_0_a (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __m_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __m__old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun ___old_l2s_g_2 (hrb.node hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 __l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (hrb.member_fc |__fml:n|))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (let (($x234 (not __ts0_a)))
 (or $x234 (=> _old_l2s_g_3 l2s_g_3))))
(assert
 (or __ts0_a (= l2s_g_3 __l2s_g_3)))
(assert
 (= _old_l2s_g_3 (ite __ts0_a __l2s_g_3 ___old_l2s_g_3)))
(assert
 (= __ts0__ts0_a |__loc:nondet|))
(assert
 (let (($x433 (l2s_g_2 @N @M)))
 (let (($x434 (not $x433)))
 (let (($x430 (hrb.rcv_init @N)))
 (let (($x429 (hrb.correct @N)))
 (let (($x431 (and $x429 $x430)))
 (and (not (=> $x431 $x434)))))))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x465 (__l2s_g_2 @N @M)))
 (let (($x433 (l2s_g_2 @N @M)))
 (let (($x466 (= $x433 $x465)))
 (or __ts0_b $x466)))))
(assert
 (let (($x252 (not __ts0_b)))
 (or $x252 (or __ts0__ts0_a (= (l2s_g_2 @N @M) (__l2s_g_2 @N @M))))))
(assert
 (let (($x250 (not __ts0__ts0_a)))
 (let (($x252 (not __ts0_b)))
 (or $x252 (or $x250 (=> (l2s_g_2 @N @M) (not (hrb.sent_msg @N @M))))))))
(assert
 (let (($x479 (l2s_g_1 @N @M)))
 (let (($x480 (not $x479)))
 (let (($x475 (l2s_g_0 @N @M)))
 (let (($x250 (not __ts0__ts0_a)))
 (let (($x482 (or $x250 (=> (and $x475 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x480))))
 (let (($x252 (not __ts0_b)))
 (or $x252 $x482))))))))
(assert
 (let (($x433 (l2s_g_2 @N @M)))
 (let (($x434 (not $x433)))
 (let (($x489 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x434)))
 (let (($x250 (not __ts0__ts0_a)))
 (let (($x252 (not __ts0_b)))
 (or $x252 (or $x250 $x489))))))))
(assert
 (let (($x250 (not __ts0__ts0_a)))
 (let (($x252 (not __ts0_b)))
 (or $x252 (or $x250 (=> (_old_l2s_g_2 @N @M) (l2s_g_2 @N @M)))))))
(assert
 (let (($x479 (l2s_g_1 @N @M)))
 (let (($x480 (not $x479)))
 (let (($x476 (hrb.correct @M)))
 (let (($x486 (__hrb.sent_msg @N @M)))
 (let (($x497 (and $x486 $x476)))
 (let (($x498 (=> $x497 $x480)))
 (let (($x501 (=> (and (not (new__old_l2s_g_0_a @N @M)) $x498) (not (l2s_g_0 @N @M)))))
 (let (($x250 (not __ts0__ts0_a)))
 (let (($x252 (not __ts0_b)))
 (or $x252 (or $x250 $x501))))))))))))
(assert
 (let (($x250 (not __ts0__ts0_a)))
 (let (($x252 (not __ts0_b)))
 (or $x252 (or $x250 (=> (new__old_l2s_g_0_a @N @M) (l2s_g_0 @N @M)))))))
(assert
 (let (($x479 (l2s_g_1 @N @M)))
 (=> $x479 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x479 (l2s_g_1 @N @M)))
 (let (($x480 (not $x479)))
 (let (($x476 (hrb.correct @M)))
 (let (($x486 (__hrb.sent_msg @N @M)))
 (let (($x497 (and $x486 $x476)))
 (let (($x510 (__m_l2s_g_0 @N @M)))
 (=> (and $x510 $x497) $x480))))))))
(assert
 (let (($x479 (l2s_g_1 @N @M)))
 (let (($x480 (not $x479)))
 (=> (and (not (_old_l2s_g_1 @N @M)) (not (__hrb.rcv_msg @N @M))) $x480))))
(assert
 (let (($x479 (l2s_g_1 @N @M)))
 (let (($x513 (_old_l2s_g_1 @N @M)))
 (=> $x513 $x479))))
(assert
 (let (($x479 (l2s_g_1 @N @M)))
 (let (($x480 (not $x479)))
 (let (($x476 (hrb.correct @M)))
 (let (($x486 (__hrb.sent_msg @N @M)))
 (let (($x497 (and $x486 $x476)))
 (let (($x498 (=> $x497 $x480)))
 (=> (and (not (__m__old_l2s_g_0 @N @M)) $x498) (not (__m_l2s_g_0 @N @M))))))))))
(assert
 (let (($x510 (__m_l2s_g_0 @N @M)))
 (let (($x520 (__m__old_l2s_g_0 @N @M)))
 (=> $x520 $x510))))
(assert
 (not (and (__hrb.rcv_msg @N @M) (__l2s_w_0 @N @M))))
(assert
 (let (($x529 (__l2s_w_1 |__fml:s| |__fml:n|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (not (and $x203 $x529)))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x486 (__hrb.sent_msg @N @M)))
 (let (($x487 (not $x486)))
 (let (($x465 (__l2s_g_2 @N @M)))
 (=> $x465 $x487)))))
(assert
 (let (($x515 (__hrb.rcv_msg @N @M)))
 (let (($x516 (not $x515)))
 (let (($x536 (__l2s_g_1 @N @M)))
 (=> $x536 $x516)))))
(assert
 (let (($x476 (hrb.correct @M)))
 (let (($x486 (__hrb.sent_msg @N @M)))
 (let (($x497 (and $x486 $x476)))
 (let (($x538 (__l2s_g_0 @N @M)))
 (=> (and $x538 $x497) (not (__l2s_g_1 @N @M))))))))
(assert
 (let (($x550 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x550))))
(assert
 (let (($x558 (hrb.member_fa @N)))
 (let (($x559 (not $x558)))
 (let (($x554 (hrb.member_fi @N)))
 (let (($x555 (not $x554)))
 (let (($x429 (hrb.correct @N)))
 (= $x429 (and (not (hrb.member_fc @N)) $x555 (not (hrb.member_fs @N)) $x559))))))))
(assert
 (let (($x568 (hrb.member_fa @M)))
 (let (($x569 (not $x568)))
 (let (($x566 (hrb.member_fs @M)))
 (let (($x567 (not $x566)))
 (let (($x476 (hrb.correct @M)))
 (= $x476 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x567 $x569))))))))
(assert
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x203)))
(assert
 (let (($x486 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x486)))
(assert
 (let (($x486 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (__hrb.rcv_msg @N @M)) $x486)))
(assert
 (let (($x573 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x203 $x573))))
(assert
 (let (($x577 (__hrb.sent_msg_proj @N)))
 (let (($x486 (__hrb.sent_msg @N @M)))
 (=> $x486 $x577))))
(assert
 (let (($x515 (__hrb.rcv_msg @N @M)))
 (let (($x585 (l2s_s_1 @N @M)))
 (let (($x476 (hrb.correct @M)))
 (=> (and l2s_saved $x476 $x585 (not (__l2s_w_0 @N @M))) $x515)))))
(assert
 (let (($x203 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x590 (hrb.rcv_init |__fml:s|)))
 (let (($x589 (hrb.correct |__fml:s|)))
 (=> (and l2s_saved $x589 $x590 (not (__l2s_w_1 |__fml:s| |__fml:n|))) $x203)))))
(assert
 (let (($x486 (__hrb.sent_msg @N @M)))
 (let (($x430 (hrb.rcv_init @N)))
 (let (($x429 (hrb.correct @N)))
 (=> (and l2s_saved $x429 $x430 (not (__l2s_w_1 @N @M))) $x486)))))
(assert
 (let (($x597 (hrb.rcv_init @M)))
 (let (($x580 (hrb.obedient @M)))
 (=> $x580 $x597))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x430 (hrb.rcv_init @N)))
 (let (($x429 (hrb.correct @N)))
 (let (($x431 (and $x429 $x430)))
 (=> $x431 (not (__l2s_g_2 @N @M)))))))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @M) (hrb.obedient @M))) (__hrb.accept @M)))
(assert
 (let (($x515 (__hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x515)))
(assert
 (let (($x573 (__hrb.sent_msg_proj |__fml:s|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:s|)) $x573)))
(assert
 (let (($x577 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x577)))
(assert
 (let (($x486 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x486)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:s|) (hrb.rcv_init |__fml:s|))))
(assert
 (=> l2s_saved (= (l2s_s_9 @M) (hrb.rcv_init @M))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x486 (__hrb.sent_msg @N @M)))
 (let (($x679 (ite __ts0_b (ite __ts0__ts0_a (ite (and (= @N |__fml:n|)) true $x486) $x486) $x486)))
 (let (($x470 (hrb.sent_msg @N @M)))
 (= $x470 $x679)))))
(assert
 (let (($x681 (___old_l2s_g_2 @N @M)))
 (let (($x484 (_old_l2s_g_2 @N @M)))
 (= $x484 (ite __ts0_b (ite __ts0__ts0_a (__l2s_g_2 @N @M) $x681) $x681)))))
(assert
 (let (($x520 (__m__old_l2s_g_0 @N @M)))
 (let (($x495 (new__old_l2s_g_0_a @N @M)))
 (= $x495 (ite __ts0_b (ite __ts0__ts0_a (__m_l2s_g_0 @N @M) $x520) $x520)))))
(assert
 (let (($x515 (__hrb.rcv_msg @N @M)))
 (let (($x507 (hrb.rcv_msg @N @M)))
 (= $x507 (ite (and (= @N |__fml:s|) (= @M |__fml:n|)) true $x515)))))
(assert
 (let (($x536 (__l2s_g_1 @N @M)))
 (let (($x513 (_old_l2s_g_1 @N @M)))
 (= $x513 $x536))))
(assert
 (let (($x538 (__l2s_g_0 @N @M)))
 (let (($x520 (__m__old_l2s_g_0 @N @M)))
 (= $x520 $x538))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (let (($x510 (__m_l2s_g_0 @N @M)))
 (let (($x475 (l2s_g_0 @N @M)))
 (let (($x737 (= $x475 $x510)))
 (or __ts0_b $x737)))))
(assert
 (let (($x252 (not __ts0_b)))
 (or $x252 (or __ts0__ts0_a (= (l2s_g_0 @N @M) (__m_l2s_g_0 @N @M))))))
(assert
 (let (($x747 (hrb.member_fa |__fml:s|)))
 (let (($x748 (not $x747)))
 (let (($x743 (hrb.member_fi |__fml:s|)))
 (let (($x744 (not $x743)))
 (let (($x749 (and (not (hrb.member_fc |__fml:s|)) $x744 (not (hrb.member_fs |__fml:s|)) $x748)))
 (let (($x589 (hrb.correct |__fml:s|)))
 (= $x589 $x749))))))))
(assert
 (let (($x572 (hrb.symmetric |__fml:s|)))
 (= $x572 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x576 (hrb.symmetric @N)))
 (= $x576 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x580 (hrb.obedient @M)))
 (= $x580 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (not (and (hrb.member_fs |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fi |__fml:s|))))
(check-sat)
