(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_7 () Bool)
(declare-fun __l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun __l2s_g_5 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun _old_l2s_g_5 () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun _old_l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun _old_l2s_g_9 () Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun _old_l2s_g_3 (hrb.node) Bool)
(declare-fun l2s_w_3 (hrb.node) Bool)
(declare-fun __l2s_w_2 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun __l2s_g_3 (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not __l2s_g_7))
(assert
 __l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> __l2s_g_5 $x138))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> l2s_g_6 $x148))))
(assert
 (let (($x285 (hrb.member_fa |__fml:n|)))
 (let (($x286 (hrb.member_fs |__fml:n|)))
 (or $x286 $x285))))
(assert
 (=> _old_l2s_g_5 l2s_g_5))
(assert
 (=> (and (not _old_l2s_g_5) (not (__hrb.accept hrb.n1))) (not l2s_g_5)))
(assert
 (=> _old_l2s_g_7 l2s_g_7))
(assert
 (=> _old_l2s_g_9 l2s_g_9))
(assert
 (let (($x327 (hrb.accept hrb.n1)))
 (let (($x328 (not $x327)))
 (=> l2s_g_5 $x328))))
(assert
 (= _old_l2s_g_5 __l2s_g_5))
(assert
 (= _old_l2s_g_7 __l2s_g_7))
(assert
 (= _old_l2s_g_9 __l2s_g_9))
(assert
 (let (($x448 (hrb.accept @N)))
 (let (($x450 (not (=> (and l2s_saved (and (l2s_s_4 @N) (hrb.obedient @N))) $x448))))
 (and $x450))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x327 (hrb.accept hrb.n1)))
 (let (($x328 (not $x327)))
 (let (($x484 (pending_goal_function_1 hrb.n1)))
 (=> $x484 $x328)))))
(assert
 (=> (pending_goal_function_1 @N) (not (hrb.accept @N))))
(assert
 (let (($x489 (= hrb.n1 |__fml:n|)))
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x327 (hrb.accept hrb.n1)))
 (or $x327 $x138 $x489))))))
(assert
 (let (($x489 (= hrb.n1 |__fml:n|)))
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x327 (hrb.accept hrb.n1)))
 (let (($x328 (not $x327)))
 (or $x328 $x137 $x489))))))
(assert
 (=> (and (not (_old_l2s_g_3 hrb.n1)) (not (__hrb.accept hrb.n1))) (not (pending_goal_function_1 hrb.n1))))
(assert
 (let (($x484 (pending_goal_function_1 hrb.n1)))
 (let (($x492 (_old_l2s_g_3 hrb.n1)))
 (=> $x492 $x484))))
(assert
 (not (and (hrb.sent_msg_proj hrb.n2) (l2s_w_3 hrb.n2))))
(assert
 (not (and (__hrb.accept hrb.n1) (__l2s_w_2 hrb.n1))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x504 (pending_goal_function_0 hrb.n2)))
 (=> $x504 $x148)))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x506 (__l2s_g_3 hrb.n1)))
 (=> $x506 $x138)))))
(assert
 (let (($x508 (hrb.rcv_init @N)))
 (let (($x445 (hrb.obedient @N)))
 (=> $x445 $x508))))
(assert
 (let (($x518 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x518))))
(assert
 (let (($x445 (hrb.obedient @N)))
 (= $x445 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (l2s_w_3 hrb.n2))) (or (hrb.sent_msg_proj hrb.n2) (pending_goal_function_0 hrb.n2))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n1) (not (__l2s_w_2 hrb.n1))) (or (__hrb.accept hrb.n1) (__l2s_g_3 hrb.n1))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (let (($x506 (__l2s_g_3 hrb.n1)))
 (let (($x492 (_old_l2s_g_3 hrb.n1)))
 (= $x492 $x506))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (let (($x526 (hrb.obedient hrb.n2)))
 (= $x526 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x531 (hrb.obedient hrb.n1)))
 (= $x531 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(check-sat)
