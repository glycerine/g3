(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun pending_goal_function_2 (hrb.node) Bool)
(declare-fun _old_l2s_g_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_4 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not l2s_g_7))
(assert
 l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> l2s_g_5 $x138))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> __l2s_g_6 $x148))))
(assert
 (hrb.rcv_init |__fml:n|))
(assert
 (=> _old_l2s_g_6 l2s_g_6))
(assert
 (=> (and (not _old_l2s_g_6) (not (__hrb.sent_msg_proj hrb.n2))) (not l2s_g_6)))
(assert
 (let (($x334 (not (hrb.sent_msg_proj hrb.n2))))
 (=> l2s_g_6 $x334)))
(assert
 (= _old_l2s_g_6 __l2s_g_6))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (let (($x423 (not $x422)))
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x418 (hrb.correct @N)))
 (let (($x420 (and $x418 $x419)))
 (and (not (=> $x420 $x423)))))))))
(assert
 (let (($x334 (not (hrb.sent_msg_proj hrb.n2))))
 (let (($x445 (pending_goal_function_2 hrb.n2)))
 (=> $x445 $x334))))
(assert
 (=> (and (not (_old_l2s_g_4 hrb.n2)) (not (__hrb.sent_msg_proj hrb.n2))) (not (pending_goal_function_2 hrb.n2))))
(assert
 (let (($x445 (pending_goal_function_2 hrb.n2)))
 (let (($x447 (_old_l2s_g_4 hrb.n2)))
 (=> $x447 $x445))))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (=> $x422 (not (hrb.sent_msg @N @M)))))
(assert
 (let (($x460 (l2s_g_1 @N @M)))
 (let (($x461 (not $x460)))
 (let (($x456 (l2s_g_0 @N @M)))
 (=> (and $x456 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x461)))))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (let (($x423 (not $x422)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x423))))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (let (($x463 (_old_l2s_g_2 @N @M)))
 (=> $x463 $x422))))
(assert
 (let (($x460 (l2s_g_1 @N @M)))
 (let (($x461 (not $x460)))
 (let (($x457 (hrb.correct @M)))
 (let (($x465 (__hrb.sent_msg @N @M)))
 (let (($x472 (and $x465 $x457)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x472 $x461)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x456 (l2s_g_0 @N @M)))
 (let (($x470 (_old_l2s_g_0 @N @M)))
 (=> $x470 $x456))))
(assert
 (not (and (__hrb.sent_msg_proj hrb.n2) (__l2s_w_3 hrb.n2))))
(assert
 (not (and (hrb.accept hrb.n1) (pending_goal_function_1 hrb.n1))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x487 (__l2s_g_4 hrb.n2)))
 (=> $x487 $x148)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x489 (pending_goal_function_0 hrb.n1)))
 (=> $x489 $x138)))))
(assert
 (let (($x465 (__hrb.sent_msg @N @M)))
 (let (($x466 (not $x465)))
 (let (($x491 (__l2s_g_2 @N @M)))
 (=> $x491 $x466)))))
(assert
 (let (($x460 (l2s_g_1 @N @M)))
 (=> $x460 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x460 (l2s_g_1 @N @M)))
 (let (($x461 (not $x460)))
 (let (($x457 (hrb.correct @M)))
 (let (($x465 (__hrb.sent_msg @N @M)))
 (let (($x472 (and $x465 $x457)))
 (let (($x496 (__l2s_g_0 @N @M)))
 (=> (and $x496 $x472) $x461))))))))
(assert
 (let (($x285 (hrb.rcv_init |__fml:n|)))
 (let (($x499 (hrb.obedient |__fml:n|)))
 (=> $x499 $x285))))
(assert
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x501 (hrb.obedient @N)))
 (=> $x501 $x419))))
(assert
 (let (($x511 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x511))))
(assert
 (let (($x519 (hrb.member_fa @N)))
 (let (($x520 (not $x519)))
 (let (($x517 (hrb.member_fs @N)))
 (let (($x518 (not $x517)))
 (let (($x515 (hrb.member_fi @N)))
 (let (($x516 (not $x515)))
 (let (($x418 (hrb.correct @N)))
 (= $x418 (and (not (hrb.member_fc @N)) $x516 $x518 $x520))))))))))
(assert
 (let (($x529 (hrb.member_fa @M)))
 (let (($x530 (not $x529)))
 (let (($x527 (hrb.member_fs @M)))
 (let (($x528 (not $x527)))
 (let (($x457 (hrb.correct @M)))
 (= $x457 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x528 $x530))))))))
(assert
 (let (($x499 (hrb.obedient |__fml:n|)))
 (= $x499 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (let (($x501 (hrb.obedient @N)))
 (= $x501 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x465 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x465)))
(assert
 (let (($x465 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x465)))
(assert
 (let (($x542 (__hrb.sent_msg_proj @N)))
 (let (($x465 (__hrb.sent_msg @N @M)))
 (=> $x465 $x542))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (__hrb.sent_msg_proj hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (let (($x554 (hrb.obedient hrb.n1)))
 (=> (and l2s_saved $x554 (not (pending_goal_function_1 hrb.n1))) (or (hrb.accept hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x493 (hrb.rcv_msg @N @M)))
 (let (($x559 (l2s_s_1 @N @M)))
 (let (($x457 (hrb.correct @M)))
 (=> (and l2s_saved $x457 $x559 (not (l2s_w_0 @N @M))) $x493)))))
(assert
 (let (($x465 (__hrb.sent_msg @N @M)))
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x418 (hrb.correct @N)))
 (=> (and l2s_saved $x418 $x419 (not (__l2s_w_1 @N @M))) $x465)))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x418 (hrb.correct @N)))
 (let (($x420 (and $x418 $x419)))
 (=> $x420 (not (__l2s_g_2 @N @M)))))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x493 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x493)))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (let (($x542 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x542)))
(assert
 (let (($x465 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x465)))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:n|) (hrb.rcv_init |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x487 (__l2s_g_4 hrb.n2)))
 (let (($x447 (_old_l2s_g_4 hrb.n2)))
 (= $x447 $x487))))
(assert
 (let (($x453 (hrb.sent_msg @N @M)))
 (= $x453 (ite (and (= @N |__fml:n|)) true (__hrb.sent_msg @N @M)))))
(assert
 (let (($x491 (__l2s_g_2 @N @M)))
 (let (($x463 (_old_l2s_g_2 @N @M)))
 (= $x463 $x491))))
(assert
 (let (($x496 (__l2s_g_0 @N @M)))
 (let (($x470 (_old_l2s_g_0 @N @M)))
 (= $x470 $x496))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x541 (hrb.symmetric @N)))
 (= $x541 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x545 (hrb.obedient @M)))
 (= $x545 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x549 (hrb.obedient hrb.n2)))
 (= $x549 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x554 (hrb.obedient hrb.n1)))
 (= $x554 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(check-sat)
