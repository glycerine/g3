(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun __l2s_saved () Bool)
(declare-fun __l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __l2s_w_2 () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_w_2 () Bool)
(declare-fun l2s_a (hrb.node) Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun __l2s_d (hrb.node) Bool)
(declare-fun __l2s_a (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun hrb.d (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun __l2s_s_4 (hrb.node) Bool)
(declare-fun __l2s_s_10 (hrb.node) Bool)
(declare-fun __l2s_s_9 (hrb.node) Bool)
(declare-fun __l2s_s_5 (hrb.node) Bool)
(declare-fun __l2s_s_8 (hrb.node) Bool)
(declare-fun __l2s_s_7 (hrb.node) Bool)
(declare-fun __l2s_s_6 (hrb.node) Bool)
(assert
 (or __l2s_waiting __l2s_frozen __l2s_saved))
(assert
 (let (($x9 (not __l2s_frozen)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x9 (not __l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (or __ts0_c __ts0_d))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or __ts0_a __ts0_b))))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or (not __ts0_a) __l2s_waiting))))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or (not __ts0_a) (not __l2s_w_2)))))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or (not __ts0_b) __l2s_frozen))))
(assert
 l2s_saved)
(assert
 (not l2s_w_2))
(assert
 (=> (and (or (l2s_a l2s_s_11) (l2s_a hrb.n0))) (= l2s_s_11 hrb.n0)))
(assert
 (= l2s_waiting (ite __ts0_d __l2s_waiting (ite __ts0_b __l2s_waiting false))))
(assert
 (= l2s_frozen (ite __ts0_d __l2s_frozen (ite __ts0_b false true))))
(assert
 (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved))))
(assert
 (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n0 __l2s_s_11))))
(assert
 (and (not false)))
(assert
 (let (($x452 (__l2s_a l2s_s_11)))
 (let (($x283 (l2s_a l2s_s_11)))
 (= $x283 (ite __ts0_d $x452 (ite __ts0_b $x452 (__l2s_d l2s_s_11)))))))
(assert
 (let (($x457 (__l2s_a hrb.n0)))
 (let (($x284 (l2s_a hrb.n0)))
 (= $x284 (ite __ts0_d $x457 (ite __ts0_b $x457 (__l2s_d hrb.n0)))))))
(assert
 (let (($x283 (l2s_a l2s_s_11)))
 (let (($x462 (and $x283)))
 (=> $x462 (= (l2s_s_4 l2s_s_11) (hrb.accept l2s_s_11))))))
(assert
 (let (($x284 (l2s_a hrb.n0)))
 (let (($x467 (and $x284)))
 (=> $x467 (= (l2s_s_4 hrb.n0) (hrb.accept hrb.n0))))))
(assert
 (let (($x283 (l2s_a l2s_s_11)))
 (let (($x462 (and $x283)))
 (=> $x462 (= (l2s_s_10 l2s_s_11) (hrb.sent_msg_proj l2s_s_11))))))
(assert
 (let (($x284 (l2s_a hrb.n0)))
 (let (($x467 (and $x284)))
 (=> $x467 (= (l2s_s_10 hrb.n0) (hrb.sent_msg_proj hrb.n0))))))
(assert
 (let (($x283 (l2s_a l2s_s_11)))
 (let (($x462 (and $x283)))
 (=> $x462 (= (l2s_s_9 l2s_s_11) (hrb.rcv_init l2s_s_11))))))
(assert
 (let (($x284 (l2s_a hrb.n0)))
 (let (($x467 (and $x284)))
 (=> $x467 (= (l2s_s_9 hrb.n0) (hrb.rcv_init hrb.n0))))))
(assert
 (let (($x283 (l2s_a l2s_s_11)))
 (let (($x462 (and $x283)))
 (=> $x462 (= (l2s_s_5 l2s_s_11) (hrb.member_fa l2s_s_11))))))
(assert
 (let (($x284 (l2s_a hrb.n0)))
 (let (($x467 (and $x284)))
 (=> $x467 (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))))
(assert
 (let (($x283 (l2s_a l2s_s_11)))
 (let (($x462 (and $x283)))
 (=> $x462 (= (l2s_s_8 l2s_s_11) (hrb.member_fs l2s_s_11))))))
(assert
 (let (($x284 (l2s_a hrb.n0)))
 (let (($x467 (and $x284)))
 (=> $x467 (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))))
(assert
 (let (($x283 (l2s_a l2s_s_11)))
 (let (($x462 (and $x283)))
 (=> $x462 (= (l2s_s_7 l2s_s_11) (hrb.member_fi l2s_s_11))))))
(assert
 (let (($x284 (l2s_a hrb.n0)))
 (let (($x467 (and $x284)))
 (=> $x467 (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))))
(assert
 (let (($x283 (l2s_a l2s_s_11)))
 (let (($x462 (and $x283)))
 (=> $x462 (= (l2s_s_6 l2s_s_11) (hrb.member_fc l2s_s_11))))))
(assert
 (let (($x284 (l2s_a hrb.n0)))
 (let (($x467 (and $x284)))
 (=> $x467 (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))))
(assert
 (let (($x493 (hrb.member_fa hrb.n0)))
 (let (($x523 (not $x493)))
 (let (($x501 (hrb.member_fs hrb.n0)))
 (let (($x522 (not $x501)))
 (let (($x524 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) $x522 $x523)))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x524))))))))
(assert
 (let (($x453 (__l2s_d l2s_s_11)))
 (=> (hrb.d l2s_s_11) $x453)))
(assert
 (let (($x458 (__l2s_d hrb.n0)))
 (=> (hrb.d hrb.n0) $x458)))
(assert
 (let (($x481 (hrb.rcv_init l2s_s_11)))
 (let (($x530 (hrb.obedient l2s_s_11)))
 (=> $x530 $x481))))
(assert
 (let (($x485 (hrb.rcv_init hrb.n0)))
 (let (($x532 (hrb.obedient hrb.n0)))
 (=> $x532 $x485))))
(assert
 (let (($x464 (hrb.accept l2s_s_11)))
 (let (($x536 (and __l2s_saved (and (__l2s_s_4 l2s_s_11) (hrb.obedient l2s_s_11)))))
 (=> $x536 $x464))))
(assert
 (let (($x469 (hrb.accept hrb.n0)))
 (=> (and __l2s_saved (and (__l2s_s_4 hrb.n0) (hrb.obedient hrb.n0))) $x469)))
(assert
 (let (($x473 (hrb.sent_msg_proj l2s_s_11)))
 (=> (and __l2s_saved (__l2s_s_10 l2s_s_11)) $x473)))
(assert
 (let (($x477 (hrb.sent_msg_proj hrb.n0)))
 (=> (and __l2s_saved (__l2s_s_10 hrb.n0)) $x477)))
(assert
 (=> __l2s_saved (= (__l2s_s_9 l2s_s_11) (hrb.rcv_init l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_9 hrb.n0) (hrb.rcv_init hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 l2s_s_11) (hrb.member_fs l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 l2s_s_11) (hrb.member_fi l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 l2s_s_11) (hrb.member_fc l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (let (($x534 (__l2s_s_4 l2s_s_11)))
 (let (($x463 (l2s_s_4 l2s_s_11)))
 (= $x463 (ite __ts0_d $x534 (ite __ts0_b (hrb.accept l2s_s_11) $x534))))))
(assert
 (let (($x538 (__l2s_s_4 hrb.n0)))
 (let (($x468 (l2s_s_4 hrb.n0)))
 (= $x468 (ite __ts0_d $x538 (ite __ts0_b (hrb.accept hrb.n0) $x538))))))
(assert
 (let (($x542 (__l2s_s_10 l2s_s_11)))
 (let (($x472 (l2s_s_10 l2s_s_11)))
 (= $x472 (ite __ts0_d $x542 (ite __ts0_b (hrb.sent_msg_proj l2s_s_11) $x542))))))
(assert
 (let (($x545 (__l2s_s_10 hrb.n0)))
 (let (($x476 (l2s_s_10 hrb.n0)))
 (= $x476 (ite __ts0_d $x545 (ite __ts0_b (hrb.sent_msg_proj hrb.n0) $x545))))))
(assert
 (let (($x548 (__l2s_s_9 l2s_s_11)))
 (let (($x480 (l2s_s_9 l2s_s_11)))
 (= $x480 (ite __ts0_d $x548 (ite __ts0_b (hrb.rcv_init l2s_s_11) $x548))))))
(assert
 (let (($x551 (__l2s_s_9 hrb.n0)))
 (let (($x484 (l2s_s_9 hrb.n0)))
 (= $x484 (ite __ts0_d $x551 (ite __ts0_b (hrb.rcv_init hrb.n0) $x551))))))
(assert
 (let (($x554 (__l2s_s_5 l2s_s_11)))
 (let (($x488 (l2s_s_5 l2s_s_11)))
 (= $x488 (ite __ts0_d $x554 (ite __ts0_b (hrb.member_fa l2s_s_11) $x554))))))
(assert
 (let (($x557 (__l2s_s_5 hrb.n0)))
 (let (($x492 (l2s_s_5 hrb.n0)))
 (= $x492 (ite __ts0_d $x557 (ite __ts0_b (hrb.member_fa hrb.n0) $x557))))))
(assert
 (let (($x560 (__l2s_s_8 l2s_s_11)))
 (let (($x496 (l2s_s_8 l2s_s_11)))
 (= $x496 (ite __ts0_d $x560 (ite __ts0_b (hrb.member_fs l2s_s_11) $x560))))))
(assert
 (let (($x563 (__l2s_s_8 hrb.n0)))
 (let (($x500 (l2s_s_8 hrb.n0)))
 (= $x500 (ite __ts0_d $x563 (ite __ts0_b (hrb.member_fs hrb.n0) $x563))))))
(assert
 (let (($x566 (__l2s_s_7 l2s_s_11)))
 (let (($x504 (l2s_s_7 l2s_s_11)))
 (= $x504 (ite __ts0_d $x566 (ite __ts0_b (hrb.member_fi l2s_s_11) $x566))))))
(assert
 (let (($x569 (__l2s_s_7 hrb.n0)))
 (let (($x508 (l2s_s_7 hrb.n0)))
 (= $x508 (ite __ts0_d $x569 (ite __ts0_b (hrb.member_fi hrb.n0) $x569))))))
(assert
 (let (($x572 (__l2s_s_6 l2s_s_11)))
 (let (($x512 (l2s_s_6 l2s_s_11)))
 (= $x512 (ite __ts0_d $x572 (ite __ts0_b (hrb.member_fc l2s_s_11) $x572))))))
(assert
 (let (($x575 (__l2s_s_6 hrb.n0)))
 (let (($x516 (l2s_s_6 hrb.n0)))
 (= $x516 (ite __ts0_d $x575 (ite __ts0_b (hrb.member_fc hrb.n0) $x575))))))
(assert
 (not (and (hrb.member_fs l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi l2s_s_11) (hrb.member_fs l2s_s_11))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc l2s_s_11) (hrb.member_fs l2s_s_11))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc l2s_s_11) (hrb.member_fi l2s_s_11))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (let (($x530 (hrb.obedient l2s_s_11)))
 (= $x530 (and (not (hrb.member_fs l2s_s_11)) (not (hrb.member_fa l2s_s_11))))))
(assert
 (let (($x532 (hrb.obedient hrb.n0)))
 (= $x532 (and (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0))))))
(check-sat)
