(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun __l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun __l2s_saved () Bool)
(declare-fun __l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __l2s_w_5 () Bool)
(declare-fun __l2s_w_4 () Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun __l2s_w_2 (hrb.node) Bool)
(declare-fun __l2s_s_4 (hrb.node) Bool)
(declare-fun __l2s_s_10 (hrb.node) Bool)
(declare-fun __l2s_s_5 (hrb.node) Bool)
(declare-fun __l2s_s_8 (hrb.node) Bool)
(declare-fun __l2s_s_7 (hrb.node) Bool)
(declare-fun __l2s_s_6 (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun __l2s_s_9 (hrb.node) Bool)
(assert
 (or __l2s_waiting __l2s_frozen __l2s_saved))
(assert
 (let (($x9 (not __l2s_frozen)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x9 (not __l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n1)))
(assert
 (=> __l2s_saved (= __l2s_s_12 hrb.n2)))
(assert
 (not l2s_g_7))
(assert
 l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (or __ts0_c __ts0_d))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or __ts0_a __ts0_b))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) __l2s_waiting))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not __l2s_w_5)))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not __l2s_w_4)))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_b) __l2s_frozen))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> l2s_g_5 $x138))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> l2s_g_6 $x148))))
(assert
 (= l2s_waiting (ite __ts0_d __l2s_waiting (ite __ts0_b __l2s_waiting false))))
(assert
 (= l2s_frozen (ite __ts0_d __l2s_frozen (ite __ts0_b false true))))
(assert
 (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved))))
(assert
 (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n1 __l2s_s_11))))
(assert
 (= l2s_s_12 (ite __ts0_d __l2s_s_12 (ite __ts0_b hrb.n2 __l2s_s_12))))
(assert
 (and (not (=> l2s_saved (= l2s_s_11 hrb.n1)))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x511 (pending_goal_function_1 hrb.n2)))
 (=> $x511 $x148)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x513 (pending_goal_function_0 hrb.n1)))
 (=> $x513 $x138)))))
(assert
 (let (($x523 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x523))))
(assert
 (=> (and __l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (hrb.sent_msg_proj hrb.n2) (pending_goal_function_1 hrb.n2))))
(assert
 (=> (and __l2s_saved (hrb.obedient hrb.n1) (not (__l2s_w_2 hrb.n1))) (or (hrb.accept hrb.n1) (pending_goal_function_0 hrb.n1))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (=> (and __l2s_saved (and (__l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (=> (and __l2s_saved (__l2s_s_10 hrb.n2)) $x147)))
(assert
 (=> __l2s_saved (= (__l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not (__l2s_w_3 hrb.n2))))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not (__l2s_w_2 hrb.n1))))))
(assert
 (let (($x572 (hrb.rcv_init hrb.n2)))
 (let (($x525 (hrb.obedient hrb.n2)))
 (=> $x525 $x572))))
(assert
 (let (($x574 (hrb.rcv_init hrb.n1)))
 (let (($x531 (hrb.obedient hrb.n1)))
 (=> $x531 $x574))))
(assert
 (let (($x525 (hrb.obedient hrb.n2)))
 (= $x525 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x531 (hrb.obedient hrb.n1)))
 (= $x531 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (=> __l2s_saved (= (__l2s_s_9 hrb.n2) (hrb.rcv_init hrb.n2))))
(assert
 (=> __l2s_saved (= (__l2s_s_9 hrb.n1) (hrb.rcv_init hrb.n1))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(check-sat)
