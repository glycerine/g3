(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (hrb.member_fi |__fml:n|))
(assert
 (hrb.rcv_init |__fml:n|))
(assert
 (let (($x318 (l2s_g_2 @N @M)))
 (let (($x319 (not $x318)))
 (let (($x315 (hrb.rcv_init @N)))
 (let (($x314 (hrb.correct @N)))
 (let (($x316 (and $x314 $x315)))
 (and (not (=> $x316 $x319)))))))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x354 (hrb.sent_msg @N @M)))
 (let (($x355 (not $x354)))
 (let (($x318 (l2s_g_2 @N @M)))
 (=> $x318 $x355)))))
(assert
 (let (($x361 (l2s_g_1 @N @M)))
 (let (($x362 (not $x361)))
 (let (($x357 (l2s_g_0 @N @M)))
 (=> (and $x357 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x362)))))
(assert
 (let (($x366 (= @N |__fml:n|)))
 (let (($x364 (__hrb.sent_msg @N @M)))
 (let (($x365 (not $x364)))
 (let (($x354 (hrb.sent_msg @N @M)))
 (or $x354 $x365 $x366))))))
(assert
 (let (($x366 (= @N |__fml:n|)))
 (let (($x364 (__hrb.sent_msg @N @M)))
 (let (($x354 (hrb.sent_msg @N @M)))
 (let (($x355 (not $x354)))
 (or $x355 $x364 $x366))))))
(assert
 (let (($x318 (l2s_g_2 @N @M)))
 (let (($x319 (not $x318)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x319))))
(assert
 (let (($x318 (l2s_g_2 @N @M)))
 (let (($x369 (_old_l2s_g_2 @N @M)))
 (=> $x369 $x318))))
(assert
 (let (($x361 (l2s_g_1 @N @M)))
 (let (($x362 (not $x361)))
 (let (($x358 (hrb.correct @M)))
 (let (($x364 (__hrb.sent_msg @N @M)))
 (let (($x376 (and $x364 $x358)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x376 $x362)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x357 (l2s_g_0 @N @M)))
 (let (($x374 (_old_l2s_g_0 @N @M)))
 (=> $x374 $x357))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x364 (__hrb.sent_msg @N @M)))
 (let (($x365 (not $x364)))
 (let (($x385 (__l2s_g_2 @N @M)))
 (=> $x385 $x365)))))
(assert
 (let (($x361 (l2s_g_1 @N @M)))
 (=> $x361 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x361 (l2s_g_1 @N @M)))
 (let (($x362 (not $x361)))
 (let (($x358 (hrb.correct @M)))
 (let (($x364 (__hrb.sent_msg @N @M)))
 (let (($x376 (and $x364 $x358)))
 (let (($x390 (__l2s_g_0 @N @M)))
 (=> (and $x390 $x376) $x362))))))))
(assert
 (let (($x401 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x401))))
(assert
 (let (($x409 (hrb.member_fa @N)))
 (let (($x410 (not $x409)))
 (let (($x405 (hrb.member_fi @N)))
 (let (($x406 (not $x405)))
 (let (($x314 (hrb.correct @N)))
 (= $x314 (and (not (hrb.member_fc @N)) $x406 (not (hrb.member_fs @N)) $x410))))))))
(assert
 (let (($x419 (hrb.member_fa @M)))
 (let (($x420 (not $x419)))
 (let (($x417 (hrb.member_fs @M)))
 (let (($x418 (not $x417)))
 (let (($x358 (hrb.correct @M)))
 (= $x358 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x418 $x420))))))))
(assert
 (let (($x364 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x364)))
(assert
 (let (($x364 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x364)))
(assert
 (let (($x424 (__hrb.sent_msg_proj @N)))
 (let (($x364 (__hrb.sent_msg @N @M)))
 (=> $x364 $x424))))
(assert
 (let (($x387 (hrb.rcv_msg @N @M)))
 (let (($x431 (l2s_s_1 @N @M)))
 (let (($x358 (hrb.correct @M)))
 (=> (and l2s_saved $x358 $x431 (not (l2s_w_0 @N @M))) $x387)))))
(assert
 (let (($x364 (__hrb.sent_msg @N @M)))
 (let (($x315 (hrb.rcv_init @N)))
 (let (($x314 (hrb.correct @N)))
 (=> (and l2s_saved $x314 $x315 (not (__l2s_w_1 @N @M))) $x364)))))
(assert
 (let (($x439 (hrb.rcv_init @M)))
 (let (($x427 (hrb.obedient @M)))
 (=> $x427 $x439))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x315 (hrb.rcv_init @N)))
 (let (($x314 (hrb.correct @N)))
 (let (($x316 (and $x314 $x315)))
 (=> $x316 (not (__l2s_g_2 @N @M)))))))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @M) (hrb.obedient @M))) (hrb.accept @M)))
(assert
 (let (($x387 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x387)))
(assert
 (let (($x424 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x424)))
(assert
 (let (($x364 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x364)))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:n|) (hrb.rcv_init |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 @M) (hrb.rcv_init @M))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x385 (__l2s_g_2 @N @M)))
 (let (($x369 (_old_l2s_g_2 @N @M)))
 (= $x369 $x385))))
(assert
 (let (($x390 (__l2s_g_0 @N @M)))
 (let (($x374 (_old_l2s_g_0 @N @M)))
 (= $x374 $x390))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (let (($x555 (hrb.sent_msg |__fml:n| @M)))
 (let (($x554 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x554 $x555))))
(assert
 (let (($x558 (= |__fml:n| |__fml:n|)))
 (let (($x555 (hrb.sent_msg |__fml:n| @M)))
 (or $x555 (not (__hrb.sent_msg |__fml:n| @M)) $x558))))
(assert
 (let (($x558 (= |__fml:n| |__fml:n|)))
 (let (($x554 (__hrb.sent_msg |__fml:n| @M)))
 (or (not (hrb.sent_msg |__fml:n| @M)) $x554 $x558))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x423 (hrb.symmetric @N)))
 (= $x423 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x427 (hrb.obedient @M)))
 (= $x427 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x554 (__hrb.sent_msg |__fml:n| @M)))
 (=> (and (hrb.symmetric |__fml:n|) (__hrb.sent_msg_proj |__fml:n|)) $x554)))
(assert
 (let (($x205 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x554 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x554 $x205))))
(assert
 (let (($x568 (hrb.symmetric |__fml:n|)))
 (= $x568 (and (not (hrb.member_fi |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(check-sat)
