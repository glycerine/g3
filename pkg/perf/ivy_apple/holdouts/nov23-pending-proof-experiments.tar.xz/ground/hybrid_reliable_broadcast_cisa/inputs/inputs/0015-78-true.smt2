(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @N2 () hrb.node)
(declare-fun @N1 () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun _old_l2s_g_3 () Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 __l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x201 (hrb.member_fa |__fml:n|)))
 (let (($x202 (hrb.member_fs |__fml:n|)))
 (or $x202 $x201))))
(assert
 (=> _old_l2s_g_3 l2s_g_3))
(assert
 (= _old_l2s_g_3 __l2s_g_3))
(assert
 (let (($x321 (l2s_g_0 @N1 @N2)))
 (let (($x322 (not $x321)))
 (and $x322))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x360 (l2s_g_1 @N1 @N2)))
 (let (($x361 (not $x360)))
 (let (($x357 (hrb.correct @N2)))
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (let (($x358 (and $x356 $x357)))
 (let (($x321 (l2s_g_0 @N1 @N2)))
 (=> (and $x321 $x358) $x361))))))))
(assert
 (let (($x360 (l2s_g_1 @N1 @N2)))
 (let (($x361 (not $x360)))
 (let (($x365 (__hrb.rcv_msg @N1 @N2)))
 (let (($x366 (not $x365)))
 (=> (and (not (_old_l2s_g_1 @N1 @N2)) $x366) $x361))))))
(assert
 (let (($x360 (l2s_g_1 @N1 @N2)))
 (let (($x363 (_old_l2s_g_1 @N1 @N2)))
 (=> $x363 $x360))))
(assert
 (let (($x321 (l2s_g_0 @N1 @N2)))
 (let (($x322 (not $x321)))
 (let (($x360 (l2s_g_1 @N1 @N2)))
 (let (($x361 (not $x360)))
 (let (($x357 (hrb.correct @N2)))
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (let (($x358 (and $x356 $x357)))
 (=> (and (not (_old_l2s_g_0 @N1 @N2)) (=> $x358 $x361)) $x322)))))))))
(assert
 (let (($x321 (l2s_g_0 @N1 @N2)))
 (let (($x370 (_old_l2s_g_0 @N1 @N2)))
 (=> $x370 $x321))))
(assert
 (not (and (__hrb.rcv_msg @N1 @N2) (__l2s_w_0 @N1 @N2))))
(assert
 (not (and (hrb.sent_msg @N1 @N2) (l2s_w_1 @N1 @N2))))
(assert
 (let (($x382 (l2s_g_2 @N1 @N2)))
 (=> $x382 (not (hrb.sent_msg @N1 @N2)))))
(assert
 (let (($x365 (__hrb.rcv_msg @N1 @N2)))
 (let (($x366 (not $x365)))
 (let (($x385 (__l2s_g_1 @N1 @N2)))
 (=> $x385 $x366)))))
(assert
 (let (($x357 (hrb.correct @N2)))
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (let (($x358 (and $x356 $x357)))
 (let (($x387 (__l2s_g_0 @N1 @N2)))
 (=> (and $x387 $x358) (not (__l2s_g_1 @N1 @N2))))))))
(assert
 (let (($x399 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x399))))
(assert
 (let (($x407 (hrb.member_fa @N2)))
 (let (($x408 (not $x407)))
 (let (($x405 (hrb.member_fs @N2)))
 (let (($x406 (not $x405)))
 (let (($x357 (hrb.correct @N2)))
 (= $x357 (and (not (hrb.member_fc @N2)) (not (hrb.member_fi @N2)) $x406 $x408))))))))
(assert
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (=> (and (hrb.symmetric @N1) (hrb.sent_msg_proj @N1)) $x356)))
(assert
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (=> (and (hrb.obedient @N2) (__hrb.rcv_msg @N1 @N2)) $x356)))
(assert
 (let (($x412 (hrb.sent_msg_proj @N1)))
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (=> $x356 $x412))))
(assert
 (let (($x365 (__hrb.rcv_msg @N1 @N2)))
 (let (($x419 (l2s_s_1 @N1 @N2)))
 (let (($x357 (hrb.correct @N2)))
 (=> (and l2s_saved $x357 $x419 (not (__l2s_w_0 @N1 @N2))) $x365)))))
(assert
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (let (($x424 (hrb.rcv_init @N1)))
 (let (($x423 (hrb.correct @N1)))
 (=> (and l2s_saved $x423 $x424 (not (l2s_w_1 @N1 @N2))) $x356)))))
(assert
 (let (($x424 (hrb.rcv_init @N1)))
 (let (($x428 (hrb.obedient @N1)))
 (=> $x428 $x424))))
(assert
 (__l2s_g_0 @N1 @N2))
(assert
 (=> (and (hrb.correct @N1) (hrb.rcv_init @N1)) (not (l2s_g_2 @N1 @N2))))
(assert
 (let (($x436 (__hrb.accept @N2)))
 (=> (and l2s_saved (and (l2s_s_4 @N2) (hrb.obedient @N2))) $x436)))
(assert
 (let (($x441 (__hrb.accept @N1)))
 (=> (and l2s_saved (and (l2s_s_4 @N1) (hrb.obedient @N1))) $x441)))
(assert
 (let (($x365 (__hrb.rcv_msg @N1 @N2)))
 (=> (and l2s_saved (and (l2s_s_0 @N1 @N2) (hrb.obedient @N2))) $x365)))
(assert
 (let (($x412 (hrb.sent_msg_proj @N1)))
 (=> (and l2s_saved (l2s_s_10 @N1)) $x412)))
(assert
 (let (($x356 (hrb.sent_msg @N1 @N2)))
 (=> (and l2s_saved (l2s_s_1 @N1 @N2)) $x356)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N1) (hrb.rcv_init @N1))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N2) (hrb.member_fa @N2))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N2) (hrb.member_fs @N2))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N2) (hrb.member_fi @N2))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N2) (hrb.member_fc @N2))))
(assert
 (let (($x385 (__l2s_g_1 @N1 @N2)))
 (let (($x363 (_old_l2s_g_1 @N1 @N2)))
 (= $x363 $x385))))
(assert
 (let (($x387 (__l2s_g_0 @N1 @N2)))
 (let (($x370 (_old_l2s_g_0 @N1 @N2)))
 (= $x370 $x387))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N2) (hrb.member_fa @N2))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N2) (hrb.member_fa @N2))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N2) (hrb.member_fs @N2))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N2) (hrb.member_fa @N2))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N2) (hrb.member_fs @N2))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N2) (hrb.member_fi @N2))))
(assert
 (let (($x517 (hrb.rcv_msg @N1 @N2)))
 (let (($x518 (not $x517)))
 (let (($x360 (l2s_g_1 @N1 @N2)))
 (=> $x360 $x518)))))
(assert
 (let (($x520 (= @N2 |__fml:n|)))
 (let (($x365 (__hrb.rcv_msg @N1 @N2)))
 (let (($x366 (not $x365)))
 (let (($x517 (hrb.rcv_msg @N1 @N2)))
 (or $x517 $x366 $x520))))))
(assert
 (let (($x520 (= @N2 |__fml:n|)))
 (let (($x365 (__hrb.rcv_msg @N1 @N2)))
 (let (($x517 (hrb.rcv_msg @N1 @N2)))
 (let (($x518 (not $x517)))
 (or $x518 $x365 $x520))))))
(assert
 (let (($x520 (= @N2 |__fml:n|)))
 (let (($x523 (hrb.accept @N2)))
 (or $x523 (not (__hrb.accept @N2)) $x520))))
(assert
 (let (($x528 (= @N1 |__fml:n|)))
 (let (($x526 (hrb.accept @N1)))
 (or $x526 (not (__hrb.accept @N1)) $x528))))
(assert
 (let (($x520 (= @N2 |__fml:n|)))
 (let (($x436 (__hrb.accept @N2)))
 (or (not (hrb.accept @N2)) $x436 $x520))))
(assert
 (let (($x528 (= @N1 |__fml:n|)))
 (let (($x441 (__hrb.accept @N1)))
 (or (not (hrb.accept @N1)) $x441 $x528))))
(assert
 (let (($x540 (hrb.member_fa @N1)))
 (let (($x541 (not $x540)))
 (let (($x538 (hrb.member_fs @N1)))
 (let (($x539 (not $x538)))
 (let (($x536 (hrb.member_fi @N1)))
 (let (($x537 (not $x536)))
 (let (($x423 (hrb.correct @N1)))
 (= $x423 (and (not (hrb.member_fc @N1)) $x537 $x539 $x541))))))))))
(assert
 (let (($x411 (hrb.symmetric @N1)))
 (= $x411 (and (not (hrb.member_fi @N1)) (not (hrb.member_fa @N1))))))
(assert
 (let (($x415 (hrb.obedient @N2)))
 (= $x415 (and (not (hrb.member_fs @N2)) (not (hrb.member_fa @N2))))))
(assert
 (let (($x428 (hrb.obedient @N1)))
 (= $x428 (and (not (hrb.member_fs @N1)) (not (hrb.member_fa @N1))))))
(assert
 (not (and (hrb.member_fs @N1) (hrb.member_fa @N1))))
(assert
 (not (and (hrb.member_fi @N1) (hrb.member_fa @N1))))
(assert
 (not (and (hrb.member_fi @N1) (hrb.member_fs @N1))))
(assert
 (not (and (hrb.member_fc @N1) (hrb.member_fa @N1))))
(assert
 (not (and (hrb.member_fc @N1) (hrb.member_fs @N1))))
(assert
 (not (and (hrb.member_fc @N1) (hrb.member_fi @N1))))
(check-sat)
