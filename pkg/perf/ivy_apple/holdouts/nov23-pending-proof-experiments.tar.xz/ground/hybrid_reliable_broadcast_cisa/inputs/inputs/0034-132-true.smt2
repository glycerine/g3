(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun __l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun __l2s_saved () Bool)
(declare-fun __l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __l2s_w_5 () Bool)
(declare-fun __l2s_w_4 () Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_w_5 () Bool)
(declare-fun l2s_w_4 () Bool)
(declare-fun l2s_a (hrb.node) Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun __l2s_d (hrb.node) Bool)
(declare-fun __l2s_a (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun __l2s_w_2 (hrb.node) Bool)
(declare-fun hrb.d (hrb.node) Bool)
(declare-fun __l2s_s_4 (hrb.node) Bool)
(declare-fun __l2s_s_10 (hrb.node) Bool)
(declare-fun __l2s_s_9 (hrb.node) Bool)
(declare-fun __l2s_s_5 (hrb.node) Bool)
(declare-fun __l2s_s_8 (hrb.node) Bool)
(declare-fun __l2s_s_7 (hrb.node) Bool)
(declare-fun __l2s_s_6 (hrb.node) Bool)
(assert
 (or __l2s_waiting __l2s_frozen __l2s_saved))
(assert
 (let (($x9 (not __l2s_frozen)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x9 (not __l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n1)))
(assert
 (=> __l2s_saved (= __l2s_s_12 hrb.n2)))
(assert
 (not l2s_g_7))
(assert
 l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (or __ts0_c __ts0_d))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or __ts0_a __ts0_b))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) __l2s_waiting))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not __l2s_w_5)))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not __l2s_w_4)))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_b) __l2s_frozen))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> l2s_g_5 $x138))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> l2s_g_6 $x148))))
(assert
 l2s_saved)
(assert
 (not l2s_w_5))
(assert
 (not l2s_w_4))
(assert
 (=> (and (or (l2s_a l2s_s_11) (l2s_a hrb.n1))) (= l2s_s_11 hrb.n1)))
(assert
 (=> (and (or (l2s_a l2s_s_12) (l2s_a hrb.n2))) (= l2s_s_12 hrb.n2)))
(assert
 (= l2s_waiting (ite __ts0_d __l2s_waiting (ite __ts0_b __l2s_waiting false))))
(assert
 (= l2s_frozen (ite __ts0_d __l2s_frozen (ite __ts0_b false true))))
(assert
 (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved))))
(assert
 (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n1 __l2s_s_11))))
(assert
 (= l2s_s_12 (ite __ts0_d __l2s_s_12 (ite __ts0_b hrb.n2 __l2s_s_12))))
(assert
 (and (not false)))
(assert
 (let (($x569 (__l2s_a l2s_s_11)))
 (let (($x376 (l2s_a l2s_s_11)))
 (= $x376 (ite __ts0_d $x569 (ite __ts0_b $x569 (__l2s_d l2s_s_11)))))))
(assert
 (let (($x574 (__l2s_a hrb.n1)))
 (let (($x377 (l2s_a hrb.n1)))
 (= $x377 (ite __ts0_d $x574 (ite __ts0_b $x574 (__l2s_d hrb.n1)))))))
(assert
 (let (($x579 (__l2s_a l2s_s_12)))
 (let (($x383 (l2s_a l2s_s_12)))
 (= $x383 (ite __ts0_d $x579 (ite __ts0_b $x579 (__l2s_d l2s_s_12)))))))
(assert
 (let (($x584 (__l2s_a hrb.n2)))
 (let (($x384 (l2s_a hrb.n2)))
 (= $x384 (ite __ts0_d $x584 (ite __ts0_b $x584 (__l2s_d hrb.n2)))))))
(assert
 (let (($x377 (l2s_a hrb.n1)))
 (let (($x589 (and $x377)))
 (=> $x589 (= (l2s_s_4 hrb.n1) (hrb.accept hrb.n1))))))
(assert
 (let (($x384 (l2s_a hrb.n2)))
 (let (($x593 (and $x384)))
 (=> $x593 (= (l2s_s_10 hrb.n2) (hrb.sent_msg_proj hrb.n2))))))
(assert
 (let (($x376 (l2s_a l2s_s_11)))
 (let (($x597 (and $x376)))
 (=> $x597 (= (l2s_s_9 l2s_s_11) (hrb.rcv_init l2s_s_11))))))
(assert
 (let (($x377 (l2s_a hrb.n1)))
 (let (($x589 (and $x377)))
 (=> $x589 (= (l2s_s_9 hrb.n1) (hrb.rcv_init hrb.n1))))))
(assert
 (let (($x383 (l2s_a l2s_s_12)))
 (let (($x606 (and $x383)))
 (=> $x606 (= (l2s_s_9 l2s_s_12) (hrb.rcv_init l2s_s_12))))))
(assert
 (let (($x384 (l2s_a hrb.n2)))
 (let (($x593 (and $x384)))
 (=> $x593 (= (l2s_s_9 hrb.n2) (hrb.rcv_init hrb.n2))))))
(assert
 (let (($x376 (l2s_a l2s_s_11)))
 (let (($x597 (and $x376)))
 (=> $x597 (= (l2s_s_5 l2s_s_11) (hrb.member_fa l2s_s_11))))))
(assert
 (let (($x377 (l2s_a hrb.n1)))
 (let (($x589 (and $x377)))
 (=> $x589 (= (l2s_s_5 hrb.n1) (hrb.member_fa hrb.n1))))))
(assert
 (let (($x383 (l2s_a l2s_s_12)))
 (let (($x606 (and $x383)))
 (=> $x606 (= (l2s_s_5 l2s_s_12) (hrb.member_fa l2s_s_12))))))
(assert
 (let (($x384 (l2s_a hrb.n2)))
 (let (($x593 (and $x384)))
 (=> $x593 (= (l2s_s_5 hrb.n2) (hrb.member_fa hrb.n2))))))
(assert
 (let (($x376 (l2s_a l2s_s_11)))
 (let (($x597 (and $x376)))
 (=> $x597 (= (l2s_s_8 l2s_s_11) (hrb.member_fs l2s_s_11))))))
(assert
 (let (($x377 (l2s_a hrb.n1)))
 (let (($x589 (and $x377)))
 (=> $x589 (= (l2s_s_8 hrb.n1) (hrb.member_fs hrb.n1))))))
(assert
 (let (($x383 (l2s_a l2s_s_12)))
 (let (($x606 (and $x383)))
 (=> $x606 (= (l2s_s_8 l2s_s_12) (hrb.member_fs l2s_s_12))))))
(assert
 (let (($x384 (l2s_a hrb.n2)))
 (let (($x593 (and $x384)))
 (=> $x593 (= (l2s_s_8 hrb.n2) (hrb.member_fs hrb.n2))))))
(assert
 (let (($x376 (l2s_a l2s_s_11)))
 (let (($x597 (and $x376)))
 (=> $x597 (= (l2s_s_7 l2s_s_11) (hrb.member_fi l2s_s_11))))))
(assert
 (let (($x377 (l2s_a hrb.n1)))
 (let (($x589 (and $x377)))
 (=> $x589 (= (l2s_s_7 hrb.n1) (hrb.member_fi hrb.n1))))))
(assert
 (let (($x383 (l2s_a l2s_s_12)))
 (let (($x606 (and $x383)))
 (=> $x606 (= (l2s_s_7 l2s_s_12) (hrb.member_fi l2s_s_12))))))
(assert
 (let (($x384 (l2s_a hrb.n2)))
 (let (($x593 (and $x384)))
 (=> $x593 (= (l2s_s_7 hrb.n2) (hrb.member_fi hrb.n2))))))
(assert
 (let (($x376 (l2s_a l2s_s_11)))
 (let (($x597 (and $x376)))
 (=> $x597 (= (l2s_s_6 l2s_s_11) (hrb.member_fc l2s_s_11))))))
(assert
 (let (($x377 (l2s_a hrb.n1)))
 (let (($x589 (and $x377)))
 (=> $x589 (= (l2s_s_6 hrb.n1) (hrb.member_fc hrb.n1))))))
(assert
 (let (($x383 (l2s_a l2s_s_12)))
 (let (($x606 (and $x383)))
 (=> $x606 (= (l2s_s_6 l2s_s_12) (hrb.member_fc l2s_s_12))))))
(assert
 (let (($x384 (l2s_a hrb.n2)))
 (let (($x593 (and $x384)))
 (=> $x593 (= (l2s_s_6 hrb.n2) (hrb.member_fc hrb.n2))))))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x679 (pending_goal_function_1 hrb.n2)))
 (=> $x679 $x148)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x681 (pending_goal_function_0 hrb.n1)))
 (=> $x681 $x138)))))
(assert
 (let (($x599 (hrb.rcv_init l2s_s_11)))
 (let (($x683 (hrb.obedient l2s_s_11)))
 (=> $x683 $x599))))
(assert
 (let (($x603 (hrb.rcv_init hrb.n1)))
 (let (($x685 (hrb.obedient hrb.n1)))
 (=> $x685 $x603))))
(assert
 (let (($x608 (hrb.rcv_init l2s_s_12)))
 (let (($x687 (hrb.obedient l2s_s_12)))
 (=> $x687 $x608))))
(assert
 (let (($x612 (hrb.rcv_init hrb.n2)))
 (let (($x689 (hrb.obedient hrb.n2)))
 (=> $x689 $x612))))
(assert
 (let (($x699 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x699))))
(assert
 (let (($x683 (hrb.obedient l2s_s_11)))
 (= $x683 (and (not (hrb.member_fs l2s_s_11)) (not (hrb.member_fa l2s_s_11))))))
(assert
 (let (($x685 (hrb.obedient hrb.n1)))
 (= $x685 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (let (($x687 (hrb.obedient l2s_s_12)))
 (= $x687 (and (not (hrb.member_fs l2s_s_12)) (not (hrb.member_fa l2s_s_12))))))
(assert
 (let (($x689 (hrb.obedient hrb.n2)))
 (= $x689 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (=> (and __l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (hrb.sent_msg_proj hrb.n2) (pending_goal_function_1 hrb.n2))))
(assert
 (=> (and __l2s_saved (hrb.obedient hrb.n1) (not (__l2s_w_2 hrb.n1))) (or (hrb.accept hrb.n1) (pending_goal_function_0 hrb.n1))))
(assert
 (let (($x570 (__l2s_d l2s_s_11)))
 (=> (hrb.d l2s_s_11) $x570)))
(assert
 (let (($x575 (__l2s_d hrb.n1)))
 (=> (hrb.d hrb.n1) $x575)))
(assert
 (let (($x580 (__l2s_d l2s_s_12)))
 (=> (hrb.d l2s_s_12) $x580)))
(assert
 (let (($x585 (__l2s_d hrb.n2)))
 (=> (hrb.d hrb.n2) $x585)))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (=> (and __l2s_saved (and (__l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x147 (hrb.sent_msg_proj hrb.n2)))
 (=> (and __l2s_saved (__l2s_s_10 hrb.n2)) $x147)))
(assert
 (=> __l2s_saved (= (__l2s_s_9 l2s_s_11) (hrb.rcv_init l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_9 hrb.n1) (hrb.rcv_init hrb.n1))))
(assert
 (=> __l2s_saved (= (__l2s_s_9 l2s_s_12) (hrb.rcv_init l2s_s_12))))
(assert
 (=> __l2s_saved (= (__l2s_s_9 hrb.n2) (hrb.rcv_init hrb.n2))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 l2s_s_12) (hrb.member_fa l2s_s_12))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 l2s_s_11) (hrb.member_fs l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 hrb.n1) (hrb.member_fs hrb.n1))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 l2s_s_12) (hrb.member_fs l2s_s_12))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 hrb.n2) (hrb.member_fs hrb.n2))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 l2s_s_11) (hrb.member_fi l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 hrb.n1) (hrb.member_fi hrb.n1))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 l2s_s_12) (hrb.member_fi l2s_s_12))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 hrb.n2) (hrb.member_fi hrb.n2))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 l2s_s_11) (hrb.member_fc l2s_s_11))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 hrb.n1) (hrb.member_fc hrb.n1))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 l2s_s_12) (hrb.member_fc l2s_s_12))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 hrb.n2) (hrb.member_fc hrb.n2))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (let (($x735 (__l2s_s_4 hrb.n1)))
 (let (($x590 (l2s_s_4 hrb.n1)))
 (= $x590 (ite __ts0_d $x735 (ite __ts0_b (hrb.accept hrb.n1) $x735))))))
(assert
 (let (($x739 (__l2s_s_10 hrb.n2)))
 (let (($x594 (l2s_s_10 hrb.n2)))
 (= $x594 (ite __ts0_d $x739 (ite __ts0_b (hrb.sent_msg_proj hrb.n2) $x739))))))
(assert
 (let (($x742 (__l2s_s_9 l2s_s_11)))
 (let (($x598 (l2s_s_9 l2s_s_11)))
 (= $x598 (ite __ts0_d $x742 (ite __ts0_b (hrb.rcv_init l2s_s_11) $x742))))))
(assert
 (let (($x745 (__l2s_s_9 hrb.n1)))
 (let (($x602 (l2s_s_9 hrb.n1)))
 (= $x602 (ite __ts0_d $x745 (ite __ts0_b (hrb.rcv_init hrb.n1) $x745))))))
(assert
 (let (($x748 (__l2s_s_9 l2s_s_12)))
 (let (($x607 (l2s_s_9 l2s_s_12)))
 (= $x607 (ite __ts0_d $x748 (ite __ts0_b (hrb.rcv_init l2s_s_12) $x748))))))
(assert
 (let (($x751 (__l2s_s_9 hrb.n2)))
 (let (($x611 (l2s_s_9 hrb.n2)))
 (= $x611 (ite __ts0_d $x751 (ite __ts0_b (hrb.rcv_init hrb.n2) $x751))))))
(assert
 (let (($x754 (__l2s_s_5 l2s_s_11)))
 (let (($x615 (l2s_s_5 l2s_s_11)))
 (= $x615 (ite __ts0_d $x754 (ite __ts0_b (hrb.member_fa l2s_s_11) $x754))))))
(assert
 (let (($x757 (__l2s_s_5 hrb.n1)))
 (let (($x619 (l2s_s_5 hrb.n1)))
 (= $x619 (ite __ts0_d $x757 (ite __ts0_b (hrb.member_fa hrb.n1) $x757))))))
(assert
 (let (($x760 (__l2s_s_5 l2s_s_12)))
 (let (($x623 (l2s_s_5 l2s_s_12)))
 (= $x623 (ite __ts0_d $x760 (ite __ts0_b (hrb.member_fa l2s_s_12) $x760))))))
(assert
 (let (($x763 (__l2s_s_5 hrb.n2)))
 (let (($x627 (l2s_s_5 hrb.n2)))
 (= $x627 (ite __ts0_d $x763 (ite __ts0_b (hrb.member_fa hrb.n2) $x763))))))
(assert
 (let (($x769 (__l2s_s_8 l2s_s_11)))
 (let (($x631 (l2s_s_8 l2s_s_11)))
 (= $x631 (ite __ts0_d $x769 (ite __ts0_b (hrb.member_fs l2s_s_11) $x769))))))
(assert
 (let (($x772 (__l2s_s_8 hrb.n1)))
 (let (($x635 (l2s_s_8 hrb.n1)))
 (= $x635 (ite __ts0_d $x772 (ite __ts0_b (hrb.member_fs hrb.n1) $x772))))))
(assert
 (let (($x775 (__l2s_s_8 l2s_s_12)))
 (let (($x639 (l2s_s_8 l2s_s_12)))
 (= $x639 (ite __ts0_d $x775 (ite __ts0_b (hrb.member_fs l2s_s_12) $x775))))))
(assert
 (let (($x778 (__l2s_s_8 hrb.n2)))
 (let (($x643 (l2s_s_8 hrb.n2)))
 (= $x643 (ite __ts0_d $x778 (ite __ts0_b (hrb.member_fs hrb.n2) $x778))))))
(assert
 (let (($x784 (__l2s_s_7 l2s_s_11)))
 (let (($x647 (l2s_s_7 l2s_s_11)))
 (= $x647 (ite __ts0_d $x784 (ite __ts0_b (hrb.member_fi l2s_s_11) $x784))))))
(assert
 (let (($x787 (__l2s_s_7 hrb.n1)))
 (let (($x651 (l2s_s_7 hrb.n1)))
 (= $x651 (ite __ts0_d $x787 (ite __ts0_b (hrb.member_fi hrb.n1) $x787))))))
(assert
 (let (($x790 (__l2s_s_7 l2s_s_12)))
 (let (($x655 (l2s_s_7 l2s_s_12)))
 (= $x655 (ite __ts0_d $x790 (ite __ts0_b (hrb.member_fi l2s_s_12) $x790))))))
(assert
 (let (($x793 (__l2s_s_7 hrb.n2)))
 (let (($x659 (l2s_s_7 hrb.n2)))
 (= $x659 (ite __ts0_d $x793 (ite __ts0_b (hrb.member_fi hrb.n2) $x793))))))
(assert
 (let (($x799 (__l2s_s_6 l2s_s_11)))
 (let (($x663 (l2s_s_6 l2s_s_11)))
 (= $x663 (ite __ts0_d $x799 (ite __ts0_b (hrb.member_fc l2s_s_11) $x799))))))
(assert
 (let (($x802 (__l2s_s_6 hrb.n1)))
 (let (($x667 (l2s_s_6 hrb.n1)))
 (= $x667 (ite __ts0_d $x802 (ite __ts0_b (hrb.member_fc hrb.n1) $x802))))))
(assert
 (let (($x805 (__l2s_s_6 l2s_s_12)))
 (let (($x671 (l2s_s_6 l2s_s_12)))
 (= $x671 (ite __ts0_d $x805 (ite __ts0_b (hrb.member_fc l2s_s_12) $x805))))))
(assert
 (let (($x808 (__l2s_s_6 hrb.n2)))
 (let (($x675 (l2s_s_6 hrb.n2)))
 (= $x675 (ite __ts0_d $x808 (ite __ts0_b (hrb.member_fc hrb.n2) $x808))))))
(assert
 (not (and (hrb.member_fs l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (not (and (hrb.member_fs l2s_s_12) (hrb.member_fa l2s_s_12))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (not (and (hrb.member_fi hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (not (and (hrb.member_fi l2s_s_12) (hrb.member_fa l2s_s_12))))
(assert
 (not (and (hrb.member_fi hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi l2s_s_11) (hrb.member_fs l2s_s_11))))
(assert
 (not (and (hrb.member_fi hrb.n1) (hrb.member_fs hrb.n1))))
(assert
 (not (and (hrb.member_fi l2s_s_12) (hrb.member_fs l2s_s_12))))
(assert
 (not (and (hrb.member_fi hrb.n2) (hrb.member_fs hrb.n2))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc l2s_s_11) (hrb.member_fa l2s_s_11))))
(assert
 (not (and (hrb.member_fc hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (not (and (hrb.member_fc l2s_s_12) (hrb.member_fa l2s_s_12))))
(assert
 (not (and (hrb.member_fc hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc l2s_s_11) (hrb.member_fs l2s_s_11))))
(assert
 (not (and (hrb.member_fc hrb.n1) (hrb.member_fs hrb.n1))))
(assert
 (not (and (hrb.member_fc l2s_s_12) (hrb.member_fs l2s_s_12))))
(assert
 (not (and (hrb.member_fc hrb.n2) (hrb.member_fs hrb.n2))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc l2s_s_11) (hrb.member_fi l2s_s_11))))
(assert
 (not (and (hrb.member_fc hrb.n1) (hrb.member_fi hrb.n1))))
(assert
 (not (and (hrb.member_fc l2s_s_12) (hrb.member_fi l2s_s_12))))
(assert
 (not (and (hrb.member_fc hrb.n2) (hrb.member_fi hrb.n2))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not (__l2s_w_3 hrb.n2))))))
(assert
 (let (($x242 (not __ts0_c)))
 (or $x242 (or (not __ts0_a) (not (__l2s_w_2 hrb.n1))))))
(check-sat)
