(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun _old_l2s_g_3 () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun ___old_l2s_g_3 () Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun new__old_l2s_g_0_a (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __m_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __m__old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun ___old_l2s_g_2 (hrb.node hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 __l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (let (($x233 (not __ts0_a)))
 (or $x233 (=> _old_l2s_g_3 l2s_g_3))))
(assert
 (or __ts0_a (= l2s_g_3 __l2s_g_3)))
(assert
 (= _old_l2s_g_3 (ite __ts0_a __l2s_g_3 ___old_l2s_g_3)))
(assert
 (let (($x411 (l2s_g_2 @N @M)))
 (let (($x412 (not $x411)))
 (let (($x408 (hrb.rcv_init @N)))
 (let (($x407 (hrb.correct @N)))
 (let (($x409 (and $x407 $x408)))
 (and (not (=> $x409 $x412)))))))))
(assert
 (or __ts0_a_a (= (l2s_g_2 @N @M) (__l2s_g_2 @N @M))))
(assert
 (let (($x249 (not __ts0_a_a)))
 (or $x249 (=> (l2s_g_2 @N @M) (not (hrb.sent_msg @N @M))))))
(assert
 (let (($x445 (l2s_g_1 @N @M)))
 (let (($x446 (not $x445)))
 (let (($x441 (l2s_g_0 @N @M)))
 (let (($x249 (not __ts0_a_a)))
 (or $x249 (=> (and $x441 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x446)))))))
(assert
 (let (($x411 (l2s_g_2 @N @M)))
 (let (($x412 (not $x411)))
 (let (($x454 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x412)))
 (let (($x249 (not __ts0_a_a)))
 (or $x249 $x454))))))
(assert
 (let (($x249 (not __ts0_a_a)))
 (or $x249 (=> (_old_l2s_g_2 @N @M) (l2s_g_2 @N @M)))))
(assert
 (let (($x445 (l2s_g_1 @N @M)))
 (let (($x446 (not $x445)))
 (let (($x442 (hrb.correct @M)))
 (let (($x451 (__hrb.sent_msg @N @M)))
 (let (($x460 (and $x451 $x442)))
 (let (($x461 (=> $x460 $x446)))
 (let (($x464 (=> (and (not (new__old_l2s_g_0_a @N @M)) $x461) (not (l2s_g_0 @N @M)))))
 (let (($x249 (not __ts0_a_a)))
 (or $x249 $x464))))))))))
(assert
 (let (($x249 (not __ts0_a_a)))
 (or $x249 (=> (new__old_l2s_g_0_a @N @M) (l2s_g_0 @N @M)))))
(assert
 (let (($x445 (l2s_g_1 @N @M)))
 (=> $x445 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x445 (l2s_g_1 @N @M)))
 (let (($x446 (not $x445)))
 (let (($x442 (hrb.correct @M)))
 (let (($x451 (__hrb.sent_msg @N @M)))
 (let (($x460 (and $x451 $x442)))
 (let (($x471 (__m_l2s_g_0 @N @M)))
 (=> (and $x471 $x460) $x446))))))))
(assert
 (let (($x445 (l2s_g_1 @N @M)))
 (let (($x446 (not $x445)))
 (=> (and (not (_old_l2s_g_1 @N @M)) (not (__hrb.rcv_msg @N @M))) $x446))))
(assert
 (let (($x445 (l2s_g_1 @N @M)))
 (let (($x474 (_old_l2s_g_1 @N @M)))
 (=> $x474 $x445))))
(assert
 (let (($x445 (l2s_g_1 @N @M)))
 (let (($x446 (not $x445)))
 (let (($x442 (hrb.correct @M)))
 (let (($x451 (__hrb.sent_msg @N @M)))
 (let (($x460 (and $x451 $x442)))
 (let (($x461 (=> $x460 $x446)))
 (=> (and (not (__m__old_l2s_g_0 @N @M)) $x461) (not (__m_l2s_g_0 @N @M))))))))))
(assert
 (let (($x471 (__m_l2s_g_0 @N @M)))
 (let (($x481 (__m__old_l2s_g_0 @N @M)))
 (=> $x481 $x471))))
(assert
 (not (and (__hrb.rcv_msg @N @M) (__l2s_w_0 @N @M))))
(assert
 (let (($x490 (__l2s_w_1 |__fml:s| |__fml:n|)))
 (let (($x202 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (not (and $x202 $x490)))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x451 (__hrb.sent_msg @N @M)))
 (let (($x452 (not $x451)))
 (let (($x434 (__l2s_g_2 @N @M)))
 (=> $x434 $x452)))))
(assert
 (let (($x476 (__hrb.rcv_msg @N @M)))
 (let (($x477 (not $x476)))
 (let (($x497 (__l2s_g_1 @N @M)))
 (=> $x497 $x477)))))
(assert
 (let (($x442 (hrb.correct @M)))
 (let (($x451 (__hrb.sent_msg @N @M)))
 (let (($x460 (and $x451 $x442)))
 (let (($x499 (__l2s_g_0 @N @M)))
 (=> (and $x499 $x460) (not (__l2s_g_1 @N @M))))))))
(assert
 (let (($x511 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x511))))
(assert
 (let (($x519 (hrb.member_fa @N)))
 (let (($x520 (not $x519)))
 (let (($x515 (hrb.member_fi @N)))
 (let (($x516 (not $x515)))
 (let (($x407 (hrb.correct @N)))
 (= $x407 (and (not (hrb.member_fc @N)) $x516 (not (hrb.member_fs @N)) $x520))))))))
(assert
 (let (($x529 (hrb.member_fa @M)))
 (let (($x530 (not $x529)))
 (let (($x527 (hrb.member_fs @M)))
 (let (($x528 (not $x527)))
 (let (($x442 (hrb.correct @M)))
 (= $x442 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x528 $x530))))))))
(assert
 (let (($x202 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x202)))
(assert
 (let (($x451 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x451)))
(assert
 (let (($x451 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (__hrb.rcv_msg @N @M)) $x451)))
(assert
 (let (($x534 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x202 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x202 $x534))))
(assert
 (let (($x538 (__hrb.sent_msg_proj @N)))
 (let (($x451 (__hrb.sent_msg @N @M)))
 (=> $x451 $x538))))
(assert
 (let (($x476 (__hrb.rcv_msg @N @M)))
 (let (($x546 (l2s_s_1 @N @M)))
 (let (($x442 (hrb.correct @M)))
 (=> (and l2s_saved $x442 $x546 (not (__l2s_w_0 @N @M))) $x476)))))
(assert
 (let (($x202 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x551 (hrb.rcv_init |__fml:s|)))
 (let (($x550 (hrb.correct |__fml:s|)))
 (=> (and l2s_saved $x550 $x551 (not (__l2s_w_1 |__fml:s| |__fml:n|))) $x202)))))
(assert
 (let (($x451 (__hrb.sent_msg @N @M)))
 (let (($x408 (hrb.rcv_init @N)))
 (let (($x407 (hrb.correct @N)))
 (=> (and l2s_saved $x407 $x408 (not (__l2s_w_1 @N @M))) $x451)))))
(assert
 (let (($x558 (hrb.rcv_init @M)))
 (let (($x541 (hrb.obedient @M)))
 (=> $x541 $x558))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x408 (hrb.rcv_init @N)))
 (let (($x407 (hrb.correct @N)))
 (let (($x409 (and $x407 $x408)))
 (=> $x409 (not (__l2s_g_2 @N @M)))))))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @M) (hrb.obedient @M))) (__hrb.accept @M)))
(assert
 (let (($x476 (__hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x476)))
(assert
 (let (($x534 (__hrb.sent_msg_proj |__fml:s|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:s|)) $x534)))
(assert
 (let (($x538 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x538)))
(assert
 (let (($x451 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x451)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:s|) (hrb.rcv_init |__fml:s|))))
(assert
 (=> l2s_saved (= (l2s_s_9 @M) (hrb.rcv_init @M))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x451 (__hrb.sent_msg @N @M)))
 (let (($x437 (hrb.sent_msg @N @M)))
 (= $x437 (ite __ts0_a_a (ite (and (= @N |__fml:n|)) true $x451) $x451)))))
(assert
 (let (($x449 (_old_l2s_g_2 @N @M)))
 (= $x449 (ite __ts0_a_a (__l2s_g_2 @N @M) (___old_l2s_g_2 @N @M)))))
(assert
 (let (($x458 (new__old_l2s_g_0_a @N @M)))
 (= $x458 (ite __ts0_a_a (__m_l2s_g_0 @N @M) (__m__old_l2s_g_0 @N @M)))))
(assert
 (let (($x476 (__hrb.rcv_msg @N @M)))
 (let (($x468 (hrb.rcv_msg @N @M)))
 (= $x468 (ite (and (= @N |__fml:s|) (= @M |__fml:n|)) true $x476)))))
(assert
 (let (($x497 (__l2s_g_1 @N @M)))
 (let (($x474 (_old_l2s_g_1 @N @M)))
 (= $x474 $x497))))
(assert
 (let (($x499 (__l2s_g_0 @N @M)))
 (let (($x481 (__m__old_l2s_g_0 @N @M)))
 (= $x481 $x499))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (or __ts0_a_a (= (l2s_g_0 @N @M) (__m_l2s_g_0 @N @M))))
(assert
 (let (($x685 (hrb.member_fa |__fml:s|)))
 (let (($x686 (not $x685)))
 (let (($x681 (hrb.member_fi |__fml:s|)))
 (let (($x682 (not $x681)))
 (let (($x687 (and (not (hrb.member_fc |__fml:s|)) $x682 (not (hrb.member_fs |__fml:s|)) $x686)))
 (let (($x550 (hrb.correct |__fml:s|)))
 (= $x550 $x687))))))))
(assert
 (let (($x533 (hrb.symmetric |__fml:s|)))
 (= $x533 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x537 (hrb.symmetric @N)))
 (= $x537 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x541 (hrb.obedient @M)))
 (= $x541 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (not (and (hrb.member_fs |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fi |__fml:s|))))
(check-sat)
