(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(assert
 (hrb.member_fi |__fml:n|))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x196 (hrb.sent_msg |__fml:s| |__fml:n|)))
 (or __ts0_a_a (= $x196 $x74)))))
(assert
 (let (($x200 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x199 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x80 (not __ts0_a_a)))
 (or $x80 (=> $x199 $x200))))))
(assert
 (let (($x204 (= |__fml:s| |__fml:n|)))
 (let (($x196 (hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x80 (not __ts0_a_a)))
 (or $x80 (or $x196 (not (__hrb.sent_msg |__fml:s| |__fml:n|)) $x204))))))
(assert
 (let (($x208 (= |__fml:n| |__fml:n|)))
 (let (($x200 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x80 (not __ts0_a_a)))
 (or $x80 (or $x200 (not (__hrb.sent_msg |__fml:n| |__fml:n|)) $x208))))))
(assert
 (let (($x204 (= |__fml:s| |__fml:n|)))
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x80 (not __ts0_a_a)))
 (or $x80 (or (not (hrb.sent_msg |__fml:s| |__fml:n|)) $x74 $x204))))))
(assert
 (let (($x208 (= |__fml:n| |__fml:n|)))
 (let (($x199 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x80 (not __ts0_a_a)))
 (or $x80 (or (not (hrb.sent_msg |__fml:n| |__fml:n|)) $x199 $x208))))))
(assert
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x74)))
(assert
 (let (($x199 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:n|) (__hrb.sent_msg_proj |__fml:n|)) $x199)))
(assert
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:s| |__fml:n|)) $x74)))
(assert
 (let (($x199 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:n| |__fml:n|)) $x199)))
(assert
 (let (($x218 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x74 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x74 $x218))))
(assert
 (let (($x77 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x199 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> $x199 $x77))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (let (($x199 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x200 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (or __ts0_a_a (= $x200 $x199)))))
(assert
 (let (($x217 (hrb.symmetric |__fml:s|)))
 (= $x217 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x221 (hrb.symmetric |__fml:n|)))
 (= $x221 (and (not (hrb.member_fi |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (let (($x224 (hrb.obedient |__fml:n|)))
 (= $x224 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(check-sat)
