(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun pending_goal_function_2 (hrb.node) Bool)
(declare-fun _old_l2s_g_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_4 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not l2s_g_7))
(assert
 l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> l2s_g_5 $x138))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> __l2s_g_6 $x148))))
(assert
 (hrb.member_fs |__fml:n|))
(assert
 (=> _old_l2s_g_6 l2s_g_6))
(assert
 (=> (and (not _old_l2s_g_6) (not (__hrb.sent_msg_proj hrb.n2))) (not l2s_g_6)))
(assert
 (let (($x334 (not (hrb.sent_msg_proj hrb.n2))))
 (=> l2s_g_6 $x334)))
(assert
 (= _old_l2s_g_6 __l2s_g_6))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (let (($x423 (not $x422)))
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x418 (hrb.correct @N)))
 (let (($x420 (and $x418 $x419)))
 (and (not (=> $x420 $x423)))))))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x334 (not (hrb.sent_msg_proj hrb.n2))))
 (let (($x460 (pending_goal_function_2 hrb.n2)))
 (=> $x460 $x334))))
(assert
 (=> (and (not (_old_l2s_g_4 hrb.n2)) (not (__hrb.sent_msg_proj hrb.n2))) (not (pending_goal_function_2 hrb.n2))))
(assert
 (let (($x460 (pending_goal_function_2 hrb.n2)))
 (let (($x462 (_old_l2s_g_4 hrb.n2)))
 (=> $x462 $x460))))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (=> $x422 (not (hrb.sent_msg @N @M)))))
(assert
 (let (($x475 (l2s_g_1 @N @M)))
 (let (($x476 (not $x475)))
 (let (($x471 (l2s_g_0 @N @M)))
 (=> (and $x471 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x476)))))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (let (($x423 (not $x422)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x423))))
(assert
 (let (($x422 (l2s_g_2 @N @M)))
 (let (($x478 (_old_l2s_g_2 @N @M)))
 (=> $x478 $x422))))
(assert
 (let (($x475 (l2s_g_1 @N @M)))
 (let (($x476 (not $x475)))
 (let (($x472 (hrb.correct @M)))
 (let (($x480 (__hrb.sent_msg @N @M)))
 (let (($x487 (and $x480 $x472)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x487 $x476)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x471 (l2s_g_0 @N @M)))
 (let (($x485 (_old_l2s_g_0 @N @M)))
 (=> $x485 $x471))))
(assert
 (not (and (__hrb.sent_msg_proj hrb.n2) (__l2s_w_3 hrb.n2))))
(assert
 (not (and (hrb.accept hrb.n1) (pending_goal_function_1 hrb.n1))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x502 (__l2s_g_4 hrb.n2)))
 (=> $x502 $x148)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x504 (pending_goal_function_0 hrb.n1)))
 (=> $x504 $x138)))))
(assert
 (let (($x480 (__hrb.sent_msg @N @M)))
 (let (($x481 (not $x480)))
 (let (($x506 (__l2s_g_2 @N @M)))
 (=> $x506 $x481)))))
(assert
 (let (($x475 (l2s_g_1 @N @M)))
 (=> $x475 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x475 (l2s_g_1 @N @M)))
 (let (($x476 (not $x475)))
 (let (($x472 (hrb.correct @M)))
 (let (($x480 (__hrb.sent_msg @N @M)))
 (let (($x487 (and $x480 $x472)))
 (let (($x511 (__l2s_g_0 @N @M)))
 (=> (and $x511 $x487) $x476))))))))
(assert
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x514 (hrb.obedient @N)))
 (=> $x514 $x419))))
(assert
 (let (($x524 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x524))))
(assert
 (let (($x532 (hrb.member_fa @N)))
 (let (($x533 (not $x532)))
 (let (($x530 (hrb.member_fs @N)))
 (let (($x531 (not $x530)))
 (let (($x528 (hrb.member_fi @N)))
 (let (($x529 (not $x528)))
 (let (($x418 (hrb.correct @N)))
 (= $x418 (and (not (hrb.member_fc @N)) $x529 $x531 $x533))))))))))
(assert
 (let (($x542 (hrb.member_fa @M)))
 (let (($x543 (not $x542)))
 (let (($x540 (hrb.member_fs @M)))
 (let (($x541 (not $x540)))
 (let (($x472 (hrb.correct @M)))
 (= $x472 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x541 $x543))))))))
(assert
 (let (($x514 (hrb.obedient @N)))
 (= $x514 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x480 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x480)))
(assert
 (let (($x480 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x480)))
(assert
 (let (($x549 (__hrb.sent_msg_proj @N)))
 (let (($x480 (__hrb.sent_msg @N @M)))
 (=> $x480 $x549))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (__hrb.sent_msg_proj hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (let (($x561 (hrb.obedient hrb.n1)))
 (=> (and l2s_saved $x561 (not (pending_goal_function_1 hrb.n1))) (or (hrb.accept hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x508 (hrb.rcv_msg @N @M)))
 (let (($x566 (l2s_s_1 @N @M)))
 (let (($x472 (hrb.correct @M)))
 (=> (and l2s_saved $x472 $x566 (not (l2s_w_0 @N @M))) $x508)))))
(assert
 (let (($x480 (__hrb.sent_msg @N @M)))
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x418 (hrb.correct @N)))
 (=> (and l2s_saved $x418 $x419 (not (__l2s_w_1 @N @M))) $x480)))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x419 (hrb.rcv_init @N)))
 (let (($x418 (hrb.correct @N)))
 (let (($x420 (and $x418 $x419)))
 (=> $x420 (not (__l2s_g_2 @N @M)))))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x508 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x508)))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (let (($x549 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x549)))
(assert
 (let (($x480 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x480)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x502 (__l2s_g_4 hrb.n2)))
 (let (($x462 (_old_l2s_g_4 hrb.n2)))
 (= $x462 $x502))))
(assert
 (let (($x468 (hrb.sent_msg @N @M)))
 (= $x468 (ite (and (= @N |__fml:n|)) true (__hrb.sent_msg @N @M)))))
(assert
 (let (($x506 (__l2s_g_2 @N @M)))
 (let (($x478 (_old_l2s_g_2 @N @M)))
 (= $x478 $x506))))
(assert
 (let (($x511 (__l2s_g_0 @N @M)))
 (let (($x485 (_old_l2s_g_0 @N @M)))
 (= $x485 $x511))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x548 (hrb.symmetric @N)))
 (= $x548 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x552 (hrb.obedient @M)))
 (= $x552 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x556 (hrb.obedient hrb.n2)))
 (= $x556 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x561 (hrb.obedient hrb.n1)))
 (= $x561 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(check-sat)
