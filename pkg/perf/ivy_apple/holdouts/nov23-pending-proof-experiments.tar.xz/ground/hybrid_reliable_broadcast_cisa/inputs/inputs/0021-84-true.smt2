(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun __l2s_saved () Bool)
(declare-fun __l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun __l2s_w_2 () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __l2s_s_5 (hrb.node) Bool)
(declare-fun __l2s_s_8 (hrb.node) Bool)
(declare-fun __l2s_s_7 (hrb.node) Bool)
(declare-fun __l2s_s_6 (hrb.node) Bool)
(assert
 (or __l2s_waiting __l2s_frozen __l2s_saved))
(assert
 (let (($x9 (not __l2s_frozen)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x10 (not __l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not __l2s_saved)))
 (let (($x9 (not __l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (or __ts0_c __ts0_d))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or __ts0_a __ts0_b))))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or (not __ts0_a) __l2s_waiting))))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or (not __ts0_a) (not __l2s_w_2)))))
(assert
 (let (($x175 (not __ts0_c)))
 (or $x175 (or (not __ts0_b) __l2s_frozen))))
(assert
 (= l2s_waiting (ite __ts0_d __l2s_waiting (ite __ts0_b __l2s_waiting false))))
(assert
 (= l2s_frozen (ite __ts0_d __l2s_frozen (ite __ts0_b false true))))
(assert
 (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved))))
(assert
 (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n0 __l2s_s_11))))
(assert
 (and (not (=> l2s_saved (= l2s_s_11 hrb.n0)))))
(assert
 (let (($x413 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x413))))
(assert
 (=> __l2s_saved (= (__l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> __l2s_saved (= (__l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(check-sat)
