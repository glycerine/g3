(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun __l2s_g_7 () Bool)
(declare-fun __l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(declare-fun __l2s_g_5 () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun _old_l2s_g_5 () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun _old_l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun _old_l2s_g_9 () Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun __ts0_a_a () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun ___old_l2s_g_5 () Bool)
(declare-fun ___old_l2s_g_7 () Bool)
(declare-fun ___old_l2s_g_9 () Bool)
(declare-fun ___old_l2s_g_6 () Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun _old_l2s_g_4 (hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun new__old_l2s_g_0_a (hrb.node hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun _old_l2s_g_3 (hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __m_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __m__old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun __l2s_w_2 (hrb.node) Bool)
(declare-fun __l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_4 (hrb.node) Bool)
(declare-fun __l2s_g_3 (hrb.node) Bool)
(declare-fun __l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(declare-fun ___old_l2s_g_4 (hrb.node) Bool)
(declare-fun ___old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun ___old_l2s_g_3 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not __l2s_g_7))
(assert
 __l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> __l2s_g_5 $x138))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> __l2s_g_6 $x148))))
(assert
 (hrb.member_fi |__fml:n|))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> _old_l2s_g_5 l2s_g_5))))
(assert
 (let (($x334 (=> (and (not _old_l2s_g_5) (not (__hrb.accept hrb.n1))) (not l2s_g_5))))
 (let (($x315 (not __ts0_a)))
 (or $x315 $x334))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> _old_l2s_g_7 l2s_g_7))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> _old_l2s_g_9 l2s_g_9))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> l2s_g_5 (not (hrb.accept hrb.n1))))))
(assert
 (or __ts0_a (= l2s_g_5 __l2s_g_5)))
(assert
 (or __ts0_a (= l2s_g_7 __l2s_g_7)))
(assert
 (or __ts0_a (= l2s_g_9 __l2s_g_9)))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> _old_l2s_g_6 l2s_g_6))))
(assert
 (let (($x450 (=> (and (not _old_l2s_g_6) (not (__hrb.sent_msg_proj hrb.n2))) (not l2s_g_6))))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 $x450))))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> l2s_g_6 (not (hrb.sent_msg_proj hrb.n2))))))
(assert
 (or __ts0_a_a (= l2s_g_6 __l2s_g_6)))
(assert
 (= _old_l2s_g_5 (ite __ts0_a __l2s_g_5 ___old_l2s_g_5)))
(assert
 (= _old_l2s_g_7 (ite __ts0_a __l2s_g_7 ___old_l2s_g_7)))
(assert
 (= _old_l2s_g_9 (ite __ts0_a __l2s_g_9 ___old_l2s_g_9)))
(assert
 (= _old_l2s_g_6 (ite __ts0_a_a __l2s_g_6 ___old_l2s_g_6)))
(assert
 (let (($x619 (l2s_g_2 @N @M)))
 (let (($x620 (not $x619)))
 (let (($x616 (hrb.rcv_init @N)))
 (let (($x615 (hrb.correct @N)))
 (let (($x617 (and $x615 $x616)))
 (and (not (=> $x617 $x620)))))))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x359 (hrb.accept hrb.n1)))
 (= $x359 (ite __ts0_a (ite (and (= hrb.n1 |__fml:n|)) true $x137) $x137)))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x660 (hrb.sent_msg |__fml:s| |__fml:n|)))
 (or __ts0_a_a (= $x660 $x287)))))
(assert
 (or __ts0_a_a (= (l2s_g_2 @N @M) (__l2s_g_2 @N @M))))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> (pending_goal_function_1 hrb.n2) (not (hrb.sent_msg_proj hrb.n2))))))
(assert
 (let (($x673 (=> (and (not (_old_l2s_g_4 hrb.n2)) (not (__hrb.sent_msg_proj hrb.n2))) (not (pending_goal_function_1 hrb.n2)))))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 $x673))))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> (_old_l2s_g_4 hrb.n2) (pending_goal_function_1 hrb.n2)))))
(assert
 (let (($x678 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> $x677 $x678))))))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> (l2s_g_2 @N @M) (not (hrb.sent_msg @N @M))))))
(assert
 (let (($x689 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x690 (not $x689)))
 (let (($x685 (l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x688 (and $x685 (and (hrb.sent_msg |__fml:s| |__fml:n|) (hrb.correct |__fml:n|)))))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> $x688 $x690))))))))
(assert
 (let (($x696 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x697 (not $x696)))
 (let (($x693 (l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x695 (and $x693 (and (hrb.sent_msg |__fml:n| |__fml:n|) (hrb.correct |__fml:n|)))))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> $x695 $x697))))))))
(assert
 (let (($x704 (l2s_g_1 @N @M)))
 (let (($x705 (not $x704)))
 (let (($x700 (l2s_g_0 @N @M)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> (and $x700 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x705)))))))
(assert
 (let (($x709 (= |__fml:s| |__fml:n|)))
 (let (($x660 (hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or $x660 (not (__hrb.sent_msg |__fml:s| |__fml:n|)) $x709))))))
(assert
 (let (($x713 (= |__fml:n| |__fml:n|)))
 (let (($x678 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or $x678 (not (__hrb.sent_msg |__fml:n| |__fml:n|)) $x713))))))
(assert
 (let (($x709 (= |__fml:s| |__fml:n|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or (not (hrb.sent_msg |__fml:s| |__fml:n|)) $x287 $x709))))))
(assert
 (let (($x713 (= |__fml:n| |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or (not (hrb.sent_msg |__fml:n| |__fml:n|)) $x677 $x713))))))
(assert
 (let (($x619 (l2s_g_2 @N @M)))
 (let (($x620 (not $x619)))
 (let (($x727 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x620)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 $x727))))))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> (_old_l2s_g_2 @N @M) (l2s_g_2 @N @M)))))
(assert
 (let (($x689 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x690 (not $x689)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x733 (and $x287 $x686)))
 (let (($x734 (=> $x733 $x690)))
 (let (($x737 (=> (and (not (new__old_l2s_g_0_a |__fml:s| |__fml:n|)) $x734) (not (l2s_g_0 |__fml:s| |__fml:n|)))))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 $x737))))))))))
(assert
 (let (($x696 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x697 (not $x696)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x741 (and $x677 $x686)))
 (let (($x742 (=> $x741 $x697)))
 (let (($x745 (=> (and (not (new__old_l2s_g_0_a |__fml:n| |__fml:n|)) $x742) (not (l2s_g_0 |__fml:n| |__fml:n|)))))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 $x745))))))))))
(assert
 (let (($x704 (l2s_g_1 @N @M)))
 (let (($x705 (not $x704)))
 (let (($x701 (hrb.correct @M)))
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x749 (and $x724 $x701)))
 (let (($x750 (=> $x749 $x705)))
 (let (($x753 (=> (and (not (new__old_l2s_g_0_a @N @M)) $x750) (not (l2s_g_0 @N @M)))))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 $x753))))))))))
(assert
 (let (($x685 (l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x731 (new__old_l2s_g_0_a |__fml:s| |__fml:n|)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> $x731 $x685))))))
(assert
 (let (($x693 (l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x739 (new__old_l2s_g_0_a |__fml:n| |__fml:n|)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> $x739 $x693))))))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> (new__old_l2s_g_0_a @N @M) (l2s_g_0 @N @M)))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> (pending_goal_function_0 hrb.n1) (not (hrb.accept hrb.n1))))))
(assert
 (let (($x768 (=> (and (not (_old_l2s_g_3 hrb.n1)) (not (__hrb.accept hrb.n1))) (not (pending_goal_function_0 hrb.n1)))))
 (let (($x315 (not __ts0_a)))
 (or $x315 $x768))))
(assert
 (let (($x315 (not __ts0_a)))
 (or $x315 (=> (_old_l2s_g_3 hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x689 (l2s_g_1 |__fml:s| |__fml:n|)))
 (=> $x689 (not (hrb.rcv_msg |__fml:s| |__fml:n|)))))
(assert
 (let (($x696 (l2s_g_1 |__fml:n| |__fml:n|)))
 (=> $x696 (not (hrb.rcv_msg |__fml:n| |__fml:n|)))))
(assert
 (let (($x704 (l2s_g_1 @N @M)))
 (=> $x704 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x689 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x690 (not $x689)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x733 (and $x287 $x686)))
 (let (($x781 (__m_l2s_g_0 |__fml:s| |__fml:n|)))
 (=> (and $x781 $x733) $x690))))))))
(assert
 (let (($x696 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x697 (not $x696)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x741 (and $x677 $x686)))
 (let (($x784 (__m_l2s_g_0 |__fml:n| |__fml:n|)))
 (=> (and $x784 $x741) $x697))))))))
(assert
 (let (($x704 (l2s_g_1 @N @M)))
 (let (($x705 (not $x704)))
 (let (($x701 (hrb.correct @M)))
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x749 (and $x724 $x701)))
 (let (($x787 (__m_l2s_g_0 @N @M)))
 (=> (and $x787 $x749) $x705))))))))
(assert
 (let (($x689 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x690 (not $x689)))
 (let (($x792 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x793 (not $x792)))
 (=> (and (not (_old_l2s_g_1 |__fml:s| |__fml:n|)) $x793) $x690))))))
(assert
 (let (($x696 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x697 (not $x696)))
 (let (($x798 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x799 (not $x798)))
 (=> (and (not (_old_l2s_g_1 |__fml:n| |__fml:n|)) $x799) $x697))))))
(assert
 (let (($x704 (l2s_g_1 @N @M)))
 (let (($x705 (not $x704)))
 (=> (and (not (_old_l2s_g_1 @N @M)) (not (__hrb.rcv_msg @N @M))) $x705))))
(assert
 (let (($x689 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x790 (_old_l2s_g_1 |__fml:s| |__fml:n|)))
 (=> $x790 $x689))))
(assert
 (let (($x696 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x796 (_old_l2s_g_1 |__fml:n| |__fml:n|)))
 (=> $x796 $x696))))
(assert
 (let (($x704 (l2s_g_1 @N @M)))
 (let (($x802 (_old_l2s_g_1 @N @M)))
 (=> $x802 $x704))))
(assert
 (let (($x689 (l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x690 (not $x689)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x733 (and $x287 $x686)))
 (let (($x734 (=> $x733 $x690)))
 (=> (and (not (__m__old_l2s_g_0 |__fml:s| |__fml:n|)) $x734) (not (__m_l2s_g_0 |__fml:s| |__fml:n|))))))))))
(assert
 (let (($x696 (l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x697 (not $x696)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x741 (and $x677 $x686)))
 (let (($x742 (=> $x741 $x697)))
 (=> (and (not (__m__old_l2s_g_0 |__fml:n| |__fml:n|)) $x742) (not (__m_l2s_g_0 |__fml:n| |__fml:n|))))))))))
(assert
 (let (($x704 (l2s_g_1 @N @M)))
 (let (($x705 (not $x704)))
 (let (($x701 (hrb.correct @M)))
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x749 (and $x724 $x701)))
 (let (($x750 (=> $x749 $x705)))
 (=> (and (not (__m__old_l2s_g_0 @N @M)) $x750) (not (__m_l2s_g_0 @N @M))))))))))
(assert
 (let (($x781 (__m_l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x811 (__m__old_l2s_g_0 |__fml:s| |__fml:n|)))
 (=> $x811 $x781))))
(assert
 (let (($x784 (__m_l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x816 (__m__old_l2s_g_0 |__fml:n| |__fml:n|)))
 (=> $x816 $x784))))
(assert
 (let (($x787 (__m_l2s_g_0 @N @M)))
 (let (($x821 (__m__old_l2s_g_0 @N @M)))
 (=> $x821 $x787))))
(assert
 (not (and (__hrb.sent_msg_proj hrb.n2) (__l2s_w_3 hrb.n2))))
(assert
 (not (and (__hrb.accept hrb.n1) (__l2s_w_2 hrb.n1))))
(assert
 (not (and (__hrb.rcv_msg |__fml:s| |__fml:n|) (__l2s_w_0 |__fml:s| |__fml:n|))))
(assert
 (not (and (__hrb.rcv_msg |__fml:n| |__fml:n|) (__l2s_w_0 |__fml:n| |__fml:n|))))
(assert
 (not (and (__hrb.rcv_msg @N @M) (__l2s_w_0 @N @M))))
(assert
 (let (($x844 (__l2s_w_1 |__fml:s| |__fml:n|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (not (and $x287 $x844)))))
(assert
 (let (($x847 (__l2s_w_1 |__fml:n| |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (not (and $x677 $x847)))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x853 (__l2s_g_4 hrb.n2)))
 (=> $x853 $x148)))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x855 (__l2s_g_3 hrb.n1)))
 (=> $x855 $x138)))))
(assert
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x725 (not $x724)))
 (let (($x663 (__l2s_g_2 @N @M)))
 (=> $x663 $x725)))))
(assert
 (let (($x792 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x793 (not $x792)))
 (let (($x858 (__l2s_g_1 |__fml:s| |__fml:n|)))
 (=> $x858 $x793)))))
(assert
 (let (($x798 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x799 (not $x798)))
 (let (($x860 (__l2s_g_1 |__fml:n| |__fml:n|)))
 (=> $x860 $x799)))))
(assert
 (let (($x804 (__hrb.rcv_msg @N @M)))
 (let (($x805 (not $x804)))
 (let (($x862 (__l2s_g_1 @N @M)))
 (=> $x862 $x805)))))
(assert
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x733 (and $x287 $x686)))
 (let (($x864 (__l2s_g_0 |__fml:s| |__fml:n|)))
 (=> (and $x864 $x733) (not (__l2s_g_1 |__fml:s| |__fml:n|))))))))
(assert
 (let (($x686 (hrb.correct |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x741 (and $x677 $x686)))
 (let (($x868 (__l2s_g_0 |__fml:n| |__fml:n|)))
 (=> (and $x868 $x741) (not (__l2s_g_1 |__fml:n| |__fml:n|))))))))
(assert
 (let (($x701 (hrb.correct @M)))
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x749 (and $x724 $x701)))
 (let (($x872 (__l2s_g_0 @N @M)))
 (=> (and $x872 $x749) (not (__l2s_g_1 @N @M))))))))
(assert
 (let (($x616 (hrb.rcv_init @N)))
 (let (($x876 (hrb.obedient @N)))
 (=> $x876 $x616))))
(assert
 (let (($x886 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x886))))
(assert
 (let (($x894 (hrb.member_fa @N)))
 (let (($x895 (not $x894)))
 (let (($x892 (hrb.member_fs @N)))
 (let (($x893 (not $x892)))
 (let (($x890 (hrb.member_fi @N)))
 (let (($x891 (not $x890)))
 (let (($x615 (hrb.correct @N)))
 (= $x615 (and (not (hrb.member_fc @N)) $x891 $x893 $x895))))))))))
(assert
 (let (($x647 (hrb.member_fa |__fml:n|)))
 (let (($x901 (not $x647)))
 (let (($x650 (hrb.member_fs |__fml:n|)))
 (let (($x900 (not $x650)))
 (let (($x285 (hrb.member_fi |__fml:n|)))
 (let (($x899 (not $x285)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (= $x686 (and (not (hrb.member_fc |__fml:n|)) $x899 $x900 $x901))))))))))
(assert
 (let (($x910 (hrb.member_fa @M)))
 (let (($x911 (not $x910)))
 (let (($x908 (hrb.member_fs @M)))
 (let (($x909 (not $x908)))
 (let (($x701 (hrb.correct @M)))
 (= $x701 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x909 $x911))))))))
(assert
 (let (($x876 (hrb.obedient @N)))
 (= $x876 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.symmetric |__fml:s|) (__hrb.sent_msg_proj |__fml:s|)) $x287)))
(assert
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x384 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x920 (hrb.symmetric |__fml:n|)))
 (let (($x921 (and $x920 $x384)))
 (=> $x921 $x677))))))
(assert
 (let (($x724 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x724)))
(assert
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:s| |__fml:n|)) $x287)))
(assert
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:n| |__fml:n|)) $x677)))
(assert
 (let (($x724 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (__hrb.rcv_msg @N @M)) $x724)))
(assert
 (let (($x917 (__hrb.sent_msg_proj |__fml:s|)))
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x287 $x917))))
(assert
 (let (($x384 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> $x677 $x384))))
(assert
 (let (($x924 (__hrb.sent_msg_proj @N)))
 (let (($x724 (__hrb.sent_msg @N @M)))
 (=> $x724 $x924))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (__hrb.sent_msg_proj hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n1) (not (__l2s_w_2 hrb.n1))) (or (__hrb.accept hrb.n1) (__l2s_g_3 hrb.n1))))
(assert
 (let (($x792 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x948 (l2s_s_1 |__fml:s| |__fml:n|)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (=> (and l2s_saved $x686 $x948 (not (__l2s_w_0 |__fml:s| |__fml:n|))) $x792)))))
(assert
 (let (($x798 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x952 (l2s_s_1 |__fml:n| |__fml:n|)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (=> (and l2s_saved $x686 $x952 (not (__l2s_w_0 |__fml:n| |__fml:n|))) $x798)))))
(assert
 (let (($x804 (__hrb.rcv_msg @N @M)))
 (let (($x956 (l2s_s_1 @N @M)))
 (let (($x701 (hrb.correct @M)))
 (=> (and l2s_saved $x701 $x956 (not (__l2s_w_0 @N @M))) $x804)))))
(assert
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (let (($x961 (hrb.rcv_init |__fml:s|)))
 (let (($x960 (hrb.correct |__fml:s|)))
 (=> (and l2s_saved $x960 $x961 (not (__l2s_w_1 |__fml:s| |__fml:n|))) $x287)))))
(assert
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x965 (hrb.rcv_init |__fml:n|)))
 (let (($x686 (hrb.correct |__fml:n|)))
 (=> (and l2s_saved $x686 $x965 (not (__l2s_w_1 |__fml:n| |__fml:n|))) $x677)))))
(assert
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x616 (hrb.rcv_init @N)))
 (let (($x615 (hrb.correct @N)))
 (=> (and l2s_saved $x615 $x616 (not (__l2s_w_1 @N @M))) $x724)))))
(assert
 (__l2s_g_0 |__fml:s| |__fml:n|))
(assert
 (__l2s_g_0 |__fml:n| |__fml:n|))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x616 (hrb.rcv_init @N)))
 (let (($x615 (hrb.correct @N)))
 (let (($x617 (and $x615 $x616)))
 (=> $x617 (not (__l2s_g_2 @N @M)))))))
(assert
 (let (($x137 (__hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x792 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x980 (and l2s_saved (and (l2s_s_0 |__fml:s| |__fml:n|) (hrb.obedient |__fml:n|)))))
 (=> $x980 $x792))))
(assert
 (let (($x798 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x984 (and l2s_saved (and (l2s_s_0 |__fml:n| |__fml:n|) (hrb.obedient |__fml:n|)))))
 (=> $x984 $x798))))
(assert
 (let (($x804 (__hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x804)))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (let (($x917 (__hrb.sent_msg_proj |__fml:s|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:s|)) $x917)))
(assert
 (let (($x384 (__hrb.sent_msg_proj |__fml:n|)))
 (=> (and l2s_saved (l2s_s_10 |__fml:n|)) $x384)))
(assert
 (let (($x924 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x924)))
(assert
 (let (($x287 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and l2s_saved (l2s_s_1 |__fml:s| |__fml:n|)) $x287)))
(assert
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (=> (and l2s_saved (l2s_s_1 |__fml:n| |__fml:n|)) $x677)))
(assert
 (let (($x724 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x724)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:s|) (hrb.rcv_init |__fml:s|))))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:n|) (hrb.rcv_init |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x669 (_old_l2s_g_4 hrb.n2)))
 (= $x669 (ite __ts0_a_a (__l2s_g_4 hrb.n2) (___old_l2s_g_4 hrb.n2)))))
(assert
 (let (($x722 (_old_l2s_g_2 @N @M)))
 (= $x722 (ite __ts0_a_a (__l2s_g_2 @N @M) (___old_l2s_g_2 @N @M)))))
(assert
 (let (($x811 (__m__old_l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x781 (__m_l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x731 (new__old_l2s_g_0_a |__fml:s| |__fml:n|)))
 (= $x731 (ite __ts0_a_a $x781 $x811))))))
(assert
 (let (($x816 (__m__old_l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x784 (__m_l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x739 (new__old_l2s_g_0_a |__fml:n| |__fml:n|)))
 (= $x739 (ite __ts0_a_a $x784 $x816))))))
(assert
 (let (($x747 (new__old_l2s_g_0_a @N @M)))
 (= $x747 (ite __ts0_a_a (__m_l2s_g_0 @N @M) (__m__old_l2s_g_0 @N @M)))))
(assert
 (let (($x764 (_old_l2s_g_3 hrb.n1)))
 (= $x764 (ite __ts0_a (__l2s_g_3 hrb.n1) (___old_l2s_g_3 hrb.n1)))))
(assert
 (let (($x792 (__hrb.rcv_msg |__fml:s| |__fml:n|)))
 (let (($x772 (hrb.rcv_msg |__fml:s| |__fml:n|)))
 (= $x772 (ite (and (= |__fml:s| |__fml:s|) (= |__fml:n| |__fml:n|)) true $x792)))))
(assert
 (let (($x798 (__hrb.rcv_msg |__fml:n| |__fml:n|)))
 (let (($x775 (hrb.rcv_msg |__fml:n| |__fml:n|)))
 (= $x775 (ite (and (= |__fml:n| |__fml:s|) (= |__fml:n| |__fml:n|)) true $x798)))))
(assert
 (let (($x804 (__hrb.rcv_msg @N @M)))
 (let (($x778 (hrb.rcv_msg @N @M)))
 (= $x778 (ite (and (= @N |__fml:s|) (= @M |__fml:n|)) true $x804)))))
(assert
 (let (($x858 (__l2s_g_1 |__fml:s| |__fml:n|)))
 (let (($x790 (_old_l2s_g_1 |__fml:s| |__fml:n|)))
 (= $x790 $x858))))
(assert
 (let (($x860 (__l2s_g_1 |__fml:n| |__fml:n|)))
 (let (($x796 (_old_l2s_g_1 |__fml:n| |__fml:n|)))
 (= $x796 $x860))))
(assert
 (let (($x862 (__l2s_g_1 @N @M)))
 (let (($x802 (_old_l2s_g_1 @N @M)))
 (= $x802 $x862))))
(assert
 (let (($x864 (__l2s_g_0 |__fml:s| |__fml:n|)))
 (let (($x811 (__m__old_l2s_g_0 |__fml:s| |__fml:n|)))
 (= $x811 $x864))))
(assert
 (let (($x868 (__l2s_g_0 |__fml:n| |__fml:n|)))
 (let (($x816 (__m__old_l2s_g_0 |__fml:n| |__fml:n|)))
 (= $x816 $x868))))
(assert
 (let (($x872 (__l2s_g_0 @N @M)))
 (let (($x821 (__m__old_l2s_g_0 @N @M)))
 (= $x821 $x872))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (or __ts0_a_a (= (pending_goal_function_1 hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (let (($x677 (__hrb.sent_msg |__fml:n| |__fml:n|)))
 (let (($x678 (hrb.sent_msg |__fml:n| |__fml:n|)))
 (or __ts0_a_a (= $x678 $x677)))))
(assert
 (or __ts0_a_a (= (hrb.sent_msg @N @M) (__hrb.sent_msg @N @M))))
(assert
 (or __ts0_a_a (= (l2s_g_0 |__fml:s| |__fml:n|) (__m_l2s_g_0 |__fml:s| |__fml:n|))))
(assert
 (or __ts0_a_a (= (l2s_g_0 |__fml:n| |__fml:n|) (__m_l2s_g_0 |__fml:n| |__fml:n|))))
(assert
 (or __ts0_a_a (= (l2s_g_0 @N @M) (__m_l2s_g_0 @N @M))))
(assert
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (=> (__hrb.sent_msg |__fml:n| @M) (hrb.sent_msg |__fml:n| @M)))))
(assert
 (let (($x1153 (= @N |__fml:n|)))
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x725 (not $x724)))
 (let (($x681 (hrb.sent_msg @N @M)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or $x681 $x725 $x1153))))))))
(assert
 (let (($x713 (= |__fml:n| |__fml:n|)))
 (let (($x1150 (hrb.sent_msg |__fml:n| @M)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or $x1150 (not (__hrb.sent_msg |__fml:n| @M)) $x713))))))
(assert
 (let (($x1153 (= @N |__fml:n|)))
 (let (($x724 (__hrb.sent_msg @N @M)))
 (let (($x681 (hrb.sent_msg @N @M)))
 (let (($x682 (not $x681)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or $x682 $x724 $x1153))))))))
(assert
 (let (($x713 (= |__fml:n| |__fml:n|)))
 (let (($x1149 (__hrb.sent_msg |__fml:n| @M)))
 (let (($x387 (not __ts0_a_a)))
 (or $x387 (or (not (hrb.sent_msg |__fml:n| @M)) $x1149 $x713))))))
(assert
 (or __ts0_a (= (pending_goal_function_0 hrb.n1) (__l2s_g_3 hrb.n1))))
(assert
 (let (($x961 (hrb.rcv_init |__fml:s|)))
 (let (($x1166 (hrb.obedient |__fml:s|)))
 (=> $x1166 $x961))))
(assert
 (let (($x965 (hrb.rcv_init |__fml:n|)))
 (let (($x927 (hrb.obedient |__fml:n|)))
 (=> $x927 $x965))))
(assert
 (let (($x1175 (hrb.member_fa |__fml:s|)))
 (let (($x1176 (not $x1175)))
 (let (($x1173 (hrb.member_fs |__fml:s|)))
 (let (($x1174 (not $x1173)))
 (let (($x1171 (hrb.member_fi |__fml:s|)))
 (let (($x1172 (not $x1171)))
 (let (($x960 (hrb.correct |__fml:s|)))
 (= $x960 (and (not (hrb.member_fc |__fml:s|)) $x1172 $x1174 $x1176))))))))))
(assert
 (let (($x916 (hrb.symmetric |__fml:s|)))
 (= $x916 (and (not (hrb.member_fi |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x920 (hrb.symmetric |__fml:n|)))
 (= $x920 (and (not (hrb.member_fi |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (let (($x923 (hrb.symmetric @N)))
 (= $x923 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x927 (hrb.obedient |__fml:n|)))
 (= $x927 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (let (($x932 (hrb.obedient @M)))
 (= $x932 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x938 (hrb.obedient hrb.n2)))
 (= $x938 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x943 (hrb.obedient hrb.n1)))
 (= $x943 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (let (($x1166 (hrb.obedient |__fml:s|)))
 (= $x1166 (and (not (hrb.member_fs |__fml:s|)) (not (hrb.member_fa |__fml:s|))))))
(assert
 (let (($x1149 (__hrb.sent_msg |__fml:n| @M)))
 (let (($x384 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x920 (hrb.symmetric |__fml:n|)))
 (let (($x921 (and $x920 $x384)))
 (=> $x921 $x1149))))))
(assert
 (let (($x384 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x1149 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x1149 $x384))))
(assert
 (not (and (hrb.member_fs |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fi |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fa |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fs |__fml:s|))))
(assert
 (not (and (hrb.member_fc |__fml:s|) (hrb.member_fi |__fml:s|))))
(assert
 (or __ts0_a_a (= (hrb.sent_msg |__fml:n| @M) (__hrb.sent_msg |__fml:n| @M))))
(check-sat)
