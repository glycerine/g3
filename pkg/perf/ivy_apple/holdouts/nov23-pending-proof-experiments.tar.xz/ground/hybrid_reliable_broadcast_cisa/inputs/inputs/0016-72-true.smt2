(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (hrb.rcv_init |__fml:n|))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (let (($x312 (not $x311)))
 (let (($x308 (hrb.rcv_init @N)))
 (let (($x307 (hrb.correct @N)))
 (let (($x309 (and $x307 $x308)))
 (and (not (=> $x309 $x312)))))))))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (=> $x311 (not (hrb.sent_msg @N @M)))))
(assert
 (let (($x341 (l2s_g_1 @N @M)))
 (let (($x342 (not $x341)))
 (let (($x337 (l2s_g_0 @N @M)))
 (=> (and $x337 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x342)))))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (let (($x312 (not $x311)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x312))))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (let (($x344 (_old_l2s_g_2 @N @M)))
 (=> $x344 $x311))))
(assert
 (let (($x341 (l2s_g_1 @N @M)))
 (let (($x342 (not $x341)))
 (let (($x338 (hrb.correct @M)))
 (let (($x346 (__hrb.sent_msg @N @M)))
 (let (($x353 (and $x346 $x338)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x353 $x342)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x337 (l2s_g_0 @N @M)))
 (let (($x351 (_old_l2s_g_0 @N @M)))
 (=> $x351 $x337))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x346 (__hrb.sent_msg @N @M)))
 (let (($x347 (not $x346)))
 (let (($x362 (__l2s_g_2 @N @M)))
 (=> $x362 $x347)))))
(assert
 (let (($x341 (l2s_g_1 @N @M)))
 (=> $x341 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x341 (l2s_g_1 @N @M)))
 (let (($x342 (not $x341)))
 (let (($x338 (hrb.correct @M)))
 (let (($x346 (__hrb.sent_msg @N @M)))
 (let (($x353 (and $x346 $x338)))
 (let (($x367 (__l2s_g_0 @N @M)))
 (=> (and $x367 $x353) $x342))))))))
(assert
 (let (($x378 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x378))))
(assert
 (let (($x386 (hrb.member_fa @N)))
 (let (($x387 (not $x386)))
 (let (($x382 (hrb.member_fi @N)))
 (let (($x383 (not $x382)))
 (let (($x307 (hrb.correct @N)))
 (= $x307 (and (not (hrb.member_fc @N)) $x383 (not (hrb.member_fs @N)) $x387))))))))
(assert
 (let (($x396 (hrb.member_fa @M)))
 (let (($x397 (not $x396)))
 (let (($x394 (hrb.member_fs @M)))
 (let (($x395 (not $x394)))
 (let (($x338 (hrb.correct @M)))
 (= $x338 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x395 $x397))))))))
(assert
 (let (($x346 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x346)))
(assert
 (let (($x346 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x346)))
(assert
 (let (($x401 (__hrb.sent_msg_proj @N)))
 (let (($x346 (__hrb.sent_msg @N @M)))
 (=> $x346 $x401))))
(assert
 (let (($x364 (hrb.rcv_msg @N @M)))
 (let (($x408 (l2s_s_1 @N @M)))
 (let (($x338 (hrb.correct @M)))
 (=> (and l2s_saved $x338 $x408 (not (l2s_w_0 @N @M))) $x364)))))
(assert
 (let (($x346 (__hrb.sent_msg @N @M)))
 (let (($x308 (hrb.rcv_init @N)))
 (let (($x307 (hrb.correct @N)))
 (=> (and l2s_saved $x307 $x308 (not (__l2s_w_1 @N @M))) $x346)))))
(assert
 (let (($x416 (hrb.rcv_init @M)))
 (let (($x404 (hrb.obedient @M)))
 (=> $x404 $x416))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x308 (hrb.rcv_init @N)))
 (let (($x307 (hrb.correct @N)))
 (let (($x309 (and $x307 $x308)))
 (=> $x309 (not (__l2s_g_2 @N @M)))))))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @M) (hrb.obedient @M))) (hrb.accept @M)))
(assert
 (let (($x364 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x364)))
(assert
 (let (($x401 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x401)))
(assert
 (let (($x346 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x346)))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:n|) (hrb.rcv_init |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_9 @M) (hrb.rcv_init @M))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x334 (hrb.sent_msg @N @M)))
 (= $x334 (ite (and (= @N |__fml:n|)) true (__hrb.sent_msg @N @M)))))
(assert
 (let (($x362 (__l2s_g_2 @N @M)))
 (let (($x344 (_old_l2s_g_2 @N @M)))
 (= $x344 $x362))))
(assert
 (let (($x367 (__l2s_g_0 @N @M)))
 (let (($x351 (_old_l2s_g_0 @N @M)))
 (= $x351 $x367))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x400 (hrb.symmetric @N)))
 (= $x400 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x404 (hrb.obedient @M)))
 (= $x404 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(check-sat)
