(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun pending_goal_function_2 (hrb.node) Bool)
(declare-fun _old_l2s_g_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_4 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not l2s_g_7))
(assert
 l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> l2s_g_5 $x138))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> __l2s_g_6 $x148))))
(assert
 (hrb.member_fa |__fml:n|))
(assert
 (=> _old_l2s_g_6 l2s_g_6))
(assert
 (=> (and (not _old_l2s_g_6) (not (__hrb.sent_msg_proj hrb.n2))) (not l2s_g_6)))
(assert
 (let (($x346 (not (hrb.sent_msg_proj hrb.n2))))
 (=> l2s_g_6 $x346)))
(assert
 (= _old_l2s_g_6 __l2s_g_6))
(assert
 (let (($x428 (l2s_g_2 @N @M)))
 (let (($x429 (not $x428)))
 (let (($x425 (hrb.rcv_init @N)))
 (let (($x424 (hrb.correct @N)))
 (let (($x426 (and $x424 $x425)))
 (and (not (=> $x426 $x429)))))))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x346 (not (hrb.sent_msg_proj hrb.n2))))
 (let (($x466 (pending_goal_function_2 hrb.n2)))
 (=> $x466 $x346))))
(assert
 (=> (and (not (_old_l2s_g_4 hrb.n2)) (not (__hrb.sent_msg_proj hrb.n2))) (not (pending_goal_function_2 hrb.n2))))
(assert
 (let (($x466 (pending_goal_function_2 hrb.n2)))
 (let (($x468 (_old_l2s_g_4 hrb.n2)))
 (=> $x468 $x466))))
(assert
 (let (($x474 (hrb.sent_msg @N @M)))
 (let (($x475 (not $x474)))
 (let (($x428 (l2s_g_2 @N @M)))
 (=> $x428 $x475)))))
(assert
 (let (($x481 (l2s_g_1 @N @M)))
 (let (($x482 (not $x481)))
 (let (($x477 (l2s_g_0 @N @M)))
 (=> (and $x477 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x482)))))
(assert
 (let (($x486 (= @N |__fml:n|)))
 (let (($x484 (__hrb.sent_msg @N @M)))
 (let (($x485 (not $x484)))
 (let (($x474 (hrb.sent_msg @N @M)))
 (or $x474 $x485 $x486))))))
(assert
 (let (($x486 (= @N |__fml:n|)))
 (let (($x484 (__hrb.sent_msg @N @M)))
 (let (($x474 (hrb.sent_msg @N @M)))
 (let (($x475 (not $x474)))
 (or $x475 $x484 $x486))))))
(assert
 (let (($x428 (l2s_g_2 @N @M)))
 (let (($x429 (not $x428)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x429))))
(assert
 (let (($x428 (l2s_g_2 @N @M)))
 (let (($x489 (_old_l2s_g_2 @N @M)))
 (=> $x489 $x428))))
(assert
 (let (($x481 (l2s_g_1 @N @M)))
 (let (($x482 (not $x481)))
 (let (($x478 (hrb.correct @M)))
 (let (($x484 (__hrb.sent_msg @N @M)))
 (let (($x496 (and $x484 $x478)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x496 $x482)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x477 (l2s_g_0 @N @M)))
 (let (($x494 (_old_l2s_g_0 @N @M)))
 (=> $x494 $x477))))
(assert
 (not (and (__hrb.sent_msg_proj hrb.n2) (__l2s_w_3 hrb.n2))))
(assert
 (not (and (hrb.accept hrb.n1) (pending_goal_function_1 hrb.n1))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x511 (__l2s_g_4 hrb.n2)))
 (=> $x511 $x148)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x513 (pending_goal_function_0 hrb.n1)))
 (=> $x513 $x138)))))
(assert
 (let (($x484 (__hrb.sent_msg @N @M)))
 (let (($x485 (not $x484)))
 (let (($x515 (__l2s_g_2 @N @M)))
 (=> $x515 $x485)))))
(assert
 (let (($x481 (l2s_g_1 @N @M)))
 (=> $x481 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x481 (l2s_g_1 @N @M)))
 (let (($x482 (not $x481)))
 (let (($x478 (hrb.correct @M)))
 (let (($x484 (__hrb.sent_msg @N @M)))
 (let (($x496 (and $x484 $x478)))
 (let (($x520 (__l2s_g_0 @N @M)))
 (=> (and $x520 $x496) $x482))))))))
(assert
 (let (($x425 (hrb.rcv_init @N)))
 (let (($x523 (hrb.obedient @N)))
 (=> $x523 $x425))))
(assert
 (let (($x533 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x533))))
(assert
 (let (($x541 (hrb.member_fa @N)))
 (let (($x542 (not $x541)))
 (let (($x539 (hrb.member_fs @N)))
 (let (($x540 (not $x539)))
 (let (($x537 (hrb.member_fi @N)))
 (let (($x538 (not $x537)))
 (let (($x424 (hrb.correct @N)))
 (= $x424 (and (not (hrb.member_fc @N)) $x538 $x540 $x542))))))))))
(assert
 (let (($x551 (hrb.member_fa @M)))
 (let (($x552 (not $x551)))
 (let (($x549 (hrb.member_fs @M)))
 (let (($x550 (not $x549)))
 (let (($x478 (hrb.correct @M)))
 (= $x478 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x550 $x552))))))))
(assert
 (let (($x523 (hrb.obedient @N)))
 (= $x523 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x484 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x484)))
(assert
 (let (($x484 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x484)))
(assert
 (let (($x558 (__hrb.sent_msg_proj @N)))
 (let (($x484 (__hrb.sent_msg @N @M)))
 (=> $x484 $x558))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (__hrb.sent_msg_proj hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (let (($x570 (hrb.obedient hrb.n1)))
 (=> (and l2s_saved $x570 (not (pending_goal_function_1 hrb.n1))) (or (hrb.accept hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x517 (hrb.rcv_msg @N @M)))
 (let (($x575 (l2s_s_1 @N @M)))
 (let (($x478 (hrb.correct @M)))
 (=> (and l2s_saved $x478 $x575 (not (l2s_w_0 @N @M))) $x517)))))
(assert
 (let (($x484 (__hrb.sent_msg @N @M)))
 (let (($x425 (hrb.rcv_init @N)))
 (let (($x424 (hrb.correct @N)))
 (=> (and l2s_saved $x424 $x425 (not (__l2s_w_1 @N @M))) $x484)))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x425 (hrb.rcv_init @N)))
 (let (($x424 (hrb.correct @N)))
 (let (($x426 (and $x424 $x425)))
 (=> $x426 (not (__l2s_g_2 @N @M)))))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x517 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x517)))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (let (($x558 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x558)))
(assert
 (let (($x484 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x484)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x511 (__l2s_g_4 hrb.n2)))
 (let (($x468 (_old_l2s_g_4 hrb.n2)))
 (= $x468 $x511))))
(assert
 (let (($x515 (__l2s_g_2 @N @M)))
 (let (($x489 (_old_l2s_g_2 @N @M)))
 (= $x489 $x515))))
(assert
 (let (($x520 (__l2s_g_0 @N @M)))
 (let (($x494 (_old_l2s_g_0 @N @M)))
 (= $x494 $x520))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (let (($x692 (hrb.sent_msg |__fml:n| @M)))
 (let (($x691 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x691 $x692))))
(assert
 (let (($x695 (= |__fml:n| |__fml:n|)))
 (let (($x692 (hrb.sent_msg |__fml:n| @M)))
 (or $x692 (not (__hrb.sent_msg |__fml:n| @M)) $x695))))
(assert
 (let (($x695 (= |__fml:n| |__fml:n|)))
 (let (($x691 (__hrb.sent_msg |__fml:n| @M)))
 (or (not (hrb.sent_msg |__fml:n| @M)) $x691 $x695))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x557 (hrb.symmetric @N)))
 (= $x557 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x561 (hrb.obedient @M)))
 (= $x561 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x565 (hrb.obedient hrb.n2)))
 (= $x565 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x570 (hrb.obedient hrb.n1)))
 (= $x570 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (let (($x691 (__hrb.sent_msg |__fml:n| @M)))
 (=> (and (hrb.symmetric |__fml:n|) (__hrb.sent_msg_proj |__fml:n|)) $x691)))
(assert
 (let (($x288 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x691 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x691 $x288))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (let (($x717 (hrb.symmetric |__fml:n|)))
 (= $x717 (and (not (hrb.member_fi |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(check-sat)
