(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (hrb.member_fa |__fml:n|))
(assert
 (let (($x317 (l2s_g_2 @N @M)))
 (let (($x318 (not $x317)))
 (let (($x314 (hrb.rcv_init @N)))
 (let (($x313 (hrb.correct @N)))
 (let (($x315 (and $x313 $x314)))
 (and (not (=> $x315 $x318)))))))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x355 (hrb.sent_msg @N @M)))
 (let (($x356 (not $x355)))
 (let (($x317 (l2s_g_2 @N @M)))
 (=> $x317 $x356)))))
(assert
 (let (($x362 (l2s_g_1 @N @M)))
 (let (($x363 (not $x362)))
 (let (($x358 (l2s_g_0 @N @M)))
 (=> (and $x358 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x363)))))
(assert
 (let (($x367 (= @N |__fml:n|)))
 (let (($x365 (__hrb.sent_msg @N @M)))
 (let (($x366 (not $x365)))
 (let (($x355 (hrb.sent_msg @N @M)))
 (or $x355 $x366 $x367))))))
(assert
 (let (($x367 (= @N |__fml:n|)))
 (let (($x365 (__hrb.sent_msg @N @M)))
 (let (($x355 (hrb.sent_msg @N @M)))
 (let (($x356 (not $x355)))
 (or $x356 $x365 $x367))))))
(assert
 (let (($x317 (l2s_g_2 @N @M)))
 (let (($x318 (not $x317)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x318))))
(assert
 (let (($x317 (l2s_g_2 @N @M)))
 (let (($x370 (_old_l2s_g_2 @N @M)))
 (=> $x370 $x317))))
(assert
 (let (($x362 (l2s_g_1 @N @M)))
 (let (($x363 (not $x362)))
 (let (($x359 (hrb.correct @M)))
 (let (($x365 (__hrb.sent_msg @N @M)))
 (let (($x377 (and $x365 $x359)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x377 $x363)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x358 (l2s_g_0 @N @M)))
 (let (($x375 (_old_l2s_g_0 @N @M)))
 (=> $x375 $x358))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x365 (__hrb.sent_msg @N @M)))
 (let (($x366 (not $x365)))
 (let (($x386 (__l2s_g_2 @N @M)))
 (=> $x386 $x366)))))
(assert
 (let (($x362 (l2s_g_1 @N @M)))
 (=> $x362 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x362 (l2s_g_1 @N @M)))
 (let (($x363 (not $x362)))
 (let (($x359 (hrb.correct @M)))
 (let (($x365 (__hrb.sent_msg @N @M)))
 (let (($x377 (and $x365 $x359)))
 (let (($x391 (__l2s_g_0 @N @M)))
 (=> (and $x391 $x377) $x363))))))))
(assert
 (let (($x402 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x402))))
(assert
 (let (($x410 (hrb.member_fa @N)))
 (let (($x411 (not $x410)))
 (let (($x408 (hrb.member_fs @N)))
 (let (($x409 (not $x408)))
 (let (($x406 (hrb.member_fi @N)))
 (let (($x407 (not $x406)))
 (let (($x313 (hrb.correct @N)))
 (= $x313 (and (not (hrb.member_fc @N)) $x407 $x409 $x411))))))))))
(assert
 (let (($x420 (hrb.member_fa @M)))
 (let (($x421 (not $x420)))
 (let (($x418 (hrb.member_fs @M)))
 (let (($x419 (not $x418)))
 (let (($x359 (hrb.correct @M)))
 (= $x359 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x419 $x421))))))))
(assert
 (let (($x365 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x365)))
(assert
 (let (($x365 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x365)))
(assert
 (let (($x425 (__hrb.sent_msg_proj @N)))
 (let (($x365 (__hrb.sent_msg @N @M)))
 (=> $x365 $x425))))
(assert
 (let (($x388 (hrb.rcv_msg @N @M)))
 (let (($x432 (l2s_s_1 @N @M)))
 (let (($x359 (hrb.correct @M)))
 (=> (and l2s_saved $x359 $x432 (not (l2s_w_0 @N @M))) $x388)))))
(assert
 (let (($x365 (__hrb.sent_msg @N @M)))
 (let (($x314 (hrb.rcv_init @N)))
 (let (($x313 (hrb.correct @N)))
 (=> (and l2s_saved $x313 $x314 (not (__l2s_w_1 @N @M))) $x365)))))
(assert
 (let (($x314 (hrb.rcv_init @N)))
 (let (($x440 (hrb.obedient @N)))
 (=> $x440 $x314))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x314 (hrb.rcv_init @N)))
 (let (($x313 (hrb.correct @N)))
 (let (($x315 (and $x313 $x314)))
 (=> $x315 (not (__l2s_g_2 @N @M)))))))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @M) (hrb.obedient @M))) (hrb.accept @M)))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @N) (hrb.obedient @N))) (hrb.accept @N)))
(assert
 (let (($x388 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x388)))
(assert
 (let (($x425 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x425)))
(assert
 (let (($x365 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x365)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x386 (__l2s_g_2 @N @M)))
 (let (($x370 (_old_l2s_g_2 @N @M)))
 (= $x370 $x386))))
(assert
 (let (($x391 (__l2s_g_0 @N @M)))
 (let (($x375 (_old_l2s_g_0 @N @M)))
 (= $x375 $x391))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (let (($x553 (hrb.sent_msg |__fml:n| @M)))
 (let (($x552 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x552 $x553))))
(assert
 (let (($x556 (= |__fml:n| |__fml:n|)))
 (let (($x553 (hrb.sent_msg |__fml:n| @M)))
 (or $x553 (not (__hrb.sent_msg |__fml:n| @M)) $x556))))
(assert
 (let (($x556 (= |__fml:n| |__fml:n|)))
 (let (($x552 (__hrb.sent_msg |__fml:n| @M)))
 (or (not (hrb.sent_msg |__fml:n| @M)) $x552 $x556))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x424 (hrb.symmetric @N)))
 (= $x424 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x428 (hrb.obedient @M)))
 (= $x428 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x440 (hrb.obedient @N)))
 (= $x440 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x552 (__hrb.sent_msg |__fml:n| @M)))
 (=> (and (hrb.symmetric |__fml:n|) (__hrb.sent_msg_proj |__fml:n|)) $x552)))
(assert
 (let (($x204 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x552 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x552 $x204))))
(assert
 (let (($x568 (hrb.symmetric |__fml:n|)))
 (= $x568 (and (not (hrb.member_fi |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(check-sat)
