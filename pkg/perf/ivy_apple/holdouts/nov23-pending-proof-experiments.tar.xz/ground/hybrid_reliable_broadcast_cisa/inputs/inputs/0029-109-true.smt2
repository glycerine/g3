(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun l2s_s_12 () hrb.node)
(declare-fun hrb.n0 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_7 () Bool)
(declare-fun l2s_g_9 () Bool)
(declare-fun l2s_g_8 () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun __l2s_g_6 () Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun _old_l2s_g_6 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun pending_goal_function_2 (hrb.node) Bool)
(declare-fun _old_l2s_g_4 (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_3 (hrb.node) Bool)
(declare-fun pending_goal_function_1 (hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_4 (hrb.node) Bool)
(declare-fun pending_goal_function_0 (hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n1)))
(assert
 (=> l2s_saved (= l2s_s_12 hrb.n2)))
(assert
 (not l2s_g_7))
(assert
 l2s_g_9)
(assert
 (not l2s_g_8))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (=> l2s_g_5 $x138))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (=> __l2s_g_6 $x148))))
(assert
 (hrb.member_fi |__fml:n|))
(assert
 (hrb.rcv_init |__fml:n|))
(assert
 (=> _old_l2s_g_6 l2s_g_6))
(assert
 (=> (and (not _old_l2s_g_6) (not (__hrb.sent_msg_proj hrb.n2))) (not l2s_g_6)))
(assert
 (let (($x347 (not (hrb.sent_msg_proj hrb.n2))))
 (=> l2s_g_6 $x347)))
(assert
 (= _old_l2s_g_6 __l2s_g_6))
(assert
 (let (($x429 (l2s_g_2 @N @M)))
 (let (($x430 (not $x429)))
 (let (($x426 (hrb.rcv_init @N)))
 (let (($x425 (hrb.correct @N)))
 (let (($x427 (and $x425 $x426)))
 (and (not (=> $x427 $x430)))))))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x347 (not (hrb.sent_msg_proj hrb.n2))))
 (let (($x465 (pending_goal_function_2 hrb.n2)))
 (=> $x465 $x347))))
(assert
 (=> (and (not (_old_l2s_g_4 hrb.n2)) (not (__hrb.sent_msg_proj hrb.n2))) (not (pending_goal_function_2 hrb.n2))))
(assert
 (let (($x465 (pending_goal_function_2 hrb.n2)))
 (let (($x467 (_old_l2s_g_4 hrb.n2)))
 (=> $x467 $x465))))
(assert
 (let (($x473 (hrb.sent_msg @N @M)))
 (let (($x474 (not $x473)))
 (let (($x429 (l2s_g_2 @N @M)))
 (=> $x429 $x474)))))
(assert
 (let (($x480 (l2s_g_1 @N @M)))
 (let (($x481 (not $x480)))
 (let (($x476 (l2s_g_0 @N @M)))
 (=> (and $x476 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x481)))))
(assert
 (let (($x485 (= @N |__fml:n|)))
 (let (($x483 (__hrb.sent_msg @N @M)))
 (let (($x484 (not $x483)))
 (let (($x473 (hrb.sent_msg @N @M)))
 (or $x473 $x484 $x485))))))
(assert
 (let (($x485 (= @N |__fml:n|)))
 (let (($x483 (__hrb.sent_msg @N @M)))
 (let (($x473 (hrb.sent_msg @N @M)))
 (let (($x474 (not $x473)))
 (or $x474 $x483 $x485))))))
(assert
 (let (($x429 (l2s_g_2 @N @M)))
 (let (($x430 (not $x429)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x430))))
(assert
 (let (($x429 (l2s_g_2 @N @M)))
 (let (($x488 (_old_l2s_g_2 @N @M)))
 (=> $x488 $x429))))
(assert
 (let (($x480 (l2s_g_1 @N @M)))
 (let (($x481 (not $x480)))
 (let (($x477 (hrb.correct @M)))
 (let (($x483 (__hrb.sent_msg @N @M)))
 (let (($x495 (and $x483 $x477)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x495 $x481)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x476 (l2s_g_0 @N @M)))
 (let (($x493 (_old_l2s_g_0 @N @M)))
 (=> $x493 $x476))))
(assert
 (not (and (__hrb.sent_msg_proj hrb.n2) (__l2s_w_3 hrb.n2))))
(assert
 (not (and (hrb.accept hrb.n1) (pending_goal_function_1 hrb.n1))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (let (($x148 (not $x147)))
 (let (($x510 (__l2s_g_4 hrb.n2)))
 (=> $x510 $x148)))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (let (($x138 (not $x137)))
 (let (($x512 (pending_goal_function_0 hrb.n1)))
 (=> $x512 $x138)))))
(assert
 (let (($x483 (__hrb.sent_msg @N @M)))
 (let (($x484 (not $x483)))
 (let (($x514 (__l2s_g_2 @N @M)))
 (=> $x514 $x484)))))
(assert
 (let (($x480 (l2s_g_1 @N @M)))
 (=> $x480 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x480 (l2s_g_1 @N @M)))
 (let (($x481 (not $x480)))
 (let (($x477 (hrb.correct @M)))
 (let (($x483 (__hrb.sent_msg @N @M)))
 (let (($x495 (and $x483 $x477)))
 (let (($x519 (__l2s_g_0 @N @M)))
 (=> (and $x519 $x495) $x481))))))))
(assert
 (let (($x286 (hrb.rcv_init |__fml:n|)))
 (let (($x522 (hrb.obedient |__fml:n|)))
 (=> $x522 $x286))))
(assert
 (let (($x426 (hrb.rcv_init @N)))
 (let (($x524 (hrb.obedient @N)))
 (=> $x524 $x426))))
(assert
 (let (($x534 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x233 (hrb.correct hrb.n0)))
 (= $x233 $x534))))
(assert
 (let (($x542 (hrb.member_fa @N)))
 (let (($x543 (not $x542)))
 (let (($x540 (hrb.member_fs @N)))
 (let (($x541 (not $x540)))
 (let (($x538 (hrb.member_fi @N)))
 (let (($x539 (not $x538)))
 (let (($x425 (hrb.correct @N)))
 (= $x425 (and (not (hrb.member_fc @N)) $x539 $x541 $x543))))))))))
(assert
 (let (($x552 (hrb.member_fa @M)))
 (let (($x553 (not $x552)))
 (let (($x550 (hrb.member_fs @M)))
 (let (($x551 (not $x550)))
 (let (($x477 (hrb.correct @M)))
 (= $x477 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x551 $x553))))))))
(assert
 (let (($x522 (hrb.obedient |__fml:n|)))
 (= $x522 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(assert
 (let (($x524 (hrb.obedient @N)))
 (= $x524 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x483 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x483)))
(assert
 (let (($x483 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x483)))
(assert
 (let (($x563 (__hrb.sent_msg_proj @N)))
 (let (($x483 (__hrb.sent_msg @N @M)))
 (=> $x483 $x563))))
(assert
 (=> (and l2s_saved (hrb.obedient hrb.n2) (not (__l2s_w_3 hrb.n2))) (or (__hrb.sent_msg_proj hrb.n2) (__l2s_g_4 hrb.n2))))
(assert
 (let (($x575 (hrb.obedient hrb.n1)))
 (=> (and l2s_saved $x575 (not (pending_goal_function_1 hrb.n1))) (or (hrb.accept hrb.n1) (pending_goal_function_0 hrb.n1)))))
(assert
 (let (($x516 (hrb.rcv_msg @N @M)))
 (let (($x580 (l2s_s_1 @N @M)))
 (let (($x477 (hrb.correct @M)))
 (=> (and l2s_saved $x477 $x580 (not (l2s_w_0 @N @M))) $x516)))))
(assert
 (let (($x483 (__hrb.sent_msg @N @M)))
 (let (($x426 (hrb.rcv_init @N)))
 (let (($x425 (hrb.correct @N)))
 (=> (and l2s_saved $x425 $x426 (not (__l2s_w_1 @N @M))) $x483)))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x426 (hrb.rcv_init @N)))
 (let (($x425 (hrb.correct @N)))
 (let (($x427 (and $x425 $x426)))
 (=> $x427 (not (__l2s_g_2 @N @M)))))))
(assert
 (let (($x137 (hrb.accept hrb.n1)))
 (=> (and l2s_saved (and (l2s_s_4 hrb.n1) (hrb.obedient hrb.n1))) $x137)))
(assert
 (let (($x516 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x516)))
(assert
 (let (($x147 (__hrb.sent_msg_proj hrb.n2)))
 (=> (and l2s_saved (l2s_s_10 hrb.n2)) $x147)))
(assert
 (let (($x563 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x563)))
(assert
 (let (($x483 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x483)))
(assert
 (=> l2s_saved (= (l2s_s_9 |__fml:n|) (hrb.rcv_init |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x510 (__l2s_g_4 hrb.n2)))
 (let (($x467 (_old_l2s_g_4 hrb.n2)))
 (= $x467 $x510))))
(assert
 (let (($x514 (__l2s_g_2 @N @M)))
 (let (($x488 (_old_l2s_g_2 @N @M)))
 (= $x488 $x514))))
(assert
 (let (($x519 (__l2s_g_0 @N @M)))
 (let (($x493 (_old_l2s_g_0 @N @M)))
 (= $x493 $x519))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (let (($x702 (hrb.sent_msg |__fml:n| @M)))
 (let (($x701 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x701 $x702))))
(assert
 (let (($x705 (= |__fml:n| |__fml:n|)))
 (let (($x702 (hrb.sent_msg |__fml:n| @M)))
 (or $x702 (not (__hrb.sent_msg |__fml:n| @M)) $x705))))
(assert
 (let (($x705 (= |__fml:n| |__fml:n|)))
 (let (($x701 (__hrb.sent_msg |__fml:n| @M)))
 (or (not (hrb.sent_msg |__fml:n| @M)) $x701 $x705))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x562 (hrb.symmetric @N)))
 (= $x562 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x566 (hrb.obedient @M)))
 (= $x566 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x570 (hrb.obedient hrb.n2)))
 (= $x570 (and (not (hrb.member_fs hrb.n2)) (not (hrb.member_fa hrb.n2))))))
(assert
 (let (($x575 (hrb.obedient hrb.n1)))
 (= $x575 (and (not (hrb.member_fs hrb.n1)) (not (hrb.member_fa hrb.n1))))))
(assert
 (let (($x701 (__hrb.sent_msg |__fml:n| @M)))
 (=> (and (hrb.symmetric |__fml:n|) (__hrb.sent_msg_proj |__fml:n|)) $x701)))
(assert
 (let (($x289 (__hrb.sent_msg_proj |__fml:n|)))
 (let (($x701 (__hrb.sent_msg |__fml:n| @M)))
 (=> $x701 $x289))))
(assert
 (not (and (hrb.member_fs hrb.n2) (hrb.member_fa hrb.n2))))
(assert
 (not (and (hrb.member_fs hrb.n1) (hrb.member_fa hrb.n1))))
(assert
 (let (($x727 (hrb.symmetric |__fml:n|)))
 (= $x727 (and (not (hrb.member_fi |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(check-sat)
