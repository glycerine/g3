(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun |__fml:n| () hrb.node)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(assert
 (hrb.rcv_init |__fml:n|))
(check-sat)
