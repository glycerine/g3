(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun |__fml:n| () hrb.node)
(declare-fun @M () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_g_3 () Bool)
(declare-fun l2s_g_4 () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_init (hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_w_1 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun hrb.symmetric (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_w_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_s_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_s_10 (hrb.node) Bool)
(declare-fun l2s_s_9 (hrb.node) Bool)
(declare-fun l2s_s_5 (hrb.node) Bool)
(declare-fun l2s_s_8 (hrb.node) Bool)
(declare-fun l2s_s_7 (hrb.node) Bool)
(declare-fun l2s_s_6 (hrb.node) Bool)
(assert
 (or l2s_waiting l2s_frozen l2s_saved))
(assert
 (let (($x9 (not l2s_frozen)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x9))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x10 (not l2s_waiting)))
 (or $x10 $x12))))
(assert
 (let (($x12 (not l2s_saved)))
 (let (($x9 (not l2s_frozen)))
 (or $x9 $x12))))
(assert
 (=> l2s_saved (= l2s_s_11 hrb.n0)))
(assert
 l2s_g_3)
(assert
 (not l2s_g_4))
(assert
 (hrb.correct hrb.n0))
(assert
 (hrb.member_fs |__fml:n|))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (let (($x312 (not $x311)))
 (let (($x308 (hrb.rcv_init @N)))
 (let (($x307 (hrb.correct @N)))
 (let (($x309 (and $x307 $x308)))
 (and (not (=> $x309 $x312)))))))))
(assert
 (not (and (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fi |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (=> $x311 (not (hrb.sent_msg @N @M)))))
(assert
 (let (($x356 (l2s_g_1 @N @M)))
 (let (($x357 (not $x356)))
 (let (($x352 (l2s_g_0 @N @M)))
 (=> (and $x352 (and (hrb.sent_msg @N @M) (hrb.correct @M))) $x357)))))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (let (($x312 (not $x311)))
 (=> (and (not (_old_l2s_g_2 @N @M)) (not (__hrb.sent_msg @N @M))) $x312))))
(assert
 (let (($x311 (l2s_g_2 @N @M)))
 (let (($x359 (_old_l2s_g_2 @N @M)))
 (=> $x359 $x311))))
(assert
 (let (($x356 (l2s_g_1 @N @M)))
 (let (($x357 (not $x356)))
 (let (($x353 (hrb.correct @M)))
 (let (($x361 (__hrb.sent_msg @N @M)))
 (let (($x368 (and $x361 $x353)))
 (=> (and (not (_old_l2s_g_0 @N @M)) (=> $x368 $x357)) (not (l2s_g_0 @N @M)))))))))
(assert
 (let (($x352 (l2s_g_0 @N @M)))
 (let (($x366 (_old_l2s_g_0 @N @M)))
 (=> $x366 $x352))))
(assert
 (not (and (__hrb.sent_msg @N @M) (__l2s_w_1 @N @M))))
(assert
 (let (($x361 (__hrb.sent_msg @N @M)))
 (let (($x362 (not $x361)))
 (let (($x377 (__l2s_g_2 @N @M)))
 (=> $x377 $x362)))))
(assert
 (let (($x356 (l2s_g_1 @N @M)))
 (=> $x356 (not (hrb.rcv_msg @N @M)))))
(assert
 (let (($x356 (l2s_g_1 @N @M)))
 (let (($x357 (not $x356)))
 (let (($x353 (hrb.correct @M)))
 (let (($x361 (__hrb.sent_msg @N @M)))
 (let (($x368 (and $x361 $x353)))
 (let (($x382 (__l2s_g_0 @N @M)))
 (=> (and $x382 $x368) $x357))))))))
(assert
 (let (($x393 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x117 (hrb.correct hrb.n0)))
 (= $x117 $x393))))
(assert
 (let (($x401 (hrb.member_fa @N)))
 (let (($x402 (not $x401)))
 (let (($x399 (hrb.member_fs @N)))
 (let (($x400 (not $x399)))
 (let (($x397 (hrb.member_fi @N)))
 (let (($x398 (not $x397)))
 (let (($x307 (hrb.correct @N)))
 (= $x307 (and (not (hrb.member_fc @N)) $x398 $x400 $x402))))))))))
(assert
 (let (($x411 (hrb.member_fa @M)))
 (let (($x412 (not $x411)))
 (let (($x409 (hrb.member_fs @M)))
 (let (($x410 (not $x409)))
 (let (($x353 (hrb.correct @M)))
 (= $x353 (and (not (hrb.member_fc @M)) (not (hrb.member_fi @M)) $x410 $x412))))))))
(assert
 (let (($x361 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.symmetric @N) (__hrb.sent_msg_proj @N)) $x361)))
(assert
 (let (($x361 (__hrb.sent_msg @N @M)))
 (=> (and (hrb.obedient @M) (hrb.rcv_msg @N @M)) $x361)))
(assert
 (let (($x416 (__hrb.sent_msg_proj @N)))
 (let (($x361 (__hrb.sent_msg @N @M)))
 (=> $x361 $x416))))
(assert
 (let (($x379 (hrb.rcv_msg @N @M)))
 (let (($x423 (l2s_s_1 @N @M)))
 (let (($x353 (hrb.correct @M)))
 (=> (and l2s_saved $x353 $x423 (not (l2s_w_0 @N @M))) $x379)))))
(assert
 (let (($x361 (__hrb.sent_msg @N @M)))
 (let (($x308 (hrb.rcv_init @N)))
 (let (($x307 (hrb.correct @N)))
 (=> (and l2s_saved $x307 $x308 (not (__l2s_w_1 @N @M))) $x361)))))
(assert
 (let (($x308 (hrb.rcv_init @N)))
 (let (($x431 (hrb.obedient @N)))
 (=> $x431 $x308))))
(assert
 (__l2s_g_0 @N @M))
(assert
 (let (($x308 (hrb.rcv_init @N)))
 (let (($x307 (hrb.correct @N)))
 (let (($x309 (and $x307 $x308)))
 (=> $x309 (not (__l2s_g_2 @N @M)))))))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @M) (hrb.obedient @M))) (hrb.accept @M)))
(assert
 (=> (and l2s_saved (and (l2s_s_4 @N) (hrb.obedient @N))) (hrb.accept @N)))
(assert
 (let (($x379 (hrb.rcv_msg @N @M)))
 (=> (and l2s_saved (and (l2s_s_0 @N @M) (hrb.obedient @M))) $x379)))
(assert
 (let (($x416 (__hrb.sent_msg_proj @N)))
 (=> (and l2s_saved (l2s_s_10 @N)) $x416)))
(assert
 (let (($x361 (__hrb.sent_msg @N @M)))
 (=> (and l2s_saved (l2s_s_1 @N @M)) $x361)))
(assert
 (=> l2s_saved (= (l2s_s_9 @N) (hrb.rcv_init @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_5 hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_5 @N) (hrb.member_fa @N))))
(assert
 (=> l2s_saved (= (l2s_s_5 @M) (hrb.member_fa @M))))
(assert
 (=> l2s_saved (= (l2s_s_8 |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_8 hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_8 @N) (hrb.member_fs @N))))
(assert
 (=> l2s_saved (= (l2s_s_8 @M) (hrb.member_fs @M))))
(assert
 (=> l2s_saved (= (l2s_s_7 |__fml:n|) (hrb.member_fi |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_7 hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_7 @N) (hrb.member_fi @N))))
(assert
 (=> l2s_saved (= (l2s_s_7 @M) (hrb.member_fi @M))))
(assert
 (=> l2s_saved (= (l2s_s_6 |__fml:n|) (hrb.member_fc |__fml:n|))))
(assert
 (=> l2s_saved (= (l2s_s_6 hrb.n0) (hrb.member_fc hrb.n0))))
(assert
 (=> l2s_saved (= (l2s_s_6 @N) (hrb.member_fc @N))))
(assert
 (=> l2s_saved (= (l2s_s_6 @M) (hrb.member_fc @M))))
(assert
 (let (($x349 (hrb.sent_msg @N @M)))
 (= $x349 (ite (and (= @N |__fml:n|)) true (__hrb.sent_msg @N @M)))))
(assert
 (let (($x377 (__l2s_g_2 @N @M)))
 (let (($x359 (_old_l2s_g_2 @N @M)))
 (= $x359 $x377))))
(assert
 (let (($x382 (__l2s_g_0 @N @M)))
 (let (($x366 (_old_l2s_g_0 @N @M)))
 (= $x366 $x382))))
(assert
 (not (and (hrb.member_fs hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fs @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fs @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fi hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fi @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fi @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fa hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fa @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fa @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fs hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fs @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fs @M))))
(assert
 (not (and (hrb.member_fc hrb.n0) (hrb.member_fi hrb.n0))))
(assert
 (not (and (hrb.member_fc @N) (hrb.member_fi @N))))
(assert
 (not (and (hrb.member_fc @M) (hrb.member_fi @M))))
(assert
 (not (and (hrb.rcv_msg @N @M) (l2s_w_0 @N @M))))
(assert
 (let (($x415 (hrb.symmetric @N)))
 (= $x415 (and (not (hrb.member_fi @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x419 (hrb.obedient @M)))
 (= $x419 (and (not (hrb.member_fs @M)) (not (hrb.member_fa @M))))))
(assert
 (let (($x431 (hrb.obedient @N)))
 (= $x431 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(check-sat)
