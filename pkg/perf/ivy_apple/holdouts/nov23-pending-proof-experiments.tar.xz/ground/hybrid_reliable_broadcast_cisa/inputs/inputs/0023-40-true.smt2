(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun hrb.n2 () hrb.node)
(declare-fun @N2 () hrb.node)
(declare-fun @N1 () hrb.node)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun l2s_g_5 () Bool)
(declare-fun hrb.sent_msg_proj (hrb.node) Bool)
(declare-fun l2s_g_6 () Bool)
(declare-fun l2s_waiting () Bool)
(declare-fun l2s_frozen () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun l2s_g_4 (hrb.node) Bool)
(declare-fun l2s_g_3 (hrb.node) Bool)
(declare-fun l2s_g_1 (hrb.node hrb.node) Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun l2s_g_2 (hrb.node hrb.node) Bool)
(declare-fun hrb.rcv_msg (hrb.node hrb.node) Bool)
(assert
 (let (($x37 (not (hrb.accept hrb.n1))))
 (=> l2s_g_5 $x37)))
(assert
 (let (($x42 (not (hrb.sent_msg_proj hrb.n2))))
 (=> l2s_g_6 $x42)))
(assert
 l2s_waiting)
(assert
 (not l2s_frozen))
(assert
 (not l2s_saved))
(assert
 (and (not (l2s_g_0 @N1 @N2))))
(assert
 (not (hrb.sent_msg_proj hrb.n2)))
(assert
 (not (hrb.accept hrb.n1)))
(assert
 (let (($x42 (not (hrb.sent_msg_proj hrb.n2))))
 (=> (l2s_g_4 hrb.n2) $x42)))
(assert
 (let (($x37 (not (hrb.accept hrb.n1))))
 (=> (l2s_g_3 hrb.n1) $x37)))
(assert
 (let (($x201 (l2s_g_0 @N1 @N2)))
 (=> (and $x201 (and (hrb.sent_msg @N1 @N2) (hrb.correct @N2))) (not (l2s_g_1 @N1 @N2)))))
(assert
 (let (($x241 (and (not (hrb.member_fc @N2)) (not (hrb.member_fi @N2)) (not (hrb.member_fs @N2)) (not (hrb.member_fa @N2)))))
 (let (($x227 (hrb.correct @N2)))
 (= $x227 $x241))))
(assert
 (let (($x226 (hrb.sent_msg @N1 @N2)))
 (not $x226)))
(assert
 (not (and (hrb.member_fs @N2) (hrb.member_fa @N2))))
(assert
 (not (and (hrb.member_fi @N2) (hrb.member_fa @N2))))
(assert
 (not (and (hrb.member_fi @N2) (hrb.member_fs @N2))))
(assert
 (not (and (hrb.member_fc @N2) (hrb.member_fa @N2))))
(assert
 (not (and (hrb.member_fc @N2) (hrb.member_fs @N2))))
(assert
 (not (and (hrb.member_fc @N2) (hrb.member_fi @N2))))
(assert
 (=> (l2s_g_2 @N1 @N2) (not (hrb.sent_msg @N1 @N2))))
(assert
 (let (($x230 (l2s_g_1 @N1 @N2)))
 (=> $x230 (not (hrb.rcv_msg @N1 @N2)))))
(assert
 (not (hrb.rcv_msg @N1 @N2)))
(check-sat)
