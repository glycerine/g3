(set-info :status unknown)
(declare-fun __l2s_g_8 () Bool)
(declare-fun _old_l2s_g_8 () Bool)
(declare-fun l2s_g_8 () Bool)
(assert
 (not __l2s_g_8))
(assert
 (= _old_l2s_g_8 __l2s_g_8))
(assert
 (and l2s_g_8))
(check-sat)
