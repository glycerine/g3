(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun |__fml:n| () hrb.node)
(declare-fun @N () hrb.node)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.accept (hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun l2s_s_4 (hrb.node) Bool)
(declare-fun l2s_saved () Bool)
(declare-fun __hrb.accept (hrb.node) Bool)
(assert
 (or (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|)))
(assert
 (let (($x35 (hrb.accept @N)))
 (let (($x34 (and l2s_saved (and (l2s_s_4 @N) (hrb.obedient @N)))))
 (and (not (=> $x34 $x35))))))
(assert
 (let (($x35 (hrb.accept @N)))
 (or $x35 (not (__hrb.accept @N)) (= @N |__fml:n|))))
(assert
 (let (($x32 (hrb.obedient @N)))
 (= $x32 (and (not (hrb.member_fs @N)) (not (hrb.member_fa @N))))))
(assert
 (let (($x57 (__hrb.accept @N)))
 (let (($x34 (and l2s_saved (and (l2s_s_4 @N) (hrb.obedient @N)))))
 (=> $x34 $x57))))
(check-sat)
