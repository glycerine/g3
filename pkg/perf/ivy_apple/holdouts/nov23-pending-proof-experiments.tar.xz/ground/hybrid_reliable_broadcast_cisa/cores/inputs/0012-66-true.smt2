(set-info :status unknown)
(declare-fun __l2s_g_4 () Bool)
(declare-fun _old_l2s_g_4 () Bool)
(declare-fun l2s_g_4 () Bool)
(assert
 (not __l2s_g_4))
(assert
 (= _old_l2s_g_4 __l2s_g_4))
(assert
 (and l2s_g_4))
(check-sat)
