(check-sat)
