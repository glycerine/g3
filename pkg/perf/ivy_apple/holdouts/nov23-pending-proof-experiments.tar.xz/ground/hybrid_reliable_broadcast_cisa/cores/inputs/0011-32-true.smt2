(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun @N2 () hrb.node)
(declare-fun @N1 () hrb.node)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(assert
 (and (not (l2s_g_0 @N1 @N2))))
(check-sat)
