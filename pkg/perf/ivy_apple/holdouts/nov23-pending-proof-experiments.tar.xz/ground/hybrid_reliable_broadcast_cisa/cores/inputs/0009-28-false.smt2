(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun |__fml:n| () hrb.node)
(declare-fun |__fml:s| () hrb.node)
(declare-fun hrb.member_fc (hrb.node) Bool)
(declare-fun __hrb.sent_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun __hrb.rcv_msg (hrb.node hrb.node) Bool)
(declare-fun hrb.obedient (hrb.node) Bool)
(declare-fun __hrb.sent_msg_proj (hrb.node) Bool)
(assert
 (hrb.member_fc |__fml:n|))
(assert
 (__hrb.sent_msg |__fml:s| |__fml:n|))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fa |__fml:n|))))
(assert
 (not (and (hrb.member_fc |__fml:n|) (hrb.member_fs |__fml:n|))))
(assert
 (let (($x42 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> (and (hrb.obedient |__fml:n|) (__hrb.rcv_msg |__fml:s| |__fml:n|)) $x42)))
(assert
 (let (($x42 (__hrb.sent_msg |__fml:s| |__fml:n|)))
 (=> $x42 (__hrb.sent_msg_proj |__fml:s|))))
(assert
 (let (($x114 (hrb.obedient |__fml:n|)))
 (= $x114 (and (not (hrb.member_fs |__fml:n|)) (not (hrb.member_fa |__fml:n|))))))
(check-sat)
