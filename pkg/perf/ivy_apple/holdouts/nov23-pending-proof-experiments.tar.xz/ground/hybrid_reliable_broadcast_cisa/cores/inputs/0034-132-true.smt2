(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n0 () hrb.node)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun hrb.n1 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun __l2s_frozen () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun __l2s_saved () Bool)
(declare-fun hrb.correct (hrb.node) Bool)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun l2s_saved () Bool)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(declare-fun hrb.member_fi (hrb.node) Bool)
(declare-fun hrb.member_fc (hrb.node) Bool)
(assert
 (let (($x8 (not __l2s_waiting)))
 (or $x8 (not __l2s_frozen))))
(assert
 (let (($x8 (not __l2s_waiting)))
 (or $x8 (not __l2s_saved))))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n0)))
(assert
 (hrb.correct hrb.n0))
(assert
 (or __ts0_c __ts0_d))
(assert
 (let (($x87 (not __ts0_c)))
 (or $x87 (or __ts0_a __ts0_b))))
(assert
 (let (($x87 (not __ts0_c)))
 (or $x87 (or (not __ts0_a) __l2s_waiting))))
(assert
 (let (($x87 (not __ts0_c)))
 (or $x87 (or (not __ts0_b) __l2s_frozen))))
(assert
 l2s_saved)
(assert
 (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved))))
(assert
 (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n1 __l2s_s_11))))
(assert
 (let (($x180 (and (not (hrb.member_fc hrb.n0)) (not (hrb.member_fi hrb.n0)) (not (hrb.member_fs hrb.n0)) (not (hrb.member_fa hrb.n0)))))
 (let (($x76 (hrb.correct hrb.n0)))
 (= $x76 $x180))))
(check-sat)
