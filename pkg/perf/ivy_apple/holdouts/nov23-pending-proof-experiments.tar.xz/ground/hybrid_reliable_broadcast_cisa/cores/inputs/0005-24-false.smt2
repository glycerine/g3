(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun |__fml:n| () hrb.node)
(declare-fun hrb.member_fa (hrb.node) Bool)
(declare-fun hrb.member_fs (hrb.node) Bool)
(assert
 (or (hrb.member_fs |__fml:n|) (hrb.member_fa |__fml:n|)))
(check-sat)
