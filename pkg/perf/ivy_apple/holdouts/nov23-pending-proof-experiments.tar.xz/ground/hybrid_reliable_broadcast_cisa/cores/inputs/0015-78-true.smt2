(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun @N2 () hrb.node)
(declare-fun @N1 () hrb.node)
(declare-fun l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun _old_l2s_g_0 (hrb.node hrb.node) Bool)
(declare-fun __l2s_g_0 (hrb.node hrb.node) Bool)
(assert
 (and (not (l2s_g_0 @N1 @N2))))
(assert
 (let (($x17 (l2s_g_0 @N1 @N2)))
 (let (($x38 (_old_l2s_g_0 @N1 @N2)))
 (=> $x38 $x17))))
(assert
 (let (($x38 (_old_l2s_g_0 @N1 @N2)))
 (= $x38 (__l2s_g_0 @N1 @N2))))
(assert
 (__l2s_g_0 @N1 @N2))
(check-sat)
