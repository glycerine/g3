(set-info :status unknown)
(declare-sort hrb.node 0)
 (declare-fun hrb.n1 () hrb.node)
(declare-fun __l2s_s_11 () hrb.node)
(declare-fun l2s_s_11 () hrb.node)
(declare-fun __l2s_saved () Bool)
(declare-fun __l2s_waiting () Bool)
(declare-fun __ts0_d () Bool)
(declare-fun __ts0_c () Bool)
(declare-fun __ts0_b () Bool)
(declare-fun __ts0_a () Bool)
(declare-fun l2s_saved () Bool)
(assert
 (or (not __l2s_waiting) (not __l2s_saved)))
(assert
 (=> __l2s_saved (= __l2s_s_11 hrb.n1)))
(assert
 (or __ts0_c __ts0_d))
(assert
 (let (($x17 (not __ts0_c)))
 (or $x17 (or __ts0_a __ts0_b))))
(assert
 (let (($x17 (not __ts0_c)))
 (or $x17 (or (not __ts0_a) __l2s_waiting))))
(assert
 (= l2s_saved (ite __ts0_d __l2s_saved (ite __ts0_b true __l2s_saved))))
(assert
 (= l2s_s_11 (ite __ts0_d __l2s_s_11 (ite __ts0_b hrb.n1 __l2s_s_11))))
(assert
 (and (not (=> l2s_saved (= l2s_s_11 hrb.n1)))))
(check-sat)
