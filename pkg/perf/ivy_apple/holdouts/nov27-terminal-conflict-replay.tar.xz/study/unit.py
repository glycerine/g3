from pathlib import Path
import os,json,subprocess as sp,tempfile,csv
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).absolute();names=(ref/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
 def put(k,s):f=d/k.name;f.write_text(s);rep[str(k)]=str(f)
 k=front/'z3bridge_solver_model.go';s=Path(rep[str(k)]).read_text().replace('stopCheck:=startStage(batch,index+1);','unitBegin(batch,index+1);stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");unitEnd(batch,index+1)');put(k,s)
 k=front/'phase_observer_trial.go';s=Path(rep[str(k)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";');put(k,s+'''
func unitBegin(b,g int){target:=os.Getenv("TARGET");if target=="all"||target==fmt.Sprintf("%d-%d",b,g){smtcore.StartUnitTrial(os.Getenv("UNIT_MODE"))}}
func unitEnd(b,g int){t,n:=smtcore.EndUnitTrial();fmt.Fprintln(os.Stderr,"UNIT_RESULT",b,g,t,n)}
''')
 k=p/'smtcore/smt_search.go';s=k.read_text();a=s.index('restarts := &session.restarts',s.index('func (k *SMTKernel) boundedSearch'));put(k,s[:a]+'if e:=seedUnitTrial(k);e!=nil{return lbool.Undef,false,e};'+s[a:]+(w/'unit.go.txt').read_text())
 k=p/'smtcore/smt_internalizer.go';s=k.read_text();a=s.index('proof, err := instance.Proof()',s.index('func (s *SMTInternalizerState) internalizeInstance'));put(k,s[:a]+s[a:])
 j=d/'ov.json';j.write_text(json.dumps(ov));exe=d/'search';sp.run(['go','build','-mod=readonly','-tags','xtrace_off','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=td,GOTMPDIR=td),check=True)

 with (w/'unit-verified.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case target mode status attempts target_check check_sum stage_sum'.split())
  for key,cases in [('12-8',[8]),('all',[8,4,1,2,3,5,6,7,9,10,11,12])]:
   for n in cases:
    golden=ref/'compat'/str(n)/'1/native'
    for mode in ['base','first','last','all']:
     r=sp.run(['taskset','-c',os.environ.get('CPU','24'),exe,ex/names[n-1]],cwd=d,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TARGET=key,UNIT_MODE=mode),capture_output=True,timeout=120)
     stages=[];rest=bytearray();tries=0
     for l in r.stderr.splitlines(keepends=True):
      a=l.split()
      if l.startswith(b'STAGE-COUNT '):
       assert a[6]==a[7];stages.append((a[1]+b'-'+a[2],a[3],int(a[4])))
      elif l.startswith(b'UNIT_RESULT '):
       if key=='all' or a[1]+b'-'+a[2]==key.encode():tries+=int(a[3])
      else:rest.extend(l)
     match=(r.returncode,r.stdout,rest)==(codes[names[n-1]],(golden/'stdout').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/'),(golden/'stderr').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/'))
     o.writerow([n,key,mode,'match' if match else 'failed',tries,sum(v for t,ph,v in stages if t==b'12-8' and ph==b'check'),sum(v for t,ph,v in stages if ph==b'check'),sum(v for _,_,v in stages)]);f.flush()
