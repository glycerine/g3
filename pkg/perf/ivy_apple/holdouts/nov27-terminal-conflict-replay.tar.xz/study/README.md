Ticket and ARM quantifier dependency replay at g3 revision 903e4307f

Run from g3/pkg on Linux with user-mode hardware instructions available. Set GOIVY_FRONTEND, GOIVY_MODFILE, IVY_EXAMPLES, CPU, TMPDIR and NNF_REFERENCE as for nov27-conflict-levels-and-ticket-search.tar.xz. NNF_REFERENCE is the extracted nnf-study directory from nov27-nnf-row-comparison.tar.xz. The frontend and module setup are described in that archive. Each build uses a private temporary Go cache.

1. python3 /path/to/study/build.py g3 traces the two full workloads and checks them against native output.
2. python3 /path/to/study/extract_cone.py regenerates the ordinals and allowed lemma shapes from the two supplied trace files.
3. python3 /path/to/study/replay.py measures publication filtering by recorded shape.
4. python3 /path/to/study/bindings.py captures the emitted quantifier and binding terms, selects them by the traced ordinals, and tests early instantiation. The process deadline includes frontend initialization and previous checks. An unsuccessful restricted-search run supplies no proof.
5. python3 /path/to/study/transfer.py tests early hints from the current or earlier checks with ordinary search enabled and compares complete frontend outputs and exit codes. Stage totals include the measured solver operations across the complete input. They exclude frontend work. The base arm omits the hint lookup.

6. python3 /path/to/study/ablation.py greedily removes groups from the traced Ticket 12/8 set and checks the target and complete solver-stage totals in each full verifier run. Indices in minimal.json are one-based positions in selected.json.

7. python3 /path/to/study/unit.py screens the input-derived unary positive predicate rule, first on Ticket 12/8 and then across twelve complete workloads. The first, last and all arms select live uninterpreted constants of the binder sort in AST slot order.

8. python3 /path/to/study/gate.py compares restricting these candidates by the quantifier assignment or by when the ground constant entered the solver.

9. python3 /path/to/study/delay.py repeats the active-quantifier experiment after one, four or sixteen conflicts and propagates again before selecting a decision.

A selected ground instance is rebuilt using a registered quantifier and live enodes with checked sorts. Only unambiguous printed shape matches are used. The candidate origins overapproximate duplicate binary clauses and can miss discarded intermediate clauses and ground-term construction dependencies. These generators are diagnostic overlays only.
