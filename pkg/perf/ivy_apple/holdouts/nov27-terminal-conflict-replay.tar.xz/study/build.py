from pathlib import Path
w=Path(__file__).resolve().parent;s=(w/'measure.py').read_text();k="  else:\n   build=";a=s.index(k);s=s[:a]+'''   path=p/'smtcore/smt_search.go';ss=Path(rep[str(path)]).read_text().replace('import (','import ("sort";')
   key='resolution, err := resolver.resolve(conflict, conflictLiteral, baseLevel, userBaseLevel)';ss=edit(ss,key,'traceCone(resolver,conflict,conflictLiteral);'+key)
   key='if err = k.internalizer.addLearnedClauseWithProof(resolution.Lemma, proof, delayed);';ss=edit(ss,key,'if causeOn(){causeActive=-causeConflict;defer func(){causeActive=0}()};'+key);put(path,ss+(w/'cone.go.txt').read_text())
   path=p/'smtcore/smt_internalizer.go';ss=path.read_text();key='func (s *SMTInternalizerState) internalizeInstance(';aa=ss.index('{',ss.index(key))+1;ss=ss[:aa]+"""if causeOn(){causeQI++;prior:=causeActive;causeActive=causeQI;defer func(){causeActive=prior}()}
"""+ss[aa:]
   key='if clause.ReinternalizeAtoms()';aa=ss.index(key,ss.index('clause, owner, err := s.makeClauseWithJustificationAndDeleteHandler(kept'));ss=ss[:aa]+'if causeActive!=0{causeClauses[clause]=causeActive};'+ss[aa:]
   key='s.binaryClauses.add(first, second, root, lemma, proof)';ss=edit(ss,key,'if causeActive!=0{key:=causeKey(s,first,second);causeBinaries[key]=append(causeBinaries[key],causeActive)};'+key);put(path,ss)
   path=p/'smtcore/smt_theory_propagation.go';ss=path.read_text();key='s.assignedLiterals = append(s.assignedLiterals, literal)';put(path,edit(ss,key,'if causeOn(){causeUnits[literal.Var()]=causeRecord{s.boolExpr[literal.Var()],literal,causeActive}};'+key))
   path=p/'smtcore/smt_boolean_propagation.go';ss=path.read_text();key='s.conflict = justification';put(path,edit(ss,key,'if causeOn(){causeFailed=causeActive};'+key))
'''+s[a:];s=s.replace('d=Path(td);ov=',"d=Path(td);os.environ['GOCACHE']=str(d/'cache');ov=");exec(compile(s,'observe','exec'))
