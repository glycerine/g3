from pathlib import Path
import os,json,subprocess as sp,tempfile,csv
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).absolute();names=(ref/'compat.txt').read_text().splitlines()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
 def put(k,s):f=d/k.name;f.write_text(s);rep[str(k)]=str(f)
 k=front/'z3bridge_solver_model.go';s=Path(rep[str(k)]).read_text().replace('stopCheck:=startStage(batch,index+1);','target:=bindBegin(batch,index+1);stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");if target{bindEnd(res==smt.Unsat,err)}');put(k,s)
 k=front/'phase_observer_trial.go';s=Path(rep[str(k)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";');put(k,s+'''
func bindBegin(b,g int)bool{key:=fmt.Sprintf("%d-%d",b,g);if key!=os.Getenv("TARGET"){return false};smtcore.StartConeGoal(key);return true}
func bindEnd(u bool,e error){smtcore.EndConeGoal();fmt.Fprintln(os.Stderr,"PROOF_RESULT",u,e);}
''')
 k=p/'smtcore/smt_search.go';s=k.read_text().replace('import (','import ("strings";"strconv";"encoding/json";"os";');a=s.index('restarts := &session.restarts',s.index('func (k *SMTKernel) boundedSearch'));s=s[:a]+'if e:=seedCone(k);e!=nil{return lbool.Undef,false,e};'+s[a:];src=(w/'tree.go.txt').read_text();put(k,s+src[src.index('func trialTree('):src.index('var trialOwner')]+(w/'bindings.txt').read_text().replace('replayGoal+"/selected.json"', 'os.Getenv("DONOR")+"/selected.json"').replace('replayMode=="capture"||replayMode=="none"', 'replayMode=="base"||replayMode=="capture"||replayMode=="none"'))
 k=p/'smtcore/smt_internalizer.go';s=k.read_text();a=s.index('proof, err := instance.Proof()',s.index('func (s *SMTInternalizerState) internalizeInstance'));s=s[:a]+'''if replayGoal!=""{if replayMode=="capture"{noteBinding(s,instance)}else if injecting{added++}else if replayMode=="only"||replayMode=="none"{suppressed++;return nil}}
'''+s[a:];put(k,s)
 # Optional transfer control renames generated numeric suffixes only during lookup.
 k=p/'smtcore/smt_search.go';s=Path(rep[str(k)]).read_text();s=s.replace('import (','import ("regexp";',1)
 s+='''
var freshConeSuffix=regexp.MustCompile(`![0-9]+([ )]|$)`)
func transferShape(value string)string{if replayMode=="rename"{return freshConeSuffix.ReplaceAllString(value,"!#$1")};return value}
'''
 s=s.replace('key:=witnessTree(s.manager,h);if _,ok:=qs','key:=transferShape(witnessTree(s.manager,h));if _,ok:=qs').replace('h:=qs[hint.Quant]','h:=qs[transferShape(hint.Quant)]').replace('key:=termKey(s,n.owner);if _,ok:=es','key:=termKey(s,n.owner);key.Shape=transferShape(key.Shape);if _,ok:=es').replace('n:=es[t];if n==nil','t.Shape=transferShape(t.Shape);n:=es[t];if n==nil');put(k,s)
 j=d/'ov.json';j.write_text(json.dumps(ov));exe=d/'search';sp.run(['go','build','-mod=readonly','-tags','xtrace_off','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=td,GOTMPDIR=td),check=True)

 with (w/'transfer.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case target donor mode outcome ready installed target_instructions check_sum push_sum stage_sum'.split());f.flush()
  assert all((w/k/'selected.json').is_file() for k in ['12-8','14-8','16-1','6-5','6-6'])
  for n,key,donors in [(8,'12-8',['12-8']),(8,'14-8',['12-8','14-8']),(8,'16-1',['12-8','14-8','16-1']),(4,'6-5',['6-5']),(4,'6-6',['6-5','6-6'])]:
   golden=ref/'compat'/str(n)/'1/native'
   for donor,mode in [('base','base')]+[(v,'hint') for v in donors]+[(v,'rename') for v in donors if v!=key]:
    r=sp.run(['taskset','-c',os.environ.get('CPU','24'),exe,ex/names[n-1]],cwd=d,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TARGET=key,REPLAY_MODE=mode,DONOR=donor,CONE_DIR=str(w)),capture_output=True,timeout=90)
    stats=[];stages=[];rest=bytearray();result=''
    for line in r.stderr.splitlines(keepends=True):
     if line.startswith(b'BIND_RESULTS '):stats=line.split()[1:]
     elif line.startswith(b'PROOF_RESULT '):result=line.decode().strip()
     elif line.startswith(b'STAGE-COUNT '):
      a=line.decode().split();assert a[6]==a[7];stages.append((a[1]+'-'+a[2],a[3],int(a[4])))
     else:rest.extend(line)
    good=(r.returncode,r.stdout,rest)==(0,(golden/'stdout').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/'),(golden/'stderr').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/')) and result=='PROOF_RESULT true <nil>'
    if not good:(w/key/('transfer-'+donor+'.err')).write_bytes(rest[-4000:])
    o.writerow([n,key,donor,mode,'match' if good else 'failed',*(int(i) for i in stats[1:3]),sum(v for t,p,v in stages if t==key and p=='check'),sum(v for t,p,v in stages if p=='check'),sum(v for t,p,v in stages if p=='push'),sum(v for _,_,v in stages)]);f.flush()
