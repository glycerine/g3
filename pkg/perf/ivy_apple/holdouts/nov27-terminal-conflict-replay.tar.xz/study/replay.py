from pathlib import Path
import os,subprocess as sp,csv,json,tempfile
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).absolute();names=(ref/'compat.txt').read_text().splitlines()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as tmp:
 d=Path(tmp);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
 def put(k,s):f=d/k.name;f.write_text(s);rep[str(k)]=str(f)
 k=front/'z3bridge_solver_model.go';s=Path(rep[str(k)]).read_text();point='stopCheck:=startStage(batch,index+1);';s=s.replace(point,'want:=coneBegin(batch,index+1);'+point).replace('stopCheck("check")','stopCheck("check");if want{coneEnd(res==smt.Unsat,err)}');put(k,s)
 k=front/'phase_observer_trial.go';s=Path(rep[str(k)]).read_text().replace('import (','import ("strings";"github.com/glycerine/g3/pkg/smtcore";');put(k,s+'''
func coneBegin(b,g int)bool{if fmt.Sprintf("%d-%d",b,g)!=os.Getenv("CONE_TARGET"){return false};data,e:=os.ReadFile(os.Getenv("CONE_LIST"));if e!=nil{panic(e)};smtcore.AllowedCone=map[string]bool{};for _,l:=range strings.Split(string(data),"\\n"){smtcore.AllowedCone[l]=true};return true}
func coneEnd(unsat bool,e error){fmt.Fprintln(os.Stderr,"CONE_RESULT",unsat,e,smtcore.ConeAccepted,smtcore.ConeSkipped);os.Exit(0)}
''')
 k=p/'smtcore/smt_internalizer.go';s=k.read_text();a=s.index('proof, err := instance.Proof()',s.index('func (s *SMTInternalizerState) internalizeInstance'));s=s[:a]+'''if AllowedCone!=nil{if !AllowedCone[witnessTree(s.manager,lemma)]{ConeSkipped++;return nil};ConeAccepted++}
'''+s[a:];src=(w/'tree.go.txt').read_text();src=src[src.index('func trialTree('):src.index('var trialOwner')];src=src[:src.index('func witnessTrace')] +src[src.index('func witnessTree'):] if 'func witnessTrace' in src else src;s+='\nvar AllowedCone map[string]bool\nvar ConeAccepted,ConeSkipped int\n'+src
 for imp in ['strings','strconv','os']:
  if '"'+imp+'"' not in s and (imp+'.') in s:s=s.replace('import (','import ("'+imp+'";',1)
 put(k,s)
 j=d/'ov.json';j.write_text(json.dumps(ov));exe=d/'search';sp.run(['go','build','-mod=readonly','-tags','xtrace_off','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=tmp,GOTMPDIR=tmp),check=True)
 with (w/'replay.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case target mode status accepted skipped instructions'.split())
  for nr,tar in [(8,'12-8'),(8,'14-8'),(8,'16-1'),(4,'6-5'),(4,'6-6')]:
   for m in ['all','cone','none']:
    try:r=sp.run(['taskset','-c',os.environ.get('CPU','22'),exe,ex/names[nr-1]],cwd=d,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),CONE_TARGET=tar,CONE_LIST=str(w/tar/(m+'.txt'))),capture_output=True,timeout=15)
    except sp.TimeoutExpired:o.writerow([nr,tar,m,'timeout','','','']);f.flush();continue
    lines=r.stderr.decode().splitlines();res=[x for x in lines if x.startswith('CONE_RESULT ')];
    if len(res)!=1:
     (w/tar/(m+'.err')).write_text('\n'.join(lines[-60:]));o.writerow([nr,tar,m,'exit '+str(r.returncode),'','','']);f.flush();continue
    _,v,*err,a,skip=res[0].split();assert r.returncode==0;outcome=('unsat' if v=='true' else 'unproved') if err==['<nil>'] else 'error '+' '.join(err)
    row=next(x.split() for x in reversed(lines) if x.startswith('STAGE-COUNT '));assert row[3]=='check' and row[6]==row[7];o.writerow([nr,tar,m,outcome,a,skip,row[4]]);f.flush()
