from pathlib import Path
import os,json,subprocess as sp,tempfile,csv
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).absolute();names=(ref/'compat.txt').read_text().splitlines()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
 def put(k,s):f=d/k.name;f.write_text(s);rep[str(k)]=str(f)
 k=front/'z3bridge_solver_model.go';s=Path(rep[str(k)]).read_text().replace('stopCheck:=startStage(batch,index+1);','target:=bindBegin(batch,index+1);stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");if target{bindEnd(res==smt.Unsat,err)}');put(k,s)
 k=front/'phase_observer_trial.go';s=Path(rep[str(k)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";');put(k,s+'''
func bindBegin(b,g int)bool{key:=fmt.Sprintf("%d-%d",b,g);if key!=os.Getenv("TARGET"){return false};smtcore.StartConeGoal(key);return true}
func bindEnd(u bool,e error){smtcore.EndConeGoal();fmt.Fprintln(os.Stderr,"PROOF_RESULT",u,e);}
''')
 k=p/'smtcore/smt_search.go';s=k.read_text().replace('import (','import ("strings";"strconv";"encoding/json";"os";');a=s.index('restarts := &session.restarts',s.index('func (k *SMTKernel) boundedSearch'));s=s[:a]+'if e:=seedCone(k);e!=nil{return lbool.Undef,false,e};'+s[a:];src=(w/'tree.go.txt').read_text();put(k,s+src[src.index('func trialTree('):src.index('var trialOwner')]+(w/'bindings.txt').read_text().replace('replayGoal+"/selected.json"', 'os.Getenv("DONOR")').replace('replayMode=="capture"||replayMode=="none"', 'replayMode=="base"||replayMode=="capture"||replayMode=="none"'))
 k=p/'smtcore/smt_internalizer.go';s=k.read_text();a=s.index('proof, err := instance.Proof()',s.index('func (s *SMTInternalizerState) internalizeInstance'));s=s[:a]+'''if replayGoal!=""{if replayMode=="capture"{noteBinding(s,instance)}else if injecting{added++}else if replayMode=="only"||replayMode=="none"{suppressed++;return nil}}
'''+s[a:];put(k,s)
 # Optional transfer control renames generated numeric suffixes only during lookup.
 k=p/'smtcore/smt_search.go';s=Path(rep[str(k)]).read_text();s=s.replace('import (','import ("regexp";',1)
 s+='''
var freshConeSuffix=regexp.MustCompile(`![0-9]+([ )]|$)`)
func transferShape(value string)string{if replayMode=="rename"{return freshConeSuffix.ReplaceAllString(value,"!#$1")};return value}
'''
 s=s.replace('key:=witnessTree(s.manager,h);if _,ok:=qs','key:=transferShape(witnessTree(s.manager,h));if _,ok:=qs').replace('h:=qs[hint.Quant]','h:=qs[transferShape(hint.Quant)]').replace('key:=termKey(s,n.owner);if _,ok:=es','key:=termKey(s,n.owner);key.Shape=transferShape(key.Shape);if _,ok:=es').replace('n:=es[t];if n==nil','t.Shape=transferShape(t.Shape);n:=es[t];if n==nil');put(k,s)
 j=d/'ov.json';j.write_text(json.dumps(ov));exe=d/'search';sp.run(['go','build','-mod=readonly','-tags','xtrace_off','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=td,GOTMPDIR=td),check=True)


 n=8;key='12-8';recipes=json.loads((w/key/'selected.json').read_text());golden=ref/'compat/8/1/native'
 with (w/'ablation.csv').open('w') as f:
  o=csv.writer(f);o.writerow('trial selected installed target stage_sum outcome'.split());tested={}
  def run(ids):
   ids=tuple(ids)
   if ids in tested:return tested[ids]
   path=d/'subset.json';path.write_text(json.dumps([recipes[i] for i in ids]));r=sp.run(['taskset','-c',os.environ.get('CPU','24'),exe,ex/names[n-1]],cwd=d,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TARGET=key,REPLAY_MODE='hint',DONOR=path.name,CONE_DIR=str(d)),capture_output=True,timeout=45)
   rest=bytearray();target=0;total=0;installed=-1;status=''
   for l in r.stderr.splitlines(keepends=True):
    if l.startswith(b'STAGE-COUNT '):
     a=l.split();assert a[6]==a[7];v=int(a[4]);total+=v
     if a[1:4]==[b'12',b'8',b'check']:target=v
    elif l.startswith(b'BIND_RESULTS '):installed=int(l.split()[3])
    elif l.startswith(b'PROOF_RESULT '):status=l.decode().strip()
    else:rest.extend(l)
   assert (r.returncode,r.stdout,rest,status)==(0,(golden/'stdout').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/'),(golden/'stderr').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/'),'PROOF_RESULT true <nil>'),rest[-1500:]
   o.writerow([len(tested),' '.join(str(i+1) for i in ids),installed,target,total,'match']);f.flush();tested[ids]=(target,total);return target,total
  ids=list(range(len(recipes)));run([]);orig=run(ids)
  def fast(x):
   target,total=run(x);return target < 60000000 and total < orig[1]+30000000
  parts=2
  while ids:
   size=(len(ids)+parts-1)//parts
   for i in range(0,len(ids),size):
    candidate=ids[:i]+ids[i+size:]
    if fast(candidate):ids=candidate;parts=max(2,parts-1);break
   else:
    if parts>=len(ids):break
    parts=min(len(ids),parts*2)
  (w/'minimal.json').write_text(json.dumps({'indices':[i+1 for i in ids],'recipes':[recipes[i] for i in ids],'instructions':run(ids)}))
