from pathlib import Path
import gzip,json
w=Path(__file__).resolve().parent
def collect(k):
 if not k:return
 assert con and n==len(con)
 by={i:v for i,v in enumerate(con,1)};qi=set();conf=set();todo=[n]
 while todo:
  i=todo.pop()
  if i in conf:continue
  conf.add(i)
  for v in by[i]:
   if v<0:assert -v<i;todo.append(-v)
   else:qi.add(v)
 assert all(0<x<=len(q) for x in qi)
 d=w/k.replace('/','-');d.mkdir(exist_ok=True)
 for tag,ids in [('cone',qi),('all',range(1,len(q)+1)),('none',[])]:
  (d/(tag+'.txt')).write_text(''.join(x+'\n' for x in dict.fromkeys(q[i-1] for i in sorted(ids))))
 (d/'ordinals.json').write_text(json.dumps({'qi':sorted(qi),'conflicts':sorted(conf)}))
 print(k,len(q),len(qi),max(qi,default=0),len(conf),len(con))
for nr in (8,4):
 k=''
 for line in gzip.open(w/f'g3-{nr}.log.gz','rt'):
  t,_,v=line.rstrip().removeprefix('EVENT ').partition(' ')
  if t=='START':collect(k);k=v;con=[];n=0;q=[]
  elif t=='Q':q.append(v.split(' ',1)[1])
  elif t=='CONE':
   a,b=v.split('[',1);n,nq,_=map(int,a.split());assert nq==len(q);con.append([int(x) for x in b.split('[')[1].rstrip(']').split()])
 collect(k)
