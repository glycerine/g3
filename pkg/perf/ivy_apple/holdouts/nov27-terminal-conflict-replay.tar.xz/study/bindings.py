from pathlib import Path
import os,json,subprocess as sp,tempfile,csv
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).absolute();names=(ref/'compat.txt').read_text().splitlines()
with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
 d=Path(td);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'stage-bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt'),str(front/'phase_observer_trial.go'):str(w/'timer.go.txt')}};rep=ov['Replace']
 def put(k,s):f=d/k.name;f.write_text(s);rep[str(k)]=str(f)
 k=front/'z3bridge_solver_model.go';s=Path(rep[str(k)]).read_text().replace('stopCheck:=startStage(batch,index+1);','target:=bindBegin(batch,index+1);stopCheck:=startStage(batch,index+1);').replace('stopCheck("check")','stopCheck("check");if target{bindEnd(res==smt.Unsat,err)}');put(k,s)
 k=front/'phase_observer_trial.go';s=Path(rep[str(k)]).read_text().replace('import (','import ("github.com/glycerine/g3/pkg/smtcore";');put(k,s+'''
func bindBegin(b,g int)bool{key:=fmt.Sprintf("%d-%d",b,g);if key!=os.Getenv("TARGET"){return false};smtcore.StartConeGoal(key);return true}
func bindEnd(u bool,e error){smtcore.EndConeGoal();fmt.Fprintln(os.Stderr,"PROOF_RESULT",u,e);os.Exit(0)}
''')
 k=p/'smtcore/smt_search.go';s=k.read_text().replace('import (','import ("strings";"strconv";"encoding/json";"os";');a=s.index('restarts := &session.restarts',s.index('func (k *SMTKernel) boundedSearch'));s=s[:a]+'if e:=seedCone(k);e!=nil{return lbool.Undef,false,e};'+s[a:];src=(w/'tree.go.txt').read_text();put(k,s+src[src.index('func trialTree('):src.index('var trialOwner')]+(w/'bindings.txt').read_text())
 k=p/'smtcore/smt_internalizer.go';s=k.read_text();a=s.index('proof, err := instance.Proof()',s.index('func (s *SMTInternalizerState) internalizeInstance'));s=s[:a]+'''if replayGoal!=""{if replayMode=="capture"{noteBinding(s,instance)}else if injecting{added++}else if replayMode=="only"||replayMode=="none"{suppressed++;return nil}}
'''+s[a:];put(k,s)
 j=d/'ov.json';j.write_text(json.dumps(ov));exe=d/'search';sp.run(['go','build','-mod=readonly','-tags','xtrace_off','-buildvcs=false','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',j,'-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE=str(d/'cache'),TMPDIR=td,GOTMPDIR=td),check=True)
 with (w/'bindings.csv').open('w') as f:
  o=csv.writer(f);o.writerow('case target mode status emitted ready installed suppressed instructions'.split())
  for n,key in [(8,'12-8'),(8,'14-8'),(8,'16-1'),(4,'6-5'),(4,'6-6')]:
   for mode in ('capture','hint','only','none'):
    try:r=sp.run(['taskset','-c',os.environ.get('CPU','24'),exe,ex/names[n-1]],cwd=d,env=dict(os.environ,GOGC='off',GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),TARGET=key,REPLAY_MODE=mode,CONE_DIR=str(w)),capture_output=True,timeout=12)
    except sp.TimeoutExpired:o.writerow([n,key,mode,'timeout','','','','','']);f.flush();continue
    lines=r.stderr.decode().splitlines();stats=next((l.split()[1:] for l in lines if l.startswith('BIND_RESULTS ')),None);
    if not stats:
     (w/key/(mode+'.err')).write_text('\n'.join(lines[-60:]));o.writerow([n,key,mode,'exit '+str(r.returncode),'','','','','']);f.flush();continue
    status=next(l.split()[1:] for l in lines if l.startswith('PROOF_RESULT '));outcome=('unsat' if status[0]=='true' else 'unproved') if status[1:]==['<nil>'] else 'error '+' '.join(status[1:]);st=next(l.split() for l in reversed(lines) if l.startswith('STAGE-COUNT '));assert st[3]=='check' and st[6]==st[7];o.writerow([n,key,mode,outcome,*stats,st[4]]);f.flush()
    if mode=='capture':
     recipes=json.loads((w/key/'recipes.json').read_text());ids=json.loads((w/key/'ordinals.json').read_text())['qi'];(w/key/'selected.json').write_text(json.dumps([recipes[i-1] for i in ids]))
