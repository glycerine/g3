from pathlib import Path
import os,json,csv,gzip,subprocess as sp,tempfile,re,shlex,shutil,sys
w=Path(__file__).resolve().parent;p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();rank=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES']).absolute();names=(rank/'compat.txt').read_text().splitlines()
def edit(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def main(mode):
 with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR','/tmp')) as td:
  d=Path(td);ov={'Replace':{str(front/'z3bridge_solver_model.go'):str(w/'bridge.go.txt'),str(front/'z3bridge_guarded_equalities.go'):str(w/'guards.go.txt')}};rep=ov['Replace']
  def put(path,s):
   f=d/path.name;f.write_text(s);rep[str(path)]=str(f)
  path=front/'z3bridge_solver_model.go';s=(w/'stage-bridge.go.txt').read_text();s=edit(s,'stopCheck:=startStage(batch,index+1);','scopeEvent(batch,index+1);stopCheck:=startStage(batch,index+1);');s=edit(s,'stopCheck("check")','stopCheck("check");scopeEvent(0,0)');put(path,s)
  timer=(w/'timer.go.txt').read_text()
  put(front/'phase_observer_trial.go',timer+'''\nfunc scopeEvent(b,g int){ v:=fmt.Sprintf("%d/%d",b,g); if (os.Getenv("CASE")=="8" && (v=="12/8"||v=="14/8"||v=="16/1")) || (os.Getenv("CASE")=="4" && (v=="6/5"||v=="6/6")) {os.Setenv("TRACE_SEARCH",v);fmt.Fprintln(os.Stderr,"EVENT START",v)}else{os.Unsetenv("TRACE_SEARCH")}}\n''')
  if mode=='g3':
   path=p/'smtcore/smt_search.go';s=path.read_text();src=(w/'tree.go.txt').read_text();src=src[src.index('func trialTree('):src.index('var trialOwner')];s=s.replace('import (','import ("os";"strings";"strconv";')+src
   k='k.internalizer.traceDecide(variable, phase == lbool.True)';s=edit(s,k,'''if os.Getenv("TRACE_SEARCH")!=""{fmt.Fprintln(os.Stderr,"EVENT D",smtDecisionLiteral(variable,phase).Index(),witnessTree(k.manager,k.internalizer.boolExpr[variable]))};'''+k)
   k='if !resolution.Resolved {';s=edit(s,k,'''if os.Getenv("TRACE_SEARCH")!="" {if !resolution.Resolved {fmt.Fprintln(os.Stderr,"EVENT END")} else {var b strings.Builder;for _,l:=range resolution.Lemma{fmt.Fprintf(&b," %d",l.Index())};fmt.Fprintln(os.Stderr,"EVENT C",k.internalizer.scopeLevel,resolution.NewScopeLevel,b.String())}};'''+k);put(path,s)
   path=p/'smtcore/smt_qi_instance.go';s=path.read_text().replace('import (','import ("os";');k='if err = internalizer.internalizeInstance(result, locals.arguments);';s=edit(s,k,'''if os.Getenv("TRACE_SEARCH")!=""{v,e:=result.Lemma();if e!=nil{panic(e)};fmt.Fprintln(os.Stderr,"EVENT Q",result.generation,witnessTree(result.manager,v))};'''+k);put(path,s)
  else:
   build=p.parent/'build';flags=dict(l.split('=',1) for l in (build/'config.mk').read_text().splitlines() if '=' in l);inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1]);objs=[]
   shape=(w/'tree.cpp.txt').read_text().split('static bool active()')[0]
   for unit in ['smt_context','qi_queue']:
    s=(p.parent/'src/smt'/(unit+'.cpp')).read_text()
    if unit=='smt_context':
     k='assign(literal(var, !is_pos), b_justification::mk_axiom(), true);';s=edit(s,k,'if(getenv("TRACE_SEARCH")){std::ostringstream out;shape(out,bool_var2expr(var));fprintf(stderr,"EVENT D %u %s\\n",literal(var,!is_pos).index(),out.str().c_str());}'+k)
     k='if (m_conflict_resolution->resolve(m_conflict, m_not_l)) {';s=edit(s,k,'''bool solved=m_conflict_resolution->resolve(m_conflict,m_not_l);if(getenv("TRACE_SEARCH")&&!solved)fprintf(stderr,"EVENT END\\n");if(solved){''')
     k='literal * lits    = m_conflict_resolution->get_lemma_literals();';s=edit(s,k,k+'''if(getenv("TRACE_SEARCH")){fprintf(stderr,"EVENT C %u %u",m_scope_lvl,new_lvl);for(unsigned i=0;i<num_lits;i++)fprintf(stderr," %u",lits[i].index());fprintf(stderr,"\\n");}''')
    else:
     k='m_context.internalize_instance(lemma, pr1, gen);';s=edit(s,k,'if(getenv("TRACE_SEARCH")){std::ostringstream out;shape(out,lemma);fprintf(stderr,"EVENT Q %u %s\\n",gen,out.str().c_str());}'+k)
    f=d/(unit+'.cpp');f.write_text(shape+s);obj=d/(unit+'.o');sp.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,f],cwd=build,check=True);objs.append(obj)
   lib=d/'study.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib);sp.run(['ar','r',lib,*objs],check=True)
   path=front/'smt/quantifier.go';put(path,path.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
  j=d/'ov.json';j.write_text(json.dumps(ov));exe=d/mode;sp.run(['go','build','-tags','xtrace_off'+(',classic_z3' if mode=='native' else ''),'-pgo='+('off' if mode=='native' else str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-buildvcs=false','-mod=readonly','-modfile',Path(os.environ['GOIVY_MODFILE']).resolve(),'-overlay',j,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,TMPDIR=td,GOTMPDIR=td),check=True)
  for n in [8,4]:
   ref=rank/'compat'/str(n)/'1/native';r=sp.run(['taskset','-c',os.environ.get('CPU','22'),exe,ex/names[n-1]],cwd=d,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'),CASE=str(n)),capture_output=True,timeout=90)
   rest=bytearray()
   with gzip.open(w/f'{mode}-{n}.log.gz','wb') as f:
    for line in r.stderr.splitlines(keepends=True):
     if line.startswith(b'EVENT '):f.write(line)
     elif not line.startswith(b'STAGE-COUNT '):rest.extend(line)
   assert (r.returncode,r.stdout,rest)==(0,(ref/'stdout').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/'),(ref/'stderr').read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(ex)+b'/')),rest[:400]
if __name__=='__main__':main(sys.argv[1])
