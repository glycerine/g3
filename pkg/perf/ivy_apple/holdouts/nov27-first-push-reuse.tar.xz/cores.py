"""Measure coverage of previously certified UNSAT cores on later identical goals."""
import csv,sys,re,subprocess
from pathlib import Path
from online import inputs
w=Path(__file__).resolve().parent
captures,z3,g3=map(lambda s:Path(s).resolve(),sys.argv[1:4])
decl,bases,goals=inputs(captures)
cores=[]
with (w/'cores.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['batch','base','core','prior_core_batch','later_covered','g3_confirmed'])
 for i,(base,goal) in enumerate(zip(bases,goals)):
    body=decl+'\n'.join('(assert (! '+c+' :named premise'+str(j)+'))' for j,c in enumerate(base))+'\n(assert '+goal+')\n'
    r=subprocess.run([z3,'-in'],input='(set-option :produce-unsat-cores true)\n'+body+'(check-sat)\n(get-unsat-core)\n',capture_output=True,text=True,timeout=30,check=True)
    m=re.fullmatch(r'unsat\s*\(([^()]*)\)\s*',r.stdout);assert m and not r.stderr,r
    core={base[int(re.fullmatch('premise([0-9]+)',n)[1])] for n in m[1].split()}
    replay=decl+'\n'.join('(assert '+c+')' for c in sorted(core))+'\n(assert '+goal+')\n(check-sat)\n'
    r=subprocess.run([g3,'-in'],input=replay,capture_output=True,text=True,timeout=30)
    assert (r.returncode,r.stdout,r.stderr)==(0,'unsat\n',''),r
    hit=next((j+1 for j,c in enumerate(cores) if goals[j]==goal and c.issubset(base)),0)
    later=sum(c==goal and core.issubset(b) for b,c in zip(bases[i+1:],goals[i+1:]))
    writer.writerow([i+1,len(base),len(core),hit,later,True]);f.flush();cores.append(core)
