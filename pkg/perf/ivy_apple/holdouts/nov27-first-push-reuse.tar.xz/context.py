"""Observe base conjunct identity on the first concrete push per frontend batch."""
import json,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
pkg=Path.cwd()
front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3])
src=front/'z3bridge_solver_model.go'
s=src.read_text()
i=s.index('func (s *Solver) GetSmallModelWithCond(')
s=s[:i]+'''var studyContexts = make(map[*smt.Z3Context]int)

func studyBase(ctx *smt.Z3Context, root smt.Z3Expr) {
 id, ok := studyContexts[ctx]
 if !ok {id=len(studyContexts)+1; studyContexts[ctx]=id}
 var leaves []uint
 var collect func(smt.Z3Expr)
 collect=func(e smt.Z3Expr){
  if e.IsAppOf(smt.DeclAnd){for i,n:=0,e.NumArgs(); i<n; i++ {collect(e.Arg(i))};return}
  leaves=append(leaves,e.GetId())
 }
 collect(root)
 fmt.Fprintf(os.Stderr,"BASE %d %v\\n",id,leaves)
}

'''+s[i:]
key='\n\t\tfor _, fc := range finalCond {'
assert s.count(key)==1
s=s.replace(key,'\n\t\tfirstStudyPush := true'+key)
key='if s.opts.Incremental {\n\t\t\t\t\tz3solver.Push()'
assert s.count(key)==1
s=s.replace(key,'if s.opts.Incremental {\n if firstStudyPush {studyBase(s.tr.Ctx,zc); firstStudyPush=false}\n z3solver.Push()')
dst=w/'context-observer.go';dst.write_text(s)
o=w/'context.json';o.write_text(json.dumps({'Replace':{str(src):str(dst)}}))
subprocess.run(['go','build','-pgo='+str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'context','./cmd/goivy_check'],cwd=front,check=True)
