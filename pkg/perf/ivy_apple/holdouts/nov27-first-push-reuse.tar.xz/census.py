"""Compare ordered and unordered common base conjuncts for adjacent physical batches."""
import csv,os,subprocess,sys
from collections import Counter
from pathlib import Path
w=Path(__file__).resolve().parent
p=Path('/tmp/g3-ivy-pgo');ex=Path('/home/jaten/ivy/ivy-lang-examples')
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
codes={r["spec"]:int(r["exit"]) for f in (p/"survey").glob("cpu-*.csv") for r in csv.DictReader(f.open()) if r["engine"]=="native"}
for case in sys.argv[1:]:
 idx=(p/'prior-gaps.txt').read_text().splitlines().index(case)+1
 ref=p/'survey'/str(idx)/'1'/'native'
 r=subprocess.run([w/'context',ex/case],env=env,cwd=w,capture_output=True,timeout=120)
 rows=[];other=[]
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'BASE '):
   _,ctx,ids=line.split(maxsplit=2)
   rows.append((int(ctx),list(map(int,ids.strip()[1:-1].split()))))
  else:other.append(line)
 assert r.returncode==codes[case] and r.stdout==(ref/'stdout').read_bytes() and b''.join(other)==(ref/'stderr').read_bytes(),(case,r.returncode,r.stderr[-200:])
 with (w/('contexts-'+str(idx)+'.csv')).open('w') as f:
  writer=csv.writer(f);writer.writerow(['batch','context','conjunct_ids'])
  for i,(ctx,ids) in enumerate(rows):writer.writerow([i,ctx,' '.join(map(str,ids))])
 ordered=common=same=0
 for (ctx,a),(ctx2,b) in zip(rows,rows[1:]):
  if ctx!=ctx2:continue
  same+=1;common+=sum((Counter(a)&Counter(b)).values())
  for x,y in zip(a,b):
   if x!=y:break
   ordered+=1
 print(case,len(rows),len(set(ctx for ctx,_ in rows)),sum(len(ids) for _,ids in rows),same,ordered,common,flush=True)
