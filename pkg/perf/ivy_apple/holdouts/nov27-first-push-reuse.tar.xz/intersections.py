"""Can any UNSAT certificate supported by one earlier base prove the next goal?"""
import csv,subprocess,sys
from pathlib import Path
from online import inputs
w=Path(__file__).resolve().parent
captures,z3,g3=map(lambda s:Path(s).resolve(),sys.argv[1:4])
decl,bases,goals=inputs(captures)
with (w/'intersections.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['previous','current','common','native','g3_confirmation'])
 for i,b in enumerate(bases):
  for j in range(i):
   if goals[i]!=goals[j]:continue
   shared=set(b)&set(bases[j])
   script=decl+'\n'.join('(assert '+c+')' for c in b if c in shared)+'\n(assert '+goals[i]+')\n(check-sat)\n'
   def query(exe):
    try:r=subprocess.run([exe,'-in'],input=script,capture_output=True,text=True,timeout=2,check=True)
    except subprocess.TimeoutExpired:return 'timeout'
    assert r.stdout.strip() in ('sat','unsat','unknown') and not r.stderr,r
    return r.stdout.strip()
   native=query(z3);g=query(g3) if native=='unsat' else ''
   out.writerow([j+1,i+1,len(shared),native,g]);f.flush()
