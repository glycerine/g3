"""Compare fresh, scoped and shared-prefix replays of the 28 ordered Flash obligations."""
import argparse,collections,csv,os,statistics,subprocess,tempfile,time
from pathlib import Path
from bases import parse,expand,conjuncts

def smt(term):return term if isinstance(term,str) else '('+' '.join(map(smt,term))+')'

def inputs(captures):
    prelude={};signatures={};bases=[];goals=[]
    for src in sorted(captures.glob('batch-*.smt2')):
        cmds=parse(src.read_text())
        for cmd in cmds:
            if cmd[0].startswith('declare'):
                if cmd[0]=='declare-fun':
                    assert signatures.setdefault(cmd[1],cmd)==cmd
                prelude[cmd]=True
        base,goal=[expand(cmd[1],{}) for cmd in cmds if cmd[0]=='assert']
        bases.append(list(dict.fromkeys(map(smt,conjuncts(base)))));goals.append(smt(goal))
    declarations='\n'.join(map(smt,sorted(prelude,key=lambda c:(c[0]=='declare-fun',smt(c)))))+'\n'
    return declarations,bases,goals

def script(declarations,bases,goals,mode):
    lines=[];counts=collections.Counter()
    def emit(row):lines.append(row)
    def push():emit('(push 1)');counts['pushes']+=1
    def pop():emit('(pop 1)')
    def premises(rows):
        if rows:
            emit('(assert (and '+' '.join(rows)+'))')
            counts['premises']+=len(rows)
    def query(i):
        push();emit('(assert '+goals[i]+')');emit('(check-sat)');pop()
    emit(declarations)
    history=collections.Counter()
    groups=[]
    width=int(mode.split('-')[-1])
    for i,base in enumerate(bases):
        active=set(base)
        prefix=0
        while prefix<len(groups) and all(c in active for c in groups[prefix]):
            prefix+=1
        for group in groups[prefix:]:pop()
        del groups[prefix:]
        retained={c for group in groups for c in group}
        pending=[c for c in base if c not in retained]
        # Stable sorting only uses occurrence counts from preceding batches.
        pending.sort(key=lambda c:-history[c])
        split=sum(history[c]>0 for c in pending)
        for start in range(0,split,width):
            chunk=pending[start:min(split,start+width)]
            push();premises(chunk);groups.append(chunk)
        push();premises(pending[split:]);query(i);pop()
        history.update(base)
    for group in groups:pop()
    if mode.startswith('flat'):
        # Flatten the logical incremental stream into independent action scopes.
        stack=[];flat=[declarations];counts.clear()
        for line in lines[1:]:
            if line=='(push 1)':stack.append([])
            elif line=='(pop 1)':stack.pop()
            elif line=='(check-sat)':
                for level in stack:
                    flat.append('(push 1)');counts['pushes']+=1
                    flat.extend(level)
                flat.extend([line]+['(pop 1)']*len(stack))
            else:stack[-1].append(line)
        # The final goal belongs to the innermost level in each case.
        counts['premises']=sum(map(len,bases))
        lines=flat
    return '\n'.join(lines)+'\n',counts

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for key in ('captures','g3','z3','perf','output'):ap.add_argument('--'+key,type=Path,required=True)
    ap.add_argument('--cpu',required=True);ap.add_argument('--rounds',type=int,default=5)
    a=ap.parse_args();args=inputs(a.captures);expected=b'unsat\n'*len(args[1])
    with tempfile.TemporaryDirectory() as t,a.output.open('x',newline='') as out:
        w=Path(t);writer=csv.writer(out);writer.writerow('round engine mode premises pushes instructions cycles milliseconds'.split());jobs=[]
        for mode in ('flat-8','online-8','flat-32','online-32'):
            text,counts=script(*args,mode);file=w/(mode+'.smt2');file.write_text(text)
            jobs+=[(e,exe,file,counts) for e,exe in [('g3',a.g3),('z3',a.z3)]]
        for i in range(a.rounds):
            for e,exe,file,counts in jobs[i%len(jobs):]+jobs[:i%len(jobs)]:
                cmd=['taskset','-c',a.cpu,a.perf,'stat','-x,','-o',w/'counts','-e','instructions:u,cycles:u','--',exe.resolve(),file]
                start=time.monotonic();r=subprocess.run(cmd,env=dict(os.environ,GOMAXPROCS='1'),capture_output=True,timeout=120)
                ms=(time.monotonic()-start)*1000
                assert (r.returncode,r.stdout,r.stderr)==(0,expected,b''),(e,file,r.stdout[:150],r.stderr[:150])
                hardware={r[2]:int(r[0]) for r in csv.reader((w/'counts').read_text().splitlines()) if len(r)>4 and float(r[4])==100}
                writer.writerow((i,e,file.stem,counts['premises'],counts['pushes'],hardware['instructions:u'],hardware['cycles:u'],ms));out.flush()
if __name__=='__main__':main()
