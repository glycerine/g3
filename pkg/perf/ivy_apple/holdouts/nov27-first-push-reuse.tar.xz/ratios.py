"""Summarize within-round instruction and elapsed ratios against bounded-width g3."""
import csv,collections as c,statistics as s,sys
for name in sys.argv[1:]:
 d=c.defaultdict(lambda:c.defaultdict(dict))
 for r in csv.DictReader(open(name)):d[r['case']][r['engine']][r['round']]=r
 for case,engines in d.items():
  base=engines['base']
  for e,x in engines.items():
   ids=set(x)&set(base)
   if e=='base' or not ids:continue
   print(case,e,len(ids),*[round(s.median(100*(float(x[i][k])/float(base[i][k])-1) for i in ids),2) for k in ('instructions','milliseconds')])
