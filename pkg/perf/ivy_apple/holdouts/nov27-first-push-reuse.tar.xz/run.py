from pathlib import Path
import subprocess,os,sys,csv,time
w=Path(__file__).resolve().parent;p=Path('/tmp/g3-ivy-pgo');ex=Path('/home/jaten/ivy/ivy-lang-examples')
env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include'))
stem,cpu,n,enames,*cases=sys.argv[1:];engines=enames.split(',')
codes={r['spec']:int(r['exit']) for f in (p/'survey').glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
with (w/(stem+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('case round engine instructions cycles milliseconds'.split())
 for name in cases:
  idx=(p/'prior-gaps.txt').read_text().splitlines().index(name)+1;ref=p/'survey'/str(idx)/'1'/'native';expected=codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()
  for i in range(int(n)):
   offset=i%len(engines)
   for e in engines[offset:]+engines[:offset]:
    env['FIRST_PASS_TRIAL']=e;exe=p/'blendscope' if e=='base' else w/'ordinary';tmp=w/(stem+'.stat');cmd=['taskset','-c',cpu,'/usr/lib/linux-tools/6.17.0-35-generic/perf','stat','-x,','-o',tmp,'-e','instructions:u,cycles:u','--',exe,ex/name]
    t=time.monotonic();r=subprocess.run(cmd,cwd=w,env=env,capture_output=True,timeout=120);ms=1000*(time.monotonic()-t)
    err=r.stderr
    if e=='count':
     lines=err.splitlines(keepends=True);(w/(name.replace('/','_')+'.matches')).write_bytes(b''.join(x for x in lines if x.startswith(b'MATCH ')));err=b''.join(x for x in lines if not x.startswith(b'MATCH '))
    assert (r.returncode,r.stdout,err)==expected,(e,name,r.returncode,err[-200:])
    hw={x[2]:int(x[0]) for x in csv.reader(tmp.read_text().splitlines()) if len(x)>4 and float(x[4])==100}
    out.writerow([name,i,e,hw['instructions:u'],hw['cycles:u'],ms]);f.flush()
