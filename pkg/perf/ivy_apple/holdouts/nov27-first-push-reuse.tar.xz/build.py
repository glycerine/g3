"""Build a one-process experiment that varies the first physical push only."""
from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);name=sys.argv[3]
ov={}
for src in ['smt_kernel.go','smt_asserted_driver.go']:
 f=p/'smtcore'/src;s=f.read_text()
 if src=='smt_kernel.go':
  s=s.replace('"runtime"','"runtime"\n"os"').replace('simplifyInitialPushOnce   bool','trialPass string\n simplifyInitialPushOnce bool').replace('k.simplifyInitialPushOnce = false','k.trialPass=os.Getenv("FIRST_PASS_TRIAL");defer func(){k.trialPass=""}();k.simplifyInitialPushOnce = false')
 else:
  key='proceed, canceled, err := k.invokeAssertedPass(pass)'
  assert s.count(key)==1
  s=s.replace(key,'''switch pass {
  case assertedPropagate: if k.trialPass=="prop" || k.trialPass=="both" || k.trialPass=="light"{continue}
  case assertedBVSharing:
   if k.trialPass=="bv" || k.trialPass=="both" || k.trialPass=="light"{continue}
   if k.trialPass=="reduce"{pass=assertedReduce}
  case assertedNNF: if k.trialPass=="light" || k.trialPass=="nnf"{continue}
  }
  '''+key)
 dst=w/(name+'-'+src);dst.write_text(s);ov[str(f)]=str(dst)
o=w/(name+'.json');o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/name,'./cmd/goivy_check'],cwd=front,check=True)
