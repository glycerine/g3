"""Sum work within each run, then take three-run medians."""
from collections import defaultdict
from pathlib import Path
import csv,statistics,sys
p=Path(sys.argv[1])
runs=defaultdict(lambda:defaultdict(lambda:[0,0,0]))
keys=defaultdict(set)
for r in csv.DictReader((p/'stages.csv').open()):
    case=int(r['case']);engine=r['engine'];rep=int(r['round'])
    batch=int(r['batch']);goal=int(r['goal']);phase=r['phase']
    # A pre-push proof can postpone the first physical push until a later goal.
    stage=(batch,0 if phase=='push' else goal,phase)
    keys[case].add(stage)
    counts=[int(r[k]) for k in ('instructions','old_witness','extra_witness')]
    for k in (stage,('all',),(phase,)):
        entry=runs[case,engine,rep][k]
        for i,n in enumerate(counts):entry[i]+=n
with (p/'summary.csv').open('w') as f,(p/'ranked.csv').open('w') as g:
    totals=csv.writer(f);ranked=csv.writer(g)
    totals.writerow(['case','phase','base','native','wide','wide_minus_base','old_witness','extra_witness'])
    ranked.writerow(['case','batch','goal','phase','base','native','gap','wide','old_witness','extra_witness'])
    for case in sorted(keys):
        def metrics(engine,k):
            samples=[]
            for i in range(3):
                assert (case,engine,i) in runs
                samples.append(runs[case,engine,i].get(k,[0,0,0]))
            return [statistics.median(x) for x in zip(*samples)]
        def values(k):
            return metrics('base',k)[0],metrics('native',k)[0],*metrics('wide',k)
        for phase in ('all','push','early','check'):
            a,b,c,u,v=values((phase,))
            totals.writerow([case,phase,a,b,c,c-a,u,v])
        rows=[]
        for k in keys[case]:
            a,b,c,u,v=values(k)
            rows.append((case,*k,a,b,a-b,c,u,v))
        ranked.writerows(sorted(rows,key=lambda r:(-r[6],r[1:4])))
