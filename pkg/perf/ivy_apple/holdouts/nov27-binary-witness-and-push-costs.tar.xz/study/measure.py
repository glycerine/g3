"""Run from g3/pkg at 14a4f46e1. Uses the adjacent study's stage counters."""
from pathlib import Path
import csv, json, os, subprocess, tarfile, tempfile, sys
p=Path.cwd()
front=Path(os.environ['GOIVY_FRONTEND']).resolve()
ref=Path(os.environ['NNF_REFERENCE'])
examples=Path(os.environ['IVY_EXAMPLES']).absolute()
names=(ref/'compat.txt').read_text().splitlines()
cases=[6,8,4,3,2,227]
with (ref/'ranking.csv').open() as f:
    codes={r['case']:int(r['exit']) for r in csv.DictReader(f)}
with tempfile.TemporaryDirectory() as temp:
    d=Path(temp)
    with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as archive:
        archive.extractall(d,filter='data')
    study=d/'study'
    plan=json.loads((study/'plans/linked-z3.json').read_text())
    mapping={str(front/path):str(study/'sources'/source) for _,path,source in plan['sources']}
    env=dict(os.environ,GOCACHE=str(d/'cache'),GOTMPDIR=temp,TMPDIR=temp)
    engines=os.environ.get('ENGINES','base,native,wide').split(',')
    for engine in engines:
        overlay=dict(mapping)
        if engine in ('wide','first','census'):
            target=p/'smtcore/smt_model_checker.go'
            code=target.read_text()
            key='var chooser *SMTModelChecker'
            code=code.replace('tryRepeatedBinding := false','tryRepeatedBinding := false\n var allowWide bool')
            code=code.replace(key,'''allowWide = auxiliary.config.CheckUninterpretedModelTables && !auxiliary.config.CertifyBoundedModelTables &&
                    flat == quantifier && count == 2 && c.manager.ResourceLimit().Limit == 0
                '''+key)
            key='if tryRepeatedBinding && useInverse && *remaining == 1 {'
            assert code.count(key)==1
            code=code.replace(key,'''if (tryRepeatedBinding || allowWide) && useInverse && *remaining == 1 {
                original := bindings[0]''')
            key='generation, err = c.tryRepeatedAuxiliaryBinding(model, quantifier, raw, bindings, generation)'
            code=code.replace(key,key+'''
                if original != bindings[0] {
                    println("WITNESS", tryRepeatedBinding)
                }''')
            if engine=='first':
                code=code.replace('original := bindings[0]', 'original := bindings[1]').replace('original != bindings[0]', 'original != bindings[1]')
            if engine=='census':
                code=code.replace('if original != bindings[0]', 'bindings[0] = original\n generation = originalGeneration\n if original != bindings[0]').replace('original := bindings[0]','original := bindings[0]\n originalGeneration := generation')
            source=d/'wide.go';source.write_text(code);overlay[str(target)]=str(source)
            if engine in ('first','census'):
                helper=p/'smtcore/smt_model_checker_repeated_binding.go'
                h=helper.read_text()
                if engine=='first':
                    for a,b in [('quantifier, 0, raw[1]', 'quantifier, 1, raw[0]'),('term != bindings[1]', 'term != bindings[0]'),('quantifier, raw[1]', 'quantifier, raw[0]'),('quantifier, 1, raw[1]', 'quantifier, 0, raw[0]'),('bindings[0] = term','bindings[1] = term')]:
                        assert h.count(a)==1
                        h=h.replace(a,b)
                else:
                    for cond,label in [('len(raw) != 2 || raw[0] == raw[1]', 'equal-value'),('err != nil || first != second','sort'),('err != nil || !found || term != bindings[1]','inverse'),('err != nil || !falsified','body')]:
                        key=cond+' {'
                        assert h.count(key)==1
                        h=h.replace(key,key+'\n println("CENSUS", "'+label+'")')
                    h=h.replace('bindings[0] = term','println("CENSUS", "accepted")\n bindings[0] = term')
                source=d/'helper.go';source.write_text(h);overlay[str(helper)]=str(source)
        config=d/'overlay.json';config.write_text(json.dumps({'Replace':overlay}))
        native=engine=='native'
        subprocess.run(['go','build','-tags','xtrace_off,classic_z3' if native else 'xtrace_off',
                        '-pgo=off' if native else '-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),
                        '-mod=readonly','-buildvcs=false','-modfile',os.environ['GOIVY_MODFILE'],
                        '-overlay',config,'-o',d/engine,'./cmd/goivy_check'],cwd=front,env=env,check=True)
    if os.environ.get('SAMPLE_PUSH'):
        subprocess.run([sys.executable,Path(__file__).with_name('sample.py'),d/'base'],check=True)
    with (Path(os.environ['RESULTS'])/'stages.csv').open('w') as f:
        out=csv.writer(f);out.writerow(['case','round','engine','batch','goal','phase','instructions','old_witness','extra_witness'])
        for case in cases:
            spec=names[case-1];gold=ref/'compat'/str(case)/'1/native'
            for i in range(int(os.environ.get("ROUNDS","3"))):
                for engine in engines[i%len(engines):]+engines[:i%len(engines)]:
                    r=subprocess.run(['taskset','-c',os.environ['CPU'],d/engine,examples/spec],cwd=d,capture_output=True,
                        env=dict(env,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),timeout=240)
                    stderr=bytearray();rows=[];witness=[0,0];events=[]
                    for line in r.stderr.splitlines(keepends=True):
                        if line.startswith(b'CENSUS '):
                            events.append(line.split()[1].decode())
                        elif line.startswith(b'WITNESS '):
                            witness[int(line.split()[1]==b'false')]+=1
                        elif line.startswith(b'STAGE-COUNT '):
                            _,batch,goal,phase,count,_,enabled,running,_=line.decode().split()
                            assert int(count)>0 and enabled==running
                            rows.append([case,i,engine,batch,goal,phase,count,*witness]);witness=[0,0]
                            if events:
                                with (Path(os.environ['RESULTS'])/'census.csv').open('a') as cf:
                                    csv.writer(cf).writerows((case,i,batch,goal,phase,e) for e in events)
                                events=[]
                        else:stderr.extend(line)
                    def expected(name):
                        return (gold/name).read_bytes().replace(b'/home/jaten/ivy/ivy-lang-examples/',os.fsencode(examples)+b'/')
                    assert rows and not events and witness==[0,0] and (r.returncode,r.stdout,stderr)==(codes[spec],expected('stdout'),expected('stderr')),(case,engine,r.returncode,stderr[-500:])
                    out.writerows(rows);f.flush()
            print('verified',case,flush=True)
