"""Profile release Go push stacks. Pass the g3 stage binary built by measure.py."""
from pathlib import Path
from collections import Counter
import csv, os, subprocess, sys, tempfile
exe=Path(sys.argv[1]).resolve()
ref=Path(os.environ['NNF_REFERENCE']);examples=Path(os.environ['IVY_EXAMPLES'])
names=(ref/'compat.txt').read_text().splitlines()
with (ref/'ranking.csv').open() as f:codes={r['case']:int(r['exit']) for r in csv.DictReader(f)}
perf=os.environ.get('PERF','perf')
with tempfile.TemporaryDirectory() as td,(Path(os.environ['RESULTS'])/'push-samples.csv').open('w') as out:
    w=csv.writer(out);w.writerow(['case','attribution','symbol','samples']);d=Path(td)
    for case in (6,2):
        spec=names[case-1];gold=ref/'compat'/str(case)/'1/native';leaf=Counter();inclusive=Counter()
        for i in range(3):
            data=d/('sample'+str(i))
            r=subprocess.run(['taskset','-c',os.environ['CPU'],perf,'record','-q','--no-buildid','-o',data,
                              '-e','instructions:u','-c','97003','--call-graph','fp','--',exe,examples/spec],
                             capture_output=True,cwd=d,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')))
            stderr=b''.join(l for l in r.stderr.splitlines(keepends=True) if not l.startswith(b'STAGE-COUNT '))
            assert (r.returncode,r.stdout,stderr)==(codes[spec],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),(case,stderr[-500:])
            raw=subprocess.check_output([perf,'script','-i',data,'-F','ip,sym'],text=True)
            for event in raw.split('\n\n'):
                stack=[s.strip().split(maxsplit=1)[1].rsplit('+0x',1)[0] for s in event.splitlines() if len(s.strip().split(maxsplit=1))==2]
                if not any(s.endswith('(*SMTKernel).internalizePushBase') for s in stack):continue
                leaf[stack[0]]+=1;inclusive.update(set(stack))
            data.unlink()
        assert sum(leaf.values())>100,(case,leaf)
        for kind,c in [('leaf',leaf),('inclusive',inclusive)]:
            for symbol,n in c.most_common():w.writerow([case,kind,symbol,n])
        out.flush()
