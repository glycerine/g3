"""Summarize each binder direction against the baseline from its own rotations."""
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median
import csv, sys
p=Path(sys.argv[1])
with (p/'directions.csv').open('w') as f:
    out=csv.writer(f)
    out.writerow(['case','direction','batch','goal','interval','base','trial','change'])
    for group,direction in [('final','wide'),('first','first')]:
        costs=defaultdict(Counter); hits=set(); cases=set()
        for r in csv.DictReader((p/group/'stages.csv').open()):
            case=int(r['case']);batch=int(r['batch']);goal=int(r['goal']);phase=r['phase']
            engine=r['engine'];i=int(r['round'])
            if engine not in ('base',direction):continue
            costs[case,engine,i][batch,goal,phase]+=int(r['instructions']);cases.add(case)
            if int(r['extra_witness'])+int(r['old_witness']):hits.add((case,batch,goal))
        def row(case,batch,goal,label,keep):
            def typical(engine):
                runs=[]
                for i in range(3):
                    assert (case,engine,i) in costs
                    runs.append(sum(n for k,n in costs[case,engine,i].items() if keep(*k)))
                return median(runs)
            base=typical('base');trial=typical(direction)
            out.writerow([case,direction,batch,goal,label,base,trial,trial-base])
        for case in sorted(cases):row(case,0,0,'all',lambda b,g,ph:True)
        for case,batch,goal in sorted(hits):
            row(case,batch,goal,'check',lambda b,g,ph:b==batch and g==goal and ph=='check')
            row(case,batch,goal,'rest of batch after goal',lambda b,g,ph:b==batch and g>goal)
            row(case,batch,goal,'entire batch',lambda b,g,ph:b==batch)
