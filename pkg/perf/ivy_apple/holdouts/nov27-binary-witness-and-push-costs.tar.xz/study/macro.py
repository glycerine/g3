"""Price repeated successful macro lookups inside each individual push."""
from pathlib import Path
import csv,json,os,subprocess,tarfile,tempfile
p=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve()
ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES'])
names=(ref/'compat.txt').read_text().splitlines()
with (ref/'ranking.csv').open() as f:codes={r['case']:int(r['exit']) for r in csv.DictReader(f)}
with tempfile.TemporaryDirectory() as temp:
    d=Path(temp)
    with tarfile.open(p/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as archive:
        archive.extractall(d,filter='data')
    study=d/'study';plan=json.loads((study/'plans/linked-z3.json').read_text())
    rep={str(front/path):str(study/'sources'/src) for _,path,src in plan['sources']}
    def update(target,fn):
        s=Path(rep.get(str(target),target)).read_text();source=d/target.name
        source.write_text(fn(s));rep[str(target)]=str(source)
    def bridge(s):
        k='stop:=startStage(batch,index+1);z3solver.Push();'
        assert s.count(k)==1
        return s.replace(k,'measurePush = true;'+k+'measurePush = false;')
    def timer(s):
        s=s.replace('import (','import ("github.com/glycerine/g3/pkg/ast/macros";')
        k='return func(phase string) {'
        assert s.count(k)==1
        return s.replace(k,'''if measurePush {
            macros.StartMacroStudy(func()uint64 {return ivyThreadRead(fd)[0]})
        }
        '''+k+'''
        if phase=="push" {
            calls,cost := macros.EndMacroStudy()
            fmt.Fprintln(os.Stderr,"MACRO",batch,goal,calls[0],calls[1],cost[0],cost[1])
        }''')+'\nvar measurePush bool\n'
    def expander(s):
        k='substitution, err := rewriter.NewVarSubstitution(m, true)'
        assert s.count(k)==1
        s=s.replace(k,'''if studyClock != nil {
            k:=studyKey{c.owner,term,c.owner.entries[i].quantifier}
            bucket:=0
            if studySeen[k] {bucket=1} else {studySeen[k]=true}
            start:=studyClock()
            defer func(){n:=studyClock();studyCost[bucket]+=n-start;studyCount[bucket]++}()
        }
        '''+k)
        return s+'''
type studyKey struct { owner *Manager; term, definition ast.ASTHandle }
var studyClock func()uint64
var studySeen map[studyKey]bool
var studyCount,studyCost [2]uint64
func StartMacroStudy(read func()uint64) {
    studyClock=read;studySeen=make(map[studyKey]bool);studyCount=[2]uint64{};studyCost=[2]uint64{}
}
func EndMacroStudy()([2]uint64,[2]uint64) {
    studyClock=nil;studySeen=nil;return studyCount,studyCost
}
'''
    update(front/'z3bridge_solver_model.go',bridge);update(front/'phase_observer_trial.go',timer)
    update(p/'ast/macros/macro_expander.go',expander)
    overlay=d/'overlay.json';overlay.write_text(json.dumps({'Replace':rep}))
    env=dict(os.environ,GOCACHE=str(d/'cache'),GOTMPDIR=temp,TMPDIR=temp)
    subprocess.run(['go','build','-mod=readonly','-buildvcs=false','-tags','xtrace_off','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-modfile',os.environ['GOIVY_MODFILE'],'-overlay',overlay,'-o',d/'study-bin','./cmd/goivy_check'],cwd=front,env=env,check=True)
    with (Path(os.environ['RESULTS'])/'macro.csv').open('w') as f:
        out=csv.writer(f);out.writerow(['case','round','batch','goal','first_calls','repeat_calls','first_ins','repeat_ins'])
        for case in (6,2,4,3,8,227):
            casepath=names[case-1];gold=ref/'compat'/str(case)/'1/native'
            for i in range(3):
                r=subprocess.run(['taskset','-c',os.environ['CPU'],d/'study-bin',ex/casepath],cwd=d,capture_output=True,timeout=240,env=dict(env,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
                rows=[];stderr=bytearray();pushes=0
                for line in r.stderr.splitlines(keepends=True):
                    if line.startswith(b'MACRO '):rows.append(list(map(int,line.split()[1:])))
                    elif line.startswith(b'STAGE-COUNT '):
                        _,_,_,phase,_,_,enabled,running,_=line.split()
                        assert enabled==running
                        pushes+=phase==b'push'
                    else:stderr.extend(line)
                assert len(rows)==pushes and pushes and (r.returncode,r.stdout,stderr)==(codes[casepath],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes())
                out.writerows([case,i,*row] for row in rows);f.flush()
