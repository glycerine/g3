from guarded_live import *
import guarded_live as gl
d=w/'guarded-nested';d.mkdir(exist_ok=True)
def edits(mode):
 if mode=='control':return{}
 both=mode.endswith('-both');ed=gl.edits('both'if both else'goal');s=ed[q]
 s=once(s,'gs,found,err:=c.definingConjuncts(g,1);if err!=nil||!found{return false,err}', '''var gs []ast.ASTHandle
 cursor:=body
 for {
  if !c.spend(1){return false,nil}
  hd,e:=m.NodeHeader(cursor);if e!=nil{return false,e}
  if hd.Kind!=ast.ASTApp||hd.Family!=m.BasicFamilyID()||hd.DeclKind!=ast.ASTOpImplies||hd.NumArgs!=2{break}
  g,e=m.GetArg(cursor,0);if e!=nil{return false,e}
  leaves,found,e:=c.definingConjuncts(g,1);if e!=nil{return false,e};if found{gs=append(gs,leaves...)}
  cursor,e=m.GetArg(cursor,1);if e!=nil{return false,e}
 }
 if len(gs)==0{return false,nil}''')
 if mode.startswith('defined'):
  # Keep the result source ordering by substituting into the original body.
  pass
 if mode.startswith('flatten'):
  # Equivalent transformation only after validating the guard. Flatten chains
  # of implications, leaving all necessary antecedents in left-to-right order.
  s=once(s,'if e=c.sub.Substitute(body,', '''var guards []ast.ASTHandle;cursor:=body
  for { hd,e:=m.NodeHeader(cursor);if e!=nil{return false,e};if hd.Kind!=ast.ASTApp||hd.Family!=m.BasicFamilyID()||hd.DeclKind!=ast.ASTOpImplies||hd.NumArgs!=2{break};head,e:=m.GetArg(cursor,0);if e!=nil{return false,e};guards=append(guards,head);cursor,e=m.GetArg(cursor,1);if e!=nil{return false,e} }
  flat,e:=m.MkAndArray(guards);if e!=nil{return false,e};newBody,e:=m.MkImplies(flat,cursor);if e!=nil{return false,e}
  keep,e:=m.NewRef(newBody);if e!=nil{return false,e};defer func(){if ce:=m.DelRef(&keep);ce!=nil {panic(ce)}}()
  if e=c.sub.Substitute(newBody,''')
 ed[q]=s;return ed
def make(v):
 od=d/v;b=build(od/'checker',o=overlay(od/'overlay',edits(v)));return b
if __name__=='__main__':
 vs=['defined','defined-both','flatten'];bs={'control':gl.d/'control/checker/goivy_check'}
 with ThreadPoolExecutor(3)as e:bs.update(dict(zip(vs,e.map(make,vs))))
 bs['native']=w/'frontend-controls/paired-build/native/goivy_check';nm='jea/hermes_rmw_o3.ivy';ref=gl.d/'ordinary-11/1-native'
 jobs=[(4,'ordinary',nm,'',0,5,ref),(11,'ordinary',nm,'',0,5,ref),(18,'testing','jea/hermes_rmw_o3_testing.ivy','',0,2,w/'extended-phases/long/1/1/native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native')]
 for cp,n in zip([0,2,6,8,9,12,14],['tlb','hybrid_reliable_broadcast_cisa','raftok','toy-consensus','rfn2','flash2','dramc_nb2']):
  sp,iso,_,f,u=CASES[n];rf=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'));jobs.append((cp,n,sp,iso,int(bool(f or u)),2,rf))
 gl.d=d
 with ThreadPoolExecutor(len(jobs))as ex:list(ex.map(lambda j:gl.measure_job(j,bs),jobs))
