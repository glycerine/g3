from study import *
from panel import CASES,measure,EVENTS
from types import SimpleNamespace
d=w/'guarded-live';d.mkdir(exist_ok=True)
q=pkg/'qe/existential_definitions.go';g=ivy.resolve()/'z3bridge_solver_model.go'
base=q.read_text()
addition="""
// A one-variable universal with x=t as a required conjunct of its guard
// can only fail at t. Substitution preserves the conditional, including
// every other conjunct, and does not require enumerating the sort.
func (c *definitionRewriter) guarded(q, body ast.ASTHandle, out ast.ASTRef) (bool,error) {
 m:=c.m
 b,err:=m.NodeHeader(body);if err!=nil||b.Kind!=ast.ASTApp||b.Family!=m.BasicFamilyID()||b.DeclKind!=ast.ASTOpImplies||b.NumArgs!=2{return false,err}
 n,err:=m.GetNumDeclarations(q);if err!=nil||n!=1{return false,err}
 g,err:=m.GetArg(body,0);if err!=nil{return false,err}
 gs,found,err:=c.definingConjuncts(g,1);if err!=nil||!found{return false,err}
 for _,cond:=range gs{
  hd,e:=m.NodeHeader(cond);if e!=nil{return false,e};if hd.Kind!=ast.ASTApp||hd.Family!=m.BasicFamilyID()||hd.DeclKind!=ast.ASTOpEq||hd.NumArgs!=2{continue}
  for i:=uint32(0);i<2;i++ {
   x,e:=m.GetArg(cond,i);if e!=nil{return false,e};h,e:=m.NodeHeader(x);if e!=nil{return false,e};if h.Kind!=ast.ASTVar{continue};idx,e:=m.GetVarIndex(x);if e!=nil{return false,e};if idx!=0{continue}
   value,e:=m.GetArg(cond,1-i);if e!=nil{return false,e};ground,e:=m.IsGround(value);if e!=nil{return false,e};if !ground{continue}
   nested,e:=m.HasQuantifiers(body);if e!=nil||nested{return false,e}
   free,e:=m.HasFreeVars(q);if e!=nil||free{return false,e}
   if c.sub==nil{c.sub,e=rewriter.NewVarSubstitution(m,true);if e!=nil{return false,e}}
   if e=c.sub.Substitute(body,[]ast.ASTHandle{value},out);e!=nil{return false,e}
   c.changed=true
   return true,nil
  }
 }
 return false,nil
}
"""
def edits(mode):
 if mode=='control':return{}
 s=base.replace('der              *EqualityDER','der              *EqualityDER\nsub *rewriter.VarSubstitution')
 s=once(s,'if cfg.der != nil {','if cfg.sub!=nil{err=errors.Join(err,cfg.sub.Close())};if cfg.der != nil {')
 s=once(s,'if err != nil || all {\n\t\treturn false, err\n\t}', 'if err!=nil{return false,err};if all{return c.guarded(q,body,out)}')
 ed={q:s+addition}
 if mode=='both':
  s=g.read_text();i=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('\n}',i)+2;sub=s[i:j];sub=sub.replace('z3solver.Assert(zc)','if !xtracer.Enabled || xtracer.Suppressed{zc=z3solver.SimplifyVerificationCondition(zc)};z3solver.Assert(zc)')
  ed[g]=s[:i]+sub+s[j:]
 return ed
def make(v):
 od=d/v;ov=overlay(od/'overlay',edits(v));b=build(od/'checker',o=ov);return b
def measure_job(j,bins):
 cpu,name,spec,iso,ex,rounds,ref=j
 od=d/(name+'-'+str(cpu));od.mkdir(exist_ok=True);cfg=SimpleNamespace(cpu=cpu,spec=examples/spec,isolate=iso,perf=perf)
 vs=list(bins)
 with(od/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow(['case','round','engine','exit','match','wall','user','sys','rss',*EVENTS])
  for r in range(rounds):
   for v in vs[r%len(vs):]+vs[:r%len(vs)]:
    td=od/f'{r+1}-{v}';rc,t,c=measure(bins[v],cfg,td,ex,100)
    if not ref:ref=td
    ok=rc==ex and all((td/k).read_bytes()==(ref/k).read_bytes()for k in ['stdout','stderr']);wr.writerow([name,r+1,v,rc,int(ok),*t,*c]);f.flush();assert ok,(name,v,rc,td,ref)
    print(name,cpu,r+1,v,round(int(c[0])/1e9,3),flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bs=dict(zip(['control','goal','both'],ex.map(make,['control','goal','both'])))
 bs['native']=w/'chained-release-controls/native/goivy_check'
 if not bs['native'].exists():bs['native']=build(d/'native',en='native')
 nm='jea/hermes_rmw_o3.ivy'
 jobs=[(4,'ordinary',nm,'',0,5,None),(11,'ordinary',nm,'',0,4,None),(18,'testing','jea/hermes_rmw_o3_testing.ivy','',0,2,w/'extended-phases/long/1/1/native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native')]
 for cpu,n in zip([0,2,6,8,9,12,14],['tlb','hybrid_reliable_broadcast_cisa','raftok','toy-consensus','rfn2','flash2','dramc_nb2']):
  sp,iso,_,f,u=CASES[n];ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'));jobs.append((cpu,n,sp,iso,int(bool(f or u)),3,ref))
 with ThreadPoolExecutor(len(jobs))as ex:list(ex.map(lambda j:measure_job(j,bs),jobs))
