from study import *
from guarded_live import edits,q,g
import corpus_phases as cp, current_verifier_stacks as st
from verification_frontier import reference
from collections import Counter
d=w/'guarded-live-audit';d.mkdir(exist_ok=True)
nm='jea/hermes_rmw_o3.ivy';ref=reference(nm)
def audit():
 cp.root=d/'phases';ov=cp.instrumentation();ls=json.loads(ov.read_text())['Replace']
 base={Path(k).resolve():Path(v).read_text()for k,v in ls.items()};v=base[g]
 v=once(v,'zCond = z3solver.SimplifyVerificationCondition(zCond)','''before:=zCond
 zCond = z3solver.SimplifyVerificationCondition(zCond)
 fmt.Fprintln(os.Stderr,"GUARD-AUDIT",obs.batch,obs.goal,!before.Equal(zCond))
 if (obs.batch==27||obs.batch==29)&&obs.goal==10 {fmt.Fprintln(os.Stderr,"GUARD-SOURCE",obs.batch,obs.goal,before.String(),"=>",zCond.String())}''')
 # Dedicated trace file keeps multiline formula output out of verifier diagnostics.
 v=v.replace('fmt.Fprintln(os.Stderr, "GUARD-SOURCE"', 'fmt.Fprintln(os.Stderr, "GUARD-SOURCE"').replace('fmt.Fprintln(os.Stderr,"GUARD-SOURCE",obs.batch,obs.goal,before.String(),"=>",zCond.String())','if e:=os.WriteFile(fmt.Sprintf("goal-%d-%d.txt",obs.batch,obs.goal),[]byte(before.String()+"\\n-----\\n"+zCond.String()),0600);e!=nil{panic(e)}')
 if '"os"'not in v[:v.index(')')]:v=once(v,'import (','import (\n"os"')
 base[g]=v
 def do(j):
  cpu,mode=j;src={**base,**{k:z for k,z in edits(mode).items()if k!=g}};od=d/mode;b=build(od/'checker',o=overlay(od/'overlay',src))
  p=subprocess.run(['taskset','-c',str(cpu),b,examples/nm],cwd=od,env=dict(env,GOMAXPROCS='1'),capture_output=True,timeout=240)
  e=b''.join(y for y in p.stderr.splitlines(keepends=True)if not y.startswith((b'VC-PHASE',b'GUARD-AUDIT')))
  assert p.returncode==0 and p.stdout==(ref/'stdout').read_bytes() and e==(ref/'stderr').read_bytes(),(mode,p.returncode,e[-180:])
  ls=p.stderr.decode().splitlines()
  (od/'raw.gz').write_bytes(gzip.compress(p.stderr,mtime=0))
  rows=[l.split()[1:]for l in ls if l.startswith('GUARD-AUDIT ')]
  print(mode,'simplified',Counter(r[2]for r in rows),flush=True)
  with(od/'goals.csv').open('w')as f:
   wr=csv.writer(f);wr.writerow(['batch','condition','changed']);wr.writerows(rows)
  with(od/'phases.csv').open('w')as f:
   wr=csv.writer(f);wr.writerow(['batch','condition','stage','result','instructions']);wr.writerows(l.split()[1:]for l in ls if l.startswith('VC-PHASE '))
 with ThreadPoolExecutor(2)as e:list(e.map(do,[(1,'control'),(3,'goal')]))
def profiles():
 st.d=d/'stacks';st.d.mkdir(exist_ok=True)
 with ThreadPoolExecutor(2)as e:list(e.map(st.lane,[('ordinary',nm,'',ref,0,6,'g3',800011),('ordinary',nm,'',ref,0,12,'native',800011)]))
if __name__=='__main__':
 with ThreadPoolExecutor(2)as e:
  fs=[e.submit(f)for f in(audit,profiles)];[f.result()for f in fs]
