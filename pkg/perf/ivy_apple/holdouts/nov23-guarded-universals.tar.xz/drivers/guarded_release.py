from study import *
from verification_frontier import reference
import guarded_live as gl,ground_release_controls as gc
d=w/'guarded-release';d.mkdir(exist_ok=True);nm='jea/hermes_rmw_o3.ivy';ref=reference(nm)
def main():
 b=build(d/'checker');bs={'g3':b,'previous':w/'guarded-nested/../guarded-live/control/checker/goivy_check','native':w/'frontend-controls/paired-build/native/goivy_check'}
 gl.d=d;gc.d=d
 def timing(cpu,name,r,sp,rf):
  run([sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',b,'--previous',bs['previous'],'--native',bs['native'],'--rounds',str(r),'--max-attempts','20','--min-idle','.95','--cpu',str(cpu),'--spec',examples/sp,'--reference',rf,'--perf',perf,'--output',d/(name+'-'+str(cpu))],stdout=subprocess.DEVNULL)
  print(name,cpu,'quiet complete',flush=True)
 with ThreadPoolExecutor(16)as e:
  fs=[e.submit(gc.corpus,b),e.submit(timing,15,'ordinary',5,nm,ref),e.submit(timing,23,'ordinary',3,nm,ref),e.submit(timing,20,'testing',3,'jea/hermes_rmw_o3_testing.ivy',w/'extended-phases/long/1/1/native'),e.submit(timing,21,'apple',3,'doc/examples/apple/ord_live.ivy',w/'apple-original-pairs/14-native')]
  for cp,n in zip([0,2,3,6,8,9,12,13,14,16],['tlb','hybrid_reliable_broadcast_cisa','cf_live','raftok','toy-consensus','rfn2','flash2','raft_no_assume_test','dramc_nb2','raft_no_assume']):
   sp,iso,_,f,u=gc.CASES[n];rf=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'));fs.append(e.submit(gl.measure_job,(cp,n,sp,iso,int(bool(f or u)),3,rf),bs))
  for f in fs:f.result()
if __name__=='__main__':main()
