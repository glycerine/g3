from ord_cores import Problem,checked
from study import *
from types import SimpleNamespace
from collections import Counter
sys.setrecursionlimit(24000)
d=w/'ordinary-hermes-hot';d.mkdir(exist_ok=True)
def source():
 od=w/'observed-phase-study/runs/hermes_rmw_o3'
 def rows(e):return {(int(r['batch']),int(r['condition'])):int(r['instructions'])for r in csv.DictReader(gzip.open(od/('1-'+e)/'phases.csv.gz','rt'))if r['stage']=='check'}
 g,n=rows('g3'),rows('native')
 ranked=sorted(((v-n.get(k,0),*k,v,n.get(k,0))for k,v in g.items()),reverse=True)
 keep=ranked[:125]
 seen={r[1]for r in keep};keep+=[next(r for r in ranked if r[1]==b)for b in sorted({r[1]for r in ranked}-seen)]
 with(d/'ranking.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('delta batch condition within_g3 within_native selected'.split());wr.writerows([*r,int(r in keep)]for r in ranked)
 return keep
def lane(job):
 cpu,rows,bins=job;cfg=SimpleNamespace(perf=perf,cpu=cpu);od=d/str(cpu);od.mkdir()
 with(od/'runs.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('batch goal route retained facts engine verdict instructions seconds conflicts instances core'.split())
  for gap,ba,go,g,n in rows:
   name=f'{ba:04}-{go:04}';path=w/'ord-holdout-capture/hermes'/(name+'.smt2.gz');p=Problem(path);rd=od/name;rd.mkdir();labels={x[0]:j for j,x in enumerate(p.pieces)}
   routes=[('core-search',p.all,True,'native'),('ordinary',None,False,'native'),('ordinary',None,False,'g3')]
   for mode,sel,mine,en in routes:
    src=p.query(sel,mine);start=time.monotonic();a,ins,txt=checked(cfg,rd,mode+'-'+en,bins[en],src,12)
    if a in ('sat','unknown'):assert mode!='ordinary' or a!='sat',(name,mode,en)
    core=''
    if mine and a=='unsat':
     cs=txt.splitlines()[1];assert cs[0]=='('and cs[-1]==')',cs;ix=sorted(labels[word]for word in cs[1:-1].split());core=' '.join(map(str,ix))
     for typ,subset in [('core',ix),('core-ground',[i for i in ix if p.pieces[i][2]==0])]:
      for k in ('native','g3') if typ=='core'else('native',):routes.append((typ,subset,False,k))
     (rd/'core.smt2.gz').write_bytes(gzip.compress(p.query(ix).encode(),mtime=0))
     hd=p.query(ix);bare=hd.replace('(push 1)\n','').replace('(set-option :smt.macro_finder true)\n','');(d/'cores'/(name+'.smt2')).write_text(bare)
     allsrc=p.query(p.all).replace('(push 1)\n','').replace('(set-option :smt.macro_finder true)\n','');(d/'inputs'/(name+'.smt2')).write_text(allsrc)
    if mode=='core':assert a in ('unsat','timeout'),(name,en,a)
    stats=dict(re.findall(r':([\w-]+)\s+(\d+)\b',txt));wr.writerow([ba,go,mode,len(sel)if sel!=None else len(p.all),len(p.all),en,a,ins,round(time.monotonic()-start,4),stats.get('conflicts',0),stats.get('quant-instantiations',0),core]);f.flush()
 print('complete',cpu,len(rows),flush=True)
if __name__=='__main__':
 keep=source();bs={'native':pkg.parent/'build/z3','g3':build(d/'g3',shell=True)}
 for t in ('cores','inputs'):(d/t).mkdir()
 cs=[0,3,6,8,10,12,18,22]
 with ThreadPoolExecutor(8)as e:list(e.map(lane,[(c,keep[j::8],bs)for j,c in enumerate(cs)]))
