from ord_cores import checked,Problem
from ord_invariants import expand
from true_ground_oracle import smt,parse
from study import *
from collections import Counter
from functools import lru_cache
from types import SimpleNamespace
out=w/'guarded-quantifiers';out.mkdir(exist_ok=True)
native=pkg.parent/'build/z3';sol=w/'ordinary-hermes-hot/g3/g3'
def headed(x,op):return isinstance(x,tuple) and x and x[0]==op
def tree(x,op):
 if headed(x,op):
  for y in x[1:]:yield from tree(y,op)
 else:yield x
def substitute(x,v,k):
 if isinstance(x,str):return k if x==v else x
 if x[0] in ('forall','exists','lambda'):
  if v in dict(x[1]):return x
  assert k not in dict(x[1])
  return (x[0],x[1],substitute(x[2],v,k))
 return tuple(substitute(y,v,k)for y in x)
def make_rewriter(mode,constants,enums,bound_names):
 def rewrite(x):
  if isinstance(x,str)or x[0]=='!':return x
  if x[0] not in ('forall','exists'):
   return tuple(rewrite(v)for v in x)
  op,vs,body=x
  if headed(body,'!'):return x
  body=rewrite(body)
  if len(vs)!=1:return(op,vs,body)
  (v,s),=vs;eqs=[]
  if 'guard'in mode:
   if op=='forall' and headed(body,'=>') and len(body)==3:eqs=list(tree(body[1],'and'))
   if op=='forall' and headed(body,'or'):
    for y in tree(body,'or'):
     if headed(y,'not') and len(y)==2:eqs.append(y[1])
     elif headed(y,'distinct') and len(y)==3:eqs.append(('=',*y[1:]))
   if op=='exists':eqs=list(tree(body,'and'))
   for y in eqs:
    if not headed(y,'=')or len(y)!=3:continue
    for a,k in ((y[1],y[2]),(y[2],y[1])):
     if a==v and k in constants and k not in bound_names:
      return substitute(body,v,k)
  if 'enum'in mode and s in enums and len(enums[s])<=2 and all(k not in bound_names for k in enums[s]):
   return ('and'if op=='forall'else'or',*(substitute(body,v,k)for k in enums[s]))
  return(op,vs,body)
 return rewrite
def bindings(x,names):
 if not isinstance(x,tuple):return
 if x and x[0]in ('forall','exists','lambda','let'):names.update(dict(x[1]))
 for y in x:bindings(y,names)
def candidates(name):
 p=Problem(w/'ord-holdout-capture/hermes'/(name+'.smt2.gz'))
 fs=parse(p.original);ds=[f for f in fs if f[0].startswith('declare-')];cs={f[1]for f in ds if f[0]=='declare-fun'and not f[2]};enums={}
 for f in ds:
  if f[0]=='declare-datatypes':
   for (s,ar),ctors in zip(f[1],f[2]):
    if ar=='0'and ctors and all(len(c)==1 for c in ctors):enums[s]=[c[0]for c in ctors];cs.update(enums[s])
 bound_names=set()
 for form in fs:bindings(form,bound_names)
 rs={};proof={}
 for scope,mode in [('all','guard'),('goal','guard'),('all','enum'),('goal','enum'),('all','guard-enum')]:
  forms=[];changes=[];cnt=0
  rewrite=make_rewriter(mode,cs,enums,bound_names)
  for i,f in enumerate(fs):
   if f[0]=='assert'and(scope=='all'or i==len(fs)-2):
    before=expand(f[1],{});after=rewrite(before)
    if before!=after:
     changes.append((f[1],after));f=('assert',after);cnt+=1
   forms.append(f)
  tag=scope+'-'+mode;rs[tag]=('\n'.join(smt(f)for f in forms)+'\n',cnt)
  if changes:
   xor=[('distinct',a,b)for a,b in changes];xor=xor[0] if len(xor)==1 else('or',*xor)
   proof[tag]='\n'.join(smt(z)for z in [*ds,('assert',xor),('check-sat',)])+'\n'
 rs['original']=(p.original,0)
 return rs,proof
def worker(job):
 cpu,names=job;d=out/str(cpu);d.mkdir(exist_ok=True);a=SimpleNamespace(perf=perf,cpu=cpu)
 with (d/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('file mode assertions_changed equivalence engine result instructions conflicts instantiations'.split())
  for name in names:
   rd=d/name;rd.mkdir(exist_ok=True);rs,proof=candidates(name)
   (rd/'rewrites.csv').write_text(''.join(t+','+str(c)+'\n'for t,(_,c)in rs.items()))
   seen={};eq={}
   for tag,src in proof.items():
    if src not in eq:
     p=subprocess.run(['taskset','-c',str(cpu),native,'-in','-smt2','-T:8'],input=src,text=True,capture_output=True)
     ans=p.stdout.strip();assert ans in ('unsat','timeout','unknown')and not p.stderr,(name,tag,ans[:180]);eq[src]=ans
     (rd/(tag+'-equiv.smt2.gz')).write_bytes(gzip.compress(src.encode(),mtime=0))
    if eq[src]!='unsat':print('unproven equivalence',name,tag,eq[src],flush=True)
   for tag in ['original','goal-guard','all-guard','goal-enum','all-enum','all-guard-enum']:
    src,n=rs[tag];ans=eq.get(proof.get(tag),'identity')
    if n==0 and tag!='original':continue
    if ans not in ('identity','unsat'):continue
    if src not in seen:
     seen[src]={}
     for en,b in [('g3',sol),('native',native)]:
      v,i,txt=checked(a,rd,tag+'-'+en,b,src,15);assert v in ('unsat','timeout','unknown'),(name,tag,en,v)
      st=dict(re.findall(r':([\w-]+)\s+(\d+)\b',txt));seen[src][en]=(v,i,st.get('conflicts',0),st.get('quant-instantiations',0))
     (rd/(tag+'.smt2.gz')).write_bytes(gzip.compress(src.encode(),mtime=0))
    for en,vs in seen[src].items():z.writerow([name,tag,n,ans,en,*vs])
    f.flush()
   print(name,[(t,n)for t,(_,n)in rs.items()],flush=True)
if __name__=='__main__':
 rank=list(csv.DictReader((w/'ordinary-hermes-hot/ranking.csv').open()));names=[f"{int(r['batch']):04}-{int(r['condition']):04}"for r in rank if r['selected']=='1']
 cpus=[0,3,6,8,10,12,18,22]
 with ThreadPoolExecutor(len(cpus))as ex:list(ex.map(worker,[(cpu,names[i::len(cpus)])for i,cpu in enumerate(cpus)]))
