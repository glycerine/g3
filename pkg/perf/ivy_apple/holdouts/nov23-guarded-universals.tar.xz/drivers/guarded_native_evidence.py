from study import *
from verification_frontier import reference
from true_ground_oracle import standard_declarations
from pending_core_recovery import qualify
from panel import CASES
from collections import Counter
d=w/'guarded-native-evidence';d.mkdir(exist_ok=True)
path=ivy.resolve()/'smt/g3_solver.go'
def buildprobe():
 s=once(path.read_text(),'import (','import ("os";"fmt";')
 x='return s.ctx.refExpr(rewriter.SimplifyVerificationCondition(e.c))'
 s=once(s,x,'''res:=s.ctx.refExpr(rewriter.SimplifyVerificationCondition(e.c))
 if !e.Equal(res) {
  m,err:=s.ctx.c.Manager();fail(err);diff,err:=m.MkXor(e.c,res.c);fail(err);hold,err:=m.NewRef(diff);fail(err)
  query,err:=s.ctx.c.BenchmarkSMT2(diff,api.APIBenchmarkConfig{});fail(err);fail(m.DelRef(&hold))
  guardAuditIndex++;fail(os.WriteFile(fmt.Sprintf("equivalence-%05d.smt2",guardAuditIndex),[]byte(query),0600))
 }
 return res''')
 s+='\nvar guardAuditIndex int\n';return build(d/'checker',o=overlay(d/'overlay',{path:s}))
def workload(job,checker):
 c,n,sp,iso,ref,ex=job;p=d/n;p.mkdir()
 r=subprocess.run(['taskset','-c',str(c),checker,*(['isolate='+iso]if iso else[]),examples/sp],cwd=p,capture_output=True,env=dict(env,GOMAXPROCS='1'),timeout=1600)
 if r.returncode!=ex or r.stdout!=(ref/'stdout').read_bytes() or r.stderr!=(ref/'stderr').read_bytes():
  print('diagnostics',n,r.returncode,r.stderr[-120:],flush=True);(p/'actual.stdout').write_bytes(r.stdout);(p/'actual.stderr').write_bytes(r.stderr)
 assert r.returncode==ex and r.stdout==(ref/'stdout').read_bytes() and r.stderr==(ref/'stderr').read_bytes()
 with(p/'answers.csv').open('w')as f:
  wr=csv.writer(f);wr.writerow('file g3 native'.split());seen={}
  for path in sorted(p.glob('*.smt2')):
   text=qualify(standard_declarations(path.read_text()))
   if text not in seen:
    answers=[]
    for b in (w/'ordinary-hermes-hot/g3/g3',pkg.parent/'build/z3'):
     v=subprocess.run(['taskset','-c',str(c),b,'-in','-smt2','-T:15'],input=text,text=True,capture_output=True,timeout=18)
     a=v.stdout.strip();assert a in ('unsat','timeout','unknown') and not v.stderr,(n,path,b,a[:220],v.stderr[:200]);answers.append(a)
    seen[text]=answers
   wr.writerow([path.name,*seen[text]]);f.flush();path.write_text(text)
  print(n,'native equivalences',len(seen),Counter(tuple(x)for x in seen.values()),flush=True)
if __name__=='__main__':
 b=buildprobe()
 jobs=[(4,'ordinary','jea/hermes_rmw_o3.ivy','',reference('jea/hermes_rmw_o3.ivy'),0),(18,'testing','jea/hermes_rmw_o3_testing.ivy','',w/'extended-phases/long/1/1/native',0),(22,'apple','doc/examples/apple/ord_live.ivy','',w/'apple-original-pairs/14-native',0)]
 for c,n in zip([0,2,6,8,9,12,14],['tlb','hybrid_reliable_broadcast_cisa','raftok','toy-consensus','rfn2','flash2','dramc_nb2']):
  sp,iso,_,f,u=CASES[n];ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'));jobs.append((c,n,sp,iso,ref,int(bool(f or u))))
 with ThreadPoolExecutor(len(jobs))as e:list(e.map(lambda j:workload(j,b),jobs))
