"""Replay saved Boolean-guard transformations using a local build of g3 or Z3."""
import argparse
import csv
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent


def select(rows, pattern):
    selected = [row for row in rows if re.search(pattern, row["case"])]
    if not selected:
        raise SystemExit("No fixture matched the case filter")
    return selected


def shell(args):
    executable = Path(args.binary).resolve()
    with (HERE / "shell.csv").open() as source:
        cases = select(csv.DictReader(source), args.case)
    for case in cases:
        proc = subprocess.run(
            [executable, "-st", "-smt2", HERE / case["case"]], capture_output=True, text=True, check=True
        )
        stats = dict(re.findall(r":([\w-]+)\s+(\d+)(?=[\s)])", proc.stdout))
        result = (proc.stdout.splitlines()[0], stats["rlimit-count"], stats.get("quant-instantiations", "0"))
        want = (case["status"], case["steps"], case["qi"])
        if proc.stderr or result != want:
            raise SystemExit(f"{case['case']} returned {result}, expected {want}. {proc.stderr}")
        print(case["case"], *result, flush=True)


def history(args):
    pkg = Path(args.pkg).resolve()
    with (HERE / "histories.csv").open() as source:
        cases = select(csv.DictReader(source), args.case)
    with tempfile.TemporaryDirectory() as directory:
        work = Path(directory)
        overlay = work / "overlay.json"
        overlay.write_text(json.dumps({"Replace": {
            str(pkg / "api" / "guard_replay_experiment_test.go"): str(HERE / "history_test.go.txt")
        }}))
        runner = work / "api.test"
        subprocess.run([
            "go", "test", "-c", "-overlay=" + str(overlay), "-tags=xtrace_off", "-o", runner, "./api"
        ], cwd=pkg, check=True)
        for case in cases:
            with gzip.open(HERE / case["case"], "rt") as source:
                blocks, checks = json.load(source)
            sequence = []
            for prelude, base, goal, declarations in checks:
                prelude, base, goal = (blocks[k] for k in (prelude, base, goal))
                sequence.append({"Problem": {
                    "Text": prelude + base + goal,
                    "AssertionsStart": len(prelude.encode()),
                    "LastAssertionStart": len((prelude + base).encode()),
                    "DeclarationCount": declarations,
                }})
            path = work / "sequence.json"
            path.write_text(json.dumps(sequence))
            env = dict(os.environ, GOMAXPROCS="1", ENUM_SEQUENCE=str(path), ENUM_STEPS=case["budget"],
                       ENUM_SCOPE="warm", ENUM_REGIME="default")
            run = subprocess.run([runner, "-test.run=^TestStudyEnumerationReplay$", "-test.timeout=30m",
                                  "-test.v"], cwd=work, env=env, text=True, capture_output=True, check=True)
            match = re.search(r"^REPLAY (\d+) (\d+) (true|false) \d+$", run.stdout, re.M)
            expected = (case["reached"], case["total"], case["proof"])
            if not match or match.groups() != expected:
                raise SystemExit(f"{case['case']} expected {expected}\n{run.stdout}")
            print(case["case"], case["budget"], *expected, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(required=True)
    s = commands.add_parser("shell")
    s.add_argument("--binary", required=True, help="Path to a g3 or in-tree Z3 executable")
    s.add_argument("--case", default=".", help="Regular expression for fixture names")
    s.set_defaults(action=shell)
    h = commands.add_parser("history")
    h.add_argument("--pkg", required=True, help="Path to the g3 Go module in pkg")
    h.add_argument("--case", default=".", help="Regular expression for fixture names")
    h.set_defaults(action=history)
    options = parser.parse_args()
    options.action(options)
