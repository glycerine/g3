from common import *
import guard_backbone_trials as gb,enumeration_replay as er,functools
rd=d/'guard-backbone-history';rd.mkdir(exist_ok=True)
def rewrite(qs,mode,sd):
 out=[];cache={}
 for q in qs:
  p=q['Problem'];t=p['Text'];a=p['AssertionsStart'];z=p['LastAssertionStart'];header=t[:a];base=t[a:z];tail=t[z:]
  if base not in cache:
   rs=[gb.parse(l)[1]for l in base.splitlines()];ds=[gb.parse(l)for l in header.splitlines()]
   def flat(r):
    if isinstance(r,tuple)and r[0]=='and':
     for ch in r[1:]:yield from flat(ch)
    else:yield r
   f,atoms=gb.get_forced([x for r in rs for x in flat(r)],ds,mode,sd);assert f is not None,mode
   head=''.join('(assert '+gb.show(gb.simplify(r,f))+')\n'for r in rs)
   cache[base]=head,f;print('prepared',sd.name,len(rs),len(f),len(base),len(head),flush=True)
  newbase,vs=cache[base];g='(assert '+gb.show(gb.simplify(gb.parse(tail)[1],vs))+')\n'
  out.append(dict(q,Problem=dict(p,Text=header+newbase+g,LastAssertionStart=a+len(newbase))))
 return out
def lane(j):
 i,c=j;sd=rd/str(i);sd.mkdir(exist_ok=True);orig=json.load((er.rd/f'q{i}.json').open());exe=er.rd/'api.test'
 with(sd/'runs.csv').open('w')as f:
  z=csv.writer(f);z.writerow('mode budget reached total proof terminal_ns instructions cycles'.split())
  for mode in ('original','prop','units'):
   qs=orig if mode=='original'else rewrite(orig,mode,sd);src=sd/(mode+'.json');src.write_text(json.dumps(qs))
   for budget in (6000000,12000000):
    pf=sd/(mode+'.perf');r=run(['taskset','-c',str(c),perf,'stat','-x,','-e','instructions:u,cycles:u','-o',pf,'--',exe,'-test.run=^TestStudyEnumerationReplay$','-test.v','-test.timeout=10m'],env=dict(env,GOMAXPROCS='1',ENUM_SEQUENCE=str(src),ENUM_SCOPE='warm',ENUM_REGIME='default',ENUM_STEPS=str(budget)),capture_output=True,text=True)
    hit=re.findall(r'^REPLAY (\d+) (\d+) (true|false) (\d+)$',r.stdout,re.M);assert len(hit)==1,r.stdout[-600:];ct=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];z.writerow([mode,budget,*hit[0],*ct]);f.flush()
 print('complete',i,flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(4)as e:list(e.map(lane,zip((5,6,1,3,2,4),(6,13,26,34,39,46))))
