from common import *
import guard_backbone_trials as gb,enum_premise_slices as sl,enum_matched_profiles as mp
rd=d/'quantified-guard-splits';rd.mkdir(exist_ok=True)
def split(r):
 if isinstance(r,tuple)and r[0]=='and':
  for a in r[1:]:yield from split(a)
 else:yield r
def shortcuts(t,want,gs):
 if isinstance(t,str):return {(t,want)}if t in gs else set()
 k=t[0]
 if k in ('forall','exists'):return shortcuts(t[2],want,gs)
 if k=='not':return shortcuts(t[1],not want,gs)
 if k=='or'and want or k=='and'and not want:
  return set().union(*(shortcuts(x,want,gs)for x in t[1:]))
 if k=='=>'and want:return shortcuts(t[1],False,gs)|shortcuts(t[2],True,gs)
 return set()
def choose(rows,gs,kind):
 votes=Counter();sz=Counter()
 for x in rows:
  for k in shortcuts(x,True,gs):votes[k]+=1;sz[k]+=len(gb.show(x))
 def score(g):
  pos,neg=votes[g,True],votes[g,False]
  return (min(pos,neg),pos+neg,sz[g,True]+sz[g,False]) if kind=='balanced' else (pos+neg,min(pos,neg),sz[g,True]+sz[g,False])
 return max(sorted(gs),key=score)if gs else None
def generate(src,sd,mode,depth):
 p=json.load(src.open())[0]['Problem'];txt=p['Text'];head=txt[:p['AssertionsStart']];ds=list(map(gb.parse,head.splitlines()));rows=[gb.parse(l)[1]for l in txt[p['AssertionsStart']:].splitlines()]
 gs={d[1]for d in ds if d[0]=='declare-fun'and d[2]==()and d[3]=='Bool'}
 base=[t for r in rows[:-1]for t in split(r)];goal=rows[-1]
 units,_=gb.get_forced(base,ds,'prop',sd);assert units is not None
 opt='(set-option :smt.macro_finder true)\n(set-option :smt.relevancy 1)\n'
 def dive(fixed,trail):
  current=[gb.simplify(x,fixed)for x in rows];flat=[x for r in current[:-1]for x in split(r) if x!='true']
  if len(trail)==depth:
   sk=''.join(('_T' if yes else '_F')for g,yes in trail)
   pre=''.join('(assert '+gb.show(x)+')\n'for x in current[:-1]if x!='true')
   yield sk,' '.join(g+('=T'if yes else'=F')for g,yes in trail),len(flat),opt+head+pre+'(push 1)\n(assert '+gb.show(current[-1])+')\n(check-sat)\n'
   return
  g=choose(flat,gs-set(fixed),mode);assert g
  for yes in (True,False):yield from dive(dict(fixed,**{g:'true'if yes else'false'}),trail+[(g,yes)])
 return list(dive(units,[]))
def trial(j):
 cpu,n,ctrl=j;sd=rd/(n+('-rank'if ctrl else'-full'));sd.mkdir(exist_ok=True);src=sl.rd/n/('rank64.json'if ctrl else'original.json');cache={}
 with(sd/'rows.csv').open('w')as f:
  z=csv.writer(f);z.writerow('assignment depth rank budget branches_left engine status steps qi instructions cycles'.split())
  for depth,mode in ((1,'balanced'),(1,'popular'),(2,'balanced')):
   for leaf,spec,nrows,s in generate(src,sd,mode,depth):
    lim=6000000//2**depth;key=(s,lim)
    if key not in cache:
     path=sd/(mode+str(depth)+leaf+'.smt2');path.write_text('(set-option :rlimit '+str(lim)+')\n'+s);rs=[]
     for en,b in [('g3',d/'watch-release-frontier/g3'),('native',pkg.parent/'build/z3')]:
      pf=sd/(path.stem+en+'.perf');r=run(['taskset','-c',str(cpu),perf,'stat','-e','instructions:u,cycles:u','-x,','-o',pf,'--',b,'-st','-smt2',path],capture_output=True,text=True,env=dict(env,GOMAXPROCS='1'))
      ans=r.stdout.splitlines()[0];assert not r.stderr and ans in ('unsat','unknown','sat')and(ctrl or ans!='sat'),(sd,path,en,ans,r.stderr[:100]);st=dict(mp.pars.findall(r.stdout));cts=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l];rs.append((en,ans,st['rlimit-count'],st.get('quant-instantiations',0),*cts))
     cache[key]=rs
    for row in cache[key]:z.writerow([spec,depth,mode,lim,nrows,*row]);f.flush()
  if ctrl:
   for en in ('g3','native'):
    for mode,depth in [('balanced','1'),('popular','1'),('balanced','2')]:
     aa=[r['status'] for r in readcsv(sd/'rows.csv')if (r['engine'],r['rank'],r['depth'])==(en,mode,depth)]
     assert len(aa)==2**int(depth)and any(v!='unsat' for v in aa),(n,mode,depth,aa)
 print(n,ctrl,flush=True)
if __name__=='__main__':
 js=[(c,'miss'+str(i),ctrl)for ctrl in (True,False)for c,i in zip((4,11,18,26,34,46),range(1,7))]
 with ThreadPoolExecutor(5)as e:list(e.map(trial,js))
