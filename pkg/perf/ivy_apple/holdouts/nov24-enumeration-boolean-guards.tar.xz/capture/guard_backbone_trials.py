from common import *
import enum_premise_slices as sl, enum_matched_profiles as mp
from functools import lru_cache
rd=d/'guard-backbone-trials';rd.mkdir(exist_ok=True)
def tup(v):return tuple(map(tup,v))if isinstance(v,list)else v
def parse(txt):return tup(sl.tree(txt))
def show(v):return v if isinstance(v,str)else '('+' '.join(map(show,v))+')'
def replace(v,scope):
 if isinstance(v,str):return scope.get(v,v)
 if v[0]in ('forall','exists'):return(v[0],v[1],replace(v[2],{k:w for k,w in scope.items()if k not in {x for x,s in v[1]}}))
 return (v[0],*(replace(x,scope)for x in v[1:]))
def simplify(v,bindings):
 if isinstance(v,str):return bindings.get(v,v)
 k=v[0]
 if k in ('forall','exists'):
  body=simplify(v[2],bindings)
  if body in ('true','false'):return body
  return(k,v[1],body)
 xs=tuple(simplify(x,bindings)for x in v[1:])
 if k in ('and','or'):
  e,z=('true','false')if k=='and'else('false','true')
  if z in xs:return z
  ys=tuple(x for x in xs if x!=e)
  if not ys:return e
  if len(ys)==1:return ys[0]
  return(k,*ys)
 if k=='not':
  if xs[0]in ('true','false'):return 'true' if xs[0]=='false' else 'false'
 if k=='='and len(xs)==2:
  x,y=xs
  if x==y:return 'true'
  if x=='true':return y
  if y=='true':return x
  if x=='false':return simplify(('not',y),{})
  if y=='false':return simplify(('not',x),{})
 if k=='=>'and len(xs)==2:
  x,y=xs
  if x=='false' or y=='true' or x==y:return 'true'
  if x=='true':return y
  if y=='false':return simplify(('not',x),{})
 if k=='ite':
  a,b,c=xs
  if a=='true'or b==c:return b
  if a=='false':return c
 return(k,*xs)
def get_forced(rows,ds,mode,sd):
 sig={d[1]:d[3]for d in ds if d[0]=='declare-fun'};guards=[d[1]for d in ds if d[0]=='declare-fun'and d[3]=='Bool'and d[2]==()]
 names={};rules=[];used=set()
 def atom(v):
  if v not in names:names[v]='a'+str(len(names))
  return names[v]
 def so(v):
  if isinstance(v,str):return sig.get(v,'Bool' if v in ('false','true')else None)
  k=v[0]
  if k in ('not','and','or','=>','forall','exists','=','distinct','xor'):return 'Bool'
  if k=='ite':return so(v[2])
  return sig.get(k)
 @lru_cache(None)
 def prop(v,depth=0):
  if isinstance(v,str):
   if v in ('true','false'):return v
   return atom(v)
  k=v[0]
  if k in ('forall','exists'):
   b=atom(v)
   if mode=='ground' and depth<2:
    vs=v[1];anchors=[{z:'rep_'+s for z,s in vs},{z:'wit_'+b+'_'+str(i)for i,(z,s)in enumerate(vs)}]
    for i,sub in enumerate(anchors):
     body=prop(replace(v[2],sub),depth+1)
     if (k=='forall')==(i==0):rules.append(('=>',b,body))
     else:rules.append(('=>',body,b))
   return b
  if k in ('or','and','=>','not','xor')or k in ('=','distinct') and so(v[1])=='Bool'or k=='ite'and so(v)=='Bool':
   return(k,*(prop(x,depth)for x in v[1:]))
  if k=='='and len(v)==3 and v[1]==v[2]:return 'true'
  return atom(v)
 if mode=='units':
  fs={r:'true'for r in rows if isinstance(r,str)and r in guards}
  fs.update({r[1]:'false'for r in rows if isinstance(r,tuple)and r[0]=='not'and r[1]in guards})
  return fs,0
 parts=[prop(r)for r in rows];tags={g:atom(g)for g in guards};rev={v:g for g,v in tags.items()}
 ls=['(set-logic QF_UF)',*(f'(declare-const {v} Bool)'for v in names.values()),*(f'(assert {show(z)})'for z in (*parts,*rules)),'(check-sat)']
 for g,v in tags.items():ls.extend([f'(check-sat-assuming ({v}))',f'(check-sat-assuming ((not {v})))'])
 path=sd/(mode+'-relax.smt2');path.write_text('\n'.join(ls)+'\n')
 res=run([pkg.parent/'build/z3',path],capture_output=True,text=True);rs=res.stdout.splitlines();assert len(rs)==1+2*len(guards)and set(rs)<=set(('sat','unsat')),rs[:3]
 if rs[0]=='unsat':return None,len(names)
 found={}
 for i,k in enumerate(tags):
  pos,neg=rs[1+2*i:3+2*i]
  assert 'sat'in (pos,neg)
  if pos=='unsat':found[k]='false'
  if neg=='unsat':found[k]='true'
 return found,len(names)
def prepare(src,mode,withgoal,sd):
 p=json.loads(src.read_text())[0]['Problem'];decls=p['Text'][:p['AssertionsStart']];ds=list(map(parse,decls.splitlines()))
 rows=[parse(l)[1]for l in p['Text'][p['AssertionsStart']:].splitlines()]
 def flatten(r):
  if isinstance(r,tuple)and r[0]=='and':
   for x in r[1:]:yield from flatten(x)
  else:yield r
 vs,names=get_forced([v for r in (rows if withgoal else rows[:-1])for v in flatten(r)],ds,mode,sd)
 head='(set-option :smt.macro_finder true)\n(set-option :smt.relevancy 1)\n(set-option :rlimit 6000000)\n'
 if vs is None:return head+decls+'(assert false)\n(check-sat)\n',-1,names,0
 rs=[simplify(r,vs) for r in rows]
 # All eliminated nullary symbols can be assigned to their established value in any model.
 out=decls+''.join('(assert '+show(r)+')\n'for r in rs[:-1] if r!='true')+'(push 1)\n(assert '+show(rs[-1])+')\n(check-sat)\n'
 return head+out,len(vs),names,len(set().union(*(set(map(show,flatten(r)))for r in rs[:-1])))
def lane(j):
 cpu,n,ctrl=j;sd=rd/(n+('-rank'if ctrl else '-full'));sd.mkdir(exist_ok=True)
 src=sl.rd/n/('rank64.json'if ctrl else'original.json')
 with(sd/'rows.csv').open('w')as f:
  z=csv.writer(f);z.writerow('mode whole fixed atoms conjuncts engine status steps qi instructions cycles'.split())
  for mode,wg in [('units',False),('prop',False),('ground',False),('prop',True),('ground',True)]:
   inp,c,atoms,ct=prepare(src,mode,wg,sd);tag=mode+('-all'if wg else'-base');p=sd/(tag+'.smt2');p.write_text(inp)
   for en,b in [('g3',d/'watch-release-frontier/g3'),('native',pkg.parent/'build/z3')]:
    pf=sd/(tag+en+'.perf');r=run(['taskset','-c',str(cpu),perf,'stat','-x,','-e','instructions:u,cycles:u','-o',pf,'--',b,'-st','-smt2',p],capture_output=True,text=True,env=dict(env,GOMAXPROCS='1'))
    answer=r.stdout.splitlines()[0];assert answer in ('unknown',('sat' if ctrl else'unsat'))and not r.stderr,(n,mode,en,answer,r.stderr[:300])
    st=dict(mp.pars.findall(r.stdout));counters=[int(l.split(',')[0])for l in pf.read_text().splitlines()if ':u'in l]
    z.writerow([mode,int(wg),c,atoms,ct,en,answer,st['rlimit-count'],st.get('quant-instantiations',0),*counters]);f.flush()
 print(n,ctrl,flush=True)
if __name__=='__main__':
 js=[(c,'miss'+str(i),ctrl)for ctrl in (True,False)for c,i in zip([4,15,26,33,37,45],range(1,7))]
 with ThreadPoolExecutor(5)as e:list(e.map(lane,js))
