from common import *
import holdouts as ho,stage_frontier as sf,steady_oracle as so
rd=d/'shallow-refutations';rd.mkdir(exist_ok=True)
a=pkg/'sat/sat_solver_search.go';p=pkg/'sat/sat_solver_parallel_portfolio.go';c=pkg/'sat/sat_solver_consequences.go';api=pkg/'api/api_ground_instances.go'
newtest=pkg/'sat/sat_solver_decision_depth_test.go'
def edits(depth):
 s=a.read_text()
 x='func (s *Solver) boundedSearch() (lbool.LBool, error) {';s=once(s,x,x.replace('boundedSearch()','boundedSearch(maxLevel uint32)'))
 x='yes, e := s.decision.decide()';s=once(s,x,'''// Abort at a propagation fixed point, before opening another decision
  // scope. The caller can pop the assumption and reuse the learned clauses.
  if maxLevel != 0 && s.Variables.scopeLevel >= maxLevel {
   return lbool.Undef, satSolverAbort{}
  }
  '''+x)
 x='func (s *Solver) checkSpan(count uint32, span satSolverLiteralSpan) (lbool.LBool, error) {'
 s=once(s,x,'''// CheckWithDecisionDepth stops a search that needs to branch from maxLevel
// open decision scopes. The assumption scope counts as one level. A zero
// bound runs the ordinary search. Reaching the bound returns Undef.
func (s *Solver) CheckWithDecisionDepth(lits []Literal, maxLevel uint32) (lbool.LBool, error) {
 return s.checkSpanWithDepth(uint32(len(lits)), satSolverLiteralSpan{literals:lits}, maxLevel)
}
'''+x+'''
 return s.checkSpanWithDepth(count,span,0)
}
func (s *Solver) checkSpanWithDepth(count uint32, span satSolverLiteralSpan, maxLevel uint32) (lbool.LBool, error) {''')
 s=once(s,'s.checkParallelSpan(count, span, cfg.NumParallel)','s.checkParallelSpan(count, span, cfg.NumParallel,maxLevel)')
 s=once(s,'s.checkCoreSpan(count, span)','s.checkCoreSpan(count, span,maxLevel)')
 s=once(s,'s.checkCoreSpan(uint32(len(lits)), satSolverLiteralSpan{literals: lits})','s.checkCoreSpan(uint32(len(lits)), satSolverLiteralSpan{literals: lits},0)')
 s=once(s,'func (s *Solver) checkCoreSpan(count uint32, span satSolverLiteralSpan)','func (s *Solver) checkCoreSpan(count uint32, span satSolverLiteralSpan, maxLevel uint32)').replace('s.boundedSearch()','s.boundedSearch(maxLevel)')
 t=p.read_text().replace('span satSolverLiteralSpan, lanes uint32)','span satSolverLiteralSpan, lanes,maxLevel uint32)').replace('p.run(count, span)','p.run(count, span,maxLevel)').replace('run(count uint32, span satSolverLiteralSpan)','run(count uint32, span satSolverLiteralSpan,maxLevel uint32)').replace('s.checkSpan(count, span)','s.checkSpanWithDepth(count, span,maxLevel)')
 u=api.read_text();x='result, err := s.sat.solver.Check(assumptions)';u=once(u,x,'''// Most refutations of the shared ground instances are shallow. Deeper
 // searches spend their time completing models of this relaxation, which
 // cannot establish satisfiability of the original quantified input.
 const maxDecisionLevel = '''+str(depth)+'''
 result, err := s.sat.solver.CheckWithDecisionDepth(assumptions,maxDecisionLevel)''')
 test='''package sat
import ("testing";"errors";"github.com/glycerine/g3/pkg/util/lbool")
func TestSATDecisionDepthAcrossAssumptions(t *testing.T){
 s,_,_:=satSolverCheckFixture(t)
 for range 12{_,err:=s.MkVar(true,true);satOK(t,err)}
 x:=MakeLiteral(0,false)
 satOK(t,s.MkClause([]Literal{x}))
 check:=func(lit Literal,depth uint32,want lbool.LBool){t.Helper();got,err:=s.CheckWithDecisionDepth([]Literal{lit},depth);satOK(t,err);if got!=want{t.Fatalf("assumption %v, depth %d: got %v, want %v",lit,depth,got,want)};satOK(t,s.PopToBaseLevel())}
 check(x,1,lbool.Undef)
 check(x.Negated(),1,lbool.False)
 check(x,0,lbool.True)
 check(x,1,lbool.Undef)
 got,err:=s.Check(nil);satOK(t,err);if got!=lbool.True{t.Fatal(got)}
 copy:=*s;if _,err:=copy.CheckWithDecisionDepth(nil,1);!errors.Is(err,ErrSATOwner){t.Fatal(err)}
}
func TestSATDecisionDepthChecksRefutationsBeforeBranching(t *testing.T){
 for mask:=0;mask<16;mask++{
  s,_,_:=satSolverCheckFixture(t);for range 2{_,e:=s.MkVar(true,true);satOK(t,e)}
  var cs [][]Literal
  for i:=0;i<4;i++{if mask&(1<<i)==0{continue};cl:=[]Literal{MakeLiteral(0,i&1!=0),MakeLiteral(1,i&2!=0)};cs=append(cs,cl);satOK(t,s.MkClause(cl))}
  want:=satSolverFiniteCNFOracle(cs,2)
  got,err:=s.CheckWithDecisionDepth(nil,1);satOK(t,err);if got!=lbool.Undef && got!=want{t.Fatalf("formula %d, bounded result %v, want %v",mask,got,want)}
  got,err=s.Check(nil);satOK(t,err);if got!=want{t.Fatalf("formula %d, ordinary search after bounded search: got %v, want %v",mask,got,want)}
 }
}
'''
 return {a:s,p:t,c:c.read_text().replace('s.boundedSearch()','s.boundedSearch(0)'),api:u,newtest:test}
def make(v):
 sd=rd/f'depth{v}';ed=edits(v);o=overlay(sd/'overlay',ed);b=build(sd/'checker',o=o)
 k=pkg/'api/steady_oracle_benchmark_trial_test.go';ed[k]=so.code.replace('var db studySteadySearch','var db groundInstanceSolver').replace('db.prove(s,m,xs)','db.prove(s,m,xs,2_000_000,1)');oo=overlay(sd/'oracle-overlay',ed)
 with(w/'build.lock').open('a')as lk:
  fcntl.flock(lk,fcntl.LOCK_SH)
  for t,r,ov,pk in [('xtrace_off','.',o,['./sat','./api/internal/order','./api']),('g3debug','TestSATDecisionDepth|TestGroundInstance|TestSATParallel',o,['./sat','./api']),('g3checked','TestSATDecisionDepth|TestGroundInstance|TestSATParallel',o,['./sat','./api']),('xtrace_off','^TestSteadyProjectionOracle$',oo,['./api'])]:
   with(sd/('oracle.log'if ov!=o else t+'-tests.log')).open('w')as log:
    run(['go','test','-p','3','-timeout=10m','-v','-count=1','-tags='+t,'-overlay='+str(ov),'-run',r,*pk],cwd=pkg,env=dict(env,G3_STEADY_CASES=str(so.rd/'cases')),stdout=log,stderr=log)
 print(v,'validated',flush=True);return b
def main():
 with ThreadPoolExecutor(2)as e:bs=dict(zip(('depth128','depth256'),e.map(make,[128,256])))
 bs['before']=d/'release-repeat-plans/checker/goivy_check';bs['release']=d/'release-ground-pool/checker/goivy_check';bs['native']=native;ho.root=rd
 js=[(42,*j[1:])for j in sf.jobs()if j[1]=='tlb']+[(c,*j[1:])for c,j in zip([9,18,22],ho.jobs()[:3])]
 with ThreadPoolExecutor(4)as e:list(e.map(lambda j:ho.measure_spec(j,bs,5 if j[1]=='tlb'else 2),js))
if __name__=='__main__':main()
