from common import *
import holdouts as ho,stage_frontier as sf,macro_identity as mi,ground_release_controls as gc,production_triggers as pt,timed_policy as tp,release_ground_pool as gp
rd=d/'release-shallow-ground';rd.mkdir(exist_ok=True)
def shell_run():
 b=rd/'shell';b.mkdir(exist_ok=True);exe=b/'g3'
 with(w/'build.lock').open('a')as lk,(b/'build.log').open('w')as l:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','3','-tags=xtrace_off','-pgo=off','-o',exe,'./cmd/g3'],cwd=pkg,stdout=l,stderr=l)
 with(b/'dimacs.csv').open('w')as l:run([sys.executable,pkg/'perf/ivy_raft/watch_propagation.py','--rounds','3','--perf',perf,'--cpu','4',d/'sat-watch-production/g3-tree',exe,pkg.parent/'build/z3'],stdout=l)
def main():
 b=build(rd/'checker');(rd/'build-info.txt').write_text(linked(b));gc.d=rd;ho.root=rd;pt.root=rd;gp.rd=rd
 bs={'before':d/'release-sat-watch/checker/goivy_check','release':b,'native':native}
 tp.root=rd/'quiet';tp.root.mkdir(exist_ok=True);tp.bins=bs
 js=[(c,*j[1:])for c,j in zip([25,27,29,30],(j for j in sf.jobs()if j[1]in('tlb','ticket_protocol','hybrid','hermes_rmw_o3')))]+[(c,*j[1:5],j[-1])for c,j in zip([8,19,20,31],(j for j in mi.jobs()if j[1]in('rfn2','cf_live','dramc_nb2','raft_no_assume_test')))]+[(c,*j[1:])for c,j in zip([15,17,42],ho.jobs()[:3])]
 with ThreadPoolExecutor(13)as ex:
  fs=[ex.submit(gc.corpus,b),ex.submit(pt.source_trace),ex.submit(gp.finite),ex.submit(gp.memory),ex.submit(shell_run),ex.submit(tp.lane,next(j[1:]for j in js if j[1]=='tlb'))]
  fs.extend(ex.submit(ho.measure_spec,j,bs,5 if j[1]in('tlb','cf_live','rfn2')else 3)for j in js)
  for f in fs:f.result()
if __name__=='__main__':main()
