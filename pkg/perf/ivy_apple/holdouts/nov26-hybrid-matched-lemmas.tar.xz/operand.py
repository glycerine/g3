"""Price reused bindings, recursive internalization and literal lookup on hybrid."""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

w = Path(__file__).resolve().parent
pkg = Path.cwd()
base = w.parent / ".boolean-enode-cost"
front = base / "frontend/goivy"
files = json.loads((w / "seg-g3.json").read_text())["Replace"]
key = str(pkg / "smtcore/smt_internalizer.go")
src = Path(files[key]).read_text()
start = src.index("for index, argument := range arguments", src.index("fd:=segFD"))
end = src.index("argsEnd:=", start)
fragment = src[start:end]
fragment = fragment.replace("if instanceArguments != nil", "zero:=lemmaRead(fd); begin:=lemmaRead(fd); if instanceArguments != nil")
fragment = fragment.replace("continue", 'if fd>=0 {end:=lemmaRead(fd); println("OPER reused",begin-zero,end-begin,0,0)}; continue')
fragment = fragment.replace("if err = s.Internalize", "probe:=lemmaRead(fd); if err = s.Internalize")
fragment = fragment.replace("literals[index], err = s.Literal", "internal:=lemmaRead(fd); literals[index], err = s.Literal")
point = fragment.rindex("}")
fragment = fragment[:point] + 'if fd>=0 {end:=lemmaRead(fd);println("OPER full",begin-zero,probe-begin,internal-probe,end-internal)}\n' + fragment[point:]
dst = w / "op-internalizer.go"
dst.write_text(src[:start] + fragment + src[end:])
files[key] = str(dst)
overlay = w / "op.json"
overlay.write_text(json.dumps({"Replace": files}))
exe = w / "op-g3"
subprocess.run(["go","build","-pgo=off","-mod=readonly","-buildvcs=false","-modfile",base/"heap/study.mod","-tags=xtrace_off","-overlay",overlay,"-o",exe,"./cmd/goivy_check"],cwd=front,env=dict(os.environ,GOCACHE="/tmp/g3-nov23-day/cache"),check=True)
examples = Path("/home/jaten/ivy/ivy-lang-examples")
ref = w.parent / ".bool-scan/golden/reference/hybrid"
out = csv.writer(sys.stdout)
out.writerow(["round","kind","empty","probe","internalize","literal"])
for i in range(5):
    r = subprocess.run(["taskset","-c","14",exe,examples/"examples/liveness/hybrid_reliable_broadcast_cisa.ivy"],cwd=w,env=dict(os.environ,GOMAXPROCS="1",GOGC="off",XTRACE_OFF="1",GOIVY_INCLUDE=str(examples/"ivy/include")),capture_output=True,check=True)
    keep, rows, candidates, segments = [], [], 0, 0
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b"PREFIX "):
            candidates += 1
        elif line.startswith(b"OPER "):
            if candidates == 0:
                rows.append(line.decode().split()[1:])
        elif line.startswith(b"SEG "):
            segments += candidates == 0
        elif line.startswith(b"STAGE-COUNT "):
            if line.startswith(b"STAGE-COUNT 35 1 check "):
                assert segments == 203 and rows
                out.writerows([i+1,*row] for row in rows)
            rows, candidates, segments = [], 0, 0
        elif not line.startswith(b"LEM "):
            keep.append(line)
    assert r.stdout == (ref/"stdout").read_bytes() and b"".join(keep) == (ref/"stderr").read_bytes()
