from pathlib import Path
import os,csv,sys,subprocess
w=Path(__file__).resolve().parent
base=w.parent/".boolean-enode-cost";e=sys.argv[1];exe=w/e
examples=Path('/home/jaten/ivy/ivy-lang-examples');ref=w.parent/'.bool-scan/golden/reference/hybrid'
out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('engine','round','candidate','operation','index','ast_hash','empty','raw'))
for i in range(5):
 r=subprocess.run(['taskset','-c','14',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
 keep=[];pending=[];c=0;counts={}
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'PREFIX '):c+=1
  elif line.startswith(b'LEM '):
   _,op,h,empty,raw=line.decode().split();key=c,op;counts[key]=counts.get(key,0)+1
   pending.append((e,i+1,c,op,counts[key],h,empty,raw))
  elif line.startswith(b'STAGE-COUNT '):
   if c or pending:
    if line.startswith(b'STAGE-COUNT 35 1 check '):
     assert counts[0,'rewrite']==counts[0,'assert']==203
     out.writerows(pending)
    else:assert line.startswith(b'STAGE-COUNT 35 1 ') and not c
    pending=[];c=0;counts={}
  else:keep.append(line)
 assert not pending and r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
 sys.stdout.flush()
