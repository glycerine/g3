"""Measure each queue rewrite and internalization in the selected hybrid check."""
import csv,json,os,re,shlex,shutil,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();old=w.parent/'.hybrid-obligations';base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
e=sys.argv[1];files=json.loads((old/('prefix-'+e+'.json')).read_text())['Replace']
def change(s,a,b):
 if s.count(a)!=1:raise ValueError(a)
 return s.replace(a,b)
if e=='z3':
 f=p.parent/'src/smt/qi_queue.cpp';s=f.read_text()
 for phase,line,h in [('rewrite','m_context.get_rewriter()(instance, s_instance, pr);','instance'),('assert','m_context.internalize_instance(lemma, pr1, gen);','lemma')]:
  s=change(s,line,'{const char* v=getenv("G3_TRIAL_STAGE_FD"); int fd=v?atoi(v):-1; uint64_t a=rd(fd), b=rd(fd); '+line+' uint64_t c=rd(fd); if(fd>=0) fprintf(stderr,"LEM '+phase+' %u %llu %llu\\n",'+h+'->hash(),(unsigned long long)(b-a),(unsigned long long)(c-b));}')
 dest=w/'qi_queue.cpp';dest.write_text('#include <unistd.h>\n#include <cstdint>\n#include <cstdlib>\n#include <cstdio>\nstatic uint64_t rd(int fd){ if(fd<0)return 0; uint64_t c[3]; if(read(fd,c,sizeof(c))!=sizeof(c)||c[1]!=c[2])abort(); return c[0];}\n'+s)
 build=p.parent/'build';mk=(build/'Makefile').read_text();flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
 obj=w/'qi_queue.o';subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',obj,dest],cwd=build,check=True)
 lib=w/'liblemma.a';shutil.copyfile(old/'libprefix.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
 q=front/'smt/quantifier.go';dst=w/'quantifier.go';dst.write_text(q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));files[str(q)]=str(dst)
else:
 f=p/'smtcore/smt_qi_instance.go';s=f.read_text()
 for pkg in ('os','syscall','strconv','unsafe'):
  if '"'+pkg+'"' not in s:s=s.replace('import (','import (\n"'+pkg+'"',1)
 s+='''
func lemmaRead(fd int) uint64 {
 if fd<0{return 0}; var c [3]uint64
 n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&c[0])),24)
 if e!=0||n!=24||c[1]!=c[2]{panic("bad counter")};return c[0]
}
func lemmaStart()(int,uint64,uint64) {
 v:=os.Getenv("G3_TRIAL_STAGE_FD"); if v=="" {return -1,0,0};fd,e:=strconv.Atoi(v);if e!=nil{panic(e)}
 a:=lemmaRead(fd);b:=lemmaRead(fd);return fd,a,b
}
'''
 for phase,call,expr in [('rewrite','rw.Rewrite(instance, simplified)','instance'),('assert','internalizer.internalizeInstance(result, locals.arguments)','lemma')]:
  needle='if err = '+call+'; err != nil {'
  get='lemma,_:=result.Lemma();' if phase=='assert' else ''
  s=change(s,needle,'fd,a,t:=lemmaStart();err='+call+';c:=lemmaRead(fd);if fd>=0 {'+get+' h,_:=b.manager.GetHash('+expr+');println("LEM '+phase+'",h,t-a,c-t)};if err!=nil {')
 dst=w/f.name;dst.write_text(s);files[str(f)]=str(dst)
ov=w/(e+'.json');ov.write_text(json.dumps({'Replace':files}));exe=w/e
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if e=='z3' else 'xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
examples=Path('/home/jaten/ivy/ivy-lang-examples');ref=w.parent/'.bool-scan/golden/reference/hybrid'
out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('engine','round','candidate','operation','index','ast_hash','empty','raw'))
for i in range(5):
 r=subprocess.run(['taskset','-c','14',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
 keep=[];pending=[];c=0;counts={}
 for line in r.stderr.splitlines(keepends=True):
  if line.startswith(b'PREFIX '):c+=1
  elif line.startswith(b'LEM '):
   _,op,h,empty,raw=line.decode().split();key=c,op;counts[key]=counts.get(key,0)+1
   pending.append((e,i+1,c,op,counts[key],h,empty,raw))
  elif line.startswith(b'STAGE-COUNT '):
   if c or pending:
    if line.startswith(b'STAGE-COUNT 35 1 check '):
     assert counts[0,'rewrite']==counts[0,'assert']==203
     out.writerows(pending)
    else:assert line.startswith(b'STAGE-COUNT 35 1 ') and not c
    pending=[];c=0;counts={}
  else:keep.append(line)
 assert not pending and r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
 sys.stdout.flush()
