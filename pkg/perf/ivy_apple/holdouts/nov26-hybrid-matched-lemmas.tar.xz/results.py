"""Verify expression correspondence and summarize measured instruction counts."""
import collections
import csv
import re
import statistics
from pathlib import Path

directory = Path(__file__).resolve().parent


def read(name):
    with (directory / (name + ".csv")).open() as source:
        return list(csv.DictReader(source))


def compare_trees():
    forward, reverse = {}, {}
    left, right = read("g3-tree"), read("z3-tree")
    counts = collections.Counter()
    for a, b in zip(left, right, strict=True):
        assert a["operation"] == b["operation"]
        counts[a["operation"]] += 1
        tokenize = r"\(|\)|[^\s()]+"
        for x, y in zip(re.findall(tokenize, a["expression"]),
                        re.findall(tokenize, b["expression"]), strict=True):
            mx, my = re.fullmatch(r"(.+)!\d+", x), re.fullmatch(r"(.+)!\d+", y)
            if mx and my:
                assert mx[1] == my[1]
                assert forward.setdefault(x, y) == y
                assert reverse.setdefault(y, x) == x
            else:
                assert x == y
    assert counts == {"assert": 203, "rewrite": 203}
    print(counts, "renamed", sum(k != v for k, v in forward.items()))


def report(name, keys, columns, prefix=False):
    samples = collections.defaultdict(lambda: collections.defaultdict(list))
    for row in read(name):
        if prefix and row["candidate"] != "0":
            continue
        for col in columns:
            key = tuple(row[k] for k in keys) + (col,)
            samples[key][row["round"]].append(int(row[col]) - int(row["empty"]))
    for key, rounds in samples.items():
        assert len(rounds) == 5
        counts = {len(values) for values in rounds.values()}
        assert len(counts) == 1
        totals = [sum(values) for values in rounds.values()]
        print(name, key, counts.pop(), "median", statistics.median(totals),
              "range", min(totals), max(totals))


compare_trees()
for name in ("g3", "z3", "gc-off", "control-g3", "control-z3"):
    report(name, ["operation"], ["raw"], prefix=not name.startswith("control"))
for name in ("segments-g3", "segments-z3"):
    report(name, ["gc"], ["operands", "clause", "watches", "mark"])
operand_rows = read("operand")
for kind in ("reused", "full"):
    rounds = collections.defaultdict(list)
    for row in operand_rows:
        if row["kind"] == kind:
            rounds[row["round"]].append(row)
    assert len(rounds) == 5
    sizes = {len(rows) for rows in rounds.values()}
    assert len(sizes) == 1
    print(kind, sizes.pop(), {col: statistics.median(
        sum(int(row[col]) - int(row["empty"]) for row in rows) for rows in rounds.values())
        for col in (["probe"] if kind == "reused" else ["probe", "internalize", "literal"])})

native = read("native-operand")
by_kind = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
for g3, z3 in zip(operand_rows, native, strict=True):
    assert g3["round"] == z3["round"]
    totals = by_kind[g3["kind"]][z3["round"]]
    for col in ("internalize", "literal"):
        totals[col] += int(z3[col]) - int(z3["empty"])
for kind, rounds in by_kind.items():
    print("native on", kind, {col: statistics.median(r[col] for r in rounds.values())
                              for col in ("internalize", "literal")})
