import collections,csv,statistics,sys
from pathlib import Path
w=Path(__file__).resolve().parent;data={}
for e in sys.argv[1:]:
 sums=collections.defaultdict(collections.Counter);v=collections.defaultdict(list);keys={}
 for r in csv.DictReader(open(w/(e+'.csv'))):
  if r['candidate']!='0':continue
  k=(r['operation'],int(r['index']));n=int(r['raw'])-int(r['empty'])
  if k in keys:assert keys[k]==r['ast_hash']
  keys[k]=r['ast_hash'];v[k].append(n);sums[r['operation']][r['round']]+=n
 data[e]=(keys,v)
 print(e,{k:dict(vals) for k,vals in sums.items()})
if len(data)==2:
 a,b=data.values()
 for kind in ['rewrite','assert']:
  rows=[(statistics.median(a[1][k])-statistics.median(b[1][k]),k[1]) for k in a[0] if k[0]==kind]
  print(kind,'matched hashes',sum(a[0][kind,i]==b[0][kind,i] for n,i in rows),'out of',len(rows),'top',sorted(rows,reverse=True)[:10])
