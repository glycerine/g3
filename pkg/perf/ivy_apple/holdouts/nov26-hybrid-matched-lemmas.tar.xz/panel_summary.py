"""Calculate median paired percentage changes over completed verifier triples."""
import csv,statistics,collections,sys
d=collections.defaultdict(dict)
for r in csv.DictReader(open(sys.argv[1])):d[r['case'],int(r['round'])][r['engine']]=r
for case in sorted(set(k for k,i in d)):
    for eng in sorted({e for (k,i),p in d.items() if k==case for e in p}-{'base'}):
        pairs=[p for (k,i),p in d.items() if k==case and eng in p and 'base' in p]
        if pairs:print(case,eng,len(pairs),*[round(statistics.median([(float(p[eng][col])/float(p['base'][col])-1)*100 for p in pairs]),3) for col in ['instructions','cycles','milliseconds']])
