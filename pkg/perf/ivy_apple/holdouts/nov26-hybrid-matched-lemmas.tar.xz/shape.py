"""Compare the ordered trees of the first candidate's input and asserted expressions."""
from pathlib import Path
import collections,csv,json,os,re,shlex,shutil,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy';e=sys.argv[1]
files=json.loads((w/(e+'.json')).read_text())['Replace']
if e=='z3':
 src=w/'qi_queue.cpp';s=src.read_text().replace('static uint64_t rd(','''
#include "ast/ast.h"
#include <sstream>
static void shape(std::ostringstream& out, expr* t) {
   if(is_app(t)) { app* a=to_app(t);out << "(" << a->get_decl()->get_name();
      for(expr* c:*a) {out << " ";shape(out,c);}out << ")"; }
   else if(is_var(t)) {out << "v" << to_var(t)->get_idx();}
   else {auto* q=to_quantifier(t);out<<"("<<(q->is_forall()?"forall":"exists");
      for(unsigned i=0;i<q->get_num_decls();i++)out<<" "<<q->get_decl_sort(i)->get_name();
      out<<" ";shape(out,q->get_expr());out<<")";}
}
static void emit(const char* op,expr* t) {std::ostringstream out;shape(out,t);fprintf(stderr,"TREE %s %s\\n",op,out.str().c_str());}
static uint64_t rd(''')
 for phase,h in [('rewrite','instance'),('assert','lemma')]:
  a='if(fd>=0) fprintf(stderr,"LEM '+phase;s=s.replace(a,'if(fd>=0)emit("'+phase+'",'+h+'); '+a)
 d=w/'shapes';d.mkdir(exist_ok=True);dst=d/src.name;dst.write_text(s);obj=d/'qi_queue.o'
 build=p.parent/'build';mk=(build/'Makefile').read_text();flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
 subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',obj,dst],cwd=build,check=True)
 lib=d/'libshape.a';shutil.copyfile(w/'liblemma.a',lib);subprocess.run(['ar','r',lib,obj],check=True)
 q=front/'smt/quantifier.go';dst=d/'quantifier.go';dst.write_text(q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));files[str(q)]=str(dst)
else:
 f=p/'smtcore/smt_qi_instance.go';s=Path(files[str(f)]).read_text()
 if '"strings"' not in s:s=s.replace('import (','import (\n"strings"')
 s+='''
func trialTree(m *ast.ASTManager,t ast.ASTHandle,b *strings.Builder) {
 h,e:=m.NodeHeader(t);if e!=nil {panic(e)}
 name:=func(x ast.ASTHandle) {n,e:=m.GetASTName(x);if e!=nil {panic(e)};v,e:=m.Symbols.String(n);if e!=nil {panic(e)};b.WriteString(v)}
 switch h.Kind {
 case ast.ASTApp:b.WriteByte('(');name(h.Decl);for i:=uint32(0);i<h.NumArgs;i++{v,e:=m.GetArg(t,i);if e!=nil{panic(e)};b.WriteByte(' ');trialTree(m,v,b)};b.WriteByte(')')
 case ast.ASTVar:i,e:=m.GetVarIndex(t);if e!=nil{panic(e)};b.WriteByte('v');b.WriteString(strconv.Itoa(int(i)))
 case ast.ASTQuantifier:all,e:=m.IsForall(t);if e!=nil{panic(e)};if all {b.WriteString("(forall")} else {b.WriteString("(exists")};n,e:=m.GetNumDeclarations(t);if e!=nil{panic(e)};for i:=uint32(0);i<n;i++{sort,e:=m.GetDeclarationSort(t,i);if e!=nil{panic(e)};b.WriteByte(' ');name(sort)};body,e:=m.GetQuantifierBody(t);if e!=nil{panic(e)};b.WriteByte(' ');trialTree(m,body,b);b.WriteByte(')')
 default:panic("unexpected node")
 }
}
'''
 for ph,h in [('rewrite','instance'),('assert','lemma')]:
  needle='h,_:=b.manager.GetHash('+h+')';s=s.replace(needle,'var text strings.Builder;trialTree(b.manager,'+h+',&text);println("TREE '+ph+'",text.String());'+needle)
 dst=w/'shape-instance.go';dst.write_text(s);files[str(f)]=str(dst)
ov=w/('shape-'+e+'.json');ov.write_text(json.dumps({'Replace':files}));exe=w/('shape-'+e)
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if e=='z3' else 'xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
examples=Path('/home/jaten/ivy/ivy-lang-examples');ref=w.parent/'.bool-scan/golden/reference/hybrid'
r=subprocess.run(['taskset','-c','16',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
num=0;rows=[];keep=[];out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('operation','expression'))
for l in r.stderr.splitlines(keepends=True):
 if l.startswith(b'PREFIX '):num+=1
 elif l.startswith(b'TREE '):
  if not num:rows.append(l.rstrip().decode().split(' ',2)[1:])
 elif l.startswith(b'STAGE-COUNT '):
  if l.startswith(b'STAGE-COUNT 35 1 check '):
   assert collections.Counter(a for a,_ in rows)=={'rewrite':203,'assert':203};out.writerows(rows)
  rows=[];num=0
 elif not l.startswith(b'LEM '):keep.append(l)
assert r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
