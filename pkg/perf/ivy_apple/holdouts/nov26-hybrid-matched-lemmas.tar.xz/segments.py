"""Bracket four stages inside the OR branch of a quantified instance assertion."""
import csv,json,os,re,shutil,shlex,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy';e=sys.argv[1]
files=json.loads((w/(e+'.json')).read_text())['Replace']
def rep(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
if e=='g3':
 f=p/'smtcore/smt_qi_instance.go';s=Path(files[str(f)]).read_text();a='err=internalizer.internalizeInstance(result, locals.arguments);';s=rep(s,a,'segFD=fd;'+a+'segFD=-1;')
 dest=w/'seg-instance.go';dest.write_text(s+'\nvar segFD = -1\n');files[str(f)]=str(dest)
 f=p/'smtcore/smt_internalizer.go';s=f.read_text();lo=s.index('switch op',s.index('func (s *SMTInternalizerState) assertExpression'));hi=s.index('case ast.ASTOpIff:',lo);core=s[lo:hi]
 core=rep(core,'literals := make(', 'fd:=segFD; a:=lemmaRead(fd);start:=lemmaRead(fd);literals := make(')
 core=rep(core,'if err = s.addRootClause','argsEnd:=lemmaRead(fd); if err = s.addRootClause')
 core=rep(core,'if s.relevancy != nil {','clauseEnd:=lemmaRead(fd); if s.relevancy != nil {')
 core+='if fd>=0 { watchEnd:=lemmaRead(fd); err:=s.markRelevant(expression); markEnd:=lemmaRead(fd);println("SEG",start-a,argsEnd-start,clauseEnd-argsEnd,watchEnd-clauseEnd,markEnd-watchEnd);return err }\n'
 dest=w/'seg-internalizer.go';dest.write_text(s[:lo]+core+s[hi:]);files[str(f)]=str(dest)
else:
 build=p.parent/'build';od=w/'seg';od.mkdir(exist_ok=True)
 flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row);inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
 queue=(w/'qi_queue.cpp').read_text();helper=queue[:queue.index('//')];i=queue.index('m_context.internalize_instance(lemma, pr1, gen);')
 queue=queue[:i]+'seg_fd=fd;'+queue[i:].replace('m_context.internalize_instance(lemma, pr1, gen);','m_context.internalize_instance(lemma, pr1, gen);seg_fd=-1;',1)
 native=(p.parent/'src/smt/smt_internalizer.cpp').read_text()
 lo=native.index('case OP_OR: {',native.index('void context::internalize_assertion'));hi=native.index('case OP_IFF:',lo);core=native[lo:hi]
 core=rep(core,'literal_buffer lits;', 'int fd=seg_fd;uint64_t a=rd(fd), start=rd(fd);literal_buffer lits;')
 core=rep(core,'mk_root_clause(', 'uint64_t argsEnd=rd(fd);mk_root_clause(')
 core=rep(core,'add_or_rel_watches(to_app(n));','uint64_t clauseEnd=rd(fd);add_or_rel_watches(to_app(n));\nif(fd>=0){uint64_t watchEnd=rd(fd);mark_as_relevant(n);uint64_t markEnd=rd(fd);fprintf(stderr,"SEG %llu %llu %llu %llu %llu\\n",(unsigned long long)(start-a),(unsigned long long)(argsEnd-start),(unsigned long long)(clauseEnd-argsEnd),(unsigned long long)(watchEnd-clauseEnd),(unsigned long long)(markEnd-watchEnd));return;}')
 assert 'mark_as_relevant(n);' in native[hi:native.index('void context::assert_default',hi)]
 hdr=queue[:queue.index('/*')] if '/*' in queue else ''
 hdr=queue[:queue.index('static uint64_t rd(')]+queue[queue.index('static uint64_t rd('):queue.index('return c[0];}')+len('return c[0];}')]+'\n'
 lib=od/'libseg.a';shutil.copyfile(w/'liblemma.a',lib)
 for name,code in [('qi_queue','int seg_fd=-1;\n'+queue),('smt_internalizer',hdr+'extern int seg_fd;\n'+native[:lo]+core+native[hi:])]:
  src=od/(name+'.cpp');src.write_text(code);obj=src.with_suffix('.o');subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,src],cwd=build,check=True);subprocess.run(['ar','r',lib,obj],check=True)
 q=front/'smt/quantifier.go';dst=od/'quantifier.go';dst.write_text(q.read_text().replace('${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)));files[str(q)]=str(dst)
ov=w/('seg-'+e+'.json');ov.write_text(json.dumps({'Replace':files}));exe=w/('seg-'+e)
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if e=='z3' else 'xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
examples=Path('/home/jaten/ivy/ivy-lang-examples');ref=w.parent/'.bool-scan/golden/reference/hybrid';out=csv.writer(sys.stdout,lineterminator='\n');out.writerow(('engine','gc','round','index','empty','operands','clause','watches','mark'))
for gc in (['100','off'] if e=='g3' else ['100']):
 for i in range(5):
  r=subprocess.run(['taskset','-c','14',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',GOGC=gc,XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
  rows=[];keep=[];c=0
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'PREFIX '):c+=1
   elif l.startswith(b'SEG '):
    if not c:rows.append(l.decode().split()[1:])
   elif l.startswith(b'STAGE-COUNT '):
    if l.startswith(b'STAGE-COUNT 35 1 check '):
     assert 0<len(rows)<=203
     for j,row in enumerate(rows):out.writerow([e,gc,i+1,j+1,*row])
    c=0;rows=[]
   elif not l.startswith(b'LEM '):keep.append(l)
  assert r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes();sys.stdout.flush()
