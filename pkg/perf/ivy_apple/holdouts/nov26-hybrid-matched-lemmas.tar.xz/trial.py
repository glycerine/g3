"""Build private variants for asserted disjunction operands and watches."""
from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).resolve().parent;p=Path.cwd();base=w.parent/'.boolean-enode-cost'
for mode in sys.argv[1:]:
 files={}
 for tag,filename in [('pair','smt_qi_instance.go'),('lits','smt_internalizer.go'),('watch','smt_relevancy_asserted_or.go')]:
  if mode!=tag and mode!='combined':continue
  f=p/'smtcore'/filename;s=f.read_text()
  if tag=='pair':
   a='lemma, err = b.manager.MkOr(negatedQuantifier, simplified)';b=a+'\n if arguments!=nil && err==nil {*arguments=[]ast.ASTHandle{negatedQuantifier,simplified}}'
  elif tag=='lits':
   a='literals := make([]SMTLiteral, len(arguments))\n\t\t\tfor index, argument := range arguments {'
   b='var small [8]SMTLiteral\n var literals []SMTLiteral\n if len(arguments)<=len(small) {literals=small[:len(arguments)]} else { literals=make([]SMTLiteral,len(arguments)) }\n for index, argument := range arguments {'
  else:
   a='for _, child := range args {\n\t\tif err := p.addLiteralWatch(child, true, &handler); err != nil {'
   b='for i, child := range args {\n var err error\n if literals[i].Sign() {err=p.addLiteralWatch(child,true,&handler)} else {err=p.addWatch(child,true,&handler)}\n if err!=nil {'
  assert s.count(a)==1,(tag,s.count(a));dest=w/(mode+'-'+filename);dest.write_bytes(subprocess.check_output(['gofmt'],input=s.replace(a,b).encode()));files[str(f)]=str(dest)
 ov=w/(mode+'-trial.json');ov.write_text(json.dumps({'Replace':files}));exe=w/('trial-'+mode)
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags=xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=base/'frontend/goivy',env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
