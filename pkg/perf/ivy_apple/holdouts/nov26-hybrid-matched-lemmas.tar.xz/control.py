from pathlib import Path
import json,sys,os,csv,subprocess
w=Path(__file__).resolve().parent;old=w.parent/'.hybrid-obligations';base=w.parent/'.boolean-enode-cost';front=base/'frontend/goivy'
for eng in sys.argv[1:]:
 files=json.loads((w/(eng+'.json')).read_text())['Replace']
 k=str(front/'phase_observer_trial.go');s=Path(files[k]).read_text();assert s.count('batch==35 && goal==1')==2
 dst=w/'control-frontend.go';dst.write_text(s.replace('batch==35 && goal==1','batch==31 && goal==34'))
 files[k]=str(dst);ov=w/('control-'+eng+'.json');ov.write_text(json.dumps({'Replace':files}));exe=w/('control-'+eng)
 subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off' if eng=='z3' else 'xtrace_off','-overlay',ov,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
 s=(w/'measure.py').read_text().split("examples=Path(")[1];s='examples=Path('+s.replace('35 1','31 34').replace("counts[0,'rewrite']==counts[0,'assert']==203","counts[0,'rewrite']==counts[0,'assert']==(49 if e=='g3' else 66)")
 e=eng;exec(s)
