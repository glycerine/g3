"""Measure native operand internalization and literal lookup in separate intervals."""
from pathlib import Path
import csv,json,os,re,shlex,shutil,subprocess,sys

w=Path(__file__).resolve().parent
pkg=Path.cwd()
base=w.parent/'.boolean-enode-cost'
front=base/'frontend/goivy'
build=pkg.parent/'build'
src=(w/'seg/smt_internalizer.cpp').read_text()
old='internalize(arg, true);\n                    lits.push_back(get_literal(arg));'
assert src.count(old)==1
src=src.replace(old,'''uint64_t a=rd(fd),b=rd(fd);
                    internalize(arg, true);
                    uint64_t c=rd(fd);
                    lits.push_back(get_literal(arg));
                    if(fd>=0){uint64_t d=rd(fd);fprintf(stderr,"NATIVEOP %llu %llu %llu\\n",(unsigned long long)(b-a),(unsigned long long)(c-b),(unsigned long long)(d-c));}''')
dest=w/'native-operand'
dest.mkdir(exist_ok=True)
f=dest/'smt_internalizer.cpp'
f.write_text(src)
flags=dict(row.split('=',1) for row in (build/'config.mk').read_text().splitlines() if '=' in row)
inc=shlex.split(re.search('^includes_39 = (.*)$',(build/'Makefile').read_text(),re.M)[1])
obj=f.with_suffix('.o')
subprocess.run([flags['CXX'],*shlex.split(flags['CXXFLAGS']),*inc,'-o',obj,f],cwd=build,check=True)
lib=dest/'lib.a'
shutil.copyfile(w/'seg/libseg.a',lib)
subprocess.run(['ar','r',lib,obj],check=True)
files=json.loads((w/'seg-z3.json').read_text())['Replace']
q=front/'smt/quantifier.go'
dst=dest/'quantifier.go'
dst.write_text(Path(files[str(q)]).read_text().replace(str(w/'seg/libseg.a'),str(lib)))
files[str(q)]=str(dst)
overlay=dest/'overlay.json'
overlay.write_text(json.dumps({'Replace':files}))
exe=dest/'goivy_check'
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-modfile',base/'heap/study.mod','-tags','classic_z3,xtrace_off','-overlay',overlay,'-o',exe,'./cmd/goivy_check'],cwd=front,env=dict(os.environ,GOCACHE='/tmp/g3-nov23-day/cache'),check=True)
examples=Path('/home/jaten/ivy/ivy-lang-examples')
ref=w.parent/'.bool-scan/golden/reference/hybrid'
out=csv.writer(sys.stdout)
out.writerow(['round','empty','internalize','literal'])
for i in range(5):
    r=subprocess.run(['taskset','-c','14',exe,examples/'examples/liveness/hybrid_reliable_broadcast_cisa.ivy'],cwd=w,env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(examples/'ivy/include')),capture_output=True,check=True)
    keep,rows,c,segments=[],[],0,0
    for line in r.stderr.splitlines(keepends=True):
        if line.startswith(b'PREFIX '): c+=1
        elif line.startswith(b'NATIVEOP '):
            if c==0: rows.append(line.decode().split()[1:])
        elif line.startswith(b'SEG '): segments+=c==0
        elif line.startswith(b'STAGE-COUNT '):
            if line.startswith(b'STAGE-COUNT 35 1 check '):
                assert segments==203 and len(rows)==639
                out.writerows([i+1,*row] for row in rows)
            rows,c,segments=[],0,0
        elif not line.startswith(b'LEM '): keep.append(line)
    assert r.stdout==(ref/'stdout').read_bytes() and b''.join(keep)==(ref/'stderr').read_bytes()
