from study import *
import guarded_live as gl,macro_identity as mi,corpus_phases as cp,inspect,simplifier_rebuild as sh
d=w/'asserted-param-phases';d.mkdir(exist_ok=True)
q=pkg/'smtcore/smt_asserted_reduce.go';rw=pkg/'ast/rewriter/th_rewriter.go'
def edit(mode):
 if mode=='control':return{}
 s=q.read_text();ed={};i=s.index('settings := []struct');a='for _, setting := range settings {';b='if err := k.preprocessor.UpdateParams(&k.assertedParams); err != nil {'
 if mode=='audit':
  s=once(s,'import (','import (\n"fmt";"os"')
  i=s.index('settings := []struct');s=s[:i]+'''ready:=k.assertedPhaseReady;begin:=beginPhaseCost();var atUpdate,atFlush uint64
   defer func(){end:=readCounter();syscallEnd();fmt.Fprintf(os.Stderr,"PHASE-PARAM %t %t %d %d %d %d %d %d %d\\n",flag,ready,len(k.scopes),len(k.assertions),k.manager.ResourceLimit().Limit,end-begin,atUpdate-begin,atFlush-atUpdate,end-atFlush)}()
  '''+s[i:]
  s=once(s,b,'atUpdate=readCounter();'+b);x='if err := k.flushAssertedCache(); err != nil {';idx=s.index(x,s.index('atUpdate=readCounter();'));s=s[:idx]+'atFlush=readCounter();'+s[idx:]
  h=(w/'plan-cost/overlay/plan_cost_observer.go').read_text();h=h[:h.index('func finishPlanCost')].replace('package api','package smtcore').replace('"fmt"','').replace('"os"','').replace('func beginPlanCost','func beginPhaseCost')+'\nfunc syscallEnd(){syscall.Close(int(fd));runtime.UnlockOSThread()}\n';ed[q.parent/'asserted_param_observer.go']=h
 else:
  u=rw.read_text()+'''
 func(r *TheoryRewriter) TrialHasAssertedParams(p *uparams.ParamsRef)bool{return p!=nil && *p==r.params}
 func(r *TheoryRewriter) TrialUpdateAnd(p *uparams.ParamsRef,b bool)error{if e:=r.context.Assign(&r.params,p);e!=nil{return e};r.configuration.boolean.elimAnd=b;return nil}
 '''
  s=s[:i]+'''steady:=k.assertedPhaseReady && k.preprocessor.TrialHasAssertedParams(&k.assertedParams) && k.manager.TraceStream==nil && !ast.ASTSourceDebug && !k.manager.Budget().InjectionArmed() && !k.manager.NumeralService().RuntimeOwner().AllocationLimited()
 '''+s[i:]
  if mode=='checked':
   # Test gparams getters of every theory rewriter helper plus owner checks.
   s=once(s,'settings := []struct','''if steady{for _,module:=range []string{"rewriter","pp"}{p,err:=k.paramGlobals.SourceGetModuleName(module);if err!=nil{return err};clear,err:=k.paramContext.Empty(&p);if e:=k.paramContext.Del(&p);err==nil{err=e};if err!=nil{return err};if !clear{steady=false}}}
   settings := []struct''')
  if mode!='update':s=once(s,a,'if steady{settings=settings[:1]};'+a)
  if mode!='settings':
   s=once(s,b,'''var adjust error
   if steady{adjust=k.preprocessor.TrialUpdateAnd(&k.assertedParams,flag)}else{adjust=k.preprocessor.UpdateParams(&k.assertedParams)}
   if err:=adjust;err!=nil{''')
  ed[rw]=u
 ed[q]=s;return ed
def make(v,isshell=False):return build(d/v/('shell'if isshell else'checker'),o=overlay(d/v/'overlay',edit(v)),shell=isshell)
def cases():return mi.jobs()+[(21,'testing','jea/hermes_rmw_o3_testing.ivy','',0,1,w/'extended-phases/long/1/1/native'),(23,'apple','doc/examples/apple/ord_live.ivy','',0,1,w/'apple-original-pairs/14-native')]
def audit(b):
 def job(j):
  c,n,sp,iso,rc,_,ref=j;rd=d/'audit'/n;rd.mkdir(exist_ok=True)
  result=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=rd,capture_output=True,env=dict(env,GOMAXPROCS='1'))
  rows=[];other=[]
  for l in result.stderr.splitlines(keepends=True):
   if l.startswith(b'PHASE-PARAM '):rows.append(l.decode().split()[1:])
   else:other.append(l)
  assert result.returncode==rc and b''.join(other)==(ref/'stderr').read_bytes()and result.stdout==(ref/'stdout').read_bytes(),(n,result.returncode,b''.join(other)[-400:])
  with gzip.open(rd/'calls.csv.gz','wt')as f:
   z=csv.writer(f);z.writerow('flag phase_ready depth assertions limit total settings update flush'.split());z.writerows(rows)
  print('audit',n,len(rows),sum(int(r[5]) for r in rows),flush=True)
 with ThreadPoolExecutor(7)as e:list(e.map(job,cases()))
def phases():
 # Current paired solver-thread attribution, including the goal simplification introduced by the frontend.
 sd=d/'current-phases';cp.root=sd;o=cp.instrumentation()
 with ThreadPoolExecutor(2)as e:bs=dict(zip(('g3','native'),e.map(lambda v:build(sd/v,v,o),('g3','native'))))
 function=inspect.getsource(cp.lane).replace('range(3)','range(3)').replace('timeout=360','timeout=1700')
 ns=dict(cp.__dict__);exec(function,ns)
 js=[(j[1],j[2],j[3],j[-1],j[4])for j in cases()if j[1] in ['ordinary','tlb','hybrid_reliable_broadcast_cisa','flash2','rfn2','raftok','cf_live','dramc_nb2','testing','apple']]
 with ThreadPoolExecutor(7)as e:list(e.map(ns['lane'],[(c,[j],bs)for c,j in zip([0,2,3,6,8,9,11,12,16,22],js)]))
def main():
 vs=['control','settings','update','direct','checked']
 def pair(v):
  if v=='control':return w/'quantifier-release/checker/goivy_check',w/'quantifier-release/shell/g3'
  return make(v),make(v,True)
 with ThreadPoolExecutor(3)as e:
  af=e.submit(lambda:audit(make('audit')));pf=e.submit(phases)
  bs=dict(zip(vs,map(pair,vs)));gl.d=d;sh.d=d/'shell-phases';sh.d.mkdir(exist_ok=True);bb={v:p[0]for v,p in bs.items()};ss={v:p[1]for v,p in bs.items()};ss['native']=pkg.parent/'build/z3'
  js=[(cpu,*j[1:5],4,j[-1])for cpu,j in zip([26,28,30,32,34,36,37,40,41],(j for j in mi.jobs()if j[1]!='dramc_nb2'))];cpus=[3,6,8,12,16,20];fs=sorted((w/'simplifier-rebuild/inputs').glob('*.smt2'))
  with ThreadPoolExecutor(12)as ee:
   fut=[ee.submit(gl.measure_job,j,bb)for j in js]+[ee.submit(sh.lane,(c,fs[i::len(cpus)],ss)) for i,c in enumerate(cpus)]
   for f in fut:f.result()
  af.result();pf.result()
if __name__=='__main__':main()
