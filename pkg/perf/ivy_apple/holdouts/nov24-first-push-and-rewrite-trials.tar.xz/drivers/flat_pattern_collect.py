from study import *
import guarded_live as gl,macro_identity as mi
from collections import Counter
d=w/'flat-pattern-collect';d.mkdir(exist_ok=True)
q=pkg/'ast/pattern/collect.go';cc=pkg/'ast/pattern/candidates.go';fn=pkg/'ast/pattern/flat_collect_trial.go'
templ='''package pattern
import("math/bits";"github.com/glycerine/g3/pkg/ast")
type flatInfoTrial struct{h ast.ASTHandle;vars uint64;size uint32;forbidden bool}
type flatTrial struct{slots [WIDTH]flatInfoTrial;selected [WIDTH]uint16;count,num int;work int}
func(t *flatTrial)visit(c *patternCandidates,h ast.ASTHandle,arith ast.FamilyID,depth int)(*flatInfoTrial,bool){
 if depth>=48 || t.work>=WIDTH*4{return nil,false};t.work++
 i:=int(h.Slot())&(WIDTH-1);for t.slots[i].h!=h && !t.slots[i].h.IsNull(){i=(i+1)&(WIDTH-1)}
 slot:=&t.slots[i];if !slot.h.IsNull(){return slot,true};if t.count>=WIDTH*3/4{return nil,false};slot.h=h;t.count++
 hd,err:=c.manager.NodeHeader(h);if err!=nil{return nil,false};slot.size=1
 if hd.Kind==ast.ASTVar {v,e:=c.manager.GetVarIndex(h);if e!=nil{return nil,false};if v<c.numBindings{slot.vars=uint64(1)<<v};return slot,true}
 if hd.Kind!=ast.ASTApp || hd.NumArgs>WIDTH{return nil,false}
 for j:=uint32(0);j<hd.NumArgs;j++{a,e:=c.manager.GetArg(h,j);if e!=nil{return nil,false};ch,ok:=t.visit(c,a,arith,depth+1);if !ok{return nil,false};slot.size+=ch.size;slot.vars|=ch.vars;slot.forbidden=slot.forbidden || ch.forbidden}
 if hd.NumArgs==0{return slot,true}
 forbidden,e:=c.forbiddenApp(h);if e!=nil{return nil,false};slot.forbidden=slot.forbidden || forbidden
 if !slot.forbidden && slot.vars!=0 && (hd.Family!=arith || !c.nestedArithOnly && hd.DeclKind>=9 && hd.DeclKind<=13){t.selected[t.num]=uint16(i);t.num++};return slot,true
}
func(t *flatTrial)publish(c *patternCandidates)error{
 var vs [64]uint32
 for _,i:=range t.selected[:t.num]{e:=&t.slots[i];num:=0;for m:=e.vars;m!=0;m&=m-1{vs[num]=uint32(bits.TrailingZeros64(m));num++};if err:=c.addCandidate(e.h,vs[:num],e.size);err!=nil{return err}}
 return nil
}
'''
guard='!ast.ASTValidateHandles && !ast.ASTSourceDebug && !diagnostic.TraceCompiled() && c.manager.TraceStream==nil && !c.manager.Budget().InjectionArmed() && !c.manager.NumeralService().RuntimeOwner().AllocationLimited() && c.numBindings<=64'
def edits(v):
 if v=='control':return{}
 s=q.read_text();e={};anchor='cache := make(map[collectKey]*collectedInfo)'
 if v in ('borrow','skip','both'):
  gate='ok,e:=c.manager.HasQuantifiers(body);rc,e2:=c.manager.GetRefCount(body);simple:=e==nil && !ok && rc>0 && e2==nil && '+guard
  if v in ('borrow','both'):
   e[cc]=once(cc.read_text(),'type patternCandidates struct {','type patternCandidates struct {\ntrialBorrow bool')
   gate+='\n c.trialBorrow=simple;defer func(){c.trialBorrow=false}()'
   s=once(s,'if info != nil {\n\t\tc.traceCollectedInfoAllocated','if info != nil && !c.trialBorrow{\n\t\tc.traceCollectedInfoAllocated')
  if v in ('skip','both'):s=once(s,'if err = c.traceCollectVisit(key);','if simple {if _,seen:=cache[key];seen{stack=stack[:len(stack)-1];continue}}\nif err = c.traceCollectVisit(key);')
  s=once(s,anchor,gate+'\n'+anchor)
 else:
  width=int(v.split('-')[-1]) if '-'in v else 64
  e[fn]=templ.replace('WIDTH',str(width))
  x='''if '''+guard+'''{nested,e:=c.manager.HasQuantifiers(body);rc,e2:=c.manager.GetRefCount(body);if e==nil && !nested && e2==nil && rc>0{var trial flatTrial;if _,ok:=trial.visit(c,body,arith,0);ok{return trial.publish(c)}}}'''
  if v=='audit':
   s=once(s,'import (','import (\n"fmt";"os"')
   x=x.replace('return trial.publish(c)','''defer func(){if err!=nil{return};order:=[]ast.ASTHandle{};for _,i:=range trial.selected[:trial.num]{a:=trial.slots[i];excluded:=false;for _,n:=range c.noPatterns{if n==a.h{excluded=true;break}};if excluded{continue};info,ok:=c.info[a.h];var mask uint64;for n:=range info.freeVars{mask|=uint64(1)<<n};if !ok||info.size!=a.size||mask!=a.vars{panic("incorrect pattern prediction")};order=append(order,a.h)};if len(order)!=len(c.candidates){panic("candidate count")};for j,h:=range order{if h!=c.candidates[j]{panic("candidate order")}};fmt.Fprintln(os.Stderr,"MATCH-PATTERN",trial.count,trial.num)}()''')
   x='defer func(){fmt.Fprintln(os.Stderr,"COLLECT-PATTERN",c.numBindings)}()\n'+x
  s=once(s,anchor,x+'\n'+anchor)
 e[q]=s;return e
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v))
 with(w/'build.lock').open('a')as f,(od/'focused.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-overlay='+str(o),'-run','PatternInference|SMTAssertedPattern','-count=1','./ast/pattern','./smtcore'],cwd=pkg,stdout=log,stderr=log)
 return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def audit(j,b):
 cpu,n,sp,iso,rc,_,ref=j;od=d/'audit'/n;od.mkdir(exist_ok=True);ct=Counter()
 with (od/'stdout').open('wb')as so,(od/'stderr').open('wb')as se,subprocess.Popen(['taskset','-c',str(cpu),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=od,env=dict(env,GOMAXPROCS='1'),stdout=so,stderr=subprocess.PIPE)as proc:
  for l in proc.stderr:
   if l.startswith((b'MATCH-PATTERN ',b'COLLECT-PATTERN ')):ct[tuple(l.decode().split())]+=1
   else:se.write(l)
  code=proc.wait()
 assert code==rc and all((od/k).read_bytes()==(ref/k).read_bytes()for k in ('stdout','stderr')),(n,code,(od/'stderr').read_bytes()[-420:])
 with (od/'coverage.csv').open('w')as f:
  z=csv.writer(f);z.writerow(['stage','bindings_or_terms','candidates','calls'])
  for k,v in ct.items():z.writerow([*k,*(['']if len(k)==2 else[]),v])
 print('audit',n,sum(v for k,v in ct.items()if k[0]=='MATCH-PATTERN'),sum(v for k,v in ct.items()if k[0]=='COLLECT-PATTERN'),flush=True)
def main():
 vs=['control','borrow','skip','both','flat-32','flat-64','flat-128','audit']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 a,_=bs.pop('audit');gl.d=d;bb={v:b[0]for v,b in bs.items()}
 js=[(c,*j[1:5],4,j[-1])for c,j in zip([25,26,27,28,29,30,32,33,34],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(16)as e:
  fs=[e.submit(gl.measure_job,j,bb)for j in js]+[e.submit(audit,j,a)for j in mi.jobs()]
  for f in fs:f.result()
if __name__=='__main__':main()
