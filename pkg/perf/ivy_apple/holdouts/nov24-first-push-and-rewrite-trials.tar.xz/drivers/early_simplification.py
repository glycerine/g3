from study import *
import macro_identity as mi,guarded_live as gl
from panel import CASES
d=w/'early-simplification';d.mkdir(exist_ok=True);q=ivy.resolve()/'z3bridge_solver_model.go'
def source(v):
 s=q.read_text();a=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('\n}',a)+2;pre,b,post=s[:a],s[a:j],s[j:]
 i=b.index('finalCheck := check');j=b.index('if s.opts.Incremental {',i);old=b[i:j];transform='if !xtracer.Enabled || xtracer.Suppressed {\n\t\t\t\t\tzCond = z3solver.SimplifyVerificationCondition(zCond)\n\t\t\t\t}'
 if v.startswith('before'):b=once(b,old,transform+'\n'+once(old,transform,''))
 elif v.startswith('retry'):
  act=old[:old.index('if proveGoal(zCond)')]+'''orig:=zCond
   yes:=proveGoal(orig)
   if !yes && (!xtracer.Enabled || xtracer.Suppressed){zCond=z3solver.SimplifyVerificationCondition(orig);if !orig.Equal(zCond){yes=proveGoal(zCond)}}
   if yes'''+old[old.index('if proveGoal(zCond)')+len('if proveGoal(zCond)'):]
  b=once(b,old,once(act,'}\n\t\t\t\t'+transform,'} else '+transform))
 if 'assume'in v:
  b=once(b,'z3solver.Assert(zCond)\n\t\t\t\tassumes', 'if !xtracer.Enabled || xtracer.Suppressed{zCond=z3solver.SimplifyVerificationCondition(zCond)};z3solver.Assert(zCond)\n\t\t\t\tassumes')
 if 'base'in v:b=once(b,'z3solver.Assert(zc)\n\n\t// Process', 'if !xtracer.Enabled || xtracer.Suppressed{zc=z3solver.SimplifyVerificationCondition(zc)};z3solver.Assert(zc)\n\n\t// Process')
 return {q:pre+b+post}
def mk(v):
 if v=='control':return w/'macro-release/checker/goivy_check'
 sd=d/v;return build(sd/'checker',o=overlay(sd/'overlay',source(v)))
def main():
 vs=['control','before','retry','before-assume','base','before-base','retry-base','before-base-assume']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;js=mi.jobs()
 with ThreadPoolExecutor(len(js))as e:list(e.map(lambda j:gl.measure_job((*j[:-2],3,j[-1]),bs),js))
if __name__=='__main__':main()
