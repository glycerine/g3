from study import *
import conditional_changes as ch,conditional_pass as cp,macro_identity as mi,guarded_live as gl
from panel import CASES
d=w/'conditional-rules';d.mkdir(exist_ok=True)
def edits(v):
 if v=='control':return{}
 ed=ch.edits('changed');s=ed[ch.ite]
 if v.startswith('rule') or v in ('single','same-side','nonbool','dt','term','datatype-or-uf','uf','single-nonbool'):
  cond=''
  if v in ('dt','uf','datatype-or-uf'):
   cond='sort,e:=m.GetSort(shared);if e!=nil{return false};fid,e:=m.GetFamilyID(sort);if e!=nil{return false};'
   if v=='dt':cond+='dt,e:=m.DatatypeFamilyID();return e==nil && fid==dt'
   elif v=='uf':cond+='return fid==ast.NullFamilyID'
   else:cond+='dt,e:=m.DatatypeFamilyID();return e==nil && (fid==dt || fid==ast.NullFamilyID)'
  elif v in ('nonbool','single-nonbool'):cond='b,e:=m.MkBoolSort();if e!=nil{return false};s,e:=m.GetSort(shared);return e==nil && s!=b'
  elif v=='term':cond='h,e:=m.NodeHeader(shared);return e==nil && h.Kind==ast.ASTApp && h.NumArgs>0'
  else:cond='return true'
  rules=([int(v[-1])]if v.startswith('rule')else [0,1,3,4]if v in ('single','single-nonbool')else [1,3]if v=='same-side'else list(range(5)))
  x='if tITE && (rw.iteExtraRules || rw.factorNestedITE) {';s=once(s,x,'''selected:=func(rule int,shared ast.ASTHandle)bool{
   if rw.iteExtraRules{return true}
   if !('''+'||'.join('rule=='+str(i)for i in rules)+'''){return false}
   '''+cond+'''
  }
  '''+x)
  # Only reached in the extra-rules arm; earlier simplifications have their own conditions.
  start=s.index('selected:=func(');p,s1=s[:start],s[start:]
  for i,(k,h)in enumerate([('f == t1','f'),('f == t2','f'),('eITE && (same || swapped)','t1'),('t == e1','t'),('t == e2','t')]):
   s1=once(s1,'if '+k+' {','if '+k+' && selected('+str(i)+','+h+') {')
  ed[ch.ite]=p+s1
 return ed
def mk(v):
 od=d/v;return build(od/'checker',o=overlay(od/'overlay',edits(v)))
def main():
 vs=['control','single','same-side','nonbool','dt','uf','datatype-or-uf','term','single-nonbool','rule0','rule1','rule2','rule3','rule4']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;js=[j for j in mi.jobs()if j[1]in ['ordinary','tlb','rfn2','hybrid_reliable_broadcast_cisa','toy-consensus','raftok','raft_no_assume_test','flash2']]
 n='raft_no_assume';sp,iso,_,a,b=CASES[n];js.append((12,n,sp,iso,int(bool(a or b)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(len(js))as ex:list(ex.map(lambda j:gl.measure_job((*j[:-2],3,j[-1]),bs),js))
if __name__=='__main__':main()
