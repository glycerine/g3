from study import *
import conditional_pass as cp,ground_release_controls as gc,verification_frontier as vf
d=w/'conditional-controls';d.mkdir(exist_ok=True)
def corpus():
 gc.d=d;gc.corpus(cp.d/'both/checker/goivy_check')
def quiet():
 run([sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',cp.d/'both/checker/goivy_check','--previous',cp.d/'control/checker/goivy_check','--native',w/'key-release/native/goivy_check','--rounds','5','--max-attempts','30','--wait-seconds','5400','--min-idle','.95','--cpu','15','--spec',examples/'jea/hermes_rmw_o3.ivy','--reference',vf.reference('jea/hermes_rmw_o3.ivy'),'--perf',perf,'--output',d/'ordinary-quiet'],stdout=subprocess.DEVNULL);print('quiet',flush=True)
def bench():
 from ord_replay import parsed
 dr=d/'fixtures';dr.mkdir(exist_ok=True);keys=['0005-0069','0014-0069','0010-0070','0010-0067','0028-0009','0013-0056','0029-0009','0013-0067','0005-0078','0025-0010']
 for key in keys:
  source=w/'ord-holdout-capture/hermes'/(key+'.smt2.gz');ds,bs,goal=parsed(source);(dr/(key+'.smt2.gz')).write_bytes(gzip.compress(('\n'.join([*ds,bs,goal])+'\n').encode(),mtime=0))
 ed=cp.edits('both')
 orig=pkg/'api/api_enumeration_refutation_benchmark_test.go';s=orig.read_text()
 needle='s, err := c.NewSolverForIncrementalChecks()';s=once(s,needle,'''return checkVerificationSiblingsUsing(c,forms,useBatch,c.NewSolverForIncrementalChecks)
 }
 func checkVerificationSiblingsUsing(c *SMTContext, forms []ast.ASTHandle,useBatch bool,makeSolver func()(*APISimpleSolver,error))(proved int,err error){
  s,err:=makeSolver()''')
 ed[orig]=s
 q=pkg/'api/api_conditional_trial_benchmark_test.go';ed[q]='''package api
 import("testing";"fmt";"os";"github.com/glycerine/g3/pkg/ast")
 func BenchmarkConditionalTrial(b *testing.B){
  key:=os.Getenv("CASE");mode:=os.Getenv("MODE")
  c,forms:=loadVerificationGoals(b,"'''+str(dr)+'''/"+key+".smt2.gz",1)
  h,e:=c.SimplifyVerificationCondition(forms[1]);if e!=nil{b.Fatal(e)}
  g,e:=c.Manager().RefGet(h);if e!=nil{b.Fatal(e)}
  b.Cleanup(func(){if e:=c.Manager().DelRef(&h);e!=nil{b.Error(e)}})
  b.Run(fmt.Sprintf("%s/%s",key,mode),func(b *testing.B){
   makeSolver:=c.NewSolverForIncrementalChecks;if mode=="factored"{makeSolver=c.NewSolverForVerificationGoals}
   for b.Loop(){_,e:=checkVerificationSiblingsUsing(c,[]ast.ASTHandle{forms[0],g},false,makeSolver);if e!=nil{b.Fatal(e)}}
  })
 }
 '''
 # API Manager() is borrowed via checker's api context ManagerHandle accessor.
 ed[q]=ed[q].replace('g,e:=c.Manager().RefGet(h)','manager,e:=c.Manager();if e!=nil{b.Fatal(e)};g,e:=manager.RefGet(h)').replace('c.Manager().DelRef','manager.DelRef')
 od=d/'bench-build';o=overlay(od/'overlay',ed);b=od/'api.test'
 with(w/'build.lock').open('a')as lk,(od/'build.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-c','-o',b,'-overlay='+str(o),'./api'],cwd=pkg,stdout=f,stderr=f)
 def lane(t):
  c,ls=t
  with(dr/f'{c}.csv').open('w')as f:
   z=csv.writer(f);z.writerow('goal round mode ns bytes allocs'.split())
   for key in ls:
    for i in range(7):
     for v in (('base','factored')if i%2==0 else('factored','base')):
      env1=dict(env,GOMAXPROCS='1',MODE=v,CASE=key);p=subprocess.run(['taskset','-c',str(c),b,'-test.run','^$','-test.bench','^BenchmarkConditionalTrial$','-test.benchtime=3x','-test.benchmem','-test.cpu=1','-test.timeout=180s'],cwd=pkg/'api',env=env1,capture_output=True,timeout=200);m=re.search(rb'(\d+)\s+ns/op\s+(\d+)\s+B/op\s+(\d+)\s+allocs/op',p.stdout);assert p.returncode==0 and m,(key,v,p.stdout[-700:],p.stderr[-200:]);z.writerow([key,i+1,v,*[x.decode()for x in m.groups()]]);f.flush()
    print('benchmark',key,flush=True)
 cs=[0,4,6,8,12,16];jobs=[(c,keys[i::len(cs)])for i,c in enumerate(cs)]
 with ThreadPoolExecutor(len(cs))as e:list(e.map(lane,jobs))
if __name__=='__main__':{'quiet':quiet,'corpus':corpus,'bench':bench}[sys.argv[1]]()
