from study import *
import scoped_conditional as sc,corpus_phases as cp,binder_exits as binder,verification_frontier as vf
from panel import CASES
d=w/'conditional-evidence';d.mkdir(exist_ok=True)
js=[('ordinary','jea/hermes_rmw_o3.ivy','',0,vf.reference('jea/hermes_rmw_o3.ivy')),('testing','jea/hermes_rmw_o3_testing.ivy','',0,w/'extended-phases/long/1/1/native'),('apple','doc/examples/apple/ord_live.ivy','',0,w/'apple-original-pairs/14-native')]
for n in ('tlb','rfn2','flash2','toy-consensus','raft_no_assume_test','hybrid_reliable_broadcast_cisa'):
 sp,iso,_,a,b=CASES[n];js.append((n,sp,iso,int(bool(a or b)),next((prior/'end-panel-final').glob('*/'+n+'/1/native'))))
def phases():
 cp.root=d/'phases';ov=cp.instrumentation();src={Path(k).resolve():Path(v).read_text()for k,v in json.loads(ov.read_text())['Replace'].items()}
 def prep(v):
  od=d/'phases'/v;return build(od/'checker','native'if v=='native'else'g3',overlay(od/'overlay',{**src,**sc.edits('control'if v=='native'else v)}))
 with ThreadPoolExecutor(2)as e:bs=dict(zip(['control','guarded','native'],e.map(prep,['control','guarded','native'])))
 def work(t):
  c,j=t;n,sp,iso,rc,rf=j
  for i in range(2):
   for v in list(bs)[::1 if i==0 else -1]:
    od=d/'phases'/n/f'{i+1}-{v}';od.mkdir(parents=True,exist_ok=True)
    p=subprocess.run(['taskset','-c',str(c),bs[v],*(['isolate='+iso]if iso else[]),examples/sp],cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1'));other=b''.join(l for l in p.stderr.splitlines(keepends=True)if not l.startswith(b'VC-PHASE '));assert p.returncode==rc and p.stdout==(rf/'stdout').read_bytes()and other==(rf/'stderr').read_bytes(),(n,v,p.returncode,other[-380:])
    with gzip.open(od/'counters.csv.gz','wt')as f:
     z=csv.writer(f);z.writerow('batch goal stage result instructions'.split());z.writerows(l.decode().split()[1:]for l in p.stderr.splitlines()if l.startswith(b'VC-PHASE '))
    print('phase',n,i,v,flush=True)
 with ThreadPoolExecutor(6)as e:list(e.map(work,zip([0,18,22,3,6,8,12,14,16],js)))
def export():
 t=pkg/'ast/rewriter/bool_rewriter_ite.go';ed=sc.edits('guarded');s=ed[t];s=once(s,'changed := false','originalC,originalT,originalF:=c,t,f;changed := false')
 a='return brRewrite1, m.SetRef(out, result)';assert s.count(a)==5
 parts=s.split(a);s=parts[0]
 for i,k in enumerate(parts[1:]):
  s+='if e=m.SetRef(out,result);e!=nil{return brFailed,e};if rw.factorNestedITE{recordConditionalTrial(m,'+str(i)+',originalC,originalT,originalF,result)};return brRewrite1,nil'+k
 ed[t]=s;ed[t.parent/'conditional_miter_trial.go']='''package rewriter
 import("bytes";"os";"fmt";"github.com/glycerine/g3/pkg/ast";usymbol "github.com/glycerine/g3/pkg/util/symbol")
 var totalsTrial [5]int
 func recordConditionalTrial(m *ast.ASTManager,rule int,c,t,f,r ast.ASTHandle){
  totalsTrial[rule]++;n:=totalsTrial[rule];if n>4 && (n%113!=0 || n>48*113){return}
  // Each standalone file asks whether these two *terms* can have different values.
  var refs []ast.ASTRef
  pin:=func(h ast.ASTHandle,e error)ast.ASTHandle{if e!=nil{panic(e)};p,e:=m.NewRef(h);if e!=nil{panic(e)};refs=append(refs,p);return h}
  defer func(){for i:=len(refs)-1;i>=0;i--{if e:=m.DelRef(&refs[i]);e!=nil{panic(e)}}}()
  old:=pin(m.MkIte(c,t,f));eq:=pin(m.MkEq(old,r));vars,e:=NewExprFreeVars(m);if e!=nil{panic(e)};if e=vars.Collect(eq);e!=nil{panic(e)}
  if !vars.Empty(){sort:=pin(m.MkBoolSort());if e=vars.SetDefaultSort(sort);e!=nil{panic(e)};vars.Reverse();sorts:=vars.Sorts();names:=make([]usymbol.Symbol,len(sorts));for i:=range names{names[i]=usymbol.Numerical(uint32(i))};eq=pin(m.MkQuantifier(ast.ASTQuantifierSpec{Forall:true,Sorts:sorts,Names:names,Weight:1,Body:eq}))}
  query:=pin(m.MkNot(eq));pp,e:=ast.NewLegacySMTPrinter(m);if e!=nil{panic(e)};var buf bytes.Buffer;if e=pp.DisplayBenchmark(&buf,query,ast.LegacySMTBenchmarkConfig{});e!=nil{panic(e)}
  if e=os.WriteFile(fmt.Sprintf("%d-%06d.smt2",rule,n),buf.Bytes(),0600);e!=nil{panic(e)}
 }
 '''
 od=d/'miter';b=build(od/'checker',o=overlay(od/'overlay',ed))
 def work(j):
  n,sp,iso,rc,rf=j;sd=od/n;sd.mkdir(exist_ok=True);p=subprocess.run([b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=sd,env=dict(env,GOMAXPROCS='1'),capture_output=True);assert p.returncode==rc and p.stdout==(rf/'stdout').read_bytes() and p.stderr==(rf/'stderr').read_bytes(),(n,p.returncode,p.stderr[-300:])
  files=sorted(sd.glob('*.smt2'));z3=pkg.parent/'build/z3';second=Path('/usr/bin/z3')
  with(sd/'queries.csv').open('w')as f:
   z=csv.writer(f);z.writerow(['file','native','installed_z3'])
   for q in files:
    result=[]
    for exe in [z3,second]:
     if not exe.exists():result.append('unavailable');continue
     r=subprocess.run([exe,'-smt2',q],capture_output=True,timeout=25);assert r.returncode==0 and r.stdout.strip()==b'unsat'and not r.stderr,(n,q.name,r.stdout[:160],r.stderr[:160]);result.append('unsat')
    z.writerow([q.name,*result]);f.flush()
  print('miter',n,len(files),flush=True)
 with ThreadPoolExecutor(5)as e:list(e.map(work,js))
def traces():
 def mk(v):
  sd=d/'trace'/v;o=overlay(sd/'overlay',sc.edits(v))
  with(w/'build.lock').open('a')as lk,(sd/'build.log').open('w')as f:
   fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-mod=readonly','-overlay='+str(o),'-o',sd/'goivy_check','./cmd/goivy_check'],cwd=ivy,stdout=f,stderr=f)
  if not(sd/'abc').exists():(sd/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
  return sd/'goivy_check'
 with ThreadPoolExecutor(2)as e:bs=dict(zip(['before-trace','after-trace'],e.map(mk,['control','guarded'])))
 binder.root=d/'trace';binder.trace(bs)
if __name__=='__main__':{'phases':phases,'traces':traces,'export':export}[sys.argv[1]]()
