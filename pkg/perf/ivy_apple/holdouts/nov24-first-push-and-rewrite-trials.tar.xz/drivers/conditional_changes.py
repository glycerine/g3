from study import *
import conditional_pass as cp,scoped_conditional as sc,guarded_live as gl,macro_identity as mi
d=w/'conditional-changes';d.mkdir(exist_ok=True)
boolean=pkg/'ast/rewriter/bool_rewriter.go';ite=pkg/'ast/rewriter/bool_rewriter_ite.go';frontend=ivy.resolve()/'z3bridge_solver_model.go';native=ivy.resolve()/'smt/native_verification_condition.go';sb=pkg/'smtcore/smt_solver.go';kernel=pkg/'smtcore/smt_kernel.go'
def edits(v):
 if v=='control':return{}
 ed=cp.edits('end')
 s=ed[boolean];ed[boolean]=once(s,'factorNestedITE bool','factorNestedITE bool\n factoredConditional bool')
 s=ed[ite];k='return brRewrite1, m.SetRef(out, result)';assert s.count(k)==5;s=s.replace(k,'rw.factoredConditional=rw.factorNestedITE\n'+k);ed[ite]=s
 r=cp.rw.read_text()
 x='// FreshDefault realizes';helper='''// WithFactoredConditionals runs an assertion pass with the shared-branch
 // rules for nested ITEs. Discard entries produced by those rules before the
 // regular traversal uses the same rewrite cache.
 func(r *TheoryRewriter) WithFactoredConditionals(run func()error)(err error){
  if err=r.open();err!=nil{return err}
  c:=&r.configuration;b:=c.boolean
  if b.iteExtraRules || b.factorNestedITE || c.maxSteps!=^uint32(0) || c.maxMemory!=uint64(^uint32(0))*1024*1024{return run()}
  b.factorNestedITE=true
  defer func(){
   b.factorNestedITE=false
   if b.factoredConditional {
    b.factoredConditional=false
    var subst *ast.ASTExprSubstitution
    if c.hasSubstitution{value:=c.substitution;subst=&value}
    err=errors.Join(err,r.SetSubstitution(subst))
   }
  }()
  return run()
 }
 '''
 ed[cp.rw]=once(r,x,helper+x)
 if v=='lazy':
  # Existing outer pass flushes reset the marker. Only flush on return if no existing reset ran.
  ed[cp.rw]=once(ed[cp.rw],'func (c *theoryRewriterConfiguration) Reset() {','func (c *theoryRewriterConfiguration) Reset() {\n c.boolean.factoredConditional=false')
 s=cp.reduce.read_text();s=once(s,'import (','import (\n"github.com/glycerine/g3/pkg/util/diagnostic"')
 x='batch, err := macros.NewFormulaBatch(k.manager)';pos=s.index(x,s.index('func (k *SMTKernel) reducePendingAssertions'))
 s=s[:pos]+'''if k.factorScopedConditionals && len(k.scopes)>0 && !ast.ASTSourceDebug && !diagnostic.TraceCompiled() && k.manager.TraceStream==nil && !k.manager.Budget().InjectionArmed() && !k.manager.NumeralService().RuntimeOwner().AllocationLimited() && k.manager.ResourceLimit().Limit==0 && !k.manager.ResourceLimit().CancelFlag() && k.smtState.MaxConflicts==^uint32(0) && !k.preprocessor.ProofGen(){
   proofs,err:=k.manager.ProofsEnabled();if err!=nil{return err};if !proofs{return k.preprocessor.WithFactoredConditionals(k.simplifyPendingRows)}
 }
 return k.simplifyPendingRows()
 }
 func(k *SMTKernel)simplifyPendingRows()(result error){
 '''+s[pos:]
 ed[cp.reduce]=s
 smt=cp.smt;s=smt.read_text();s=once(s,'logic  string','logic  string\n verificationGoals bool');x='c, err := newG3Solver(ctx.c, logic)';s=once(s,x,'''return ctx.newSolver(logic,false)
 }
 // NewVerificationGoalSolver selects g3's simplifier for scoped verification goals.
 func(ctx *Z3Context)NewVerificationGoalSolver()*Z3Solver{return ctx.newSolver("",true)}
 func(ctx *Z3Context)newSolver(logic string,goals bool)*Z3Solver{
 c,err:=newG3Solver(ctx.c,logic,goals)''')
 s=once(s,'params: p, logic: logic','params: p, logic: logic,verificationGoals:goals')
 s=once(s,'func newG3Solver(ctx *api.SMTContext, logic string)','func newG3Solver(ctx *api.SMTContext,logic string,goals bool)')
 s=once(s,'if factory, ok := any(ctx).(interface {','''if goals{
   if factory,ok:=any(ctx).(interface{NewSolverForVerificationGoals()(*api.APISimpleSolver,error)});ok{return factory.NewSolverForVerificationGoals()}
 }
 if factory, ok := any(ctx).(interface {''');s=once(s,'newG3Solver(s.ctx.c, s.logic)','newG3Solver(s.ctx.c,s.logic,s.verificationGoals)');ed[smt]=s
 ed[native]=native.read_text()+'''
 func(ctx *Z3Context)NewVerificationGoalSolver()*Z3Solver{return ctx.NewZ3Solver()}
 '''
 s=frontend.read_text();x='s.showVCsBase(clauses)\n\n\tz3solver := s.newZ3Solver()';s=once(s,x,'''s.showVCsBase(clauses)
 newSolver:=s.tr.Ctx.NewZ3Solver
 if s.opts.Incremental && len(finalCond)>0 && !xtracer.Enabled{newSolver=s.tr.Ctx.NewVerificationGoalSolver}
 z3solver:=newSolver();s.applyZ3SolverOptions(z3solver)''');ed[frontend]=s
 if v=='ground-only' or v=='quantified-only':
  x='if k.factorScopedConditionals &&';ed[cp.reduce]=once(ed[cp.reduce],x,'if '+('!k.assertedHasQuantifiers'if v=='ground-only'else'k.assertedHasQuantifiers')+' && k.factorScopedConditionals &&')
 return ed
def mk(v):
 od=d/v;o=overlay(od/'overlay',edits(v));return build(od/'checker',o=o)
def main():
 vs=['control','changed','lazy','quantified-only','ground-only']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;js=mi.jobs()+[(17,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native')]
 with ThreadPoolExecutor(11)as ex:list(ex.map(lambda j:gl.measure_job(j,bs if j[0]not in (17,22)else{k:bs[k]for k in ['control','changed','quantified-only']}),js))
if __name__=='__main__':main()
