from study import *
import guarded_live as gl,macro_identity as mi,flat_pattern_collect as fc
from collections import Counter
d=w/'pattern-body-walk';d.mkdir(exist_ok=True)
engine=pkg/'ast/rewriter/rewriter_engine.go';front=pkg/'ast/pattern/rewriter.go';tr=pkg/'ast/rewriter/traversal.go';src=pkg/'ast/rewriter/pattern_body_trial.go'
algo='''package rewriter
import("github.com/glycerine/g3/pkg/ast";"github.com/glycerine/g3/pkg/util/diagnostic")
type bodyPlanTrial struct{terms [WIDTH]ast.ASTHandle; nodes,visits,shared int; order [WIDTH]ast.ASTHandle}
func(p *bodyPlanTrial)visit(m *ast.ASTManager,h ast.ASTHandle,isRoot bool)bool{
 if p.visits>=WIDTH*2{return false};p.visits++
 hd,e:=m.NodeHeader(h);if e!=nil{return false};if hd.Kind==ast.ASTVar{return true};if hd.Kind!=ast.ASTApp{return false};if hd.NumArgs==0{return true}
 if hd.Family==m.BasicFamilyID() && hd.DeclKind==ast.ASTOpIte {if hd.NumArgs!=3{return false};cond,e:=m.GetArg(h,0);if e!=nil || m.IsTrue(cond) || m.IsFalse(cond){return false}}
 cache:=!isRoot && hd.RefCount>1
 if cache{for _,seen:=range p.terms[:p.nodes]{if seen==h{return true}}}
 if p.nodes==WIDTH{return false};p.terms[p.nodes]=h;p.nodes++
 for i:=uint32(0);i<hd.NumArgs;i++{a,e:=m.GetArg(h,i);if e!=nil || !p.visit(m,a,false){return false}}
 if cache{p.order[p.shared]=h;p.shared++};return true
}
func(r *rewriterEngine)trialPatternBodyPlan(m *ast.ASTManager,h ast.ASTHandle,p *bodyPlanTrial)bool{
 if ast.ASTValidateHandles||ast.ASTSourceDebug||diagnostic.TraceCompiled()||m.TraceStream!=nil||m.Budget().InjectionArmed()||m.NumeralService().RuntimeOwner().AllocationLimited(){return false}
 if x,e:=m.HasQuantifiers(h);e!=nil||x{return false}
 if prev,e:=m.RefGetHeld(r.r);e!=nil || !prev.IsNull(){return false}
 return p.visit(m,h,true)
}
'''
def edits(v):
 if v=='control':return {}
 e={};width=int(v.split('-')[-1])if '-'in v else 48
 s=engine.read_text();s=once(s,'modelBooleanShortCircuit bool','modelBooleanShortCircuit bool\ntrialPattern bool\ntrialAuditQ ast.ASTHandle\ntrialBegin,trialSteps uint32')
 u=tr.read_text()+'\nfunc(t *Traversal)TrialPatternOnly(){t.engine.trialPattern=true}\n';t=front.read_text();x='return r, nil';t=once(t,x,'if !proofs{r.traversal.TrialPatternOnly()}\n'+x)
 i=s.index('func (r *rewriterEngine) processQuantifier()')
 head,tail=s[:i],s[i:];x='done, e := r.visit(h, fr.maxDepth())';assert tail.count(x)==1
 common='''if r.trialPattern && i==0 && np==0 && nn==0 && fr.maxDepth()==3 {var p bodyPlanTrial;if r.trialPatternBodyPlan(m,h,&p){'''
 if v=='audit':
  common+='''r.trialAuditQ=q;r.trialBegin=r.numSteps;r.trialSteps=uint32(2*p.nodes)'''
  y='pa := ast.SliceArguments(r.patterns)';tail=once(tail,y,'''if r.trialPattern{if q==r.trialAuditQ{fmt.Fprintln(os.Stderr,"PATTERN-WALK",r.trialSteps,r.numSteps-r.trialBegin,newBody==body);r.trialAuditQ=ast.ASTHandle{}}else{fmt.Fprintln(os.Stderr,"WALK-FALLBACK")}}
  '''+y)
  head=once(head,'import (','import (\n"fmt";"os"')if '"fmt"'not in head else once(head,'import (','import (\n"os"')
 else:
  common+='''steps:=uint32(2*p.nodes)
  if !c.cancelCheck || m.ResourceLimit().TryIncOffset(steps){
   CACHE
   r.numSteps+=steps;if e:=appendRewriterRoot(m,&c.results,h);e!=nil{return e};continue}'''.replace('CACHE','''for _,x:=range p.order[:p.shared]{if e:=c.cacheResult(x,x);e!=nil{return e}}'''if 'keep'in v else'')
 tail=once(tail,x,common+'}}\n'+x);e[engine]=head+tail;e[tr]=u;e[front]=t;e[src]=algo.replace('WIDTH',str(width))
 return e
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v))
 with(w/'build.lock').open('a')as f,(od/'focused.log').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','4','-overlay='+str(o),'-run','PatternInference|SMTAssertedPattern|Rewriter.*Quantifier','-count=1','./ast/pattern','./ast/rewriter','./smtcore'],cwd=pkg,stdout=log,stderr=log)
 return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def audit(j,b):
 c,n,sp,iso,rc,_,ref=j;od=d/'audit'/n;od.mkdir(exist_ok=True);ct=Counter()
 with(od/'stdout').open('wb')as so,(od/'stderr').open('wb')as se,subprocess.Popen(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=od,env=dict(env,GOMAXPROCS='1'),stdout=so,stderr=subprocess.PIPE)as proc:
  for l in proc.stderr:
   if l.startswith((b'PATTERN-WALK ',b'WALK-FALLBACK')):ct[tuple(l.decode().split())]+=1
   else:se.write(l)
  code=proc.wait()
 assert code==rc and all((od/k).read_bytes()==(ref/k).read_bytes()for k in('stdout','stderr')),(n,code)
 with(od/'coverage.csv').open('w')as f:
  z=csv.writer(f);z.writerow('action predicted actual unchanged calls'.split())
  for key,num in ct.items():z.writerow([*key,*(['','','']if len(key)==1 else[]),num])
 totals=[sum(n for k,n in ct.items()if len(k)==4 and (k[1]==k[2] and k[3]=='true')==ok)for ok in (False,True)]
 print('audit',n,*totals,ct[('WALK-FALLBACK',)],flush=True)
def main():
 vs=['control','skip-16','skip-48','skip-128','keep-16','keep-48','keep-128','audit']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 a,_=bs.pop('audit');gl.d=d;bb={v:b[0]for v,b in bs.items()}
 js=[(c,*j[1:5],3,j[-1])for c,j in zip([0,1,2,3,6,8,9,10,12],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 with ThreadPoolExecutor(18)as e:
  fs=[e.submit(gl.measure_job,j,bb)for j in js]+[e.submit(audit,j,a)for j in mi.jobs()]
  for f in fs:f.result()
if __name__=='__main__':main()
