from study import *
import conditional_changes as ch,conditional_rules as cr,conditional_pass as cp,macro_identity as mi,guarded_live as gl
from panel import CASES
d=w/'conditional-sorts';d.mkdir(exist_ok=True)
def edits(v):
 if v=='control':return{}
 if v=='all':return ch.edits('changed')
 ed=cr.edits('dt');s=ed[ch.ite];needle='sort,e:=m.GetSort(shared);if e!=nil{return false};fid,e:=m.GetFamilyID(sort);if e!=nil{return false};dt,e:=m.DatatypeFamilyID();return e==nil && fid==dt'
 a='sort,e:=m.GetSort(shared);if e!=nil{return false};fid,e:=m.GetFamilyID(sort);if e!=nil{return false};'
 parts=[]
 if 'bool'in v:parts.append('fid==m.BasicFamilyID()')
 if 'uf'in v:parts.append('fid==ast.NullFamilyID')
 if 'dt'in v:a+='dt,e:=m.DatatypeFamilyID();if e!=nil{return false};';parts.append('fid==dt')
 if 'bound'in v:
  a+='_=fid;ground,e:=m.IsGround(shared);if e!=nil{return false};';parts.append('!ground')
 if v=='noarith':
  a+='arith,e:=m.ArithmeticFamilyID();if e!=nil{return false};';parts.append('fid!=arith')
 s=once(s,needle,a+'return '+' || '.join(parts));ed[ch.ite]=s
 if v=='bool-onlynocache':
  r=ed[cp.rw];a=r.index('if b.factoredConditional {');b=r.index('\n   }',a)+len('\n   }');ed[cp.rw]=r[:a]+'b.factoredConditional=false'+r[b:]
 return ed
def mk(v):
 od=d/v;b=od/'checker/goivy_check'
 if b.is_file():return b
 ed=edits(v)
 for rel in ['api/api_solver.go','api/api_goal_instances_check.go','api/api_order_abstraction.go']:
  ed[pkg/rel]=subprocess.check_output(['git','show','78c85c5e4:pkg/'+rel],cwd=pkg).decode()
 return build(od/'checker',o=overlay(od/'overlay',ed))
def main():
 vs=['control','bool','bool-dt','bool-uf','bool-dt-uf','bound','noarith','bool-onlynocache','all']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;js=[j for j in mi.jobs()if j[1]in ['ordinary','tlb','rfn2','hybrid_reliable_broadcast_cisa','toy-consensus','raftok','raft_no_assume_test','flash2']]
 n='raft_no_assume';sp,iso,_,a,b=CASES[n];js.append((12,n,sp,iso,int(bool(a or b)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(9)as ex:list(ex.map(lambda j:gl.measure_job((*j[:-2],3,j[-1]),bs),js))
if __name__=='__main__':main()
