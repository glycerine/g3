from study import *
import macro_identity as mi
from collections import Counter,defaultdict
d=w/'asserted-root-census';d.mkdir(exist_ok=True);q=pkg/'smtcore/smt_asserted_formulas.go';g=pkg/'smtcore/smt_asserted_driver.go';kernel=pkg/'smtcore/smt_kernel.go';reset=pkg/'smtcore/smt_asserted_reduce.go'
def mk():
 t=q.read_text();i=t.index('proofGen := k.preprocessor.ProofGen()');assert i>0;t=t[:i]+'''initial:=k.manager.ResourceLimit().Count();empty,ee:=k.manager.ExprSubstitutionEmpty(k.assertedSubstitution);if ee!=nil{return ast.ASTHandle{},ast.ASTHandle{},ee}
 defer func(){if err==nil{fmt.Fprintf(os.Stderr,"AROOT %p %d %d %d %d %d %t %t %d %d %d %d %d %d\\n",k,formula.Origin(),formula.Slot(),formula.Generation(),k.rootPassTrial,mode,k.assertedElimAnd,empty,k.rootEpochTrial,len(k.scopes),result.Slot(),result.Generation(),k.manager.ResourceLimit().Count()-initial,k.manager.ResourceLimit().Limit)}}()
 '''+t[i:];t=once(t,'import (','import (\n"os"'+('\n"fmt"'if '"fmt"'not in t else''))
 s=kernel.read_text();s=once(s,'type SMTKernel struct {','type SMTKernel struct {\n rootPassTrial int;rootEpochTrial int')
 h=g.read_text();x='if !k.shouldApplyAssertedPass(pass) {';h=once(h,x,'save:=k.rootPassTrial;k.rootPassTrial=1+int(pass);defer func(){k.rootPassTrial=save}()\n'+x)
 z=reset.read_text();x='return k.preprocessor.SetSubstitution(&k.assertedSubstitution)';z=once(z,x,'k.rootEpochTrial++;'+x)
 o=overlay(d/'overlay',{q:t,g:h,kernel:s,reset:z});return build(d/'checker',o=o)
def lane(j,b):
 c,n,sp,iso,rc,_,ref=j;sd=d/n;sd.mkdir(exist_ok=True)
 p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=sd,capture_output=True,env=dict(env,GOMAXPROCS='1'))
 other=b'';rows=[]
 for line in p.stderr.splitlines(keepends=True):
  if line.startswith(b'AROOT '):rows.append(line.decode().split()[1:])
  else:other+=line
 assert p.returncode==rc and other==(ref/'stderr').read_bytes() and p.stdout==(ref/'stdout').read_bytes(),(n,p.returncode,other[-500:])
 with gzip.open(sd/'roots.csv.gz','wt')as f:
  z=csv.writer(f);z.writerow('solver origin slot generation phase mode elim_and empty epoch depth result_slot result_generation steps limit'.split());z.writerows(rows)
 print(n,len(rows),flush=True)
def summary():
 for f in sorted(d.glob('*/roots.csv.gz')):
  ct=Counter();seen={};samephase={};unch={};pre={}
  for r in csv.DictReader(gzip.open(f,'rt')):
   n=int(r['steps']);ct['all']+=n;ct['calls']+=1
   if r['empty']!='true':continue
   ct['empty']+=n;owner=(r['origin'],r['slot'],r['generation'],r['elim_and']);rkey=(r['result_slot'],r['result_generation']);k=(*owner,r['phase'],r['mode']);local=(r['solver'],*k)
   if samephase.get(k)==rkey:ct['samephase']+=n
   if seen.get(owner)==rkey:ct['samemgr']+=n
   if unch.get(local)==rkey:ct['samekernel']+=n
   if pre.get((*local,r['epoch']))==rkey:ct['sameepoch']+=n
   if seen.get(owner) and seen[owner]!=rkey:ct['different']+=1
   if (r['slot'],r['generation'])==rkey:ct['identity']+=n
   samephase[k]=seen[owner]=unch[local]=pre[(*local,r['epoch'])]=rkey
  print(f.parent.name,ct)
if __name__=='__main__':
 if 'summary'in sys.argv:summary()
 else:
  b=mk()
  with ThreadPoolExecutor(6)as e:list(e.map(lambda j:lane(j,b),mi.jobs()))
  summary()
