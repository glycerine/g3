from study import *
import conditional_sorts as cs,conditional_rules as cr,conditional_changes as ch,macro_identity as mi,guarded_live as gl
from panel import CASES
d=w/'conditional-shared';d.mkdir(exist_ok=True)
def ed(v):
 if v=='control':return{}
 e=cs.edits('bool-dt');s=e[ch.ite]
 x='return fid==m.BasicFamilyID() || fid==dt'
 z='''boolean:=fid==m.BasicFamilyID();datatype:=fid==dt
  h,e:=m.NodeHeader(shared);if e!=nil{return false};compound:=h.Kind==ast.ASTApp && h.NumArgs>0
  leaf:=h.Kind==ast.ASTApp && h.NumArgs==0;variable:=h.Kind==ast.ASTVar
  _=compound;_=leaf;_=variable;
 '''
 checks={'sorts':'boolean||datatype','compound':'(boolean||datatype)&&compound','compound-bool':'datatype || boolean&&compound','compound-data':'boolean || datatype&&compound','terminal':'(boolean||datatype)&&!compound','novar':'(boolean||datatype)&&!variable','ground':'(boolean||datatype)&&ground','no-ground':'(boolean||datatype)&&!ground','asymmetric':'datatype || boolean&&(rule==0||rule==4)','positive':'datatype || boolean&&(rule==1||rule==3)','small-inner':'(boolean||datatype)&&rc<=2'}
 if v in ('ground','no-ground'):z+='ground,e:=m.IsGround(shared);if e!=nil{return false};'
 if v=='small-inner':z+='inner:=t;if rule>=3{inner=f};rc,e:=m.GetRefCount(inner);if e!=nil{return false};'
 e[ch.ite]=once(s,x,z+'return '+checks[v]);return e
def mk(v):
 sd=d/v;b=sd/'checker/goivy_check'
 if v=='control':return w/'macro-release/checker/goivy_check'
 o=overlay(sd/'overlay',ed(v));return build(sd/'checker',o=o)
def main():
 vs=['control','sorts','compound','compound-bool','compound-data','terminal','novar','ground','no-ground','asymmetric','positive','small-inner']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d
 js=[j for j in mi.jobs()if j[1]in ['ordinary','tlb','hybrid_reliable_broadcast_cisa','raftok','toy-consensus']]
 n='raft_no_assume';sp,iso,_,a,b=CASES[n];js.append((12,n,sp,iso,int(bool(a or b)),3,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 with ThreadPoolExecutor(len(js))as e:list(e.map(lambda j:gl.measure_job((*j[:-2],3,j[-1]),bs),js))
if __name__=='__main__':main()
