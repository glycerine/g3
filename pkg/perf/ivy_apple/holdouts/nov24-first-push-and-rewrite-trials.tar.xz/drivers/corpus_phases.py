from study import *
from panel import CASES
from collections import defaultdict
root=w/'corpus-phases';root.mkdir(exist_ok=True)
def instrumentation():
    q=ivy.resolve()/'z3bridge_solver_model.go';s=q.read_text()
    i=s.index('func (s *Solver) GetSmallModelWithCond(');j=s.index('\n}',i)+2;a,s,b=s[:i],s[i:j],s[j:]
    s=once(s,'z3solver := s.newZ3Solver()','obs:=newVerificationObserver();defer obs.close();t:=obs.read();z3solver:=s.newZ3Solver();obs.put(t,"new",0);t=obs.read()')
    s=once(s,'zc, err := s.ClausesToZ3(clauses)','zc,err:=s.ClausesToZ3(clauses);obs.put(t,"base-translation",0)')
    s=s.replace('z3solver.Assert(zc)','t=obs.read();z3solver.Assert(zc);obs.put(t,"base-assert",0)')
    # Rows include permanent assumptions and nil callbacks in their original positions.
    s=once(s,'for _, fc := range finalCond {','for ordinal,fc:=range finalCond{obs.goal=ordinal+1')
    s=s.replace('zCond, err := s.ClausesToZ3(cond)','t=obs.read();zCond,err:=s.ClausesToZ3(cond);obs.put(t,"condition-translation",0)')
    s=once(s,'if proveGoal(zCond) {','t=obs.read();yes:=proveGoal(zCond);ans:=0;if yes{ans=-1};obs.put(t,"early",ans);if yes{')
    s=once(s,'z3solver.Push()\n\t\t\t\t}\n\t\t\t\tz3solver.Assert(zCond)','t=obs.read();z3solver.Push();obs.put(t,"push",0)\n}\n z3solver.Assert(zCond)')
    s=s.replace('z3solver.Assert(zCond)','t=obs.read();z3solver.Assert(zCond);obs.put(t,"assert",0)')
    s=once(s,'res, err := s.decideZ3With(z3solver, finalCheck)','t=obs.read();res,err:=s.decideZ3With(z3solver,finalCheck);obs.put(t,"check",int(res))')
    # Record only condition pops in this loop. Later model minimization stays outside.
    i=s.index('// No final conditions:');s=s[:i].replace('z3solver.Pop()','t=obs.read();z3solver.Pop();obs.put(t,"pop",0)')+s[i:]
    s=once(s,'overallResult, err = s.decideZ3(z3solver)','t=obs.read();overallResult,err=s.decideZ3(z3solver);obs.put(t,"standalone",int(overallResult))')
    s=once(s,'z3solver.Reset()\n\t\treturn nil, nil','t=obs.read();z3solver.Reset();obs.put(t,"release",0)\n return nil,nil')
    counter=(w/'plan-cost/overlay/plan_cost_observer.go').read_text();i=counter.index('func beginPlanCost');j=counter.index('a := readCounter()',i)
    setup=counter[i:j];setup=setup[setup.index('runtime.LockOSThread()'):].replace('fd, _, err =','o.fd, _, err =')
    read=counter[counter.index('func readCounter()'):i].replace('func readCounter()', 'func(o *vcObs)read()').replace('SYS_READ, fd,','SYS_READ, o.fd,')
    h='''package goivy
import("bufio";"fmt";"os";"runtime";"syscall";"unsafe")
type vcObs struct{fd uintptr;batch,goal int;empty uint64;w *bufio.Writer}
var vcBatch int
func newVerificationObserver()*vcObs{vcBatch++;o:=&vcObs{batch:vcBatch,w:bufio.NewWriterSize(os.Stderr,65536)}
'''+setup+'''a:=o.read();o.empty=o.read()-a;return o}
func(o *vcObs)close(){if err:=o.w.Flush();err!=nil{panic(err)};syscall.Close(int(o.fd));runtime.UnlockOSThread()}
func(o *vcObs)put(begin uint64,stage string,result int){n:=o.read()-begin; if n>o.empty{n-=o.empty}else{n=0};fmt.Fprintln(o.w,"VC-PHASE",o.batch,o.goal,stage,result,n)}
'''+read
    return overlay(root/'overlay',{q:a+s+b,ivy.resolve()/'verification_observer_experiment.go':h})
def lane(arg):
    cpu,group,bins=arg
    for n,spec,iso,ref,outcome in group:
        d=root/'runs'/n;d.mkdir(parents=True)
        for step in range(3):
            for en in (('g3','native')if step%2==0 else ('native','g3')):
                sd=d/f'{step+1}-{en}';sd.mkdir();flags=[*(['isolate='+iso]if iso else []),examples/spec]
                p=subprocess.run(['taskset','-c',str(cpu),bins[en],*flags],cwd=sd,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100'),timeout=360)
                stack=[];extra=bytearray()
                for l in p.stderr.splitlines(keepends=True):
                    if l.startswith(b'VC-PHASE '):
                        _,bid,no,ph,ver,ins=l.split();stack.append((bid.decode(),no.decode(),ph.decode(),ver.decode(),ins.decode()))
                    else:extra.extend(l)
                assert p.returncode==outcome and p.stdout==(ref/'stdout').read_bytes() and bytes(extra)==(ref/'stderr').read_bytes(),(sd,p.returncode,bytes(extra)[-250:])
                with gzip.open(sd/'phases.csv.gz','wt')as f:
                    wr=csv.writer(f);wr.writerow(['batch','condition','stage','result','instructions']);wr.writerows(stack)
        print(n,flush=True)
def main():
    o=instrumentation()
    with ThreadPoolExecutor(2)as ex:bins=dict(zip(('g3','native'),ex.map(lambda en:build(root/en,en,o),('g3','native'))))
    survey=w/'witness-release/corpus';names=(prior/'spec-survey/proof-cases.txt').read_text().splitlines()
    rc={r['spec']:int(r['exit'])for p in survey.glob('cpu-*.csv')for r in csv.DictReader(p.open())}
    jobs=[(str(i+1),n,None,survey/str(i+1)/'1/native',rc[n])for i,n in enumerate(names)]
    for name in ['dramc_nb2','rfn2','cf_live']:
        rel,iso,_,_,_=CASES[name];ref=next((prior/'end-panel-final').glob('*/'+name+'/1/native'));jobs.append((name,rel,iso,ref,0))
    # Start with the largest observed whole-process instruction deficits.
    rank={r['spec']:int(r['instructions'])for r in csv.DictReader(gzip.open(pkg/'perf/ivy_apple/goal_instances/nov23-witness-corpus.csv.gz','rt'))if r['engine']=='g3'}
    for r in csv.DictReader(gzip.open(pkg/'perf/ivy_apple/goal_instances/nov23-witness-corpus.csv.gz','rt')):
        if r['engine']=='native':rank[r['spec']]-=int(r['instructions'])
    jobs.sort(key=lambda j:-rank.get(j[1],0))
    (root/'names.csv').write_text('name,spec,isolate\n'+''.join(f'{n},{f},{iso or ""}\n'for n,f,iso,_,_ in jobs))
    with ThreadPoolExecutor(6)as ex:list(ex.map(lane,[(16+i,jobs[i::6],bins)for i in range(6)]))
if __name__=='__main__':main()
