from study import *
import scoped_conditional as sc,guarded_live as gl,macro_identity as mi
from panel import CASES
d=w/'conditional-pass';d.mkdir(exist_ok=True)
rw=pkg/'ast/rewriter/th_rewriter.go';reduce=pkg/'smtcore/smt_asserted_reduce.go';a=pkg/'smtcore/smt_asserted_formulas.go';f=pkg/'tactic/portfolio/strategic_solver_factory.go';api=pkg/'api/api_solver_factory_default.go';cmd=pkg/'cmd_context/solver_factory_strategic.go';smt=ivy.resolve()/'smt/g3_solver.go'
def edits(v):
 if v=='control':return {}
 ed=sc.edits('simplifier')
 ed.pop(a);ed.pop(f)
 ctx=cmd.read_text();k='factory, err := portfolio.NewIncrementalStrategicSolverFactory(logic, c.config)'
 ctx=once(ctx,k,'''return c.newIncrementalStrategicSolver(logic,false)
 }
 // NewVerificationStrategicSolver enables conditional factoring for temporary
 // verification assertions in the incremental strategy.
 func(c *Context)NewVerificationStrategicSolver(logic string)(solver.Solver,error){
   return c.newIncrementalStrategicSolver(logic,true)
 }
 func(c *Context)newIncrementalStrategicSolver(logic string,factor bool)(solver.Solver,error){
  config:=c.config
  config.FactorScopedConditionals=factor
  factory,err:=portfolio.NewIncrementalStrategicSolverFactory(logic,config)''')
 ed[cmd]=ctx
 ed[api]=api.read_text()+'''
 // NewSolverForVerificationGoals constructs an incremental solver for batches
 // of model checks with temporary assertions. Simplifying a nested conditional
 // with shared branches can change the satisfying model selected by search.
 func(c *SMTContext)NewSolverForVerificationGoals()(*APISimpleSolver,error){
   if err:=c.open();err!=nil{return nil,err}
   return c.saveSolver(newLazyAPISolver(c.smtContextState,c.command.NewVerificationStrategicSolver))
 }
 '''
 src=smt.read_text();src=once(src,'import (','import (\n "github.com/glycerine/ivy/goivy/xtracer"')
 k='if factory, ok := any(ctx).(interface {'
 ed[smt]=once(src,k,'''if !xtracer.Enabled || xtracer.Suppressed {if f,ok:=any(ctx).(interface{NewSolverForVerificationGoals()(*api.APISimpleSolver,error)});ok{return f.NewSolverForVerificationGoals()}}
 '''+k)
 # SetFactoring restores the selected mode on error and keeps the borrowed substitution.
 k='// FreshDefault realizes';x='''// SetFactorNestedConditionals changes nested ITE rewriting for one assertion
 // pass. Clear cached results from the previous mode while preserving its
 // borrowed substitution.
 func(r *TheoryRewriter) SetFactorNestedConditionals(enabled bool)error{
   if err:=r.open();err!=nil{return err}
   c:=&r.configuration
   if c.boolean.factorNestedITE==enabled{return nil}
   c.boolean.factorNestedITE=enabled
   FLUSH
 }
 // CanFactorNestedConditionals reports whether the traversal uses unlimited
 // rewrite steps and the default rewrite memory bound.
 func(r *TheoryRewriter)CanFactorNestedConditionals()bool{
    return r.configuration.maxSteps==^uint32(0) && r.configuration.maxMemory==uint64(^uint32(0))*1024*1024
 }
 '''
 flush='var sub *ast.ASTExprSubstitution;if c.hasSubstitution{saved:=c.substitution;sub=&saved};return r.SetSubstitution(sub)'
 if v=='end':flush='if enabled{return nil};'+flush
 if v=='none':flush='return nil'
 ed[rw]=once(rw.read_text(),k,x.replace('FLUSH',flush)+k)
 s=once(reduce.read_text(),'import (','import (\n "github.com/glycerine/g3/pkg/util/diagnostic"')
 k='batch, err := macros.NewFormulaBatch(k.manager)';pos=s.index(k,s.index('func (k *SMTKernel) reducePendingAssertions'))
 s=s[:pos]+'''if k.factorScopedConditionals && len(k.scopes)>0 && !ast.ASTSourceDebug && !diagnostic.TraceCompiled() && k.manager.TraceStream==nil && !k.manager.Budget().InjectionArmed() && !k.manager.NumeralService().RuntimeOwner().AllocationLimited() && !k.manager.ResourceLimit().CancelFlag() && k.smtState.MaxConflicts==^uint32(0) && k.manager.ResourceLimit().Limit==0 && !k.preprocessor.ProofGen() && k.preprocessor.CanFactorNestedConditionals(){
    proofs,err:=k.manager.ProofsEnabled();if err!=nil{return err};if !proofs{
      if err=k.preprocessor.SetFactorNestedConditionals(true);err!=nil{return errors.Join(err,k.preprocessor.SetFactorNestedConditionals(false))}
      defer func(){result=errors.Join(result,k.preprocessor.SetFactorNestedConditionals(false))}()
    }
 }
 '''+s[pos:];ed[reduce]=s
 return ed
def mk(v):
 od=d/v;return build(od/'checker',o=overlay(od/'overlay',edits(v)))
def main():
 vs=['control','both','end','none']
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(vs,ex.map(mk,vs)))
 gl.d=d;js=[j for j in mi.jobs() if j[1] in ('ordinary','tlb','rfn2','flash2','toy-consensus','raft_no_assume_test','dramc_nb2','cf_live','hybrid_reliable_broadcast_cisa')]
 js+=[(19,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native')]
 with ThreadPoolExecutor(10)as ex:
  work=[ex.submit(gl.measure_job,j,bs if j[0]not in (19,22)else {z:bs[z]for z in ['control','both','end']})for j in js]
  for job in work:job.result()
if __name__=='__main__':main()
