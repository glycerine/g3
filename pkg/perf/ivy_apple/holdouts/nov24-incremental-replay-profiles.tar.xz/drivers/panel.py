from study import *
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
from paired_verification import CASES
from complete_search import same_output
sys.path.insert(0,str(pkg/'perf/ivy_apple'))
from compare import measure,EVENTS
from types import SimpleNamespace
allcases=['tlb','cf_live','dramc_nb2','raft_no_assume','raftok','raft_no_assume_test','flash2','hybrid_reliable_broadcast_cisa','ticket','toy-consensus','rfn2','examp1_numeric']
def panel(root,variants,cases=allcases,rounds=5,cpu0=9):
 def lane(job):
  ix,n=job;d=root/n;d.mkdir(parents=True);cpu=cpu0+ix
  rel,iso,ps,fs,unk=CASES[n]
  ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))
  conf=SimpleNamespace(cpu=cpu,perf=perf,spec=examples/rel,isolate=iso)
  with(d/'runs.csv').open('w')as out:
   wr=csv.writer(out);wr.writerow(['case','pair','variant','cpu','gogc','exit','match','wall','user','sys','rss',*EVENTS])
   for i in range(rounds):
    order=list(variants);offset=(i//2)%len(order);order=order[offset:]+order[:offset]
    if i%2:order=order[::-1]
    for v in order:
     sd=d/f'{i+1}-{v}';b=variants[v]
     rc,t,c=measure(b,conf,sd,int(bool(fs or unk)),100)
     ok=rc==int(bool(fs or unk)) and (sd/'stderr').read_bytes()==(ref/'stderr').read_bytes() and same_output((sd/'stdout').read_bytes(),(ref/'stdout').read_bytes(),unk)
     wr.writerow([n,i+1,v,cpu,100,rc,int(ok),*t,*c]);out.flush()
     assert ok,sd
  print('complete',n,flush=True)
 with ThreadPoolExecutor(len(cases))as pool:list(pool.map(lane,enumerate(cases)))
if __name__=='__main__':
 for _ in range(300):
  if all((w/'baseline'/v/'abc').exists() for v in ['g3','native']):break
  time.sleep(1)
 panel(w/'start-panel',{v:w/'baseline'/v/'goivy_check'for v in ('g3','native')},rounds=5)
