from study import *
import io
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import warm_queries as warm
d=w/'warm-current';d.mkdir(exist_ok=True)
b=w/'quantifier-release/shell/g3';n=pkg.parent/'build/z3';bs={'g3':b,'native':n}
def counts(c,qs):
 run([sys.executable,pkg/'perf/ivy_apple/holdouts/warm_queries.py','--g3',b,'--native',n,'--output',d/('counter-'+str(c)),'--queries',*qs,'--iterations','1','8','64','--pairs','7','--cpu',str(c),'--perf',perf],stdout=subprocess.DEVNULL)
def profile(c,name):
 od=d/('profile-'+name);od.mkdir(exist_ok=True);src=warm.script(name,48,False).encode()
 for i in range(1,4):
  for en in (['g3','native']if i%2 else['native','g3']):
   rd=od/f'{i}-{en}';rd.mkdir(exist_ok=True);cmd=['taskset','-c',str(c),perf,'record','-q','-m','1024','--no-buildid','-e','instructions:u','-c','280003','--call-graph',('fp'if en=='g3'else'dwarf,8192'),'-o',rd/'data','--',bs[en],'-in','-smt2']
   res=run(cmd,cwd=rd,env=dict(env,GOMAXPROCS='1'),input=src,capture_output=True);assert res.stdout.split()==[warm.NUMERIC_ANSWERS.get(name,'unsat').encode()]*48 and not res.stderr,(name,en,res.stderr[:350])
   for mode,fl in [('inclusive','--children'),('leaf','--no-children')]:
    with (rd/(mode+'.txt')).open('wb')as out:run([perf,'report',fl,'--stdio','--no-demangle','--percent-limit','.15','--stdio-color=never','--no-call-graph','-i',rd/'data'],stdout=out)
   (rd/'data').unlink();print(name,en,i,flush=True)
def main():
 qs=list(warm.CASES)+list(warm.NUMERIC_ANSWERS)
 with ThreadPoolExecutor(8)as e:
  fs=[e.submit(counts,c,qs[i::4])for i,c in enumerate([6,9,14,18])]+[e.submit(profile,c,q)for c,q in zip([11,12,20,23],['toy-consensus-18','ticket-127','aux-012725','aux-017026'])]
  for f in fs:f.result()
if __name__=='__main__':main()
