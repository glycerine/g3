from study import *
import guarded_live as gl,macro_identity as mi,simplifier_rebuild as sh
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import warm_queries as warm
from types import SimpleNamespace
d=w/'theory-traversal-steps';d.mkdir(exist_ok=True)
q=pkg/'ast/rewriter/rewriter_engine.go';tr=pkg/'ast/rewriter/th_rewriter.go';ar=pkg/'ast/ast_core_span_factories.go'
def edits(v):
 ed={}
 if v=='control':return {}
 if v in ('args','combined'):
  s=ar.read_text();x='func (a AppArguments) At(i uint32) (ASTHandle, error) { return a.at(i) }';ed[ar]=once(s,x,'''func(a AppArguments)At(i uint32)(ASTHandle,error){
  if a.appOwner==nil && !a.raw && i<a.count && i<=^uint32(0)-a.argumentOffset{return a.slice[a.argumentOffset+i],nil}
  return a.at(i)
  }''')
 if v in ('leaves','uf','dispatch','combined'):
  s=q.read_text();x='modelBooleanShortCircuit bool';s=once(s,x,x+'\n theory *theoryRewriterConfiguration')
  x='r.cfg = cfg';s=once(s,x,x+'''\n if !proofGen && !ast.ASTSourceDebug && !ast.ASTValidateHandles {r.theory,_=cfg.(*theoryRewriterConfiguration)}''')
  if v in ('leaves','combined'):
   start=s.index('func (r *rewriterEngine) visit(');x='cache, e := r.mustCacheShape(t, kind, rc, n)';s=s[:start]+once(s[start:],x,'''if r.theory!=nil && (kind==ast.ASTVar && len(r.bindings)==0 || kind==ast.ASTApp && n==0 && r.trialInertConstant(t)){
     return true,appendRewriterRoot(m,&c.results,t)
    }
    '''+x)
   s+='''
func(r *rewriterEngine)trialInertConstant(t ast.ASTHandle)bool{
 m:=r.core.manager;_,family,op,err:=m.AppIdentity(t);return err==nil && (family==ast.NullFamilyID || family==m.BasicFamilyID() && (op==ast.ASTOpFalse || op==ast.ASTOpTrue))
}
'''
  if v in ('uf','combined'):
   start=s.index('func (r *rewriterEngine) processApp()');x='if r.substituteVariables {';a,b=s[:start],s[start:];b=once(b,x,'if r.substituteVariables || r.theory!=nil && (!r.theory.pullCheapITE || n!=2) && r.trialUninterpreted(t) {');s=a+b
   s+='''\nfunc(r *rewriterEngine)trialUninterpreted(t ast.ASTHandle)bool{_,f,_,e:=r.core.manager.AppIdentity(t);return e==nil && f==ast.NullFamilyID}\n'''
  if v in ('dispatch','combined'):
   # Cache the app identity on the stack while returning from children.
   start=s.index('func (r *rewriterEngine) processApp()');a,b=s[:start],s[start:];i=b.index('d, e := m.GetDecl(t)',b.index('return r.finish(fr, false, true)'));j=b.index('assoc := false',i)
   b=b[:i]+'''header,e:=m.NodeHeader(t);if e!=nil{return e};d,rc:=header.Decl,header.RefCount
   '''+b[j:];x='st, e := r.cfg.ReduceApp(d, args, r.r, r.pr2)';b=once(b,x,'''var st brStatus
    if r.theory!=nil{st,e=r.theory.trialKnownApp(d,args,r.r,r.pr2,header.Family,header.DeclKind)}else{st,e=r.cfg.ReduceApp(d,args,r.r,r.pr2)}''');s=a+b
   t=tr.read_text();idx=t.index('func (c *theoryRewriterConfiguration) reduceAppCore(');i=t.index('if family == m.BasicFamilyID()',idx);j=t.index('if kind == ast.ASTOpEq {',i)
   outer=t[idx:i];sig=outer.split('\n')[0];t=t[:idx]+outer+'''var op int32;if family==m.BasicFamilyID(){op,err=m.GetDeclKind(decl);if err!=nil{return RewriteFailed,err}}
   return c.trialKnownCore(decl,args,out,family,op)}
   '''+sig.replace('reduceAppCore','trialKnownCore').replace('out ast.ASTRef)','out ast.ASTRef,family ast.FamilyID,kind int32)')+'''\n m:=c.owner.manager
   if family==ast.NullFamilyID{return RewriteFailed,nil}
   if family == m.BasicFamilyID() {'''+t[j:]
   start=t.index('func (c *theoryRewriterConfiguration) ReduceApp(');x='if err != nil || status != RewriteDone && status != RewriteFailed {';ix=t.index(x,start);t=t[:ix]+'''return c.trialCompleteApp(decl,args,out,status,err)}
    func(c *theoryRewriterConfiguration)trialKnownApp(decl ast.ASTHandle,args ast.AppArguments,out,proof ast.ASTRef,family ast.FamilyID,op int32)(RewriteStatus,error){
    if err:=c.owner.manager.SetRef(proof,ast.ASTHandle{});err!=nil{return RewriteFailed,err}
    status,err:=c.trialKnownCore(decl,args,out,family,op);return c.trialCompleteApp(decl,args,out,status,err)}
    func(c *theoryRewriterConfiguration)trialCompleteApp(decl ast.ASTHandle,args ast.AppArguments,out ast.ASTRef,status RewriteStatus,err error)(RewriteStatus,error){\n'''+t[ix:];ed[tr]=t
  ed[q]=s
 if v in ('pull','combined'):
  s=ed.get(tr,tr.read_text());x='rangeSort, err := c.owner.manager.GetRange(decl)';idx=s.index('func (c *theoryRewriterConfiguration) pullITE(');i=s.index(x,idx)
  s=s[:i]+'''if !ast.ASTValidateHandles && !ast.ASTSourceDebug{
  m:=c.owner.manager;_,f,k,e:=m.AppIdentity(left);if e==nil && (f!=m.BasicFamilyID()||k!=ast.ASTOpIte){_,f,k,e=m.AppIdentity(right);if e==nil && (f!=m.BasicFamilyID()||k!=ast.ASTOpIte){return RewriteFailed,nil}}}
  '''+s[i:];ed[tr]=s
 return ed
def mk(v):
 od=d/v;od.mkdir(exist_ok=True);o=overlay(od/'overlay',edits(v))
 with(w/'build.lock').open('a')as f,(od/'focused.txt').open('w')as log:
  fcntl.flock(f,fcntl.LOCK_SH);run(['go','test','-p','3','-count=1','-overlay='+str(o),'./ast/rewriter','./ast/pattern','./ast','-run','^(Test(BoolRewriter|TheoryRewriter|Traversal|Rewriter|AppArgument|PatternInference))'],cwd=pkg,stdout=log,stderr=log)
 return build(od/'checker',o=o),build(od/'shell',o=o,shell=True)
def replay(arg):
 cpu,name,bs=arg;od=d/('warm-'+name);od.mkdir(exist_ok=True);args=SimpleNamespace(cpu=cpu,perf=perf,timeout=320,gogc='100')
 with(od/'runs.csv').open('w')as f,(od/'stats.csv').open('w')as sf:
  z=csv.writer(f);z.writerow('query round iterations variant instructions'.split());ss=csv.writer(sf);ss.writerow('query variant it decisions second_counter conflicts steps matches'.split());control=None
  for v,b in bs.items():
   _,r=warm.run(args,b,name,od/('stats-'+v),32,True)
   if control is None:control=r
   for i,x in enumerate(r):ss.writerow([name,v,i+1,*x,int(x==control[i])])
   sf.flush()
  for i in range(5):
   vs=list(bs);vs=vs[i%len(vs):]+vs[:i%len(vs)]
   for num in ([4,32]if i%2==0 else[32,4]):
    for v in vs:
     ir,_=warm.run(args,bs[v],name,od/f'{i}-{num}-{v}',num,False);z.writerow([name,i+1,num,v,ir]);f.flush()
def main():
 vs=['control','leaves','uf','args','pull','dispatch','combined']
 with ThreadPoolExecutor(3)as e:bs=dict(zip(vs,e.map(mk,vs)))
 bb={v:b[0]for v,b in bs.items()};ss={v:b[1]for v,b in bs.items()}|{'native':pkg.parent/'build/z3'};gl.d=d
 js=[(cpu,*j[1:5],3,j[-1])for cpu,j in zip([0,1,2,3,8,9,10,11,12],(j for j in mi.jobs()if j[1]!='dramc_nb2'))]
 qs=list(warm.CASES)+['aux-012725','aux-017026','aux-011440']
 with ThreadPoolExecutor(len(js)+len(qs))as e:
  fs=[e.submit(gl.measure_job,j,bb)for j in js]+[e.submit(replay,(cpu,n,ss))for cpu,n in zip([25,26,27,32,33,34],qs)]
  for f in fs:f.result()
if __name__=='__main__':main()
