from study import *
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'))
import query_operations as op,warm_queries as warm
d=w/'warm-method-counts';d.mkdir(exist_ok=True)
os.environ.update(env)
def make(name):
 od=d/name;od.mkdir(exist_ok=True);go,gm,cpp,cm=op.OPS[name]
 with(w/'build.lock').open('a')as f:
  fcntl.flock(f,fcntl.LOCK_SH);g=op.build_go(od,go,gm,None)
 n=op.build_native(od,cpp,cm,pkg.parent/'build')
 return g,n
def lane(name,c,bs):
 od=d/name
 with (od/'runs.csv').open('w')as f,(od/'search.csv').open('w')as sf:
  z=csv.writer(f);z.writerow('name query n round engine calls instructions'.split());sc=csv.writer(sf);sc.writerow('name query engine iteration decisions second_counter conflicts resource_steps'.split())
  for q in ['ticket-127','ticket-290','aux-012725','toy-consensus-18']:
   expected=None
   for i in range(5):
    for n in ([4,32]if i%2==0 else[32,4]):
     for en,b in (list(zip(['g3','native'],bs))[::1 if i%2==0 else -1]):
      res=run(['taskset','-c',str(c),b,'-in','-smt2'],input=warm.script(q,n,False),text=True,capture_output=True,timeout=260,env=dict(env,GOMAXPROCS='1',SCOPE_THREAD_EVENT='1'))
      ans=warm.NUMERIC_ANSWERS.get(q,'unsat');assert res.stdout.split()==[ans]*n,(q,en,i,res.stdout[-150:])
      a=re.findall(r'^REPLAY-OP (\d+) (\d+)$',res.stderr,re.M);assert len(a)==1,(name,q,n,en,res.stderr);assert name!='check-sat' or a[0][0]==str(n)
      z.writerow([name,q,n,i+1,en,*a[0]]);f.flush()
   for en,b in zip(['g3','native'],bs):
    res=run(['taskset','-c',str(c),b,'-in','-smt2'],input=warm.script(q,32,True),text=True,capture_output=True,timeout=260,env=dict(env,GOMAXPROCS='1',SCOPE_THREAD_EVENT='1'))
    block=re.split(r'(?m)^(sat|unsat|unknown)$',res.stdout)
    cols=['decisions','added-eqs'if q.startswith('aux')else'quant-instantiations','conflicts','rlimit-count'];rs=[]
    for j,blk in enumerate(block[2::2]):
     vals=dict(re.findall(r':([\w-]+)\s+(\d+)\b',blk));r=tuple(int(vals.get(k,0))for k in cols);sc.writerow([name,q,en,j+1,*r]);rs.append(r)
    sf.flush();assert len(rs)==32 and (expected is None or expected==rs),(name,q,en);expected=rs
   print(name,q,flush=True)
def main():
 names=list(op.OPS)
 with ThreadPoolExecutor(3)as e:bs=dict(zip(names,e.map(make,names)))
 with ThreadPoolExecutor(len(names))as e:list(e.map(lambda tup:lane(tup[0],tup[1],bs[tup[0]]),zip(names,[0,2,4,6,8,10,12,14])))
if __name__=='__main__':main()
