from study import *
import guarded_live as gl, simplifier_rebuild as sh
from panel import CASES
d=w/'macro-identity';d.mkdir(exist_ok=True);m=pkg/'ast/macros/macro_manager.go';ex=pkg/'ast/macros/macro_expander.go'
def edit(v):
 if v=='control':return{}
 size=256 if '256'in v else 1024
 s=m.read_text();x='type Manager struct {';s=once(s,x,'''type macroIdentityTrial struct { term ast.ASTHandle; steps uint32 }
 '''+x+'\n identitiesTrial *['+str(size)+']macroIdentityTrial')
 x='m.byDeclaration[declaration] = len(m.entries)';s=once(s,x,'if m.identitiesTrial!=nil{clear(m.identitiesTrial[:])}\n'+x);ed={m:s}
 s=ex.read_text();x='oldTerm, err := m.manager.NewRef(term)'
 inline='''eligible:=false
 if !ast.ASTSourceDebug && !ast.ASTValidateHandles && m.manager.TraceStream==nil && !m.manager.Budget().InjectionArmed() && !m.manager.NumeralService().RuntimeOwner().AllocationLimited() && m.manager.ResourceLimit().Limit==0 && !m.manager.ResourceLimit().CancelFlag(){
   enabled,e:=m.manager.ProofsEnabled();eligible=e==nil && !enabled
 }
 var count uint32;var costBefore uint64
 if eligible {
   if m.identitiesTrial!=nil{a:=m.identitiesTrial[term.Slot()%uint32(len(m.identitiesTrial))];if a.term==term{count=a.steps}}
   PROBE
   if count!=0 {
     RETURN
   }
   costBefore=m.manager.ResourceLimit().Count()
 }
 '''
 probe='if count==0 {var seen [64]ast.ASTHandle;var n int;budget:=128;steps,ok:=m.identityStepsTrial(term,0,seen[:],&n,&budget);if ok{count=2*steps;if count==0{count=1}}}'
 inline=inline.replace('PROBE',probe if 'probe'in v or 'audit'in v else '')
 audit='audit'in v
 inline=inline.replace('RETURN','' if audit else '''limit:=m.manager.ResourceLimit()
 if !limit.CancelFlag(){if !limit.IncOffset(count){return resultDependency,rewriter.NewRewriterException(limit.CancelMessage())};return resultDependency,m.manager.SetRef(out,term)}
 ''')
 # Rewriter exception only exposed through the engine; preserve error path by resuming the original code from the pre-increment count when a signal arrives.
 inline=inline.replace('if !limit.IncOffset(count){return resultDependency,rewriter.NewRewriterException(limit.CancelMessage())};return resultDependency,m.manager.SetRef(out,term)','if limit.IncOffset(count){return resultDependency,m.manager.SetRef(out,term)};limit.Steps-=uint64(count)')
 s=once(s,x,inline+'\n'+x)
 x='done, e := m.expandMacrosStep(cfg, traversal, proofs, oldTerm, oldProof, out, outProof, &resultDependency)';s=once(s,x,x+'''
 unused:=len(cfg.trail)==0 && cfg.usedDependency.IsNull()
 ''')
 x='if done {\n\t\t\tbreak';s=once(s,x,('''if eligible && !changed {
    spent:=m.manager.ResourceLimit().Count()-costBefore
    AUDIT
    if done && unused && spent>0 && spent<=128 {
      if m.identitiesTrial==nil{m.identitiesTrial=new(['''+str(size)+''']macroIdentityTrial)}
      m.identitiesTrial[term.Slot()%uint32(len(m.identitiesTrial))]=macroIdentityTrial{term,uint32(spent)}
    }
 }
 ''').replace('AUDIT','''if count!=0 && (!done || !unused || uint64(count)!=spent){panic(fmt.Sprintf("macro identity observation failed %v %d %d %t %t",term,count,spent,done,unused))};fmt.Fprintf(os.Stderr,"MACRO-ID %d %d %t %t\\n",count,spent,done,unused)''' if audit else '')+x)
 if audit:s=once(s,'"errors"','"errors"\n"os"\n"fmt"')
 if 'probe'in v or audit:s+='''
// Count the original traversal's non-leaf frames in each quantifier scope.
// Every non-root frame suspends exactly one parent and each frame finishes once.
func(m *Manager)identityStepsTrial(h ast.ASTHandle,depth int,seen []ast.ASTHandle,used,budget *int)(uint32,bool){
 if depth>32 || *budget==0{return 0,false};*budget--
 hd,e:=m.manager.NodeHeader(h);if e!=nil{return 0,false}
 switch hd.Kind{
 case ast.ASTVar:return 0,true
 case ast.ASTApp:
  if _,ok:=m.byDeclaration[hd.Decl];ok{return 0,false}
  if hd.NumArgs==0{return 0,true}
  if hd.Family==m.manager.BasicFamilyID() && hd.DeclKind==ast.ASTOpIte{return 0,false}
 case ast.ASTQuantifier:
 default:return 0,false
 }
 if hd.RefCount>1 {
   for _,prev:=range seen[:*used]{if prev==h{return 0,true}}
   if *used==len(seen){return 0,false};seen[*used]=h;*used++
 }
 n:=uint32(1)
 if hd.Kind==ast.ASTQuantifier{
   body,e:=m.manager.GetQuantifierBody(h);if e!=nil{return 0,false};ns:=0
   x,ok:=m.identityStepsTrial(body,depth+1,seen[*used:],&ns,budget);return x+n,ok
 }
 for i:=uint32(0);i<hd.NumArgs;i++{arg,e:=m.manager.GetArg(h,i);if e!=nil{return 0,false};x,ok:=m.identityStepsTrial(arg,depth+1,seen,used,budget);if !ok{return 0,false};n+=x}
 return n,true
}
'''
 ed[ex]=s;return ed
def mk(v):
 dr=d/v;o=overlay(dr/'overlay',edit(v));return build(dr/'checker',o=o),build(dr/'shell',o=o,shell=True)
def jobs():
 js=[(4,'ordinary','jea/hermes_rmw_o3.ivy','',0,4,w/'guarded-live/ordinary-11/1-native')]
 for c,n in zip([1,2,7,9,10,13,14,18,11],['tlb','hybrid_reliable_broadcast_cisa','flash2','toy-consensus','rfn2','dramc_nb2','raftok','raft_no_assume_test','cf_live']):
  sp,iso,_,f,u=CASES[n];js.append((c,n,sp,iso,int(bool(f or u)),4,next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))))
 return js
def audit():
 b,s=mk('audit');js=jobs()
 def lane(j):
  c,n,sp,iso,rc,r,rf=j;od=d/'audit'/n;od.mkdir(exist_ok=True);p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=od,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100'));(od/'stderr.gz').write_bytes(gzip.compress(p.stderr));rem=b''.join(l for l in p.stderr.splitlines(keepends=True)if not l.startswith(b'MACRO-ID '));ok=(p.returncode==rc and rem==(rf/'stderr').read_bytes() and p.stdout==(rf/'stdout').read_bytes());print(n,ok,rem[-600:]if not ok else '',flush=True);return ok
 with ThreadPoolExecutor(5)as e:ok=list(e.map(lane,js))
 assert all(ok)
def main():
 vs=['control','observed256','observed','probe256','probe']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;bb={v:b[0]for v,b in bs.items()};js=jobs()
 with ThreadPoolExecutor(8)as e:list(e.map(lambda j:gl.measure_job(j,bb),js))
if __name__=='__main__':
 if 'audit'in sys.argv:audit()
 else:main()
