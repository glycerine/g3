from pathlib import Path
from collections import defaultdict
import re,csv
w=Path(__file__).resolve().parent
def rows(path):
 groups=defaultdict(list)
 for line in path.read_text().splitlines():
  k,_,v=line.partition(' ');groups[k].append(v)
 pat=re.compile(r'([^()\s!]+)!(\d+)')
 nums=defaultdict(set)
 for matches in groups.values():
  for s in matches:
   for p,n in pat.findall(s):nums[p].add(int(n))
 norm={k:{v:i for i,v in enumerate(sorted(vs))} for k,vs in nums.items()}
 for k,n in [('VAR',7),('QUANT',2),('ENODE',2)]:
  parts=[v.split(' ',n) for v in groups[k]]
  groups[k+'_NORM']=[pat.sub(lambda m:m[1]+'!@'+str(norm[m[1]][int(m[2])]),v[-1]) for v in parts]
  groups[k+'_SHAPE']=[v[-1] for v in parts]
  groups[k+'_ID']=[v[1 if k=='VAR' else 0] for v in parts]
 return groups
base=rows(w/'snap-base.txt')
with (w/'state-differences.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['run','field','baseline_count','trial_count','unequal_positions','multiset_matches'])
 for p in sorted(w.glob('snap-*.txt')):
  current=rows(p)
  for k,a in base.items():
   b=current[k];out.writerow([p.stem[5:],k,len(a),len(b),sum(x!=y for x,y in zip(a,b))+abs(len(a)-len(b)),sorted(a)==sorted(b)])
