from pathlib import Path
from collections import Counter
import csv,re
w=Path(__file__).resolve().parent
def events(fp):
 names={};counts=Counter()
 def canon(m):
  full=m[0];prefix=m[1]
  if full not in names:names[full]=prefix+'!@'+str(counts[prefix]);counts[prefix]+=1
  return names[full]
 return [re.sub(r'([^()\s!]+)!\d+',canon,v[6:]) for v in fp.read_text().splitlines()]
a=events(w/'events-base+0.log')
with (w/'sequence.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['mode','event','baseline','trial','matching_prefix','baseline_next','trial_next'])
 for arm in ['before+0','before+3']:
  b=events(w/f'events-{arm}.log')
  for k in ['all','D','Q','C']:
   x,y=[[s for s in ev if k=='all' or s.startswith(k+' ')] for ev in [a,b]]
   i=next((j for j,(p,q) in enumerate(zip(x,y)) if p!=q),min(len(x),len(y)))
   o.writerow([arm,k,len(x),len(y),i,x[i] if i<len(x) else '',y[i] if i<len(y) else ''])
