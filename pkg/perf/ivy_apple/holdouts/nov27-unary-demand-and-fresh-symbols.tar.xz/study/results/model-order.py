from pathlib import Path
from collections import Counter
import csv,re
w=Path(__file__).resolve().parent
def rows(name):
 rows=[x for x in (w/('mbqi-'+name+'.log')).read_text().splitlines() if x.startswith('MODEL ')]
 # These model-checker runs generate names from a common counter. Preserve
 # model-value indices. A constant shift of three was observed at entry.
 if name=='before+0':
  pat=re.compile(r'([^()\s!]+(?:![^()\s!]+)*)!(\d+)')
  def shifted(m):
   if m[1].endswith('!val'):return m[0]
   return m[1]+'!'+str(int(m[2])+3)
  rows=[pat.sub(shifted,l) for l in rows]
 return rows
a=rows('base+0')
with (w/'model-order.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['mode','event','baseline','trial','matching_prefix','baseline_next','trial_next'])
 for name in ['before+0','before+3']:
  b=rows(name)
  for kind in ['all']+sorted({s.split()[1] for s in a+b}):
   x,y=[[v for v in src if kind=='all' or v.split()[1]==kind] for src in [a,b]]
   i=next((i for i,(a1,b1) in enumerate(zip(x,y)) if a1!=b1),min(len(x),len(y)))
   out.writerow([name,kind,len(x),len(y),i,x[i] if i<len(x) else '',y[i] if i<len(y) else ''])
