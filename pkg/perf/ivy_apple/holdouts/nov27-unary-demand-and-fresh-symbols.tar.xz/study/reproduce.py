"""Replay one experiment from the g3/pkg working directory on Linux."""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import tempfile

here = Path(__file__).resolve().parent
pkg = Path.cwd()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("experiment", choices=sorted(p.stem for p in (here / "plans").glob("*.json")))
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
output = args.output.absolute()
output.mkdir(parents=True, exist_ok=True)
frontend = Path(os.environ["GOIVY_FRONTEND"]).resolve()
modfile = Path(os.environ["GOIVY_MODFILE"]).resolve()
reference = Path(os.environ["NNF_REFERENCE"])
examples = Path(os.environ["IVY_EXAMPLES"]).absolute()
native_root = b"/home/jaten/ivy/ivy-lang-examples/"
inputs = (reference / "compat.txt").read_text().splitlines()
with (reference / "ranking.csv").open() as stream:
    codes = {r["case"]: int(r["exit"]) for r in csv.DictReader(stream)}
plan = json.loads((here / "plans" / (args.experiment + ".json")).read_text())
roots = {"frontend": frontend, "pkg": pkg}
replacements = {str(roots[root] / path): str(here / "sources" / src) for root, path, src in plan["sources"]}

with tempfile.TemporaryDirectory(dir=os.environ.get("TMPDIR", "/tmp")) as temp:
    scratch = Path(temp)
    overlay = scratch / "overlay.json"
    overlay.write_text(json.dumps({"Replace": replacements}))
    exe = scratch / "goivy_check"
    build = dict(os.environ, GOCACHE=str(scratch / "cache"), TMPDIR=temp, GOTMPDIR=temp)
    native = args.experiment == "linked-z3"
    subprocess.run(["go", "build", "-mod=readonly", "-tags", "xtrace_off,classic_z3" if native else "xtrace_off", "-buildvcs=false",
                    "-pgo=off" if native else "-pgo=" + str(pkg / "perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof"),
                    "-overlay", overlay, "-modfile", modfile, "-o", exe, "./cmd/goivy_check"],
                   cwd=frontend, env=build, check=True)
    with (output / "costs.csv").open("w") as stream:
        writer = csv.writer(stream)
        writer.writerow(["case", "target", "mode", "status", "selected_check", "check_sum", "stage_sum"])
        for number, target, mode, selected in plan["runs"]:
            case = inputs[number - 1]
            prefix = f"{number}-{target}-{mode}"
            env = dict(os.environ, GOGC="off", GOMAXPROCS="1", XTRACE_OFF="1",
                       GOIVY_INCLUDE=str(examples / "ivy/include"), TARGET=target, UNIT_MODE="all" if args.experiment in ("tie", "diagonal", "robust", "candidate", "finalrobust") else mode, TIE_MODE=mode, SWAP_DIR=str(here / "results"),
                       SNAPFILE=str(output / (prefix + ".snapshot")))
            run = subprocess.run(["taskset", "-c", os.environ["CPU"], exe, examples / case],
                                 cwd=scratch, env=env, capture_output=True, timeout=120)
            stages = []
            ordinary = bytearray()
            with (output / (prefix + ".log")).open("wb") as log:
                for line in run.stderr.splitlines(keepends=True):
                    if line.startswith(b"STAGE-COUNT "):
                        _, batch, goal, phase, count, _, enabled, running, _ = line.split()
                        if enabled != running:
                            raise RuntimeError("multiplexed solver instruction counter")
                        stages.append(((batch + b"-" + goal).decode(), phase, int(count)))
                    elif line.startswith((b"UNIT_RESULT ", b"DEMAND ", b"STATE_ROW ", b"ORDER ", b"MODEL ", b"SWAP ")):
                        log.write(line)
                    else:
                        ordinary.extend(line)
            golden = reference / "compat" / str(number) / "1/native"
            def expected(name):
                return (golden / name).read_bytes().replace(native_root, os.fsencode(examples) + b"/")
            matches = (run.returncode, run.stdout, ordinary) == (codes[case], expected("stdout"), expected("stderr"))
            writer.writerow([number, target, mode, "match" if matches else "different",
                             sum(v for t, ph, v in stages if t == selected and ph == b"check"),
                             sum(v for _, ph, v in stages if ph == b"check"), sum(v for _, _, v in stages)])
            stream.flush()
            if not matches:
                (output / (prefix + ".stderr")).write_bytes(ordinary)
                raise RuntimeError("native transcript mismatch on " + prefix)
