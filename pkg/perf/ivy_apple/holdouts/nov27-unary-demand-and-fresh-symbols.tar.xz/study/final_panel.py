"""Compare the optimized regular and Apple GoIvy frontends with the native transcripts."""
from pathlib import Path
import concurrent.futures
import csv
import json
import os
import shutil
import subprocess
import tempfile

pkg = Path.cwd()
here = Path(__file__).resolve().parent
output = Path(os.environ["RESULTS"])
output.mkdir(parents=True, exist_ok=True)
source = here / "release-sources"
frontend = Path(os.environ["GOIVY_FRONTEND"]).resolve()
apple_frontend = Path(os.environ["APPLE_FRONTEND"]).resolve()
ref = Path(os.environ["NNF_REFERENCE"])
examples = Path(os.environ["IVY_EXAMPLES"]).absolute()
names = (ref / "compat.txt").read_text().splitlines()
with (ref / "ranking.csv").open() as f:
    codes = {row["case"]: int(row["exit"]) for row in csv.DictReader(f)}
cpus = list(map(int, os.environ["PANEL_CPUS"].split(",")))
perf = os.environ.get("PERF", "perf")
with tempfile.TemporaryDirectory(dir=os.environ.get("TMPDIR","/tmp")) as temp:
    d = Path(temp)
    env = dict(os.environ, GOCACHE=str(d/"cache"), TMPDIR=temp, GOTMPDIR=temp)
    verify_only = os.environ.get("VERIFY_ONLY") == "1"
    (d/"abc").symlink_to(Path(os.environ["ABC"]).resolve(strict=True))
    for apple in ([False] if verify_only else [False, True]):
        front = apple_frontend if apple else frontend
        for mode in (["candidate"] if verify_only else ["base", "candidate"]):
            mapping = {
                str(front/"z3bridge_solver_model.go"): str(source/("apple.go.txt" if apple else "regular.go.txt")),
                str(front/"z3bridge_guarded_equalities.go"): str(source/("apple-guards.go.txt" if apple else "regular-guards.go.txt")),
                str(pkg/"smtcore/smt_model_checker.go"): str(source/(mode+".go.txt")),
                str(pkg/"smtcore/smt_model_checker_repeated_binding.go"): str(source/(mode+"-helper.go.txt")),
            }
            overlay = d/"overlay.json"
            overlay.write_text(json.dumps({"Replace": mapping}))
            subprocess.run(["go","build","-tags","xtrace_off","-mod=readonly","-buildvcs=false",
                            "-pgo="+str(pkg/"perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof"),
                            "-overlay",overlay,*([] if apple else ["-modfile",os.environ["GOIVY_MODFILE"]]),
                            "-o",d/(mode+str(apple)),"./cmd/goivy_check"],cwd=front,env=env,check=True)
    def run(case, mode, cpu, measure, round_no=0):
        apple = case in ("rfn2", "dramc_nb2")
        if isinstance(case,int):
            spec=names[case-1]
            expected_code=codes[spec]
            gold=ref/f"compat/{case}/1/native"
        else:
            spec="doc/examples/apple/ord_live.ivy" if apple else "examples/raft/raft_no_assume.ivy"
            gold=Path(os.environ["APPLE_REFERENCE"] if apple else os.environ["RAFT_REFERENCE"])/case/"1/native"
            expected_code=0
        with tempfile.TemporaryDirectory(dir=d) as work:
            loc=Path(work)
            cmd=["taskset","-c",str(cpu)]
            if measure:
                cmd.extend([perf,"stat","-x,","-e","instructions:u","-o",str(loc/"stat"),"--"])
            cmd.extend([d/(mode+str(apple)),*(["isolate="+case] if apple else []),examples/spec])
            r=subprocess.run(cmd,cwd=loc,capture_output=True,timeout=240,
                             env=dict(os.environ,GOMAXPROCS="1",XTRACE_OFF="1",GOIVY_INCLUDE=str(examples/"ivy/include")))
            def expected(name):
                return (gold/name).read_bytes().replace(b"/home/jaten/ivy/ivy-lang-examples/",os.fsencode(examples)+b"/")
            if (r.returncode,r.stdout,r.stderr)!=(expected_code,expected("stdout"),expected("stderr")):
                (output/f"mismatch-{case}-{mode}.stderr").write_bytes(r.stderr)
                raise RuntimeError(f"transcript mismatch on {case} {mode}, exit {r.returncode}")
            if not measure:
                return [case,"match"]
            with (loc/"stat").open() as f:
                counts=[int(row[0]) for row in csv.reader(f) if len(row)>4 and row[2]=="instructions:u" and float(row[4])==100]
            if len(counts)!=1:raise RuntimeError("incomplete hardware instruction measurement")
            return [case,round_no,mode,counts[0],"match"]
    def group(cases,cpu,number):
        with (output/f"timing-{number}.csv").open("w") as f:
            out=csv.writer(f);out.writerow(["case","round","mode","instructions","transcript"])
            for c in cases:
                for r in range(3):
                    for mode in (["base","candidate"] if r%2==0 else ["candidate","base"]):
                        out.writerow(run(c,mode,cpu,True,r));f.flush()
    if not verify_only:
        with concurrent.futures.ThreadPoolExecutor(4) as pool:
            jobs=[pool.submit(group,g,cpus[i],i) for i,g in enumerate([
                [8,6,2,3,4,5,7,9,10,11,12,1],["raft_no_assume"],["rfn2"],["dramc_nb2"]])]
            for job in jobs:job.result()
    with concurrent.futures.ThreadPoolExecutor(4) as pool,(output/"verified.csv").open("w") as f:
        out=csv.writer(f);out.writerow(["case","transcript"])
        jobs=[pool.submit(run,n,"candidate",cpus[n%4],False) for n in range(1,len(names)+1)]
        for job in concurrent.futures.as_completed(jobs):
            out.writerow(job.result());f.flush()
