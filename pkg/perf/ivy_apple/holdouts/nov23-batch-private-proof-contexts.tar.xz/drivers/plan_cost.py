from study import *
from panel import CASES
root=w/'plan-cost';root.mkdir(exist_ok=True)
def make():
 q=pkg/'api/api_goal_instances_check.go'
 base=(w/'private-cost/overlay/meter.go').read_text();rd=base[base.index('func readCounter()'):base.index('func Begin(')]
 setup=base[base.index('runtime.LockOSThread()'):base.index('active = true')]
 obs='''package api
import ("fmt";"os";"runtime";"syscall";"unsafe")
var fd uintptr
var validation uint64
var empty uint64
var observed bool
'''+rd+'''func beginPlanCost() uint64{
'''+setup+'''a:=readCounter();empty=readCounter()-a;validation=0;observed=true;return readCounter()
}
func finishPlanCost(t uint64,kind string,width,count int,steps uint32,ok bool,stage [3]uint64){total:=readCounter()-t;observed=false;syscall.Close(int(fd));runtime.UnlockOSThread();fmt.Fprintln(os.Stderr,"PLAN-COST",kind,width,count,steps,ok,total,stage,validation,empty)}
'''
 s=q.read_text();i=s.index('{',s.index('func (p *orderProofState) checkProofPlan'))+1
 s=s[:i]+'''kind:="unknown";width,count:=0,0;switch a:=plan.(type){case *shortPremisePlan:kind="short";count=len(a.selected);case *witnessInstancePlan:kind="witness";width=a.width;count=len(a.assertions);case *goalInstancePlan:kind="ground";count=len(a.ground)}
 var stage [3]uint64;begin:=beginPlanCost();defer func(){finishPlanCost(begin,kind,width,count,maxSteps,proved,stage)}()
'''+s[i:]
 s=once(s,'m, err := aux.ctx.Manager()','stage[0]=readCounter()-begin; m, err := aux.ctx.Manager()')
 s=once(s,'complete, err := plan.assertIn(parent, m, aux.child)','t:=readCounter();complete,err:=plan.assertIn(parent,m,aux.child);stage[1]=readCounter()-t')
 s=once(s,'answer, err := aux.child.Check()','t=readCounter();answer,err:=aux.child.Check();stage[2]=readCounter()-t')
 wit=pkg/'api/api_witness_input.go';u=wit.read_text();i=u.index('{',u.index('func (s *witnessClauseSet) acceptsInput'))+1
 u=u[:i]+'if observed{t:=readCounter();defer func(){validation+=readCounter()-t}()}\n'+u[i:]
 iv=ivy.resolve()/'z3bridge_solver_model.go'
 return build(root/'build',o=overlay(root/'overlay',{q:s,wit:u,pkg/'api/plan_cost_observer.go':obs,iv:(w/'ground-paths/overlay'/iv.name).read_text()}))
def lane(job):
 ix,n,b=job;d=root/n;d.mkdir();rel,iso,_,fs,unk=CASES[n];ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))
 for r in range(2):
  proc=subprocess.run(['taskset','-c',str(3+ix),b,*(['isolate='+iso]if iso else[]),examples/rel],cwd=d,env=dict(env,GOMAXPROCS='1',GOGC='100'),capture_output=True)
  assert proc.returncode==int(bool(fs or unk))and proc.stdout==(ref/'stdout').read_bytes()and b''.join(l for l in proc.stderr.splitlines(keepends=True)if not l.startswith((b'PLAN-COST ',b'PATH-')))==(ref/'stderr').read_bytes(),d
  (d/f'{r+1}.stderr.gz').write_bytes(gzip.compress(proc.stderr,mtime=0))
 print(n,flush=True)
if __name__=='__main__':
 b=make();names=['tlb','cf_live','dramc_nb2','rfn2','flash2','hybrid_reliable_broadcast_cisa','ticket','raftok','raft_no_assume']
 with ThreadPoolExecutor(9)as ex:list(ex.map(lane,[(i,n,b)for i,n in enumerate(names)]))
