from study import *
import corpus_phases as cp
from collections import Counter,defaultdict
from math import ceil
from types import SimpleNamespace
from panel import measure
d=w/'verification-frontier';d.mkdir(exist_ok=True)
cases=['test/flash_cubicle.ivy','test/flash2.ivy','examples/liveness/tlb.ivy','jea/hermes_rmw_o3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/ticket_protocol.ivy','test/arm_rules3.ivy','examples/ivy/flash2.ivy','examples/liveness/ticket_nested.ivy','examples/liveness/alternating_bit_protocol.ivy','doc/examples/liveness/ticket_l2s_auto.ivy','test/test_liveness2.ivy']
def reference(n):
 data=w/'predicate-verification/corpus';i=(data/'specs.txt').read_text().splitlines().index(n);return data/str(i)/'reference'
def stages():
 cp.root=d/'stages';o=cp.instrumentation()
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(('g3','native'),ex.map(lambda e:build(cp.root/e,e,o),('g3','native'))))
 jobs=[(str(i),s,'',reference(s),int(b'[FAIL]'in (reference(s)/'stdout').read_bytes()or b'FAIL' in (reference(s)/'stdout').read_bytes()))for i,s in enumerate(cases)]
 # Use observed exits, because the TLB example includes expected counterexamples.
 data=w/'predicate-verification/corpus';status={r['spec']:int(r['exit'])for p in data.glob('cpu-*.csv')for r in csv.DictReader(p.open())}
 jobs=[(n,s,iso,ref,status[s])for n,s,iso,ref,_ in jobs]
 with ThreadPoolExecutor(3)as ex:list(ex.map(cp.lane,[(cpu,jobs[j::3],bs)for j,cpu in enumerate([2,11,18])]))
def summary():
 for i,n in enumerate(cases):
  rows={}
  for e in ('g3','native'):
   f=d/f'stages/runs/{i}/1-{e}/phases.csv.gz'
   if not f.exists():continue
   t=defaultdict(int);calls=Counter();hits=Counter();goals={}
   for r in csv.DictReader(gzip.open(f,'rt')):
    p=r['stage'];t[p]+=int(r['instructions']);calls[p]+=1;hits[p]+=r['result']=='-1';goals[(r['batch'],r['condition'],p)]=int(r['instructions'])
   rows[e]=(t,calls,hits,goals)
  if len(rows)==2:
   t,u=rows['g3'][0],rows['native'][0];diff=sorted(((round((v-u.get(p,0))/1e9,3),p,rows['g3'][1][p],rows['g3'][2][p])for p,v in t.items()),reverse=True)
   print(n, diff[:6])
def capture():
 bin=w/'ord-holdout-capture/binary/goivy_check';n=cases[0];rd=d/'cubicle-inputs';rd.mkdir(exist_ok=True)
 p=subprocess.run(['taskset','-c','8',bin,examples/n],cwd=rd,env=dict(env,GOMAXPROCS='1'),capture_output=True,timeout=200);ref=reference(n)
 assert p.stdout==(ref/'stdout').read_bytes() and p.stderr==(ref/'stderr').read_bytes() and not p.returncode
 for f in sorted(rd.glob('*.smt2')):f.with_suffix('.smt2.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0));f.unlink()
 print('inputs',len(list(rd.glob('*.gz'))),flush=True)
if __name__=='__main__':
 if sys.argv[1:] == ['summary']:summary()
 else:
  with ThreadPoolExecutor(2)as ex:
   jobs=[ex.submit(f)for f in (stages,capture)]
   for j in jobs:j.result()
  summary()
