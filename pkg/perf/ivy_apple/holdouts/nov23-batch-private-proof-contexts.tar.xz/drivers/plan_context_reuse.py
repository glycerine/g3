from study import *
import guarded_live as gl,macro_identity as mi
d=w/'plan-context-reuse';d.mkdir(exist_ok=True)
state=pkg/'api/api_order_abstraction.go';plan=pkg/'api/api_goal_instances_check.go';short=pkg/'api/api_short_premises.go'
def edits(v):
 if v=='control':return{}
 rounds=4 if '4-'in v else 16 if '16-'in v else 64
 cache='translation'in v;all=('all'in v)
 s=state.read_text();s=once(s,'type orderProofState struct {','type orderProofState struct {\n planAux *orderProofState\n planSource *ast.ASTManager\n planCount int\n planTranslation *ast.ASTTranslation')
 x='if p.child, err = p.ctx.NewSimpleSolver(); err != nil {';s=once(s,x,'''return p.newPrivateChild()
 }
 func(p *orderProofState)newPrivateChild()(err error){
 '''+x)
 x='if p.pendingCondition != nil {';s=once(s,x,'''if e:=p.closePlanTrial();e!=nil{return e}
 '''+x)
 s+='''\nfunc(p *orderProofState)closePlanTrial()error{
  if p.planTranslation!=nil{if e:=p.planTranslation.Close();e!=nil{return e};p.planTranslation=nil}
  if p.planAux!=nil{if e:=p.planAux.release();e!=nil{return e};p.planAux=nil}
  p.planSource=nil;p.planCount=0;return nil
 }
 '''
 t=plan.read_text();i=t.index('aux := &orderProofState{source: p.source}');j=t.index('m, err := aux.ctx.Manager()',i)
 t=t[:i]+'''short,isShort:=plan.(*shortPremisePlan)
 reuse:=ISUSE
 _=short;_=isShort
 if reuse && p.planAux!=nil && (p.planSource!=parent || p.planCount>=ROUNDS){if e:=p.closePlanTrial();e!=nil{return false,e}}
 var aux *orderProofState
 if reuse{aux=p.planAux}
 if aux==nil{
  aux=&orderProofState{source:p.source}
  if reuse{p.planAux=aux;p.planSource=parent}
  if e:=aux.start(parent);e!=nil{if !reuse{p.pendingCondition=aux};return false,e}
 }else if e:=aux.newPrivateChild();e!=nil{return false,e}
 defer func(){
  if !reuse{if e:=aux.release();e!=nil{p.pendingCondition=aux;proved,err=false,errors.Join(err,e)};return}
  p.planCount++
  if err!=nil || parent.ResourceLimit().CancelFlag(){err=errors.Join(err,p.closePlanTrial());proved=false;return}
  if e:=aux.child.Close();e!=nil{proved,err=false,e}else{aux.child=nil}
 }()
 '''.replace('ISUSE','true'if all else'isShort').replace('ROUNDS',str(rounds))+t[j:]
 if cache:
  x='complete, err := plan.assertIn(parent, m, aux.child)';t=once(t,x,'''var complete bool
  if reuse && isShort{
   input:=witnessClauseSet{m:m}
   complete,err=input.acceptsInput(parent,short.source)
   if err==nil && complete{
    if p.planTranslation==nil{p.planTranslation,err=ast.NewASTTranslation(parent,m,true)}
    if err==nil{complete,err=assertTranslatedPremises(p.planTranslation,m,aux.child,short.selected)}
   }
  }else{complete,err=plan.assertIn(parent,m,aux.child)}
  ''')
 return{state:s,plan:t}
def mk(v):
 od=d/v;o=overlay(od/'overlay',edits(v));return build(od/'checker',o=o)
def main():
 vs=['control','4-short','16-short','64-short','16-translation','64-translation','16-all-translation']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;js=mi.jobs()+[(17,'testing','jea/hermes_rmw_o3_testing.ivy','',0,2,w/'extended-phases/long/1/1/native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native')]
 with ThreadPoolExecutor(10)as ex:list(ex.map(lambda j:gl.measure_job(j,bs if j[0]not in (17,22)else{k:bs[k]for k in ['control','16-short','16-translation']}),js))
if __name__=='__main__':main()
