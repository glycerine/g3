from study import *
import binder_exits as binder
def trace(root):
 dest=root/'trace';sd=dest/'after';sd.mkdir(parents=True,exist_ok=True)
 with(w/'build.lock').open('a')as lk,(sd/'build.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-mod=readonly','-o',sd/'goivy_check','./cmd/goivy_check'],cwd=ivy,stdout=f,stderr=f)
 if not(sd/'abc').exists():(sd/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
 binder.root=dest;binder.trace({'before-trace':w/'conditional-evidence/trace/control/goivy_check','after-trace':sd/'goivy_check'})
if __name__=='__main__':trace(w/sys.argv[1])
