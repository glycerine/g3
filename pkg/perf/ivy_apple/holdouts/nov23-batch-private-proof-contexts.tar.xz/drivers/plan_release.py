from study import *
import guarded_live as gl,macro_identity as mi,ground_release_controls as gc,verification_frontier as vf
d=w/'plan-release';d.mkdir(exist_ok=True)
def main():
 b=build(d/'checker');bs={'previous':w/'conditional-pass/control/checker/goivy_check','g3':b,'native':w/'key-release/native/goivy_check'}
 gl.d=d;gc.d=d
 jobs=mi.jobs()+[(21,'testing','jea/hermes_rmw_o3_testing.ivy','',0,3,w/'extended-phases/long/1/1/native'),(23,'apple','doc/examples/apple/ord_live.ivy','',0,3,w/'apple-original-pairs/14-native')]
 with ThreadPoolExecutor(len(jobs)+2)as e:
  fs=[e.submit(gl.measure_job,j,bs)for j in jobs]
  fs.append(e.submit(gc.corpus,b))
  fs.append(e.submit(run,[sys.executable,pkg/'perf/ivy_apple/holdouts/rotating_verification.py','--g3',b,'--previous',bs['previous'],'--native',bs['native'],'--rounds','5','--max-attempts','30','--wait-seconds','5400','--min-idle','.95','--cpu','15','--spec',examples/'jea/hermes_rmw_o3.ivy','--reference',vf.reference('jea/hermes_rmw_o3.ivy'),'--perf',perf,'--output',d/'ordinary-quiet'],stdout=subprocess.DEVNULL))
  for f in fs:f.result()
if __name__=='__main__':main()
