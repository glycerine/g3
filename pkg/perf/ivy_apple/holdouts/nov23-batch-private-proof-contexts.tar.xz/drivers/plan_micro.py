from study import *
d=w/'plan-release'
with(d/'micro-rotating.csv').open('w')as f:
 z=csv.writer(f);z.writerow('round mode ns bytes allocs'.split())
 for i in range(15):
  for v in (['Fresh','Batch'] if i%2==0 else ['Batch','Fresh']):
   cmd=['taskset','-c','19',d/'api.test','-test.run','^$','-test.bench','^BenchmarkPrivateProofPlanContexts$/^'+v+'$','-test.benchtime=64x','-test.cpu=1','-test.benchmem']
   r=run(cmd,cwd=pkg/'api',capture_output=True,text=True);a=re.search(r'(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert a
   z.writerow([i+1,v,*a.groups()]);f.flush()
