from study import *
import macro_identity as mi
from collections import defaultdict,Counter
d=w/'prefix-census';d.mkdir(exist_ok=True);a=pkg/'api/api_goal_instances_check.go';state=pkg/'api/api_order_abstraction.go'
def make():
 ed={};s=once(state.read_text(),'type orderProofState struct {','var trialBatchOrdinal int\ntype orderProofState struct {\n trialBatch int')
 ed[state]=s
 helper=(w/'plan-cost/overlay/plan_cost_observer.go').read_text()
 # No nesting across private proof plans.
 h=pkg/'api/prefix_counter_trial.go';hsrc=helper[:helper.index('func finishPlanCost(')]+'''func endPrefixTrial()uint64{n:=readCounter();observed=false;syscall.Close(int(fd));runtime.UnlockOSThread();return n}''';ed[h]=hsrc.replace('"fmt"','').replace('"os"','')
 src=once(a.read_text(),'import (','import (\n"fmt"\n"os"')
 x='aux := &orderProofState{source: p.source}'
 src=once(src,x,'''var stage [4]uint64
 var began uint64
 plan1,short:=plan.(*shortPremisePlan)
 if short{
  if p.trialBatch==0{trialBatchOrdinal++;p.trialBatch=trialBatchOrdinal}
  began=beginPlanCost()
  defer func(){t:=endPrefixTrial()
   fmt.Fprintf(os.Stderr,"PREFIX %d %d %t %d %d %d %d %d %d %d",p.trialBatch,maxSteps,proved,t-began,stage[0],stage[1],stage[2],stage[3],len(plan1.source),len(plan1.selected))
   for _,h:=range plan1.selected{fmt.Fprintf(os.Stderr," %d.%d",h.Slot(),h.Generation())};fmt.Fprintln(os.Stderr)
  }()
 }
 '''+x)
 src=once(src,'m, err := aux.ctx.Manager()', 'if short{stage[0]=readCounter()-began};m,err:=aux.ctx.Manager()')
 src=once(src,'complete, err := plan.assertIn','if short{stage[1]=readCounter()};complete,err:=plan.assertIn')
 src=once(src,'answer, err := aux.child.Check()','if short{stage[1]=readCounter()-stage[1];stage[2]=readCounter()};answer,err:=aux.child.Check();if short{stage[2]=readCounter()-stage[2];stage[3]=validation}')
 ed[a]=src
 # Validation cost is inclusive in assertion construction.
 q=pkg/'api/api_witness_input.go';s=q.read_text();i=s.index('{',s.index('func validProofInput('))+1;s=s[:i]+'\n if observed{a:=readCounter();defer func(){validation+=readCounter()-a}()}\n'+s[i:];ed[q]=s
 return build(d/'checker',o=overlay(d/'overlay',ed))
def main():
 b=make();js=mi.jobs()+[(17,'testing','jea/hermes_rmw_o3_testing.ivy','',0,1,w/'extended-phases/long/1/1/native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,1,w/'apple-original-pairs/14-native')]
 def job(j):
  cpu,n,sp,iso,rc,_,rf=j;sd=d/n;sd.mkdir(exist_ok=True);p=subprocess.run(['taskset','-c',str(cpu),b,*(['isolate='+iso]if iso else[]),examples/sp],env=dict(env,GOMAXPROCS='1'),cwd=sd,capture_output=True);ls=p.stderr.splitlines(keepends=True);lines=[l.decode().split()[1:]for l in ls if l.startswith(b'PREFIX ')];assert p.returncode==rc and p.stdout==(rf/'stdout').read_bytes()and b''.join(l for l in ls if not l.startswith(b'PREFIX '))==(rf/'stderr').read_bytes(),(n,p.returncode,p.stderr[-180:])
  with gzip.open(sd/'calls.csv.gz','wt')as f:
   z=csv.writer(f);z.writerow('batch cap proved total setup assertions check validation source_size selected_size prefix goal'.split())
   for row in lines:z.writerow([*row[:10],' '.join(row[10:-1]),row[-1]])
  print(n,len(lines),flush=True)
 with ThreadPoolExecutor(7)as e:list(e.map(job,js))
def report():
 for f in sorted(d.glob('*/calls.csv.gz')):
  rs=list(csv.DictReader(gzip.open(f,'rt')));hs={}
  for r in rs:hs.setdefault(r['batch'],[]).append(r)
  def eligible(slots):
   out=[]
   for rows in hs.values():
    cache=[]
    for r in rows:
     key=(r['prefix'],r['cap'])
     if key in cache:out.append(r);cache.remove(key)
     cache.insert(0,key);cache=cache[:slots]
   return out
  print(f.parent.name,len(rs),round(sum(int(r['total'])for r in rs)/1e9,3),[(x,len(rr),[round(sum(int(r[t])for r in rr)/1e9,3)for t in ['total','setup','assertions','validation','check']])for x in [1,2,4,16]if(rr:=eligible(x))])
if __name__=='__main__':
 if 'report'in sys.argv:report()
 else:main()
