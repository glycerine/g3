from study import *
import plan_context_reuse as pr,macro_identity as mi,guarded_live as gl,conditional_changes as ch
d=w/'plan-reset';d.mkdir(exist_ok=True)
def edit(v):
 if v=='control':return{}
 q=pr.state;s=q.read_text();s=once(s,'type orderProofState struct {','type orderProofState struct {\n trialPlanContext *orderProofState\n trialPlanOwner *ast.ASTManager\n trialPlanChecks uint32')
 x='if p.pendingCondition != nil {';s=once(s,x,'if e:=p.closeTrialPlanContext();e!=nil{return e};'+x)
 s+='''\nfunc(p *orderProofState)closeTrialPlanContext()error{
  if p.trialPlanContext==nil{return nil}
  if e:=p.trialPlanContext.release();e!=nil{return e}
  p.trialPlanContext=nil;p.trialPlanOwner=nil;p.trialPlanChecks=0;return nil
 }
 '''
 t=pr.plan.read_text();i=t.index('aux := &orderProofState{source: p.source}');j=t.index('m, err := aux.ctx.Manager()',i)
 size=4 if v.startswith('4')else 16 if v.startswith('16')else 64
 t=t[:i]+'''_,short:=plan.(*shortPremisePlan);_=short;reuse:=ELIGIBLE
 if reuse && p.trialPlanContext!=nil && (p.trialPlanOwner!=parent || p.trialPlanChecks>=N){if e:=p.closeTrialPlanContext();e!=nil{return false,e}}
 var aux *orderProofState
 if reuse{aux=p.trialPlanContext}
 if aux==nil{
  aux=&orderProofState{source:p.source}
  if reuse {p.trialPlanContext=aux;p.trialPlanOwner=parent}
  if e:=aux.start(parent);e!=nil{if !reuse{p.pendingCondition=aux};return false,e}
 }
 defer func(){
  if reuse{
   p.trialPlanChecks++
   if err==nil && !parent.ResourceLimit().CancelFlag(){if e:=aux.child.Reset();e==nil{return}else{err=e;proved=false}}
   err=errors.Join(err,p.closeTrialPlanContext());return
  }
  if e:=aux.release();e!=nil{p.pendingCondition=aux;proved,err=false,errors.Join(err,e)}
 }()
 '''.replace('ELIGIBLE','true'if 'all'in v else'short').replace('>=N','>='+str(size))+t[j:]
 return {q:s,pr.plan:t}
def mk(v):
 od=d/v;ed=edit(v)
 if 'composed'in v:ed.update(ch.edits('changed'))
 return build(od/'checker',o=overlay(od/'overlay',ed))
def main():
 vs=['control','4-short','16-short','16-all','64-all','16-all-composed']
 with ThreadPoolExecutor(2)as e:bs=dict(zip(vs,e.map(mk,vs)))
 gl.d=d;js=mi.jobs()+[(17,'testing','jea/hermes_rmw_o3_testing.ivy','',0,2,w/'extended-phases/long/1/1/native'),(22,'apple','doc/examples/apple/ord_live.ivy','',0,2,w/'apple-original-pairs/14-native')]
 with ThreadPoolExecutor(10)as ex:list(ex.map(lambda j:gl.measure_job(j,bs if j[0]not in (17,22)else{k:bs[k]for k in ['control','16-all','16-all-composed']}),js))
if __name__=='__main__':main()
