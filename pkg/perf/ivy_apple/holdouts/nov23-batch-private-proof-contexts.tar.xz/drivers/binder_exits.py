from study import *
from panel import CASES,panel
root=w/'binder-exits';root.mkdir(exist_ok=True)
p=ivy.resolve();f=p/'logicutil_logic_utils.go';q=p/'cmd/goivy_check/main.go';old=subprocess.check_output(['git','show','817871f86:goivy/logicutil_logic_utils.go'],cwd=ivy,text=True)
def make(n):
    e='native'if 'native'in n else'g3';pre='before'in n;ed={f:old}if pre else {}
    if 'alloc'in n:
        s=q.read_text();s=once(s,'import (','import (\n"runtime"')
        s=once(s,'os.Exit(goivy.MainWithConfig(args, cfg))','''var a,b runtime.MemStats;runtime.ReadMemStats(&a);code:=goivy.MainWithConfig(args,cfg);runtime.ReadMemStats(&b);fmt.Fprintln(os.Stderr,"BINDER-ALLOC",b.TotalAlloc-a.TotalAlloc,b.Mallocs-a.Mallocs);os.Exit(code)''');ed[q]=s
    d=root/n;o=overlay(d/'overlay',ed)
    if 'trace' not in n:return build(d,e,o)
    with(w/'build.lock').open('a')as lk,(d/'build.log').open('w')as log:
        fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-mod=readonly','-pgo=off','-buildvcs=false','-overlay='+str(o),'-o',d/'goivy_check','./cmd/goivy_check'],cwd=ivy,stdout=log,stderr=log)
    (d/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc');return d/'goivy_check'
def alloc(bs):
    def lane(job):
        i,n=job;d=root/'memory'/n;d.mkdir(parents=True);rel,iso,_,fails,unk=CASES[n];ref=next((prior/'end-panel-final').glob('*/'+n+'/1/g3'))
        with(d/'runs.csv').open('w')as out:
            wr=csv.writer(out);wr.writerow(['case','pair','variant','cpu','bytes','objects'])
            for r in range(4):
                seq=['before-alloc','after-alloc','before-alloc-native','after-alloc-native']
                for en in seq if r%2==0 else seq[::-1]:
                    p=subprocess.run(['taskset','-c',str(2+i),bs[en],*(['isolate='+iso]if iso else[]),examples/rel],cwd=d,env=dict(env,GOMAXPROCS='1'),capture_output=True)
                    l=[line for line in p.stderr.splitlines()if line.startswith(b'BINDER-ALLOC ')]
                    assert len(l)==1 and p.returncode==int(bool(unk or fails))and p.stdout==(ref/'stdout').read_bytes()and b''.join(s for s in p.stderr.splitlines(keepends=True)if not s.startswith(b'BINDER-ALLOC '))==(ref/'stderr').read_bytes()
                    wr.writerow([n,r+1,en,2+i,*l[0].decode().split()[1:]]);out.flush()
    with ThreadPoolExecutor(5)as ex:list(ex.map(lane,enumerate(['tlb','dramc_nb2','rfn2','cf_live','flash2'])))
def trace(bs):
    with(root/'trace.csv').open('w')as out:run(['python3','-B',pkg/'perf/ivy_apple/compare_frontend_traces.py','--checker','before','40',bs['before-trace'],'--checker','after','41',bs['after-trace'],'--spec',examples/'doc/examples/apple/ord_live.ivy','--isolate','rfn2','--passes','26','--output',root/'trace-rfn2'],stdout=out)
    o=root/'paxos.log';case=examples/'jea/popl18-p145-aux/reducing-liveness-to-safety-in-first-order-logic/paxos_liveness/multi_paxos_liveness.ivy'
    with o.open('wb')as out:r=subprocess.run(['taskset','-c','40',bs['after-trace'],case],cwd=root,env=dict(env,XTRACE_OFF='0',GOMAXPROCS='1'),stdout=out,stderr=subprocess.STDOUT)
    assert r.returncode==1
    a=run(['python3','-B','/tmp/g3-paxos-log3/compare.py','py.log',o],capture_output=True,text=True);assert 'all output match'in a.stdout;(root/'paxos.txt').write_text(a.stdout)
if __name__=='__main__':
    names=['before-trace','after-trace','after','before-alloc','after-alloc','before-alloc-native','after-alloc-native']
    with ThreadPoolExecutor(3)as ex:bs=dict(zip(names,ex.map(make,names)))
    with ThreadPoolExecutor(3)as ex:
        jobs=[ex.submit(trace,bs),ex.submit(alloc,bs),ex.submit(panel,root/'panel',{'before':w/'parsed-release/after/goivy_check','after':bs['after']},['dramc_nb2','tlb','rfn2','cf_live','flash2','hybrid_reliable_broadcast_cisa'],5,22)]
        for j in jobs:j.result()
