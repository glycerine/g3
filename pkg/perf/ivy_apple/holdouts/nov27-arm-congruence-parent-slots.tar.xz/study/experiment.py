from pathlib import Path
import subprocess as sp,tarfile
def variants(pkg,mode):
    def src(name):return sp.check_output(['git','show','78f29d7f7:pkg/smtcore/'+name]).decode()
    for name in ('smt_equality_propagation.go','smt_enode_core.go','smt_cg_small_table.go','smt_cg_table.go'):
        s=src(name)
        if mode!='base' and name=='smt_equality_propagation.go':s=s.replace('s.congruence.Erase(parent)','s.congruence.eraseParent(parent)')
        if mode=='hint' and name=='smt_enode_core.go':s=s.replace('internalScopeLevel                    uint32','internalScopeLevel, cgSlot uint32',1)
        if mode=='hint' and name=='smt_cg_small_table.go':
            s=s.replace('*e = smtCgSmallEntry{k0, k1, node}','*e = smtCgSmallEntry{k0, k1, node};node.cgSlot=uint32(i)')
            s=s.replace('e.node = node','e.node = node;node.cgSlot=uint32(i)').replace('t.entries[i] = *e','t.entries[i] = *e;e.node.cgSlot=uint32(i)')
        if mode!='base' and name=='smt_cg_table.go':
            idx={'hint':'int(node.cgSlot)','home':'smtCgSmallSlot(key[0],key[1],small.shift)','lookup':'small.slot(key[0],key[1])'}[mode]
            s+='''
func (t *SMTCongruenceTable) eraseParent(node *SMTEnode)(bool,error){
    if len(node.arguments)>0 && len(node.arguments)<=2 && (!node.commutative || len(node.arguments)==2) && int64(node.functionDeclID)<int64(len(t.buckets)){
        b:=t.buckets[node.functionDeclID];small:=&b.small
        if b.declaration==node.declaration && small.count!=0{
            key:=smtCongruenceSmallKey(node)
            i:='''+idx+'''
            if uint(i)<uint(len(small.entries)){
                e:=&small.entries[i]
                if e.node==node && e.k0==key[0] && e.k1==key[1]{
                    small.deleteSlot(i);return true,nil
                }
            }
        }
    }
    return t.Erase(node)
}
'''
        yield pkg/'smtcore'/name,s

if __name__=='__main__':
    with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
    a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
    s=s[:a]+"""    modes=['base','home','lookup','hint']
    for mode in modes:
        for p,source in variants(pkg,mode):put(p,source)
"""+s[b:]
    exec(compile(s.replace("'notification.csv'","'erase.csv'"),'erase','exec'))
