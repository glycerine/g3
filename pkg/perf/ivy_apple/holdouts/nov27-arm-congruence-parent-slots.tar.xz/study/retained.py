from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['base','hint','restore']
    for mode in modes:
        for n in ['smt_cg_table.go','smt_cg_small_table.go','smt_enode_core.go','smt_equality_propagation.go']:
            p=pkg/'smtcore'/n
            put(p,p.read_text() if mode=='restore' else sp.check_output(['git','show',('75f6f67e1' if mode=='hint' else '78f29d7f7')+':pkg/smtcore/'+n]).decode())
"""+s[b:]
exec(compile(s.replace('range(4)','range(6)').replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'notification.csv'","'retained.csv'"),'retained','exec'))
