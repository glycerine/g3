"""Compare equality-maintenance regions on three full-history ARM checks."""
from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-backjump-relevance-and-reductions.tar.xz') as t:s=t.extractfile('study/phase.py').read().decode()
def add_probes(code,prefix,methods,statement):
    for i,name in enumerate(methods):
        a=code.index(prefix+name+'(');b=code.index('{',a)+1
        code=code[:b]+statement.replace('PHASE',str(i))+code[b:]
    return code
def go_body(pkg):
    p=pkg/'smtcore/smt_equality_propagation.go'
    src=p.read_text().replace('import (','import (\n"syscall"\n"unsafe"\n"os"\n"strconv"')
    src+='''
func regionRead(fd int)int64{var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,uintptr(fd),uintptr(unsafe.Pointer(&v)),24);if n!=24||e!=0||v[1]!=v[2]{panic("region counter")};return int64(v[0])}
func regionFinish(fd,phase int,a,b int64){v:=regionRead(fd);println("POP-PHASE",phase,1,v-2*b+a)}
'''
    return p,add_probes(src,'func (s *SMTInternalizerState) ',['detachCongruenceParents','reinsertCongruenceParents','undoEquality'],'\nif fd,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));e==nil{a,b:=regionRead(fd),regionRead(fd);defer regionFinish(fd,PHASE,a,b)}\n')
def cpp_body(pkg):
    p=pkg.parent/'src/smt/smt_context.cpp'
    src='''#include <cstdlib>
#include <unistd.h>
struct arm_meter{
 int fd=-1,op;long long a,b;
 long long rd(){unsigned long long c[3];if(read(fd,c,24)!=24||c[1]!=c[2])__builtin_trap();return c[0];}
 arm_meter(int op):op(op){if(auto x=getenv("QI_COUNTER_FD")){fd=atoi(x);a=rd();b=rd();}}
 ~arm_meter(){if(fd>=0){auto v=rd();fprintf(stderr,"POP-PHASE %d 1 %lld\\n",op,v-2*b+a);}}
};
'''
    src='#include <cstdio>\n'+src+p.read_text()
    return p,add_probes(src,'void context::',['remove_parents_from_cg_table','reinsert_parents_into_cg_table','undo_add_eq'],'arm_meter sample(PHASE);')
a=s.index("            p=pkg/'smtcore/smt_relevancy.go'");b=s.index('        else:',a)
s=s[:a]+"            p,src=go_body(pkg);put(p,src)\n"+s[b:]
a=s.index("            p=pkg.parent/'src/smt/smt_relevancy.cpp'");b=s.index('            src=d/p.name;',a)
s=s[:a]+"            p,s=cpp_body(pkg)\n"+s[b:]
s=s.replace("d/'smt_relevancy.o'","d/'smt_context.o'").replace('((batch==12||batch==13||batch==14)&&index==7)||(batch==16&&index==0)','batch==6&&index>=3&&index<=5').replace('splitlines()[7]','splitlines()[3]').replace("'compat/8/1/native'","'compat/4/1/native'").replace('{(12,8),(13,8),(14,8),(16,1)}','{(6,4),(6,5),(6,6)}').replace('len(totals)==12','len(totals)==9').replace('range(5)','range(3)').replace("'phase.csv'","'regions.csv'")
exec(compile(s,'regions','exec'))
