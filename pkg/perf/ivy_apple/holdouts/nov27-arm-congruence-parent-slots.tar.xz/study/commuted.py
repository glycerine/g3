from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'restore.py').read_text()
s=s.replace("if mode in ('hint','both'):","if mode in ('hint','both','home','flip'):").replace("if mode in ('restore','both')", "if mode in ('both','home','flip')").replace("if mode=='both' else ''","if mode in ('both','home','flip') else ''")
s=s.replace("        yield p,s",'''        if mode in ('both','home','flip') and p.name=='smt_cg_table.go':
            idx=s.index('func (t *SMTCongruenceTable) restoreParent(')
            pre,body=s[:idx],s[idx:]
            body=body.replace('&& !node.commutative','&& (!node.commutative || n==2)')
            anchor='*e=smtCgSmallEntry'
            guard='if node.commutative && !b.flatAssociative && key[0]!=key[1] && small.get(key[1],key[0])!=nil{break};'
            if mode=='flip':
                body=body.replace('for i:=smtCgSmallSlot',guard.replace('break','_,err:=t.Insert(node);return err')+'for i:=smtCgSmallSlot')
            else:body=body.replace(anchor,guard+anchor)
            if mode=='home':
                body=body.replace('if e.k0==key[0]', 'if e.node!=node{break};if e.k0==key[0]')
            s=pre+body
        yield p,s''')
s=s.replace("['base','hint','restore','both']","['hint','both','home','flip']").replace("'final.csv'","'commuted.csv'")
exec(compile(s,'commuted','exec'))
