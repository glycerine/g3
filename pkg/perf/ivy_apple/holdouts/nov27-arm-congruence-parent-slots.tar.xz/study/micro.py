from pathlib import Path
import os,subprocess as sp,json
from experiment import variants
d=Path(__file__).resolve().parent;pkg=Path.cwd()
for mode in ('base','lookup','hint'):
    mp={}
    for p,src in variants(pkg,mode):
        dst=d/(mode+p.name);dst.write_text(src);mp[str(p)]=str(dst)
    # This benchmark reports the structural footprint alongside merge and undo timings.
    t=pkg/'smtcore/smt_cg_lookup_benchmark_test.go';src=t.read_text().replace('import (','import (\n"unsafe"')+'\nfunc BenchmarkStudyEnode(b *testing.B){b.ReportMetric(float64(unsafe.Sizeof(SMTEnode{})),"bytes/enode")}\n'
    dst=d/(mode+t.name);dst.write_text(src);mp[str(t)]=str(dst)
    ov=d/(mode+'.json');ov.write_text(json.dumps({'Replace':mp}))
    sp.run(['go','test','-pgo=perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof','-overlay',ov,'-c','-o',d/(mode+'.test'),'./smtcore'],check=True)
for i in range(4):
    modes=['base','lookup','hint'];modes=modes[i%3:]+modes[:i%3]
    for mode in modes:
        with (d/(mode+'.txt')).open('a') as f:
            sp.run(['taskset','-c',os.environ['CPU'],d/(mode+'.test'),'-test.run=^$','-test.bench=^Benchmark(SMTMergeAndUndo|StudyEnode)$','-test.benchtime=3000x','-test.benchmem'],cwd=pkg/'smtcore',stdout=f,check=True)
