from pathlib import Path
d=Path(__file__).resolve().parent
exec((d/'regions.py').read_text().rsplit("exec(compile(s,",1)[0])
oldgo,oldcpp=go_body,cpp_body
def go_body(pkg):
    p,code=oldgo(pkg)
    marker='if fd,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));e==nil{a,b:=regionRead(fd),regionRead(fd);defer regionFinish(fd,2,a,b)}'
    assert code.count(marker)==1
    code=code.replace(marker,'''fd,e:=strconv.Atoi(os.Getenv("QI_COUNTER_FD"));var a,b int64;start:=func(){if e==nil{a,b=regionRead(fd),regionRead(fd)}};done:=func(op int){if e==nil{regionFinish(fd,op,a,b)}};start()
''')
    a=code.index('func (s *SMTInternalizerState) undoEquality(');b=code.index('func smtInvertTrans',a)
    part=code[a:b];part=part.replace('entry.stage = 1','done(2);start();entry.stage = 1').replace('entry.stage = 2','done(3);start();entry.stage = 2').replace('entry.stage = 3','done(4);start();entry.stage = 3').replace('entry.stage = 4','done(5);entry.stage = 4')
    return p,code[:a]+part+code[b:]
def cpp_body(pkg):
    p,code=oldcpp(pkg)
    marker='arm_meter sample(2);'
    assert code.count(marker)==1
    code=code.replace(marker,'''int fd=-1;if(auto x=getenv("QI_COUNTER_FD"))fd=atoi(x);long long a=0,b=0;
    auto readIt=[&](){unsigned long long v[3];if(read(fd,v,24)!=24||v[1]!=v[2])__builtin_trap();return (long long)v[0];};
    auto start=[&](){if(fd>=0){a=readIt();b=readIt();}};auto done=[&](int op){if(fd>=0){auto v=readIt();fprintf(stderr,"POP-PHASE %d 1 %lld\\n",op,v-2*b+a);}};start();''')
    a=code.index('void context::undo_add_eq(');b=code.index('\n    }',a)
    part=code[a:b].replace('enode * curr = r1;','done(2);start();enode * curr = r1;').replace('// try to reinsert parents of r1','done(3);start();// try to reinsert parents of r1').replace('// restore theory vars','done(4);start();// restore theory vars')
    return p,code[:a]+part+'\n done(5);'+code[b:]
s=s.replace("'regions.csv'","'undo-regions.csv'").replace('len(totals)==9','len(totals)==18')
exec(compile(s,'undo-regions','exec'))
