from pathlib import Path
import subprocess as sp
d=Path(__file__).resolve().parent
s=(d/'symmetric.py').read_text().split("with tarfile.open(")[0]
exec(s.replace("s=p.read_text()","s=sp.check_output(['git','show','75f6f67e1:pkg/smtcore/'+name]).decode()"))
# The enode file did not change after the slot commit.
s=(d/'panel.py').read_text().replace('from experiment import variants','').replace("'base'):", "'base'):")
exec(compile(s,'pair-panel','exec'))
