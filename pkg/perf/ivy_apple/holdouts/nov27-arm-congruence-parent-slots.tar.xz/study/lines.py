from pathlib import Path
import subprocess as sp
d=Path(__file__).resolve().parent/'allocsites'
for case in [4,8]:
    p=d/(str(case)+'-trial.pb.gz')
    for function in ('newSMTEnode','newSMTFingerprint'):
        result=sp.run(['go','tool','pprof','-list=\\.'+function+'$','-sample_index=alloc_objects',p],capture_output=True,text=True,check=True)
        (d/(str(case)+'-'+function+'.txt')).write_text(result.stdout)
