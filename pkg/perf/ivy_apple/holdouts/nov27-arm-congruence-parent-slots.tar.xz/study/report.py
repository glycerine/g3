from pathlib import Path
from statistics import median
from collections import defaultdict, Counter
import csv
d=Path(__file__).resolve().parent
for file,base in [('commuted','hint'),('symmetric','base')]:
    path=d/(file+'.csv')
    if not path.exists():continue
    c=Counter()
    for r in csv.DictReader(path.open()):c[r['case'],r['mode'],r['round']]+=int(r['instructions'])
    for case,m in sorted(set(k[:2] for k in c)):
        vals=[100*(v/c[case,base,k[2]]-1) for k,v in c.items() if k[:2]==(case,m) and (case,base,k[2]) in c]
        if vals:print(file,case,m,len(vals),round(median(vals),3))
for file in ('counts','undo-counts'):
    rows=list(csv.DictReader((d/(file+'.csv')).open()))
    for case in ('4','8'):
        selected=[r for r in rows if r['case']==case and r['round']=='0']
        print(file,case,{k:sum(int(r[k]) for r in selected) for k in list(rows[0])[5:]})
