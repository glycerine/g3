from pathlib import Path
import subprocess as sp
d=Path(__file__).resolve().parent/'allocsites'
for p in sorted(d.glob('*.pb.gz')):
    for idx in ('alloc_objects','alloc_space'):
        for group in ('all','solver'):
            if group=='solver' and 'native' in p.name:continue
            args=['go','tool','pprof','-top','-nodecount=30','-unit='+('bytes' if idx=='alloc_space' else 'count'),'-sample_index='+idx]
            if group=='solver':args+=['-focus=github.com/glycerine/g3/pkg/']
            result=sp.run([*args,p],capture_output=True,text=True,check=True)
            (d/(p.name.split('.')[0]+'-'+idx+'-'+group+'.txt')).write_text(result.stdout)
