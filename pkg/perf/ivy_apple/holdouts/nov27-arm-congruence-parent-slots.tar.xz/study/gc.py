from pathlib import Path
d=Path(__file__).resolve().parent
src=(d/'combined.py').read_text().rsplit('exec(compile(s,',1)[0]
exec(compile(src,'prepare','exec'))
a=s.index("    j=d/'overlay.json'")
s=s[:a]+'''    p=front/'cmd/goivy_check/main.go';body=p.read_text();body=body.replace('import (','import (\\n"runtime"\\n"runtime/metrics"')
    body=body.replace('os.Exit(goivy.MainWithConfig(args, cfg))',end)
    dst=d/(name+p.name);dst.write_text(body);mp[str(p)]=str(dst)
'''+s[a:]
end='''code:=goivy.MainWithConfig(args,cfg);var m runtime.MemStats;runtime.ReadMemStats(&m)
v:=[]metrics.Sample{{Name:"/cpu/classes/gc/mark/assist:cpu-seconds"},{Name:"/cpu/classes/gc/total:cpu-seconds"}}
metrics.Read(v);fmt.Fprintln(os.Stderr,"GC-STATS",m.NumGC,m.TotalAlloc,m.Mallocs,m.PauseTotalNs,v[0].Value.Float64(),v[1].Value.Float64());os.Exit(code)'''
s=s.replace('assert (r.returncode,r.stdout,r.stderr)==','lines=r.stderr.splitlines(keepends=True);marked=[l for l in lines if l.startswith(b"GC-STATS ")];assert len(marked)==1;stats=marked[0].split()[1:];assert (r.returncode,r.stdout,b"".join(l for l in lines if l!=marked[0]))==')
s=s.replace('round(elapsed,3)]','round(elapsed,3),*[float(x) for x in stats]]').replace("'wall_ms']","'wall_ms','num_gc','allocated_bytes','mallocs','pause_ns','assist_seconds','gc_cpu_seconds']")
s=s.replace('range(9):','range(25):').replace('((4,6),(8,3))','((4,),(6,),(8,))')
exec(compile(s,'gc-cost','exec'))
