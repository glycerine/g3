from experiment import variants
from pathlib import Path
import os,tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/panel.py').read().decode()
a=s.index("    if name=='trial':");b=s.index("    j=d/",a)
s=s[:a]+"""    for p,src in variants(pkg,os.environ['ERASE'] if name=='trial' else 'base'):
        dst=d/(name+p.name);dst.write_text(src);mp[str(p)]=str(dst)
"""+s[b:]
exec(compile(s,'whole-verifier','exec'))
