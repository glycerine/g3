from pathlib import Path
d=Path(__file__).resolve().parent
script=(d/'combined.py').read_text().rsplit('exec(compile(s,',1)[0]
exec(compile(script,'prepare','exec'))
s=s.replace('range(9):','range(25):').replace("GOGC='100'","GOGC=os.environ['STUDY_GC']").replace('((4,6),(8,3))','((4,),(6,),(8,))')
exec(compile(s,'repeat','exec'))
