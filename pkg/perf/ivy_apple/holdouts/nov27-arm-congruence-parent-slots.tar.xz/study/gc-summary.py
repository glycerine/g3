from pathlib import Path
from statistics import median
import csv
d=Path(__file__).resolve().parent
for f in sorted((d/'gc-panel').glob('time-*.csv')):
    rows=list(csv.DictReader(f.open()))
    if len(rows)!=50:continue
    pairs={}
    for r in rows:pairs.setdefault(r['round'],{})[r['engine']]=r
    for mode in ('base','trial'):
        sample=[v[mode] for v in pairs.values()]
        print(f.stem,mode,[(k,median(float(r[k]) for r in sample)) for k in ('allocated_bytes','mallocs','num_gc','gc_cpu_seconds','assist_seconds')])
    dg=[int(float(v['trial']['num_gc'])-float(v['base']['num_gc'])) for v in pairs.values()]
    print(f.stem,'paired cycle deltas',dict((i,dg.count(i)) for i in sorted(set(dg))))
