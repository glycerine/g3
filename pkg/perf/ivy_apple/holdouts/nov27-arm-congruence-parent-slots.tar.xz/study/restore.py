"""Probe and restore the known parent on undo with no per-merge journal."""
from experiment import variants as erase
from pathlib import Path
import tarfile
def variants(pkg,mode):
    for p,s in erase(pkg,'base'):
        if mode in ('hint','both'):s=p.read_text()
        if mode in ('restore','both') and p.name=='smt_equality_propagation.go':
            s=s.replace('if _, err := s.congruence.Insert(parent); err != nil {','if err := s.congruence.restoreParent(parent); err != nil {')
        if mode in ('restore','both') and p.name=='smt_cg_table.go':
            s+='''
func (t *SMTCongruenceTable) restoreParent(node *SMTEnode) error{
    n:=len(node.arguments)
    if (n==1||n==2)&& !node.commutative && uint(node.functionDeclID)<uint(len(t.buckets)){
        b:=t.buckets[node.functionDeclID];small:=&b.small
        if b.declaration==node.declaration && 2*(small.count+1)<=len(small.entries){
            key:=smtCongruenceSmallKey(node);mask:=len(small.entries)-1
            for i:=smtCgSmallSlot(key[0],key[1],small.shift);;i=(i+1)&mask{
                e:=&small.entries[i];if e.node==nil{
                    *e=smtCgSmallEntry{key[0],key[1],node};small.count++;HINT
                    return nil
                }
                if e.k0==key[0] && e.k1==key[1]{if e.node==node{return nil};break}
            }
        }
    }
    _,err:=t.Insert(node);return err
}
'''.replace('HINT','node.congruenceSlot=uint32(i)' if mode=='both' else '')
        yield p,s
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['base','hint','restore','both']
    for mode in modes:
        for p,source in variants(pkg,mode):put(p,source)
"""+s[b:]
exec(compile(s.replace("'notification.csv'","'final.csv'"),'restore','exec'))
