import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/native-panel.py').read().decode()
s=s.replace('((1,3),(4,8),(6,227))','((4,8),)').replace('ThreadPoolExecutor(3)','ThreadPoolExecutor(1)')
exec(compile(s,'native','exec'))
