from pathlib import Path
from statistics import median
import csv
from collections import Counter,defaultdict
d=Path(__file__).resolve().parent
for name in ('erase','insert','journal','final','retained'):
    f=d/(name+'.csv')
    if not f.exists():continue
    s=Counter();rounds=set()
    for r in csv.DictReader(f.open()):
        s[r['case'],r['mode'],r['round']]+=int(r['instructions']);rounds.add(r['round'])
    for c,m in sorted(set(k[:2] for k in s)):
        keys=[i for i in rounds if (c,m,i) in s and (c,'base',i) in s]
        if keys:print(name,c,m,len(keys),int(median(s[c,m,i] for i in keys)),round(median(100*(s[c,m,i]/s[c,'base',i]-1) for i in keys),3))
for f in sorted(d.glob('*panel/time-*.csv')):
    v=defaultdict(dict)
    for r in csv.DictReader(f.open()):v[r['round']][r['engine']]=int(r['instructions'])
    pairs=[100*(p['trial']/p['base']-1) for p in v.values() if len(p)==2]
    if pairs:print(f.parent.name,f.stem,len(pairs),round(median(pairs),3))
