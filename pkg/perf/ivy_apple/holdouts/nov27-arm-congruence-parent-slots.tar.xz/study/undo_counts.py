from pathlib import Path
import tarfile
d=Path(__file__).resolve().parent
src=(d/'count.py').read_text()
a=src.index('s=s[:a]+');b=src.index('a=s.index("    put(front/',a)
src=src[:a]+'''s=s[:a]+"""    modes=['current']
    for mode in modes:
        p=pkg/'smtcore/smt_equality_propagation.go'
        body=p.read_text()
        needle='if _, err := s.congruence.Insert(parent); err != nil {'
        assert body.count(needle)==1
        body=body.replace(needle,code+needle)
        put(p,body+'\\\\nvar CgStudy [6]int64\\\\n')
"""+s[b:]
'''+src[b:]
code='''
    switch {
    case len(parent.arguments)>2: CgStudy[0]++
    case parent.commutative: CgStudy[1]++
    default: CgStudy[2]++
    }
    candidate,_,probeErr:=s.congruence.Find(parent);if probeErr!=nil{panic(probeErr)}
    if candidate==nil{CgStudy[3]++}else if candidate==parent{CgStudy[4]++}else{CgStudy[5]++}
'''
exec(compile(src.replace('hit fallback home writes shifts rehash','wide commutative ordered absent self other').replace("'counts.csv'","'undo-counts.csv'"),'audit','exec'))
