from experiment import variants
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['hint']
    for mode in modes:
        for p,src in variants(pkg,mode):
            if p.name=='smt_cg_table.go':
                src=src.replace('small.deleteSlot(i);return true,nil','CgStudy[0]++;if i==smtCgSmallSlot(key[0],key[1],small.shift){CgStudy[2]++};small.deleteSlot(i);return true,nil').replace('    return t.Erase(node)','    CgStudy[1]++;return t.Erase(node)')
                src+='\\nvar CgStudy [6]int64\\n'
            if p.name=='smt_cg_small_table.go':
                src=src.replace('node.cgSlot=uint32(i)','node.cgSlot=uint32(i);CgStudy[3]++').replace('i = j','CgStudy[4]++;i = j').replace('t.set(e.k0, e.k1, e.node)','CgStudy[5]++;t.set(e.k0, e.k1, e.node)')
            put(p,src)
"""+s[b:]
a=s.index("    put(front/'phase_observer");b=s.index('    modes=',a)
s=s[:a]+"    put(front/'phase_observer_trial.go', timer)\n"+s[b:]
timer='''package goivy
import ("fmt";"os";"github.com/glycerine/g3/pkg/smtcore")
var capturePush bool
var bid int
func newStageBatch()int{bid++;return bid}
func startStage(b,g int)func(string){if !capturePush{return func(string){}};prior:=smtcore.CgStudy;return func(phase string){x:=smtcore.CgStudy;fmt.Fprintln(os.Stderr,"STAGE-COUNT",b,g,phase,x[0]-prior[0],x[1]-prior[1],x[2]-prior[2],x[3]-prior[3],x[4]-prior[4],x[5]-prior[5])}}
'''
s=s.replace('range(4)','range(2)').replace("a[6]==a[7] and ","").replace('cost[k]=int(a[4])','cost[k]=list(map(int,a[4:]))').replace('mode,*k,v]','mode,*k,*v]').replace('goal instructions','goal hit fallback home writes shifts rehash').replace("'notification.csv'","'counts.csv'")
exec(compile(s,'counts','exec'))
