"""Reuse the empty slot found while inserting a small ordered signature."""
from experiment import variants as erase_variants
from pathlib import Path
import tarfile
def variants(pkg,mode):
    for p,s in erase_variants(pkg,'lookup' if mode=='both' else 'base'):
        if p.name=='smt_cg_table.go' and mode!='base':
            a=s.index('candidate, commuted, err := bucket.find(node)',s.index('func (t *SMTCongruenceTable) Insert('))
            s=s[:a]+'''if len(node.arguments)<=2 && (!node.commutative || bucket.flatAssociative) {
                small:=&bucket.small
                if 2*(small.count+1)<=len(small.entries){
                    key:=smtCongruenceSmallKey(node);mask:=len(small.entries)-1
                    for i:=smtCgSmallSlot(key[0],key[1],small.shift);;i=(i+1)&mask{
                        e:=&small.entries[i]
                        if e.node==nil {
                            *e=smtCgSmallEntry{key[0],key[1],node};small.count++
                            return SMTCongruenceInsertResult{Node:node},nil
                        }
                        if e.k0==key[0] && e.k1==key[1]{
                            ok,commuted,err:=SMTEnodesCongruent(e.node,node)
                            if err!=nil{return SMTCongruenceInsertResult{},err}
                            if ok{return SMTCongruenceInsertResult{Node:e.node,Commuted:commuted},nil}
                            e.node=node;return SMTCongruenceInsertResult{Node:node},nil
                        }
                    }
                }
            }
            '''+s[a:]
        yield p,s
if __name__=='__main__':
    with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
    a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
    s=s[:a]+"""    modes=['base','insert','both']
    for mode in modes:
        for p,source in variants(pkg,mode):put(p,source)
"""+s[b:]
    exec(compile(s.replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'notification.csv'","'insert.csv'"),'insert','exec'))
