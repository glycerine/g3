from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/panel.py').read().decode()
a=s.index("    if name=='trial':");b=s.index("    j=d/",a)
s=s[:a]+"""    if name=='base':
        for fname in ('smt_cg_table.go','smt_enode_core.go','smt_cg_small_table.go','smt_equality_propagation.go'):
            path=d/fname;path.write_bytes(sp.check_output(['git','show','78f29d7f7:pkg/smtcore/'+fname]));mp[str(pkg/'smtcore'/fname)]=str(path)
"""+s[b:]
s=s.replace('((1,3),(4,8),(6,227))','((4,6),(8,3))').replace('range(5):','range(9):')
exec(compile(s,'combined','exec'))
