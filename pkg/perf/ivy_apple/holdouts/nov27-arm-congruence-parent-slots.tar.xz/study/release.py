import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/release.py').read().decode()
s=s.replace("('smt_internalizer.go','smt_relevancy_asserted_or.go','smt_relevancy.go')","('smt_cg_table.go','smt_enode_core.go','smt_cg_small_table.go','smt_equality_propagation.go')").replace('bf4a3f032:','78f29d7f7:')
exec(compile(s,'release','exec'))
