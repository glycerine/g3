"""Compare rebuilding a parent list on undo with recording actual detachments."""
from pathlib import Path
import tarfile
def variants(pkg,mode):
    for name in ('smt_internalizer_state.go','smt_equality_propagation.go'):
        p=pkg/'smtcore'/name;s=p.read_text()
        if mode!='base' and name=='smt_internalizer_state.go':
            s=s.replace('type smtEqualityUndo struct {','type smtEqualityUndo struct {\n detachStart int')
            s=s.replace('equalityTrail         []smtEqualityUndo','detachedParents []*SMTEnode\n equalityTrail []smtEqualityUndo')
        if mode!='base' and name=='smt_equality_propagation.go':
            s=s.replace('s.equalityTrail[trailIndex].merged = true','s.equalityTrail[trailIndex].detachStart=len(s.detachedParents);s.equalityTrail[trailIndex].merged = true')
            needle='if _, err := s.congruence.Erase(parent); err != nil {\n\t\t\t\t\treturn err\n\t\t\t\t}'
            assert s.count(needle)==1
            s=s.replace(needle,needle+';s.detachedParents=append(s.detachedParents,parent)')
            a=s.index('for _, parent := range r1.sourceParents {');b=s.index('entry.stage = 3',a)
            insert='if _,err:=s.congruence.Insert(parent);err!=nil{return err}'
            if mode=='store':
                insert='''if b:=s.congruence.bucketFor(parent); b!=nil && len(parent.arguments)<=2 {
                b.store(parent)
            }else if _,err:=s.congruence.Insert(parent);err!=nil{return err}'''
            s=s[:a]+'''for _,parent:=range s.detachedParents[entry.detachStart:]{
            '''+insert+'''
            parent.congruence=parent
        }
        clear(s.detachedParents[entry.detachStart:]);s.detachedParents=s.detachedParents[:entry.detachStart]
        '''+s[b:]
        yield p,s
if __name__=='__main__':
    with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
    a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
    s=s[:a]+"""    modes=['base','journal','store']
    for mode in modes:
        for p,src in variants(pkg,mode):put(p,src)
"""+s[b:]
    exec(compile(s.replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'notification.csv'","'journal.csv'"),'journal','exec'))
