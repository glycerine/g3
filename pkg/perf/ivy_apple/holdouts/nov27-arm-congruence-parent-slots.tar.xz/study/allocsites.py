"""Census Go allocations across the complete ARM and Ticket runs, including startup."""
from pathlib import Path
import tarfile
d=Path(__file__).resolve().parent
with tarfile.open('perf/ivy_apple/holdouts/nov27-quantified-lemma-installation.tar.xz') as t:s=t.extractfile('study/native-panel.py').read().decode()
a=s.index("    j=d/'overlay.json'")
s=s[:a]+'''    p=front/'cmd/goivy_check/main.go';body=p.read_text().replace('import (','import (\\n"runtime"\\n"runtime/pprof"')
    body=body.replace('os.Exit(goivy.MainWithConfig(args, cfg))',end)
    dst=d/(name+p.name);dst.write_text(body);mp[str(p)]=str(dst)
'''+s[a:]
end='''code:=goivy.MainWithConfig(args,cfg);runtime.GC();runtime.GC();runtime.GC()
    f,err:=os.Create(os.Getenv("ALLOC_PROFILE"));if err!=nil{panic(err)};if err=pprof.Lookup("allocs").WriteTo(f,0);err!=nil{panic(err)};if err=f.Close();err!=nil{panic(err)};os.Exit(code)'''
s=s.replace("GOMAXPROCS='1',GOGC='100'","GODEBUG='memprofilerate=1',ALLOC_PROFILE=str(out/(str(case)+'-'+mode+'.pb.gz')),GOMAXPROCS='1',GOGC='100'")
s=s[:s.index(' def measure(index,case):')]+''' for case in (4,8):
    for mode in ('native','trial'):run(case,mode,cpus[0],False)
'''
exec(compile(s,'sites','exec'))
