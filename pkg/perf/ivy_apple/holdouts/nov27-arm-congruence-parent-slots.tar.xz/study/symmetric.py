"""Place both operand orders in one probe cluster, retaining the stored order."""
from pathlib import Path
import tarfile
def variants(pkg,mode):
    for name in ['smt_cg_small_table.go','smt_cg_table.go','smt_equality_propagation.go']:
        p=pkg/'smtcore'/name;s=p.read_text()
        if mode!='base' and name=='smt_cg_small_table.go':
            s=s.replace('count   int','symmetric bool\n count int')
            for k in ['k0, k1','e.k0, e.k1']:
                s=s.replace('smtCgSmallSlot('+k+', t.shift)', 't.home('+k+')')
            s+='''
func (t *smtCgSmallTable) home(a,b *SMTEnode) int{
    if t.symmetric && b!=nil && a.owner.Slot()>b.owner.Slot(){a,b=b,a}
    return smtCgSmallSlot(a,b,t.shift)
}
'''
        if mode!='base' and name=='smt_cg_table.go':
            s=s.replace('flatAssociative: flags.FlatAssociative,','flatAssociative: flags.FlatAssociative,small:smtCgSmallTable{symmetric:flags.Commutative && !flags.FlatAssociative},')
            if mode!='hash':
                a=s.index('candidate, commuted, err := bucket.find(node)',s.index('func (t *SMTCongruenceTable) Insert('))
                s=s[:a]+'''if bucket.small.symmetric && node.commutative && len(node.arguments)==2{
                    if result,ok:=bucket.small.tryInsertPair(node);ok{return result,nil}
                }
                '''+s[a:]
                s+='''
// If either orientation is occupied by a different node, use ordinary lookup
// to preserve exact-key precedence and the stale-signature checks.
func (t *smtCgSmallTable) tryInsertPair(node *SMTEnode)(SMTCongruenceInsertResult,bool){
    if 2*(t.count+1)>len(t.entries){return SMTCongruenceInsertResult{},false}
    a,b:=node.arguments[0].root,node.arguments[1].root;mask:=len(t.entries)-1
    for i:=t.home(a,b);;i=(i+1)&mask{
        e:=&t.entries[i]
        if e.node==nil{*e=smtCgSmallEntry{a,b,node};t.count++;node.congruenceSlot=uint32(i);return SMTCongruenceInsertResult{Node:node},true}
        if e.k0==a && e.k1==b || e.k0==b && e.k1==a{return SMTCongruenceInsertResult{},false}
    }
}
'''
        yield p,s
with tarfile.open('perf/ivy_apple/holdouts/nov27-arm-ticket-check-costs.tar.xz') as t:s=t.extractfile('study/notify-trials.py').read().decode()
a=s.index('    modes=');b=s.index("        j=d/'overlay.json'",a)
s=s[:a]+"""    modes=['base','hash','pair']
    for mode in modes:
        for p,src in variants(pkg,mode):put(p,src)
"""+s[b:]
exec(compile(s.replace('modes[i:]+modes[:i]','modes[i%3:]+modes[:i%3]').replace("'notification.csv'","'symmetric.csv'"),'symmetric','exec'))
