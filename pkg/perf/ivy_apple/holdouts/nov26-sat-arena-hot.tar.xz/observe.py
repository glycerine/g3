"""Verify the untimed SAT watch census against the stock Go and C++ solvers."""
from pathlib import Path
import csv,json,os,subprocess,sys

root=Path.cwd()
sys.path.insert(0,str(root/'perf/ivy_raft'))
from watch_propagation import check_output

out=Path(__file__).resolve().parent
fixtures=Path(sys.argv[1])
engines=[e.split('=',1) for e in sys.argv[2:]]
keys=('conflicts','decisions','propagations','ternary-propagations','binary-propagations')
for name,verdict in (('random-208-3','unsat'),('random-208-4','sat'),('pigeon8-s0','unsat')):
    fixture=fixtures/(name+'.cnf')
    rows=[row.split() for row in fixture.read_text().splitlines() if row.strip() and not row.lstrip().startswith('c')]
    variables,count=map(int,rows[0][2:]); clauses=[]; clause=[]
    for row in rows[1:]:
        for lit in map(int,row):
            if lit: clause.append(lit)
            else: clauses.append(clause); clause=[]
    if clause or len(clauses)!=count: raise ValueError(fixture)
    expected=None
    for label,exe in engines:
        run=subprocess.run(['taskset','-c','12',exe,'-v:2','-st','-dimacs',fixture],capture_output=True,text=True,env=dict(os.environ,GOMAXPROCS='1'),timeout=120)
        if run.returncode not in (0,10 if verdict=='sat' else 20): raise ValueError(run.returncode)
        stats=check_output(run.stdout,verdict,variables,clauses)
        selected=tuple(stats.get(k,0) for k in keys)
        if expected is None: expected=selected
        if expected!=selected: raise ValueError((name,label,expected,selected))
        prefix=out/(name+'-'+label)
        prefix.with_suffix('.stdout').write_text(run.stdout)
        prefix.with_suffix('.stderr').write_text(run.stderr)
        result=[line.split(' ',1)[1] for line in run.stderr.splitlines() if line.startswith('CLAUSE-HOT ')]
        if label=='census':
            assert len(result)==1
            values=json.loads(result[0]); values['fixture']=name; values['counters']=dict(zip(keys,selected))
            print(json.dumps(values),flush=True)
