"""Profile post-erasure SAT clause accesses on matched replays."""
from pathlib import Path
from collections import Counter
import argparse,csv,os,re,subprocess,sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--perf',default='perf')
p.add_argument('--cpu',required=True)
p.add_argument('--fixture',required=True,type=Path,action='append')
p.add_argument('--out',required=True,type=Path)
p.add_argument('--rounds',default=3,type=int)
p.add_argument('go')
p.add_argument('z3')
a=p.parse_args()
a.out.mkdir()
w=csv.writer(sys.stdout)
w.writerow(('case','engine','round','propagation','leaf','samples'))
for fixture in a.fixture:
    ref=None
    for r in range(a.rounds):
        for label in (('g3','z3') if r%2==0 else ('z3','g3')):
            exe,stack,propagation=(a.go,'fp,40','(*satSolverPropagationState).propagateCore') if label=='g3' else (a.z3,'dwarf,8192','sat::solver::propagate_core(')
            data=a.out/(f'{fixture.stem}-{label}-{r+1}.data')
            with data.with_suffix('.stdout').open('wb') as stdout,data.with_suffix('.record').open('wb') as stderr:
                cmd=['taskset','-c',a.cpu,a.perf,'record','-B','-N','-e','instructions:u','-c','2000003','--call-graph',stack,'-o',data,'--',exe,'-v:2','-st','-dimacs',fixture]
                proc=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=dict(os.environ,GOMAXPROCS='1'),timeout=90)
            if proc.returncode not in (0,10,20): raise ValueError((data,proc.returncode))
            output=data.with_suffix('.stdout').read_text()
            stats=dict(re.findall(r':([\w-]+)\s+(\d+)\b',output))
            observed=tuple(stats.get(k,'0') for k in ('decisions','conflicts','propagations','ternary-propagations','binary-propagations'))
            if ref is None: ref=observed
            if observed!=ref or all(value=='0' for value in observed): raise ValueError((data,ref,observed))
            with subprocess.Popen([a.perf,'report','-D','-i',data],stdout=subprocess.PIPE,text=True) as raw:
                errors=sum(re.search(r': PERF_RECORD_(THROTTLE|LOST):',row)!=None for row in raw.stdout)
            if errors or raw.returncode: raise ValueError((data,errors,raw.returncode))
            stacks=subprocess.check_output([a.perf,'script','-i',data],text=True)
            totals=Counter()
            for event in stacks.split('\n\n'):
                lines=event.splitlines()
                if len(lines)<2:continue
                leaf=lines[1].lstrip().split(maxsplit=1)[1].rsplit(' (',1)[0].split('+0x',1)[0]
                totals[propagation in event,leaf.removeprefix('github.com/glycerine/g3/pkg/')]+=1
            for (inside,leaf),count in totals.most_common():w.writerow((fixture.stem,label,r+1,int(inside),leaf,count))
            sys.stdout.flush()
