"""Probe one, two, or three replacement literals before the dynamic tail scan."""
from pathlib import Path
import argparse,json,subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('variants',nargs='+',choices=('first','pair','triple','pairs','quads'))
a=p.parse_args()
root=Path.cwd()
base=Path(__file__).resolve().parent
file=root/'sat/sat_clause_storage.go'
old='''	for len(rest) >= 4 {
		replacement := Literal(binary.LittleEndian.Uint32(rest))'''
for name in a.variants:
    n={'first':1,'pair':2,'triple':3,'pairs':2,'quads':4}[name]
    candidate=f'''    if len(rest)>={4*n} {{
        head:=rest[:{4*n}]
'''
    if name in ('pairs','quads'):
        candidate=candidate.replace('if len(rest)', 'for len(rest)')
    for i in range(n):
        candidate+=f'''        candidate{i}:=Literal(binary.LittleEndian.Uint32(head[{4*i}:]))
        if assignment[candidate{i}.index()] != lbool.False {{
            binary.LittleEndian.PutUint32(v[satClauseLiteralsOffset+4:],uint32(candidate{i}))
            binary.LittleEndian.PutUint32(head[{4*i}:],uint32(falsified))
            return candidate{i},true
        }}
'''
    candidate+=f'        rest=rest[{4*n}:]\n    }}\n'
    content=file.read_text()
    assert content.count(old)==1
    out=base/name
    out.mkdir(exist_ok=True)
    generated=out/file.name
    generated.write_bytes(subprocess.check_output(['gofmt'],input=content.replace(old,candidate+old).encode()))
    overlay=out/'g3.json'
    overlay.write_text(json.dumps({'Replace':{str(file):str(generated)}}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
