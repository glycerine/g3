package main

import (
	"os"

	"github.com/google/pprof/profile"
)

func main() {
	var profiles []*profile.Profile
	for _, path := range os.Args[1:] {
		file, err := os.Open(path)
		if err != nil {
			panic(err)
		}
		p, err := profile.Parse(file)
		file.Close()
		if err != nil {
			panic(err)
		}
		profiles = append(profiles, p)
	}
	merged, err := profile.Merge(profiles)
	if err != nil {
		panic(err)
	}
	if err := merged.Write(os.Stdout); err != nil {
		panic(err)
	}
}
