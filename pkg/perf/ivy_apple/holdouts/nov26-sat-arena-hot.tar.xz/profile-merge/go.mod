module local.g3/profilemerge

go 1.27.3

require github.com/google/pprof v0.0.0-20210720184732-4bb14d4b1be1

replace github.com/google/pprof => /home/jaten/go/pkg/mod/github.com/google/pprof@v0.0.0-20210720184732-4bb14d4b1be1
