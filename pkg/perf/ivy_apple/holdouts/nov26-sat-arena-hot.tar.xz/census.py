"""Count the exact long-watch branch, size and replacement distributions."""
from pathlib import Path
import json
import subprocess

root=Path.cwd()
out=Path(__file__).resolve().parent/'census'
out.mkdir(exist_ok=True)
changes={}

def patch(name, old, new):
    src=root/name
    content=changes.get(src,src).read_text()
    assert content.count(old)==1, (name,old,content.count(old))
    target=out/src.name
    target.write_text(content.replace(old,new))
    changes[src]=target

path='sat/sat_solver_propagation.go'
patch(path,'\t\t\tcase 2:\n\t\t\t\tblocked, e :=', '\t\t\tcase 2:\n                propagationCensus.Long++\n\t\t\t\tblocked, e :=')
patch(path,'\t\t\t\t\tif tracing {\n\t\t\t\t\t\ts.traceBlockedClause', '\t\t\t\t\tpropagationCensus.Blocked++\n\t\t\t\t\tif tracing {\n\t\t\t\t\t\ts.traceBlockedClause')
patch(path,'\t\t\t\tif tracing {\n\t\t\t\t\ts.traceProcessingClause(c)', '\t\t\t\tpropagationCensus.Width[min(64,clause.size())]++\n                if off.storageKind!=0 {propagationCensus.Direct++}\n\t\t\t\tif tracing {\n\t\t\t\t\ts.traceProcessingClause(c)')
patch(path,'if clause.flag(satClauseFlagRemoved) || c1 != not {', 'if clause.flag(satClauseFlagRemoved) || c1 != not {\n                    propagationCensus.Obsolete++')
patch(path,'if assignment[c0.index()] == lbool.True {','if assignment[c0.index()] == lbool.True {\n                    propagationCensus.Companion++')
patch(path,'if moved {\n\t\t\t\t\ti := replacement.Negated()', 'if moved {\n                    propagationCensus.Moves++\n\t\t\t\t\ti := replacement.Negated()')
patch(path,'\t\t\t\t\tif dest != nil && dest.appendEncoded(satWatchWords{bits.val1, 2 + uint32(c0)<<2}, iter.backing.owner) {', '\t\t\t\t\tif dest != nil && dest.appendEncoded(satWatchWords{bits.val1, 2 + uint32(c0)<<2}, iter.backing.owner) {\n                        propagationCensus.FastDest++')
patch('sat/sat_clause_storage.go','\tfor len(rest) >= 4 {\n\t\treplacement', '\tpos := 0\n\tfor len(rest) >= 4 {\n        propagationCensus.Inspected++\n\t\treplacement')
patch('sat/sat_clause_storage.go','\t\t\tv.setLiteral(1, replacement)\n\t\t\tbinary.LittleEndian.PutUint32(rest, uint32(falsified))','\t\t\tpropagationCensus.Replacement[min(64,pos)]++\n\t\t\tv.setLiteral(1, replacement)\n\t\t\tbinary.LittleEndian.PutUint32(rest, uint32(falsified))')
patch('sat/sat_clause_storage.go','\t\trest = rest[4:]\n\t}\n\treturn 0, false','\t\tpos++\n\t\trest = rest[4:]\n\t}\n\treturn 0, false')
path=root/'sat/sat_hot_trial_census.go'
changes[path]=out/path.name
changes[path].write_text('''package sat
import("encoding/json"; "fmt"; "os")
var propagationCensus struct {
    Long, Blocked, Companion, Obsolete, Direct, Moves, FastDest, Inspected uint64
    Width,Replacement [65]uint64
}
func PrintPropagationCensus() {
    raw,_:=json.Marshal(propagationCensus)
    fmt.Fprintf(os.Stderr,"CLAUSE-HOT %s\\n",raw)
}
''')
patch('cmd/g3/main.go','\tstopProfile()\n','\tstopProfile()\n\tsat.PrintPropagationCensus()\n')
overlay=out/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(path):str(data) for path,data in changes.items()}}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/'g3','./cmd/g3'],check=True)
