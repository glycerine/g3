"""Generate the reviewable four-literal scan and build either entry point."""
from pathlib import Path
import argparse,json,subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--goivy',action='store_true')
p.add_argument('--min-groups',type=int,default=1)
a=p.parse_args()
root=Path.cwd()
base=Path(__file__).resolve().parent
rel='sat/sat_clause_storage.go'
source=(root/rel).read_text()
start=source.index('// moveWatch installs')
end=source.index('\nfunc (a *ClauseAllocator) allocate',start)
chunk=source[start:end]
anchor='\tfor len(rest) >= 4 {'
assert chunk.count(anchor)==1
candidate='''	// Read four candidates from one bounded group. Stop at the first
	// non-false literal, in clause order, before testing the remaining tail.
	for len(rest) >= 16 {
		group := rest[:16]
		first := Literal(binary.LittleEndian.Uint32(group))
		if assignment[first.index()] != lbool.False {
			return v.installWatch(falsified, first, group)
		}
		second := Literal(binary.LittleEndian.Uint32(group[4:]))
		if assignment[second.index()] != lbool.False {
			return v.installWatch(falsified, second, group[4:])
		}
		third := Literal(binary.LittleEndian.Uint32(group[8:]))
		if assignment[third.index()] != lbool.False {
			return v.installWatch(falsified, third, group[8:])
		}
		fourth := Literal(binary.LittleEndian.Uint32(group[12:]))
		if assignment[fourth.index()] != lbool.False {
			return v.installWatch(falsified, fourth, group[12:])
		}
		rest = rest[16:]
	}
'''
if a.min_groups>1:
    candidate=f'\tif len(rest) >= {16*a.min_groups} {{\n'+''.join('\t'+line for line in candidate.splitlines(keepends=True))+'\t}\n'
chunk=chunk.replace(anchor,candidate+anchor)
old='''			v.setLiteral(1, replacement)
			binary.LittleEndian.PutUint32(rest, uint32(falsified))
			return replacement, true'''
assert chunk.count(old)==1
chunk=chunk.replace(old,'\t\t\treturn v.installWatch(falsified, replacement, rest)')
chunk+='''
func (v satClauseView) installWatch(falsified, replacement Literal, previous []byte) (Literal, bool) {
    binary.LittleEndian.PutUint32(v[satClauseLiteralsOffset+4:],uint32(replacement))
    binary.LittleEndian.PutUint32(previous,uint32(falsified))
    return replacement,true
}
'''
out=base/('release' if a.min_groups==1 else f'release-{a.min_groups}')
out.mkdir(exist_ok=True)
file=out/'sat_clause_storage.go'
file.write_bytes(subprocess.check_output(['gofmt'],input=(source[:start]+chunk+source[end:]).encode()))
keys={str(root/rel):str(file)}
if a.goivy: keys[str(Path.home()/'g3/pkg'/rel)]=str(file)
name='goivy_check' if a.goivy else 'g3'
overlay=out/(name+'.json')
overlay.write_text(json.dumps({'Replace':keys}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/name,
                *(['-tags=xtrace_off','./cmd/goivy_check'] if a.goivy else ['./cmd/g3'])],
               cwd=Path.home()/'ivy/goivy' if a.goivy else root,check=True)
