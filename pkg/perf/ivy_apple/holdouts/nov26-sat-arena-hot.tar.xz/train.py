"""Collect compiler training profiles on fixtures reserved for training."""
from pathlib import Path
import argparse,os,subprocess

root=Path.cwd()
out=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--baseline',type=Path,default=root/'build/.nov26-qi-path/base')
p.add_argument('--input-dir',type=Path)
a=p.parse_args()
training=out/'training'
training.mkdir(exist_ok=True)
cases={
 'pigeon':root/'build/.nov26-propagation/pigeon8-s1.cnf',
 'random':root/'build/.nov26-clause-locality/fixtures/unsat-candidate-220-884.cnf',
 'smt':root/'build/.nov26-rewrite-steps/fixtures/toy-consensus-18.smt2',
}
if a.input_dir is not None:
    cases={label:a.input_dir/file.name for label,file in cases.items()}
binary=a.baseline.resolve()
for label,file in cases.items():
    env=dict(os.environ,GOMAXPROCS='1',G3_CPUPROFILE=str(training/(label+'.pprof')))
    args=['-v:2','-st','-dimacs',file] if label!='smt' else ['-in','-smt2']
    source=None if label!='smt' else (file.read_bytes()+b'\n(reset)\n')*30
    run=subprocess.run(['taskset','-c','16',binary,*args],input=source,capture_output=True,env=env,timeout=120)
    if run.returncode not in (0,20): raise ValueError((label,run.returncode))
    (training/(label+'.stdout')).write_bytes(run.stdout)
    (training/(label+'.stderr')).write_bytes(run.stderr)
    if label=='smt' and (run.stdout.count(b'unsat\n')!=30 or b'(error' in run.stdout):raise ValueError(label)
    if label!='smt' and not run.stdout.startswith(b'unsat\n'):raise ValueError(label)
module=out/'profile-merge'
external=Path.home()/'go/pkg/mod/github.com/google/pprof@v0.0.0-20210720184732-4bb14d4b1be1'
replacement='replace github.com/google/pprof => '+str(external)
mod=module/'go.mod'
source=mod.read_text()
if replacement not in source: mod.write_text(source+'\n'+replacement+'\n')
with (training/'combined.pprof').open('wb') as merged:
    subprocess.run(['go','run','-mod=mod','.',*(str(training/(label+'.pprof')) for label in cases)],env=dict(os.environ,GOPROXY='off'),cwd=module,stdout=merged,check=True)
