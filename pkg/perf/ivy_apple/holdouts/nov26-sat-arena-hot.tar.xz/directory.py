"""Try compact hot page records and generation-based bounds in the existing SAT arena."""
from pathlib import Path
import argparse
import json
import subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('variants',nargs='+',choices=('bounds','split','split-bounds'))
p.add_argument('--goivy',action='store_true')
a=p.parse_args()
root=Path.cwd()
base=Path(__file__).resolve().parent
rel='arena/clause_pages.go'
for name in a.variants:
    out=base/name
    out.mkdir(exist_ok=True)
    source=(root/rel).read_text()
    if name.startswith('split'):
        source = source.replace('''type clausePage struct {
	data            []byte
	stride, count   uint32
	taken, live     uint32
	firstFree, next uint32 // one-based row within the page and next nonfull page
	epoch, maximum  uint32
	_               uint64 // Keep the directory stride at 64 bytes on amd64.
}''','''type clausePage struct {
    count, live uint32
    firstFree, next uint32
    epoch, maximum uint32
}

type clausePagePayload struct {
    data []byte
    stride,taken uint32
}''')
        assert 'type clausePagePayload struct' in source
        source=source.replace('pages     []clausePage','pages     []clausePage\n    payloads []clausePagePayload')
        source=source.replace('uint64(reflect.TypeOf(clausePage{}).Size())','uint64(reflect.TypeOf(clausePage{}).Size()+reflect.TypeOf(clausePagePayload{}).Size())')
        source=source.replace('''		pages := make([]clausePage, len(a.pages), capacity)
		copy(pages, a.pages)
		a.pages = pages''','''        pages := make([]clausePage,len(a.pages),capacity)
        payloads := make([]clausePagePayload,len(a.payloads),capacity)
        copy(pages,a.pages)
        copy(payloads,a.payloads)
        a.pages,a.payloads = pages,payloads''')
        source=source.replace('''	a.pages = append(a.pages, clausePage{
		data: make([]byte, int(bytes)), stride: stride, count: count, epoch: 1, maximum: 1,
	})''','''    a.pages=append(a.pages,clausePage{count:count,epoch:1,maximum:1})
    a.payloads=append(a.payloads,clausePagePayload{data:make([]byte,int(bytes)), stride:stride})''')
        source=source.replace('page := &a.pages[pageID-1]\n','page := &a.pages[pageID-1]\n    payload:=&a.payloads[pageID-1]\n')
        for field in ('data','taken'):
            source=source.replace('page.'+field,'payload.'+field)
        source=source.replace('uint64(len(a.pages)) || r.Generation == 0','uint64(len(a.payloads)) || r.Generation == 0')
        alloc, other=source.split('func (a *ClauseBytes) Borrow(')
        borrow, after=other.split('func (a *ClauseBytes) IsLive(')
        borrow=borrow.replace('p := &a.pages[page]','p := &a.payloads[page]')
        after=after.replace('p := &a.pages[page]\n','p := &a.pages[page]\n    payload:=&a.payloads[page]\n')
        dealloc, later=after.split('func (a *ClauseBytes) Stats(')
        for field in ('data','stride','taken'):
            dealloc=dealloc.replace('p.'+field,'payload.'+field)
        later=later.replace('if p.data != nil {','if a.payloads[i].data != nil {').replace('a.pages = nil','a.pages = nil\n        a.payloads=nil')
        source=alloc+'func (a *ClauseBytes) Borrow('+borrow+'func (a *ClauseBytes) IsLive('+dealloc+'func (a *ClauseBytes) Stats('+later
    if 'bounds' in name:
        old='''	if index >= p.taken {
		return nil, ErrInvalidSlot
	}
	start := index * p.stride
	end := start + p.stride
	row := p.data[start:end:end]
	if binary.LittleEndian.Uint32(row) != uint32(r.Generation) {
		return nil, ErrInvalidSlot
	}
	return row[clausePageHeaderBytes:], nil'''
        new='''    stride,data:=p.stride,p.data
    start:=index*stride
    end:=start+stride
    // Never-allocated and released slots have generation zero. Reclaimed
    // pages have no backing and fail the computed upper bound.
    if end>uint32(len(data)) || binary.LittleEndian.Uint32(data[start:])!=uint32(r.Generation) {
        return nil,ErrInvalidSlot
    }
    return data[start+clausePageHeaderBytes:end:end],nil'''
        assert source.count(old)==1
        source=source.replace(old,new)
    changes={}
    target=out/'clause_pages.go'
    changes[str(root/rel)] = str(target)
    if a.goivy: changes[str(Path.home()/'g3/pkg'/rel)]=str(target)
    target.write_bytes(subprocess.check_output(['gofmt'],input=source.encode()))
    if name.startswith('split') and not a.goivy:
        test='arena/clause_pages_test.go'
        dest=out/'clause_pages_test.go'
        dest.write_text((root/test).read_text().replace('binary.LittleEndian.PutUint32(page.data,','binary.LittleEndian.PutUint32(a.payloads[0].data,'))
        changes[str(root/test)] = str(dest)
    binary='goivy_check' if a.goivy else 'g3'
    overlay=out/(binary+'.json')
    overlay.write_text(json.dumps({'Replace':changes}))
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,'-o',out/binary,
                   *(['-tags=xtrace_off','./cmd/goivy_check'] if a.goivy else ['./cmd/g3'])],
                   cwd=Path.home()/'ivy/goivy' if a.goivy else root,check=True)
