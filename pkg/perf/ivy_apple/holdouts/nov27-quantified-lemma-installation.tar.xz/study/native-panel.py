"""Time the unmodified release against parent and linked Z3, then verify release outputs."""
import csv,json,os,subprocess as sp,tempfile,tarfile,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
out=Path(os.environ['RESULTS']);out.mkdir(parents=True,exist_ok=True)
pkg=Path.cwd();front=Path(os.environ['GOIVY_FRONTEND']).resolve();af=Path(os.environ['APPLE_FRONTEND']).resolve()
ref=Path(os.environ['NNF_REFERENCE']);ex=Path(os.environ['IVY_EXAMPLES'])
names=(ref/'compat.txt').read_text().splitlines();codes={r['case']:int(r['exit']) for r in csv.DictReader((ref/'ranking.csv').open())}
with tempfile.TemporaryDirectory() as temp,tarfile.open(pkg/'perf/ivy_apple/holdouts/nov27-unary-demand-and-fresh-symbols.tar.xz') as t:
 d=Path(temp);(d/'abc').symlink_to(Path(os.environ['ABC']).resolve(strict=True))
 for name in ('native','trial'):
    apple=name=='apple';frontend=af if apple else front;native=name=='native';mp={}
    for f,src in [('z3bridge_solver_model.go','apple.go.txt' if apple else 'regular.go.txt'),('z3bridge_guarded_equalities.go','apple-guards.go.txt' if apple else 'regular-guards.go.txt')]:
        path=d/(name+f);path.write_bytes(t.extractfile('study/release-sources/'+src).read());mp[str(frontend/f)]=str(path)
    if name=='base':
        for fname in ('smt_internalizer.go','smt_relevancy_asserted_or.go','smt_relevancy.go'):
            src=d/('orig-'+fname);src.write_bytes(sp.check_output(['git','show','bf4a3f032:pkg/smtcore/'+fname]))
            mp[str(pkg/'smtcore'/fname)]=str(src)
    j=d/'overlay.json';j.write_text(json.dumps({'Replace':mp}))
    sp.run(['go','build','-tags','xtrace_off,classic_z3' if native else 'xtrace_off','-pgo='+('off' if native else str(pkg/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof')),'-buildvcs=false','-mod=readonly','-overlay',j,*([] if apple else ['-modfile',Path(os.environ['GOIVY_MODFILE']).resolve()]),'-o',d/name,'./cmd/goivy_check'],cwd=frontend,env=dict(os.environ,GOCACHE=os.environ.get('TRIAL_CACHE',str(d/'cache'))),check=True)
 cpus=list(map(int,os.environ['PANEL_CPUS'].split(',')))
 def run(case,mode,cpu,timed):
    apple=mode=='apple';spec='doc/examples/apple/ord_live.ivy' if apple else names[case-1]
    refdir=Path(os.environ['APPLE_REFERENCE'])/case/'1/native' if apple else ref/'compat'/str(case)/'1/native'
    with tempfile.TemporaryDirectory(dir=d) as temp_run:
        wd=Path(temp_run);cmd=['taskset','-c',str(cpu)]
        if timed:cmd.extend([os.environ.get('PERF','perf'),'stat','-x,','-e','instructions:u,cycles:u','-o',wd/'stat','--'])
        start=time.monotonic_ns()
        r=sp.run([*cmd,d/mode,*(['isolate='+case] if apple else []),ex/spec],cwd=wd,capture_output=True,timeout=240,env=dict(os.environ,GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')))
        elapsed=(time.monotonic_ns()-start)/1e6
        assert (r.returncode,r.stdout,r.stderr)==(0 if apple else codes[spec],(refdir/'stdout').read_bytes(),(refdir/'stderr').read_bytes()),(case,mode,r.returncode,r.stderr[-400:])
        if timed:
            v={row[2]:int(row[0]) for row in csv.reader((wd/'stat').open()) if len(row)>4 and row[2] in ('instructions:u','cycles:u') and float(row[4])==100}
            return [v['instructions:u'],v['cycles:u'],round(elapsed,3)]
        return [case,'match']
 def measure(index,case):
    with (out/f'time-{case}.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['case','round','engine','instructions','cycles','wall_ms'])
        for i in range(5):
            modes=['native','trial'];modes=modes[::1 if i%2==0 else -1]
            for mode in modes:w.writerow([case,i,mode,*run(case,mode,cpus[index%len(cpus)],True)]);f.flush()
 def group(index,cases):
    for c in cases:measure(index,c)
 with ThreadPoolExecutor(3) as pool:
    jobs=[pool.submit(group,i,cases) for i,cases in enumerate(((1,3),(4,8),(6,227)))]
    for j in jobs:j.result()

