"""Print medians of complete counter runs and paired whole-process changes."""
import sys,csv,statistics as stats
from collections import Counter, defaultdict
from pathlib import Path
root=Path(sys.argv[1])
def rows(group):
    with (root/group/'phases.csv').open() as f:return list(csv.DictReader(f))
def mean_count(group,engine,op,predicate):
    by={}
    for row in rows(group):
        key=int(row['flag'])
        if row['engine']==engine and row['op']==op and predicate(key):
            sums=by.setdefault(row['round'],[0,0])
            sums[0]+=int(row['calls']);sums[1]+=int(row['instructions'])
    return tuple(stats.median(v[i] for v in by.values()) for i in (0,1))
for has_missing in (False,True):
    for e in ['release','native']:
        print('installation',has_missing,e,mean_count('results',e,'A',lambda x:bool(x%1000)==has_missing))
for missing in (False,True):
    for op in 'LKWM':
        for e in ('release','native'):
            print('parts',missing,op,e,mean_count('stored',e,op,lambda x:bool(x//10000%100)==missing))
        weighted=[]
        for i in ('0','1'):
            by=defaultdict(dict)
            for r in rows('stored'):
                x=int(r['flag'])
                if r['round']==i and r['op']==op and bool(x//10000%100)==missing:
                    by[x][r['engine']]=(int(r['calls']),int(r['instructions']))
            shared=[v for v in by.values() if len(v)==2]
            cnt=sum(v['release'][0] for v in shared)
            diff=sum(gi-gc*ni/nc for v in shared for gc,gi in [v['release']] for nc,ni in [v['native']])
            weighted.append(diff)
        print('matched',missing,op,cnt,round(stats.median(weighted)))
for e in ('release','native'):
    for miss in (False,True):
        r=[r for r in rows('stored') if r['engine']==e and r['round']=='0' and r['op']=='D']
        dist=Counter()
        for x in r:
            packed=int(x['flag']);shape,size=divmod(packed,1000)
            if bool(shape//10000%100)==miss:dist[size]+=int(x['calls'])
        print('ordinary stored width',e,miss,dict(sorted(dist.items())))
for group in ['panel','root-panel','gate-panel','confirmed']:
    for f in sorted((root/group).glob('time*.csv')):
        r=list(csv.DictReader(f.open())); by={ (v['round'],v['engine']):v for v in r}
        if len(r)!=10:continue
        print(group,f.stem,*(round(stats.median(100*(float(by[str(i),'trial'][key])/float(by[str(i),'base'][key])-1) for i in range(5)),2) for key in ['instructions','wall_ms']))
if (root/'confirmed-cost/phases.csv').exists():
    for e in ('base','release'):
        print('production installation',e,mean_count('confirmed-cost',e,'A',lambda x:True))

for f in sorted((root/'native-panel').glob('time*.csv')):
    with f.open() as inp:r=list(csv.DictReader(inp))
    if len(r)==10:
        print('native comparison',f.stem,*(round(stats.median(float(z['wall_ms']) for z in r if z['engine']==e),2) for e in ('trial','native')))
if (root/'kinds/phases.csv').exists():
    for code in sorted({int(r['flag']) for r in rows('kinds') if r['op']=='F'}):
        for e in ('release','native'):
            print('fresh kind',code,e,mean_count('kinds',e,'F',lambda k:k==code))

if (root/'live-check/phases.csv').exists():
    raw=rows('live-check')
    for e in ('base','release','native'):
        r=[v for v in raw if v['engine']==e]
        if r:print('live check',e,len(r),round(stats.median(int(v['instructions']) for v in r)),round(stats.median(int(v['ns']) for v in r)/1e6,2))
