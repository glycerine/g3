"""Break down the OR-assertion path inside the live quantified lemma installation."""
from pathlib import Path
import tarfile
def member(archive,name):
    with tarfile.open(Path('perf/ivy_apple/holdouts')/archive) as t:return t.extractfile(name).read().decode()
def edit(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
a='nov27-first-push-queue-comparison.tar.xz'
qgo=member(a,'check-g3-smt_qi_instance.go')+'\nvar installMeter = -1\n'
qgo=edit(qgo,'err=internalizer.internalizeInstance(result, locals.arguments);','installMeter=fd;err=internalizer.internalizeInstance(result, locals.arguments);installMeter=-1;')
qcpp=member(a,'qi_queue.cpp')
qcpp='thread_local int install_meter=-1;\n'+edit(qcpp,'m_context.internalize_instance(lemma, pr1, gen);','install_meter=fd;m_context.internalize_instance(lemma, pr1, gen);install_meter=-1;')
g=Path('smtcore/smt_internalizer.go').read_text()
pos=g.index('func (s *SMTInternalizerState) assertExpression(')
pre,g=g[:pos],g[pos:]
g=edit(g,'literals := make([]SMTLiteral, len(arguments))','fd:=installMeter; a:=studyRd(fd);literals := make([]SMTLiteral, len(arguments))')
g=edit(g,'if err = s.addRootClause(literals, proof);','studyLog(fd,a,"L",false);a=studyRd(fd);if err = s.addRootClause(literals, proof);')
g=edit(g,'if s.relevancy != nil {\n\t\t\t\tif err = s.relevancy.addAssertedOrWatches','studyLog(fd,a,"K",false);a=studyRd(fd);if s.relevancy != nil {\n\t\t\t\tif err = s.relevancy.addAssertedOrWatches')
g=edit(g,'\n\t\tcase ast.ASTOpIff:', '\n\t\t\tstudyLog(fd,a,"W",false);a=studyRd(fd);err=s.markRelevant(expression);studyLog(fd,a,"M",false);return err\n\t\tcase ast.ASTOpIff:')
g=pre+g
c=Path('../src/smt/smt_internalizer.cpp').read_text()
c='#include <unistd.h>\n#include <cstdio>\n#include <cstdlib>\nextern thread_local int install_meter;\nstatic long long read_install(int fd){if(fd<0)return 0;unsigned long long x[3];if(read(fd,x,sizeof(x))!=sizeof(x)||x[1]!=x[2])std::abort();return x[0];}\nstatic void install_log(int fd,long long a,const char* op){if(fd>=0)fprintf(stderr,"%s 0 %lld\\n",op,read_install(fd)-a);}\n'+c
c=edit(c,'case OP_OR: {\n                literal_buffer lits;', 'case OP_OR: {\n                int fd=install_meter;auto a=read_install(fd);literal_buffer lits;')
c=edit(c,'mk_root_clause(lits.size(), lits.c_ptr(), pr);\n                add_or_rel_watches(to_app(n));','install_log(fd,a,"L");a=read_install(fd);mk_root_clause(lits.size(), lits.c_ptr(), pr);install_log(fd,a,"K");a=read_install(fd);\n                add_or_rel_watches(to_app(n));install_log(fd,a,"W");a=read_install(fd);mark_as_relevant(n);install_log(fd,a,"M");return;')
s=member('nov27-tlb-model-bindings.tar.xz','study/phases.py')
s=edit(s,'def first(name):return source','def first(name):\n    if name in overlays:return overlays[name]\n    return source')
s=edit(s,"('cached_var_subst','qi_queue')","('cached_var_subst','qi_queue','smt_internalizer')")
s=edit(s,"put(pkg/'smtcore/smt_qi_instance.go',","put(pkg/'smtcore/smt_internalizer.go',overlays['internalizer.go']);put(pkg/'smtcore/smt_qi_instance.go',")
s=s.replace("('base','release','native')","('release','native')").replace("['base','release','native']","['release','native']").replace("range(3)","range(2)").replace("b'R',b'A'","b'R',b'A',b'L',b'K',b'W',b'M'")
import os
assert 'METER_LIB' not in os.environ
exec(compile(s,'phases.py','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
