"""Price each newly bound OR operand by its syntactic kind and polarity."""
from pathlib import Path
d=Path(__file__).resolve().parent
src=(d/'components.py').read_text()
exec(src[:src.index("g=Path(")])
g=Path('smtcore/smt_internalizer.go').read_text()
g=edit(g,'import (','import (\n "os"')
a=g.index('case ast.ASTOpOr:',g.index('func (s *SMTInternalizerState) assertExpression'));b=g.index('if err = s.addRootClause',a)
loop=g[a:b]
loop=edit(loop,'if instanceArguments != nil {','''fd:=installMeter;code:=-1
                if fd>=0 {
                    term:=argument;negative:=0
                    _,child,e:=s.manager.IsNot(term);if e!=nil{panic(e)};if !child.IsNull(){term=child;negative=100}
                    if _,bound:=s.boolVar.lookup(term);!bound && !s.manager.IsFalse(argument) {
                        h,e:=s.manager.NodeHeader(term);if e!=nil{panic(e)}
                        code=5
                        if h.Kind==ast.ASTQuantifier {code=4} else if h.Kind==ast.ASTApp {
                            switch h.Family {
                            case ast.NullFamilyID:code=1
                            case s.manager.BasicFamilyID():switch h.DeclKind {
                            case ast.ASTOpEq:code=2
                            case ast.ASTOpOr:code=6
                            case ast.ASTOpAnd:code=7
                            case ast.ASTOpIff:code=8
                            case ast.ASTOpIte:code=9
                            case ast.ASTOpImplies:code=10
                            default:code=3
                            }
                            }
                        }
                        code+=negative
                    }
                };var start uint64;if code>=0{start=studyRd(fd)}
                if instanceArguments != nil {''')
loop=edit(loop,'literals[index] = literal','if code>=0{panic("unexpected bound operand")};literals[index] = literal')
needle='literals[index], err = s.Literal(argument)'
loop=edit(loop,needle,needle+';if code>=0 {cost:=studyRd(fd)-start;fmt.Fprintln(os.Stderr,"F",code,cost)}')
g=g[:a]+loop+g[b:]
c=Path('../src/smt/smt_internalizer.cpp').read_text()
c='#include <unistd.h>\n#include <cstdio>\n#include <cstdlib>\nextern thread_local int install_meter;\nstatic long long operand_rd(int fd){unsigned long long x[3];if(read(fd,x,sizeof(x))!=sizeof(x)||x[1]!=x[2])std::abort();return x[0];}\n'+c
c=edit(c,'internalize(arg, true);\n                    lits.push_back(get_literal(arg));','''int fd=install_meter;int code=-1;long long start=0;
 if(fd>=0 && !lit_internalized(arg)){
   expr* atom=arg;bool neg=m_manager.is_not(arg,atom);code=5;
   if(is_quantifier(atom))code=4;
   else if(is_app(atom)){auto* a=to_app(atom);auto family=a->get_family_id();
   if(family==null_family_id)code=1;else if(family==m_manager.get_basic_family_id()){switch(a->get_decl_kind()){
    case OP_EQ:code=2;break;case OP_OR:code=6;break;case OP_AND:code=7;break;
    case OP_IFF:code=8;break;case OP_ITE:code=9;break;case OP_IMPLIES:code=10;break;default:code=3;}}}
   if(neg)code+=100;start=operand_rd(fd);}
 internalize(arg, true);lits.push_back(get_literal(arg));
 if(code>=0){auto n=operand_rd(fd)-start;fprintf(stderr,"F %d %lld\\n",code,n);}''')
exec(src[src.index("s=member('nov27-tlb"):src.index('exec(compile(s,')])
s=edit(s,"b'W',b'M'","b'W',b'M',b'F'")
exec(compile(s,'phases.py','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
