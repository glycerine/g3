# Quantified disjunction installation on TLB 60/1

Run from g3/pkg on Linux with the GoIvy benchmark frontends and this repository's native build. Use bf4a3f032 for measure.py, components.py, strata.py, panel.py and root.py. Use the revision containing this archive for release.py, final-cost.py, operand-kinds.py, native-panel.py, gate-trial.py and live-check.py. These scripts use the source observers in nov27-tlb-model-bindings.tar.xz and its dependencies. Reuse the environment documented there, including GOIVY_FRONTEND, GOIVY_MODFILE, APPLE_FRONTEND, APPLE_REFERENCE, IVY_EXAMPLES, NNF_REFERENCE, ABC, PERF, CPU and PANEL_CPUS. Use absolute paths for the references and modfile. TRIAL_CACHE can point to a dedicated cache. All drivers check both output streams and the reference exit code. Each RESULTS directory should be fresh.

    RESULTS="$OUT/results" python3 "$STUDY/measure.py"
    RESULTS="$OUT/components" python3 "$STUDY/components.py"
    RESULTS="$OUT/stored" python3 "$STUDY/strata.py"
    RESULTS="$OUT/panel" python3 "$STUDY/panel.py"
    RESULTS="$OUT/root-panel" python3 "$STUDY/root.py"
    RESULTS="$OUT/confirmed" python3 "$STUDY/release.py"
    RESULTS="$OUT/confirmed-cost" python3 "$STUDY/final-cost.py"
    RESULTS="$OUT/kinds" python3 "$STUDY/operand-kinds.py"
    RESULTS="$OUT/native-panel" python3 "$STUDY/native-panel.py"
    RESULTS="$OUT/gate-panel" python3 "$STUDY/gate-trial.py"
    RESULTS="$OUT/live-check" python3 "$STUDY/live-check.py"
    python3 "$STUDY/summary.py" "$OUT"

The first three drivers build the instrumented native objects against this fork. Leave METER_LIB unset for these. For final-cost.py both engines are Go and METER_LIB may point to an existing check.a from nov27-first-push-queue-comparison. Each of the three original partitioning experiments runs Go and native twice in reverse order. An independent thread-local meter brackets the entire installation in measure.py. The finer meters in the other two drivers are read separately. Printing one event costs instructions in any enclosing interval. Use the original whole-operation meter to price the total. Classification reads precede the phase being measured.

In results/phases.csv, A records instructions to install an instance. Decode its flag with divmod(flag, 1000) to obtain disjunction width and the count of operands without Boolean bindings on entry. Minus one would represent a different root. The literal test strips exactly one NOT and recognizes the native reserved false literal. L, K, W and M in components/phases.csv measure operand processing, ordinary root clause insertion, watch installation and relevance propagation respectively. Stored/phases.csv adds the decision scope to these operations' flags. Decode with width = flag // 1000000, missing = flag // 10000 % 100, and level = flag % 10000. D records use that same flag times 1000 plus the ordinary auxiliary clause length immediately after insertion. A zero length means no new ordinary auxiliary record. The instructions column for D sums stored lengths. The other operation codes are inherited from the previous archive.

Panel.py tries using a signed literal when registering a watch. Root.py tests reusing the new watch record at the first propagation. Release.py uses ordinary uninstrumented binaries with normal GC, five alternating pairs per workload and a complete release transcript screen. Final-cost.py instruments just the quantifier queue and compares the production changes with the sources from bf4a3f032 at identical model-binding policy. The summary's normalized comparison uses only cells present in both engines and weights the native per-call cost by g3's call count within each cell.

The F operand codes in kinds/phases.csv are 1 for uninterpreted applications, 2 for equality, 6 for OR and 9 for ITE. A leading offset of 100 means a syntactic negation. The timer covers internalizing the argument in gate context and obtaining the literal. All classifications precede the timer. The complete native panel uses five alternating pairs per input. Live-check.py records six rotations with normal GC and no per-instance hooks, measuring the entire selected check on the solver thread.
