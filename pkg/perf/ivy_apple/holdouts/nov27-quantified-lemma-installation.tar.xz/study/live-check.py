"""Measure elapsed time and instructions on the complete uninstrumented solver check."""
from pathlib import Path
import tarfile
def archived(archive,name):
    with tarfile.open(Path('perf/ivy_apple/holdouts')/archive) as t:return t.extractfile(name).read().decode()
s=archived('nov27-tlb-model-bindings.tar.xz','study/phases.py')
pos=s.index(" if os.environ.get('METER_LIB')");s=s[:pos]+s[s.index(' for engine in',pos):]
s=s.replace("        if fn.startswith('z3bridge'):","""        if fn.startswith('phase_observer'):
            data=data.replace(b'runtime.LockOSThread()',b'if !capturePush{return func(string){}};runtime.LockOSThread()').replace(b'os.Setenv("QI_COUNTER_FD",fmt.Sprint(fd));',b'').replace(b'os.Unsetenv("QI_COUNTER_FD")',b'')
        if fn.startswith('z3bridge'):""")
a=s.index("    if native:put(front/");b=s.index("    j=d/",a)
s=s[:a]+"""    if engine=='base':
        for fname in ('smt_internalizer.go','smt_relevancy.go','smt_relevancy_asserted_or.go'):
            put(pkg/'smtcore'/fname,sp.check_output(['git','show','bf4a3f032:pkg/smtcore/'+fname]))
"""+s[b:]
s=s.replace("range(3)","range(6)").replace("modes[i:]+modes[:i]","modes[i%3:]+modes[:i%3]").replace("GOGC='off'","GOGC='100'").replace("['round','engine','op','flag','calls','instructions']","['round','engine','instructions','ns']").replace("active=False;end+=1","active=False;end+=1;observed=[int(a[4]),int(a[8])]").replace('wr.writerows([i,eng,*k,counts[k],cost[k]] for k in sorted(counts))','wr.writerow([i,eng,*observed])')
exec(compile(s,'phases.py','exec'))
