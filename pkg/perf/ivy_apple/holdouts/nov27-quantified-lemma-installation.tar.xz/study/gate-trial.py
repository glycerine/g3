"""Measure collecting a gate's literals from its owned argument array."""
from pathlib import Path
import tempfile
d=Path(__file__).resolve().parent
g=Path('smtcore/smt_internalizer.go').read_text()
old='''arguments, err := s.argumentLiterals(expression)
	if err != nil {
		return err
	}
	if gate := s.boolGate(variable); gate != nil {
		// Children precede their gate in scope order, so these literal indices
		// remain live for the owning Boolean variable's whole lifetime.
		gate.literals = arguments
	}'''
new='''var arguments []SMTLiteral
    var err error
    if gate := s.boolGate(variable); gate != nil {
        arguments=make([]SMTLiteral,len(gate.args))
        for i,child:=range gate.args {
            if literal,ok:=s.boundInstanceLiteral(child);ok{arguments[i]=literal;continue}
            arguments[i],err=s.Literal(child);if err!=nil{return err}
        }
        gate.literals=arguments
    } else {
        arguments,err=s.argumentLiterals(expression);if err!=nil{return err}
    }'''
assert g.count(old)==1
with tempfile.TemporaryDirectory() as tmp:
    src=Path(tmp)/'gate.go';src.write_text(g.replace(old,new))
    s=(d/'panel.py').read_text().replace("mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp[str(pkg/'smtcore/smt_internalizer.go')]=gate_source")
    exec(compile(s,'gate-panel','exec'),{'gate_source':str(src),'__file__':str(d/'panel.py')})
