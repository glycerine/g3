"""Partition the archived 60/1 installation meter by input clause shape."""
from pathlib import Path
import os,tarfile
root=Path.cwd()/'perf/ivy_apple/holdouts'
def archived(archive,file):
    with tarfile.open(root/archive) as t:return t.extractfile(file).read()
script=archived('nov27-tlb-model-bindings.tar.xz','study/phases.py').decode()
def replace(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
go=archived('nov27-first-push-queue-comparison.tar.xz','check-g3-smt_qi_instance.go').decode()
go=replace(go,'fd:=studyFD();a:=studyRd(fd);err=internalizer.internalizeInstance', '''fd:=studyFD();shape:=-1
    if fd>=0 {
        lemma,e:=result.Lemma();if e!=nil{panic(e)}
        op,basic,e:=internalizer.basicOperation(lemma);if e!=nil{panic(e)}
        if basic && op==ast.ASTOpOr {
            args,e:=internalizer.argumentHandles(lemma);if e!=nil{panic(e)}
            missing:=0
            for _,arg:=range args {
                if b.manager.IsFalse(arg){continue}
                _,child,e:=b.manager.IsNot(arg);if e!=nil{panic(e)}
                if !child.IsNull(){arg=child}
                if _,ok:=internalizer.boolVar.lookup(arg);!ok{missing++}
            }
            if missing>=1000{panic("shape overflow")};shape=len(args)*1000+missing
        }
    };a:=studyRd(fd);err=internalizer.internalizeInstance''')
go=replace(go,'studyLog(fd,a,"A",false)','if fd>=0{n:=studyRd(fd)-a;fmt.Fprintln(os.Stderr,"A",shape,n)}')
cpp=archived('nov27-first-push-queue-comparison.tar.xz','qi_queue.cpp').decode()
cpp=replace(cpp,'if(fd>=0)a=rd(fd);m_context.internalize_instance','''int shape=-1;
        if(fd>=0 && m_manager.is_or(lemma)) {
            app* n=to_app(lemma); unsigned missing=0;
            for(expr* arg:*n) if(!m_context.lit_internalized(arg)) ++missing;
            if(missing>=1000)std::abort();
            shape=1000*n->get_num_args()+missing;
        }
        if(fd>=0)a=rd(fd);m_context.internalize_instance''')
cpp=replace(cpp,'"A %d %lld\\n",0','"A %d %lld\\n",shape')
script=replace(script,"def first(name):return source",'''def first(name):
    if name=='qi_queue.cpp':return instrumented_cpp
    if name=='check-g3-smt_qi_instance.go':return instrumented_go
    return source''')
script=script.replace("('base','release','native')","('release','native')").replace("['base','release','native']","['release','native']").replace("range(3)","range(2)").replace("counts['A',0]","sum(v for (op,_),v in counts.items() if op=='A')")
assert 'METER_LIB' not in os.environ
exec(compile(script,'phases.py','exec'),{'instrumented_go':go.encode(),'instrumented_cpp':cpp.encode()})
