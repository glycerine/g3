"""Pass the freshly built OR watch to its initial relevance propagation."""
from pathlib import Path
import os,tempfile
d=Path(__file__).resolve().parent
def edit(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
g=Path('smtcore/smt_internalizer.go').read_text()
g=edit(g,'if err = s.relevancy.addAssertedOrWatches(expression, arguments, literals); err != nil {','''var gate *smtAssertedOr
                if err = s.relevancy.buildAssertedOrWatches(expression, arguments, literals,&gate); err != nil {''')
g=edit(g,'\n\t\t\t}\n\t\tcase ast.ASTOpIff:', '''
                if err = s.relevancy.MarkRelevant(expression); err!=nil{return err}
                return s.relevancy.propagateWithOr(expression,gate)
            }
        case ast.ASTOpIff:''')
w=Path('smtcore/smt_relevancy_asserted_or.go').read_text()
sig='func (p *SMTRelevancyPropagator) addAssertedOrWatches(parent ast.ASTHandle, args []ast.ASTHandle, literals []SMTLiteral) error {'
w=edit(w,sig,sig+'''
    return p.buildAssertedOrWatches(parent,args,literals,nil)
}
func (p *SMTRelevancyPropagator) buildAssertedOrWatches(parent ast.ASTHandle, args []ast.ASTHandle, literals []SMTLiteral, hint **smtAssertedOr) error {''')
w=edit(w,'gate.witness = -1','if hint!=nil{*hint=gate};gate.witness = -1')
r=Path('smtcore/smt_relevancy.go').read_text()
r=edit(r,'Propagate() (result error) {','''Propagate() error {
    return p.propagateWithOr(ast.ASTHandle{},nil)
}
func(p *SMTRelevancyPropagator) propagateWithOr(parent ast.ASTHandle,gate *smtAssertedOr)(result error){''')
r=edit(r,'err = p.propagateOr(expression)','if gate!=nil && expression==parent {err=p.propagateAssertedOr(parent,gate)}else{err = p.propagateOr(expression)}')
files={'smt_internalizer.go':g,'smt_relevancy.go':r,'smt_relevancy_asserted_or.go':w}
with tempfile.TemporaryDirectory() as tmp:
    m={}
    for f,src in files.items():
        p=Path(tmp)/f;p.write_text(src);m[str((Path.cwd()/'smtcore'/f).resolve())]=str(p)
    s=(d/'panel.py').read_text()
    s=edit(s,"mp[str(pkg/'smtcore/smt_relevancy_asserted_or.go')]=str(Path(__file__).with_name('watches.go.txt').resolve())","mp.update(trial_sources)")
    exec(compile(s,'panel.py','exec'),{'trial_sources':m,'__file__':str(d/'panel.py')})
