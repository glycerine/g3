"""Attribute each OR operation at the same input width, missing bindings and solver depth."""
from pathlib import Path
d=Path(__file__).resolve().parent
exec((d/'components.py').read_text().split('exec(compile(s,')[0])
g=edit(g,'fd:=installMeter; a:=studyRd(fd);','''fd:=installMeter; shape:=0
    if fd>=0 {
        missing:=0
        for _,arg:=range arguments {
            if s.manager.IsFalse(arg){continue}
            _,child,e:=s.manager.IsNot(arg);if e!=nil{panic(e)};if !child.IsNull(){arg=child}
            if _,ok:=s.boolVar.lookup(arg);!ok{missing++}
        }
        if s.scopeLevel>=10000 || missing>=100 {panic("shape")}
        shape=len(arguments)*1000000+missing*10000+int(s.scopeLevel)
    }
    a:=studyRd(fd);''')
g=edit(g,'a=studyRd(fd);if err = s.addRootClause','prior:=len(s.auxClauses);a=studyRd(fd);if err = s.addRootClause')
for tag in 'LKWM':
    old=f'studyLog(fd,a,"{tag}",false)'
    extra=';stored:=0;if len(s.auxClauses)>prior{stored=len(s.auxClauses[prior].directoryLiterals())};fmt.Fprintln(os.Stderr,"D",shape,stored)' if tag=='K' else ''
    g=edit(g,old,'if fd>=0{used:=studyRd(fd)-a;fmt.Fprintln(os.Stderr,"'+tag+'",shape,used)'+extra+'}')
g=edit(g,'import (','import (\n "os"')
c=edit(c,'int fd=install_meter;auto a=read_install(fd);literal_buffer lits;','''int fd=install_meter;int shape=0;
 if(fd>=0){unsigned missing=0;for(expr* arg:*to_app(n))if(!lit_internalized(arg))++missing;
 if(missing>=100 || get_scope_level()>=10000)std::abort();
 shape=to_app(n)->get_num_args()*1000000+missing*10000+get_scope_level();}auto a=read_install(fd);literal_buffer lits;''')
c=edit(c,'install_log(fd,a,"L");a=read_install(fd);mk_root_clause','install_log(fd,a,"L");auto prior=m_aux_clauses.size();a=read_install(fd);mk_root_clause')
for tag in 'LKWM':
    extra='fprintf(stderr,"D %d %u\\n",shape,m_aux_clauses.size()>prior?m_aux_clauses[prior]->get_num_literals():0);' if tag=='K' else ''
    c=edit(c,'install_log(fd,a,"'+tag+'")','if(fd>=0){auto used=read_install(fd)-a;fprintf(stderr,"'+tag+' %d %lld\\n",shape,used);'+extra+'}')
s=edit(s,"b'W',b'M'","b'W',b'M',b'D'")
s=edit(s,"key=(a[0].decode(),int(a[1]));counts[key]","key=(a[0].decode(),int(a[1])*1000+int(a[2]) if a[0]==b'D' else int(a[1]));counts[key]")
exec(compile(s,'phases.py','exec'),{'overlays':{k:v.encode() for k,v in [('qi_queue.cpp',qcpp),('smt_internalizer.cpp',c),('check-g3-smt_qi_instance.go',qgo),('internalizer.go',g)]}})
