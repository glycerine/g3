"""Measure the production parent and release installation path in two rotations."""
from pathlib import Path
import tarfile
with tarfile.open('perf/ivy_apple/holdouts/nov27-tlb-model-bindings.tar.xz') as t:
    s=t.extractfile('study/phases.py').read().decode()
s=s.replace("('base','release','native')","('base','release')").replace("['base','release','native']","['base','release']").replace("range(3)","range(2)")
a=s.index("        if engine=='base'");b=s.index("    j=d/",a)
s=s[:a]+'''        if engine=='base':
            for fname in ('smt_internalizer.go','smt_relevancy.go','smt_relevancy_asserted_or.go'):
                put(pkg/'smtcore'/fname,sp.check_output(['git','show','bf4a3f032:pkg/smtcore/'+fname]))
'''+s[b:]
exec(compile(s,'phases.py','exec'))
