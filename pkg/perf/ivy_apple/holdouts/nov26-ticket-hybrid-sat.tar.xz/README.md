# Ticket, hybrid broadcast and standalone SAT

The original g3 build is da8b16e6a. The final subsumption build corresponds
to 47792d65be18210afa8155359931a143e314ab71. The SAT before and after binaries use ordinary Go without PGO.
The native SAT control is build/z3 from this repository. The linked control
for Ticket and hybrid is the GoIvy classic_z3 build. The GoIvy revision,
local g3 module replacement and flags are in frontier/build.json.

Use pkg/perf/ivy_raft/watch_propagation.py with --permutations 3 --rounds 5
and the baseline g3, final g3 and in-tree Z3 to repeat the 210 final SAT
measurements. The script regenerates the exact inputs, validates printed
SAT models and requires matching integral search statistics on UNSAT cases.
The SAT leaf profiles sample every 1,999,993 user-mode instructions on
pigeon8-s1. The archive only stores decoded profiles and statistics.

The five exact phase rotations match both output streams and exit status
to references in nov24-verifier-instruction-stacks.tar.xz. Apply
phase-counters/goivy-solver.patch to z3bridge_solver_model.go via overlay
and also overlay phase_observer_trial.go as a new GoIvy package file.
Build both backends with the manifest-producing driver or its recorded
flags plus the overlay. Instructions are counted by the calling OS thread.
The phase rows contain the original counter calibration and enabled/running
times. First and ordinary pushes are distinguished within each physical
batch. Early exits in g3 explain different check counts across backends.
The separate whole-process FP profiles cover three rotations per spec.

The measured phase builds used the new subsumption code. The matched
standalone replays used the 16-byte reason candidate, which is included as
a patch.

Use pkg/perf/ivy_apple/holdouts/query_operations.py with --queries
ticket-127 ticket-290 to reproduce matched exact replay measurements.
The probe commits no changes to either solver. The QI trial patches are
alternatives against da8b16e6a. The dispatch trial overlays its patch on
the 16-byte reason candidate so both arms use the same reason storage. The SAT reason
prototypes were rebased onto the released compact watch storage for
measurement. The archive includes their historical raw layouts and driver
sources to identify the earlier experiments. The trial named native in
reason16-verifier and rewrite-dispatch-verifier is an alternate Go build.
Their actual Z3 controls are reported in the separate frontier results.
The aborted perf-wrapper wall comparison is included with its rejected
attempts. Use the direct quiet timing rows for elapsed time.
