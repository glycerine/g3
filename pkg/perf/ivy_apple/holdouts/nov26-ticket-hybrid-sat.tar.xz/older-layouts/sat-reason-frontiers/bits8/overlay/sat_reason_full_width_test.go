package sat

import (
	"math"
	"testing"
)

func TestSATReasonColumnFullWidthLocators(t *testing.T) {
	var c satSolverJustifications
	c.bind()
	c.clauses = &ClauseAllocator{origin: math.MaxUint64}
	defer c.finalize()
	for i := 0; i < 6; i++ {
		satOK(t, c.push(newSATBinaryJustification(2)))
	}
	for rep := 0; rep < 2; rep++ {
		for i, o := range []satClauseOffset{
			{owner: math.MaxUint64, slot: math.MaxUint32, generation: math.MaxUint32, storageKind: math.MaxUint32},
			{owner: math.MaxUint64, slot: 31, generation: (1 << 28) - 1, storageKind: 1},
			{owner: math.MaxUint64, slot: 9, generation: 1 << 28, storageKind: 0},
			{owner: math.MaxUint64, slot: 11, generation: (1 << 28) - 1, storageKind: 0},
			{owner: math.MaxUint64, slot: 1, generation: 0, storageKind: 4},
			{owner: math.MaxUint64, slot: 0, generation: 0, storageKind: 0},
		} {
			j := newSATClauseJustification(o)
			satOK(t, c.write(uint32(i), j))
			got, e := c.read(uint32(i))
			satOK(t, e)
			if got != j || !got.Clause() || got.ClauseOffset() != o {
				t.Fatalf("lost locator %#v: %#v", o, got)
			}
		}
		satOK(t, c.shrink(2))
		for len(c.values) < 6 {
			satOK(t, c.push(newSATExternalJustification(91)))
		}
		for i := uint32(2); i < 6; i++ {
			j, e := c.read(i)
			satOK(t, e)
			if !j.External() || j.ExternalIndex() != 91 {
				t.Fatal("retired clause survived regrowth", i, j)
			}
		}
	}
}
