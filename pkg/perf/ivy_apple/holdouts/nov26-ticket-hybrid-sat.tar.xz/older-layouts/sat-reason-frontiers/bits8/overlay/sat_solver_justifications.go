package sat

import "github.com/glycerine/g3/pkg/arena"

// Native values retain the exact checked clause locator alongside the source
// kind/literal words. The surrounding variable-state header owns this member;
// native backing has no Runtime allocation or separate provenance reservation.
type satReasonRow struct{ val1, val2 uint32 }

const satReasonWide = ^uint32(0) - 4

type satSolverJustifications struct {
	self    *satSolverJustifications
	clauses *ClauseAllocator // fixed non-owning allocator binding
	values  []satReasonRow
	wide    map[uint32]uint64
	closed  bool
}

func (c *satSolverJustifications) bind() { c.self = c }
func (c *satSolverJustifications) open() error {
	if c == nil || c.self != c {
		return ErrSATOwner
	}
	if c.closed {
		return arena.ErrClosed
	}
	return nil
}
func (c *satSolverJustifications) bindClauses(a *ClauseAllocator) error {
	if e := c.open(); e != nil {
		return e
	}
	if e := a.open(); e != nil {
		return e
	}
	if c.clauses != nil && c.clauses != a {
		return ErrSATOwner
	}
	c.clauses = a
	return nil
}
func (c *satSolverJustifications) size() (uint32, error) {
	if e := c.open(); e != nil {
		return 0, e
	}
	return uint32(len(c.values)), nil
}
func (c *satSolverJustifications) checkIndex(i uint32) error {
	if e := c.open(); e != nil {
		return e
	}
	if uint64(i) >= uint64(len(c.values)) {
		if satStorageSourceDebug {
			return ErrSATAssertion
		}
		return arena.ErrBounds
	}
	return nil
}
func (c *satSolverJustifications) checkValue(j satJustification) error {
	if j.Kind() == 3 && (c.clauses == nil || j.owner != c.clauses.origin) {
		return ErrSATOwner
	}
	return nil
}
func (c *satSolverJustifications) read(i uint32) (satJustification, error) {
	if e := c.checkIndex(i); e != nil {
		return satJustification{}, e
	}
	r := c.values[i]
	j := satJustification{val1: r.val1, val2: r.val2}
	if j.Kind() == 3 {
		if c.clauses == nil {
			return j, ErrSATOwner
		}
		j.owner = c.clauses.origin
		if r.val2 == satReasonWide {
			j.stamp = c.wide[i]
		} else {
			j.stamp = uint64(r.val2>>4) | uint64(r.val2>>3&1)<<32
		}
		j.val2 = 3
	}
	return j, nil
}
func (c *satSolverJustifications) write(i uint32, j satJustification) error {
	if e := c.checkIndex(i); e != nil {
		return e
	}
	if e := c.checkValue(j); e != nil {
		return e
	}
	c.store(i, j)
	return nil
}
func (c *satSolverJustifications) push(j satJustification) error {
	if e := c.open(); e != nil {
		return e
	}
	if e := c.checkValue(j); e != nil {
		return e
	}
	if uint64(len(c.values)) >= uint64(^uint32(0)) {
		return arena.ErrBounds
	}
	i := uint32(len(c.values))
	c.values = append(c.values, satReasonRow{})
	c.store(i, j)
	return nil
}
func (c *satSolverJustifications) shrink(n uint32) error {
	if e := c.open(); e != nil {
		return e
	}
	if uint64(n) > uint64(len(c.values)) {
		if satStorageSourceDebug {
			return ErrSATAssertion
		}
		return arena.ErrBounds
	}
	for i := range c.wide {
		if i >= n {
			delete(c.wide, i)
		}
	}
	c.values = c.values[:n]
	return nil
}
func (c *satSolverJustifications) finalize() error {
	if c == nil || c.self != c {
		return ErrSATOwner
	}
	c.wide = nil
	c.values = nil
	c.closed = true
	return nil
}

func (c *satSolverJustifications) store(i uint32, j satJustification) {
	tag := j.val2
	if j.Clause() {
		g, k := uint32(j.stamp), uint32(j.stamp>>32)
		tag = 3 | k<<3 | g<<4
		if g >= 1<<28 || k > 1 {
			tag = satReasonWide
		}
	}
	if tag == satReasonWide {
		if c.wide == nil {
			c.wide = make(map[uint32]uint64)
		}
		c.wide[i] = j.stamp
	} else if c.wide != nil {
		delete(c.wide, i)
	}
	c.values[i] = satReasonRow{j.val1, tag}
}
