package sat

import (
	"github.com/glycerine/g3/pkg/util/diagnostic"
	utext "github.com/glycerine/g3/pkg/util/text"
)

type satJustification struct {
	val1, val2   uint32
	owner, stamp uint64
}

func newSATBinaryJustification(l Literal) satJustification {
	return satJustification{val1: uint32(l), val2: 1}
}
func newSATTernaryJustification(a, b Literal) satJustification {
	return satJustification{val1: uint32(a), val2: 2 + (uint32(b) << 3)}
}
func newSATClauseJustification(o satClauseOffset) satJustification {
	return satJustification{val1: o.slot, val2: 3, owner: o.owner, stamp: uint64(o.generation) | uint64(o.storageKind)<<32}
}
func newSATExternalJustification(i uint32) satJustification {
	return satJustification{val1: i, val2: 4}
}
func (j satJustification) Kind() uint32   { return j.val2 & 7 }
func (j satJustification) None() bool     { return j.val2 == 0 }
func (j satJustification) Binary() bool   { return j.val2 == 1 }
func (j satJustification) Ternary() bool  { return j.Kind() == 2 }
func (j satJustification) Clause() bool   { return j.val2 == 3 }
func (j satJustification) External() bool { return j.val2 == 4 }
func satJustificationAssertion(ok bool, line int32, condition string) error {
	if ok || !satStorageSourceDebug {
		return nil
	}
	d := diagnostic.BorrowProcessDebugContext()
	enabled, err := d.AssertionsEnabled()
	if err != nil || !enabled {
		return err
	}
	if !d.HasAssertionActions() {
		return ErrSATAssertion
	}
	return diagnostic.DebugAssertionFailure(d, "src/sat/sat_justification.h", line, condition)
}
func (j satJustification) Literal() (Literal, error) {
	if err := satJustificationAssertion(j.Binary(), 43, "is_binary_clause()"); err != nil {
		return 0, err
	}
	return Literal(j.val1), nil
}
func (j satJustification) Literal1() (Literal, error) {
	if err := satJustificationAssertion(j.Ternary(), 46, "is_ternary_clause()"); err != nil {
		return 0, err
	}
	return Literal(j.val1), nil
}
func (j satJustification) Literal2() (Literal, error) {
	if err := satJustificationAssertion(j.Ternary(), 47, "is_ternary_clause()"); err != nil {
		return 0, err
	}
	return Literal(j.val2 >> 3), nil
}
func (j satJustification) ClauseOffset() satClauseOffset {
	return satClauseOffset{owner: j.owner, slot: j.val1, generation: uint32(j.stamp), storageKind: uint32(j.stamp >> 32)}
}
func (j satJustification) ExternalIndex() uint32 { return j.val1 }
func (j satJustification) DisplayInto(s *utext.NumericTextStream) error {
	switch j.Kind() {
	case 0:
		return s.AppendCString("none")
	case 1:
		if e := s.AppendCString("binary "); e != nil {
			return e
		}
		l, e := j.Literal()
		if e != nil {
			return e
		}
		return satLiteralInto(s, l)
	case 2:
		if e := s.AppendCString("ternary "); e != nil {
			return e
		}
		l, e := j.Literal1()
		if e != nil {
			return e
		}
		if e = satLiteralInto(s, l); e != nil {
			return e
		}
		if e = s.AppendCString(" "); e != nil {
			return e
		}
		l, e = j.Literal2()
		if e != nil {
			return e
		}
		return satLiteralInto(s, l)
	case 3:
		return s.AppendCString("clause")
	case 4:
		return s.AppendCString("external")
	}
	return nil
}
