from common import *
import sat_watch_backing_shapes as sw,watch_lookup_trials as wt,holdouts as ho,split_instance_attribution as sa
sd=pkg/'sat';rd=d/'sat-watch-encoded-offset';rd.mkdir(exist_ok=True);vs=['before','offset24','offset20','transfer','one-watch','hot-read'];base=sw.edits
def edits(v):
 if v=='before':return {}
 ed=base('direct8');k=sd/'sat_watched.go';ed.pop(k);ed.pop(sd/'sat_solver_watch_store_test.go')
 k=sd/'sat_solver_watch_store.go';s=ed[k];s=s.replace('common satWatchMetadata\n other []satWatchMetadata\n commonSet bool','owner uint64\n other []satClauseOffset\n ownerSet bool')
 s=s.replace('next.common=prev.common;next.commonSet=prev.commonSet','next.owner=prev.owner;next.ownerSet=prev.ownerSet').replace('make([]satWatchMetadata,cap(next.data))','make([]satClauseOffset,cap(next.data))')
 i=s.index('type satWatchMetadata struct');j=s.index('func(b *satWatchBacking)swap',i)
 b=20 if v=='offset20'else 24;maxg=(1<<(31-b))-1
 s=s[:i]+'''const satWatchSlotBits=WIDTH
const satWatchMaxGeneration=MAXG
const satWatchWide=uint32(1)<<(32-satWatchSlotBits)-1
func(b *satWatchBacking)invalidate(){*b=satWatchBacking{}}
func(b *satWatchBacking)offset(w satWatchWords,i uint32)satClauseOffset{
 code:=w.val1>>satWatchSlotBits
 if code==satWatchWide{return b.other[i]}
 return satClauseOffset{owner:b.owner,slot:w.val1&((1<<satWatchSlotBits)-1),generation:code>>1,storageKind:code&1}
}
func(b *satWatchBacking)read(i uint32)satWatched{
 w:=b.data[i];r:=satWatched{val1:w.val1,val2:w.val2}
 if r.Clause(){r.locator=b.offset(w,i);r.val1=r.locator.slot};return r
}
func(b *satWatchBacking)store(i uint32,w satWatched){
 a:=w.val1
 if w.Clause(){
  o:=w.locator;o.slot=a
  if !b.ownerSet{b.owner=o.owner;b.ownerSet=true}
  if b.owner==o.owner&&a<1<<satWatchSlotBits&&o.generation<satWatchMaxGeneration&&o.storageKind<=1{
   a|=(o.generation<<1|o.storageKind)<<satWatchSlotBits
  }else{
   if b.other==nil{b.other=make([]satClauseOffset,cap(b.data))};b.other[i]=o;a=satWatchWide<<satWatchSlotBits
  }
 }
 b.data[i]=satWatchWords{a,w.val2}
}
'''.replace('WIDTH',str(b)).replace('MAXG',str(maxg))+s[j:]
 if v in ('transfer','one-watch','hot-read'):
  s+='''
func(x *satSolverWatchListRecord)appendEncoded(w satWatchWords,owner uint64)bool{
 b:=x.backing
 if b==nil||b.owner!=owner||!b.ownerSet||w.val1>>satWatchSlotBits==satWatchWide{return false}
 n:=len(b.data);if n>=cap(b.data)||uint64(n)>=uint64(^uint32(0)){return false}
 b.data=b.data[:n+1];b.data[n]=w;return true
}
'''
 if v=='one-watch':
  i=s.index('old := x.values()',s.index('func (x *satSolverWatchListRecord) growAndAppend'))
  s=s[:i]+'''if x.backing==nil{p:=new(struct{h satWatchBacking;first [1]satWatchWords});p.h.alive=true;p.h.data=p.first[:];p.h.store(0,w);x.backing=&p.h;return nil}
 '''+s[i:]
 if v=='hot-read':
  i=s.index('if e := i.store.open();',s.index('func (i *satSolverWatchIterator) Next'));j=s.index('w, e := satPropagationCursorRead',i);s=s[:i]+'''if i.index==i.end{return satWatched{},false,i.store.open()};'''+s[j:]
 ed[k]=s;k=sd/'sat_solver_propagation.go';q=ed[k]
 i=q.index('w=iter.backing.read(pos);off,e:=w.ClauseOffset()');j=q.index('c := StoredClauseRef(off)',i);q=q[:i]+'''off:=iter.backing.offset(bits,pos)
 '''+q[j:]
 q=q.replace('w.SetClause(c0, off)','w.val2=2+uint32(c0)<<2')
 q=q.replace('satWatchWords{w.val1,w.val2};if iter.backing.other','satWatchWords{bits.val1,w.val2};if iter.backing.other')
 if v in ('transfer','one-watch','hot-read'):
  i=q.index('nextWatch, err := newSATClauseWatch(c0, off)');j=q.index('\n\t\t\t\t\t}',i)
  q=q[:i]+'''next:=satWatchWords{bits.val1,2+uint32(c0)<<2};if dest.appendEncoded(next,iter.backing.owner){keep=false;break}
 '''+q[j:]
 ed[k]=q;return ed
if __name__=='__main__':
 sw.edits=edits;sw.rd=wt.rd=ho.root=rd;sw.vs=vs
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(sw.prep,vs)))
 with ThreadPoolExecutor(10)as ex:
  fs=[ex.submit(sw.pop,bb)]+[ex.submit(wt.probe,j,{v:b[2]for v,b in bb.items()})for j in [(3,'pigeon8'),(10,'pigeon7'),(15,'planted5'),(32,'propagate6')]]
  fs+=[ex.submit(ho.measure_spec,j,{v:b[1]for v,b in bb.items()},3)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  for f in fs:f.result()
 print('all passed',flush=True)
