from common import *
import tempfile,watch_lookup_trials as wt,holdouts as ho,split_instance_attribution as sa
sd=pkg/'sat';rd=d/'sat-reason-frontiers';rd.mkdir(exist_ok=True);vs=['before','old8','words16','bits8','packed8','packed-push']
def orig(p):return subprocess.check_output(['git','show','a635dd294:pkg/sat/'+p.name],cwd=pkg,text=True)
def edits(v):
 if v=='before':return {}
 j=sd/'sat_justification.go';k=sd/'sat_solver_justifications.go';x=orig(j);s=orig(k)
 if v=='old8':
  z=rd/'old8-patch';z.mkdir(exist_ok=True);p=z/k.name;p.write_text(s);run(['patch','--batch','--fuzz=0',p,pkg/'perf/ivy_raft/allocator/compact-sat-reasons.patch'],stdout=subprocess.DEVNULL);return {k:p.read_text()}
 x=x.replace('locator    satClauseOffset','owner, stamp uint64')
 ctor='return satJustification{val1:o.slot,val2:3,owner:o.owner,stamp:uint64(o.generation)|uint64(o.storageKind)<<32}'
 packed=v.startswith('packed')
 if packed:ctor='''tag:=uint32(3)|o.storageKind<<3|o.generation<<4
 if o.storageKind>1||o.generation>=1<<28||tag==satReasonWide{return satJustification{val1:o.slot,val2:satReasonWide,owner:o.owner,stamp:uint64(o.generation)|uint64(o.storageKind)<<32}}
 return satJustification{val1:o.slot,val2:tag,owner:o.owner}'''
 x=once(x,'return satJustification{val1: o.slot, val2: 3, locator: o}',ctor)
 if packed:x=x.replace('return j.val2 == 3','return j.Kind()==3').replace('return Literal(j.val2 >> 3), nil','if j.Clause(){return 0,nil};return Literal(j.val2>>3),nil')
 unpack='return satClauseOffset{owner:j.owner,slot:j.val1,generation:uint32(j.stamp),storageKind:uint32(j.stamp>>32)}'
 if packed:unpack='if j.Clause()&&j.val2!=satReasonWide{return satClauseOffset{owner:j.owner,slot:j.val1,generation:j.val2>>4,storageKind:j.val2>>3&1}};'+unpack
 x=x.replace('o := j.locator; o.slot = j.val1; return o',unpack);s=s.replace('j.locator.owner','j.owner')
 s=s.replace('values  []satJustification','values  []satReasonRow'+(''if v=='words16'else'\n wide map[uint32]uint64'))
 row='type satReasonRow struct{val1,val2 uint32'+(';stamp uint64'if v=='words16'else'')+'}'
 s=s.replace('type satSolverJustifications struct {',row+'\nconst satReasonWide = ^uint32(0)-4\n type satSolverJustifications struct {')
 i=s.index('j := c.values[i]');j1=s.index('\n}',i)
 read='''r:=c.values[i];j:=satJustification{val1:r.val1,val2:r.val2}
 if j.Kind()==3{if c.clauses==nil{return j,ErrSATOwner};j.owner=c.clauses.origin;'''
 if v=='words16':read+='j.stamp=r.stamp'
 elif packed:read+='if r.val2==satReasonWide{j.stamp=c.wide[i]}'
 else:read+='if r.val2==satReasonWide{j.stamp=c.wide[i]}else{j.stamp=uint64(r.val2>>4)|uint64(r.val2>>3&1)<<32};j.val2=3'
 s=s[:i]+read+'};return j,nil'+s[j1:]
 if v=='words16':
  s=s.replace('c.values[i] = j','c.values[i]=satReasonRow{j.val1,j.val2,j.stamp}').replace('append(c.values, j)','append(c.values,satReasonRow{j.val1,j.val2,j.stamp})')
 else:
  s=s.replace('c.values[i] = j','c.store(i,j)').replace('c.values = append(c.values, j)','i:=uint32(len(c.values));c.values=append(c.values,satReasonRow{});c.store(i,j)')
  s=s.replace('c.values = c.values[:n]','for i:=range c.wide{if i>=n{delete(c.wide,i)}};c.values=c.values[:n]').replace('c.values = nil','c.wide=nil;c.values=nil')
  s+='''\nfunc(c *satSolverJustifications)store(i uint32,j satJustification){
 tag:=j.val2
 '''+(''if packed else'''if j.Clause(){g,k:=uint32(j.stamp),uint32(j.stamp>>32);tag=3|k<<3|g<<4;if g>=1<<28||k>1{tag=satReasonWide}}
 ''')+'''if tag==satReasonWide{if c.wide==nil{c.wide=make(map[uint32]uint64)};c.wide[i]=j.stamp}else if c.wide!=nil{delete(c.wide,i)};c.values[i]=satReasonRow{j.val1,tag}
}'''
 if v=='packed-push':
  s=s.replace('i:=uint32(len(c.values));c.values=append(c.values,satReasonRow{});c.store(i,j)','if j.val2!=satReasonWide{c.values=append(c.values,satReasonRow{j.val1,j.val2})}else{i:=uint32(len(c.values));c.values=append(c.values,satReasonRow{});c.store(i,j)}')
 return {k:s,j:x}
def prep(v):
 o=rd/v;o.mkdir(exist_ok=True);ed=edits(v);test=sd/'sat_reason_full_width_test.go';ed[test]=(d/test.name).read_text();ov=overlay(o/'overlay',ed);b=o/'sat.test'
 with(w/'build.lock').open('a')as lk,(o/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-c','-pgo=off','-overlay='+str(ov),'-o',b,'./sat'],cwd=pkg,stdout=f,stderr=f);run([b,'-test.run=.'],cwd=sd,stdout=f,stderr=f)
  run(['go','test','-p','3','-tags=g3checked,g3debug,g3trace','-overlay='+str(ov),'-run=Justifi|Reason|Assign|Propagat|Integrity','-count=1','./sat'],cwd=pkg,stdout=f,stderr=f)
 return b,build(o/'checker',o=ov),build(o/'shell',o=ov,shell=True)
def bench(bb):
 with(rd/'reason.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine mode n instructions bytes ns'.split())
  for rr in range(7):
   for v in vs[rr%len(vs):]+vs[:rr%len(vs)]:
    for m in ['Binary','Mixed','Clause']:
     for n in ([1000,500000]if rr%2==0 else[500000,1000]):
      st=rd/'reason.stat';p=run(['taskset','-c','38',perf,'stat','-x,','-e','instructions:u','-o',st,'--',bb[v][0],'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSATJustificationColumn$/^'+m+'$','-test.benchtime='+str(n)+'x'],cwd=sd,env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
      ir=next(int(r[0])for r in csv.reader(st.open())if len(r)>2 and r[2]=='instructions:u');l=next(l for l in p.stdout.splitlines()if l.startswith('BenchmarkSATJustificationColumn/'));met={k:x for x,k in re.findall(r'([-\d.]+) ([\w/-]+)',l)};z.writerow([rr+1,v,m,n,ir,met['bytes/row'],met['ns/op']]);f.flush()
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(prep,vs)))
 wt.rd=ho.root=rd
 with ThreadPoolExecutor(12)as ex:
  fs=[ex.submit(bench,bb)]+[ex.submit(wt.probe,j,{v:b[2]for v,b in bb.items()})for j in [(2,'pigeon8'),(7,'pigeon7'),(28,'planted5'),(35,'propagate6')]]
  fs+=[ex.submit(ho.measure_spec,j,{v:b[1]for v,b in bb.items()},3)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  for f in fs:f.result()
 print('passed',flush=True)
