from common import *
import sat_watch_backing_shapes as sw,compact_sat_watches as cw,watch_lookup_trials as wt,holdouts as ho,split_instance_attribution as sa
sd=pkg/'sat';rd=d/'sat-watch-value-layout';rd.mkdir(exist_ok=True);vs=['before','cursor32','inline24','cursor24','fold24','fold-cursor','short24','short-fold','direct8']
def edits(v):
 if v in ('before','inline24','direct8'):return sw.edits(v)
 small=v!='cursor32';ed=sw.edits('inline24') if small else {};k=sd/'sat_watched.go'
 if 'fold'in v:
  s=ed[k].replace('generation, storageKind uint32','stamp uint64')
  s=s.replace('generation:o.generation,storageKind:o.storageKind','stamp:uint64(o.generation)|uint64(o.storageKind)<<32')
  s=s.replace('generation:w.generation,storageKind:w.storageKind','generation:uint32(w.stamp),storageKind:uint32(w.stamp>>32)')
  s=s.replace('w.owner,w.generation,w.storageKind=o.owner,o.generation,o.storageKind','w.owner,w.stamp=o.owner,uint64(o.generation)|uint64(o.storageKind)<<32')
  ed[k]=s
 k=sd/'sat_solver_watch_store.go';s=k.read_text()
 if 'cursor'in v or 'short'in v:
  i=s.index('if e := i.store.open();',s.index('func (i *satSolverWatchIterator) Next'));j=s.index('w, e := satPropagationCursorRead',i)
  s=s[:i]+'''if i.index==i.end{return satWatched{},false,i.store.open()}
 '''+s[j:]
 if 'short'in v:
  i=s.index('old := x.values()',s.index('func (x *satSolverWatchListRecord) growAndAppend'))
  s=s[:i]+'''if x.backing==nil{b:=new(struct{header satWatchBacking;first [1]satWatched});b.first[0]=w;b.header.data=b.first[:];b.header.alive=true;x.backing=&b.header;return nil}
 '''+s[i:]
 ed[k]=s;return ed
def main():
 sw.edits=edits_proxy;sw.rd=wt.rd=ho.root=rd;sw.vs=vs
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(sw.prep,vs)))
 with ThreadPoolExecutor(11)as ex:
  fs=[ex.submit(sw.pop,bb)]+[ex.submit(wt.probe,j,{v:b[2] for v,b in bb.items()})for j in [(5,'pigeon8'),(9,'pigeon7'),(21,'planted5'),(26,'propagate6')]]
  fs += [ex.submit(ho.measure_spec,j,{v:b[1] for v,b in bb.items()},3)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  for f in fs:f.result()
 print('all passed',flush=True)
base_edits=sw.edits
def edits_proxy(v):
 return original(v)
src=inspect_src=None
import inspect
exec(inspect.getsource(edits).replace('def edits(v):','def original(v):').replace('sw.edits(','base_edits('))
if __name__=='__main__':main()
