from common import *
import compact_sat_watches as cw,watch_lookup_trials as wt,holdouts as ho,split_instance_attribution as sa
sd=pkg/'sat';rd=d/'sat-watch-backing-shapes';rd.mkdir(exist_ok=True);vs=['before','inline24','common8','lazy8','direct8']
fixture='sat_watch_population_benchmark_test.go'
def edits(v):
 if v=='before':return {}
 ed=cw.ed('inline24');ed.pop(cw.prop,None)
 if v=='inline24':return ed
 k=sd/'sat_solver_watch_store.go';s=k.read_text()
 s=s.replace('data  []satWatched','data []satWatchWords\n common satWatchMetadata\n other []satWatchMetadata\n commonSet bool')
 s=s.replace('func (x *satSolverWatchListRecord) values() []satWatched','func (x *satSolverWatchListRecord) values() []satWatchWords')
 s=s.replace('return x.backing.data[i], nil','return x.backing.read(i),nil').replace('x.backing.data[i] = w','x.backing.store(i,w)')
 s=s.replace('b.data[n] = w','b.store(uint32(n),w)')
 i=s.index('next := append(old, w)');j=s.index('return nil',i)
 s=s[:i]+'''next:=&satWatchBacking{data:append(old,satWatchWords{}),alive:true}
 if prev:=x.backing;prev!=nil{next.common=prev.common;next.commonSet=prev.commonSet
 if prev.other!=nil{next.other=make([]satWatchMetadata,cap(next.data));copy(next.other,prev.other)}
 prev.invalidate()}
 x.backing=next;next.store(uint32(len(old)),w)
 '''+s[j:]
 s=s.replace('for i, w := range x.values() {','for i := range x.values() {\\n w:=x.backing.read(uint32(i))').replace('for _, v := range x.values() {','for i := range x.values() {\\n v:=x.backing.read(uint32(i))').replace('{\\n','{\n')
 s=s.replace('copy(data[i:], data[i+1:])','copy(data[i:],data[i+1:]);if x.backing.other!=nil{copy(x.backing.other[i:len(data)-1],x.backing.other[i+1:len(data)])}')
 s=s.replace('x.backing.alive = false\n\t\tx.backing.data = nil','x.backing.invalidate()').replace('b.alive = false\n\t\t\tb.data = nil','b.invalidate()')
 s+='''
type satWatchWords struct{val1,val2 uint32}
type satWatchMetadata struct{owner uint64;generation,storageKind uint32}
func(b *satWatchBacking)invalidate(){*b=satWatchBacking{}}
func(b *satWatchBacking)read(i uint32)satWatched{
 w:=b.data[i];r:=satWatched{val1:w.val1,val2:w.val2}
 if r.Clause(){m:=b.common;if b.other!=nil{m=b.other[i]};r.owner,r.generation,r.storageKind=m.owner,m.generation,m.storageKind};return r
}
func(b *satWatchBacking)store(i uint32,w satWatched){
 b.data[i]=satWatchWords{w.val1,w.val2}
 if !w.Clause(){return};m:=satWatchMetadata{w.owner,w.generation,w.storageKind}
 if b.other!=nil{b.other[i]=m;return};if !b.commonSet{b.common=m;b.commonSet=true;return}
 if m!=b.common{b.other=make([]satWatchMetadata,cap(b.data));for j:=range b.data{b.other[j]=b.common};b.other[i]=m}
}
func(b *satWatchBacking)swap(i,j int){b.data[i],b.data[j]=b.data[j],b.data[i];if b.other!=nil{b.other[i],b.other[j]=b.other[j],b.other[i]}}
'''
 p=sd/'sat_solver_propagation.go';q=p.read_text().replace('return x.data[n], nil','return x.read(n),nil').replace('x.data[n] = w','x.store(n,w)').replace('var data []satWatched','var data []satWatchWords').replace('w := data[pos]','w:=iter.backing.read(pos)').replace('data[out] = w','iter.backing.store(out,w)')
 q=q.replace('copy(backing.data[*to:*to+count], backing.data[from:i.end])','copy(backing.data[*to:*to+count],backing.data[from:i.end]);if backing.other!=nil{copy(backing.other[*to:*to+count],backing.other[from:i.end])}')
 if v=='direct8':
  q=q.replace('w:=iter.backing.read(pos)','bits:=data[pos];w:=satWatched{val1:bits.val1,val2:bits.val2}')
  q=q.replace('s.traceBlockedClause(blocked, w)','s.traceBlockedClause(blocked,iter.backing.read(pos))').replace('off, e := w.ClauseOffset()','w=iter.backing.read(pos);off,e:=w.ClauseOffset()')
  q=q.replace('iter.backing.store(out,w)','data[out]=satWatchWords{w.val1,w.val2};if iter.backing.other!=nil{iter.backing.other[out]=iter.backing.other[pos]}')
 if v=='lazy8':
  # Store the optional dictionary beside only lists containing clause watches.
  s=s.replace('common satWatchMetadata\n other []satWatchMetadata\n commonSet bool','detail *satWatchDetail')
  s=s.replace('type satWatchMetadata struct','type satWatchDetail struct{common satWatchMetadata;other []satWatchMetadata}\ntype satWatchMetadata struct')
  i=s.index('next.common=prev.common;');j=s.index('prev.invalidate()',i)
  s=s[:i]+'''next.detail=prev.detail;if next.detail!=nil&&next.detail.other!=nil{z:=make([]satWatchMetadata,cap(next.data));copy(z,next.detail.other);next.detail.other=z}
 '''+s[j:]
  s=s.replace('if !b.commonSet{b.common=m;b.commonSet=true;return}', 'if b.detail==nil{b.detail=&satWatchDetail{common:m};return}').replace('b.common','b.detail.common').replace('b.other','b.detail.other')
  s=s.replace('if b.detail.other!=nil','if b.detail!=nil&&b.detail.other!=nil')
  s=s.replace('if x.backing.other!=nil{','if x.backing.detail!=nil&&x.backing.detail.other!=nil{').replace('copy(x.backing.other','copy(x.backing.detail.other').replace('],x.backing.other','],x.backing.detail.other')
  q=q.replace('if backing.other!=nil','if backing.detail!=nil&&backing.detail.other!=nil').replace('copy(backing.other','copy(backing.detail.other').replace('],backing.other','],backing.detail.other')
 ed[k]=s;ed[p]=q
 k=sd/'sat_solver_watch_sort.go';s=k.read_text();i=s.index('type satWatchSortSlice');j=s.index('// watched_lt',i);s=s[:i]+'''type satWatchSortSlice struct{b *satWatchBacking;binary bool}
func(v *satWatchSortSlice)Len()int{return len(v.b.data)}
func(v *satWatchSortSlice)Less(i,j int)bool{a,b:=v.b.data[i],v.b.data[j];x,y:=satWatched{val1:a.val1,val2:a.val2},satWatched{val1:b.val1,val2:b.val2};if v.binary{return satSimplifierBinaryLess(x,y)};return satWatchedLess(x,y)}
func(v *satWatchSortSlice)Swap(i,j int){v.b.swap(i,j)}
'''+s[j:];s=s.replace('s.sorter.data = x.values()','if len(x.values())<2{return nil};s.sorter.b=x.backing').replace('s.sorter.data = nil','s.sorter.b=nil');ed[k]=s
 k=sd/'sat_simplifier_duplicate_bins.go';s=k.read_text();i=s.index('data := it.backing.data');j=s.index('return nil',i);ed[k]=s[:i]+'''sorter:=&it.store.sorter;sorter.b=it.backing;sorter.binary=true;sort.Stable(sorter);sorter.binary=false;sorter.b=nil
 '''+s[j:]
 return ed
def prep(v):
 o=rd/v;o.mkdir(exist_ok=True);ed=edits(v);ed[sd/fixture]=(d/fixture).read_text();ov=overlay(o/'overlay',ed);b=o/'sat.test'
 with(w/'build.lock').open('a')as lk,(o/'tests.log').open('w')as f:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','test','-p','3','-c','-pgo=off','-overlay='+str(ov),'-o',b,'./sat'],cwd=pkg,stdout=f,stderr=f);run([b,'-test.run=.'],cwd=sd,stdout=f,stderr=f)
  run(['go','test','-p','3','-count=1','-tags=g3checked,g3debug,g3trace','-overlay='+str(ov),'-run=Watch|Propagation|ClauseAttach','./sat'],cwd=pkg,stdout=f,stderr=f)
 return b,build(o/'checker',o=ov),build(o/'shell',o=ov,shell=True)
def pop(bb):
 with(rd/'population.csv').open('w')as f:
  z=csv.writer(f);z.writerow('round engine mode n instructions live reads ns'.split())
  for rr in range(7):
   for v in vs[rr%len(vs):]+vs[:rr%len(vs)]:
    for mode in ['Binary','Mixed','Reused','Short']:
     for n in ([3,97]if rr%2==0 else [97,3]):
      st=rd/'stat';p=run(['taskset','-c','7',perf,'stat','-e','instructions:u','-x,','-o',st,'--',bb[v][0],'-test.cpu=1','-test.run=^$','-test.bench=^BenchmarkSATWatchPopulation$/^'+mode+'$','-test.benchtime='+str(n)+'x'],cwd=sd,env=dict(env,GOMAXPROCS='1'),capture_output=True,text=True)
      ir=next(int(r[0])for r in csv.reader(st.open())if len(r)>2 and r[2]=='instructions:u')
      l=next(l for l in p.stdout.splitlines()if l.startswith('BenchmarkSATWatchPopulation/'));m={k:x for x,k in re.findall(r'([-\d.]+) ([\w/-]+)',l)};z.writerow([rr+1,v,mode,n,ir,m['live-B/watch'],m['reads/op'],m['ns/op']]);f.flush()
if __name__=='__main__':
 with ThreadPoolExecutor(3)as ex:bb=dict(zip(vs,ex.map(prep,vs)))
 wt.rd=ho.root=rd
 with ThreadPoolExecutor(9)as ex:
  fs=[ex.submit(pop,bb)]+[ex.submit(wt.probe,j,{v:b[2] for v,b in bb.items()})for j in [(4,'pigeon8'),(12,'planted5'),(17,'propagate6')]]
  fs += [ex.submit(ho.measure_spec,j,{v:b[1] for v,b in bb.items()},4)for j in sa.cases()if j[1]in ('rfn2','hermes_rmw_o3','arm_rules3','hybrid','ticket_protocol','tlb')]
  for f in fs:f.result()
 print('all passed',flush=True)
