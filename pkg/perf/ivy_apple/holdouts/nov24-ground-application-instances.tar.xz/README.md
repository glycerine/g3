# Quantified ground applications in verification batches

Extract this archive, then run the replay from any directory. Supply the g3 Go module and the native Z3 executable built from this repository's src tree.

    python3 replay.py --g3-module /path/to/g3/pkg --z3 /path/to/g3/build/z3

The oracle runs 90 goals on each of 32 premise sets, shrinks each premise set by half, then restores it. A private Go proof must agree with native UNSAT. The three Hermes SMT-LIB replay files include push, check-sat and pop around each unmodified goal. The compressed inputs in the repository's perf/ivy_apple/test_vectors directory expose the same base and sibling sequence as separate assertions for the Go benchmark.

Run the committed heap benchmark with one Go processor and one iteration per process.

    go test -tags=xtrace_off ./api -run '^$' -bench '^BenchmarkGroundApplicationWorkerMemory$' -benchtime=1x -cpu=1

release/ has five rotating process-counter rounds and separate seven-round quiet timing series. combined/ measures the final build together with the AST translation change. corpus/ records matching stdout, stderr and status. The ablation, admission, long-controls, storage and equalities directories contain exploratory comparisons. The traces directory records the independently checked release trace totals. All whole-verifier jobs used one Go processor and default GC. The two g3 builds used GoIvy 832e392ef. The historical native control in release/ and combined/ predates that frontend commit. CPU IDs for each series are recorded in its CSV.
