"""Replay the native ground oracle, or test the Go refutation against its saved answers."""
import argparse, json, os, subprocess, tempfile
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--z3", type=Path)
parser.add_argument("--g3-module", type=Path)
args = parser.parse_args()
if not (args.z3 or args.g3_module):
    parser.error("supply --z3, --g3-module, or both")
cases = root / "oracle" / "cases"
if args.z3:
    binary = args.z3.resolve()
    def verify(script, expected):
        result = subprocess.run([binary, "-smt2", "-in"], input=script, text=True, capture_output=True, check=True)
        if result.stderr or result.stdout.splitlines() != expected:
            raise RuntimeError(result.stderr or "verdict mismatch")
    for path in sorted(cases.iterdir()):
        lines = (path / "input.smt2").read_text().splitlines()
        declarations = [row for row in lines if row.startswith("(declare-")]
        assertions = [row for row in lines if row.startswith("(assert ")]
        n = int((path / "nbase").read_text())
        goals = assertions[n:]
        answers = (path / "expected").read_text().splitlines()
        for i, count in enumerate([n, n // 2, n]):
            script = declarations + assertions[:count]
            for goal in goals:
                script.extend(["(push 1)", goal, "(check-sat)", "(pop 1)"])
            verify("\n".join(script) + "\n", answers[i*len(goals):(i+1)*len(goals)])
    for path in sorted((root / "hermes").glob("*.replay.smt2")):
        answers = path.with_name(path.name.replace(".replay.smt2", ".expected")).read_text().splitlines()
        verify(path.read_text(), answers)
    print("Matched 8,640 generated checks and 123 Hermes checks")
if args.g3_module:
    pkg = args.g3_module.resolve()
    with tempfile.TemporaryDirectory() as td:
        overlay = Path(td) / "overlay.json"
        overlay.write_text(json.dumps({"Replace": {str(pkg / "api/application_oracle_test.go"): str(root / "oracle/application_oracle_test.go")}}))
        subprocess.run(["go", "test", "-overlay=" + str(overlay), "-tags=xtrace_off", "-count=1", "-run", "^TestSteadyProjectionOracle$", "-v", "./api"], cwd=pkg, env=dict(os.environ, G3_STEADY_CASES=str(cases)), check=True)
