from pathlib import Path
w=Path(__file__).resolve().parent;b=w.parent/'grandchildren';s=(b/'run.py').read_text().replace('shape="child-eq";','shape="child-eq";if inner{shape=studyEqShape(s,expr)};')
(w/'run.py').write_text(s);h=(b/'read.go.txt').read_text().replace('import(', 'import("strings";')
h+='''\nfunc studyEqShape(s *SMTInternalizerState,expr ast.ASTHandle)string{
 var b strings.Builder;b.WriteString("eq:")
 for i:=uint32(0);i<2;i++{
 a,e:=s.manager.GetArg(expr,i);if e!=nil{panic(e)}
 h,e:=s.manager.NodeHeader(a);if e!=nil{panic(e)}
 if h.Kind!=ast.ASTApp{b.WriteByte('_')}else if e=s.manager.DisplayDeclarationHead(&b,h.Decl);e!=nil{panic(e)}
 if s.context.enodes.get(a)!=nil{b.WriteString("/present")}else{b.WriteString("/fresh")};b.WriteByte('|')
 }
 return strings.ReplaceAll(b.String()," ","_")
}
'''
(w/'read.go.txt').write_text(h)
