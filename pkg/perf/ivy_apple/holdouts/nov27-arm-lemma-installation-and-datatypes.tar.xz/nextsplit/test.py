from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/theory_datatype_split.go';s=f.read_text()
k='''		constructors, err := s.manager.DatatypeConstructors(sort)
		if err != nil {
			return err
		}
''';assert s.count(k)==1;s=s.replace(k,'')
k='if recognizer == nil {\n\t\t\t\tconstructor = constructors[i]';s=s.replace(k,'''if recognizer == nil {
				constructors, err := t.utility.Constructors(sort)
				if err != nil { return err }
				if i >= len(constructors) { return ast.ErrASTDomain }
				constructor = constructors[i]''');assert 't.utility.Constructors(sort)' in s
dst=w/'split.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(16").replace("/tmp/g3-arm-events/identity/release","/tmp/g3-live-literals/count/release")'))
