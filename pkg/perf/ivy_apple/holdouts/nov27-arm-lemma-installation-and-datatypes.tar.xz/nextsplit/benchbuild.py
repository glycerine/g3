from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_datatype_enum_benchmark_test.go';s=f.read_text()
a=s.index('m := astTestManager(b)');b=s.index('b.ReportAllocs()',a)
setup=s[a:b].replace('s := solver.kernel.internalizer','return solver.kernel.internalizer, x, sorts[0]')
s=s[:a]+'s, x, _ := smtScopedEnumFixture(b, width)\n\t\t\t'+s[b:]+'''
func smtScopedEnumFixture(b *testing.B, width int) (*SMTInternalizerState, ast.ASTHandle, ast.ASTHandle) {
	b.Helper()
'''+setup+'}\n'+'''
// Revisit a split after its preferred constructor has been ruled out.
// Once the next recognizer is relevant and unassigned, it remains the choice.
func BenchmarkSMTEnumSplitAfterFalsePreference(b *testing.B) {
 for _,width:=range []int{4,16,64}{
  b.Run(fmt.Sprintf("constructors=%d",width),func(b *testing.B){
   s,x,sort:=smtScopedEnumFixture(b,width)
   m:=s.manager
   family,err:=m.DatatypeFamilyID();astTestMust(b,err);dt:=s.theories[family].(*SMTDatatypeTheory)
   astTestMust(b,s.Internalize(x,false))
   astTestMust(b,dt.split(x,sort))
   preferred,found,err:=dt.utility.NonRecursiveConstructor(sort);astTestMust(b,err);if !found{b.Fatal("missing preferred constructor")}
   slots,err:=dt.recognizerSlots(x);astTestMust(b,err)
   negative,err:=m.MkNot(slots[preferred].expression);astTestMust(b,err)
   astTestMust(b,s.Assert(negative,ast.ASTHandle{},0))
   consistent,err:=s.PropagateCore();astTestMust(b,err);if !consistent{b.Fatal("unexpected conflict")}
   astTestMust(b,dt.split(x,sort))
   slots,err=dt.recognizerSlots(x);astTestMust(b,err);if len(slots)!=2{b.Fatal("expected two recognizers",len(slots))}
   b.ReportAllocs();b.ResetTimer()
   for i:=0;i<b.N;i++{astTestMust(b,dt.split(x,sort))}
  })
 }
}
'''
d=w/'bench.go';d.write_text(s);subprocess.run(['gofmt','-w',d],check=True)
for mode in ['base','count']:
 rep=json.loads((w/'trial.json').read_text())['Replace'] if mode=='count' else {}
 rep[str(f)]=str(d);ov=w/(mode+'.json');ov.write_text(json.dumps({'Replace':rep}))
 subprocess.run(['go','test','-overlay',ov,'-c','-o',w/(mode+'.test'),'./smtcore'],check=True)
s=(w.parent/'count/bench.py').read_text().replace('BenchmarkSMTScopedEnumTerm','BenchmarkSMTEnumSplitAfterFalsePreference').replace("'2000x'","'5000x'").replace("r'2000","r'5000");exec(s)
