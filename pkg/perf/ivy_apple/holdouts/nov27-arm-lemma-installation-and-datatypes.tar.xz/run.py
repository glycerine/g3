"""Generate observational overlays for both engines. Run from pkg."""
from pathlib import Path
import csv,json,os,subprocess,sys,re,shlex,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();mode=sys.argv[1]
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(); prior=Path('/tmp/g3-ticket-stages')
ov=json.loads((prior/'translated.json').read_text())['Replace']
names=['lemmas','ors','operands','bound','bound_negative','all_bound','new_vars','fresh_operands','first_bound']
def overlay(f,s):
 dst=w/(mode+'-'+f.name+('' if f.name=='quantifier.go' else '.txt'));dst.write_text(s);ov[str(f)]=str(dst)
def sub(s,k,z):
 assert s.count(k)==1,(k,s.count(k));return s.replace(k,z)
st=(prior/'stage.go.txt').read_text()
if mode=='g3':
 st=st.replace('import (','import (\n"github.com/glycerine/g3/pkg/smtcore"')
 expr='smtcore.StudyEventCounts'
 f=p/'smtcore/smt_internalizer.go';t=f.read_text()
 k='return s.assertExpression(lemma, proof, instance.Generation(), arguments)';t=sub(t,k,'studyInstance=true;defer func(){studyInstance=false}();StudyEventCounts[0]++;'+k)
 a=t.index('func (s *SMTInternalizerState) assertExpression');h=t[:a];t=t[a:]
 k='literals := make([]SMTLiteral, len(arguments))';t=sub(t,k,'all:=true;if studyInstance{StudyEventCounts[1]++};'+k)
 k='for index, argument := range arguments {';t=sub(t,k,k+'if studyInstance {StudyEventCounts[2]++;lit,ok:=s.boundInstanceLiteral(argument);if ok{StudyEventCounts[3]++;if lit.Sign(){StudyEventCounts[4]++};if index==0{StudyEventCounts[8]++}}else{all=false;StudyEventCounts[7]++}};')
 k='if err = s.addRootClause(literals, proof);';t=sub(t,k,'if studyInstance&&all{StudyEventCounts[5]++};'+k)
 k='if err = s.Internalize(argument, true); err != nil {';a=t.index(k);t=t[:a]+t[a:].replace(k,'before:=len(s.boolExpr);err=s.Internalize(argument,true);if studyInstance{StudyEventCounts[6]+=uint64(len(s.boolExpr)-before)};if err!=nil{',1)
 overlay(f,h+t);overlay(p/'smtcore/study_event_counts.go','package smtcore\nvar StudyEventCounts [9]uint64\nvar studyInstance bool\n')

else:
 expr='studyRead()'
 st+='''
func studyRead() (v [9]uint64) {
 b,e:=os.ReadFile(os.Getenv("ARM_EVENT_FILE"));if e!=nil{panic(e)}
 for i:=range v {v[i]=binary.LittleEndian.Uint64(b[8*i:])};return
}
'''
 st=st.replace('import (','import (\n"encoding/binary"')
 b=p.parent/'build';src=p.parent/'src/smt';s=(src/'smt_context.cpp').read_text()
 helper='''
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdlib>
static unsigned long long* studyBuffer(){
 static auto p=[](){int fd=open(getenv("ARM_EVENT_FILE"),O_RDWR);if(fd<0)abort();
 void* ptr=mmap(nullptr,4096,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);if(ptr==MAP_FAILED)abort();close(fd);
 return static_cast<unsigned long long*>(ptr);}();return p;
}
'''
 qsrc=(src/'qi_queue.cpp').read_text();k='m_context.internalize_instance(lemma, pr1, gen);'
 (w/'qi_queue.cpp').write_text('thread_local bool studyInstance=false;\n'+sub(qsrc,k,'studyInstance=true;'+k+'studyInstance=false;'))
 s=(src/'smt_internalizer.cpp').read_text();a=s.index('void context::internalize_assertion(');b=s.index('case OP_IFF:',a);part=s[a:b]
 part=sub(part,'flet<unsigned> l','if(studyInstance)studyBuffer()[0]++;flet<unsigned> l')
 part=sub(part,'literal_buffer lits;','bool all=true;if(studyInstance)studyBuffer()[1]++;literal_buffer lits;')
 k='internalize(arg, true);';part=sub(part,k,'''unsigned before=get_num_bool_vars();if(studyInstance){auto v=studyBuffer();v[2]++;expr* child=arg;bool neg=m_manager.is_not(arg,child);if(!neg)child=arg;if(!m_manager.is_not(child)&&b_internalized(child)){v[3]++;if(neg)v[4]++;if(i==0)v[8]++;}else{v[7]++;all=false;}}internalize(arg,true);if(studyInstance)studyBuffer()[6]+=get_num_bool_vars()-before;''')
 part=sub(part,'mk_root_clause(lits.size()', 'if(studyInstance&&all)studyBuffer()[5]++;mk_root_clause(lits.size()')
 (w/'smt_internalizer.cpp').write_text(helper+'extern thread_local bool studyInstance;\n'+s[:a]+part+s[b:]);b=p.parent/'build'
 mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l)
 lib=w/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
 for n in ['qi_queue','smt_internalizer']:
  subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),'-I'+str(src),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',w/(n+'.o'),w/(n+'.cpp')],cwd=b,check=True)
  subprocess.run(['ar','r',lib,w/(n+'.o')],check=True)
 f=front/'smt/quantifier.go';overlay(f,sub(f.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
st=sub(st,'runtime.LockOSThread()','before:='+expr+';runtime.LockOSThread()')
st=sub(st,'runtime.UnlockOSThread()','runtime.UnlockOSThread();after:='+expr+';fmt.Fprintf(os.Stderr,"EVENT %d %d %s",batch,goal,phase);for i:=range after{fmt.Fprintf(os.Stderr," %d",after[i]-before[i])};fmt.Fprintln(os.Stderr)')
overlay(front/'phase_observer_trial.go',st)
ovpath=w/(mode+'.json');ovpath.write_text(json.dumps({'Replace':ov}));exe=w/mode
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off'+(',classic_z3' if mode=='native' else ''),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',ovpath,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');case='test/arm_rules3.ivy';ref=rank/'compat'/str((rank/'compat.txt').read_text().splitlines().index(case)+1)/'1/native'
with (w/(mode+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow(['round','batch','goal','phase',*names]);previous=None
 for i in range(3):
  mem=w/(mode+'.map');mem.write_bytes(bytes(4096))
  r=subprocess.run(['taskset','-c','14' if mode=='native' else '12',exe,ex/case],cwd=w,env=dict(os.environ,ARM_EVENT_FILE=str(mem),GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
  raw=[];rows=[]
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'EVENT '):rows.append(l.decode().split()[1:])
   elif not l.startswith(b'STAGE-COUNT '):raw.append(l)
  assert (r.returncode,r.stdout,b''.join(raw))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(r.returncode,r.stderr[-1200:])
  assert rows and (previous==None or previous==rows);previous=rows
  out.writerows([[i,*row] for row in rows]);f.flush()
