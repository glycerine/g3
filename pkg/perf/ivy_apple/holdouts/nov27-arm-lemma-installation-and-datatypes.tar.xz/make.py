from pathlib import Path
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-arm-events/events.py').read_text()
a=s.index('names=[');b=s.index('\ndef overlay',a);s=s[:a]+"names=['lemmas','ors','operands','bound','bound_negative','all_bound','new_vars','fresh_operands','first_bound']"+s[b:]
a=s.index(' src={');b=s.index('\nelse:',a)
s=s[:a]+''' f=p/'smtcore/smt_internalizer.go';t=f.read_text()
 k='return s.assertExpression(lemma, proof, instance.Generation(), arguments)';t=sub(t,k,'studyInstance=true;defer func(){studyInstance=false}();StudyEventCounts[0]++;'+k)
 a=t.index('func (s *SMTInternalizerState) assertExpression');h=t[:a];t=t[a:]
 k='literals := make([]SMTLiteral, len(arguments))';t=sub(t,k,'all:=true;if studyInstance{StudyEventCounts[1]++};'+k)
 k='for index, argument := range arguments {';t=sub(t,k,k+'if studyInstance {StudyEventCounts[2]++;lit,ok:=s.boundInstanceLiteral(argument);if ok{StudyEventCounts[3]++;if lit.Sign(){StudyEventCounts[4]++};if index==0{StudyEventCounts[8]++}}else{all=false;StudyEventCounts[7]++}};')
 k='if err = s.addRootClause(literals, proof);';t=sub(t,k,'if studyInstance&&all{StudyEventCounts[5]++};'+k)
 k='if err = s.Internalize(argument, true); err != nil {';a=t.index(k);t=t[:a]+t[a:].replace(k,'before:=len(s.boolExpr);err=s.Internalize(argument,true);if studyInstance{StudyEventCounts[6]+=uint64(len(s.boolExpr)-before)};if err!=nil{',1)
 overlay(f,h+t);overlay(p/'smtcore/study_event_counts.go','package smtcore\\nvar StudyEventCounts [9]uint64\\nvar studyInstance bool\\n')
'''+s[b:]
a=s.index(' for i,k in enumerate');b=s.index(' f=front/',a)
s=s[:a]+''' qsrc=(src/'qi_queue.cpp').read_text();k='m_context.internalize_instance(lemma, pr1, gen);'
 (w/'qi_queue.cpp').write_text('thread_local bool studyInstance=false;\\n'+sub(qsrc,k,'studyInstance=true;'+k+'studyInstance=false;'))
 s=(src/'smt_internalizer.cpp').read_text();a=s.index('void context::internalize_assertion(');b=s.index('case OP_IFF:',a);part=s[a:b]
 part=sub(part,'flet<unsigned> l','if(studyInstance)studyBuffer()[0]++;flet<unsigned> l')
 part=sub(part,'literal_buffer lits;','bool all=true;if(studyInstance)studyBuffer()[1]++;literal_buffer lits;')
 k='internalize(arg, true);';part=sub(part,k,\'''unsigned before=get_num_bool_vars();if(studyInstance){auto v=studyBuffer();v[2]++;expr* child=arg;bool neg=m_manager.is_not(arg,child);if(!neg)child=arg;if(!m_manager.is_not(child)&&b_internalized(child)){v[3]++;if(neg)v[4]++;if(i==0)v[8]++;}else{v[7]++;all=false;}}internalize(arg,true);if(studyInstance)studyBuffer()[6]+=get_num_bool_vars()-before;\''')
 part=sub(part,'mk_root_clause(lits.size()', 'if(studyInstance&&all)studyBuffer()[5]++;mk_root_clause(lits.size()')
 (w/'smt_internalizer.cpp').write_text(helper+'extern thread_local bool studyInstance;\\n'+s[:a]+part+s[b:]);b=p.parent/'build'
 mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l)
 lib=w/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
 for n in ['qi_queue','smt_internalizer']:
  subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),'-I'+str(src),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',w/(n+'.o'),w/(n+'.cpp')],cwd=b,check=True)
  subprocess.run(['ar','r',lib,w/(n+'.o')],check=True)
'''+s[b:]
(w/'run.py').write_text(s)
