from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go';s=f.read_text();k='return s.assertExpression(lemma, proof, instance.Generation(), arguments)'
s=s.replace(k,'''if proof.IsNull() && len(arguments)==0 {
   h,e:=s.manager.NodeHeader(lemma);if e!=nil{return e};if h.Kind==ast.ASTApp&&h.Family==s.manager.BasicFamilyID()&&h.DeclKind==ast.ASTOpOr{arguments,e=s.argumentHandles(lemma);if e!=nil{return e}}
  }
  if proof.IsNull() && len(arguments)>=2 {
 for i,arg:=range arguments{
  if _,found:=s.boundInstanceLiteral(arg);found{continue}
  h,neg,e:=s.signedStudyOperand(arg);if e!=nil{return e}
  op,basic,e:=s.basicOperation(h);if e!=nil{return e}
  if basic&&op==ast.ASTOpIff{
   ok,e:=s.assertExpandedStudyIff(arguments,i,h,neg,instance.Generation());if e!=nil||ok{return e}
  }
 }
 }
 '''+k)
s+='''
func (s *SMTInternalizerState) signedStudyOperand(a ast.ASTHandle)(ast.ASTHandle,bool,error){
 _,c,e:=s.manager.IsNot(a);if e!=nil{return a,false,e};if c.IsNull(){return a,false,nil};return c,true,nil
}
func (s *SMTInternalizerState) assertExpandedStudyIff(args []ast.ASTHandle,at int,eq ast.ASTHandle,negative bool,gen uint32)(bool,error){
 m:=s.manager
 var sides [2][]ast.ASTHandle
 for i:=0;i<2;i++{
  child,e:=m.GetArg(eq,uint32(i));if e!=nil{return false,e}
  or,neg,e:=s.signedStudyOperand(child);if e!=nil{return false,e};negative=negative!=neg
  h,e:=m.NodeHeader(or);if e!=nil{return false,e}
  if h.Kind!=ast.ASTApp||h.Family!=m.BasicFamilyID()||h.DeclKind!=ast.ASTOpOr||h.NumArgs<2||h.NumArgs>5{return false,nil}
  sides[i],e=s.argumentHandles(or);if e!=nil{return false,e}
 }
 if negative{return false,nil}
 for i,side:=range sides{
  for _,atom:=range side{
   not,e:=m.MkNotSimplified(atom);if e!=nil{return false,e};if e=m.IncRef(not);e!=nil{return false,e}
   terms:=make([]ast.ASTHandle,0,len(args)+len(sides[1-i]));terms=append(terms,args[:at]...);terms=append(terms,not);terms=append(terms,sides[1-i]...);terms=append(terms,args[at+1:]...)
   e=s.studyAssertClause(terms,gen);e=errors.Join(e,m.DecRef(not));if e!=nil{return true,e}
  }
 }
 return true,nil
}
func (s *SMTInternalizerState) studyAssertClause(terms []ast.ASTHandle,gen uint32)error{
 m:=s.manager;lemma,e:=m.MkOrArgs(terms);if e!=nil{return e};if e=m.IncRef(lemma);e!=nil{return e}
 e=s.assertExpression(lemma,ast.ASTHandle{},gen,nil);return errors.Join(e,m.DecRef(lemma))
}
'''
dst=w/'internalizer.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(8")'))
