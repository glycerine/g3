from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go'
s=(w.parent/'expand-all/internalizer.go.txt').read_text().replace('import (','import (\n"os"',1)
s=s.replace('if proof.IsNull() && len(arguments)==0 {','originalArgs:=arguments\n if studyRule!="base" && proof.IsNull() && len(arguments)==0 {')
s=s.replace('if proof.IsNull() && len(arguments)>=2 {','if (studyRule=="expand"||studyRule=="preserve") && proof.IsNull() && len(arguments)>=2 {')
s=s.replace('return s.assertExpression(lemma, proof, instance.Generation(), arguments)','if studyRule=="preserve"{arguments=originalArgs};return s.assertExpression(lemma, proof, instance.Generation(), arguments)')
s+='\nvar studyRule=os.Getenv("STUDY_RULE")\n'
dst=w/'internalizer.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace('modes[m],ex/name',"w/'release',ex/name").replace("GOMAXPROCS='1'","STUDY_RULE=m,GOMAXPROCS='1'")
exec(script)
run(16,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],11,['base','reuse','expand','preserve'])
