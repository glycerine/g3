from pathlib import Path
w=Path(__file__).resolve().parent;ov=w/'trial.json';s=Path('/tmp/g3-card-install/volume_release_long.py').read_text().replace("'-o',w/'volume-release-apple'","'-overlay',ov,'-o',w/'apple'").replace('range(3)','range(2)').replace("('base','release')","('base','preserve')").replace('ACTION_SCOPE=mode,CARD_MODE=mode','STUDY_RULE=mode')
a=s.index('    exe=((');b=s.index('\n',a);s=s[:a]+"    exe=w/('apple' if apple else 'release')"+s[b:]
exec(s)
