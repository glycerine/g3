from pathlib import Path
import subprocess,csv,concurrent.futures,os,json
p=Path.cwd();w=Path(__file__).resolve().parent;f=p/'smtcore/smt_internalizer.go';s=(w.parent/'binary-expand/internalizer.go.txt').read_text();k='for i,side:=range sides{';assert s.count(k)==1;d=w/'internalizer.go.txt';d.write_text(s.replace(k,'println("EXPAND",len(sides[0]),len(sides[1]));'+k));ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(d)}}))
orig=Path('/tmp/g3-or-install/final/release.py').read_text().split("modes={")[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'");exec(orig)
abc=w/'abc'
if not abc.exists():abc.symlink_to('/tmp/g3-frame-child/abc')
def check(job):
 i,case=job;gold=rank/'compat'/str(i+1)/'1/native';r=subprocess.run([w/'release',ex/case],env=dict(os.environ,GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=h,capture_output=True,timeout=180)
 lines=r.stderr.splitlines(keepends=True);obs=[l for l in lines if l.startswith(b'EXPAND ')];raw=b''.join(l for l in lines if not l.startswith(b'EXPAND '))
 assert (r.returncode,r.stdout,raw)==(codes[case],(gold/'stdout').read_bytes(),(gold/'stderr').read_bytes()),case
 return [case,len(obs),sum(sum(map(int,l.split()[1:])) for l in obs)]
with (w/'observed.csv').open('w') as f,concurrent.futures.ThreadPoolExecutor(8) as pool:
 o=csv.writer(f);o.writerow(['case','expansions','clauses'])
 for row in pool.map(check,enumerate(cases)):o.writerow(row);f.flush()
