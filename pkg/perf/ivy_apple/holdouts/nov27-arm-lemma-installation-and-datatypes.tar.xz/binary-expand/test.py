from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go'
s=(w.parent/'expand-all/internalizer.go.txt').read_text()
a=s.index('if proof.IsNull() && len(arguments)==0');b=s.index('return s.assertExpression(lemma, proof, instance.Generation(), arguments)',a)
s=s[:a]+'''if proof.IsNull() && arguments==nil{
 h,e:=s.manager.NodeHeader(lemma);if e!=nil{return e}
 if h.Kind==ast.ASTApp && h.Family==s.manager.BasicFamilyID() && h.DeclKind==ast.ASTOpOr && h.NumArgs==2{
   rhs,e:=s.manager.GetArg(lemma,1);if e!=nil{return e}
   if _,found:=s.boundInstanceLiteral(rhs);!found{
    eq,neg,e:=s.signedStudyOperand(rhs);if e!=nil{return e}
    h,e:=s.manager.NodeHeader(eq);if e!=nil{return e}
    if h.Kind==ast.ASTApp && h.Family==s.manager.BasicFamilyID() && h.DeclKind==ast.ASTOpIff{
     guard,e:=s.manager.GetArg(lemma,0);if e!=nil{return e}
     run,e:=s.assertExpandedStudyIff([]ast.ASTHandle{guard,rhs},1,eq,neg,instance.Generation());if e!=nil||run{return e}
    }
   }
 }
 }
 '''+s[b:]
dst=w/'internalizer.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(14")'))
