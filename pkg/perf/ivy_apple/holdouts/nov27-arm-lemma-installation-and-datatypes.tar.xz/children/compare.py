from pathlib import Path
import statistics as st,csv
from collections import defaultdict
w=Path(__file__).resolve().parent
with (w/'summary.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['scope','kind','g3_calls','native_calls','g3_M','native_M','gap_M'])
 for goal in ['all','5','6']:
  by=defaultdict(dict)
  for m in ['g3','native']:
   d=defaultdict(lambda:defaultdict(lambda:[0,0]))
   for r in csv.DictReader((w/(m+'-shapes.csv')).open()):
    if goal!='all' and (r['batch']!='6' or r['goal']!=goal or r['phase']!='check'):continue
    v=d[r['shape']][r['round']];v[0]+=int(r['count']);v[1]+=int(r['net'])
   for k,rs in d.items():
    assert len(rs)==3 and len(set(v[0] for v in rs.values()))==1
    by[k][m]=next(iter(rs.values()))[0],st.median(v[1] for v in rs.values())/1e6
  for k,vs in by.items():
   (n,a),(j,b)=vs.get('g3',(0,0)),vs.get('native',(0,0));out.writerow([goal,k,n,j,round(a,3),round(b,3),round(a-b,3)])
