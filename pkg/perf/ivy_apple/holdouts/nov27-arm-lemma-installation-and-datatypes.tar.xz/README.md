# Live lemma installation and datatype costs

Study baseline g3 c328dc1db. The count release is db3d9261b. The split release is 450b4dd06. See pkg/PERF_STUDY.md for interpreted results. All overlays are research tools for this checkout. CSVs are retained so that analysis needs neither perf permissions nor the external verifier corpora.

From pkg run the committed benchmarks with:

    go test ./smtcore -run '^$' -bench 'BenchmarkSMT(ScopedEnumTerm|EnumSplitAfterFalsePreference)$' -benchtime=5000x -count=7 -cpu=1

For the exact historical microbenchmarks, count/bench.py uses 2000 iterations and nextsplit/benchbuild.py uses 5000. base/count denote before/after within each measurement. Compile a test binary for each revision using the same benchmark source. Pass the binaries as base.test and count.test. Each perf interval includes startup and setup. CPU 18 was pinned.

For the verifier studies the original working root was /tmp/g3-live-literals. Run from pkg using the indicated baseline. Paths to the GoIvy frontend, native build, corpus, cached native transcripts, perf executable and CPU numbers in the drivers are host-specific. Use the same frontend and compiler profile for both sides. The supporting release driver, stage observer, translations and survey case list are included under support. The previous nov27-arm-search-volume-and-cost archive describes the original stage harness. Compiled programs and verifier dependencies are external inputs.

run.py g3 and run.py native generate the top-level operand census. Subdirectories price, shapes, iff, children, orphase, grandchildren, names and count-priced contain successive probe refinements. Use their final run.py files directly. Probes are independent builds. Measurements containing child probes can include instrumentation overhead. Reads for adjacent empty intervals are retained in the raw data.

panels.py computes median paired changes from matching runs in whole.csv and long runs. Individual release drivers record transcript status. count and nextsplit survey files cover the 228 native comparisons for each release. nextsplit/head-native.csv contains the final direct comparison. inventory/observed.csv gives the broad rewrite eligibility census. Some archived prototype trials explicitly record different output or timeouts. They are historical observations, not verification of production code.
