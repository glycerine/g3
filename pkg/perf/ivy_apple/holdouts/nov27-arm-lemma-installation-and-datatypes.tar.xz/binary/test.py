from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_qi_instance.go';s=f.read_text();k='lemma, err = b.manager.MkOr(negatedQuantifier, simplified)';assert s.count(k)==1;s=s.replace(k,k+';if arguments!=nil && err==nil{*arguments=[]ast.ASTHandle{negatedQuantifier,simplified}}')
dst=w/'internalizer.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(6")'))
