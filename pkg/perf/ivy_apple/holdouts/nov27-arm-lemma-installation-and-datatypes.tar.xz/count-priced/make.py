from pathlib import Path
w=Path(__file__).resolve().parent;b=w.parent/'names';s=(b/'run.py').read_text().replace("ovpath=w/(mode+'.json')","ov.update(json.loads((w.parent/'count/trial.json').read_text())['Replace']);ovpath=w/(mode+'.json')")
(w/'read.go.txt').write_text((b/'read.go.txt').read_text());(w/'run.py').write_text(s)
