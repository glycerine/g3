from pathlib import Path
import subprocess,csv,re
w=Path(__file__).resolve().parent;perf='/usr/lib/linux-tools/6.17.0-35-generic/perf'
with (w/'bench.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['width','round','mode','instructions','ns','bytes','allocs'])
 for width in [4,16,64]:
  for i in range(7):
   for mode in ['base','count'][::1 if i%2==0 else -1]:
    stat=w/'bench.stat';r=subprocess.run(['taskset','-c','18',perf,'stat','-x,','-o',stat,'-e','instructions:u','--',w/(mode+'.test'),'-test.run','^$','-test.bench','^BenchmarkSMTScopedEnumTerm$/^constructors='+str(width)+'$','-test.benchtime','2000x','-test.cpu','1'],text=True,capture_output=True,check=True)
    match=re.search(r'2000\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',r.stdout);assert match,r.stdout
    n=next(x[0] for x in csv.reader(stat.open()) if len(x)>4 and x[2]=='instructions:u' and float(x[4])==100)
    o.writerow([width,i,mode,n,*match.groups()]);f.flush()
