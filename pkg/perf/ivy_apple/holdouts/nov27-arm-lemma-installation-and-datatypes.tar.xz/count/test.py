from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();rep={}
def save(f,s):
 d=w/(f.name+'.txt');d.write_text(s);rep[str(f)]=str(d)
f=p/'smtcore/theory_datatype.go';s=f.read_text();a=s.index('func (t *SMTDatatypeTheory) initializeVariable');h,t=s[:a],s[a:]
t=t.replace('constructors, err := state.manager.DatatypeConstructors(sort)','count, err := state.manager.DatatypeNumConstructors(sort)',1).replace('if len(constructors) == 1 {','if count == 1 {\n constructors,err:=state.manager.DatatypeConstructors(sort);if err!=nil{return err}',1);save(f,h+t)
f=p/'smtcore/theory_datatype_metadata.go';s=f.read_text();a=s.index('sort, err :=',s.index('func (t *SMTDatatypeTheory) addRecognizer'));b=s.index('index, matched, err',a)
s=s[:a]+'''if len(data.recognizers) == 0 {
		sort, err := s.manager.GetSort(recognizer.arguments[0].owner)
		if err != nil { return err }
		count, err := s.manager.DatatypeNumConstructors(sort)
		if err != nil { return err }
		data.recognizers = make([]*SMTEnode,count)
	}
	'''+s[b:]
s=s.replace('if data.constructor.declaration == constructors[index] {','constructor,matched,err:=s.manager.DatatypeRecognizerConstructor(recognizer.declaration);if err!=nil{return err};if !matched{return ast.ErrASTDomain};if data.constructor.declaration == constructor {');save(f,s)
ov=w/'trial.json';ov.write_text(json.dumps({'Replace':rep}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(20")'))
