from pathlib import Path
w=Path(__file__).resolve().parent
for name,src,cpu in [('binary','gate',6),('expand-all','expand',8),('distribute-all','distribute',20)]:
 s=(w/src/'test.py').read_text()
 if name=='binary':
  a=s.index("f=p/'smtcore/");b=s.index("dst=w/",a);s=s[:a]+"""f=p/'smtcore/smt_qi_instance.go';s=f.read_text();k='lemma, err = b.manager.MkOr(negatedQuantifier, simplified)';assert s.count(k)==1;s=s.replace(k,k+';if arguments!=nil && err==nil{*arguments=[]ast.ASTHandle{negatedQuantifier,simplified}}')
"""+s[b:]
 else:
  s=s.replace('if proof.IsNull() && len(arguments)>=2 {','''if proof.IsNull() && len(arguments)==0 {
   h,e:=s.manager.NodeHeader(lemma);if e!=nil{return e};if h.Kind==ast.ASTApp&&h.Family==s.manager.BasicFamilyID()&&h.DeclKind==ast.ASTOpOr{arguments,e=s.argumentHandles(lemma);if e!=nil{return e}}
  }
  if proof.IsNull() && len(arguments)>=2 {''')
 s=s.replace('run(18','run('+str(cpu)).replace('run(14','run('+str(cpu)).replace('run(10','run('+str(cpu))
 (w/name/'test.py').write_text(s)
