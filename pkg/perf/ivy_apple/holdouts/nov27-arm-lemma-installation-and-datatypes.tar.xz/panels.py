from pathlib import Path
from collections import defaultdict
import statistics as s,csv
w=Path(__file__).resolve().parent
with (w/'panels.csv').open('w') as f:
 o=csv.writer(f);o.writerow(['study','input','candidate','complete_pairs','matches','failed_runs','instructions_percent','time_percent'])
 for file in sorted([*w.glob('*/whole.csv'),*w.glob('*/volume-release-long-*.csv')]):
  d=defaultdict(lambda:defaultdict(dict))
  for r in csv.DictReader(file.open()):d[r['case']][r['round']][r['mode']]=r
  for name,vs in d.items():
   for m in sorted({k for v in vs.values() for k in v}-{'base'}):
    records=[r[k] for r in vs.values() for k in ['base',m] if k in r]
    pairs=[r for r in vs.values() if m in r and 'base' in r and r[m]['status']==r['base']['status']=='match']
    if not pairs:continue
    o.writerow([file.parent.name,name,m,len(pairs),sum(r['status']=='match' for r in records),sum(r['status']!='match' for r in records),*[round(s.median(100*(float(r[m][k])/float(r['base'][k])-1) for r in pairs),2) for k in ['instructions','ms']]])
