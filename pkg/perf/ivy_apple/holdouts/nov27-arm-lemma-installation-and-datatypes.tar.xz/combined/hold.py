from pathlib import Path
import concurrent.futures
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-or-install/final/release.py').read_text().split("run(12,")[0];s=s[:s.index('subprocess.run([*flags')]+s[s.index('modes={'):];s=s.replace("Path('/tmp/g3-card-install/volume-release')","w.parent/'count/release'");exec(s)
cases=['test/flash_cubicle.ivy','doc/examples/window.ivy','test/learning_switch1.ivy','test/vsync_paxos.ivy','doc/examples/sht/trans_test.ivy','test/whilesome2.ivy']
with concurrent.futures.ThreadPoolExecutor(3) as pool:
 jobs=[pool.submit(run,2+4*i,'hold'+str(i),cases[i::3],11,['base','release']) for i in range(3)]
 for j in jobs:j.result()
