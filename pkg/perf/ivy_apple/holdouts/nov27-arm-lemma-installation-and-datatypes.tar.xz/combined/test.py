from pathlib import Path
import concurrent.futures
w=Path(__file__).resolve().parent;ov=w.parent/'binary-expand/trial.json';s=Path('/tmp/g3-or-install/final/release.py').read_text().split("run(12,")[0].replace("Path('/tmp/g3-card-install/volume-release')","w.parent/'count/release'").replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'")
exec(s)
abc=w/'abc'
if not abc.exists():abc.symlink_to('/tmp/g3-frame-child/abc')
cpus=[0,2,4,6,8,10,12,14]
with concurrent.futures.ThreadPoolExecutor(9) as pool:
 jobs=[pool.submit(run,cpu,'survey'+str(i),cases[i::len(cpus)],1,['release','base'] if i%2 else ['base','release']) for i,cpu in enumerate(cpus)]
 jobs.append(pool.submit(run,18,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],11,['base','release']))
 for j in jobs:j.result()
