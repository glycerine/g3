from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_relevancy_asserted_or.go';s=f.read_text();old='for _, child := range args {\n\t\tif err := p.addLiteralWatch(child, true, &handler);';new='''for i, child := range args {
        positive:=!literals[i].Sign()
        if !positive { child=p.internalizer.boolExpr[literals[i].Var()] }
        if err := p.addWatch(child, positive, &handler);'''
assert old in s;dst=w/'watches.go.txt';dst.write_text(s.replace(old,new));ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().replace("Path('/tmp/g3-card-install/volume-release')","Path('/tmp/g3-arm-events/identity/release')").replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace("],7,['base','release']", "],11,['base','release']")
exec(compile(script,__file__,'exec'))
