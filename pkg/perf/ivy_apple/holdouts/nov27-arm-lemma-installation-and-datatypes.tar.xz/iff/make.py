from pathlib import Path
w=Path(__file__).resolve().parent;src=w.parent/'shapes';s=(src/'run.py').read_text()
s=s.replace('var studyInstance bool\\nfunc studyOperand','var studyInstance bool\\nvar target ast.ASTHandle\\nfunc studyOperand')
s=s.replace("(w/'read.go.txt').read_text()","(w/'read.go.txt').read_text().replace('import(', 'import(\"github.com/glycerine/g3/pkg/ast\";')") if False else s
s=s.replace('kind="iff";','kind="iff";target=expr;').replace('studyOperand(kind,tick)','studyOperand(kind,tick);target=ast.ASTHandle{}')
k=' overlay(f,h+t);';i=s.index(k)
s=s[:i]+''' h=sub(h,'for index := uint32(0); index < count; index++ {\\n\\t\\targument, err := s.manager.GetArg(expression, index)','var tick uint64;direct:=studyInstance&&expression==target;if direct{tick=freshRead()};for index := uint32(0); index < count; index++ {\\n\\t\\targument, err := s.manager.GetArg(expression, index)')
 h=sub(h,'variable, isNew := s.boolVar.lookup(expression)','if direct{studyOperand("iff-children",tick);tick=freshRead()};variable, isNew := s.boolVar.lookup(expression)')
 h=sub(h,'if err = s.addGateConstraints(expression, op);','if direct{studyOperand("iff-variable",tick);tick=freshRead()};if err = s.addGateConstraints(expression, op);')
 h=sub(h,'return fmt.Errorf("internalize formula gate constraints: %w", err)\\n\\t\\t}','return fmt.Errorf("internalize formula gate constraints: %w", err)\\n\\t\\t};if direct{studyOperand("iff-gate",tick)}')
'''+s[i:]
s=s.replace('case OP_IFF:kind="iff";','case OP_IFF:kind="iff";target=child;').replace('fprintf(stderr,"OPERAND %s %llu %llu','target=nullptr;fprintf(stderr,"OPERAND %s %llu %llu')
k=" (w/'smt_internalizer.cpp').write_text";i=s.index(k);s=s[:i]+''' tail=s[b:];helper+='static thread_local void* target=nullptr;static void measure(const char*k,unsigned long long t){auto v=freshRead()-t;auto a=freshRead();auto e=freshRead()-a;fprintf(stderr,"OPERAND %s %llu %llu\\\\n",k,v,e);}'
 a2=tail.index('void context::internalize_formula_core(');pre=tail[:a2];core=tail[a2:];core=core.replace('// process args','bool direct=studyInstance&&n==target;unsigned long long tick=direct?freshRead():0;// process args',1).replace('bool is_new_var = false;','if(direct){measure("iff-children",tick);tick=freshRead();}bool is_new_var = false;',1).replace('mk_iff_cnstr(to_app(n));','if(direct){measure("iff-variable",tick);tick=freshRead();}mk_iff_cnstr(to_app(n));if(direct)measure("iff-gate",tick);',1)
'''+s[i:];s=s.replace("+s[:a]+part+s[b:]","+s[:a]+part+pre+core")
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt','compare.py']:(w/n).write_text((src/n).read_text())
f=w/'read.go.txt';f.write_text(f.read_text().replace('import(', 'import("github.com/glycerine/g3/pkg/ast";'))
