"""Generate observational overlays for both engines. Run from pkg."""
from pathlib import Path
import csv,json,os,subprocess,sys,re,shlex,shutil
w=Path(__file__).resolve().parent;p=Path.cwd();mode=sys.argv[1]
front=(p/'build/.boolean-enode-cost/frontend/goivy').resolve(); prior=Path('/tmp/g3-ticket-stages')
ov=json.loads((prior/'translated.json').read_text())['Replace']
names=['lemmas','ors','operands','bound','bound_negative','all_bound','new_vars','fresh_operands','first_bound']
def overlay(f,s):
 dst=w/(mode+'-'+f.name+('' if f.name=='quantifier.go' else '.txt'));dst.write_text(s);ov[str(f)]=str(dst)
def sub(s,k,z):
 assert s.count(k)==1,(k,s.count(k));return s.replace(k,z)
st=(prior/'stage.go.txt').read_text()
if mode=='g3':
 st=st.replace('import (','import (\n"github.com/glycerine/g3/pkg/smtcore"')
 expr='smtcore.StudyEventCounts'
 f=p/'smtcore/smt_internalizer.go';t=f.read_text()
 k='return s.assertExpression(lemma, proof, instance.Generation(), arguments)';t=sub(t,k,'studyInstance=true;defer func(){studyInstance=false}();StudyEventCounts[0]++;'+k)
 a=t.index('func (s *SMTInternalizerState) assertExpression');h=t[:a];t=t[a:]
 k='for index, argument := range arguments {';t=sub(t,k,k+'''var tick uint64;kind:="bound";if studyInstance{if _,ok:=s.boundInstanceLiteral(argument);!ok{expr:=argument;_,child,e:=s.manager.IsNot(expr);if e!=nil{panic(e)};if !child.IsNull(){expr=child};header,e:=s.manager.NodeHeader(expr);if e!=nil{panic(e)};kind="theory";if header.Kind==ast.ASTQuantifier{kind="quant"}else if header.Family==ast.NullFamilyID{kind="predicate"}else if header.Family==s.manager.BasicFamilyID(){switch header.DeclKind{case ast.ASTOpEq:kind="eq";case ast.ASTOpIff:kind="iff";target=expr;case ast.ASTOpAnd:kind="and";case ast.ASTOpOr:kind="or";case ast.ASTOpIte:kind="ite";default:kind="other-basic"}}};tick=freshRead()};''')
 k='literals[index] = literal';t=sub(t,k,k+';if studyInstance{studyOperand(kind,tick);target=ast.ASTHandle{}}')
 k='literals[index], err = s.Literal(argument)';t=sub(t,k,k+';if studyInstance{studyOperand(kind,tick);target=ast.ASTHandle{}}')
 h=sub(h,'for index := uint32(0); index < count; index++ {\n\t\targument, err := s.manager.GetArg(expression, index)','var tick uint64;direct:=studyInstance&&expression==target;if direct{tick=freshRead()};for index := uint32(0); index < count; index++ {\n\t\targument, err := s.manager.GetArg(expression, index)')
 h=sub(h,'variable, isNew := s.boolVar.lookup(expression)','if direct{studyOperand("iff-children",tick);tick=freshRead()};variable, isNew := s.boolVar.lookup(expression)')
 h=sub(h,'if err = s.addGateConstraints(expression, op);','if direct{studyOperand("iff-variable",tick);tick=freshRead()};if err = s.addGateConstraints(expression, op);')
 h=sub(h,'return fmt.Errorf("internalize formula gate constraints: %w", err)\n\t\t}','return fmt.Errorf("internalize formula gate constraints: %w", err)\n\t\t};if direct{studyOperand("iff-gate",tick)}')
 overlay(f,h+t);overlay(p/'smtcore/study_event_counts.go',(w/'read.go.txt').read_text()+'\nvar studyInstance bool\nvar target ast.ASTHandle\nfunc studyOperand(k string,t uint64){v:=freshRead()-t;a:=freshRead();e:=freshRead()-a;println("OPERAND",k,v,e)}\n')

else:
 expr='studyRead()'
 st+='''
func studyRead() (v [9]uint64) {
 b,e:=os.ReadFile(os.Getenv("ARM_EVENT_FILE"));if e!=nil{panic(e)}
 for i:=range v {v[i]=binary.LittleEndian.Uint64(b[8*i:])};return
}
'''
 st=st.replace('import (','import (\n"encoding/binary"')
 b=p.parent/'build';src=p.parent/'src/smt';s=(src/'smt_context.cpp').read_text()
 helper='''
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdlib>
static unsigned long long* studyBuffer(){
 static auto p=[](){int fd=open(getenv("ARM_EVENT_FILE"),O_RDWR);if(fd<0)abort();
 void* ptr=mmap(nullptr,4096,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);if(ptr==MAP_FAILED)abort();close(fd);
 return static_cast<unsigned long long*>(ptr);}();return p;
}
'''
 qsrc=(src/'qi_queue.cpp').read_text();k='m_context.internalize_instance(lemma, pr1, gen);'
 (w/'qi_queue.cpp').write_text('thread_local bool studyInstance=false;\n'+sub(qsrc,k,'studyInstance=true;'+k+'studyInstance=false;'))
 s=(src/'smt_internalizer.cpp').read_text();a=s.index('void context::internalize_assertion(');b=s.index('case OP_IFF:',a);part=s[a:b]
 helper+=(w/'read.cpp.txt').read_text()
 k='internalize(arg, true);';part=sub(part,k,'''unsigned long long tick=0;const char* kind="bound";if(studyInstance){expr* child=nullptr;if(!m_manager.is_not(arg,child))child=arg;if(m_manager.is_not(child)||!b_internalized(child)){kind="theory";if(is_quantifier(child))kind="quant";else if(is_app(child)){app* ap=to_app(child);if(ap->get_family_id()==null_family_id)kind="predicate";else if(ap->get_family_id()==m_manager.get_basic_family_id()){switch(ap->get_decl_kind()){case OP_EQ:kind="eq";break;case OP_IFF:kind="iff";target=child;break;case OP_AND:kind="and";break;case OP_OR:kind="or";break;case OP_ITE:kind="ite";break;default:kind="other-basic";}}}}tick=freshRead();}internalize(arg,true);''')
 k='lits.push_back(get_literal(arg));';part=sub(part,k,k+'if(studyInstance){auto v=freshRead()-tick;auto a=freshRead();auto e=freshRead()-a;target=nullptr;fprintf(stderr,"OPERAND %s %llu %llu\\n",kind,v,e);}')
 tail=s[b:];helper+='static thread_local void* target=nullptr;static void measure(const char*k,unsigned long long t){auto v=freshRead()-t;auto a=freshRead();auto e=freshRead()-a;fprintf(stderr,"OPERAND %s %llu %llu\\n",k,v,e);}'
 a2=tail.index('void context::internalize_formula_core(');pre=tail[:a2];core=tail[a2:];core=core.replace('// process args','bool direct=studyInstance&&n==target;unsigned long long tick=direct?freshRead():0;// process args',1).replace('bool is_new_var = false;','if(direct){measure("iff-children",tick);tick=freshRead();}bool is_new_var = false;',1).replace('mk_iff_cnstr(to_app(n));','if(direct){measure("iff-variable",tick);tick=freshRead();}mk_iff_cnstr(to_app(n));if(direct)measure("iff-gate",tick);',1)
 (w/'smt_internalizer.cpp').write_text(helper+'extern thread_local bool studyInstance;\n'+s[:a]+part+pre+core);b=p.parent/'build'
 mk=(b/'Makefile').read_text();conf=dict(l.split('=',1) for l in (b/'config.mk').read_text().splitlines() if '=' in l)
 lib=w/'libz3.a';shutil.copyfile(front/'z3vendor/native_lib/libz3.a',lib)
 for n in ['qi_queue','smt_internalizer']:
  subprocess.run([conf['CXX'],*shlex.split(conf['CXXFLAGS']),'-I'+str(src),*shlex.split(re.search('^includes_39 = (.*)$',mk,re.M)[1]),'-o',w/(n+'.o'),w/(n+'.cpp')],cwd=b,check=True)
  subprocess.run(['ar','r',lib,w/(n+'.o')],check=True)
 f=front/'smt/quantifier.go';overlay(f,sub(f.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(lib)))
st=sub(st,'runtime.LockOSThread()','before:='+expr+';runtime.LockOSThread()')
st=sub(st,'runtime.UnlockOSThread()','runtime.UnlockOSThread();after:='+expr+';fmt.Fprintf(os.Stderr,"EVENT %d %d %s",batch,goal,phase);for i:=range after{fmt.Fprintf(os.Stderr," %d",after[i]-before[i])};fmt.Fprintln(os.Stderr)')
overlay(front/'phase_observer_trial.go',st)
ovpath=w/(mode+'.json');ovpath.write_text(json.dumps({'Replace':ov}));exe=w/mode
subprocess.run(['go','build','-mod=readonly','-modfile',(p/'build/.boolean-enode-cost/heap/study.mod').resolve(),'-buildvcs=false','-tags','xtrace_off'+(',classic_z3' if mode=='native' else ''),'-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-overlay',ovpath,'-o',exe,'./cmd/goivy_check'],cwd=front,check=True)
ex=Path('/home/jaten/ivy/ivy-lang-examples');rank=Path('/tmp/g3-reduction-rows');case='test/arm_rules3.ivy';ref=rank/'compat'/str((rank/'compat.txt').read_text().splitlines().index(case)+1)/'1/native'
with (w/(mode+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow(['round','batch','goal','phase',*names]);previous=None
 out2=csv.writer((w/(mode+'-shapes.csv')).open('w'));out2.writerow(['round','batch','goal','phase','shape','count','net']);from collections import Counter
 for i in range(3):
  mem=w/(mode+'.map');mem.write_bytes(bytes(4096))
  r=subprocess.run(['taskset','-c','14' if mode=='native' else '12',exe,ex/case],cwd=w,env=dict(os.environ,ARM_EVENT_FILE=str(mem),GOMAXPROCS='1',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),capture_output=True,timeout=180)
  raw=[];rows=[];n=Counter();cost=Counter()
  for l in r.stderr.splitlines(keepends=True):
   if l.startswith(b'OPERAND '):
    _,k,v,e=l.decode().split();n[k]+=1;cost[k]+=int(v)-int(e)
   elif l.startswith(b'EVENT '):
    row=l.decode().split()[1:];rows.append(row);out2.writerows([i,*row[:3],k,n[k],cost[k]] for k in sorted(n));n.clear();cost.clear()
   elif not l.startswith(b'STAGE-COUNT '):raw.append(l)
  assert (r.returncode,r.stdout,b''.join(raw))==(0,(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(r.returncode,r.stderr[-1200:])
  assert rows and (previous==None or previous==rows);previous=rows
  out.writerows([[i,*row] for row in rows]);f.flush()
