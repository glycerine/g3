from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go';s=f.read_text();k='arguments, err := s.argumentLiterals(expression)';assert s.count(k)==1
s=s.replace(k,'''gate:=s.boolGate(variable)
	var arguments []SMTLiteral
	var err error
	if gate!=nil{
		arguments=make([]SMTLiteral,len(gate.args))
		for i,arg:=range gate.args{
			lit,found:=s.boundInstanceLiteral(arg)
			if !found{
				lit,err=s.Literal(arg)
				if err!=nil{return err}
			}
			arguments[i]=lit
		}
	}else{
		arguments,err=s.argumentLiterals(expression)
	}''').replace('if gate := s.boolGate(variable); gate != nil {\n\t\t// Children','if gate != nil {\n\t\t// Children')
dst=w/'internalizer.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(18")'))
