from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go';s=f.read_text();k='return s.assertExpression(lemma, proof, instance.Generation(), arguments)';assert s.count(k)==1
s=s.replace(k,'''if proof.IsNull() && len(arguments)>=2 {
		for i, arg := range arguments {
			if _, found := s.boundInstanceLiteral(arg); found { continue }
			expr:=arg
			_,child,err:=s.manager.IsNot(arg);if err!=nil{return err}
			negative:=!child.IsNull();if negative{expr=child}
			op,basic,err:=s.basicOperation(expr);if err!=nil{return err}
			if basic && op==ast.ASTOpIff {
				return s.assertDistributedInstance(arguments,i,expr,negative,instance.Generation())
			}
		}
	}
	'''+k)
s+='''
func (s *SMTInternalizerState) assertDistributedInstance(args []ast.ASTHandle,index int,iff ast.ASTHandle,neg bool,generation uint32)(ret error){
 m:=s.manager
 a,err:=m.GetArg(iff,0);if err!=nil{return err};b,err:=m.GetArg(iff,1);if err!=nil{return err}
 na,err:=m.MkNotSimplified(a);if err!=nil{return err};if err=m.IncRef(na);err!=nil{return err};defer func(){ret=errors.Join(ret,m.DecRef(na))}()
 nb,err:=m.MkNotSimplified(b);if err!=nil{return err};if err=m.IncRef(nb);err!=nil{return err};defer func(){ret=errors.Join(ret,m.DecRef(nb))}()
 if neg{b,nb=nb,b}
 pairs:=[2][2]ast.ASTHandle{{na,b},{a,nb}}
 for _,pair:=range pairs{
  lits:=make([]ast.ASTHandle,0,len(args)+1);lits=append(lits,args[:index]...);lits=append(lits,pair[:]...);lits=append(lits,args[index+1:]...)
  lemma,err:=m.MkOrArgs(lits);if err!=nil{return err};if err=m.IncRef(lemma);err!=nil{return err}
  err=s.assertExpression(lemma,ast.ASTHandle{},generation,nil);err=errors.Join(err,m.DecRef(lemma));if err!=nil{return err}
 }
 return nil
}
'''
s=s.replace('defer func(){ret=errors.Join(ret,m.DecRef(nb))}()','defer func(h ast.ASTHandle){ret=errors.Join(ret,m.DecRef(h))}(nb)')
dst=w/'internalizer.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(14")'))
