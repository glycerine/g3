from pathlib import Path
w=Path(__file__).resolve().parent;base=Path('/tmp/g3-arm-events/regions');s=(w.parent/'run.py').read_text()
a=s.index(" k='literals :=");b=s.index('\nelse:',a)
s=s[:a]+''' k='literals := make([]SMTLiteral, len(arguments))';t=sub(t,k,'var tick uint64;if studyInstance{studyEnd(3,freshRead());tick=freshRead()};'+k)
 k='if err = s.addRootClause(literals, proof);';t=sub(t,k,'if studyInstance{studyEnd(0,tick);tick=freshRead()};'+k)
 k='if err = s.relevancy.addAssertedOrWatches';t=sub(t,k,'if studyInstance{studyEnd(1,tick);tick=freshRead()};'+k)
 k='case ast.ASTOpIff:';t=t.replace(k,'if studyInstance{studyEnd(2,tick)};'+k,1)
 t=t.replace('StudyEventCounts[0]++;return s.assertExpression','return s.assertExpression')
 overlay(f,h+t);overlay(p/'smtcore/study_event_counts.go',(w/'read.go.txt').read_text()+'\\nvar studyInstance bool\\n')
'''+s[b:]
a=s.index(" part=sub(part,'flet");b=s.index(" (w/'smt_internalizer.cpp')",a)
s=s[:a]+''' helper+=(w/'read.cpp.txt').read_text()
 part=sub(part,'literal_buffer lits;','unsigned long long tick=0;if(studyInstance){endStudy(3,freshRead());tick=freshRead();}literal_buffer lits;')
 part=sub(part,'mk_root_clause(lits.size()', 'if(studyInstance){endStudy(0,tick);tick=freshRead();}mk_root_clause(lits.size()')
 part=sub(part,'add_or_rel_watches(to_app(n));','if(studyInstance){endStudy(1,tick);tick=freshRead();}add_or_rel_watches(to_app(n));if(studyInstance)endStudy(2,tick);')
'''+s[b:]
s=s.replace("assert rows and (previous==None or previous==rows)","assert rows and (previous==None or [r[:3]+r[7:] for r in previous]==[r[:3]+r[7:] for r in rows])")
s=s.replace('StudyEventCounts[0]++;','') if False else s
# The global instance wrapper lives in the source prefix.
s=s.replace("studyInstance=false}();StudyEventCounts[0]++;","studyInstance=false}();")
a=s.index('names=[');b=s.index('\ndef overlay',a);s=s[:a]+"names=['operands','root','watches','empty','operands_calls','root_calls','watches_calls','empty_calls','unused']"+s[b:]
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt']:(w/n).write_text((base/n).read_text())
(w/'compare.py').write_text((base/'compare.py').read_text().replace("'detach','reinsert','undo'","'operands','root','watches'"))
