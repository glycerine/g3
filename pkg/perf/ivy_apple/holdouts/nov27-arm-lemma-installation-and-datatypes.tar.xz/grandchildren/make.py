from pathlib import Path
w=Path(__file__).resolve().parent;b=w.parent/'orphase';s=(b/'run.py').read_text()
s=s.replace('var shape string;if outer','var shape string;if direct').replace('shape="child-or";subtarget=expr;','shape="child-or";if outer{subtarget=expr};').replace('if outer{studyOperand(shape,childTick);subtarget=ast.ASTHandle{}}','if inner{studyOperand(shape,childTick)};if outer{subtarget=ast.ASTHandle{}}')
s=s.replace('const char* shape="child-theory";if(outer)','const char* shape="child-theory";if(direct)').replace('shape="child-or";subtarget=e;','shape="child-or";if(outer)subtarget=e;').replace('if(outer){measure(shape,t0);subtarget=nullptr;}','if(inner)measure(shape,t0);if(outer)subtarget=nullptr;')
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt','compare.py']:(w/n).write_text((b/n).read_text())
