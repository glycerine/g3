from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/theory_datatype.go';s=f.read_text().replace('import (','import (\n"os"',1);s+='\nvar studyDatatypePolicy=os.Getenv("STUDY_DTYPE")\n';k='infinite, err := state.manager.SortIsInfinite(sort)';assert s.count(k)>0;s=s.replace(k,'''if t.lazySplits()==1 && studyDatatypePolicy!="base" {
 if studyDatatypePolicy=="late"{return nil}
 enum,e:=state.manager.DatatypeIsEnumSort(sort);if e!=nil{return e}
 if enum{return nil}
}
'''+k,1)
dst=w/'datatype.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-or-install/final/release.py').read_text().split('run(12,')[0].replace("'-o',w/'release'","'-overlay',ov,'-o',w/'release'").replace('modes[m],ex/name',"w/'release',ex/name").replace("GOMAXPROCS='1'","STUDY_DTYPE=m,GOMAXPROCS='1'")
exec(script)
run(18,'whole',['test/arm_rules3.ivy','examples/liveness/hybrid_reliable_broadcast_cisa.ivy','examples/ivy/card3.ivy'],9,['base','late','enum'])
