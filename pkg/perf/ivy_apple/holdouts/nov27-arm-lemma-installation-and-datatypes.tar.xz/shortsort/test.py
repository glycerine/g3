from pathlib import Path
import json
w=Path(__file__).resolve().parent;p=Path.cwd();f=p/'smtcore/smt_internalizer.go';s=f.read_text();k='slices.Sort(literals)';assert s.count(k)==1;s=s.replace(k,'''switch len(literals) {
        case 3:
            if literals[1]>literals[2]{literals[1],literals[2]=literals[2],literals[1]}
            if literals[0]>literals[1]{literals[0],literals[1]=literals[1],literals[0]}
            if literals[1]>literals[2]{literals[1],literals[2]=literals[2],literals[1]}
        case 2:
            if literals[0]>literals[1]{literals[0],literals[1]=literals[1],literals[0]}
        default:slices.Sort(literals)
        }''')
dst=w/'internalizer.go.txt';dst.write_text(s);ov=w/'trial.json';ov.write_text(json.dumps({'Replace':{str(f):str(dst)}}))
script=Path('/tmp/g3-live-literals/watch/test.py').read_text().split('script=',1)[1];exec('script='+script.replace('exec(compile(script','exec(compile(script.replace("run(12","run(16")'))
