from pathlib import Path
w=Path(__file__).resolve().parent;base=w.parent/'price';s=(w.parent/'run.py').read_text()
a=s.index(" k='literals :=");b=s.index('\nelse:',a)
s=s[:a]+''' k='for index, argument := range arguments {';t=sub(t,k,k+\'''var tick uint64;kind:="bound";if studyInstance{if _,ok:=s.boundInstanceLiteral(argument);!ok{expr:=argument;_,child,e:=s.manager.IsNot(expr);if e!=nil{panic(e)};if !child.IsNull(){expr=child};header,e:=s.manager.NodeHeader(expr);if e!=nil{panic(e)};kind="theory";if header.Kind==ast.ASTQuantifier{kind="quant"}else if header.Family==ast.NullFamilyID{kind="predicate"}else if header.Family==s.manager.BasicFamilyID(){switch header.DeclKind{case ast.ASTOpEq:kind="eq";case ast.ASTOpIff:kind="iff";case ast.ASTOpAnd:kind="and";case ast.ASTOpOr:kind="or";case ast.ASTOpIte:kind="ite";default:kind="other-basic"}}};tick=freshRead()};\''')
 k='literals[index] = literal';t=sub(t,k,k+';if studyInstance{studyOperand(kind,tick)}')
 k='literals[index], err = s.Literal(argument)';t=sub(t,k,k+';if studyInstance{studyOperand(kind,tick)}')
 overlay(f,h+t);overlay(p/'smtcore/study_event_counts.go',(w/'read.go.txt').read_text()+'\\nvar studyInstance bool\\nfunc studyOperand(k string,t uint64){v:=freshRead()-t;a:=freshRead();e:=freshRead()-a;println("OPERAND",k,v,e)}\\n')
'''+s[b:]
a=s.index(" part=sub(part,'flet");b=s.index(" (w/'smt_internalizer.cpp')",a)
s=s[:a]+''' helper+=(w/'read.cpp.txt').read_text()
 k='internalize(arg, true);';part=sub(part,k,\'''unsigned long long tick=0;const char* kind="bound";if(studyInstance){expr* child=nullptr;if(!m_manager.is_not(arg,child))child=arg;if(m_manager.is_not(child)||!b_internalized(child)){kind="theory";if(is_quantifier(child))kind="quant";else if(is_app(child)){app* ap=to_app(child);if(ap->get_family_id()==null_family_id)kind="predicate";else if(ap->get_family_id()==m_manager.get_basic_family_id()){switch(ap->get_decl_kind()){case OP_EQ:kind="eq";break;case OP_IFF:kind="iff";break;case OP_AND:kind="and";break;case OP_OR:kind="or";break;case OP_ITE:kind="ite";break;default:kind="other-basic";}}}}tick=freshRead();}internalize(arg,true);\''')
 k='lits.push_back(get_literal(arg));';part=sub(part,k,k+'if(studyInstance){auto v=freshRead()-tick;auto a=freshRead();auto e=freshRead()-a;fprintf(stderr,"OPERAND %s %llu %llu\\\\n",kind,v,e);}')
'''+s[b:]
s=s.replace("previous=None","previous=None\n out2=csv.writer((w/(mode+'-shapes.csv')).open('w'));out2.writerow(['round','batch','goal','phase','shape','count','net']);from collections import Counter")
s=s.replace('raw=[];rows=[]','raw=[];rows=[];n=Counter();cost=Counter()').replace("if l.startswith(b'EVENT '):rows.append(l.decode().split()[1:])","if l.startswith(b'OPERAND '):\n    _,k,v,e=l.decode().split();n[k]+=1;cost[k]+=int(v)-int(e)\n   elif l.startswith(b'EVENT '):\n    row=l.decode().split()[1:];rows.append(row);out2.writerows([i,*row[:3],k,n[k],cost[k]] for k in sorted(n));n.clear();cost.clear()")
(w/'run.py').write_text(s)
for n in ['read.go.txt','read.cpp.txt']:(w/n).write_text((base/n).read_text())
