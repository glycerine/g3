from pathlib import Path
w=Path(__file__).resolve().parent;s=Path('/tmp/g3-arm-events/events.py').read_text().replace("w=Path(__file__).resolve().parent;p=Path.cwd();mode=sys.argv[1]","root=Path(__file__).resolve().parent;w=root/sys.argv[2];w.mkdir(exist_ok=True);p=Path.cwd();mode=sys.argv[1]")
a=s.index(' src={');b=s.index(' overlay(p/',s.index("overlay(f,s)",a))
s=s[:a]+''' which=sys.argv[2];f=p/'smtcore/smt_internalizer.go';t=f.read_text() if which=='base' else (root.parent/which/'internalizer.go.txt').read_text()
 k='return s.assertExpression(lemma, proof, instance.Generation(), arguments)';a=t.index('func (s *SMTInternalizerState) internalizeInstance(');b=t.index('proof, err := instance.Proof()',a)
 t=t[:b]+'StudyEventCounts[0]++;if arguments==nil{StudyEventCounts[1]++};'+t[b:];t=sub(t,k,'StudyEventCounts[2]++;'+k)
 if 'expand' in which:
  t=sub(t,'if negative{return false,nil}', 'if negative{StudyEventCounts[5]++;return false,nil};StudyEventCounts[3]++')
  t=sub(t,'e=s.studyAssertClause(terms,gen);','StudyEventCounts[4]++;e=s.studyAssertClause(terms,gen);')
 if 'distribute' in which:
  t=sub(t,'return s.assertDistributedInstance(arguments,i,expr,negative,instance.Generation())','StudyEventCounts[3]++;StudyEventCounts[4]+=2;return s.assertDistributedInstance(arguments,i,expr,negative,instance.Generation())')
 overlay(f,t);f=p/'smtcore/smt_search.go';t=f.read_text();k='func (k *SMTKernel) resolveSearchConflict(session *smtSearchSession) (bool, error) {';overlay(f,sub(t,k,k+'StudyEventCounts[6]++;'))
 f=p/'smtcore/smt_internalizer_state.go';t=f.read_text();k='s.statistics.NumMkBoolVar++';overlay(f,sub(t,k,k+';StudyEventCounts[7]++'))
 f=p/'smtcore/smt_internalizer.go';t=(w/(mode+'-'+f.name+'.txt')).read_text();k='s.statistics.NumMkLits += uint32(len(kept))';overlay(f,sub(t,k,'StudyEventCounts[8]++;'+k))
'''+s[b:]
a=s.index('names=[');b=s.index('\ndef overlay',a);s=s[:a]+"names=['instances','no_args','ordinary','expanded','emitted','opposite','conflicts','variables','stored']"+s[b:]
(w/'run.py').write_text(s)
