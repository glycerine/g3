# Clause reads during conflict analysis and decision-level counting

Run from pkg/ on linux/amd64. The baseline binaries used g3 solver commit b189e1034 and the release uses the SAT changes described in PERF_STUDY.md. Build each source revision with Go 1.27.3 using the following commands, saving each baseline executable before building the release. The GoIvy checkout was 07cdeec61 with a local replacement pointing at this pkg directory. Native was this repository's build/z3.

    go build -pgo=off -buildvcs=false -mod=readonly -o /tmp/g3-candidate ./cmd/g3
    go -C ~/ivy/goivy build -pgo=off -buildvcs=false -mod=readonly -tags=xtrace_off -o /tmp/goivy-candidate ./cmd/goivy_check

Extract nov26-clause-locality.tar.xz for the DIMACS inputs, nov26-sat-arena-hot.tar.xz for the second pigeonhole ordering, and nov24-verifier-instruction-stacks.tar.xz for verifier reference transcripts. The timings use rotated binaries, GOMAXPROCS=1, single pinned CPU, perf user counters, and disabled PGO. An example for the hard random pair follows. The same driver handles planted and random-256 via the :stdin suffix. Use the expected unsat status for both pigeonhole orderings.

    python3 measure.py --cpu 10 --rounds 5 --solver-arg=-v:2 \
      --case unsat:fixtures/random-208-3.cnf --case sat:fixtures/random-208-4.cnf \
      base=/tmp/g3-base frontier=/tmp/g3-candidate > sample.csv
    python3 summary.py sample.csv

measure.py verifies all five search counters across engines and validates every SAT model against the input clauses. verify.py checks both output streams and the expected exit code against each archived reference. Supply --perf if the perf binary is outside PATH. To reproduce the three paired profiles, run:

    python3 profile.py --cpu 11 --rounds 3 --out /tmp/reason-profiles \
      --fixture fixtures/random-208-3.cnf --fixture fixtures/random-208-4.cnf \
      --fixture fixtures/pigeon8-s0.cnf /tmp/g3-base ../build/z3 > profile.csv

The samples count exclusive stack categories, period 2,000,003 retired user instructions. Go used frame pointers, Z3 used DWARF. The native first-UIP clause loop is part of resolve_conflict_core, so its samples are included in the native conflict bucket. Cross-engine first-UIP percentages cannot be read directly from the CSV.

initial.csv uses reason.py both on the baseline to try only the conflict-resolution and minimization changes. Run the script from pkg/ on the baseline with the script in an ignored scratch directory. frontier.csv compares the final conflict, minimization and glue changes on CPU 10. holdout.csv uses CPU 12. confirm.csv repeats random SAT and ordinary pigeonhole on CPU 11 in reversed executable order. planted.csv and planted-gcoff.csv repeat the planted stdin control with normal GC and GOGC=off, respectively. verifier.csv covers four complete GoIvy runs on CPU 11. verifier-confirm.csv repeats Ticket and hybrid on CPU 10. Percent changes in the report use ratios of medians.
