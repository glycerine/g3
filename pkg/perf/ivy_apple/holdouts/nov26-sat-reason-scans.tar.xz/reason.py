"""Try a retained clause view during callback-free conflict and reason walks."""
import argparse,json,subprocess
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('variant',choices=('both','resolve','minimize'))
p.add_argument('--goivy',action='store_true')
a=p.parse_args()
root=Path.cwd()
out=Path(__file__).resolve().parent/a.variant
out.mkdir(exist_ok=True)
changes={}

def emit(rel,text):
    source=root/rel
    out_file=out/source.name
    out_file.write_bytes(subprocess.check_output(['gofmt'],input=text.encode()))
    changes[str(source)]=str(out_file)
    if a.goivy: changes[str(Path.home()/'g3/pkg'/rel)]=str(out_file)

rel='sat/sat_clause_storage.go'
s=(root/rel).read_text()
start=s.index('// watchedLiterals places')
s=s[:start]+'''// reasonLiteral has the same per-read bounds as ClauseAllocator.Literal.
// Its validated view must remain live for the entire reason walk.
func (v satClauseView) reasonLiteral(i uint32) (Literal,error) {
    if satStorageSourceDebug {
        if len(v)<8 {return 0,arena.ErrBounds}
        if i>=v.size() {return 0,ErrSATAssertion}
    }
    offset:=satClauseLiteralsOffset+4*uint64(i)
    if offset+4>uint64(len(v)) {return 0,arena.ErrBounds}
    return Literal(binary.LittleEndian.Uint32(v[offset:])),nil
}

'''+s[start:]
emit(rel,s)
if a.variant in ('resolve','both'):
    rel='sat/sat_solver_conflict_helpers.go'
    s=(root/rel).read_text()
    start=s.index('\tcase 3:\n',s.index('func (s *satSolverConflictResolution) processConsequent'))
    end=s.index('\n\tcase 4:',start)
    block=s[start:end]
    advance=block.index('\n\t\ti := uint32(0)')
    slow=block[advance:].replace('p.clauses.', 'a.')
    significant=slow.replace('a.Literal(c, ', 'view.reasonLiteral(')
    significant=significant.replace('n, e := a.Size(c)\n\t\tif e != nil {\n\t\t\treturn e\n\t\t}', 'n := view.size()')
    s=s[:start]+'''    case 3:
        if mode==2 {
            return s.processTracedClauseConsequent(consequent,j.ClauseOffset(),mode,marks)
        }
        view,e:=p.clauses.view(StoredClauseRef(j.ClauseOffset()))
        if e!=nil {return e}
        if len(view)<8 {return arena.ErrBounds}
'''+significant+s[end:]
    s+='''
// Core tracing can call out between antecedents, so the traced route resolves
// each read from its original clause handle.
func (s *satSolverConflictResolution) processTracedClauseConsequent(consequent Literal, off satClauseOffset, mode uint8, marks *uint32) error {
    a:=s.analysis.propagation.clauses
    c,e:=a.GetClause(off)
    if e!=nil {return e}
'''+slow+'\n}\n'
    s=s.replace('package sat\n','package sat\nimport \"github.com/glycerine/g3/pkg/arena\"\n',1)
    emit(rel,s)
if a.variant in ('minimize','both'):
    rel='sat/sat_solver_lemma_minimization.go'
    s=(root/rel).read_text()
    start=s.index('\t\tcase 3:')
    end=s.index('\n\t\tcase 4:',start)
    block=s[start:end].replace('c, e := a.GetClause(j.ClauseOffset())', 'view,e:=a.view(StoredClauseRef(j.ClauseOffset()))')
    block=block.replace('a.Literal(c, ','view.reasonLiteral(').replace('n, e := a.Size(c)\n\t\t\tif e != nil {\n\t\t\t\treturn false, e\n\t\t\t}', 'n := view.size()')
    s=s[:start]+block+s[end:]
    emit(rel,s)
name='goivy_check' if a.goivy else 'g3'
file=out/(name+'.json')
file.write_text(json.dumps({'Replace':changes}))
subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',file,'-o',out/name,
    *(['-tags=xtrace_off','./cmd/goivy_check'] if a.goivy else ['./cmd/g3'])],cwd=Path.home()/'ivy/goivy' if a.goivy else root,check=True)
