"""Validate verifier transcripts and measure rewrite costs for recorded row classes."""
import argparse,csv,json,os,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--cpu',required=True);p.add_argument('--perf',default='perf')
p.add_argument('--reference',required=True,type=Path);p.add_argument('--tlb-reference',required=True,type=Path)
p.add_argument('--examples',required=True,type=Path);p.add_argument('--rounds',type=int,default=3)
p.add_argument('--case',action='append',required=True);p.add_argument('engines',nargs='+')
a=p.parse_args();work=Path(__file__).resolve().parent
cases=json.loads((a.reference/'cases.json').read_text());cases['tlb']=('examples/liveness/tlb.ivy','',1)
engines=[(k,Path(f).resolve()) for k,f in [v.split('=',1) for v in a.engines]]
out=csv.writer(sys.stdout);out.writerow(('case','round','engine','whole_instructions','cycles','forward','reverse_other','reverse_quiet','counter_empty','quiet_rows'))
for case in a.case:
    src,isolate,status=cases[case]
    ref=a.tlb_reference if case=='tlb' else a.reference/'reference'/case
    expected=[(ref/key).read_bytes() for key in ('stdout','stderr')]
    env=dict(os.environ,GOMAXPROCS='1',GOGC='100',XTRACE_OFF='1',SWEEP_VISITS=str(work/'classify/census'/(case+'.json')))
    for i in range(a.rounds):
        off=i%len(engines)
        for name,exe in engines[off:]+engines[:off]:
            wd=work/('run-'+name);wd.mkdir(exist_ok=True);counters=wd/'perf.csv'
            args=['taskset','-c',a.cpu,a.perf,'stat','-x,','-o',counters,'-e','instructions:u,cycles:u','--',exe]
            if isolate:args+=['isolate='+isolate]
            r=subprocess.run(args+[a.examples/src],cwd=wd,capture_output=True,env=env,timeout=150)
            lines=r.stderr.splitlines(keepends=True)
            ds=[x for x in lines if x.startswith(b'SWEEP-INSTRUCTIONS ')]
            stderr=b''.join(x for x in lines if not x.startswith(b'SWEEP-INSTRUCTIONS '))
            if r.returncode!=status or [r.stdout,stderr]!=expected or len(ds)!=(name=='timing'):
                (wd/'error.stderr').write_bytes(r.stderr);raise ValueError((case,i,name,r.returncode,r.stderr[-900:]))
            phases=[0]*3;empty=rows=0
            if ds:
                report=json.loads(ds[0].split(b' ',1)[1]);phases=[r['Instructions']-r['Empty'] for r in report]
                empty=sum(r['Empty'] for r in report);rows=report[2]['Rows']
            hw={r[2]:int(r[0]) for r in csv.reader(counters.read_text().splitlines()) if len(r)>4 and r[2].endswith(':u') and float(r[4])==100}
            out.writerow((case,i+1,name,hw['instructions:u'],hw['cycles:u'],*phases,empty,rows));sys.stdout.flush()
