from pathlib import Path
import json,subprocess
root=Path.cwd();work=Path(__file__).resolve().parent;out=work/'timing';out.mkdir(exist_ok=True)
ivy=Path.home()/'ivy/goivy'
changes={str(root/'smtcore/value_sweep_counter.go'):str(work/'counter.go')}
src=root/'smtcore/smt_asserted_propagate.go'
s=src.read_text().replace('changed := false\n\tfor _, reverse','counter:=newSweepCounter()\n defer counter.close()\n changed := false\n\tfor _, reverse')
anchor='one, result = k.rewritePendingAssertion(i)'
assert s.count(anchor)==1
s=s.replace(anchor,'''limit:=k.manager.ResourceLimit()
                before:=limit.Steps
                start:=counter.read()
                '''+anchor+'''
                delta:=counter.read()-start
                counter.row(reverse,i-k.assertedHead,limit.Steps-before,one,delta)''')
dst=out/src.name;dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
changes[str(src)]=str(dst)
for src,dst in list(changes.items()):changes[str(Path.home()/'g3/pkg'/Path(src).relative_to(root))]=dst
src=ivy/'cmd/goivy_check/main.go';s=src.read_text()
if '"github.com/glycerine/g3/pkg/smtcore"' not in s:s=s.replace('package main','package main\nimport "github.com/glycerine/g3/pkg/smtcore"',1)
s=s.replace('os.Exit(goivy.MainWithConfig(args, cfg))','code:=goivy.MainWithConfig(args,cfg);smtcore.PrintSweepInstructions();os.Exit(code)')
dst=out/'main.go';dst.write_bytes(subprocess.check_output(['gofmt'],input=s.encode()))
changes[str(src)]=changes[str(src.resolve())]=str(dst)
file=out/'overlay.json';file.write_text(json.dumps({'Replace':changes}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-tags=xtrace_off','-overlay',file,'-o',out/'goivy','./cmd/goivy_check'],cwd=ivy,check=True)
