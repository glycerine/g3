"""Try the same validated fast return GetKind uses for AST hashes."""
import json, subprocess
from pathlib import Path
pkg=Path.cwd()
work=Path(__file__).resolve().parent
ivy=Path.home()/'ivy/goivy'
src=pkg/'ast/ast_core_accessors.go'
dst=work/src.name
before='func (m *ASTManager) GetHash(h ASTHandle) (uint32, error) {\n\tr, e := m.readNode(h)'
after=before.split('\n')[0]+'''
	if m.fastHandle(h) {
		return m.nodeAt(h.slot).hash, nil
	}
	r, e := m.readNodeChecked(h)'''
s=src.read_text()
assert s.count(before)==1
dst.write_text(s.replace(before,after))
f=work/'hash-overlay.json'
f.write_text(json.dumps({'Replace':{str(src):str(dst),str(Path.home()/'g3/pkg/ast'/src.name):str(dst)}}))
subprocess.run(['go','build','-pgo=off','-mod=readonly','-buildvcs=false','-tags=xtrace_off','-overlay',f,'-o',work/'hash-goivy','./cmd/goivy_check'],cwd=ivy,check=True)
