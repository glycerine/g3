package ast

import (
	"encoding/json"
	"fmt"
	"os"
)

type valueRow struct {
	cacheHits, changedCacheHits              uint64
	index                                    int
	earlier, sameRow, unseen, earlierBinding bool
	writes, reads                            uint64
	input                                    ASTHandle
	changed                                  bool
	charge, probes, hits, temporaryHits      uint64
	readings                                 map[ASTHandle]ASTHandle
}

type valueSweepCounts struct {
	Rows, Changed, Charge, Probes, Hits, TemporaryHits, RowsWithTemporaryHit uint64
}
type valueCounts struct {
	Visits                                                                                                [][4]uint64
	SameReadsChangedWithCache, SameReadsChangedWithoutCache                                               uint64
	SameReadsChangedChargeAndCacheHits                                                                    uint64
	Batches                                                                                               uint64
	ProducerSame, ProducerEarlier, ProducerUnknown                                                        uint64
	SurpriseEarlier, SurpriseSameOnly, SurpriseUnknownOnly, SurpriseEarlierBinding, SurpriseNoChangedRead uint64
	ReverseNoCacheEffects, ReverseNoCacheCharge, StableNoCacheEffects, StableNoCacheCharge                uint64
	Forward, Reverse                                                                                      valueSweepCounts
	SameInput, SameInputChanged, SameInputSteps                                                           uint64
	SameInputSameReads, SameReadsChangedCharge, SameReadsChangedOutput                                    uint64
	SameUnchanged, SameUnchangedNoTemporaryRead, SameUnchangedNoTemporarySteps                            uint64
	DifferentForwardRead, DifferentReverseRead, SharedKeySameValue                                        uint64
	DepthCalls, DepthHits, GroundDepthMisses, OtherDepthMisses, SaturatedDepthMisses                      uint64
}

var valueReport valueCounts
var valueObservationActive, valueReverse bool
var valuePrevious []valueRow
var valueCurrent valueRow
var valueInserted map[ASTHandle]struct{}

func ValueObservationBegin(rows int) {
	valueReport.Batches++
	valuePrevious = make([]valueRow, rows)
}
func ValueObservationDirection(reverse bool) {
	valueProducers = make(map[valueProducerKey]valueProducer)
	valueReverse = reverse
	valueInserted = make(map[ASTHandle]struct{})
}
func ValueObservationRow(index int, input ASTHandle) {
	valueCurrent = valueRow{index: index, input: input, readings: make(map[ASTHandle]ASTHandle)}
	valueObservationActive = true
}
func ValueObservationCache(key, value ASTHandle) {
	if !valueObservationActive {
		return
	}
	valueCurrent.cacheHits++
	if key != value {
		valueCurrent.changedCacheHits++
	}
}
func ValueObservationProbe(key, value ASTHandle, hit bool) {
	if !valueObservationActive {
		return
	}
	valueCurrent.probes++
	if hit {
		valueCurrent.hits++
		if _, ok := valueInserted[key]; ok {
			valueCurrent.temporaryHits++
		}
		valueCurrent.readings[key] = value
	}
}
func valueObservationInsert(key ASTHandle) {
	if valueInserted != nil {
		valueInserted[key] = struct{}{}
	}
}
func ValueObservationDepth(cached bool, ground bool, depth uint32) {
	valueReport.DepthCalls++
	if cached {
		valueReport.DepthHits++
		return
	}
	if !ground {
		valueReport.OtherDepthMisses++
		return
	}
	if depth == 65535 {
		valueReport.SaturatedDepthMisses++
		return
	}
	valueReport.GroundDepthMisses++
}
func ValueObservationEndRow(row int, charge uint64, changed bool) {
	valueObservationActive = false
	current := valueCurrent
	current.changed = changed
	current.charge = charge
	out := &valueReport.Forward
	if valueReverse {
		out = &valueReport.Reverse
	}
	out.Rows++
	if changed {
		out.Changed++
	}
	out.Charge += charge
	out.Probes += current.probes
	out.Hits += current.hits
	out.TemporaryHits += current.temporaryHits
	if current.temporaryHits != 0 {
		out.RowsWithTemporaryHit++
	}
	if !valueReverse {
		valuePrevious[row] = current
		return
	}
	if current.reads == 0 && current.writes == 0 {
		valueReport.ReverseNoCacheEffects++
		valueReport.ReverseNoCacheCharge += charge
	}
	previous := valuePrevious[row]
	var class, outcome uint64
	if current.input == previous.input && !current.changed && !previous.changed && current.reads == 0 && current.writes == 0 && previous.reads == 0 && previous.writes == 0 {
		class = 1
	}
	if current.changed {
		outcome = 1
	}
	valueReport.Visits = append(valueReport.Visits, [4]uint64{uint64(row), charge, outcome, class})

	if previous.input != current.input {
		return
	}
	valueReport.SameInput++
	valueReport.SameInputSteps += charge
	if changed {
		valueReport.SameInputChanged++
	}
	same := true
	for key, value := range previous.readings {
		if reverse, ok := current.readings[key]; ok && reverse == value {
			valueReport.SharedKeySameValue++
		} else {
			valueReport.DifferentForwardRead++
			same = false
		}
	}
	for key, value := range current.readings {
		if forward, ok := previous.readings[key]; !ok || forward != value {
			valueReport.DifferentReverseRead++
			same = false
		}
	}
	if same {
		valueReport.SameInputSameReads++
		if previous.charge != charge {
			valueReport.SameReadsChangedCharge++
			if current.cacheHits != previous.cacheHits {
				valueReport.SameReadsChangedChargeAndCacheHits++
			}
		}
		if changed != previous.changed {
			valueReport.SameReadsChangedOutput++
			switch {
			case current.earlier:
				valueReport.SurpriseEarlier++
			case current.sameRow:
				valueReport.SurpriseSameOnly++
			case current.unseen:
				valueReport.SurpriseUnknownOnly++
			default:
				valueReport.SurpriseNoChangedRead++
			}
			if current.earlierBinding {
				valueReport.SurpriseEarlierBinding++
			}
			if current.changedCacheHits != 0 {
				valueReport.SameReadsChangedWithCache++
			} else {
				valueReport.SameReadsChangedWithoutCache++
			}
		}
	}
	if !previous.changed && !changed {
		valueReport.SameUnchanged++
		if current.reads == 0 && current.writes == 0 && previous.reads == 0 && previous.writes == 0 {
			valueReport.StableNoCacheEffects++
			valueReport.StableNoCacheCharge += charge
		}
		if current.temporaryHits == 0 {
			valueReport.SameUnchangedNoTemporaryRead++
			valueReport.SameUnchangedNoTemporarySteps += charge
		}
	}
}
func ValueObservationFinish() {
	valueObservationActive = false
	valueProducers = nil
	valueInserted = nil
	valuePrevious = nil
}
func PrintValueObservation() {
	data, err := json.Marshal(valueReport)
	if err != nil {
		panic(err)
	}
	fmt.Fprintf(os.Stderr, "VALUE-SWEEPS %s\n", data)
}

type valueProducerKey struct {
	c *ActivityCache
	k ASTHandle
}
type valueProducer struct {
	v       ASTHandle
	row     int
	binding bool
}

var valueProducers map[valueProducerKey]valueProducer

func valueProducerWrite(c *ActivityCache, k, v ASTHandle) {
	if valueProducers == nil {
		return
	}
	key := valueProducerKey{c, k}
	if !valueObservationActive {
		delete(valueProducers, key)
		return
	}
	valueCurrent.writes++
	valueProducers[key] = valueProducer{v, valueCurrent.index, valueCurrent.temporaryHits != 0 || valueCurrent.earlierBinding}
}
func ValueProducerRead(c *ActivityCache, k, v ASTHandle) {
	if !valueObservationActive {
		return
	}
	valueCurrent.reads++
	if k == v {
		return
	}
	p, ok := valueProducers[valueProducerKey{c, k}]
	switch {
	case !ok || p.v != v:
		valueCurrent.unseen = true
		valueReport.ProducerUnknown++
	case p.row == valueCurrent.index:
		valueCurrent.sameRow = true
		valueReport.ProducerSame++
	default:
		valueCurrent.earlier = true
		valueCurrent.earlierBinding = valueCurrent.earlierBinding || p.binding
		valueReport.ProducerEarlier++
	}
}
