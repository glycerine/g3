"""Build an untimed sweep dependency census and cached depth trials."""
import argparse
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('variants',nargs='+',choices=('observer',))
parser.add_argument('--cli',action='store_true')
a=parser.parse_args()
pkg=Path.cwd()
ivy=Path.home()/'ivy/goivy'
root=Path(__file__).resolve().parent
prop='smtcore/smt_asserted_propagate.go'

for name in a.variants:
    paths={}
    out=root/name
    out.mkdir(exist_ok=True)
    def edit(file,before,after,external=False):
        src=(ivy if external else pkg)/file
        text=paths.get(src,src).read_text()
        assert text.count(before)==1,(file,before,text.count(before))
        dst=out / (('ivy-' if external else '')+Path(file).name)
        dst.write_bytes(subprocess.check_output(['gofmt'],input=text.replace(before,after,1).encode()))
        paths[src]=dst
        if external: paths[src.resolve()]=dst
    if name=='observer':
        paths[pkg/'ast/value_sweep_observer.go']=root/'observer.go'
        edit(prop,'changed := false\n\tfor _, reverse := range',
             'changed:=false\n ast.ValueObservationBegin(len(k.assertions)-k.assertedHead)\n defer ast.ValueObservationFinish()\n for _, reverse := range')
        edit(prop,'if err := k.manager.ScopedExprSubstitutionPush(k.assertedScopedSubst); err != nil {',
             'ast.ValueObservationDirection(reverse)\n if err := k.manager.ScopedExprSubstitutionPush(k.assertedScopedSubst); err != nil {')
        edit(prop,'one, result = k.rewritePendingAssertion(i)',
             '''limit:=k.manager.ResourceLimit()
             before:=limit.Steps
             ast.ValueObservationRow(i-k.assertedHead,k.assertions[i].Formula)
             one,result=k.rewritePendingAssertion(i)
             ast.ValueObservationEndRow(i-k.assertedHead,limit.Steps-before,one)''')
        edit('ast/ast_expr_substitution_scope.go','a.trail = append(a.trail, k)',
             'a.trail=append(a.trail,k)\n valueObservationInsert(key)')
        edit('ast/rewriter/th_rewriter.go','found, err := c.owner.manager.ExprSubstitutionFindDependency(c.substitution, term, &value, &proof, &dependency)',
             'found,err:=c.owner.manager.ExprSubstitutionFindDependency(c.substitution,term,&value,&proof,&dependency)\n ast.ValueObservationProbe(term,value,found)')
        engine = 'ast/rewriter/rewriter_engine.go'
        text = (pkg/engine).read_text()
        before = 'if !h.IsNull() {\n\t\t\tif e = r.sameSort(t, h); e != nil {'
        assert text.count(before)==2
        dst=out/Path(engine).name
        dst.write_bytes(subprocess.check_output(['gofmt'],input=text.replace(before,
            'if !h.IsNull() {\n ast.ValueObservationCache(t,h)\n if e=r.sameSort(t,h);e!=nil {',1).encode()))
        paths[pkg/engine]=dst
        # Record actual cache publications, including replacement of an old value.
        cache='ast/ast_activity_cache.go'
        edit(cache,'entry.value = value\n','entry.value = value\n valueProducerWrite(c,k,v)\n')
        edit(cache,'entry.value, entry.valueHeld = value, c.incomingHeld','entry.value, entry.valueHeld = value, c.incomingHeld\n valueProducerWrite(c,k,v)')
        core='ast/rewriter/rewriter_core.go'
        edit(core,'return c.cache.Find(k)','h,err:=c.cache.Find(k)\n if err==nil && !h.IsNull(){ast.ValueProducerRead(c.cache,k,h)}\n return h,err')
        main='cmd/g3/main.go' if a.cli else 'cmd/goivy_check/main.go'
        if '"github.com/glycerine/g3/pkg/ast"' not in ((pkg if a.cli else ivy)/main).read_text():
            edit(main,'package main','package main\n import "github.com/glycerine/g3/pkg/ast"',not a.cli)
        if a.cli:
            edit(main,'func main() {','func main() {\n defer ast.PrintValueObservation()')
        else:
            edit(main,'os.Exit(goivy.MainWithConfig(args, cfg))',
                 'code:=goivy.MainWithConfig(args,cfg)\n ast.PrintValueObservation()\n os.Exit(code)',True)
    for src,dst in list(paths.items()):
        if src.is_relative_to(pkg) and not a.cli:
            paths[Path.home()/'g3/pkg'/src.relative_to(pkg)]=dst
    overlay=out/('g3.json' if a.cli else 'goivy.json')
    overlay.write_text(json.dumps({'Replace':{str(k):str(v) for k,v in paths.items()}}))
    target=['./cmd/g3'] if a.cli else ['-tags=xtrace_off','./cmd/goivy_check']
    subprocess.run(['go','build','-pgo=off','-buildvcs=false','-mod=readonly','-overlay',overlay,
                    '-o',out/('g3' if a.cli else 'goivy_check'),*target],
                   cwd=pkg if a.cli else ivy,check=True)
