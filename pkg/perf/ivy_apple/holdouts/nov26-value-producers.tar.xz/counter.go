package smtcore

import (
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"syscall"
	"unsafe"
)

var sweepVisitFile struct{ Visits [][4]uint64 }
var sweepIndex int
var sweepTotals [3]struct{ Rows, Instructions, Empty uint64 }

type sweepCounter struct {
	fd    uintptr
	empty uint64
}

func newSweepCounter() sweepCounter {
	if sweepVisitFile.Visits == nil {
		b, e := os.ReadFile(os.Getenv("SWEEP_VISITS"))
		if e != nil {
			panic(e)
		}
		if e = json.Unmarshal(b, &sweepVisitFile); e != nil {
			panic(e)
		}
	}
	runtime.LockOSThread()
	var attr struct {
		Type, Size                                    uint32
		Config, Period, SampleType, ReadFormat, Flags uint64
		Pad                                           [16]byte
	}
	attr.Size = uint32(unsafe.Sizeof(attr))
	attr.Config = 1
	attr.ReadFormat = 3
	attr.Flags = 1<<5 | 1<<6
	fd, _, e := syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN, uintptr(unsafe.Pointer(&attr)), 0, ^uintptr(0), ^uintptr(0), 0, 0)
	if e != 0 {
		panic(e)
	}
	c := sweepCounter{fd: fd}
	start := c.read()
	c.empty = c.read() - start
	return c
}
func (c sweepCounter) read() uint64 {
	var buf [3]uint64
	n, _, e := syscall.RawSyscall(syscall.SYS_READ, c.fd, uintptr(unsafe.Pointer(&buf[0])), 24)
	if n != 24 || e != 0 || buf[1] != buf[2] {
		panic("sweep counter unavailable or multiplexed")
	}
	return buf[0]
}
func (c sweepCounter) close() { syscall.Close(int(c.fd)); runtime.UnlockOSThread() }
func (c sweepCounter) row(reverse bool, row int, charge uint64, changed bool, n uint64) {
	class := uint64(0)
	if reverse {
		r := sweepVisitFile.Visits[sweepIndex]
		sweepIndex++
		if r[0] != uint64(row) || r[1] != charge || (r[2] != 0) != changed {
			panic(fmt.Sprintf("different sweep visit %d: %v vs %d %d %t", sweepIndex, r, row, charge, changed))
		}
		class = 1 + r[3]
	}
	total := &sweepTotals[class]
	total.Rows++
	total.Instructions += n
	total.Empty += c.empty
}
func PrintSweepInstructions() {
	if sweepIndex != len(sweepVisitFile.Visits) {
		panic("incomplete sweep replay")
	}
	b, e := json.Marshal(sweepTotals)
	if e != nil {
		panic(e)
	}
	fmt.Fprintf(os.Stderr, "SWEEP-INSTRUCTIONS %s\n", b)
}
