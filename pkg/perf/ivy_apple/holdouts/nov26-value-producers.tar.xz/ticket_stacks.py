"""Break down the archived g3 Ticket queue theory rewrite instruction samples."""
import argparse, csv, re, subprocess, sys
from collections import Counter
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('profiles',type=Path)
p.add_argument('--perf',default='perf')
a=p.parse_args()
out=csv.writer(sys.stdout)
out.writerow(['query','round','category','leaf','samples'])
for f in sorted(a.profiles.glob('ticket-*-g3.data')):
    query, rnd=f.stem.rsplit('-',2)[:2]
    samples=subprocess.check_output([a.perf,'script','-i',f],text=True)
    counts=Counter()
    for s in samples.split('\n\n'):
        if not all(x in s for x in ['(*Context).CheckSatDisplay','(*SMTQuantifierManager).instantiate','(*TheoryRewriter).Rewrite']):continue
        if any(x in s for x in ['(*SMTChecker).run','(*SMTChecker).checkCandidate','(*SMTChecker).checkCore','(*SMTCachedVarSubstitution).Instantiate','(*SMTQuantifierManager).promoteUnsatEntry']):continue
        frames=[re.sub(r'^.*?/pkg/', '', m[1]) for x in s.splitlines() if (m:=re.match(r'\s*[0-9a-f]+ (.*?)\+0x',x))]
        if not frames:raise ValueError(f)
        for name,keys in [('reducer',('.ReduceApp',)),('substitution',('.GetSubst',)),('expression cache',('.getCached','.cacheResult','ActivityCache','ExprCache')),('result ownership',('RewriterRoot','HeldRefs','RefHeld','RefGetHeld')),('visit',('(*rewriterEngine).visit',)),('application frame',('(*rewriterEngine).processApp',))]:
            if any(k in fr for k in keys for fr in frames):break
        else:name='other'
        counts[name,frames[0]]+=1
    for (category,leaf),n in sorted(counts.items()):out.writerow([query,rnd,category,leaf,n])
