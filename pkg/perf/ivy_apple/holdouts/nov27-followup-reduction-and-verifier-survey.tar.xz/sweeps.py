"""Isolate the effect of each value-propagation sweep on complete verification."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);ov={}
for fn in ['smt_kernel.go','smt_asserted_propagate.go']:
 src=p/'smtcore'/fn;s=src.read_text()
 if fn=='smt_kernel.go':
  key='k.simplifyInitialPushOnce = false'
  s=s.replace('import (','import (\n"os"');s=s.replace(key,'k.studySweep=os.Getenv("ACTION_SCOPE");defer func(){k.studySweep=""}()\n '+key)
  s=s.replace('type SMTKernel struct {','type SMTKernel struct {\n studySweep string')
 else:
  s=s.replace('import (','import (\n"fmt"\n"os"')
  key='for _, reverse := range []bool{false, true} {'
  s=s.replace(key,'''for _, reverse := range []bool{false,true}{
   if reverse && (k.studySweep=="forward" || k.studySweep=="conditional" && !changed) {break}
   if !reverse && k.studySweep=="reverse" {continue}
   count:=0
   ''')
  key='changed = changed || one';s=s.replace(key,key+'\n if one {count++}')
  key='if reverse {\n\t\t\tif err := k.traceAssertedBody'
  s=s.replace(key,'if k.studySweep=="census" {fmt.Fprintln(os.Stderr,"SWEEP",reverse,len(k.assertions)-k.assertedHead,count)}\n '+key)
 dst=w/('sweeps-'+fn);dst.write_text(s);ov[str(src)]=str(dst)
o=w/'sweeps.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'sweeps','./cmd/goivy_check'],cwd=front,check=True)
