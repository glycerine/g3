from pathlib import Path
import subprocess,csv,os
w=Path(__file__).resolve().parent;p=Path('/tmp/g3-ivy-pgo');ex=Path('/home/jaten/ivy/ivy-lang-examples')
codes={r['spec']:int(r['exit']) for f in (p/'survey').glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
cases=(p/'prior-gaps.txt').read_text().splitlines()
with (w/'sweep-events.csv').open('w') as f:
 out=csv.writer(f);out.writerow('spec push reverse rows changes'.split())
 for idx in [5,2,3,1,11,12,4,6,8]:
  name=cases[idx-1];ref=p/'survey'/str(idx)/'1/native';r=subprocess.run([w/'sweeps',ex/name],env=dict(os.environ,GOMAXPROCS='1',GOGC='off',ACTION_SCOPE='census',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),cwd=w,capture_output=True,timeout=120)
  lines=r.stderr.splitlines(keepends=True);rows=[l.decode().split()[1:] for l in lines if l.startswith(b'SWEEP ')]
  assert all(len(row)==3 for row in rows) and (r.returncode,r.stdout,b''.join(l for l in lines if not l.startswith(b'SWEEP ')))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes())
  for i,row in enumerate(rows):out.writerow([name,i//2+1,*row])
  f.flush()
