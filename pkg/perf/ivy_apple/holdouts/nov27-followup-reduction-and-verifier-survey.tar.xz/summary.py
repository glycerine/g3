from collections import defaultdict
from pathlib import Path
import csv,statistics
for f in Path(__file__).resolve().parent.glob('*.csv'):
 rows=list(csv.DictReader(f.open()))
 if not rows:continue
 print(f.stem)
 if 'changed' in rows[0]:
  d=defaultdict(lambda:[0,0])
  for r in rows:
   if r['round']!='0':continue
   k=tuple(r[x] for x in ['previous_output','quantified','changed'])
   d[k][0]+=int(r['rows']);d[k][1]+=int(r['instructions'])
  print([(k,n,round(t/1e6,3)) for k,(n,t) in sorted(d.items()) if n])
 else:
  b={r['round']:r for r in rows if r['mode']=='base'}
  for m in set(r['mode'] for r in rows)-{'base'}:
   xs=[r for r in rows if r['mode']==m and r['round'] in b and r['status']=='match']
   if xs:print(m,len(xs),*[round(statistics.median((float(x[k])/float(b[x['round']][k])-1)*100 for x in xs),2) for k in ['instructions','ms']])
