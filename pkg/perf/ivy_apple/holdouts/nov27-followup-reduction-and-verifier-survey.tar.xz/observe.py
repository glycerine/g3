import csv,os,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path('/tmp/g3-ivy-pgo');ex=Path('/home/jaten/ivy/ivy-lang-examples')
name,stem,cpu=sys.argv[1:];idx=(p/'prior-gaps.txt').read_text().splitlines().index(name)+1
ref=p/'survey'/str(idx)/'1/native'
codes={r['spec']:int(r['exit']) for f in (p/'survey').glob('cpu-*.csv') for r in csv.DictReader(f.open()) if r['engine']=='native'}
with (w/(stem+'.csv')).open('w') as f:
 out=csv.writer(f);out.writerow('round push previous_output quantified changed rows instructions'.split())
 for i in range(int(os.getenv("ROUNDS","3"))):
  r=subprocess.run(['taskset','-c',cpu,w/'meter',ex/name],cwd=w,capture_output=True,env=dict(os.environ,GOMAXPROCS='1',GOGC='off',XTRACE_OFF='1',GOIVY_INCLUDE=str(ex/'ivy/include')),timeout=120)
  other=[];rows=[]
  for line in r.stderr.splitlines(keepends=True):
   if line.startswith(b'ROWS '):
    _,push,g,n,ins=line.split();g=int(g);rows.append([i,int(push),g&1,(g>>1)&1,(g>>2)&1,int(n),int(ins)])
   elif not line.startswith(b'IVY-PUSH-STAGE '):other.append(line)
  if idx==35:
   abc=Path('/tmp/g3-flash-marginal/abc-control')
   assert (r.returncode,r.stdout,b''.join(other))==(1,(abc/'native.out').read_bytes(),(abc/'native.err').read_bytes())
   out.writerows(rows);f.flush();continue
  assert (r.returncode,r.stdout,b''.join(other))==(codes[name],(ref/'stdout').read_bytes(),(ref/'stderr').read_bytes()),(r.returncode,r.stderr[-500:])
  out.writerows(rows);f.flush()
