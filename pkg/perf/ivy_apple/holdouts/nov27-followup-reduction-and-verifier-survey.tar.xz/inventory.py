from collections import Counter,defaultdict
from pathlib import Path
import csv
w=Path(__file__).resolve().parent
d=defaultdict(dict)
for f in (w/'compat').glob('cpu-*.csv'):
 for r in csv.DictReader(f.open()):d[r['spec']][r['engine']]=r
prior=set(Path('/tmp/g3-ivy-pgo/prior-gaps.txt').read_text().splitlines())
out=[]
for case,m in d.items():
 a,b=m['g3'],m['native'];exact=a['exit']==b['exit'] and all(a[k]=='1' for k in ['same_stdout','same_stderr']) and all(r['timed_out']=='0' for r in [a,b])
 proof=int(a['pass'])+int(a['fail'])>0
 out.append([case,exact,proof,case in prior,int(a['instructions'])-int(b['instructions']),float(a['wall_s'])-float(b['wall_s']),a['exit']])
out.sort(key=lambda r:-r[4])
with (w/'ranking.csv').open('w') as f:
 wr=csv.writer(f);wr.writerow('case exact proof prior_gap excess_instructions excess_seconds exit'.split());wr.writerows(out)
print(len(out),'exact',sum(r[1] for r in out),'proof producing',sum(r[2] for r in out))
for cls in [True,False]:
 xs=[r for r in out if r[2]==cls]
 print('proof',cls,'excess instructions',sum(r[4]>0 for r in xs),'excess elapsed',sum(r[5]>0 for r in xs))
print('new excesses',[(r[0],round(r[4]/1e6)) for r in out if r[4]>0 and not r[3]])
print('mismatches',[(r[0],r[6]) for r in out if not r[1]])
