"""Measure the BV pass's follow-up reduction by earlier output identity."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);ov={}
def file(fn,s):
 src=p/'smtcore'/fn;dst=w/fn;dst.write_text(s);ov[str(src)]=str(dst)
s=(p/'perf/ivy_apple/incremental_cost/push_stage_counter.go.txt').read_text().replace('package pushcounter','package smtcore').replace('import (','import (\n"github.com/glycerine/g3/pkg/ast"')
import re
for key in ['fd','empty','calls','instructions','depth','ordinal','active','readCounter','Scope','Enter','Leave','Pass']:
 s=re.sub(r'\b'+key+r'\b','study'+key,s)
s+='''
var followup bool
var priorOutput map[ast.ASTHandle]bool
var rowStats [8]struct{n int;cycles uint64}
func finishRows(){
 for i,v:=range rowStats{fmt.Fprintln(os.Stderr,"ROWS",studyordinal,i,v.n,v.cycles)}
 priorOutput=nil
}
'''
file('reduction_observer.go',s)
for fn in ['smt_kernel.go','smt_asserted_reduce.go','smt_asserted_bv.go']:
 s=(p/'smtcore'/fn).read_text()
 if fn=='smt_kernel.go':
  key='k.simplifyInitialPushOnce = false';s=s.replace(key,'defer studyScope()();priorOutput=make(map[ast.ASTHandle]bool);clear(rowStats[:]);defer finishRows()\n '+key)
 elif fn=='smt_asserted_bv.go':
  key='return k.reducePendingAssertions()';s=s.replace(key,'if studyactive {followup=true;defer func(){followup=false}()}\n '+key)
 else:
  key='formula, proof, err := k.preprocessAssertionMode(row.Formula, row.Proof, assertedProofSimplify)'
  assert s.count(key)==1
  s=s.replace(key,'''var group int;var start uint64
   if studyactive && followup {
    if priorOutput[row.Formula]{group|=1}
    if q,e:=k.manager.HasQuantifiers(row.Formula);e==nil && q{group|=2}
    start=studyreadCounter()
   }
   '''+key+'''
   if studyactive && err==nil {
    if followup {cost:=studyreadCounter()-start-studyempty;if formula!=row.Formula{group|=4};rowStats[group].n++;rowStats[group].cycles+=cost
    }else{priorOutput[formula]=true}
   }''')
 file(fn,s)
o=w/'rows.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'meter','./cmd/goivy_check'],cwd=front,check=True)
