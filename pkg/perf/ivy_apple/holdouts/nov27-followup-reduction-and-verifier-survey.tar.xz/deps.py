"""Count substitution and traversal-cache activity during the measured follow-up only."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);ov={}
def file(fn,s):
 src=p/fn;dst=w/('deps-'+src.name);dst.write_text(s);ov[str(src)]=str(dst)
def before(fn):
 return subprocess.check_output(['git','show','eae68af4a:pkg/'+fn],text=True)
fn='ast/rewriter/rewriter_core.go';s=before(fn)
s=s.replace('return c.cache.Insert(k, v)','''if StudyEvents!=nil{StudyEvents[4]++;if k!=v{StudyEvents[5]++}}
 return c.cache.Insert(k,v)''').replace('return c.cache.Find(k)','''v,e:=c.cache.Find(k)
 if StudyEvents!=nil {StudyEvents[1]++;if !v.IsNull(){StudyEvents[2]++;if k!=v{StudyEvents[3]++}}}
 return v,e''')
s+='\nvar StudyEvents *[8]int\n';file(fn,s)
fn='ast/rewriter/rewriter_engine.go';s=before(fn).replace('sub, subProof, found, e := r.cfg.GetSubst(t)','''sub, subProof, found, e := r.cfg.GetSubst(t)
 if StudyEvents!=nil{StudyEvents[6]++;if found{StudyEvents[0]++;if sub!=t{StudyEvents[7]++}}}''');file(fn,s)
fn='smtcore/smt_asserted_bv.go';s=before(fn)
s=s.replace('"errors"','"errors"\n "fmt"\n "os"')
s=s.replace('return k.reducePendingAssertions()','''if studyDependencyFirst{
  var stats [8]int
  rewriter.StudyEvents=&stats
  defer func(){rewriter.StudyEvents=nil;fmt.Fprintln(os.Stderr,"DEPS",stats)}()
 }
 return k.reducePendingAssertions()''')
if '/ast/rewriter"' not in s:s=s.replace('import (','import (\n "github.com/glycerine/g3/pkg/ast/rewriter"')
file(fn,s)
fn='smtcore/smt_kernel.go';s=before(fn).replace('k.simplifyInitialPushOnce = false','studyDependencyFirst=true;defer func(){studyDependencyFirst=false}();k.simplifyInitialPushOnce = false');s+='\nvar studyDependencyFirst bool\n';file(fn,s)
o=w/'deps.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'deps','./cmd/goivy_check'],cwd=front,check=True)
