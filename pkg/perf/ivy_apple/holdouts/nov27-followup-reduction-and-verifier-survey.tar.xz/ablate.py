"""Isolate the follow-up theory reduction on the initial verifier push."""
from pathlib import Path
import json,sys,subprocess
w=Path(__file__).resolve().parent;p=Path.cwd();front,mod=map(lambda s:Path(s).resolve(),sys.argv[1:3]);ov={}
for fn in ['smt_kernel.go','smt_asserted_bv.go']:
 src=p/'smtcore'/fn;s=src.read_text()
 if fn=='smt_kernel.go':
  s=s.replace('simplifyInitialPushOnce   bool','studyFirst bool\n simplifyInitialPushOnce bool').replace('k.simplifyInitialPushOnce = false','k.studyFirst=true;defer func(){k.studyFirst=false}()\n k.simplifyInitialPushOnce = false')
 else:s=s.replace('return k.reducePendingAssertions()','if k.studyFirst{return nil};return k.reducePendingAssertions()')
 dst=w/('trial-'+fn);dst.write_text(s);ov[str(src)]=str(dst)
o=w/'ablate.json';o.write_text(json.dumps({'Replace':ov}))
subprocess.run(['go','build','-pgo='+str(p/'perf/ivy_apple/compiler_profiles/nov27-raft-tlb-sat-smt.pprof'),'-buildvcs=false','-mod=readonly','-modfile',mod,'-tags','xtrace_off','-overlay',o,'-o',w/'ablate','./cmd/goivy_check'],cwd=front,check=True)
