from pathlib import Path
import subprocess,sys,os
w=Path(__file__).resolve().parent
p=Path('/tmp/g3-ivy-pgo')
cases=(p/'prior-gaps.txt').read_text().splitlines()
i=int(sys.argv[1])
for j in range(i,len(cases),4):
 subprocess.run([sys.executable,str(w/'observe.py'),cases[j],f'rows{j+1:02}',str(4+2*i)],env=dict(os.environ,ROUNDS='1'),check=True)
