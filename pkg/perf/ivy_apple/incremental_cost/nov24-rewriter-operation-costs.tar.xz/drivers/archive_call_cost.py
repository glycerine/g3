from common import *
import io,tarfile
root=d/'portable-call-cost';tmp=d/'call-cost-summary';tmp.mkdir(exist_ok=True)
def emit(name,head,rows):
 with(tmp/name).open('w')as f:z=csv.writer(f);z.writerow(head);z.writerows(rows)
def calculations():
 rows=[]
 for op in ['visit','app','find','insert']:
  for n in ['tlb','flash2','hybrid_reliable_broadcast_cisa']:
   p=root/op/n/'runs.csv';rs=readcsv(p);assert len(rs)==10
   for r in rs:
    s=readcsv(root/op/n/(r['round']+'-'+r['engine'])/'calls.csv')
    for k in sorted({v['pass'] for v in s}):
     a=[v for v in s if v['pass']==k];calls=sum(int(v['calls'])for v in a);num=sum(int(v['samples'])for v in a);net=sum(int(v['raw'])-int(v['samples'])*int(v['empty'])for v in a)
     assert num;rows.append([op,n,r['engine'],r['round'],r['offset'],k,calls,num,net,net/num])
 emit('phase-calls.csv','operation spec engine round offset pass calls samples adjusted_sample_instructions mean_per_sample'.split(),rows)
 rows=[]
 for f in (d/'activity-shapes').glob('*/*.csv.gz'):
  src=list(csv.DictReader(gzip.open(f,'rt')))
  if not src:continue
  cols=list(src[0])[2:]
  for k in sorted({r['pass']for r in src}):rows.append([f.parent.name,f.stem.split('.')[0],k,*[sum(int(r[c])for r in src if r['pass']==k)for c in cols]])
 emit('cache-use.csv',['spec','round','pass',*cols],rows)
def main():
 calculations()
 dest=pkg/'perf/ivy_apple/incremental_cost/nov24-rewriter-operation-costs.tar.xz'
 with tarfile.open(dest,'w:xz',preset=3)as ar:
  def add(n,b):
   h=tarfile.TarInfo(str(n));h.size=len(b);ar.addfile(h,io.BytesIO(b))
  def tree(path,patterns,tag):
   files={p for pat in patterns for p in path.glob(pat)if p.is_file()}
   for p in sorted(files):add(tag+'/'+str(p.relative_to(path)),p.read_bytes())
  note='''Portable measurements: g3 b7caff4fa, GoIvy 3d552b46c, its linked C++ Z3 fork, linux/amd64. The private Go workspace resolves the local checkout. Each row is a count or calibrated sample inside a first physical Push on the same OS thread. Only complete matched stdout, stderr and expected exits were accepted. Five rotations per input and operation use offsets 0,17,34,51,62 in a 67-call period, restarting at phase entry. A dedicated binary per operation measures inclusive instructions, counting user mode only and rejecting multiplexed samples. Mean per sampled call = sum(raw - empty * samples) / sum(samples) across all passes of the indicated name within a run. The report uses medians of these five within-run means. Nested operations overlap. Samples include instrumented call boundaries and are unsuitable for wall timing. Reproduce with incremental_cost/rewriter_call_cost.py once per input and operation. The Flash input is examples/ivy/flash2.ivy, the hybrid and TLB inputs are examples/liveness/hybrid_reliable_broadcast_cisa.ivy and examples/liveness/tlb.ivy. Use the exact supplied case pathname and expected exit when constructing references. The native build embeds recompiled copies of matching asserted_formulas.o and th_rewriter.o or wraps the actual cache operation in the GoIvy archive. initial/ has a second set on the previous source 2fdeac3be. stacks/ contains two separately instrumented profile rounds from that prior source, exclusively during first pushes and attributed to matching pass and OS thread. The sampling period is 160001 user instructions. cache-use/ observes data shapes using b7caff4fa. Its release preflight sums all retained per-node references without mutating the cache. Some caches survive one pass and release their entries in another; use each observation's own denominator. Short scratch drivers are included for historical provenance; the portable driver also exists in the source tree.'''
  add('README.txt',note.encode());tree(tmp,['*.csv'],'summary')
  tree(root,['*/*/runs.csv','*/*/*/calls.csv','*/flash2/build-*/build-info.txt'],'portable')
  tree(d/'visitor-cost',['*/*/*/calls.csv','*/go/build-info.txt'],'initial')
  tree(d/'visitor-profile',['*/*/stacks.csv.gz','*/*/decode.log'],'stacks')
  tree(d/'activity-shapes',['*/*.csv.gz','build-info.txt'],'cache-use')
  tree(d,['cache_shapes.py','visitor_cost.py','visitor_profile.py','portable_calls.py','archive_call_cost.py'],'drivers')
 print(dest,dest.stat().st_size)
if __name__=='__main__':main()
