from common import *
from bisect import bisect_left
import visitor_cost as vc,macro_identity as mi
root=d/'activity-shapes';root.mkdir(exist_ok=True)
def make():
 ed=vc.frontend();q=pkg/'smtcore/smt_asserted_driver.go';s=q.read_text();x='if err := assertedVerbose(10,';s=s.replace(x,'defer ast.BeginActivityShape(pass.sourceName())()\n'+x,1);ed[q]=once(s,'import "fmt"','import "fmt"\nimport "github.com/glycerine/g3/pkg/ast"')
 q=pkg/'ast/ast_activity_cache.go';s=q.read_text();x='type activityCacheEntries struct {';s=once(s,x,x+'\n trialFind ASTHandle;trialLastMiss bool;trialIdentity bool;trialMixed bool')
 i=s.index('func (c *ActivityCache) Insert(');x='if c.activityCacheEntries == nil {';k=s.index(x,i);s=s[:k]+'''if shapeActive {
 sh[0]++;if k==v{sh[1]++};if !ready{sh[2]++}
 if c.activityCacheEntries==nil || c.table.size==0 {sh[3]++}
 if c.activityCacheEntries!=nil {if c.unused>=c.maxUnused{sh[4]++};if !c.table.hasFreeCells(){sh[5]++};if c.table.slots!=0 {b:= &c.table.cells[int32(hash&uint32(c.table.slots-1))];if b.next==activityChashFree {sh[6]++}else if b.entry.key==key{sh[7]++}else{sh[8]++}}}
 }
 '''+s[k:]
 s=once(s,'entry := c.table.put(key, hash, k.origin == m.origin)','''if c.table.size==0 {c.trialIdentity=true;c.trialMixed=false};if k!=v{c.trialMixed=true};if k==c.trialFind{c.trialLastMiss=false}
 entry:=c.table.put(key,hash,k.origin==m.origin)
 if shapeActive{if entry.dummy{sh[9]++}else if m.external(entry.value)==v{sh[10]++}else{sh[11]++}}
 ''')
 x='entry := c.table.find(astNodeRef{k.slot, k.generation}, hash)';s=once(s,x,x+'''
 if shapeActive{sh[12]++;if entry==nil{sh[13]++;if c.trialFind==k&&c.trialLastMiss{sh[14]++}}else{sh[15]++;if !entry.accessed{sh[16]++};if entry.key==entry.value{sh[17]++}}}
 c.trialFind=k;c.trialLastMiss=entry==nil
 ''')
 s=once(s,'return c.table.each(c.retire)','''if shapeActive && c.table.size>0{
 sh[18]++;if c.trialIdentity&&!c.trialMixed{sh[19]++}
 survival:=true;entries:=uint64(c.table.size);refs:=map[astNodeRef]uint32{}
 c.table.each(func(a *astActivityEntry)error{if a.keyHeld{refs[a.key]++};if a.valueHeld{refs[a.value]++};return nil})
 for k,n:=range refs{if c.manager.nodeAt(k.slot).rc<=n{survival=false;break}}
 sh[20]+=entries;if survival{sh[21]++;sh[22]+=entries};if c.trialIdentity&&!c.trialMixed{sh[23]+=entries;if survival{sh[24]+=entries}}
 };return c.table.each(c.retire)''')
 ed[q]=s;ed[pkg/'ast/act_shape_study.go']='''package ast
import("fmt";"os";"runtime";"syscall";"unsafe")
var shapeActive bool
var sh [25]uint64
func shapeNow()int64{var t syscall.Timespec;_,_,e:=syscall.RawSyscall(syscall.SYS_CLOCK_GETTIME,1,uintptr(unsafe.Pointer(&t)),0);if e!=0{panic(e)};return t.Nano()}
func BeginActivityShape(n string)func(){if shapeActive|| n!="propagate-values"&&n!="pattern-inference"&&n!="maximizing-bv-sharing"{return func(){}};runtime.LockOSThread();tid:=syscall.Gettid();sh=[25]uint64{};shapeActive=true;a:=shapeNow();return func(){b:=shapeNow();runtime.UnlockOSThread();shapeActive=false;fmt.Fprintln(os.Stderr,"ACTIVITY-SHAPE",n,tid,a,b,sh)}}
'''
 o=overlay(root/'overlay',ed);b=build(root/'checker',o=o);(root/'build-info.txt').write_text(linked(b));return b
def lane(t):
 j,b=t;c,n,sp,iso,rc,_,rf=j;rd=root/n;rd.mkdir()
 for i in range(2):
  p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else []),examples/sp],env=dict(env,GOMAXPROCS='1'),cwd=rd,capture_output=True)
  spans=[];events=[];rest=bytearray()
  for l in p.stderr.splitlines(keepends=True):
   if l.startswith(b'W-INTERVAL '):
    _,bi,kind,_,tid,a,z=l.split()
    if kind==b'first':spans.append(tuple(map(int,(bi,tid,a,z))))
   elif l.startswith(b'ACTIVITY-SHAPE '):
    xs=l.decode().replace('[','').replace(']','').split();events.append((xs[1],*map(int,xs[2:])))
   else:rest.extend(l)
  assert p.returncode==rc and (p.stdout,rest)==tuple((rf/k).read_bytes()for k in ('stdout','stderr')),(n,p.returncode,rest[-170:])
  ends=[x[3]for x in spans];assert ends==sorted(ends)
  with gzip.open(rd/f'{i+1}.csv.gz','wt')as f:
   z=csv.writer(f);z.writerow('push pass inserts identity uncertain empty eviction full empty_bucket head_match collision fresh repeat replace finds miss repeated_miss hit first_access identity_hit releases identity_tables released_entries surviving_tables surviving_entries identity_entries surviving_identity_entries'.split())
   for label,tid,a,b2,*counts in events:
    ix=bisect_left(ends,a)
    if ix<len(ends)and spans[ix][1]==tid and spans[ix][2]<=a<=b2<=ends[ix]:z.writerow([spans[ix][0],label,*counts])
  print(n,i+1,len(spans),flush=True)
if __name__=='__main__':
 b=make();js=[j for j in mi.jobs()if j[1]in ('tlb','flash2','hybrid_reliable_broadcast_cisa','cf_live','dramc_nb2','toy-consensus','raftok','ordinary')]
 with ThreadPoolExecutor(8)as ex:list(ex.map(lane,[(j,b)for j in js]))
