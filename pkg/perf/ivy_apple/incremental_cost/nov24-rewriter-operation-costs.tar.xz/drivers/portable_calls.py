from common import *
from types import SimpleNamespace
import macro_identity as mi
sys.path.insert(0,str(pkg/'perf/ivy_apple/incremental_cost'))
import rewriter_call_cost as cost
root=d/'portable-call-cost';root.mkdir(exist_ok=True)
def cases():
 return [j for j in mi.jobs()if j[1]in ('tlb','flash2','hybrid_reliable_broadcast_cisa')]
def study(op):
 js=cases()
 c,n,sp,iso,rc,_,ref=next(j for j in js if j[1]=='flash2')
 out=root/op;out.mkdir(exist_ok=True)
 stage=out/'flash2'
 cmd=[sys.executable,cost.__file__,'--goivy',ivy,'--spec',examples/sp,'--reference',ref,'--cpu',str(26+list(cost.OPS).index(op)),'--operation',op,'--expect-exit',str(rc),'--rounds','5','--output',stage,'--abc',prior/'spec-survey/with-abc-native/abc']
 if iso:cmd+=['--isolate',iso]
 with(w/'build.lock').open('a')as lk,(out/'driver.log').open('w')as log:
  fcntl.flock(lk,fcntl.LOCK_SH);run(cmd,stdout=log,stderr=log)
 def lane(j):
  _,n,sp,iso,rc,_,rf=j;outn=out/n;outn.mkdir()
  args=SimpleNamespace(cpu=(4 if n=='tlb'else 16)+list(cost.OPS).index(op),operation=op,spec=examples/sp,isolate=iso,reference=rf,expect_exit=rc)
  with(outn/'runs.csv').open('w')as f:
   z=csv.writer(f);z.writerow('round operation offset engine pushes samples'.split())
   for i,offset in enumerate(cost.OFFSETS):
    for en in (['g3','native']if i%2==0 else['native','g3']):
     b=stage/('build-'+en)/'goivy_check';n,k=cost.measure(args,b,outn/f'{i+1}-{en}',offset)
     z.writerow([i+1,op,offset,en,n,k]);f.flush()
  print(op,j[1],'done',flush=True)
 with ThreadPoolExecutor(2)as ex:list(ex.map(lane,(j for j in js if j[1]!='flash2')))
 print(op,'complete',flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(2)as ex:list(ex.map(study,cost.OPS))
