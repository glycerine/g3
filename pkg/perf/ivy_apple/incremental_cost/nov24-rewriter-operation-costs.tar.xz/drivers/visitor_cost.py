from common import *
import macro_identity as mi,shutil
from bisect import bisect_left
sys.path.insert(0,str(pkg/'perf/ivy_apple'));from relevance_counts import make_value
root=d/'visitor-cost';root.mkdir(exist_ok=True)
src=pkg.parent/'src';cpp=pkg.parent/'build';stage=w/'portable-pass-final/build'
modes=['visit','app','find','insert']
def frontend():
 return {ivy.resolve()/p.name:p.read_text()for p in (stage/'ivy/goivy').glob('*.go')}
gohelper=r'''package visitmeter
import("fmt";"os";"runtime";"strconv";"syscall";"unsafe")
var fd uintptr;var active bool;var total,samples,sum,empty,offset uint64
func clock()int64{var t syscall.Timespec;_,_,e:=syscall.RawSyscall(syscall.SYS_CLOCK_GETTIME,1,uintptr(unsafe.Pointer(&t)),0);if e!=0{panic(e)};return t.Nano()}
func count()uint64{var v [3]uint64;n,_,e:=syscall.RawSyscall(syscall.SYS_READ,fd,uintptr(unsafe.Pointer(&v[0])),24);if e!=0||n!=24||v[1]!=v[2]{panic("incomplete counter")};return v[0]}
//go:noinline
func Enter()uint64{if !active{return 0};total++;if (total+offset)%67!=0{return 0};samples++;return count()}
//go:noinline
func End(t uint64){if t!=0{sum+=count()-t}}
//go:noinline
func calibrate(){defer End(Enter())()}
func Begin(name string)func(){if active || (name!="propagate-values" && name!="maximizing-bv-sharing" && name!="pattern-inference"){return func(){}};runtime.LockOSThread()
 var attr struct{Type,Size uint32;Config,Period,SampleType,ReadFormat,Flags uint64;Padding [16]byte};attr.Size=uint32(unsafe.Sizeof(attr));attr.Config=1;attr.Flags=1<<5|1<<6;attr.ReadFormat=3
 var err syscall.Errno;fd,_,err=syscall.RawSyscall6(syscall.SYS_PERF_EVENT_OPEN,uintptr(unsafe.Pointer(&attr)),0,^uintptr(0),^uintptr(0),0,0);if err!=0{panic(err)}
 tid:=syscall.Gettid();active=true;offset=0;total,samples,sum=0,0,0;for i:=0;i<9;i++{total=66;calibrate()};empty=sum/samples
 offset,_=strconv.ParseUint(os.Getenv("VISIT_OFFSET"),10,64);total,samples,sum=0,0,0;start:=clock()
 return func(){end:=clock();active=false;syscall.Close(int(fd));runtime.UnlockOSThread();fmt.Fprintln(os.Stderr,"VISIT-COST",name,tid,start,end,total,samples,sum,empty)}
}
'''.replace('End(Enter())()','End(Enter())')
def go(v):
 od=root/v/'go';ed=frontend();drv=pkg/'smtcore/smt_asserted_driver.go';s=once(drv.read_text(),'package smtcore','package smtcore\nimport "github.com/glycerine/g3/pkg/util/visitmeter"');anchor='if err := assertedVerbose(10,'
 ed[drv]=s.replace(anchor,'defer visitmeter.Begin(pass.sourceName())()\n'+anchor,1);ed[pkg/'util/visitmeter/meter.go']=gohelper
 q,fun={'visit':('ast/rewriter/rewriter_engine.go','func (r *rewriterEngine) visit(t '),'app':('ast/rewriter/rewriter_engine.go','func (r *rewriterEngine) processApp()'),'find':('ast/ast_activity_cache.go','func (c *ActivityCache) Find('),'insert':('ast/ast_activity_cache.go','func (c *ActivityCache) Insert(')}[v]
 q=pkg/q;s=once(q.read_text(),'import (','import (\n"github.com/glycerine/g3/pkg/util/visitmeter"');i=s.index('{',s.index(fun))+1;ed[q]=s[:i]+'\n defer visitmeter.End(visitmeter.Enter())\n'+s[i:]
 b=build(od/'checker',o=overlay(od/'overlay',ed));(od/'build-info.txt').write_text(linked(b));return b
header=r'''#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <unistd.h>
namespace visitmeter {
struct state {int fd; unsigned long long total,samples,sum,empty,offset;};
extern thread_local state* active;
inline unsigned long long count(state& s){uint64_t v[3]; if(read(s.fd,v,sizeof(v))!=sizeof(v)||v[1]!=v[2])abort();return v[0];}
inline long long clock(){timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t))abort();return uint64_t(t.tv_sec)*1000000000+t.tv_nsec;}
[[gnu::noinline]] inline unsigned long long enter(){auto* s=active;if(!s)return 0;if((++s->total+s->offset)%67)return 0;++s->samples;return count(*s);}
[[gnu::noinline]] inline void end(unsigned long long t){if(t)active->sum+=count(*active)-t;}
struct sample {unsigned long long t=enter();~sample(){end(t);}};
[[gnu::noinline]] inline void calibrate(){sample measure;}
struct pass {
 state s{};int tid; char const* name;long long start;
 pass(char const* n):name(nullptr){
   if (active || (strcmp(n,"propagate-values")&&strcmp(n,"maximizing-bv-sharing")&&strcmp(n,"pattern-inference")))return;
   name=n;perf_event_attr a{};a.type=PERF_TYPE_HARDWARE;a.size=sizeof a;a.config=PERF_COUNT_HW_INSTRUCTIONS;a.exclude_kernel=a.exclude_hv=1;a.read_format=PERF_FORMAT_TOTAL_TIME_ENABLED|PERF_FORMAT_TOTAL_TIME_RUNNING;
   s.fd=syscall(SYS_perf_event_open,&a,0,-1,-1,0);if(s.fd<0)abort();tid=syscall(SYS_gettid);active=&s;
   for(int i=0;i<9;i++){s.total=66;calibrate();}s.empty=s.sum/s.samples;s.total=s.samples=s.sum=0;auto z=getenv("VISIT_OFFSET");s.offset=z?atoi(z):0;start=clock();}
 ~pass(){if(!name)return;long long stop=clock();active=nullptr;close(s.fd);fprintf(stderr,"VISIT-COST %s %d %lld %lld %llu %llu %llu %llu\n",name,tid,start,stop,s.total,s.samples,s.sum,s.empty);}
};}
'''
def native_one(v):
 od=root/v/'cpp';od.mkdir(parents=True,exist_ok=True)
 if (od/'checker/goivy_check').is_file():return od/'checker/goivy_check'
 hp=od/'visitmeter.h';hp.write_text(header);inc='#include "'+str(hp)+'"\n';unit='smt/asserted_formulas.cpp';ed={unit:once((src/unit).read_text(),'if (!s.should_apply()) return true;','if (!s.should_apply()) return true;\nvisitmeter::pass measured(s.id());')};ed[unit]=inc+'thread_local visitmeter::state* visitmeter::active=nullptr;\n'+ed[unit];target='ast/rewriter/rewriter_def.h'
 if v in ('visit','app'):
  key='bool rewriter_tpl<Config>::visit(expr * t, unsigned max_depth) {'if v=='visit'else 'void rewriter_tpl<Config>::process_app(app * t, frame & fr) {'
  edited=od/'visitor.h';edited.write_text(inc+once((src/target).read_text(),key,key+'\nvisitmeter::sample trial_measure;'))
  for name in [unit,'ast/rewriter/th_rewriter.cpp']:
   ed[name]=once(ed.get(name,(src/name).read_text()),'#include "'+target+'"','#include "'+str(edited)+'"')
 else:
  # Wrap the actual linked symbol. The vendor archive and local build differ
  # in this member, so keep the complete vendor implementation intact.
  sig='void*' if v=='find'else 'void';sym='_ZN9act_cache4findEP4expr'if v=='find'else '_ZN9act_cache6insertEP4exprS1_';args='void* c,void* key' + (',void* val'if v=='insert'else'');invoke='c,key'+(',val'if v=='insert'else'')
  wrap=od/'wrap.cpp';wrap.write_text(inc+'extern "C" '+sig+' __real_'+sym+'('+args+');\nextern "C" '+sig+' __wrap_'+sym+'('+args+'){visitmeter::sample measured;return __real_'+sym+'('+invoke+');}\n')
  run(['c++','-std=c++17','-O3','-fPIC','-c',wrap,'-o',od/'wrap.o'])
 lib=ivy/'z3vendor/native_lib/libz3.a';make=(cpp/'Makefile').read_text();cfg=(cpp/'config.mk').read_text()
 def compile(item):
  name,s=item;patched=od/Path(name).name;patched.write_text(s);obj=patched.with_suffix('.o');assert subprocess.check_output(['ar','p',lib,obj.name])==(cpp/Path(name).with_suffix('.o')).read_bytes(),name
  rule=re.search(r'\$\((includes_\d+)\).*'+re.escape('../src/'+name)+r'$',make,re.M)
  with(od/(obj.stem+'.log')).open('w')as out:run([*make_value(cfg,'CXX'),*make_value(cfg,'CXXFLAGS'),*make_value(make,rule[1]),'-o',obj,patched],cwd=cpp,stdout=out,stderr=out)
  return obj
 with ThreadPoolExecutor(2)as ex:objs=list(ex.map(compile,ed.items()))
 arc=od/'libz3.a';shutil.copyfile(lib,arc);run(['ar','rcs',arc,*objs]);bridge=ivy.resolve()/'smt/quantifier.go';a=frontend();a[bridge]=once(bridge.read_text(),'${SRCDIR}/../z3vendor/native_lib/libz3.a',str(arc));o=overlay(od/'overlay',a)
 if v not in ('find','insert'):return build(od/'checker','native',o)
 od2=od/'checker';od2.mkdir(exist_ok=True);b=od2/'goivy_check'
 with(w/'build.lock').open('a')as lk,(od2/'build.log').open('w')as out:
  fcntl.flock(lk,fcntl.LOCK_SH);run(['go','build','-p','4','-pgo=off','-buildvcs=false','-tags=xtrace_off,classic_z3','-mod=readonly','-modfile='+str(w/'local-checkout.mod'),'-overlay='+str(o),'-ldflags',f"-linkmode=external '-extldflags=-Wl,--wrap={sym} {od}/wrap.o {arc} -lstdc++ -lm -lgomp'",'-o',b,'./cmd/goivy_check'],cwd=ivy,stdout=out,stderr=out)
 if not(od2/'abc').exists():(od2/'abc').symlink_to(prior/'spec-survey/with-abc-native/abc')
 return b
def measure(t):
 c,n,sp,iso,rc,_,ref,v,bs=t
 for j,offset in enumerate([0,17,34,51,62]):
  for en,b in list(bs.items())[::1 if j%2==0 else -1]:
   rd=root/v/n/f'{j+1}-{en}';rd.mkdir(parents=True);p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else []),examples/sp],cwd=rd,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100',VISIT_OFFSET=str(offset)))
   spans=[];items=[];other=bytearray()
   for l in p.stderr.splitlines(keepends=True):
    xs=l.decode().split()
    if l.startswith(b'W-INTERVAL ') and xs[2]=='first':spans.append(tuple(map(int,[xs[1],*xs[4:]])))
    elif l.startswith(b'VISIT-COST '):items.append((xs[1],*map(int,xs[2:])))
    else:other.extend(l)
   assert p.returncode==rc and (p.stdout,other)==tuple((ref/k).read_bytes()for k in ['stdout','stderr']),(n,en,p.returncode,other[-250:])
   ends=[x[-1]for x in spans];assert ends==sorted(ends);kept=[]
   for name,tid,lo,hi,count,k,ins,empty in items:
    i=bisect_left(ends,lo)
    if i<len(spans) and spans[i][1]==tid and spans[i][2]<=lo<=hi<=spans[i][3]:kept.append((spans[i][0],name,count,k,ins,empty))
   assert kept and any(r[3]for r in kept),(v,n,en)
   with(rd/'calls.csv').open('w')as out:z=csv.writer(out);z.writerow('push pass calls samples raw empty'.split());z.writerows(kept)
   print(v,n,j+1,en,len(spans),len(kept),flush=True)
def main():
 js=[j for j in mi.jobs() if j[1]in ['tlb','hybrid_reliable_broadcast_cisa','flash2']]
 def batch(v):
  with ThreadPoolExecutor(2)as ex:f=ex.submit(native_one,v);g=go(v);b=f.result()
  bs={'g3':g,'native':b}
  with ThreadPoolExecutor(3)as ex:list(ex.map(measure,[(c,*j[1:],v,bs)for c,j in zip([2+2*modes.index(v),14+2*modes.index(v),24+2*modes.index(v)],js)]))
 with ThreadPoolExecutor(2)as ex:list(ex.map(batch,sys.argv[1:] or modes))
if __name__=='__main__':main()
