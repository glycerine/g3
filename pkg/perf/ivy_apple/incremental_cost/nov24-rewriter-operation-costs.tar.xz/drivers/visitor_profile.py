from common import *
import macro_identity as mi,first_push_frontier as ff
from bisect import bisect_left
from decimal import Decimal
sys.path.insert(0,str(pkg/'perf/ivy_apple/holdouts'));import first_push_profile as pf
root=d/'visitor-profile';root.mkdir(exist_ok=True)
def make(v):
 ed=ff.source();fn=ivy.resolve()/'logical_window.go';s=(w/'portable-pass-final/build/ivy/goivy/logical_window.go').read_text();s=once(s,'a := wTime()','studySignal("enable");a:=wTime()');s=once(s,'b := wTime()','b:=wTime();studySignal("disable")');s=once(s,'import (','import ("bufio";')
 s+='''
var ctl,ack *os.File
var rdr *bufio.Reader
func studySignal(cmd string){if ctl==nil{var e error;ctl,e=os.OpenFile(os.Getenv("VISIT_CTL"),os.O_RDWR,0);if e!=nil{panic(e)};ack,e=os.OpenFile(os.Getenv("VISIT_ACK"),os.O_RDWR,0);if e!=nil{panic(e)};rdr=bufio.NewReader(ack)};if _,e:=fmt.Fprintln(ctl,cmd);e!=nil{panic(e)};if _,e:=rdr.ReadString('\\n');e!=nil{panic(e)}}
'''
 ed[fn]=s
 if v=='native':
  ed={q:s for q,s in ed.items()if q.is_relative_to(ivy.resolve())};q=ivy.resolve()/'smt/quantifier.go';ed[q]=(w/'portable-pass-final/build/bin-native/quantifier.go').read_text()
 od=root/v;return build(od/'checker',v,overlay(od/'overlay',ed))
def lane(j,bs):
 c,n,sp,iso,rc,_,ref=j
 for i in range(2):
  for en,b in list(bs.items())[::1 if i==0 else -1]:
   rd=root/n/f'{i+1}-{en}';rd.mkdir(parents=True);ctl=rd/'ctl';ack=rd/'ack';os.mkfifo(ctl);os.mkfifo(ack);record=rd/'data';period=160001
   cmd=['taskset','-c',str(c),perf,'record','--no-buildid','--clockid','mono','--quiet','-m','1024','-e','instructions:u','-c',str(period),'--call-graph','fp'if en=='g3'else'dwarf,8192','--control',f'fifo:{ctl},{ack}','-D','-1','-o',record,'--',b,*(['isolate='+iso]if iso else[]),examples/sp]
   p=subprocess.run(cmd,cwd=rd,capture_output=True,env=dict(env,GOMAXPROCS='1',GOGC='100',VISIT_CTL=str(ctl),VISIT_ACK=str(ack)));(rd/'events.gz').write_bytes(gzip.compress(p.stderr));ordinary=bytearray();win=[];passes=[]
   for l in p.stderr.splitlines(keepends=True):
    if l.startswith(b'W-INTERVAL '):
     t=l.split();win.append(tuple(map(int,[t[1],*t[4:]])))
    elif l.startswith(b'ASSERTED-PASS '):
     t=l.decode().split()
     if t[1]in ('propagate-values','maximizing-bv-sharing','pattern-inference'):passes.append((t[1],*map(int,t[2:5])))
    elif l.strip() not in [b'Events enabled',b'Events disabled']:ordinary.extend(l)
   assert p.returncode==rc and (p.stdout,ordinary)==tuple((ref/k).read_bytes()for k in ('stdout','stderr')),(n,en,ordinary[-500:]);ends=[v[-1]for v in win];inner=[]
   for ps in passes:
    kind,tid,a,z=ps;k=bisect_left(ends,a)
    if k<len(ends)and win[k][1]==tid and win[k][2]<=a<=z<=win[k][3]:inner.append(ps)
   se=[t[-1]for t in inner];assert se==sorted(se) and inner
   counts=Counter();frames=[];tag=None
   def finish():
    if not tag:return
    for key,markers in [('app',('rewriterEngine).processApp','::process_app<')),('visit',('rewriterEngine).visit','>::visit<')),('find',('ActivityCache).Find','act_cache::find(')),('insert',('ActivityCache).Insert','act_cache::insert('))]:
     k=next((i for i,f in enumerate(frames)if any(m in f for m in markers)),None)
     if k is None:continue
     for level,func in [('child',frames[k-1]if k else '(self)'),('grandchild',frames[k-2] if k>=2 else '(self)'),('leaf',frames[0])]:counts[tag,key,level,func]+=1
    if frames:counts[tag,'pass','leaf',frames[0]]+=1
   with(rd/'decode.log').open('w')as log,subprocess.Popen([perf,'script','--ns','--no-inline','-F','tid,time,event,ip,sym,dso','-i',record],stdout=subprocess.PIPE,stderr=log,text=True)as f:
    for l in f.stdout:
     if hd:=pf.HEADER.match(l):
      finish();frames=[];tag=None;tid=int(hd[1]);ts=int(Decimal(hd[2])*1000000000);k=bisect_left(se,ts)
      if k<len(se)and inner[k][1]==tid and inner[k][2]<=ts:tag=inner[k][0]
     elif tag and (m:=pf.FRAME.match(l)):frames.append(m[1])
    finish();assert f.wait()==0 and counts
   assert 'lost'not in (rd/'decode.log').read_text().lower()
   with gzip.open(rd/'stacks.csv.gz','wt')as f:z=csv.writer(f);z.writerow('pass operation level function samples period'.split());z.writerows([*k,v,period]for k,v in counts.items())
   record.unlink();ctl.unlink();ack.unlink();print(n,i+1,en,len(inner),flush=True)
def main():
 with ThreadPoolExecutor(2)as ex:bs=dict(zip(['g3','native'],ex.map(make,['g3','native'])))
 js=[(c,*j[1:])for c,j in zip([7,11,13],(j for j in mi.jobs()if j[1]in ('tlb','hybrid_reliable_broadcast_cisa','flash2')))]
 with ThreadPoolExecutor(3)as ex:list(ex.map(lambda j:lane(j,bs),js))
if __name__=='__main__':main()
