from common import *
import io,tarfile
od=d/'reductions-report';od.mkdir(exist_ok=True)
def write(name,fields,rows):
 with(od/name).open('w')as f:z=csv.writer(f);z.writerow(fields);z.writerows(rows)
def summarize():
 data=[];summary=[]
 for op in ['constant','variable','substitution','fold','reduce','reduce-core']:
  for spec in ['tlb','hybrid_reliable_broadcast_cisa','flash2']:
   path=d/'rewriter-child-cost'/op/spec;rs=readcsv(path/'runs.csv');assert len(rs)==10,(op,spec)
   for r in rs:
    by=defaultdict(list)
    for x in readcsv(path/(r['round']+'-'+r['engine'])/'calls.csv'):by[x['pass']].append(x)
    for phase,xs in by.items():
     calls=sum(int(x['calls'])for x in xs);n=sum(int(x['samples'])for x in xs);net=sum(int(x['raw'])-int(x['empty'])*int(x['samples'])for x in xs)
     data.append([spec,op,phase,r['engine'],r['round'],calls,n,net,net/n if n else ''])
 for key in sorted({tuple(z[:4])for z in data}):
  vs=[z for z in data if tuple(z[:4])==key];summary.append([*key,median(z[5]for z in vs),sum(z[6]for z in vs),median(z[8]for z in vs if z[8]!='')if any(z[8]!=''for z in vs)else''])
 write('call-observations.csv','spec operation phase engine round calls samples calibrated_sum instructions_per_call'.split(),data);write('call-summary.csv','spec operation phase engine median_calls total_samples median_instructions_per_call'.split(),summary)
 agg=[]
 for spec in ['tlb','hybrid_reliable_broadcast_cisa','flash2']:
  for i in range(1,8):
   for en in ['g3','native']:
    pair=[]
    for trial in ['reduce-rule-cost','rule-probe-floor']:
     p=d/trial/spec/(str(i)+'-'+en)/'rules.csv.gz';a=defaultdict(lambda:[0,0])
     for r in csv.DictReader(gzip.open(p,'rt')):
      row=a[r['pass'],r['rule']];row[0]+=int(r['samples']);row[1]+=int(r['raw'])
     pair.append(a)
    for (phase,rule),(n,amt) in pair[0].items():
     nc,blank=pair[1].get((phase,rule),(0,0))
     if n and nc:agg.append([spec,phase,rule,en,i,n,nc,amt/n,blank/nc,amt/n-blank/nc])
 write('rule-observations.csv','spec phase rule engine round samples floor_samples mean_observed mean_blank same_signature_adjusted'.split(),agg)
 rules=[]
 for key in sorted({tuple(r[:4])for r in agg}):
  rs=[r for r in agg if tuple(r[:4])==key];rules.append([*key,len(rs),sum(v[5]for v in rs),sum(v[6]for v in rs),median(v[9]for v in rs),min(v[9]for v in rs),max(v[9]for v in rs)])
 write('rule-summary.csv','spec phase rule engine rounds samples floor_samples median_calibrated minimum maximum'.split(),rules)
 for z in summary:
  if z[:1]==['tlb']and z[2]=='propagate-values':print(z[1],z[3],z[4],round(z[6],1)if z[6]!=''else'-')
 print('by rule')
 for z in rules:
  if z[:2]==['tlb','propagate-values'] and z[5]>=50:print(z[2],z[3],z[5],round(z[7],1),*[round(v)for v in z[8:10]])
def archive():
 dst=pkg/'perf/ivy_apple/incremental_cost/nov24-reduction-rule-costs.tar.xz'
 with tarfile.open(dst,'w:xz',preset=3)as ar:
  def put(n,b):
   t=tarfile.TarInfo(n);t.size=len(b);ar.addfile(t,io.BytesIO(b))
  def feed(base,globs,pref):
   for f in sorted({p for pat in globs for p in base.glob(pat)if p.is_file()}):put(pref+'/'+str(f.relative_to(base)),f.read_bytes())
  put('README.txt',b'''Retired user instructions on the OS thread of the first push. The six operations are separately instrumented. Results are inclusive, and must not be added across nested calls or compared as though all had the same call frequency. Whole-call medians subtract the measured empty PMU interval at each push. Seven rule observations count one of each 67 calls at different offsets. Each instrumentation binary classifies the rule after stopping the outer counter. Dedicated floor binaries invoke an empty no-inline method with matching arguments and observer arrangement. Each observation subtracts the per-call floor measured on the same workload, offset, phase, language and rule. Sampling changes codegen. Comparisons of very rare rules are noisy. Observations are not elapsed times. All measured processes reproduce the expected exit, stdout and stderr. cost scripts are experiment sources; the main portable rewriter_call_cost.py CLI can build and repeat the six whole-operation measurements. Each compiler used the actual checkout; C++ rebuilt the selected archive object inside the in-tree fork and linked the full archive into the same GoIvy frontend. GoIvy 3d552b46c; these research builds for the instrumentation started on g3 37a8cf71d or preceding b7caff4fa depending on the operation.\n''')
  feed(od,['*.csv'],'summary')
  feed(d/'rewriter-child-cost',['*/*/runs.csv','*/*/[0-9]-*/*.csv','*/flash2/build-*/build-info.txt'],'operations')
  for tag in ['reduce-rule-cost','rule-probe-floor']:feed(d/tag,['*/*/rules.csv.gz','build/*/build-info.txt','build/g3/*.go','build/native/*.cpp','build/native/*.h'],tag)
  feed(d,['portable_calls.py','rewriter_child_cost.py','reduce_rule_cost.py','rule_probe_floor.py','report_reductions.py'],'drivers')
 print(dst,dst.stat().st_size)
if __name__=='__main__':
 summarize()
 if '--write'in sys.argv:archive()
