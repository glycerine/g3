from common import *
from types import SimpleNamespace
import portable_calls as pc
cost=pc.cost;root=d/'reduce-rule-cost';root.mkdir(exist_ok=True)
names=['uf','eq-uf','eq-bool','eq-arith','eq-bv','eq-dt','eq-other','not','and','or','ite','iff','implies','arith','bv','other']
def build_all():
 o=root/'build';o.mkdir(exist_ok=True);a=SimpleNamespace(goivy=ivy.resolve(),cpp_build=pkg.parent/'build',abc=prior/'spec-survey/with-abc-native/abc',operation='reduce-core')
 run(['go','work','init',pkg,ivy.resolve()],cwd=o,env=dict(env,GOWORK='off'));os.environ.update(env);os.environ['GOWORK']=str(o/'go.work')
 patch=gzip.decompress((cost.HERE/'nov24-first-pass-observers.patch.gz').read_bytes()).decode();front=''.join(h for h in re.split(r'(?=^--- )',patch,flags=re.M)if '\n+++ b/ivy/'in h)
 def mk(en):
  stage=o/en;stage.mkdir();files=cost.stage_patch(front,ivy.resolve(),stage)
  if en=='g3':
   f=pkg/'util/visitmeter/meter.go';s=(cost.HERE/'rewriter_call_meter.go.txt').read_text();s+='\nvar amounts,counts [16]uint64\nfunc Finish(a uint64)uint64{d:=instructions()-a;sum+=d;return d}\nfunc Note(cat int,v uint64){amounts[cat]+=v;counts[cat]++}\n'
   s=once(s,'start := monotonicNS()','clear(amounts[:]);clear(counts[:]);start:=monotonicNS()');s=once(s,'syscall.Close(int(fd))','for j,n:=range counts{if n>0{fmt.Fprintln(os.Stderr,"RULE-COST",name,tid,start,stop,j,n,amounts[j],empty)}};syscall.Close(int(fd))')
   cost.edit(files,stage,f,s);f=pkg/'smtcore/smt_asserted_driver.go';s=f.read_text().replace('package smtcore','package smtcore\nimport "github.com/glycerine/g3/pkg/util/visitmeter"');s=s.replace('if err := assertedVerbose(10,','defer visitmeter.Begin(pass.sourceName())()\nif err := assertedVerbose(10,',1);cost.edit(files,stage,f,s)
   f=pkg/'ast/rewriter/th_rewriter.go';s=f.read_text().replace('package rewriter','package rewriter\nimport "github.com/glycerine/g3/pkg/util/visitmeter"');i=s.index('{',s.index(cost.OPS['reduce-core'][1]))+1
   cls='''func(c *theoryRewriterConfiguration)studyKind(d ast.ASTHandle,args ast.AppArguments)int{
   m:=c.owner.manager;f,e:=m.GetFamilyID(d);if e!=nil{panic(e)}
   switch f{case ast.NullFamilyID:return 0;case c.arithmetic.family:return 13;case c.bitVector.bvFamily:return 14;case m.BasicFamilyID():
   k,e:=m.GetDeclKind(d);if e!=nil{panic(e)};switch k{case ast.ASTOpEq:x,e:=args.At(0);if e!=nil{panic(e)};s,e:=m.GetSort(x);if e!=nil{panic(e)};sf,e:=m.GetFamilyID(s);if e!=nil{panic(e)};switch sf{case ast.NullFamilyID:return 1;case m.BasicFamilyID():return 2;case c.arithmetic.family:return 3;case c.bitVector.bvFamily:return 4;case c.datatype.family:return 5;default:return 6}
   case ast.ASTOpNot:return 7;case ast.ASTOpAnd:return 8;case ast.ASTOpOr:return 9;case ast.ASTOpIte:return 10;case ast.ASTOpIff:return 11;case ast.ASTOpImplies:return 12}};return 15}'''
   s=s[:i]+'''\nif st:=visitmeter.Enter();st!=0{defer func(){d:=visitmeter.Finish(st);visitmeter.Note(c.studyKind(decl,args),d)}()}
   '''+s[i:]+'\n'+cls;cost.edit(files,stage,f,s);return cost.build_checker(a.goivy,stage,files,a.abc)
  h=(pkg.parent/'src/test/perf/ivy_rewriter_call_cost.h').read_text();h=once(h,'int fd = -1;', 'int fd=-1; uint64_t amounts[16]{}, tagged[16]{};')
  h=once(h,'class pass {','''template<class F> struct tag { F kind; uint64_t start; ~tag(){if(start){auto delta=instructions(*active)-start;active->sum+=delta;unsigned k=kind();++active->tagged[k];active->amounts[k]+=delta;}} };\nclass pass {''')
  h=once(h,'close(s.fd);','''for(unsigned j=0;j<16;j++)if(s.tagged[j])std::fprintf(stderr,"RULE-COST %s %d %llu %llu %u %llu %llu %llu\\n",name,tid,(unsigned long long)start,(unsigned long long)stop,j,(unsigned long long)s.tagged[j],(unsigned long long)s.amounts[j],(unsigned long long)empty);\nclose(s.fd);''');hp=stage/'rule.h';hp.write_text(h)
  import inspect
  code=inspect.getsource(cost.prepare_native);code=code.replace('def prepare_native(', 'def local_native(');anchor='HEADER + replace_one(theory.read_text(), method, method + sample)';code=once(code,anchor,'HEADER + replace_one(theory.read_text(), method, method + observer)')
  observer='''\nauto tag = [&]()->unsigned { auto fid=f->get_family_id();if(fid==null_family_id)return 0;if(fid==m_a_rw.get_fid())return 13;if(fid==m_bv_rw.get_fid())return 14;if(fid==m_b_rw.get_fid())switch(f->get_decl_kind()){
  case OP_EQ:{auto sf=m().get_sort(args[0])->get_family_id();if(sf==null_family_id)return 1;if(sf==m_b_rw.get_fid())return 2;if(sf==m_a_rw.get_fid())return 3;if(sf==m_bv_rw.get_fid())return 4;if(sf==m_dt_rw.get_fid())return 5;return 6;}
  case OP_NOT:return 7;case OP_AND:return 8;case OP_OR:return 9;case OP_ITE:return 10;case OP_IFF:return 11;case OP_IMPLIES:return 12;}return 15;};
  ivy_rewriter_cost::tag<decltype(tag)> measured{tag,ivy_rewriter_cost::enter()};'''
  g=dict(vars(cost),HEADER='#include "'+str(hp)+'"\n',observer=observer);exec(code,g);return g['local_native'](a,stage,files)
 with(w/'build.lock').open('a')as lk:
  fcntl.flock(lk,fcntl.LOCK_SH)
  with ThreadPoolExecutor(2)as ex:bs=dict(zip(['g3','native'],ex.map(mk,['g3','native'])))
 for en,b in bs.items():(o/en/'build-info.txt').write_bytes(subprocess.check_output(['go','version','-m',b]))
 return bs
def lane(j,bs):
 c,n,sp,iso,rc,_,rf=j;rd=root/n;rd.mkdir()
 for i,offset in enumerate([0,11,22,33,44,55,66]):
  for en,b in list(bs.items())[::1 if i%2==0 else -1]:
   td=rd/f'{i+1}-{en}';td.mkdir();p=subprocess.run(['taskset','-c',str(c),b,*(['isolate='+iso]if iso else[]),examples/sp],cwd=td,env=dict(env,GOMAXPROCS='1',GOGC='100',VISIT_OFFSET=str(offset)),capture_output=True);rest=bytearray();spans=[];rules=[]
   for l in p.stderr.splitlines(keepends=True):
    s=l.split()
    if l.startswith(b'W-INTERVAL '):
     if s[2]==b'first':spans.append(tuple(map(int,[s[1],s[4],s[5],s[6]])))
    elif l.startswith(b'VISIT-COST '):continue
    elif l.startswith(b'RULE-COST '):rules.append((s[1].decode(),*map(int,s[2:])))
    else:rest.extend(l)
   assert (p.returncode,p.stdout,rest)==(rc,(rf/'stdout').read_bytes(),(rf/'stderr').read_bytes()),(n,en,rest[-200:])
   ends=[row[3]for row in spans];total=0
   with gzip.open(td/'rules.csv.gz','wt')as f:
    z=csv.writer(f);z.writerow('batch pass rule samples raw empty'.split())
    for label,tid,start,end,cat,num,amount,blank in rules:
     k=cost.bisect_left(ends,start)
     if k<len(spans)and spans[k][1]==tid and spans[k][2]<=start<=end<=ends[k]:z.writerow([spans[k][0],label,names[cat],num,amount,blank]);total+=num
   assert total>0;print(n,i+1,en,total,flush=True)
if __name__=='__main__':
 bs=build_all()
 with ThreadPoolExecutor(3)as ex:list(ex.map(lambda j:lane(j,bs),pc.cases()))
