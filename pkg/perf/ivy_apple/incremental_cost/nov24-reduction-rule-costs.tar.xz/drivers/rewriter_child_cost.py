from common import *
import portable_calls as pc
pc.root=d/'rewriter-child-cost';pc.root.mkdir(exist_ok=True)
ops=['reduce','reduce-core','substitution','variable','constant','fold']
with ThreadPoolExecutor(3)as ex:list(ex.map(pc.study,ops))
