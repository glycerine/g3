from common import *
import reduce_rule_cost as base,inspect
root=d/'rule-probe-floor';root.mkdir(exist_ok=True)
source=inspect.getsource(base.build_all)
i=source.index('s=s[:i]+');j=source.index('cost.edit(files,stage,f,s)',i)
source=source[:i]+'''signature='func (c *theoryRewriterConfiguration) studyBlank(decl ast.ASTHandle,args ast.AppArguments,out ast.ASTRef) (RewriteStatus,error) {'
   measured='if st:=visitmeter.Enter();st!=0{defer func(){delta:=visitmeter.Finish(st);visitmeter.Note(c.studyKind(decl,args),delta)}()}'
   s=s[:i]+'\\nc.studyBlank(decl,args,out)\\n'+s[i:]+'\\n'+cls+'\\n//go:noinline\\n'+signature+measured+';return RewriteFailed,nil}\\n';'''+source[j:]
x="g=dict(vars(cost),HEADER="
i=source.index(x);source=source[:i]+'''method=cost.THEORY_METHODS['reduce-core']
  code=once(code,'replace_one(theory.read_text(), method, method + observer)','replace_one(theory.read_text(), method, blank_method + observer + "}" + method + " study_blank(f,num,args);")')
  blank_method='[[gnu::noinline]] void study_blank(func_decl *f,unsigned num,expr* const* args){'
  '''+source[i:]
source=source.replace("observer=observer);exec", "observer=observer,blank_method=blank_method);exec")
g=dict(vars(base),root=root);exec(source,g);base.root=root
bins=g['build_all']()
with ThreadPoolExecutor(3)as ex:list(ex.map(lambda j:base.lane(j,bins),base.pc.cases()))
